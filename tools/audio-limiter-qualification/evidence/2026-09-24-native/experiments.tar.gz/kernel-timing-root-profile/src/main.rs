use deadpan_audio::{LimitedTile, LimiterContext};
use deadpan_core::AudioSample;
use std::{sync::atomic::AtomicBool, time::{Duration, Instant}};

fn main() {
    let cancelled = AtomicBool::new(false);
    for (name, frames) in [("quiet", 8192), ("hot", 8192), ("silence", 8192), ("hot-crop", 257)] {
        let source: Vec<_> = (0..100_000).map(|n| match name {
            "quiet" => { let v = (0.8 * (std::f64::consts::TAU * 1000.0 * (n as f64 + 0.5) / 48000.0).sin()) as f32; [v, v / 4.0] },
            "silence" => [0.0, -0.0],
            _ if n % 2 == 0 => [16.0, -8.0],
            _ => [0.0, -0.0],
        }).collect();
        let project = AudioSample(0)..AudioSample(100_000);
        let requested = AudioSample(45_993)..AudioSample(45_993 + frames);
        let required = LimitedTile::required_context(&project, &requested).unwrap();
        let count = required.end.0 - required.start.0;
        for repetition in 0..3 {
            let input = LimiterContext {
                project_samples: project.clone(), start: required.start,
                samples: source[required.start.0 as usize..required.end.0 as usize].to_vec(),
            };
            let begin = Instant::now();
            let result = LimitedTile::prepare(input, requested.clone(), begin + Duration::from_secs(60), &cancelled).unwrap();
            println!("{{\"case\":\"{name}\",\"repetition\":{repetition},\"context_frames\":{count},\"output_frames\":{frames},\"seconds\":{},\"min_gain\":{},\"peak\":{}}}", begin.elapsed().as_secs_f64(), result.min_gain(), result.peak);
        }
    }
}
