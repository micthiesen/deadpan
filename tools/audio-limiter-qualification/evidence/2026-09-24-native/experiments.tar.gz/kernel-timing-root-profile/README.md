# Native pure limiter timing with the repository release profile

2026-09-24, Apple M5 Max arm64 macOS, Rust 1.97.1. Source and command hashes are in `metadata.json`; raw successful observations are in `results.jsonl`. The harness declares the root release options exactly: one codegen unit, thin LTO, stripped debug information and enabled overflow checks. Three cold repetitions per case, with other workers active. Dependency compilation took 4m42s and is excluded from measured intervals.

| Case | Context frames | Output frames | Median ms | Min–max ms | Minimum gain | Final owned finite peak |
| --- | ---: | ---: | ---: | ---: | ---: | ---: |
| 0.8-amplitude 1 kHz tone | 66,688 | 8,192 | 105.740 | 100.119–106.806 | 1 | 0.8000609986847849 |
| Alternating 16/−8 stereo and exact zeros | 66,688 | 8,192 | 145.792 | 144.774–148.155 | 0.05139016546308994 | 0.8222426176071167 |
| All signed-zero context | 66,688 | 8,192 | 0.242 | 0.241–0.268 | 1 | 0 |
| Alternating hot, small cold request | 58,753 | 257 | 69.455 | 69.449–70.398 | 0.05139016546308994 | 0.8222426176071167 |

Each observation creates a fresh native detector and kernel over already prepared owned PCM. Input context copying, source decode, source resampling, Preserve and bus preparation are excluded. Native construction, limiter processing, final direct finite verification and returned allocations are included. Every output passed the production verifier. An independent finite-probe corpus audit remains separate.

At 48 kHz, 8,192 samples occupy 170.667 ms; this particular hot-case median leaves about 25 ms for other preparation. These three observations do not establish sustained playback deadlines. A fresh full halo for each 257-sample/5.354 ms output request is too expensive; integration needs canonical cached prepared batches. Deadline, cancellation, missing-context and final-ceiling failures remain explicit.

Earlier measurements using ordinary Cargo release with debug information are retained separately in `../kernel-timing`; they are not measurements of this profile. The two runs have the same frozen limiter source and identical reported gain/peak for these controls. This report does not claim mastered export or complete device performance qualification.
