"""Bind a native run to retained sources and one release binary; scratch writes only."""
from pathlib import Path
import hashlib,json,os,platform,subprocess,time,re,shutil

ROOT=Path(__file__).resolve().parent
REPO=Path('/Users/michael/Code/deadpan')
def sha(data): return hashlib.sha256(data).hexdigest()
def write(path,data):
    path.parent.mkdir(parents=True,exist_ok=True)
    with path.open('xb') as f: f.write(data)
def json_new(path,value): write(path,(json.dumps(value,indent=2,allow_nan=False)+'\n').encode())
def checked(args,**kwargs): return subprocess.check_output(args,**kwargs).decode().strip()
def snapshot():
    paths=checked(['git','ls-files','--cached','--others','--exclude-standard','-z','--',
        'Cargo.toml','Cargo.lock','rust-toolchain.toml','crates/deadpan-audio','crates/deadpan-core',
        'crates/deadpan-plan','crates/deadpan-media','native/deadpan-dsp','native/deadpan-source','native/deadpan-process'],cwd=REPO).split('\0')
    return {p:(REPO/p).read_bytes() for p in sorted(set(paths)) if p and (REPO/p).is_file()}
def main():
    meta=ROOT/f'provenance-{time.time_ns()}'
    meta.mkdir()
    before=snapshot()
    for path,data in before.items(): write(meta/'source'/path,data)
    for p in (ROOT/'harness').rglob('*'):
        if p.is_file(): write(meta/'harness'/p.relative_to(ROOT/'harness'),p.read_bytes())
    for name in ('audit.py','run.py','inputs.json'): write(meta/name,(ROOT/name).read_bytes())
    env=os.environ.copy();env.update(PATH='/Users/michael/.cargo/bin:'+env['PATH'],RUSTUP_TOOLCHAIN='1.97.1',RUSTC='rustc',DEADPAN_FFMPEG_PREFIX='/tmp/deadpan-media-compatible-xyhilms4/prefix',CARGO_TARGET_DIR=str(REPO/'target'))
    rustc=checked(['rustc','--version','--verbose'],env=env)
    cargo=checked(['cargo','--version'],env=env)
    assert rustc.startswith('rustc 1.97.1 ') and 'commit-hash: 8bab26f4f68e0e26f0bb7960be334d5b520ea452' in rustc
    assert cargo.startswith('cargo 1.97.1 ')
    assert shutil.which('rustc',path=env['PATH'])=='/Users/michael/.cargo/bin/rustc'
    assert shutil.which('cargo',path=env['PATH'])=='/Users/michael/.cargo/bin/cargo'
    json_new(meta/'compiler-before-build.json',{'rustc':rustc,'cargo':cargo,'rustc_path':shutil.which('rustc',path=env['PATH']),'cargo_path':shutil.which('cargo',path=env['PATH'])})
    command=['cargo','build','--manifest-path',str(ROOT/'harness/Cargo.toml'),'--release','--locked','--offline','-j','2']
    with (meta/'build.log').open('xb') as log:
        result=subprocess.run(command,cwd=REPO,env=env,stdout=log,stderr=subprocess.STDOUT)
    after=snapshot()
    if result.returncode or before!=after:
        json_new(meta/'rejected.json',{'build_exit':result.returncode,'changed_sources':[p for p in sorted(set(before)|set(after)) if before.get(p)!=after.get(p)]})
        raise SystemExit(f'Build/source binding rejected; retained at {meta}')
    binary=REPO/'target/release/deadpan-native-limiter-audit'
    binary_compilers=sorted(set(x.decode() for x in re.findall(rb'/rustc/[0-9a-f]{40}',binary.read_bytes())))
    assert binary_compilers==['/rustc/8bab26f4f68e0e26f0bb7960be334d5b520ea452'],binary_compilers
    write(meta/'deadpan-native-limiter-audit',binary.read_bytes())
    os.chmod(meta/'deadpan-native-limiter-audit',0o755)
    environment={'command':command,'rustc':rustc,'cargo':cargo,'binary_compiler_paths':binary_compilers,'platform':platform.platform(),
        'hardware_model':checked(['sysctl','-n','hw.model']),'hardware_memory':checked(['sysctl','-n','hw.memsize']),
        'cpu_brand':checked(['sysctl','-n','machdep.cpu.brand_string']),
        'load_average_at_start':checked(['sysctl','-n','vm.loadavg']),
        'timing_scope':'Observed wall time with possible concurrent workspace builds; not isolated performance qualification',
        'git_revision':checked(['git','rev-parse','HEAD'],cwd=REPO),'git_status':checked(['git','status','--short'],cwd=REPO),
        'source_sha256':{p:sha(data) for p,data in before.items()},'binary_sha256':sha(binary.read_bytes()),
        'harness_lock_sha256':sha((ROOT/'harness/Cargo.lock').read_bytes()),'inputs_manifest_sha256':sha((ROOT/'inputs.json').read_bytes()),
        'ffmpeg_prefix':env['DEADPAN_FFMPEG_PREFIX'],'scratch_only':True,'build_exit':result.returncode}
    json_new(meta/'environment.json',environment)
    output=meta/'render'
    print(json.dumps({'provenance':str(meta),'render':str(output),'binary_sha256':environment['binary_sha256']}),flush=True)
    command=[str(meta/'deadpan-native-limiter-audit'),str(meta/'inputs.json'),str(output)]
    with (meta/'render.log').open('x') as log:
        process=subprocess.Popen(command,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True)
        for line in process.stdout:
            log.write(line);log.flush()
            try:
                value=json.loads(line);print(json.dumps({k:value[k] for k in ('name','error','render_seconds') if k in value}),flush=True)
            except json.JSONDecodeError: print(line,end='',flush=True)
        status=process.wait()
    json_new(meta/'run-status.json',{'exit':status,'command':command,'sources_unchanged_after_run':before==snapshot()})
    if status: raise SystemExit(status)
    print(f'RENDER_READY {output}',flush=True)
if __name__=='__main__': main()
