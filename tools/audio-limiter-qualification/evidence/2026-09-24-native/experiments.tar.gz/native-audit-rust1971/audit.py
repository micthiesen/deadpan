"""Audit retained native limiter output. No optimization or filter sweep."""
from pathlib import Path
from decimal import Decimal, localcontext
import hashlib, importlib.util, json, math, platform, struct, sys, time
import numpy as np
import scipy

ROOT=Path(__file__).resolve().parent
CANDIDATE=Path('/tmp/deadpan-master-20260924/candidate/triggered17')

def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()
def write(path,value):
    with path.open('x') as f: json.dump(value,f,indent=2,allow_nan=False); f.write('\n')
def wav(path):
    data=path.read_bytes()
    assert struct.unpack('<4sI4s4sIHHIIHH4sI',data[:44])==(b'RIFF',len(data)-8,b'WAVE',b'fmt ',16,3,2,48000,384000,8,32,b'data',len(data)-44)
    result=np.frombuffer(data[44:],dtype='<f4').reshape(-1,2)
    assert np.isfinite(result).all()
    return result
def exact_bs(pcm,fir):
    def integer(value):
        bits,=struct.unpack('<I',struct.pack('<f',value)); exponent=(bits>>23)&255; frac=bits&((1<<23)-1)
        mag=frac if exponent==0 else ((1<<23)|frac)<<(exponent-1)
        return -mag if bits>>31 else mag
    maximum=0
    for channel in range(2):
        values=[integer(v) for v in pcm[:,channel]]
        maximum=max(maximum,max(map(abs,values),default=0)<<13)
        for phase in range(4):
            sums=[0]*(len(values)+11)
            for n,value in enumerate(values):
                for k in range(12): sums[n+k]+=value*fir[k][phase]
            maximum=max(maximum,max(map(abs,sums),default=0))
    return maximum
def bh(pcm,rows):
    best={'absolute':float(np.max(abs(pcm))), 'kind':'sample'}
    for phase,row in enumerate(rows,1):
        for ch in range(2):
            values=np.convolve(pcm[:,ch].astype(np.float64),row[::-1],mode='full')
            pos=int(np.argmax(abs(values))); value=float(values[pos])
            if abs(value)>best['absolute']:
                best={'absolute':abs(value),'signed':value,'phase':phase,'channel':ch,'anchor':pos-96,'kind':'BH96x32'}
    if best['kind']=='BH96x32':
        row=rows[best['phase']-1]; anchor=best['anchor']; ch=best['channel']
        with localcontext() as context:
            context.prec=80
            witness=sum((Decimal.from_float(float(pcm[anchor+d,ch]))*Decimal.from_float(float(row[d+96]))
                         for d in range(-96,97) if 0<=anchor+d<len(pcm)),Decimal(0))
            best['coefficient_exact_dot_80digits']=str(witness)
            best['dot_difference']=str(witness-Decimal.from_float(best['signed']))
    # All filters' direct summations have <=193 products and additions.
    # A global L1/max-input bound conservatively covers every anchor.
    eps=2**-53; gamma=386*eps/(1-386*eps)
    error=gamma*float(np.max(np.sum(abs(rows),axis=1)))*float(np.max(abs(pcm)))
    best['conservative_f64_error']=error
    best['upper_with_f64_error']=best['absolute']+error
    best['passes_guarded_ceiling']=best['upper_with_f64_error']<=10**(-1/20)
    return best

def main():
    run=Path(sys.argv[1]); manifest=json.loads((ROOT/'inputs.json').read_text()); reports=json.loads((run/'results.json').read_text())
    assert len(reports)==len(manifest['inputs'])==25
    assert len({r['name'] for r in reports})==25
    by_name={r['name']:r for r in reports}
    coefficients=CANDIDATE/'coefficients'
    coefficient_hashes={name:sha(coefficients/name) for name in ('bs1770.f64le','blackman-harris-r96-32x.f64le')}
    original_environment=json.loads((CANDIDATE/'environment.json').read_text())
    assert all(original_environment['coefficient_hashes'][k]==v for k,v in coefficient_hashes.items())
    bs=np.fromfile(coefficients/'bs1770.f64le',dtype='<f8').reshape(12,4)
    assert np.all(bs*8192==np.round(bs*8192))
    fir=(bs*8192).astype(np.int64).tolist()
    rows=np.fromfile(coefficients/'blackman-harris-r96-32x.f64le',dtype='<f8').reshape(31,193)
    findings=[]; began=time.perf_counter()
    for case in manifest['inputs']:
        name=case['name']; input_path=Path(case['path']); report=by_name[name]
        assert sha(input_path)==case['sha256']
        if 'error' in report:
            findings.append({'name':name,'kernel_error':report['error']}); continue
        output_path=run/'outputs'/f'{name}.wav'; gain_path=run/'outputs'/f'{name}.gain.f64le'
        source=wav(input_path); output=wav(output_path); gain=np.fromfile(gain_path,dtype='<f8')
        assert source.shape==output.shape and len(gain)==len(source) and np.isfinite(gain).all()
        exact=exact_bs(output,fir)
        exact_pass=10*exact**20 <= 1<<(162*20)
        zeros=source==0; active_before=np.any(source!=0,axis=1); active_after=np.any(output!=0,axis=1)
        recreated=(source.astype(np.float64)*gain[:,None]).astype(np.float32)
        candidate=wav(CANDIDATE/'outputs'/f'{name}.wav')
        candidate_gain=np.fromfile(CANDIDATE/'outputs'/f'{name}.gain.f64le',dtype='<f8')
        result={'name':name,'frames':len(source),'input_sha256':case['sha256'],'output_sha256':sha(output_path),'gain_sha256':sha(gain_path),
            'exact_bs_numerator':str(exact),'exact_bs_denominator_exponent':162,'exact_bs_pass':exact_pass,'exact_bs_peak':exact/2**162,
            'bh':bh(output,rows),'gain_min':float(gain.min()),'gain_max':float(gain.max()),'gain_bounds_pass':bool(np.all((gain>=0)&(gain<=1))),
            'nominal_attack_step':float(np.max(np.maximum(0,gain[:-1]-gain[1:]),initial=0)),
            'nominal_release_step':float(np.max(np.maximum(0,gain[1:]-gain[:-1]),initial=0)),
            'shared_gain_recreates_f32':bool(np.array_equal(recreated.view(np.uint32),output.view(np.uint32))),
            'zero_bits_unchanged':bool(np.array_equal(source.view(np.uint32)[zeros],output.view(np.uint32)[zeros])),
            'active_frames_before':int(active_before.sum()),'active_frames_after':int(active_after.sum()),
            'active_frames_lost':int(np.sum(active_before & ~active_after)),
            'changed_frames':int(np.sum(np.any(source.view(np.uint32)!=output.view(np.uint32),axis=1))),
            'bytes_unchanged':bool(np.array_equal(source.view(np.uint32),output.view(np.uint32))),
            'candidate_changed_frames':int(np.sum(np.any(candidate.view(np.uint32)!=output.view(np.uint32),axis=1))),
            'candidate_max_abs_pcm_difference':float(np.max(abs(candidate.astype(np.float64)-output))),
            'candidate_gain_bits_equal':bool(np.array_equal(candidate_gain.view(np.uint64),gain.view(np.uint64))),
            'render_seconds':report['render_seconds'],'parity':report['parity']}
        result['four_pass_slope_pass']=result['nominal_attack_step']<=4/4096+1e-14 and result['nominal_release_step']<=4/8192+1e-14
        result['parity_pass']=all(p.get('f32_equal') and p.get('gain_equal') for p in report['parity'])
        result['finite_and_preservation_pass']=all((exact_pass,result['bh']['passes_guarded_ceiling'],result['gain_bounds_pass'],result['shared_gain_recreates_f32'],result['zero_bits_unchanged'],result['active_frames_lost']==0,result['four_pass_slope_pass'],result['parity_pass']))
        findings.append(result)
        print(json.dumps({k:result[k] for k in ('name','finite_and_preservation_pass','bytes_unchanged','candidate_changed_frames','render_seconds')}),flush=True)
    write(run/'independent-audit.json',{'scope':'exact BS4 integer arithmetic; pinned BH96/32 direct convolution with f64 error guard; no sinc sweep or listening claim',
        'python':sys.version,'numpy':np.__version__,'scipy':scipy.__version__,'platform':platform.platform(),
        'script_sha256':sha(Path(__file__)),'coefficient_hashes':coefficient_hashes,'audit_seconds':time.perf_counter()-began,'cases':findings})

if __name__=='__main__': main()
