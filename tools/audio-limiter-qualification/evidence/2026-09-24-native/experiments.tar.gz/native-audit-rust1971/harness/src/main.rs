use std::{fs::{self, OpenOptions}, io::Write, path::Path, sync::atomic::AtomicBool, time::{Duration, Instant}};
use deadpan_audio::{LimitedTile, LimiterContext, LIMITER_ID, LIMITER_MAX_OUTPUT_FRAMES};
use deadpan_core::AudioSample;
use serde_json::{json, Value};

fn write_new(path: &Path, bytes: &[u8]) -> Result<(), String> {
    OpenOptions::new().create_new(true).write(true).open(path).map_err(|e| e.to_string())?
        .write_all(bytes).map_err(|e| e.to_string())
}
fn pcm(path: &Path) -> Result<Vec<[f32; 2]>, String> {
    let bytes = fs::read(path).map_err(|e| e.to_string())?;
    if bytes.len() < 44 || &bytes[0..4] != b"RIFF" || &bytes[8..16] != b"WAVEfmt "
        || &bytes[36..40] != b"data" || u16::from_le_bytes(bytes[20..22].try_into().unwrap()) != 3
        || u16::from_le_bytes(bytes[22..24].try_into().unwrap()) != 2
        || u32::from_le_bytes(bytes[24..28].try_into().unwrap()) != 48000
        || u16::from_le_bytes(bytes[34..36].try_into().unwrap()) != 32
        || (bytes.len()-44)%8 != 0
        || u32::from_le_bytes(bytes[40..44].try_into().unwrap()) as usize != bytes.len()-44 {
        return Err("unexpected frozen WAV grammar".into());
    }
    let samples: Vec<_> = bytes[44..].chunks_exact(8).map(|v| [f32::from_le_bytes(v[..4].try_into().unwrap()), f32::from_le_bytes(v[4..].try_into().unwrap())]).collect();
    if samples.iter().flatten().any(|v| !v.is_finite()) { return Err("nonfinite input".into()); }
    Ok(samples)
}
fn render(source: &[[f32; 2]], start: usize, count: usize) -> Result<(LimitedTile, Value), String> {
    let request = AudioSample(start as i64)..AudioSample((start+count) as i64);
    let project = AudioSample(0)..AudioSample(source.len() as i64);
    let context = LimitedTile::required_context(&project, &request).map_err(|e| e.to_string())?;
    let begin = Instant::now();
    let tile = LimitedTile::prepare(LimiterContext { project_samples: project, start: context.start,
        samples: source[context.start.0 as usize..context.end.0 as usize].to_vec() },
        request, Instant::now()+Duration::from_secs(120), &AtomicBool::new(false)).map_err(|e| e.to_string())?;
    let report = json!({"start": start, "frames": count, "context_start":context.start.0,
        "context_end":context.end.0, "seconds":begin.elapsed().as_secs_f64(), "peak":tile.peak});
    if tile.samples.len()!=count || tile.gain.len()!=count { return Err("kernel returned wrong output length".into()); }
    Ok((tile, report))
}
fn wav(samples: &[[f32; 2]]) -> Vec<u8> {
    let n = (samples.len()*8) as u32;
    let mut b = Vec::new();
    b.extend(b"RIFF"); b.extend((36+n).to_le_bytes()); b.extend(b"WAVEfmt ");
    b.extend(16_u32.to_le_bytes()); b.extend(3_u16.to_le_bytes()); b.extend(2_u16.to_le_bytes());
    b.extend(48000_u32.to_le_bytes()); b.extend(384000_u32.to_le_bytes()); b.extend(8_u16.to_le_bytes()); b.extend(32_u16.to_le_bytes());
    b.extend(b"data"); b.extend(n.to_le_bytes());
    for pair in samples { for x in pair { b.extend(x.to_le_bytes()); } }
    b
}
fn run_case(name: &str, input: &Path, out: &Path) -> Result<Value, String> {
    let source=pcm(input)?;
    let mut output=Vec::with_capacity(source.len());
    let mut gain=Vec::with_capacity(source.len());
    let mut tiles=Vec::new();
    let started=Instant::now();
    let width=LIMITER_MAX_OUTPUT_FRAMES as usize;
    for start in (0..source.len()).step_by(width) {
        let (tile, report)=render(&source,start,width.min(source.len()-start))?;
        output.extend(tile.samples); gain.extend(tile.gain); tiles.push(report);
    }
    let render_seconds=started.elapsed().as_secs_f64();
    write_new(&out.join("outputs").join(format!("{name}.wav")), &wav(&output))?;
    let gain_bytes:Vec<u8>=gain.iter().flat_map(|v|v.to_le_bytes()).collect();
    write_new(&out.join("outputs").join(format!("{name}.gain.f64le")), &gain_bytes)?;
    let queries: Vec<(usize,usize)> = if name=="long-rapid-mask-16" || name=="long-ordinary-tone-0.8" {
        vec![(source.len()-1,1),(32761,31),(8191,3),(23001,1024),(0,1)]
    } else if name=="quiet-1-sample-fragment" {
        vec![(4094,4),(source.len()-1,1),(0,2)]
    } else { Vec::new() };
    let mut parity=Vec::new();
    for (start,count) in queries {
        match render(&source,start,count) {
            Ok((tile,mut report)) => {
                let pcm_equal=tile.samples.iter().zip(&output[start..start+count]).all(|(a,b)|a[0].to_bits()==b[0].to_bits() && a[1].to_bits()==b[1].to_bits());
                let gain_equal=tile.gain.iter().zip(&gain[start..start+count]).all(|(a,b)|a.to_bits()==b.to_bits());
                report["f32_equal"]=json!(pcm_equal); report["gain_equal"]=json!(gain_equal);
                parity.push(report);
            },
            Err(error)=>parity.push(json!({"start":start,"frames":count,"error":error})),
        }
    }
    Ok(json!({"name":name,"frames":source.len(),"render_seconds":render_seconds,"tiles":tiles,"parity":parity,
        "limiter_id":LIMITER_ID,"native_engine":deadpan_dsp::FIXED_PEAK_ENGINE_ID}))
}
fn main() -> Result<(), String> {
    let args:Vec<_>=std::env::args().collect();
    if args.len()!=3 { return Err("usage: audit manifest.json destination".into()); }
    let manifest:Value=serde_json::from_slice(&fs::read(&args[1]).map_err(|e|e.to_string())?).map_err(|e|e.to_string())?;
    let out=Path::new(&args[2]); fs::create_dir(out).map_err(|e|e.to_string())?;
    fs::create_dir(out.join("outputs")).map_err(|e|e.to_string())?;
    fs::create_dir(out.join("reports")).map_err(|e|e.to_string())?;
    let mut reports=Vec::new();
    for case in manifest["inputs"].as_array().ok_or("missing inputs")? {
        let name=case["name"].as_str().ok_or("missing name")?;
        let input=Path::new(case["path"].as_str().ok_or("missing path")?);
        let result=match run_case(name,input,out) { Ok(r)=>r, Err(error)=>json!({"name":name,"error":error}) };
        write_new(&out.join("reports").join(format!("{name}.json")), &serde_json::to_vec_pretty(&result).unwrap())?;
        println!("{}",result); std::io::stdout().flush().map_err(|e|e.to_string())?;
        reports.push(result);
    }
    write_new(&out.join("results.json"), &serde_json::to_vec_pretty(&reports).unwrap())?;
    Ok(())
}
