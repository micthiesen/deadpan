# Pinned compiler replay

This run corrects the earlier native audit's compiler attribution. Its environment
record and embedded binary compiler path prove that
`../native-audit/provenance-1790244980014579000` used Homebrew Rust 1.98.0. The old
README's Rust 1.97.1 statement was wrong; those original bytes remain retained.

`provenance-1790247077077703000` explicitly put `/Users/michael/.cargo/bin` first
in PATH, asserted both cargo and rustc 1.97.1 before building, and checked that the
resulting binary embeds only compiler commit
`8bab26f4f68e0e26f0bb7960be334d5b520ea452`. The exact root release profile is in
the retained harness manifest. Its binary SHA-256 is
`0d805acc07e0f328c7a7d007da5faf8be148d9be5af6859e41b51c741831a10b`.

All 25 frozen inputs rendered successfully; all 13 fresh shuffled/cold queries
matched canonical f32 PCM and f64 gain bytes. The same independent exact BS4 and
pinned BH96/32 finite audit passed all 25 outputs. Fourteen unity controls remain
unchanged. `compiler-replay-comparison.json` confirms all 50 PCM/gain files equal
the old Rust 1.98 outputs, and therefore the triggered17 candidate. The six
retained stronger sinc diagnostic failures and their point witnesses still apply
to these identical samples. No new sinc sweep or listening claim was made.

Source snapshots, the pre-build compiler checks, executable/compiler-path identity,
locked harness, logs, inputs manifest, native results and independent audit are
retained. Sources were unchanged across build and run. The build waited for the
application release build on the shared Cargo target. Timings are observations
under uncontrolled machine activity, not throughput or device-deadline qualification.

Executables and Cargo targets are excluded from the repository archive; hashes
remain in provenance. To reproduce, copy the harness into new scratch space,
point its path dependencies at the retained final source or a matching checkout,
use the exact retained release profile and dependencies, explicitly select the
rustup PATH, and retain new output paths. Do not overwrite either original run.
