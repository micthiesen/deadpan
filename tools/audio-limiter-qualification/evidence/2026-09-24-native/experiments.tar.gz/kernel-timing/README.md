# Native pure limiter cold preparation timing

Measured 2026-09-24 on Apple M5 Max, arm64 macOS, Rust 1.97.1. This is a developer harness, not an end-user dependency or a device deadline qualification. Other workers/builds were active. Three repetitions per case, each creating a fresh kernel/native detector from already prepared owned PCM. Source decode, resampling, Preserve DSP, bus preparation and copying the input context are excluded; native construction, four-pass processing with exact fixed-point early completion, final direct verification and output allocation are included.

Command:

```
DEADPAN_FFMPEG_PREFIX=/tmp/deadpan-media-compatible-xyhilms4/prefix CARGO_TARGET_DIR=/Users/michael/Code/deadpan/target cargo run --manifest-path /tmp/deadpan-master-20260924/kernel-timing/Cargo.toml --offline --locked --release > /tmp/deadpan-master-20260924/kernel-timing/optimized-results.jsonl
```

The scratch release profile uses ordinary Cargo release optimization and `debug=1`. It does not inherit the repository's single codegen unit, thin LTO, stripped debug information or overflow-check settings. Do not label these measurements as the full application's release profile.

Frozen kernel SHA-256: `b6cc3afb419b61d6dce1d8f87de82090421206197b56ae57721c8d0099da0c4d`.
Pinned coefficient source SHA-256: `0382365a3dd475bcbc133143af7dcac4a5a748b3c16d879cb4e6dc0dad11e97d`.
Coefficient binary bytes SHA-256: `488b81862c8d687fc9d612a00d10cd82b68f3041f6f716b442461e0f784b241c`.

| Case | Supplied context | Output | Median milliseconds | Min–max milliseconds | Minimum gain | Final owned finite peak |
| --- | ---: | ---: | ---: | ---: | ---: | ---: |
| 0.8-amplitude 1 kHz tone | 66,688 | 8,192 | 90.895 | 83.393–101.852 | 1 | 0.8000609986847849 |
| Alternating 16/−8 stereo and exact zeros | 66,688 | 8,192 | 121.003 | 116.151–124.305 | 0.05139016546308994 | 0.8222426176071167 |
| All signed-zero context | 66,688 | 8,192 | 0.180 | 0.175–0.242 | 1 | 0 |
| Alternating hot, small cold request | 58,753 | 257 | 69.941 | 64.197–70.086 | 0.05139016546308994 | 0.8222426176071167 |

All outputs passed the production final direct Kaiser64/BS4/sample verifier. This harness does not replace the independent finite-probe corpus audit. At 48 kHz, 8,192 output samples occupy 170.667 ms; these pure-kernel samples leave some time for the rest of the preparation path, but three cold observations do not prove sustained playback. The 257-sample cold request occupies only 5.354 ms, so rendering each small output request from a fresh full halo is unsuitable. Canonical cached prepared batches are required. The explicit missing-context, cancellation, deadline and final-ceiling errors remain necessary.

Prior to the exact zero and all-Q fixed-point optimizations, the same harness produced median 188.721 ms tone, 185.130 ms hot, 179.156 ms silence, and 133.167 ms hot-crop. Those preliminary values were captured in the tool session before this final source was compiled; they are comparison notes, not a separately sealed source revision. `optimized-results.jsonl` is the retained raw measurement for the final source above.

Focused checks on this kernel: nine integration tests passed (9.86 s aggregate debug), the three inline coefficient/horizon/final-verification tests passed, and strict all-target audio Clippy passed. The independent audit and full application gate belong to the parent task.
