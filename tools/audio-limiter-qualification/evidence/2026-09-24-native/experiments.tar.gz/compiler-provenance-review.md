# Compiler provenance review, 2026-09-24

The retained pipeline measurements used the pinned Rust 1.97.1 toolchain. The initial native numerical audit used Rust 1.98.0 and must retain that identity; its previous 1.97.1 claim was incorrect. No pipeline rerun is required for this issue. Preserve the original native audit and its correction, then qualify the separately pinned rerun independently.

This review made no production or old-evidence changes and ran no new numerical experiment. It examined retained executable hashes, embedded compiler commit paths, captured command/environment records and surviving Cargo artifacts. The report is newly written scratch evidence for archive retention.

## Retained executable evidence

Each pipeline executable's current SHA-256 matches the hash captured in its original `metadata.json`. Extracting Rust source commit paths from each binary produces exactly one distinct commit:

| Artifact | SHA-256 | Embedded Rust commit |
| --- | --- | --- |
| `/tmp/deadpan-master-20260924/pipeline-timing/bin/deadpan-master-pipeline-timing` | `7678e5b55a4b83059bc31115fdbdbca41bfb2e502dc140f97df4cde713191e25` | `8bab26f4f68e0e26f0bb7960be334d5b520ea452` |
| `/tmp/deadpan-master-20260924/pipeline-timing-cached/bin/deadpan-master-pipeline-timing` | `f0063db4f4d7bf078f19d1a11bc4b34f5b7e7c1da107c2423f929396afffe51e` | `8bab26f4f68e0e26f0bb7960be334d5b520ea452` |
| `/tmp/deadpan-master-20260924/native-audit/provenance-1790244980014579000/deadpan-native-limiter-audit` | `e3de683a6c979fbf65e6c653929bc8a3835707c0ffbfff8f6548981ee87702d7` | `88d9e12ae178fab0fb5cc050a94da85685d449ea` |

The pinned compiler's full `rustc -Vv` output identifies `8bab26f4f68e0e26f0bb7960be334d5b520ea452` as Rust 1.97.1, dated 2026-07-14, host `aarch64-apple-darwin`, LLVM 22.1.6. The native audit's captured `environment.json` explicitly identifies its compiler as Rust 1.98.0 Homebrew, commit `88d9e12ae178fab0fb5cc050a94da85685d449ea`. Its retained binary independently agrees with that captured environment.

Commands used for the binary check, repeated for each exact path above:

```
shasum -a 256 <artifact>
strings <artifact> | rg -o '/rustc/[0-9a-f]{40}' | sort -u
```

The pipeline Cargo commands were executed from `/Users/michael/Code/deadpan`, passing an external `--manifest-path`, rather than launching Cargo with a scratch working directory. The recorded commands and binary evidence support their original 1.97.1 attribution. The separately recorded `rustc --version` metadata alone would not have established the compiler used by a different subprocess.

## Kernel timing artifacts

The following surviving build products also contain only `8bab26f4f68e0e26f0bb7960be334d5b520ea452`:

| Artifact | SHA-256 | Role |
| --- | --- | --- |
| `/Users/michael/Code/deadpan/target/release/deadpan-limiter-kernel-timing` | `e83c9179a2279d92403ff8e48d2311ebae934dd3362ae9008a777d53d986e404` | Last kernel benchmark, matching root release profile |
| `/Users/michael/Code/deadpan/target/release/deps/deadpan_limiter_kernel_timing-5cbf1dc5653194ee` | `e83c9179a2279d92403ff8e48d2311ebae934dd3362ae9008a777d53d986e404` | Same executable in Cargo's dependency directory |
| `/Users/michael/Code/deadpan/target/release/deps/deadpan_limiter_kernel_timing-927439c4339ceb77` | `18f49439018dd2e91052795da1c7930ddc311723c2f741f7c314a817259fcebd` | Earlier ordinary Cargo release profile with `debug = 1` |

The matching-profile executable's observed modification time was 2026-09-24 03:20:16 local and size 538576 bytes. These surviving binaries were inspected after measurement; unlike the pipeline copies, their hashes were not included in the initial timing metadata. Preserve them as corroborating artifacts rather than retroactively claiming the earlier metadata sealed them.

The two kernel fingerprint JSON records and the pipeline fingerprint record report Cargo rustc fingerprint `11722972603611519644`, with empty `rustflags`. The matching root profile has profile fingerprint `2154336957897440151`; the earlier debug-information profile has `16832388881666374475`. The current `target/.rustc_info.json` reports Rust 1.97.1. Those live target records can be overwritten, so this review treats them as corroboration, not primary historical proof.

The earlier profile discrepancy remains separate from compiler version: `kernel-timing` declares ordinary release optimization with `debug = 1`; `kernel-timing-root-profile` and both pipeline harnesses declare one codegen unit, thin LTO, stripped debug information and enabled overflow checks. The former observations must stay labelled as preliminary, nonmatching-profile timings.

## Corrections and limits

- Correct the initial native audit's 1.97.1 attribution to the captured actual Rust 1.98.0. Keep its original outputs, environment and binary; do not overwrite them with a pinned rerun.
- A pinned native rerun is required before asserting those numerical measurements qualify the pinned 1.97.1 native build. No result of that rerun is inferred here.
- The retained pipeline binaries support their existing 1.97.1 identity. Their measured timings, cache comparisons and load limitations remain unchanged; no compiler-driven pipeline rerun is requested.
- Embedded commit paths identify the Rust implementation linked into each executable. They are independent binary evidence, not a complete compiler-invocation trace or a reproducible-build guarantee. The conclusion also uses captured working-directory/command records and, for the failing native audit, its explicit actual compiler environment.
- This review does not qualify another platform, toolchain, C++ compiler, future rebuild or different release profile. It changes no numerical acceptance result and makes no new playback or listening claim.
