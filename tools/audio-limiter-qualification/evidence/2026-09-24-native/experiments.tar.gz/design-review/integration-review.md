# LimitedAudio integration review

Read-only bounded review, 2026-09-24. No repository edits, DSP sweep, build, or
test execution. Other workers were still implementing the kernel/native bank.

## Result

No supported correctness finding in the current `limited.rs` wrapper and the
`stages.rs` preparation-budget/dependency extension. Kernel correctness and its
reported verification result remain the kernel reviewer's responsibility.

Reviewed paths:

- `crates/deadpan-audio/src/limited.rs`: `LimitedAudio::read`, `tile`, cache
  ownership and suppression assembly.
- `crates/deadpan-audio/src/stages.rs`: `PreparationBudget`, `PreparedBus`,
  `prepare_bus`, `revalidate_dependencies`, existing `WorkControl::observe`,
  private controlled reads and stage-cache admission.
- `crates/deadpan-audio/src/sequence.rs`: `resolve_source` and exact revision or
  retained-context provider contracts.

## Verified design properties

One read creates one PreparationBudget. Both possible canonical tiles reuse it
for cache revalidation and cold bus preparation. `prepare_bus` accumulates all
<=256-frame private reads under that same controller and unions each block's
complete dependencies. It does not build the dependency list only from newly
observed sources.

Revalidation calls `resolve_source` against the immutable plan, including the
special full-asset-contract path for retained audio contexts. `observe` rejects
a changed fingerprint for an asset already seen in the same request. Empty
dependency sets still execute a final budget/cancellation check.

The wrapper passes the exact shared deadline into `LimitedTile::prepare`, then
checks the budget before publishing the tile. A cache hit revalidates before
returning. The public read checks once more after assembling the result. A
failure can retain an earlier independently verified cached tile, but returns
no partial PCM result. No failed limiter tile is inserted into the cache.

The wrapper has one immutable StageAudio, no plan replacement setter, and a
fixed limiter identity. A canonical start therefore determines one tile range
within this cache. The final short tile clips to the actual full-project end.
An admitted <=8192-frame read reaches at most two canonical tiles. Cache residency
is four completed tiles; active limiter context and existing source/stage caches
are separately bounded. Suppression is clipped and merged in increasing tile
order; this records explicit authored suppression without reapplying a mask
after limiter verification.

## Halo scope clarified with the parent

Production acceptance is direct Kaiser radius64 plus BS, with raw sample floor.
BH radius96 is an independent external qualification measurement, not a hidden
production acceptance stage. The worker's conservative halos 37440 left and
21056 right are consistent with four passes using a canonical1024 detector
block allowance plus a radius64 final verifier. The wrapper requests canonical
8192 tiles, while the kernel separately promises arbitrary <=8192 intervals.

The earlier design note's direct-FIR radius96 bound remains an alternative
calculation; it does not alter the declared production filter scope. No claim
about complete sinc or physical DAC peak follows from these finite checks.

## Focused regression cases to retain

1. A request crossing two tiles where the provider returns a different
   fingerprint for the same asset between tile checks must reject the whole
   result, including when the first tile was cached.
2. A cached tile depending on Source PCM hidden inside Preserve/RoomTone/Bound
   preparation must revalidate that transitive source and reject provider
   refusal rather than return stale PCM.
3. Cancellation/deadline expiry on a warm tile with no media dependencies still
   rejects; this exercises the otherwise-empty revalidation path.
4. A cold two-tile read shares plan/preparation limits and deadline, rather than
   receiving fresh admission for its second context.
5. Kernel rejection publishes no tile; a later valid call can retry. Interior,
   crossing-seam, and short-final-tile reads equal crops of verified canonical
   output and retain absolute sample/suppression coordinates.

These are suggested integration coverage, not claimed executed tests. No issue
was elevated solely because its test was not yet written.
