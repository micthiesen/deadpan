# Bounded master candidate implementation review

Read-only mathematical/design review, 2026-09-24. No DSP sweep, production
qualification, or repository edits. The reviewed scratch pilot is
`/tmp/deadpan-master-20260924/candidate/pilot.py`, SHA-256
`98a7c7819bc9e0482d563cd4f7ccb513f2cd274b2d89b7d57668021a7c0b20a4`.
These conclusions concern the named finite filter banks, not universal sinc or
physical DAC behavior.

## 1. Direct FIR dependency bound

Let integer caps C be in [0,Q], Q=2^32. The pilot's backward attack and forward
release scans are:

    F[n] = min(C[n], F[n+1] + A), A=2^20
    G[n] = min(F[n], G[n-1] + B), B=2^19

The serial scan has the exact closed form:

    G[n] = min(min(j>=n, C[j] + A*(j-n)),
               min(j<=n, C[j] + B*(n-j)))

Expanding both scans minimizes over i<=n and j>=i. For fixed j the cheapest i
is min(n,j), which proves the expression above. Thus the serial implementation
does not secretly need an additional combined attack/release horizon.

At a future distance of 4096 or past distance of 8192, even a zero cap contributes
Q and cannot beat the local cap. Those horizons are conservative by one integer
sample, but safe. Seed scan boundaries with Q only after expanding the requested
working interval sufficiently. Never seed at the requested output crop.

With detector support radius R and cap dilation radius D, one output sample in
one pass depends on input within:

    left  = R + D + 8192
    right = R + D + 4096

R=D=64 gives 8320 left and 4224 right per pass. Four fixed passes require 33280
left and 16896 right. A final radius-96 verifier, evaluated at the owned output
anchors, adds 96 once: 33376 left and 16992 right. An 8192-frame master tile needs
at most 58560 source frames before clipping to the complete project. Check actual
bank support offsets, not tap count; the symmetric radius bound safely covers
the pilot's 129-tap Kaiser bank and the smaller BS bank.

Work backward through each pass before allocating or cropping. If final y4 is
needed over V, y3 is needed over V plus one pass halo, y2 over two, and so on.
Intermediate working boundaries must not become synthetic audio endpoints.

## 2. Project edges, validation anchors, and crop parity

Keep the interval of owned detector anchors separate from the PCM samples used
to evaluate those anchors. For an internal master tile [a,b), validate every
declared bank phase/channel and the raw sample floor at anchors in [a,b). Its
final PCM verification context is [a-Rmax,b+Rmax).

The first/last project tiles must additionally own outer zero-extension rows
whose filter support intersects the project: conservatively [-Rmax,0) and
[N,N+Rmax), where N is the exclusive project end. They are verification context,
not extra delivered PCM. No additional in-project source halo beyond the bound
above is required for these outer anchors; their extra PCM is outside the whole
project and exactly zero.

Read StageAudio only within [0,N); insert zeros only outside that complete
interval. A request crop, internal tile edge, cache boundary, or edit seam is
not a zero-extension boundary. For a short final tile, retain the same absolute
tile origin and filter-block geometry used by the rest of the project.

The pilot computes detector rows outside a PCM interval before cap dilation,
then crops caps to the real interval. Preserve this endpoint behavior. Detector
values immediately outside [0,N) need not be zero because their taps overlap
real PCM. Do not replace all such values or caps with unity at the boundary.
There is no need to materialize mastered output outside the project: it is zero.

Do not run a full-convolution acceptance check on every sample of a temporary
work buffer and accept/reject its artificial outer boundary. Those margins may
intentionally contain incomplete earlier-pass history. Restrict acceptance to
the owned anchor set after obtaining all of its required correct final PCM.

Required parity cases: stitched full tiles versus canonical whole output;
shuffled and repeated cropped reads; anchors b-1 and b at internal seams; first
and last project samples; N=1/2 and a partial final tile; a tiny Hard fragment
straddling a tile edge; actual explicit silence next to processed decay. Empty
projects, if admitted by the public master API, return an empty result without a
nonempty StageAudio call.

## 3. FFT implementation adds numerical block dependencies

Direct FIR with fixed coefficients and summation order has the finite dependency
bound above. FFT convolution additionally depends numerically on block origin,
transform length, zero padding and overlap/crop choices. An FFT size selected
from each request or final-tile length can change a near-threshold cap and hence
the final PCM even when the mathematical convolution is identical.

If FFT is selected, define a global, fixed detector output block lattice and
fixed transform/kernel plans, including Euclidean floor for negative positions.
For detector block core width T, let C_T(J) expand an anchor interval J to the
union of its canonical blocks. The backward interval operator for one pass is:

    previous = expand_R(C_T(expand_left_right(current, D+8192, D+4096)))

Apply that operator four times, rather than only adding the direct FIR halo.
At most T-1 extra samples per side per pass is a conservative numerical bound.
The pilot uses T=1024 and adds T per pass, a conservative allowance. Its fixed
FFT_LENGTH=1152, global tile alignment and retained valid convolution core must
remain part of the reproducible algorithm. A final FFT verifier needs its own
canonical block expansion; final filter radius alone does not describe it.

## 4. Shared gain, slope, and floating-point contract

The integer per-pass envelope obeys exactly:

    -A/Q <= g[n+1]-g[n] <= B/Q

For the ideal product of four gains in [0,1], telescoping adjacent products gives
directional bounds four times as large. Do not claim that the final accumulated
gain obeys the one-pass slope. Ordinary f64 multiplication adds a rounding-sized
residual; report/check a justified numerical tolerance, not exact real equality.
Q does not fit in u32. Use storage and checked arithmetic that represent Q and
all scan intermediates.

The actual pilot accumulates `gain *= envelope(caps)` and recomputes each pass as
`f32(original_f64 * accumulated_gain)`. The next detector observes that final
f32 output. This is not a chain of `f32(previous_f32 * new_gain)` operations.
Preserve one specified operation order; swapping these recipes changes bytes.
The accumulated shared gain reproduces final bytes with the pilot's recipe.

One shared gain preserves channel balance before the ordinary per-channel f32
rounding. It does not imply exact ratios after rounding, nor that every nonzero
subnormal survives. Finite nonnegative multiplication preserves exact zeros.
Compliant quiet input should produce exact unity caps on every pass and preserve
PCM bytes. Nonfinite input, detector values or products must fail explicitly.
The pilot admits input magnitude <=16; production must choose and check an
explicit admission range rather than silently inherit unlimited f32 magnitude.

Treat persisted f64 coefficients as the named finite bank's exact coefficients,
or separately account for coefficient-generation error. A direct f64 dot product
is still a numerical estimate. For a formal ceiling bound, add a conservative
summation/multiplication error bound (for example gamma_(2m) times sum(abs(h*x))
for m taps under the stated operation model), or retain an explicit sufficiently
large acceptance guard and qualify that numerical scope. No fast-math-dependent
reassociation should silently redefine the bank. The BS estimator, Kaiser bank
and independent BH bank are finite checks, not a physical-DAC guarantee.

## 5. Shared StageAudio admission and master cache

Current repository source now includes `StageAudio::prepare_edge_faded` in
`crates/deadpan-audio/src/stages.rs`. It collects <=256-frame private reads under
one WorkControl, which is the correct cumulative admission shape. Individual
public `read_edge_faded` calls each create a new controller and are not a safe
substitute for one bounded logical source-window preparation.

The current returned EdgeFadedBlock contains PCM and suppression but no complete
transitive dependency set. A reusable master tile needs the preparation's full
dependency/admission capability, including sources reached through cached
Preserve, RoomTone and Bound paths. A globally already-observed source set must
not cause a particular tile's own dependency set to be incomplete. Alternatively
a cache hit must repeat the necessary source-window admission explicitly.

Cache keys include the immutable plan identity, full-project end, master/filter
configuration and absolute tile coordinate. Hits recheck all transitive source
fingerprints and applicable admission/cancellation/deadline limits. Bound entry
count, resident PCM and transient detector/gain buffers separately. The direct
58560-frame stereo f32 input alone is 468480 bytes before gains or workspaces.
Do not publish a partially prepared or unverified tile.

## 6. Fixed-pass failure is an ordinary explicit result

Four passes are a bounded candidate, not a convergence theorem for signed FIR
reconstruction. After pass four, validate final f32 at every owned anchor with
the selected banks and sample floor. On failure return a typed error identifying
tile/sample, bank, channel/phase, observed bound, ceiling and pass count. Publish
no failed cache tile and enqueue no failed PCM. Do not hide a fifth pass, clip,
silently scale the program, lower monitor gain, insert zeros, or remask after
verification. Playback and export must use their existing explicit failure path.

A small failure-path test can inject a four-pass candidate with a 1.0 sample
against the -1 dB ceiling and assert validation failure plus no cache publication.
That proves rejection handling, not that the producer actually generates this
failure. Retain an actual algorithm counterexample only if measured by the
authorized candidate experiment. Complete-sinc diagnostic failures do not fail
this explicitly finite-bank contract unless a named acceptance bank also fails.
