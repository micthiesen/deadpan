"""ONE modest finite-bank limiter pilot, not adopted production processing.

Four bounded feedback passes. Final f32 is independently measured. Signed
reconstruction is not monotone under local gain reduction. Complete-sinc is
a named broader diagnostic, not the acceptance contract for this pilot.
"""
from pathlib import Path
import hashlib
import importlib.util
import json
import math
import platform
import subprocess
import sys
import time

import numpy as np
import scipy
from scipy import fft, ndimage

ROOT=Path(__file__).resolve().parent
REPO=Path('/Users/michael/Code/deadpan')
CORPUS=Path('/tmp/deadpan-limiter-20260924/finite-producer/experiment.py')
EXACT=Path('/tmp/deadpan-limiter-20260924/design-audit/audit_outputs.py')
R=64
PHASES=16
PASSES=4
TILE=1024
FFT_LENGTH=1152
Q=1<<32
A=1<<20
D=1<<19
TARGET_DB=-1.7
TARGET=10**(TARGET_DB/20)
CEILING=10**(-1/20)
LEFT_HALO=PASSES*(2*R+Q//D+TILE)
RIGHT_HALO=PASSES*(2*R+Q//A+TILE)


def load(path,name):
    spec=importlib.util.spec_from_file_location(name,path)
    module=importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


corpus=load(CORPUS,'retained_finite_corpus')
exact=load(EXACT,'retained_integer_fir_auditor')
BS=corpus.v3.bs_coefficients()
assert np.all(BS*8192==np.round(BS*8192))
BS_INTEGER=(BS*8192).astype(np.int64).tolist()


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def write(path,value):
    path.write_text(json.dumps(value,indent=2,allow_nan=False)+'\n')


def db(value):
    return 20*math.log10(value) if value else None


def kaiser_rows():
    d=np.arange(-R,R+1,dtype=float)
    rows=[]
    for phase in range(1,PHASES):
        t=d-phase/PHASES
        window=np.zeros_like(t)
        active=abs(t)<=R
        window[active]=np.i0(8.6*np.sqrt(1-(t[active]/R)**2))/np.i0(8.6)
        row=np.sinc(t)*window
        row/=np.sum(row)
        rows.append(row)
    return np.asarray(rows)


KAISER=kaiser_rows()
KERNELS=fft.rfft(KAISER[:,::-1],n=FFT_LENGTH,axis=-1)


def detector(pcm,origin=0):
    first,last=origin-R,origin+len(pcm)+R
    peaks=np.zeros(last-first)
    source=pcm.astype(np.float64)
    for tile in range((first//TILE)*TILE,last,TILE):
        input_first=tile-R
        block=np.zeros((2,TILE+2*R))
        lo,hi=max(origin,input_first),min(origin+len(pcm),input_first+len(block[0]))
        if lo<hi:
            block[:,lo-input_first:hi-input_first]=source[lo-origin:hi-origin].T
        transformed=fft.rfft(block,n=FFT_LENGTH,axis=-1)
        lo,hi=max(first,tile),min(last,tile+TILE)
        target=slice(lo-first,hi-first)
        for kernel in KERNELS:
            values=fft.irfft(transformed*kernel,n=FFT_LENGTH,axis=-1)
            linked=np.max(abs(values[:,2*R+lo-tile:2*R+hi-tile]),axis=0)
            np.maximum(peaks[target],linked,out=peaks[target])
    padded=np.pad(source,((R,R),(0,0)))
    np.maximum(peaks,np.max(abs(padded),axis=1),out=peaks)
    for phase in range(4):
        row=np.zeros(13)
        row[:12]=BS[::-1,phase]
        values=ndimage.correlate1d(padded,row,axis=0,mode='constant',cval=0)
        np.maximum(peaks,np.max(abs(values),axis=1),out=peaks)
    return peaks


def envelope(caps):
    assert len(caps)<1_000_000
    cap=np.floor(np.clip(caps,0,1)*Q).astype(np.int64)
    n=np.arange(len(cap),dtype=np.int64)
    future=np.minimum.accumulate((cap+n*A)[::-1])[::-1]-n*A
    gain=np.minimum.accumulate(future-n*D)+n*D
    assert np.all(gain>=0) and np.all(gain<=Q)
    return gain.astype(np.float64)/Q


def limit(source,origin=0):
    source=np.asarray(source,dtype=np.float32)
    assert source.shape[1:]==(2,) and 0<len(source)<1_000_000
    assert np.isfinite(source).all() and np.max(abs(source))<=16
    original=source.astype(np.float64)
    gain=np.ones(len(source))
    output=source.copy()
    history=[]
    for step in range(PASSES):
        peaks=detector(output,origin)
        caps=np.minimum(1,np.divide(TARGET,peaks,out=np.ones_like(peaks),where=peaks!=0))
        caps=ndimage.minimum_filter1d(caps,2*R+1,mode='constant',cval=1)[R:-R]
        gain*=envelope(caps)
        output=(original*gain[:,None]).astype(np.float32)
        history.append({'pass':step+1,'detected_before':float(peaks.max()),
                        'gain_min':float(gain.min()),'gain_max':float(gain.max())})
    return output,gain,history


def independent_rows():
    # A different radius/window/phase grid; direct convolution, no producer FFT.
    radius=96
    offsets=np.arange(-radius,radius+1,dtype=float)
    rows=[]
    for phase in range(1,32):
        d=offsets-phase/32
        position=(d+radius)/(2*radius)
        window=(0.35875-0.48829*np.cos(2*np.pi*position)
                +0.14128*np.cos(4*np.pi*position)-0.01168*np.cos(6*np.pi*position))
        window[abs(d)>radius]=0
        row=np.sinc(d)*window
        row/=np.sum(row)
        rows.append(row)
    return np.asarray(rows)


INDEPENDENT=independent_rows()


def independent_peak(pcm):
    maximum=float(np.max(abs(pcm)))
    for row in INDEPENDENT:
        for channel in range(2):
            values=np.convolve(pcm[:,channel].astype(np.float64),row[::-1],mode='full')
            maximum=max(maximum,float(np.max(abs(values))))
    return maximum


def exact_bs(pcm):
    maximum=exact.exact_bs(pcm.tolist(),BS_INTEGER)
    return maximum/(2**162),10*maximum**20<=(1<<(162*20))


def controls():
    yield from corpus.all_cases()
    n=np.arange(65536)
    raw=np.where(n%2==0,16.0,0.0)
    yield 'long-rapid-mask-16',np.column_stack((raw,raw)),'long coherent diagnostic; same detector configuration'
    quiet=0.8*np.sin(2*np.pi*1000*(n+0.5)/48000)
    yield 'long-ordinary-tone-0.8',np.column_stack((quiet,quiet/4)),'long ordinary unity control'


def run_case(name,source,description,oracle):
    source=np.asarray(source,dtype=np.float32)
    input_path=ROOT/'inputs'/f'{name}.wav'
    output_path=ROOT/'outputs'/f'{name}.wav'
    corpus.v3.wav(input_path,source)
    started=time.perf_counter()
    output,gain,history=limit(source)
    producer_seconds=time.perf_counter()-started
    corpus.v3.wav(output_path,output)
    (ROOT/'outputs'/f'{name}.gain.f64le').write_bytes(gain.astype('<f8').tobytes())
    began=time.perf_counter()
    final_peak=float(detector(output).max())
    other=independent_peak(output)
    bs_peak,bs_pass=exact_bs(output)
    finite_seconds=time.perf_counter()-began
    diagnostics=[]
    diagnostic_seconds=0.0
    if name in ('rapid-mask-0.8','rapid-mask-16.0','alternating-16.0','near-nyquist','retained-failure-16','long-rapid-mask-16'):
        began=time.perf_counter()
        diagnostics=[oracle.audit_channel(output[:,ch].astype(np.float64),128,len(output),8) for ch in range(2)]
        diagnostic_seconds=time.perf_counter()-began
    zeros=source==0
    result={'name':name,'description':description,'frames':len(source),
            'input_sha256':sha(input_path),'output_sha256':sha(output_path),
            'producer_seconds':producer_seconds,'finite_measurement_seconds':finite_seconds,
            'diagnostic_seconds':diagnostic_seconds,'final_detector_peak':final_peak,
            'final_detector_db':db(final_peak),'independent_bh32_peak':other,'independent_bh32_db':db(other),
            'exact_bs_peak':bs_peak,'exact_bs_db':db(bs_peak),'exact_bs_pass':bs_pass,
            'passes_finite_contract':bool(final_peak<=CEILING and other<=CEILING and bs_pass),
            'gain_min':float(gain.min()),'gain_max':float(gain.max()),
            'unity_gain':bool(np.all(gain==1)),
            'bytes_unchanged':bool(np.array_equal(source.view(np.uint32),output.view(np.uint32))),
            'zeros_unchanged':bool(np.array_equal(source.view(np.uint32)[zeros],output.view(np.uint32)[zeros])),
            'active_frames_before':int(np.count_nonzero(np.any(source!=0,axis=1))),
            'active_frames_after':int(np.count_nonzero(np.any(output!=0,axis=1))),
            'shared_gain_recreates_bytes':bool(np.array_equal((source.astype(np.float64)*gain[:,None]).astype(np.float32).view(np.uint32),output.view(np.uint32))),
            'maximum_attack_step':float(np.max(np.maximum(0,gain[:-1]-gain[1:]),initial=0)),
            'maximum_release_step':float(np.max(np.maximum(0,gain[1:]-gain[:-1]),initial=0)),
            'history':history,'complete_sinc_diagnostic':diagnostics}
    if diagnostics:
        upper=max(r['qualified_numerical_global_upper'] for r in diagnostics)
        result['sinc_diagnostic_upper_db']=db(upper)
    write(ROOT/'reports'/f'{name}.json',result)
    print(json.dumps({k:result[k] for k in ('name','passes_finite_contract','exact_bs_db','independent_bh32_db','producer_seconds','bytes_unchanged')}) ,flush=True)
    return result


def seek_test():
    length=131072
    rng=np.random.default_rng(20260924)
    n=np.arange(length)
    mono=1.8*np.sin(2*np.pi*12345*(n+0.31)/48000)+rng.uniform(-0.3,0.3,length)
    mono[44000:44512:2]=0
    pcm=np.column_stack((mono,-0.7*mono)).astype(np.float32)
    began=time.perf_counter()
    full,full_gain,_=limit(pcm)
    full_seconds=time.perf_counter()-began
    queries=[]
    for start,count in [(65001,257),(131071,1),(0,1),(63000,8192),(65536,1)]:
        first,last=max(0,start-LEFT_HALO),min(length,start+count+RIGHT_HALO)
        began=time.perf_counter()
        block,gain,_=limit(pcm[first:last],origin=first)
        elapsed=time.perf_counter()-began
        offset=start-first
        queries.append({'start':start,'count':count,'read_first':first,'read_last':last,'seconds':elapsed,
                        'f32_equal':bool(np.array_equal(block[offset:offset+count].view(np.uint32),full[start:start+count].view(np.uint32))),
                        'gain_equal':bool(np.array_equal(gain[offset:offset+count],full_gain[start:start+count]))})
    result={'frames':length,'full_seconds':full_seconds,'left_halo':LEFT_HALO,'right_halo':RIGHT_HALO,
            'queries':queries,'all_equal':all(q['f32_equal'] and q['gain_equal'] for q in queries)}
    write(ROOT/'seek.json',result)
    print(json.dumps({'seek_equal':result['all_equal'],'full_seconds':full_seconds}),flush=True)


def main():
    for folder in ('inputs','outputs','reports','coefficients'):
        (ROOT/folder).mkdir(exist_ok=True)
    for name,rows in [('kaiser-r64-16x-beta8.6',KAISER),('blackman-harris-r96-32x',INDEPENDENT),('bs1770',BS)]:
        (ROOT/'coefficients'/f'{name}.f64le').write_bytes(rows.astype('<f8').tobytes())
        write(ROOT/'coefficients'/f'{name}.json',rows.tolist())
    oracle_path,oracle=corpus.v3.load_oracle()
    meta={'repository_revision':subprocess.check_output(['git','rev-parse','HEAD'],cwd=REPO,text=True).strip(),
          'python':sys.version,'numpy':np.__version__,'scipy':scipy.__version__,'platform':platform.platform(),
          'script_sha256':sha(Path(__file__)),'corpus_sha256':sha(CORPUS),'exact_auditor_sha256':sha(EXACT),'oracle_sha256':sha(oracle_path),
          'coefficient_hashes':{p.name:sha(p) for p in (ROOT/'coefficients').glob('*.f64le')},
          'radius':R,'phases':PHASES,'beta':8.6,'per_phase_dc_normalization':True,
          'fixed_passes':PASSES,'target_db':TARGET_DB,'ceiling_db':-1,'tile':TILE,'fft_length':FFT_LENGTH,
          'integer_q':Q,'attack_units':A,'release_units':D,'left_halo':LEFT_HALO,'right_halo':RIGHT_HALO,
          'acceptance':'final f32 producer finite bank + independent exact BS4 + separately pinned BH4-windowed radius96 phase32 direct convolution; no production or universal DAC claim',
          'complete_sinc':'named stronger diagnostic, not finite-contract acceptance'}
    write(ROOT/'environment.json',meta)
    results=[]
    for name,source,description in controls():
        results.append(run_case(name,source,description,oracle))
        write(ROOT/'results.json',{'environment':meta,'results':results})
    seek_test()
    if any(not r['passes_finite_contract'] for r in results):
        raise SystemExit(1)


if __name__=='__main__':
    main()
