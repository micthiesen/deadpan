# Modest finite-bank master candidate, 2026-09-24

The **triggered17** pilot passes all 25 declared finite checks, preserves the
ordinary/quiet/tiny/tail controls, and matches five shuffled range reads exactly.
This is a candidate for native implementation and further qualification, not
adoption of a production master. No repository source was written by this worker.
Current authority is `docs/AUDIO_MASTERING.md` at the recorded repository revision.

Two earlier runs remain unchanged: the initial −1.2 dB guard fails a separate
finite reconstruction check; unconditional −1.7 dB fixes that peak result but
attenuates an otherwise-compliant ordinary tone near its ending boundary.

## Runnable sources and retained identities

All runs use Python 3.12.13, NumPy 2.5.3 and SciPy 1.18.0 as developer tools.
They read corpus/oracle helpers and the BS table from the existing checkout and
previous scratch evidence; exact copies are retained in each `dependencies/`.
Commands below regenerate that version's outputs, not another version's files.

```sh
uv run --python 3.12 --with numpy==2.5.3 --with scipy==1.18.0 /tmp/deadpan-master-20260924/candidate/pilot.py
uv run --python 3.12 --with numpy==2.5.3 --with scipy==1.18.0 /tmp/deadpan-master-20260924/candidate/target17/pilot.py
uv run --python 3.12 --with numpy==2.5.3 --with scipy==1.18.0 /tmp/deadpan-master-20260924/candidate/triggered17/pilot.py
```

The first exits 1 because six final finite checks fail. The follow-ups exit 0.
Each directory contains exact input and output float32 WAVs, float64 gains,
per-case/pass reports, coefficient JSON and little-endian f64 bytes,
`environment.json`, `results.json`, `summary.json`, `seek.json`, and `sha256.json`.
The environment binds the script, corpus, exact auditor, oracle, coefficient hashes,
library versions and repository revision. `followup-comparison.json` retains the
unconditional follow-up's exact changed sample ranges. No source revision or
failed numerical output was overwritten while preparing the follow-ups.

## Exact proposed filter and gain law

The signal is post-mask, 48 kHz float32 stereo. There is no conditioner, additive
audio, clipper, source normalizer, creative fade, or gain above one. Input admission
in this prototype is fewer than one million frames, finite, and magnitude ≤16.
This limit is an explicit prototype bound, not qualification of every future mix.

The linked detector takes the maximum over both channels and:

- Original sample magnitudes.
- The pinned BS.1770 four-phase, 12-tap finite estimator.
- Fifteen fractional phases at `p/16`, p=1..15, each with 129 taps at integer
  offsets d=−64..64. Compute `sinc(d-p/16)` times the phase-centered Kaiser
  window, beta 8.6, support `abs(d-p/16)≤64`, then normalize each row's DC sum.

Kaiser coefficient bytes SHA-256:
`488b81862c8d687fc9d612a00d10cd82b68f3041f6f716b442461e0f784b241c`.
These are experimental chosen coefficients, not a claim that ITU specifies this
window. Pin the retained coefficients when porting; do not silently regenerate
different values under a library upgrade.

The final variant performs exactly four passes. Let P be the measured linked
peak, C=`10^(-1/20)`, and T=`10^(-1.7/20)`. Its local cap is:

```
cap(P) = 1       when P <= C
         T / P  when P > C
```

Take the minimum cap over a radius-64 neighborhood so each contributing sample
receives the row's correction. Quantize downward on Q=2^32. Construct one exact
integer backward envelope with A=2^20 units/sample, then a forward envelope with
D=2^19 units/sample. Multiply that correction into shared cumulative float64
gain. Reconstruct the pass output as `f32(original_f32 * cumulative_gain)`;
measure these actual rounded samples on the next pass. There is no convergence
loop or output clamp. The original two runs instead applied `min(1,T/P)` to all
nonzero peaks, with T at −1.2 and −1.7 respectively.

An input entirely compliant with the **measured producer bank** receives unity
gain by construction. This is not proof that an unseen input also passes every
other finite bank. The threshold introduces a guard reduction when limiting is
triggered; input-level continuity and audible gain behavior still need review.
Independent local reductions are not monotone for signed reconstruction, so the
finite final-output checks remain mandatory.

The integer recurrences have exact per-pass influence of 4096 future and 8192
past caps. Their product does not generally preserve the same exact final gain
slope: the initial pilot recorded attack/release steps about 3.18e-8 above the
nominal slopes. The final variant did not exceed those slopes on this corpus,
but that measurement is not a general bound on four multiplied corrections.

## Measurement contract and results

Final float32 output is independently scanned with exact-integer BS convolution,
including complete trailing context and the sample floor. The exact dyadic FIR
and exact ceiling comparison reuse the separately authored retained auditor.
A second, separately pinned reconstruction probe uses 31 fractional phases at
p/32, radius 96, a four-term Blackman-Harris window, per-phase DC normalization,
and direct full convolution. It does not reuse producer FFT values or coefficients.
Its coefficient hash is
`e1565242a564ddbfae0d7c20e6e9c53c6f6ac701c4b6542ec55cae70c2504296`.
Both finite probes must remain ≤−1 dB for this experiment's acceptance.

| Run | Finite checks | Ordinary controls |
|---|---|---|
| Unconditional −1.2 | 19/25 pass | Ordinary 0.8 tones are unchanged |
| Unconditional −1.7 | 25/25 pass | Long 0.8 tone changes at its ending boundary |
| Triggered −1.7 | 25/25 pass | Both 0.8 tones, tiny fragments and tail are unchanged |

Initial failures were rapid masks 0.8/16, alternating 0.8/16, hot 23,990 Hz, and
the long rapid mask. They passed the producer and exact BS scans but failed the
different finite bank. Worst result: **−0.822340 dB** on the hot near-Nyquist tone.

The unconditional −1.7 long-tone change occupies `[65418,65536)`, 118 frames or
2.458 ms, with maximum attenuation **0.112363 dB**. That file was already finite
compliant. The triggered rule restores all its original bytes. It also restores
unity on the hard-silent-gap and the retained-failure16 fixture.

Triggered results include:

| Final independent Blackman-Harris probe | Measured peak |
|---|---:|
| Rapid mask 0.8 | −1.479590 dB |
| Rapid mask 16, short and long | −1.479425 dB |
| Alternating 16 | −1.351123 dB |
| Hot 23,990 Hz | −1.314059 dB |
| Unchanged hard-silent-gap | −1.099019 dB |

All runs preserve every zero bit, every active frame in this corpus, and output
length. The final run leaves 14 whole inputs byte-identical, including quiet
tone/DC, ordinary 0.5 and 0.8 tones, ordinary 0.5 DC, both tiny Hard fragments,
the permitted tail and both retained old-failure inputs. Ordinary finite 0.8 DC
is limited; a below-ceiling sample level does not imply a safe endpoint peak.
No general f32-subnormal preservation or listening claim follows from these tests.

Six final cases also retain the broader complete-sinc128 diagnostic. Those
results remain failures: e.g. +6.655904 dB for alternating16 and +4.901100 dB for
the long rapid mask. These are named evidence under a different reconstruction
model, not hidden results and not this finite contract's universal acceptance
criterion. No universal converter/DAC claim or interval certificate is made.

## Cost, random access, and next implementation

The FFT version fixes tiles to absolute multiples of 1024 project samples, FFT
length 1152. It does not choose a transform size or phase from request boundaries.
The four-pass mathematical FIR halos are 33280 past and 16896 future samples.
To preserve the FFT's numerical dependence on all tile inputs, the tested halos
add four complete tiles per side: **37376 past, 20992 future**. The final finite
verification also needs its own complete output-filter context.

On Apple M5 Max/macOS 26.5.2, the final pilot's 8192-frame producer time is
0.0373–0.0466 s, median **0.0441 s**, excluding independent audit. Two 65536-frame
clips take 0.286–0.300 s. These Python observations are not native benchmarks.
The 131072-frame full seek baseline takes 0.595 s for 2.731 s of audio. All five
shuffled requests match float32 output bits and float64 gains exactly. A cold
257-frame read loads 58625 frames and takes **0.256 s**; observed cold reads range
0.099–0.299 s. No source decoding or Preserve preparation is included.

Next implementation should:

1. Port the pinned law and coefficients into a bounded native execution path;
   qualify its arithmetic and final PCM against this evidence. A different FIR
   or FFT arithmetic schedule needs its own version and numerical comparison.
2. Prepare/cache canonical tiles or stream overlapping per-pass context. Do not
   recompute a complete halo for every 256-frame StageAudio read. Carry one
   cumulative work/deadline/cancellation allowance across canonical input reads,
   all passes, final checks and cache admission.
3. Validate final output with surrounding canonical output samples before
   publication/submission. If a fixed-work result fails a declared finite probe,
   report it explicitly; do not pass an intermediate result, silently clip, or
   switch to global optimization. No producer-pass/independent-fail case remained
   in this corpus, but no general theorem eliminates that possibility.
4. Bind caches to immutable revision, transitive media/policy dependencies,
   coefficients, algorithm, gain settings and absolute tile. Preserve output
   sample coordinates and exact allocation, with monitor gain applied afterward.
5. Add real Source/RoomTone/Preserve/binding input tests, interrupted/stale work,
   budget/residency tests, native throughput/cold seeks, and listening/gain-motion
   review. Shared preview/export processing and encoded verification remain owed.

The finite contract follows the current mastering document and the published
[BS.1770-5 Annex 2](https://www.itu.int/dms_pubrec/itu-r/rec/bs/R-REC-BS.1770-5-202311-I!!PDF-E.pdf)
estimation boundary. The extra bank, guard and trigger are measured design
choices, not standardized or proven perceptually transparent by this pilot.
