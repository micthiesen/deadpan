"""Independent standard-library audit of completed producer files.

The BS FIR scan uses exact integer convolution of the actual f32 payload and
published dyadic coefficients. Complete-sinc witnesses use fresh Decimal sums
at 80 digits; these confirm points, not the global maximum or an interval bound.
Only this audit's scratch directory is written.
"""

import ast
import argparse
from decimal import Decimal, localcontext
import hashlib
import json
import math
from pathlib import Path
import struct
import sys
import time

ROOT = Path(__file__).resolve().parent
PRODUCER = ROOT.parent / "producer"
REPO = Path("/Users/michael/Code/deadpan")
PI = Decimal("3.1415926535897932384626433832795028841971693993751058209749445923078164062862089986280348253421170679")


def sha(data):
    return hashlib.sha256(data).hexdigest()


def wave(data):
    fields = struct.unpack("<4sI4s4sIHHIIHH4sI", data[:44])
    assert fields == (b"RIFF", len(data)-8, b"WAVE", b"fmt ", 16, 3, 2,
                      48000, 384000, 8, 32, b"data", len(data)-44)
    assert len(data) == 44 + 8192 * 8
    samples = list(struct.iter_unpack("<ff", data[44:]))
    assert all(math.isfinite(x) for pair in samples for x in pair)
    return samples


def f32integer(value):
    """Represent the finite f32 value exactly as integer * 2^-149."""
    bits, = struct.unpack("<I", struct.pack("<f", value))
    exponent = (bits >> 23) & 255
    fraction = bits & ((1 << 23)-1)
    magnitude = fraction if exponent == 0 else ((1 << 23) | fraction) << (exponent-1)
    return -magnitude if bits >> 31 else magnitude


def exact_bs(samples, fir):
    maximum = 0
    for channel in range(2):
        integers = [f32integer(pair[channel]) for pair in samples]
        maximum = max(maximum, max(map(abs, integers)) << 13)
        for phase in range(4):
            accum = [0] * (len(samples)+11)
            for n, value in enumerate(integers):
                for k in range(12):
                    accum[n+k] += value * fir[k][phase]
            maximum = max(maximum, max(map(abs, accum)))
    return maximum


def sin_decimal(x):
    term = total = x
    for k in range(1, 100):
        term *= -x*x / ((2*k)*(2*k+1))
        total += term
        if abs(term) < Decimal("1e-85"):
            return total
    raise AssertionError("sin series exhausted")


def witness(samples, channel, coordinate):
    position = Decimal.from_float(coordinate)
    integer = math.floor(coordinate)
    phase = position - integer
    if phase == 0:
        return Decimal.from_float(samples[integer][channel]) if 0 <= integer < len(samples) else Decimal(0)
    total = sum((Decimal.from_float(pair[channel]) * (-1 if n % 2 else 1) / (position-n)
                 for n, pair in enumerate(samples) if pair[channel] != 0), Decimal(0))
    return (-1 if integer % 2 else 1) * sin_decimal(PI*phase) * total / PI


def audit(name, destination, fir):
    before = {}
    for kind, suffix in [("reports", "json"), ("inputs", "wav"), ("outputs", "wav")]:
        path = PRODUCER / kind / f"{name}.{suffix}"
        data = path.read_bytes()
        before[path] = sha(data)
        (destination / f"{name}-{kind}.{suffix}").write_bytes(data)
    report = json.loads((destination / f"{name}-reports.json").read_text())
    input_bytes = (destination / f"{name}-inputs.wav").read_bytes()
    output_bytes = (destination / f"{name}-outputs.wav").read_bytes()
    assert sha(input_bytes) == report["input_sha256"]
    assert sha(output_bytes) == report["output_sha256"]
    source, output = wave(input_bytes), wave(output_bytes)
    retained_input = None
    if name.startswith("retained-failure-"):
        level = name.removeprefix("retained-failure-")
        retained = REPO / "tools/audio-limiter-qualification/evidence/2026-09-22-postmask/producer/outputs" / f"mask-alternating-dc-{level}-hard.wav"
        assert input_bytes == retained.read_bytes()
        retained_input = {"path": str(retained), "byte_identical": True, "sha256": sha(input_bytes)}
    knots = list(range(0, 8192, 64)) + [8191]
    gains = report["gain_knots"]
    assert len(gains) == len(knots)
    gain = []
    recreated = bytearray()
    for n, pair in enumerate(source):
        left = min(n // 64, len(knots)-2)
        fraction = (n-knots[left]) / (knots[left+1]-knots[left])
        g = (1-fraction)*gains[left] + fraction*gains[left+1]
        gain.append(g)
        recreated.extend(struct.pack("<ff", pair[0]*g, pair[1]*g))
    exact_peak = exact_bs(output, fir)
    with localcontext() as ctx:
        ctx.prec = 80
        bs_peak = Decimal(exact_peak) / (Decimal(2) ** 162)
        ceiling = Decimal(10) ** (-Decimal(1)/20)
        checks = []
        for ch, result in enumerate(report["oracle"]):
            t = result["refined_coordinate"]
            value = witness(output, ch, t)
            checks.append({"channel": ch, "coordinate_hex": t.hex(),
                           "value_80_digits": str(value),
                           "difference_from_report": str(value-Decimal.from_float(result["refined_signed_value"])),
                           "below_ceiling_at_this_point": abs(value) <= ceiling})
    assert all(path.read_bytes() and sha(path.read_bytes()) == expected for path, expected in before.items())
    return {"name": name, "input_sha256": sha(input_bytes), "output_sha256": sha(output_bytes),
            "retained_input_identity": retained_input,
            "unchanged_input_bytes": input_bytes == output_bytes,
            "shared_gain_recreates_output_bytes": bytes(recreated) == output_bytes[44:],
            "gains_in_closed_unit_interval": all(0 <= g <= 1 for g in gain),
            "maximum_attack_slope_excess": max(0, max(gain[n]-gain[n+1] for n in range(8191))-1/4096),
            "maximum_release_slope_excess": max(0, max(gain[n+1]-gain[n] for n in range(8191))-1/8192),
            "numeric_zeros_preserved": all(y == 0 for a,b in zip(source,output) for x,y in zip(a,b) if x == 0),
            "nonzero_frames_preserved": sum(any(x != 0 for x in pair) for pair in source) == sum(any(x != 0 for x in pair) for pair in output),
            "exact_bs_peak_numerator": str(exact_peak), "exact_bs_peak_denominator_power_two": 162,
            "exact_bs_peak_decimal": str(bs_peak),
            # p/2^162 <= 10^(-1/20), compared without transcendental rounding.
            "exact_bs_below_ceiling": 10 * exact_peak**20 <= (1 << (162*20)),
            "bs_difference_from_report": float(bs_peak)-report["bs_peak"],
            "complete_sinc_point_checks": checks,
            "global_sinc_bound_scope": "Producer's retained numerical oracle only; fresh Decimal checks confirm witnesses, not all-real global certification."}


def main():
    global PRODUCER
    parser = argparse.ArgumentParser()
    parser.add_argument("--producer", type=Path, default=PRODUCER)
    parser.add_argument("names", nargs="*")
    args = parser.parse_args()
    PRODUCER = args.producer
    destination = ROOT / ("output-audit-" + str(time.time_ns()))
    destination.mkdir()
    path = REPO / "crates/deadpan-audio/src/true_peak.rs"
    text = path.read_text().split("const FIR: [[f64; 4]; 12] = ", 1)[1].split(";", 1)[0]
    values = ast.literal_eval(text)
    assert all(float(value*8192).is_integer() for row in values for value in row)
    fir = [[int(value*8192) for value in row] for row in values]
    names = args.names or sorted(path.stem for path in (PRODUCER / "reports").glob("*.json") if not path.stem.endswith("-iterations"))
    result = {"script_sha256": sha(Path(__file__).read_bytes()),
              "producer_directory": str(PRODUCER),
              "producer_sha256": sha((PRODUCER / "experiment.py").read_bytes()),
              "fir_source_sha256": sha(path.read_bytes()),
              "bs_arithmetic": "exact integer full zero-extended convolution of actual f32 and exact dyadic FIR coefficients, including raw sample floor",
              "sinc_arithmetic": "independent 80-digit Decimal finite direct sums at reported witnesses; not an interval certificate",
              "cases": [audit(name, destination, fir) for name in names]}
    (destination / "audit.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps({"destination": str(destination), "cases": result["cases"]}, indent=2))


if __name__ == "__main__":
    main()
