"""Bounded finite-bank feedback experiment, deliberately not production DSP.

No conditioner and no global optimization. Four fixed correction passes measure
the actual f32 waveform. Signed finite reconstruction is not monotone under
local attenuation, so final output is independently audited and may FAIL.
"""
from pathlib import Path
import argparse
import hashlib
import importlib.util
import json
import math
import platform
import sys
import time

import numpy as np
import scipy
from scipy import ndimage

ROOT = Path(__file__).resolve().parent
V3_PATH = ROOT.parent / 'producer-v3' / 'experiment.py'
RADIUS = 256
PHASES = 16
PASSES = 4
TARGET_DB = -2.0
TARGET = 10 ** (TARGET_DB / 20)
CEILING = 10 ** (-1 / 20)
Q = 1 << 32
ATTACK = 1 << 20
RELEASE = 1 << 19
# A pass samples R away, dilates R away, then finite integer control history.
LEFT_HALO = PASSES * (2 * RADIUS + Q // RELEASE)
RIGHT_HALO = PASSES * (2 * RADIUS + Q // ATTACK)


def load(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


v3 = load(V3_PATH, 'v3_corpus_and_format')


def write_json(path, value):
    path.write_text(json.dumps(value, indent=2, allow_nan=False) + '\n')


def db(value):
    return 20 * math.log10(value) if value else None


def detector_bank():
    # Explicit truncated sinc, with no window/normalization/conditioning.
    # Integer phase is the sample floor. Each row samples k+phase from x[k+d].
    offsets = np.arange(-RADIUS, RADIUS + 1)
    rows = [(f'sinc16-{p}', np.sinc(p / PHASES - offsets))
            for p in range(1, PHASES)]
    # Convolution BS row can be expressed as correlation with reversed taps.
    # Padding odd-length to 13 fixes integer origin; origin shift does not
    # change full-support peak and dilation conservatively includes all taps.
    for p in range(4):
        row = np.zeros(13)
        row[:12] = v3.bs_coefficients()[::-1, p]
        rows.append((f'bs4-{p}', row))
    return rows


BANK = detector_bank()


def finite_peaks(pcm):
    padded = np.pad(pcm.astype(np.float64), ((RADIUS, RADIUS), (0, 0)))
    peaks = np.max(np.abs(padded), axis=1)
    per_row = {}
    for name, row in BANK:
        values = ndimage.correlate1d(padded, row, axis=0, mode='constant', cval=0)
        linked = np.max(np.abs(values), axis=1)
        per_row[name] = float(np.max(linked))
        np.maximum(peaks, linked, out=peaks)
    return peaks, per_row


def envelope(caps):
    # Exact u64 cap recurrence; at most finite Q/A, Q/R influence. Use signed
    # integers for the algebraic cumulative-min forms, with bounded lengths.
    assert len(caps) < 1_000_000
    cap = np.floor(np.clip(caps, 0, 1) * Q).astype(np.int64)
    index = np.arange(len(cap), dtype=np.int64)
    future = np.minimum.accumulate((cap + index * ATTACK)[::-1])[::-1] - index * ATTACK
    result = np.minimum.accumulate(future - index * RELEASE) + index * RELEASE
    assert np.all(result >= 0) and np.all(result <= Q)
    return result.astype(np.float64) / Q


def limit(source, history=False):
    source = np.asarray(source, dtype=np.float32)
    assert source.ndim == 2 and source.shape[1] == 2
    assert len(source) < 1_000_000 and np.isfinite(source).all() and np.max(abs(source)) <= 16
    source64 = source.astype(np.float64)
    gain = np.ones(len(source))
    pcm = source.copy()
    trace = []
    for iteration in range(PASSES):
        peaks, rows = finite_peaks(pcm)
        correction = np.minimum(1, np.divide(TARGET, peaks, out=np.ones_like(peaks), where=peaks != 0))
        # Every sample contributing to a flagged row receives that cap. This
        # is a heuristic correction, not a proof of signed-peak monotonicity.
        correction = ndimage.minimum_filter1d(correction, 2 * RADIUS + 1, mode='constant', cval=1)
        correction = correction[RADIUS:-RADIUS]
        gain *= envelope(correction)
        pcm = (source64 * gain[:, None]).astype(np.float32)
        if history:
            trace.append({'pass': iteration + 1, 'detected_before_peak': float(np.max(peaks)),
                          'gain_min': float(gain.min()), 'gain_max': float(gain.max()),
                          'rows_before': rows})
    return pcm, gain, trace


def all_cases():
    yield from v3.cases()
    n = np.arange(v3.N)
    for amplitude in (0.5, 0.8):
        mono = amplitude * np.sin(2 * np.pi * 1000 * (n + 0.5) / 48000)
        yield f'ordinary-tone-{amplitude}', np.column_stack((mono, mono / 4)), 'below-ceiling ordinary tone; attenuation must be reported'
        yield f'ordinary-dc-{amplitude}', np.full((v3.N, 2), amplitude), 'ordinary finite DC; endpoint reconstruction separately audited'
    # Longer periods and fractional phases are not the rapid-mask training
    # case, and exercise sensitivity to fixed detector origin.
    for period in (3, 7, 31):
        mono = np.where(n % period < period // 2, 16.0, 0.0)
        yield f'hot-mask-period-{period}', np.column_stack((mono, -0.7 * mono)), 'additional fixed-origin mask stress'


def run_case(name, source, description, oracle):
    source = np.asarray(source, dtype=np.float32)
    v3.wav(ROOT / 'inputs' / f'{name}.wav', source)
    began = time.perf_counter()
    pcm, gain, trace = limit(source, history=True)
    producer_seconds = time.perf_counter() - began
    output = ROOT / 'outputs' / f'{name}.wav'
    v3.wav(output, pcm)
    (ROOT / 'outputs' / f'{name}.gain.f64le').write_bytes(gain.astype('<f8').tobytes())
    finite, rows = finite_peaks(pcm)
    bs, _ = v3.bs_scan(pcm.astype(np.float64), v3.bs_coefficients())
    began = time.perf_counter()
    audits = [oracle.audit_channel(pcm[:, ch].astype(np.float64), 128, len(pcm), 8) for ch in range(2)]
    oracle_seconds = time.perf_counter() - began
    upper = max(row['qualified_numerical_global_upper'] for row in audits)
    source_bits, output_bits = source.view(np.uint32), pcm.view(np.uint32)
    zero_mask = source == 0
    result = {
        'name': name, 'description': description, 'frames': len(pcm),
        'input_sha256': v3.digest(ROOT / 'inputs' / f'{name}.wav'),
        'output_sha256': v3.digest(output),
        'producer_seconds': producer_seconds, 'oracle_seconds': oracle_seconds,
        'producer_realtime_factor': producer_seconds / (len(pcm) / 48000),
        'finite_peak': float(finite.max()), 'finite_db': db(float(finite.max())),
        'bs_peak': bs, 'bs_db': db(bs), 'sinc_upper': upper, 'sinc_upper_db': db(upper),
        'passes_finite': bool(finite.max() <= CEILING),
        'passes_bs': bool(bs <= CEILING), 'passes_sinc_diagnostic': bool(upper <= CEILING),
        'passes_all': bool(finite.max() <= CEILING and bs <= CEILING and upper <= CEILING),
        'gain_min': float(gain.min()), 'gain_max': float(gain.max()),
        'unity_gain': bool(np.all(gain == 1)),
        'byte_identical': bool(np.array_equal(source_bits, output_bits)),
        'exact_zero_preserved': bool(np.all(pcm[zero_mask] == 0)),
        'zero_bits_preserved': bool(np.array_equal(source_bits[zero_mask], output_bits[zero_mask])),
        'nonzero_input_frames': int(np.count_nonzero(np.any(source != 0, axis=1))),
        'nonzero_output_frames': int(np.count_nonzero(np.any(pcm != 0, axis=1))),
        'finite_rows': rows, 'passes': trace, 'oracle': audits,
    }
    write_json(ROOT / 'reports' / f'{name}.json', result)
    print(json.dumps({k: result[k] for k in ('name', 'passes_all', 'finite_db', 'bs_db', 'sinc_upper_db', 'producer_seconds', 'byte_identical')}), flush=True)
    return result


def seek_test():
    # Long deterministic nonperiodic clip. Query halos are derived from four
    # passes, never reset at a requested boundary. Direct FIR operation order
    # is length-independent; the integer recurrence is exact.
    length = 98304
    rng = np.random.default_rng(20260924)
    n = np.arange(length)
    mono = (rng.uniform(-1, 1, length) * 0.15 + 2 * np.sin(2 * np.pi * 23990 * n / 48000))
    mono[35000:41000:2] = 0
    source = np.column_stack((mono, -0.7 * mono)).astype(np.float32)
    began = time.perf_counter()
    full, full_gain, _ = limit(source)
    full_seconds = time.perf_counter() - began
    records = []
    for start, count in [(45001, 257), (0, 1), (98047, 257), (33000, 8192), (49152, 1)]:
        first, last = max(0, start - LEFT_HALO), min(length, start + count + RIGHT_HALO)
        began = time.perf_counter()
        block, gain, _ = limit(source[first:last])
        duration = time.perf_counter() - began
        offset = start - first
        actual = block[offset:offset + count]
        expected = full[start:start + count]
        records.append({'start': start, 'count': count, 'read_first': first, 'read_last': last,
                        'seconds': duration, 'f32_bits_equal': bool(np.array_equal(actual.view(np.uint32), expected.view(np.uint32))),
                        'gain_equal': bool(np.array_equal(gain[offset:offset + count], full_gain[start:start + count]))})
    report = {'frames': length, 'left_halo': LEFT_HALO, 'right_halo': RIGHT_HALO,
              'full_seconds': full_seconds, 'queries': records,
              'all_equal': all(row['f32_bits_equal'] and row['gain_equal'] for row in records)}
    write_json(ROOT / 'seek.json', report)
    print(json.dumps({'seek_equal': report['all_equal'], 'seek_seconds': full_seconds}), flush=True)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('cases', nargs='*')
    parser.add_argument('--seek', action='store_true')
    args = parser.parse_args()
    for directory in ('inputs', 'outputs', 'reports'):
        (ROOT / directory).mkdir(exist_ok=True)
    oracle_path, oracle = v3.load_oracle()
    metadata = {'python': sys.version, 'numpy': np.__version__, 'scipy': scipy.__version__,
                'platform': platform.platform(), 'script_sha256': v3.digest(Path(__file__)),
                'corpus_script_sha256': v3.digest(V3_PATH), 'oracle_sha256': v3.digest(oracle_path),
                'bank': '15 noninteger truncated-sinc phases at 1/16, 513 taps, no window; four BS1770 phases, 12 taps; sample floor',
                'radius': RADIUS, 'phases': PHASES, 'fixed_passes': PASSES,
                'target_db': TARGET_DB, 'ceiling_db': -1, 'control_q': Q,
                'attack_per_pass_q': ATTACK, 'release_per_pass_q': RELEASE,
                'left_halo': LEFT_HALO, 'right_halo': RIGHT_HALO,
                'claim': 'experimental finite detector heuristic; final f32 diagnostic only; no universal reconstruction/DAC, listening, production, or realtime qualification'}
    write_json(ROOT / 'environment.json', metadata)
    wanted = set(args.cases)
    results = []
    for name, source, description in all_cases():
        if wanted and name not in wanted:
            continue
        try:
            results.append(run_case(name, source, description, oracle))
        except Exception as error:
            failure = {'name': name, 'passes_all': False, 'error': repr(error)}
            write_json(ROOT / 'reports' / f'{name}-failure.json', failure)
            results.append(failure)
            print(json.dumps(failure), flush=True)
        write_json(ROOT / 'results.json', {'environment': metadata, 'results': results})
    if args.seek:
        seek_test()
    if any(not row['passes_all'] for row in results):
        raise SystemExit(1)


if __name__ == '__main__':
    main()
