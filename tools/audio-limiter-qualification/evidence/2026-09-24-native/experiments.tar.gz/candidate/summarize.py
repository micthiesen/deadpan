"""Retain summary/provenance without rerunning the numerical pilot."""
from pathlib import Path
import hashlib
import json
import shutil
import statistics

ROOT=Path(__file__).resolve().parent
report=json.loads((ROOT/'results.json').read_text())
rows=report['results']
short=[r for r in rows if r['frames']==8192]
summary={'cases':len(rows),'finite_passes':sum(r['passes_finite_contract'] for r in rows),
         'all_exact_bs_pass':all(r['exact_bs_pass'] for r in rows),
         'all_producer_detector_pass':all(r['final_detector_peak']<=10**(-1/20) for r in rows),
         'all_zero_bits_preserved':all(r['zeros_unchanged'] for r in rows),
         'all_active_frames_preserved':all(r['active_frames_before']==r['active_frames_after'] for r in rows),
         'all_shared_gain_recreates_bytes':all(r['shared_gain_recreates_bytes'] for r in rows),
         'unchanged_cases':[r['name'] for r in rows if r['bytes_unchanged']],
         'finite_failures':[{'name':r['name'],'independent_bh32_db':r['independent_bh32_db']} for r in rows if not r['passes_finite_contract']],
         'complete_sinc_diagnostics':[{'name':r['name'],'upper_db':r['sinc_diagnostic_upper_db']} for r in rows if 'sinc_diagnostic_upper_db' in r],
         'short_producer_seconds':{'minimum':min(r['producer_seconds'] for r in short),
                                    'median':statistics.median(r['producer_seconds'] for r in short),
                                    'maximum':max(r['producer_seconds'] for r in short)},
         'maximum_final_attack_step':max(r['maximum_attack_step'] for r in rows),
         'maximum_final_release_step':max(r['maximum_release_step'] for r in rows)}
(ROOT/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
deps=ROOT/'dependencies'
deps.mkdir(exist_ok=True)
for name,path in {
    'corpus.py':Path('/tmp/deadpan-limiter-20260924/finite-producer/experiment.py'),
    'v3-experiment.py':Path('/tmp/deadpan-limiter-20260924/producer-v3/experiment.py'),
    'exact-auditor.py':Path('/tmp/deadpan-limiter-20260924/design-audit/audit_outputs.py'),
    'finite_sinc.py':Path('/Users/michael/Code/deadpan/tools/audio-limiter-qualification/evidence/2026-09-22-postmask/audit/finite_sinc.py'),
    'true_peak.rs':Path('/Users/michael/Code/deadpan/crates/deadpan-audio/src/true_peak.rs'),
}.items():
    shutil.copyfile(path,deps/name)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert report['environment']['script_sha256']==sha(ROOT/'pilot.py')
for row in rows:
    assert row['input_sha256']==sha(ROOT/'inputs'/f"{row['name']}.wav")
    assert row['output_sha256']==sha(ROOT/'outputs'/f"{row['name']}.wav")
manifest={str(p.relative_to(ROOT)):sha(p) for p in sorted(ROOT.rglob('*')) if p.is_file() and p.name!='sha256.json' and '__pycache__' not in p.parts}
(ROOT/'sha256.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps(summary,indent=2))
