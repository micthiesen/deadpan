"""Read-only comparison of the two frozen parameter runs."""
from pathlib import Path
import json
import math
import struct

ROOT=Path(__file__).resolve().parent
names=['ordinary-tone-0.8','long-ordinary-tone-0.8','retained-failure-16','near-nyquist','rapid-mask-16.0']
rows=[]
for name in names:
    source=(ROOT/'inputs'/f'{name}.wav').read_bytes()[44:]
    old=(ROOT/'outputs'/f'{name}.wav').read_bytes()[44:]
    new=(ROOT/'target17'/'outputs'/f'{name}.wav').read_bytes()[44:]
    assert len(source)==len(old)==len(new)
    gains=[g[0] for g in struct.iter_unpack('<d',(ROOT/'target17'/'outputs'/f'{name}.gain.f64le').read_bytes())]
    changed=[n for n in range(len(gains)) if source[n*8:n*8+8]!=new[n*8:n*8+8]]
    runs=[]
    for n in changed:
        if runs and runs[-1][1]==n:
            runs[-1][1]=n+1
        else:
            runs.append([n,n+1])
    rows.append({'name':name,'frames':len(gains),'old_equals_input':old==source,'new_equals_input':new==source,
                 'new_changed_frames':len(changed),'new_changed_runs':runs,'new_gain_min':min(gains),'new_gain_max':max(gains),
                 'new_max_reduction_db':-20*math.log10(min(gains)) if min(gains)>0 else None})
(ROOT/'followup-comparison.json').write_text(json.dumps(rows,indent=2)+'\n')
print(json.dumps([{k:v for k,v in row.items() if k!='new_changed_runs'} for row in rows],indent=2))
