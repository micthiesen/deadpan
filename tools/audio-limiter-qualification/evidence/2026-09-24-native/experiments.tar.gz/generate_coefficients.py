from pathlib import Path
import hashlib
import struct

source=Path('/tmp/deadpan-master-20260924/candidate/triggered17/coefficients/kaiser-r64-16x-beta8.6.f64le')
data=source.read_bytes()
assert hashlib.sha256(data).hexdigest()=='488b81862c8d687fc9d612a00d10cd82b68f3041f6f716b442461e0f784b241c'
values=[value[0] for value in struct.iter_unpack('<Q',data)]
assert len(values)==15*129
lines=['//! Pinned phase-centered Kaiser64/16x beta8.6, per-phase DC normalization.',
       '//! Source f64le SHA-256: 488b81862c8d687fc9d612a00d10cd82b68f3041f6f716b442461e0f784b241c.',
       '//! Rows are phases 1/16..15/16; columns are offsets -64..64.',
       '', '#[rustfmt::skip]', 'pub(super) const KAISER: [[f64; 129]; 15] = [']
for phase in range(15):
    lines.append('    [')
    for index in range(129):
        h=f'{values[phase*129+index]:016x}'
        grouped='_'.join(h[i:i+4] for i in range(0,16,4))
        lines.append(f'        f64::from_bits(0x{grouped}),')
    lines.append('    ],')
lines.append('];')
Path('/Users/michael/Code/deadpan/crates/deadpan-audio/src/limiter/coefficients.rs').write_text('\n'.join(lines)+'\n')
