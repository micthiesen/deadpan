#include <signalsmith-linear/fft.h>

#include <algorithm>
#include <cmath>
#include <complex>
#include <cstddef>
#include <cstdint>
#include <new>
#include <vector>

namespace {
constexpr int radius = 64;
constexpr int tile_frames = 1024;
constexpr int rows_count = 19;
constexpr int fft_rows_count = 15;
using Fft = signalsmith::linear::RealFFT<double>;
using Complex = Fft::Complex;

constexpr double fir[12][4] = {
    {0.001708984375, -0.0291748046875, -0.0189208984375, -0.00830078125},
    {0.010986328125, 0.029296875, 0.0330810546875, 0.014892578125},
    {-0.0196533203125, -0.0517578125, -0.0582275390625, -0.026611328125},
    {0.033203125, 0.089111328125, 0.1015625, 0.047607421875},
    {-0.0594482421875, -0.16650390625, -0.2003173828125, -0.102294921875},
    {0.1373291015625, 0.465087890625, 0.77978515625, 0.97216796875},
    {0.97216796875, 0.77978515625, 0.465087890625, 0.1373291015625},
    {-0.102294921875, -0.2003173828125, -0.16650390625, -0.0594482421875},
    {0.047607421875, 0.1015625, 0.089111328125, 0.033203125},
    {-0.026611328125, -0.0582275390625, -0.0517578125, -0.0196533203125},
    {0.014892578125, 0.0330810546875, 0.029296875, 0.010986328125},
    {-0.00830078125, -0.0189208984375, -0.0291748046875, 0.001708984375},
};

struct Row {
    int support_radius;
    std::vector<double> weights;
};

struct Detector {
    const std::size_t fft_size;
    const std::size_t bins;
    Fft fft;
    std::vector<Row> rows;
    std::vector<std::vector<Complex>> kernel_spectra;
    std::vector<double> kernel_time;
    std::vector<double> input_left, input_right, output_left, output_right;
    std::vector<Complex> spectrum_left, spectrum_right, product_left, product_right;

    Detector()
        : fft_size(Fft::fastSizeAbove(tile_frames + 2 * radius)),
          bins(fft_size / 2), fft(fft_size),
          kernel_time(fft_size), input_left(fft_size), input_right(fft_size),
          output_left(fft_size), output_right(fft_size), spectrum_left(bins),
          spectrum_right(bins), product_left(bins), product_right(bins) {
        rows.reserve(rows_count);
        constexpr double pi = 3.141592653589793238462643383279502884;
        for (int phase = 1; phase < 16; ++phase) {
            Row row{radius, std::vector<double>(2 * radius + 1)};
            const double fraction = static_cast<double>(phase) / 16.0;
            for (int d = -radius; d <= radius; ++d) {
                const double x = fraction - static_cast<double>(d);
                row.weights[static_cast<std::size_t>(d + radius)] =
                    x == 0.0 ? 1.0 : std::sin(pi * x) / (pi * x);
            }
            rows.push_back(std::move(row));
        }
        for (int phase = 0; phase < 4; ++phase) {
            Row row{6, std::vector<double>(13, 0.0)};
            for (int j = 0; j < 12; ++j) {
                row.weights[static_cast<std::size_t>(j)] = fir[11 - j][phase];
            }
            rows.push_back(std::move(row));
        }
        kernel_spectra.resize(fft_rows_count, std::vector<Complex>(bins));
        for (std::size_t row_index = 0; row_index < fft_rows_count; ++row_index) {
            std::fill(kernel_time.begin(), kernel_time.end(), 0.0);
            const auto &row = rows[row_index];
            const auto support = static_cast<std::size_t>(2 * row.support_radius + 1);
            for (std::size_t q = 0; q < support; ++q) {
                kernel_time[q] = row.weights[support - 1 - q];
            }
            fft.fft(kernel_time.data(), kernel_spectra[row_index].data());
        }
    }

    int run(const double *left, const double *right, std::size_t frames, double *output) {
        if (!left || !right || !output || !frames || frames > 1'000'000) return 1;
        constexpr double scale = 1.0; // Inverse scaling is measured against direct Rust FIR.
        std::fill(output, output + frames, 0.0);
        for (std::size_t tile = 0; tile < frames; tile += tile_frames) {
            const std::size_t count = std::min<std::size_t>(tile_frames, frames - tile);
            std::fill(input_left.begin(), input_left.end(), 0.0);
            std::fill(input_right.begin(), input_right.end(), 0.0);
            const std::size_t copied = count + 2 * radius;
            for (std::size_t i = 0; i < copied; ++i) {
                const auto source = static_cast<std::int64_t>(tile) - radius +
                                    static_cast<std::int64_t>(i);
                if (source >= 0 && static_cast<std::size_t>(source) < frames) {
                    input_left[i] = left[source];
                    input_right[i] = right[source];
                }
            }
            fft.fft(input_left.data(), spectrum_left.data());
            fft.fft(input_right.data(), spectrum_right.data());
            for (std::size_t row_index = 0; row_index < rows.size(); ++row_index) {
                const auto &row = rows[row_index];
                if (row_index < fft_rows_count) {
                    const auto &kernel = kernel_spectra[row_index];
                    product_left[0] = {spectrum_left[0].real() * kernel[0].real(),
                                       spectrum_left[0].imag() * kernel[0].imag()};
                    product_right[0] = {spectrum_right[0].real() * kernel[0].real(),
                                        spectrum_right[0].imag() * kernel[0].imag()};
                    for (std::size_t bin = 1; bin < bins; ++bin) {
                        product_left[bin] = spectrum_left[bin] * kernel[bin];
                        product_right[bin] = spectrum_right[bin] * kernel[bin];
                    }
                    fft.ifft(product_left.data(), output_left.data());
                    fft.ifft(product_right.data(), output_right.data());
                    const std::size_t offset = static_cast<std::size_t>(radius + row.support_radius);
                    for (std::size_t z = 0; z < count; ++z) {
                        const std::size_t at = offset + z;
                        const double l = output_left[at] / static_cast<double>(fft_size) * scale;
                        const double r = output_right[at] / static_cast<double>(fft_size) * scale;
                        output[tile + z] = std::max(output[tile + z], std::max(std::abs(l), std::abs(r)));
                    }
                } else {
                    for (std::size_t z = 0; z < count; ++z) {
                        const std::size_t start = static_cast<std::size_t>(radius - row.support_radius) + z;
                        double l = 0.0;
                        double r = 0.0;
                        for (std::size_t tap = 0; tap < row.weights.size(); ++tap) {
                            l += input_left[start + tap] * row.weights[tap];
                            r += input_right[start + tap] * row.weights[tap];
                        }
                        output[tile + z] = std::max(output[tile + z], std::max(std::abs(l), std::abs(r)));
                    }
                }
            }
        }
        return 0;
    }
};
} // namespace

extern "C" void *fft_detector_create(std::size_t *fft_size) noexcept {
    if (!fft_size) return nullptr;
    try {
        auto *detector = new Detector();
        *fft_size = detector->fft_size;
        return detector;
    } catch (...) {
        return nullptr;
    }
}

extern "C" int fft_detector_run(void *handle, const double *left, const double *right,
                                std::size_t frames, double *output) noexcept {
    if (!handle) return 1;
    try {
        return static_cast<Detector *>(handle)->run(left, right, frames, output);
    } catch (...) {
        return 2;
    }
}

extern "C" void fft_detector_destroy(void *handle) noexcept {
    try {
        delete static_cast<Detector *>(handle);
    } catch (...) {
    }
}
