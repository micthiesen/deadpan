use std::ffi::c_void;
use std::hint::black_box;
use std::time::{Duration, Instant};

const RADIUS: usize = 64;
const TILE_FRAMES: usize = 1024;
const ROW_COUNT: usize = 19;

unsafe extern "C" {
    fn fft_detector_create(fft_size: *mut usize) -> *mut c_void;
    fn fft_detector_run(
        handle: *mut c_void,
        left: *const f64,
        right: *const f64,
        frames: usize,
        output: *mut f64,
    ) -> i32;
    fn fft_detector_destroy(handle: *mut c_void);
}

struct Row {
    radius: usize,
    weights: Vec<f64>,
}

fn rows() -> Vec<Row> {
    let mut result = Vec::with_capacity(ROW_COUNT);
    let pi = std::f64::consts::PI;
    for phase in 1..16 {
        let fraction = phase as f64 / 16.0;
        let weights = (-(RADIUS as isize)..=RADIUS as isize)
            .map(|d| {
                let x = fraction - d as f64;
                if x == 0.0 { 1.0 } else { (pi * x).sin() / (pi * x) }
            })
            .collect();
        result.push(Row { radius: RADIUS, weights });
    }
    let fir = [
        [0.001708984375, -0.0291748046875, -0.0189208984375, -0.00830078125],
        [0.010986328125, 0.029296875, 0.0330810546875, 0.014892578125],
        [-0.0196533203125, -0.0517578125, -0.0582275390625, -0.026611328125],
        [0.033203125, 0.089111328125, 0.1015625, 0.047607421875],
        [-0.0594482421875, -0.16650390625, -0.2003173828125, -0.102294921875],
        [0.1373291015625, 0.465087890625, 0.77978515625, 0.97216796875],
        [0.97216796875, 0.77978515625, 0.465087890625, 0.1373291015625],
        [-0.102294921875, -0.2003173828125, -0.16650390625, -0.0594482421875],
        [0.047607421875, 0.1015625, 0.089111328125, 0.033203125],
        [-0.026611328125, -0.0582275390625, -0.0517578125, -0.0196533203125],
        [0.014892578125, 0.0330810546875, 0.029296875, 0.010986328125],
        [-0.00830078125, -0.0189208984375, -0.0291748046875, 0.001708984375],
    ];
    for phase in 0..4 {
        let mut weights = vec![0.0; 13];
        for j in 0..12 {
            weights[j] = fir[11 - j][phase];
        }
        result.push(Row { radius: 6, weights });
    }
    result
}

fn source(frames: usize) -> (Vec<f64>, Vec<f64>) {
    let mut left = Vec::with_capacity(frames);
    let mut right = Vec::with_capacity(frames);
    let mut state = 0x6a09_e667_f3bc_c909u64;
    for n in 0..frames {
        state ^= state << 13;
        state ^= state >> 7;
        state ^= state << 17;
        let noise = (state as f64 / u64::MAX as f64) * 2.0 - 1.0;
        let t = n as f64;
        let l = 0.71 * (std::f64::consts::TAU * 23_990.0 * t / 48_000.0).sin()
            + 0.09 * (std::f64::consts::TAU * 997.0 * t / 48_000.0).sin()
            + 0.02 * noise;
        let r = 0.55 * (std::f64::consts::TAU * 19_111.0 * t / 48_000.0 + 0.3).sin()
            - 0.02 * noise;
        if (20_001..22_049).contains(&n) || (43_000..43_128).contains(&n) {
            left.push(0.0);
            right.push(0.0);
        } else {
            left.push(l);
            right.push(r);
        }
    }
    (left, right)
}

fn padded(source: &[f64]) -> Vec<f64> {
    let mut result = vec![0.0; source.len() + 2 * RADIUS];
    result[RADIUS..RADIUS + source.len()].copy_from_slice(source);
    result
}

fn direct(
    left: &[f64],
    right: &[f64],
    frames: usize,
    rows: &[Row],
    output: &mut [f64],
) {
    output.fill(0.0);
    for tile in (0..frames).step_by(TILE_FRAMES) {
        let count = TILE_FRAMES.min(frames - tile);
        for row in rows {
            for z in 0..count {
                let n = tile + z;
                let start = n + RADIUS - row.radius;
                let mut l = 0.0;
                let mut r = 0.0;
                for (tap, weight) in row.weights.iter().enumerate() {
                    l += left[start + tap] * weight;
                    r += right[start + tap] * weight;
                }
                output[n] = output[n].max(l.abs().max(r.abs()));
            }
        }
    }
}

fn median(values: &mut [Duration]) -> Duration {
    values.sort();
    values[values.len() / 2]
}

fn main() {
    let frames = 60_000;
    let rows = rows();
    let (source_l, source_r) = source(frames);
    let input_l = padded(&source_l);
    let input_r = padded(&source_r);
    let mut direct_out = vec![0.0; frames];
    let mut fft_out = vec![0.0; frames];

    let create_start = Instant::now();
    let mut fft_size = 0;
    let handle = unsafe { fft_detector_create(&mut fft_size) };
    let create_time = create_start.elapsed();
    assert!(!handle.is_null());
    assert!(fft_size >= TILE_FRAMES + 2 * RADIUS);
    assert_eq!(rows.len(), ROW_COUNT);

    direct(&input_l, &input_r, frames, &rows, &mut direct_out);
    let status = unsafe {
        fft_detector_run(handle, source_l.as_ptr(), source_r.as_ptr(), frames, fft_out.as_mut_ptr())
    };
    assert_eq!(status, 0);
    let mut max_abs_error = 0.0f64;
    let mut max_relative_error = 0.0f64;
    let mut worst_index = 0usize;
    for (index, (expected, actual)) in direct_out.iter().zip(&fft_out).enumerate() {
        let error = (expected - actual).abs();
        if error > max_abs_error {
            max_abs_error = error;
            worst_index = index;
        }
        max_relative_error = max_relative_error.max(error / expected.abs().max(1.0e-300));
    }

    let mut direct_times = Vec::new();
    let mut fft_times = Vec::new();
    for _ in 0..3 {
        let start = Instant::now();
        direct(&input_l, &input_r, frames, &rows, &mut direct_out);
        direct_times.push(start.elapsed());
        let start = Instant::now();
        let status = unsafe {
            fft_detector_run(handle, source_l.as_ptr(), source_r.as_ptr(), frames, fft_out.as_mut_ptr())
        };
        assert_eq!(status, 0);
        fft_times.push(start.elapsed());
        black_box((&direct_out, &fft_out));
    }
    let direct_median = median(&mut direct_times);
    let fft_median = median(&mut fft_times);
    unsafe { fft_detector_destroy(handle) };

    println!("frames={frames} tile={TILE_FRAMES} radius={RADIUS} rows={ROW_COUNT} nfft={fft_size}");
    println!("fft_plan_init_ms={:.3}", create_time.as_secs_f64() * 1_000.0);
    println!("direct_safe_rust_ms={:.3}", direct_median.as_secs_f64() * 1_000.0);
    println!("signalsmith_fft_ms={:.3}", fft_median.as_secs_f64() * 1_000.0);
    println!("speedup={:.2}", direct_median.as_secs_f64() / fft_median.as_secs_f64());
    println!("max_abs_frame_peak_error={max_abs_error:.17e} at frame={worst_index}");
    println!("max_relative_row_error={max_relative_error:.17e}");
}
