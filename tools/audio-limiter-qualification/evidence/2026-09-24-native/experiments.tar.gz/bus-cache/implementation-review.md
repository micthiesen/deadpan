# Exact bus range cache

Owned source change: `crates/deadpan-audio/src/limited.rs` only.

`LimitedAudio` now retains twelve raw bus cache entries beside its four verified
limiter tiles. Each raw entry contains an exact sample range and its complete
PreparedBus: PCM, authored suppression, and transitive source fingerprints.

The existing limiter required_context is split from its exact start into
consecutive chunks of at most 8192 frames. No chunk is rounded outward to a
canonical grid. An exact start/end match is the only cache hit. A partial final
chunk does not stand in for a later longer chunk with the same start.

Hits are removed before StageAudio::revalidate_dependencies. Provider errors,
cancellation and budget failures propagate, leaving that entry removed. A valid
new fingerprint invalidates the old PCM and triggers normal preparation. Every
check and new chunk uses the original PreparationBudget; no new deadline or
work counter is allocated. WorkControl rejects inconsistent fingerprints within
the same request before their dependency maps can be unioned.

Assembly copies exact chunk PCM into the original context, unions every chunk's
complete dependencies, and clips/merges suppression for the final requested
tile. Only LimitedTile::prepare may publish verified limited PCM. Valid prepared
bus entries may remain reusable after a later limiter failure.

The cache uses LRU ordering, with a maximum of twelve entries. Interior sequential
contexts shift by 8192: seven old full chunks can be reused; one new full chunk
and one 1152-frame remainder require preparation, totaling9344 new frames rather
than66688. Boundary-clipped contexts use their actual exact ranges and may have
different reuse patterns.

Exports for the parent to register/test:
`MAX_CACHED_LIMITER_BUS_BLOCKS=12` and `LimitedAudio::cached_bus_block_count()`.
The parent owns integration regressions and pipeline timing. No kernel/native
code changed, and the earlier direct-kernel output audit remains applicable to
those unchanged sources. Integration PCM parity must still be verified by the
parent's tests after this cache change.

Scoped compilation passed:
`cargo check -p deadpan-audio --locked`, Rust1.97.1 with the pinned FFmpeg prefix.
Strict library Clippy also passed:
`cargo clippy -p deadpan-audio --lib --locked -- -D warnings`.
Final owned file SHA-256:
`e3b45c857689fe3d7bc5ab07b18c1727276799da3125656188e271b92700cfb2`.
