# Exact limiter bus cache review

Scope: read-only review of `crates/deadpan-audio/src/limited.rs` and `crates/deadpan-audio/tests/stages/limited.rs`, focused on the exact bus-block cache. Production `limited.rs` SHA-256 observed: `e3b45c857689fe3d7bc5ab07b18c1727276799da3125656188e271b92700cfb2`.

Verdict: no concrete correctness, bounds, dependency, or suppression defect found in the reviewed change.

Evidence reviewed:
- `LimitedAudio::read` validates request bounds before capacity allocation and uses one `PreparationBudget` across all canonical output tiles.
- A canonical output tile asks `LimitedTile::required_context` for its complete limiter support, clipped only at the project interval. `tile` splits that interval from its exact start into non-overlapping intervals no wider than 8192 frames; it does not round or fetch beyond the required support.
- `bus_block` keys by the exact `(start,end)` range, admits hits only after revalidating the complete `PreparedBus.dependencies`, and shares the same cumulative budget with cold preparation and source-identity observations. Stale entries are removed before revalidation; errors cannot leave them available for reuse. New entries are limited to 12, each at most 8192 stereo frames.
- A tile's dependency union covers every bus interval used to produce the final limited tile. The shared `WorkControl` rejects provider fingerprints that change for one asset within a read, including between a cache revalidation and subsequent cold preparation. On later reads, each retained tile/block is revalidated against the provider.
- Suppression ranges are clipped to the canonical output tile while assembling bus context, then clipped/merged again to the caller's request. The underlying bus ranges are traversed in ascending contiguous order; stage preparation itself merges ranges.
- Read-only regression coverage includes overlapping adjacent tile reuse with changed provider layout, per-read provider-identity consistency across warm tiles, cache count limits/cancellation, equality with direct full-context output, and a fixture proving context ending at sample 29248 does not fetch a following source beginning at sample 30000.

No test command was run for this narrow review because the parent reported the focused tests were already running in the shared checkout. This file is a reviewer attestation, not captured test stdout.
