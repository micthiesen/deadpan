"""Summarize one completed independent audit from its retained snapshots."""
from decimal import Decimal
import hashlib
import json
from pathlib import Path
import struct
import sys

root = Path(sys.argv[1])
audit = json.loads((root / "audit.json").read_text())
cases = audit["cases"]
summary = {
    "script_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
    "audit_sha256": hashlib.sha256((root / "audit.json").read_bytes()).hexdigest(),
    "cases": len(cases),
    "exact_bs_all_pass": all(x["exact_bs_below_ceiling"] for x in cases),
    "all_shared_gain_bytes": all(x["shared_gain_recreates_output_bytes"] for x in cases),
    "all_gains_in_unit_interval": all(x["gains_in_closed_unit_interval"] for x in cases),
    "all_numeric_zeros_preserved": all(x["numeric_zeros_preserved"] for x in cases),
    "unchanged_input_bytes": [x["name"] for x in cases if x["unchanged_input_bytes"]],
    "active_frames_not_preserved": [x["name"] for x in cases if not x["nonzero_frames_preserved"]],
    "max_attack_slope_excess": max(x["maximum_attack_slope_excess"] for x in cases),
    "max_release_slope_excess": max(x["maximum_release_slope_excess"] for x in cases),
    "max_bs_report_difference": max(abs(x["bs_difference_from_report"]) for x in cases),
    "sinc_witnesses": sum(len(x["complete_sinc_point_checks"]) for x in cases),
    "all_sinc_witnesses_below": all(y["below_ceiling_at_this_point"] for x in cases for y in x["complete_sinc_point_checks"]),
    "max_sinc_witness_report_difference": str(max(abs(Decimal(y["difference_from_report"])) for x in cases for y in x["complete_sinc_point_checks"])),
    "retained_input_checks": [x["retained_input_identity"] for x in cases if x["retained_input_identity"] is not None],
}
source = list(struct.iter_unpack("<ff", (root / "near-nyquist-inputs.wav").read_bytes()[44:]))
output = list(struct.iter_unpack("<ff", (root / "near-nyquist-outputs.wav").read_bytes()[44:]))
missing = [n for n, (x,y) in enumerate(zip(source, output)) if any(x) and not any(y)]
ranges = []
for n in missing:
    if ranges and n == ranges[-1][1]:
        ranges[-1][1] += 1
    else:
        ranges.append([n,n+1])
report = json.loads((root / "near-nyquist-reports.json").read_text())
summary["near_nyquist"] = {"gain_min": report["gain_min"], "new_zero_frames": len(missing),
                           "new_zero_ranges": ranges, "longest_zero_frames": max((b-a for a,b in ranges), default=0),
                           "zero_total_ms": len(missing)/48}
(root / "summary.json").write_text(json.dumps(summary, indent=2) + "\n")
print(json.dumps(summary, indent=2))
