"""Read-only mathematical checks; no limiter producer or repository writes.

Decimal evaluations use a retained 100-digit pi constant and 80 decimal places.
They are high-precision numerical witnesses, not interval certificates.
"""

from decimal import Decimal, localcontext
import hashlib
import json
from pathlib import Path
import platform
import sys

ROOT = Path(__file__).resolve().parent
PI = Decimal("3.1415926535897932384626433832795028841971693993751058209749445923078164062862089986280348253421170679")


def main():
    with localcontext() as ctx:
        ctx.prec = 80
        one = Decimal(1)
        half = one / 2
        amplitude = Decimal("0.8")
        ceiling = Decimal(10) ** (-one / 20)
        examples = []
        # Complete finite sinc at t=-1/2. Only even PCM frames are nonzero.
        for frames in (512, 8192):
            total = sum((one / (2 * k + half) for k in range(frames // 2)), Decimal(0))
            witness = amplitude * total / PI
            examples.append({
                "frames": frames,
                "sample_pattern": "0.8 at every even index; exact zero at every odd index",
                "coordinate": "-0.5",
                "value": str(witness),
                "db": str(20 * witness.log10()),
                "over_minus_1db": witness > ceiling,
            })

        # Dropping only a negative signed-row contribution increases the row.
        # x=[1,1], t=3/2: a=[-2/(3*pi), 2/pi].
        delta = one / (2 ** 32)
        before = 4 / (3 * PI)
        after = before + 2 * delta / (3 * PI)

        # Distant even islands can exceed the ceiling while the first 8192
        # samples are all zero. Integral of decreasing positive terms supplies
        # an analytic lower bound; Decimal evaluates the bound numerically.
        first = 8192
        end = 4 * 60 * 48000
        distant_lower = amplitude / (2 * PI) * ((Decimal(end) + half) / (Decimal(first) + half)).ln()
        result = {
            "python": sys.version,
            "platform": platform.platform(),
            "decimal_precision": 80,
            "pi_digits": 100,
            "numerical_scope": "high-precision numerical evaluations of explicit formulas, not interval certification",
            "script_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
            "ceiling": str(ceiling),
            "complete_finite_even_island_witnesses": examples,
            "downward_quantization_counterexample": {
                "samples": [1, 1],
                "coordinate": "1.5",
                "original_gains": [1, 1],
                "changed_gains": [f"1 - 2^-32", 1],
                "before": str(before),
                "after": str(after),
                "increase": str(after - before),
                "claim": "A downward quantization can increase a previously constrained signed row; no global-max claim is needed.",
            },
            "distant_context_witness": {
                "frames": end,
                "first_nonzero_frame": first,
                "nonzero_pattern": "0.8 on even frames in [8192,11520000), zero elsewhere",
                "coordinate": "-0.5",
                "analytic_lower_bound": "0.8/(2*pi) * log((11520000+0.5)/(8192+0.5))",
                "lower_bound_evaluation": str(distant_lower),
                "over_minus_1db": distant_lower > ceiling,
                "claim": "A complete-sinc query is not determined by the first 8192 samples, all of which are zero in this example.",
            },
        }
        assert after > before
        assert distant_lower > ceiling
        (ROOT / "counterexamples.json").write_text(json.dumps(result, indent=2) + "\n")
        print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
