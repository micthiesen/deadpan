# Post-mask master gain: independent mathematical review

2026-09-24. Read-only repository review, with scratch-only mathematical checks
and an independent audit of completed producer outputs. This does not adopt a
limiter, qualify listening/export, or establish production seek/runtime behavior.

## Recommendation

Continue the finite-fixture cutting-plane experiment. A shared post-mask gain
with all gain, slope, and signed reconstruction constraints inside the same
optimization can resolve the retained failure mechanism without filtering over
zeros or inserting a fixed fade on a one-sample fragment. The completed v3
rapid-mask 0.8 and 16 outputs support that direction. Do not adopt its global
optimizer as an interactive master reader: the 16 case took 92.95 seconds for
8192 frames, and complete sinc introduces whole-revision dependencies.

Use this as a qualification baseline against which a faster bounded design must
be compared. Keep a certified or explicitly numerically qualified feasible
incumbent, improve cut coverage, and measure the extra reduction required when
the optimization budget expires. Do not disguise failed convergence as a pass.

## Why the optimization is sound in exact arithmetic

Let `x_c[n]` be the final policy-resolved stereo bus, with all required digital
silence already present. Let `g[n] = sum_j B[n,j] z[j]`, where B linearly
interpolates fixed project-origin gain knots, B is nonnegative, and its rows sum
to one. The output is `y_c[n] = x_c[n] g[n]`. No signal filter follows the mask.

For a queried real coordinate t, complete finite reconstruction is

```
F_c(t) = sum_(n=0..N-1) x_c[n] sinc(t-n) g[n]
       = a_c(t)^T z.
```

The absolute peak constraint is the pair `a^T z <= T` and `-a^T z <= T`.
Published finite FIR rows have exactly the same linear form. Add sample caps,
`0 <= z <= 1`, and both directional gain-slope inequalities. These form a convex
feasible set. The all-zero gain is feasible; a sufficiently small positive
constant gain is feasible for every finite nonzero input. Thus the retained
rapid-mask failures are not an infeasibility of post-mask shared gain.

Maximizing positive weighted gain is a useful first experiment, not a claim of
perceptual optimality. If unity is already feasible, it attains the maximum at
every frame. A final-input bypass makes that preservation explicit and avoids
solver tolerance affecting quiet PCM. There must be no preconditioner in that
quiet-control comparison. A quiet passage near a loud event may legitimately
be inside the chosen attack/release transition; that differs from an entirely
compliant input being changed without need.

With nonnegative shared gain, exact zero PCM stays zero and the real-valued
stereo ratio is retained before output rounding. Tiny Hard fragments retain
their positions and durations; no fixed 96-sample master envelope is required.
The general mathematical constraints still permit zero gain, and f32 underflow
can erase a subnormal channel even with positive shared gain. Therefore report
actual active-frame survival and quiet-byte equality, rather than promising
that every arbitrary nonzero f32 sample can survive all necessary limiting.

## Two decisive counterexamples

1. **Independent downward gain changes are not peak-monotone.** For samples
   `[1,1]` at `t=3/2`, the signed sinc row is `[-2/(3*pi), 2/pi]`. Reducing only
   the first gain from 1 to `1-2^-32` increases that constrained row by
   `2/(3*pi*2^32) = 4.9408197121e-11`. A tight signed cut can therefore be broken
   by downward quantization, clipping a tiny negative numerical gain, or a
   later attack/release minimum pass. Slopes belong inside the solve; the final
   f32 waveform needs a fresh check. Uniform multiplication of the entire gain
   by one positive scalar is different: every exact reconstruction scales by
   that scalar, preserving all existing absolute linear constraints.

2. **The detector has no inherited finite seek horizon.** A signal with exact
   zero frames before 8192 and value 0.8 on every even frame in
   `[8192,11520000)` has complete-sinc value at `t=-1/2` bounded below by

   ```
   0.8/(2*pi) * log((11520000+0.5)/(8192+0.5))
   = 0.9229230744... > 10^(-1/20).
   ```

   The bound follows by integrating the decreasing positive series
   `0.8/pi * sum 1/(2*k+1/2)`. Every one of the first 8192 PCM samples is zero.
   This is a concrete four-minute input, not an infinite sequence. It proves
   that complete-sinc evaluation is not determined by a short local PCM
   window. It does not claim every finite local limiter must fail every such
   input; a conservative duration-dependent bound can attenuate against
   unknown context, at the cost of unnecessary reduction. The existing
   4096-future/8192-past cap recurrence horizons bound that recurrence only.

`counterexamples.py` and `counterexamples.json` retain these calculations using
80-digit Decimal arithmetic. They also show the duration dependence directly:
unconditioned 0.8-valued even islands give a witness of 1.2441657 for 512 frames
and 1.5972992 for 8192 frames at `t=-1/2`. These are new formula checks, not
reproductions of the old conditioned-output peaks.

Digital silence is the applicable invariant. A nonzero finite sinc sum is an
analytic function and cannot vanish on an open real-time interval without
vanishing identically. Requiring exact digital silence is coherent; requiring
every reconstructed analog instant in that interval also to be zero would be
a different and generally impossible contract.

## Numerical qualification and a path to a certificate

The retained oracle includes all finite samples and evaluates a nonperiodic
linear convolution. Its outer-tail and between-grid bounds have a valid
analytic structure. For final f32 output y, use

```
T_tail = sum |y[n]| / (pi*D)
U_grid = max_i |F(t_i)| + M2/(8*P^2),   t_i spacing 1/P
U = max(T_tail, U_grid).
```

`M2` bounds the second derivative everywhere. The retained formula uses
`|sinc''(u)| <= pi^2/3` near zero and
`pi/q + 2/q^2 + 2/(pi*q^3)` for distance at least q, with a conservative
two-samples-per-distance-bucket count. This covers every cell, not just the
eight extrema chosen for refinement. The tail calculation covers the infinite
outer domain beyond the finite scan.

However, `finite_sinc.py:164` adds `1e-10 * max(1,L1)` as an empirical floating
allowance. It does not prove all FFT, coefficient, reduction, and elementary
function errors fit inside that allowance. Direct high-precision checks at
reported witnesses confirm those points; they do not certify the global upper
bound. Keep the current label **qualified numerical upper bound**.

A rigorous next certificate should calculate outward-enclosed grid values,
M2, and the tail bound. One concrete implementation is outward interval
coefficient construction plus verified finite convolution, followed by the
same cell bound. A second is exact integer convolution of fixed-point
approximations with explicitly bounded coefficient/input quantization; the
convolution must be complete linear convolution, not a periodic FFT. Both
need their own measured cost and numerical implementation review. A few
random direct checks or a wider empirical margin are not substitutes.

For interval cutting-plane coefficients `a_mid +/- a_rad`, nonnegative z
allows the robust rows `(a_mid+a_rad)^T z <= T` and
`(-a_mid+a_rad)^T z <= T`. Solver success remains provisional: validate actual
returned gains, constraints and final output. Include f32 conversion in the
error budget. With capped ideal output below 1, a conservative per-sample
rounding error is `2^-25`; for N=8192 the simple sinc row bound
`2+(2/pi)*sum_(q=1..N) 1/q` is about 8.1. Its worst-case rounding contribution
is about `2.4e-7`, already larger than a universal claim based on a `1e-7`
cut margin. The final waveform check is therefore necessary even if the
linear solve was exact.

## Preferred experiment and convergence rule

Use the parent's current 8192-frame, 64-sample-knot experiment as the bounded
test: 129 control variables, shared stereo gain, slopes inside the LP, raw
sample constraints plus both signs of published BS FIR and complete-sinc
rows. No conditioner, post-solve minimum recurrence, independent gain
rounding, or filter after the policy mask. Recheck final f32 at every
separation step and at the final 128-phase complete-sinc audit.

Improve selection by taking a violating maximum in each knot cell/channel
before filling the remaining row allowance by severity. Globally highest
rows can cluster at nearly identical positions/phases, spending many solves
before other affected regions receive constraints. This is a convergence
heuristic to measure, not a finite-convergence proof.

Retain a feasible incumbent using one uniform gain scale:
`alpha = min(1, target/max(BS_upper,sinc_upper))`. Regenerate from the original
input with `alpha*g`, round to f32, and verify again. This preserves exact
linear/slope feasibility before rounding, unlike independently reducing
individual gains. It gives a baseline for the remaining gain objective and
an explicit measure of extra reduction if optimization stops early. It may
attenuate distant quiet passages; it is not automatically a desirable
production fallback. Never substitute it silently for the tested algorithm.

Cap rows, knot count, rounds, source duration and bytes, and use a remaining
whole-case deadline for every solver call. The initial v1 lacked a solver
time limit despite a 32-round cap. v3 now carries a 180-second cooperative
case deadline and passes the remaining allowance to HiGHS; these are not
preemptive native-call deadlines. Preserve failed variants and report their
budgets and signal names.

## Practical cost and canonical seek

The initial scan uses 31 fractional phases per channel over all 8192 samples;
the final oracle retains 3,145,728 grid values per channel, about 24 MiB for
that array alone. Magnitudes, convolution buffers, and solver storage add to
this. Dense cut rows have 129 entries, so row inventory affects LP memory and
solve time even with compact knot control. Measure peak RSS; a matrix-size
calculation does not bound HiGHS internal copies.

The observed v3 0.8 case took about 1.52 seconds, and 16 took 92.95 seconds
for 0.1707 seconds of stereo input. These are Python/HiGHS research costs on
the current Mac, not native throughput predictions, but plainly do not
qualify immediate mastering of arbitrary project revisions.

A globally prepared immutable gain/PCM object can provide exact range reads
after preparation. It must be keyed by the full revision and admitted media,
bus/policy settings, algorithm/solver version, and absolute knot origin.
Changing duration or distant material may change existing gains. Cold seek
can require complete preparation; independently optimizing request windows
or concatenating optimized tiles changes the algorithm. A canonical solver
tie-break and execution identity remain necessary if recomputation must be
bit-identical rather than merely reusing retained PCM bytes. None of this
creates a finite local detector horizon.

## Independent output checks completed

The standard-library `audit_outputs.py` snapshots input/output/report bytes,
checks the stored hashes, recreates final f32 output from the recorded shared
gain, and performs an exact integer published-FIR scan. Every finite f32 is
represented as an integer times `2^-149`; the FIR coefficients are exact
integers times `2^-13`, so convolution is integer arithmetic with a `2^-162`
output denominator. This establishes the listed finite FIR peaks without
FFT or floating reduction error. It includes zero extension and sample-peak
floor. Independent 80-digit direct sinc sums confirm reported witnesses.

Completed v3 snapshots are in
`output-audit-1790240936872492000/audit.json`:

| Case | Exact finite BS peak | Fresh complete-sinc witness | Other checks |
| --- | ---: | ---: | --- |
| rapid-mask 0.1 | 0.1034667984167754184 | 0.2060027571336107534 | Entire WAV unchanged |
| rapid-mask 0.8 | 0.8000000119209289551 | 0.8568077161801901914 | All 4096 islands and exact zeros retained |
| rapid-mask 16 | 0.8560516834259033203 | 0.8816290344942499505 | All 4096 islands and exact zeros retained |
| alternating 0.1 | 0.1191894549010612536 | 0.3535324745117881628 | Entire WAV unchanged; opposed stereo retained |

All four reconstructed output byte-for-byte from the same interpolated gain
for both channels. Gains stayed in `[0,1]`. Actual floating gain slope
excesses were at most `1.11e-16` in this v3 subset; these are numerical slopes,
not the prior prototype's exact integer recurrence guarantee. Earlier v1
0.8 audit also found a release excess of `2.22e-16`. No production code or
whole-workspace tests were changed/run by this audit.

## Claim boundaries and exact references

- Normative product order, level preservation, -1 dBTP default, tiny fades,
  Hard policy and silence: `docs/spec/DEADPAN_SPEC.md:554-588`.
- Retained negative evidence and numerical limits:
  `docs/qualification/audio-limiter-postmask-2026-09-22.md:19-45,48-76,89-96`.
- Prior finite detector and separate min recurrences:
  `tools/audio-limiter-qualification/evidence/2026-09-22-postmask/producer/prototype.py:142,164,335`.
- Complete finite oracle and global-bound arithmetic:
  `tools/audio-limiter-qualification/evidence/2026-09-22-postmask/audit/finite_sinc.py:94-164`.
- Reviewed new algorithm: `producer-v3/experiment.py:99` (basis), `:109`
  (complete scan), `:132` (finite BS scan), `:147` (LP), `:165` (solver time
  admission), `:214` (final f32 oracle). Bound source hash:
  `2017061ccb2185b1a93bb4e200706b186e4b7666db54e8f8f16e856bf5197a3b`.
- [ITU-R BS.1770-5, Annex 2 and its Attachment 1](https://www.itu.int/dms_pubrec/itu-r/rec/bs/R-REC-BS.1770-5-202311-I!!PDF-E.pdf),
  printed pp.18-22: an estimation method, example finite FIR, oversampling
  under-read and filter-response discussion. It does not specify this gain
  optimizer or guarantee every possible DAC reconstruction.
- [EBU Tech 3341](https://tech.ebu.ch/docs/tech/tech3341.pdf), Section 2.6 and
  Table 1 signals 15-23: finite meter tests and tolerances. These are meter
  requirements, not a limiter design or proof against arbitrary masks.

Passing the published FIR, passing complete finite ideal sinc numerically,
certifying a specified reconstruction mathematically, physical DAC behavior,
and post-AAC behavior are separate claims. This experiment currently supports
the first two on named files, with independent exact finite-FIR checks and
pointwise high-precision sinc confirmation for the subset above.
