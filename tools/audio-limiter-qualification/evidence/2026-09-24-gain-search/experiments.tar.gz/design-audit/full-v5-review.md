# Independent v5 pilot and full-output audit

The two v5 pilot files and all 16 completed `producer-v5-full` files were
independently audited from byte snapshots. All full-run outputs pass the
exact finite BS arithmetic check, preserve all original numeric zeros and
active frames, and reproduce byte-for-byte from their recorded shared gain.
No repository or producer files were modified and no optimization was run.

## Artifacts and identity

- Pilot: `output-audit-1790241740473798000/`.
- Full corpus: `output-audit-1790241871184261000/`.
- Each contains `audit.json`, the input/output/report snapshots, and the exact
  source of the shared auditor as `auditor.py`.
- `floor-reference/` contains reconstructed uniform-reference WAVs, its
  numerical-oracle results, independent exact FIR and Decimal witness checks,
  copied source files, and `audit.json`.
- Full base audit SHA-256:
  `248972dec4de50f21faa263e386fcac595bb328a2cc87b2f6671dabdb6e9dd36`.
- Full floor audit SHA-256:
  `2a63044d6f35c478bba43326111a6befc994b225f823dbd36ec8c6bc838539e3`.
- Pinned CSR gain replay: `csr-gain-audit.json`, SHA-256
  `b4afa6d8d14cb7791206fa43cec1e84e9838a22d86da46c1bb5f567f4a6cb88b`.
- Both runs bind producer source hash
  `8020fbf6e26f67ad3c0346fa83c3f30ccc40c1901d36c4aa9be23ce75de909f2`.

The two prior-failure inputs remain byte-identical to their retained
repository WAVs. The pilot and full-run near-Nyquist and quiet-one-sample
output WAVs are also byte-identical to one another. This is a two-run result,
not a cross-platform determinism or random-seek qualification.

## Output checks

All 16 exact BS peaks equal the producer's reported peak values. The independent
implementation represents f32 as integers times `2^-149`, applies the published
dyadic FIR with exact integer convolution, includes complete finite zero
extension and sample-peak floor, and compares the result to the -1 dB ceiling
using the integer inequality `10*p^20 <= 2^(162*20)`.

All 32 fresh 80-digit complete-sinc output witness sums are below the ceiling.
They confirm the reported points, not an independently certified all-real
global maximum. The largest witness/report difference remains `5.91452e-11`
on the quiet one-sample fragment near integer 100, the previously documented
near-integer sine evaluation issue in the retained oracle.

All final gain values lie in `[0,1]`; using the same interpolated gain for both
input channels recreates every f32 output byte. Maximum slope excess in the
producer's actual pinned CSR arithmetic is `5.551115123125783e-17` for attack
and `1.1102230246251565e-16` for release. The independent scalar re-evaluation
gives maxima of `1.1102230246251565e-16` and `2.220446049250313e-16` respectively.
These are numerical slopes, not exact quantized recurrence bounds.

Eight complete input WAVs are unchanged: `alternating-0.1`, `rapid-mask-0.1`,
`quiet-tone`, `quiet-dc`, `quiet-1-sample-fragment`, `quiet-2-sample-fragment`,
`hard-silent-gap`, and `permitted-tail`. All rapid-mask cases retain 4096 active
islands; the opposed hot two-sample fragment retains both frames.

The v5 near-Nyquist result has minimum actual gain
`0.010331085048034618`, versus the reference uniform gain
`0.020662170096069236`. It retains all 8192 nonzero frames, with no newly zero
intervals. This fixes the observed v3 zero-gain outcome on this fixture. It
does not establish listening quality or the general fidelity of the gain
objective.

## Uniform reference and floor checks

For every full-run case the audit independently reconstructed the original
input and the uniform f32 reference waveform. Its exact BS peak passes the
product ceiling. The retained complete finite-sinc oracle was rerun on both
input and uniform output; the recomputed input upper bound, uniform gain
formula, uniform BS report, and uniform sinc bound all match the producer's
stored values exactly. All 32 new uniform-reference Decimal witness checks
are below the ceiling.

The global sinc rerun uses the same retained numerical oracle with a verified
source hash. It is a fresh verification of the reference calculation and
bytes, not a new independent global or interval certificate. Exact FIR
arithmetic and high-precision point sums remain separate checks.

Every reference gain is positive and no greater than one; every recorded
floor equals exactly half its uniform reference. All returned knots and all
actual gains under the producer's pinned CSR interpolation meet their floor.
An independent scalar interpolation differs by at most `1.11e-16` from that
evaluation. In one case it produces a value slightly below the floor:

| Case | Uniform reference | Minimum scalar gain | Scalar floor undershoot |
| --- | ---: | ---: | ---: |
| alternating-16.0 | 0.01513169138394361 | 0.007565845691971804 | 8.673617379884035e-19 |

The actual CSR minimum for that case is `0.007565845691971805`, exactly the
recorded floor and minimum. Both evaluations recreate identical f32 output
bytes. The apparent one-ULP floor failure is therefore a difference in audit
evaluation order, not a producer floor violation. The supplemental CSR audit
confirms all 16 reported min/max values and every output byte without running
the optimizer. Fields referring to interpolated minima in the earlier
`floor-reference/audit.json` describe the scalar evaluation; use the CSR audit
for claims about the producer's exact arithmetic.

The mathematical half-reference constraint corresponds to 6.020599913... dB,
relative to that particular feasible uniform reference. It is an experimental
fidelity bound, not least necessary attenuation or a normative six-dB policy.
Another implementation order or platform still needs numerical qualification.

## Remaining limits

The finite corpus now avoids both the retained peak failures and the observed
v3 zero-frame failure. This does not qualify perceptual transparency, arbitrary
signals or f32 subnormal survival, a formal all-real reconstruction certificate,
physical DACs, AAC output, real-time throughput, or canonical local seek. Global
optimization still depends on the complete finite input. The most expensive
full-run case remains many seconds for 8192 frames; native optimization and a
production range-reader design are unmeasured.

The previous audit scripts remain unchanged and their hash-matching versions
are copied into their evidence directories. V5 reference work is isolated in
the new `audit_floor.py`; the empty-new-zero summary case uses
`summarize_audit_v5.py`, preserving the original v3 summarizer.
