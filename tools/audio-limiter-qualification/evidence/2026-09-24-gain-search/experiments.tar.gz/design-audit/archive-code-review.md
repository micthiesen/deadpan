# Archive verifier and retention review

Read-only targeted review of `tools/audio-limiter-qualification/evidence/2026-09-24-gain-search/verify.py`
and `/tmp/deadpan-limiter-20260924/retain.py`, before the archive was sealed.
No DSP, producer, repository mutation, or workspace check was run. The current
producer environment hashes inspected matched their corresponding scripts.

Three actionable guard omissions were reported to the parent:

1. **Derive PCM facts before claiming their verification.** At verifier
   lines 116-121, the v3 newly silent frame count and v5 preserved-frame and
   unchanged-control assertions use stored report counts/booleans. The WAVs
   have already been decoded at lines 78-80, so independently count nonzero
   input/output frames and compare complete input/output bytes. Compare those
   derived facts with the stored fields and the expected v3/v5 outcomes.
   A stale producer flag/count currently passes if copied consistently into
   `results.json` and the per-case report, even though the final printed
   `v5_active_frames_preserved_cases` and `v5_unchanged_controls` imply those
   properties were checked against PCM.

2. **Require unique and complete case coverage.** At verifier lines 100-103,
   a 16-entry native-meter summary is accepted without unique names or
   equality with the producer's case-name set. A duplicated report entry can
   replace a missing case and still produce the claimed 32 meter joins.
   Assert unique native names and exact coverage of the matching producer
   result names. Also reject duplicate names in producer result lists before
   counting joined cases.

3. **Reject missing required retention inputs.** At retainer lines 26-30,
   missing explicitly named files are silently skipped. At lines 46-52, a
   missing selected audit directory produces an empty `rglob` result without
   rejection. Assert each selected full-v3/v5-pilot/v5-full audit directory
   exists, and assert explicitly required root/dependency files are regular
   files before collecting. Otherwise a renamed or removed final audit or
   `docs-review.json` can be omitted while an archive is still sealed.

Exclusive `xb`/`x` publication prevents silently overwriting a sealed archive
or manifest. A failure during publication can leave an incomplete archive
which prevents an ordinary rerun; this is visible, fail-closed behavior rather
than an observed overwrite. No current PCM corruption or mismatched producer
script identity was found in this scope. The three findings concern what the
new sealing/verification code fails to detect.

The parent owns fixes and the final archive verification. This review is
retained outside previously frozen numerical audit output directories.
