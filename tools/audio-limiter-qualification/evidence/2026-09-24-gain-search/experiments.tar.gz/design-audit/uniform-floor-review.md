# Audit of the proposed v5 uniform-reference gain floor

The proposed lower bound `g[n] >= u/2`, with fixed positive uniform reference
gain u for the whole finite input, is mathematically sound as an experimental
gain constraint. It limits additional gain attenuation relative to that
particular reference to `20*log10(2) = 6.020599913... dB`. Half is not exactly
6 dB. This is a new experiment rule, not a normative product setting.

The floor must participate in the LP bounds. Applying `max(g,u/2)` afterward
can violate signed peak cuts by increasing selected contributions. A lower
bound applied within the optimization does not have that problem. Because
the knot interpolation weights are nonnegative and sum to one, a lower bound
on all knot gains gives the same lower bound on all ideal interpolated gains.
Validate the actual returned and interpolated gains, rather than assuming
solver feasibility tolerances establish an exact bound.

## Feasibility qualification

A uniform reference that passes final f32 at the product ceiling is not, by
that fact alone, feasible for every LP row: the LP's target is stricter and
its rows act on the pre-rounding product. There are two straightforward ways
to make the feasibility argument explicit:

1. Admit u against the stricter reconstruction/row targets, including a
   stated rounding and coefficient-error allowance. Then the constant u
   vector is a feasible point satisfying the floor.
2. Verify the constant `u/2` vector itself. If `r=round_f32(u*x)` has peak at
   most C0 under a reconstruction and its rounding perturbation has bound E,
   then that reconstruction of the unrounded `u*x` is bounded by `C0+E`.
   The constant floor vector is bounded by `(C0+E)/2`. If this is below the
   LP target minus its guard, the floor vector is feasible for every such
   cut. Constant gain has zero slopes and satisfies the gain box when
   `0<u<=1`.

For the current N=8192, final output below 1, and widely separated product
and half-product levels, the second route has substantial slack. Signed
cancellation does not invalidate uniform scaling of the entire ideal signal.
Final f32 rounding does prevent an unconditional claim that every rounded
sample and reconstructed value scales exactly; regenerate and recheck the
actual output. The existing numerical global oracle remains numerical rather
than a formal interval certificate, so this review does not upgrade that
underlying admission claim.

## Fidelity limits

Keep u fixed during the case, positive, and at most one. Record how it was
chosen and checked. A conservative upper bound can produce a smaller u than
necessary, so the floor measures loss relative to that specific feasible
reference, not to the best possible uniform gain or the least possible
limiting. If the original input already satisfies the stricter constraints,
unity still satisfies the floor and maximizes the current positive gain
objective.

The floor avoids the v3 near-Nyquist exact-zero gain intervals in real
arithmetic. Actual f32 underflow can still erase extremely small nonzero
samples, including a tiny channel paired with a hot channel under shared
gain. The current fixtures use ordinary magnitudes, so directly verify their
active-frame counts, min gain, and new-zero ranges. Do not replace that check
with a claim based on the knot floor alone.

Positive gain and a fixed-reference reduction bound do not prove listening
quality, acceptable modulation, preservation of every intended dynamic,
local seek, or throughput. They are useful explicit experimental constraints
that address the observed zero-gain failure while retaining peak feasibility.

No producer or repository files were changed during this review.
