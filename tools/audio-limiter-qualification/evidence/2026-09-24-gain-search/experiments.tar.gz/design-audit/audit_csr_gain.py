"""Reconstruct the producer's pinned CSR gain arithmetic without optimizing.

This resolves scalar-vs-CSR float64 evaluation differences. It is an exact
implementation-order replay, separate from the independent scalar/FIR/sinc
checks. Source and all writes are inside this audit's snapshot directory.
"""
import argparse
import hashlib
import importlib.util
import json
from pathlib import Path
import sys

import numpy as np
import scipy

parser = argparse.ArgumentParser()
parser.add_argument("directory", type=Path)
args = parser.parse_args()
root = args.directory
source = root / "floor-reference/producer.py"
base = json.loads((root / "audit.json").read_text())
assert hashlib.sha256(source.read_bytes()).hexdigest() == base["producer_sha256"]
spec = importlib.util.spec_from_file_location("readonly_gain_basis", source)
producer = importlib.util.module_from_spec(spec)
spec.loader.exec_module(producer)
knots, basis = producer.interpolation()
results = []
for case in base["cases"]:
    name = case["name"]
    report = json.loads((root / f"{name}-reports.json").read_text())
    reference = report["fidelity_reference"]
    gain = np.asarray(basis @ np.asarray(report["gain_knots"], dtype=np.float64))
    data = (root / f"{name}-inputs.wav").read_bytes()
    source_pcm = np.frombuffer(data, dtype="<f4", offset=44).reshape(-1,2).astype(np.float64)
    output_bytes = (root / f"{name}-outputs.wav").read_bytes()[44:]
    recreated = (source_pcm * gain[:,None]).astype("<f4").tobytes()
    scalar = []
    for n in range(len(gain)):
        left = min(n//64,len(knots)-2)
        fraction = (n-int(knots[left])) / int(knots[left+1]-knots[left])
        z = report["gain_knots"]
        scalar.append((1-fraction)*z[left] + fraction*z[left+1])
    scalar = np.asarray(scalar)
    results.append({"name": name, "minimum_gain": float(gain.min()),
                    "reported_minimum_matches": float(gain.min()) == report["gain_min"],
                    "reported_maximum_matches": float(gain.max()) == report["gain_max"],
                    "gain_floor": reference["gain_floor"],
                    "all_producer_gains_meet_floor": bool(np.all(gain >= reference["gain_floor"])),
                    "all_producer_gains_at_most_one": bool(np.all(gain <= 1)),
                    "gain_floor_undershoot": max(0.,reference["gain_floor"]-float(gain.min())),
                    "output_bytes_match": recreated == output_bytes,
                    "maximum_attack_slope_excess": max(0.,float(np.max(-np.diff(gain)))-1/4096),
                    "maximum_release_slope_excess": max(0.,float(np.max(np.diff(gain)))-1/8192),
                    "scalar_gain_maximum_difference": float(np.max(abs(scalar-gain))),
                    "scalar_and_csr_differing_frames": int(np.count_nonzero(scalar != gain))})
result = {"script_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
          "producer_sha256": base["producer_sha256"], "python": sys.version,
          "numpy": np.__version__, "scipy": scipy.__version__,
          "scope": "Pinned producer interpolation replay only, no optimizer; scalar audit differences are distinct from actual CSR arithmetic",
          "cases": results,
          "all_actual_gains_meet_floor": all(x["all_producer_gains_meet_floor"] for x in results),
          "all_actual_output_bytes_match": all(x["output_bytes_match"] for x in results)}
(root / "csr-gain-audit.json").write_text(json.dumps(result,indent=2)+"\n")
(root / "csr-gain-auditor.py").write_bytes(Path(__file__).read_bytes())
print(json.dumps(result,indent=2))
