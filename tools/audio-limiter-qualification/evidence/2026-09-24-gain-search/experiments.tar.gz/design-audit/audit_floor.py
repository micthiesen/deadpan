"""Audit a completed v5 gain floor and reconstruct its uniform reference.

Input/output snapshots come from audit_outputs.py. Exact finite-BS arithmetic
and fresh Decimal point checks are independent. Complete-sinc global bounds
are recomputed with the same retained numerical oracle, explicitly not a new
independent global or interval certificate. No optimization is executed.
"""

import argparse
import ast
from decimal import Decimal, localcontext
import hashlib
import importlib.util
import json
from pathlib import Path
import struct
import sys

import numpy as np

import audit_outputs as independent

REPO = Path("/Users/michael/Code/deadpan")


def digest(data):
    return hashlib.sha256(data).hexdigest()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("directory", type=Path)
    args = parser.parse_args()
    root = args.directory
    original = json.loads((root / "audit.json").read_text())
    producer = Path(original["producer_directory"])
    environment = json.loads((producer / "environment.json").read_text())
    assert environment["script_sha256"] == original["producer_sha256"]
    assert digest((producer / "experiment.py").read_bytes()) == original["producer_sha256"]
    saved = root / "floor-reference"
    saved.mkdir(exist_ok=False)
    (saved / "auditor.py").write_bytes(Path(__file__).read_bytes())
    (saved / "producer.py").write_bytes((producer / "experiment.py").read_bytes())
    (saved / "environment.json").write_text(json.dumps(environment, indent=2) + "\n")
    oracle_path = REPO / "tools/audio-limiter-qualification/evidence/2026-09-22-postmask/audit/finite_sinc.py"
    oracle_bytes = oracle_path.read_bytes()
    assert digest(oracle_bytes) == environment["oracle_sha256"]
    copied = saved / "finite_sinc.py"
    copied.write_bytes(oracle_bytes)
    spec = importlib.util.spec_from_file_location("audit_retained_sinc", copied)
    oracle = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(oracle)
    fir_source = REPO / "crates/deadpan-audio/src/true_peak.rs"
    text = fir_source.read_text().split("const FIR: [[f64; 4]; 12] = ", 1)[1].split(";", 1)[0]
    coefficients = ast.literal_eval(text)
    assert all(float(value*8192).is_integer() for row in coefficients for value in row)
    fir = [[int(value*8192) for value in row] for row in coefficients]
    results = []
    for case in original["cases"]:
        name = case["name"]
        report = json.loads((root / f"{name}-reports.json").read_text())
        reference = report["fidelity_reference"]
        data = (root / f"{name}-inputs.wav").read_bytes()
        source = independent.wave(data)
        source_array = np.asarray(source, dtype=np.float64)
        input_reports = [oracle.audit_channel(source_array[:, ch], 128, 8192, 8) for ch in range(2)]
        input_bs = independent.exact_bs(source, fir) / (1 << 162)
        input_upper = max(input_bs, *(r["qualified_numerical_global_upper"] for r in input_reports))
        u = reference["uniform_gain"]
        floor = reference["gain_floor"]
        expected_u = min(1.0, (10 ** (-1.35/20) - 1e-6) / input_upper) if input_upper else 1.0
        uniform = []
        payload = bytearray()
        for pair in source:
            encoded = struct.pack("<ff", pair[0]*u, pair[1]*u)
            payload.extend(encoded)
            uniform.append(struct.unpack("<ff", encoded))
        uniform_path = saved / f"{name}-uniform.wav"
        uniform_path.write_bytes(data[:44] + payload)
        uniform_integer_peak = independent.exact_bs(uniform, fir)
        uniform_array = np.asarray(uniform, dtype=np.float64)
        uniform_reports = [oracle.audit_channel(uniform_array[:, ch], 128, 8192, 8) for ch in range(2)]
        uniform_upper = max(r["qualified_numerical_global_upper"] for r in uniform_reports)
        knots = list(range(0, 8192, 64)) + [8191]
        gains = report["gain_knots"]
        actual = []
        for n in range(8192):
            left = min(n//64, len(knots)-2)
            fraction = (n-knots[left]) / (knots[left+1]-knots[left])
            actual.append((1-fraction)*gains[left] + fraction*gains[left+1])
        with localcontext() as ctx:
            ctx.prec = 80
            ceiling = Decimal(10) ** (-Decimal(1)/20)
            witnesses = []
            for ch, r in enumerate(uniform_reports):
                t = r["refined_coordinate"]
                value = independent.witness(uniform, ch, t)
                witnesses.append({"channel": ch, "coordinate_hex": t.hex(), "value_80_digits": str(value),
                                  "below_ceiling_at_this_point": abs(value) < ceiling,
                                  "difference_from_retained_oracle": str(value-Decimal.from_float(r["refined_signed_value"]))})
        result = {"name": name, "uniform_gain": u, "gain_floor": floor,
                  "uniform_gain_positive_and_at_most_one": 0 < u <= 1,
                  "floor_exactly_half_uniform_gain": floor == u/2,
                  "recomputed_uniform_gain": expected_u,
                  "uniform_gain_formula_difference": u-expected_u,
                  "input_upper_difference": reference["input_upper"]-input_upper,
                  "uniform_wave_sha256": digest(uniform_path.read_bytes()),
                  "uniform_bs_exact_integer_peak": str(uniform_integer_peak),
                  "uniform_bs_denominator_power_two": 162,
                  "uniform_bs_exactly_below_product_ceiling": 10 * uniform_integer_peak**20 < (1 << (162*20)),
                  "uniform_bs_report_difference": uniform_integer_peak / (1 << 162) - reference["uniform_bs_peak"],
                  "uniform_sinc_numerical_upper": uniform_upper,
                  "uniform_sinc_report_difference": uniform_upper-reference["uniform_sinc_upper"],
                  "uniform_sinc_numerically_below_product_ceiling": uniform_upper < 10**(-1/20),
                  "actual_minimum_gain": min(actual), "actual_maximum_gain": max(actual),
                  "gain_floor_undershoot": max(0.0, floor-min(actual)),
                  "all_knots_meet_floor": all(g >= floor for g in gains),
                  "all_interpolated_gains_meet_floor": all(g >= floor for g in actual),
                  "actual_minimum_ratio_to_uniform": min(actual)/u,
                  "uniform_point_checks": witnesses}
        results.append(result)
        (saved / f"{name}-details.json").write_text(json.dumps({"input_oracle": input_reports, "uniform_oracle": uniform_reports, "result": result}, indent=2) + "\n")
        print(json.dumps({k: result[k] for k in ["name", "uniform_gain", "actual_minimum_gain", "gain_floor_undershoot", "uniform_bs_exactly_below_product_ceiling", "uniform_sinc_numerically_below_product_ceiling"]}), flush=True)
    result = {"script_sha256": digest(Path(__file__).read_bytes()),
              "base_audit_sha256": digest((root / "audit.json").read_bytes()),
              "producer_sha256": original["producer_sha256"],
              "oracle_sha256": digest(oracle_bytes), "numpy": np.__version__, "python": sys.version,
              "global_sinc_scope": "Recomputed retained numerical complete-sinc oracle, not an independent global or interval certificate",
              "cases": results}
    (saved / "audit.json").write_text(json.dumps(result, indent=2) + "\n")
    print(str(saved), flush=True)


if __name__ == "__main__":
    main()
