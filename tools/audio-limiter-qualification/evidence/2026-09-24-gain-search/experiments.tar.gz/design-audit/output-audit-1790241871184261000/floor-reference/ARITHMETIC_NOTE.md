The gain interpolation in `audit.json` is an independent scalar float64
evaluation. Its fields named `actual_minimum_gain`, `gain_floor_undershoot`,
and `all_interpolated_gains_meet_floor` describe that re-evaluation, not a
direct observation of the producer's SciPy sparse-matrix multiplication.

The scalar result for alternating-16.0 is one ULP below the floor. Replaying
the actual pinned producer interpolation gives the floor exactly. Both
produce identical f32 output bytes. The supplemental `../csr-gain-audit.json`
confirms all 16 producer minima/maxima, floor compliance, and output bytes.
It does not run optimization. Retaining the scalar result records the
evaluation-order distinction rather than overwriting its hash-bound evidence.
