# Independent v3 output audit

All 16 completed v3 cases were audited from retained byte snapshots. No
producer, repository, optimization, device, or GUI work was performed.

Final artifact:
`output-audit-1790241294821706000/audit.json`

Summary:
`output-audit-1790241294821706000/summary.json`

The final audit JSON SHA-256 is
`7d952346b9e979a34439d08f1b6307b95a18147329c0bca4f079ff5e689a4bcf`.
It records producer source hash
`2017061ccb2185b1a93bb4e200706b186e4b7666db54e8f8f16e856bf5197a3b`.
All input/output/report files were copied before checking and their producer
hashes rechecked afterward. The two retained-failure inputs are byte-identical
to the repository's prior failing WAVs, not approximations of those outputs.

## Results

- All 16 finite BS FIR peaks pass. The independent scan uses exact integer
  convolution of actual f32 values and dyadic coefficients, including full
  zero extension and the original sample-peak floor. Its comparison to
  `10^(-1/20)` is also exact: for peak `p/2^162`, test
  `10*p^20 <= 2^(162*20)`. All rounded reported peak values match the producer.
- All 32 fresh 80-digit complete-sinc witness sums are below the ceiling.
  These checks confirm the reported points, not the all-real global maximum.
- Every output byte can be recreated by applying the recorded interpolated
  shared gain to the input and rounding to f32. All actual gains are in
  `[0,1]`. Maximum floating slope excess is `2.220446049250313e-16` for both
  attack and release. This is tolerance-level agreement, not an exact
  integer-slope guarantee.
- All original numeric zeros survive. All rapid-mask and retained-failure
  cases keep their 4096 active frames; the two hot opposed samples survive.
- Eight complete input WAVs are unchanged: `alternating-0.1`,
  `rapid-mask-0.1`, `quiet-tone`, `quiet-dc`, `quiet-1-sample-fragment`,
  `quiet-2-sample-fragment`, `hard-silent-gap`, and `permitted-tail`.

## Material limitation: introduced silence

`near-nyquist` has minimum gain exactly zero. Its input has 8192 nonzero
frames; only 7102 output frames remain nonzero. The 1090 newly zero frames
occur in `[1856,2497)` and `[4736,5185)`, totaling 22.7083 ms. The longer
641-frame interval lasts 13.3542 ms. This is a real output change, not merely
an unobserved zero between gain knots. It is the only case failing active-frame
preservation in this corpus.

The constraints permit that result. The gain objective and peak compliance
therefore do not establish preservation of intentional dynamics. A sufficiently
small positive constant gain is feasible for these finite inputs, so zero gain
is not a mathematical necessity of satisfying a finite peak ceiling. This
finding calls for a design decision and qualification; it does not claim how
the result sounds. No listening quality is inferred from any peak pass.

## Numerical limitations

The largest fresh witness/report difference is `5.9145203486e-11`, on the
quiet one-sample fragment near integer coordinate 100. Its exact-input
waveform is just `0.5*sinc(t-100)` in the left channel; the fresh value at the
reported coordinate is `0.4999999999993973...`. The retained direct evaluator
computes `sin(pi*phase)` with phase close to 1, then divides by a small
distance. Argument error is amplified there. Evaluating the numerator as
`sin(pi*min(phase,1-phase))` would avoid this particular loss; no oracle file
was changed. All other witness differences are at most `2.61e-16`.

That discrepancy does not threaten this quiet file's ceiling result. It does
reinforce the existing limitation: the retained FFT/cell/tail calculation uses
an empirical arithmetic allowance, not outward-rounded interval certification.
This audit supplies exact finite-FIR results and independent pointwise sinc
checks, not an independent all-real certified complete-sinc maximum.

The global preparation cost, canonical seeking, physical DAC reconstruction,
encoded-output behavior, real audio listening, and full product mastering
remain unqualified. The prior design review's global-context counterexample
and numerical-certificate requirements still apply.

## Reproduction

The completed immutable producer remains at `../producer-v3` relative to this
directory. Run only the scratch audit:

```
python3 audit_outputs.py --producer /tmp/deadpan-limiter-20260924/producer-v3
python3 summarize_audit.py /tmp/deadpan-limiter-20260924/design-audit/NEW_OUTPUT_AUDIT_DIRECTORY
```

The first command creates a fresh timestamped output directory and prints its
path. The summary uses that directory's retained snapshots. Both scripts use
the Python standard library and never run the producer or modify repository
files. Earlier audit directories retain their earlier script identities and
scope; the final directory named above includes the exact rational ceiling
comparison and explicit retained-input joins.
