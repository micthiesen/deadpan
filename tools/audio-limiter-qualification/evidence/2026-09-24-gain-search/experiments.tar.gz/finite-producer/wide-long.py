"""Second, separately retained configuration. Not production qualification.

Finite8193/16phase with fixed absolute8192-frame overlap-save tiles. No input
conditioner. Reuses the exact four-pass control experiment, narrower guard.
"""
from pathlib import Path
import argparse
import importlib.util
import json
import math
import time

import numpy as np
from scipy import fft, ndimage

BASE = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('finite_short', BASE / 'experiment.py')
p = importlib.util.module_from_spec(spec)
spec.loader.exec_module(p)
parser = argparse.ArgumentParser()
parser.add_argument('cases', nargs='*')
parser.add_argument('--radius', type=int, default=8192, choices=[4096,8192])
parser.add_argument('--seek', action='store_true')
args = parser.parse_args()
p.ROOT = BASE / f'wide-r{args.radius}-long'
p.ROOT.mkdir(exist_ok=True)
p.RADIUS = args.radius
p.TARGET_DB = -1.35
p.TARGET = 10 ** (p.TARGET_DB / 20)
p.LEFT_HALO = p.PASSES * (2 * p.RADIUS + p.Q // p.RELEASE)
p.RIGHT_HALO = p.PASSES * (2 * p.RADIUS + p.Q // p.ATTACK)
p.BANK = p.detector_bank()
TILE = 8192
FFT_LENGTH = fft.next_fast_len(TILE + 2 * p.RADIUS)
SINC_ROWS = [(name, row) for name, row in p.BANK if name.startswith('sinc')]
KERNELS = np.array([fft.rfft(row[::-1], n=FFT_LENGTH) for _, row in SINC_ROWS])


def tiled_peaks(pcm, origin=0):
    first, last = origin - p.RADIUS, origin + len(pcm) + p.RADIUS
    peaks = np.zeros(last - first)
    rows = {name: 0.0 for name, _ in p.BANK}
    samples64 = pcm.astype(np.float64)
    # Tiles are locked to an immutable absolute integer sample origin.
    # Valid convolution samples cannot wrap into this range.
    for tile_first in range((first // TILE) * TILE, last, TILE):
        input_first, input_last = tile_first - p.RADIUS, tile_first + TILE + p.RADIUS
        signal = np.zeros((2, TILE + 2 * p.RADIUS))
        copy_first, copy_last = max(input_first, origin), min(input_last, origin + len(pcm))
        if copy_first < copy_last:
            signal[:, copy_first-input_first:copy_last-input_first] = samples64[copy_first-origin:copy_last-origin].T
        transformed = fft.rfft(signal, n=FFT_LENGTH, axis=-1)
        low, high = max(first, tile_first), min(last, tile_first + TILE)
        tile_slice = slice(low - tile_first, high - tile_first)
        output_slice = slice(low - first, high - first)
        for index, (name, _) in enumerate(SINC_ROWS):
            convolved = fft.irfft(transformed * KERNELS[index], n=FFT_LENGTH, axis=-1)
            values = convolved[:, 2*p.RADIUS:2*p.RADIUS+TILE][:, tile_slice]
            linked = np.max(abs(values), axis=0)
            rows[name] = max(rows[name], float(linked.max(initial=0)))
            np.maximum(peaks[output_slice], linked, out=peaks[output_slice])
    padded = np.pad(samples64, ((p.RADIUS, p.RADIUS), (0, 0)))
    np.maximum(peaks, np.max(abs(padded), axis=1), out=peaks)
    for name, row in p.BANK:
        if not name.startswith('bs'):
            continue
        values = ndimage.correlate1d(padded, row, axis=0, mode='constant', cval=0)
        linked = np.max(abs(values), axis=1)
        rows[name] = float(linked.max())
        np.maximum(peaks, linked, out=peaks)
    return peaks, rows


def limit(source, history=False, origin=0):
    source = np.asarray(source, dtype=np.float32)
    assert source.ndim == 2 and source.shape[1] == 2 and len(source) < 1_000_000
    assert np.isfinite(source).all() and np.max(abs(source)) <= 16
    source64 = source.astype(np.float64)
    gain = np.ones(len(source))
    pcm = source.copy()
    trace = []
    for iteration in range(p.PASSES):
        peaks, rows = tiled_peaks(pcm, origin)
        correction = np.minimum(1, np.divide(p.TARGET, peaks, out=np.ones_like(peaks), where=peaks != 0))
        correction = ndimage.minimum_filter1d(correction, 2*p.RADIUS+1, mode='constant', cval=1)[p.RADIUS:-p.RADIUS]
        gain *= p.envelope(correction)
        pcm = (source64 * gain[:, None]).astype(np.float32)
        if history:
            trace.append({'pass': iteration+1, 'detected_before_peak': float(peaks.max()),
                          'gain_min': float(gain.min()), 'gain_max': float(gain.max()), 'rows_before': rows})
    return pcm, gain, trace


def seek_test():
    length = 262144
    rng = np.random.default_rng(20260924)
    n = np.arange(length)
    mono = rng.uniform(-1,1,length)*0.15 + 2*np.sin(2*np.pi*23990*n/48000)
    mono[35000:41000:2] = 0
    source = np.column_stack((mono,-0.7*mono)).astype(np.float32)
    began = time.perf_counter()
    full, gains, _ = limit(source)
    full_seconds = time.perf_counter()-began
    records = []
    for start,count in [(145001,257),(0,1),(261887,257),(130001,8192),(147456,1)]:
        first,last=max(0,start-p.LEFT_HALO),min(length,start+count+p.RIGHT_HALO)
        # FFT error depends on all values in a fixed tile even where exact
        # FIR support would not. Include the full boundary tiles as a finite
        # numerical dependency; every pass's outer dependency expands TILE.
        first=max(0,first-p.PASSES*TILE)
        last=min(length,last+p.PASSES*TILE)
        began=time.perf_counter()
        actual,gain,_=limit(source[first:last],origin=first)
        offset=start-first
        records.append({'start':start,'count':count,'read_first':first,'read_last':last,
                        'seconds':time.perf_counter()-began,
                        'f32_bits_equal':bool(np.array_equal(actual[offset:offset+count].view(np.uint32),full[start:start+count].view(np.uint32))),
                        'gain_equal':bool(np.array_equal(gain[offset:offset+count],gains[start:start+count]))})
    report={'frames':length,'left_exact_fir_halo':p.LEFT_HALO,'right_exact_fir_halo':p.RIGHT_HALO,
            'extra_fft_tile_halo_each_side':p.PASSES*TILE,'tile_frames':TILE,'fft_length':FFT_LENGTH,
            'full_seconds':full_seconds,'queries':records,
            'all_equal':all(r['f32_bits_equal'] and r['gain_equal'] for r in records)}
    p.write_json(p.ROOT/'seek.json',report)
    print(json.dumps({'seek_equal':report['all_equal'],'full_seconds':full_seconds}),flush=True)


def check_detector():
    rng=np.random.default_rng(942781)
    source=rng.uniform(-1,1,(257,2)).astype(np.float32)
    origin=8191
    peaks,rows=tiled_peaks(source,origin)
    worst=0.0
    direct_max_error=0.0
    # Independent direct finite dot at signed boundaries and fractional phase
    # positions, instead of a second FFT implementation.
    for k in [-p.RADIUS,-2,0,1,128,256,257,p.RADIUS+256]:
        for phase in [1,5,8,15]:
            offsets=np.arange(len(source))-k
            active=abs(offsets)<=p.RADIUS
            weights=np.sinc(phase/p.PHASES-offsets[active])
            direct=max(abs(math.fsum(source[active,ch].astype(float)*weights)) for ch in range(2))
            assert direct<=peaks[k+p.RADIUS]+1e-12
            absolute=origin+k
            tile_first=(absolute//TILE)*TILE
            input_first=tile_first-p.RADIUS
            signal=np.zeros((2,TILE+2*p.RADIUS))
            lo,hi=max(input_first,origin),min(input_first+len(signal[0]),origin+len(source))
            if lo<hi:
                signal[:,lo-input_first:hi-input_first]=source[lo-origin:hi-origin].T
            convolved=fft.irfft(fft.rfft(signal,n=FFT_LENGTH,axis=-1)*KERNELS[phase-1],n=FFT_LENGTH,axis=-1)
            actual=float(np.max(abs(convolved[:,2*p.RADIUS+absolute-tile_first])))
            direct_max_error=max(direct_max_error,abs(actual-direct))
    assert direct_max_error<1e-12
    # Translation changes FFT partition but numerical agreement remains a
    # diagnostic. Deterministic seek test separately fixes absolute origin.
    translated,_=tiled_peaks(source,origin+137)
    worst=float(np.max(abs(translated-peaks)))
    p.write_json(p.ROOT/'detector-check.json',{'direct_selected_points_bounded':True,
                  'direct_vs_fft_selected_row_max_abs_error':direct_max_error,
                  'translated_partition_peak_max_abs_error':worst,'tile_frames':TILE,'fft_length':FFT_LENGTH})


p.limit=limit
p.finite_peaks=tiled_peaks
p.seek_test=seek_test
check_detector()
for directory in ('inputs','outputs','reports'):
    (p.ROOT/directory).mkdir(exist_ok=True)
oracle_path,oracle=p.v3.load_oracle()
metadata={'python':p.sys.version,'numpy':np.__version__,'scipy':p.scipy.__version__,
          'platform':p.platform.platform(),'script_sha256':p.v3.digest(Path(__file__)),
          'base_script_sha256':p.v3.digest(BASE/'experiment.py'),
          'oracle_sha256':p.v3.digest(oracle_path),
          'corpus_script_sha256':p.v3.digest(p.V3_PATH),
          'radius':p.RADIUS,'taps':2*p.RADIUS+1,'phases':p.PHASES,
          'bank':'15 truncated-sinc noninteger phases, four pinned BS1770 phases, sample floor; no window or conditioner',
          'fixed_passes':p.PASSES,'target_db':p.TARGET_DB,'ceiling_db':-1,
          'control_q':p.Q,'attack_per_pass_q':p.ATTACK,'release_per_pass_q':p.RELEASE,
          'tile_frames':TILE,'fft_length':FFT_LENGTH,
          'left_exact_fir_halo':p.LEFT_HALO,'right_exact_fir_halo':p.RIGHT_HALO,
          'extra_fft_tile_halo_each_side':p.PASSES*TILE,
          'claim':'experimental finite bank; final f32 diagnostic only; no universal DAC/production/real-time or listening qualification'}
p.write_json(p.ROOT/'environment.json',metadata)
results=[]
def long_cases():
    n=np.arange(65536)
    mono=np.where(n%2==0,16.0,0.0)
    yield 'long-rapid-mask-16',np.column_stack((mono,mono)), '65536-frame coherent rapidmask, larger than fixed detector support'
    mono=0.8*np.sin(2*np.pi*1000*(n+0.5)/48000)
    yield 'long-ordinary-tone-0.8',np.column_stack((mono,mono/4)), '65536-frame ordinary tone unity control'
for name,source,description in long_cases():
    if args.cases and name not in args.cases:
        continue
    try:
        results.append(p.run_case(name,source,description,oracle))
    except Exception as error:
        failure={'name':name,'passes_all':False,'error':repr(error)}
        p.write_json(p.ROOT/'reports'/f'{name}-failure.json',failure)
        results.append(failure)
        print(json.dumps(failure),flush=True)
    p.write_json(p.ROOT/'results.json',{'environment':metadata,'results':results})
if args.seek:
    seek_test()
if any(not r['passes_all'] for r in results):
    raise SystemExit(1)
