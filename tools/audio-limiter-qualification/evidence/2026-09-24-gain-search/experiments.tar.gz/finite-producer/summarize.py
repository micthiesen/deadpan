"""Regenerate the evidence table without rerunning or changing experiments."""
from pathlib import Path
import hashlib
import json
import statistics

ROOT=Path(__file__).resolve().parent
summaries=[]
for name,path in [('short513',ROOT),('wide8193',ROOT/'wide-r4096'),('wide16385',ROOT/'wide-r8192'),('wide16385-long',ROOT/'wide-r8192-long')]:
    report=json.loads((path/'results.json').read_text())
    results=report['results']
    summaries.append({'configuration':name,'cases':len(results),'passes_all':sum(r['passes_all'] for r in results),
        'failures':[{'name':r['name'],'sinc_upper_db':r.get('sinc_upper_db')} for r in results if not r['passes_all']],
        'producer_seconds_min':min(r['producer_seconds'] for r in results),
        'producer_seconds_median':statistics.median(r['producer_seconds'] for r in results),
        'producer_seconds_max':max(r['producer_seconds'] for r in results),
        'all_exact_zeros':all(r['exact_zero_preserved'] and r['zero_bits_preserved'] for r in results),
        'all_length_preserved':all(r['frames']==(65536 if name.endswith('long') else 8192) for r in results)})
(ROOT/'summary.json').write_text(json.dumps(summaries,indent=2)+'\n')
manifest={str(path.relative_to(ROOT)):hashlib.sha256(path.read_bytes()).hexdigest()
          for path in sorted(ROOT.rglob('*')) if path.is_file() and path.name!='sha256.json' and '__pycache__' not in path.parts}
(ROOT/'sha256.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps(summaries,indent=2))
