# Finite-context limiter experiment, 2026-09-24

**Not adopted.** A fast finite-bank, four-pass shared-gain candidate preserves the
tested authored zeros and ordinary controls, but fails the retained complete-sinc
stress diagnostic when coherent input is longer than its detector support. Do not
promote its finite-meter pass or its 23/23 short-fixture pass to master qualification.
No production source or dependency changed.

## Reproduce

Run from the current Deadpan checkout. These developer-only scripts reuse the
unchanged `../producer-v3/experiment.py` corpus/format helpers, the repository's
pinned BS.1770 coefficient table, and the retained independent
`tools/audio-limiter-qualification/evidence/2026-09-22-postmask/audit/finite_sinc.py`.
Each run records their hashes. Python 3.12, NumPy 2.5.3, SciPy 1.18.0 are required.

```sh
uv run --python 3.12 --with numpy==2.5.3 --with scipy==1.18.0 /tmp/deadpan-limiter-20260924/finite-producer/experiment.py
uv run --python 3.12 --with numpy==2.5.3 --with scipy==1.18.0 /tmp/deadpan-limiter-20260924/finite-producer/wide.py
uv run --python 3.12 --with numpy==2.5.3 --with scipy==1.18.0 /tmp/deadpan-limiter-20260924/finite-producer/wide.py --radius 8192 --seek
uv run --python 3.12 --with numpy==2.5.3 --with scipy==1.18.0 /tmp/deadpan-limiter-20260924/finite-producer/wide-long.py
uv run --python 3.12 --with numpy==2.5.3 --with scipy==1.18.0 /tmp/deadpan-limiter-20260924/finite-producer/summarize.py
```

Exit 1 is the expected retained qualification failure for the first, second, and
fourth runs. Per-case names may select a subset, but running one overwrites that
configuration's aggregate results file. The original full evidence is present now.
`summary.json` summarizes full runs; `sha256.json` inventories retained files.
`sealed.json` verifies script, corpus, oracle, input and output identities against
revision `034a35308e6652ab548c10a8999afd6f16f28d98`; `dependencies/` retains copies
of the reused source files and the exact BS coefficient table.
Each configuration owns inputs, final float32 WAV outputs, float64 shared gain,
per-pass detector observations, final per-channel oracle reports, and environment.

## Candidate and bounds

No conditioner, clipping, additive signal, automatic creative fade, source
normalization, or gain above one is used. The input already includes authored
mask/fades and is converted to float32 first. One gain is shared by stereo.
After every pass, output is reconstructed as `f32(original_f32 * cumulative_gain)`.
The next pass measures those actual float32 values. Every pass executes even if
the previous finite scan passed; the budget is exactly four, never convergence.

The detector bank combines sample magnitude, the four pinned BS.1770 phases, and
15 noninteger truncated-sinc rows at phases 1/16 through 15/16. A sinc row contains
`sinc(phase - d)` for integer `d` in `[-R,R]`, without a window or DC normalization.
This is an explicitly chosen experimental finite approximation, not an ITU filter
specification or a qualified reconstruction model. The internal target is a
measured guard parameter, not a numerical certificate.

For every oversampled row, form `min(1,target/linked_peak)`, then take the minimum
over all rows touching a sample, conservatively dilated by R. Smooth that correction
using exact integer caps Q=2^32, backward attack slope A=2^20 and forward release
slope D=2^19 per sample. Multiply it into the cumulative gain. Four passes can
compound the final gain slope; the per-pass slope is not a final attack/release
specification. Lowering individual gains is **not** assumed to monotonically lower
signed reconstructed peaks. The final scans can and do fail.

The recurrence `F[n]=min(C[n],F[n+1]+A)` then
`G[n]=min(F[n],G[n-1]+D)` has exact finite cap influence of 4096 future and 8192
past samples because caps lie in `[0,Q]`. This is a derivation from the integer
recurrence, not an empirical or standards claim. Including finite detection and
dilation, a four-pass mathematical FIR read requires left halo
`4*(2R+8192)` and right halo `4*(2R+4096)`.

The wide implementation uses fixed **absolute** 8192-frame overlap-save tiles,
not FFT sizes or phases chosen from request length. For R4096 the FFT length is
16384; for R8192 it is 24576. Each phase is evaluated separately to bound scratch
memory. FFT roundoff can depend on all samples in a tile even when their exact
FIR coefficients do not contribute, so the tested reproducible numerical halo
adds four complete tiles, 32768 samples, to **each** side. This is deliberately
conservative. The long-run direct check compares 32 selected signed-boundary and
fractional-phase rows with compensated direct sums; see `detector-check.json`.

Inputs are restricted to fewer than one million frames, stereo finite samples
with magnitude at most 16. The finite bank has fixed taps/phases/iterations;
working arrays scale with that explicit input bound. The complete-sinc audit is
separate whole-fixture diagnostic work and has much larger memory/cost. This
prototype has no production cancellation/deadline/source-cache implementation.

## Measured outcomes

Host: Apple M5 Max, 18 logical CPUs, 128 GiB RAM. Exact OS/Python/library versions
are in each `environment.json`. Some runs overlapped other numerical work, so
these are observed wall times, not isolated CPU benchmarks. Producer timing
excludes the final independent audit. Short clips contain 8192 stereo frames at
48 kHz, or 0.170667 seconds.

| Configuration | Internal target | Pass all scans | Producer median, range |
|---|---:|---:|---:|
| R256, 513 taps, direct FIR | −2 dB | 16/23 | 1.315 s, 1.201–1.479 s |
| R4096, 8193 taps, fixed FFT tiles | −1.35 dB | 17/23 | 0.107 s, 0.096–0.110 s |
| R8192, 16385 taps, fixed FFT tiles | −1.35 dB | 23/23 | 0.167 s, 0.100–0.173 s |
| R8192, two 65536-frame clips | −1.35 dB | 1/2 | 0.550 s, 0.549–0.551 s |

Representative complete finite zero-extended sinc numerical upper results:

| Input | R256 | R4096 | R8192 |
|---|---:|---:|---:|
| Raw rapid mask 0.8 | +1.187504 dB | −0.871782 dB | −1.319826 dB |
| Raw rapid mask 16 | +1.595215 dB | −0.871782 dB | −1.319826 dB |
| Alternating 16 | +4.090557 dB | −0.796931 dB | −1.345749 dB |
| Hot 23,990 Hz | +1.236104 dB | −1.189564 dB | −1.339547 dB |
| Exact retained prior failure 0.8 | +1.365607 dB | −0.776635 dB | −1.334403 dB |
| Exact retained prior failure 16 | +1.578559 dB | −0.760878 dB | −1.342614 dB |

Every final finite-bank scan and BS scan passed −1 dB in these runs. That did not
predict the complete-sinc results. On **65536 frames** of raw rapid-mask 16, the
R8192 final finite bank and BS scan reported −1.350000 dB, but the independent
complete-sinc numerical upper was **+0.987005 dB**. This is the decisive surviving
counterexample. A direct refined witness has amplitude 1.1198203898373151, so this
is not merely a loose upper bound. Its gain varies over the longer input; a bounded support did not
eliminate the long coherent reconstruction contribution.

All runs preserved exact output length and every numeric zero, including zero
sign bits. All 4096 short rapid-mask silent frames survive. Wide configurations
preserve quiet 0.1 tone/DC, ordinary 0.5 and 0.8 tones, ordinary 0.5 DC, both tiny Hard
fragments, and the permitted-tail fixture byte-for-byte. The first −2 dB candidate
attenuated the ordinary 0.8 tone and is rejected on that control as well. Finite
ordinary 0.8 DC was attenuated; its endpoint reconstruction is not assumed safe
merely because its sample level is below −1 dBFS. The 65536-frame ordinary 0.8 tone
is byte-identical, with complete-sinc upper −1.578384 dB.

The R8192 support/dilation covers the entire 8192-frame corpus. Its reduced short
fixtures therefore have **constant whole-fixture gain**, not demonstrated good
local limiting behavior. The 23/23 result does not justify imposing global
attenuation on a program. No listening or perceptual dynamics claim is made.

## Seeking and adoption boundary

The R8192 seek test processes 262144 deterministic stereo frames, including a hot
near-Nyquist signal, nonperiodic noise, and exact-zero islands. Five shuffled
requests, including 1, 257, and 8192 frames, match the full render's float32 bits and
float64 gain exactly. The full run took 1.859 s for 5.461 s of audio. A cold 257-frame
query read 246017 context frames and took 1.763 s. Across queries: 0.925–1.763 s.

The tested left/right numerical halos are 131072 and 114688 samples, or 2.731 and
2.389 seconds. This demonstrates a bounded reproducible computation, but not
responsive cold seeking. It omits source decoding, Preserve preparation, actual
device scheduling, checkpoint memory, and any native optimization. Reducing the
halo, filtering a query with fresh edge zeros, or changing FFT partitions would
need a new equality analysis. No boundary reset at a Hold, Repeat, split, or seek
is permissible merely to make it faster.

Do not adopt this candidate. It supplies runnable failed finite-detector evidence
and a fixed-context performance/seek experiment. It has not resolved the detector
choice and does not replace the previous global LP's result. Further work needs
an explicit practical detector contract and independent qualification, not another
claim that a local gain reduction or a finite-meter pass proves arbitrary signed
reconstruction safety.

The [ITU-R BS.1770-5 Annex 2](https://www.itu.int/dms_pubrec/itu-r/rec/bs/R-REC-BS.1770-5-202311-I!!PDF-E.pdf)
defines a finite true-peak estimation algorithm. The retained complete-sinc stress
oracle is a separate broader finite-signal diagnostic. Its floating-point grid,
direct refinement, curvature allowance, and numerical guard are retained evidence,
not a universal DAC model or formal interval-arithmetic certificate. This report
does not conflate those claims.

## Practical production judgment

The normative requirement is a tested oversampled −1 dBTP limiter. It does not
require bounding every infinite-band ideal reconstruction or every DAC. The
complete-sinc diagnostic should remain in the permanent stress evidence, with
its exact measured failures, rather than becoming an unbounded production solve
or a new universal release requirement by implication.

Define a finite production contract before choosing the next implementation:

1. Independently measured final-float32 BS.1770-5 true peak at or below −1 dBTP,
   checked with the relevant EBU qualification signals and a separately implemented
   meter. Declare the detector filter, phases, numerical/output-rounding guard,
   latency, history, tail, and version. Do not claim that simply increasing an
   oversampling factor guarantees safety.
2. Additional finite reconstruction checks must name their bandwidth/filter and
   phases. Select these from admitted preview/export conversion paths and a
   justified quality margin. Retain the complete-sinc results alongside them,
   clearly labeled as a stronger different reconstruction model.
3. A known complete-sinc failure blocks adoption if it also violates a declared
   supported finite path, the encoded/decode verification contract, or required
   quality/dynamics tests. Otherwise it remains a documented estimator limitation,
   not hidden evidence and not a universal-DAC claim. This interpretation should
   be explicit in the qualification decision.
4. Final output validation must use the final gain-modulated float32 samples plus
   their full finite output halo, including adjacent output blocks and authored
   masks. A bounded candidate may fail with an explicit safety-validation error
   after fixed work. It cannot silently release an unverified block, reset at a
   block seam, or expand into the global cutting-plane LP. Validate before device
   submission or export publication.
5. Meter compliance alone does not satisfy dynamics or interactivity. Test ordinary
   below-ceiling content for unity, absence of per-word leveling, stereo linkage,
   attack/release behavior, tiny Hard fragments, permitted tails, and silent policy.
   Listening and cold/steady timing measurements still matter.

This does **not** recommend shipping the R8192 experiment under a narrower label.
Its cold seeking, whole-short-fixture attenuation, and unqualified local dynamics
remain concrete gaps. It recommends a bounded, independently testable production
contract that recognizes the finite standard instead of promising a theorem the
specification does not ask for. The current experiment and prior LP are evidence
for that next decision, not production APIs.
