"""Verify run identities and retain source dependencies without changing them."""
from pathlib import Path
import ast
import hashlib
import json
import shutil
import subprocess

ROOT=Path(__file__).resolve().parent
REPO=Path('/Users/michael/Code/deadpan')
DEST=ROOT/'dependencies'
DEST.mkdir(exist_ok=True)
def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()
paths={
    'v3-experiment.py':ROOT.parent/'producer-v3'/'experiment.py',
    'finite_sinc.py':REPO/'tools/audio-limiter-qualification/evidence/2026-09-22-postmask/audit/finite_sinc.py',
    'true_peak.rs':REPO/'crates/deadpan-audio/src/true_peak.rs',
}
for name,path in paths.items():
    shutil.copyfile(path,DEST/name)
table=ast.literal_eval(paths['true_peak.rs'].read_text().split('const FIR: [[f64; 4]; 12] = ',1)[1].split(';',1)[0])
(DEST/'bs1770-table.json').write_text(json.dumps(table,indent=2)+'\n')
checks=[]
for path,script in [(ROOT,ROOT/'experiment.py'),(ROOT/'wide-r4096',ROOT/'wide.py'),(ROOT/'wide-r8192',ROOT/'wide.py'),(ROOT/'wide-r8192-long',ROOT/'wide-long.py')]:
    env=json.loads((path/'environment.json').read_text())
    assert env['script_sha256']==sha(script)
    assert env['corpus_script_sha256']==sha(paths['v3-experiment.py'])
    assert env['oracle_sha256']==sha(paths['finite_sinc.py'])
    report=json.loads((path/'results.json').read_text())
    for row in report['results']:
        assert row['input_sha256']==sha(path/'inputs'/f"{row['name']}.wav")
        assert row['output_sha256']==sha(path/'outputs'/f"{row['name']}.wav")
    checks.append({'configuration':str(path.relative_to(ROOT)),'cases':len(report['results']),'identities_match':True})
report={'repository_revision':subprocess.check_output(['git','rev-parse','HEAD'],cwd=REPO,text=True).strip(),
        'dependencies':{name:sha(path) for name,path in paths.items()},'checks':checks,
        'scope':'read-only source provenance and source/output hash verification; no new numerical claim'}
(ROOT/'sealed.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
