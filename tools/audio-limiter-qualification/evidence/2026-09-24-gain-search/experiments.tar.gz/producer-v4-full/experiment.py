"""Finite-fixture master-gain experiment, not production DSP.

Optimize one shared stereo piecewise-linear gain after the final authored mask.
Gain/slope constraints participate in the solve. Full finite-sinc cutting planes
are global to this fixture; this does NOT prove local seek or realtime behavior.
The final f32 output is checked, never a pre-rounding/intermediate waveform.
"""
from pathlib import Path
import ast
import hashlib
import importlib.util
import json
import math
import platform
import struct
import sys
import time

import numpy as np
import scipy
from scipy import optimize, signal, sparse

ROOT = Path(__file__).resolve().parent
REPO = Path('/Users/michael/Code/deadpan')
N = 8192
TARGET = 10 ** (-1.35 / 20)
CEILING = 10 ** (-1 / 20)
KNOT_STEP = 64
ATTACK = 1 / 4096
RELEASE = 1 / 8192
MAX_ITERATIONS = 96
CASE_SECONDS = 180


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def write_json(path, value):
    path.write_text(json.dumps(value, indent=2, allow_nan=False) + '\n')


def wav(path, pcm):
    data = np.asarray(pcm, dtype='<f4').tobytes()
    path.write_bytes(struct.pack('<4sI4s4sIHHIIHH4sI', b'RIFF', 36 + len(data),
        b'WAVE', b'fmt ', 16, 3, 2, 48000, 384000, 8, 32, b'data', len(data)) + data)


def load_oracle():
    path = REPO / 'tools/audio-limiter-qualification/evidence/2026-09-22-postmask/audit/finite_sinc.py'
    spec = importlib.util.spec_from_file_location('retained_sinc_audit', path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return path, module


def bs_coefficients():
    path = REPO / 'crates/deadpan-audio/src/true_peak.rs'
    text = path.read_text().split('const FIR: [[f64; 4]; 12] = ', 1)[1].split(';', 1)[0]
    result = np.asarray(ast.literal_eval(text), dtype=np.float64)
    assert result.shape == (12, 4)
    return result


def cases():
    n = np.arange(N)
    for level in [0.1, 0.8, 16.0]:
        mono = np.where(n % 2 == 0, level, 0.0)
        yield f'rapid-mask-{level}', np.column_stack((mono, mono)), 'raw every-other-frame exact silence; no conditioner/fade'
    for level in [0.1, 0.8, 16.0]:
        mono = np.where(n % 2 == 0, level, -level)
        yield f'alternating-{level}', np.column_stack((mono, -mono)), 'unmasked Nyquist sequence; shared opposed stereo gain'
    quiet = 0.1 * np.sin(2 * np.pi * 1000 * (n + 0.5) / 48000)
    yield 'quiet-tone', np.column_stack((quiet, quiet / 4)), 'unchanged quiet control'
    yield 'quiet-dc', np.full((N, 2), 0.1), 'unchanged quiet control'
    near = 16 * np.sin(2 * np.pi * 23990 * (n + 0.5) / 48000)
    yield 'near-nyquist', np.column_stack((near, -near)), 'hot near-Nyquist signal'
    gap = 0.8 * np.sin(2 * np.pi * 997 * (n + 0.5) / 48000)
    gap[3072:3584] = 0
    yield 'hard-silent-gap', np.column_stack((gap, -0.75 * gap)), 'exact silent interval; Hard edges retained'
    tail = 0.5 * np.sin(2 * np.pi * 997 * (n + 0.5) / 48000)
    tail[3072:] *= np.exp(-(n[3072:] - 3072) / 700)
    yield 'permitted-tail', np.column_stack((tail, tail / 2)), 'tail remains nonzero through nominal gap'
    impulses = np.zeros((N, 2))
    impulses[4096] = [16, -16]
    impulses[4097] = [-16, 16]
    yield 'opposed-impulses', impulses, 'two Hard samples, no automatic master fade'
    for width in [1, 2]:
        tiny = np.zeros((N, 2))
        tiny[100:100+width] = [0.5, -0.25]
        yield f'quiet-{width}-sample-fragment', tiny, 'tiny below-ceiling Hard fragment must remain byte-identical'
    previous = REPO / 'tools/audio-limiter-qualification/evidence/2026-09-22-postmask/producer/outputs'
    for level in ['0.8', '16']:
        path = previous / f'mask-alternating-dc-{level}-hard.wav'
        pcm = np.frombuffer(path.read_bytes(), dtype='<f4', offset=44).reshape(-1, 2).copy()
        yield f'retained-failure-{level}', pcm, f'exact retained prior failing output used as new input; sha256={digest(path)}'


def interpolation():
    knots = np.unique(np.append(np.arange(0, N, KNOT_STEP), N - 1))
    left = np.minimum(np.searchsorted(knots, np.arange(N), side='right') - 1, len(knots) - 2)
    fraction = (np.arange(N) - knots[left]) / (knots[left + 1] - knots[left])
    rows = np.repeat(np.arange(N), 2)
    cols = np.column_stack((left, left + 1)).ravel()
    vals = np.column_stack((1 - fraction, fraction)).ravel()
    return knots, sparse.csr_matrix((vals, (rows, cols)), shape=(N, len(knots)))


def diverse_cuts(rows, limit):
    """Keep worst violations across all gain cells before clustered phases."""
    ordered = sorted(rows, reverse=True)
    cells = {}
    for row in ordered:
        cells.setdefault((row[2], math.floor(row[3] / KNOT_STEP)), row)
    selected = sorted(cells.values(), reverse=True)[:limit]
    seen = {row[1:] for row in selected}
    for row in ordered:
        if len(selected) >= limit:
            break
        if row[1:] not in seen:
            selected.append(row)
            seen.add(row[1:])
    return selected


def sinc_scan(pcm, phases=32):
    """All N terms by linear convolution; every requested lag is retained."""
    first, last = -N, 2 * N
    offsets = np.arange(first - N + 1, last + 1)
    indices = np.arange(N - 1, N - 1 + last - first + 1)
    result = []
    maximum = 0.0
    for channel in range(2):
        for p in range(1, phases):
            phase = p / phases
            kernel = np.where(offsets % 2 == 0, 1.0, -1.0) * math.sin(math.pi * phase) / (math.pi * (offsets + phase))
            values = signal.fftconvolve(pcm[:, channel], kernel, mode='full')[indices]
            mags = np.abs(values)
            maximum = max(maximum, float(np.max(mags)))
            # One-dimensional local maxima in each fractional-phase row.
            local = np.flatnonzero((mags >= TARGET * (1 + 1e-8)) & (mags >= np.roll(mags, 1)) & (mags >= np.roll(mags, -1)))
            result.extend((float(mags[k]), 'sinc', channel, first + int(k) + phase, 0) for k in local)
    return maximum, diverse_cuts(result, 1024)


def bs_scan(pcm, fir):
    result = []
    maximum = float(np.max(np.abs(pcm)))
    for channel in range(2):
        for phase in range(4):
            values = np.convolve(pcm[:, channel], fir[:, phase], mode='full')
            maximum = max(maximum, float(np.max(np.abs(values))))
            bad = np.flatnonzero(np.abs(values) > TARGET * (1 + 1e-8))
            result.extend((float(abs(values[k])), 'bs', channel, int(k), phase) for k in bad)
    return maximum, diverse_cuts(result, 512)


def experiment(name, source, description, fir, oracle):
    started = time.monotonic()
    source = np.asarray(source, dtype=np.float32).astype(np.float64)
    assert source.shape == (N, 2) and np.isfinite(source).all() and np.max(abs(source)) <= 16
    wav(ROOT / 'inputs' / f'{name}.wav', source)
    knots, basis = interpolation()
    count = len(knots)
    slope = sparse.diags([-np.ones(count - 1), np.ones(count - 1)], [0, 1], shape=(count - 1, count), format='csr')
    # Per-sample caps remain constraints in knot space.
    matrix = sparse.vstack([basis.multiply(np.max(abs(source), axis=1)[:, None]), slope, -slope], format='csr')
    bound = np.concatenate([np.full(N, TARGET), np.diff(knots) * RELEASE, np.diff(knots) * ATTACK])
    objective = -np.asarray(basis.sum(axis=0)).ravel()
    seen = set()
    history = []
    for iteration in range(MAX_ITERATIONS):
        remaining = CASE_SECONDS - (time.monotonic() - started)
        if remaining <= 0:
            raise RuntimeError(f'{name}: whole-case cooperative deadline exceeded')
        solved = optimize.linprog(objective, A_ub=matrix, b_ub=bound, bounds=(0, 1), method='highs', options={'time_limit': remaining, 'primal_feasibility_tolerance': 1e-9, 'dual_feasibility_tolerance': 1e-9})
        if not solved.success:
            raise RuntimeError(f'{name}: {solved.message}')
        gain = np.asarray(basis @ solved.x)
        pcm = (source * gain[:, None]).astype(np.float32).astype(np.float64)
        sinc_max, sinc_rows = sinc_scan(pcm)
        bs_max, bs_rows = bs_scan(pcm, fir)
        curvature = oracle.curvature_bound(N, float(np.max(abs(pcm))))
        numeric_guard = 1e-10 * max(1.0, float(np.sum(abs(pcm))))
        coarse_upper = max(sinc_max + curvature / (8 * 32**2), float(np.max(np.sum(abs(pcm), axis=0))) / (math.pi * N)) + numeric_guard
        history.append({'iteration': iteration, 'sinc_grid_peak': sinc_max, 'coarse_numerical_upper': coarse_upper, 'bs_peak': bs_max, 'constraint_rows': matrix.shape[0]})
        write_json(ROOT / 'reports' / f'{name}-iterations.json', history)
        # Separation optimizes toward a lower internal target, but acceptance
        # tests the actual product ceiling with the complete coarse-grid bound.
        # Final f32 still receives the independent retained128-phase scan below.
        if coarse_upper < CEILING and bs_max < CEILING:
            break
        candidates = sinc_rows + bs_rows
        if not candidates:
            break
        rows = []
        for _, kind, channel, t, phase in candidates:
            key = (kind, channel, t, phase)
            if key in seen:
                continue
            seen.add(key)
            if kind == 'sinc':
                weights = np.sinc(t - np.arange(N))
            else:
                weights = np.zeros(N)
                for k in range(12):
                    at = t - k
                    if 0 <= at < N:
                        weights[at] = fir[k, phase]
            row = np.asarray(basis.T @ (weights * source[:, channel])).ravel()
            rows.extend([row, -row])
        if not rows:
            raise RuntimeError(f'{name}: repeated violating cuts after final f32 conversion')
        matrix = sparse.vstack([matrix, sparse.csr_matrix(np.array(rows))], format='csr')
        bound = np.concatenate([bound, np.full(len(rows), TARGET - 1e-7)])
    else:
        raise RuntimeError(f'{name}: iteration budget exceeded')
    output_path = ROOT / 'outputs' / f'{name}.wav'
    wav(output_path, pcm)
    (ROOT / 'outputs' / f'{name}.f32le').write_bytes(pcm.astype('<f4').tobytes())
    reports = []
    for ch in range(2):
        if time.monotonic() - started >= CASE_SECONDS:
            raise RuntimeError(f'{name}: whole-case cooperative deadline exceeded before final audit')
        reports.append(oracle.audit_channel(pcm[:, ch], 128, N, 8))
    zero_preserved = bool(np.all(pcm[source == 0] == 0))
    assert zero_preserved
    upper = max(report['qualified_numerical_global_upper'] for report in reports)
    result = {'name': name, 'description': description, 'input_sha256': digest(ROOT / 'inputs' / f'{name}.wav'), 'output_sha256': digest(output_path), 'input_peak': float(np.max(abs(source))), 'sample_peak': float(np.max(abs(pcm))), 'gain_min': float(np.min(gain)), 'gain_max': float(np.max(gain)), 'gain_knots': solved.x.tolist(), 'gain_all_unity': bool(np.all(gain == 1)), 'input_output_identical': bool(np.array_equal(source.astype(np.float32), pcm.astype(np.float32))), 'numeric_zero_preserved': zero_preserved, 'nonzero_input_frames': int(np.count_nonzero(np.any(source != 0, axis=1))), 'nonzero_output_frames': int(np.count_nonzero(np.any(pcm != 0, axis=1))), 'bs_peak': bs_max, 'sinc_upper': upper, 'passes_both': bool(bs_max <= CEILING and upper <= CEILING), 'oracle': reports, 'iterations': history, 'seconds': time.monotonic() - started}
    write_json(ROOT / 'reports' / f'{name}.json', result)
    print(json.dumps({k:result[k] for k in ['name', 'passes_both', 'gain_min', 'input_output_identical', 'seconds']}), flush=True)
    return result


def main():
    for path in ['inputs', 'outputs', 'reports']:
        (ROOT / path).mkdir(exist_ok=True)
    oracle_path, oracle = load_oracle()
    metadata = {'python': sys.version, 'platform': platform.platform(), 'numpy': np.__version__, 'scipy': scipy.__version__, 'script_sha256': digest(Path(__file__)), 'oracle_sha256': digest(oracle_path), 'target_db': -1.35, 'frames': N, 'knots_step': KNOT_STEP, 'attack': ATTACK, 'release': RELEASE, 'maximum_iterations': MAX_ITERATIONS, 'case_cooperative_deadline_seconds': CASE_SECONDS, 'scope': 'global finite-fixture optimization; no preemptive wall-time, realtime, local-seek, production or formal interval-certificate claim'}
    write_json(ROOT / 'environment.json', metadata)
    wanted = set(sys.argv[1:])
    results = []
    for name, source, description in cases():
        if wanted and name not in wanted:
            continue
        try:
            results.append(experiment(name, source, description, bs_coefficients(), oracle))
        except Exception as error:
            failure = {'name': name, 'passes_both': False, 'error': str(error)}
            write_json(ROOT / 'reports' / f'{name}-failure.json', failure)
            print(json.dumps(failure), flush=True)
            results.append(failure)
        write_json(ROOT / 'results.json', {'environment': metadata, 'results': results})
    if any(not row['passes_both'] for row in results):
        raise SystemExit(1)


if __name__ == '__main__':
    main()
