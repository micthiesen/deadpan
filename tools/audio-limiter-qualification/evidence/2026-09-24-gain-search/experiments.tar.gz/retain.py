"""Seal completed research files without re-running producers or changing PCM."""
from pathlib import Path
import gzip
import hashlib
import io
import json
import subprocess
import tarfile

ROOT = Path(__file__).resolve().parent
REPO = Path('/Users/michael/Code/deadpan')
DESTINATION = REPO / 'tools/audio-limiter-qualification/evidence/2026-09-24-gain-search'
RUNS = ['producer', 'producer-v2', 'producer-v3', 'producer-v4',
        'producer-v4-full', 'producer-v5', 'producer-v5-full',
        'native-meter-v3', 'native-meter-v5', 'finite-producer', 'finite-review', 'gate']


def sha(data):
    return hashlib.sha256(data).hexdigest()


def main():
    DESTINATION.mkdir(exist_ok=True)
    files = {}

    def add(path, relative=None, required=False):
        if required:
            assert path.is_file() and not path.is_symlink(), path
        if '__pycache__' in path.parts or path.suffix in ['.f32le', '.log']:
            return
        if not path.is_file() or path.is_symlink():
            return
        relative = str(relative or path.relative_to(ROOT))
        assert relative not in files
        data = path.read_bytes()
        files[relative] = (path, data)

    for run in RUNS:
        assert (ROOT / run).is_dir(), run
        for path in sorted((ROOT / run).rglob('*')):
            add(path)
    # Preserve original reviewed scripts and final audit snapshots. Earlier
    # subset/repeated audits remain scratch-only; their scope is documented.
    audit_root = ROOT / 'design-audit'
    for path in sorted(audit_root.iterdir()):
        if path.is_file():
            add(path)
    selected = {'output-audit-1790241294821706000'}
    for name in ['v5-pilot-audit-run.json', 'v5-full-audit-run.json']:
        marker = json.loads((audit_root / name).read_text())
        selected.add(Path(marker['destination']).name)
    for name in sorted(selected):
        directory = audit_root / name
        assert directory.is_dir() and not directory.is_symlink(), directory
        for required in ['audit.json', 'auditor.py']:
            assert (directory / required).is_file(), directory / required
        audited = json.loads((directory / 'audit.json').read_text())
        for row in audited['cases']:
            for kind, suffix in [('inputs', 'wav'), ('outputs', 'wav'), ('reports', 'json')]:
                assert (directory / (row['name'] + '-' + kind + '.' + suffix)).is_file()
        for path in sorted(directory.rglob('*')):
            add(path)
    for name in ['measure_v5.py', 'retain.py', 'docs-review.json', 'gate.py', 'archive-review-resolutions.json']:
        add(ROOT / name, required=True)
    for path in [REPO / 'crates/deadpan-audio/src/true_peak.rs',
                 REPO / 'tools/audio-limiter-qualification/evidence/2026-09-22-postmask/audit/finite_sinc.py']:
        add(path, 'dependencies/' + path.name, required=True)
    manifest = {'repository_revision': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=REPO, text=True).strip(),
                'scope': 'Exact retained research bytes. No production limiter adoption or reproducible-build claim.',
                'omitted': ['raw f32 files duplicating WAV payloads', 'Python bytecode caches',
                            'earlier subset/repeated v3 audits', 'compiled meter executable'],
                'files': {name: {'source': str(path), 'sha256': sha(data), 'bytes': len(data)}
                          for name, (path, data) in sorted(files.items())}}
    archive_path = DESTINATION / 'experiments.tar.gz'
    # Exclusive publication avoids silently replacing any already sealed run.
    with archive_path.open('xb') as output:
        with gzip.GzipFile(fileobj=output, mode='wb', filename='', mtime=0) as compressed:
            with tarfile.open(fileobj=compressed, mode='w') as archive:
                for name, (path, data) in sorted(files.items()):
                    assert sha(path.read_bytes()) == sha(data), path
                    info = tarfile.TarInfo(name)
                    info.size = len(data)
                    info.mode = 0o644
                    archive.addfile(info, io.BytesIO(data))
    manifest['archive_sha256'] = sha(archive_path.read_bytes())
    with (DESTINATION / 'retention.json').open('x') as output:
        output.write(json.dumps(manifest, indent=2) + '\n')
    print(json.dumps({'files': len(files), 'uncompressed_bytes': sum(len(data) for _, data in files.values()),
                      'archive_bytes': archive_path.stat().st_size, 'archive_sha256': manifest['archive_sha256']}))


if __name__ == '__main__':
    main()
