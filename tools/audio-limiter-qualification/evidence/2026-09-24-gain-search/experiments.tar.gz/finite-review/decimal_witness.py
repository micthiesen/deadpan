import json, math, pathlib, struct, time
from decimal import Decimal, localcontext
root=pathlib.Path('/tmp/deadpan-limiter-20260924/finite-producer/wide-r8192-long')
report=json.loads((root/'reports/long-rapid-mask-16.json').read_text())
raw=(root/'outputs/long-rapid-mask-16.wav').read_bytes()
assert len(raw)==44+65536*2*4
interleaved=struct.unpack('<131072f',raw[44:44+65536*8])
samples=interleaved[::2]
assert all(a==b for a,b in zip(interleaved[::2],interleaved[1::2]))
t=Decimal(str(report['oracle'][0]['refined_coordinate']))
floor=int(t)
with localcontext() as ctx:
    ctx.prec=90
    pi=Decimal('3.1415926535897932384626433832795028841971693993751058209749445923078164062862089986280348253421170679')
    phase=t-Decimal(floor)
    x=pi*phase
    term=x; sine=x; k=1
    while abs(term)>Decimal('1e-92'):
        term=-term*x*x/Decimal((2*k)*(2*k+1))
        sine+=term
        k+=1
    total=Decimal(0)
    for i,s in enumerate(samples):
        total+=(Decimal.from_float(float(s))*(Decimal(1) if i%2==0 else Decimal(-1)))/(t-Decimal(i))
    value=(Decimal(-1) if floor%2 else Decimal(1))*sine/pi*total
    db=Decimal(20)*(abs(value).ln()/Decimal(10).ln())
    print('coordinate',t)
    print('high_precision_sinc_witness',value)
    print('high_precision_dbtp',db)
    print('series_terms',k)
