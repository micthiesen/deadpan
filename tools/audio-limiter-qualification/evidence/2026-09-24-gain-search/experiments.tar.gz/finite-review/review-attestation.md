# Independent review attestation: finite limiter experiment

Review scope: `/tmp/deadpan-limiter-20260924/finite-producer` and its retained producer scripts, README, outputs, reports, sealed source identities, plus the relevant current spec clauses. Read-only review; no repository files or experiment outputs were changed. Scratch additions in this review directory are `audit.py`, `decimal_witness.py`, and this attestation.

## Conclusion

Do not adopt the finite-bank candidate as the production limiter. The 65,536-frame final-f32 rapid-mask case passes both its finite detector bank and its BS.1770 scan at approximately -1.35 dBTP. It therefore is not evidence that this output fails the normative oversampled meter ceiling. It does fail the retained broader complete-sinc diagnostic, and remains a legitimate negative qualification result. The diagnostic must remain visible, but is not a universal DAC/reconstruction requirement. This prototype also lacks the separate EBU signal-set / independent-meter qualification, final group-mix integration, playback/export integration, and AAC verification needed for production adoption.

Spec references checked: `docs/spec/DEADPAN_SPEC.md:574-580` requires tested oversampled -1 dBTP limiting, preservation of authored level/dynamics, and no per-word normalization; `:582-586` covers shortened tiny-fragment fades and distinct silence/tail policies; `:883-887` requires declared state/history and matching random-access behavior; `:1160-1166` requires AAC decode/event-time and A/V verification. Section 22.6 does not state an additional -1 dBTP ceiling on AAC-decoded output.

## Provenance and artifact binding

The experiment environment records Python 3.12.13, NumPy 2.5.3, SciPy 1.18.0, macOS 26.5.2 arm64. Source hashes checked against their retained/current files:

- `finite-producer/experiment.py`: `dc46b4ecf72e53c7a6f02d0681a22527c62a982a5114be1a72cf9b484e38ff1b`
- `finite-producer/wide.py`: `49e355e24887986bb49495c7c6ff313b83af94ef2c5e9db216b5fa0ed75499bc`
- `finite-producer/wide-long.py`: `8f7b4060b183d4ada68b4e6e0787662063980646b0413374e9363d67fd2bf077`
- retained `producer-v3/experiment.py`: `2017061ccb2185b1a93bb4e200706b186e4b7666db54e8f8f16e856bf5197a3b`
- retained sinc audit `finite_sinc.py`: `d5e8166bdf9b2e71d6b7a9c4fa3e3cb5dcafdc304ebe93a563bae82d2ece209e`
- current `crates/deadpan-audio/src/true_peak.rs`: `6ced3d91cfe6cfe003eabb037a33e4d263ddf4206dfee50736c894fe97c464ae`
- retained coefficient table: `46a59aebd4e7ae7e3f7c5805b8f1abe715ead3034497285d1ea0a5c5526e3a91`

The `sha256.json` manifest has 308 entries, exactly matching its 308 eligible retained files; all 308 hashes verified with no missing or mismatched entries. `sealed.json` binds repository revision `034a35308e6652ab548c10a8999afd6f16f28d98` and reports identity checks for 23 cases in each short configuration and both long cases. Current copies of the three sealed source dependencies match the recorded and retained hashes.

For `wide-r8192-long/reports/long-rapid-mask-16.json`:

- input WAV SHA-256: `89e294f2a729ec65f845f3bc54c82039ce57f2fcbefa46d83db2c1a149f4dc1f`
- final-f32 output WAV SHA-256: `4430dc02e5fd6b7ecc9c08d11cf96793f2baadf9e476e2b634e4cb059261d969`
- saved shared-f64 gain SHA-256: `7e0833f5721056f9235660d0d5118e85bc9e45b4427c6a3222f84394715a8316`
- report SHA-256: `2a725da8678906d1267e802906056155f7ea3ff40424a8eef341093cf8638a9a`

Both channels are identical. Input, output, and gain all have 65,536 frames. Recomputing `f32(input_f32 * saved_gain_f64)` reproduces each output sample exactly. The output preserves all 32,768 zero frames and their f32 sign bits. Reported finite-bank and BS scans are -1.350000028 dBTP and -1.350000287 dBTP; complete-sinc numerical global upper is +0.987005199 dBTP.

## Independent failure witness

The retained oracle reports its refined peak at `t=65534.43516864303`, amplitude `1.1198203898373151`, or +0.982967418 dBTP. I independently evaluated the complete finite zero-extended sinc sum at that fixed coordinate using 90-digit Decimal arithmetic over the 65,536 retained final-f32 left-channel samples:

- amplitude: `1.11982038983731504538517103692128365829811298861034599240575694110946997449517141023766072`
- level: `+0.982967418442990871449574914730103962177966157429261118879554699516170724485366817254110916 dBTP`

This direct point is sufficient to establish a numerical exceedance of -1 dB under that reconstruction; the report's +0.987005 figure is its larger grid/interpolation/numerical upper, not the refined point itself. The report expressly says its floating-point upper is not a rigorous interval-arithmetic certificate.

## Direct detector and seek evidence

`wide-r8192-long/detector-check.json` reports 32 selected signed-boundary/fractional-phase direct checks, with direct-versus-FFT maximum absolute error `3.3306690738754696e-16`; translated partition peak difference is `6.661338147750939e-16`. The source script shows these selected checks use a deterministic 257-frame synthetic signal. They are a focused kernel check, not exhaustive direct verification of every detector output on the long rapid-mask input.

`wide-r8192/seek.json` reports five shuffled query matches against one full render, exact in both f32 output bits and f64 gain. The test is bounded but cold seeking is expensive: a 257-frame query reads 246,017 input/context frames and takes 1.763 seconds; the full 262,144-frame render takes 1.859 seconds. The README correctly disclaims source decoding, Preserve preparation, device scheduling, production cancellation/deadlines, and responsive cold seek.

## Commands and runtime record

No producer, wide, wide-long, long oracle sweep, or parameter sweep was rerun for this review. The retained exact command lines are documented in `finite-producer/README.md`; its source/output hashes and `sealed.json` were checked read-only.

Review commands that were run successfully:

- `python3 /tmp/deadpan-limiter-20260924/finite-review/audit.py` — approximately 0.6 s wall time reported by the tool; verifies manifest, selected source/output/report hashes, WAV/gain binding, shared stereo, exact zeros, independent float64-sum witness, detector-check summary, and seek summary.
- `python3 /tmp/deadpan-limiter-20260924/finite-review/decimal_witness.py` — approximately 0.6 s wall time reported by the tool; independently evaluates the fixed complete-sinc witness in 90-digit Decimal arithmetic.
- One short Python stdlib provenance check compared retained dependency copies and environment-recorded source hashes against current files; the script, corpus, oracle, and applicable base-script comparisons passed. The base environment has no `base_script_sha256` field.
- One short Python stdlib check compared all eligible files with `sha256.json`; result was 308/308 present and matching, with no missing or extra manifest entries.

Raw stdout/stderr was not redirected to retained log files. The values above are reviewer-attested from tool results and checked against the retained JSON/WAV artifacts; they are not presented as copied raw stdout. The local Python used for the two review helper scripts was Python 3.14.7 (visible in the failed optional `mpmath` import traceback); the Decimal witness uses only Python standard-library arithmetic. The producer-run Python/dependency versions are the recorded 3.12.13 / NumPy 2.5.3 / SciPy 1.18.0 values above.
