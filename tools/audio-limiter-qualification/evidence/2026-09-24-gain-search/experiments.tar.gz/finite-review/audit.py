import hashlib, json, math, pathlib, struct, sys
root=pathlib.Path('/tmp/deadpan-limiter-20260924/finite-producer')
manifest=json.loads((root/'sha256.json').read_text())
checked=missing=mismatched=0
for rel,digest in manifest.items():
    path=root/rel
    if not path.is_file(): missing+=1; continue
    checked+=1
    if hashlib.sha256(path.read_bytes()).hexdigest()!=digest: mismatched+=1
print('manifest entries',len(manifest),'checked',checked,'missing',missing,'mismatched',mismatched)
for path in ['experiment.py','wide.py','wide-long.py','wide-r8192-long/environment.json','wide-r8192-long/inputs/long-rapid-mask-16.wav','wide-r8192-long/outputs/long-rapid-mask-16.wav','wide-r8192-long/outputs/long-rapid-mask-16.gain.f64le','wide-r8192-long/reports/long-rapid-mask-16.json','wide-r8192/seek.json']:
 p=root/path
 print('sha',path,hashlib.sha256(p.read_bytes()).hexdigest())

def wav(path):
 b=path.read_bytes()
 fmt=struct.unpack('<4sI4s4sIHHIIHH4sI',b[:44])
 assert fmt[0:3]==(b'RIFF',len(b)-8,b'WAVE')
 assert fmt[5:11]==(3,2,48000,384000,8,32),fmt
 assert fmt[-2:]==(b'data',len(b)-44)
 flat=struct.unpack('<%df'%((len(b)-44)//4),b[44:])
 assert len(flat)%2==0
 return b,[flat[2*i:2*i+2] for i in range(len(flat)//2)]
base=root/'wide-r8192-long'
name='long-rapid-mask-16'
in_b,inp=wav(base/f'inputs/{name}.wav'); out_b,out=wav(base/f'outputs/{name}.wav')
gain_bytes=(base/f'outputs/{name}.gain.f64le').read_bytes()
gains=struct.unpack('<%dd'%(len(gain_bytes)//8),gain_bytes)
print('frames',len(inp),len(out),'gain frames',len(gains),'stereo_equal_input',all(a==b for a,b in inp),'stereo_equal_output',all(a==b for a,b in out))
print('zeros input/output',sum(a==0 and b==0 for a,b in inp),sum(a==0 and b==0 for a,b in out),'zero_sign_bits_equal',sum(struct.pack('<f',a)==struct.pack('<f',b) for (a,b),(x,y) in zip(inp,out) if a==0 and b==0 and x==0 and y==0))
recalc=all(struct.pack('<f',float(x)*g)==struct.pack('<f',y) and struct.pack('<f',float(z)*g)==struct.pack('<f',w) for (x,z),(y,w),g in zip(inp,out,gains))
print('output equals input times shared float64 gain then f32',recalc,'gain range',min(gains),max(gains),'gain vector shared stereo by construction')
report=json.loads((base/f'reports/{name}.json').read_text())
print('report input/output hash matches',hashlib.sha256(in_b).hexdigest()==report['input_sha256'],hashlib.sha256(out_b).hexdigest()==report['output_sha256'])
print('report frames/finite/BS/sinc upper/passes',report['frames'],report['finite_db'],report['bs_db'],report['sinc_upper_db'],report['passes_finite'],report['passes_bs'],report['passes_sinc_diagnostic'])
coord=report['oracle'][0]['refined_coordinate'];
samples=[a for a,b in out]
floor=math.floor(coord); phase=coord-floor
terms=(samples[i]* (1 if i%2==0 else -1) / (coord-i) for i in range(len(samples)))
value=((-1 if floor%2 else 1)*math.sin(math.pi*phase)/math.pi)*math.fsum(terms)
dbp=20*math.log10(abs(value))
print('independent fsum at retained refined coordinate',repr(value),repr(dbp),'report',report['oracle'][0]['refined_signed_value'],report['oracle'][0]['refined_dbtp'])
seek=json.loads((root/'wide-r8192/seek.json').read_text())
print('seek frames/hallos/all_equal',seek['frames'],seek['left_exact_fir_halo'],seek['right_exact_fir_halo'],seek['extra_fft_tile_halo_each_side'],seek['all_equal'],'queries',[(q['start'],q['count'],q['read_first'],q['read_last'],q['f32_bits_equal'],q['gain_equal']) for q in seek['queries']])
print('detector-check',json.loads((base/'detector-check.json').read_text()))
