"""Run the retained compiled meter on final v5 bytes; never regenerate PCM."""
from pathlib import Path
import hashlib
import json
import subprocess

ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / 'producer-v5-full'
DESTINATION = ROOT / 'native-meter-v5'
METER = Path('/Users/michael/Code/deadpan/target/release/examples/measure_pcm')


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    DESTINATION.mkdir(exist_ok=False)
    before = sha(METER)
    assert before == '97216bd091c1f54b769ccfa0c709590fd03ae7e095b94e7fd12a2dc3ba78eaae'
    records = []
    for row in json.loads((SOURCE / 'results.json').read_text())['results']:
        name = row['name']
        raw = SOURCE / 'outputs' / (name + '.f32le')
        wav = SOURCE / 'outputs' / (name + '.wav')
        assert raw.read_bytes() == wav.read_bytes()[44:]
        assert sha(wav) == row['output_sha256']
        raw_hash = sha(raw)
        output = DESTINATION / (name + '.json')
        command = [str(METER), str(raw), str(output)]
        # Invoke by executable name through its directory, retaining PATH shims.
        command[0] = 'measure_pcm'
        import os
        env = os.environ.copy()
        env['PATH'] = str(METER.parent) + os.pathsep + env['PATH']
        completed = subprocess.run(command, env=env, capture_output=True, text=True, check=True)
        report = json.loads(output.read_text())
        assert sha(raw) == raw_hash
        records.append({'name': name, 'raw_sha256': raw_hash, 'report_sha256': sha(output),
                        'command': command, 'stdout': completed.stdout, 'stderr': completed.stderr})
    assert sha(METER) == before
    summary = {'meter_sha256': before, 'script_sha256': sha(Path(__file__)),
               'scope': 'Same retained compiled meter used in prior qualification; not rebuilt for this run',
               'results': records}
    (DESTINATION / 'summary.json').write_text(json.dumps(summary, indent=2) + '\n')
    print(json.dumps({'cases': len(records), 'meter_sha256': before}))


if __name__ == '__main__':
    main()
