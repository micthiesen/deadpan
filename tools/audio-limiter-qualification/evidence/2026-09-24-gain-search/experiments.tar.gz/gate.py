"""Run the required repository gate, retaining complete command output."""
import gzip
import json
import os
from pathlib import Path
import subprocess
import time

ROOT = Path(__file__).resolve().parent
REPO = Path('/Users/michael/Code/deadpan')
DESTINATION = ROOT / 'gate'
COMMANDS = [
    ['cargo', 'fmt', '--all', '--', '--check'],
    ['cargo', 'clippy', '--workspace', '--all-targets', '--locked', '--', '-D', 'warnings'],
    ['cargo', 'test', '--workspace', '--locked'],
    ['cargo', 'build', '--workspace', '--locked'],
    ['cargo', 'run', '-p', 'deadpan-cli', '--', 'doctor'],
]


def main():
    DESTINATION.mkdir(exist_ok=False)
    env = os.environ.copy()
    env['DEADPAN_FFMPEG_PREFIX'] = '/tmp/deadpan-media-compatible-xyhilms4/prefix'
    results = []
    for index, command in enumerate(COMMANDS):
        started = time.monotonic()
        log = DESTINATION / f'{index}.log'
        with log.open('xb') as output:
            process = subprocess.run(command, cwd=REPO, env=env, stdout=output, stderr=subprocess.STDOUT)
        data = log.read_bytes()
        (DESTINATION / f'{index}.log.gz').write_bytes(gzip.compress(data, mtime=0))
        row = {'command': command, 'exit_code': process.returncode,
               'seconds': time.monotonic() - started, 'log': f'{index}.log.gz'}
        results.append(row)
        (DESTINATION / 'results.json').write_text(json.dumps(results, indent=2) + '\n')
        print(json.dumps(row), flush=True)
        if process.returncode:
            raise SystemExit(process.returncode)


if __name__ == '__main__':
    main()
