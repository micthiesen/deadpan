# Checked sound placement history, 2026-10-27

Audio's route builder and Plan's afterbirth validator previously repeated the
same Core placement projections. A sealed Plan cursor now owns the existing
scalar placement vector and issues finished evidence only after all clock
steps and the current allocation check. Route construction borrows its rows;
afterbirth consumes the proof and rechecks the complete journal, binding,
alias, original/current recipe and context, every route window/grid/count,
birth/disappearance and Split continuation.

An initial charged six-unit step bounds allocation by the canonical journal.
Each following advance performs one existing instance remap, context remap,
historical placement or current placement query. Audio checks cancellation,
deadline and aggregate work around every advance. Error poisons the cursor;
partial histories cannot finish. The 65,536-unit query cap, afterbirth's supplied
call-wide cap and 16,777,216-unit read cap stay intact.

The proof's four immutable borrowed objects can be compared directly. Exact
original/current objects, complete scope slice and context need four identity
checks. Other handles receive the complete semantic comparison, charging those
four attempts plus every comparison. Cloned occurrences and fresh equivalent
scope handles remain accepted. This shortcut does not replace afterbirth's
canonical journal or other authority checks. The old public manual-route API
continues recomputing placements through the joined context query.

Certified-Split proof reads still project the exact historical/current context
when required; those standalone queries and scalar captures are charged. No
context-clock vector is added to the placement rows. No cache, dependency,
permission, authored format, media admission or plan-owning Arc changes.

Six Plan tests cover old-query row oracles, each-step exact/one-short budgets,
poisoning and incomplete finish, oversized public slices before allocation,
separate context steps, skipped Repeat-birth instances, storage and exact versus
semantic authority budgets. An Audio test checks cancellation after remap and
aggregate exhaustion between steps. The public authority fixture compares
complete and partitioned route queries, exact/one-short afterbirth work,
equivalent proof minting/consumption, and 14 rejection cases.

The literal 4/9/15 fixture keeps sample support 24024..30431. Manual afterbirth
costs 117 units; the fieldwise-only proof cost 108. The exact-borrow version costs
78. Including the cursor's extra six-unit allocation guard removes 33 actual
units. This is a checked query-work comparison, not an elapsed-time benchmark.

Rows remain 144 bytes, with exactly clocks.len()+1 capacity. The finished proof
header is 64 bytes, the cursor 208, its phase 88 and borrowed authorities 40.
These are measured compiler/platform sizes, not an ABI promise. There is one
bounded row vector, replacing the old one, plus the existing route and Split
vectors; the header stores borrowed references and no owned plan. No claim of
a measured construction-peak saving is made.
