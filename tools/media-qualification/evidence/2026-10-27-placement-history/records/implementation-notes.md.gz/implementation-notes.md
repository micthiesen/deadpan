# Placement-history proof implementation

Status: source frozen for parent compilation. No Cargo or other compiler run by this agent. All pre-existing source bytes were copied before edits; `source-before.json` and `source-frozen.json` record SHA-256, and `implementation.diff` isolates this task from inherited WIP.

## API and work

`AudioSourceOccurrence::placement_history_cursor(original, clocks, context)` returns a borrowed cursor with no row allocation yet. Its initial `advance` performs six structural operations (first member, canonical owner/event lookups, count, checked capacity and reserve), rejects a supplied slice whose length differs from the actual current-plan journal, then reserves exactly `clocks.len()+1` rows. This separate guard step leaves each subsequent existing Core query its entire individually admitted allowance. Constructor rejects empty clocks. No new cap is introduced.

Later `advance(maximum_work)` performs exactly one existing instance remap, context remap, historical placement, or current placement query. Missing instance skips only its context/placement stages. Each successful step returns the exact existing query work, and Audio obtains `WorkControl::query_limits()` before and calls `spend_plan_work()` afterward. Every error poisons the state before returning. Only completion following current allocation equality admits `finish()`.

The sealed finished `AudioSoundPlacementHistory` is non-Clone, exposes only read-only `placements()`, and is consumed by `complete_processing_history_after_birth_with_placements`. Each scalar `AudioSoundPlacement` contains precisely the former Audio row's complete_start, allocation, anchor and expands_history. No stored context clocks, plan/layout Arc, cloned path, second row vector, persistent cache, source handle or permission is added. Cursor header borrows authorities; pending historical phase owns the same two transient remapped paths as the former Audio loop. Actual stack/row/phase/proof sizes are printed by the new storage test, pending parent execution. A no-memory-increase claim beyond equal row layout is deliberately not made.

Common afterbirth body retains full ordered journal validation, initial binding/alias/recipe/original checks, every instance/context remap and birth/disappearance check, every grid/window/count/current-allocation comparison, Split evidence work and processing-history construction. The proof header compares occurrence fields, policy Arc identity and exact scope tuples before reuse, precharged 22 + 6*clock_count structural units. Row checks cost 2 per historical placement and 3 for current. Bounded string/path comparisons follow existing structural billing rather than new per-byte billing. Legacy entrypoint passes no proof and keeps the prior joined placement/context Core queries and their reported work. Proof path skips placements only; certified Split contexts still run separate exact `project(context, ZERO, None)` and bill projection.work plus scalar capture1. No rational reassociation.

## Tests added by this agent

Plan private module `src/audio_sound_placement_history/tests.rs`:

- placement_cursor_matches_individual_queries_and_each_exact_budget
- placement_cursor_rejects_partial_poisoned_and_oversized_journals
- placement_cursor_keeps_context_remapping_a_separate_admitted_step
- placement_cursor_row_storage_matches_the_replaced_scalar_rows
- placement_cursor_skips_absent_repeat_births_without_issuing_placement_queries

Audio `src/sound_clocks/tests.rs`:

- placement_cursor_checks_cancellation_and_aggregate_work_between_steps

Parent owns new_group_birth_authority public oracle/negative tests, including route exactness, proof-vslegacy work, exact/one-short afterbirth budget, occurrence clones/fresh equivalent scopes and foreign authorities. No new dedicated Split fallback test was added here; existing Split fixtures and parent integration verification remain necessary.

Formatting of owned files and `git diff --check` passed. No tests/builds run by this agent.
