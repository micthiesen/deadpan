from pathlib import Path
import json,subprocess,sys
s=Path(__file__).resolve().parent
bins=json.loads((s/'scoped-binary-pins.json').read_text())
jobs=[(r,'scoped-plan-'+r['name'].replace('_','-'),['--nocapture']) for r in bins if r['package']=='deadpan-plan']
r=next(r for r in bins if r['package']=='deadpan-audio' and r['name']=='deadpan_audio')
jobs.append((r,'scoped-audio-library',['--nocapture','--test-threads=1']))
r=next(r for r in bins if r['package']=='deadpan-audio' and r['name']=='audio_definition')
jobs.append((r,'scoped-birth',['new_group_birth::','--nocapture','--test-threads=1']))
results=[]
for r,label,args in jobs:
 b=r['path'];code=subprocess.call([sys.executable,str(s/'run_scoped.py'),'--binary',b,label,'--',b,*args])
 results.append(dict(label=label,exit_code=code))
 (s/'scoped-results.json').write_text(json.dumps(results,indent=2)+'\n')
raise SystemExit(any(r['exit_code'] for r in results))
