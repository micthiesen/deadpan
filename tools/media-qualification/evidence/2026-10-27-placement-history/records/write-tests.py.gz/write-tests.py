from pathlib import Path
source=Path('/Users/michael/Code/deadpan/crates/deadpan-audio/src/sound_clocks/tests.rs').read_text()
helpers=source[source.index('fn id('):source.index("fn control<'a>")]
out=Path('/Users/michael/Code/deadpan/crates/deadpan-plan/src/audio_sound_placement_history/tests.rs');out.parent.mkdir(exist_ok=True)
out.write_text('''use super::*;
use deadpan_core::{
    AssetId, AssetRecord, AudioBindingState, AudioEdgePolicy, AudioTimingId, AudioTimingRecord,
    BeatNode, BeatSound, ColorPolicy, FrameDuration, FrameRate, FrozenAudioLayout, HoldAudio,
    HoldRecipe, HoldVideo, NodeId, PresentationBasis, ProjectDocument, ProjectId, RevisionId,
    SoundClockJournal, SoundClockReference, SoundId, SoundOverflowPolicy, SourceAudio,
    SourceAudioMapping, SourceQualificationId, SourceSpan, SourceTimeBase, SourceTimestamp,
};
use std::collections::BTreeMap;

'''+helpers+'''
macro_rules! fixture {
    ($plan:ident, $historical:ident, $scopes:ident, $original:ident, $current:ident) => {
        let document = document(&["asset-a"], 2);
        let $plan = RenderPlan::compile(&document).unwrap();
        let $scopes = $plan.beat_sound_clock_scopes(
            &id("owner"), &SoundId::new("sound-0").unwrap(), 65_536,
        ).unwrap();
        let $historical = $plan.compile_sound_processing_layout(
            $scopes[0].historical_layout(),
            &std::collections::BTreeSet::from([AssetId::new("asset-a").unwrap()]),
        ).unwrap();
        let event = &document.beat_sounds()[&id("owner")][&SoundId::new("sound-0").unwrap()];
        let recipe = crate::AudioSourceVoiceRecipe {
            source: event.source.clone(), mapping: event.mapping, offset: event.offset,
        };
        let instance = InstancePath { node: id("owner"), repeats: Vec::new() };
        let $original = $historical.source_voice_occurrence(instance.clone(), recipe.clone(), Default::default()).unwrap();
        let $current = $plan.source_voice_occurrence(instance, recipe, Default::default()).unwrap();
    }
}

#[test]
fn placement_cursor_matches_individual_queries_and_each_exact_budget() {
    fixture!(plan, historical, scopes, original, current);
    let mut expected = vec![6];
    let mut rows = Vec::new();
    let mut first_origin = None;
    for scope in &scopes {
        let (instance, work) = scope.try_remap_instance_with_work(current.instance(), 65_536).unwrap();
        expected.push(work);
        let placement = scope.historical_layout().sound_occurrence_placement(&instance.unwrap(), None, 65_536).unwrap();
        expected.push(placement.work);
        let first = *first_origin.get_or_insert(placement.owner_origin);
        let start = original.extent().start.checked_add(placement.owner_origin.checked_sub(first).unwrap()).unwrap();
        rows.push((start, placement.allocation, placement.delivery_start.checked_sub(start).unwrap(), false));
    }
    let placement = scopes[0].live_layout().sound_occurrence_placement(current.instance(), None, 65_536).unwrap();
    expected.push(placement.work);
    let start = original.extent().start.checked_add(placement.owner_origin.checked_sub(first_origin.unwrap()).unwrap()).unwrap();
    rows.push((start, placement.allocation, placement.delivery_start.checked_sub(start).unwrap(), false));
    for (index, needed) in expected.iter().copied().enumerate() {
        for exact in [true, false] {
            let mut cursor = current.placement_history_cursor(&original, &scopes, None).unwrap();
            for previous in &expected[..index] { assert_eq!(cursor.advance(65_536).unwrap(), *previous); }
            let result = cursor.advance(if exact { needed } else { needed - 1 });
            if exact { assert_eq!(result.unwrap(), needed); }
            else { assert!(result.is_err()); assert!(cursor.advance(65_536).is_err()); assert!(cursor.finish().is_err()); }
        }
    }
    let mut cursor = current.placement_history_cursor(&original, &scopes, None).unwrap();
    for work in expected { assert_eq!(cursor.advance(65_536).unwrap(), work); }
    assert!(cursor.is_complete());
    let proof = cursor.finish().unwrap();
    assert_eq!(proof.placements().len(), rows.len());
    assert!(proof.placements().capacity_is_not_public());
    for (row, expected) in proof.placements().iter().zip(rows) {
        assert_eq!((row.complete_start(), row.allocation(), row.anchor(), row.expands_history()), expected);
    }
}

#[test]
fn placement_cursor_rejects_partial_poisoned_and_oversized_journals() {
    fixture!(plan, historical, scopes, original, current);
    let mut cursor = current.placement_history_cursor(&original, &scopes, None).unwrap();
    assert_eq!(cursor.rows.capacity(), 0);
    assert_eq!(cursor.advance(6).unwrap(), 6);
    assert!(cursor.finish().is_err());
    let repeated = vec![scopes[0].clone(); 128];
    let mut cursor = current.placement_history_cursor(&original, &repeated, None).unwrap();
    assert_eq!(cursor.rows.capacity(), 0);
    assert!(cursor.advance(65_536).is_err());
    assert_eq!(cursor.rows.capacity(), 0);
    assert!(cursor.finish().is_err());
    let mut cursor = current.placement_history_cursor(&original, &scopes, None).unwrap();
    assert!(cursor.advance(65_537).is_err());
    assert!(cursor.finish().is_err());
    assert!(current.placement_history_cursor(&original, &[], None).is_err());
}

#[test]
fn placement_cursor_keeps_context_remapping_a_separate_admitted_step() {
    fixture!(plan, historical, scopes, original, current);
    let context = plan.audio_sound_instance_context(current.instance(), Default::default()).unwrap();
    let mut cursor = current.placement_history_cursor(&original, &scopes, Some(&context)).unwrap();
    assert_eq!(cursor.advance(6).unwrap(), 6);
    for scope in &scopes {
        let (instance, remap_work) = scope.try_remap_instance_with_work(current.instance(), 65_536).unwrap();
        assert_eq!(cursor.advance(remap_work).unwrap(), remap_work);
        let (mapped, context_work) = scope.try_remap_context_with_work(&context, 65_536).unwrap();
        assert_eq!(cursor.advance(context_work).unwrap(), context_work);
        let placement = scope.historical_layout().sound_occurrence_placement(&instance.unwrap(), mapped.as_ref(), 65_536).unwrap();
        assert_eq!(cursor.advance(placement.work).unwrap(), placement.work);
    }
    let placement = scopes[0].live_layout().sound_occurrence_placement(current.instance(), Some(context.owner()), 65_536).unwrap();
    assert_eq!(cursor.advance(placement.work).unwrap(), placement.work);
    let proof = cursor.finish().unwrap();
    assert!(proof.placements().iter().all(|row| row.expands_history()));
}

#[test]
fn placement_cursor_row_storage_matches_the_replaced_scalar_rows() {
    #[allow(dead_code)]
    struct OldRow { complete_start: ExactRatio, allocation: Range<ExactRatio>, anchor: ExactRatio, expands_history: bool }
    assert_eq!(std::mem::size_of::<AudioSoundPlacement>(), std::mem::size_of::<OldRow>());
    fixture!(plan, historical, scopes, original, current);
    let mut cursor = current.placement_history_cursor(&original, &scopes, None).unwrap();
    while !cursor.is_complete() { cursor.advance(65_536).unwrap(); }
    assert_eq!(cursor.rows.len(), scopes.len() + 1);
    assert_eq!(cursor.rows.capacity(), scopes.len() + 1);
    eprintln!("placement sizes: row={} cursor={} proof={} phase={} authorities={} capacity={}",
        std::mem::size_of::<AudioSoundPlacement>(),
        std::mem::size_of::<AudioSoundPlacementHistoryCursor<'_, '_, '_>>(),
        std::mem::size_of::<AudioSoundPlacementHistory<'_, '_, '_>>(),
        std::mem::size_of::<Phase>(), std::mem::size_of::<Authorities<'_, '_, '_>>(), cursor.rows.capacity());
}
''')
s=out.read_text().replace('    assert!(proof.placements().capacity_is_not_public());\n','');out.write_text(s)
