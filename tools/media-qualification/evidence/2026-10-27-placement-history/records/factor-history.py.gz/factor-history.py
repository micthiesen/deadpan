from pathlib import Path
p=Path('/Users/michael/Code/deadpan/crates/deadpan-plan/src/audio_sound_processing_history.rs')
s=p.read_text()
needle='''    ) -> Result<(Option<AudioSoundProcessingHistory<'plan>>, usize), PlanError> {
        limits.validate()?;
'''
assert s.count(needle)==1
s=s.replace(needle,'''    ) -> Result<(Option<AudioSoundProcessingHistory<'plan>>, usize), PlanError> {
        self.processing_history_after_birth_inner(
            original, alias, binding, delivery, clocks, context, None, limits,
        )
    }

    /// Certify the same complete journal using one-shot placements already
    /// admitted by the host. This skips only repeated Core placement queries;
    /// all source, journal, remap, context and delivery checks still run.
    #[allow(clippy::too_many_arguments)]
    pub fn complete_processing_history_after_birth_with_placements(
        &self,
        original: &AudioSourceOccurrence<'_>,
        alias: &crate::AudioOccurrenceAlias<'_>,
        binding: &crate::AudioSoundClockBinding<'_, '_>,
        delivery: &crate::AudioSoundRoute<AudioSample>,
        clocks: &[crate::AudioSoundClockScope<'_>],
        context: &AudioSoundOwnerContext<'_>,
        placements: AudioSoundPlacementHistory<'_, '_, '_>,
        limits: AudioQueryLimits,
    ) -> Result<(Option<AudioSoundProcessingHistory<'plan>>, usize), PlanError> {
        self.processing_history_after_birth_inner(
            original, alias, binding, delivery, clocks, context, Some(&placements), limits,
        )
    }

    #[allow(clippy::too_many_arguments)]
    fn processing_history_after_birth_inner(
        &self,
        original: &AudioSourceOccurrence<'_>,
        alias: &crate::AudioOccurrenceAlias<'_>,
        binding: &crate::AudioSoundClockBinding<'_, '_>,
        delivery: &crate::AudioSoundRoute<AudioSample>,
        clocks: &[crate::AudioSoundClockScope<'_>],
        context: &AudioSoundOwnerContext<'_>,
        placements: Option<&AudioSoundPlacementHistory<'_, '_, '_>>,
        limits: AudioQueryLimits,
    ) -> Result<(Option<AudioSoundProcessingHistory<'plan>>, usize), PlanError> {
        limits.validate()?;
''',1)
needle='''        let extent = original.extent();
        let step = original.grid.frames_per_sample();'''
assert s.count(needle)==1
s=s.replace(needle,'''        if let Some(placements) = placements {
            spend(&mut work, placements.validation_work()?)?;
            placements.validate(original, self, clocks, context)?;
        }
        let extent = original.extent();
        let step = original.grid.frames_per_sample();''',1)
a=s.index('            let (placement, context_clock) = if certified_split {')
b=s.index('            let grid = AudioSampleGrid::new(',a)
old=s[a:b]
s=s[:a]+'''            let (complete_start, allocation, anchor, context_clock) =
                if let Some(placements) = placements {
                    spend(&mut work, 2)?;
                    let row = placements.placements().get(placement_index).ok_or(
                        PlanError::InvalidPlan("sound placement history is incomplete"),
                    )?;
                    if row.expands_history() != historical_context.is_some() {
                        return Err(PlanError::InvalidPlan("sound placement history has another context"));
                    }
                    let context_clock = if certified_split {
                        historical_context.as_ref().map(|context| {
                            let projected = scope.historical_layout().project(
                                context, ExactRatio::ZERO, None,
                                remaining(work)?.min(deadpan_core::MAX_DOCUMENT_NODES),
                            )?;
                            spend(&mut work, projected.work)?;
                            spend(&mut work, 1)?;
                            Ok::<_, PlanError>((projected.origin, projected.frames_per_local_frame))
                        }).transpose()?
                    } else { None };
                    (row.complete_start(), row.allocation(), row.anchor(), context_clock)
                } else {
''' + old.replace('            ','                    ',1) + '''                    (complete_start, placement.allocation.clone(),
                        placement.delivery_start.checked_sub(complete_start)?,
                        context_clock.map(|p| (p.origin, p.frames_per_local_frame)))
                };
            if certified_split {
                context_origins.push(context_clock);
            }
''' + s[b:]
# Remove the old context push in moved legacy branch, since now performed once below.
oldpush='''            if certified_split {
                context_origins.push(context_clock.map(|p| (p.origin, p.frames_per_local_frame)));
            }
'''
assert s.count(oldpush)==1
s=s.replace(oldpush,'',1)
# Historical window consumes common scalar row.
needle='''                selection: placement.allocation.start.checked_sub(complete_start)?
                    ..placement.allocation.end.checked_sub(complete_start)?,
                anchor: placement.delivery_start.checked_sub(complete_start)?,'''
assert s.count(needle)==1
s=s.replace(needle,'''                selection: allocation.start.checked_sub(complete_start)?
                    ..allocation.end.checked_sub(complete_start)?,
                anchor,''',1)
# Current branch, common scalar.
a=s.index('        let (placement, context_clock) = if certified_split {')
b=s.index('        let grid = AudioSampleGrid::new(',a)
old=s[a:b]
s=s[:a]+'''        let (complete_start, allocation, anchor, context_clock) =
            if let Some(placements) = placements {
                spend(&mut work, 3)?;
                let row = placements.placements().get(placement_index).ok_or(
                    PlanError::InvalidPlan("sound placement history has no current placement"),
                )?;
                if !row.expands_history() || placements.placements().len() != placement_index + 1 {
                    return Err(PlanError::InvalidPlan("sound placement history has another current placement"));
                }
                let context_clock = if certified_split {
                    let projected = scope.live_layout().project(
                        context.owner(), ExactRatio::ZERO, None,
                        remaining(work)?.min(deadpan_core::MAX_DOCUMENT_NODES),
                    )?;
                    spend(&mut work, projected.work)?;
                    spend(&mut work, 1)?;
                    Some((projected.origin, projected.frames_per_local_frame))
                } else { None };
                (row.complete_start(), row.allocation(), row.anchor(), context_clock)
            } else {
''' + old + '''                (complete_start, placement.allocation.clone(),
                    placement.delivery_start.checked_sub(complete_start)?,
                    context_clock.map(|p| (p.origin, p.frames_per_local_frame)))
            };
        if certified_split {
            context_origins.push(context_clock);
        }
''' + s[b:]
currentpush=oldpush.replace('            ', '        ', 1).replace('                context_origins', '            context_origins').replace('            }', '        }')
assert s.count(currentpush)==1
s=s.replace(currentpush,'',1)
needle='''            selection: placement.allocation.start.checked_sub(complete_start)?
                ..placement.allocation.end.checked_sub(complete_start)?,
            anchor: placement.delivery_start.checked_sub(complete_start)?,'''
assert s.count(needle)==1
s=s.replace(needle,'''            selection: allocation.start.checked_sub(complete_start)?
                ..allocation.end.checked_sub(complete_start)?,
            anchor,''',1)
s=s.replace('''        if placement.allocation != self.extent()
''','''        if allocation != self.extent()
''',1)
p.write_text(s)
