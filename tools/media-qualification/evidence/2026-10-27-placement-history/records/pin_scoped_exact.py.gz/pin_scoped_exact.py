from pathlib import Path
import json,hashlib,shutil
s=Path(__file__).resolve().parent
artifacts=[]
for line in (s/'scoped-exact-build.stdout').read_text().splitlines():
 try:r=json.loads(line)
 except ValueError:continue
 if r.get('reason')!='compiler-artifact' or not r.get('executable') or not r.get('profile',{}).get('test'):continue
 pkg=r['package_id'].split('/crates/')[1].split('#')[0]
 name=r['target']['name']
 if pkg=='deadpan-plan' or (pkg=='deadpan-audio' and name in ['deadpan_audio','audio_definition']):
  artifacts.append((pkg,name,r['executable']))
print('Available',len(artifacts))
if len([a for a in artifacts if a[0]=='deadpan-plan'])!=28 or len([a for a in artifacts if a[0]=='deadpan-audio'])!=2:
 raise SystemExit('Requested targets not emitted yet')
pins=[]
for pkg,name,source in artifacts:
 p=s/('scoped-'+pkg+'-'+name.replace('_','-')+'-exact')
 assert not p.exists()
 shutil.copy2(source,p)
 pins.append(dict(package=pkg,name=name,path=str(p),sha256=hashlib.sha256(p.read_bytes()).hexdigest()))
(s/'scoped-exact-pins.json').write_text(json.dumps(pins,indent=2)+'\n')
