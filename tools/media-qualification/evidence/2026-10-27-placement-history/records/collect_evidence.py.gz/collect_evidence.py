from pathlib import Path
import gzip,json,hashlib
s=Path(__file__).resolve().parent
dest=Path('/Users/michael/Code/deadpan/tools/media-qualification/evidence/2026-10-27-placement-history')
extensions={'.json','.stdout','.stderr','.py','.patch','.rs','.txt','.md','.diff','.before'}
assert not dest.exists()
dest.mkdir(parents=True)
files=[]
for p in sorted(s.rglob('*')):
 if not p.is_file() or p.suffix not in extensions:continue
 data=p.read_bytes();compressed=gzip.compress(data,mtime=0)
 out=dest/'records'/Path(str(p.relative_to(s))+'.gz')
 out.parent.mkdir(parents=True,exist_ok=True);out.write_bytes(compressed)
 files.append(dict(path=str(out.relative_to(dest)),bytes=len(compressed),sha256=hashlib.sha256(compressed).hexdigest(),expanded_bytes=len(data),expanded_sha256=hashlib.sha256(data).hexdigest()))
inventory=dict(schema_version=1,base_revision='a2414045',scope='Independent ten-file sealed placement history cursor, exact-borrow discriminator with semantic fallback, and Audio integration. Same scalar row vector replaces prior Audio vector. Retain all journal/binding/context/remap/route/source checks; no cache, raised limit or new plan ownership. Original test-fixture and lint failures, intermediate fieldwise-only matrix, final current/isolated checks, commands, immutable inputs/binary pins and reviews retained. No acceptance credit. Executables local only.',runtime_baseline_evidence=dict(path='../2026-10-27-placement-context/inventory.json',inventory_sha256='67d2d9b9dad13ae1c317b7d3be91134f5596d618ba69bd60ab2884f97e20a0d9',base_revision='d76f8f24',note='Prior full candidate diff and untracked archive reconstruct the inherited general-Split runtime state including the joined-context code. This inventory retains the new final overlay and exact input identities; no repeated full-tree archive.'),files=files)
out=dest/'inventory.json';out.write_text(json.dumps(inventory,indent=2)+'\n')
for row in files:
 data=(dest/row['path']).read_bytes();expanded=gzip.decompress(data)
 assert len(data)==row['bytes'] and hashlib.sha256(data).hexdigest()==row['sha256']
 assert len(expanded)==row['expanded_bytes'] and hashlib.sha256(expanded).hexdigest()==row['expanded_sha256']
print(json.dumps(dict(payloads=len(files),stored_bytes=sum(r['bytes'] for r in files),expanded_bytes=sum(r['expanded_bytes'] for r in files),inventory_sha256=hashlib.sha256(out.read_bytes()).hexdigest()),indent=2))
