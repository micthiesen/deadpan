from pathlib import Path
import difflib,json,hashlib,shutil
s=Path(__file__).resolve().parent;r=Path('/Users/michael/Code/deadpan')
rels=list(json.loads((s/'source-frozen.json').read_text()))
rel='crates/deadpan-audio/tests/audio_definition/sound_clocks/new_group_birth_authority.rs'
rels.append(rel)
patch='';pins={}
for rel in rels:
 if rel=='crates/deadpan-audio/src/sound_clocks/tests.rs':baseline=s/'sound_clocks.tests.rs.before'
 elif rel.endswith('new_group_birth_authority.rs'):baseline=s/'new_group_birth_authority.before.rs'
 elif rel in ['crates/deadpan-plan/src/audio_sound_placement_history.rs','crates/deadpan-plan/src/audio_sound_placement_history/tests.rs']:baseline=None
 else:baseline=s/(Path(rel).name+'.before')
 before=baseline.read_text() if baseline else ''
 after=(r/rel).read_text()
 patch+=''.join(difflib.unified_diff(before.splitlines(True),after.splitlines(True),fromfile='a/'+rel if before else '/dev/null',tofile='b/'+rel))
 pins[rel]=hashlib.sha256(after.encode()).hexdigest()
(s/'combined-final.patch').write_text(patch)
(s/'final-source-pins.json').write_text(json.dumps(pins,indent=2)+'\n')
print('Final ten-file patch',len(patch),'bytes')
