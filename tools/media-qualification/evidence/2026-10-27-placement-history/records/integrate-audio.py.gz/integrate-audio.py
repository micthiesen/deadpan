from pathlib import Path
p=Path('/Users/michael/Code/deadpan/crates/deadpan-audio/src/sound_clocks.rs');s=p.read_text()
a=s.index('/// Every placement contributes'); b=s.index('pub(super) fn route_occurrence',a)
s=s[:a]+'''/// Every placement contributes one rounded allocation. Keeping the intermediate
/// grids prevents a later move from reviving samples clipped by an earlier move.
'''+s[b:]
s=s.replace('placements: &[SoundPlacement]','placements: &[deadpan_plan::AudioSoundPlacement]')
s=s.replace('first.allocation != extent || first.complete_start != extent.start','first.allocation() != extent || first.complete_start() != extent.start')
s=s.replace('placement.complete_start','placement.complete_start()').replace('placement.anchor,','placement.anchor(),')
s=s.replace('''                .allocation
''','''                .allocation()
''')
a=s.index('pub(super) fn placements('); b=s.index('\n#[cfg(test)]',a)
s=s[:a]+'''pub(super) fn placements<'query, 'current, 'original>(
    original: &'query AudioSourceOccurrence<'original>,
    current: &'query AudioSourceOccurrence<'current>,
    clocks: &'query [deadpan_plan::AudioSoundClockScope<'current>],
    context: Option<&'query deadpan_plan::AudioSoundOwnerContext<'current>>,
    control: WorkControl<'_>,
) -> Result<deadpan_plan::AudioSoundPlacementHistory<'query, 'current, 'original>, StageAudioError> {
    let mut cursor = current.placement_history_cursor(original, clocks, context)?;
    while !cursor.is_complete() {
        let work = cursor.advance(control.query_limits()?.maximum_work)?;
        control.spend_plan_work(work)?;
    }
    Ok(cursor.finish()?)
}
'''+s[b:]
p.write_text(s)
p=Path('/Users/michael/Code/deadpan/crates/deadpan-audio/src/beat_sounds.rs');s=p.read_text()
s=s.replace('''                                &placements,
''','''                                placements.placements(),
''',1)
s=s.replace('''if placements.iter().all(|p| p.expands_history)''','''if placements.placements().iter().all(|p| p.expands_history())''',1)
s=s.replace('''control.spend_plan_work(placements.len())?;''','''control.spend_plan_work(placements.placements().len())?;''',1)
s=s.replace('''.complete_processing_history_after_birth(
''','''.complete_processing_history_after_birth_with_placements(
''',1)
needle='''                                        &scopes,
                                        context,
                                        control.query_limits()?,'''
assert s.count(needle)==1
s=s.replace(needle,'''                                        &scopes,
                                        context,
                                        placements,
                                        control.query_limits()?,''',1)
p.write_text(s)
