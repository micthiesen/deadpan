from pathlib import Path
import json,subprocess,sys
s=Path(__file__).resolve().parent
row=next(r for r in json.loads((s/'scoped-exact-pins.json').read_text()) if r['package']=='deadpan-audio' and r['name']=='audio_definition')
b=row['path']
code=subprocess.call([sys.executable,str(s/'run_scoped.py'),'--binary',b,'scoped-exact-birth','--',b,'new_group_birth::','--nocapture','--test-threads=1'])
if code:raise SystemExit(code)
row=next(r for r in json.loads((s/'exact-pins.json').read_text()) if r['package']=='deadpan-audio' and r['name']=='stages')
b=row['path']
raise SystemExit(subprocess.call([sys.executable,str(s/'run.py'),'--binary',b,'exact-split-matrix','--',b,'general_split_sound::','--nocapture','--test-threads=1']))
