import fcntl
import hashlib
import json
from pathlib import Path
import sqlite3
import subprocess

root = Path('/tmp/deadpan-structural-capture-20261001/native-qa')
labels = ['before', 'cut', 'cancelled', 'pasted', 'undo-paste', 'undo-cut', 'whole-child-cancelled']
snapshots = {}
for label in labels:
    path = root / (label + '.sqlite')
    with sqlite3.connect(path) as db:
        names = [r[0] for r in db.execute("select name from sqlite_master where type='table' order by name")]
        tables = {name: sorted(db.execute('select * from "' + name.replace('"', '""') + '"').fetchall(), key=repr) for name in names}
        head = db.execute('select head_revision from state').fetchone()[0]
        document = json.loads(db.execute('select document from revisions where id=?', (head,)).fetchone()[0])
    snapshots[label] = {'tables': tables, 'document': document, 'sha256': hashlib.sha256(path.read_bytes()).hexdigest()}
baseline = snapshots['before']['tables']
assert snapshots['cancelled']['tables'] == snapshots['cut']['tables']
assert snapshots['whole-child-cancelled']['tables'] == snapshots['undo-cut']['tables']
for label, increment in [('cut', 1), ('pasted', 2), ('undo-paste', 3), ('undo-cut', 4)]:
    assert len(snapshots[label]['tables']['revisions']) == len(baseline['revisions']) + increment, label
assert len(snapshots['cut']['tables']['history']) == len(baseline['history']) + 1
assert len(snapshots['pasted']['tables']['history']) == len(baseline['history']) + 2
unchanged = [name for name in baseline if name not in ['history', 'redo', 'revisions', 'state']]
for label in labels:
    for name in unchanged:
        assert snapshots[label]['tables'][name] == baseline[name], (label, name)
for earlier, undone in [('cut', 'undo-paste'), ('before', 'undo-cut')]:
    expected = dict(snapshots[earlier]['document'])
    actual = dict(snapshots[undone]['document'])
    assert expected.pop('revision_id') != actual.pop('revision_id')
    assert expected == actual, (earlier, undone)
executable = str(root / 'DeadpanStructuralQA.app/Contents/MacOS/deadpan-app')
running = [line for line in subprocess.check_output(['ps', '-axo', 'pid=,comm='], text=True).splitlines()
           if line.strip().split(None, 1)[-1] in (executable, '/private' + executable)]
assert not running
with (root / 'Cut slices.deadpan/.writer.lock').open('rb') as handle:
    fcntl.flock(handle, fcntl.LOCK_EX | fcntl.LOCK_NB)
    fcntl.flock(handle, fcntl.LOCK_UN)
result = {
    'cancel_preserves_all_tables': len(baseline),
    'whole_child_copy_and_cancel_preserves_all_tables': len(baseline),
    'cut_and_paste_each_add_one_revision_and_one_history_entry': True,
    'each_undo_restores_every_authored_field_except_fresh_revision': True,
    'unrelated_tables_identical_throughout': unchanged,
    'temporary_app_exited': True, 'writer_lock_released': True,
    'snapshots': {label: {'database_sha256': data['sha256'],
                         'head': data['document']['revision_id'],
                         'counts': {name: len(rows) for name, rows in data['tables'].items()},
                         'table_sha256': {name: hashlib.sha256(repr(rows).encode()).hexdigest() for name, rows in data['tables'].items()}}
                  for label, data in snapshots.items()},
}
(root / 'verification.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({key: value for key, value in result.items() if key != 'snapshots'}, indent=2))
