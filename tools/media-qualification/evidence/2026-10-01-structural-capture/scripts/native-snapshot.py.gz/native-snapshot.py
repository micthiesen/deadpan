import json
from pathlib import Path
import sqlite3
import sys

package, output, label = map(Path, sys.argv[1:])
output.mkdir(parents=True, exist_ok=True)
destination = output / (str(label) + '.sqlite')
assert not destination.exists(), destination
with sqlite3.connect((package / 'project.sqlite').as_uri() + '?mode=ro', uri=True) as source:
    with sqlite3.connect(destination) as snapshot:
        source.backup(snapshot)
with sqlite3.connect(destination) as snapshot:
    head = snapshot.execute('select head_revision from state').fetchone()[0]
    document = json.loads(snapshot.execute('select document from revisions where id=?', (head,)).fetchone()[0])
    tables = snapshot.execute("select name from sqlite_master where type='table' order by name").fetchall()
    counts = {name: snapshot.execute('select count(*) from "' + name.replace('"', '""') + '"').fetchone()[0] for name, in tables}
(output / (str(label) + '-document.json')).write_text(json.dumps(document, indent=2) + '\n')
print(json.dumps({'label': str(label), 'head': head, 'counts': counts}, indent=2))
