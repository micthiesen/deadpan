import hashlib
import json
from pathlib import Path
import shutil
import subprocess

repo = Path.cwd()
target = Path('/tmp/deadpan-structural-capture-20261001/baseline')
target.mkdir(exist_ok=False)
for directory in ('crates', 'native', '.cargo'):
    shutil.copytree(repo / directory, target / directory)
for name in ('Cargo.toml', 'Cargo.lock', 'rust-toolchain.toml'):
    shutil.copy2(repo / name, target / name)
manifest = {str(path.relative_to(target)): hashlib.sha256(path.read_bytes()).hexdigest()
            for path in sorted(target.rglob('*')) if path.is_file()}
report = {
    'base_commit': subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip(),
    'files': manifest,
}
(target.parent / 'baseline-source.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps({'commit': report['base_commit'], 'files': len(manifest), 'snapshot': str(target)}))
