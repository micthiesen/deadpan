import fcntl
import hashlib
import json
from pathlib import Path
import shutil

root = Path('/tmp/deadpan-structural-capture-20261001/native-qa')
source = Path('/tmp/deadpan-structural-capture-20261001/visual-cut-second/projects/delete-range/Documents/Deadpan/cfr-bframes.deadpan')
root.mkdir(exist_ok=True)
with (source / '.writer.lock').open('rb') as lock:
    fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
    shutil.copytree(source, root / 'Cut slices.deadpan')
    database_hash = hashlib.sha256((source / 'project.sqlite').read_bytes()).hexdigest()
    fcntl.flock(lock, fcntl.LOCK_UN)
(root / 'fixture.json').write_text(json.dumps({
    'source': str(source), 'source_database_sha256': database_hash,
    'source_writer_released': True,
    'purpose': 'Closed retained production replay package copied for isolated native keyboard QA',
}, indent=2) + '\n')
print(root / 'Cut slices.deadpan')
