import datetime
import gzip
import hashlib
import json
import platform
from pathlib import Path
import re
import shutil
import subprocess

repo = Path('/Users/michael/Code/deadpan')
scratch = Path('/tmp/deadpan-structural-capture-20261001')
destination = repo / 'tools/media-qualification/evidence/2026-10-01-structural-capture'
final_source = '55df165772764063e162c8b1eb397f8e691aff3f2a625bd39d4711355236d4c5'
manifest_path = scratch / 'checks' / ('source-' + final_source + '.json')
manifest = json.loads(manifest_path.read_text())
for name, expected in manifest.items():
    assert hashlib.sha256((repo / name).read_bytes()).hexdigest() == expected, name
assert not destination.exists(), destination
destination.mkdir(parents=True)

def copy(source, relative, compress=False):
    target = destination / relative
    target.parent.mkdir(parents=True, exist_ok=True)
    if compress:
        target.write_bytes(gzip.compress(source.read_bytes(), mtime=0))
    else:
        shutil.copy2(source, target)

for source in sorted((scratch / 'checks').iterdir()):
    if source.suffix == '.json' and not source.name.startswith('source-'):
        record = json.loads(source.read_text())
        assert 'exit_code' in record, source
    compress = source.suffix == '.log' or source.name.startswith('source-')
    copy(source, 'checks/' + source.name + ('.gz' if compress else ''), compress)
for source in sorted(scratch.glob('*.md')):
    copy(source, source.name)
for source in sorted(scratch.glob('*.json')):
    copy(source, source.name + '.gz', True)
for source in sorted(scratch.glob('*.py')):
    copy(source, 'scripts/' + source.name + '.gz', True)
copy(repo / 'tools/media-qualification/evidence/2026-09-29-generated-pictures/run-native.py', 'scripts/run-native.py.gz', True)

base = '2ea675646abc24e8410616af74b4193ed4af51da'
name = 'crates/deadpan-store/tests/edited_slice.rs'
original = subprocess.check_output(['git', 'show', base + ':' + name], cwd=repo)
generator = (scratch / 'baseline' / name).read_bytes()
assert generator.startswith(original)
(destination / 'old-range-generator.rs.txt.gz').write_bytes(gzip.compress(generator[len(original):], mtime=0))
copy(scratch / 'prepare-baseline.py', 'scripts/prepare-baseline.py.gz', True)
copy(scratch / 'old-range/range-v1.json', 'old-range-v1.json.gz', True)

replays = {}
for output in sorted(scratch.iterdir()):
    report = output / 'report.json'
    if output.is_dir() and report.exists():
        copy(report, 'replays/' + output.name + '.json.gz', True)
        data = json.loads(report.read_text())
        replays[output.name] = {s['name']: {'failed': s['failed'], 'checks': len(s['checks']), 'skipped': s['skipped']} for s in data['scenarios']}
for output, images in {
    'visual-cut-second': ['delete-range-122.png', 'delete-range-123.png'],
    'visual-place-third': ['place-slice-137.png', 'place-slice-138.png', 'place-slice-139.png', 'place-slice-140.png'],
    'visual-cut-first': ['delete-range-122.png'],
    'visual-place-first': ['place-slice-137.png'],
    'visual-place-second': ['place-slice-137.png'],
}.items():
    for image in images:
        copy(scratch / output / image, 'images/' + output + '-' + image)
for source in sorted((scratch / 'native-qa').iterdir()):
    if source.is_file() and source.suffix in ('.json', '.md', '.sqlite'):
        compress = source.suffix == '.sqlite'
        copy(source, 'native/' + source.name + ('.gz' if compress else ''), compress)

environment = {
    'collected_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'base_commit': base,
    'final_source_manifest_sha256': final_source,
    'rechecked_source_inputs': len(manifest),
    'platform': platform.platform(),
    'rustc': subprocess.check_output(['rustup', 'run', '1.97.1', 'rustc', '-vV'], text=True),
    'macos': subprocess.check_output(['sw_vers'], text=True),
    'ffmpeg_prefix': '/tmp/deadpan-ui-ffmpeg/prefix',
    'replays': replays,
}
(destination / 'environment.json').write_text(json.dumps(environment, indent=2) + '\n')
hashes = {str(path.relative_to(destination)): hashlib.sha256(path.read_bytes()).hexdigest()
          for path in sorted(destination.rglob('*')) if path.is_file()}
(destination / 'SHA256SUMS.json').write_text(json.dumps(hashes, indent=2) + '\n')
print(json.dumps({'destination': str(destination), 'files': len(hashes), 'source_inputs_rechecked': len(manifest)}, indent=2))
