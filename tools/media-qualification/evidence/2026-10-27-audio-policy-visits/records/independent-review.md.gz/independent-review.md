# Independent review: raw final-policy visitor candidate

## Scope

Reviewed only `raw-policy/candidate.patch` against its pinned before/after trees. This candidate changes `edges.rs`, adds `raw_policy.rs` and its tests, and replaces the final flattened-span/suppression block in `stages.rs`. It does not contain the separate Components permission-carrier/phase-visitor vertical. No Cargo was run; the main session owns build verification.

## Findings

No supported correctness finding in the reviewed diff.

The production adapter uses the same visitor events at the former mutation points: each flattened span still gets a `control.check`; silent holds zero and mark suppression; other spans apply retained envelope before calculating/extracting exhausted endpoint slots; explicit policy ranges are validated as a complete set before any policy zeroing; creative fades still execute afterward in `read_queries_borrowed`, followed by its existing final `control.check`. `exhausted_range_slots` retains prefix-before-suffix order while replacing the temporary per-span Vec with two fixed optional slots. The checked offset helper enforces the selected frame window, and the explicit policy nonempty condition matches `apply_suppression`'s `left >= right` rejection.

Cold `visit` invokes the caller's `charge` hook before visits, offset validations, and event emissions; the production adapter deliberately passes a no-op so it does not add plan-work charges. The new tests use literal event order, include silent-hold and non-silent exhaustion cases, assert retained-envelope error precedence, prove late invalid explicit suppression does not emit a policy event before validation, test work-limit/cancellation propagation, and verify creative fade zero gain and policy `contents` do not manufacture raw-mask events.

## Limits / test caveat

I did not build or execute the candidate. The visitor's generic callback can observe earlier non-policy events before a later envelope/range error; callers must treat the returned error as an incomplete visit and discard any provisional collection. The explicit suppression phase itself preserves all-or-nothing validation-before-emission. The visitor does not independently perform a terminal cancellation/deadline check when there are no flattened or explicit-policy events; the current production caller retains its final check after creative fades, while a cold caller should bracket/own that check (or the contract should state this explicitly). This is a bounded-use caveat, not a current production regression.

# Independent review supplement: Components permission carrier / phase visitors

Reviewed `/tmp/deadpan-policy-visitor-2026-10-27/components/carrier-visitors.patch` against the frozen Components source and its before/after audit metadata. Scope is the six patch paths only; the separately integrated Raw policy change and unrelated WIP are excluded. No Cargo was run; the main session owns verification.

## Findings

No supported runtime behavior regression found in this phase-only extraction. `Sample.permitted` is moved to one `Components`-owned carrier; `resident_frames` accounts for its header and the prospective per-route word payload (including old+replacement payload during growth), and `allocate()` allocates that payload before PCM. The existing `add` ordering remains: event-gain validation/assignment and PCM writes occur as before, with permission marked only after both channel finite checks pass. The numerical engines continue to use the same per-route/sample eligibility predicates and preserve their constant/dynamic outer traversal, gain flushes, finite checks, sends, output ordering, and error propagation.

The EQ visitor retains owner-member order, checks permission shape before treating an absent row as inactive, and only requires a clock when an active member is reached. The wet visitor emits Reverb then Delay, invokes the caller only for present send levels, and checks the clock at the same active effect boundary as before. Both request objects borrow the already-selected phase clock; they do not clone it per member/effect. Runtime hooks are no-ops and do not add work charges; metadata hooks can bill inactive probes before each member/effect check and propagate the first error.

## Limits / design caveat

This patch does not add a cold population path or whole-Components completion proof. `SamplePermissions::contains` and `row` intentionally yield false/empty for absent data; only the EQ visitor validates carrier shape. Therefore no future cold caller may interpret those convenience reads as proof of inactivity without first establishing complete allocated/populated carrier shape. This is explicitly documented and does not alter the current runtime path, whose normal allocation occurs before numerical finish. The patch also does not establish admission of any additional caller-owned metadata buffers or enable batching.

No Cargo or tests were run by this reviewer. Candidate tests cover deferred exact payload and growth retention, valid one/1024-frame cases, mark-after-finite behavior, metadata visits without PCM, borrowed clock identity, callback ordering, inactive probes, and error short-circuiting; the main build remains authoritative.

### Strict-lint test-only correction

The main session reports strict Clippy found `manual_bits` in `permission_tests.rs`' exact byte-count assertion. The expression was changed from `header + 8 * size_of::<u64>()` to the equivalent `header + size_of::<[u64; 8]>()`; expected bytes and production code are unchanged. The main session reports the rerun passing for all four scoped crates and all targets. I did not run Cargo.
