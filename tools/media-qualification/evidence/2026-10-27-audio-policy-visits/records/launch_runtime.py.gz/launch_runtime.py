from pathlib import Path
import subprocess,sys,json
s=Path(__file__).resolve().parent
cases=[
 ('run_scoped.py','scoped-audio-lib','scoped-verified-build-deadpan-audio',['--nocapture','--test-threads=1']),
 ('run_scoped.py','scoped-birth-pcm','scoped-verified-build-audio-definition',['new_group_birth::','--nocapture','--test-threads=1']),
 ('run.py','audio-definition','verified-build-audio-definition',['--nocapture','--test-threads=1']),
 ('run.py','enabled-stages','verified-build-stages',['--nocapture','--test-threads=1','--skip','general_split_sound']),
]
results=[]
for runner,label,binary,args in cases:
 command=[sys.executable,str(s/runner),'--binary',str(s/binary),label,'--',str(s/binary),*args]
 result=subprocess.run(command,check=False)
 results.append({'label':label,'exit_code':result.returncode})
 (s/'runtime-status.json').write_text(json.dumps(results,indent=2)+'\n')
 if result.returncode:raise SystemExit(result.returncode)
