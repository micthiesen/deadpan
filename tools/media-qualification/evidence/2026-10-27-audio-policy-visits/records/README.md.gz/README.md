# Shared audio policy visits checkpoint

Base HEAD:43cf0e654db44e5380ea22d0d43bb0489f48495b.
The final source patch changes ten Audio files. All ten staged source files
match the isolated published runtime byte for byte; main retains unrelated
general-Split/index WIP. Main guards1408 inputs and the isolated run1180.

Final verified library counts are231 main and214 isolated. Complete main
Audio definition passes171; enabled stages pass203 with seven unfinished
generalSplit cases filtered. Isolated historical birth/processing PCM passes8.
All have zero failed/ignored; the eight-test subset filters163 other tests.
Strict2 is the successful formatting/four-crate strict all-target lint check.
Original Strict retains its test-only manual_bits failure. Equivalent exact
eight-word array-size assertion correction changes no production source.
Final main/isolated binaries are rebuilt and copied from Cargo JSON inventory.

regression-summary.json verifies exact counts, final input hashes and executed
binary pins. Evidence-path-correction records the recorder's relative/absolute
key mismatch and correction; it changes neither hashes nor results.

Runtime population still comes from actual reads. Root final-policy and per-phase
visitors/carrier are production code, but complete cold policy population,
whole demand traversal, recursive resource proof and batching remain owed.
The preceding four-pass/three-work-failure Split matrix is historical, not rerun.
No requirement or gate closes.

Main owns Cargo and all executable receipts. Workers wrote frozen scratch
candidates only; independent review found no supported runtime regression.
raw-policy/next-wiring.md is a read-only design with scope/identity/billing and
planned-versus-observed permission oracle constraints, not implemented evidence.
