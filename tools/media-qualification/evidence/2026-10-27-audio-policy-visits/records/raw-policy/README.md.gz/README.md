# Raw final-policy borrowed visitor candidate

Frozen candidate: candidate.patch, SHA-256
880bb34d18d5c553439aaafe5b15295be11f1d6c60a9d5cab296183e42a1e5aa.

Base HEAD captured at copy: 43cf0e654db44e5380ea22d0d43bb0489f48495b.
before-manifest.json pins the copied inputs. after-manifest.json pins every
candidate source file. Apply against current text with normal conflict review;
do not replace the whole live stages.rs from this scratch copy.

## Implemented boundary

stages.rs::read_queries_borrowed now calls raw_policy::apply at the exact old
final policy boundary, after processing spans produce PCM and before creative
fades and the final control.check().

raw_policy::visit is allocation-free and borrowed. It dispatches flattened-span
SilentHold, retained-envelope, exhaustion and explicit suppressed range events.
Production consumes those same events, so a future cold consumer will not
hand-copy final policy selection. Numeric retained-envelope work stays in the
production callback at its previous position. Exhaustion uses the same checked
arithmetic in edges.rs::exhausted_range_slots, returning at most two fixed slots
instead of a collected temporary. Edges unit tests retain a test-only collector.

The adapter preserves these boundaries:

- Each flattened-span control check occurs before that span's work.
- SilentHold bypasses retained-envelope arithmetic, zeroes the same samples and
  contributes suppression.
- A non-SilentHold span applies canonical retained-envelope PCM before evaluating
  exhaustion. A numeric-envelope error wins over exhaustion or later policy.
- Every explicit policy range is validated before any explicit policy zeroing.
  Two borrowed passes replace the old temporary offsets collection.
- Creative fades still execute after final raw policy. Numeric zero from a
  creative fade supplies no permission bit.
- No processing-child mask union or inference from policy.contents.
  An independent occurrence with no flattened spans receives no Original
  endpoint exhaustion.

The private adapter now returns Range on malformed flattened offsets that could
previously panic during slicing or overflow in unchecked subtraction. This is a
checked malformed-private-input behavior change, not an identical-error claim.
Valid admitted query behavior and old work/check locations are preserved.

## Accounting contract

Production passes a no-op charge hook: this replaces its existing single final
walk and adds no planning traversal or plan-work charges. Existing output
suppressed/exhausted Vec allocations remain. This patch makes no allocator-slack,
resource-limit, residency or performance claim.

A future cold caller must supply charge with its real WorkControl billing,
before the extra metadata visits, and separately admit its carrier/callback
storage and query construction. The hook is called before each flattened record
validation, flattened metadata event, explicit policy record validation and
explicit policy emission. Refused/failed visits keep charges already performed.
There is no refund or silent fallback accounting waiver. Tests pin successful
and failed partial counts; they do not waive query-construction work.

A metadata consumer ignoring RetainedEnvelope can obtain masks without numeric
PCM execution. Success assumes independent numeric validation would pass. It
does not validate the envelope's complete structure, all PCM, source admission,
provider access, absence of intrinsic preparation or temporal resource bounds.

## Remaining domain and exact reuse points

This is root final-policy groundwork only. It does not implement cold routed,
retained, signal, bound, point-domain, Stage or Projected adapters, the bounded
256-frame permission carrier, temporal demand recursion or runtime batching.

The next adapter should share production metadata transfer operations:

- stages.rs::read_signal_queries has explicit policy suppression and no
  separate exhaustion output.
- voice_occurrence.rs::source_occurrence_queries deliberately has no Original
  flattened spans. It selects the voice's own policy.
- retained_sound_input.rs::occurrence_raw_queries has empty flattened spans;
  explicit silence policy is separate from Original exhaustion.
- routed.rs::read_root_source_query_borrowed permits only source/silence leaves;
  silence spans suppress. read_routed_root_borrowed marks route gaps and
  integer-shifts child suppression; it does not forward child exhaustion as an
  independent exhaustion channel.
- projected_root.rs::read_projected_root_controlled applies domain.policy.
  Reject actual unsupported projected forms at the cold boundary even when the
  Plan intrinsic query reports NotRequired.
- stages.rs::read_retained_controlled, read_bound_at,
  read_point_domain_controlled and read_domain_controlled can introduce exact
  policy transfers. signal_transfer.rs helpers point_boundary, mark_interval,
  mark_outside_support and validate_root_block contain canonical point-ceil
  pullback and support policy. Share/factor those before claiming cold masks.
  Child suppression applies before interpolation and output policy afterward;
  rounded endpoints or ordinary child unions lose this.
- shared_eq.rs::permitted rejects suppressed or exhausted samples. add_sound
  permission additionally requires the admitted sound id and nonzero event fade
  length. Numeric fades/gains and source zeros do not establish these permissions.

Real PCM readers still owe source/provider admission. Unsupported
Stage/Projected/query-boundary forms should remain fail-closed in the first
eligibility domain. Nothing here closes generalSplit or grants an estimate waiver.

## Verification

Only rustfmt +1.97.1 --edition 2024 --config skip_children=true and source/diff
review ran. No Cargo, rustc, native/media/provider execution, live checkout
writes, commits or pushes. Parent owns compilation and integration checks.

Five focused unit tests:

1. Literal event order, mask intervals, bit-exact PCM including negative zero,
   exact cold charge count and production no added charge.
2. Later invalid policy cannot zero an earlier valid range; invalid validation
   stays billed and no policy events have emitted.
3. Retained callback/numeric errors precede exhaustion and policy.
4. Creative zero and policy.contents cannot invent masks; empty Original
   flattened spans do not mask an independent occurrence.
5. Exact work budget succeeds; one-short refuses with prior work retained;
   cancellation at the old flattened check emits nothing.
