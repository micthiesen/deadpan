# Next wiring: pre-PCM contribution permissions

Read-only design, 2026-10-27. No source changes or Cargo. This describes wiring
still to implement, not implementation evidence, acceptance or a resource proof.
The integrated 231-lib-test result was supplied by main, not rerun here.

## Preferred next unit

Populate the existing Components permission carrier for one current chunk from
its actual prepared inputs, after route/voice/family discovery and before
mix.allocate or any Original/source/event-return PCM read. Keep every descendant
scalar until the separate cold-demand interpreter and full admission are done.

Use the real current-chunk routes built by shared_eq.rs::read_shared_program.
Do not construct a second owner graph, fake ReadBlock, fake provider or PCM.
At present Components::allocate_policy exists, but SharedMix has no forwarding
API and Components has no public metadata mark method. Add the smallest
SharedMix/Components forwarding boundary for policy-only allocation and marking
a real shared_mix::Route's component id. Respect ignored routes; validate offset
against the real route interval exactly as Components::add does. Existing
SharedMix::add_wide and Components::add must retain their finite PCM checks and
normal marking. Pre-marking never authorizes sample reads or makes invalid PCM
finite.

Where: shared_eq.rs::read_shared_program, immediately after allowed_aliases and
include_output_aliases are computed, before reservation/make_room/mix.allocate
and the result closure. That is the first point with all real route identities,
owner support, selected sound ids and aliases. Preparation of roots/beats has
not opened media. The metadata walk must bracket with control.check(), including
an empty visit, and discard every partially populated carrier on error.

This location currently follows prepare_sound_processing_plans_in_context,
prepare_beat_sounds, prepare_root_sounds, Context::owners, route construction and
family registration. Reuse all those exact results rather than evaluating them
again. Their existing billed work stays; charge the additional metadata visits
and carrier population. Separately admit carrier payload before allocate_policy;
do not use full Components::resident_frames as permission to allocate PCM before
the eventual complete temporal resource bound.

## Permission formula, shared with the real producer

Original per owner span: route present AND admitted(original_id) AND
span.support()==AudioOwnerSupport::Active AND final raw suppression/exhaustion
does not contain at. Route absence currently comes from original_is_silent().
Inactive-support nonzero PCM remains a runtime error checked by the existing
read; the metadata gate does not replace it.

Sound: route active AND admitted(id) AND event gate span.length!=0 AND final raw
suppression/exhaustion does not contain at. The exact gate spans already live in
PreparedSoundQuery.fades or PreparedOccurrence.fades. Validate partition/coverage
with the existing validate_gate_envelopes boundary. Do not evaluate edge_gain
to establish permission. Creative fade zero, trim, post-gate numeric zero,
source zeros and tail return values do not remove these metadata permissions.
Post gates do not replace the input permission formula.

Carrier population needs one missing operation: SamplePermissions currently
only marks positive bits. Prefer a checked clear-range counterpart using the
same route/offset validation, rather than fabricate sample values or repeatedly
revisit a query for each output sample. Start each route row at zero, mark only
its admitted support/gate samples with billed visits, then clear exactly the raw
suppressed/exhausted intervals reported by the shared metadata adapters. Clip to
that route's checked contribution interval on the common chunk grid; do not
extend to siblings or outside support. Numeric production add can later OR the
same successful bits, preserving current finite-check boundaries, but that
combined carrier is NOT an independent runtime oracle. SharedMix::add_wide
currently returns immediately for route.ignored or voice=None; it never clears
a predicted true bit on those paths. Components::add only marks a positive bit
after both-channel finite checks. Consequently comparing the prefilled row with
the row after rendering can conceal predicted-true/actual-false bugs, and an
actual positive OR can conceal predicted-false/actual-true bugs if the saved
prediction is not separately preserved.

Future verification must either compare each actual permission decision with
the planned bit BEFORE SharedMix::add_wide's ignored/voice=None early returns,
including negative decisions, or build a separately admitted, initially empty
observed carrier and compare it against an untouched planned carrier. A
per-decision comparison must preserve the actual producer's finite-check/error
boundaries: an invalid PCM call cannot become a successful observation. Decisions
skipped entirely by Original/add_sound producer loops need explicit coverage or
the separate observed row comparison, so unvisited predicted positives cannot
survive unnoticed. Shared canonical predicates for planning and production are
still appropriate, but tests must independently exercise raw policy adapters;
sharing a predicate does not validate a mistaken adapter.

On any metadata error discard the whole provisional carrier, including already
marked bits. Reusing the same carrier requires an explicit clear/reset step so
fallback/failed attempts cannot leave stale positive bits. This is a future
wiring/oracle pitfall, not a current runtime bug: cold population is not
implemented.

The admitted closure in shared_eq.rs already combines program.allowed and
split_family_aliases. Reuse it. Do not infer aliases from sound ids/names.
Original support/selection checks and sound gate checks should be factored as
small common metadata predicates used both by cold population and existing
Original/add_sound producer loops. Otherwise two bool formulas will drift.

## Already prepared sound inputs

1. Root Direct: sound_events.rs::PreparedSoundInput::Direct owns
   AudioSignalQuery<'plan> and AudioPolicyQuery<SignalSample>. prepare_root_sounds
   constructs/bills/preflights them before PCM. read_prepared_root_sound later
   moves those same values into read_signal_queries. Pre-PCM metadata only needs
   policy.suppressed, validated on signal.labels; convert by exact i64 label
   identity into AudioSample, as the real reader does. There is no independent
   exhaustion channel here. Do NOT add suppression from arbitrary signal leaf
   Silence: the production signal output's final policy is authoritative.
   Factor validation/borrowed range enumeration from apply_suppression, or add a
   shared typed borrowed policy-range visitor actually consumed by the signal
   reader; do not copy its checked subtraction/whole-list validation.

2. Current occurrence: beat_sounds.rs::PreparedBeatInput::Current owns
   Box<RootReadQueries<'plan>>. prepare_beat_sounds calls
   voice_occurrence.rs::source_occurrence_queries once. That query intentionally
   has empty flattened.spans, voice.processing and voice.policy, fades None.
   Borrow queries.as_borrowed() into raw_policy::visit before PCM and then let
   read_prepared_beat_sound consume the same box. No Original envelope mask may
   leak into this independent voice. For cold visit supply real extra-work
   charging; ignoring RetainedEnvelope is unnecessary for current occurrence
   because its flattened spans are empty.

3. Routed root or occurrence: PreparedSoundInput::Routed and
   PreparedBeatInput::Routed own routed.rs::PreparedRoutedRootQuery<'history>.
   preflight_routed_root already retained each destination, exact old range and
   PreparedRetainedSoundInput for every non-gap route span. Add a borrowed policy
   visitor on PreparedRoutedRootQuery; it must walk these stored spans, not call
   domain.route().query again. old=None emits destination suppression. For
   old=Some, borrow span.input and visit its final input suppression, then map
   both labels through routed.rs::shift_label(label,old.start,destination.start).
   The real read_routed_root_borrowed copies this suppression and returns
   exhausted empty; do not independently forward input.exhausted. Share this
   mapping/validation dispatch with the real reader instead of a second route
   implementation. Existing preflight/admit-retained-source work is not waived.

4. PreparedRetainedSoundInput has private start/frames/raw fields. Keep traversal
   in retained_sound_input.rs rather than exposing internal graphs. Source input
   has stored raw AudioProcessingQuery and read_root_source_query_borrowed
   suppresses exactly Leaf(Silence) spans, rejecting every non-source/non-silence
   form. Occurrence input uses occurrence_raw_queries(raw): empty flattened
   spans plus suppression for processing Leaf(Silence), then read_queries.
   Factor that leaf classification and interval visit for both production
   policies; do not allocate occurrence_raw_queries' suppression Vec solely for
   the cold inspection. Reuse raw samples/start/frames for range validation.
   These are final policies of these specific raw-read forms, not child-mask
   union rules. Both have no exhaustion at this output boundary.
   Projected input has raw=None: prepare_retained_sound_query currently discards
   the policy after preflight, and the reader queries/prepares projected PCM
   later. First cold domain must reject this actual input enum before processing
   it; do not approximate from the Plan intrinsic capability result.

## Original preparation split and cache

shared_eq/original_inputs.rs::shared_original_input currently has no prepared
query argument. A cache miss calls read_controlled, read_context_controlled or
read_retained_controlled. Context Root/Domain construct all queries inside those
calls. Entry stores immutable Context, exact samples, depth, lookup links and a
payload key; Cached stores Arc<ReadBlock> and accounted resident size. No entry
stores query metadata or a separate cold policy proof.

Minimum honest split:

- Factor the existing Root and Domain query construction into one borrowed
  current-request preparation helper, returning RootReadQueries<'plan> with
  flattened, processing, policy and fades. Use graph.plan for Root and the
  existing captured AudioDomain for Domain; preserve edge_fades=true. Preserve
  validation, checked end/range, query order and spend_plan_work(query.work).
- Keep that owned query local to read_shared_program's current chunk, next to
  roots/beats/owners. Borrow it into raw_policy::visit before PCM. Validate actual
  unsupported processing forms under the first eligibility gate; no authored
  node-only inference or warm-history exemption.
- Allow shared_original_input to receive this optional prepared request. On its
  cache miss consume/borrow it through read_queries_borrowed instead of calling
  read_controlled/read_context_controlled and rebuilding queries. Cache insertion,
  optional memoization, eviction, dependency accounting and PCM admission retain
  their current behavior. Existing readers without an attempted cold path keep
  their current no-prepared-query branch.
- On a cache hit, policy still comes from the fresh chunk-local metadata request.
  Reuse cached PCM only through the current full Context/range/depth/scope key
  checks, relative-depth check and live fingerprint validation. Do not use the
  existence of cached output or cached masks as the cold-demand proof.

Thus each attempted cold chunk constructs Original metadata once and reuses it
on a miss. A previous PCM-cache hit used to construct zero queries; the attempted
cold path now has one genuinely additional metadata construction and must bill
it. This is not a duplicate re-query. If fallback follows a cold attempt, retain
that same local prepared query through the fallback read rather than query again;
never refund spent work. A complete fallback that was never eligible can keep
the present scalar/cache path.

There is no honest way for the CURRENT cache to supply independent cold policy
on a hit without either this metadata work or retaining extra evidence: it
contains only output masks and identity. Avoid claiming otherwise. A future
alternative is separately admitted fixed scalar policy bits in Entry, captured
by the same pre-PCM visitor when inserting, with exact Context/range/depth/scope
identity. That is new metadata retention and an accounting extension, not a
query cache, and is unnecessary for the first wiring. Fresh Graph/empty-cache
execution must still perform the full proof, so no qualification may depend on
warm evidence. Do not pin ReadBlock Arc just to inspect masks across descendant
reads: that defeats current eviction behavior and changes residency.

Context::Retained is not RootReadQueries. read_retained_controlled calls
read_bound_at(input.bound(), input.reference_at(start)), rebases relative
suppression to current output labels and returns exhausted empty. A first
implementation should explicitly reject this Context on BOTH cold and warm
paths until its exact transfer-policy adapter exists. Domain/Root may have
Bound processing children; final raw policy is still the outer RootReadQueries'
policy, but the separate preparation/resource eligibility must inspect or
conservatively reject unsupported child processing before claiming closure.

## Lifetimes and no self-reference

Graph<'plan>::plan is borrowed from the local plan Arc in read_shared_input.
Root queries can borrow graph.plan for 'plan. AudioDomain<'plan>::processing
explicitly returns AudioProcessingQuery<'plan>, not a query tied to the temporary
borrow of the domain Arc (audio_domain.rs::processing). Therefore preparing a
local query from Context::Domain does not require self_cell or storing an owner
Arc beside a query that borrows that same struct field. Context Arc identity
remains the original cache key; a node id is no substitute.

RootSound inputs borrow graph.plan. Current occurrence inputs borrow graph.plan
and own their query Vecs. Historical routed queries borrow RenderPlans in local
SoundProcessingPlans retained; the beat input separately owns an Arc for
with_plan_scope during playback. Do not shorten/drop retained before beats or
move borrowed historical graphs into Graph. A metadata visitor borrows one
PreparedRoutedRootQuery for its call and retains only carrier bits/checked scalar
counts. It must finish before moving occurrences into read_prepared_beat_sound.
No plan pin/query cache is needed across chunks.

## Still not a temporal allocation bound

Pre-populated route bits let the existing shared_components visitors inspect
real temporal callback permission sets without route.pcm. They do not by
themselves enumerate the scalar descendant read_shared_program invocations,
construct their contexts/queries, admit filters/event returns/native histories,
or bound output buffers and overlapping residency. A later pure demand driver
must share actual Components stage/owner sequencing and fold/drop each
descendant's metadata, force descendants scalar, charge every visit and return a
complete conservative bound before current batch PCM/native allocation.

Eligibility may return conservative unknown and preserve scalar fallback.
Every additional failed/unknown proof keeps actual work billed. Resource
estimates cannot waive existing limit or source checks. Full generalSplit goal
and scalar behavior remain required.

## Focused verification once implemented

- Preserve every planned permission row pre-PCM. Compare each actual positive
  AND negative decision before SharedMix early return, with complete coverage,
  or use an independently populated observed carrier with separate admission.
  Do not compare a prefilled carrier with its own post-render OR updates.
  Cover cold Root, captured Domain, root Direct, current occurrence and routed
  Source/Occurrence, exact supports/negative labels, route gaps, silence and gate
  length zero. Assert deliberate raw-adapter false positives and false negatives
  are detected. No fake-provider planner.
- A cache hit and cold miss yield identical planned bits; cold miss performs one
  Original metadata construction, actual miss consumes the same query; cache hit
  retains fingerprint/index/depth rejection and does not turn unsupported
  Context::Retained into an eligible path.
- Direct-signal Silence does not invent mask bits beyond policy; routed
  occurrence gets its own silence-only policy; no Original exhaustion union.
- Exact/one-short extra visit budget, cancellation at empty boundaries and late
  malformed suppression discard partial carriers and retain spent work.
- Neither source admission nor finite PCM validation is bypassed. Admit actual
  carrier storage before allocation; preserve no-PCM cold callback traces and
  reject unsupported Stage/Projected boundaries without a warm-cache exception.
