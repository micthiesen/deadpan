from pathlib import Path
import gzip
import hashlib
import json

s = Path(__file__).resolve().parent
dest = Path('/Users/michael/Code/deadpan/tools/media-qualification/evidence/2026-10-27-audio-policy-visits')
assert not dest.exists(), 'refuse evidence overwrite'
summary = json.loads((s / 'regression-summary.json').read_text())
assert summary['all_sources_and_executed_binaries_stable']
assert all(json.loads((s / 'published-scoped-equality.json').read_text()).values())
allowed = {'.json', '.py', '.md', '.patch', '.txt', '.stdout', '.stderr'}
paths = [p for p in s.iterdir() if p.is_file() and p.suffix in allowed
         and p.name != 'qualification-draft.md']
for folder in ['raw-policy', 'components']:
    paths.extend(p for p in (s / folder).iterdir() if p.is_file() and p.suffix in allowed)
changed = json.loads((s / 'changed-files.json').read_text())
paths.extend(s / 'before' / name for name in changed['changed'])
dest.mkdir(parents=True)
files = []
for p in sorted(set(paths)):
    data = p.read_bytes()
    compressed = gzip.compress(data, mtime=0)
    out = dest / 'records' / (str(p.relative_to(s)) + '.gz')
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_bytes(compressed)
    files.append(dict(path=str(out.relative_to(dest)), bytes=len(compressed),
                      sha256=hashlib.sha256(compressed).hexdigest(), expanded_bytes=len(data),
                      expanded_sha256=hashlib.sha256(data).hexdigest()))
inventory = dict(schema_version=1, base_revision='43cf0e654db44e5380ea22d0d43bb0489f48495b',
    scope='Ten-file production root final-policy adapter plus Components admitted permission carrier and temporal phase visitors. Fourteen new tests. No complete cold population, whole demand walker, recursive resource proof or batching. Main retains inherited Split/index WIP; all ten published files match the isolated runtime exactly. Seven unfinished Split tests filtered; historical four pass/three work failures is not a fresh matrix result. Original test-only Clippy failure and equivalent correction retained.',
    prior_runtime_evidence=dict(path='../2026-10-27-intrinsic-capability/inventory.json',
        inventory_sha256='a6eac23f267c6a7eb5a4415e705683f863dadc65ac3d390375c8101240499375',
        note='No copied workspace or executable bytes; source manifests, changed-file before snapshots and exact task patches retained.'),
    files=files)
out = dest / 'inventory.json'
out.write_text(json.dumps(inventory, indent=2) + '\n')
for row in files:
    data = (dest / row['path']).read_bytes()
    expanded = gzip.decompress(data)
    assert len(data) == row['bytes'] and hashlib.sha256(data).hexdigest() == row['sha256']
    assert len(expanded) == row['expanded_bytes'] and hashlib.sha256(expanded).hexdigest() == row['expanded_sha256']
result = dict(payloads=len(files), stored_bytes=sum(r['bytes'] for r in files),
              expanded_bytes=sum(r['expanded_bytes'] for r in files),
              inventory_sha256=hashlib.sha256(out.read_bytes()).hexdigest())
(s / 'evidence-result.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result, indent=2))
