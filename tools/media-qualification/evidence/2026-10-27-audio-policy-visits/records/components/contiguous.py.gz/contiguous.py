from pathlib import Path
b=Path('/tmp/deadpan-policy-visitor-2026-10-27/components/source/crates/deadpan-audio/src')
p=b/'shared_components.rs';s=p.read_text()
s=s.replace('    permitted: permissions::SamplePermissions,\n','')
s=s.replace('            permitted: permissions::SamplePermissions::new(self.frames),\n','')
old="    routes: Vec<Route<'plan>>,\n";assert s.count(old)==1;s=s.replace(old,old+'    permitted: permissions::SamplePermissions,\n')
old='            routes: Vec::new(),\n';assert s.count(old)==1;s=s.replace(old,old+'            permitted: permissions::SamplePermissions::new(frames as usize),\n')
start=s.index('        let (prepared_gain_bytes, policy_heap_bytes) =')
end=s.index('        let per_route =',start)
s=s[:start]+'''        let prepared_gain_bytes = self.routes.iter().try_fold(0usize, |total, route| {
            total
                .checked_add(Program::resident_bytes(route, &self.owners, self.send)?)
                .ok_or(StageAudioError::Limit("contribution gain residency"))
        })?;
        let policy_bytes = self.permitted.resident_bytes(self.routes.len())?;
'''+s[end:]
old='''    pub(super) fn allocate(&mut self) {
        for route in &mut self.routes {
            route.permitted.allocate();
            route.pcm = vec![Sample::default(); self.frames];
        }
    }'''
new='''    /// Admit resident_frames before allocating policy or PCM. Policy can be
    /// populated independently first; allocating PCM preserves those marks.
    pub(super) fn allocate_policy(&mut self) {
        self.permitted.allocate(self.routes.len());
    }

    pub(super) fn allocate(&mut self) {
        self.allocate_policy();
        for route in &mut self.routes {
            route.pcm = vec![Sample::default(); self.frames];
        }
    }'''
assert s.count(old)==1;s=s.replace(old,new)
old='''        let route = &mut self.routes[route];
        if !route.samples.contains(&at) {'''
new='''        let id = route;
        let route = &mut self.routes[id];
        if !route.samples.contains(&at) {'''
assert s.count(old)==1;s=s.replace(old,new)
s=s.replace('        route.permitted.mark(at)?;','        self.permitted.mark(id, at)?;')
s=s.replace('self.routes[id].permitted.contains(at)','self.permitted.contains(id, at)')
s=s.replace('route.permitted.contains(at)','self.permitted.contains(id, at)')
# The only terminal immutable route loop needs the route index for policy.
s=s.replace('''                    for route in &self.routes {
                        if self.permitted.contains(id, at)''','''                    for (id, route) in self.routes.iter().enumerate() {
                        if self.permitted.contains(id, at)''')
# New EQ phase borrows the separate policy carrier, never route PCM.
s=s.replace('''                                    owner,
                                    at,
                                    sample,''','''                                    owner,
                                    permitted: &self.permitted,
                                    at,
                                    sample,''')
p.write_text(s)
p=b/'shared_components/block.rs';s=p.read_text()
s=s.replace('''    fn transfer_block(&mut self, control: WorkControl<'_>)''','''    fn transfer_block(&mut self, permitted: permissions::PermissionRow<'_>, control: WorkControl<'_>)''')
s=s.replace('''        event_input: bool,
        control:''','''        event_input: bool,
        permitted: permissions::PermissionRow<'_>,
        control:''')
s=s.replace('self.permitted.contains(at)','permitted.contains(at)')
s=s.replace('self.routes[id].permitted.contains(at)','self.permitted.contains(id, at)')
s=s.replace('self.routes[member].permitted.contains(at)','self.permitted.contains(member, at)')
s=s.replace('route.permitted.contains(at)','self.permitted.contains(id, at)')
# route top-level sends require index; old body and order remain.
s=s.replace('''        for route in &mut self.routes {
            if self''','''        for (id, route) in self.routes.iter_mut().enumerate() {
            if self''')
s=s.replace('route.send_block(&mut outputs[0].samples, true, control)?;','route.send_block(&mut outputs[0].samples, true, self.permitted.row(id), control)?;')
s=s.replace('self.routes[id].transfer_block(control)?;','self.routes[id].transfer_block(self.permitted.row(id), control)?;')
s=s.replace('self.routes[id].send_block(&mut outputs[0].samples, false, control)?;','self.routes[id].send_block(&mut outputs[0].samples, false, self.permitted.row(id), control)?;')
# final route transfer walk also needs id, without a second traversal.
s=s.replace('''        for route in &mut self.routes {
            if requested''','''        for (id, route) in self.routes.iter_mut().enumerate() {
            if requested''')
s=s.replace('route.transfer_block(control)?;','route.transfer_block(self.permitted.row(id), control)?;')
s=s.replace('''                for route in &self.routes {
                    if self.permitted.contains(id, at)''','''                for (id, route) in self.routes.iter().enumerate() {
                    if self.permitted.contains(id, at)''')
s=s.replace('''                                owner,
                                at,
                                sample:''','''                                owner,
                                permitted: &self.permitted,
                                at,
                                sample:''')
p.write_text(s)
p=b/'shared_components/visitors.rs';s=p.read_text()
s=s.replace("    pub(super) owner: &'a Owner<'plan>,\n","    pub(super) owner: &'a Owner<'plan>,\n    pub(super) permitted: &'a permissions::SamplePermissions,\n")
s=s.replace('if route.permitted.contains(phase.at) {','if phase.permitted.contains(id, phase.at) {')
p.write_text(s)
print('Contiguous post-admission payload integrated in scratch only.')
