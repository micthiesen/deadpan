from pathlib import Path
base=Path('/tmp/deadpan-policy-visitor-2026-10-27/components/source/crates/deadpan-audio/src')
p=base/'shared_components.rs';s=p.read_text()
old='''                        for &(id, _) in &owner.members {
                            let route = &mut self.routes[id];
                            let frame = &mut route.pcm[at];
                            if frame.permitted {
                                frame.value = if eq {
                                    equalize(
                                        eq_clock.as_ref().ok_or(PlanError::InvalidPlan(
                                            "shared EQ has no admitted clock",
                                        ))?,
                                        Temporal::Equalizer(stage),
                                        sample,
                                        permissions,
                                        Some(route.voice),
                                    )?
                                } else if count == 1 {
                                    let saturation = saturation.ok_or(PlanError::InvalidPlan(
                                        "contribution saturation absent",
                                    ))?;
                                    sum.map(|value| saturation.shape(value))
                                } else {
                                    std::array::from_fn(|ch| frame.value[ch] * factor[ch])
                                };
                                if frame.value.iter().any(|value| !value.is_finite()) {
                                    return Err(PreparationError::InvalidSamples.into());
                                }
                            }
                        }'''
new='''                        if eq {
                            visitors::visit_equalizer(
                                &mut self.routes,
                                visitors::EqualizerPhase {
                                    owner,
                                    at,
                                    sample,
                                    stage,
                                    permissions: &permissions,
                                    clock: eq_clock.as_ref(),
                                },
                                |_, route, request| {
                                    let frame = &mut route.pcm[at];
                                    frame.value = request.read(&mut equalize)?;
                                    if frame.value.iter().any(|value| !value.is_finite()) {
                                        return Err(PreparationError::InvalidSamples.into());
                                    }
                                    Ok(())
                                },
                            )?;
                        } else {
                            for &(id, _) in &owner.members {
                                let route = &mut self.routes[id];
                                if route.permitted.contains(at) {
                                    let frame = &mut route.pcm[at];
                                    frame.value = if count == 1 {
                                        let saturation = saturation.ok_or(PlanError::InvalidPlan(
                                            "contribution saturation absent",
                                        ))?;
                                        sum.map(|value| saturation.shape(value))
                                    } else {
                                        std::array::from_fn(|ch| frame.value[ch] * factor[ch])
                                    };
                                    if frame.value.iter().any(|value| !value.is_finite()) {
                                        return Err(PreparationError::InvalidSamples.into());
                                    }
                                }
                            }
                        }'''
assert s.count(old)==1;s=s.replace(old,new)
old='''                        for effect in [
                            deadpan_core::TailEffect::Reverb,
                            deadpan_core::TailEffect::Delay,
                        ] {
                            if let Some(level) = sends.level(effect) {
                                let wet = equalize(
                                    clock.as_ref().ok_or(PlanError::InvalidPlan(
                                        "wet return has no admitted clock",
                                    ))?,
                                    Temporal::Wet(effect),
                                    sample,
                                    wet_permissions,
                                    Some(route.voice),
                                )?;
                                let wet = route.send_sample(
                                    &authored_gain::GainSum::default(),
                                    wet,
                                    level,
                                    control,
                                )?;
                                for (out, input) in route.pcm[at].value.iter_mut().zip(wet) {
                                    *out += input;
                                }
                                if route.pcm[at].value.iter().any(|x| !x.is_finite()) {
                                    return Err(PreparationError::InvalidSamples.into());
                                }
                            }
                        }'''
new='''                        visitors::visit_wet_effects(
                            visitors::WetPhase {
                                sample,
                                permissions: &wet_permissions,
                                clock: clock.as_ref(),
                                voice: route.voice,
                                sends,
                            },
                            |level, request| {
                                let wet = request.read(&mut equalize)?;
                                let wet = route.send_sample(
                                    &authored_gain::GainSum::default(),
                                    wet,
                                    level,
                                    control,
                                )?;
                                for (out, input) in route.pcm[at].value.iter_mut().zip(wet) {
                                    *out += input;
                                }
                                if route.pcm[at].value.iter().any(|x| !x.is_finite()) {
                                    return Err(PreparationError::InvalidSamples.into());
                                }
                                Ok(())
                            },
                        )?;'''
assert s.count(old)==1;s=s.replace(old,new);p.write_text(s)
p=base/'shared_components/block.rs';s=p.read_text()
s=s.replace('''                        if frame.permitted {
                            count += 1;''','''                        if self.routes[id].permitted.contains(at) {
                            count += 1;''')
old='''                    for &(id, _) in &owner.members {
                        let route = &mut self.routes[id];
                        let frame = &mut route.pcm[at];
                        if frame.permitted {
                            frame.value = if eq {
                                equalize(
                                    eq_clock.as_ref().ok_or(PlanError::InvalidPlan(
                                        "shared EQ has no admitted clock",
                                    ))?,
                                    Temporal::Equalizer(stage),
                                    AudioSample(self.start.0 + at as i64),
                                    permissions,
                                    Some(route.voice),
                                )?
                            } else if count == 1 {
                                let saturation = saturation.ok_or(PlanError::InvalidPlan(
                                    "contribution saturation absent",
                                ))?;
                                sum.map(|value| saturation.shape(value))
                            } else {
                                std::array::from_fn(|ch| frame.value[ch] * factor[ch])
                            };
                            if frame.value.iter().any(|value| !value.is_finite()) {
                                return Err(PreparationError::InvalidSamples.into());
                            }
                        }
                    }'''
new='''                    if eq {
                        visitors::visit_equalizer(
                            &mut self.routes,
                            visitors::EqualizerPhase {
                                owner,
                                at,
                                sample: AudioSample(self.start.0 + at as i64),
                                stage,
                                permissions: &permissions,
                                clock: eq_clock.as_ref(),
                            },
                            |_, route, request| {
                                let frame = &mut route.pcm[at];
                                frame.value = request.read(&mut equalize)?;
                                if frame.value.iter().any(|value| !value.is_finite()) {
                                    return Err(PreparationError::InvalidSamples.into());
                                }
                                Ok(())
                            },
                        )?;
                    } else {
                        for &(id, _) in &owner.members {
                            let route = &mut self.routes[id];
                            if route.permitted.contains(at) {
                                let frame = &mut route.pcm[at];
                                frame.value = if count == 1 {
                                    let saturation = saturation.ok_or(PlanError::InvalidPlan(
                                        "contribution saturation absent",
                                    ))?;
                                    sum.map(|value| saturation.shape(value))
                                } else {
                                    std::array::from_fn(|ch| frame.value[ch] * factor[ch])
                                };
                                if frame.value.iter().any(|value| !value.is_finite()) {
                                    return Err(PreparationError::InvalidSamples.into());
                                }
                            }
                        }
                    }'''
assert s.count(old)==1;s=s.replace(old,new)
old='''                        for effect in [
                            deadpan_core::TailEffect::Reverb,
                            deadpan_core::TailEffect::Delay,
                        ] {
                            if sends.level(effect).is_none() {
                                continue;
                            }
                            let wet = equalize(
                                clock.as_ref().ok_or(PlanError::InvalidPlan(
                                    "wet return has no admitted clock",
                                ))?,
                                Temporal::Wet(effect),
                                AudioSample(self.start.0 + at as i64),
                                wet_permissions,
                                Some(self.routes[id].voice),
                            )?;
                            let wet = transfer
                                .next()
                                .ok_or(PlanError::InvalidPlan("wet gain checkpoint absent"))?
                                .apply_wide(wet, control)?;
                            for (out, input) in self.routes[id].pcm[at].value.iter_mut().zip(wet) {
                                *out += input;
                            }
                            if self.routes[id].pcm[at].value.iter().any(|x| !x.is_finite()) {
                                return Err(PreparationError::InvalidSamples.into());
                            }
                        }'''
new='''                        visitors::visit_wet_effects(
                            visitors::WetPhase {
                                sample: AudioSample(self.start.0 + at as i64),
                                permissions: &wet_permissions,
                                clock: clock.as_ref(),
                                voice: self.routes[id].voice,
                                sends,
                            },
                            |_, request| {
                                let wet = request.read(&mut equalize)?;
                                let wet = transfer
                                    .next()
                                    .ok_or(PlanError::InvalidPlan("wet gain checkpoint absent"))?
                                    .apply_wide(wet, control)?;
                                for (out, input) in self.routes[id].pcm[at].value.iter_mut().zip(wet) {
                                    *out += input;
                                }
                                if self.routes[id].pcm[at].value.iter().any(|x| !x.is_finite()) {
                                    return Err(PreparationError::InvalidSamples.into());
                                }
                                Ok(())
                            },
                        )?;'''
assert s.count(old)==1;s=s.replace(old,new);p.write_text(s)
print('Both engines now consume actual per-phase visitors at former callback points.')
