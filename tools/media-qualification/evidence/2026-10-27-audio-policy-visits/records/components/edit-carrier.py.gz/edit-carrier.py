from pathlib import Path
base=Path('/tmp/deadpan-policy-visitor-2026-10-27/components/source/crates/deadpan-audio/src')
p=base/'shared_components.rs';s=p.read_text()
def replace(old,new):
 global s
 assert s.count(old)==1,(old[:90],s.count(old))
 s=s.replace(old,new)
replace('mod policy;\n','mod policy;\n\n#[path = "shared_components/permissions.rs"]\nmod permissions;\n#[path = "shared_components/visitors.rs"]\nmod visitors;\n')
replace('    permitted: bool,\n','')
replace('    pcm: Vec<Sample>,\n','    pcm: Vec<Sample>,\n    permitted: permissions::SamplePermissions,\n')
replace('            pcm: Vec::new(),\n','            pcm: Vec::new(),\n            permitted: permissions::SamplePermissions::new(self.frames),\n')
replace('''        let prepared_gain_bytes = self.routes.iter().try_fold(0usize, |total, route| {
            total
                .checked_add(Program::resident_bytes(route, &self.owners, self.send)?)
                .ok_or(StageAudioError::Limit("contribution gain residency"))
        })?;''','''        let (prepared_gain_bytes, policy_heap_bytes) =
            self.routes.iter().try_fold((0usize, 0usize), |(gain, policy), route| {
                Ok::<_, StageAudioError>((
                    gain.checked_add(Program::resident_bytes(route, &self.owners, self.send)?)
                        .ok_or(StageAudioError::Limit("contribution gain residency"))?,
                    policy.checked_add(route.permitted.heap_bytes()?)
                        .ok_or(StageAudioError::Limit("contribution policy residency"))?,
                ))
            })?;
        // The carrier lives in each Route slot, including spare Vec capacity.
        // Overflow words are admitted prospectively before their allocation.
        let policy_bytes = self.routes.capacity()
            .checked_mul(std::mem::size_of::<permissions::SamplePermissions>())
            .and_then(|bytes| bytes.checked_add(policy_heap_bytes))
            .ok_or(StageAudioError::Limit("contribution policy residency"))?;''')
replace('''            .and_then(|n| n.checked_add(prepared_gain_bytes))''','''            .and_then(|n| n.checked_add(prepared_gain_bytes))
            .and_then(|n| n.checked_add(policy_bytes))''')
replace('''        for route in &mut self.routes {
            route.pcm = vec![Sample::default(); self.frames];
        }''','''        for route in &mut self.routes {
            route.permitted.allocate();
            route.pcm = vec![Sample::default(); self.frames];
        }''')
replace('''        output.permitted = true;''','''        route.permitted.mark(at)?;''')
s=s.replace('self.routes[id].pcm[at].permitted','self.routes[id].permitted.contains(at)')
s=s.replace('route.pcm[at].permitted','route.permitted.contains(at)')
p.write_text(s)
p=base/'shared_components/block.rs';s=p.read_text()
s=s.replace('''        for frame in &mut self.pcm {
            if frame.permitted {''','''        for (at, frame) in self.pcm.iter_mut().enumerate() {
            if self.permitted.contains(at) {''')
s=s.replace('if frame.permitted {','if self.permitted.contains(at) {',2)
s=s.replace('self.routes[id].pcm[at].permitted','self.routes[id].permitted.contains(at)')
s=s.replace('self.routes[member].pcm[at].permitted','self.routes[member].permitted.contains(at)')
s=s.replace('route.pcm[at].permitted','route.permitted.contains(at)')
p.write_text(s)
print('Carrier integrated in scratch only; numerical member loops await visitor refactor.')
