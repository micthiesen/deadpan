# Components permission carrier and per-phase demand visitors

Scratch-only first candidate, frozen2026-10-27. No repository writes, Cargo, rustc, commits, worktrees or test execution. Main owns review/application/compilation and verification.

## Exact scope

before/ + before.json copy ten exact current input files. source/ contains the candidate. carrier-visitors.patch changes ONLY:
- shared_components.rs
- shared_components/block.rs
- NEW shared_components/permissions.rs
- NEW shared_components/permission_tests.rs
- NEW shared_components/visitors.rs
- NEW shared_components/visitor_tests.rs

policy.rs and existing policy/program/output tests are unchanged. shared_mix.rs, shared_eq.rs, StageAudio, raw policy, sources and native processing are untouched. Copied stages.rs is read-only context and not in the patch; main's authorized raw-policy integration changed it after the snapshot. The final audit distinguishes that read-only drift from owned source, all of which remains identical in main.

## Production carrier

Sample now contains only value/send_input stereo f64 arrays. Components owns one SamplePermissions header with frames/word stride/empty Vec during route metadata construction. No per-route flag array or heap payload is allocated before admission.

resident_frames includes that header and prospective flag payload. Normal<=256 frames need four u64 per route; existing legal1024-frame tests need16. There is no new frame cap. Empty Components allocate zero payload. One-frame routes allocate one word using vec![0u64;required], avoiding Vec::resize minimum growth from empty.

allocate_policy allocates the contiguous flag payload after resident_frames admission. Existing allocate calls it, then allocates Sample vectors in the old route loop. Metadata may populate the production carrier's mark method before Sample allocation; allocate preserves those marks. The carrier's mark is actually consumed by numerical add, not a test-only setter/API.

The first allocation uses an exact-length Vec. Same-shape reuse allocates nothing. Growth preserves old words using a replacement vector. Its prospective residency includes old capacity + new required words while copying; subsequent admission uses actual retained capacity. Capacity is counted even if words were truncated. No query graph, plan pin, gain or source handle is retained in flags.

add retains its original sample-range/control/event-gain order. It marks the bit only after both channel finite checks succeed. Existing Program activity still uses event_gain, not a new any-bit scan. Metadata marking is structural policy, not source authority or numeric success. A failed actual read still aborts; premarked flags must never excuse missing PCM/source admission.

The new fixed header lives inline with Components during route construction, like the existing metadata headers; new variable flag payload is deferred until admission. This is PCM-equivalent ownership accounting, not a new total-RSS bound. Standard Vec zero initialization and growth copying are allocation/data movement, not an added Plan/owner traversal; no canonical work weights are lowered. Existing repeated PCM allocation behavior is unchanged.

## Shared per-phase visitors, not a full walker

Both numerical engines now invoke visit_equalizer for the old EQ member loop and visit_wet_effects for their old Reverb/Delay loop. Requests carry the exact kind/stage/sample/mask/selected voice and BORROW the existing phase clock. No clock clone is performed per request. Existing clone counts remain:
- EQ: once per owner/sample;
- constant wet: once per route/sample;
- dynamic wet: the existing one combined context walk per owner/sample.

The actual callback invocation is TemporalDemand::read. A metadata consumer can instead fold the request without invoking that method or touching PCM. Tests visit with completely empty Sample vectors and actual marked metadata.

Constant and dynamic OUTER traversals remain distinct and unchanged:
- constant EQ owner/stage/sample/member;
- constant wet owner/member/sample/effect;
- dynamic sample/owner/stage/member/effect.
All gain flushes, aggregate finite checks, Program guards, wet eligibility, first-clock selection and postcallback finite checks stay at their original numerical boundaries. Explicit Tail exclusion still comes from shared policy helpers. Output selection and aliases still affect only the existing paths.

EQ visitor validates carrier shape in O(1) before inspecting members; an unallocated carrier cannot silently look wholly inactive. Allocated all-false flags are valid structural state. Wet effect visitor receives a previously selected route and prepared mask/clock, not a carrier, so its caller retains that eligibility precondition. There is no whole-policy completion token in this milestone.

Each visitor has an inspection hook:
- EQ: before EVERY member inspection, including inactive members;
- wet: before BOTH effect probes, including absent sends.
Production supplies an infallible noop, replacing the corresponding old uncharged walk without moving existing spend/check calls. A genuinely additional metadata walk can pass control.spend_plan_work(1), obtaining exact partial charges on callback/budget/cancellation errors. No extra billing traversal or refund is needed.

## Authored verification, not yet run

New filters:
- stages::shared_components::permissions::tests::
  - permission_payload_is_deferred_exact_and_preserved_across_growth
  - permission_payload_supports_existing_one_and_1024_frame_windows
  - metadata_permissions_can_precede_pcm_and_allocation_preserves_them
  - add_marks_only_after_both_finite_checks_and_preserves_event_gain_errors
- stages::shared_components::visitors::tests::
  - equalizer_phase_emits_metadata_requests_without_pcm_and_borrows_one_clock
  - wet_phase_visits_reverb_then_delay_with_exact_levels_and_borrowed_clock
  - phase_visitation_propagates_first_callback_error_without_later_requests
  - inactive_phase_does_not_require_a_clock_but_active_request_still_does
  - metadata_inspection_hooks_bill_inactive_probes_and_stop_at_the_actual_error

The existing policy bridge/literal tests, independent constant-vs-dynamic scalar PCM oracles,1024-frame unity work test, output alias/send/skip/stop/mute/overflow/cancellation/budget tests remain unchanged and should all run. New phase tests check clock pointer identity to catch per-member clones, exact effect order/levels/masks, absent-clock/refusal timing, metadata with no PCM, and billed inactive probes/partial failure.

Static checks: narrow rustfmt; full scoped diff review; no old Sample.permitted references; owned main inputs unchanged; existing numerical spend_plan_work/check call counts unchanged; added lines whitespace clean. No test pass is claimed.

## Still owed

This is the defensible per-phase API permitted by the task, NOT a complete metadata-only Components walker. A future whole traversal must choose and share the constant/dynamic schedule without copying the numerical driver, and must preserve successful upper-demand semantics when gain/finite errors shorten runtime. It must establish completed policy population before using a wholly inactive result as proof.

Cold population from raw/routed/retained/signal policy into Components is not integrated. The production carrier and per-phase methods support it internally, but this patch does not add an unused external setter or claim a complete raw adapter. Existing actual add population remains the only runtime population path.

No resource fold, batch eligibility, graph batching, prefix/PCM/query cache, source admission change, new limit or work refund is included. Admission of full cold recursive resources and actual failing-case bounds remain separate prerequisites.
