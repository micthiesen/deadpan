from pathlib import Path
import hashlib,json,re
s=Path(__file__).resolve().parent
expected={'verified-audio-lib':231,'scoped-audio-lib':214,'scoped-birth-pcm':8,'audio-definition':171,'enabled-stages':203}
summary={}
for label,count in expected.items():
 r=json.loads((s/(label+'.json')).read_text())
 assert r['exit_code']==0 and r['sources_unchanged'] and r['binaries_unchanged'],label
 text=(s/(label+'.stdout')).read_text()
 m=re.search(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out',text)
 assert m,label
 values=list(map(int,m.groups()))
 assert values[:4]==[count,0,0,0],(label,values)
 if label=='enabled-stages':assert values[4]==7,values
 frozen=json.loads((s/('scoped-frozen.json' if label.startswith('scoped-') else 'source-frozen.json')).read_text())
 if not label.startswith('scoped-'):
  frozen={str(Path('/Users/michael/Code/deadpan')/name):pin for name,pin in frozen.items()}
 assert r['source_after']==frozen,label
 summary[label]={'passed':values[0],'failed':values[1],'ignored':values[2],'filtered':values[4],'seconds':r['seconds']}
for label in ['verified-build','scoped-verified-build','strict2']:
 r=json.loads((s/(label+'.json')).read_text())
 assert r['exit_code']==0 and r['sources_unchanged'] and r['binaries_unchanged'],label
 summary[label]={'seconds':r['seconds'],'passed':True}
assert json.loads((s/'strict.json').read_text())['exit_code']!=0
for label in ['verified-build','scoped-verified-build']:
 pins=json.loads((s/(label+'-pins.json')).read_text());assert len(pins)==3
 for pin in pins:
  path=Path(pin['path']);assert hashlib.sha256(path.read_bytes()).hexdigest()==pin['sha256']
summary['all_sources_and_executed_binaries_stable']=True
summary['main_inputs']=1408;summary['isolated_inputs']=1180
summary['scope']='Fourteen new tests; root final-policy adapter and Components admitted carrier/per-phase visitors. No complete cold population/walker/resource proof or batching. Seven unfinished Split tests filtered; historical four pass/three failures is not a fresh matrix result.'
(s/'regression-summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(summary,indent=2))
