from pathlib import Path
import hashlib,json
s=Path('/tmp/deadpan-query-groundwork-2026-10-26/scoped')
c=Path('/tmp/deadpan-components-native-tests-candidate-2026-10-31')
r=Path('/tmp/deadpan-components-mask-qualification-2026-10-31')
out=Path('/tmp/deadpan-components-parent-delta-review-2026-10-31')
def pin(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  while chunk:=f.read(1024*1024):h.update(chunk)
 return {'path':str(p),'bytes':p.stat().st_size,'sha256':h.hexdigest()}
rels=[]
for patch in (c/'patches').glob('*.patch'):
 rels.append(Path(patch.read_text().splitlines()[0].removeprefix('--- a/')))
rels+=list(Path('crates/deadpan-audio/src')/n for n in ['components_mask_trace.rs','bound_reads/components_mask_native_tests.rs'])
rows=[];changed=[];unchanged=[]
for rel in rels:
 base=c/'hook-new'/rel;now=s/rel
 rows.extend([pin(base),pin(now)])
 (unchanged if base.read_bytes()==now.read_bytes() else changed).append(str(rel))
for p in [s/'crates/deadpan-audio/src/bound_reads/authored_eq.rs',s/'crates/deadpan-audio/src/point_suppression/ops_trace.rs',s/'crates/deadpan-audio/src/point_suppression.rs',c/'candidate-sha256.txt',r/'mark-repeat-proof.json']:
 rows.append(pin(p))
summaries={}
for kind in ['count','bounded','diagnostic']:
 for v in ['main','scoped']:
  for ext in ['stdout','stderr']:
   p=r/f'components-native-{kind}-{v}.{ext}'
   if p.exists():rows.append(pin(p))
  p=r/f'components-native-{kind}-{v}.stdout'
  summaries[f'{kind}-{v}']=[line for line in p.read_text().splitlines()if line.startswith('test result:')]
for n in range(1,4):
 for v in ['main','scoped']:
  p=r/f'components-mark-repeat{n}-{v}.stdout';rows.append(pin(p))
  summaries[f'repeat{n}-{v}']=[line for line in p.read_text().splitlines()if line.startswith('test result:')]
fixture=s/'crates/deadpan-audio/tests/fixtures/components-mask-baseline-v1/snapshot.json'
rows.append(pin(fixture))
results={'changed_from_frozen_native_candidate':changed,'unchanged_from_frozen_native_candidate':unchanged,'runtime_stdout_summaries_not_full_binary_audit':summaries,'before34_fixture':pin(fixture)}
(out/'source-pins.json').write_text(json.dumps(rows,indent=2)+'\n')
(out/'audit-results.json').write_text(json.dumps(results,indent=2)+'\n')
print(json.dumps(results,indent=2))
