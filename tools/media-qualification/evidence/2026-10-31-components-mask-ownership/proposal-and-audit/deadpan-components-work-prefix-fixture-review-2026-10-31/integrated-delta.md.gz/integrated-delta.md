# Integrated fixture delta review

GO for the three parent additions to candidate 777e1931. Current Scope differs only by two ample.result.is_ok() assertions and serialization of the actual ample root first_attempt receipt as measured_first_attempt. No seed injection timing, fixture, production work, or legacy replay is changed.

The corrected analyzer checks failed first-attempt work == MAX; measured ample work + initial seed == failed work; and the same real Mark index/sample. It preserves literal failure status/error, pre-count null versus absent capacity, no written bit/destination, and source cleanup. This resolves the double-seed equation identified in the prior report. Compile/native execution and fresh-run stability are still owed.

Current Scope native test SHA256: 176b31a929953fd72b3d9b3f71fcbedb5c0e948432a9cc903d1c297bd1a6e9a2.
Analyzer11 SHA256: 342a535caa005e35999e28088df469468930c770d22f2cca347d04b2d1045a1e.
