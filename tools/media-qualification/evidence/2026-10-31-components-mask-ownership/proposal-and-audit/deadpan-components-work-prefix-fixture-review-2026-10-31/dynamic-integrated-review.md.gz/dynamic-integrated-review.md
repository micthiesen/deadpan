# Corrected dynamic expectation integrated

GO for current Scope test adad3a59f4036ab71ece35379ef5e8808113292da13f9750fe626daa5a672786 and analyzer12 79f54ef53cf60c243a60aa63ec7b48a8d9a7817bb1793e9555f4d10e0f623e71. Against prior verified 176b31a9, only the gain-failure driver expectations/diagnostics and serialized expected driver change to dynamic. Ample success checks and actual measured_first_attempt remain. Analyzer12 differs from11 only in its failure expected-map driver and failure driver assertion. The measured ample + seed equation, failed-first==MAX, same index/sample, typed error and cleanup checks are intact. No production change.

Parent reports build12 native three tests pass both variants. This review inspected source/delta only; four fresh repeats and final full qualification remain owed. Build11's failed constant assumption and the earlier wet-seed failure remain separate failures.

The external scratch candidate was subsequently revised in place. To keep this review's previously pinned inputs available, source-history retains exact hash-verified reconstructions of 777e1931 and176b31a9, plus the observed current adad3a59 source. Reconstruction is labeled and is not a fabricated build receipt.
