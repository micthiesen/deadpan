# Actual driver correction after build11

The prior constant-driver static conclusion was wrong. Parent's build11 Main execution failed the new has_driver(constant) assertion before any final11 matrix/capture qualification. That runtime failure supersedes the earlier static claim; the pass from static review is not execution evidence.

The overlooked real path is shared_eq.rs Original population: mix.add(route, offset, value, event_gain=0, ...). SharedMix::add_wide forwards the selected Original route to Components::add. Components::add stores route.event_gain=Some(0). Program::prepare checks Program::constant; constant_layer rejects a ClipGain with envelopes at the Root owner's active recipe slice. finish_into therefore chooses the dynamic driver for this gain+saturation fixture. No Sound event is required.

Correct only the failure-case expected driver to dynamic. No wet sends, EQ recipe, or sounds remain, so dynamic owner gain/saturation has no temporal EQ/wet callback and the Root-only OriginalInput-key argument still applies. The real test must prove callback_count=0 and exact failed first-Mark work under the corrected driver. There is no production source change or justification to alter fees/caps.

This is a read-only source confirmation. Native success of the corrected expectation is still owed. Earlier reports remain intact, including the mistaken constant claim, so evidence does not silently rewrite history.
