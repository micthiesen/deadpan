# Classic13 analysis and complete capture join

Scratch-only tooling. No Root edits, Cargo/builds, native execution, fixture generation, cap/weight changes or old oracle edits. Original F analyze_final_capture.py and the prior join are unchanged.

New files in /tmp/deadpan-components-mask-qualification-2026-10-31:
- analyzer_classic13.py
- join_inline_qualification13.py

The independent inline all-six validator is owned by the surface agent. Its agreed aggregate interface is base_historical_analysis_by_variant (main/scoped classic13 results verbatim), full_capture_hashes (six literal canonical hash entries), and components_cases_by_capture (six variant/mode keys, each positive2/zero1/mark_refusal1). No Components receipt value is normalized.

## Why a distinct classic product

The actual pre13 Main/Scope probe full bodies are both38,529,544 bytes but have distinct SHA:
- Main09305804017016f913ae45a1e13e1db6b0a77720b8896924d74ee6d268f4df8d
- Scope4ff870f4a84e1da5d626f7e98216f9663eec3833edc7b3fa102a14b3354c89ae

pre13-cross-root-work-differences.json preserves54 literal differences, all below components_producer_cases/cases/1 (dynamic_positive), with leaf names plan_work/plan_work_before/plan_work_after/source_plan_work_before. The raw files and difference list remain unchanged. They are not cross-root byte-identical.

Removing exactly the entire additive top-level components_producer_cases from each probe and canonicalizing the remaining complete object gives the same35,593,959-byte classic body, SHA a0551013c190119e61a17e09db82a64c8807abedefab02336c01887ae126af45. This is a separate declared product, not a normalized full-body hash. Final captures must be checked afresh; the probe classic hash is evidence, not a generated expected oracle.

## Classic analyzer

CLI:
analyzer_classic13.py PREFIX --variant main|scoped --capture-directory DIR --output JSON

Each selected-variant call:
- Reads all six actual active/active2/active3 × main/scoped complete canonical bodies.
- Requires the additive Components product to exist in each, excludes exactly that top-level product, and compares every remaining field/value/counter/capacity/error byte-for-byte across all six declared classic products.
- Records all six full raw canonical path/bytes/SHA entries literally in raw_hash_manifest and computes full_raw_bodies_exact from actual hashes. It never claims old cross_root_exact for full bodies.
- Compares selected variant's current representative classic body against the same variant's real before-shared body for all744 current paired.new outputs, including264 exact Ok/480 exact Error. Outer five cases/fixture headers and operation metadata/counts are checked.
- Keeps all42 result fields of10 internal+4 public transfer cases exact, with exact result key sets and fixture names; account changes remain literal.
- Reconciles758-style interval snapshots as actual encountered, with477 completed +1 partial =478 rows and original per-row native/host/query equations. Inclusive rows are never summed as global work.
- Requires the five historical immutable canonical SHAs in both variants.
- Returns unchanged counts/output_changes/account_changes/partial_intervals fields, explicitly for the selected representative classic body, plus classic_cross_root_exact/classic_projection and raw_hash_manifest.

Representative counts are not multiplied by repeats or variants. The same six classic projections are checked globally on each per-variant invocation; this is redundant validation with distinct before/current joins, not six independent budgets merged together.

## Join13

CLI retains the prior join arguments:
join_inline_qualification13.py BUILD_LABEL MATRIX_LABEL PREFIX --capture-directory DIR --analysis AGGREGATE_JSON --matrix-summary MATRIX_JSON --source-audit AUDIT_JSON [--check-label LABEL ...]

The join retains the exact21 unique Audio-target pin/matrix coverage, real binary file bytes/SHA, Cargo manifest/qualified profile, nonempty unchanged current source/build manifests, exact command/binary before+after identities and capture provenance checks. Each raw body is canonicalized only by stripping the existing four variant/source provenance fields and is tied byte-for-byte to its actual canonical file/proof; full raw hashes are not forced equal.

It independently computes the same declared classic projection from each proof-bound current body and requires one classic bytes/SHA across six. Both base results must declare that exact product and each base raw_hash_manifest must join to the six actual proofs. The surface validator's six literal full_capture_hashes and six per-capture fixture count results are required;24 fixture validations remain distinct.

The resulting qualification reports classic_cross_root_exact and full_raw_bodies_exact separately, and preserves all six full raw hashes. It makes no old single active_sha256/cross_root_exact claim covering unequal full bodies. Ordinary multi-output, projected PreserveTape policy, exhausted vectors, PCM/dependencies and whole preparation remain outside the ownership claim.

## Verification status

Only static source/schema inspection and Python syntax compilation in memory have been done here. The two already-complete pre13 probe JSONs were read to confirm the exact54 paths and classic projection equality. No final native job or analyzer/join qualification was executed. Parent owns fresh six-capture validation and all real source/binary guards before publication.
