from pathlib import Path
from collections import Counter
import argparse
import hashlib
import json

parser = argparse.ArgumentParser()
parser.add_argument("prefix")
parser.add_argument("--variant", choices=("main", "scoped"), default="scoped")
parser.add_argument("--capture-directory", default=None)
parser.add_argument("--output", default="classic13-capture-analysis.json")
args = parser.parse_args()
s = Path(args.capture_directory).resolve() if args.capture_directory else Path(__file__).resolve().parent
capture_prefix = args.prefix

def canonical(value):
    return (json.dumps(value, sort_keys=True, separators=(",", ":")) + "\n").encode()

# The exclusion is one entire additive product, validated separately in every
# literal capture. No field inside the remaining classic body is normalized.
raw_hash_manifest = []
classic_reference = None
new = None
for mode in ("active", "active2", "active3"):
    for variant in ("main", "scoped"):
        path = s / f"{capture_prefix}-{mode}-{variant}-canonical.json"
        raw = path.read_bytes()
        body = json.loads(raw)
        assert "components_producer_cases" in body and isinstance(body["components_producer_cases"], dict)
        classic = {key: value for key, value in body.items() if key != "components_producer_cases"}
        encoded = canonical(classic)
        if classic_reference is None:
            classic_reference = encoded
        assert encoded == classic_reference, (mode, variant, "classic body differs")
        raw_hash_manifest.append({
            "mode": mode,
            "variant": variant,
            "path": str(path.resolve()),
            "bytes": len(raw),
            "sha256": hashlib.sha256(raw).hexdigest(),
        })
        if mode == "active" and variant == args.variant:
            new = classic
assert new is not None and classic_reference is not None

old = json.loads((s / f"{capture_prefix}-before-shared-{args.variant}-canonical.json").read_text())
counts = Counter()
changes = []
rows = []
before_cases = old["native_requests"]["cases"]
after_cases = new["native_requests"]["cases"]
assert len(before_cases) == len(after_cases) == 5
for i, (before, after) in enumerate(zip(before_cases, after_cases)):
    assert {key: value for key, value in before.items() if key != "operations"} == {
        key: value for key, value in after.items() if key != "operations"
    }
    assert len(before["operations"]) == len(after["operations"])
    for j, (a, b) in enumerate(zip(before["operations"], after["operations"])):
        assert {key: value for key, value in a.items() if key != "paired"} == {
            key: value for key, value in b.items() if key != "paired"
        }
        a = a["paired"]["new"]["read"]["output"]
        b = b["paired"]["new"]["read"]["output"]
        counts["native_requests"] += 1
        if a == b:
            counts["exact_" + a["status"]] += 1
        else:
            kind = a["status"] + "_to_" + b["status"]
            counts[kind] += 1
            changes.append({
                "case": i, "operation": j, "kind": kind,
                "before": a if a["status"] != "Ok" else {"status": "Ok"},
                "after": b if b["status"] != "Ok" else {"status": "Ok"},
            })

def visit(value, path=""):
    if isinstance(value, dict):
        if value.get("schema") == "native-mask-query-intervals-v1":
            assert value["active_intervals"] == value["dropped_intervals"] == 0
            assert not value["misnested"] and not value["overflow"], path
            counts["interval_snapshots"] += 1
            for row in value["rows"]:
                counts["interval_rows"] += 1
                assert row["attributable"] and not row["foreign_work_overlap"], (path, row)
                for lane_kind in ("native", "host"):
                    before = row[lane_kind + "_before"]
                    after = row[lane_kind + "_after"]
                    assert before["reset_epoch"] is not None
                    assert before["reset_epoch"] == after["reset_epoch"]
                    assert not before["overflow"] and not after["overflow"]
                claim = row["claim"]
                if claim is None:
                    counts["partial_intervals"] += 1
                    rows.append({"path": path, "partial": row})
                    continue
                counts["completed_intervals"] += 1
                assert claim["total"] == claim["canonical"] + claim["additional"]
                for lane in range(2):
                    before_phases = row["native_before"]["lanes"][lane]
                    after_phases = row["native_after"]["lanes"][lane]
                    assert len(before_phases) == len(after_phases)
                    phase = [b - a for a, b in zip(before_phases, after_phases)]
                    host = row["host_after"]["units"][lane] - row["host_before"]["units"][lane]
                    observed = row["work_after"][lane] - row["work_before"][lane]
                    assert min(phase) >= 0 and host >= 0 and observed >= 0
                    expected = (
                        claim["expected_debit"] if lane == row["selected_lane"] else 0
                    ) + sum(phase) + host
                    assert observed == expected, (path, lane, row)
        else:
            for key, item in value.items():
                visit(item, path + "/" + key)
    elif isinstance(value, list):
        for index, item in enumerate(value):
            visit(item, path + "/" + str(index))

visit(new)
assert counts["native_requests"] == 744
assert counts["exact_Ok"] == 264 and counts["exact_Error"] == 480 and not changes
assert counts["completed_intervals"] == 477 and counts["partial_intervals"] == 1
assert counts["interval_rows"] == 478

historical_hashes = {
    "before-shared": "9d6f3c67d9d611f46e75360006845a1b9419b30168a983db1ca9e4cf79c8be0a",
    "before-root": "596d738a53f6ef4cbf7870d74b3025504f6289f735ea91f4a38ed45c6661f44a",
    "before-policy": "afa6038a02c959c7192c09c08a89266c7d52151a5e59a4f69828fbdf67e7414e",
    "before-off": "af7a292718365c34fa03692e2cbe58a2cfb3c6d444b5ae29d52647e1fdbbff14",
    "before-interval": "f64d3a00a10967cc3822083d21705bd454f2d33ff2198da30e25671092ab5a53",
}
for mode, expected in historical_hashes.items():
    for variant in ("main", "scoped"):
        assert hashlib.sha256(
            (s / f"{capture_prefix}-{mode}-{variant}-canonical.json").read_bytes()
        ).hexdigest() == expected, (mode, variant)

internal_changes = []
for group, before, after in [
    ("internal", old["internal_and_transfer_paths"]["cases"], new["internal_and_transfer_paths"]["cases"]),
    ("transfer", old["internal_and_transfer_paths"]["public_transfers"]["cases"], new["internal_and_transfer_paths"]["public_transfers"]["cases"]),
]:
    assert len(before) == len(after) == (10 if group == "internal" else 4)
    for i, (a, b) in enumerate(zip(before, after)):
        assert a["name"] == b["name"]
        assert {key for key in a if key.startswith("result_")} == {
            key for key in b if key.startswith("result_")
        }
        counts[group + "_cases"] += 1
        for key in a:
            if key.startswith("result_"):
                assert a[key] == b[key], (group, i, key)
                counts[group + "_exact_output_fields"] += 1
            if key.startswith("account_") and a[key] != b[key]:
                internal_changes.append({
                    "group": group, "case": i, "name": a.get("name"),
                    "field": key, "before": a[key], "after": b[key],
                })
assert counts["internal_exact_output_fields"] + counts["transfer_exact_output_fields"] == 42

proof = {
    "schema": "components-classic13-analysis-v1",
    "capture_prefix": capture_prefix,
    "capture_directory": str(s.resolve()),
    "variant": args.variant,
    "representative_capture": f"active/{args.variant}",
    "classic_cross_root_exact": True,
    "classic_projection": {
        "excluded_top_level_keys": ["components_producer_cases"],
        "captures": 6,
        "bytes": len(classic_reference),
        "sha256": hashlib.sha256(classic_reference).hexdigest(),
    },
    "raw_hash_manifest": raw_hash_manifest,
    "full_raw_bodies_exact": len({row["sha256"] for row in raw_hash_manifest}) == 1,
    "five_historical_bodies_exact_in_both_variants": True,
    "counts": counts,
    "output_changes": changes,
    "account_changes": internal_changes,
    "partial_intervals": rows,
    "limits": (
        "The complete classic projection is identical across all six actual captures. "
        "Only top-level components_producer_cases is excluded and independently validated "
        "for all six by the inline analyzer; no values or counters inside either product "
        "are normalized. Raw full-body hashes remain literal and need not be identical. "
        "Counts and inclusive interval equations describe the selected representative "
        "classic body, never a sum of repeated or nested intervals. All historical complete "
        "outputs, capacities and errors remain exact; account changes remain literal."
    ),
}
output = Path(args.output)
if not output.is_absolute():
    output = s / output
output.write_text(json.dumps(proof, indent=2) + "\n")
print(json.dumps({
    "variant": args.variant,
    "classic_cross_root_exact": True,
    "classic_projection": proof["classic_projection"],
    "full_raw_bodies_exact": proof["full_raw_bodies_exact"],
    "counts": counts,
}))
