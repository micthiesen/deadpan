from pathlib import Path
import hashlib,json,difflib
c=Path('/tmp/deadpan-components-native-tests-candidate-2026-10-31')
s=Path('/tmp/deadpan-query-groundwork-2026-10-26/scoped')
out=Path('/tmp/deadpan-components-native-proof-review-2026-10-31')
def pin(p):
 b=p.read_bytes()
 return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
rows=[];results={}
for name in ['candidate-sha256.txt','source-sha256.txt']:
 mismatch=[];count=0
 for line in (c/name).read_text().splitlines():
  sha,path=line.split(None,1);path=path.strip()
  aliases={'reviewed-components-production-candidate.patch':Path('/tmp/deadpan-components-mask-candidate-2026-10-31/candidate.patch')}
  p=aliases.get(path) or (s/Path(path).relative_to('Scope') if path.startswith('Scope/') else (Path(path) if Path(path).is_absolute() else c/path))
  a=pin(p);rows.append(a);count+=1
  if a['sha256']!=sha:mismatch.append(path)
 results[name]={'checked':count,'mismatches':mismatch}
bad=[];patchbad=[];count=0
for patch in (c/'patches').glob('*.patch'):
 rel=Path(patch.read_text().splitlines()[0].removeprefix('--- a/'))
 p=c/'hook-before'/rel
 q=c/'hook-new'/rel
 rows.extend([pin(p),pin(q),pin(s/rel)])
 if p.read_bytes()!=(s/rel).read_bytes():bad.append(str(rel))
 name=patch.name
 proposed=''.join(difflib.unified_diff(p.read_text().splitlines(True),q.read_text().splitlines(True),fromfile='a/'+str(rel),tofile='b/'+str(rel)))
 if patch.read_text()!=proposed:patchbad.append(name)
 count+=1
results['hook_before_equal_current_scope']={'checked':count,'mismatches':bad}
results['per_file_patches_reconstruct_hook_new']={'checked':count,'mismatches':patchbad}
results['two_new_module_copies_equal']=all((c/'new'/p).read_bytes()==(c/'hook-new'/p).read_bytes()for p in [Path('crates/deadpan-audio/src/components_mask_trace.rs'),Path('crates/deadpan-audio/src/bound_reads/components_mask_native_tests.rs')])
extras=['point_suppression.rs','point_suppression/mutations.rs','point_suppression/ops_trace.rs','shared_components/program.rs','bound_reads/retained_host_cases.rs']
for p in extras:rows.append(pin(s/'crates/deadpan-audio/src'/p))
for p in [c/'candidate-sha256.txt',c/'integration-hooks.md',c/'README.md']:rows.append(pin(p))
unique={r['path']:r for r in rows}
(out/'source-pins.json').write_text(json.dumps(list(unique.values()),indent=2)+'\n')
(out/'audit-results.json').write_text(json.dumps(results,indent=2)+'\n')
print(json.dumps(results,indent=2))
