from pathlib import Path
import hashlib,json,difflib
c=Path('/tmp/deadpan-components-bounded-mark-tests-candidate-2026-10-31')
s=Path('/tmp/deadpan-query-groundwork-2026-10-26/scoped')
d=Path('/tmp/deadpan-components-bounded-mark-tests-review-2026-10-31')
v=json.loads((c/'source-pins.json').read_text())
def pin(p):
 b=p.read_bytes()
 return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
pins=[];bad=[];states={}
for f in v['files']:
 rel=Path(f['path']);new=c/'new'/rel;pins.append(pin(new))
 if pin(new)['sha256']!=f['new_sha256']:bad.append(str(new))
 if f.get('before_exists',True):
  old=c/'before'/rel;pins.append(pin(old))
  if pin(old)['sha256']!=f['before_sha256']:bad.append(str(old))
 if (s/rel).exists():
  current=pin(s/rel);pins.append(current)
  states[str(rel)]='proposed-new'if current['sha256']==f['new_sha256'] else 'before'if current['sha256']==f.get('before_sha256')else 'different'
 else:states[str(rel)]='absent'
depbad=[]
for f in v['dependencies']:
 a=pin(s/f['path']);pins.append(a)
 if a['sha256']!=f['sha256']:depbad.append(f['path'])
artbad=[]
for f in v['artifacts']:
 a=pin(c/f['path']);pins.append(a)
 if a['sha256']!=f['sha256']or a['bytes']!=f['bytes']:artbad.append(f['path'])
checks={}
for name in ['hook.patch','tests.patch']:
 t=(c/name).read_text();old,rel=t.splitlines()[:2]
 rel=rel.removeprefix('+++ b/')
 before=[]if old=='--- /dev/null'else(c/'before'/rel).read_text().splitlines(True)
 reconstructed=''.join(difflib.unified_diff(before,(c/'new'/rel).read_text().splitlines(True),fromfile=old.removeprefix('--- '),tofile='b/'+rel))
 checks[name]=reconstructed==t
results={'file_pins_mismatches':bad,'current_root_state':states,'dependency_pins_checked':len(v['dependencies']),'dependency_mismatches':depbad,'artifact_pins_checked':len(v['artifacts']),'artifact_mismatches':artbad,'patch_reconstruction':checks}
pins.extend([pin(c/'source-pins.json'),pin(s/'crates/deadpan-audio/src/shared_components/marks.rs'),pin(s/'crates/deadpan-audio/src/components_mask_trace.rs')])
(d/'source-pins.json').write_text(json.dumps(pins,indent=2)+'\n')
(d/'audit-results.json').write_text(json.dumps(results,indent=2)+'\n')
print(json.dumps(results,indent=2))
