from pathlib import Path
import hashlib,json,re,difflib
c=Path('/tmp/deadpan-components-mask-candidate-2026-10-31')
out=Path('/tmp/deadpan-components-mask-production-review-2026-10-31')
scope=Path('/tmp/deadpan-query-groundwork-2026-10-26/scoped')
def hashrow(p):
 b=p.read_bytes()
 return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
pins=[]
checks={}
for manifest in ['source-pins.json','dependency-pins.json','test-source-pins.json']:
 vals=json.loads((c/manifest).read_text())
 mismatch=[]
 for path,row in vals.items():
  p=Path(path)
  actual=hashrow(p);pins.append(actual)
  if (actual['bytes'],actual['sha256'])!=(row['bytes'],row['sha256']):mismatch.append(path)
 checks[manifest]={'checked':len(vals),'mismatches':mismatch}
vals=json.loads((c/'candidate-pins.json').read_text())
mismatch=[]
for path,row in vals.items():
 actual=hashrow(c/path);pins.append(actual)
 if (actual['bytes'],actual['sha256'])!=(row['bytes'],row['sha256']):mismatch.append(path)
checks['candidate-pins.json']={'checked':len(vals),'mismatches':mismatch}
def read(tree,path):return (c/tree/'crates/deadpan-audio/src'/path).read_text()
old=read('before','shared_components.rs')
new=read('new','shared_components.rs')
old=old[old.index('    pub(super) fn finish_into('):]
new=new[new.index('    pub(super) fn finish_into('):]
new=new.replace('output.mark_suppressed(at, sample, control)?;','output.mark_suppressed(sample);')
checks['finish_into_literal_except_two_mark_calls']=(old==new)
old=read('before','shared_components/block.rs')
new=read('new','shared_components/block.rs').replace('output.mark_suppressed(at, AudioSample(self.start.0 + at as i64), control)?;','output.mark_suppressed(AudioSample(self.start.0 + at as i64));')
checks['block_literal_except_mark_call']=(old==new)
old=read('before','shared_mix.rs');new=read('new','shared_mix.rs')
checks['nonseparate_finish_literal']=(old[old.index('        let mut order: Vec<_>'):]==new[new.index('        let mut order: Vec<_>'):])
checks['source_snapshots_equal_scope']=all((c/'before'/p.relative_to(scope)).read_bytes()==p.read_bytes() for p in [Path(p) for p in json.loads((c/'source-pins.json').read_text())])
paths=re.findall(r'^--- a/(.+)$',(c/'candidate.patch').read_text(),flags=re.M)
patch=''.join(''.join(difflib.unified_diff((c/'before'/p).read_text().splitlines(True),(c/'new'/p).read_text().splitlines(True),fromfile='a/'+p,tofile='b/'+p)) for p in paths)
checks['candidate_patch_exact_before_to_new']=(patch==(c/'candidate.patch').read_text())
checks['patch_sha256']=hashrow(c/'candidate.patch')['sha256']
for p in [c/'candidate-pins.json',c/'README.md',c/'candidate.patch',c/'optional-test-adapters.patch',c/'hook-proposal/components_mask_request.rs']:
 pins.append(hashrow(p))
unique={row['path']:row for row in pins}
(out/'source-pins.json').write_text(json.dumps(list(unique.values()),indent=2)+'\n')
(out/'audit-results.json').write_text(json.dumps(checks,indent=2)+'\n')
print(json.dumps(checks,indent=2))
