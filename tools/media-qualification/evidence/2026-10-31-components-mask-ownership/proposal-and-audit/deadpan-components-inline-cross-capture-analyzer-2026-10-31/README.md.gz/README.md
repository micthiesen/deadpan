# Inline Components six-capture validator (14-path review)

Scratch-only analyzer. It reads six literal captures for one run prefix:

- `<prefix>-active-{main,scoped}-canonical.json`
- `<prefix>-active2-{main,scoped}-canonical.json`
- `<prefix>-active3-{main,scoped}-canonical.json`

For each file it checks all four producer cases independently: root-row driver identity, source inline-bitset state, bounded trace completeness, Mark writes vs inline-word popcount, source/target reservation overlap, target ownership and held payload release, zero-emission no-target behavior, and the reached dynamic Mark refusal. It preserves legacy and active result bodies as captured. For the refusal receipt, `literal_legacy` is the actual `legacy_at_same_work_seed` body.

The final capture diff showed 367 differences against Main active, across 95 unique pointers. The reviewed path spec allows only those exact 95 paths, with each path constrained again to named cases, row ids, and accounting contexts: 15 paths in constant wet-positive case 0 (rows 767, 768, plus aggregate work), and 80 paths in dynamic-positive case 1 (rows 0 and 7 through 20, plus aggregate work). The allowed leaves are limited to the four observed plan-work counters. No generic work-field filtering is used. All six values and deltas from Main active are emitted. The 367-diff source file and SHA are pinned in the path spec. Changes outside those paths fail.

The analyzer emits each complete raw canonical capture's SHA-256, absolute path, and byte count independently. It does not rewrite input JSON. Classic historical parity is delegated to pointagent's `analyzer_classic13.py`; both per-variant outputs are embedded unchanged, with the classic projection proof kept separate from all six raw hashes.

Invocation:

```sh
python3 analyze_inline_six.py components-final \
  --capture-directory /path/to/captures \
  --base-analyzer /path/to/analyzer_classic13.py \
  --path-spec /path/to/reviewed-inline-plan-work-paths.json \
  --output /tmp/inline-six-analysis.json
```

## Pins

- `analyze_inline_capture12.py` source basis: `79f54ef53cf60c243a60aa63ec7b48a8d9a7817bb1793e9555f4d10e0f623e71`
- `final13-all-current-differences.json`: `d08fe65371136c6c954d50ca5afe0fab1264dba559fe4e5bfb88cc673ab0155b`
- `reviewed-inline-plan-work-paths.json`: `a3fbe5c20dfc1ec7710b492ea70a41f3a08ea9873063674ff42a391045f424cd`
- `analyze_inline_six.py`: `c261d2e358898d33b1a5a7e991c02c8c4ac669594ff0452d7739de87f391f106`
- prior rejected 54-path analyzer, retained as `analyze_inline_six_13_failed.py`: `92f1dbc205103e5d358ba46cce6c1ba8fba6124a9d797fd07e71d7c875574559`

The updated script was syntax-checked with `python3 -m py_compile`. It has not yet been run on the final six captures in this candidate turn.
