# Inline Components analyzer/join review

Static GO after the scratch fixes below. Final captures/build receipts are not yet available to this review. No analyzer/join qualification run, native execution, Root edit, build, Git operation or frozen-payload change was performed. Python source syntax was compiled in memory only.

Authority inspected:
- Current Scope bound_reads/components_mask_native_tests.rs::capture_cases and actual Run body JSON.
- Current Scope components_mask_trace.rs failure/success result emission and native_mask_after.rs envelope.
- Existing F analyze_final_capture.py and real first F active canonical body.
- Actual existing build pin, matrix run and capture proof schemas.

Frozen reviewed scripts:
- analyze_inline_capture.py: 11,356 bytes, SHA 6f72eaef37e5ffcb7cbcb844f987070e74388a9aa380be24ba2e6a0e358d06a9.
- join_inline_qualification.py: 10,432 bytes, SHA e4c9311233af249b1f6b729dbe6f91514ea2a5a37c3c80c841b2561db2bd466b.
- README.md: SHA 70f9afd20aac0230c91086e1baa72d10ea78a688e77c426d7fa64ca2f114cec2.
- Exact dependency/source pins are review-pins.json here and refreshed source-pins.txt in the analyzer directory. The latter now uses real newlines throughout.

Resolved findings:
1. Join incorrectly required completed+partial=477. A read-only count of components-first-active-scoped-canonical.json (35,593,948 bytes, SHA1423d6c22e5aa1e1be5e769e4968d792c22760e51750208b7fc446a0f339e1e1) confirms758 snapshots,478 rows,477 completed and1 partial. Join now asserts those distinct completed/partial/row counts correctly.
2. Matrix length21 did not establish unique/exact target coverage; pin count was unchecked. Join now requires the fixed actual21 Audio target names exactly once in both pins and matrix, and21 distinct run labels. Each pin is verified against the actual binary file bytes/SHA, Cargo Audio manifest/target and qualified opt2/overflow/debug profile.
3. row.sha==pin.sha plus binaries_unchanged could pass vacuous/foreign run manifests. Each matrix/capture run now requires exactly the resolved actual pinned binary before and after (bytes+SHA), that exact executable as command[0], source manifests identical to the nonempty exact build manifest, and successful unmodified receipt flags. Current actual source files remain hash-guarded.
4. Capture proof/bin hash was not enough to bind the actual captured body or command. Join now checks each named mode's exact ignored test command, variant/checkpoint, environment output/source digest, saved relative source manifest, proof source count/digest and binary hash. It independently strips only the four allowed outer/native variant/source fields from the raw body and requires reconstructed canonical bytes, size and SHA to match the saved canonical/proof. Analysis prefix/directory/active bytes/SHA and nested base analysis are bound to these captures.
5. The unchanged F base analyzer zipped outer native cases without case-count/fixture-header checks. The inline wrapper now checks exact five outer cases and all headers except operations before invoking the base. Existing operation-length/metadata/output checks remain unchanged.
6. Four case rows plus a positive/zero/refusal Counter could accept duplicate constant-positive and omit dynamic-positive. The wrapper now requires the exact four unique case names.
7. Measured Mark has different top-level keys and an actual failure row without mask_capacity. The analyzer correctly uses legacy_at_same_work_seed/active and optional derived success flags, and requires absent destination/capacity instead of fictional zero capacity. It now also requires the exact active {status:Error,error:Limit("plan work per read")} body and matching root row error. Legacy is retained separately and can be Ok at the same seed. Receipt labels are neutral literal_*_body, not misleading “error” labels.

Schema review:
- Positive/zero Run bodies genuinely contain sample_capacity and exhausted_capacity; both complete success bodies are compared directly without normalization.
- Measured failure lacks those output fields; its top-level capacity values can be null and are not mistaken for returned output storage.
- The root-row selection is program_depth0 plus the actual fixture start0/8128; target/source reservation predicate is independently stronger than the convenience capture flag (active_frames>=real source reservation).
- Inline words have no heap source allocation, charge, pointer or physical disposal claim. Positive destination pointer identity/capacity, zero no-target and actual measured Mark refusal are separate.
- Existing interval rows remain inclusive and are not summed; legacy query/native/host work fields are not repriced or normalized.

Scope limit: this review verifies script/schema joins, not current native success. It neither proves the new nine regression paths pass nor replaces actual final captures, complete21-target matrix, source audit or boundary/native tests. Check labels supplied to the join must refer to successful receipts from the same exact frozen build-source set.
