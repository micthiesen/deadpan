from pathlib import Path
import argparse
import hashlib
import json

parser = argparse.ArgumentParser()
parser.add_argument("build_label", help="build receipt stem, e.g. components-inline-build8")
parser.add_argument("matrix_label", help="matrix receipt stem, e.g. components-inline-matrix8")
parser.add_argument("capture_prefix", help="capture prefix passed to analyze_inline_capture.py")
parser.add_argument("--capture-directory", default=None, help="directory containing receipts and captures; defaults to this script directory")
parser.add_argument("--analysis", default="inline-components-capture-analysis.json")
parser.add_argument("--matrix-summary", required=True)
parser.add_argument("--source-audit", required=True)
parser.add_argument("--check-label", action="append", default=[])
args = parser.parse_args()
script_dir = Path(__file__).resolve().parent
s = Path(args.capture_directory).resolve() if args.capture_directory else script_dir

def artifact(name):
    path = Path(name)
    return path if path.is_absolute() else s / path

roots = {
    "main": Path("/Users/michael/Code/deadpan"),
    "scoped": Path("/tmp/deadpan-query-groundwork-2026-10-26/scoped"),
}
summary = json.loads(artifact(args.matrix_summary).read_text())
for variant, root in roots.items():
    build_file = s / f"{args.build_label}-{variant}.json"
    pins_file = s / f"{args.build_label}-{variant}-pins.json"
    build = json.loads(build_file.read_text())
    assert build["exit_code"] == 0 and build["sources_unchanged"]
    pins = json.loads(pins_file.read_text())
    for absolute, pin in build["source_after"].items():
        content = Path(absolute).read_bytes()
        assert pin == {
            "bytes": len(content),
            "sha256": hashlib.sha256(content).hexdigest(),
        }, absolute
    matrix_file = s / f"{args.matrix_label}-{variant}-matrix.json"
    matrix = json.loads(matrix_file.read_text())
    assert len(matrix) == 21, (variant, len(matrix))
    for row in matrix:
        run = json.loads((s / f"{row['run']}.json").read_text())
        assert run["exit_code"] == 0 and run["sources_unchanged"] and run["binaries_unchanged"]
        pin = next(item for item in pins if item["name"] == row["target"])
        assert row["sha256"] == pin["sha256"]
    for mode in [
        "before-off", "before-interval", "before-policy", "before-root",
        "before-shared", "active", "active2", "active3",
    ]:
        label = f"{args.capture_prefix}-{mode}-{variant}"
        proof = json.loads((s / f"{label}-proof.json").read_text())
        expected_binary = next(item["sha256"] for item in pins if item["name"] == "deadpan_audio")
        assert proof["binary_sha256"] == expected_binary
        capture = json.loads((s / f"{label}.json").read_text())
        assert capture["exit_code"] == 0 and capture["sources_unchanged"] and capture["binaries_unchanged"]

for label in args.check_label:
    check = json.loads((s / f"{label}.json").read_text())
    assert check["exit_code"] == 0 and check["sources_unchanged"]

analysis = json.loads(artifact(args.analysis).read_text())
base = analysis["base_historical_analysis"]
counts = base["counts"]
assert counts["native_requests"] == 744 and not base["output_changes"]
assert counts["exact_Ok"] == 264 and counts["exact_Error"] == 480
assert counts["internal_exact_output_fields"] + counts["transfer_exact_output_fields"] == 42
assert counts["completed_intervals"] + counts["partial_intervals"] == 477
assert analysis["components_cases"] == {"positive": 2, "zero": 1, "mark_refusal": 1}
audit = json.loads(artifact(args.source_audit).read_text())
assert audit["immutable_payloads_exact"] == 34

result = {
    "build_label": args.build_label,
    "matrix_label": args.matrix_label,
    "capture_prefix": args.capture_prefix,
    "matrix_summary": summary,
    "capture_analysis": analysis,
    "source_audit": audit,
    "qualification_scope": "single-output Components inline marks and final destination; ordinary multi-output, projected PreserveTape policy, exhausted vectors, PCM/dependencies and whole preparation remain outside this claim",
}
out = s / f"{args.capture_prefix}-inline-final-qualification.json"
out.write_text(json.dumps(result, indent=2) + "\n")
print(json.dumps({
    "build_label": args.build_label,
    "matrix_label": args.matrix_label,
    "capture_prefix": args.capture_prefix,
    "historical_native_requests": counts["native_requests"],
    "historical_internal_transfer_fields": counts["internal_exact_output_fields"] + counts["transfer_exact_output_fields"],
    "historical_intervals": counts["completed_intervals"] + counts["partial_intervals"],
    "components_cases": analysis["components_cases"],
    "immutable_payloads": audit["immutable_payloads_exact"],
}))
