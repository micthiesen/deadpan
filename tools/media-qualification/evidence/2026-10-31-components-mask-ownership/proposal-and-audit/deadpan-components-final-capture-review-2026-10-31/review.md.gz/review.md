# Final Components capture/source review

GO for the bounded single-output Components ownership claim, with literal work-counter variability disclosed below. Parent analysis 14 and final join 13 pass and agree with these independent checks. No production blocker remains from this review.

The qualified scope is the single-output Components producer: bounded inline decisions, live existing source reservation, and funded typed AudioSample destination after callbacks/depth. Ordinary multi-output, PreserveTape, exhausted/PCM/dependency ownership, whole preparation, and DP/Gate acceptance remain outside this result.

## Verified evidence

I independently joined all 21 actual compiler-artifact records and pinned executables per root to final 13 build/source guards, executed matrix commands, before/after binary guards, and streamed output hashes. Main passes 1136 and Scope 1130; libraries 555/549, 24 ignored, Main 7 known Split filters. Each root has 20 rebuilt integration artifacts and one library reused exactly from build 12: identical source inputs and library bytes. Strict 7 Main, Clippy 7 Scope, formatting 6, hygiene 5 and rustdoc 13 commands/streams pass; rustdoc has zero executable examples. This reviewer performed read-only source and Python evidence audits, no builds/native execution/Git.

All 16 completed capture proofs match their actual command/environment/source identity, guarded binary, raw body, identity-only canonical transformation and stream hashes. Five historical complete bodies match their frozen hashes in both roots. Every current body has38,529,544canonical bytes, but the six hashes differ:

| Capture | SHA-256 |
| --- | --- |
| active-main | 5f2ddd4df01c0a012da87c23ab7953b3285787fddf8d2ce38850162df44b8c4e |
| active-scoped | 7a18d4416386c617bc835bec033ee497fe06c725dde038ddc3c23eb313c8bcab |
| active2-main | 4656ec16ebc20f8e570b4f924dbf0cefcc66bf8627e616809965f1d8422e3a74 |
| active2-scoped | 66f7130b55b4b4f96aada54bc67ec6a47539f5c032a6e021aff4139f4235099a |
| active3-main | 3cac845a1d7f509178a893e7383ec6418dfa734e3b1a319cf1e9573a190b995b |
| active3-scoped | 3eb16f318a76582887f66d6b1dc3232c542cbc0c9314783fb12fe9ba3ea249e8 |

All six captures independently preserve 744 complete outputs (264 Ok/480 Error), 42 internal/transfer result fields, and classic account fields. Each has 758 interval snapshots, 478 rows, 477 completed inclusive claims with 954 exact lane equations. The one claimless partial stays partial: observed plan 6, native 1, host 0, unclaimed residual 5. It is not presented as a completed equation or normalized.

All four real producer cases pass independently in every capture: actual expected driver/root identity, callback reachability, four initialized words/32 inline bytes, real Zero4 debit, first/last accepted Mark1 with unchanged cache lane, exact actual bit-derived ranges, raw-count destination capacity, source reservation live at funding, retained destination pointer, no truncation/unfinished rows, and request cleanup. Constant 514 produces 769 rows, root 128 marks and final 257 ranges/capacity 257; held account 522 releases to shell 3 (payload 519). Dynamic 8128..8256 produces 21 rows, root 64 marks and [8192,8256), output capacity 1; held 10 releases to 3 (payload 7). Source-only zero root has no target/owned capacity; recursive work legitimately leaves shell 3. Gain-only failure is genuinely dynamic with callback 0; measured ample prefix + initial seed reaches the same first Mark exactly at MAX, refuses before any written bit or destination, and records the real typed error and cleanup.

## Literal work variability

The initial dynamic-only comparison correctly failed on additional constant-positive evidence. Relative to active-scoped, the other five captures differ at 307 scalar leaves across 95 unique exact paths: 15 in constant-positive rows 767/768 plus whole-invoke work, 80 in dynamic-positive. Maximum absolute delta 4. Every difference is an integer absolute plan-work checkpoint: source before/init, first/last Mark before/after, row completion, or whole invoke. All outputs/capacities/errors/account lifetimes, structure, counts, native debit relations, zero case and gain-failure case remain exact.

Raw bodies, all six hashes, and every changed path/value/delta are retained. There is no current full-body equality claim, rewritten canonical body, fee subtraction or production fee/cap change. Pointer-hashed Domain OriginalInput collision-chain work is a plausible source-supported explanation; this audit does not claim an exact causal replay of each differing lookup.

The separately identified current classic section is exact across all six captures: 35,593,959 bytes, SHA-256 a0551013c190119e61a17e09db82a64c8807abedefab02336c01887ae126af45. This section comparison leaves all full raw bodies unchanged. Parent analyzer14 uses the exact same 95 observed paths; its 367 differences use Main-active as reference, whereas this review records 307 relative to Scope-active. Neither count is a normalized body. The executed analyzer is retained unchanged, including a stale nonfunctional comment saying 54; functional assertions and report correctly require 95.

## Source and limitations

All 17 owned current files match final source pins. Initial unowned 2920 Main/2592 Scope inputs and all 34 immutable oracle payloads hash exactly. Current build guards contain 2937 Main/2609 Scope inputs. Main inherited source differences remain excluded from shipping authority; Scope is authoritative.

Earlier failures remain: nine unchanged wet/event budget regressions of the rejected heap flags; observer truncation; dynamic media qualification; unexplained early Mark reachability miss; absent-capacity assertion; AtomicBool drop lint; final 9 wet-seed instability whose passing repeats were not accepted as a fix; build 11 incorrect constant-driver assertion, including my incorrect static conclusion; and rejected dynamic-only final variance whitelist. The final gain-only failure fixture and direct ordered bit-run producer address concrete failures without repricing.

Destination quota refusal and callback/depth/numeric failures of this producer are not established by these fixtures. Seven real-context boundary tests establish constructor/bit-run/work-prefix behavior; they do not substitute for public-driver proof. No new Gate credit or whole-preparation claim follows.

Machine-readable independent results and exact pins are in this review directory. No full Main source map is copied.
