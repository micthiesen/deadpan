from pathlib import Path
import argparse
import json
import re

parser = argparse.ArgumentParser()
parser.add_argument('--prefix', default='components-final13')
args = parser.parse_args()
root = Path('/tmp/deadpan-components-mask-qualification-2026-10-31')
output = Path(__file__).resolve().parent
names = [f'{mode}-{variant}' for mode in ['active', 'active2', 'active3'] for variant in ['main', 'scoped']]


def load(name):
    json.loads((root / f'{args.prefix}-{name}-proof.json').read_text())
    path = root / f'{args.prefix}-{name}-canonical.json'
    value = json.loads(path.read_text())
    assert value['components_producer_cases']['cases'][1]['name'] == 'dynamic_positive'
    return value


def differences(left, right, path=''):
    if type(left) is not type(right):
        yield path, left, right
    elif isinstance(left, dict):
        assert left.keys() == right.keys(), (path, left.keys() ^ right.keys())
        for key in left:
            yield from differences(left[key], right[key], path + '/' + key)
    elif isinstance(left, list):
        assert len(left) == len(right), path
        for index, (a, b) in enumerate(zip(left, right)):
            yield from differences(a, b, path + '/' + str(index))
    elif left != right:
        yield path, left, right


prefix = '/components_producer_cases/cases/1/'
# Exact scalar fields, never a blanket removal of work or trace objects.
row_fields = {
    'source_plan_work_before',
    'source_init/plan_work_after',
    'result/plan_work_after',
    'marks/first_attempt/plan_work_before',
    'marks/last_attempt/plan_work_before',
    'marks/first_accepted_work_after/plan_work',
    'marks/last_accepted_work_after/plan_work',
}


def permitted(path, left, right, current):
    assert type(left) is int and type(right) is int
    assert 0 <= left <= 16 * 1024 * 1024 and 0 <= right <= 16 * 1024 * 1024
    if path == prefix + 'work/plan_work':
        return
    match = re.fullmatch(re.escape(prefix + 'components_trace/rows/') + r'(\d+)/(.*)', path)
    assert match is not None and match[2] in row_fields, path
    index = int(match[1])
    assert index < len(current['components_producer_cases']['cases'][1]['components_trace']['rows'])



reference_name = 'active-scoped'
reference = load(reference_name)
comparisons = []
for name in names:
    current = load(name)
    changes = []
    for path, left, right in differences(reference, current):
        changes.append({'path': path, 'reference': left, 'current': right,
                        'delta': right-left if type(left) is int and type(right) is int else None})
    comparisons.append({'capture': name, 'count': len(changes), 'differences': changes})
(output / 'all-final-literal-differences.json').write_text(json.dumps(comparisons, indent=2)+'\\n')
print(json.dumps({item['capture']: item['count'] for item in comparisons}))
