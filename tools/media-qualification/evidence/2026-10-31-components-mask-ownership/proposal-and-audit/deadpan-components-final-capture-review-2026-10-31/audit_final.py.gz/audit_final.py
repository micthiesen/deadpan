from pathlib import Path
from collections import Counter
import argparse,hashlib,json,re
parser=argparse.ArgumentParser()
parser.add_argument('--build',default='components-build13')
parser.add_argument('--matrix',default='components-matrix13')
parser.add_argument('--prefix',default='components-final13')
args=parser.parse_args()
R=Path('/tmp/deadpan-components-mask-qualification-2026-10-31')
O=Path(__file__).resolve().parent
ROOTS={'main':Path('/Users/michael/Code/deadpan'),'scoped':Path('/tmp/deadpan-query-groundwork-2026-10-26/scoped')}
MODES={
'before-off':('old','DEADPAN_INTERNAL_MASK_AFTER','capture_active_internal_mask_after_v1','e8fcdb3cb02f9682bef53f6ba2709e8a5ad692d0','af7a292718365c34fa03692e2cbe58a2cfb3c6d444b5ae29d52647e1fdbbff14'),
'before-interval':('intervals','DEADPAN_QUERY_INTERVAL_AFTER','capture_active_query_intervals_v1','ab211a2f132379a246157c3596d95fc42121541c','f64d3a00a10967cc3822083d21705bd454f2d33ff2198da30e25671092ab5a53'),
'before-policy':('policy','DEADPAN_POINT_POLICY_AFTER','capture_active_point_policy_after_v1','eedbc58272bdd009a65239b7104ddb786a2554fc','afa6038a02c959c7192c09c08a89266c7d52151a5e59a4f69828fbdf67e7414e'),
'before-root':('root','DEADPAN_ROOT_MASK_AFTER','capture_active_root_mask_after_v1','44068bd971dee62e2ed8cbaffbb2f18922283f83','596d738a53f6ef4cbf7870d74b3025504f6289f735ea91f4a38ed45c6661f44a'),
'before-shared':('shared','DEADPAN_SHARED_MIX_MASK_AFTER','capture_active_shared_mix_mask_after_v1','6458e9b989172147e0844fcb251c89ce8c479aaf','9d6f3c67d9d611f46e75360006845a1b9419b30168a983db1ca9e4cf79c8be0a')}
for mode in ['active','active2','active3']:
 MODES[mode]=('components','DEADPAN_COMPONENTS_MASK_AFTER','capture_active_components_mask_after_v1','69698b678fd8a75dd644993d7d2a9846986d6911',None)
missing=[]
for variant in ROOTS:
 for mode in MODES:
  p=R/f'{args.prefix}-{mode}-{variant}-proof.json'
  try:json.loads(p.read_text())
  except(FileNotFoundError,json.JSONDecodeError):missing.append(p.name)
if missing:
 print(json.dumps({'status':'waiting_for_complete_proofs','count':len(missing),'missing':missing}))
 raise SystemExit(0)
cache={}
def fingerprint(path):
 p=Path(path);st=p.stat();key=(str(p),st.st_size,st.st_mtime_ns)
 if key not in cache:
  h=hashlib.sha256()
  with p.open('rb')as f:
   while block:=f.read(1024*1024):h.update(block)
  cache[key]={'bytes':st.st_size,'sha256':h.hexdigest()}
 return cache[key]
def canonical(v):return(json.dumps(v,sort_keys=True,separators=(',',':'))+'\n').encode()
def load(p):return json.loads(Path(p).read_text())
def streams(run,label):
 for path,pin in run['streams'].items():assert fingerprint(path)==pin,(label,path)
def run_guard(run,pin,source,label):
 assert run['exit_code']==0 and run['sources_unchanged'] and run['binaries_unchanged'],label
 assert run['source_before']==run['source_after']==source,label
 actual={str(Path(pin['path']).resolve()):{'bytes':pin['bytes'],'sha256':pin['sha256']}}
 for field in ['binary_before','binary_after']:
  assert {str(Path(p).resolve()):v for p,v in run[field].items()}==actual,(label,field)
 assert Path(run['command'][0]).resolve()==Path(pin['path']).resolve(),label
 streams(run,label)
expected={p.stem for p in(ROOTS['scoped']/'crates/deadpan-audio/tests').glob('*.rs')}|{'deadpan_audio'}
assert len(expected)==21
builds={};capture_pins={};records=[];summary={}
for variant,root in ROOTS.items():
 label=f'{args.build}-{variant}';build=load(R/f'{label}.json')
 assert build['exit_code']==0 and build['sources_unchanged']
 source=build['source_after'];assert source==build['source_before']
 assert Path(build['cwd']).resolve()==root.resolve()
 assert build['environment']['CARGO_INCREMENTAL']=='0'
 assert build['environment']['CARGO_PROFILE_DEV_OPT_LEVEL']=='2'
 assert 'ffmpeg-8.0.3' in build['environment']['DEADPAN_FFMPEG_PREFIX']
 assert 'onnxruntime-1.31.0' in build['environment']['DEADPAN_ORT_PREFIX']
 for path,pin in source.items():assert fingerprint(path)==pin,path
 streams(build,label)
 emitted=[]
 for line in(R/f'{label}.stdout').open():
  try:value=json.loads(line)
  except ValueError:continue
  if value.get('reason')=='compiler-artifact'and value.get('executable')and value.get('profile',{}).get('test')and Path(value.get('manifest_path','/missing')).resolve()==(root/'crates/deadpan-audio/Cargo.toml').resolve():emitted.append(value)
 assert len(emitted)==21 and {x['target']['name']for x in emitted}==expected
 pins=load(R/f'{label}-pins.json');assert len(pins)==21
 assert {p['name']for p in pins}==expected
 byname={p['name']:p for p in pins}
 for pin in pins:
  assert pin['package']=='audio'
  assert pin['artifact']in emitted
  p=pin['artifact']['profile']
  assert p['opt_level']=='2'and p['debug_assertions']and p['overflow_checks']and p['test']
  assert fingerprint(pin['path'])=={'bytes':pin['bytes'],'sha256':pin['sha256']}
 matrix=load(R/f'{args.matrix}-{variant}-matrix.json')
 assert len(matrix)==21 and {r['target']for r in matrix}==expected and len({r['run']for r in matrix})==21
 counts=Counter();target_results=[]
 for row in matrix:
  run=load(R/f"{row['run']}.json");pin=byname[row['target']]
  assert row['exit_code']==0 and row['sha256']==pin['sha256']
  run_guard(run,pin,source,row['run'])
  expected_args=['--test-threads=1'if row['target']=='deadpan_audio'else'--test-threads=4']
  if variant=='main'and row['target']=='stages':expected_args+=['--skip','general_split_sound::']
  assert run['command'][1:]==expected_args,(row['run'],run['command'])
  result=re.findall(r'test result: ok\. (\d+) passed; 0 failed; (\d+) ignored; 0 measured; (\d+) filtered out;', (R/f"{row['run']}.stdout").read_text())
  assert len(result)==1,row['run']
  passed,ignored,filtered=map(int,result[0])
  counts.update(passed=passed,ignored=ignored,filtered=filtered)
  target_results.append({'target':row['target'],'passed':passed,'ignored':ignored,'filtered':filtered,'binary':fingerprint(pin['path'])})
 rel={str(Path(p).resolve().relative_to(root.resolve())):pin for p,pin in source.items()}
 source_digest=hashlib.sha256(canonical(rel)).hexdigest()
 builds[variant]={'source':source,'pins':byname,'digest':source_digest}
 summary[variant]={'targets':target_results,'totals':dict(counts),'source_inputs':len(source),'source_digest':source_digest,'fresh_artifacts':dict(Counter(str(x.get('fresh'))for x in emitted))}
 for mode,(produce,envpre,test,checkpoint,historical)in MODES.items():
  cap=f'{args.prefix}-{mode}-{variant}'
  proof=load(R/f'{cap}-proof.json');run=load(R/f'{cap}.json')
  pin=byname['deadpan_audio']
  run_guard(run,pin,source,cap)
  assert(proof['mode'],proof['variant'],proof['base_revision'])==(produce,variant,checkpoint)
  assert proof['source_inputs']==len(source)and proof['source_manifest_sha256']==source_digest
  assert proof['binary_sha256']==pin['sha256']
  manifest_path=R/f'{cap}-source-manifest.json'
  assert load(manifest_path)==rel and fingerprint(manifest_path)['sha256']==source_digest
  assert run['command'][1:]==['--ignored','--exact','stages::bound_reads::retained_host_baseline::pairs::native_mask_after::'+test,'--nocapture','--test-threads=1']
  env=run['environment'];owner='main-inherited'if variant=='main'else'scoped-published'
  assert env[envpre+'_VARIANT']==owner and env[envpre+'_SOURCE_SHA256']==source_digest and env[envpre+'_PUBLISHED_CHECKPOINT']==checkpoint
  body_path=R/f'{cap}-body.json';assert Path(env[envpre+'_OUTPUT']).resolve()==body_path.resolve()
  body=load(body_path)
  assert body.pop('variant')==owner and body.pop('source_sha256')==source_digest
  assert body['native_requests'].pop('variant')==owner and body['native_requests'].pop('source_sha256')==source_digest
  data=canonical(body);path=R/f'{cap}-canonical.json'
  assert fingerprint(path)=={'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}
  with path.open('rb')as f:assert f.read()==data
  actual=fingerprint(path)
  assert all(proof[k]==v for k,v in actual.items())
  if historical:assert actual['sha256']==historical
  capture_pins[(mode,variant)]=actual
  records.append({'capture':cap,**actual,'proof':fingerprint(R/f'{cap}-proof.json'),'raw_body':fingerprint(body_path),'stdout':fingerprint(R/f'{cap}.stdout'),'stderr':fingerprint(R/f'{cap}.stderr')})
active_pin=[{'mode':mode,'variant':v,**capture_pins[mode,v]}for mode in ['active','active2','active3']for v in ROOTS]
O.joinpath('qualification-audit.json').write_text(json.dumps({'build':args.build,'matrix':args.matrix,'prefix':args.prefix,'variants':summary,'active':active_pin,'captures':records},indent=2)+'\n')
print(json.dumps({'status':'qualified_source_binary_capture_streams','active':active_pin,'totals':{v:x['totals']for v,x in summary.items()},'captures':len(records)}))
