from pathlib import Path
import json
import re

directory = Path(__file__).resolve().parent
comparisons = json.loads((directory / 'all-final-literal-differences.json').read_text())
fields = {
    'source_plan_work_before',
    'source_init/plan_work_after',
    'result/plan_work_after',
    'marks/first_attempt/plan_work_before',
    'marks/last_attempt/plan_work_before',
    'marks/first_accepted_work_after/plan_work',
    'marks/last_accepted_work_after/plan_work',
}
observed = set()
for comparison in comparisons:
    for item in comparison['differences']:
        path = item['path']
        match = re.fullmatch(r'/components_producer_cases/cases/([01])/(.*)', path)
        assert match, path
        case = int(match[1])
        tail = match[2]
        if tail != 'work/plan_work':
            row = re.fullmatch(r'components_trace/rows/(\d+)/(.*)', tail)
            assert row and row[2] in fields, path
            if case == 0:
                assert int(row[1]) in [767, 768], path
        assert type(item['reference']) is int and type(item['current']) is int
        assert 0 <= item['reference'] <= 16777216 and 0 <= item['current'] <= 16777216
        observed.add(path)

result = {
    'status': 'only_observed_integer_absolute_work_variance',
    'scope': 'two positive wet cases only; constant case rows767/768+invoke; dynamic exact recorded paths',
    'initial_dynamic_only_whitelist': 'rejected on final constant-positive evidence; retained',
    'comparisons': comparisons,
    'unique_observed_paths': sorted(observed),
    'changed_leaves': sum(len(item['differences']) for item in comparisons),
    'maximum_absolute_delta': max(abs(item['delta']) for comparison in comparisons for item in comparison['differences']),
}
(directory / 'observed-variance-audit.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({key: value for key, value in result.items() if key not in ['comparisons', 'unique_observed_paths']}))
