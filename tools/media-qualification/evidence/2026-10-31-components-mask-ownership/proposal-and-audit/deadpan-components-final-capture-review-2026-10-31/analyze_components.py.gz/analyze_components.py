#!/usr/bin/env python3
"""Read-only validator for additive Components producer receipts in final6 bodies."""
from pathlib import Path
import hashlib
import json
import sys

root = Path('/tmp/deadpan-components-mask-qualification-2026-10-31')
prefix = sys.argv[1] if len(sys.argv) > 1 else 'components-final6'
output = Path(sys.argv[2]) if len(sys.argv) > 2 else Path('/tmp/deadpan-components-final-capture-review-2026-10-31/analysis.json')


def read(mode, variant):
    path = root / f'{prefix}-{mode}-{variant}-canonical.json'
    raw = path.read_bytes()
    return path, raw, json.loads(raw)


def require(test, message):
    if not test:
        raise AssertionError(message)


def producer_cases(doc):
    cases = doc.get('components_producer_cases')
    require(isinstance(cases, list) and len(cases) == 4,
            f"expected four additive Components cases, got {type(cases).__name__} / {len(cases) if isinstance(cases,list) else None}")
    return cases


def assert_trace(trace, name):
    require(trace.get('enabled') is True, f'{name}: observer not enabled')
    require(trace.get('unfinished') is False, f'{name}: unfinished stack')
    require(trace.get('truncated_rows') is False, f'{name}: row truncation')
    rows = trace.get('rows')
    require(isinstance(rows, list) and len(rows) > 0, f'{name}: missing rows')
    require(trace.get('attempted_rows') == len(rows), f'{name}: dropped request rows')
    require(all(row.get('events_truncated') is not True for row in rows), f'{name}: event truncation')
    return rows


def find_root(rows, start):
    matches = [r for r in rows if r.get('program_depth') == 0 and r.get('start') == start]
    require(len(matches) == 1, f'expected unique depth-zero row at {start}, got {len(matches)}')
    return matches[0]


def assert_positive(case):
    name = case['name']
    require(case.get('exact_output_match') is True, f'{name}: active/legacy body differs')
    old, active = case.get('legacy'), case.get('active')
    require(isinstance(old, dict) and isinstance(active, dict), f'{name}: missing complete bodies')
    require(old == active, f'{name}: literal body mismatch')
    require(old.get('status') == 'Ok', f'{name}: positive fixture did not succeed')
    require(case.get('provider_was_used') is True, f'{name}: WAV provider not used')
    require(case.get('active_frames_after_request') == 0, f'{name}: active frame cleanup')
    require(case.get('sound_context_frames_after_request') == 0, f'{name}: source reservation cleanup')
    trace = case.get('components_trace', {})
    rows = assert_trace(trace, name)
    start = active.get('start')
    root_row = find_root(rows, start)
    require(root_row.get('parent_row_id') is None, f'{name}: root row has parent')
    require(case.get('actual_driver_reached') is True, f'{name}: intended root driver not reached')
    require(case.get('root_positive_marks') is True, f'{name}: no positive root marks')
    expected_driver = case.get('expected_driver')
    require(expected_driver in root_row.get('driver_kinds', []), f'{name}: wrong root driver')
    require(root_row.get('result', {}).get('success') is True, f'{name}: root producer failed')
    require(root_row.get('source_init', {}).get('success') is True, f'{name}: source init failed')
    require(root_row.get('source_reservation', {}).get('accepted') is True, f'{name}: source reserve refused')
    require(root_row.get('source_reservation', {}).get('frames') == root_row.get('source_charge_frames'), f'{name}: source charge mismatch')
    require(root_row.get('source_disposed') is True and root_row.get('source_identity_preserved') is True, f'{name}: source buffer disposal/identity')
    result = root_row['result']
    require(result.get('owned') is True and result.get('destination_identity_preserved') is True, f'{name}: destination ownership/identity')
    require(result.get('source_destination_allocations_distinct') is True, f'{name}: source/destination allocations alias')
    require(root_row.get('destination_reservation', {}).get('accepted') is True, f'{name}: destination reservation refused')
    require(result.get('mask_capacity') == active.get('mask_capacity'), f'{name}: mask capacity differs from returned block')
    require(case.get('sample_capacity') == active.get('sample_capacity'), f'{name}: sample capacity capture mismatch')
    require(case.get('exhausted_capacity') == active.get('exhausted_capacity'), f'{name}: exhausted capacity capture mismatch')
    require(case.get('held_after_controller_drop') == case.get('held_while_output_live'), f'{name}: output lease not held after controller drop')
    require(case.get('output_payload_frames', 0) > 0, f'{name}: missing output payload charge')
    shell = case.get('live_after_output_drop')
    if shell is not None:
        require(case.get('held_while_output_live') == shell + case.get('output_payload_frames'), f'{name}: held shell+payload mismatch')
        events = root_row.get('events', [])
        require(any(e.get('kind') == 'source_reserve_after' and e.get('value', {}).get('accepted') is True for e in events), f'{name}: actual source admission receipt absent')
        require(any(e.get('kind') == 'destination_reserve_after' and e.get('value', {}).get('accepted') is True for e in events), f'{name}: actual destination admission receipt absent')
    if expected_driver == 'dynamic':
        require(case.get('root_dynamic_callbacks') is True, f'{name}: dynamic callback not observed')
        require(root_row.get('callback_count', 0) > 0, f'{name}: root callback count absent')
    return {'name': name, 'root_row_id': root_row['row_id'], 'rows': len(rows), 'mask_capacity': result['mask_capacity'], 'source_charge_frames': root_row['source_charge_frames'], 'destination_frames': root_row['destination_reservation']['frames'], 'held': case.get('held_while_output_live'), 'payload': case.get('output_payload_frames'), 'shell': shell}


paths = {}
loaded = {}
for mode in ['before-off', 'before-interval', 'before-policy', 'before-root', 'before-shared', 'active', 'active2', 'active3']:
    for variant in ['main', 'scoped']:
        path, raw, doc = read(mode, variant)
        paths[str(path)] = hashlib.sha256(raw).hexdigest()
        loaded[(mode, variant)] = (raw, doc)

active_bytes = loaded[('active', 'main')][0]
require(active_bytes == loaded[('active', 'scoped')][0], 'active canonical bodies differ across roots')
for variant in ['main', 'scoped']:
    for repeat in ['active2', 'active3']:
        require(loaded[(repeat, variant)][0] == loaded[('active', variant)][0], f'{repeat}/{variant} body drift')

summaries = {}
for variant in ['main', 'scoped']:
    doc = loaded[('active', variant)][1]
    cases = producer_cases(doc)
    by_name = {case['name']: case for case in cases}
    require(set(by_name) == {'constant_block_positive', 'dynamic_positive', 'constant_zero_emission', 'measured_mark_work_refusal'}, f'{variant}: case names differ')
    positive = [assert_positive(by_name[n]) for n in ['constant_block_positive', 'dynamic_positive']]
    zero = by_name['constant_zero_emission']
    zr = assert_trace(zero.get('components_trace', {}), f'{variant}/zero')
    zroot = find_root(zr, zero['active']['start'])
    require(zero.get('exact_output_match') is True and zero['active'] == zero['legacy'], f'{variant}: zero body mismatch')
    require(zroot.get('result', {}).get('success') is True and zroot.get('source_disposed') is True, f'{variant}: zero source/result cleanup')
    require(zroot.get('result', {}).get('owned') is False and zroot.get('result', {}).get('mask_capacity') == 0, f'{variant}: zero unexpectedly owns destination')
    require(zroot.get('destination_reservation') is None, f'{variant}: zero destination reserve present')
    require(zero.get('output_payload_frames') == 0, f'{variant}: zero output payload charge nonzero')
    require(zero.get('held_after_controller_drop') == zero.get('held_while_output_live') == zero.get('live_after_output_drop'), f'{variant}: zero output/controller lifetime differs')
    failure = by_name['measured_mark_work_refusal']
    fr = assert_trace(failure.get('components_trace', {}), f'{variant}/mark refusal')
    froot = find_root(fr, 0)
    require(failure.get('actual_mark_refusal_reached') is True, f'{variant}: Mark refusal not reached')
    require(froot.get('events') and any(e.get('kind') == 'mark_refused' for e in froot['events']), f'{variant}: no root refusal event')
    require(froot.get('source_disposed') is True, f'{variant}: source not disposed on Mark refusal')
    require(failure.get('active_frames_after_request') == 0 and failure.get('sound_context_frames_after_request') == 0, f'{variant}: failure cleanup')
    require(failure.get('live_after_controller_drop') == failure.get('live_before') + zero.get('live_after_output_drop'), f'{variant}: failure retained mask payload beyond the known empty-output shell')
    summaries[variant] = {'positive': positive, 'zero': {'rows': len(zr), 'result': zroot.get('result')}, 'mark_refusal': {'root_row_id': froot.get('row_id'), 'error': froot.get('result', {}).get('error'), 'rows': len(fr)}}

report = {
    'prefix': prefix,
    'active_sha256': hashlib.sha256(active_bytes).hexdigest(),
    'active_bytes': len(active_bytes),
    'cross_root_exact': True,
    'active_repeat_exact': True,
    'capture_pins': paths,
    'components': summaries,
    'limits': 'This script checks the complete captured receipts as supplied. It does not attribute whole-row work to the mask producer or infer a per-read mask fee. Earlier MAX_ROWS overflow and the prior reached-Mark miss are separate failed attempts, not evidence in the final rows. The four cases are actual native tests/capture rows; no whole-preparation ceiling claim is made.'
}
output.parent.mkdir(parents=True, exist_ok=True)
output.write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps({'active_sha256': report['active_sha256'], 'active_bytes': report['active_bytes'], 'components': summaries}, indent=2))
