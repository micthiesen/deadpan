# Final Components capture/source review

Status: independent checks complete; final verdict held pending corrected parent analysis of both observed wet cases. This is a pending draft, not publication approval.

The qualified scope is the single-output Components producer: bounded inline decisions, live existing source reservation, and funded typed AudioSample destination after callbacks/depth. Ordinary multi-output, PreserveTape, exhausted/PCM/dependency ownership, whole preparation, and DP/Gate acceptance remain outside this result.

## Verified evidence

I independently joined all21 actual compiler-artifact records and pinned executables per root to final13 build/source guards, executed matrix commands, before/after binary guards, and streamed output hashes. Main passes1136 and Scope1130; libraries555/549,24ignored, Main7known Split filters. Each root has20 rebuilt integration artifacts and one library reused exactly from build12: identical source inputs and library bytes. Strict7 Main and Clippy7 Scope commands/streams pass. This reviewer performed read-only source and Python evidence audits, no builds/native execution/Git.

All16 completed capture proofs match their actual command/environment/source identity, guarded binary, raw body, identity-only canonical transformation and stream hashes. Five historical complete bodies match their frozen hashes in both roots. Every current body has38,529,544canonical bytes, but the six hashes differ:

| Capture | SHA-256 |
| --- | --- |
| active-main | 5f2ddd4df01c0a012da87c23ab7953b3285787fddf8d2ce38850162df44b8c4e |
| active-scoped | 7a18d4416386c617bc835bec033ee497fe06c725dde038ddc3c23eb313c8bcab |
| active2-main | 4656ec16ebc20f8e570b4f924dbf0cefcc66bf8627e616809965f1d8422e3a74 |
| active2-scoped | 66f7130b55b4b4f96aada54bc67ec6a47539f5c032a6e021aff4139f4235099a |
| active3-main | 3cac845a1d7f509178a893e7383ec6418dfa734e3b1a319cf1e9573a190b995b |
| active3-scoped | 3eb16f318a76582887f66d6b1dc3232c542cbc0c9314783fb12fe9ba3ea249e8 |

All six captures independently preserve744 complete outputs (264Ok/480Error),42 internal/transfer result fields, and classic account fields. Each has758interval snapshots,478rows,477completed inclusive claims with954 exact lane equations. The one claimless partial stays partial: observed plan6, native1, host0, unclaimed residual5. It is not presented as a completed equation or normalized.

All four real producer cases pass independently in every capture: actual expected driver/root identity, callback reachability, four initialized words/32inline bytes, real Zero4 debit, first/last accepted Mark1 with unchanged cache lane, exact actual bit-derived ranges, raw-count destination capacity, source reservation live at funding, retained destination pointer, no truncation/unfinished rows, and request cleanup. Constant514 produces769rows, root128marks and final257ranges/cap257; held account522 releases to shell3 (payload519). Dynamic8128..8256 produces21rows, root64marks and [8192,8256), outputcap1; held10 releases to3 (payload7). Source-only zero root has no target/owned capacity; recursive work legitimately leaves shell3. Gain-only failure is genuinely dynamic with callback0; measured ample prefix + initial seed reaches the same first Mark exactly at MAX, refuses before any written bit or destination, and records the real typed error and cleanup.

## Literal work variability

The initial dynamic-only comparison correctly failed on additional constant-positive evidence. Relative to active-scoped, the other five captures differ at307 scalar leaves across95unique exact paths:15in constant-positive rows767/768 plus whole-invoke work,80in dynamic-positive. Maximum absolute delta4. Every difference is an integer absolute plan-work checkpoint: source before/init, first/last Mark before/after, row completion, or whole invoke. All outputs/capacities/errors/account lifetimes, structure, counts, native debit relations, zero case and gain-failure case remain exact.

Raw bodies, all six hashes, and every changed path/value/delta are retained. There is no current full-body equality claim, rewritten canonical body, fee subtraction or production fee/cap change. Pointer-hashed Domain OriginalInput collision-chain work is a plausible source-supported explanation; this audit does not claim an exact causal replay of each differing lookup.

## Source and limitations

All17 owned current files match final source pins. Initial unowned2920Main/2592Scope inputs and all34immutable oracle payloads hash exactly. Current build guards contain2937Main/2609Scope inputs. Main inherited source differences remain excluded from shipping authority; Scope is authoritative.

Earlier failures remain: nine unchanged wet/event budget regressions of the rejected heap flags; observer truncation; dynamic media qualification; unexplained early Mark reachability miss; absent-capacity assertion; AtomicBool drop lint; final9wet-seed instability whose passing repeats were not accepted as a fix; build11incorrect constant-driver assertion, including my incorrect static conclusion; and rejected dynamic-only final variance whitelist. The final gain-only failure fixture and direct ordered bit-run producer address concrete failures without repricing.

Destination quota refusal and callback/depth/numeric failures of this producer are not established by these fixtures. Seven real-context boundary tests establish constructor/bit-run/work-prefix behavior; they do not substitute for public-driver proof. No new Gate credit or whole-preparation claim follows.

Machine-readable independent results and exact pins are in this review directory. No full Main source map is copied.
