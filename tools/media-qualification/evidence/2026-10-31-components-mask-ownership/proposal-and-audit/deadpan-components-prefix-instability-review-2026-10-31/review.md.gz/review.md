# Components initial-prefix instability: causal source review

Read-only, scratch-only review. No root edits, builds, native runs, cap changes, seed search or acceptance change. The exact failing Scope library receipt is components-matrix9-scoped-deadpan-audio.stdout:548 passed,1 failed,24 ignored. The failed assertion was projected_marks>0 versus expected false, so the failure run had accepted at least one real root Mark before reaching its later actual plan-work limit.

## Concrete unstable variable

The test assumes that a measured first-Mark prefix from one fresh run is the exact initial work prefix of a second fresh run. Each run recompiles the checked document, creates a new StageAudio, constructs new graph/domain identities and a fresh verified WAV provider. It seeds the second ReadWork with MAX_PLAN_WORK_PER_READ minus the first run's absolute first-attempt plan_work.

That assumption is not guaranteed by current production accounting. shared_eq/original_inputs.rs::LookupKey contains context identity as a usize. LookupKey::new maps:
- Context::Root to kind0/context0, independent of any allocation address.
- Context::Domain to kind1/Arc::as_ptr(domain).
- Context::Retained to kind2/retained pointer.

bucket() hashes the complete key through DefaultHasher and reduces modulo64. Cache::find bills HASH_WORK6, then one actual plan-work unit per visited collision-chain entry. The same semantic range/depth can have a different bucket distribution when fresh Domain Arc addresses differ. Logical hit/miss identity remains checked, but the measured work to reach it need not remain constant.

The wet fixture selects actual Reverb on the root. Its Components callbacks enter shared_eq_node/node_description. Nonempty incoming Root context is resolved through admitted owner input/capture into a Domain or retained context; the fallback explicitly takes the sound context's processing Domain Arc. The graph's shared Original cache is used both by try_cached_original_for_prediction and shared_original_input_mode for those nested contexts. Root and pointer-keyed entries share the same64 bucket chains. Even a later Root key's lookup can therefore encounter address-dependent Domain entries.

This is an existing variable fee source, not random PCM or a newly invented weight. It is a strong concrete explanation for a few work units of first-Mark drift: if the measured run had more collision visits than the later run, MAX-first_measured leaves that difference available and the later run accepts Mark(s) before failing. Different allocator state and concurrent tests can change Arc addresses, so focused success and a later full-library miss are consistent with this mechanism.

The report does not claim a native reproduction of the exact collision delta. Parent diagnostics should correlate each run's actual first-attempt work with Cache::find bucket/visited-entry counts for Root/Domain/retained keys. A fixed first-prefix measurement should not be asserted solely because the checked document is equal.

## Paths that do not use a Domain pointer

A genuine no-wet/no-EQ Components request whose shared Original context remains Root uses only kind0/context0 in this cache. With no temporal callback, it does not enter shared_eq_node/node_description to allocate nested Domain contexts. SharedMix can still select Components from plan.has_audio_component_automation(), independently of wet sends. This is the appropriate bounded fixture direction for the strict initial-first-Mark test.

The Root branch is not merely a pointer compare disguised as stable identity. Its hash input literally contains0. The graph scope Arc is separately checked by validate_original_input_request; that identity is not part of the Root hash key or a variable traversal fee. As long as no non-Root entries are introduced, Root-only cache bucket chains depend on range/depth and deterministic insertion order, not allocation addresses.

Do not generalize this conclusion to all Root reads with temporal descendants: mixed Root/Domain entries still share buckets. Likewise a retained context is pointer-keyed too; replacing Domain with Retained would not solve the measurement assumption.

## Alternatives considered and excluded by source

- checked_wet_aggregate builds nodes and children deterministically using BTreeMap plus ordered segment indices.
- RenderPlan compile's temporary HashMap is populated from the sorted durations map and used for key lookup. It does not iterate that hash table to produce the node order; the compiled node loop is over document.nodes(). It does not supply the charged cache collision fee identified above.
- PublicProvider returns its one actual PreparedSource and records calls. cases::prepared verifies the same repository WAV bytes, SHA-256 content identity and reopened index for each run. No provider selection randomness appears in these helpers.
- WorkControl's reduced query_limits can produce an earlier legitimate query failure as initial work rises. Successful child construction still executes its actual operations; it cannot be assumed prefix-invariant across arbitrary cache/identity changes. This adaptive allowance is another reason not to infer a later boundary from a different run without checking its path.
- The reported error is Limit("plan work per read"), not Timeout. The ten-second deadline begins before WAV preparation, but elapsed native setup alone does not account for additional accepted root Mark bits or explain this exact work error.
- The Components legacy flag uses a thread-local RAII restore. The source inspected does not support claiming random document traversal or deliberate flag leakage as the cause.

## Correct scope of the fix

Keep the wet positive, dynamic, zero fixtures and all nine default wet/event regression assertions unchanged. Keep all production caps, canonical fees, cache identity behavior and actual Mark1 charges unchanged. Do not widen seed search, waive zero accepted Marks, retroactively fill the ledger at Mark, or normalize the observed prefix.

Use a separate genuine public no-wet/no-EQ Components fixture with Root-only cache keys for the initial-prefix refusal assertion. It must independently prove actual Components selection and actual root first Mark, then measure its prefix and replay the literal initial seed. Confirm exactly zero root accepted Marks, actual first-Mark work refusal, no destination reservation/storage, clean source/controller ledgers and preserved literal legacy/active bodies. This preserves the intended failure boundary rather than weakening it. The surface agent owns concrete fixture construction and parent owns fresh repeated/full-library execution.

If diagnostics show pointer-bucket comparisons account for the drift, retain that literal evidence and classify this as a test's unsupported cross-run prefix assumption. A production redesign for address-independent cache lookup work would be a separate unit with its own before evidence; it is not needed to qualify this mask-ownership change.
