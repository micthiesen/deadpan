from collections import Counter
from pathlib import Path
import argparse
import hashlib
import json
import shutil
import subprocess
import sys

parser = argparse.ArgumentParser()
parser.add_argument("prefix", help="capture prefix, for example components-inline-final7")
parser.add_argument("--capture-directory", default=None, help="directory containing canonical captures; defaults to this script directory")
parser.add_argument("--output", default="inline-components-capture-analysis.json")
parser.add_argument(
    "--base-analyzer",
    default="/tmp/deadpan-components-mask-qualification-2026-10-31/analyze_final_capture.py",
)
args = parser.parse_args()
script_dir = Path(__file__).resolve().parent
capture_dir = Path(args.capture_directory).resolve() if args.capture_directory else script_dir
prefix = args.prefix

old = json.loads((capture_dir / f"{prefix}-before-shared-scoped-canonical.json").read_text())
active_path = capture_dir / f"{prefix}-active-scoped-canonical.json"
active = json.loads(active_path.read_text())

before_native_cases = old["native_requests"]["cases"]
after_native_cases = active["native_requests"]["cases"]
assert isinstance(before_native_cases, list) and isinstance(after_native_cases, list)
assert len(before_native_cases) == len(after_native_cases) == 5
for before_case, after_case in zip(before_native_cases, after_native_cases):
    assert {key: value for key, value in before_case.items() if key != "operations"} == {
        key: value for key, value in after_case.items() if key != "operations"
    }, "native fixture/header changed"


# The established analyzer resolves files beside its own source file. Copy it
# beside the selected capture set so arbitrary run prefixes/directories work.
base_analyzer_source = Path(args.base_analyzer).resolve()
base_analyzer_copy = capture_dir / ".inline-base-analyze-final-capture.py"
shutil.copyfile(base_analyzer_source, base_analyzer_copy)
base_output = capture_dir / f"{prefix}-base-capture-analysis.json"
subprocess.run(
    [sys.executable, base_analyzer_copy.name, prefix, base_output.name],
    cwd=capture_dir,
    check=True,
)
base = json.loads(base_output.read_text())

cases = active.get("components_producer_cases", {}).get("cases")
assert isinstance(cases, list) and len(cases) == 4, "expected three success cases and one measured refusal"
expected = {
    "constant_block_positive": (0, "constant"),
    "dynamic_positive": (8128, "dynamic"),
    "constant_zero_emission": (0, "constant"),
    "measured_mark_work_refusal": (0, "dynamic"),
}
assert {case["name"] for case in cases} == set(expected), "missing or duplicated Components fixture"
counts = Counter()
receipts = []
for case in cases:
    name = case["name"]
    assert name in expected, name
    start, expected_driver = expected[name]
    trace = case["components_trace"]
    assert trace["schema"] == "components-inline-marks-v2", (name, trace.get("schema"))
    assert trace["unfinished"] is False and trace["truncated_rows"] is False
    assert trace["attempted_rows"] == len(trace["rows"])
    assert trace["dropped_rows"] == 0
    assert all(row.get("events_truncated") is not True for row in trace["rows"])
    candidates = [
        row for row in trace["rows"]
        if row.get("program_depth") == 0 and row.get("start") == start
    ]
    assert len(candidates) == 1, (name, candidates)
    row = candidates[0]
    assert row["parent_row_id"] is None
    assert row["source_heap_allocation"] is False
    assert row["source_heap_charge_frames"] == 0
    assert row["source_storage"] == "inline_bitset"
    assert row["inline_source_scope_closed"] is True
    assert row["source_frames"] == row["requested_frames"]
    assert 0 < row["requested_frames"] <= 256
    initial = row["inline_words_initial"]
    projected = row["inline_words_latest"]
    assert isinstance(initial, list) and isinstance(projected, list)
    assert len(initial) == len(projected) == row["inline_word_count"] == 4
    assert all(word == 0 for word in initial)
    assert row["inline_bytes"] == 4 * 8
    popcount = sum(word.bit_count() for word in projected)
    written = row["marks"]["written_count"]
    assert popcount == written, (name, popcount, written)

    actual_driver_reached = expected_driver in row["driver_kinds"]
    provider_was_used = case["provider_calls"] > 0
    root_positive_marks = written > 0
    assert row["parent_row_id"] is None
    assert actual_driver_reached, (name, expected_driver, row["driver_kinds"])
    assert provider_was_used, name
    assert root_positive_marks == (popcount > 0)
    # Success cases serialize these flags; refusal cases expose the source row
    # and error receipt only, so derive their facts from that same row.
    if "actual_driver_reached" in case:
        assert case["actual_driver_reached"] is actual_driver_reached
    if "provider_was_used" in case:
        assert case["provider_was_used"] is provider_was_used
    if "root_positive_marks" in case:
        assert case["root_positive_marks"] is root_positive_marks

    destination = row["destination_reservation"]
    source_frames = row["source_reservation_frames"]
    target_reserved_while_source_live = (
        isinstance(destination, dict)
        and source_frames > 0
        and destination["active_frames"] >= source_frames
    )
    destination_capacity = row["destination_storage"]["capacity"] if isinstance(row["destination_storage"], dict) else None
    if "target_reserved_while_existing_source_live" in case:
        assert case["target_reserved_while_existing_source_live"] is target_reserved_while_source_live
    if "destination_capacity" in case:
        assert case["destination_capacity"] == destination_capacity

    if name == "dynamic_positive":
        assert row["callback_count"] > 0
        assert case["root_dynamic_callbacks"] is True
    if name in ("constant_block_positive", "dynamic_positive"):
        assert case["exact_output_match"] is True
        assert case["legacy"] == case["active"], name
        assert popcount > 0 and row["raw_mark_count"] == popcount
        assert row["result"]["success"] is True
        assert row["result"]["owned"] is True
        assert row["result"]["destination_identity_preserved"] is True
        assert destination["accepted"] is True
        assert source_frames > 0
        assert target_reserved_while_source_live is True
        capacity = row["raw_mark_count"]
        assert row["destination_storage"]["capacity"] == capacity
        assert row["result"]["mask_capacity"] == capacity
        assert destination_capacity == capacity
        assert case["held_while_output_live"] == case["held_after_controller_drop"]
        assert case["held_while_output_live"] - case["live_after_output_drop"] == case["output_payload_frames"]
        assert case["output_payload_frames"] > 0
        for body in (case["legacy"], case["active"]):
            assert "sample_capacity" in body and "exhausted_capacity" in body
        counts["positive"] += 1
    elif name == "constant_zero_emission":
        assert case["exact_output_match"] is True and case["legacy"] == case["active"]
        assert popcount == 0 and row["raw_mark_count"] == 0
        assert row["result"]["success"] is True
        assert row["result"]["owned"] is False and row["result"]["mask_capacity"] == 0
        assert row["destination_reservation"] is None
        assert row["destination_storage"] is None
        assert target_reserved_while_source_live is False
        assert case["zero_emission_has_no_target"] is True
        assert destination_capacity is None
        assert case["output_payload_frames"] == 0
        assert case["held_while_output_live"] == case["live_after_output_drop"]
        for body in (case["legacy"], case["active"]):
            assert "sample_capacity" in body and "exhausted_capacity" in body
        counts["zero"] += 1
    else:
        assert case["failure_fixture"] == "checked_gain_aggregate"
        assert case["expected_driver"] == expected_driver == "dynamic"
        assert case["actual_driver_reached"] is True and actual_driver_reached
        assert case["root_callback_count"] == 0
        assert case["root_first_attempt_plan_work_before"] == row["marks"]["first_attempt"]["plan_work_before"]
        failed_first_attempt_work = row["marks"]["first_attempt"]["plan_work_before"]
        ample_first_attempt_work = case["ample_first_attempt_plan_work_before"]
        assert failed_first_attempt_work == 16 * 1024 * 1024
        assert ample_first_attempt_work + case["seed_from_actual_first_mark"] == 16 * 1024 * 1024
        assert case["actual_mark_refusal_reached"] is True
        assert row["result"]["success"] is False
        assert row["inline_source_scope_closed"] is True
        assert row["source_heap_allocation"] is False
        assert row["source_heap_charge_frames"] == 0
        assert row["raw_mark_count"] is None
        assert popcount == 0 and written == 0
        assert row["marks"]["attempt_count"] > 0
        assert any(event["kind"] == "mark_refused" for event in row["events"])
        assert row["destination_reservation"] is None
        assert row["destination_storage"] is None
        assert row["result"].get("mask_capacity") is None
        assert target_reserved_while_source_live is False
        assert case["legacy_at_same_work_seed"] is not None
        assert case["active"] == {
            "status": "Error",
            "error": 'Limit("plan work per read")',
        }
        assert row["result"]["error"] == case["active"]["error"]
        # Keep the bodies separate: the legacy lane can succeed at this seed.
        assert case["active_frames_after_request"] == 0
        assert case["sound_context_frames_after_request"] == 0
        counts["mark_refusal"] += 1

    receipts.append({
        "name": name,
        "expected_driver": expected_driver,
        "actual_driver_reached_from_root_row": actual_driver_reached,
        "provider_used_from_run_receipt": provider_was_used,
        "root_positive_marks_from_mark_receipt": root_positive_marks,
        "popcount": popcount,
        "mark_writes": written,
        "raw_mark_count": row["raw_mark_count"],
        "inline_source_scope_closed": row["inline_source_scope_closed"],
        "target_reserved_while_existing_source_live_from_reservations": target_reserved_while_source_live,
        "destination_capacity_from_storage_receipt": destination_capacity,
        "exact_legacy_output_match": case.get("exact_output_match"),
        "held_while_output_live": case.get("held_while_output_live"),
        "live_after_output_drop": case.get("live_after_output_drop"),
        "output_payload_frames": case.get("output_payload_frames"),
        "mark_refusal_reached": case.get("actual_mark_refusal_reached"),
        "failure_fixture": case.get("failure_fixture"),
        "failure_root_driver": case.get("expected_driver"),
        "failure_root_callbacks": case.get("root_callback_count"),
        "failure_root_first_mark_work": case.get("root_first_attempt_plan_work_before"),
        "failure_ample_first_mark_work": case.get("ample_first_attempt_plan_work_before"),
        "literal_legacy_body": case.get("legacy_at_same_work_seed"),
        "literal_active_body": case.get("active"),
    })

assert counts == Counter({"positive": 2, "zero": 1, "mark_refusal": 1}), counts
proof = {
    "capture_prefix": prefix,
    "capture_directory": str(capture_dir),
    "active_bytes": active_path.stat().st_size,
    "active_sha256": hashlib.sha256(active_path.read_bytes()).hexdigest(),
    "base_historical_analysis": base,
    "components_cases": counts,
    "producer_receipts": receipts,
    "limits": "Only the four explicit Components producer fixtures are attributed. Inline storage has no heap-reservation or stable moved-stack pointer claim. A pre-projection Mark refusal has no raw_mark_count because that pass was not reached. The legacy and active bodies are preserved literally without equality normalization.",
}
output_path = Path(args.output)
if not output_path.is_absolute():
    output_path = capture_dir / output_path
output_path.write_text(json.dumps(proof, indent=2) + "\n")
print(json.dumps({
    "capture_prefix": prefix,
    "capture_directory": str(capture_dir),
    "active_sha256": proof["active_sha256"],
    "historical_native_requests": base["counts"]["native_requests"],
    "components_cases": dict(counts),
}))
