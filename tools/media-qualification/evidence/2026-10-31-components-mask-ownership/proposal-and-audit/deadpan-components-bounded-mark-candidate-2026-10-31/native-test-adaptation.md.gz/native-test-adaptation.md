# Separate native test adaptation contract

Do not modify before34, prior canonical fixtures, caps, request sizes or source qualification. Existing actual checked constant/dynamic root fixtures and providers remain authoritative. The old Flags observer-specific assertions in bound_reads/components_mask_native_tests.rs need a deliberate inline-marker rewrite; production semantics tests keep complete PCM/range/provider assertions.

Replace source proof:
- source_init.success remains actual constructor success; assert source_storage=inline_bitset, source_heap_allocation=false, source_heap_charge_frames=0, source_frames=requested_frames within1..256, inline_word_count=ceil(MAX_OUTPUT_FRAMES/64), inline_bytes=actual sizeof words. Constructor words are allzero.
- Remove source_len/capacity=frames and bool-layout source-charge expectations. Do not replace them with fictional zero-capacity heap vectors.
- Remove source_identity_preserved, source_disposed and source_destination_allocations_distinct. Inline stack moves have no stable allocation pointer. Require inline_source_scope_closed on reached completed driver/depth/finalization paths; constructor failure may have no source.
- Keep actual constant/dynamic driver branch evidence and callback counts; assert Mark accepted/written counts stop exactly at actual refusal. Projection words must equal the real marked index set, not a mask inferred from PCM zeros.
- raw_mark_count is the actual postdepth popcount. Null on an earlier failure is honest. After a completed count, destination reservation must request exact m-capacity range vector plus actual Box Layout. The current source active/reservation must still be live at that real reserve event.
- For nonempty successful rows, destination cap=m and emitted len is the number of coalesced runs. Its real private pointer equals final mask pointer. No generic owned-merge or second-destination allocation work should appear in this lane. Check literal range values against the old singleton+sort+merge result.
- For zero m, destination_storage/reservation stay absent; no Account/AllocateVector/AllocateStorage arises from this producer. Whole-case account may already contain other legitimate D/E owners/shells, so prove local delta/phase absence rather than assert global live0.

Boundary/algorithm cases must use actual WorkControl plus StageAudio context (or real native checked fixture), never a fake ledger:
1. Frames1,63,64,65,127,128,129,255,256; empty marks, singleton last index, allmarks, alternating, runs crossing63/64,127/128,191/192 and final partial word. Compare actual output with literal prior singleton merged helper once per case.
2. Negative AudioSample start with checked end, preserving exact labels.
3. Invalid frames0/>256 rejected at the private marker and invalid mark index rejected before writing/debit. Existing public read_shared_program bounds remain the production proof; do not reject a general aggregate >256.
4. Every small real accepted-work prefix for marker construction, Mark, count, destination admission and run emission. Keep accepted work and exact error classification; no continuation after refused check/spend. Mark may consume a separate native lane budget from old canonical query work.
5. Cancellation/deadline at reached Mark and finalization boundaries, driver/depth errors closing inline scope, quota refusal reached only after actual count. Pending builder cleanup must return account payload live frames to actual prior shell/owners.
6. Actual root driver/checked real WAV with positive marks; actual dynamic fixture remains qualified. Observe destination reservation while existing source Components reservation is live. Keep provider/PCM/relative-depth behavior compared to immutable old lane.
7. Held nonempty result past local work/provider/controller destruction, and unchanged ordinary multi-output/direct fixture behavior.

Do not claim the nine work regressions are fixed until unchanged full-library tests run. Existing wet/event tests must still check independent finite-history PCM, root/child wet composition, silent Hold exclusions, repeat identity, cold partitions and returned owner history at the exact prior default requests.
