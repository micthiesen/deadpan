# Bounded marker static review

Independent reviewer /root/policy_output_design_review inspected the production core and run extraction without builds/native execution. No production blocker found.

Confirmed: bits!=0 establishes low<64 and positive width; high==64 branch excludes shift64; clearing advances; adjacent runs across word boundaries coalesce correctly; exact raw-m capacity is retained; no heap sort or second Vec.

Minor notes:
- Output retains an explicit control check before ComponentMarks::mark, which also checks before central spend checks. This is redundant checking, not duplicate debit; left unchanged to preserve the reviewed production patch.
- Neutral inline_words_latest/account_live_frames_at_completion labels replace projection labels because numeric/depth failure may snapshot before final projection. The adapter now makes no moved-stack pointer or source heap deallocation claim.

Unverified: compilation, actual controller/WorkControl prefix tests, destination residency/cleanup, all nine original default wet/event regressions and full matrix. These remain parent-owned runtime obligations.
