from pathlib import Path
import json,hashlib,difflib
root=Path('/tmp/deadpan-query-groundwork-2026-10-26/scoped');out=Path('/tmp/deadpan-components-bounded-mark-candidate-2026-10-31')
paths=['crates/deadpan-audio/src/shared_components.rs','crates/deadpan-audio/src/shared_components/outputs.rs','crates/deadpan-audio/src/shared_mix.rs','crates/deadpan-audio/src/shared_eq.rs','crates/deadpan-audio/src/components_mask_trace.rs']
old={p:(root/p).read_text() for p in paths};new=dict(old)
def edit(p,a,b):
 assert new[p].count(a)==1,(p,a[:90],new[p].count(a))
 new[p]=new[p].replace(a,b)
p=paths[0]
edit(p,'use super::point_suppression::ops::FlagBuffer;\n','')
edit(p,'#[path = "shared_components/outputs.rs"]','''#[path = "shared_components/marks.rs"]
mod marks;
pub(super) use marks::ComponentMarks;

#[path = "shared_components/outputs.rs"]''')
start=new[p].index('    pub(super) fn finish_flags(');end=new[p].index('    /// Execute the common contribution driver',start)
s=new[p][start:end].replace('finish_flags','finish_marks').replace('mut flags: FlagBuffer','mut marks: ComponentMarks').replace('OutputSuppression::Flags(flags.as_mut_slice())','OutputSuppression::Marks(&mut marks)').replace('MixedSuppression::PendingFlags { start, flags }','MixedSuppression::PendingMarks { start, marks }')
s=s.replace('''                #[cfg(test)]
                let (pointer, len, capacity, _) = flags.test_descriptor();
                drop(flags);
                #[cfg(test)]
                super::components_mask_trace::source_disposed(pointer, len, capacity);''','''                #[cfg(test)]
                super::components_mask_trace::inline_source_snapshot(&marks);
                #[cfg(test)]
                super::components_mask_trace::inline_source_closed();''')
assert 'flags' not in s
new[p]=new[p][:start]+s+new[p][end:]
p=paths[1]
edit(p,"    Flags(&'a mut [bool]),","    Marks(&'a mut ComponentMarks),")
edit(p,'Some(OutputSuppression::Flags(flags)) if flags.len() != frames','Some(OutputSuppression::Marks(marks)) if marks.frames() != frames')
edit(p,'Some(OutputSuppression::Flags(_)) | None','Some(OutputSuppression::Marks(_)) | None')
edit(p,'Some(OutputSuppression::Flags(flags)) =>','Some(OutputSuppression::Marks(marks)) =>')
edit(p,'''                let spent = point_suppression::ops::spend_work(
                    control,
                    point_suppression::ops::MaskWorkPhase::Mark,
                    1,
                );''','''                let spent = marks.mark(at, control);''')
edit(p,'                flags[at] = true;\n','')
p=paths[2]
edit(p,'ops::{FlagBuffer, MaskContext, MaskWorkPhase, begin_ranges}','ops::{MaskContext, MaskWorkPhase, begin_ranges}')
new[p]=new[p].replace('PendingFlags','PendingMarks').replace('finish_with_component_flags','finish_with_component_marks').replace('component_flags','component_marks')
edit(p,'''    PendingMarks {
        start: AudioSample,
        flags: FlagBuffer,
    },''','''    PendingMarks {
        start: AudioSample,
        marks: shared_components::ComponentMarks,
    },''')
start=new[p].index('            Self::PendingMarks { start, flags } => {');end=new[p].index('            Self::Pending { start, permissions } => {',start)
new[p]=new[p][:start]+'''            Self::PendingMarks { start, marks } => {
                #[cfg(test)]
                super::components_mask_trace::inline_source_snapshot(&marks);
                let result = marks.finish(start, context);
                #[cfg(test)]
                super::components_mask_trace::inline_source_closed();
                result
            }
'''+new[p][end:]
edit(p,'component_marks: Option<FlagBuffer>','component_marks: Option<shared_components::ComponentMarks>')
edit(p,'''            let flags = component_marks.ok_or(PlanError::InvalidPlan(
                "component suppression destination absent",
            ))?;
            return self.components.finish_flags(
                self.output_voice,
                self.output_aliases,
                flags,''','''            let marks = component_marks.ok_or(PlanError::InvalidPlan(
                "component suppression destination absent",
            ))?;
            return self.components.finish_marks(
                self.output_voice,
                self.output_aliases,
                marks,''')
p=paths[3]
new[p]=new[p].replace('component_flags','component_marks').replace('finish_with_component_flags','finish_with_component_marks').replace('PendingFlags','PendingMarks')
edit(p,'''            #[cfg(test)]
            if components_receipt.is_some() {
                super::components_mask_trace::source_reservation_begin();
            }
''','')
edit(p,'point_suppression::ops::begin_flags(&mut self.masks(control), frames).map(Some)','shared_components::ComponentMarks::new(frames, control).map(Some)')
edit(p,'''            #[cfg(test)]
            if components_receipt.is_some() {
                super::components_mask_trace::source_reservation_end();
            }
''','')
edit(p,'''            #[cfg(test)]
            let components_source_descriptor = components_receipt.and_then(|_| {
                component_marks
                    .as_ref()
                    .map(point_suppression::ops::FlagBuffer::test_descriptor)
            });
''','')
edit(p,'''                if let (Some(receipt), Some((pointer, len, capacity, _))) =
                    (components_receipt, components_source_descriptor)
                    && matches!(&mixed.suppressed, MixedSuppression::PendingMarks { .. })
                {
                    drop(mixed.suppressed);
                    super::components_mask_trace::source_disposed(pointer, len, capacity);''','''                if let Some(receipt) = components_receipt
                    && let MixedSuppression::PendingMarks { marks, .. } = &mixed.suppressed
                {
                    super::components_mask_trace::inline_source_snapshot(marks);
                    drop(mixed.suppressed);
                    super::components_mask_trace::inline_source_closed();''')
p=paths[4]
edit(p,'use super::{StageAudioError, WorkControl, point_suppression::AudioSuppressionMask};','use super::{StageAudioError, WorkControl, point_suppression::AudioSuppressionMask};')
new[p]=new[p].replace('    source_ptr: usize,\n','').replace('    source_len: usize,\n','').replace('    source_capacity: usize,\n','')
edit(p,'''            "enabled": s.enabled,''','''            "schema": "components-inline-marks-v2",
            "enabled": s.enabled,''')
edit(p,'''                "source_len": null,
                "source_capacity": null,
                "source_charge_frames": null,
                "source_element_bytes": std::mem::size_of::<bool>(),''','''                "source_storage": "inline_bitset",
                "source_heap_allocation": false,
                "source_heap_charge_frames": 0,
                "source_frames": request.frames,
                "inline_word_count": null,
                "inline_bytes": null,
                "inline_words_initial": null,
                "inline_words_latest": null,
                "raw_mark_count": null,''')
edit(p,'''                "source_disposed": false,
                "source_identity_preserved": false,''','''                "inline_source_scope_closed": false,''')
new[p]=new[p].replace('super::point_suppression::ops::FlagBuffer','super::shared_components::ComponentMarks')
edit(p,'''            Ok(Some(flags)) => {
                let (ptr, len, cap, charge) = flags.test_descriptor();
                row.source_ptr = ptr;
                row.source_len = len;
                row.source_capacity = cap;
                row.value["source_len"] = json!(len);
                row.value["source_capacity"] = json!(cap);
                row.value["source_charge_frames"] = json!(charge);''','''            Ok(Some(marks)) => {
                row.value["inline_word_count"] = json!(marks.test_words().len());
                row.value["inline_bytes"] = json!(std::mem::size_of_val(marks.test_words()));
                row.value["inline_words_initial"] = json!(marks.test_words());''')
edit(p,'''pub(super) fn source_reservation_begin() {
    mutate_current(|row| row.value["reservation_phase"] = json!("source"));
}
pub(super) fn source_reservation_end() {
    mutate_current(|row| row.value["reservation_phase"] = Value::Null);
}
''','')
start=new[p].index('pub(super) fn source_disposed(');end=new[p].index('pub(super) fn complete(',start)
new[p]=new[p][:start]+'''pub(super) fn inline_source_snapshot(marks: &super::shared_components::ComponentMarks) {
    mutate_current(|row| {
        row.value["inline_words_latest"] = json!(marks.test_words());
    });
}
pub(super) fn counted_marks(count: usize) {
    mutate_current(|row| row.value["raw_mark_count"] = json!(count));
}
pub(super) fn inline_source_closed() {
    mutate_current(|row| row.value["inline_source_scope_closed"] = json!(true));
}
pub(super) fn source_account_after(live: u64) {
    mutate_current(|row| row.value["account_live_frames_at_completion"] = json!(live));
}
'''+new[p][end:]
edit(p,'let (ok, error, len, cap, owned, same, distinct) = match result','let (ok, error, len, cap, owned, same) = match result')
edit(p,'''                row.destination_ptr != 0
                    && row.destination_ptr == mask.as_slice().as_ptr() as usize,
                row.source_ptr != 0
                    && row.destination_ptr != 0
                    && row.source_ptr != row.destination_ptr,''','''                row.destination_ptr != 0
                    && row.destination_ptr == mask.as_slice().as_ptr() as usize,''')
edit(p,'''Err(error) => (false, Some(format!("{error:?}")), 0, 0, false, false, false),''','''Err(error) => (false, Some(format!("{error:?}")), 0, 0, false, false),''')
edit(p,'''            "source_destination_allocations_distinct": distinct,
''','')
newfile='crates/deadpan-audio/src/shared_components/marks.rs'
new[newfile]='''//! Inline suppression marks for the one bounded Components output.
//! This buffer is never a general ReadBlock mask or a cache-owned allocation.
use super::*;
use crate::stages::point_suppression::ops::{
    MaskContext, MaskWorkPhase, begin_ranges, spend_work,
};

const WORD_BITS: usize = u64::BITS as usize;
const WORDS: usize = (MAX_OUTPUT_FRAMES as usize).div_ceil(WORD_BITS);

pub(in crate::stages) struct ComponentMarks {
    frames: usize,
    words: [u64; WORDS],
}

impl ComponentMarks {
    pub(in crate::stages) fn new(
        frames: usize,
        control: WorkControl<'_>,
    ) -> Result<Self, StageAudioError> {
        control.check()?;
        if frames == 0 || frames > MAX_OUTPUT_FRAMES as usize {
            return Err(StageAudioError::Range);
        }
        // Charge the actual fixed word initialization before doing it.
        spend_work(control, MaskWorkPhase::Zero, WORDS)?;
        Ok(Self {
            frames,
            words: [0; WORDS],
        })
    }

    pub(in crate::stages) fn frames(&self) -> usize {
        self.frames
    }

    pub(in crate::stages) fn mark(
        &mut self,
        at: usize,
        control: WorkControl<'_>,
    ) -> Result<(), StageAudioError> {
        control.check()?;
        if at >= self.frames {
            return Err(StageAudioError::Range);
        }
        spend_work(control, MaskWorkPhase::Mark, 1)?;
        self.words[at / WORD_BITS] |= 1_u64 << (at % WORD_BITS);
        Ok(())
    }

    #[cfg(test)]
    pub(in crate::stages) fn test_words(&self) -> &[u64] {
        &self.words
    }

    pub(in crate::stages) fn finish<C: MaskContext>(
        self,
        start: AudioSample,
        context: &mut C,
    ) -> Result<AudioSuppressionMask, StageAudioError> {
        let mut count = 0_usize;
        for word in &self.words {
            context.check()?;
            context.spend(MaskWorkPhase::Scan, 1)?;
            count = count
                .checked_add(word.count_ones() as usize)
                .ok_or(StageAudioError::Range)?;
        }
        #[cfg(test)]
        crate::stages::components_mask_trace::counted_marks(count);
        if count == 0 {
            context.check()?;
            return Ok(AudioSuppressionMask::default());
        }

        // Keep the old raw singleton count as funded capacity, even though
        // ordered emission coalesces the actual set bits into fewer ranges.
        let mut destination = begin_ranges::<AudioSample, C>(context, count)?;
        #[cfg(test)]
        crate::stages::components_mask_trace::destination_storage(
            destination.as_slice().as_ptr() as usize,
            destination.capacity(),
        );
        let mut pending: Option<Range<AudioSample>> = None;
        for (index, mut bits) in self.words.into_iter().enumerate() {
            context.check()?;
            context.spend(MaskWorkPhase::Scan, 1)?;
            while bits != 0 {
                context.check()?;
                context.spend(MaskWorkPhase::Scan, 1)?;
                let low = bits.trailing_zeros() as usize;
                let width = (bits >> low).trailing_ones() as usize;
                let high = low + width;
                // Full-word runs must never shift a u64 by 64.
                bits = if high == WORD_BITS {
                    0
                } else {
                    bits & (!0_u64 << high)
                };
                let left = index * WORD_BITS + low;
                let right = index * WORD_BITS + high;
                if right > self.frames {
                    return Err(StageAudioError::Range);
                }
                let range = AudioSample(start.0 + left as i64)
                    ..AudioSample(start.0 + right as i64);
                match pending.as_mut() {
                    Some(previous) if previous.end == range.start => {
                        context.spend(MaskWorkPhase::Map, 1)?;
                        previous.end = range.end;
                    }
                    _ => {
                        if let Some(previous) = pending.take() {
                            destination.push(previous, context)?;
                        }
                        pending = Some(range);
                    }
                }
            }
        }
        if let Some(previous) = pending {
            destination.push(previous, context)?;
        }
        // No sort or second Vec: each bit run was visited in increasing order.
        destination.finish(context)
    }
}
'''
pins={'schema':'components-bounded-mark-candidate-v1','authority':str(root),'published_base':'69698b678fd8a75dd644993d7d2a9846986d6911','state':'F6 integrated unpublished; replaces unshipped flag producer','files':[]}
core=[];adapter=[]
for rel in new:
 before=old.get(rel,'')
 for mode,data in [('before',before),('new',new[rel])]:
  path=out/mode/rel;path.parent.mkdir(parents=True,exist_ok=True);path.write_text(data)
 pins['files'].append({'path':rel,'before_exists':rel in old,'before_sha256':hashlib.sha256(before.encode()).hexdigest() if rel in old else None,'new_sha256':hashlib.sha256(new[rel].encode()).hexdigest()})
 patch=''.join(difflib.unified_diff(before.splitlines(True),new[rel].splitlines(True),fromfile='a/'+rel if rel in old else '/dev/null',tofile='b/'+rel))
 pp=out/'patches'/(Path(rel).stem+'.patch');pp.parent.mkdir(parents=True,exist_ok=True);pp.write_text(patch)
 (adapter if rel.endswith('components_mask_trace.rs') else core).append(patch)
(out/'production.patch').write_text(''.join(core));(out/'observer-adapter.patch').write_text(''.join(adapter))
(out/'source-pins.json').write_text(json.dumps(pins,indent=2)+'\n')
