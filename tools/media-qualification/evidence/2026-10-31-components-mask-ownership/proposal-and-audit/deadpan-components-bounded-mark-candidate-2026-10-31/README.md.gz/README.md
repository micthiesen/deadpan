# F fix candidate: bounded inline Components marks

Scope authority: /tmp/deadpan-query-groundwork-2026-10-26/scoped, integrated F6 unpublished. Published base E is 69698b678fd8a75dd644993d7d2a9846986d6911. before34 and all earlier oracles remain immutable. This scratch replaces the unshipped Flags producer, not E's pending permission grid or the general native mask implementation. No root edits, build, native run, Git, cap/weight change, fixture generation or runtime success claim.

## Concrete production

production.patch contains five files: shared_components.rs, shared_components/outputs.rs, shared_mix.rs, shared_eq.rs, and new private shared_components/marks.rs. before/ and new/ are exact Scope snapshots/candidate text, with hashes in source-pins.json. observer-adapter.patch is separate and required for truthful cfg(test) receipts.

The actual controlled production boundary is read_shared_program: control check, frames !=0 and <=MAX_OUTPUT_FRAMES (256), depth, then checked start+frames before query/source work. Its shared-input and recursive-tile callers chunk to MAX_OUTPUT_FRAMES. A general ReadBlock may aggregate more frames; it cannot pass an oversized single program to this marker. Ordinary direct cfg(test) Components finish and ordinary multi-output remain unchanged.

ComponentMarks is private to shared_components, with fixed [u64; ceil(MAX_OUTPUT_FRAMES/64)] and actual frame length. On the pinned constant it has four words, no Vec/Box/Arc/lease and no heap source charge. Its constructor rechecks the closed bound and debits the four actual word initializations through real WorkControl before [0;WORDS]. Each mark checks the real frame index and central Mark1 before setting its bit. Output sink validation compares its actual frame length to PCM length. Constant/dynamic numeric loops and their mark call sites remain literal: all original finite validation and PCM assignment precede the mark, and no StageAudio borrow crosses callbacks.

MixedSuppression::PendingMarks moves only these inline words plus the original AudioSample start until the existing post-callback depth check. Source Components residency remains funded by the unchanged live read_shared_program reservation until its normal tail. Only after depth does finish:
1. Bill Scan1 per actual word and popcount actual raw set bits m.
2. For m0 return default with no final payload reservation, account initialization, vector or Box caused by this producer.
3. Otherwise begin_ranges(m) through the real StageAudio context while the existing source reservation and inline marks remain live. The requested Layout covers exact raw-mark capacity m plus the destination Storage Box; the existing account shell is real/lazy.
4. Visit each word and each contiguous set-bit run in increasing order, billing bounded Scan work before extraction. Full-word runs explicitly handle high==64, avoiding a shift by64. Tail/end bounds remain checked. Adjacent runs across word boundaries coalesce using one billed Map mutation.
5. Push each completed merged run through the funded builder and finish directly into its Box. No second vector, no generic heapsort, no postprocessing copy and no shrink/refund. Capacity stays m even when emitted run count r<m.

The source inline value has no heap-allocation identity. The destination Vec pointer/capacity remains the same from builder allocation through the final mask. Once the actual mask leaves read_shared_program, existing native owner lifetime/drop behavior applies, independent of local ReadWork/controller lifetime. No bitset carrier enters WideBlock/cache/public output.

The ordinary replay branch is literal. Existing scalar work, DSP/filter history, route/owner validation, content/query fees, limits and request sizes are unchanged. Native Mark still debits once per actual driver mark. Eliminating Zero(frames), full-frame count/projection scans and generic sort removes operations themselves. New work is four-word initialization/counting, one-word/run extraction, cross-word compaction mutations, real allocation and actual emitted pushes. Native receipts remain separate from old canonical work.

## Static causal evidence and limits

Main full stages receipt recorded 194 pass/nine Limit("plan work per read") failures in real default wet/event reads. Source tests unwrap prepare_authored_bus for six 4,800-frame repeated source iterations or a 48,000-frame event composition. Independent review found Reverb history196,096frames /256 =766 recursive Components programs. Unshipped F charged per-frame Zero and Scan at every program, and positive masks paid full second scan/copy/heap sort. This candidate makes marker initialization/count bounded by four words and dense run traversal bounded by four word-runs, while preserving Mark at each actual driver event.

It is not a runtime fix claim. Parent must rerun the exact nine failures and the full matrix under existing caps. Work/quota cancellation may still legitimately refuse at the new real boundary. General mask FlagBuffer and owned merge remain unchanged for their other consumers.

## Required integration and receipts

The observer adapter uses schema components-inline-marks-v2, removes heap-source len/capacity/charge/identity/disposal and distinct-source-allocation claims, and reports inline words/frame bound/no source heap charge instead. destination_storage still privately compares the real allocated Vec pointer to final mask pointer. inline_source_scope_closed denotes consumed logical scope, not moved-stack pointer stability or physical stack deallocation. It records initialization/projection words, raw m and actual destination cap. Existing source_reservation_frames continues to mean the real preexisting Components reservation; it is not a bitset ticket.

The adapter changes no old frozen bodies. Existing F native assertions about initialized flags len=frames, bool payload frames, distinct allocations and source heap disposal do not apply and must not silently survive under new names. native-test-adaptation.md gives the separate evidence obligations and specific assertions to replace.

Parent owns integration preserving Main WIP, formatting, compilation, tests, fresh full after captures, receipt review and publication. No Cargo/native execution was performed here. A prospective Tape contract remains separate; it provides no F credit.
