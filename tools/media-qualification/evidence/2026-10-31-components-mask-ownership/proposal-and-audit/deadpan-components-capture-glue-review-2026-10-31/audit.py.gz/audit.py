from pathlib import Path
import hashlib,json
s=Path('/tmp/deadpan-query-groundwork-2026-10-26/scoped')
r=Path('/tmp/deadpan-components-mask-qualification-2026-10-31')
e=Path('/tmp/deadpan-shared-mix-mask-qualification-2026-10-31')
out=Path('/tmp/deadpan-components-capture-glue-review-2026-10-31')
def pin(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  while chunk:=f.read(1024*1024):h.update(chunk)
 return {'path':str(p),'bytes':p.stat().st_size,'sha256':h.hexdigest()}
rels=['stages.rs','shared_mix_mask_request.rs','components_mask_request.rs','root_mask_request.rs','point_policy_request.rs','shared_mix.rs','shared_eq.rs','shared_components.rs','bound_reads/native_mask_after.rs','bound_reads/retained_host_pairs.rs','bound_reads/internal_suppression_baseline.rs','bound_reads/internal_transfer_entries.rs','shared_mix_mask_trace.rs','point_suppression/ops.rs']
files=[s/'crates/deadpan-audio/src'/p for p in rels]
before=r/'before/scoped/crates/deadpan-audio/src/bound_reads/native_mask_after.rs'
files += [before,r/'before-freeze-proof.json',r/'freeze_before.py']
f=s/'crates/deadpan-audio/tests/fixtures/components-mask-baseline-v1/snapshot.json'
files.append(f)
for mode in ['active','active2','active3']:
 for variant in ['main','scoped']:files.append(e/f'shared-mix-final3-{mode}-{variant}-canonical.json')
rows=[pin(p)for p in files]
frozen=pin(f)
target={'bytes':35593716,'sha256':'9d6f3c67d9d611f46e75360006845a1b9419b30168a983db1ca9e4cf79c8be0a'}
checks={'fixture_exact':all(frozen[k]==v for k,v in target.items()),
'six_E_canonical_stream_hashes_exact':all(all(row[k]==v for k,v in target.items())for row in rows[-6:])}
old=before.read_text();new=(s/'crates/deadpan-audio/src/bound_reads/native_mask_after.rs').read_text()
start='        value["schema"] = json!("active-shared-mix-mask-after-v1");'
a=old[old.index(start):old.index('    let file =',old.index(start))]
a=a[:a.rfind('    }')]
b=new[new.index('fn shared_mix_checkpoint'):new.index('fn root_checkpoint')]
b=b[b.index('    value["schema"]'):b.rfind('}')]
checks['factored_E_header_statements_literal']=[line.strip()for line in a.strip().splitlines()]==[line.strip()for line in b.strip().splitlines()]
checks['capture_guard_and_reset_literal']=old[:old.index('#[test]')]==new[:new.index('#[test]')]
checks['observed_body_literal']=old[old.index('fn observed_body'):old.index('#[test]',old.index('fn observed_body'))]==new[new.index('fn observed_body'):new.index('#[test]',new.index('fn observed_body'))]
checks['root_checkpoint_literal']=old[old.index('fn root_checkpoint'):old.index('fn observed_body')]==new[new.index('fn root_checkpoint'):new.index('fn observed_body')]
v=json.loads(f.read_text())
checks['frozen_header']={k:v[k]for k in ['schema','published_checkpoint','shared_mix_mask_checkpoint','shared_mix_mask_before']}
checks['frozen_fixture_excludes_identity']=not any(k in v or k in v['native_requests']for k in ['variant','source_sha256'])
(out/'source-pins.json').write_text(json.dumps(rows,indent=2)+'\n')
(out/'audit-results.json').write_text(json.dumps(checks,indent=2)+'\n')
print(json.dumps(checks,indent=2))
