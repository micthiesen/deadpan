# Dynamic Components sound fixture qualification repair

Candidate only. No root edit, build, native execution, Git, prefix/observer change, cap/fee change or before34 modification.

candidate.patch adds exactly two lines inside checked_dynamic_sounds and requires no imports. It sets assets.media.source_qualification to the existing checked fixture identifier "b".repeat(64) and sets still_image=false.

Authority is the existing bound_reads/authored_eq.rs::allowed_sound_history at687-688, which performs those identical writes before constructing the same allowed/forbidden SoundEvent pair over media0..8192. The typed version of the same pattern also exists in authored_eq.rs at414-415. This uses actual existing fixture schema/bytes, not a new qualification schema or bypass.

Causal check: controlled_reads::fixture_document_at_rate gives the base media asset audio span0..8197, still_image=true and source_qualification=None. The checked helper clones that asset while replacing only nodes. Core sound_events.rs explicitly rejects event assets with no source_qualification, then checks that the event span lies inside the qualified audio span. The dynamic event span0..8192 is already inside0..8197, so neither the span nor real PreparedSource needs enlargement.

The repair preserves the root Sequence of source4096/pause4096/tail4096, both events and allowances, actual PublicProvider Stereo48000, varying owner-layer gain envelope over0..12288, Saturation/Equalizer/ClipGain order, and all requested read windows. Current dynamic cases request8128/128 and cross the8192 event/pause boundary. No request transition was moved to obtain a preferred result.

before/new hold complete source snapshots for provenance, but integration must apply the function-local hunk against current text because parent diagnostics elsewhere in this file may change. function-before.rs/function-new.rs isolate the exact function. A text check proves removing only the two inserted lines recovers the complete original file.

Function-only rustfmt succeeded. Parsing the modified ProjectDocument and executing the public native read are owed to the parent; no pass or dynamic-driver reachability is claimed by this source-only repair. source-pins.json pins the exact current fixture and its checked helper/core validation authorities.
