fn checked_dynamic_sounds() -> Checked {
    let rate = FrameRate::new(48_000, 1).unwrap();
    let mut setup = checked(
        vec![id("a"), id("pause"), id("tail")],
        BTreeMap::from([
            (id("a"), source(rate, 0, 4096, 4096)),
            (id("pause"), hold(4096)),
            (id("tail"), hold(4096)),
        ]),
    );
    let mut wire = setup.wire.clone();
    wire["assets"]["media"]["source_qualification"] = serde_json::json!("b".repeat(64));
    wire["assets"]["media"]["still_image"] = serde_json::json!(false);
    let audio = match source(rate, 0, 8192, 8192).kind {
        NodeKind::Source { source } => source.audio.unwrap(),
        _ => unreachable!("public source helper"),
    };
    let event = SoundEvent {
        owner: id("root"),
        label: "Independent".into(),
        mapping: SourceAudioMapping::natural_rate(audio.span, rate).unwrap(),
        source: audio,
        offset: AudioSample(0),
        treatments: AudioTreatments::default(),
        start_edge: AudioEdgePolicy::Hard,
        end_edge: AudioEdgePolicy::Hard,
        overflow: SoundOverflowPolicy::Reject,
    };
    wire["sounds"] = serde_json::json!({"allowed": event.clone(), "forbidden": event});
    wire["sound_allowances"] = serde_json::json!({
        "allowed": SoundHoldAllowances::try_from(vec![SoundHoldIssuer::Node {
            instance: InstancePath { node: id("pause"), repeats: vec![] }
        }]).unwrap()
    });

    let recipe = EqualizerRecipe::new(
        [6000, -6000, 3000].map(|value| GainDb::new(value).unwrap()),
        None,
        None,
    )
    .unwrap();
    let saturation = Saturation::new(GainDb::new(9000).unwrap()).unwrap();
    let gain = ClipGain::new(
        GainDb::UNITY,
        false,
        vec![
            GainEnvelope::new(
                GainClock::OwnerOutput,
                GainRange::new(ExactRatio::ZERO, ExactRatio::integer(12288)).unwrap(),
                GainDb::UNITY,
                vec![
                    GainSegment::new(
                        ExactRatio::integer(12288),
                        GainDb::new(-1200).unwrap(),
                        GainCurve::Linear,
                    )
                    .unwrap(),
                ],
            )
            .unwrap(),
        ],
        vec![],
    )
    .unwrap();
    let treatments = AudioTreatments::with_equalizer_stages(
        vec![
            AudioTreatmentStage::Saturation,
            AudioTreatmentStage::Equalizer,
            AudioTreatmentStage::ClipGain,
        ],
        Some(gain),
        Some(saturation),
        None,
        Some(recipe),
    )
    .unwrap();
    let mut nodes: BTreeMap<NodeId, BeatNode> =
        serde_json::from_value(wire["nodes"].clone()).unwrap();
    nodes.get_mut(&id("root")).unwrap().audio_treatments = treatments;
    wire["nodes"] = serde_json::to_value(nodes).unwrap();
    setup.document = ProjectDocument::from_json(&wire.to_string());
    setup.wire = wire;
    setup
}
