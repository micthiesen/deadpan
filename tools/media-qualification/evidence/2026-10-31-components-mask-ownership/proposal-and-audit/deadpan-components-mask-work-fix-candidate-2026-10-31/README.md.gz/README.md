# F Components work regression: direct admitted emitted Vec

Scratch production candidate against Scope's integrated, unpublished F. Published base E is 69698b678fd8a75dd644993d7d2a9846986d6911. No root writes, Cargo, native execution, Git, caps, request changes, oracle generation or tests were performed here. Parent owns integration and all qualification.

## Evidence and fix

Actual Main full stages receipt: 194 pass, nine ordinary default-read failures with Limit("plan work per read"). Failures are event_returns::event_return_enters_the_parent_return_without_self_feedback and the eight wet_owners cases listed in failure-receipt-pins.json. Their helpers unwrap public prepare_authored_bus on real fixture PCM: wet_owners base has six 4,800-frame iterations; event_returns requests a 48,000-frame composition. These are normal output correctness/history tests, not artificial low-budget probes.

Static F cause is unconditional per-program work: begin_flags initializes each frame with Zero1, then PendingFlags scans every frame even if no mark occurred. A positive mask adds another full-frame scan, a second destination vector, per-range copying and generic owned heapsort. Independent policy_output_design_review reports the actual Reverb history spans 196,096 input frames, about 766 recursive 256-frame Components programs. Exact causal per-case accepted-work totals still require parent runtime receipts; the work cap itself is unchanged 16,777,216.

production.patch replaces only Components' unshipped heap flag lane with a pre-admitted RangeBuilder<AudioSample>, capacity equal to the actual single-output frame count, length initially zero:
1. After verify_prediction/released reservation cleanup, before Components callbacks, the actual StageAudio mask context reserves the future vector and Box payload via existing begin_ranges. The vector allocation does not initialize frame entries.
2. Components borrows that builder as OutputSuppression::AdmittedRanges. Its sink validates empty actual length and sufficient already funded capacity separately from PCM length. Legacy Ranges/multiple outputs remain literal.
3. At the exact existing post-finite/post-PCM mark site, RangeBuilder::push_marked uses genuine WorkControl and central ops::spend_work(Mark,1) before pushing the actual singleton. It has no StageAudio/context reference, does not allocate or reserve, and cannot grow beyond funded capacity. No fake MaskContext is involved.
4. The owned pending builder crosses callbacks and depth validation. PendingRanges then publishes its same Vec in the precharged Box and uses existing owned merge after depth. No second range vector or source flags exist. A zero-mark builder is physically dropped and returns default, with no Box and no full-frame scan. Accepted account shell can remain live.
5. Normal read_shared_program's reservation tail remains after finalization and error disposal. The builder owns a real account charge independently, including through nested callbacks.

The source vector is also the destination vector. Pointer identity and funded capacity survive finish/merge. Box physical allocation occurs after depth; its bytes were included in the source pending charge before callbacks. All allocation/copy/compaction changes are new native accounting work; old DSP/query/visitor charges are unchanged. Mark still debits once per actual mark. Removing F's Zero/full-frame Scan/copy operations removes the operations themselves, not a fee for work still performed.

## Files and integration

production.patch contains five production files:
- point_suppression/ops.rs: closed WorkControl-only marked push and borrowed cfg(test) descriptor.
- shared_components/outputs.rs: admitted range sink and unchanged mark location.
- shared_components.rs: finish_ranges returning PendingRanges.
- shared_mix.rs: PendingRanges and final same-allocation publication.
- shared_eq.rs: actual pre-callback begin_ranges and matching pending integration.

before/ and new/ contain exact Scope files. source-pins.json records SHA-256 per before/new. Per-file patches are under patches/. Main WIP was never copied. A separate observer-adapter.patch is required for cfg(test) compilation and truthful receipts; it is not production instrumentation.

The adapter uses schema components-admitted-range-custody-v2. It changes source element Layout from bool to Range<AudioSample>, records initial len0 and later emitted length separately, reports source_vec_transferred for nonempty success, and retains distinct/disposed booleans as actual booleans. It does not assert a source allocation was freed after moving its same Vec into output. Driver/depth errors record actual live builder len at disposal. Zero marks drop the vector; nonempty output retains its full funded frame capacity. Native tests asserting flags len=frames, exact-mark destination capacity or distinct allocation pointers must be rewritten to this real custody contract. Do not merely change expected numbers and call old flags proof sufficient.

No block.rs arithmetic or numeric loop changed. Existing ordinary test finish wrapper still calls the original ordinary Components finish, including E/F-only literal replay. Existing E Pending permission lane is untouched and excludes PendingRanges from its observer.

## Limits and required qualification

This is the smallest concrete direct-custody fix, not a claim that all nine now pass. Existing owned merge still heapsorts ascending singleton emissions, so positive masks may retain significant O(m log m) work. If actual parent reruns show that dominates, use a producer-specific checked ordered compaction/run emission, not a cap increase or weight waiver. Independent reviewer suggested a private fixed four-word mark bitset because actual read_shared_program chunks are at most 256; that is a separate alternative design, not implemented here.

Direct pre-admission reserves capacity=frames even for sparse or zero marks. Compared with F's bool source plus exact mark-count destination, sparse retained capacity and pre-callback payload pressure can increase; dense overlap loses the extra source vector. Actual successful output capacity therefore need not equal previous exact-mark capacity. No shrink/refund is attempted. Parent must measure quota minima and whole-read pressure under default caps, including nested wet/event history, before accepting this representation.

Required parent checks:
- The exact nine failing full-library paths plus the full default matrix, keeping current PCM/history/provider assertions and request sizes.
- Fresh complete after capture against immutable before34, with explicit range-custody receipt/schema and actual capacity/account differences.
- Zero marks: no Zero/count Scan/projection Scan; empty result but truthful pending charge during callbacks and residual shell.
- Positive marks: once-only Mark, same source/final vector pointer, cap=validated frames, final Box after depth, output retained past local ReadWork/controller.
- Work/cancel refusal at an actual mark, pending builder disposal on driver/depth error, final-storage/merge refusal; preserve accepted prefixes and all prior canonical work.
- Real pre-callback quota failure, including sparse capacity pressure, without provider/callback execution after refusal.
- Existing ordinary multi-output/direct fixture tests unchanged; no broad surface acceptance.

No runtime fix is claimed. All native execution and test adaptation remain parent-owned.
