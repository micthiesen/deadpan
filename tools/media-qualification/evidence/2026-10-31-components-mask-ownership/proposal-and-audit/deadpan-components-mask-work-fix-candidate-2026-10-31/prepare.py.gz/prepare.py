from pathlib import Path
import hashlib,json,difflib
root=Path('/tmp/deadpan-query-groundwork-2026-10-26/scoped')
out=Path('/tmp/deadpan-components-mask-work-fix-candidate-2026-10-31')
files=['crates/deadpan-audio/src/point_suppression/ops.rs','crates/deadpan-audio/src/shared_mix.rs','crates/deadpan-audio/src/shared_components.rs','crates/deadpan-audio/src/shared_components/outputs.rs','crates/deadpan-audio/src/shared_eq.rs','crates/deadpan-audio/src/components_mask_trace.rs']
old={p:(root/p).read_text() for p in files}
new=dict(old)
def edit(p,a,b):
 assert new[p].count(a)==1,(p,a[:100],new[p].count(a))
 new[p]=new[p].replace(a,b)
p=files[0]
edit(p,'impl<S: MaskSample> RangeBuilder<S> {\n','''impl<S: MaskSample> RangeBuilder<S> {
    #[cfg(test)]
    pub(in crate::stages) fn test_descriptor(&self) -> (usize, usize, usize, u64) {
        self.pending.as_ref().map_or((0, 0, 0, 0), |storage| {
            (
                storage.ranges.as_ptr() as usize,
                storage.ranges.len(),
                storage.ranges.capacity(),
                storage.charge.frames,
            )
        })
    }

    // The caller reserved the complete capacity before entering callbacks.
    // A real WorkControl can debit writes without borrowing StageAudio again.
    pub(in crate::stages) fn push_marked(
        &mut self,
        range: Range<S>,
        control: super::WorkControl<'_>,
    ) -> Result<(), StageAudioError> {
        control.check()?;
        if self.len() >= self.capacity() {
            return Err(StageAudioError::Limit("funded suppression range capacity"));
        }
        spend_work(control, MaskWorkPhase::Mark, 1)?;
        self.pending
            .as_mut()
            .expect("nonzero funded capacity has pending storage")
            .ranges
            .push(range);
        Ok(())
    }

''')
p=files[1]
new[p]=new[p].replace('ops::{FlagBuffer, MaskContext, MaskWorkPhase, begin_ranges}','ops::{MaskContext, MaskWorkPhase, RangeBuilder, begin_ranges}')
new[p]=new[p].replace('PendingFlags','PendingRanges').replace('finish_with_component_flags','finish_with_component_ranges').replace('component_flags','component_ranges')
edit(p,'''    PendingRanges {
        start: AudioSample,
        flags: FlagBuffer,
    },''','''    PendingRanges {
        ranges: RangeBuilder<AudioSample>,
    },''')
start=new[p].index('            Self::PendingRanges { start, flags } => {')
end=new[p].index('            Self::Pending { start, permissions } => {',start)
new[p]=new[p][:start]+'''            Self::PendingRanges { ranges } => {
                #[cfg(test)]
                let (source_pointer, source_len, source_capacity, _) = ranges.test_descriptor();
                #[cfg(test)]
                super::components_mask_trace::destination_storage(
                    source_pointer,
                    source_capacity,
                );
                let result = if ranges.len() == 0 {
                    drop(ranges);
                    context.check().map(|()| AudioSuppressionMask::default())
                } else {
                    // The emitted Vec remains the final destination allocation.
                    ranges.finish(context).and_then(|mask| mask.merge(context))
                };
                #[cfg(test)]
                if result.as_ref().is_ok_and(|mask| mask.is_owned()) {
                    super::components_mask_trace::source_transferred(
                        source_pointer,
                        source_len,
                        source_capacity,
                    );
                } else {
                    super::components_mask_trace::source_disposed(
                        source_pointer,
                        source_len,
                        source_capacity,
                    );
                }
                result
            }
'''+new[p][end:]
edit(p,'component_ranges: Option<FlagBuffer>','component_ranges: Option<RangeBuilder<AudioSample>>')
edit(p,'''            let flags = component_ranges.ok_or(PlanError::InvalidPlan(
                "component suppression destination absent",
            ))?;
            return self.components.finish_flags(
                self.output_voice,
                self.output_aliases,
                flags,''','''            let ranges = component_ranges.ok_or(PlanError::InvalidPlan(
                "component suppression destination absent",
            ))?;
            return self.components.finish_ranges(
                self.output_voice,
                self.output_aliases,
                ranges,''')
p=files[2]
new[p]=new[p].replace('ops::FlagBuffer','ops::RangeBuilder').replace('pub(super) fn finish_flags(','pub(super) fn finish_ranges(')
edit(p,'mut flags: FlagBuffer,','mut ranges: RangeBuilder<AudioSample>,')
# only function slice, not ordinary finish
start=new[p].index('    pub(super) fn finish_ranges(')
end=new[p].index('    /// Execute the common contribution driver',start)
piece=new[p][start:end]
piece=piece.replace('        let start = self.start;\n','')
piece=piece.replace('OutputSuppression::Flags(flags.as_mut_slice())','OutputSuppression::AdmittedRanges(&mut ranges)')
piece=piece.replace('MixedSuppression::PendingFlags { start, flags }','MixedSuppression::PendingRanges { ranges }')
piece=piece.replace('flags.test_descriptor()','ranges.test_descriptor()').replace('drop(flags)','drop(ranges)')
new[p]=new[p][:start]+piece+new[p][end:]
p=files[3]
edit(p,"    Flags(&'a mut [bool]),","    AdmittedRanges(&'a mut point_suppression::ops::RangeBuilder<AudioSample>),")
edit(p,'''            Some(OutputSuppression::Flags(flags)) if flags.len() != frames => {
                return Err(StageAudioError::Range);
            }
            Some(OutputSuppression::Flags(_)) | None => {}''','''            Some(OutputSuppression::AdmittedRanges(ranges)) => {
                if ranges.len() != 0 {
                    return Err(PlanError::InvalidPlan(
                        "contribution output suppression is not empty",
                    )
                    .into());
                }
                if ranges.capacity() < frames {
                    return Err(StageAudioError::Range);
                }
            }
            None => {}''')
edit(p,'Some(OutputSuppression::Flags(flags)) => {','Some(OutputSuppression::AdmittedRanges(ranges)) => {')
edit(p,'''                let spent = point_suppression::ops::spend_work(
                    control,
                    point_suppression::ops::MaskWorkPhase::Mark,
                    1,
                );''','''                let spent = ranges.push_marked(sample..AudioSample(sample.0 + 1), control);''')
edit(p,'                flags[at] = true;\n','')
# checked call remains old before push, okay redundant WorkControl check no acceptedwork
p=files[4]
new[p]=new[p].replace('component_flags','component_ranges').replace('finish_with_component_flags','finish_with_component_ranges').replace('PendingFlags','PendingRanges')
edit(p,'point_suppression::ops::begin_flags(&mut self.masks(control), frames).map(Some)','point_suppression::ops::begin_ranges::<AudioSample, _>(&mut self.masks(control), frames).map(Some)')
edit(p,'.map(point_suppression::ops::FlagBuffer::test_descriptor)','.map(point_suppression::ops::RangeBuilder::test_descriptor)')
# saved initialization descriptor no longer carries final len; obtain live builder descriptor at depth failure
edit(p,'''            #[cfg(test)]
            let components_source_descriptor = components_receipt.and_then(|_| {
                component_ranges
                    .as_ref()
                    .map(point_suppression::ops::RangeBuilder::test_descriptor)
            });
''','')
edit(p,'''                #[cfg(test)]
                if let (Some(receipt), Some((pointer, len, capacity, _))) =
                    (components_receipt, components_source_descriptor)
                    && matches!(&mixed.suppressed, MixedSuppression::PendingRanges { .. })
                {''','''                #[cfg(test)]
                let components_source_descriptor = match &mixed.suppressed {
                    MixedSuppression::PendingRanges { ranges } => Some(ranges.test_descriptor()),
                    _ => None,
                };
                #[cfg(test)]
                if let (Some(receipt), Some((pointer, len, capacity, _))) =
                    (components_receipt, components_source_descriptor)
                {''')
p=files[5]
new[p]=new[p].replace('ops::FlagBuffer','ops::RangeBuilder<AudioSample>')
edit(p,'use super::{StageAudioError, WorkControl, point_suppression::AudioSuppressionMask};','use super::{AudioSample, StageAudioError, WorkControl, point_suppression::AudioSuppressionMask};')
edit(p,'''            "enabled": s.enabled,
            "attempted_rows":''','''            "schema": "components-admitted-range-custody-v2",
            "enabled": s.enabled,
            "attempted_rows":''')
edit(p,'"source_element_bytes": std::mem::size_of::<bool>(),','"source_element_bytes": std::mem::size_of::<std::ops::Range<AudioSample>>(),')
edit(p,'''                "source_disposed": false,
                "source_identity_preserved": false,''','''                "source_disposed": false,
                "source_vec_transferred": false,
                "source_identity_preserved": false,''')
new[p]=new[p].replace('Ok(Some(flags)) => {','Ok(Some(ranges)) => {').replace('flags.test_descriptor()','ranges.test_descriptor()')
edit(p,'''            row.source_ptr == ptr && row.source_len == len && row.source_capacity == capacity''','''            row.source_ptr == ptr && row.source_capacity == capacity''')
edit(p,'''        row.value["source_disposed"] = json!(true);''','''        row.value["source_disposed"] = json!(true);
        row.value["source_len_at_disposal"] = json!(len);''')
edit(p,'''pub(super) fn source_account_after(live: u64) {
    mutate_current(|row| row.value["account_live_frames_after_source_drop"] = json!(live));
}''','''pub(super) fn source_transferred(ptr: usize, len: usize, capacity: usize) {
    mutate_current(|row| {
        row.value["source_vec_transferred"] = json!(true);
        row.value["source_len_before_merge"] = json!(len);
        row.value["source_identity_preserved"] =
            json!(row.source_ptr == ptr && row.source_capacity == capacity);
    });
}
pub(super) fn source_account_after(live: u64) {
    mutate_current(|row| row.value["account_live_frames_after_projection"] = json!(live));
}''')
# source_len field Row retained? now unused except init; remove private field only.
new[p]=new[p].replace('    source_len: usize,\n','').replace('                row.source_len = len;\n','')
pins={'schema':'components-work-fix-candidate-v1','published_base':'69698b678fd8a75dd644993d7d2a9846986d6911','state':'F integrated unpublished; replaces unshipped Flags producer','authority':str(root),'files':[]}
core=[];trace=[]
for rel in files:
 for mode,data in [('before',old[rel]),('new',new[rel])]:
  path=out/mode/rel;path.parent.mkdir(parents=True,exist_ok=True);path.write_text(data)
 pins['files'].append({'path':rel,'before_sha256':hashlib.sha256(old[rel].encode()).hexdigest(),'new_sha256':hashlib.sha256(new[rel].encode()).hexdigest()})
 patch=''.join(difflib.unified_diff(old[rel].splitlines(True),new[rel].splitlines(True),fromfile='a/'+rel,tofile='b/'+rel))
 patchpath=out/'patches'/Path(rel).name;patchpath=patchpath.with_suffix('.patch');patchpath.parent.mkdir(parents=True,exist_ok=True);patchpath.write_text(patch)
 (trace if rel.endswith('components_mask_trace.rs') else core).append(patch)
(out/'production.patch').write_text(''.join(core));(out/'observer-adapter.patch').write_text(''.join(trace))
(out/'source-pins.json').write_text(json.dumps(pins,indent=2)+'\n')
