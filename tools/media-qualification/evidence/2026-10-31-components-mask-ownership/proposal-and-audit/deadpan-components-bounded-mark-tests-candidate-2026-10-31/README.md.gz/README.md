# ComponentMarks real-context boundary tests

Scratch only. No roots, Cargo/builds, native executables, Git, fixtures or captures were changed. Parent owns integration and execution after the current build7 source freeze.

The hook is a private child of the actual integrated Scope shared_components/marks.rs, SHA a6fa7c099ad597c249181372466d893dc6c89fe16b9ed5a894f91577a350124d. hook.patch adds only cfg(test) marks_tests.rs. tests.patch adds that one file; before/new source and dependencies are pinned in source-pins.json. A later cargo fmt-only change may require mechanically reapplying the three-line hook against current text.

All tests use a real StageAudio created from a checked ProjectDocument and RenderPlan::compile, actual RefCell<ReadWork>, AtomicBool and WorkControl, and StageAudio::masks for final native allocations. No fake MaskContext, lease, counter or source is supplied. This is constructor/accounting algorithm coverage, not real WAV/provider/native Components driver reachability.

Seven tests:
1. inline_marks_match_old_singleton_merge_at_word_boundaries: 90 combinations of frames1/63/64/65/127/128/129/255/256, empty/all/last/alternating/cross-word marks, and AudioSample starts -513/+11. Marks are inserted backwards, then compared to the prior literal singleton merged_suppression helper. Actual raw-mark capacity and owning/nonowning result are checked.
2. empty_inline_marks_spend_only_bounded_word_work_and_create_no_account: all nine frame boundaries, actual zero source words, final empty cap0/Plain, exactly bounded initialization+count word work, actual account0/no observer.
3. invalid_frame_and_mark_bounds_change_no_bit_or_account: 0, >256 and usize::MAX frames; valid65 frame marker with at65/256/usize::MAX. Exact Range errors precede new work/bit writes, no account.
4. refused_and_cancelled_marks_do_not_publish_a_bit: real WorkControl refusal at the unchanged work cap and real cancellation after actual marker construction, unchanged accepted work and all bits zero, no account.
5. refused_inline_initialization_creates_no_account_or_partial_debit: insufficient remaining work for the real four-word initialization bulk debit leaves the prior count unchanged and creates no account.
6. dense_runs_retain_raw_capacity_and_outlive_work_and_controller: four full u64 words coalesce into one negative-coordinate run while retaining cap256. A real one-range native seed establishes the actual shell baseline; held output and account survive ReadWork/cancel flag/controller destruction, then actual payload drops back to that measured shell with only observer held.
7. each_small_finish_work_prefix_stops_and_cleans_actual_payload: first measures actual successful finish cost for [0,1,63,64,65,128] on129 frames; sweeps every smaller remaining-unit prefix on fresh real renderers with an actual seeded shell. Exact native work limit, accepted full remaining prefix and pending payload cleanup to the measured shell are checked. The small sweep is bounded below128 observed units; no257-range quadratic sweep.

Budget-state tests deliberately inject larger prior ReadWork.plan_work, matching current point_suppression/ops_tests.rs conventions. They never lower accepted work, raise a production cap, refund a debit, or describe the injected prior state as measured DSP work. All tested debits/refusals go through actual production WorkControl and mask context. Seed-shell baseline is obtained by real admission/publication/drop, not by assigning account counters or guessing native ABI fees.

Parent integration:
- Apply hook.patch and tests.patch to Scope, preserving current frozen source and concurrent work.
- Port the same child test file/hook to Main without copying other Scope source or inherited Main WIP.
- Format/compile under the project's normal guarded build; run the focused lib filter shared_components::marks::tests, then the existing required library/matrix gates.
- Native fixture proof remains separate: actual checked constant/dynamic driver and real WAV, source reservation live at destination admission, reached quota/Mark refusal cleanup, and unchanged nine wet/event regressions. These tests do not substitute for those obligations.

No test here was compiled or executed. No runtime success is claimed.
