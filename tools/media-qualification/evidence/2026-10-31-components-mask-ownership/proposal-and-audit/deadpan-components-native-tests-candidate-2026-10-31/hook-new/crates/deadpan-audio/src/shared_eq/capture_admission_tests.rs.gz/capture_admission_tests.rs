use super::*;
use deadpan_plan::AudioSoundContextAdmission;
use std::alloc::Layout;

struct Counting<'work, const M: bool> {
    control: WorkControl<'work>,
    forwarded: usize,
    reservations: usize,
    fail_on: Option<usize>,
}
impl<'work, const M: bool> Counting<'work, M> {
    fn new(control: WorkControl<'work>) -> Self {
        Self {
            control,
            forwarded: 0,
            reservations: 0,
            fail_on: None,
        }
    }
}
impl<const M: bool> AudioSoundContextAdmission for Counting<'_, M> {
    const METERED: bool = M;
    type Error = StageAudioError;
    type Issuer = ();
    type Lease = ();
    fn issuer(&self) {}
    fn spend(&mut self, units: usize) -> Result<(), Self::Error> {
        if M {
            self.control.spend_plan_work(units)?;
            self.forwarded = self.forwarded.checked_add(units).unwrap();
        }
        Ok(())
    }
    fn reserve(&mut self, _: Layout) -> Result<(), Self::Error> {
        self.control.check()?;
        self.reservations += 1;
        if M && self.fail_on == Some(self.reservations) {
            return Err(StageAudioError::Limit("capture allocation sentinel"));
        }
        Ok(())
    }
    fn merge(&mut self, _: &mut (), _: &mut ()) {}
}

#[test]
fn numerical_original_capture_refusal_matches_the_actual_sealed_capture_prefix() {
    let plan = fixture::fixture();
    let owner = fixture::owner(&plan);
    let key = OwnerKey::new(&owner);
    let cancelled = AtomicBool::new(false);
    let standalone_work = RefCell::new(ReadWork::default());
    let standalone_control = fixture::control(&cancelled, &standalone_work);
    let mut standalone = Counting::<true>::new(standalone_control);
    let candidates = plan
        .audio_owner_input_candidates_at_admitted(
            AudioSample(128),
            standalone_control.query_limits().unwrap(),
            &mut standalone,
        )
        .unwrap();
    let selected = candidates.query().spans()[0]
        .owners()
        .iter()
        .position(|clock| OwnerKey::new(clock) == key)
        .unwrap();
    let first_capture_reservation = standalone.reservations + 1;
    standalone.fail_on = Some(first_capture_reservation);
    assert!(matches!(
        candidates.capture(
            selected,
            standalone_control.query_limits().unwrap(),
            &mut standalone
        ),
        Err(StageAudioError::Limit("capture allocation sentinel"))
    ));
    assert_eq!(standalone.reservations, first_capture_reservation);

    let actual_work = RefCell::new(ReadWork::default());
    let actual_control = fixture::control(&cancelled, &actual_work);
    let mut actual = Counting::<true>::new(actual_control);
    actual.fail_on = Some(first_capture_reservation);
    assert!(matches!(
        original_context_admitted(
            &plan,
            &Context::Root,
            &key,
            AudioSample(128)..AudioSample(129),
            AudioSample(128),
            actual_control,
            &mut actual
        ),
        Err(StageAudioError::Limit("capture allocation sentinel"))
    ));
    assert_eq!(actual.reservations, first_capture_reservation);
    assert_eq!(actual.forwarded, standalone.forwarded);
    assert_eq!(
        actual_work.borrow().plan_work,
        standalone_work.borrow().plan_work
    );
}

fn success_work<const M: bool>() {
    let plan = fixture::fixture();
    let owner = fixture::owner(&plan);
    let cancelled = AtomicBool::new(false);
    let work = RefCell::new(ReadWork::default());
    let control = fixture::control(&cancelled, &work);
    let mut policy = Counting::<M>::new(control);
    let resolved = original_context_admitted(
        &plan,
        &Context::Root,
        &OwnerKey::new(&owner),
        AudioSample(128)..AudioSample(129),
        AudioSample(128),
        control,
        &mut policy,
    )
    .unwrap()
    .unwrap();
    assert!(matches!(&resolved.context, Context::Domain(_)));
    let frozen: serde_json::Value = serde_json::from_str(include_str!(
        "../../tests/fixtures/owner-query-baseline-v1/work-receipts.json"
    ))
    .unwrap();
    let old = &frozen["cases"][0];
    assert_eq!(old["case"], "unbound_eq_root");
    assert_eq!(old["retained_result"], "None");
    let probe_work = old["retained_probe_work"].as_u64().unwrap() as usize;
    assert_eq!(probe_work, 9);
    if M {
        // Q/C/P and final sharing now reach the same policy at their actual
        // sites. The positive None probe is included, never dropped or doubled.
        assert_eq!(work.borrow().plan_work, policy.forwarded);
    } else {
        assert_eq!(policy.forwarded, 0);
        assert_eq!(
            work.borrow().plan_work,
            old["expected_success_receipt_total"].as_u64().unwrap() as usize
        );
    }
    drop(resolved);
}
#[test]
fn numerical_original_capture_work_reaches_controller_once_in_both_modes() {
    success_work::<true>();
    success_work::<false>();
}

#[test]
fn numerical_probe_refusal_matches_the_same_actual_query_capture_and_probe_prefix() {
    let plan = fixture::fixture();
    let owner = fixture::owner(&plan);
    let key = OwnerKey::new(&owner);
    let cancelled = AtomicBool::new(false);
    let expected_work = RefCell::new(ReadWork::default());
    let expected_control = fixture::control(&cancelled, &expected_work);
    let mut expected = Counting::<true>::new(expected_control);
    let candidates = plan
        .audio_owner_input_candidates_at_admitted(
            AudioSample(128),
            expected_control.query_limits().unwrap(),
            &mut expected,
        )
        .unwrap();
    let selected = candidates.query().spans()[0]
        .owners()
        .iter()
        .position(|clock| OwnerKey::new(clock) == key)
        .unwrap();
    let capture = candidates
        .capture(
            selected,
            expected_control.query_limits().unwrap(),
            &mut expected,
        )
        .unwrap();
    let first_probe_reservation = expected.reservations + 1;
    expected.fail_on = Some(first_probe_reservation);
    assert!(matches!(
        capture.input().unwrap().retained_probe_at_admitted(
            AudioSample(128),
            expected_control.query_limits().unwrap(),
            &mut expected,
        ),
        Err(StageAudioError::Limit("capture allocation sentinel"))
    ));
    assert_eq!(expected.reservations, first_probe_reservation);
    drop(capture);

    let actual_work = RefCell::new(ReadWork::default());
    let actual_control = fixture::control(&cancelled, &actual_work);
    let mut actual = Counting::<true>::new(actual_control);
    actual.fail_on = Some(first_probe_reservation);
    assert!(matches!(
        original_context_admitted(
            &plan,
            &Context::Root,
            &key,
            AudioSample(128)..AudioSample(129),
            AudioSample(128),
            actual_control,
            &mut actual,
        ),
        Err(StageAudioError::Limit("capture allocation sentinel"))
    ));
    assert_eq!(actual.reservations, first_probe_reservation);
    assert_eq!(actual.forwarded, expected.forwarded);
    assert_eq!(
        actual_work.borrow().plan_work,
        expected_work.borrow().plan_work
    );
}

#[test]
fn numerical_retained_owner_refusal_matches_the_same_actual_complete_prefix() {
    let plan = retained_plan();
    let at = AudioSample(128);
    let query = plan
        .audio_gain_owners(at..AudioSample(129), Default::default())
        .unwrap();
    let owner = query.spans()[0]
        .owners()
        .iter()
        .find(|clock| clock.instance().node.as_str() == "tone")
        .unwrap();
    let key = OwnerKey::new(owner);
    let cancelled = AtomicBool::new(false);
    let expected_work = RefCell::new(ReadWork::default());
    let expected_control = fixture::control(&cancelled, &expected_work);
    let mut expected = Counting::<true>::new(expected_control);
    let candidates = plan
        .audio_owner_input_candidates_at_admitted(
            at,
            expected_control.query_limits().unwrap(),
            &mut expected,
        )
        .unwrap();
    let selected = candidates.query().spans()[0]
        .owners()
        .iter()
        .position(|clock| OwnerKey::new(clock) == key)
        .unwrap();
    let capture = candidates
        .capture(
            selected,
            expected_control.query_limits().unwrap(),
            &mut expected,
        )
        .unwrap();
    let probe = capture
        .input()
        .unwrap()
        .retained_probe_at_admitted(at, expected_control.query_limits().unwrap(), &mut expected)
        .unwrap();
    let first_owner_reservation = expected.reservations + 1;
    expected.fail_on = Some(first_owner_reservation);
    assert!(matches!(
        probe.input().unwrap().owners_admitted(
            at..AudioSample(129),
            expected_control.query_limits().unwrap(),
            &mut expected,
        ),
        Err(StageAudioError::Limit("capture allocation sentinel"))
    ));
    assert_eq!(expected.reservations, first_owner_reservation);
    drop(probe);
    drop(capture);

    let actual_work = RefCell::new(ReadWork::default());
    let actual_control = fixture::control(&cancelled, &actual_work);
    let mut actual = Counting::<true>::new(actual_control);
    actual.fail_on = Some(first_owner_reservation);
    assert!(matches!(
        original_context_admitted(
            &plan,
            &Context::Root,
            &key,
            at..AudioSample(129),
            at,
            actual_control,
            &mut actual,
        ),
        Err(StageAudioError::Limit("capture allocation sentinel"))
    ));
    assert_eq!(actual.reservations, first_owner_reservation);
    assert_eq!(actual.forwarded, expected.forwarded);
    assert_eq!(
        actual_work.borrow().plan_work,
        expected_work.borrow().plan_work
    );
}

fn retained_success_work<const M: bool>() {
    let plan = retained_plan();
    let at = AudioSample(128);
    let query = plan
        .audio_gain_owners(at..AudioSample(129), Default::default())
        .unwrap();
    let owner = query.spans()[0]
        .owners()
        .iter()
        .find(|clock| clock.instance().node.as_str() == "tone")
        .unwrap();
    let cancelled = AtomicBool::new(false);
    let work = RefCell::new(ReadWork::default());
    let control = fixture::control(&cancelled, &work);
    let mut policy = Counting::<M>::new(control);
    let resolved = original_context_admitted(
        &plan,
        &Context::Root,
        &OwnerKey::new(owner),
        at..AudioSample(129),
        at,
        control,
        &mut policy,
    )
    .unwrap()
    .unwrap();
    assert!(matches!(&resolved.context, Context::Retained(_)));
    let frozen: serde_json::Value = serde_json::from_str(include_str!(
        "../../tests/fixtures/owner-query-baseline-v1/work-receipts.json"
    ))
    .unwrap();
    let old = &frozen["cases"][2];
    assert_eq!(old["case"], "accepted_retained_tone");
    assert_eq!(old["retained_result"], "Some");
    let old_total = old["expected_success_receipt_total"].as_u64().unwrap() as usize;
    assert_eq!(old_total, 60);
    if M {
        assert_eq!(work.borrow().plan_work, policy.forwarded);
        assert!(policy.forwarded >= old_total);
    } else {
        assert_eq!(policy.forwarded, 0);
        assert_eq!(work.borrow().plan_work, old_total);
    }
    drop(resolved);
}

#[test]
fn numerical_retained_query_and_complete_prefix_reach_controller_once_in_both_modes() {
    retained_success_work::<true>();
    retained_success_work::<false>();
}
