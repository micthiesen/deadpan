# Components native receipt candidate

Scratch-only code proposal for current Scope. No source-root files were edited, no build or native run was done, and frozen historical bodies are unchanged.

## Base and source pins

Source authority is /tmp/deadpan-query-groundwork-2026-10-26/scoped; this candidate is based on its F production wiring before adding these test-only receipts. Main's unshipped shared_eq.rs WIP is excluded. source-sha256.txt pins the touched base files. candidate-sha256.txt pins the new modules, README, and generated patches. Each patch is against the current Scope base, not the earlier E baseline.

## Concrete candidate

- new/crates/deadpan-audio/src/components_mask_trace.rs is a cfg(test), default-off, bounded receipt stack. It records each actual source-admission boundary, driver branch, callbacks, Mark attempts/accepted writes/refusals, final destination admission/storage, source disposal, returned owned-mask identity, and real account/work observations. It carries actual program_depth and start so tests select the intended public depth-zero row rather than the first nested row. Rows/events have explicit truncation and unfinished flags. No pointer address is serialized.
- new/crates/deadpan-audio/src/bound_reads/components_mask_native_tests.rs uses checked public graphs, read_shared_input, and the real prepared stereo WAV provider. It includes a positive constant block case, a varying-gain dynamic case whose request crosses from allowed sound into a held silent root tail, zero emitted mask case, and measured actual Mark refusal. Each active output is compared against the actual legacy Components path on PCM bits, mask ranges and capacity, sample capacity, exhausted ranges/capacity, dependencies, depth, and error. Positive lifetime assertions require exact shell plus typed output payload after renderer drop, then shell only after returned output drop. The successful case asserts Mark consumes exactly one plan-work unit and does not change cache-plan work.
- capture_cases() returns only separate F Components observations. hook-new/.../native_mask_after.rs adds this as components_producer_cases inside the current Components capture branch. No older capture schema or frozen 744 + 10 + 4 bodies is changed.

## Integration patches

patches/ has one unified patch per modified existing file. new/ has the two new source files. Apply the already-reviewed Components production patch first, then these hook patches. The capture hook intentionally references the sibling baseline through its narrow pub(super) wrapper.

The hook set adds:
1. the test module declaration and borrowed FlagBuffer descriptor;
2. explicit begin/result boundaries around actual begin_flags, with real source-admission values and cleanup paths;
3. actual constant/dynamic branch and existing callback/Mark boundaries;
4. real reservation probes in Context::reserve;
5. source disposal after the actual FlagBuffer drop, including the numeric failure path, and destination allocation identity after the real builder admission;
6. the child test module/wrapper plus the current-F-only capture field.

The observer does not reconcile whole-request deltas into mask fees. It reads ReadWork only at explicit source and Mark boundaries and reads the actual live native account around those operations.

## Evidence boundary

This candidate was rustfmt-checked only. It was not compiled or run; the fixture assertions are designed to fail if an intended real path is not reached. In particular, the dynamic case must record the root row's dynamic branch, callback, and positive writes before it can support dynamic-path claims.

Not covered: source reservation failure before a complete FlagBuffer exists, projection reservation or merge refusal, callback error/depth error/cancellation/deadline, aliases or unselected outputs, and alternate send/temporal fixture combinations. These are not claimed by the proposed receipts. The current positive/zero/Mark-refusal cases are the proposed tested evidence only; parent owns integration, compilation, execution, and any additional reached-path coverage.
