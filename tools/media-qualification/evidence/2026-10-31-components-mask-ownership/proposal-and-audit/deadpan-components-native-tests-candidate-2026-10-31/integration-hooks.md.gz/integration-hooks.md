# Candidate integration order

Base source: current Scope F code pinned in source-sha256.txt. Apply the reviewed Components production patch bbf08cfccc91c2b81bb7923d02c894a7335130cf9518286ea4f22403d9e2a7c1 first. Then apply each patch under patches/ independently. Add the two files under new/ at their stated crates/deadpan-audio/src paths.

The stages.rs patch contains both the cfg(test) observer declaration and the narrow typed-payload helper used by sibling tests. The components_mask_trace::Request struct groups actual start/depth/frame/admission/work values at the begin_request callsite. The baseline wrapper is pub(super), and the F-only capture hook reaches it through the retained-host baseline parent.

No patch changes production source when cfg(test) is false. The SharedMix finish_flags error arm explicitly drops the real FlagBuffer before reporting its test-only disposal receipt, preserving the original error and completion point. Native runtime qualification remains outstanding.
