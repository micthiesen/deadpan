# Single-output Components native mask candidate

Scratch only, against current Scope source. No roots, builds/compiler/native runs, Git, before-body generation or oracle updates. Main WIP was not read or copied. Parent still owns E qualification/publication; integrate only after E publishes and fresh before34 is frozen. No E or future Gate is awarded here.

rustfmt --edition 2024 --config skip_children=true passed on all candidate and mechanical adapter files. Compilation/runtime checks remain owed.

## Files and integration

candidate.patch and five independent production patches cover:

- shared_eq.rs: after existing prediction verification and exact source-reservation adjustment, obtain the actual separate mix frame count and admit begin_flags through a temporary real StageAudio context. No context borrow survives into callbacks. Invoke the controlled finish dispatch. E's Pending-only observer now explicitly excludes PendingFlags.
- shared_mix.rs: add component_mask_frames, a controlled finish_with_component_flags dispatch and an owning PendingFlags carrier/finalizer. Preserve non-separate E algorithm/observer. Keep cfg(test) finish as an explicit old direct-fixture wrapper.
- shared_components.rs: retain the literal old finish wrapper under cfg(test), add finish_flags using the same finish_into numerical driver with the actual owning buffer, and make its two existing mark sites fallible.
- shared_components/outputs.rs: distinguish the ordinary range-Vec sink from a bool flag slice, preserve ordinary checks/pushes and add exact flag-length validation plus one centralized native Mark spend before each actual flag write.
- shared_components/block.rs: make the existing constant-driver post-finite/post-PCM mark site fallible. Numeric sums, channel order, callbacks, gain and finite predicates are untouched.

Use Scope before/new trees and per-file hunks; preserve Main shared_eq.rs WIP instead of replacing its file.

Required parent-owned cfg(test) Stage hook:

    #[cfg(test)]
    #[path = "components_mask_request.rs"]
    mod components_mask_request;

hook-proposal/components_mask_request.rs is separate from the production patch. Its components-only override skips flag admission and selects literal old Components::finish; it does not change E's non-separate permission-grid flag, D Root collection or C Point handoff. Parent owns historical wrapper chaining and capture glue. Immediate E replay must enable only this new Components override. Older wrappers may chain it deliberately.

optional-test-adapters.patch only wraps five existing Some(Vec borrow) Output literals in OutputSuppression::Ranges, without changing assertions, expected values, capacities, work or callbacks. None literals are unchanged. No native tests were written.

## Exact source and target custody

The existing source reservation remains frames*12 + mix.resident_frames, after its existing prediction-retirement subtraction. Separate Components::resident_frames still accounts for its route PCM, gain/programs, per-route permitted/predicted matrices and output PCM. Non-separate E still accounts (buses+1)*frames*(2+WORDS), not merely the outer transient multiplier. None of those equations, caps or old charges changed.

New flags are an additional actual allocation, separately paid by begin_flags. That existing constructor reserves Layout::array<bool>(actual_frames) before allocation, asserts actual capacity, accepts per-entry initialization work and returns a unique FlagBuffer with Vec-before-Charge disposal. It does not retain a renderer/context borrow.

The flags owner moves into Components::finish_flags. Only its borrowed bool slice reaches Output. The existing numerical driver and equalizer callback run once. Exactly after each old finite validation and PCM samples.set, the same actual at/sample pair reaches mark_suppressed. Its Flags arm checks the real WorkControl, accepts ops::spend_work(Mark,1) exactly once and then writes true at the existing frame index. A refusal immediately propagates; no later loop work executes. Ordinary Vec and None arms accept no new fee and preserve literal old behavior.

A successfully initialized nonempty flag slice is not an ordinary nonempty suppression Vec. Validation checks its exact length against frames; ordinary Vec emptiness and multi-output capacity checks remain separate and literal. The controlled private wrapper supplies freshly false-initialized owning storage. The actual single-output drivers visit each frame once and have at most one mark, so count(true) equals the old raw range emission count. No PCM-zero inference or re-evaluation of permissions/gains occurs.

Numeric/callback failure drops flags inside the current read_shared_program closure, before its source-reservation tail. On success, finish_flags moves that same owner and actual AudioSample start into PendingFlags. After the existing nested-depth check, its finalizer counts actual true flags, reserves an exact typed range builder, scans/emits the original absolute one-frame intervals, finishes the funded Box and merges in place. A bounded result closure retains flags through destination construction/merge; explicit drop(flags) executes for success and every Result error before returning to the scalar reservation tail.

No Plan lease is synthesized, no source flag buffer is copied, no Vec is detached from an owner, and no source charge is retired early. Empty final output still incurred its real scratch allocation/initialization and count scan; it allocates no destination payload. The initialized shell may persist.

## Production dispatch and legacy boundaries

Production read_shared_program calls only finish_with_component_flags. A separate request without supplied flags rejects with InvalidPlan("component suppression destination absent"); it cannot silently fall back to ordinary allocation. The explicit cfg(test) Components override is the only read-path legacy selection.

Existing direct SharedMix::finish fixtures retain their old separate Components wrapper via a cfg(test) compatibility entry. Direct Components::finish is also cfg(test). Thus ordinary_for_test continues receiving Ordinary for those historical fixtures instead of panicking on a new pending type. New producer tests must call the real controlled read/dispatch, not that explicit fixture entry.

The ordinary multi-output finish_into sink remains available and unchanged in behavior. It does not acquire ownership merely because the single-output wrapper now does. Two narrow non-test dead_code allowances retain its ordinary sink/carrier variants when no current production constructor selects them; they mask no production errors or resource checks.

The existing non-separate E branch remains literal, including its E-only legacy projection. PendingFlags neither calls E destination_storage/source_disposed hooks nor opens an E row. The shared_eq E descriptor match recognizes only Pending permissions. Parent must add a distinct Components observer for actual flag/Mark/range phases; do not reinterpret E permission rows as coverage here.

## Values, clocks and caches

Projection retains the actual start+index and at+1 AudioSample arithmetic, guarded by existing finish_into start-plus-frames validation and read request checks. It introduces no Signal/Point remapping, clipping, reversed-range normalization or canonical Plan fee.

The old final Components merge allocates capacity equal to the old raw mark count. PendingFlags uses that exact count and retains its charge/capacity after compaction. Downstream owned growth/re-merges may retain a larger capacity where Plain formerly copied fewer elements; preserve actual differences, as in D, rather than forcing a shrink or promising universal capacity parity.

No WideBlock, ReadBlock or cached-block field changes are needed beyond E's already opaque masks. Existing read_shared_input directly propagates ownership. Cached temporal/event outputs remain empty-mask constructors; their old resident equations stay unchanged. Existing Original ReadBlock accounting uses unaccounted_capacity and does not re-debit owned masks. Flags remain transient and are never cached.

This unit does not close ordinary multi-output storage, projected PreserveTape/Plan policy, exhausted buffers, PCM/dependencies, graph metadata or whole preparation.

## Qualification owed

Parent must first publish E, freeze actual before34, integrate the cfg(test) hook/mechanical adapters, compile both variants and preserve current E/D/C and older full-body replay. No implementation-success claim is made from formatting.

Required new proof must reach the real separate production path in both constant and dynamic drivers, with selection/aliases, sends, temporal callbacks, allowed numerical zero and positive masks. Record actual scratch pointer/len/capacity/charge before callbacks, exact accepted marks at their old sites, target count/capacity/charge and explicit source disposal before the unchanged scalar tail. FlagBuffer currently exposes slice borrows but no capacity accessor; parent can add a narrow cfg(test) borrowed descriptor/accessor rather than serialize a guessed capacity.

Exercise actual scratch admission/initialization failure, reached Mark refusal, numeric/callback/depth failure while flags are live, and range admission/emission/merge refusal. Show no WideBlock, real active/source cleanup and payload returning to prior account baseline plus any actual retained shell. An earlier metadata, E-grid or filter failure does not prove a reached Components phase. Preserve literal query invalid flags and actual native counters with distinct producer intervals.

Compare complete PCM bits, masks/capacity, dependencies/depth and errors to independent fresh before; retain output beyond request/controller/work and cover real cache pin/hit/evict. No caps, old source/PCM fees or canonical weights may be raised, normalized or refunded to fit expected observations.

## Artifact layout

before/new are exact Scope snapshots for production files. test-before/test-new contain only the mechanical Output-literal adapters. source-pins.json and test-source-pins.json pin the source bytes; dependency-pins.json pins current E builders/observer, controls and design/review inputs. candidate-pins.json pins all scratch output. prepare.py is the initial transformation recipe; the formatted before/new trees and patches are integration authority.
