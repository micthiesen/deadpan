from pathlib import Path
import hashlib,json
d=Path('/tmp/deadpan-components-mask-candidate-2026-10-31')
root=Path('/tmp/deadpan-query-groundwork-2026-10-26/scoped')
names=['shared_eq.rs','shared_mix.rs','shared_components.rs','shared_components/outputs.rs','shared_components/block.rs']
def change(s,old,new,count=1):
 assert s.count(old)==count,(old[:100],s.count(old),count)
 return s.replace(old,new)
pins={}
for name in names:
 rel=Path('crates/deadpan-audio/src')/name
 source=root/rel;raw=source.read_bytes()
 pins[str(source)]={'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}
 before=d/'before'/rel;new=d/'new'/rel
 before.parent.mkdir(parents=True,exist_ok=True);new.parent.mkdir(parents=True,exist_ok=True)
 before.write_bytes(raw);s=raw.decode()
 if name=='shared_eq.rs':
  old='''            let mixed = mix.finish(control, |owner, stage, at, permissions, voice| {'''
  replacement='''            let component_mask_frames = mix.component_mask_frames();
            #[cfg(test)]
            let component_mask_frames = component_mask_frames
                .filter(|_| !super::components_mask_request::legacy());
            let component_flags = if let Some(frames) = component_mask_frames {
                Some(point_suppression::ops::begin_flags(
                    &mut self.masks(control),
                    frames,
                )?)
            } else {
                None
            };
            let mixed = mix.finish_with_component_flags(
                control,
                component_flags,
                |owner, stage, at, permissions, voice| {'''
  s=change(s,old,replacement)
  # Close the existing callback/new function invocation without changing its body.
  s=change(s,'''                Ok(block.samples[(at.0 - tile) as usize])
            })?;
            if program''','''                Ok(block.samples[(at.0 - tile) as usize])
                },
            )?;
            if program''')
  s=change(s,'                MixedSuppression::Ordinary(_) => None,','                MixedSuppression::Ordinary(_) | MixedSuppression::PendingFlags { .. } => None,')
 elif name=='shared_mix.rs':
  s=change(s,'use super::point_suppression::ops::{MaskContext, MaskWorkPhase, begin_ranges};','use super::point_suppression::ops::{FlagBuffer, MaskContext, MaskWorkPhase, begin_ranges};')
  s=change(s,'''pub(super) enum MixedSuppression {
    Ordinary(Vec<Range<AudioSample>>),
    Pending {
        start: AudioSample,
        permissions: Vec<Permissions>,
    },
}''','''pub(super) enum MixedSuppression {
    #[cfg_attr(
        not(test),
        allow(dead_code, reason = "Retain the explicit ordinary carrier independently of owned production.")
    )]
    Ordinary(Vec<Range<AudioSample>>),
    Pending {
        start: AudioSample,
        permissions: Vec<Permissions>,
    },
    PendingFlags {
        start: AudioSample,
        flags: FlagBuffer,
    },
}''')
  s=change(s,'            Self::Pending { .. } => panic!("component fixture must retain its ordinary producer"),','            Self::Pending { .. } | Self::PendingFlags { .. } => {\n                panic!("component fixture must retain its ordinary producer")\n            }')
  anchor='''            Self::Ordinary(ranges) => Ok(AudioSuppressionMask::plain(ranges)),
            Self::Pending { start, permissions } => {'''
  replacement='''            Self::Ordinary(ranges) => Ok(AudioSuppressionMask::plain(ranges)),
            Self::PendingFlags { start, flags } => {
                let result = (|| {
                    let mut capacity = 0_usize;
                    for suppressed in flags.as_slice() {
                        context.check()?;
                        context.spend(MaskWorkPhase::Scan, 1)?;
                        if *suppressed {
                            capacity = capacity.checked_add(1).ok_or(StageAudioError::Range)?;
                        }
                    }
                    if capacity == 0 {
                        context.check()?;
                        return Ok(AudioSuppressionMask::default());
                    }

                    let mut ranges = begin_ranges::<AudioSample, C>(context, capacity)?;
                    for (index, suppressed) in flags.as_slice().iter().enumerate() {
                        context.check()?;
                        context.spend(MaskWorkPhase::Scan, 1)?;
                        let at = AudioSample(start.0 + index as i64);
                        let range = at..AudioSample(at.0 + 1);
                        if *suppressed {
                            ranges.push(range, context)?;
                        }
                    }
                    ranges.finish(context)?.merge(context)
                })();
                drop(flags);
                result
            }
            Self::Pending { start, permissions } => {'''
  s=change(s,anchor,replacement)
  s=change(s,'''    pub(super) fn uses_components(&self) -> bool {
        self.separate
    }''','''    pub(super) fn uses_components(&self) -> bool {
        self.separate
    }

    pub(super) fn component_mask_frames(&self) -> Option<usize> {
        self.separate.then_some(self.frames)
    }''')
  old='''    pub(super) fn finish(
        mut self,
        control: WorkControl<'_>,
        mut equalize: impl FnMut('''
  replacement='''    #[cfg(test)]
    pub(super) fn finish(
        self,
        control: WorkControl<'_>,
        equalize: impl FnMut(
            &AudioOwnerClock<'plan>,
            Temporal,
            AudioSample,
            Permissions,
            Option<usize>,
        ) -> Result<[f64; 2], StageAudioError>,
    ) -> Result<MixedBlock, StageAudioError> {
        if self.separate {
            return self.components.finish(
                self.output_voice,
                self.output_aliases,
                control,
                equalize,
            );
        }
        self.finish_with_component_flags(control, None, equalize)
    }

    pub(super) fn finish_with_component_flags(
        mut self,
        control: WorkControl<'_>,
        component_flags: Option<FlagBuffer>,
        mut equalize: impl FnMut('''
  s=change(s,old,replacement)
  old='''        if self.separate {
            return self.components.finish(
                self.output_voice,
                self.output_aliases,
                control,
                equalize,
            );
        }
        let mut order: Vec<_>'''
  replacement='''        if self.separate {
            #[cfg(test)]
            if super::components_mask_request::legacy() {
                return self.components.finish(
                    self.output_voice,
                    self.output_aliases,
                    control,
                    equalize,
                );
            }
            let flags = component_flags.ok_or(PlanError::InvalidPlan(
                "component suppression destination absent",
            ))?;
            return self.components.finish_flags(
                self.output_voice,
                self.output_aliases,
                flags,
                control,
                equalize,
            );
        }
        let mut order: Vec<_>'''
  s=change(s,old,replacement)
 elif name=='shared_components.rs':
  s=change(s,'use deadpan_core::AudioTreatmentStage;','use super::point_suppression::ops::FlagBuffer;\nuse deadpan_core::AudioTreatmentStage;')
  s=change(s,'pub(super) use outputs::{Output, OutputSamples, OutputSelection};','pub(super) use outputs::{Output, OutputSamples, OutputSelection, OutputSuppression};')
  s=change(s,'''    pub(super) fn finish(
        self,
        output_voice:''','''    #[cfg(test)]
    pub(super) fn finish(
        self,
        output_voice:''')
  s=change(s,'                suppressed: Some(&mut suppressed),','                suppressed: Some(OutputSuppression::Ranges(&mut suppressed)),')
  anchor='''    /// Execute the common contribution driver once, then emit each requested'''
  method='''    pub(super) fn finish_flags(
        self,
        output_voice: Option<usize>,
        output_aliases: Permissions,
        mut flags: FlagBuffer,
        control: WorkControl<'_>,
        equalize: impl FnMut(
            &AudioOwnerClock<'plan>,
            Temporal,
            AudioSample,
            Permissions,
            Option<usize>,
        ) -> Result<[f64; 2], StageAudioError>,
    ) -> Result<MixedBlock, StageAudioError> {
        let start = self.start;
        let mut samples = vec![[0.0; 2]; self.frames];
        self.finish_into(
            &mut [Output {
                selection: OutputSelection {
                    voice: output_voice,
                    aliases: output_aliases,
                },
                samples: OutputSamples::Interleaved(&mut samples),
                suppressed: Some(OutputSuppression::Flags(flags.as_mut_slice())),
            }],
            control,
            equalize,
        )?;
        Ok(MixedBlock {
            samples,
            suppressed: MixedSuppression::PendingFlags { start, flags },
        })
    }

'''
  s=change(s,anchor,method+anchor)
  s=change(s,'                    output.mark_suppressed(sample);','                    output.mark_suppressed(at, sample, control)?;',2)
 elif name=='shared_components/outputs.rs':
  s=change(s,'pub(in crate::stages) struct Output<','''pub(in crate::stages) enum OutputSuppression<'a> {
    #[cfg_attr(
        not(test),
        allow(dead_code, reason = "The ordinary multi-output destination remains available.")
    )]
    Ranges(&'a mut Vec<Range<AudioSample>>),
    Flags(&'a mut [bool]),
}

pub(in crate::stages) struct Output<''')
  s=change(s,"    pub(super) suppressed: Option<&'a mut Vec<Range<AudioSample>>>,","    pub(super) suppressed: Option<OutputSuppression<'a>>,")
  old='''        if let Some(suppressed) = &self.suppressed {
            if !suppressed.is_empty() {
                return Err(
                    PlanError::InvalidPlan("contribution output suppression is not empty").into(),
                );
            }
            if multiple && suppressed.capacity() < frames {
                return Err(StageAudioError::Limit(
                    "contribution output suppression capacity",
                ));
            }
        }'''
  replacement='''        match &self.suppressed {
            Some(OutputSuppression::Ranges(suppressed)) => {
                if !suppressed.is_empty() {
                    return Err(
                        PlanError::InvalidPlan("contribution output suppression is not empty").into(),
                    );
                }
                if multiple && suppressed.capacity() < frames {
                    return Err(StageAudioError::Limit(
                        "contribution output suppression capacity",
                    ));
                }
            }
            Some(OutputSuppression::Flags(flags)) if flags.len() != frames => {
                return Err(StageAudioError::Range);
            }
            Some(OutputSuppression::Flags(_)) | None => {}
        }'''
  s=change(s,old,replacement)
  old='''    pub(super) fn mark_suppressed(&mut self, sample: AudioSample) {
        if let Some(suppressed) = &mut self.suppressed {
            suppressed.push(sample..AudioSample(sample.0 + 1));
        }
    }'''
  replacement='''    pub(super) fn mark_suppressed(
        &mut self,
        at: usize,
        sample: AudioSample,
        control: WorkControl<'_>,
    ) -> Result<(), StageAudioError> {
        match &mut self.suppressed {
            Some(OutputSuppression::Ranges(suppressed)) => {
                suppressed.push(sample..AudioSample(sample.0 + 1));
            }
            Some(OutputSuppression::Flags(flags)) => {
                control.check()?;
                point_suppression::ops::spend_work(
                    control,
                    point_suppression::ops::MaskWorkPhase::Mark,
                    1,
                )?;
                flags[at] = true;
            }
            None => {}
        }
        Ok(())
    }'''
  s=change(s,old,replacement)
 else:
  s=change(s,'                    output.mark_suppressed(AudioSample(self.start.0 + at as i64));','                    output.mark_suppressed(at, AudioSample(self.start.0 + at as i64), control)?;')
 new.write_text(s)
(d/'source-pins.json').write_text(json.dumps(pins,indent=2)+'\n')
