# Inline native adapter final delta

**GO for current24b5b50d752415a560dc9312372f9291db5c44ba0ac78b5062323890aa66823e.** This supersedes the assertion gaps recorded for e1e770 in the initial review. No compiler/native run or root edit was performed here.

The intermediate7ed delta strengthens the actual identified root's zero-mask proof: both destination fields are null, result is unowned and capacity0. Positive target active_frames must cover that row's recorded source reservation, rather than merely be nonzero. Capture predicates use the same stronger conditions. No request, fixture, production operation, work cap or fee changes.

Parent execution then exposed an assertion/schema mismatch I missed in the e1 static review: pre-projection Mark failure uses set_failure_result, which deliberately omits mask_capacity. Null/absence could not honestly be asserted equal to0.

The final24b5 delta now requires destination_reservation and destination_storage null and checks that the failure result object has no mask_capacity key. expect_counted=false separately requires raw_mark_count null, while the actual returned Rust error remains explicitly matched as Limit("plan work per read"). Mark attempt/refusal, zero written bits, inline scope closure, real counter cleanup and retained shell checks remain.

The observer writes success=false and the actual error into its failure object. The test checks the typed returned error and the absence shape; it does not separately compare those two JSON fields. This report does not claim that additional assertion exists.

Full success bodies/capacities remain literal; same-seed legacy and active outcomes remain independently serialized without invented equality. Partial-case JSON must be analyzed by actual case shape, not success-row defaults.

Final current/scratch module, patch and observer/marker identities are pinned in /tmp/deadpan-components-inline-native-adapter-review-2026-10-31/final-native-pins.json. Current and scratch modules are byte-identical. Parent owns build8, native execution, all21 matrix and final capture/binary/source joins.
