# Bounded Components marker candidate review

**GO for integration and qualification. No production blocker found.** Reviewed production.patch SHA-256 29339f182c668e132c16561a501c47a3138731e5c32fcc730456b1254a678168, observer-adapter.patch SHA-256 2cb634c766757a9b01a62bb23f172b29604f5157cb5ffb81b35cf3c294e3e45d, new marks.rs SHA-256 20f0e4322fa58730de5b1c8ef2ef07a0de332ca016bd205a013094858c82728a, and the test-adaptation contract.

This replaces an unpublished failed F design. It does not change E authority, before34, production caps or canonical work weights. No root edits, Rust/compiler/native execution, Git or oracle generation occurred in this review. Actual default-read regressions and full qualification remain owed.

## Closed bound and arithmetic

The bound is specific to this producer. read_shared_program rejects frames0 or greater than MAX_OUTPUT_FRAMES256 and checks start plus frames before source/query work. Its only production callers, shared input and recursive tile preparation, also chunk to that constant. The controlled SharedMix arm supplies this private marker to exactly one Components output. The direct cfg(test) finish and ordinary multi-output paths retain their literal ordinary API. General ReadBlock aggregation remains unbounded by256 and keeps the existing owned mask.

WORDS derives from MAX_OUTPUT_FRAMES and u64::BITS, currently four. The source has only inline integer words plus logical length; no Vec, Box, Arc, lease or source heap allocation exists. Constructor initialization bills four actual words before constructing the array. Mark validates at<frames before its bit write; both word index and shift are bounded.

start.0+left/right in finish is safe on actual production callers. SharedMix and Components retain the start/frame pair established by read_shared_program. finish_marks captures self.start, invokes finish_into, and constructs PendingMarks only after that driver succeeds. finish_into independently checks start+frames and validates marker length. PendingMarks is the sole production caller of marks.finish. Every extracted endpoint satisfies0<=left<right<=frames, so adding it cannot overflow after the checked end. Negative starts obey the same proof.

A direct private helper invocation with an unchecked overflowing start lies outside this closed precondition. Boundary tests should use a checked start/end, and overflow classification should be tested through the actual read/driver entry. This patch does not introduce a reachable unchecked endpoint conversion or new clock/grid mapping.

## Run extraction and exact capacity

For each nonzero word, trailing_zeros yields low<64. After shifting by low, the low bit is one, so trailing_ones gives positive width and high<=64. high==64 clears the word without evaluating a shift by64. Otherwise the mask clears the complete current run and all lower bits; the next iteration strictly advances.

Word order and extraction order are increasing. Each emitted interval is positive. Within a word runs are separated by a zero; adjacent runs across words join when the previous end equals the next start. These are exactly the unions produced by the old sorted singleton collector. Overlap and reversed/empty ranges cannot arise from the actual marked index set.

Popcount computes raw marked-frame count m. Actual single-output drivers visit a frame once and mark at most once, so m equals the old raw singleton count. begin_ranges(m) reserves the exact target Vec capacity and future Storage Box. The builder stores only coalesced runs, then finishes directly. It retains capacity m, even when final length is smaller. There is no generic heap sort, second destination vector, shrink, detach or unadmitted clone.

An independent Python model of this reviewed extractor matched a literal singleton-union oracle for393801 boundary/pattern cases, including all16-bit patterns at offsets spanning word boundaries, full/partial words, alternating/empty marks and negative starts. This is a separate algorithm cross-check, not execution or compilation of the candidate Rust. Its script/results are retained alongside the review.

## Numerical order, work and ownership

The numeric loops, route/gain/finite predicates, callback order and original post-PCM mark call sites are unchanged. The ordinary sink still pushes exactly as before. The active mark reaches one centralized Mark spend before writing its bit. Output currently checks control before mark, and mark checks again before the spend's own check. This is redundant checking, not a duplicate debit or a source of unbilled mutation.

No StageAudio borrow survives into callbacks. The constructor and marker use genuine WorkControl only. Real StageAudio MaskContext is used after the existing callback/depth boundary, when actual target admission is necessary. Existing source reservations remain unchanged and live through that finalization and its normal tail. Inline storage needs no invented source charge.

Zero marks incur only actual word work and return default without this producer initializing an account or reserving/allocating a Vec/Box. An account legitimately created by another producer is neither erased nor refunded. Positive output uses the unchanged lazy closed account, exact destination layouts and existing physical Box/Vec/Charge drop rules.

Every count/extraction/push/finalization failure propagates its actual Result. Before target admission there is no destination owner to release. After admission, pending builder or owned mask RAII disposes actual payload before its charge. The inline source has no heap allocation to dispose. Driver/depth failures cannot return a successful block, and existing scalar source funding is released only at its established tail.

The reduced work follows deleted operations: per-frame flag initialization/count/copy loops and generic sorting disappear. Native phases bill actual words, bit runs, cross-word accumulator changes, real pushes and allocation. No old DSP/query/visitor fee, cap or canonical claim is repriced.

## Observer and tests

The adapter removes heap-source pointer/capacity/charge/deallocation and distinct-allocation claims. It records actual inline words and zero source heap charge. inline_source_scope_closed denotes logical completion, not physical stack deallocation. Neutral inline_words_latest and account_live_frames_at_completion correctly cover failures before projection.

Destination pointer identity remains meaningful: it is captured only after actual builder allocation and compared with the final owned Vec. E's permission-grid observer excludes PendingMarks. Existing truncation/unfinished rejection and default-off guards remain required. The old native tests still assert heap-flag fields and must be deliberately adapted; the adapter alone is not passing evidence.

The separate test contract correctly requires real WorkControl/controller boundary tests, same-root actual constant/dynamic/callback cases, raw m versus emitted runs, zero local allocation/account, exact accepted prefixes, retained output life, and all nine unchanged default wet/event regressions plus the full matrix. Existing source qualification, requests, PCM/history assertions, before34 and earlier old lanes must remain fixed. No same-seed legacy-error equality should be invented across changed native operations.

## Artifact checks and limitations

All six source entries match their pinned candidate/current bases, all seven dependency hashes match, and all four declared artifact pins match. The five-file production patch and one-file observer adapter reconstruct their new files exactly.

Exact pins, audit.py/audit-results.json and boundary_model.py/results are retained in /tmp/deadpan-components-bounded-mark-review-2026-10-31. The regression mechanism and rejected direct-plus-generic-merge alternative are separately documented in /tmp/deadpan-components-regression-design-review-2026-10-31.md.

No compiler/private-visibility success, actual quota/cancellation cleanup, nine-regression fix, historical replay, final native matrix or publication is claimed by this GO. Parent owns that verification.
