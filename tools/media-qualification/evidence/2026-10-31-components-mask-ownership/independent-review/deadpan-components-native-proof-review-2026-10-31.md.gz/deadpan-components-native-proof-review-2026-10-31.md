# Components native observer and proof candidate review

**GO for integration and actual qualification of the corrected frozen candidate.** No remaining material blocker found statically. Candidate manifest SHA-256: 4a2cae6531be3e344772351fdb41e0b0fbf2bdfbdc7ac3ee7524bf09503f47cb. Observer: 2a7f6dde8ec523f5f537a3476f630121381f4b1d6adc5dc2954e74ab49c13ffb. Native test source: f5fd0a1800abaaa84299cecef8abbf6f0e81bfb55f34cb2e49f34c836007aca9.

This is a read-only source/protocol review. No compiler, Cargo/native execution, root edit, fixture capture or Git operation was performed. Rustfmt parsing does not establish compilation, fixture validity, branch reach or runtime success.

## Findings corrected before freezing

The initial draft had default-off Mark allocations/ReadWork borrows; child-substitution branch assertions; the wrong typed plan-work error; missing ops-trace cleanup; weak retained-charge checks; and a false nonzero payload calculation for an empty Plain mask. These were sent directly to the author and corrected in the frozen files.

The final version guards before Mark work/JSON and before source ReadWork borrowing; identifies the intended actual depth-zero/start row; requires that same row's driver, positive writes, positive owned destination and callback for the dynamic case; expects Limit("plan work per read"); restores trace state through Drop; requires exact shell plus typed output payload then shell only; and computes payload only for an owned final mask. The final manifest also repairs its earlier stale integration-hooks hash.

## Concrete hooks and ownership

Source-row creation precedes the actual begin_flags constructor. Its explicit admission scope encloses only that constructor, records its Result before propagation, and handles a constructor error separately without inventing a completed buffer descriptor. The exact FlagBuffer pointer/length/capacity/charge descriptor borrows existing storage only. It neither extracts storage nor synthesizes a lease.

The trace begins only when enabled. The shared_eq hook checks that before borrowing ReadWork; Mark attempt/write/refusal hooks check for an active row before formatting or allocating. Reserve hooks check an explicit source/destination phase before creating events. Disabled observers do not introduce those ReadWork borrows or JSON allocations.

Actual driver hooks sit at the existing constant/dynamic dispatch. Callback hooks sit at the real equalizer closure invocation. Mark observes around the existing check, one centralized ops::spend_work(Mark, 1), and actual flag write; no additional work debit or ledger mutation is introduced.

The source descriptor stays private. Flags remain owned through callbacks, marking and the PendingFlags projection. The actual builder pointer/capacity is observed only after real destination admission. Destination identity is compared with the actual returned owned mask; source/destination pointer distinctness uses simultaneous source/destination construction, not a copied mask.

Numeric failure explicitly drops flags before reporting disposal. The shared_eq error handler then records live account/active state and completes the row before the scalar source-reservation tail. Depth failure explicitly drops the real PendingFlags field before its disposal receipt. Projection success/error drops flags after the bounded destination closure and before result completion. E's permission-grid observer remains separate.

A documentation qualification: integration-hooks.md says no patch changes production source when cfg(test) is false. That is too literal. The instrumentation APIs are cfg(test), but Result handling, Mark error arms and the explicit finish_flags error Drop refactor are unconditional. They preserve the original typed errors, work and callback order; flag Vec/charge disposal completes while the existing source reservation is live. This review includes those release-path refactors and does not claim the patch consists solely of cfg(test) tokens.

## Nested and bounded lifecycle

The receipt stack restores the enclosing row across actual nested Components producers. Rows carry actual program.depth and start in addition to parent row identity. This matters because a child reached during source population can finish before its parent's flag row exists; parent_row_id:null or rows[0] alone was insufficient. The final tests select the intended depth-zero/start row uniquely.

Rows are bounded at 32 and boundary events at 256 per row. Mark/callback data are aggregate first/last/count observations. Snapshots expose truncation and unfinished state; tests reject either and reject truncated row events. Pop mismatch leaves unfinished state rather than claiming completion.

Once the row bound is exceeded, current-row hooks can still land on the enclosing row because no overflow receipt is pushed. truncated_rows is then true, so that snapshot is invalid for attribution and the proposed tests reject it. Do not treat individual rows from a truncated snapshot as qualified. Increase a fixed bound only after actual observed reach warrants it, as the README says.

Raw pointer integers are not serialized. Snapshots expose identity booleans and actual scalar values. No full-row work delta is relabeled as a canonical query fee. Source work boundaries and first Mark before/after are actual local observations; parent/child work totals remain inclusive.

## Real tests and honest scope

The proposed fixtures use checked ProjectDocument compilation, read_shared_input and the existing real prepared stereo WAV provider. They do not construct a fake Bound, mask, quota ledger or private query lease.

The dynamic fixture now extends the checked document with a held silent tail and requests the real transition from allowed sound into that tail; its root gain envelope actually varies. Assertions must still prove the intended root dynamic branch, callback and positive final mask at runtime. The constant alternating and source-only wet-send fixtures likewise require actual branch evidence rather than relying on names.

The output comparison includes f32 bits, mask values/capacity, sample Vec capacity, exhausted values/capacity, dependencies, relative depth and typed error. Outputs are serialized before renderer drop; retained account and final owned-mask capacity are inspected after renderer/provider destruction. Tests then require exact shell plus output payload while held and exact shell after output disposal. Actual active_frames and sound_context_frames must be zero immediately after the read.

The successful root Mark observation must consume exactly one normal plan-work unit and leave the cache lane unchanged. The refusal seed derives from an actual root Mark boundary, then requires the real typed error and reached Mark refusal event with zero writes. It neither raises a cap nor refunds work. Runtime must establish that prior query/preflight behavior does not move that seed to an earlier refusal.

The four new producer cases are added only to Destination::Components through a narrow baseline wrapper, after the older 744+10+4 body is constructed. Older schemas and frozen before34 data are untouched. Trace guards disable the independently enabled Components/ops observers on normal return or unwind.

Still unproven and explicitly excluded: constructor admission/initialization refusal, destination admission/merge refusal, callback/depth errors, cancellation/deadline, aliases/unselected outputs, alternate sends/temporal combinations, and cache pin/evict lifecycle for these new fixtures. Hooks support some of those paths, but hook presence is not execution evidence. No whole-preparation or new Gate claim follows.

## Artifact audit

All 14 candidate manifest entries and all 10 source entries match. All nine hook-before files equal current Scope, all nine per-file patches reconstruct hook-new exactly, and the two new module copies match. The source manifest's Scope prefix and reviewed-components-production-candidate.patch alias were resolved to their exact known files; no Main WIP was read.

Review source pins, audit.py, audit-results.json and navigation output are retained in /tmp/deadpan-components-native-proof-review-2026-10-31. Compilation, strict checks, actual branch/refusal/lifetime tests and guarded current/historical captures remain parent-owned qualification.
