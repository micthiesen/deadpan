# Components replay and capture glue review

**GO. No material finding in the integrated Scope glue.** This review is independent of the production candidate GO and does not claim the current library, replay or native capture has run. No roots, builds/native executions, Git or existing evidence were changed.

## Replay selection and literal paths

stages.rs registers components_mask_request only under cfg(test). Its independent TLS override defaults false and restores the previous value with a Drop guard, including unwind.

shared_mix_mask_request::with_legacy_shared_mix now chains the Components override only inside that explicit historical wrapper. Thus older Root/Point/B replay chains acquire the new legacy arm transitively. It does not change the default runtime flags. Immediate E capture and new before34 regression set only Components legacy; E's non-separate mask producer stays active.

The new current Components capture asserts both Components and SharedMix legacy are false and invokes Destination::Components without a legacy wrapper. Active read_shared_program still selects the controlled production dispatch; a separate mix without its flags errors rather than falling back to ordinary allocation. This current capture does not manufacture ownership by selecting a fixture-only finish wrapper.

The factored shared_mix_checkpoint has exactly the previous E header assignment statements, including all strings and SHA constants. Capture guard/reset code, observed_body and root_checkpoint are byte-identical to the pinned published-E source snapshot retained by the new qualification directory. Historical bodies are reconstructed through their intended explicit old path, not normalized to the current result.

## Headers, fixture identity and comparison

Destination::Components requires the published checkpoint environment to equal 69698b678fd8a75dd644993d7d2a9846986d6911. It retains prior checkpoint fields, then names its own active-components-mask-after-v1 schema, immediate components baseline path and SHA, and a bounded single-output ownership scope. Ordinary multi-output, PreserveTape, exhausted buffers, PCM/dependencies and whole preparation stay explicitly outside the claim.

The ancestor published_checkpoint field remains the old B checkpoint by design, alongside separately named C/D/E/Components provenance. This is the existing additive schema, not a claim that the whole current implementation was published at B. The retained E before field likewise continues to identify E's immediate D authority.

The new fixture independently hashes to exactly 35,593,716 bytes, SHA-256 9d6f3c67d9d611f46e75360006845a1b9419b30168a983db1ca9e4cf79c8be0a. Streaming hashes match all six existing final E active canonical captures (three per variant). The source freeze proof names the same bytes and pre-edit freeze. This static audit does not rerun or requalify those captures.

shared_mix_before_components_match_frozen_v1 hashes the included bytes before parsing; constructs actual observations with only Components legacy; adds the literal Root/E headers; removes only variant/source_sha256 identity at the two established levels; and compares the entire Value to the immutable fixture. It does not strip outputs, capacities, errors, work, invalid flags, producer rows, or account observations. The fixture itself already omits those two identity fields.

## Capture state and scope

Both current and E captures enable the existing E projection observer before observed_body. That function owns Capture RAII while all 744 native operations and the ten internal plus four transfer cases run. Existing operation/case helpers reset ops, intervals and enabled projection rows at each boundary and snapshot actual receipts afterward. Capture Drop disables intervals, native ops and projections and clears TLS state even on unwind. It finishes before output serialization, with the captured Value already owned.

The reset/receipt helper chain and internal/transfer case observers are unchanged from the E baseline. The new Destination does not silently remove earlier invalid flags or convert whole-invocation native totals into query claims. E permission-grid rows remain separate. A distinct Components producer observer and reached flag/Mark/disposal assertions remain later qualification work; the current glue alone proves no new producer-local interval or runtime success.

The new replay test adds no independently forged request/provider/lease. Existing actual request factories remain the source of observations. External capture environment, fresh /tmp output creation, source identity shape checks and fsync behavior are preserved.

## Pins and limits

Current Scope and exact before snapshots, fixture and six E canonical bodies are pinned in /tmp/deadpan-components-capture-glue-review-2026-10-31/source-pins.json. audit.py and audit-results.json retain the streamed identity and literal-code checks; ripwire.txt records navigation. No Main WIP source was used.

Current library compilation, actual full before34 replay, fresh Components captures, their source/compiler/binary/environment guards, and native failure/lifetime proof remain parent-owned verification. GO concerns this glue's static correctness and honest comparison scope.
