# Components work regression diagnosis and bounded fix

**Reject the always-sized heap flags implementation as a shippable F design. Prefer a private Components-only bounded bit marker with ordered run emission.** The unchanged normal wet-return reads must pass under existing caps and old fees; these failures cannot be accepted as newly legitimate resource refusals. Parent has selected this direction. No root edits, builds/native executions, Git or fixture changes were performed here.

## Actual failure and mechanism

The retained Main stages receipt reports 194 passed, nine failures, seven existing Split filters. All nine fail normal prepare_authored_bus unwraps with Limit("plan work per read"): one event-return parent composition and eight wet_owners tests. The retained E stages receipt shows those exact nine passing, 203 total passed with the same seven filters. These are ordinary real-PCM history/numerical assertions, not artificial low-budget fixtures.

The source explains the repeated work. A wet tile re-prepares its complete finite input in read_shared_program blocks of at most 256. Reverb history is 192000 and output width4096, so one tile is 196096 frames /256 =766 subprograms. This exactly explains the separately measured 767 rows for a64-frame root plus one Reverb tile and769 for a514-frame root in three chunks plus the same tile. Delay uses384000+4096 frames, or1516 subprograms per tile.

Each current Components block initializes all n flags and scans all n to count, even when no suppression is emitted. Positive masks add another n-entry scan, m singleton copies, per-mark work and a generic owned heapsort despite already ascending singleton positions. Globally enabling wet sends forces the Components branch, including wholly negative prehistory with no permitted route.

There is a static impossibility bound, not merely a suspected extra cost. The unchanged wet_owners base is six4800-frame plays, total28800. Its Delay test needs eight4096-output tiles. Tile i has1500−16*i wholly negative256-frame subprograms, for11552 blocks across i0..7. No early-success bypass skips these blocks in read_shared_program.

For each wholly suppressed n=256 block:
- Zero, count scan, fill scan, Mark and destination push cost5n.
- Source vector, target vector and target Box add3 units.
- Generic merge has n−1 mandatory extraction swaps plus3n−2 compaction units for adjacent singleton ranges, even ignoring every sift operation.
- Total is at least9n=2304 units per block.

Thus those negative blocks alone require at least26,615,808 new F units, above the unchanged16,777,216 cap before any prior E work, actual sift work, account initialization or residency inspection. This demonstrates why the algorithm must change. It does not identify the precise last accepted phase in each failed native read.

The proposed direct RangeBuilder candidate removes flags/copy scans but still passes n singleton entries into generic heap merge. It also cannot satisfy this Delay case as written: generic heap construction/extraction require at least762 additional sift scans for n256. Its per-block lower bound is2041 units, totaling23,577,632 before old work. Ordered output handling is necessary.

## Preferred boundary

Use a private ComponentMarks, not a new general mask representation. Its words are a fixed array sized from MAX_OUTPUT_FRAMES and u64::BITS. With current constants this is four words. Safe initialized integer storage avoids heap allocation, uninitialized memory, fake leases and StageAudio borrow retention.

The bound is actual:
- read_shared_program rejects zero or frames>MAX_OUTPUT_FRAMES before construction.
- read_shared_input and shared_eq_tile both split their calls at that constant.
- The sole production controlled dispatch is shared_eq -> SharedMix -> Components controlled finish.
- Direct cfg(test) finish remains the literal ordinary wrapper.

The earlier general ReadBlock257-ranges counterexample does not apply to this private temporary marker. ReadBlock aggregation, public masks and cache payloads keep their existing opaque owned representation.

Initialize the actual fixed words through genuine WorkControl; preserve one central Mark debit at each original post-finite/post-PCM site, then set the corresponding bit. Do not retain StageAudio or invent a no-op MaskContext to satisfy an API. Existing source matrices/programs/PCM keep their unchanged active reservation.

After callbacks and the existing depth check, count actual set bits with word popcounts and reserve begin_ranges<AudioSample> for exactly raw mark count m. This funds the actual future Box and Vec while source custody is still present. All-zero markers return empty with no new mask payload/account; there is no heap source ticket to invent or retire.

Emit maximal set-bit runs in increasing order, combining adjacency across word boundaries, and finish that builder directly. Do not invoke generic merge, re-evaluate permission/gain logic or inspect PCM zero. Final Vec capacity remains m even when its length is the smaller coalesced run count, matching the old producer's final allocation capacity.

A bounded contiguous-run extractor can use trailing_zeros, then trailing_ones after shifting by low<64. Clear bits below high with an explicit high==64 branch; otherwise shift by high<64. This avoids shift64 and avoids per-set-bit accumulator work in dense history. Charge actual word/run inspections, accumulator changes and emitted ranges. These operations replace deleted initialization/copy/sort loops; old DSP/query/visitor fees remain untouched.

## Alternative and objections

Direct pre-admitted RangeBuilder with ordered compaction is ownership-safe and smaller in patch size. A WorkControl-only marked push is sufficient after real pre-admission; it does not need a renderer during callbacks. However it reserves capacity n and future Box before callbacks even when m=0, roughly16 times the old bool vector bytes, and retains n instead of exact m for sparse output. It needs fresh quota minima/capacity evidence and still needs ordered compaction. Generic merge is not an acceptable fallback.

Lazy allocation on first mark is safe only if actual capacity/Box quota was already reserved or a real allocator context is available there. Moving a StageAudio admission callback into the mark sink conflicts with the existing recursive equalizer borrow; a fake context or late retroactive reservation is unacceptable. The inline marker avoids that complication entirely.

## Required proof

Keep all nine failed reads, request sizes, finite kernels, PCM/history assertions and caps unchanged. Re-run them and the complete default matrix after the replacement, retaining the failed6 receipt.

New pure bit-boundary tests should cover0/63/64/127/128/191/192/255, partial final words, full words, empty/alternating words, disjoint runs, cross-word runs and negative AudioSample start under the existing checked frame-end invariant. Compare run values and raw-count capacity to the literal singleton collection/merge oracle. No public or cached mask may silently become fixed256 storage.

Real checked tests must prove same-root constant/dynamic+callback marks, exact one Mark debit, exact raw-m target capacity, zero output without a new account/payload, accepted prefixes and cleanup on constructor/Mark/projection failure, and retained output ownership. Replace heap-source pointer/charge assertions with honest inline-source observations; only the actual final destination has allocation identity and a native charge.

Parent-owned source/binary guards, historical before34 parity, current captures and native quota/cancellation checks remain required. This report supplies static mechanism and design, not execution or a claim the proposed fix already passes.

## Pins

Exact Scope source, unchanged integration tests, failed F and passing E stages logs, and the direct-builder proposal are pinned under /tmp/deadpan-components-regression-design-review-2026-10-31/source-pins.json. static-cost-bound.json retains the arithmetic above; ripwire.txt records navigation. Main WIP source was not used.
