# Components parent delta review

**GO for full qualification. No material source blocker found.** Current Scope differs from the frozen native-proof hook candidate in exactly four reviewed files: components_mask_trace.rs, bound_reads/components_mask_native_tests.rs, shared_components/outputs.rs and shared_eq.rs. The other seven hooked/new files are byte-identical, including the capture glue. Main WIP was excluded.

This is a read-only source and retained-log review. No compiler, native execution, root edit, Git or fixture change was performed. The parent owns runtime qualification and publication.

## Error and work preservation

The Flags Mark arm now stores the actual check Result, uses cfg(test) inspect_err only to observe its borrowed error, then propagates it with ?. It does the same around exactly one ops::spend_work(Mark, 1). inspect_err returns the original Result; no error is converted, swallowed or replaced. The actual flag write follows accepted check/spend, and mark_written follows the write. Ordinary Ranges/None behavior is unchanged.

The check count is unchanged: one explicit control.check plus the check already inside the single central work spend. There is no new debit, canonical weight, cap, refund, source release or successful numerical operation in this lint rewrite.

The shared_eq if-let binds the same existing receipt and avoids its prior expect after is_some; both branches observe the same already-completed projection before the scalar release tail. Passing &mut read to the explicit legacy wrapper calls the same mutable closure and restores the same TLS override. It introduces no fallback or second read.

Source/flag/destination custody, physical drop order, typed AudioSample projection and callback borrow separation remain those reviewed in the frozen candidate. These deltas do not alter any of them.

## Bounded observer and default-off behavior

MAX_ROWS changes only in the cfg(test) observer, from 32 to 1024. MAX_EVENTS remains 256. The retained diagnostic stderr records actual attempted counts of 769 for positive/ample Mark setup and 767 for zero emission, with respectively 737/735 dropped at the old 32-row bound. The tests rejected these snapshots. The larger observation bound therefore follows actual reach and does not relax a production audio/residency/work limit.

attempted_rows increments only after the enabled check and before either recording or dropping a row. enable/reset construct a fresh default State; rows are never removed by pop. Consequently attempted_rows is always at least rows.len(), and dropped_rows is their actual difference. Source-init failure still counts as an attempted producer, without fabricating a completed source buffer.

Existing truncation/unfinished checks remain mandatory. Once an overflow occurs, hooks can still refer to the enclosing stack row; truncated snapshots must remain invalid for all attribution. The new counters expose the omitted count and do not make such data complete.

The default-off source ReadWork guard, Mark early guards, reserve phase guards, nested receipt stack and private pointer identity handling are unchanged. Counter/row storage does not allocate or debit native work while disabled. No new pointer address is serialized.

## Checked fixture and schema preservation

The dynamic fixture's two media lines exactly match the established authored_eq allowance fixture: source_qualification is the existing repeated-b qualification, and still_image is false. These are public ProjectDocument wire fields, subsequently checked and compiled through the ordinary path. They do not manufacture a Bound, policy result, lease, suppression flag or PCM sample.

The request still crosses from the allowed sound into its real held silent tail. The varying envelope, typed clocks, actual WAV provider and same-root depth/start assertions remain intact. The root itself must show the dynamic driver, callback, positive Mark count and owned destination. Child rows cannot substitute for that proof.

The Mark diagnostics add only assertion output. The seed formula and typed refusal expectation are unchanged. Do not infer that the dynamic media-qualification correction caused a separate constant-fixture Mark failure to disappear.

Current native_mask_after.rs, baseline wrapper, stages registration, mask Context, ops descriptor, SharedMix projection and Components driver hook files equal the frozen reviewed candidate. Thus the older capture schemas and independent replay wrappers are unchanged by these parent deltas. before34 remains exactly 35,593,716 bytes, SHA-256 9d6f3c67d9d611f46e75360006845a1b9419b30168a983db1ca9e4cf79c8be0a.

## Runtime evidence and limits

I read and pinned the retained logs rather than executing tests:

- The old count runs fail all three tests at truncation, preserving the measured 769/767 counts.
- The bounded run passes zero emission but still fails the combined positive-fixture test in both roots; Main also fails the Mark reach assertion.
- Later diagnostic stdout reports all three tests passing in both roots.
- Three isolated Mark repetitions per root each report one passing test, consistent with the parent's mark-repeat proof.

The earlier Main bounded Mark rootattempt=0 failure remains unexplained. The later diagnostics and repeats establish subsequent reach; they do not establish its cause or prove a specific fix addressed it. Keep that failed receipt and this limitation in qualification history.

This review does not perform the final compiler-artifact/source/binary joins or independently certify the complete native matrix, strict checks, historical replays or final captures. At task handoff, parent reports build5 native3 plus isolated repeats passed and strict3/Clippy3 underway. New source-initialization, projection, callback/depth/cancellation and cache-lifecycle failure coverage remains as explicitly limited in the frozen proof review. No Gate or publication claim follows.

## Pins

Exact current and frozen source pins plus retained stdout/stderr identities are in /tmp/deadpan-components-parent-delta-review-2026-10-31/source-pins.json. audit.py and audit-results.json record the four changed/seven identical files, unchanged before34 stream hash and literal log summaries. No broad Main source map was read.
