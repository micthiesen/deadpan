# Boundary test lexical-lifetime delta

**GO.** Current Scope marks_tests.rs SHA-256 db64c170d05190ffc35176bcf03f31d5cad061aa623dafbe4f5cbb9443447a7e differs from reviewed b502877a... only in formatting and the dense lifetime test's lexical block.

The block returns only the owned mask, owned account Observer and scalar held/shell measurements. Renderer, actual ReadWork/WorkControl, cancellation flag and temporary index Vec leave scope before subsequent mask/account assertions. No reference or borrowed admission escapes. This removes the drop_non_drop lint and makes the intended lifetime boundary clearer.

All exact range, capacity256, held-account and post-output shell assertions remain. The allocation/seed/mark/finalization operations are unchanged. Other six tests are unchanged apart from formatting. No production or work-accounting change follows.

This is a read-only source comparison; no compiler/native execution, root edit or Git was performed here. Parent reports the preceding build8 native3 and boundary7 passed both roots; verification of this final test delta remains parent-owned.
