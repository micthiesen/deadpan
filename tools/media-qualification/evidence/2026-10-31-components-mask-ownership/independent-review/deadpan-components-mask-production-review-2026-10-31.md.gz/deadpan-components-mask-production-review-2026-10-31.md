# Components mask production candidate review

**GO for parent integration and qualification. No material production blocker found.** Reviewed candidate.patch SHA-256 bbf08cfccc91c2b81bb7923d02c894a7335130cf9518286ea4f22403d9e2a7c1, all five proposed source files, the optional adapters and separate legacy hook. Scope is source authority. Parent reports E published at 69698b678fd8a75dd644993d7d2a9846986d6911; this review verifies source bytes, not Git publication.

No builds, compiler/native runs, root edits, Git operations, fixture capture or oracle changes were performed. Formatting reported by the author is not compilation evidence.

## Behavior and production dispatch

The active read_shared_program path admits begin_flags for exactly mix.component_mask_frames() after prediction verification and its existing reservation adjustment. It invokes finish_with_component_flags, whose separate branch requires Some(flags); absence yields InvalidPlan("component suppression destination absent"). There is no ordinary production fallback. Both the direct fixture finish wrapper and legacy escape are cfg(test).

The existing finish_into body is byte-identical after reversing only its two changed mark calls. The constant block file is byte-identical after reversing its one changed mark call. Therefore entry validation, route/program preparation, owner phases, callback sequence, gain/channel arithmetic, finite predicates, PCM writes and ordinary iteration order are preserved. The non-separate SharedMix finish algorithm is byte-identical.

All three actual mark calls remain after the original finite checks and samples.set. The ordinary Ranges arm retains its exact push and charges no new work; None remains inert. Flags checks WorkControl and invokes centralized ops::spend_work(Mark, 1) once before flags[at] = true. It neither bills twice nor holds StageAudio. Added refusal is a new native resource prefix after the original PCM write.

Ordinary destination emptiness and multi-output capacity validation remain separate from the Flags exact-length check. The controlled wrapper receives fresh false initialization, and the existing one-output loops visit each frame once with at most one mark. No output decision is reconstructed from zero PCM, per-route permissions, or replayed gain/equalizer work. Ordinary multi-output ownership remains explicitly deferred.

## Actual admission and custody

begin_flags is unchanged: it checks control, reserves the exact bool Layout before Vec allocation, accepts AllocateVector once, initializes entries with checked Zero work, asserts actual capacity and returns a unique FlagBuffer whose Vec drops before Charge. Existing source residency and all caps/old fee equations are unchanged. The new scratch is genuinely additional native residency.

The temporary self.masks(control) borrow ends at the begin_flags statement. FlagBuffer retains only its owned data/charge. The later equalizer closure can therefore borrow mutable StageAudio and Graph without a competing retained context. This is a source-level borrow feasibility finding; compilation remains owed.

finish_flags owns the buffer while finish_into borrows its slice. On success it moves that exact owner and self.start into PendingFlags. The finalizer counts actual true entries, admits begin_ranges<AudioSample> for the full old emission count, scans/emits absolute start+i..start+i+1 ranges, finishes actual Box storage, and merges in place. Both scans are checked/billed. The target Vec is distinct and admitted while the flag source is live. No owner is detached or cloned.

The established start-plus-frames validation precedes successful numeric completion, so final projection's AudioSample arithmetic has the same valid endpoint bound. Counting flags does not clip, relabel, or change clock/grid semantics. Owned merge retains actual target capacity equal to raw emission count at this producer. Later owned aggregation can retain capacity differently from older Plain algorithms; literal before/after evidence must disclose that.

## Failure and disposal paths

- Scratch admission, allocation-work or initialization refusal drops any accepted native payload inside begin_flags before returning.
- Numeric/Mark/callback failure drops the owned flags from finish_flags while read_shared_program's source reservation remains live.
- The existing post-callback depth failure drops the MixedBlock and PendingFlags before the closure's scalar release tail.
- Count, destination reserve/fill, Box-finish or merge failure cleans the pending/owned destination by existing mask RAII; the bounded finalizer closure then explicitly drops flags before returning the error.
- Successful projection also explicitly drops flags before returning the owned mask and before source active_frames subtraction.
- An all-false result has no final mask allocation, but real scratch initialization and any lazy shell remain honestly charged.

The added operations may preempt later old errors under a resource refusal. Adequate-resource numerical and validation order is preserved; universal error-priority equality is not claimed.

## E trace, old lanes and cache scope

The E descriptor match excludes PendingFlags. Its finalizer does not invoke E destination_storage or source_disposed hooks. E's permission-grid row has no recursive callbacks during projection, so the new component marking does not silently become an E producer interval. A separate Components observer and explicit unfinished/truncation checks remain qualification work.

The legacy proposal uses its own default-false TLS flag and restores prior state on unwind. Parent must install its cfg(test) module and chain historical wrappers deliberately. Immediate E replay enables only this Components override. The optional patch is exactly five Output literal wrappers around existing Vec borrows; no expected value, capacity, callback or work assertion changes. Existing direct fixture entry points remain explicitly ordinary, so ordinary_for_test cannot silently bypass new active tests.

No cached WideBlock/ReadBlock field or residency equation changes. Cached temporal/event masks remain empty; Original owned payload accounting remains through unaccounted_capacity. Flags are transient. The two non-test dead_code allowances cover retained ordinary APIs, not a default fallback. PreserveTape, multi-output ownership, PCM/dependencies, graph metadata and whole preparation remain outside this unit.

## Evidence and pins

Automated read-only checks passed:

- 5 production source pins, 14 dependency pins, 1 test source pin and all 26 candidate manifest entries match.
- All five before snapshots equal current Scope.
- candidate.patch reconstructs the five new files exactly.
- Both numeric driver comparisons and the non-separate finish comparison above are exact.

Retained under /tmp/deadpan-components-mask-production-review-2026-10-31: audit.py, audit-results.json, source-pins.json and ripwire.txt. Full native/source-guard qualification, actual separate constant/dynamic and temporal paths, each reached resource prefix, scratch/destination overlap, controller/cache lifetimes and fresh before34 replay remain owed. No compile/runtime result is inferred from this review.
