# ComponentMarks real-context tests review

**GO. No obvious compile or test-validity blocker found.** Reviewed marks_tests.rs SHA-256 b502877a4041d6e637e7563f608c6f27f7c493e086b856f1cd310d6d0ea70d9a and its cfg(test) child hook. The current Scope files already equal these proposed files at final pin time. No Rust/compiler/native execution or root/Git edit was performed by this review.

All seven tests use the real StageAudio mask context and WorkControl. The checked empty ProjectDocument/RenderPlan constructor matches the established ops test helper. No Charge, lease, native frame total or fake MaskContext is supplied.

The boundary oracle is independent of the new run extractor: it creates the previous singleton ranges and calls literal merged_suppression. Ninety cases cover frame lengths1/63/64/65/127/128/129/255/256, empty/full/last/alternating/cross-word patterns and both negative/positive starts. Reverse insertion checks that output ordering follows sample positions. Unique input indices make raw capacity==indices.len() a valid old-producer comparison.

The zero test checks exact bounded word initialization/count work, empty Plain cap0 and actual account0/no observer. Invalid frame/index tests require Range before new work or bit mutation. Actual cancellation and exhausted prior work refuse Mark without publishing a bit. Insufficient initialization work checks the real bulk debit is atomic and creates no account.

The dense test seeds and disposes a real one-range owner to measure its shell baseline. Four full words then produce one negative-coordinate range with capacity256. Output/account observations survive actual ReadWork, cancellation flag and controller destruction, then return to the measured shell after output disposal. This is real native ownership bookkeeping; it does not claim WAV/provider reachability.

The prefix sweep first measures successful finalization cost, then uses fresh real renderers with the same actually seeded shell for every smaller remaining-unit budget. Constructor/Mark work precedes the injected prior work; injection only increases the prior counter. All charged finalization operations in this seeded path use single-unit debits, so expecting accepted work to reach the cap before each next refusal is sound. Actual pending/owned payload cleanup is checked against the measured shell. The below128 observation bound keeps the sweep small and makes an unexpectedly broad operation fail explicitly.

Private access through the marks child module is feasible: parent types/helpers/constants and StageAudio ancestor fields remain visible. No obvious moved-value, mutable-borrow or lifetime error was found. Dense destruction relies on the last use of the Copy WorkControl references occurring before dropping their owners; no guard escapes in the mask. Compilation remains a separate required check.

All two source entries, seven dependency pins and three artifacts match. Both hook.patch and tests.patch reconstruct their proposed files exactly. Pins and audit results are in /tmp/deadpan-components-bounded-mark-tests-review-2026-10-31.

Coverage limits are honest: these are constructor/algorithm/account tests, not real Components numerical callback/provider proof. They do not test an overflowing unchecked private start, deadline expiration, native quota refusal or driver/depth failures. Real constant/dynamic WAV cases, exact nine wet/event regressions, historical/current captures and the full matrix remain separate parent-owned obligations. No runtime success or Gate credit is claimed.
