# Integrated inline native adapter review

**GO for the guarded run of integrated e1e770ebe3f0f07cd605ec2cb69a94ac16cf19708e16c1858f78148106ed9768.** No production change is assessed here. Two narrow proof assertions should be strengthened before claiming root zero-allocation/source-funding coverage. No builds, Rust/native execution, roots or Git were changed.

The reviewed module is the actual Scope file, based on dbac0182..., with adaptation patch52d2dc55e797f4e782b8fe1f7b3f524a9ecdd176192bf46fbeb6abeecb214d49. Source qualification, checked fixtures, real WAV/provider, row-bound diagnostics, same-root identity and Mark error diagnostics remain present.

The expect_counted fix is correct. Success/zero projection requires the recorded popcount to equal the real inline words. Mark refusal uses expect_counted=false, requires raw_mark_count null, and never unwraps it. The test still requires the actual root Mark refusal, zero accepted writes, closed logical inline scope, absent destination reservation and typed Limit("plan work per read"). Popcount of the observed prefix still equals successful writes.

Same-seed legacy and active outcomes are serialized independently. There is no unsupported assertion that they fail identically after changing real native work. Error bodies remain literal; unavailable sample/exhausted capacities are null rather than fabricated returned allocations.

Success parity remains a full active.body==old.body comparison, including all capacities. It therefore does not permit capacity differences. This is not inherently impossible for the selected unchanged fixtures: the bounded producer preserves raw-m capacity and the same coalesced values as the prior passing F5 lane. Keep it as a fixture-specific guard pending execution. A real capacity-only difference must be disclosed and adjudicated separately from semantic parity; do not normalize observations or assume universal capacity parity.

Inline storage proof removes source heap charges, stable moved-stack pointers and distinct-allocation claims. Positive target capacity equals actual popcount m and uses the typed target payload formula. Exact held shell+payload then shell-only assertions remain. Global shell retention on zero/root-Mark cases can be caused by genuine nested positive producers; it must not be described as a zero-root allocation.

Two proof weaknesses remain in e1e770:
- Zero allocation uses any row with no destination. Require the identified zero root itself to have null destination_reservation/storage, unowned result and cap0.
- Target active_frames>0 can be unrelated outer funding. At least require the actual target reservation's active_frames>=that same row's source_reservation_frames, and strengthen the capture boolean likewise.

These are assertion-strengthening gaps, not discovered production faults. Parent/author reports a later7ed86379... adapter addresses them; it is separate from the running integrated e1e770 build and requires its own pins/review.

The new F cases remain separate from the older744+10+4 bodies. The Mark-refusal row intentionally has a different JSON shape from success rows. Capture analysis must branch by case kind and read actual fields; it must not demand provider/driver/positive keys on the partial case or fill missing keys with success defaults.

Exact current source and patch identities are retained in /tmp/deadpan-components-inline-native-adapter-review-2026-10-31/source-pins.json. That pin set also records the then-pending scratch module hash7ed86379... distinctly from actual Scope e1e770. This report claims neither compilation nor runtime success.
