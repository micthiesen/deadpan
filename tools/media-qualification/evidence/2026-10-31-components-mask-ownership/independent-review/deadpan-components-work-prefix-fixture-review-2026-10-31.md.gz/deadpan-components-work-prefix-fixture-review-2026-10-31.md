# Failure-only fixture review

GO for the Rust fixture change, with one analyzer correction required before qualification. No build or native execution was performed.

The candidate patch reconstructs its new file exactly from the pinned current Scope file. All five declared base-source pins match. The three existing positive/zero fixtures and the nine regression requests remain unchanged.

The new checked fixture retains the genuine 514-frame alternating Hold/Source plan and public reader. Root varying owner-output clip gain plus saturation makes component_automation true. With no event gain, finish_into selects the constant Components driver. There is no wet send, EQ recipe, or sound event. The read_shared_input graph starts with Context::Root, and the only route to recursive shared_eq_tile is the equalize callback, which this fixture asserts never runs. OriginalInput Root keys use kind=0/context=0 plus range/depth. Their fixed hash buckets and traversal costs do not depend on fresh Arc addresses. This removes the identified pointer-dependent cache-key input from this fixture, without changing production work, caps, or the initial-seed method.

The Rust rerun asserts the actual depth-zero row selects that driver, callback_count=0, the real first Mark attempt sees MAX_PLAN_WORK_PER_READ, the actual typed plan-work refusal occurs, no bit is written, no destination exists, and request/source/account cleanup completes. It does not assert same-seed legacy and active errors are equal.

## Required analyzer fix

Candidate analyze_inline_capture.py lines 168-170 reads first_attempt_work from the failed, already-seeded row, then adds the seed and compares with MAX. The new Rust test correctly requires that failed-row value itself to equal MAX. With a positive seed, the analyzer equation cannot hold. Require failed first_attempt_work == MAX. To prove seed derivation independently, capture the ample first-work value separately and assert ample_prefix + seed == MAX. Parent and author were notified immediately.

## Limits

Static path review supports the fixture choice; runtime prefix stability remains owed. The earlier wet-fixture failure is retained. Pointer-hashed Domain collision work is a real varying input, but this review cannot reconstruct the exact failed run's missing prefix delta. Wet positive/dynamic/zero captures still retain literal work receipts and must pass final repeated/cross-root comparisons without normalization. The correction is confined to the additive F failure case; five older replay bodies must remain exact.

Pinned candidate Rust SHA: 777e1931ae50757844fa71153629476cef5855308a8cacdd52b16ceb35a45d13.
Pinned patch SHA: 35c657e95980ca92184d5eaf078d2a525c70367245c90067277071a68bfe04e6.
Pinned analyzer SHA: ae8e7d72dc1932757696f923302200c927994eaa24ce05f475562f2e0cfebfdc.
