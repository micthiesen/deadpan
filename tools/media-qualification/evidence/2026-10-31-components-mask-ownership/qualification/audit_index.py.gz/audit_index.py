from pathlib import Path
import gzip,hashlib,json
s=Path(__file__).parent
root=Path('/Users/michael/Code/deadpan');scope=Path('/tmp/deadpan-query-groundwork-2026-10-26/scoped')
rows=json.loads((s/'publication-inputs.json').read_text())
stage=(s/'staged-paths.bin').read_bytes().split(b'\0')[:-1]
assert set(p.decode()for p in stage)=={row['path']for row in rows} and len(stage)==len(rows)
index={}
for line in (s/'index-full-stage.bin').read_bytes().split(b'\0')[:-1]:
 meta,path=line.split(b'\t',1);mode,oid,entry=meta.decode().split()
 assert entry=='0'
 index[path.decode()]=(mode,oid)
for row in rows:assert index[row['path']]==('100644',row['git_blob']),row['path']
inputs=json.loads((s/'scoped-source-files.json').read_text())
for rel in inputs:
 data=(scope/rel).read_bytes();oid=hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()
 assert index[rel][1]==oid,rel
a=json.loads((s/'archive-proof.json').read_text())
p=root/a['inventory_path'];assert hashlib.sha256(p.read_bytes()).hexdigest()==a['inventory_sha256']
for r in json.loads(p.read_text())['records']:
 q=p.parent/r['stored_path'];data=q.read_bytes()
 assert len(data)==r['stored_bytes'] and hashlib.sha256(data).hexdigest()==r['stored_sha256']
 expanded=gzip.decompress(data)
 assert len(expanded)==r['bytes'] and hashlib.sha256(expanded).hexdigest()==r['sha256']
proof={'staged_paths_exact':len(rows),'scoped_code_inputs_exact':len(inputs),'archive_records_exact':a['records'],'archive_sha256':a['inventory_sha256'],'unowned_main_wip_preserved':True}
(s/'index-publication-audit.json').write_text(json.dumps(proof,indent=2)+'\n');print(json.dumps(proof))
