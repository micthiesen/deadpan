from pathlib import Path
import hashlib,json
s=Path(__file__).parent
root=Path('/Users/michael/Code/deadpan');scope=Path('/tmp/deadpan-query-groundwork-2026-10-26/scoped')
owned=json.loads((s/'owned-code-paths.json').read_text())
docs=['docs/qualification/components-mask-ownership-2026-10-31.md','docs/spec/AGENT_HANDOFF.md','docs/REQUIREMENTS.md']
paths={rel:scope/rel for rel in owned}
for rel in docs:
 assert (root/rel).read_bytes()==(scope/rel).read_bytes()
 paths[rel]=root/rel
for p in (root/'tools/media-qualification/evidence/2026-10-31-components-mask-ownership').rglob('*'):
 if p.is_file():paths[str(p.relative_to(root))]=p
assert len(paths)>18
rows=[]
for rel,p in sorted(paths.items()):
 data=p.read_bytes()
 oid=hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()
 rows.append({'path':rel,'source':str(p),'git_blob':oid,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()})
(s/'publication-inputs.json').write_text(json.dumps(rows,indent=2)+'\n')
(s/'publication-sources.txt').write_text(''.join(row['source']+'\n'for row in rows))
(s/'publication-index-info.txt').write_text(''.join('100644 '+row['git_blob']+'\t'+row['path']+'\n'for row in rows))
print(json.dumps({'paths':len(rows),'code':len(owned),'docs':len(docs),'evidence':len(rows)-len(owned)-len(docs)}))
