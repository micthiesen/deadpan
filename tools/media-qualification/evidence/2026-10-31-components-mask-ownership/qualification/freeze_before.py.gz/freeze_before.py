from pathlib import Path
import hashlib,json,shutil
e=Path('/tmp/deadpan-shared-mix-mask-qualification-2026-10-31')
s=Path('/tmp/deadpan-components-mask-qualification-2026-10-31')
assert not s.exists()
roots={'main':Path('/Users/michael/Code/deadpan'),'scoped':Path('/tmp/deadpan-query-groundwork-2026-10-26/scoped')}
publication=json.loads((e/'publication-proof.json').read_text())
assert publication['revision']=='69698b678fd8a75dd644993d7d2a9846986d6911'
s.mkdir()
names={}
for variant,root in roots.items():
 source=e/('source-files.json'if variant=='main'else'scoped-source-files.json')
 names[variant]=json.loads(source.read_text())
 initial={}
 for rel in names[variant]:
  data=(root/rel).read_bytes()
  initial[rel]={'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}
 (s/f'{variant}-initial-authority.json').write_text(json.dumps(initial,indent=2)+'\n')
shutil.copyfile(e/'removed-files.json',s/'removed-files.json')
before=[
 'crates/deadpan-audio/src/shared_eq.rs','crates/deadpan-audio/src/shared_mix.rs',
 'crates/deadpan-audio/src/shared_components.rs','crates/deadpan-audio/src/shared_components/outputs.rs',
 'crates/deadpan-audio/src/shared_components/block.rs','crates/deadpan-audio/src/stages.rs',
 'crates/deadpan-audio/src/shared_mix_mask_request.rs','crates/deadpan-audio/src/shared_mix_mask_trace.rs',
 'crates/deadpan-audio/src/bound_reads/native_mask_after.rs','crates/deadpan-audio/src/bound_reads/retained_host_pairs.rs',
 'crates/deadpan-audio/src/bound_reads/internal_suppression_baseline.rs',
 'crates/deadpan-audio/src/bound_reads/internal_transfer_entries.rs',
 'crates/deadpan-audio/src/point_suppression/ops.rs','crates/deadpan-audio/src/point_suppression/flags.rs'
]
for variant,root in roots.items():
 for rel in before:
  p=root/rel
  if not p.exists():continue
  dest=s/'before'/variant/rel;dest.parent.mkdir(parents=True,exist_ok=True)
  shutil.copyfile(p,dest)
body=(e/'shared-mix-final3-active-scoped-canonical.json').read_bytes()
sha=hashlib.sha256(body).hexdigest()
assert len(body)==35593716 and sha=='9d6f3c67d9d611f46e75360006845a1b9419b30168a983db1ca9e4cf79c8be0a'
for variant in roots:
 for mode in ['active','active2','active3']:
  assert (e/f'shared-mix-final3-{mode}-{variant}-canonical.json').read_bytes()==body
rel='crates/deadpan-audio/tests/fixtures/components-mask-baseline-v1/snapshot.json'
for variant,root in roots.items():
 p=root/rel;assert not p.exists();p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(body)
 names[variant].append(rel);names[variant].sort()
 target='source-files.json'if variant=='main'else'scoped-source-files.json'
 (s/target).write_text(json.dumps(names[variant],indent=2)+'\n')
pins=json.loads((e/'immutable-oracle-pins.json').read_text())
assert len(pins)==33
pins.append({'path':rel,'sha256':sha,'scope_equal':True})
(s/'immutable-oracle-pins.json').write_text(json.dumps(pins,indent=2)+'\n')
(s/'base-revision.txt').write_text(publication['revision']+'\n')
(s/'owned-code-paths.json').write_text(json.dumps([rel],indent=2)+'\n')
proof={'published_shared_mix':publication,'frozen_before_path':rel,'bytes':len(body),'sha256':sha,'six_independent_actual_captures_exact':True,'frozen_before_components_rust_edits':True,'initial_named_inputs':{v:len(names[v])-1 for v in roots},'immutable_before_payloads':34}
(s/'before-freeze-proof.json').write_text(json.dumps(proof,indent=2)+'\n')
for name in ['audit_sources.py','pin.py','run_target.py','run_matrix.py','run_qualified.py','run_scoped_qualified.py']:
 shutil.copyfile(e/name,s/name)
for name in ['run_qualified.py','run_scoped_qualified.py']:
 p=s/name;t=p.read_text()
 anchor="        'DEADPAN_SHARED_MIX_MASK_AFTER_OUTPUT'"
 assert t.count(anchor)==1
 p.write_text(t.replace(anchor,"        'DEADPAN_COMPONENTS_MASK_AFTER_OUTPUT', 'DEADPAN_COMPONENTS_MASK_AFTER_VARIANT',\n        'DEADPAN_COMPONENTS_MASK_AFTER_SOURCE_SHA256', 'DEADPAN_COMPONENTS_MASK_AFTER_PUBLISHED_CHECKPOINT',\n"+anchor))
shutil.copyfile('/tmp/deadpan-components-freeze-2026-10-31.py',s/'freeze_before.py')
print(json.dumps(proof))
