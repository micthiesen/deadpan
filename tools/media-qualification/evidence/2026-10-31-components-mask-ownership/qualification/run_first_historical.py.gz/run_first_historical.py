from pathlib import Path
import json,subprocess
s=Path(__file__).resolve().parent
expected={'old':'af7a292718365c34fa03692e2cbe58a2cfb3c6d444b5ae29d52647e1fdbbff14','intervals':'f64d3a00a10967cc3822083d21705bd454f2d33ff2198da30e25671092ab5a53','policy':'afa6038a02c959c7192c09c08a89266c7d52151a5e59a4f69828fbdf67e7414e','root':'596d738a53f6ef4cbf7870d74b3025504f6289f735ea91f4a38ed45c6661f44a'}
proof=[]
for mode,name in [('old','off'),('intervals','intervals'),('policy','policy'),('root','root')]:
 for variant in ['main','scoped']:
  label=f'components-first-before-{name}-{variant}'
  subprocess.run(['python',str(s/'capture_after.py'),variant,f'components-build1-{variant}',mode,label],check=True)
  r=json.loads((s/(label+'-proof.json')).read_text());assert r['sha256']==expected[mode];proof.append(r)
(s/'first-historical-proof.json').write_text(json.dumps(proof,indent=2)+'\n')
print('all_four_earlier_historical_bodies_exact_both_roots')
