from pathlib import Path
import difflib,hashlib,json,re
s=Path(__file__).resolve().parent
candidate=Path('/tmp/deadpan-components-mask-candidate-2026-10-31')
roots={'scoped':Path('/tmp/deadpan-query-groundwork-2026-10-26/scoped'),'main':Path('/Users/michael/Code/deadpan')}
rows=[]
for source_dir,target_dir in [('before','new'),('test-before','test-new')]:
 for p in sorted((candidate/source_dir).rglob('*.rs')):
  rel=str(p.relative_to(candidate/source_dir));old=p.read_bytes();new=(candidate/target_dir/rel).read_bytes()
  for variant,root in roots.items():
   path=root/rel;current=path.read_bytes()
   before=s/'before'/variant/rel
   if not before.exists():before.parent.mkdir(parents=True,exist_ok=True);before.write_bytes(current)
   else:assert before.read_bytes()==current
   if variant=='scoped':assert current==old;target=new
   else:
    a=old.decode().splitlines(True);b=current.decode().splitlines(True);c=new.decode().splitlines(True)
    matching=difflib.SequenceMatcher(a=a,b=b,autojunk=False).get_matching_blocks();edits=[]
    for kind,i,j,k,l in difflib.SequenceMatcher(a=a,b=c,autojunk=False).get_opcodes():
     if kind=='equal':continue
     matches=[m for m in matching if m.a<=i and j<=m.a+m.size and(m.size or i==len(a))]
     assert matches,(rel,i,j)
     m=matches[0];mi=i+m.b-m.a;mj=j+m.b-m.a;assert b[mi:mj]==a[i:j]
     edits.append((mi,mj,c[k:l]))
    for i,j,replacement in reversed(edits):b[i:j]=replacement
    target=''.join(b).encode()
   diff=list(difflib.unified_diff(current.decode().splitlines(True),target.decode().splitlines(True)))
   assert diff,rel
   patch='*** Begin Patch\n*** Update File: '+str(path)+'\n'
   patch+=''.join(re.sub(r'^@@.*@@.*\n$','@@\n',line)for line in diff[2:])
   patch+='*** End Patch\n'
   rows.append({'variant':variant,'path':rel,'patch':patch,'before_sha256':hashlib.sha256(current).hexdigest(),'after_sha256':hashlib.sha256(target).hexdigest()})
hook='crates/deadpan-audio/src/components_mask_request.rs'
new=(candidate/'hook-proposal/components_mask_request.rs').read_text()
for variant,root in roots.items():
 path=root/hook;assert not path.exists()
 patch='*** Begin Patch\n*** Add File: '+str(path)+'\'+\n'
 patch='*** Begin Patch\n*** Add File: '+str(path)+'\n'+''.join('+'+line for line in new.splitlines(True))+'*** End Patch\n'
 rows.append({'variant':variant,'path':hook,'patch':patch,'before_sha256':None,'after_sha256':hashlib.sha256(new.encode()).hexdigest()})
owned=set(json.loads((s/'owned-code-paths.json').read_text()))
owned.update(row['path']for row in rows)
owned.update(['crates/deadpan-audio/src/stages.rs','crates/deadpan-audio/src/shared_mix_mask_request.rs','crates/deadpan-audio/src/bound_reads/native_mask_after.rs'])
(s/'owned-code-paths.json').write_text(json.dumps(sorted(owned),indent=2)+'\n')
(s/'core-integration-plan.json').write_text(json.dumps(rows,indent=2)+'\n')
print(json.dumps(rows))
