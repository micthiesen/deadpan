from pathlib import Path
import json,re
s=Path(__file__).parent
summary={}
for variant in ['main','scoped']:
 matrix=json.loads((s/f'components-matrix-{variant}-matrix.json').read_text())
 counts={'targets':len(matrix),'passed':0,'ignored':0,'filtered':0,'retained_exact_binaries':0}
 for r in matrix:
  assert r['exit_code']==0
  name=r.get('retained_exact_binary_run',r.get('run'))
  if 'retained_exact_binary_run'in r:counts['retained_exact_binaries']+=1
  text=(s/(name+'.stdout')).read_text()
  matches=re.findall(r'test result: ok\. (\d+) passed; 0 failed; (\d+) ignored; 0 measured; (\d+) filtered out;',text)
  assert len(matches)==1,(name,matches)
  passed,ignored,filtered=map(int,matches[0])
  counts['passed']+=passed;counts['ignored']+=ignored;counts['filtered']+=filtered
 summary[variant]=counts
(s/'audio-matrix-summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(summary))
