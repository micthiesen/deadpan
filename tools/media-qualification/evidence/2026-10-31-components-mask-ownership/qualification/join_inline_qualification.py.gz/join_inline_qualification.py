from pathlib import Path
import argparse
import hashlib
import json

parser = argparse.ArgumentParser()
parser.add_argument("build_label", help="build receipt stem, e.g. components-inline-build8")
parser.add_argument("matrix_label", help="matrix receipt stem, e.g. components-inline-matrix8")
parser.add_argument("capture_prefix", help="capture prefix passed to analyze_inline_capture.py")
parser.add_argument("--capture-directory", default=None, help="directory containing receipts and captures; defaults to this script directory")
parser.add_argument("--analysis", default="inline-components-capture-analysis.json")
parser.add_argument("--matrix-summary", required=True)
parser.add_argument("--source-audit", required=True)
parser.add_argument("--check-label", action="append", default=[])
args = parser.parse_args()
script_dir = Path(__file__).resolve().parent
s = Path(args.capture_directory).resolve() if args.capture_directory else script_dir

def artifact(name):
    path = Path(name)
    return path if path.is_absolute() else s / path

def canonical(value):
    return (json.dumps(value, sort_keys=True, separators=(",", ":")) + "\n").encode()

def fingerprint(path):
    digest = hashlib.sha256()
    size = 0
    with Path(path).open("rb") as stream:
        while chunk := stream.read(1024 * 1024):
            size += len(chunk)
            digest.update(chunk)
    return {"bytes": size, "sha256": digest.hexdigest()}

def resolved_manifest(manifest):
    return {str(Path(name).resolve()): pin for name, pin in manifest.items()}

def qualify_run(run, pin, source):
    assert run["exit_code"] == 0 and run["sources_unchanged"] and run["binaries_unchanged"]
    assert run["source_before"] == run["source_after"] == source
    expected = {str(Path(pin["path"]).resolve()): {"bytes": pin["bytes"], "sha256": pin["sha256"]}}
    assert resolved_manifest(run["binary_before"]) == expected
    assert resolved_manifest(run["binary_after"]) == expected
    assert Path(run["command"][0]).resolve() == Path(pin["path"]).resolve()

roots = {
    "main": Path("/Users/michael/Code/deadpan"),
    "scoped": Path("/tmp/deadpan-query-groundwork-2026-10-26/scoped"),
}
targets = {
    "audio_context", "audio_definition", "audio_domain", "composite_insert",
    "deadpan_audio", "dormant_source", "gap_bindings", "gap_definition",
    "limiter", "loudness", "reanchors", "reference_policy", "resample",
    "root_sound_trim", "sequence", "session", "signal_transfer", "sound_events",
    "stages", "timing_representation", "true_peak",
}
capture_modes = {
    "before-off": ("old", "DEADPAN_INTERNAL_MASK_AFTER", "capture_active_internal_mask_after_v1", "e8fcdb3cb02f9682bef53f6ba2709e8a5ad692d0"),
    "before-interval": ("intervals", "DEADPAN_QUERY_INTERVAL_AFTER", "capture_active_query_intervals_v1", "ab211a2f132379a246157c3596d95fc42121541c"),
    "before-policy": ("policy", "DEADPAN_POINT_POLICY_AFTER", "capture_active_point_policy_after_v1", "eedbc58272bdd009a65239b7104ddb786a2554fc"),
    "before-root": ("root", "DEADPAN_ROOT_MASK_AFTER", "capture_active_root_mask_after_v1", "44068bd971dee62e2ed8cbaffbb2f18922283f83"),
    "before-shared": ("shared", "DEADPAN_SHARED_MIX_MASK_AFTER", "capture_active_shared_mix_mask_after_v1", "6458e9b989172147e0844fcb251c89ce8c479aaf"),
    "active": ("components", "DEADPAN_COMPONENTS_MASK_AFTER", "capture_active_components_mask_after_v1", "69698b678fd8a75dd644993d7d2a9846986d6911"),
    "active2": ("components", "DEADPAN_COMPONENTS_MASK_AFTER", "capture_active_components_mask_after_v1", "69698b678fd8a75dd644993d7d2a9846986d6911"),
    "active3": ("components", "DEADPAN_COMPONENTS_MASK_AFTER", "capture_active_components_mask_after_v1", "69698b678fd8a75dd644993d7d2a9846986d6911"),
}
summary = json.loads(artifact(args.matrix_summary).read_text())
build_sources = {}
capture_hashes = {}
for variant, root in roots.items():
    build_file = s / f"{args.build_label}-{variant}.json"
    pins_file = s / f"{args.build_label}-{variant}-pins.json"
    build = json.loads(build_file.read_text())
    assert build["exit_code"] == 0 and build["sources_unchanged"]
    source = build["source_after"]
    assert source and build["source_before"] == source
    assert Path(build["cwd"]).resolve() == root.resolve()
    for absolute, pin in source.items():
        assert fingerprint(absolute) == pin, absolute
    build_sources[variant] = source

    pins = json.loads(pins_file.read_text())
    assert len(pins) == 21 and {pin["name"] for pin in pins} == targets
    by_target = {pin["name"]: pin for pin in pins}
    for pin in pins:
        assert pin["package"] == "audio"
        assert Path(pin["artifact"]["manifest_path"]).resolve() == (root / "crates/deadpan-audio/Cargo.toml").resolve()
        assert pin["artifact"]["target"]["name"] == pin["name"]
        profile = pin["artifact"]["profile"]
        assert profile["opt_level"] == "2" and profile["overflow_checks"] and profile["debug_assertions"]
        assert fingerprint(pin["path"]) == {"bytes": pin["bytes"], "sha256": pin["sha256"]}

    matrix_file = s / f"{args.matrix_label}-{variant}-matrix.json"
    matrix = json.loads(matrix_file.read_text())
    assert len(matrix) == 21 and {row["target"] for row in matrix} == targets
    assert len({row["run"] for row in matrix}) == 21
    for row in matrix:
        run = json.loads((s / f"{row['run']}.json").read_text())
        pin = by_target[row["target"]]
        assert row["exit_code"] == 0 and row["sha256"] == pin["sha256"]
        qualify_run(run, pin, source)

    relative_source = {
        str(Path(absolute).resolve().relative_to(root.resolve())): pin
        for absolute, pin in source.items()
    }
    source_digest = hashlib.sha256(canonical(relative_source)).hexdigest()
    for mode, (producer_mode, env_prefix, test_name, checkpoint) in capture_modes.items():
        label = f"{args.capture_prefix}-{mode}-{variant}"
        proof = json.loads((s / f"{label}-proof.json").read_text())
        capture = json.loads((s / f"{label}.json").read_text())
        pin = by_target["deadpan_audio"]
        qualify_run(capture, pin, source)
        assert proof["binary_sha256"] == pin["sha256"]
        assert proof["variant"] == variant and proof["mode"] == producer_mode
        assert proof["base_revision"] == checkpoint
        assert proof["source_inputs"] == len(source)
        assert proof["source_manifest_sha256"] == source_digest
        saved_manifest = s / f"{label}-source-manifest.json"
        assert json.loads(saved_manifest.read_text()) == relative_source
        assert fingerprint(saved_manifest)["sha256"] == source_digest
        expected_test = "stages::bound_reads::retained_host_baseline::pairs::native_mask_after::" + test_name
        assert capture["command"][1:] == [
            "--ignored", "--exact", expected_test, "--nocapture", "--test-threads=1",
        ]
        environment = capture["environment"]
        expected_variant = "main-inherited" if variant == "main" else "scoped-published"
        assert environment[env_prefix + "_VARIANT"] == expected_variant
        assert environment[env_prefix + "_SOURCE_SHA256"] == source_digest
        assert environment[env_prefix + "_PUBLISHED_CHECKPOINT"] == checkpoint
        body_path = s / f"{label}-body.json"
        assert Path(environment[env_prefix + "_OUTPUT"]).resolve() == body_path.resolve()
        body = json.loads(body_path.read_text())
        assert body.pop("variant") == expected_variant
        assert body.pop("source_sha256") == source_digest
        native = body["native_requests"]
        assert native.pop("variant") == expected_variant
        assert native.pop("source_sha256") == source_digest
        canonical_path = s / f"{label}-canonical.json"
        encoded = canonical(body)
        assert canonical_path.read_bytes() == encoded
        actual = {"bytes": len(encoded), "sha256": hashlib.sha256(encoded).hexdigest()}
        assert {key: proof[key] for key in actual} == actual
        capture_hashes[(mode, variant)] = actual

for label in args.check_label:
    check = json.loads((s / f"{label}.json").read_text())
    assert check["exit_code"] == 0 and check["sources_unchanged"]
    assert check["source_before"] == check["source_after"]
    assert check["source_after"] in build_sources.values()

analysis = json.loads(artifact(args.analysis).read_text())
assert analysis["capture_prefix"] == args.capture_prefix
assert Path(analysis["capture_directory"]).resolve() == s.resolve()
active_pin = capture_hashes[("active", "scoped")]
assert analysis["active_bytes"] == active_pin["bytes"]
assert analysis["active_sha256"] == active_pin["sha256"]
base = analysis["base_historical_analysis"]
assert base["active_bytes"] == active_pin["bytes"] and base["active_sha256"] == active_pin["sha256"]
counts = base["counts"]
assert counts["native_requests"] == 744 and not base["output_changes"]
assert counts["exact_Ok"] == 264 and counts["exact_Error"] == 480
assert counts["internal_exact_output_fields"] + counts["transfer_exact_output_fields"] == 42
assert counts["completed_intervals"] == 477 and counts["partial_intervals"] == 1
assert counts["interval_rows"] == 478
assert analysis["components_cases"] == {"positive": 2, "zero": 1, "mark_refusal": 1}
audit = json.loads(artifact(args.source_audit).read_text())
assert audit["immutable_payloads_exact"] == 34

result = {
    "build_label": args.build_label,
    "matrix_label": args.matrix_label,
    "capture_prefix": args.capture_prefix,
    "matrix_summary": summary,
    "capture_analysis": analysis,
    "source_audit": audit,
    "qualification_scope": "single-output Components inline marks and final destination; ordinary multi-output, projected PreserveTape policy, exhausted vectors, PCM/dependencies and whole preparation remain outside this claim",
}
out = s / f"{args.capture_prefix}-inline-final-qualification.json"
out.write_text(json.dumps(result, indent=2) + "\n")
print(json.dumps({
    "build_label": args.build_label,
    "matrix_label": args.matrix_label,
    "capture_prefix": args.capture_prefix,
    "historical_native_requests": counts["native_requests"],
    "historical_internal_transfer_fields": counts["internal_exact_output_fields"] + counts["transfer_exact_output_fields"],
    "historical_intervals": counts["interval_rows"],
    "components_cases": analysis["components_cases"],
    "immutable_payloads": audit["immutable_payloads_exact"],
}))
