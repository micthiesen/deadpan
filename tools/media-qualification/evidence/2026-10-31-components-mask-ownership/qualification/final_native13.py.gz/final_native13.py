from pathlib import Path
import subprocess
s=Path(__file__).resolve().parent
for variant in ['main','scoped']:
 subprocess.run(['python',str(s/'pin.py'),'components-build13-'+variant],check=True)
for variant in ['main','scoped']:
 subprocess.run(['python',str(s/'run_target.py'),'components-build13-'+variant,variant,'audio','deadpan_audio','components-inline13-'+variant+'-native','components_mask_native_tests::','--test-threads=1','--nocapture'],check=True)
for variant in ['main','scoped']:
 subprocess.run(['python',str(s/'run_matrix.py'),'components-build13-'+variant,variant,'components-matrix13-'+variant],check=True)
subprocess.run(['python',str(s/'summarize_matrix13.py')],check=True)
subprocess.run(['python',str(s/'run_captures.py'),'components-build13','components-final13'],check=True)
