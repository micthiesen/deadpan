from pathlib import Path
import subprocess
s=Path(__file__).resolve().parent
for variant in ['main','scoped']:
 for suffix,filter in [('native','components_mask_native_tests::'),('boundaries','shared_components::marks::tests::')]:
  subprocess.run(['python',str(s/'run_target.py'),'components-build8-'+variant,variant,'audio','deadpan_audio','components-inline8-'+variant+'-'+suffix,filter,'--test-threads=1','--nocapture'],check=True)
