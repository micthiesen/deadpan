from pathlib import Path
import subprocess
s=Path(__file__).resolve().parent
commands=[['components-build7-scoped','scoped','audio','stages','components-inline7-scoped-stages','--test-threads=4']]
for variant in ['main','scoped']:
 commands.append(['components-build7-'+variant,variant,'audio','deadpan_audio','components-inline7-'+variant+'-native','components_mask_native_tests::','--test-threads=1','--nocapture'])
for args in commands:
 subprocess.run(['python',str(s/'run_target.py'),*args],check=True)
