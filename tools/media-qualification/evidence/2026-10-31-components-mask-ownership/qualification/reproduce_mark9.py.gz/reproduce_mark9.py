from pathlib import Path
import subprocess,json
s=Path(__file__).resolve().parent
results=[]
for i in range(8):
 label=f'components-mark9-fresh-scoped-{i+1}'
 result=subprocess.run(['python',str(s/'run_target.py'),'components-build9-scoped','scoped','audio','deadpan_audio',label,'measured_native_work_prefix_reaches_components_mark_refusal_and_cleans_source','--test-threads=1','--nocapture'])
 results.append({'run':label,'exit_code':result.returncode})
(s/'mark9-fresh-reproduction.json').write_text(json.dumps({'purpose':'Diagnostic fresh-process reproduction using the immutable build9 executable; current sources differ only by assertion diagnostics and capture caption. No final qualification claim.','results':results},indent=2)+'\n')
print(json.dumps(results))
