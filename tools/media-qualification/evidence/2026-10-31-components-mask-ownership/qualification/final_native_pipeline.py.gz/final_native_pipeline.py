from pathlib import Path
import subprocess
s=Path(__file__).resolve().parent
for variant in ['main','scoped']:
 subprocess.run(['python',str(s/'pin.py'),'components-build6-'+variant],check=True)
for variant in ['main','scoped']:
 subprocess.run(['python',str(s/'run_matrix.py'),'components-build6-'+variant,variant,'components-matrix-'+variant],check=True)
subprocess.run(['python',str(s/'summarize_matrix.py')],check=True)
subprocess.run(['python',str(s/'run_captures.py'),'components-build6','components-final6'],check=True)
subprocess.run(['python',str(s/'analyze_final_capture.py'),'components-final6','final6-capture-analysis.json'],check=True)
