from pathlib import Path
import subprocess,json
s=Path(__file__).resolve().parent
proof=[]
for repeat in range(1,4):
 for variant in ['main','scoped']:
  label=f'components-mark-repeat{repeat}-{variant}'
  r=subprocess.run(['python',str(s/'run_target.py'),'components-build5-'+variant,variant,'audio','deadpan_audio',label,'measured_native_work_prefix_reaches_components_mark_refusal_and_cleans_source','--nocapture','--test-threads=1'])
  proof.append({'repeat':repeat,'variant':variant,'label':label,'exit_code':r.returncode})
(s/'mark-repeat-proof.json').write_text(json.dumps(proof,indent=2)+'\n')
assert all(r['exit_code']==0 for r in proof)
