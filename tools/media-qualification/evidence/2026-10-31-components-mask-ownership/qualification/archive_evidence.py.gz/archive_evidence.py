from pathlib import Path
import gzip,hashlib,json
s=Path(__file__).resolve().parent
root=Path('/Users/michael/Code/deadpan');scope=Path('/tmp/deadpan-query-groundwork-2026-10-26/scoped')
out=root/'tools/media-qualification/evidence/2026-10-31-components-mask-ownership'
assert not out.exists()
allowed={'.json','.md','.txt','.py','.patch','.diff','.rs','.stdout','.stderr'}
excluded={'archive-proof.json','qualification-draft.md','final-doc-template.md','publication-proof.json','index-publication-audit.json','publication-inputs.json','publication-sources.txt','publication-index-info.txt','publication-blobs.txt','core-integration-plan.json','glue-integration-plan.json','native-hooks-integration-plan.json','patches.json','glue-patches.json','native-hooks-patches.json','inline-integration-plan.json','inline-native-integration-plan.json','inline-native-strengthening-plan.json','inline-boundary-integration-plan.json','root-prefix-integration-plan.json','driver-correction-integration-plan.json'}
files={}
for p in sorted(s.rglob('*')):
 if not p.is_file()or p.suffix not in allowed or '__pycache__'in p.parts:continue
 rel=p.relative_to(s)
 if rel.parts[:2]in [('before','main'),('observer-before','main')]or p.name in excluded or 'ripwire'in p.name:continue
 files['qualification/'+str(rel)]=p
review_names=[
 '/tmp/deadpan-after-shared-mix-producer-design-2026-10-31.md',
 '/tmp/deadpan-after-shared-mix-producer-design-review-2026-10-31.md',
 '/tmp/deadpan-components-mask-production-review-2026-10-31.md',
 '/tmp/deadpan-components-capture-glue-review-2026-10-31.md',
 '/tmp/deadpan-components-native-proof-review-2026-10-31.md',
 '/tmp/deadpan-components-parent-delta-review-2026-10-31.md',
 '/tmp/deadpan-components-final-capture-review-2026-10-31.md',
 '/tmp/deadpan-components-regression-design-review-2026-10-31.md',
 '/tmp/deadpan-components-bounded-mark-review-2026-10-31.md',
 '/tmp/deadpan-components-inline-native-adapter-review-2026-10-31.md',
 '/tmp/deadpan-components-bounded-mark-tests-review-2026-10-31.md',
 '/tmp/deadpan-components-inline-native-adapter-review-2026-10-31-addendum.md',
 '/tmp/deadpan-components-bounded-mark-tests-review-2026-10-31-lifetime-addendum.md',
 '/tmp/deadpan-components-work-prefix-fixture-review-2026-10-31.md']
for name in review_names:
 p=Path(name);assert p.exists(),p;files['independent-review/'+p.name]=p
for directory in [
 '/tmp/deadpan-after-shared-mix-producer-design-2026-10-31',
 '/tmp/deadpan-after-shared-mix-producer-design-review-2026-10-31',
 '/tmp/deadpan-components-mask-production-review-2026-10-31',
 '/tmp/deadpan-components-capture-glue-review-2026-10-31',
 '/tmp/deadpan-components-native-proof-review-2026-10-31',
 '/tmp/deadpan-components-parent-delta-review-2026-10-31',
 '/tmp/deadpan-components-final-capture-review-2026-10-31',
 '/tmp/deadpan-components-mask-candidate-2026-10-31',
 '/tmp/deadpan-components-native-tests-candidate-2026-10-31',
 '/tmp/deadpan-components-native-proof-candidate-2026-10-31',
 '/tmp/deadpan-components-dynamic-fixture-fix-2026-10-31',
 '/tmp/deadpan-components-bounded-mark-candidate-2026-10-31',
 '/tmp/deadpan-components-mask-work-fix-candidate-2026-10-31',
 '/tmp/deadpan-components-inline-native-tests-2026-10-31',
 '/tmp/deadpan-components-bounded-mark-tests-candidate-2026-10-31',
 '/tmp/deadpan-components-inline-capture-audit-2026-10-31',
 '/tmp/deadpan-components-inline-join-review-2026-10-31',
 '/tmp/deadpan-components-inline-native-adapter-review-2026-10-31',
 '/tmp/deadpan-components-work-prefix-fixture-2026-10-31',
 '/tmp/deadpan-components-prefix-instability-review-2026-10-31',
 '/tmp/deadpan-components-work-prefix-fixture-review-2026-10-31',
 '/tmp/deadpan-components-classic13-audit-candidate-2026-10-31',
 '/tmp/deadpan-components-inline-cross-capture-analyzer-2026-10-31',
 '/tmp/deadpan-components-bounded-mark-tests-review-2026-10-31']:
 d=Path(directory);assert d.exists(),d
 for p in sorted(d.rglob('*')):
  if p.is_file()and p.suffix in allowed and 'ripwire'not in p.name:
   rel=p.relative_to(d)
   if rel.parts[:2]in [('before','main'),('observer-before','main')]:continue
   files['proposal-and-audit/'+d.name+'/'+str(rel)]=p
for rel in json.loads((s/'owned-code-paths.json').read_text()):files['shipping-source/'+rel]=scope/rel
rows=[]
for key,source in sorted(files.items()):
 data=source.read_bytes();zipped=gzip.compress(data,compresslevel=6,mtime=0);dest=out/(key+'.gz')
 dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(zipped);assert gzip.decompress(dest.read_bytes())==data
 rows.append({'path':key,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest(),'stored_path':key+'.gz','stored_bytes':len(zipped),'stored_sha256':hashlib.sha256(zipped).hexdigest()})
body={'schema':'deadpan-qualified-gzip-evidence-v1','scope':'single-output production Components bounded inline marks, actual Mark sites, AudioSample destination and retained owner; actual public constant/dynamic/zero/work-refusal cases plus unchanged classic744+10+4, with literal absolute plan-work variability across six current bodies; no ordinary multi-output/projected policy/whole-preparation or product acceptance','base_revision':(s/'base-revision.txt').read_text().strip(),'records':rows,'expanded_bytes':sum(r['bytes']for r in rows),'stored_bytes':sum(r['stored_bytes']for r in rows),'excluded':'pinned executables, full Main snapshots/maps and parent raw Main patch plans; shipping source is Scope only'}
data=(json.dumps(body,indent=2)+'\n').encode();(out/'inventory.json').write_bytes(data)
proof={'inventory_path':str((out/'inventory.json').relative_to(root)),'inventory_sha256':hashlib.sha256(data).hexdigest(),'records':len(rows),'expanded_bytes':body['expanded_bytes'],'stored_bytes':body['stored_bytes']}
(s/'archive-proof.json').write_text(json.dumps(proof,indent=2)+'\n');print(json.dumps(proof))
