from pathlib import Path
import subprocess,sys
s=Path(__file__).resolve().parent
build=sys.argv[1];prefix=sys.argv[2]
for mode,name in [('old','before-off'),('intervals','before-interval'),('policy','before-policy'),('root','before-root'),('shared','before-shared'),('components','active'),('components','active2'),('components','active3')]:
 for variant in ['main','scoped']:
  subprocess.run(['python',str(s/'capture_after.py'),variant,build+'-'+variant,mode,prefix+'-'+name+'-'+variant],check=True)
