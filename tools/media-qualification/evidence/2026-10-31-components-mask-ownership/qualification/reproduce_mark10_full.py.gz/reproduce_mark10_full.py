from pathlib import Path
import subprocess,json
s=Path(__file__).resolve().parent
results=[]
for i in range(3):
 label=f'components-diagnostic10-scoped-lib-repeat-{i+1}'
 result=subprocess.run(['python',str(s/'run_target.py'),'components-build10-scoped','scoped','audio','deadpan_audio',label,'--test-threads=1'])
 results.append({'run':label,'exit_code':result.returncode})
 if result.returncode:break
(s/'mark10-full-reproduction.json').write_text(json.dumps(results,indent=2)+'\n')
print(json.dumps(results))
