from pathlib import Path
import subprocess
s=Path(__file__).resolve().parent
for variant in ['main','scoped']:
 subprocess.run(['python',str(s/'pin.py'),'components-build9-'+variant],check=True)
for variant in ['main','scoped']:
 subprocess.run(['python',str(s/'run_matrix.py'),'components-build9-'+variant,variant,'components-matrix9-'+variant],check=True)
subprocess.run(['python',str(s/'summarize_matrix9.py')],check=True)
subprocess.run(['python',str(s/'run_captures.py'),'components-build9','components-final9'],check=True)
