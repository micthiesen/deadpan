from pathlib import Path
import difflib,hashlib,json,re
s=Path(__file__).resolve().parent;c=Path('/tmp/deadpan-components-native-tests-candidate-2026-10-31')
assert hashlib.sha256((c/'candidate-sha256.txt').read_bytes()).hexdigest()=='4a2cae6531be3e344772351fdb41e0b0fbf2bdfbdc7ac3ee7524bf09503f47cb'
for line in (c/'candidate-sha256.txt').read_text().splitlines():
 sha,rel=line.split('  ',1);assert hashlib.sha256((c/rel).read_bytes()).hexdigest()==sha,rel
roots={'scoped':Path('/tmp/deadpan-query-groundwork-2026-10-26/scoped'),'main':Path('/Users/michael/Code/deadpan')}
rows=[]
for p in sorted((c/'hook-before').rglob('*.rs')):
 rel=str(p.relative_to(c/'hook-before'));a=p.read_text().splitlines(True);new=(c/'hook-new'/rel).read_text().splitlines(True)
 if a==new:continue
 for variant,root in roots.items():
  target=root/rel;current=target.read_text().splitlines(True)
  prior=s/'before'/variant/'pre-native-hooks'/rel;assert not prior.exists();prior.parent.mkdir(parents=True,exist_ok=True);prior.write_text(''.join(current))
  original=s/'before'/variant/rel
  if not original.exists():original.parent.mkdir(parents=True,exist_ok=True);original.write_text(''.join(current))
  if variant=='scoped':assert current==a;result=new
  else:
   result=current.copy();maps=difflib.SequenceMatcher(a=a,b=current,autojunk=False).get_matching_blocks();edits=[]
   for kind,i,j,k,l in difflib.SequenceMatcher(a=a,b=new,autojunk=False).get_opcodes():
    if kind=='equal':continue
    matches=[m for m in maps if m.a<=i and j<=m.a+m.size and(m.size or i==len(a))]
    assert matches,(rel,i,j)
    m=matches[0];mi=i+m.b-m.a;mj=j+m.b-m.a;assert result[mi:mj]==a[i:j]
    edits.append((mi,mj,new[k:l]))
   for i,j,replacement in reversed(edits):result[i:j]=replacement
  diff=list(difflib.unified_diff(current,result));assert diff
  patch='*** Begin Patch\n*** Update File: '+str(target)+'\n'+''.join(re.sub(r'^@@.*@@.*\n$','@@\n',x)for x in diff[2:])+'*** End Patch\n'
  rows.append({'variant':variant,'path':rel,'patch':patch,'after_sha256':hashlib.sha256(''.join(result).encode()).hexdigest()})
for p in sorted((c/'new').rglob('*.rs')):
 rel=str(p.relative_to(c/'new'));new=p.read_text()
 for variant,root in roots.items():
  target=root/rel;assert not target.exists()
  patch='*** Begin Patch\n*** Add File: '+str(target)+'\n'+''.join('+'+x for x in new.splitlines(True))+'*** End Patch\n'
  rows.append({'variant':variant,'path':rel,'patch':patch,'after_sha256':hashlib.sha256(new.encode()).hexdigest()})
owned=set(json.loads((s/'owned-code-paths.json').read_text()));owned.update(r['path']for r in rows)
(s/'owned-code-paths.json').write_text(json.dumps(sorted(owned),indent=2)+'\n')
(s/'native-hooks-integration-plan.json').write_text(json.dumps(rows,indent=2)+'\n')
print(json.dumps(rows))
