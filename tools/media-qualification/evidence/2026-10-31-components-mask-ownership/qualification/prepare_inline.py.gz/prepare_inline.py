from pathlib import Path
import difflib,hashlib,json,re
s=Path(__file__).resolve().parent
c=Path('/tmp/deadpan-components-bounded-mark-candidate-2026-10-31')
roots={'scoped':Path('/tmp/deadpan-query-groundwork-2026-10-26/scoped'),'main':Path('/Users/michael/Code/deadpan')}
rows=[]
for pin in json.loads((c/'source-pins.json').read_text())['files']:
 rel=pin['path'];new=(c/'new'/rel).read_text().splitlines(True)
 assert hashlib.sha256(''.join(new).encode()).hexdigest()==pin['new_sha256']
 for variant,root in roots.items():
  target=root/rel
  if pin['before_exists']:
   old=(c/'before'/rel).read_text().splitlines(True)
   assert hashlib.sha256(''.join(old).encode()).hexdigest()==pin['before_sha256']
   current=target.read_text().splitlines(True)
   saved=s/'before'/variant/'pre-inline'/rel
   assert not saved.exists();saved.parent.mkdir(parents=True,exist_ok=True);saved.write_text(''.join(current))
   if variant=='scoped':
    assert current==old,rel
    result=new
   else:
    result=current.copy();maps=difflib.SequenceMatcher(a=old,b=current,autojunk=False).get_matching_blocks();edits=[]
    for kind,i,j,k,l in difflib.SequenceMatcher(a=old,b=new,autojunk=False).get_opcodes():
     if kind=='equal':continue
     matches=[m for m in maps if m.a<=i and j<=m.a+m.size and(m.size or i==len(old))]
     assert matches,(rel,i,j)
     m=matches[0];mi=i+m.b-m.a;mj=j+m.b-m.a
     assert result[mi:mj]==old[i:j]
     edits.append((mi,mj,new[k:l]))
    for i,j,replacement in reversed(edits):result[i:j]=replacement
   diff=list(difflib.unified_diff(current,result));assert diff
   patch='*** Begin Patch\n*** Update File: '+str(target)+'\n'+''.join(re.sub(r'^@@.*@@.*\n$','@@\n',x)for x in diff[2:])+'*** End Patch\n'
  else:
   assert not target.exists();result=new
   patch='*** Begin Patch\n*** Add File: '+str(target)+'\n'+''.join('+'+x for x in new)+'*** End Patch\n'
  rows.append({'variant':variant,'path':rel,'patch':patch,'after_sha256':hashlib.sha256(''.join(result).encode()).hexdigest()})
owned=set(json.loads((s/'owned-code-paths.json').read_text()));owned.update(r['path']for r in rows)
(s/'owned-code-paths.json').write_text(json.dumps(sorted(owned),indent=2)+'\n')
for variant in roots:
 p=s/('scoped-source-files.json' if variant=='scoped' else 'source-files.json')
 paths=set(json.loads(p.read_text()));paths.update(r['path']for r in rows if r['variant']==variant)
 p.write_text(json.dumps(sorted(paths),indent=2)+'\n')
(s/'inline-integration-plan.json').write_text(json.dumps(rows,indent=2)+'\n')
print(json.dumps({'patches':len(rows),'paths':len(owned)}))
