from pathlib import Path
import subprocess,json
s=Path(__file__).resolve().parent
rows=[]
for variant in ['main','scoped']:
 for i in range(4):
  label=f'components-mark12-{variant}-fresh-{i+1}'
  r=subprocess.run(['python',str(s/'run_target.py'),'components-build12-'+variant,variant,'audio','deadpan_audio',label,'measured_native_work_prefix_reaches_components_mark_refusal_and_cleans_source','--test-threads=1','--nocapture'])
  rows.append({'run':label,'exit_code':r.returncode})
  assert r.returncode==0
(s/'mark12-repeat-proof.json').write_text(json.dumps(rows,indent=2)+'\n')
print(json.dumps(rows))
