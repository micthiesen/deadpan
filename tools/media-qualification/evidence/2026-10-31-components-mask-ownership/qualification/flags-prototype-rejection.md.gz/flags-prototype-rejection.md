# Unpublished Components flags prototype rejected

Published base: `69698b678fd8a75dd644993d7d2a9846986d6911`.

`components-build6-main` compiled all 21 Audio targets. The matrix passed 20 targets, while stages passed 194 tests and failed nine unchanged wet/event tests with `Limit("plan work per read")`. Seven known unrelated Main Split tests remained filtered. The isolated `wet_owners::root_returns_match_dry_plus_finite_wet_and_cold_partitions` reproduced that failure. No cap, weight, request or legacy assertion was changed to accept it. The full isolated matrix and final captures were not run after the Main failure.

The ordinary 28,800-frame Delay history requires 11,552 masked 256-frame programs across the actual eight output tiles. Flag initialization, two full-frame scans, marking and generic sort/compaction alone exceed the unchanged 16,777,216 per-read limit. Direct preallocated ranges with the generic sort retained are also insufficient. The proposed replacement uses the existing maximum 256-frame program bound, four inline words, actual Mark debits, raw-popcount destination capacity and ordered run emission without generic sorting.

The retained manual `components-flags-regression-probe-scoped` body is 40,392,493 bytes, SHA256 `2101ba383511194796bc37a573815d6fc11988f9ff6f5725059696401498029f`. It records the rejected flags prototype, not final acceptance. The first preobserver prototype body and historical captures remain separate, immutable evidence. The pre-freeze before34 body is unchanged.

The replacement must pass all nine original failures and the complete matrix under the existing limits before publication. It must also retain literal errors, verify actual native positive/zero/Mark-refusal paths, and reproduce all historical bodies. Static design approval alone is insufficient.
