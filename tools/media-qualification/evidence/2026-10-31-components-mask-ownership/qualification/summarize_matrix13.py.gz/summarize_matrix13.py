from pathlib import Path
import json,re
s=Path(__file__).parent
summary={}
for variant in ['main','scoped']:
 matrix=json.loads((s/f'components-matrix13-{variant}-matrix.json').read_text())
 assert len(matrix)==21 and len({r['target']for r in matrix})==21
 counts={'targets':len(matrix),'passed':0,'ignored':0,'filtered':0}
 for r in matrix:
  assert r['exit_code']==0
  text=(s/(r['run']+'.stdout')).read_text()
  matches=re.findall(r'test result: ok\. (\d+) passed; 0 failed; (\d+) ignored; 0 measured; (\d+) filtered out;',text)
  assert len(matches)==1,(r['run'],matches)
  passed,ignored,filtered=map(int,matches[0])
  counts['passed']+=passed;counts['ignored']+=ignored;counts['filtered']+=filtered
 summary[variant]=counts
(s/'audio-matrix13-summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(summary))
