from pathlib import Path
import difflib,json,re
s=Path(__file__).resolve().parent
roots=[Path('/tmp/deadpan-query-groundwork-2026-10-26/scoped'),Path('/Users/michael/Code/deadpan')]
rows=[]
for root in roots:
 rel='crates/deadpan-audio/src/stages.rs';p=root/rel;old=p.read_text()
 anchor='#[path = "shared_mix_mask_request.rs"]\nmod shared_mix_mask_request;'
 assert old.count(anchor)==1
 new=old.replace(anchor,anchor+'\n\n#[cfg(test)]\n#[path = "components_mask_request.rs"]\nmod components_mask_request;')
 rows.append((p,old,new))
 rel='crates/deadpan-audio/src/shared_mix_mask_request.rs';p=root/rel;old=p.read_text()
 assert old.count('    action()\n')==1
 new=old.replace('    action()\n','    super::components_mask_request::with_legacy_components_masks(action)\n')
 rows.append((p,old,new))
 rel='crates/deadpan-audio/src/bound_reads/native_mask_after.rs';p=root/rel;old=p.read_text();new=old
 anchor='    capture_after(\n        "DEADPAN_SHARED_MIX_MASK_AFTER",\n        true,\n        true,\n        Destination::SharedMix,\n    );'
 assert new.count(anchor)==1
 new=new.replace(anchor,'    crate::stages::components_mask_request::with_legacy_components_masks(|| {\n'+anchor.replace('\n','\n    ').rstrip()+'\n    });')
 enum='    SharedMix,\n}'
 assert new.count(enum)==1
 new=new.replace(enum,'    SharedMix,\n    Components,\n}')
 before='        if matches!(destination, Destination::SharedMix) {\n            "6458e9b989172147e0844fcb251c89ce8c479aaf"'
 assert new.count(before)==1
 new=new.replace(before,'        if matches!(destination, Destination::Components) {\n            "69698b678fd8a75dd644993d7d2a9846986d6911"\n        } else if matches!(destination, Destination::SharedMix) {\n            "6458e9b989172147e0844fcb251c89ce8c479aaf"')
 before='    if matches!(destination, Destination::SharedMix) {\n        PROJECTIONS.set(true);'
 assert new.count(before)==1
 new=new.replace(before,'    if matches!(destination, Destination::SharedMix | Destination::Components) {\n        PROJECTIONS.set(true);')
 start=new.index('    if matches!(destination, Destination::SharedMix) {\n        value["schema"]')
 end=new.index('    let file = OpenOptions::new()',start)
 block=new[start:end];assert block.endswith('    }\n')
 body=block[block.index('\n')+1:-6]
 helper='fn shared_mix_checkpoint(value: &mut Value) {\n'+''.join(line[4:]if line.startswith('    ')else line for line in body.splitlines(True))+'}\n\n'
 replacement='    if matches!(destination, Destination::SharedMix | Destination::Components) {\n        shared_mix_checkpoint(&mut value);\n    }\n'
 replacement+='''    if matches!(destination, Destination::Components) {
        value["schema"] = json!("active-components-mask-after-v1");
        value["components_mask_checkpoint"] = json!("69698b678fd8a75dd644993d7d2a9846986d6911");
        value["components_mask_before"] = json!({
            "path":"tests/fixtures/components-mask-baseline-v1/snapshot.json",
            "sha256":"9d6f3c67d9d611f46e75360006845a1b9419b30168a983db1ca9e4cf79c8be0a",
        });
        value["native_requests"]["scope"] = json!(
            "744 actual current native requests with Point, Root, non-separate SharedMix and single-output Components destinations. Native work remains independent of query claims."
        );
        value["scope"] = json!(
            "Production single-output Components separately funds flags before numerical finish and retains them through typed AudioSample destination projection inside its live source reservation. Ordinary multi-output, projected PreserveTape policy, exhausted vectors, PCM/dependencies and whole preparation remain outside this claim."
        );
    }
'''
 new=new[:start]+replacement+new[end:]
 anchor='fn root_checkpoint(value: &mut Value) {'
 assert new.count(anchor)==1
 new=new.replace(anchor,helper+anchor)
 anchor='#[derive(Clone, Copy)]\nenum Destination {'
 extra='''#[test]
#[ignore = "manual single-output Components mask capture; pinned sources and fresh /tmp"]
fn capture_active_components_mask_after_v1() {
    assert!(!crate::stages::components_mask_request::legacy());
    assert!(!crate::stages::shared_mix_mask_request::legacy());
    capture_after(
        "DEADPAN_COMPONENTS_MASK_AFTER",
        true,
        true,
        Destination::Components,
    );
}

'''
 assert new.count(anchor)==1
 new=new.replace(anchor,extra+anchor)
 new+='''\n#[test]
fn shared_mix_before_components_match_frozen_v1() {
    let bytes = include_bytes!("../../tests/fixtures/components-mask-baseline-v1/snapshot.json");
    assert_eq!(
        hex(Sha256::digest(bytes)),
        "9d6f3c67d9d611f46e75360006845a1b9419b30168a983db1ca9e4cf79c8be0a",
    );
    let expected: Value = serde_json::from_slice(bytes).unwrap();
    let mut actual = crate::stages::components_mask_request::with_legacy_components_masks(|| {
        PROJECTIONS.set(true);
        crate::stages::shared_mix_mask_trace::enable();
        observed_body("scoped-published", &"0".repeat(64), true, true)
    });
    root_checkpoint(&mut actual);
    shared_mix_checkpoint(&mut actual);
    for field in ["variant", "source_sha256"] {
        actual.as_object_mut().unwrap().remove(field);
        actual["native_requests"].as_object_mut().unwrap().remove(field);
    }
    assert_eq!(actual, expected);
}
'''
 rows.append((p,old,new))
patches=[]
for p,old,new in rows:
 diff=list(difflib.unified_diff(old.splitlines(True),new.splitlines(True)))
 patch='*** Begin Patch\n*** Update File: '+str(p)+'\n'
 patch+=''.join(re.sub(r'^@@.*@@.*\n$','@@\n',line)for line in diff[2:])+'*** End Patch\n'
 patches.append({'path':str(p),'patch':patch})
(s/'glue-integration-plan.json').write_text(json.dumps(patches,indent=2)+'\n')
print(json.dumps(patches))
