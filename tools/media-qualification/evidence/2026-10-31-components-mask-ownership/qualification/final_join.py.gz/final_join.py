from pathlib import Path
import hashlib,json,re
s=Path(__file__).resolve().parent
roots={'main':Path('/Users/michael/Code/deadpan'),'scoped':Path('/tmp/deadpan-query-groundwork-2026-10-26/scoped')}
summary=json.loads((s/'audio-matrix-summary.json').read_text())
for variant,root in roots.items():
 build=json.loads((s/f'components-build6-{variant}.json').read_text())
 assert build['exit_code']==0 and build['sources_unchanged']
 for absolute,pin in build['source_after'].items():
  data=Path(absolute).read_bytes()
  assert pin=={'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()},absolute
 matrix=json.loads((s/f'components-matrix-{variant}-matrix.json').read_text())
 pins=json.loads((s/f'components-build6-{variant}-pins.json').read_text())
 assert len(matrix)==len(pins)==21
 for row in matrix:
  run=json.loads((s/(row['run']+'.json')).read_text())
  assert run['exit_code']==0 and run['sources_unchanged'] and run['binaries_unchanged']
  pin=next(p for p in pins if p['name']==row['target'])
  assert row['sha256']==pin['sha256']
 for mode in ['before-off','before-interval','before-policy','before-root','before-shared','active','active2','active3']:
  name=f'components-final6-{mode}-{variant}'
  proof=json.loads((s/(name+'-proof.json')).read_text())
  assert proof['binary_sha256']==next(p['sha256']for p in pins if p['name']=='deadpan_audio')
  run=json.loads((s/(name+'.json')).read_text())
  assert run['exit_code']==0 and run['sources_unchanged'] and run['binaries_unchanged']
for name in ['components-strict3-main','components-clippy3-scoped','components-hygiene3-main','components-hygiene3-scoped','components-doc-main','components-doc-scoped','components-fmt-main','components-fmt-scoped']:
 run=json.loads((s/(name+'.json')).read_text())
 assert run['exit_code']==0 and run['sources_unchanged']
analysis=json.loads((s/'final6-capture-analysis.json').read_text())
assert analysis['counts']['native_requests']==744 and not analysis['output_changes']
assert analysis['counts']['exact_Ok']==264 and analysis['counts']['exact_Error']==480
assert analysis['counts']['internal_exact_output_fields']+analysis['counts']['transfer_exact_output_fields']==42
audit=json.loads((s/'final-source-audit.json').read_text())
assert audit['immutable_payloads_exact']==34
result={'build':'components-build6','tests':summary,'capture':analysis,'source_audit':audit,'checks':'Main strict check, Scope Audio all-target Clippy, both formatting/hygiene/doc tests; exact compiler-artifact/native run/source guards','claim':'single-output Components flags and destination only; ordinary multi-output/projected PreserveTape/whole preparation remain open, no product/Gate acceptance'}
(s/'final-qualification-join.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'active_sha256':analysis['active_sha256'],'matrix':summary,'immutable_payloads':audit['immutable_payloads_exact']}))
