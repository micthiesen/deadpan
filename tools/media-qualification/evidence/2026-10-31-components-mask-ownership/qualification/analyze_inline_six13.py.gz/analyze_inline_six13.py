from collections import Counter
from pathlib import Path
import argparse
import hashlib
import json
import subprocess
import sys

parser = argparse.ArgumentParser(description="Validate six inline Components captures without normalizing source JSON.")
parser.add_argument("prefix", help="capture prefix, e.g. components-final6")
parser.add_argument("--capture-directory", required=True)
parser.add_argument("--base-analyzer", required=True, help="classic13 analyzer script from point_content_old_producer")
parser.add_argument("--cross-root-probe", required=True, help="pre13-cross-root-work-differences.json")
parser.add_argument("--output", required=True)
args = parser.parse_args()

capture_dir = Path(args.capture_directory).resolve()
prefix = args.prefix
base_analyzer = Path(args.base_analyzer).resolve()
probe_path = Path(args.cross_root_probe).resolve()
probe = json.loads(probe_path.read_text())
assert isinstance(probe, list) and len(probe) == 54
allowed_paths = {entry["path"] for entry in probe}
assert len(allowed_paths) == len(probe), "duplicate probe paths"
allowed_leaves = {"plan_work", "plan_work_before", "plan_work_after", "source_plan_work_before"}
assert all(
    path.startswith("/components_producer_cases/cases/1/")
    and path.rsplit("/", 1)[-1] in allowed_leaves
    for path in allowed_paths
)

expected = {
    "constant_block_positive": (0, "constant"),
    "dynamic_positive": (8128, "dynamic"),
    "constant_zero_emission": (0, "constant"),
    "measured_mark_work_refusal": (0, "dynamic"),
}

def validate_capture(path):
    active = json.loads(path.read_text())
    cases = active.get("components_producer_cases", {}).get("cases")
    assert isinstance(cases, list) and len(cases) == 4, f"{path}: expected exactly four producer cases"
    assert {c.get("name") for c in cases} == set(expected), f"{path}: case names mismatch"
    counts = Counter()
    receipts = []
    for case in cases:
        name = case["name"]
        start, driver = expected[name]
        trace = case["components_trace"]
        assert trace["schema"] == "components-inline-marks-v2"
        assert trace["unfinished"] is False and trace["truncated_rows"] is False
        assert trace["attempted_rows"] == len(trace["rows"]) and trace["dropped_rows"] == 0
        assert all(row.get("events_truncated") is not True for row in trace["rows"])
        roots = [r for r in trace["rows"] if r.get("program_depth") == 0 and r.get("start") == start]
        assert len(roots) == 1, (path, name, roots)
        row = roots[0]
        assert row["parent_row_id"] is None
        assert row["source_heap_allocation"] is False and row["source_heap_charge_frames"] == 0
        assert row["source_storage"] == "inline_bitset" and row["inline_source_scope_closed"] is True
        assert row["source_frames"] == row["requested_frames"] and 0 < row["requested_frames"] <= 256
        initial, words = row["inline_words_initial"], row["inline_words_latest"]
        assert isinstance(initial, list) and isinstance(words, list)
        assert len(initial) == len(words) == row["inline_word_count"] == 4
        assert all(word == 0 for word in initial) and row["inline_bytes"] == 32
        popcount = sum(word.bit_count() for word in words)
        written = row["marks"]["written_count"]
        assert popcount == written
        actual_driver = driver in row["driver_kinds"]
        provider_used = case["provider_calls"] > 0
        assert actual_driver and provider_used
        if "actual_driver_reached" in case: assert case["actual_driver_reached"] is actual_driver
        if "provider_was_used" in case: assert case["provider_was_used"] is provider_used
        if "root_positive_marks" in case: assert case["root_positive_marks"] is (written > 0)
        destination = row["destination_reservation"]
        source_frames = row["source_reservation_frames"]
        overlap = isinstance(destination, dict) and source_frames > 0 and destination["active_frames"] >= source_frames
        capacity = row["destination_storage"]["capacity"] if isinstance(row["destination_storage"], dict) else None
        if "target_reserved_while_existing_source_live" in case: assert case["target_reserved_while_existing_source_live"] is overlap
        if "destination_capacity" in case: assert case["destination_capacity"] == capacity
        if name == "dynamic_positive": assert row["callback_count"] > 0 and case["root_dynamic_callbacks"] is True
        if name in ("constant_block_positive", "dynamic_positive"):
            assert case["exact_output_match"] is True and case["legacy"] == case["active"]
            assert popcount > 0 and row["raw_mark_count"] == popcount
            assert row["result"]["success"] is True and row["result"]["owned"] is True
            assert row["result"]["destination_identity_preserved"] is True and destination["accepted"] is True
            assert source_frames > 0 and overlap and capacity == popcount
            assert row["result"]["mask_capacity"] == capacity
            assert case["held_while_output_live"] == case["held_after_controller_drop"]
            assert case["held_while_output_live"] - case["live_after_output_drop"] == case["output_payload_frames"] > 0
            for body in (case["legacy"], case["active"]): assert "sample_capacity" in body and "exhausted_capacity" in body
            counts["positive"] += 1
        elif name == "constant_zero_emission":
            assert case["exact_output_match"] is True and case["legacy"] == case["active"]
            assert popcount == 0 and row["raw_mark_count"] == 0
            assert row["result"]["success"] is True and row["result"]["owned"] is False and row["result"]["mask_capacity"] == 0
            assert destination is None and row["destination_storage"] is None and not overlap and capacity is None
            assert case["zero_emission_has_no_target"] is True and case["output_payload_frames"] == 0
            assert case["held_while_output_live"] == case["live_after_output_drop"]
            for body in (case["legacy"], case["active"]): assert "sample_capacity" in body and "exhausted_capacity" in body
            counts["zero"] += 1
        else:
            assert case["failure_fixture"] == "checked_gain_aggregate"
            assert case["expected_driver"] == "dynamic" and actual_driver
            assert case["root_callback_count"] == 0
            assert case["root_first_attempt_plan_work_before"] == row["marks"]["first_attempt"]["plan_work_before"] == 16 * 1024 * 1024
            measured = case["measured_first_attempt"]
            assert measured["plan_work_before"] + case["seed_from_actual_first_mark"] == 16 * 1024 * 1024
            assert measured["index"] == row["marks"]["first_attempt"]["index"]
            assert measured["sample"] == row["marks"]["first_attempt"]["sample"]
            assert case["actual_mark_refusal_reached"] is True
            assert row["result"]["success"] is False and row["inline_source_scope_closed"] is True
            assert row["raw_mark_count"] is None and popcount == written == 0
            assert row["marks"]["attempt_count"] > 0 and any(e["kind"] == "mark_refused" for e in row["events"])
            assert destination is None and row["destination_storage"] is None and row["result"].get("mask_capacity") is None and not overlap
            assert case["active"] == {"status": "Error", "error": 'Limit("plan work per read")'}
            assert row["result"]["error"] == case["active"]["error"]
            assert case["active_frames_after_request"] == case["sound_context_frames_after_request"] == 0
            counts["mark_refusal"] += 1
        receipts.append({"name": name, "root_driver_reached": actual_driver, "provider_used": provider_used,
                         "popcount": popcount, "mark_writes": written, "inline_words_latest": words,
                         "raw_mark_count": row["raw_mark_count"], "source_closed": row["inline_source_scope_closed"],
                         "reservation_overlap": overlap, "destination_capacity": capacity,
                         "literal_legacy": case.get("legacy"), "literal_active": case.get("active"),
                         "output_payload_frames": case.get("output_payload_frames"),
                         "held_while_output_live": case.get("held_while_output_live"),
                         "live_after_output_drop": case.get("live_after_output_drop"),
                         "mark_refusal_reached": case.get("actual_mark_refusal_reached"),
                         "failure_fixture": case.get("failure_fixture")})
    assert counts == Counter({"positive": 2, "zero": 1, "mark_refusal": 1}), (path, counts)
    raw = path.read_bytes()
    return active, {"path": str(path), "bytes": len(raw), "sha256": hashlib.sha256(raw).hexdigest()}, receipts

modes = ["active", "active2", "active3"]
variants = ["main", "scoped"]
loaded = {}
receipts = {}
hashes = []
for variant in variants:
    for mode in modes:
        path = capture_dir / f"{prefix}-{mode}-{variant}-canonical.json"
        doc, hash_entry, case_receipts = validate_capture(path)
        loaded[(variant, mode)] = doc
        receipts[(variant, mode)] = case_receipts
        hashes.append({"variant": variant, "mode": mode, **hash_entry})

# Compare the six producer-case trees verbatim except for the 54 specifically
# probed plan_work JSON pointers. The source documents are never rewritten.
def resolve_pointer(root, pointer):
    value = root
    for part in pointer.lstrip("/").split("/"):
        part = part.replace("~1", "/").replace("~0", "~")
        value = value[int(part)] if isinstance(value, list) else value[part]
    return value

def diff(a, b, path=""):
    found = []
    if type(a) is not type(b): return [(path or "/", a, b)]
    if isinstance(a, dict):
        if a.keys() != b.keys(): return [(path or "/", sorted(a.keys()), sorted(b.keys()))]
        for key in a:
            found.extend(diff(a[key], b[key], path + "/" + str(key).replace("~", "~0").replace("/", "~1")))
    elif isinstance(a, list):
        if len(a) != len(b): return [(path or "/", len(a), len(b))]
        for i, (x, y) in enumerate(zip(a, b)): found.extend(diff(x, y, path + "/" + str(i)))
    elif a != b: found.append((path or "/", a, b))
    return found

reference = loaded[("main", "active")]
ref_cases = reference["components_producer_cases"]
allowed_values = {p: [] for p in allowed_paths}
for variant in variants:
    for mode in modes:
        doc = loaded[(variant, mode)]
        # Require only producer payload equality after applying the explicit
        # plan_work path allowlist; all other JSON body fields remain compared.
        differences = diff(ref_cases, doc["components_producer_cases"])
        for pointer, left, right in differences:
            full_pointer = "/components_producer_cases" + pointer
            assert full_pointer in allowed_paths, (variant, mode, full_pointer, left, right)
        for pointer in allowed_paths:
            value = resolve_pointer(doc, pointer)
            assert isinstance(value, int) and not isinstance(value, bool), (variant, mode, pointer, value)
            allowed_values[pointer].append({"variant": variant, "mode": mode, "value": value})
# Verify all six actual values/deltas are retained and every probe-listed path
# has changed in the historical Main/Scope cross-root pair.

base_analyzer = base_analyzer.resolve()
base_by_variant = {}
analysis_dir = Path(args.output).resolve().parent
analysis_dir.mkdir(parents=True, exist_ok=True)
for variant in variants:
    out = analysis_dir / f"{prefix}-classic13-{variant}.json"
    subprocess.run([sys.executable, str(base_analyzer), prefix, "--variant", variant,
                    "--capture-directory", str(capture_dir), "--output", str(out)], check=True)
    base_by_variant[variant] = json.loads(out.read_text())

proof = {
    "capture_prefix": prefix,
    "capture_directory": str(capture_dir),
    "full_capture_hashes": hashes,
    "producer_receipts_by_capture": {f"{v}/{m}": receipts[(v,m)] for v in variants for m in modes},
    "components_cases_by_capture": {f"{v}/{m}": {"positive": 2, "zero": 1, "mark_refusal": 1} for v in variants for m in modes},
    "allowed_counter_differences": [{
        "path": p,
        "values_and_reference_deltas": [
            {**entry, "delta_from_main_active": entry["value"] - next(
                x["value"] for x in allowed_values[p] if x["variant"] == "main" and x["mode"] == "active"
            )}
            for entry in allowed_values[p]
        ],
    } for p in sorted(allowed_paths)],
    "probe_sha256": hashlib.sha256(probe_path.read_bytes()).hexdigest(),
    "historical_probe_values": probe,
    "base_historical_analysis_by_variant": base_by_variant,
    "comparison_scope": "All six four-case producer payloads were compared recursively. Only the exact 54 pre-probed plan_work pointers were allowed to vary; every value is recorded literally. Full raw capture hashes are separate and are not claimed equal. Classic historical parity is delegated to the supplied classic13 analyzer.",
    "case_limit": "Only the four explicitly captured Components cases per file are validated. No source JSON is normalized or rewritten by this script.",
}
out = Path(args.output)
out.parent.mkdir(parents=True, exist_ok=True)
out.write_text(json.dumps(proof, indent=2) + "\n")
print(json.dumps({"capture_prefix": prefix, "captures": len(hashes), "counter_paths": len(allowed_paths),
                   "all_six_cases_validated": True, "raw_hashes": hashes}))
