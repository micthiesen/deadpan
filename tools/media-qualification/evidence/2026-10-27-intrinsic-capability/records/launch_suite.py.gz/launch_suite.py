from pathlib import Path
import json
import os
import sys

scratch = Path(__file__).resolve().parent
scoped = len(sys.argv) > 1 and sys.argv[1] == 'scoped'
pins = json.loads((scratch / ('scoped-all-pins.json' if scoped else 'all-pins.json')).read_text())
runner = scratch / ('run_scoped.py' if scoped else 'run.py')
command = [sys.executable, str(runner)]
for row in pins:
    command += ['--binary', row['path']]
command += ['scoped-plan-all' if scoped else 'plan-all', '--', sys.executable,
            str(scratch / 'run_pinned_suite.py')]
if scoped:
    command.append('scoped')
os.execv(sys.executable, command)
