from pathlib import Path
import hashlib
import json
import shutil

scratch = Path(__file__).resolve().parent
receipt = json.loads((scratch / 'build4.json').read_text())
assert receipt['exit_code'] == 0 and receipt['sources_unchanged']
binaries = []
for line in (scratch / 'build4.stdout').read_text().splitlines():
    try:
        artifact = json.loads(line)
    except ValueError:
        continue
    if (artifact.get('reason') != 'compiler-artifact' or not artifact.get('executable')
            or not artifact.get('profile', {}).get('test')):
        continue
    name = artifact['target']['name']
    if 'deadpan-plan#' not in artifact['package_id'] or name not in ['deadpan_plan', 'intrinsic_preparation']:
        continue
    out = scratch / ('verified-' + name.replace('_', '-'))
    assert not out.exists()
    shutil.copy2(artifact['executable'], out)
    binaries.append(dict(name=name, path=str(out), bytes=out.stat().st_size,
                         sha256=hashlib.sha256(out.read_bytes()).hexdigest(), artifact=artifact))
assert len(binaries) == 2
(scratch / 'verified-pins.json').write_text(json.dumps(binaries, indent=2) + '\n')
print(json.dumps([{key: row[key] for key in ['name', 'path', 'sha256']}
                  for row in binaries], indent=2))
