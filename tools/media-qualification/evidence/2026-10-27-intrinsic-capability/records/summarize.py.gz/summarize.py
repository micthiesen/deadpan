from pathlib import Path
import hashlib
import json
import re

scratch = Path(__file__).resolve().parent
counts = {}
for label, expected in [('verified-plan-lib', 102), ('intrinsic-tests3', 11),
                        ('scoped-plan-lib', 89), ('scoped-intrinsic', 11)]:
    receipt = json.loads((scratch / (label + '.json')).read_text())
    assert receipt['exit_code'] == 0 and receipt['sources_unchanged'] and receipt['binaries_unchanged']
    found = re.findall(r'test result: .*? (\d+) passed; (\d+) failed; (\d+) ignored;',
                       (scratch / (label + '.stdout')).read_text())
    assert len(found) == 1 and tuple(map(int, found[0])) == (expected, 0, 0)
    counts[label] = dict(passed=expected, failed=0, ignored=0, seconds=receipt['seconds'])
for label, result_file, total in [('plan-all', 'suite-results.json', 552),
                                  ('scoped-plan-all', 'scoped-suite-results.json', 539)]:
    receipt = json.loads((scratch / (label + '.json')).read_text())
    result = json.loads((scratch / result_file).read_text())
    assert receipt['exit_code'] == 0 and receipt['sources_unchanged'] and receipt['binaries_unchanged']
    assert (result['passed'], result['failed'], result['ignored']) == (total, 0, 0)
    assert len(result['targets']) == 29
    counts[label] = dict(passed=total, failed=0, ignored=0, targets=29, seconds=receipt['seconds'])
for label in ['build2', 'build3', 'build4', 'all-build', 'scoped-build', 'scoped-all-build', 'strict']:
    receipt = json.loads((scratch / (label + '.json')).read_text())
    assert receipt['exit_code'] == 0 and receipt['sources_unchanged'] and receipt['binaries_unchanged']
    counts[label] = dict(exit_code=0, seconds=receipt['seconds'])
for filename in ['source-frozen.json', 'scoped-frozen.json']:
    for path, pin in json.loads((scratch / filename).read_text()).items():
        data = Path(path).read_bytes()
        assert pin == dict(bytes=len(data), sha256=hashlib.sha256(data).hexdigest())
out = scratch / 'regression-summary.json'
assert not out.exists()
result = dict(counts=counts, all_sources_and_executed_binaries_stable=True,
              production_query_logic_unchanged_during_fixture_corrections=True,
              runtime_audio_caller=False, runtime_batching=False,
              media_or_full_split_matrix_rerun=False, acceptance_credit=False)
out.write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result, indent=2))
