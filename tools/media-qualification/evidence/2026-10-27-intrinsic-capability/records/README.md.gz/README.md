# Intrinsic-preparation capability candidate

Scratch-only candidate, 2026-10-27. No repository edits, Cargo, rustc, native
processing, provider calls, commits or pushes. Rustfmt 1.97.1 was run only on
the copied changed files. No test is claimed to pass before main builds it.

## Candidate and contract

`RenderPlan::audio_intrinsic_preparation(AudioQueryLimits)` returns:

* `NotRequired { work }` only after every current compiled node, optional own
  retained layout, and every `audio_bindings.timings` layout is scanned.
* `MayBeRequired { work }` after finding a processing recipe or owned input.
* `WorkLimit { work }` before an uncharged visit would occur. It never proves
  absence. Audio must bill `work()` before selecting scalar fallback.

Only invalid limits return PlanError, before any work. There are no other
fallible operations after discovery starts. No new resource/work limit, cache,
owned query graph, Arc clone or persistent pin is introduced. Record work is
charged before inspecting each node/layout, with duplicate layouts deliberately
rescanned. No Repeat plays or override occurrences are enumerated.

The capability concerns the plan's owned authored/history graph, not arbitrary
caller-provided projected PCM handles. Even after NotRequired, a future cold
Audio walker must refuse actual ProjectedStage/Projected root/signal inputs
under its first intrinsic-free eligibility domain. This does not enable runtime
batching or prove a future resource bound, sources, permission or cache state.
As with existing bounded Plan queries, Audio owns cancellation/deadline checks
before and after this native-free, allocation-free bounded scan.

## Coverage audit

* Live `CompiledKind::Retime` uses the exact processing predicate
  `pitch.processes(scale == ExactRatio::ONE)`. An owned `preserve_input` is
  separately positive even if the effective live clock has become unity.
* Frozen tables reuse Core's `FrozenAudioLayout::retime_processes(id,node)`:
  both the integral processing recipe and effective derived clock count.
  Historical compilation/validation is not repeated or charged after the fact.
* Every structural definition/override is in the complete compiled node map;
  every Original binding and BeatSound journal references the retained timing
  inventory. Every timing is scanned, including later clocks and unrelated
  nodes. This may give conservative positives for old hidden stages but cannot
  certify a hidden owned table absent without visiting it.
* `compile_audio_context` retains its original layout in sound_clock_layout;
  `compile_sound_processing_layout` does likewise. The query scans that table
  as well as their compiled nodes. The live sound-clock capture is also scanned
  if present, even though it overlaps current nodes.
* Automatic Source-occurrence projections use
  `audio_source_occurrence_support::processes/resolve` and
  `AudioStage::for_node`; both apply the same compiled processing predicate.
  The owned-input builder uses `AudioStage::for_owned_input` and the detected
  `preserve_input` field. Bound intrinsic preparation resolves back to a
  processing node in these same live/retained maps. It is not a fresh unowned
  source of recipes.
* Root/BeatSound source mappings carry source selection/placement/offset and
  apply affine source resampling. Core sound_events validates exact natural
  duration. They have no independent PitchPolicy. RootSoundRoute edits change
  unity-rate delivery; compiled root sounds retain a source route and islands,
  not an intrinsic operand. The source-recipe test constructs both paths and
  checks that an attempted independent duration change is refused by Core.
* Caller-created `AudioStageProjection::new_mixed_input`, projected roots and
  other external operands are outside this capability. No false NotRequired
  claim about those allocations is made, and no source admission is waived.

## Tests authored, not executed

The new integration target contains eleven tests covering ordinary structures
and compact Repeat count independence; transparent unity Preserve Partitions
and nonunity FollowSpeed; nonunity Preserve/unity nonzero Shift; sparse override
processing; an ordinary current Source bound to a historical table containing
processing; retained audio contexts; complete/tight/partial work with conserved
spent counts; invalid limits; routed root/BeatSound recipes; later sound journal
clocks; and owned Preserve input behind a unity effective live clock.

A twelfth test in the module exercises **derived-only** historical processing:
the integral Preserve recipe is unity, only its frozen derived clock is
nonunity, and `Visits::layout` must report MayBeRequired. It starts with the
transparent table reporting no processing. The FrozenAudioLayout is admitted
through public capture/from_json; no internal Core fields are bypassed.
Existing binding admission calls require_follow_speed_clocks and refuses this
derived processor before it can be hidden behind a valid public current Source
binding; FrozenAudioContext refuses nonintegral clocks as well. The test asserts
these refusals instead of fabricating a currently impossible public document.
The normal valid historical binding tests remain unchanged. This is coverage
of the exact future-safe layout predicate, not acceptance of derived Preserve
bindings. `initial.patch` preserves the candidate before this added unit.

Fixtures use public admission/compilation APIs and no provider or native device.
They are unbuilt. Main should first run the new target, fix any fixture or
compiler/lint issue with exact evidence retained, then broader Plan regressions
and strict lint. Expected commands, under main's scheduler:

```sh
cargo test -p deadpan-plan --locked --test intrinsic_preparation
cargo test -p deadpan-plan --locked
cargo clippy -p deadpan-plan --all-targets --locked -- -D warnings
```

## Lineage and handoff

The immutable before copy pins 487 files from Core/Plan src/tests, both crate
manifests, workspace manifest/lock and toolchain at current HEAD
`053d31c2960904fc173435ae3f04b6241e818a72`. Other in-flight modules remain untouched.
`before-manifest.json` records the live source overlay, not just that commit.
`after-manifest.json` records all copied Plan files; `changed-files.json` narrows
the four-file candidate; `implementation.patch` applies only those paths.
Main owns review, application, builds, Audio integration and acceptance credit.
