# Independent review: intrinsic-preparation capability query

Scope: `implementation.patch` and `README.md`, including the new `audio_intrinsic_preparation` module, the Plan exports, and the new integration test target. The pinned Core/Plan inputs were used for context; unrelated WIP was excluded.

## Findings

No supported false-`NotRequired` finding in the declared scope. The query returns `NotRequired` only after charging and scanning the current compiled node inventory, the retained `sound_clock_layout` when present, and every entry in `audio_bindings.timings()`. Current nodes separately check `preserve_input` and the same `pitch.processes(scale == ExactRatio::ONE)` predicate used by compiled Retime processing. Frozen tables call Core's `FrozenAudioLayout::retime_processes`, which checks both integral mapping/duration and the effective derived clock. Work exhaustion before any node/layout/header visit returns `WorkLimit` with accumulated visits, never a negative proof. The code performs no repeat expansion, allocation, Arc clone, provider access, or native work.

The API documentation and README limit the proof to plan-owned authored/history recipes and explicitly leave caller-created projected operands, source admission, allocation admission, and batching outside its contract.

## Verification limits and material test gaps

- No Cargo or rustc run was performed; the candidate tests are unexecuted and the main session owns build/integration.
- Tests cover the compiled predicate variants, current owned Preserve input, frozen historical processing, all timing entries, sparse overrides, repeat-count independence, work-limit accounting, invalid limits, and affine source/root sound mappings. The routed-source fixture does not model arbitrary externally supplied projected handles, consistent with the stated scope.
- The patch is a four-file candidate. The main session still needs to apply the clean published-plan insertion hunk and compile/run the new target; no acceptance of resource fit or downstream Audio eligibility follows from this capability result.

## Supplemental review: final test-only changes

The production query body is unchanged. The new unit case directly feeds a metadata-only frozen layout to the same `Visits::layout` helper used by the query: a 4-frame integral Retime becomes nonunity only through its frozen derived clock, so the helper correctly charges the header plus three node visits and returns `MayBeRequired { work: 4 }`. It also confirms `AudioBindingState::new` and `FrozenAudioContext::from_json` continue to reject that layout under Core's existing Preserve guard. This tests conservative handling of the table predicate without fabricating a binding-valid history. Existing public integration tests exercise valid retained tables.

The final integration fixture corrections retain a valid 48 kHz Original asset and keep opaque Preserve processing outside the bound source while still asserting that the complete owned timing table is scanned conservatively. This is consistent with the query's deliberately conservative inventory contract. The reported progression was an initial compile failure, then 1 pass/10 fixture failures, then 9 pass/2 fixture failures, and finally all 11 target tests plus 541 Plan library tests passing. Those results are reported by the main session; I did not run Cargo. No new finding.
