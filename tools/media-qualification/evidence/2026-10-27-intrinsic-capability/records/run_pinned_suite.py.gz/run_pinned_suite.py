from pathlib import Path
import hashlib
import json
import re
import subprocess
import sys
import time

scratch = Path(__file__).resolve().parent
scoped = len(sys.argv) > 1 and sys.argv[1] == 'scoped'
pins = json.loads((scratch / ('scoped-all-pins.json' if scoped else 'all-pins.json')).read_text())
directory = scratch / ('scoped-all-results' if scoped else 'all-results')
assert not directory.exists()
directory.mkdir()
script_hash = hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
results = []
for row in pins:
    binary = Path(row['path'])
    assert hashlib.sha256(binary.read_bytes()).hexdigest() == row['sha256']
    command = [str(binary), '--nocapture', '--test-threads=1']
    stdout = directory / (row['name'] + '.stdout')
    stderr = directory / (row['name'] + '.stderr')
    start = time.monotonic()
    with stdout.open('xb') as output, stderr.open('xb') as errors:
        code = subprocess.run(command, stdout=output, stderr=errors, check=False).returncode
    summaries = re.findall(r'test result: .*? (\d+) passed; (\d+) failed; (\d+) ignored;',
                           stdout.read_text())
    assert len(summaries) == 1, row['name']
    passed, failed, ignored = map(int, summaries[0])
    results.append(dict(name=row['name'], command=command, sha256=row['sha256'],
                        exit_code=code, passed=passed, failed=failed, ignored=ignored,
                        seconds=time.monotonic() - start))
    assert hashlib.sha256(binary.read_bytes()).hexdigest() == row['sha256']
    print(json.dumps(results[-1]), flush=True)
assert hashlib.sha256(Path(__file__).read_bytes()).hexdigest() == script_hash
result = dict(script_sha256=script_hash, targets=results,
              passed=sum(row['passed'] for row in results),
              failed=sum(row['failed'] for row in results),
              ignored=sum(row['ignored'] for row in results))
(scratch / ('scoped-suite-results.json' if scoped else 'suite-results.json')).write_text(
    json.dumps(result, indent=2) + '\n')
print(json.dumps({key: result[key] for key in ['passed', 'failed', 'ignored']}), flush=True)
raise SystemExit(any(row['exit_code'] != 0 for row in results))
