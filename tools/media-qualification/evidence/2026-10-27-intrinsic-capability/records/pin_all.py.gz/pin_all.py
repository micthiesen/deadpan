from pathlib import Path
import hashlib
import json
import shutil
import sys

scratch = Path(__file__).resolve().parent
scoped = len(sys.argv) > 1 and sys.argv[1] == 'scoped'
label = 'scoped-all-build' if scoped else 'all-build'
receipt = json.loads((scratch / (label + '.json')).read_text())
assert receipt['exit_code'] == 0 and receipt['sources_unchanged']
directory = scratch / ('scoped-all-binaries' if scoped else 'all-binaries')
assert not directory.exists()
directory.mkdir()
binaries = []
for line in (scratch / (label + '.stdout')).read_text().splitlines():
    try:
        artifact = json.loads(line)
    except ValueError:
        continue
    if (artifact.get('reason') != 'compiler-artifact' or not artifact.get('executable')
            or not artifact.get('profile', {}).get('test')
            or 'deadpan-plan#' not in artifact.get('package_id', '')):
        continue
    name = artifact['target']['name']
    out = directory / name
    assert not out.exists()
    shutil.copy2(artifact['executable'], out)
    binaries.append(dict(name=name, path=str(out), bytes=out.stat().st_size,
                         sha256=hashlib.sha256(out.read_bytes()).hexdigest(), artifact=artifact))
assert any(row['name'] == 'deadpan_plan' for row in binaries)
assert any(row['name'] == 'intrinsic_preparation' for row in binaries)
out = scratch / ('scoped-all-pins.json' if scoped else 'all-pins.json')
out.write_text(json.dumps(sorted(binaries, key=lambda row: row['name']), indent=2) + '\n')
print(json.dumps(dict(targets=len(binaries), pins=str(out))))
