from pathlib import Path
import gzip
import hashlib
import json

scratch = Path(__file__).resolve().parent
dest = Path('/Users/michael/Code/deadpan/tools/media-qualification/evidence/2026-10-27-intrinsic-capability')
assert not dest.exists(), 'refuse evidence overwrite'
summary = json.loads((scratch / 'regression-summary.json').read_text())
assert summary['all_sources_and_executed_binaries_stable']
labels = ['build', 'build2', 'build3', 'build4', 'intrinsic-tests', 'intrinsic-tests2',
          'intrinsic-tests3', 'plan-lib', 'plan-lib2', 'verified-plan-lib', 'strict',
          'scoped-build', 'scoped-plan-lib', 'scoped-intrinsic', 'all-build',
          'plan-all', 'scoped-all-build', 'scoped-plan-all']
for label in labels:
    receipt = json.loads((scratch / (label + '.json')).read_text())
    assert 'exit_code' in receipt and receipt['sources_unchanged'] and receipt['binaries_unchanged']
paths = [path for path in scratch.iterdir() if path.is_file() and path.suffix in
         {'.json', '.py', '.md', '.patch', '.rs', '.before', '.stdout', '.stderr', '.txt'}]
for directory in ['all-results', 'scoped-all-results', 'failed-blank-source', 'failed-opaque-binding']:
    paths += [path for path in (scratch / directory).rglob('*') if path.is_file()]
for name in ['crates/deadpan-plan/src/lib.rs', 'crates/deadpan-plan/src/plan.rs']:
    paths.append(scratch / 'before' / name)
dest.mkdir(parents=True)
files = []
for path in sorted(paths):
    data = path.read_bytes()
    compressed = gzip.compress(data, mtime=0)
    out = dest / 'records' / (str(path.relative_to(scratch)) + '.gz')
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_bytes(compressed)
    files.append(dict(path=str(out.relative_to(dest)), bytes=len(compressed),
                      sha256=hashlib.sha256(compressed).hexdigest(), expanded_bytes=len(data),
                      expanded_sha256=hashlib.sha256(data).hexdigest()))
inventory = dict(schema_version=1, base_revision='226d6c27',
    scope='Four-file bounded Plan intrinsic-time-processing capability query. Complete negative, conservative positive and partial WorkLimit each retain actual spent work; no Audio caller, media/resource admission or batching. Main552/scoped539 combined Plan tests across29 targets each, including102/89 library and11 new integration tests each. Strict/review pass; fixture failures and commentary count correction retained. Exact live/published patches preserve inherited Plan WIP.',
    runtime_baseline_evidence=dict(path='../2026-10-27-component-policy/inventory.json',
        inventory_sha256='9d717633adabeebe95bda37c0714a55f7f25aa46961e63d7737d8dd97ee095ed',
        note='Baseline frozen main/scoped runtime identities. Exact three-line Plan module insertion differs only in inherited surrounding context; three other task files match byte-for-byte. No copied workspace/executable archive.'), files=files)
out = dest / 'inventory.json'
out.write_text(json.dumps(inventory, indent=2) + '\n')
for row in files:
    data = (dest / row['path']).read_bytes()
    expanded = gzip.decompress(data)
    assert len(data) == row['bytes'] and hashlib.sha256(data).hexdigest() == row['sha256']
    assert len(expanded) == row['expanded_bytes'] and hashlib.sha256(expanded).hexdigest() == row['expanded_sha256']
print(json.dumps(dict(payloads=len(files), stored_bytes=sum(row['bytes'] for row in files),
                      expanded_bytes=sum(row['expanded_bytes'] for row in files),
                      inventory_sha256=hashlib.sha256(out.read_bytes()).hexdigest()), indent=2))
