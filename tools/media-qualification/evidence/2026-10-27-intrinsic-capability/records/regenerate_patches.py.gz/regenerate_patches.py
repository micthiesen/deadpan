from pathlib import Path
import difflib
import hashlib
import json

scratch = Path(__file__).resolve().parent
root = Path('/Users/michael/Code/deadpan')
paths = ['crates/deadpan-plan/src/audio_intrinsic_preparation.rs',
         'crates/deadpan-plan/src/lib.rs', 'crates/deadpan-plan/src/plan.rs',
         'crates/deadpan-plan/tests/intrinsic_preparation.rs']
insertion = ('#[path = "audio_intrinsic_preparation.rs"]\n'
             'mod audio_intrinsic_preparation;\n'
             'pub use audio_intrinsic_preparation::AudioIntrinsicPreparation;\n')
anchor = '#[path = "audio_context.rs"]\nmod audio_context;\n'
live = []
published = []
pins = {}
for name in paths:
    original = scratch / 'before' / name
    before = original.read_text() if original.exists() else ''
    after = (root / name).read_text()
    pins[name] = dict(bytes=len(after.encode()), sha256=hashlib.sha256(after.encode()).hexdigest())
    def difference(old, new):
        return ''.join(difflib.unified_diff(old.splitlines(keepends=True),
                     new.splitlines(keepends=True), fromfile='a/' + name if old else '/dev/null',
                     tofile='b/' + name))
    live.append(difference(before, after))
    if name == 'crates/deadpan-plan/src/plan.rs':
        clean = (scratch / 'published-plan.rs.before').read_text()
        assert clean.count(anchor) == 1 and after.count(insertion) == 1
        published.append(difference(clean, clean.replace(anchor, anchor + insertion)))
    else:
        published.append(difference(before, after))
(scratch / 'final-live.patch').write_text(''.join(live))
(scratch / 'final-published.patch').write_text(''.join(published))
(scratch / 'parent-final-task-pins.json').write_text(json.dumps(pins, indent=2) + '\n')
print(json.dumps(pins, indent=2))
