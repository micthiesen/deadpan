# Complete744 Point native auditor candidate

Scratch-only independent auditor. No root source edits, native/build/producer execution, oracle generation, cap changes, work-weight changes, refunds or semantic normalization.

The driver is audit_point_native.py. It requires four REAL fresh native captures plus the pinned immutable current-before body. No fabricated or derived capture is accepted as authority.

## Inputs and exact authority

Frozen actual OLD:
crates/deadpan-audio/tests/fixtures/point-content-native-baseline-v1/snapshot.json
SHA-256164f9543d7db901b20a8d1a4d200a9853cd3a89e6fc0615aaf61f4ee2dee38c3
Schema raw-domain-native-admitted-v1, exactly744 unique fixture/operation rows.

The actual baseline is EACH operations[].paired.new. Embedded prior pair comparison/accounting refers to the earlier retained reference and never becomes the actual Point-before observation.

Four fresh body inputs are required:
- ordinary Main/scoped: point-content-native-ordinary-receipts-v1, actual_point_content_mode ordinary_query_and_manual_debit; only Point content query legacy, all other admissions remain active.
- admitted Main/scoped: point-content-native-admitted-v1, actual_point_content_mode admitted_query_forwarded_debit.

Exact candidate schema was coordinated with native-test candidate v2. Declared added top fields:
preceding_raw_domain_schema, published_point_content_checkpoint, point_content_scope, pre_point_content_frozen_sha256, actual_point_content_mode.
Outer variant/source_sha256 remain capture provenance. Each paired.receipts adds point_content and point_content_host_eviction {accepted_units_by_lane:[plan,cache],overflow}. Existing historical scope/checkpoint/pair fields remain present.

The auditor qualifies ordinary captures before using them: restore only the explicitly named preceding schema, remove exactly declared additions and two provenance fields, then require ENTIRE body equality to the immutable164f body. It separately requires each real ordinary paired.new observation equals frozen paired.new. Point ordinary receipt canonical work is therefore an independent actual constructor observation, not an inferred residual or the older embedded pair.

## Checks and accounting

All744 ordered fixture/index identities, row metadata, requests, member shapes, complete paired.new payloads, every PCM sample, typed errors, source events, work snapshots, cache/controller snapshots, input/setup and cleanup are recursively compared. Duplicate/missing/extra cases or operations fail closed. Every unchanged actual observation is fingerprinted after full comparison; all changed leaf values and changed complete outputs are retained in audit.json. Success payload/error changes fail unless an explicit injected-work row transitions within the narrowly named work-budget error family.

Before/read-injection work state remains exact. Teardown work cannot silently change after return drop. Provider-observed sound_context_frames differences are separately retained and accepted only as nonnegative increases with an actually acquired Point result. The auditor does not call this difference measured Point bytes.

Point full/prefix receipts are checked independently per plan/cache lane: accepted=canonical+additional+partial+host, complete/admitted/ordinary/failed call counts reconcile, ordinary additional0, correct ordinary/admitted modes, no nested constructor deltas, no invalid/overflow. Result create/drop/live/peak and consumer markers are checked separately. Ordinary mode intentionally has no admitted result marker. Native consumer markers show overlap with some live Point, not unique payload identity.

For each lane:
measured actual read difference =
(current Point accepted minus its host subset)
minus (qualified actual ordinary Point accepted minus its host subset)
plus each independent surrounding product/issuer receipt delta
plus explicit global accepted host-eviction delta ONCE.

Surrounding receipts are retained fade, retained owners, raw domain, and Original flattened/processing/policy/fade. Their native constructor scopes are synchronous and disjoint in current sources; Original issuer_work is separately outside those constructor scopes. Host subsets are removed from every product before global host is counted. All surrounding receipt differences, including full/prefix transitions, remain in report. Nested constructor flags/depths fail closed before any inclusive fee sum.

Injected-prior-work rows are separate. Their independently measured components and signed unreconciled difference are retained without assigning any residual to Point. They do not establish an additive fee identity. Noninjected rows require exact independent reconciliation. A report pass may include explicitly counted injected unreconciled lanes; the report says so. A changed cancellation/nonbudget/output/provider/cache/cleanup semantic never passes via this exception.

Ordinary/admitted Main/scoped bodies must each equal after removing ONLY variant/source_sha256. Neither work, nested Bound fields, caps, errors, nor observations are normalized.

The auditor validates body-level capture provenance format and content hashes. Parent's guarded build/capture source/binary/environment proof receipts remain separate authority for how those bodies were produced; this script does not claim to recreate execution provenance from body text.

## Invocation after parent real captures

python3 audit_point_native.py \
  --admitted-main /tmp/REAL-admitted-main.json \
  --admitted-scoped /tmp/REAL-admitted-scoped.json \
  --ordinary-main /tmp/REAL-Point-only-ordinary-main.json \
  --ordinary-scoped /tmp/REAL-Point-only-ordinary-scoped.json \
  --frozen /Users/michael/Code/deadpan/crates/deadpan-audio/tests/fixtures/point-content-native-baseline-v1/snapshot.json \
  --out-dir /tmp/NEW-point-native-audit

Output audit.json/report.md use create-new writes. Exit0 means no unexpected discrepancy under the documented injected-row treatment; exit1 means complete observations/receipts/accounting contain findings; exit2 means malformed/missing schema or unqualified baseline, failing closed. All744 rows per scope remain auditable in audit.json.

## Preparation validation

Python parsing/py_compile passed. Pure comparator checks verified suffixes/missing members and bool-versus-int differences are not discarded, work-path filtering excludes setup/injection counters, and provider residency paths are exact. The actual pinned frozen164f bytes and all744 unique ordered identities were read and validated. No new capture was synthesized or expected body generated. Full audit execution waits for parent's four real guarded captures.

source-pins.json pins the immutable baseline, native-test v2 schema source, original raw auditor read as schema context, current trace/accounting sources, and this driver/README. The raw auditor was inspected, not executed or copied wholesale: its earlier baseline and residual limitations are deliberately not inherited.
