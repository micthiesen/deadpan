#!/usr/bin/env python3
"""Compare complete Point ordinary/admitted captures against frozen actual paired.new.
Only reads capture/source files. Writes create-new scratch audit evidence, never goldens.
"""
from __future__ import annotations
import argparse
import collections
import hashlib
import json
from pathlib import Path
from typing import Any

FROZEN_SHA = "164f9543d7db901b20a8d1a4d200a9853cd3a89e6fc0615aaf61f4ee2dee38c3"
CHECKPOINT = "af34e1e1143e9abc11f49b77ee49c602c116aac4"
OLD_SCHEMA = "raw-domain-native-admitted-v1"
SCHEMAS = {"ordinary": "point-content-native-ordinary-receipts-v1",
           "admitted": "point-content-native-admitted-v1"}
MODES = {"ordinary": "ordinary_query_and_manual_debit",
         "admitted": "admitted_query_forwarded_debit"}
ENVELOPE = {"variant", "source_sha256"}
ADDITIVE_TOP = {"preceding_raw_domain_schema", "published_point_content_checkpoint",
                "point_content_scope", "pre_point_content_frozen_sha256",
                "actual_point_content_mode"}
ADDITIVE_RECEIPTS = {"point_content", "point_content_host_eviction"}
POINT_LANE = {"constructor_calls", "ordinary_calls", "admitted_calls", "completed_queries",
              "failed_queries", "accepted_work", "canonical_units", "additional_units",
              "partial_work", "host_eviction_work", "result_spans"}
POINT_SCALARS = {"active_depth", "max_active_depth", "live_results", "peak_live_results",
                 "result_creations", "result_drops", "preflight_callbacks",
                 "numerical_callbacks", "span_callbacks", "nested", "invalid", "overflow"}
WORK = {"plan_work", "cache_plan_work"}
WORK_VIEWS = {"after_handle_drop", "after_renderer_drop",
              "read/after_return_drop", "read/after_scope_drop"}
MISSING = {"missing_json_member": True}

class AuditError(Exception):
    pass

def require(condition: bool, message: str) -> None:
    if not condition:
        raise AuditError(message)

def read(path: Path) -> Any:
    return json.loads(path.read_text())

def pin(path: Path) -> dict[str, Any]:
    raw = path.read_bytes()
    return {"path": str(path), "bytes": len(raw), "sha256": hashlib.sha256(raw).hexdigest()}

def canon(value: Any) -> bytes:
    return (json.dumps(value, sort_keys=True, separators=(",", ":")) + "\n").encode()

def diff(a: Any, b: Any, path: str = "") -> list[dict[str, Any]]:
    """Full recursive exact comparison; neither missing keys nor array suffixes disappear."""
    if type(a) is not type(b):
        return [{"path": path or "/", "current": a, "baseline": b}]
    if isinstance(a, dict):
        out = []
        for key in sorted(a.keys() | b.keys()):
            child = path + "/" + key.replace("~", "~0").replace("/", "~1")
            if key not in a or key not in b:
                out.append({"path": child, "current": a.get(key, MISSING),
                            "baseline": b.get(key, MISSING)})
            else:
                out.extend(diff(a[key], b[key], child))
        return out
    if isinstance(a, list):
        out = []
        if len(a) != len(b):
            out.append({"path": path + "/#length", "current": len(a), "baseline": len(b)})
        for i in range(max(len(a), len(b))):
            if i >= len(a) or i >= len(b):
                out.append({"path": path + "/" + str(i),
                            "current": a[i] if i < len(a) else MISSING,
                            "baseline": b[i] if i < len(b) else MISSING})
            else:
                out.extend(diff(a[i], b[i], path + "/" + str(i)))
        return out
    return [] if a == b else [{"path": path or "/", "current": a, "baseline": b}]

def rows(body: dict[str, Any]) -> dict[tuple[str, int], dict[str, Any]]:
    require(body.get("operations") == 744, "operations field must be exactly744")
    require(type(body.get("cases")) is list, "cases array required")
    result = {}
    seen_cases = set()
    for case in body["cases"]:
        require(set(case) == {"fixture", "operations"}, "case schema changed")
        name = case["fixture"]
        require(type(name) is str and name not in seen_cases, "duplicate/non-string fixture")
        seen_cases.add(name)
        require(type(case["operations"]) is list, "operations array required")
        for row in case["operations"]:
            require(set(row) == {"authored", "mode", "old_operation_index", "old_request", "paired"},
                    f"{name}: row schema changed")
            index = row["old_operation_index"]
            require(type(index) is int, f"{name}: integer operation index required")
            key = (name, index)
            require(key not in result, f"duplicate operation key {key}")
            require(type(row["paired"]) is dict and type(row["paired"].get("new")) is dict,
                    f"{key}: actual paired.new observation missing")
            result[key] = row
    require(len(result) == 744, f"actual unique row count {len(result)} !=744")
    return result

def check_capture_shape(body: dict[str, Any], frozen: dict[str, Any], lane: str) -> None:
    require(body.get("schema") == SCHEMAS[lane], f"{lane}: wrong capture schema")
    require(set(body) == set(frozen) | ADDITIVE_TOP | ENVELOPE,
            f"{lane}: undeclared top keys/additions/missing fields")
    require(body["preceding_raw_domain_schema"] == OLD_SCHEMA, "preceding schema wrong")
    require(body["published_point_content_checkpoint"] == CHECKPOINT, "Point checkpoint wrong")
    require(body["pre_point_content_frozen_sha256"] == FROZEN_SHA, "Point baseline pin wrong")
    require(body["actual_point_content_mode"] == MODES[lane], "wrong actual Point mode")
    require(type(body["point_content_scope"]) is str and bool(body["point_content_scope"]),
            "Point scope note absent")
    require(body["variant"] in {"main-inherited", "scoped-published"}, "capture variant invalid")
    require(type(body["source_sha256"]) is str and len(body["source_sha256"]) == 64
            and all(c in "0123456789abcdef" for c in body["source_sha256"]),
            "source manifest SHA invalid")
    baseline_rows = rows(frozen)
    for key, row in rows(body).items():
        baseline = baseline_rows.get(key)
        require(baseline is not None, f"{key}: unknown fixture/operation")
        require(set(row["paired"]) == set(baseline["paired"]), f"{key}: pair schema changed")
        require(set(row["paired"]["receipts"]) ==
                set(baseline["paired"]["receipts"]) | ADDITIVE_RECEIPTS,
                f"{key}: undeclared receipt fields/missing receipt")

def historical_body(body: dict[str, Any]) -> dict[str, Any]:
    """Remove declared additive evidence only, restoring explicitly named preceding schema."""
    value = json.loads(json.dumps(body))
    value["schema"] = value["preceding_raw_domain_schema"]
    for key in ADDITIVE_TOP | ENVELOPE:
        value.pop(key)
    for row in rows(value).values():
        for key in ADDITIVE_RECEIPTS:
            row["paired"]["receipts"].pop(key)
    return value

def stripped_envelope(body: dict[str, Any]) -> dict[str, Any]:
    return {key: value for key, value in body.items() if key not in ENVELOPE}

def counters(value: dict[str, Any], where: str) -> None:
    require(type(value) is dict, f"{where}: counter object missing")
    require(all(type(v) is int and v >= 0 for v in value.values()),
            f"{where}: noninteger/negative counter")

def point_receipt(receipt: dict[str, Any], mode: str, where: str) -> None:
    require(set(receipt) == {"plan", "cache"} | POINT_SCALARS,
            f"{where}: Point receipt exact schema mismatch")
    for flag in ("nested", "invalid", "overflow"):
        require(receipt[flag] is False, f"{where}: {flag} trace flag")
    scalars = {k: receipt[k] for k in POINT_SCALARS - {"nested", "invalid", "overflow"}}
    counters(scalars, where)
    successes = calls = 0
    for lane in ("plan", "cache"):
        value = receipt[lane]
        require(set(value) == POINT_LANE, f"{where}/{lane}: lane exact schema mismatch")
        counters(value, where + "/" + lane)
        completed, ordinary, failed = (value[k] for k in
                                      ("completed_queries", "ordinary_calls", "failed_queries"))
        require(value["constructor_calls"] == completed + ordinary + failed,
                f"{where}/{lane}: full constructor/prefix count mismatch")
        require(value["admitted_calls"] == completed, f"{where}/{lane}: admitted count mismatch")
        require(value["accepted_work"] == sum(value[k] for k in
                ("canonical_units", "additional_units", "partial_work", "host_eviction_work")),
                f"{where}/{lane}: accepted prefix/full receipt sum mismatch")
        require(ordinary == 0 if mode == "admitted" else completed == 0,
                f"{where}/{lane}: wrong constructor mode")
        if mode == "ordinary":
            require(value["additional_units"] == 0, f"{where}/{lane}: ordinary additional work")
        successes += completed
        calls += value["constructor_calls"]
    require(receipt["active_depth"] == 0, f"{where}: live constructor scope")
    require(receipt["max_active_depth"] == int(calls > 0), f"{where}: nested constructor delta")
    require(receipt["live_results"] == 0, f"{where}: leaked result marker")
    require(receipt["result_creations"] == receipt["result_drops"] == successes,
            f"{where}: acquired/dropped admitted results disagree")
    require(receipt["peak_live_results"] <= successes, f"{where}: impossible lifetime peak")
    require(bool(receipt["peak_live_results"]) == bool(successes), f"{where}: absent lifetime peak")
    if mode == "ordinary":
        require(all(receipt[k] == 0 for k in ("live_results", "peak_live_results",
                    "result_creations", "result_drops", "preflight_callbacks",
                    "numerical_callbacks", "span_callbacks")),
                f"{where}: ordinary mode unexpectedly acquired admitted lifetime")

def product_receipts(receipts: dict[str, Any]) -> dict[str, dict[str, Any]]:
    return {"retained_fade": receipts["fade"], "retained_owners": receipts["owners"],
            "raw_domain": receipts["raw_domain"],
            **{"original_" + name: value for name, value in receipts["original_queries"].items()}}

def outside_receipt_checks(receipts: dict[str, Any], where: str) -> None:
    require(set(receipts["original_queries"]) == {"flattened", "processing", "policy", "fade"},
            f"{where}: Original product schema changed")
    for name, receipt in product_receipts(receipts).items():
        for flag in ("nested", "invalid", "overflow"):
            require(receipt.get(flag) is False, f"{where}/{name}: unsafe receipt flag {flag}")
        require(receipt.get("active_depth") == 0 and receipt.get("max_active_depth", 0) <= 1,
                f"{where}/{name}: inclusive/nested active constructor")
        for lane in ("plan", "cache"):
            value = receipt[lane]
            require(all(type(v) is int and v >= 0 for k, v in value.items()
                        if k != "kind_counts"), f"{where}/{name}/{lane}: bad counter")
            require(value["constructor_calls"] == value["completed_queries"] +
                    value["failed_queries"] + value.get("ordinary_calls", 0),
                    f"{where}/{name}/{lane}: call/prefix sum")
            require(value["accepted_work"] == sum(value.get(k, 0) for k in
                    ("canonical_units", "additional_units", "partial_work", "host_eviction_work")),
                    f"{where}/{name}/{lane}: accepted receipt sum")
        if name == "raw_domain":
            require(receipt["live_results"] == 0 and
                    receipt["result_creations"] == receipt["result_drops"],
                    f"{where}/raw_domain: lifetime cleanup")
            successful = sum(receipt[lane]["completed_queries"] +
                             receipt[lane]["ordinary_calls"] for lane in ("plan", "cache"))
            require(receipt["result_creations"] == successful,
                    f"{where}/raw_domain: result count differs from full receipts")
            require(bool(receipt["peak_live_results"]) == bool(successful)
                    and receipt["peak_live_results"] <= successful,
                    f"{where}/raw_domain: impossible lifetime peak")
            for lane in ("plan", "cache"):
                require(receipt[lane]["canonical_units"] == 0,
                        f"{where}/raw_domain: canonical work changed")
                kinds = receipt[lane]["kind_counts"]
                require(type(kinds) is list and len(kinds) == 3 and
                        all(type(v) is int and v >= 0 for v in kinds) and
                        sum(kinds) == receipt[lane]["completed_queries"] +
                        receipt[lane]["ordinary_calls"],
                        f"{where}/raw_domain: product counts differ from full receipts")

def global_host(receipts: dict[str, Any], lane: str) -> int:
    host = receipts["point_content_host_eviction"]
    require(set(host) == {"accepted_units_by_lane", "overflow"} and host["overflow"] is False,
            "explicit accepted global host receipt missing/overflow")
    units = host["accepted_units_by_lane"]
    require(type(units) is list and len(units) == 2
            and all(type(v) is int and v >= 0 for v in units), "bad explicit global host units")
    for receipt in product_receipts(receipts).values():
        if "all_host_eviction_work" in receipt:
            require(receipt["all_host_eviction_work"] == units,
                    "explicit global host units disagree with existing independent trace")
    return units[0 if lane == "plan" else 1]

def direct_work(receipt: dict[str, Any], lane: str) -> int:
    value = receipt[lane]
    return value["accepted_work"] - value["host_eviction_work"]

def outside_work(receipts: dict[str, Any], lane: str) -> dict[str, int]:
    # Native constructor scopes are synchronous/disjoint; issuer checks are outside
    # each Original constructor scope. Host subsets are excluded before global host.
    return {name: direct_work(value, lane) + value[lane].get("issuer_work", 0)
            for name, value in product_receipts(receipts).items()}

def read_delta(observation: dict[str, Any], lane: str) -> int:
    key = "plan_work" if lane == "plan" else "cache_plan_work"
    return observation["read"]["after_return_drop"][key] - observation["read"]["before"][key]

def work_path(path: str) -> bool:
    parts = path.strip("/").split("/")
    if parts[-1] not in WORK:
        return False
    parent = "/".join(parts[:-1])
    return parent in WORK_VIEWS or (len(parts) == 4 and parts[0] == "provider_events"
                                  and parts[2] == "work_before_provider_result")

def provider_memory_path(path: str) -> bool:
    parts = path.strip("/").split("/")
    return (len(parts) == 4 and parts[0] == "provider_events"
            and parts[2:] == ["work_before_provider_result", "sound_context_frames"])

def budget_error(output: dict[str, Any]) -> bool:
    if output.get("status") != "Error":
        return False
    value = output.get("error", {})
    if value.get("is_cancelled") is not False:
        return False
    debug = value.get("debug", "")
    if debug in {'Limit("plan work per read")', 'Limit("saved audio key work per read")'}:
        return True
    return (debug.startswith('Plan(AudioQueryLimit("') and debug.endswith('"))')
            and ("work" in debug or "binding resolution" in debug))

def classify(new: dict[str, Any], old: dict[str, Any]) -> str:
    if new == old:
        return "same_complete_" + ("success" if new.get("status") == "Ok" else "typed_error")
    if budget_error(new) and budget_error(old):
        return "changed_complete_work_budget_error"
    if new.get("status") == "Error" and old.get("status") == "Ok":
        return "new_refusal"
    if new.get("status") == "Ok" and old.get("status") == "Error":
        return "new_success"
    return "unexpected_complete_payload_or_error_change"

def audit_row(current: dict[str, Any], ordinary: dict[str, Any],
              frozen: dict[str, Any], key: tuple[str, int]) -> dict[str, Any]:
    issues = []
    context = str(key)
    for name in ("authored", "mode", "old_operation_index", "old_request"):
        require(current[name] == ordinary[name] == frozen[name], f"{context}: input metadata {name} changed")
    now, prior = current["paired"]["new"], frozen["paired"]["new"]
    require(ordinary["paired"]["new"] == prior, f"{context}: ordinary actual paired.new !=frozen")
    receipts, old_receipts = current["paired"]["receipts"], ordinary["paired"]["receipts"]
    point_receipt(receipts["point_content"], "admitted", context + "/admitted")
    point_receipt(old_receipts["point_content"], "ordinary", context + "/ordinary")
    outside_receipt_checks(receipts, context + "/admitted")
    outside_receipt_checks(old_receipts, context + "/ordinary")
    output, old_output = now["read"]["output"], prior["read"]["output"]
    classification = classify(output, old_output)
    tight = current["old_request"]["fault"] == "injected_prior_plan_work"
    if classification not in {"same_complete_success", "same_complete_typed_error"}:
        if not (tight and classification == "changed_complete_work_budget_error"):
            issues.append("unapproved output classification: " + classification)
    observed = diff(now, prior)
    semantic, work, memory = [], [], []
    for change in observed:
        path = change["path"]
        if path.startswith("/read/output/"):
            continue  # compared in full above, including every PCM/error/member.
        if work_path(path) and type(change["current"]) is int and type(change["baseline"]) is int:
            work.append(change)
        elif provider_memory_path(path):
            memory.append(change)
            if not (type(change["current"]) is int and type(change["baseline"]) is int
                    and change["current"] >= change["baseline"]
                    and receipts["point_content"]["result_creations"] > 0):
                issues.append("unexpected provider-observed metadata residency change: " + path)
        else:
            semantic.append(change)
    if semantic:
        issues.append("complete observation non-work state/provider/cache/cleanup changed")
    # Setup, teardown and every provider event are compared above, not merely output.
    accounting = {}
    for lane in ("plan", "cache"):
        measured = read_delta(now, lane) - read_delta(prior, lane)
        current_point = direct_work(receipts["point_content"], lane)
        old_point = direct_work(old_receipts["point_content"], lane)
        current_outside, old_outside = outside_work(receipts, lane), outside_work(old_receipts, lane)
        outside_deltas = {name: current_outside[name] - old_outside[name] for name in current_outside}
        host_delta = global_host(receipts, lane) - global_host(old_receipts, lane)
        independently_measured = current_point - old_point + sum(outside_deltas.values()) + host_delta
        accounting[lane] = {
            "current_read_delta": read_delta(now, lane),
            "frozen_actual_read_delta": read_delta(prior, lane),
            "measured_read_delta_difference": measured,
            "point_current_direct_accepted": current_point,
            "point_actual_ordinary_direct_accepted": old_point,
            "point_independent_delta": current_point - old_point,
            "outside_independent_deltas": outside_deltas,
            "global_host_delta_counted_once": host_delta,
            "independently_measured_sum": independently_measured,
            "reconciles_exactly": measured == independently_measured,
            "unattributed_signed_difference": measured - independently_measured,
            "injected_row_separate_no_residual_attribution": tight,
        }
        if not tight and measured != independently_measured:
            issues.append(lane + ": noninjected read difference not reconciled by independent receipts")
        work_key = "plan_work" if lane == "plan" else "cache_plan_work"
        for end_view in (now["read"]["after_scope_drop"], now["after_handle_drop"],
                         now["after_renderer_drop"]):
            if end_view[work_key] != now["read"]["after_return_drop"][work_key]:
                issues.append(lane + ": teardown changed accepted work after return drop")

    pair_context_differences = diff(
        {k: v for k, v in current["paired"].items() if k not in {"new", "receipts"}},
        {k: v for k, v in frozen["paired"].items() if k not in {"new", "receipts"}})
    for change in pair_context_differences:
        path = change["path"]
        allowed = (path in {"/comparison", "/accounting/new_read_delta/plan",
                            "/accounting/new_read_delta/cache",
                            "/accounting/host_evictions/new/0",
                            "/accounting/host_evictions/new/1"})
        if not allowed:
            issues.append("historical pair context unexpectedly changed: " + path)
    for lane in ("plan", "cache"):
        require(current["paired"]["accounting"]["new_read_delta"][lane] == read_delta(now, lane),
                context + ": existing pair current delta inconsistent with actual work")
    outside = diff(
        {k: v for k, v in receipts.items() if k not in ADDITIVE_RECEIPTS},
        {k: v for k, v in old_receipts.items() if k not in ADDITIVE_RECEIPTS})
    return {"fixture": key[0], "operation": key[1], "mode": current["mode"],
            "authored": current["authored"], "fault": current["old_request"]["fault"],
            "classification": classification, "issues": issues,
            "actual_frozen_observation_sha256": hashlib.sha256(canon(prior)).hexdigest(),
            "actual_current_observation_sha256": hashlib.sha256(canon(now)).hexdigest(),
            "complete_observation_differences": observed,
            "complete_output_differences": diff(output, old_output),
            "typed_outputs_if_changed": {"ordinary": old_output, "admitted": output}
                    if output != old_output else None,
            "point_ordinary_receipt": old_receipts["point_content"],
            "point_admitted_receipt": receipts["point_content"],
            "point_host_ordinary": old_receipts["point_content_host_eviction"],
            "point_host_admitted": receipts["point_content_host_eviction"],
            "outside_receipt_differences": outside,
            "historical_pair_context_differences": pair_context_differences,
            "work_accounting": accounting,
            "provider_residency_differences_not_claimed_as_point_bytes": memory,
            "injected_row_separate": tight}

def audit_scope(admitted_path: Path, ordinary_path: Path, frozen: dict[str, Any], scope: str) -> dict[str, Any]:
    admitted, ordinary = read(admitted_path), read(ordinary_path)
    check_capture_shape(admitted, frozen, "admitted")
    check_capture_shape(ordinary, frozen, "ordinary")
    require(historical_body(ordinary) == frozen,
            scope + ": entire narrow ordinary historical body !=pinned OLD after declared additions")
    baseline, new_rows, ordinary_rows = rows(frozen), rows(admitted), rows(ordinary)
    require(new_rows.keys() == ordinary_rows.keys() == baseline.keys(), scope + ": exact row-key coverage mismatch")
    # Preserve operation order as well as key identity, including all744 rows.
    require(list(new_rows) == list(ordinary_rows) == list(baseline), scope + ": row order changed")
    reports = [audit_row(new_rows[key], ordinary_rows[key], baseline[key], key) for key in baseline]
    return {"scope": scope, "pins": {"admitted": pin(admitted_path), "ordinary": pin(ordinary_path)},
            "operations": len(reports),
            "ordinary_actual_paired_new_and_entire_historical_body_equal_frozen": True,
            "classifications": dict(collections.Counter(r["classification"] for r in reports)),
            "issue_rows": sum(bool(r["issues"]) for r in reports),
            "injected_rows": sum(r["injected_row_separate"] for r in reports),
            "injected_unreconciled_lane_records": sum(not r["work_accounting"][lane]["reconciles_exactly"]
                for r in reports if r["injected_row_separate"] for lane in ("plan", "cache")),
            "rows": reports}

def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ("admitted-main", "admitted-scoped", "ordinary-main", "ordinary-scoped", "frozen", "out-dir"):
        parser.add_argument("--" + name, type=Path, required=True)
    args = parser.parse_args()
    require(args.out_dir.is_absolute() and args.out_dir.resolve().is_relative_to(Path("/tmp").resolve()),
            "audit output must be absolute scratch /tmp")
    args.out_dir.mkdir(parents=True, exist_ok=True)
    require(not (args.out_dir / "audit.json").exists() and not (args.out_dir / "report.md").exists(),
            "audit outputs must be create-new")
    frozen_pin = pin(args.frozen)
    require(frozen_pin["sha256"] == FROZEN_SHA, "immutable actual OLD baseline digest mismatch")
    frozen = read(args.frozen)
    require(frozen.get("schema") == OLD_SCHEMA and len(rows(frozen)) == 744,
            "immutable OLD schema/count mismatch")
    reports = [audit_scope(args.admitted_main, args.ordinary_main, frozen, "main"),
               audit_scope(args.admitted_scoped, args.ordinary_scoped, frozen, "scoped")]
    equality = {}
    for lane in ("ordinary", "admitted"):
        main_path, scoped_path = getattr(args, lane + "_main"), getattr(args, lane + "_scoped")
        equality[lane] = stripped_envelope(read(main_path)) == stripped_envelope(read(scoped_path))
    result = {"frozen_actual_baseline": frozen_pin, "auditor": pin(Path(__file__).resolve()),
              "baseline_authority": "every immutable operations[].paired.new; never embedded earlier retained reference",
              "main_scoped_equality_after_only_variant_source_sha256": equality,
              "scope_reports": reports,
              "pass": all(equality.values()) and not any(r["issue_rows"] for r in reports)}
    with (args.out_dir / "audit.json").open("x") as f:
        json.dump(result, f, indent=2, sort_keys=True);f.write("\n")
    lines = ["# Complete Point native audit", "",
             "Every actual observation is compared against frozen paired.new, using an independent narrow ordinary Point receipt capture whose entire historical body must first equal the frozen baseline.", "",
             "Point fees are the difference of actual constructor receipts. Separate surrounding product/issuer receipt deltas and one global host-eviction delta reconcile full-read changes. No residual is called Point work. Injected rows retain unreconciled differences explicitly and are not additive fee evidence.", "",
             "Liveness counters are checked separately from work. Provider residency differences are full observed values, not claimed as measured Point bytes. Consumer markers prove overlap with some live Point result, not unique query identity.", "",
             "No native executable ran. No oracle, cap, work weight, payload or nested work field was rewritten.", "",
             "Pass: " + str(result["pass"]), "",
             "Main/scoped equality: " + json.dumps(equality, sort_keys=True), ""]
    for report in reports:
        lines += [report["scope"] + ": " + json.dumps({k: v for k, v in report.items()
                  if k not in {"rows", "pins"}}, sort_keys=True), ""]
    lines += ["Full differences, typed changed outputs, all constructor full/prefix receipts, provider/cache/cleanup observations and separate injected rows are in audit.json.", ""]
    with (args.out_dir / "report.md").open("x") as f:f.write("\n".join(lines))
    print(json.dumps({k: v for k, v in result.items() if k != "scope_reports"}))
    print(json.dumps([{"scope":r["scope"],"operations":r["operations"],
                      "issue_rows":r["issue_rows"],"classifications":r["classifications"],
                      "injected_unreconciled_lane_records":r["injected_unreconciled_lane_records"]}
                     for r in reports]))
    return 0 if result["pass"] else 1

if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except (AuditError, KeyError, TypeError, ValueError) as error:
        print(json.dumps({"audit_failed_closed": str(error)}))
        raise SystemExit(2)
