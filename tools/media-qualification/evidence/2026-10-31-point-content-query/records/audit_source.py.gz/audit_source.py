from pathlib import Path
import hashlib,json
s=Path(__file__).resolve().parent
roots={'main':Path('/Users/michael/Code/deadpan'),'scoped':Path('/tmp/deadpan-query-groundwork-2026-10-26/scoped')}
owned=set(json.loads((s/'owned-code-paths.json').read_text()))
assert len(owned)==29
stage=json.loads((s/'staged-code-inventory.json').read_text());assert {p['path']for p in stage}==owned
sha=lambda b:hashlib.sha256(b).hexdigest()
preserved={}
for v,root in roots.items():
 initial=json.loads((s/f'{v}-initial-authority.json').read_text());n=0
 for name,h in initial.items():
  if name in owned:continue
  b=(root/name).read_bytes();assert len(b)==h['bytes']and sha(b)==h['sha256'],(v,name);n+=1
 preserved[v]=n
 build=json.loads((s/f'point-content-final-audio-{v}-build.json').read_text())
 assert build['exit_code']==0 and build['sources_unchanged']
 for path,h in build['source_after'].items():
  b=Path(path).read_bytes();assert len(b)==h['bytes']and sha(b)==h['sha256'],path
for entry in stage:
 p=entry['path'];b=(roots['scoped']/p).read_bytes()
 assert entry['mode']=='100644'and entry['stage']=='0'
 assert hashlib.sha1(f'blob {len(b)}\0'.encode()+b).hexdigest()==entry['sha'],p
 if p!='crates/deadpan-audio/src/shared_eq.rs':assert b==(roots['main']/p).read_bytes(),p
candidate=Path('/tmp/deadpan-point-content-native-tests-candidate-v2-2026-10-31')
name='crates/deadpan-audio/src/shared_eq.rs'
for v,variant in [('main','main-inherited'),('scoped','scoped-published')]:
 expected=(candidate/'after'/variant/name).read_text().replace('AudioSample(0)..AudioSample(4096),','AudioSample(0)..AudioSample(i64::from(MAX_OUTPUT_FRAMES)),')
 if v=='scoped':
  expected=expected.replace('        selected_family_count: 0,\n','').replace('        canonical_families: FamilyRegistry::default(),\n','')
 assert expected.encode()==(roots[v]/name).read_bytes(),v
pins=json.loads((s/'immutable-oracle-pins.json').read_text());assert len(pins)==26
for pin in pins:
 for root in roots.values():assert sha((root/pin['path']).read_bytes())==pin['sha256']
out={'preserved_unowned':preserved,'immutable_oracles':26,'owned_code_paths':29,'all_staged_code_blobs_equal_isolated_shipping':True,'all_other_owned_main_and_isolated_bytes_equal':True,'main_shared_eq_private_code_preserved_with_only_verified_test_helper':'variant-specific helper; isolated Graph omits Main-only fields; actual read bounded to MAX_OUTPUT_FRAMES256','source_counts':{v:len(json.loads((s/f'point-content-final-audio-{v}-build.json').read_text())['source_after'])for v in roots},'all_current_code_inputs_equal_final_build_sources':True,'shipping_source_patch_sha256':sha((s/'shipping-source.patch').read_bytes())}
(s/'preserved-source-and-oracle-audit.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
