# Complete Point native audit

Every actual observation is compared against frozen paired.new, using an independent narrow ordinary Point receipt capture whose entire historical body must first equal the frozen baseline.

Point fees are the difference of actual constructor receipts. Separate surrounding product/issuer receipt deltas and one global host-eviction delta reconcile full-read changes. No residual is called Point work. Injected rows retain unreconciled differences explicitly and are not additive fee evidence.

Liveness counters are checked separately from work. Provider residency differences are full observed values, not claimed as measured Point bytes. Consumer markers prove overlap with some live Point result, not unique query identity.

No native executable ran. No oracle, cap, work weight, payload or nested work field was rewritten.

Pass: True

Main/scoped equality: {"admitted": true, "ordinary": true}

main: {"classifications": {"same_complete_success": 264, "same_complete_typed_error": 480}, "injected_rows": 80, "injected_unreconciled_lane_records": 0, "issue_rows": 0, "operations": 744, "ordinary_actual_paired_new_and_entire_historical_body_equal_frozen": true, "scope": "main"}

scoped: {"classifications": {"same_complete_success": 264, "same_complete_typed_error": 480}, "injected_rows": 80, "injected_unreconciled_lane_records": 0, "issue_rows": 0, "operations": 744, "ordinary_actual_paired_new_and_entire_historical_body_equal_frozen": true, "scope": "scoped"}

Full differences, typed changed outputs, all constructor full/prefix receipts, provider/cache/cleanup observations and separate injected rows are in audit.json.
