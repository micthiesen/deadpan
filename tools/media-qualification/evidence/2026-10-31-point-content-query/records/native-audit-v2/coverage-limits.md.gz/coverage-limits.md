# Full744 native evidence limits

The auditor compares all744 complete observations per scope, but this does not mean744 Point constructors ran. Actual current capture has64 Point constructor rows per scope:56 plan and8 cache, all complete, no constructor failure/prefix work, one result span per success. Point accepted work832 versus qualified ordinary64 gives exact new additional768 total (672 plan,96 cache). No other product/global-host receipt changed. All80 injected-work rows per scope reconcile too; none establishes a nonzero failed Point prefix in this matrix.

All64 Point results remain live across preflight/numerical/span callbacks and produce64 source-callback residency increases per scope; counters balance64 creates/drops with peak1. Actual provider sound_context_frames increases are recorded as observed shared-ledger deltas, not byte-exact query allocation attribution.

The full744 fixture is primarily unchanged consumer behavior and scoped fee/lifetime evidence on its actual Point cases. Genuine native Stage/Bound nesting and Original eviction, and forced constructor refusal/cancellation/prefix coverage, need the parent's separate focused tests/receipts. The logical initial306 and public supplement53 remain separately frozen source/branch evidence. Do not enlarge this matrix's claim by treating absent native branches or zero prefix counters as exercised failures.
