from pathlib import Path
import json,sys,shutil,hashlib
s=Path(__file__).resolve().parent
label=sys.argv[1]
receipt=json.loads((s/(label+'.json')).read_text())
assert receipt['exit_code']==0 and receipt['sources_unchanged']
artifacts=[]
for line in (s/(label+'.stdout')).read_text().splitlines():
 try:a=json.loads(line)
 except ValueError:continue
 if a.get('reason')!='compiler-artifact' or not a.get('executable') or not a.get('profile',{}).get('test'):continue
 package=next((p for p in ['core','plan','audio','cli'] if ('deadpan-'+p+'#') in a['package_id']),None)
 if package:artifacts.append((package,a))
assert artifacts
keys=[(p,a['target']['name']) for p,a in artifacts]
assert len(keys)==len(set(keys))
pins=[]
for package,a in artifacts:
 dest=s/(label+'-'+package+'-'+a['target']['name'].replace('_','-'))
 assert not dest.exists()
 shutil.copyfile(a['executable'],dest);shutil.copymode(a['executable'],dest)
 b=dest.read_bytes()
 pins.append({'package':package,'name':a['target']['name'],'path':str(dest),'sha256':hashlib.sha256(b).hexdigest(),'bytes':len(b),'artifact':a})
(s/(label+'-pins.json')).write_text(json.dumps(pins,indent=2)+'\n')
print(json.dumps({'binaries':len(pins),'packages':{p:sum(row['package']==p for row in pins) for p in ['core','plan','audio']},'pins':str(s/(label+'-pins.json'))}))
