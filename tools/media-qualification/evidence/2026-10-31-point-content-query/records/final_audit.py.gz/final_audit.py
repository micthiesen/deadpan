from pathlib import Path
from datetime import datetime
import hashlib,json,re
s=Path(__file__).resolve().parent
sha=lambda b:hashlib.sha256(b).hexdigest()
negative={
'point-content-focused-audio-scoped-build':101,
'point-content-focused-native-main-tests':101,
'point-content-focused-plan-main-tests':101,
'point-content-focused-plan-scoped-tests':101,
'point-supplement-old-plan-main':101,
'point-supplement-old-plan-scoped':101,
}
receipts=[];native=[]
for p in sorted(s.glob('*.json')):
 r=json.loads(p.read_text())
 if not isinstance(r,dict)or'command'not in r or'started_at'not in r:continue
 assert r.get('exit_code')==negative.get(p.stem,0),(p.stem,r.get('exit_code'))
 assert r['sources_unchanged']and r['binaries_unchanged'],p.stem
 for name,h in r['streams'].items():
  b=Path(name).read_bytes();assert len(b)==h['bytes']and sha(b)==h['sha256'],name
 credit=r['exit_code']==0 and p.stem!='point-content-native-main-ordinary-v1'
 receipts.append({'label':p.stem,'exit_code':r['exit_code'],'seconds':r['seconds'],'sha256':sha(p.read_bytes()),'acceptance_credit':credit,'epoch':'named source snapshot in each retained receipt'})
 is_audio=r['environment'].get('CARGO_PROFILE_DEV_OPT_LEVEL')=='2'
 if is_audio and(r['binary_before']or'--doc'in r['command']):
  native.append((datetime.fromisoformat(r['started_at']),datetime.fromisoformat(r['finished_at']),p.stem))
  if r['binary_before']and'--list'not in r['command']:assert'--test-threads=1'in r['command'],p.stem
for a,b in zip(sorted(native),sorted(native)[1:]):assert a[1]<=b[0],('native overlap',a[2],b[2])
tests={}
for package,variants in [('plan',['main','scoped']),('audio',['main','scoped'])]:
 for v in variants:
  name=f'final-plan-{v}-coverage.json'if package=='plan'else'final-audio-main-scoped-coverage.json'
  rows=[row for row in json.loads((s/name).read_text())if row['variant']==v]
  assert len(rows)==(29 if package=='plan'else 21)
  build=f'point-content-final-{package}-{v}-build'
  pins=json.loads((s/(build+'-pins.json')).read_text())
  for row in rows:
   pin=next(p for p in pins if p['name']==row['target'])
   assert pin['sha256']==row['sha256']==sha(Path(pin['path']).read_bytes())
   r=json.loads(Path(row['receipt']).read_text())
   assert r['exit_code']==0 and r['sources_unchanged']and r['binaries_unchanged']
   found=re.findall(r'test result: ok\. (\d+) passed; 0 failed; (\d+) ignored;',Path(row['receipt']).with_suffix('.stdout').read_text())
   assert len(found)==1
   tests[Path(row['receipt']).stem]={'passed':int(found[0][0]),'ignored':int(found[0][1]),'skipped_filter':row.get('skipped_filter',[])}
coverage=json.loads((s/'verified-final-matrix-summary.json').read_text())
for label in ['point-content-strict-main-v1','point-content-strict-scoped-v1',
 'point-content-final-main-plan-doctests','point-content-final-scoped-plan-doctests',
 'point-content-final-main-audio-doctests','point-content-final-scoped-audio-doctests',
 'point-content-final-main-hygiene','point-content-final-scoped-hygiene']:
 assert json.loads((s/(label+'.json')).read_text())['exit_code']==0,label
source=json.loads((s/'preserved-source-and-oracle-audit.json').read_text())
assert source['preserved_unowned']=={'main':2839,'scoped':2511}and source['immutable_oracles']==26
for entry in json.loads((s/'staged-doc-inventory.json').read_text()):
 b=(Path('/Users/michael/Code/deadpan')/entry['path']).read_bytes()
 assert hashlib.sha1(f'blob {len(b)}\0'.encode()+b).hexdigest()==entry['sha']
native_audit=json.loads((s/'native-audit-v2/audit.json').read_text())
assert native_audit['pass']
for mode in ['ordinary','admitted']:
 for v in ['main','scoped']:
  label=f'point-content-native-{v}-{mode}-v2'
  proof=json.loads((s/(label+'-proof.json')).read_text())
  assert proof['source_binary_environment_guards']and proof['full_current_source_build']and proof['operations']==744
  assert proof['body_sha256']==sha((s/(label+'-body.json')).read_bytes())
out={'all_terminal':True,'native_audio_runs_serial':True,'native_invocations':len(native),
'native_intervals':[{'label':n,'start':a.isoformat(),'end':b.isoformat()}for a,b,n in sorted(native)],
'coverage':coverage,'tests':tests,'receipts':receipts,'source_audit':source,
'complete_native_audit_sha256':sha((s/'native-audit-v2/audit.json').read_bytes()),
'full_native_scope':'Each variant744 actual observations:264 unchanged complete successes and480 unchanged typed errors; actual Point constructors64, additional672plan+96cache, no outside receipt changes. Failed Point/native eviction coverage comes from focused tests, not this matrix.',
'current_new_native_canonical_sha256':'3d6338e4e4b0f5617647ab6e0fa4d80bf8882a87c87a55efe306002c3011dbdc',
'general_split':'Not rerun;7 inherited unfinished Main research tests filtered from stage suite. Preceding raw checkpoint retains3pass4fail. General sound-bearing Split remains disabled.',
'failed_wrapper_attempts':'Native ordinaryv1 actual execution passed but postvalidator mistook operations count for array; acceptance credit withheld. Syntax-only matrix/summary wrappers and formatting check failures retained; no expected bodies rewritten.',
'no_caps_weights_refunds_formats_or_requirement_gate_changes':True}
(s/'final-audit.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({k:v for k,v in out.items()if k not in ['tests','receipts','native_intervals']},indent=2))
