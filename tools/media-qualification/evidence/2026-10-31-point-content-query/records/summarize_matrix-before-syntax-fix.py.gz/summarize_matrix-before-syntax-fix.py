from pathlib import Path
import hashlib,json,re
s=Path(__file__).resolve().parent
out={}
rows=json.loads((s/'final-audio-main-scoped-coverage.json').read_text())
assert len(rows)==42
for v in ['main','scoped']:
 plan=json.loads((s/'verified-plan-matrix-summary.json').read_text())[v]
 out[v]={'plan':plan}
 total=ignored=0
 selected=[row for row in rows if row['variant']==v];assert len(selected)==21
 for row in selected:
  r=json.loads(Path(row['receipt']).read_text());assert r['exit_code']==0 and r['sources_unchanged']and r['binaries_unchanged']
  assert any(h['sha256']==row['sha256']for h in r['binary_before'].values())
  found=re.findall(r'test result: ok\. (\d+) passed; 0 failed; (\d+) ignored;',Path(row['receipt']).with_suffix('.stdout').read_text())
  assert len(found)==1
  p,i=map(int,found[0]);total+=p;ignored+=i
  if row['target']=='deadpan_audio':assert(p,i)==((447 if v=='main'else441),12)
  if row['skipped_filter']:assert v=='main'and row['target']=='stages'and row['skipped_filter']==['--skip','general_split_sound::']
 out[v]['audio']={'executables':21,'passed':total,'ignored':ignored}
assert out['main']['audio']['passed']==1028 and out['scoped']['audio']['passed']==1022
p=s/'verified-final-matrix-summary.json';assert not p.exists();p.write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out,indent=2))
