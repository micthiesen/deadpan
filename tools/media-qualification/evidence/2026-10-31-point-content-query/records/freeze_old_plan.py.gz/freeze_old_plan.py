from pathlib import Path
import json,hashlib
s=Path(__file__).resolve().parent
data=(s/'point-content-old-plan-canonical-initial.json').read_bytes();digest=hashlib.sha256(data).hexdigest()
assert len(data)==17636945 and digest=='b7d93aa5673d393b5b74e9e8eb152d510f66f60ab10e70d8e7b0c3cba8b8214e'
analysis=json.loads((s/'old-plan-initial-analysis.json').read_text());assert analysis['full_main_scoped_equality']and analysis['all_actual_delta_and_cleanup_checks_pass']
roots=[Path('/Users/michael/Code/deadpan'),Path('/tmp/deadpan-query-groundwork-2026-10-26/scoped')]
for v in ['main','scoped']:
 p=json.loads((s/f'point-content-old-plan-{v}-proof.json').read_text());assert p['fresh_ordinary_capture_before_query_production_changes']and p['source_binary_environment_guards']
folder='crates/deadpan-plan/tests/fixtures/point-content-query-baseline-v1'
readme="""# Ordinary Structural Point content queries: raw-operand witness v1

Independently captured in Main and the isolated shipping copy after published
Point borrow checkpoint af34e1e1143e9abc11f49b77ee49c602c116aac4, before public
Point content admission or native consumption changes. The only prior code
additions are default-off read-only observers and complete private serializers.
Both unoptimized binaries have complete source/binary/environment guards.
Whole bodies agree after removing only outer variant, source_sha256 and
published_point_borrow_checkpoint.

The unchanged actual raw driver retains77genuine Bounds and full setup corpora,
with18Point operands and59honest NotApplicable roots. The306representative
ordinary requests produce198Ok/108Error. All18fullgeometry queries succeed with
oneLeaf span and literalwork1. Ordinary capacities are4for162nonempty successes
and0for36empty successes. Stage/Bound and richer growth are not reached in this
raw-operand witness; a separate additive public-Point supplement is required.
No composite Point or private enum is forged to broaden these counts.

Each request holds a real admitted raw carrier. Ordinary results are fully
snapshotted, then dropped before the separate existing internal metered helper
runs on that same live issuer. Its144Ok/162Error results retain literal work,
canonical/additional units, exact spend/Layout/merge events and cumulative raw+
query ledger state. Helper success triples(canonical,additional,result.work)
are(0,5,5),(0,7,7),(1,11,12),(1,12,13),(1,15,16).
These are actual observations, not an ordinary/helper work normalization.

Every query/header/span/content owning field is retained through borrowed
snapshots. The ordinary call changes no admitted ledger state. Helper accepted
deltas equal actual canonical+additional; only raw leases remain after helper
drop and all result leases release on raw drop. Caller/Bound/Point state stays
exact. Harness JSON, ordinary unadmitted allocations and observer storage are
outside those ledger/peak claims. No allocator/RSS or whole-preparation result.

No expected body was regenerated after a query/native production change.
Source constructors, limits, errors, direct visitor provenance, full Some/None/
rejected setup outcomes and storage-only NotMeasured state remain literal.
"""
names=[folder+'/snapshot.json',folder+'/snapshot.sha256',folder+'/README.md']
for root in roots:
 d=root/folder;assert not d.exists();d.mkdir(parents=True)
 (d/'snapshot.json').write_bytes(data);(d/'snapshot.sha256').write_text(digest+'\n');(d/'README.md').write_text(readme)
p=s/'immutable-oracle-pins.json';pins=json.loads(p.read_text());assert len(pins)==24
pins.append({'path':names[0],'bytes':len(data),'sha256':digest});p.write_text(json.dumps(pins,indent=2)+'\n')
(s/'owned-plan-baseline-paths.json').write_text(json.dumps(names,indent=2)+'\n')
p=s/'owned-paths.json';owned=set(json.loads(p.read_text()));owned.update(names);p.write_text(json.dumps(sorted(owned),indent=2)+'\n')
for name in ['source-files.json','scoped-source-files.json','main-logic-source-files.json','scoped-logic-source-files.json']:
 p=s/name;paths=set(json.loads(p.read_text()));assert not paths.intersection(names);paths.update(names);p.write_text(json.dumps(sorted(paths),indent=2)+'\n')
(s/'old-plan-freeze.json').write_text(json.dumps({'canonical_bytes':len(data),'canonical_sha256':digest,'ordinary':analysis['ordinary_statuses'],'helper':analysis['helper_statuses'],'immutable_oracles':25,'before_query_production_changes':True},indent=2)+'\n')
print('Frozen initial306request witness; 25 immutable oracles, genuineLeaf-only gap explicit')
