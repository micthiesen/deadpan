# Native Point content tests and capture candidate v2

Scratch only, layered over the parent's integrated Plan API and native v3.
Actual Main/Scope sources were freshly read into before/ and are separately
pinned. No actual source edits, Cargo/typecheck, native executable, capture,
fixture/expected generation, or Git action was performed. Existing native
candidate v1/v2/v3 directories remain untouched.

## Owned paths

- New bound_reads/point_content_query_tests.rs: nine focused tests.
- retained_host_baseline.rs: one new test-module hook.
- retained_host_pairs.rs: opt-in Point receipt/global accepted-host receipt;
  Point legacy only around the existing Raw-only success pair regression.
- raw_domain_lifetime_tests.rs: Point legacy around the existing observed
  Raw-only paired test adapter.
- raw_domain_host_baseline.rs: explicitly opt-in Point capture flag, reset/
  snapshot/disable wiring, and ignored fresh NEW producer.
- shared_eq.rs: cfg(test)-only real Original WAV cache helper. It keeps its
  actual private Graph live across the test closure, then clears its real cache.

Production DSP, weights, limits and refund policy are unchanged. Test limits are
only reduced. No cache entry, provenance or lease is synthesized.

## Focused behavior

The Source test pairs actual Point-only legacy and admitted reads on the same
checked document/WAV, in plan/cache lanes, for success, provider failure and
provider cancellation. It retains full output bits/masks/dependencies/depth,
existing provider snapshots, full work/controller snapshots, Point snapshots
and independent global host receipts. Successful Point canonical work equals
the observed ordinary query work; native delta equals independent Point
additional receipts, never a gross ReadWork residual. Provider callbacks see the
actual admitted carrier live, and cleanup precedes returned PCM drop.

Other tests cover actual resident refusal before source I/O in both lanes;
plan-work accepted-prefix refusal; the actual early cache allowance refusal;
cleanup when a source callback disables the trace; real Preserve cache-hit WAV
dependency validation without another prepared stage; real Original cache
eviction reconciled to the global accepted-eviction receipt; and actual Point
foreign/depth/range/cancel/deadline priority before constructors/provider I/O.

The cache helper is needed because read_shared_input clears its Graph and
removes controller Original entries at return. A completed read cannot honestly
serve as a persistent Original-cache factory. The helper uses the existing
shared_original_input constructor and drops the returned Arc, leaving the
controller's real WAV cache evictable during the closure. It clears the Graph
afterwards. Point cleanup returns to the real caller key-metadata residency,
which the helper then releases.

## NEW capture

Exact suffix:

stages::bound_reads::retained_host_baseline::pairs::raw_domain_host_baseline::capture_new_point_content_native_v1

Environment keys:

- DEADPAN_POINT_HOST_OUTPUT: fresh create_new absolute /tmp file.
- DEADPAN_POINT_HOST_VARIANT: main-inherited or scoped-published.
- DEADPAN_POINT_HOST_SOURCE_SHA256: parent's complete actual source manifest.
- DEADPAN_POINT_HOST_PUBLISHED_CHECKPOINT:
  af34e1e1143e9abc11f49b77ee49c602c116aac4.

The parent must record all four environment values in the guarded execution
receipt. Top schema is point-content-native-admitted-v1. It pins the independently
frozen pre-Point native body SHA
164f9543d7db901b20a8d1a4d200a9853cd3a89e6fc0615aaf61f4ee2dee38c3
and states that actual paired.new is compared to that frozen body's paired.new.

Every preceding observation/embedded pair name remains. The preceding raw schema
is also retained as preceding_raw_domain_schema. Its historical
published_retained_fade_checkpoint remains
87ab6192e765a34dae9595139e10bd9010d6315e; the fresh Point checkpoint has its own
published_point_content_checkpoint field. Historical captures pass false and
receive neither new receipt key. Opt-in capture adds point_content plus
point_content_host_eviction to each receipt object without expanding the four
Original/two retained trace slots. Drop disables the trace even after source
failure/cancellation.

## Verification and remaining work

Rustfmt --edition 2024 --config skip_children=true parsed/formatted all 11 Rust
files; the same command with --check passed. finalize.py verifies each current
root equals its fresh before bytes, new files are absent in actual roots,
writes exact variant patches and independently applies every hunk in scratch,
then byte-compares the result to the candidate.

This is static-only evidence. The parent still owes compilation/strict lint,
actual WAV execution of all nine tests, frozen additive OLD native oracle
verification, guarded NEW capture and complete fieldwise OLD/NEW comparison.
No expected body is generated or updated here. The ninth focused test selects Source a from the exact current document of
cases::fixtures()[1] through public audio_definition/in_point_clock. An ordinary
standalone query, outside ReadWork and dropped before measurement, must contain
an actual AudioSignalContent::Bound. It then pairs real WAV reads in both lanes,
checks output equality, requires more than one live Point result at provider
callbacks, verifies result cleanup and nonoverlapping constructor scopes, and
reconciles native extra work to the independent Point fee receipt. This genuine
Bound assertion must pass on actual execution before coverage is claimed.
Focused tests do not claim exhaustive public Bound/large-span behavior.


## V2 additive ordinary receipt capture

The original test candidate is immutable at
/tmp/deadpan-point-content-native-tests-candidate-2026-10-31. This revision keeps
the same owned paths and refreshes all before pins from the current actual
roots. prepare_v2.py runs the copied base prepare.py then applies this revision;
finalize.py creates the complete v2 patches.

The additional exact ignored suffix is:

stages::bound_reads::retained_host_baseline::pairs::raw_domain_host_baseline::capture_point_legacy_receipts_native_v1

Both ignored Point producers call the same capture_point_content_native helper,
require the same four DEADPAN_POINT_HOST_* environment values, use the same
af34e1e1143e9abc11f49b77ee49c602c116aac4 checkpoint and fresh create_new output,
and enable the same bounded Point/global-host receipt hooks.

Only the ordinary receipt producer wraps the same captured_body_with_point in
point_content_request::with_legacy_point_content. Raw-domain, fade, owner and
other admissions remain active. It is an additive observation of the existing
ordinary query and its real manual debit, never an expected-body regeneration.

Exact envelope declarations for the external auditor:

- The top schema is point-content-native-ordinary-receipts-v1 for the narrow
  ordinary producer, or point-content-native-admitted-v1 for the admitted one.
- Added actual_point_content_mode is ordinary_query_and_manual_debit or
  admitted_query_forwarded_debit respectively.
- Other added top keys are preceding_raw_domain_schema,
  published_point_content_checkpoint, point_content_scope and
  pre_point_content_frozen_sha256. Their values are as documented above.
- Each paired.receipts has added point_content (the existing v3 scalar snapshot)
  and point_content_host_eviction:
  { accepted_units_by_lane: [plan, cache], overflow: boolean }.
  The latter comes directly from the existing accepted global eviction counter.
- Existing top scope, historical published_retained_fade_checkpoint and every
  preceding observation/pair field remain unchanged.
- Ordinary Point receipts have ordinary_calls/canonical_units/accepted_work
  from the actual manual debit, zero additional fees and zero admitted result
  lifetime markers; they are independent evidence for canonical reconciliation.

Before using ordinary receipts as fee evidence, the parent/auditor must compare
every actual ordinary paired.new field exactly to frozen164f paired.new and
compare the complete historical body after removing only the declared additive
receipt/top provenance keys (plus the established variant/source envelope).
Then the separate admitted body's extra work can be reconciled to the completed
Point fee and accepted global host deltas. No residual is labeled canonical.
