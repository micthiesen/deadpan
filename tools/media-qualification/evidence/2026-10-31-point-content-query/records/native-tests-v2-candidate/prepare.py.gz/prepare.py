from pathlib import Path
import hashlib,json,difflib,subprocess
s=Path(__file__).resolve().parent
roots={'main-inherited':Path('/Users/michael/Code/deadpan'),'scoped-published':Path('/tmp/deadpan-query-groundwork-2026-10-26/scoped')}
base='crates/deadpan-audio/src/bound_reads/'
paths=[base+n for n in ['retained_host_baseline.rs','retained_host_pairs.rs','raw_domain_host_baseline.rs','raw_domain_lifetime_tests.rs']]
for variant,root in roots.items():
 for name in paths:
  before=(root/name).read_text()
  p=s/'before'/variant/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(before)
  after=before
  if name.endswith('retained_host_baseline.rs'):
   anchor='#[path = "raw_domain_lifetime_tests.rs"]\nmod raw_domain_lifetime_tests;\n'
   assert after.count(anchor)==1
   after=after.replace(anchor,anchor+'\n#[path = "point_content_query_tests.rs"]\nmod point_content_query_tests;\n')
  elif name.endswith('retained_host_pairs.rs'):
   anchor='''    if let Some(raw) = raw_domain_host_baseline::receipt_if_capturing() {
        value["raw_domain"] = raw;
    }
'''
   assert after.count(anchor)==1
   after=after.replace(anchor,anchor+'''    if let Some(point) = raw_domain_host_baseline::point_receipt_if_capturing() {
        value["point_content"] = point;
        let (units, overflow) = original_request::flattened_work_trace::host_eviction_units();
        value["point_content_host_eviction"] = json!({
            "accepted_units_by_lane":units,"overflow":overflow,
        });
    }
''')
   anchor='            raw_domain_query_trace::reset();\n            let paired = pair(fixture, value, true);\n'
   assert after.count(anchor)==1
   after=after.replace(anchor,'''            raw_domain_query_trace::reset();
            let paired = crate::stages::point_content_request::with_legacy_point_content(|| {
                pair(fixture, value, true)
            });
''')
  elif name.endswith('raw_domain_lifetime_tests.rs'):
   anchor='''fn observed(
    fixture: &cases::Fixture,
    shared: bool,
    authored: bool,
    fault: Fault,
    legacy: bool,
) -> Value {
'''
   assert after.count(anchor)==1
   after=after.replace(anchor,anchor+'''    crate::stages::point_content_request::with_legacy_point_content(|| {
        observed_with_ordinary_point(fixture, shared, authored, fault, legacy)
    })
}
fn observed_with_ordinary_point(
    fixture: &cases::Fixture,
    shared: bool,
    authored: bool,
    fault: Fault,
    legacy: bool,
) -> Value {
''')
  elif name.endswith('raw_domain_host_baseline.rs'):
   anchor='    static CAPTURING: Cell<bool> = const { Cell::new(false) };\n'
   assert after.count(anchor)==1
   after=after.replace(anchor,anchor+'    static CAPTURING_POINT: Cell<bool> = const { Cell::new(false) };\n')
   anchor='''    fn new() -> Self {
        assert!(!CAPTURING.replace(true));
        Self
'''
   assert after.count(anchor)==1
   after=after.replace(anchor,'''    fn new(point_content: bool) -> Self {
        assert!(!CAPTURING.replace(true));
        assert!(!CAPTURING_POINT.replace(point_content));
        Self
''')
   anchor='''        raw_domain_query_trace::disable();
        CAPTURING.set(false);
'''
   assert after.count(anchor)==1
   after=after.replace(anchor,'''        raw_domain_query_trace::disable();
        if CAPTURING_POINT.replace(false) {
            crate::stages::point_content_query_trace::disable();
        }
        CAPTURING.set(false);
''')
   anchor='''    if CAPTURING.get() {
        raw_domain_query_trace::reset();
    }
'''
   assert after.count(anchor)==1
   after=after.replace(anchor,anchor+'''    if CAPTURING_POINT.get() {
        crate::stages::point_content_query_trace::reset();
    }
''')
   anchor='''fn captured_body(variant: &str, source: &str, checkpoint: &str) -> Value {
    let _capture = Capture::new();
    let mut value = current_body(variant, source);
'''
   assert after.count(anchor)==1
   after=after.replace(anchor,'''pub(super) fn point_receipt_if_capturing() -> Option<Value> {
    CAPTURING_POINT
        .get()
        .then(|| serde_json::to_value(crate::stages::point_content_query_trace::snapshot()).unwrap())
}

fn captured_body(variant: &str, source: &str, checkpoint: &str) -> Value {
    captured_body_with_point(variant, source, checkpoint, false)
}

fn captured_body_with_point(
    variant: &str,
    source: &str,
    checkpoint: &str,
    point_content: bool,
) -> Value {
    let _capture = Capture::new(point_content);
    let mut value = current_body(variant, source);
''')
   anchor='''#[path = "point_content_host_baseline.rs"]
mod point_content_host_baseline;
'''
   assert after.count(anchor)==1
   after=after.replace(anchor,'''#[test]
#[ignore = "manual admitted Point native capture; fresh /tmp output and pinned actual source required"]
fn capture_new_point_content_native_v1() {
    let output = std::env::var("DEADPAN_POINT_HOST_OUTPUT").expect("explicit fresh output");
    let path = Path::new(&output);
    assert!(path.is_absolute());
    assert!(
        path.parent().unwrap().canonicalize().unwrap()
            .starts_with(Path::new("/tmp").canonicalize().unwrap())
    );
    let variant = std::env::var("DEADPAN_POINT_HOST_VARIANT").expect("actual source variant");
    assert!(matches!(variant.as_str(), "main-inherited" | "scoped-published"));
    let source = std::env::var("DEADPAN_POINT_HOST_SOURCE_SHA256")
        .expect("actual complete source manifest");
    assert!(source.len() == 64 && source.bytes().all(|byte| byte.is_ascii_hexdigit()));
    let checkpoint = std::env::var("DEADPAN_POINT_HOST_PUBLISHED_CHECKPOINT")
        .expect("published preceding checkpoint");
    assert_eq!(checkpoint, "af34e1e1143e9abc11f49b77ee49c602c116aac4");
    let file = OpenOptions::new().create_new(true).write(true).open(path).unwrap();
    let mut value = captured_body_with_point(
        &variant, &source, "87ab6192e765a34dae9595139e10bd9010d6315e", true,
    );
    value["published_point_content_checkpoint"] = json!(checkpoint);
    value["preceding_raw_domain_schema"] = value["schema"].clone();
    value["schema"] = json!("point-content-native-admitted-v1");
    value["point_content_scope"] = json!(
        "Complete actual paired.new observations against point-content-native-baseline-v1 paired.new, with independent Point constructor and accepted global host-eviction receipts. Embedded preceding pair names and fields remain unchanged."
    );
    value["pre_point_content_frozen_sha256"] =
        json!("164f9543d7db901b20a8d1a4d200a9853cd3a89e6fc0615aaf61f4ee2dee38c3");
    let mut writer = std::io::BufWriter::new(file);
    serde_json::to_writer_pretty(&mut writer, &value).unwrap();
    writer.write_all(b"\\n").unwrap();
    writer.flush().unwrap();
    writer.get_ref().sync_all().unwrap();
}

'''+anchor)
  p=s/'after'/variant/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(after)
files=list((s/'after').rglob('*.rs'))+list((s/'new').rglob('*.rs'))
subprocess.run(['rustfmt','--edition','2024','--config','skip_children=true',*[str(p)for p in files]],check=True)
subprocess.run(['rustfmt','--edition','2024','--config','skip_children=true','--check',*[str(p)for p in files]],check=True)
print('Prepared four focused adapters per variant plus new native tests; rustfmt passed.')

helper = '''
#[cfg(test)]
pub(super) fn with_cached_original_for_point_test<P: AudioSourceProvider, R>(
    renderer: &mut StageAudio,
    provider: &mut P,
    control: WorkControl<'_>,
    action: impl FnOnce(&mut StageAudio, &mut P) -> R,
) -> R {
    let plan = Arc::clone(&renderer.plan);
    let mut graph = Graph {
        plan: &plan,
        nodes: Vec::new(),
        resident: 0,
        node_capacity_frames: 0,
        wet_filters: std::array::from_fn(|_| None),
        event_tiles: BTreeMap::new(),
        event_nodes: Default::default(),
        event_filters: BTreeMap::new(),
        voices: BTreeMap::new(),
        permission_families: BTreeMap::new(),
        selected_family_count: 0,
        canonical_families: FamilyRegistry::default(),
        sends: None,
        skip: Vec::new(),
        original_only: true,
        original_inputs: original_inputs::Cache::default(),
    };
    let cached = renderer
        .shared_original_input(
            provider,
            &mut graph,
            &Context::Root,
            AudioSample(0)..AudioSample(4096),
            control,
            0,
        )
        .unwrap();
    assert!(matches!(&cached, original_inputs::Read::Cached(_)));
    drop(cached);
    let result = action(renderer, provider);
    graph.original_inputs.clear(renderer);
    result
}
'''
for variant,root in roots.items():
 name='crates/deadpan-audio/src/shared_eq.rs'
 before=(root/name).read_text()
 p=s/'before'/variant/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(before)
 p=s/'after'/variant/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(before+helper)
files=[s/'after'/variant/'crates/deadpan-audio/src/shared_eq.rs' for variant in roots]
subprocess.run(['rustfmt','--edition','2024','--config','skip_children=true',*[str(p)for p in files]],check=True)
subprocess.run(['rustfmt','--edition','2024','--config','skip_children=true','--check',*[str(p)for p in files]],check=True)
