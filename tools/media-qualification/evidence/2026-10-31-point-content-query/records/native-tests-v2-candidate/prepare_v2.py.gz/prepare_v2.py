from pathlib import Path
import subprocess
s=Path(__file__).resolve().parent
subprocess.run(['python',str(s/'prepare.py')],check=True)
for variant in ['main-inherited','scoped-published']:
 p=s/'after'/variant/'crates/deadpan-audio/src/bound_reads/raw_domain_host_baseline.rs'
 text=p.read_text()
 anchor='''fn capture_new_point_content_native_v1() {
    let output = '''
 replacement='''fn capture_new_point_content_native_v1() {
    capture_point_content_native(false);
}

#[test]
#[ignore = "manual Point-only ordinary receipt capture; same admitted raw/fade/owner modes and fresh /tmp output"]
fn capture_point_legacy_receipts_native_v1() {
    capture_point_content_native(true);
}

fn capture_point_content_native(point_legacy: bool) {
    let output = '''
 assert text.count(anchor)==1
 text=text.replace(anchor,replacement)
 anchor='''    let mut value = captured_body_with_point(
        &variant,
        &source,
        "87ab6192e765a34dae9595139e10bd9010d6315e",
        true,
    );
'''
 replacement='''    let producer = || {
        captured_body_with_point(
            &variant,
            &source,
            "87ab6192e765a34dae9595139e10bd9010d6315e",
            true,
        )
    };
    let mut value = if point_legacy {
        crate::stages::point_content_request::with_legacy_point_content(producer)
    } else {
        producer()
    };
'''
 assert text.count(anchor)==1
 text=text.replace(anchor,replacement)
 anchor='''    value["schema"] = json!("point-content-native-admitted-v1");
'''
 replacement='''    value["schema"] = json!(if point_legacy {
        "point-content-native-ordinary-receipts-v1"
    } else {
        "point-content-native-admitted-v1"
    });
    value["actual_point_content_mode"] = json!(if point_legacy {
        "ordinary_query_and_manual_debit"
    } else {
        "admitted_query_forwarded_debit"
    });
'''
 assert text.count(anchor)==1
 text=text.replace(anchor,replacement)
 p.write_text(text)
files=list((s/'after').rglob('*.rs'))+list((s/'new').rglob('*.rs'))
subprocess.run(['rustfmt','--edition','2024','--config','skip_children=true',*[str(p)for p in files]],check=True)
subprocess.run(['rustfmt','--edition','2024','--config','skip_children=true','--check',*[str(p)for p in files]],check=True)
print('Prepared v2 same-body Point-only legacy receipt capture; fresh current before sources and rustfmt verified.')
