from pathlib import Path
import json,hashlib,os,subprocess,sys
s=Path(__file__).resolve().parent
prior=Path('/tmp/deadpan-point-signal-borrow-2026-10-31')
v=sys.argv[1];assert v in ['main','scoped']
root=Path('/Users/michael/Code/deadpan')if v=='main'else Path('/tmp/deadpan-query-groundwork-2026-10-26/scoped')
build=f'point-audio-{v}-build'
oldbuild=json.loads((prior/(build+'.json')).read_text());assert oldbuild['exit_code']==0 and oldbuild['sources_unchanged']
pin=next(p for p in json.loads((prior/(build+'-pins.json')).read_text())if p['name']=='deadpan_audio')
profile=pin['artifact']['profile'];assert profile['opt_level']=='2'and profile['debug_assertions']and profile['overflow_checks']
assert hashlib.sha256(Path(pin['path']).read_bytes()).hexdigest()==pin['sha256']
manifest={}
for absolute,h in oldbuild['source_after'].items():
 p=Path(absolute);b=p.read_bytes();actual={'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()};assert actual==h,absolute
 manifest[str(p.relative_to(root))]=actual
encoded=(json.dumps(manifest,sort_keys=True,separators=(',',':'))+'\n').encode();digest=hashlib.sha256(encoded).hexdigest()
label=f'point-content-old-native-{v}'
manifest_path=s/(label+'-source-manifest.json');assert not manifest_path.exists();manifest_path.write_bytes(encoded)
names=[l.removesuffix(': test')for l in(prior/f'point-{v}-audio-list.stdout').read_text().splitlines()if l.endswith('raw_domain_host_baseline::capture_new_raw_domain_native_v1: test')]
assert len(names)==1
out=s/(label+'-body.json');assert not out.exists()
tag='main-inherited'if v=='main'else'scoped-published'
env=os.environ.copy();env.update({'DEADPAN_RAW_HOST_OUTPUT':str(out),'DEADPAN_RAW_HOST_VARIANT':tag,'DEADPAN_RAW_HOST_SOURCE_SHA256':digest,'DEADPAN_RAW_HOST_PUBLISHED_CHECKPOINT':'87ab6192e765a34dae9595139e10bd9010d6315e'})
runner=s/('run_qualified.py'if v=='main'else'run_scoped_qualified.py')
subprocess.run(['python3',str(runner),'--binary',pin['path'],label,'--',pin['path'],'--ignored','--exact',names[0],'--nocapture','--test-threads=1'],env=env,check=True)
receipt=json.loads((s/(label+'.json')).read_text());assert receipt['exit_code']==0 and receipt['sources_unchanged']and receipt['binaries_unchanged']
body=json.loads(out.read_text());assert body.pop('variant')==tag and body.pop('source_sha256')==digest
canonical=(json.dumps(body,sort_keys=True,separators=(',',':'))+'\n').encode();sha=hashlib.sha256(canonical).hexdigest()
assert len(canonical)==27092643 and sha=='164f9543d7db901b20a8d1a4d200a9853cd3a89e6fc0615aaf61f4ee2dee38c3'
canonical_path=s/(label+'-canonical-body.json');assert not canonical_path.exists();canonical_path.write_bytes(canonical)
proof={'actual_published_point_checkpoint':(s/'base-revision.txt').read_text().strip(),'variant':v,'source_inputs':len(manifest),'source_manifest_sha256':digest,'binary_sha256':pin['sha256'],'binary_origin':'reused immutable last published Point unit executable; complete current named sources byte-equal its build source_after','fresh_native_execution_before_point_content_changes':True,'capture_driver_historical_schema_and_retained_checkpoint_preserved':True,'removed_only':['variant','source_sha256'],'canonical_bytes':len(canonical),'canonical_sha256':sha,'operations':744,'source_binary_guards':True,'exact_named_test':names[0]}
(s/(label+'-proof.json')).write_text(json.dumps(proof,indent=2)+'\n');print(json.dumps(proof))
