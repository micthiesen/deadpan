from pathlib import Path
import json,hashlib,os,subprocess,sys
s=Path(__file__).resolve().parent;v=sys.argv[1]
root=Path('/Users/michael/Code/deadpan')if v=='main'else Path('/tmp/deadpan-query-groundwork-2026-10-26/scoped')
build=f'point-supplement-old-plan-{v}-build';label=f'point-supplement-old-plan-{v}'
receipt=json.loads((s/(build+'.json')).read_text());assert receipt['exit_code']==0 and receipt['sources_unchanged']
pin=next(p for p in json.loads((s/(build+'-pins.json')).read_text())if p['name']=='deadpan_plan')
assert pin['artifact']['profile']['opt_level']=='0'
assert hashlib.sha256(Path(pin['path']).read_bytes()).hexdigest()==pin['sha256']
manifest={}
for absolute,h in receipt['source_after'].items():
 b=Path(absolute).read_bytes();actual={'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()};assert actual==h,absolute
 manifest[str(Path(absolute).relative_to(root))]=actual
data=(json.dumps(manifest,sort_keys=True,separators=(',',':'))+'\n').encode();digest=hashlib.sha256(data).hexdigest()
p=s/(label+'-source-manifest.json');assert not p.exists();p.write_bytes(data)
names=[l.removesuffix(': test')for l in(s/f'point-supplement-old-plan-{v}-list.stdout').read_text().splitlines()if l.endswith('supplement::capture_old_point_content_public_supplement_v1: test')]
assert len(names)==1
out=s/(label+'-body.json');assert not out.exists()
tag='main-inherited'if v=='main'else'scoped-published'
env=os.environ.copy();env.update({'DEADPAN_POINT_SUPPLEMENT_OUTPUT':str(out),'DEADPAN_POINT_SUPPLEMENT_VARIANT':tag,'DEADPAN_POINT_SUPPLEMENT_SOURCE_SHA256':digest,'DEADPAN_POINT_SUPPLEMENT_PUBLISHED_CHECKPOINT':(s/'base-revision.txt').read_text().strip()})
subprocess.run(['python3',str(s/'run_logic_target.py'),build,v,'plan','deadpan_plan',label,'--ignored','--exact',names[0],'--nocapture','--test-threads=1'],env=env,check=True)
run=json.loads((s/(label+'.json')).read_text());assert run['exit_code']==0 and run['sources_unchanged']and run['binaries_unchanged']
for key,value in env.items():
 if key.startswith('DEADPAN_POINT_SUPPLEMENT_'):assert run['environment'][key]==value,key
body=json.loads(out.read_text());assert body['variant']==tag and body['source_sha256']==digest and body['published_point_borrow_checkpoint']==(s/'base-revision.txt').read_text().strip()
assert body['schema']=='old-point-content-query-public-supplement-v1' and len(body['cases'])==4 and body['actual_request_count']<=60
proof={'variant':v,'source_inputs':len(manifest),'source_manifest_sha256':digest,'binary_sha256':pin['sha256'],'fresh_ordinary_capture_before_query_production_changes':True,'source_binary_environment_guards':True,'actual_request_count':body['actual_request_count'],'body_bytes':out.stat().st_size,'body_sha256':hashlib.sha256(out.read_bytes()).hexdigest(),'published_point_borrow_checkpoint':body['published_point_borrow_checkpoint'],'exact_named_test':names[0]}
(s/(label+'-proof.json')).write_text(json.dumps(proof,indent=2)+'\n');print(json.dumps(proof))
