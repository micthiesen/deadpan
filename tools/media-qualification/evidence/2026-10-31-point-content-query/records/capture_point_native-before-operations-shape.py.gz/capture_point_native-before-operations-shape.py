from pathlib import Path
import hashlib,json,os,subprocess,sys
s=Path(__file__).resolve().parent
v,mode,build,label=sys.argv[1:]
assert v in ['main','scoped']and mode in ['ordinary','admitted']
root=Path('/Users/michael/Code/deadpan')if v=='main'else Path('/tmp/deadpan-query-groundwork-2026-10-26/scoped')
receipt=json.loads((s/(build+'.json')).read_text())
assert receipt['exit_code']==0 and receipt['sources_unchanged']
pin=next(p for p in json.loads((s/(build+'-pins.json')).read_text())if p['name']=='deadpan_audio')
profile=pin['artifact']['profile']
assert profile['opt_level']=='2' and profile['debug_assertions']and profile['overflow_checks']
assert hashlib.sha256(Path(pin['path']).read_bytes()).hexdigest()==pin['sha256']
manifest={}
for absolute,h in receipt['source_after'].items():
 data=Path(absolute).read_bytes();actual={'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}
 assert actual==h,absolute
 manifest[str(Path(absolute).relative_to(root))]=actual
encoded=(json.dumps(manifest,sort_keys=True,separators=(',',':'))+'\n').encode()
digest=hashlib.sha256(encoded).hexdigest()
p=s/(label+'-source-manifest.json');assert not p.exists();p.write_bytes(encoded)
test='stages::bound_reads::retained_host_baseline::pairs::raw_domain_host_baseline::'+('capture_point_legacy_receipts_native_v1'if mode=='ordinary'else'capture_new_point_content_native_v1')
out=s/(label+'-body.json');assert not out.exists()
tag='main-inherited'if v=='main'else'scoped-published'
keys={'DEADPAN_POINT_HOST_OUTPUT':str(out),'DEADPAN_POINT_HOST_VARIANT':tag,'DEADPAN_POINT_HOST_SOURCE_SHA256':digest,'DEADPAN_POINT_HOST_PUBLISHED_CHECKPOINT':(s/'base-revision.txt').read_text().strip()}
env=os.environ.copy();env.update(keys)
subprocess.run(['python3',str(s/'run_target.py'),build,v,'audio','deadpan_audio',label,'--ignored','--exact',test,'--nocapture','--test-threads=1'],env=env,check=True)
r=json.loads((s/(label+'.json')).read_text())
assert r['exit_code']==0 and r['sources_unchanged']and r['binaries_unchanged']
for k,value in keys.items():assert r['environment'][k]==value,k
b=json.loads(out.read_text());assert b['variant']==tag and b['source_sha256']==digest
assert b['schema']==('point-content-native-ordinary-receipts-v1'if mode=='ordinary'else'point-content-native-admitted-v1')
assert len(b['operations'])==744
proof={'variant':v,'mode':mode,'fresh_native_execution':True,'full_current_source_build':True,'source_binary_environment_guards':True,'source_manifest_sha256':digest,'source_inputs':len(manifest),'binary_sha256':pin['sha256'],'exact_named_test':test,'operations':744,'body_bytes':out.stat().st_size,'body_sha256':hashlib.sha256(out.read_bytes()).hexdigest(),'base_checkpoint':keys['DEADPAN_POINT_HOST_PUBLISHED_CHECKPOINT']}
p=s/(label+'-proof.json');assert not p.exists();p.write_text(json.dumps(proof,indent=2)+'\n')
print(json.dumps(proof))
