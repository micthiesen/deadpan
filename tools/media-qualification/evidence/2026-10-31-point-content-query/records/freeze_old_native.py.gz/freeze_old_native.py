from pathlib import Path
import json,hashlib
s=Path(__file__).resolve().parent
roots=[Path('/Users/michael/Code/deadpan'),Path('/tmp/deadpan-query-groundwork-2026-10-26/scoped')]
bodies=[(s/f'point-content-old-native-{v}-canonical-body.json').read_bytes()for v in ['main','scoped']]
assert bodies[0]==bodies[1];data=bodies[0];digest=hashlib.sha256(data).hexdigest()
assert len(data)==27092643 and digest=='164f9543d7db901b20a8d1a4d200a9853cd3a89e6fc0615aaf61f4ee2dee38c3'
for v,root in zip(['main','scoped'],roots):
 proof=json.loads((s/f'point-content-old-native-{v}-proof.json').read_text());assert proof['fresh_native_execution_before_point_content_changes']and proof['source_binary_guards']
 initial=json.loads((s/(v+'-initial-authority.json')).read_text())
 for p,h in initial.items():
  b=(root/p).read_bytes();assert len(b)==h['bytes']and hashlib.sha256(b).hexdigest()==h['sha256'],(v,p)
folder='crates/deadpan-audio/tests/fixtures/point-content-native-baseline-v1'
readme="""# Structural Point content-query native baseline v1

Fresh native executions after published Point borrow checkpoint
af34e1e1143e9abc11f49b77ee49c602c116aac4, before any new Point content-query
public admission or native consumption change. The existing immutable last
published optimized Audio executables were reused only after verifying every
current named source input equals their actual build source_after.

Both Main and isolated runs replay all744literal real-WAV requests. Complete
bodies agree after removing only capture variant and source_sha256. Admitted
raw-domain/fade/owner carriers and the borrowed Point signal are active.
The fresh generated Point content query remains ordinary. All264current
successes and480complete typed errors, work/controller/cache/provider/receipt
state and cleanup are retained. Five WAV cases, four actual owning input origins
and both authored modes stay explicit.

The historical raw capture schema, published retained checkpoint and pre-raw
reference remain unchanged in the body. No field is renamed to pretend it is a
new schema. This unit's OLD current result is paired.new; the embedded pair.old
still names the older full legacy behavior. External proof names the actual
published Point checkpoint and source/binary identities. It is a fresh capture
whose canonical values also equal the preceding published Point result.

No expected body is generated after changing query/native production. The
separate logical witness must record full generated query/header/span/content
fields, work/lookup and actual errors; this native body does not replace it.
"""
names=[folder+'/snapshot.json',folder+'/snapshot.sha256',folder+'/README.md']
for root in roots:
 d=root/folder;assert not d.exists();d.mkdir(parents=True)
 (d/'snapshot.json').write_bytes(data);(d/'snapshot.sha256').write_text(digest+'\n');(d/'README.md').write_text(readme)
p=s/'immutable-oracle-pins.json';pins=json.loads(p.read_text());assert len(pins)==23
pins.append({'path':names[0],'bytes':len(data),'sha256':digest});p.write_text(json.dumps(pins,indent=2)+'\n')
(s/'owned-native-baseline-paths.json').write_text(json.dumps(names,indent=2)+'\n')
(s/'owned-paths.json').write_text(json.dumps(names,indent=2)+'\n')
for name in ['source-files.json','scoped-source-files.json','main-logic-source-files.json','scoped-logic-source-files.json']:
 p=s/name;paths=json.loads(p.read_text());assert not set(names)&set(paths);paths.extend(names);p.write_text(json.dumps(sorted(paths),indent=2)+'\n')
(s/'old-native-equality.json').write_text(json.dumps({'complete_main_scoped_equality':True,'removed_only':['variant','source_sha256'],'operations':744,'current_successes':264,'current_typed_errors':480,'canonical_bytes':len(data),'canonical_sha256':digest,'immutable_oracles':24,'before_point_content_query_production_changes':True},indent=2)+'\n')
print('Frozen native-before body in both roots; 24 immutable oracle bodies')
