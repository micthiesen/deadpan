from pathlib import Path
import subprocess
s=Path(__file__).resolve().parent
for v in ['main','scoped']:
 runner='run_qualified.py'if v=='main'else'run_scoped_qualified.py'
 subprocess.run(['python3',str(s/runner),f'point-content-final-{v}-audio-doctests','--','cargo','test','--locked','-p','deadpan-audio','--doc'],check=True)
