# Point content candidate seal review, v2

Read-only follow-up to immutable candidate v1. No candidate, source root, pin,
patch or prior note was overwritten. No Cargo, executable, native run, capture,
test, expected generation or Git operation was performed.

## Callback protocol

Actual Plan GuardedBound::map in audio_bound_query.rs:166 checks its Plan
_memory through budget.check_memory before mapping, then checks the resulting
_memory. Legacy calls the supplied closure directly. Metered constructs a
CoreAdmission adapter and calls Core AudioBindingValue::map_value.

Core map_value in audio_binding/admission.rs:257 calls validate before and after
the closure. validate reads policy.issuer and compares stored issuer and metered
mode. On mismatch CoreAdmission::issuer_mismatch constructs
PlanError::AudioMetadataIssuerMismatch via the existing error conversion. It
does not call outer spend, reserve, or merge. The identity closure performs only
an ownership move. Core value, lease, buffer, optional work receipt, metered flag
and charge_transferred flag are preserved literally.

Plan QueryBudget::check compares stored issuer with admission.issuer only.
check_memory invokes check and then compares the memory issuer. outer only maps
errors. Therefore README v1's no-new-spend/reserve/merge assertion is correct.
There is no zero-unit spend tail, no new cancellation callback and no new work
or receipt forwarding at the public seal.

For a successful public seal after structural_child_query returns:
1. capacity precheck: one issuer read.
2. GuardedBound map Plan precheck: one issuer read.
3. Core lane only: map_value prevalidate and postvalidate, one read each.
4. GuardedBound map Plan postcheck: one issuer read.
5. capacity postcheck: one issuer read.
6. final budget.check: one issuer read.

Thus five additional issuer reads for a Legacy final lane, seven for Metered.
Failures short-circuit. Mode comparison itself performs no runtime callback.
Identity map preserves SignalBuffer.query before capacity; GuardedBound retains
its payload before _memory; Core AudioBindingValue retains value before its
independent leases. All complete values and applicable guards remain owned
through every fallible validation.

## Coverage and accounting boundaries

The identity map does not invoke validate_composition. Core map_value only
checks issuer/mode; it preserves an outstanding work receipt or transferred
charge flag rather than rejecting it. It is not an independent proof that Core
work was accounted. On the actual helper path, bound_at_query takes each Core
receipt and budget.account_core validates issuer and forwarding mode before
folding its units locally. Collection zip calls validate_composition for Metered
inputs and therefore rejects pending receipts and transferred charges before
composition. The final identity map does not weaken those existing checks and
cannot mint, consume, clear or forward another receipt.

The public wrapper also verifies checked canonical+additional equals literal
query.work and maximum_work minus remaining. That verifies its counter
relationship, not the semantic correctness of the helper's debit decisions.
Independent frozen OLD helper callback/work witnesses remain necessary.
Scalar receipt getters may be read repeatedly, but do not issue callbacks or
consume work. Host code must respect was_forwarded and avoid a second debit.

The public carrier has private fields, no Clone and no consuming extraction.
The returned query reference cannot itself outlive the carrier. However,
AudioSignalQuery, AudioSignalSpan, AudioSignalContent, AudioStage and AudioBound
already implement Clone. A caller can explicitly clone a query or nested value
through the borrowed interface, allocate uncharged storage, drop the carrier,
then retain the clone. Existing &AudioSignalQuery API therefore cannot enforce
a universal prohibition on uncharged caller copies. This is an API/trusted-host
scope limit, not a new clone or detach method added by the candidate. Native v3
borrows query() for preflight and numerical consumption and does not clone it.

Trusted AudioSoundContextAdmission can also implement dishonest reservation or
merge behavior; the type cannot prove a lease's true external byte coverage.
Existing trusted-policy and independent Drop contracts remain unchanged.

## Native checkpoint

Read native candidate v3 scoped-published stages.rs:1215-1269. After the
constructor, forwarding decision and test result-lifetime marker, control.check
runs before policy construction. This preserves the old post-query cancellation
checkpoint previously reached through spend_plan_work. A second control.check
follows numerical consumption. Plan issuer checks do not replace those native
cancellation checks. The query enum remains in scope through both consumers.
Peer /root/point_content_native_candidate confirmed the same v3 placement.

## Focused tests needed at integration

1. Public false path with an admission whose issuer, spend, reserve and merge
   all panic. Compare complete query including nonserialized work and nested
   fields against independently frozen ordinary results. Cover empty range,
   genuine three-leaf spans, Stage, Bound, and exact/short maximum_work and
   maximum_spans errors. On every success canonical=ordinary.work, additional=0,
   total=ordinary.work and forwarded=false. Failures must not inspect admission.

2. Public true path over those same shapes against the independent OLD internal
   Structural helper using PointCeil and stops (true,true). Compare full logical
   fields, lookup and literal work; compare complete spend/reserve/merge event
   sequence and layouts, including genuine vector growth/copies and Core Bound
   receipts. No extra callback or invented Spend(0) tail. Verify canonical plus
   additional equals returned work and sum of forwarded successful spends;
   canonical matches OLD helper canonical, not an assumed ordinary work value.
   Nested Bound work/lattice fields remain literal.

3. Exact helper total allowance succeeds; one less fails at the independently
   frozen callback/location, with no callback after failure. Exact span limits
   and one less preserve helper behavior. A failed policy spend/reserve is
   propagated unchanged; already-issued leases drop and work is not refunded.

4. Inject cancellation and issuer rotation at every actual helper spend,
   reserve and merge callback for Leaf growth, Stage and Core Bound cases.
   Assert immediate existing rejection, no later helper callbacks, all retained
   construction charges released. For final-seal issuer validation, use an
   independently instrumented helper-end marker or an issuer-read trigger;
   exercise each post-helper check in the applicable five/seven-read sequence.
   A stable cancellation flag alone cannot fail an issuer-only Plan seal.

5. On successful true construction, all observed Plan payload, Core payload/
   buffer and SignalBuffer capacity charges remain live while query is borrowed
   and fall to baseline only after carrier drop. Failure at each issuer check
   also drops the complete result and all leases. Use allocation/liveness
   instrumentation to verify values drop before charges, including growth peak.

6. Native v3: cancellation made visible immediately after admitted constructor
   must stop before policy/preflight/provider/numerical callbacks via explicit
   control.check. Forwarded true must produce no manual positive debit;
   compatibility false must debit total once. Assert query lifetime remains
   live through preflight and numerical callbacks and releases on error paths.

7. Public API compile checks: method callable through crate exports, stored
   plan lifetime preserved, non-Clone lease accepted, returned query borrow
   cannot outlive carrier, carrier itself not Clone and no consuming extraction.
   Do not assert query payload is non-Clone; the existing API permits cloning.

All tests should consume independent ordinary/OLD helper witnesses or directly
assert protocol invariants. Do not generate expected values from candidate
output. This review does not establish type-checking or executed behavior.
