# Structural Point content public API candidate

Scratch-only candidate. No actual Main/isolated file was changed. No Cargo,
type check, native executable, source capture, expected/golden generation or Git
operation was performed. Parent must freeze and accept the independent complete
OLD logical witness before integrating any production query change.

## Proposed interface

AudioPointDomain::content_query_admitted(
    Range<SignalSample>, AudioQueryLimits, &mut A
) -> Result<AdmittedAudioPointContentQuery<'plan, A::Issuer, A::Lease>, A::Error>

The opaque carrier has query(), canonical_units(), additional_units(),
total_units() and was_forwarded(). query() returns &AudioSignalQuery<'plan>
with the stored plan lifetime explicit. No Clone, detach or public consuming
method is added.

Native worker /root/point_content_native_candidate was told these exact names.
The carrier and method live in existing audio_signal_processing_query.rs,
where the actual SignalValue/SignalBuffer representation already belongs.
audio_signal.rs publicly reexports the carrier and lib.rs exposes the existing
Plan wildcard path. No plan.rs change or visibility widening is needed.

## Actual ordinary and admitted algorithms

False mode calls the unchanged signal_ref().query(samples, limits), stores that
ordinary result in a separate private enum variant and reports its literal work
as canonical, zero additional, forwarded false. It does not construct a
QueryBudget/Memory/GuardedBound or read the admission issuer. Success/error,
lookup, limits and generated spans remain the ordinary algorithm's own result.

True mode starts one QueryBudget with the request's exact maximum_work and
empty lookup. It delegates to the existing structural_child_query on PointCeil
with stops (true,true). This is not a wrapper around an already constructed
ordinary query. It does not rebuild or normalize returned query.work or any
nested Bound/Stage field.

The returned existing GuardedBound<SignalBuffer> is retained directly.
SignalBuffer.capacity remains independent of its GuardedBound payload/Core/
Plan lanes. The public seal verifies total work against the literal helper
query.work and local remainder, checks capacity, uses the existing allocation-
free GuardedBound identity map to validate its lanes before/after the move, then
checks capacity and issuer again. This adds no spend, reserve or merge callback,
positive work, vector conversion, copy, allocation or receipt forwarding.
Existing constructor callback events should remain the helper's exact prefix;
only issuer inspections from final validation are added.

Both query data and capacity lease stay inside the complete value-before-memory
representation on success and every seal error. The carrier's private enum
contains the GuardedBound, whose payload owns SignalBuffer.query before its
capacity; GuardedBound's independent memory follows its value. The wrapper does
not retain a mutable admission policy borrow.

## Integration and limits

pins.json records fresh exact before/after hashes for the three existing files
in each actual root. patches/<variant>.patch is the complete narrow patch, and
before/, after/ and apply-check/ hold full copies. Finalize verifies live before
hashes and independently applies every diff hunk in scratch; resulting bytes
equal the formatted after files. Rustfmt with skip_children=true parsed and
formatted scratch files only.

No new source file is introduced. Use only the patch for its matching root
after rechecking all before hashes; rebase from fresh text if the parent changed
one first. Do not copy Main files over different isolated files.

No cap, existing work weight, refund, DSP, persisted format, policy admission,
generic Signal provider, Tape/Mix aggregation or complete preparation change is
proposed. AudioPointDomain's stored signal is Structural by its existing
construction invariant; the actual helper still rejects another provider.
False mode intentionally retains the compatibility constructor's semantics.

This candidate is not type-checked or executed. Parent owns compiler errors,
frozen ordinary/helper parity, exact/short limits, callback-prefix/cancellation/
issuer failure tests, actual lease/peak checks, native consumption and delivery.
No test expectation is derived from this candidate.
