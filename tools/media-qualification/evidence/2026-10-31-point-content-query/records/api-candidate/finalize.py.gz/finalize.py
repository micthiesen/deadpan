from pathlib import Path
import hashlib,json,difflib,re
s=Path(__file__).resolve().parent
roots={'main-inherited':Path('/Users/michael/Code/deadpan'),'scoped-published':Path('/tmp/deadpan-query-groundwork-2026-10-26/scoped')}
paths=['crates/deadpan-plan/src/audio_signal_processing_query.rs','crates/deadpan-plan/src/audio_signal.rs','crates/deadpan-plan/src/lib.rs']
pins={}
for variant,root in roots.items():
 patch='';rows={}
 for name in paths:
  before=(s/'before'/variant/name).read_bytes();after=(s/'after'/variant/name).read_bytes()
  assert(root/name).read_bytes()==before,(variant,name,'live source changed')
  rows[name]={'before_bytes':len(before),'before_sha256':hashlib.sha256(before).hexdigest(),'after_bytes':len(after),'after_sha256':hashlib.sha256(after).hexdigest()}
  patch+=''.join(difflib.unified_diff(before.decode().splitlines(True),after.decode().splitlines(True),fromfile='a/'+name,tofile='b/'+name))
 dest=s/'patches'/(variant+'.patch');dest.parent.mkdir(exist_ok=True);dest.write_text(patch)
 for block in re.split(r'(?m)^--- ',patch)[1:]:
  first,*rest=block.splitlines(True);assert rest[0].startswith('+++ ')
  name=rest[0].strip()[4:].removeprefix('b/')
  original=(s/'before'/variant/name).read_text().splitlines(True)
  output=[];at=0
  for group in re.split(r'(?m)^@@ ',''.join(rest[1:]))[1:]:
   header,*body=group.splitlines(True)
   match=re.match(r'-(\d+)(?:,\d+)? \+\d+(?:,\d+)? @@',header);assert match,header
   start=max(int(match[1])-1,0);assert at<=start
   output.extend(original[at:start]);at=start
   for line in body:
    if line.startswith(' '):
     assert original[at]==line[1:];output.append(line[1:]);at+=1
    elif line.startswith('-'):
     assert original[at]==line[1:];at+=1
    elif line.startswith('+'):output.append(line[1:])
    else:raise AssertionError((name,line))
  output.extend(original[at:]);actual=''.join(output).encode()
  assert actual==(s/'after'/variant/name).read_bytes(),name
  p=s/'apply-check'/variant/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(actual)
 pins[variant]={'files':rows,'patch':str(dest.relative_to(s)),'patch_sha256':hashlib.sha256(patch.encode()).hexdigest(),'exact_scratch_application_verified':True}
(s/'pins.json').write_text(json.dumps(pins,indent=2)+'\n')
print(json.dumps({'variants':2,'owned_existing_files_per_variant':3,'new_files':0,'roots_unchanged':True,'exact_scratch_patch_application':True}))
