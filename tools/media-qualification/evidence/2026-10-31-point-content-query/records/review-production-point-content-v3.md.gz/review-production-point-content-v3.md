# Independent integrated production Point content review

Read-only static review of actual Main Plan API, native v3 consumer and trace, after OLD initial/supplement witness capture. No builds, producer/native runs, source edits, cap/weight changes, refunds, or immutable fixture modifications. Parent owns active build and behavioral evidence. Source pins are in review-production-point-content-v3-source-pins.json.

Result: no material production correctness defect found in this bounded change. No required source change is proposed from static review. Native NEW full-body and adversarial admission/lifetime validation remain parent-owned; static review is not execution evidence.

## Plan API and helper parity

audio_signal_processing_query.rs: content_query_admitted false mode directly uses ordinary signal_ref().query with literal ordinary work, zero additional and forwarded=false; it does not read the issuer or invoke policy callbacks. Metered mode creates a fresh exact request allowance and lookup, invokes existing Structural child helper with PointCeil and stops(true,true), and retains the actual GuardedBound<SignalBuffer>.

The public seal preserves helper query.work and nested values. It checks canonical+additional against literal work and local remainder, validates independent capacity memory, then uses allocation-free GuardedBound identity map to validate outer/Core guard identity before and after ownership move. It adds no work or spend/reserve/merge callback. total_units' direct addition is safe under the constructor's checked private-field invariant. No ordinary query is built first in metered mode.

GuardedBound stores payload before its outer memory, and SignalBuffer stores query before capacity memory. Thus destruction releases query values and span Vec before the independent capacity lease and before outer payload/Core guards. All new seal failure paths retain the complete carrier until unwind; no detached payload or query clone was introduced.

## Native work, ownership and stop checkpoints

stages.rs read_point_domain_controlled preserves foreign-domain/depth/range checks and derives its end from the checked Point reference rebase. That rebase is one-to-one, so it matches old signal_start+frames. The mutable Admission borrow is short; returned query owns independent leases and remains alive through ordinary policy construction/debit, original shallow preflight, all numerical/nested callbacks and final control.check.

Native forwarded=true avoids the old post-construction query.work debit. The defensive forwarded=false path spends total once. All Plan callbacks use the same WorkControl plan/cache lane and deadline. Admission spend/reserve enforce cancellation/deadline during construction; v3's explicit control.check immediately after construction preserves the former post-constructor stop checkpoint without adding a work callback. Ordinary policy still spends its own literal work once. Existing query validation/error precedence remains separate from policy admission.

The numerical loop now borrows AudioSignalQuery and each span. The Point wrapper is not cloned, consumed or detached, and the actual raw-domain carrier enclosing a nested Point read remains alive in read_bound_at's borrowed match/transfer closure. Ordinary read_signal, per-mix voice and direct root sound callers borrow their own existing signal rather than introducing a new clone. Policy remains owned so its suppression Vec still transfers into output.

Public AudioSignalQuery is Clone; an external caller could clone through query() and outlive the admitted carrier. This is a cooperative public API limitation, not an actual copy performed by the reviewed native Point route. The carrier itself is opaque and has no Clone/detach API.

There ARE real existing downstream owning allocations outside this new product: Hold PreparedKey clones of definition/instance/gap/content; dependencies asset maps; Preserve descriptor clone at prepare_stage, followed by stage input_signal/output_signal ordinary construction; cache/preparation/PCM ownership. They already existed in the old numerical body. Keeping the admitted query borrowed does not admit those separate allocations. This unit therefore covers fresh Point content metadata plus its actual borrowed lifetime, not every consumer/preparation allocation.

## Literal nested Bound work

Successful OLD supplement pairs differ in query work/capacity and genuine Bound resolved.work/lattice.work. The public wrapper preserves those exact values. The metered bound_at_query consumes Core take_work receipt once using budget.account_core; it never calls canonical(value.work) on the metered branch. Only the separate legacy resolution branch uses value.work.

Native read_signal_queries Bound arm borrows bound then calls read_bound/read_bound_at. These do not read bound.work. raw_domain_admitted rebuilds from lattice origin/scale/grid/support and definition/instance/constraints; it neither reads nor copies resolved.work/lattice.work into a charge. raw_domain_query explicitly requires canonical==0 and reports only its fresh construction additional work. Subsequent raw queries recompute their own work from their own constructors.

One existing indirect production call self.bound().work() exists in AudioOwnerRetainedInput::fades_admitted's retained fade canonical formula. That input is not constructed or invoked from the new Point content→read_signal_queries→read_bound_at route. It should not be confused with a direct wrapper re-debit. Existing retained/input/Original traces may change for genuine new admitted products or fresh independently constructed Bound receipts; attribute them with independent scoped receipts, not a whole-read residual or by normalizing nested literals.

## Trace correctness and limits

point_content_query_trace is cfg(test), default-off, fixed scalar TLS. Constructor scope measures actual plan/cache accepted deltas and subtracts independently observed accepted host-eviction units before checking the exact success receipt. Failed scopes retain accepted prefixes and do not invent canonical/additional splits. Original ordinary lane includes its real manual work debit. Other-lane deltas, arithmetic failure and forwarded provenance mismatches set invalid/overflow.

ResultGuard is declared before the query, so its drop follows actual query cleanup. It remains balanced if tracing is disabled while a result is alive. reset asserts no active scope/results, and Drop still tracks acquired guards even after disable. Consumer markers show preflight/numerical/span callbacks while some admitted Point result is alive.

Two limits to preserve in evidence claims:
- Consumer markers are gated by any live Point result, not keyed to the exact query object. Nested ordinary work under a live Point can also increment them. They prove an admitted Point lifetime overlaps those callbacks; they do not uniquely attribute each callback to that Point payload.
- Constructor scopes are inclusive deltas. If constructors ever overlap/nest, aggregating both scopes would double-count the inner accepted work. The trace records nested/max_active_depth but does not automatically exclude it or set invalid for it. Present construction is synchronous Plan helper + host eviction, with no native Point constructor callback; assert nested=false/max_active_depth1 when using aggregate constructor fees. Nested result lifetimes during later preparation are legitimate and separate from nested constructor scopes.

No evidence currently supports >4 ordinary Point vector growth, ProjectedStage Structural output, or full recursive preparation admission. OLD supplement's genuine3 Leaf admitted accumulator replacement1→2→4 remains useful independent coverage.

## Review verification

Compared native v3 patch against actual changed bodies, traced shared helper/GuardedBound/Core move, WorkControl/Admission and raw Bound downstream paths, inspected every modified borrowed call site and the test trace. No execution or source mutation was performed. Parent's full744 NEW capture, scoped exact receipt reconciliation, failure/cleanup/cancellation tests and build/gates remain the runtime adjudication.
