from pathlib import Path
import json,hashlib,difflib
s=Path(__file__).resolve().parent
assert json.loads((s/'old-plan-supplement-freeze.json').read_text())['before_production_changes']
roots=[('main-inherited',Path('/Users/michael/Code/deadpan')),('scoped-published',Path('/tmp/deadpan-query-groundwork-2026-10-26/scoped'))]
patches=[];owned=set();added=set()
for candidate in ['deadpan-point-content-api-candidate-2026-10-31','deadpan-point-content-native-candidate-v3-2026-10-31']:
 c=Path('/tmp')/candidate
 pins=json.loads((c/'pins.json').read_text())
 for v,root in roots:
  row=pins[v];assert hashlib.sha256((c/row['patch']).read_bytes()).hexdigest()==row['patch_sha256']
  for name,h in row['files'].items():
   a=(root/name).read_bytes();b=(c/'after'/v/name).read_bytes()
   assert len(a)==h['before_bytes']and hashlib.sha256(a).hexdigest()==h['before_sha256'],(v,name)
   assert len(b)==h['after_bytes']and hashlib.sha256(b).hexdigest()==h['after_sha256']
   body=''.join('@@\n'if l.startswith('@@')else l for l in list(difflib.unified_diff(a.decode().splitlines(True),b.decode().splitlines(True)))[2:])
   patches.append('*** Begin Patch\n*** Update File: '+str(root/name)+'\n'+body+'*** End Patch')
   owned.add(name)
  for name,h in row.get('new_files',{}).items():
   b=(c/'new'/name).read_bytes();assert not(root/name).exists()
   assert len(b)==h['bytes']and hashlib.sha256(b).hexdigest()==h['sha256']
   patches.append('*** Begin Patch\n*** Add File: '+str(root/name)+'\n'+''.join('+'+l for l in b.decode().splitlines(True))+'*** End Patch')
   owned.add(name);added.add(name)
(s/'production-apply-patches.json').write_text(json.dumps(patches))
(s/'owned-production-paths.json').write_text(json.dumps(sorted(owned),indent=2)+'\n')
(s/'production-new-paths.json').write_text(json.dumps(sorted(added),indent=2)+'\n')
print('Validated all before/after pins, 8 existing files and 2 new files per root; no mutation')
