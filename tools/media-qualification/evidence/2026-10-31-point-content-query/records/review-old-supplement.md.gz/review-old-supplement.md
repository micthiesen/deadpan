# Independent OLD Point content supplement review

Read-only review of the integrated observer, analyzer, complete fresh v2 captures and proof receipts. No root edits, builds, captures or fixture changes.

Result: no material evidence blocker. Canonical supplement 1,137,739 bytes, SHA-256 9fdedc89939dc218bf8e5f01e020f312e81d7025328019c2c70cc00760b6a8ae. Both complete bodies equal it after removing exactly variant, source_sha256 and published_point_borrow_checkpoint. Proof manifest digests match their manifest bytes. Both capture receipts record exact source_before/source_after and binary_before/binary_after equality. Comparing initial producer build source receipts with supplement-v2 builds found only the first-producer module hook changed plus the new supplemental module; production query sources were unchanged.

Coverage: 53 requests; ordinary 30 Ok/23 Error, helper25 Ok/28 Error. Full queries genuinely return3 Leaf,1 Stage,1 Bound. Public Sequence rejection remains typed InvalidAudioRootPlacement. Growth reservations768,1536,3072 retain old buffers during replacement, actual peak4792 and returned live3368; result drop returns live0 without resetting peak.

Independent checks beyond analyzer: every request input equals its case setup before/during/after; isolated policy actually begins live0/peak0/accepted_work0; all247 reserve callbacks and694 spend callbacks accepted; accepted spend sum equals exact reported accepted_work; reservation live-byte increment equals Layout.size, peak equals max(previous peak,new live), and every lease has the same issuer; peak survives result drop, which restores live0.

Successful ordinary/helper pairs differ only in query work, span_capacity, and Bound nested resolved.work/lattice.work. Five ordinary successes become helper work-limit errors at low ordinary-derived allowances; complete bodies retain both outputs. Captured Bound/full_one_below_returned_work preserves actual Document LimitExceeded with message frozen projection work exhausted.

Analyzer blind spots, with no contradictory capture found:
- It does not compare successful lane semantics. Independent recursive comparison above found only the expected literal accounting/capacity differences, without normalizing or rewriting either body.
- Growth overlap assertions use lower bounds rather than exact reservation ledger deltas. Independent event checks above verify actual deltas, peak and issuer.
- Request set has ordinary-derived work thresholds, not isolated helper exact-total/one-below thresholds. These belong in new admission verification and should not be falsely claimed from this OLD witness.
- No refusal/cancellation/foreign-issuer injection, >4 ordinary Point vector growth or ProjectedStage coverage. Public placement restrictions and Structural return branches explain those truthful limits.
- The fresh isolated helper policy excludes unadmitted public input storage, ordinary query storage and JSON/harness allocations. This is requested Layout accounting, not allocator/RSS evidence. Initial306 remains separate shared raw-carrier lifetime evidence.

Source/note provenance: review-old-supplement-source-pins.json records SHA-256/bytes of analyzed scripts, receipts, canonical body and actual observer sources at review. review-old-supplement-note-pin.json pins this note and the pin manifest. These pins are new scratch review evidence, not expected-body generation.
