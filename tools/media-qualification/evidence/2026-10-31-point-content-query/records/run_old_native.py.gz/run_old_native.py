from pathlib import Path
import subprocess
s=Path(__file__).resolve().parent
for v in ['scoped','main']:
 subprocess.run(['python3',str(s/'capture_old_native.py'),v],check=True)
