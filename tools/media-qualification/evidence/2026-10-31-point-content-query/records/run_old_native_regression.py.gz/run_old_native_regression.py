from pathlib import Path
import subprocess
s=Path(__file__).resolve().parent
for v in ['scoped','main']:
 build=f'point-content-old-audio-{v}-build'
 subprocess.run(['python3',str(s/'run_target.py'),build,v,'audio','deadpan_audio',f'point-content-old-native-{v}-regression','complete_ordinary_point_content_native_body_matches_frozen_before','--test-threads=1'],check=True)
