# Fresh Structural Point content-query admission

Base is the published Point borrow checkpoint. No production query/native
construction changes until both complete ordinary logical and native witnesses
are frozen and independently checked in Main and the isolated shipping copy.
Use actual owning raw-domain carriers and immutable Point operands; preserve
full query/span/header/content fields, literal work/lookup, genuine typed errors,
and separate ordinary versus existing internal admitted helper receipts.
The cached/stored Point signal is not a generated-query oracle.

Only the actual Structural Point content query and its native borrowed consumer
are in this unit. SignalSample policy, other Signal providers, Tape/Mix outer
aggregation, general Graph containers and full preparation remain open.
No cap, prior weight, refund, DSP, format or requirement/Gate status changes.
General sound-bearing Split stays disabled. Actual captures/builds/native tests
remain parent-owned and native executables serial across roots.
