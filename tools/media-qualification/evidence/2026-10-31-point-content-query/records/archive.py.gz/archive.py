from pathlib import Path
import gzip,hashlib,json
s=Path(__file__).resolve().parent
repo=Path('/Users/michael/Code/deadpan')
dest=repo/'tools/media-qualification/evidence/2026-10-31-point-content-query'
assert not dest.exists()
audit=json.loads((s/'final-audit.json').read_text());assert audit['all_terminal']and audit['native_audio_runs_serial']
prior=repo/'tools/media-qualification/evidence/2026-10-31-point-signal-borrow/inventory.json'
prior_sha='082247fafe2a7e833a9e3d6c083f7a98f032c736212d7bd0cfbc4fb57cc61671'
sha=lambda b:hashlib.sha256(b).hexdigest()
assert sha(prior.read_bytes())==prior_sha
allowed={'.rs','.json','.py','.md','.patch','.stdout','.stderr','.txt','.sha256'}
rows=[]
for p in sorted(s.rglob('*')):
 if not p.is_file()or p.suffix not in allowed or p.name=='published-evidence.json':continue
 rel=p.relative_to(s)
 assert not(p.name=='shared_eq.rs'and'main-inherited'in rel.parts),'private inherited Main source must stay outside archive'
 data=p.read_bytes()
 if p.suffix=='.json':
  obj=json.loads(data)
  if isinstance(obj,dict)and'command'in obj and'started_at'in obj:
   assert'exit_code'in obj and obj['sources_unchanged']and obj['binaries_unchanged']
 target=(dest/'records'/rel).with_name(rel.name+'.gz')
 target.parent.mkdir(parents=True,exist_ok=True)
 packed=gzip.compress(data,mtime=0);target.write_bytes(packed)
 rows.append({'path':str(target.relative_to(dest)),'bytes':len(packed),'sha256':sha(packed),'expanded_bytes':len(data),'expanded_sha256':sha(data)})
 if len(rows)%100==0:print('archived',len(rows),flush=True)
manifest={'schema_version':1,'base_revision':(s/'base-revision.txt').read_text().strip(),
'documentation_correction_revision':(s/'doc-correction-published-revision.txt').read_text().strip(),
'scope':'Fresh Structural Point content admission plus its borrowed native consumer, independently frozen complete before bodies and real lease/fee verification. No cap/old-weight/refund/DSP/format/requirement/Gate changes; full goal active.',
'prior_point_borrow_inventory':{'path':'../2026-10-31-point-signal-borrow/inventory.json','sha256':prior_sha},
'exclusions':'Executables and nontext files excluded. Full Main inherited shared_eq candidate snapshots excluded; exact hashes and narrow new test-helper patches retained, full isolated shipping source retained.26 immutable expected bodies remain exact. Complete NEW body is a measured result, never a replacement expected body. Historical native schema/checkpoints and embedded earlier pair fields stay truthful. Failed attempts retained without acceptance credit. Native61 invocations serial; general Split research not rerun,7 inherited unfinished cases explicitly filtered from Main stages. No whole-preparation or allocator/RSS claim.',
'files':rows}
p=dest/'inventory.json';p.write_text(json.dumps(manifest,indent=2)+'\n')
for row in rows:
 packed=(dest/row['path']).read_bytes();plain=gzip.decompress(packed)
 assert len(packed)==row['bytes']and sha(packed)==row['sha256']
 assert len(plain)==row['expanded_bytes']and sha(plain)==row['expanded_sha256']
out={'files':len(rows),'stored_bytes':sum(r['bytes']for r in rows),'expanded_bytes':sum(r['expanded_bytes']for r in rows),'inventory_sha256':sha(p.read_bytes())}
(s/'published-evidence.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out),flush=True)
