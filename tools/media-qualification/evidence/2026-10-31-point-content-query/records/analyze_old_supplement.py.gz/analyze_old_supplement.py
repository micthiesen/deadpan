from pathlib import Path
import json,hashlib,collections
s=Path(__file__).resolve().parent
b=[]
for v in ['main','scoped']:
 proof=json.loads((s/f'point-supplement-old-plan-{v}-v2-proof.json').read_text())
 assert proof['source_binary_environment_guards'] and proof['fresh_ordinary_capture_before_query_production_changes']
 d=json.loads((s/f'point-supplement-old-plan-{v}-v2-body.json').read_text())
 for k in ['variant','source_sha256','published_point_borrow_checkpoint']:d.pop(k)
 b.append(d)
assert b[0]==b[1]
body=b[0]
assert body['actual_request_count']==53
ordinary=collections.Counter();helper=collections.Counter();full=[];triples=set()
for c in body['cases']:
 assert c['document_before']==c['document_after']
 if c['setup']['status']!='PointConstructed':
  assert c['name']=='public-sequence-point-rejection'
  assert c['setup']['error']['variant']=='InvalidAudioRootPlacement'
  continue
 full.append({'name':c['name'],**c['setup']['actual_full_query_coverage']})
 for r in c['requests']:
  o=r['ordinary'];h=r['existing_internal_metered_helper_isolated_query_policy']
  assert o['query_policy_before']==o['query_policy_while_result_live']==o['query_policy_after_result_drop']
  assert r['input_before']==r['input_after']==o['input_while_result_live']==h['input_while_result_live']
  assert h['accepted_work']==h['canonical']+h['additional']
  assert h['local_before']['remaining']-h['local_after']['remaining']==h['accepted_work']
  assert h['ledger_after_result_drop']['live']==0
  ordinary[o['result']['result']]+=1;helper[h['result']['result']]+=1
  if h['result']['result']=='Ok':
   q=h['result']['query']
   assert q['work']==h['canonical']+h['additional']
   triples.add((h['canonical'],h['additional'],q['work']))
assert [x['content_counts']for x in full]==[{'Leaf':3},{'Stage':1},{'Bound':1}]
growth=body['cases'][0]['requests'][0]['existing_internal_metered_helper_isolated_query_policy']
layouts=[e for e in growth['events']if e['event']=='reserve'and e['layout']['align']==16]
assert [e['layout']['size']for e in layouts]==[768,1536,3072]
assert layouts[1]['before']['live']>=768 and layouts[2]['before']['live']>=1536
data=(json.dumps(body,sort_keys=True,separators=(',',':'))+'\n').encode()
p=s/'point-content-old-plan-canonical-supplement.json';assert not p.exists();p.write_bytes(data)
out={'full_main_scoped_equality':True,'removed_only':['variant','source_sha256','published_point_borrow_checkpoint'],'canonical_bytes':len(data),'canonical_sha256':hashlib.sha256(data).hexdigest(),'actual_request_count':53,'ordinary_statuses':dict(ordinary),'helper_statuses':dict(helper),'full_geometry':full,'work_triples':sorted(triples),'all_input_ledger_cleanup_checks_pass':True,'actual_growth_layout_sizes':[768,1536,3072],'growth_peak':growth['ledger_after_result_drop']['peak'],'growth_returned_live':growth['ledger_while_result_live']['live']}
(s/'old-plan-supplement-analysis.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out,indent=2))
