# Native helper and capture static review

Fresh source pins: source-pins.json, 12 paths per variant, 2026-10-31.
No source edits, builds, executable launches, capture or oracle changes.

Compared current sources to immutable native-tests candidate v2. Main
shared_eq.rs differs only by 4096 -> i64::from(MAX_OUTPUT_FRAMES) in the test-only
real cache helper. Scope differs only by that range plus deleting the two
Main-only Graph initializers selected_family_count/canonical_families.
These fixes use the real native request bound and each actual Graph shape.

Both variants' capture hooks, paired receipt hooks and nine-test module match
the candidate byte for byte. The NEW and Point-only ordinary producer share
one helper; only ordinary wraps the existing body in Point legacy. They preserve
all other active admissions and the historical full observation fields.
Independent global host work is read from the accepted eviction counter.
No further variant-specific source assumptions were found in these reviewed
hooks. Runtime outcomes belong to the parent's execution evidence.

Current actual hashes:
- Main shared_eq: 0780f76f2139484698bfb15164265adf1936aa2a5ed141536d48f88184a9e32d
- Scope shared_eq: dc8d5e675bf73fa29529ac37dd459d806625d37c1d9dfddbc22f5aedcfd39274
- Both capture: b59a54e28cc4d1583e000af74e0c6aa44064c322b7438c1de3217c82f10fe92d
- Both pairs: ecb46af364fcc4f9e34adb1d56a675482079d409483ab29da5f236be9a7136e0
- Both nine tests: df9c7a5ca6df3142f1567617c56327c7116d0389372d5970f591147129033c83
