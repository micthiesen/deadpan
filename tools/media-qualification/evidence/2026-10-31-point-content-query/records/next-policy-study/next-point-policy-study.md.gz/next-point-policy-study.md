# Next boundary: fresh Structural Point policy

Read-only study, 2026-10-31. No production/fixture edits, implementation candidate,
build, native executable or capture. This unit must wait until the current Point
content unit is published. Fresh Main/Scope hashes are in source-pins.json.
Ripwire's task-specific map was capped; direct source bodies below supplied the
evidence. All studied policy/native files match between variants except shared_eq.

The next narrow boundary is the actual Point domain's existing
signal_ref().policy(SignalSample range), not Root/Domain policy or arbitrary
AudioSignal providers. Reuse the admitted policy walk on that exact stored
Structural signal with PointCeil and source endpoints enabled. A dedicated
SignalSample carrier and an explicit native suppression-output handoff are
needed before implementation.

## Exact existing machinery

- [AudioSignal::policy](/Users/michael/Code/deadpan/crates/deadpan-plan/src/audio_policy.rs:136)
  calls policy_with_endpoints(..., true), then policy_on_grid with PointCeil.
  The ordinary PolicyWork result contains ordered contents, merged SignalSample
  suppressed ranges, lookup and work. policy_after_preserve passes false and
  is a different operation.
- The existing admitted [signal_policy](/Users/michael/Code/deadpan/crates/deadpan-plan/src/audio_policy_query.rs:523)
  already accepts an explicit boundary rule, a borrowed AudioSignal, range,
  State, one QueryBudget, depth and endpoints. It uses structural_child_query
  first with stops (false,false), and a separate bindings walk with
  (false,true). These are not the content query's (true,true) stops.
- [signal_current](/Users/michael/Code/deadpan/crates/deadpan-plan/src/audio_policy_query.rs:368)
  drains the guarded child result into the guarded global content inventory.
  Empty/range collections, capacity replacement and raw Bound recursion already
  use the same accepted-work/allocation protocol.
- [bound_policy](/Users/michael/Code/deadpan/crates/deadpan-plan/src/audio_policy_query.rs:673)
  admits actual raw domains. Its Point arm clones the signal under admission,
  recurses on PointCeil, offsets ranges back to reference labels, then performs
  the bound inverse mapping. The direct top-level Point policy should borrow
  its already stored signal; it must not invent that nested clone or offset.
- [finish](/Users/michael/Code/deadpan/crates/deadpan-plan/src/audio_policy_query.rs:829)
  merges ranges and constructs a sealed product, but hardcodes
  AudioPolicyQuery<AudioSample>, Range<AudioSample> storage and AudioSample
  labels. [AdmittedAudioPolicyQuery](/Users/michael/Code/deadpan/crates/deadpan-plan/src/audio_policy_query.rs:27)
  is likewise AudioSample-only. It exposes a borrowed query, canonical/additional,
  work and was_forwarded, retaining guarded payload and inventory capacity.
- Root audio_policy_admitted explicitly selects RoundEven; Domain
  policy_admitted/domain_query_with_processing use domain_policy_inner and may
  reuse a sealed Domain processing tape. None is an interchangeable Point API.
  Relabeling their AudioSample outputs would hide a different walk/grid/work.
- structural_child_query rejects non-Structural providers
  ([source](/Users/michael/Code/deadpan/crates/deadpan-plan/src/audio_signal_processing_query.rs:173)).
  Ordinary signal policy also supports a source_voice_hold_carrier branch,
  which the admitted closed Structural walk does not implement. Keep the
  prospective public boundary on AudioPointDomain; do not broaden it to every
  Signal/Tape/Mix/voice policy query.

## Required interface and native ownership

A narrow AudioPointDomain method should accept the same Range<SignalSample>,
fresh AudioQueryLimits and mutable admission and return an opaque sealed
SignalSample policy product. Its borrowed query must be
&AudioPolicyQuery<SignalSample>; receipts need canonical_units,
additional_units, total/work and was_forwarded. The carrier owns both payload
and vector-capacity leases and permits no unmetered clone/detach. There is no
Plan borrow in AudioPolicyQuery itself, so a plan lifetime is not automatically
necessary. Getter issuer bounds must match GuardedBound's Copy + Eq requirement.

A sibling label-specific finalizer/carrier can reuse the existing internal
walk; genericizing the existing finalizer would require proving existing
Root/Domain callback, byte-layout, work and lifetime traces unchanged. Never
construct a Root/Domain product and convert its grid. Decide and freeze the
false-mode protocol explicitly: existing policy ordinary() reads issuer;
current Point content false mode performs no issuer read. These are different
existing contracts, not a reason to silently normalize either. QueryBudget
check/check_memory compare issuer only and do not add Spend(0).

At [read_point_domain_controlled](/Users/michael/Code/deadpan/crates/deadpan-audio/src/stages.rs:1188)
the current content carrier must remain live while a short Admission(self,
control) constructs the fresh policy. Do not bill already-forwarded work again.
Preserve the native cancellation/deadline checkpoint currently provided by
spend_plan_work(policy.work) after a successful ordinary policy, before preflight.
Keep both carriers through shallow preflight, numerical reads, nested providers,
suppression application and the final check.

The shared [preflight_signal_queries](/Users/michael/Code/deadpan/crates/deadpan-audio/src/stages.rs:2880)
already borrows policy. The numerical [read_signal_queries](/Users/michael/Code/deadpan/crates/deadpan-audio/src/stages.rs:2907)
still takes policy by value. It borrows suppressed ranges during application,
then moves policy.suppressed into merged_suppression and returns that owned Vec.
Simply changing its argument to a borrowed query leaves a real output-ownership
problem. Do not fix it with an unadmitted clone or by moving a guarded Vec out
and dropping its lease. Define a sealed, consuming final handoff from policy
metadata into the existing bounded SignalBlock output, with explicit accounting
ownership and cleanup before public PCM publication. Alternatively retaining a
lease in output would require a wider lifetime/API change and is outside this
narrow study. All three ordinary Signal/Mix/root-sound consumers must retain
their current policy behavior.

## Independent OLD oracle and branch traps

Freeze the current ordinary policy and admitted-helper observations before any
new public wrapper/finalizer/consumer change. Keep the current admitted Point
content, raw, fade, owner and Original behavior active. Use a new narrow
Point-policy legacy flag, chained under historical wrappers where required;
do not reuse a broad legacy scope that changes another product's work.

Capture full results (suppressed, contents in actual order, lookup and work),
typed errors, actual private Structural operand/grid/placement/binding state
and source documents. Capture an independent same-signal helper protocol under
recording admission, including callbacks, allocations/capacities, issuer checks,
accepted prefixes and cleanup. Exercise:

1. Signed/fractional PointCeil placement and source-selection endpoints; true
   endpoints versus the intentionally different after-Preserve false path.
   Ordinary policy traverses Preserve rather than stopping at content spans.
2. No-binding and empty-sample returns after the current walk; binding second
   walk; dense/repeated bindings. Global contents are bounded by shared work,
   not maximum_spans; do not deduplicate or cap them by the wrong limit.
3. Actual Bound Empty/Root/Point arms, empty support, clipped-empty selection,
   signed origins, fractional steps, endpoint inverse ceil, offset ranges,
   nested Preserve endpoint disabling and explicit silent Holds. Keep complete
   masks even when the corresponding PCM happens to be zero.
4. Inventory/range capacity growth, replacement overlap, merge of overlapping
   and adjacent ranges, empty/discarded ranges, final typed-range allocation and
   nested clone/offset phases. Existing
   [Point policy trace](/Users/michael/Code/deadpan/crates/deadpan-plan/src/audio_policy_point_trace.rs:1)
   observes nested clone/offset only; it is not a top-level complete oracle.
5. Invalid limits/ranges, maximum-span and work boundaries, recursive depth,
   overflow, refusal at every real spend/reserve, cancellation and rotating
   issuers. Record exact callback/error ordering. Ordinary policy failure has
   no successful manual native bill; admitted failure may retain a prefix.
   Never split a failed prefix into invented canonical/additional fees.
6. Native foreign/depth/range/cancel/deadline priority, residency refusal before
   I/O, source success/failure/cancel, genuine Stage/Bound providers, cache-hit
   validation and real accepted host eviction in plan/cache lanes. Policy
   construction happens while admitted content metadata is live, so residency
   pressure/cleanup must reflect that real overlap.

For native work reconciliation, first capture Point-policy-only legacy receipts
and prove its entire historical body/paired.new against the frozen ordinary
body. Only then compare admitted policy canonical work with that independent
ordinary receipt. Keep Point-content fees separate and preserve every existing
observation field. New bounded default-off policy receipts should include
canonical/additional/partial/scoped host work plus the independent global
accepted host receipt; do not expand existing four Original/two retained slots,
raise caps, normalize work, or call the gross ReadWork difference canonical.

## Current test-helper/capture review, static only

Fresh actual native sources were compared against immutable native tests v2.
Main shared_eq differs only by changing the test cache range from 4096 to
MAX_OUTPUT_FRAMES (currently the native bound is 256). Scope differs only by that
range and removing Main-only selected_family_count/canonical_families fields.
The helper now matches each variant's actual Graph and still calls the real
shared_original_input, keeps Graph/cache live across the closure, and clears it
afterwards. No similar variant-only assumption was found in the shared hooks.

Both variants' raw_domain_host_baseline, retained_host_pairs and the nine-test
source exactly match the candidate. The two ignored producers share the same
explicit env/path guard and body. Narrow ordinary wraps only Point legacy;
the admitted producer does not. Receipt keys are opt-in, the historical raw
checkpoint stays 87ab..., and the separate Point checkpoint is af34....

These are source observations, not an independent runtime claim. The parent
reported both variants' nine tests passed after the helper fixes; this agent
did not build or execute them and did not run any native capture.
