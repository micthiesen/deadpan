from pathlib import Path
import hashlib,json,difflib,shutil
s=Path(__file__).resolve().parent
c=Path('/tmp/deadpan-point-content-query-supplement-old-candidate-2026-10-31')
copy=s/'supplement-producer-candidate';assert not copy.exists();shutil.copytree(c,copy)
pins=json.loads((c/'pins.json').read_text());patches=[];owned=set()
for variant,root in [('main-inherited',Path('/Users/michael/Code/deadpan')),('scoped-published',Path('/tmp/deadpan-query-groundwork-2026-10-26/scoped'))]:
 row=pins[variant];assert isinstance(row['files'],dict)and len(row['files'])==1
 patch=(c/row['patch']).read_bytes();assert hashlib.sha256(patch).hexdigest()==row['patch_sha256']
 for name,h in row['files'].items():
  before=(root/name).read_bytes();after=(c/'after'/variant/name).read_bytes()
  assert len(before)==h['before_bytes']and hashlib.sha256(before).hexdigest()==h['before_sha256'],(variant,name)
  assert len(after)==h['after_bytes']and hashlib.sha256(after).hexdigest()==h['after_sha256']
  d=list(difflib.unified_diff(before.decode().splitlines(True),after.decode().splitlines(True)))
  body=''.join('@@\n'if line.startswith('@@')else line for line in d[2:])
  patches.append('*** Begin Patch\n*** Update File: '+str(root/name)+'\n'+body+'*** End Patch')
  owned.add(name)
 h=row['new_file'];name=h['path'];data=(c/'new'/name).read_bytes();assert not(root/name).exists()
 assert len(data)==h['bytes']and hashlib.sha256(data).hexdigest()==h['sha256']
 patches.append('*** Begin Patch\n*** Add File: '+str(root/name)+'\n'+''.join('+'+line for line in data.decode().splitlines(True))+'*** End Patch');owned.add(name)
(s/'supplement-apply-patches.json').write_text(json.dumps(patches,indent=2)+'\n')
(s/'owned-supplement-producer-paths.json').write_text(json.dumps(sorted(owned),indent=2)+'\n')
print('Validated every real before/after file and both patch pins; no source changed')
