from pathlib import Path
import json,hashlib,collections
s=Path(__file__).resolve().parent
b=[]
for v in ['main','scoped']:
 d=json.loads((s/f'point-content-old-plan-{v}-body.json').read_text())
 for key in ['variant','source_sha256','published_point_borrow_checkpoint']:d.pop(key)
 b.append(d)
assert b[0]==b[1]
data=(json.dumps(b[0],sort_keys=True,separators=(',',':'))+'\n').encode()
(s/'point-content-old-plan-canonical-initial.json').write_bytes(data)
ordinary=collections.Counter();helper=collections.Counter();kinds=collections.Counter();geometry=collections.Counter();full=[];helper_work=[];deltas=[];capacities=collections.Counter()
for operand in b[0]['operands']:
 if operand['kind']!='PointCeil':continue
 g=operand['geometry_setup']['geometry']['full_ordinary_result']
 geometry[g['result']]+=1
 if g['result']=='Ok':full.append({'context':operand['context'],'span_count':len(g['query']['spans']),'content_kinds':[x['content']['tag']for x in g['query']['spans']],'work':g['query']['work'],'capacity':g['query']['span_capacity']})
 for row in operand['requests']:
  o=row['ordinary']['result'];h=row['existing_internal_metered_helper_same_issuer']
  ordinary[o['result']]+=1;helper[h['result']['result']]+=1
  if o['result']=='Ok':
   capacities[o['query']['span_capacity']]+=1
   kinds.update(x['content']['tag']for x in o['query']['spans'])
  assert h['accepted_work_delta']==h['canonical']+h['additional']
  assert row['ordinary']['ledger_while_result_live']==row['ordinary']['ledger_after_result_drop']==row['raw']['while_result_live']
  assert h['ledger_after_result_drop']['live']==row['raw']['while_result_live']['live']
  assert row['raw']['issuer_after_all_results_drop']['live']==0
  if h['result']['result']=='Ok':helper_work.append([h['canonical'],h['additional'],h['result']['query']['work']])
out={'full_main_scoped_equality':True,'removed_only':['variant','source_sha256','published_point_borrow_checkpoint'],'canonical_bytes':len(data),'canonical_sha256':hashlib.sha256(data).hexdigest(),'ordinary_statuses':dict(ordinary),'helper_statuses':dict(helper),'geometry_statuses':dict(geometry),'ordinary_content_kind_counts':dict(kinds),'ordinary_success_capacities':dict(capacities),'full_geometry_queries':full,'helper_success_work_triples':sorted(set(tuple(x)for x in helper_work)),'all_actual_delta_and_cleanup_checks_pass':True}
(s/'old-plan-initial-analysis.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({k:v for k,v in out.items()if k not in ['full_geometry_queries','helper_success_work_triples']},indent=2))
print('full geometry',[(x['span_count'],x['content_kinds'],x['work'],x['capacity'])for x in full])
print('helper work',out['helper_success_work_triples'])
