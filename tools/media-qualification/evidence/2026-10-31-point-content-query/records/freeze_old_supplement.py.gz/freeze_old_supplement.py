from pathlib import Path
import json,hashlib
s=Path(__file__).resolve().parent
a=json.loads((s/'old-plan-supplement-analysis.json').read_text())
data=(s/'point-content-old-plan-canonical-supplement.json').read_bytes()
digest=hashlib.sha256(data).hexdigest()
assert a['full_main_scoped_equality'] and a['all_input_ledger_cleanup_checks_pass']
assert digest=='9fdedc89939dc218bf8e5f01e020f312e81d7025328019c2c70cc00760b6a8ae' and len(data)==1137739
folder='crates/deadpan-plan/tests/fixtures/point-content-query-public-supplement-v1'
readme="""# Ordinary Point content queries: additive public witness v1

Frozen before public Point content admission and native consumer changes.
Main and isolated shipping-copy captures agree completely after stripping only
outer variant, source_sha256 and published_point_borrow_checkpoint. Published
code checkpoint is af34e1e1143e9abc11f49b77ee49c602c116aac4; the later ca5da6f
documentation correction does not change code. Source, binary and environment
guards are retained with qualification evidence.

Three checked public Points yield real full queries: placed Source has three
Leaf spans (ordinary work3); nonunity Preserve has one Stage (work1); unchanged
captured Source binding has one Bound (work11). A fourth checked nine-child
Sequence records the genuine InvalidAudioRootPlacement rejection. No private
Point or unsupported composite is manufactured.

The53 bounded representative requests produce30 ordinary Ok/23 Error and25
internal admitted helper Ok/28 Error. Every header/span/content field, nested
Stage/Bound payload, literal work, typed error, input state, exact spend/Layout/
merge events and live/peak ledger is retained. Ordinary input and result
storage are unadmitted and outside the fresh isolated query-only ledger.

The full three-span helper performs actual vector reservations of768,1536,3072
bytes, preserving earlier live storage while growing1-to2-to4. Actual requested
Layout peak is4792 bytes, returned live storage3368; cleanup returns to0.
This is requested Layout accounting, not allocator/RSS or complete preparation.
Ordinary capacity remains4; no >4 ordinary vector or ProjectedStage is covered.

The original306request raw-carrier witness remains independently frozen at
b7d93aa5673d393b5b74e9e8eb152d510f66f60ab10e70d8e7b0c3cba8b8214e.
The first supplemental capture failed because its test observer did not name
InvalidAudioRootPlacement. A supplement-local typed serializer fixed that;
failed receipts remain in evidence, with no expected body emitted or regenerated.
"""
names=[folder+'/snapshot.json',folder+'/snapshot.sha256',folder+'/README.md']
for root in [Path('/Users/michael/Code/deadpan'),Path('/tmp/deadpan-query-groundwork-2026-10-26/scoped')]:
 d=root/folder;assert not d.exists();d.mkdir(parents=True)
 (d/'snapshot.json').write_bytes(data);(d/'snapshot.sha256').write_text(digest+'\n');(d/'README.md').write_text(readme)
p=s/'immutable-oracle-pins.json';pins=json.loads(p.read_text());assert len(pins)==25;pins.append({'path':names[0],'bytes':len(data),'sha256':digest});p.write_text(json.dumps(pins,indent=2)+'\n')
(s/'owned-supplement-baseline-paths.json').write_text(json.dumps(names,indent=2)+'\n')
for filename in ['source-files.json','scoped-source-files.json','main-logic-source-files.json','scoped-logic-source-files.json']:
 p=s/filename;paths=set(json.loads(p.read_text()));assert not paths.intersection(names);paths.update(names);p.write_text(json.dumps(sorted(paths),indent=2)+'\n')
(s/'old-plan-supplement-freeze.json').write_text(json.dumps({'bytes':len(data),'sha256':digest,'immutable_oracles':26,'before_production_changes':True},indent=2)+'\n')
print('Frozen oracle26',len(data),digest)
