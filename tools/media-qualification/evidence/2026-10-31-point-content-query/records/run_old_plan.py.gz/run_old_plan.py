from pathlib import Path
import subprocess,sys
s=Path(__file__).resolve().parent;v=sys.argv[1]
build=f'point-content-old-plan-{v}-build'
subprocess.run(['python3',str(s/'run_logic_target.py'),build,v,'plan','deadpan_plan',f'point-content-old-plan-{v}-list','--list'],check=True)
subprocess.run(['python3',str(s/'capture_old_plan.py'),v],check=True)
