from pathlib import Path
import subprocess,sys
s=Path(__file__).resolve().parent;v=sys.argv[1]
for package,runner in [('plan','run_main_logic.py'if v=='main'else'run_scoped_logic.py'),('audio','run_qualified.py'if v=='main'else'run_scoped_qualified.py')]:
 label=f'point-content-old-{package}-{v}-build'
 subprocess.run(['python3',str(s/runner),label,'--','cargo','test','-p','deadpan-'+package,'--lib','--locked','--no-run','--message-format=json'],check=True)
 subprocess.run(['python3',str(s/'pin.py'),label],check=True)
