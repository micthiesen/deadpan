# Old Point content query producer review

Lens: oracle integrity and completeness.

## Findings

No concrete defects found in the candidate under this lens.

## Verified points

- `AudioSignalQuery` is explicitly destructured and records project/revision/definition, queried sample range, every span, vector capacity, literal `work`, and all three `LookupStats` fields. Each `AudioSignalSpan` is explicitly destructured and records all current fields: definition, logical and allocated ranges, exact signal extent, full instance/repeats, gap, transform, grid, sample map, retimes, and content.
- Leaf payloads serialize the complete `AudioContent`; Bound payloads use the existing exhaustive private Bound snapshot; Stage payloads use a borrowed snapshot that exhaustively destructures `AudioStage` and `AudioStageDescriptor`, including the private child/node indices and their stable node IDs. ProjectedStage aborts before the output file is opened, so no incomplete descriptor is represented as a full snapshot.
- The ordinary `signal_ref().query` uses Point-mapped support endpoints and actual returned span seams. The request set includes endpoint empties, first/last samples, reversed input, support overhangs, work/span ceilings and one-below cases. A literal zero ceiling remains an invalid-limit probe. The suite does not normalize ordinary and helper results.
- In each request scope, a fresh real raw-domain result is held while the ordinary query is snapshotted; that ordinary result is dropped before `structural_child_query` begins. The helper uses the same Point signal and raw issuer with PointCeil and `(true, true)`, and records its local budget, separate canonical/additional amounts, callback slice, cumulative issuer state, and drop cleanup. The geometry setup similarly checks issuer cleanup after dropping its actual raw result. Caller state is compared before and after.
- Capture is default-off and guarded by the existing capture session. The output is created only after all rows are built; unexpected content aborts before publication. The checkpoint is pinned to `af34e1e1143e9abc11f49b77ee49c602c116aac4`; the README accurately limits claims about allocator/RSS, performance, projected/native paths, and unrun captures.

Type-checking, applying the candidate to either scratch root, and running captures were outside this review and remain parent-owned.
