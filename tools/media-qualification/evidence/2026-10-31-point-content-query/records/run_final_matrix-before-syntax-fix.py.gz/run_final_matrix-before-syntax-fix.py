from pathlib import Path
import hashlib,json,subprocess,sys
s=Path(__file__).resolve().parent
package=sys.argv[1];variants=sys.argv[2:]or['main','scoped']
assert package in ['plan','audio']
rows=[]
for v in variants:
 build=f'point-content-final-{package}-{v}-build'
 pins=json.loads((s/(build+'-pins.json')).read_text())
 assert len(pins)==(29 if package=='plan'else21)
 for pin in sorted(pins,key=lambda p:p['name']):
  assert pin['package']==package
  profile=pin['artifact']['profile']
  assert profile['opt_level']==('0'if package=='plan'else'2')
  if package=='audio':assert profile['debug_assertions']and profile['overflow_checks']
  assert hashlib.sha256(Path(pin['path']).read_bytes()).hexdigest()==pin['sha256']
  label=f"point-content-final-{v}-{package}-{pin['name'].replace('_','-')}"
  skip=['--skip','general_split_sound::']if package=='audio'and v=='main'and pin['name']=='stages'else[]
  runner='run_logic_target.py'if package=='plan'else'run_target.py'
  subprocess.run(['python3',str(s/runner),build,v,package,pin['name'],label,*skip,'--test-threads=1'],check=True)
  rows.append({'variant':v,'package':package,'target':pin['name'],'sha256':pin['sha256'],'receipt':str(s/(label+'.json')),'skipped_filter':skip,'fresh_execution':True})
  (s/f'final-{package}-{"-".join(variants)}-coverage-progress.json').write_text(json.dumps(rows,indent=2)+'\n')
(s/f'final-{package}-{"-".join(variants)}-coverage.json').write_text(json.dumps(rows,indent=2)+'\n')
