from pathlib import Path
import json,hashlib,difflib
s=Path(__file__).resolve().parent;c=Path('/tmp/deadpan-point-content-tests-candidate-v2-2026-10-31')
pins=json.loads((c/'pins.json').read_text());patches=[];owned=set();added=set()
for v,root in [('main-inherited',Path('/Users/michael/Code/deadpan')),('scoped-published',Path('/tmp/deadpan-query-groundwork-2026-10-26/scoped'))]:
 row=pins[v];assert hashlib.sha256((c/row['patch']).read_bytes()).hexdigest()==row['patch_sha256']
 for name,h in row['files'].items():
  a=(root/name).read_bytes()if h['before_exists']else b''
  assert (root/name).exists()==h['before_exists']
  b=(c/'after'/v/name).read_bytes()
  assert len(a)==h['before_bytes']and hashlib.sha256(a).hexdigest()==h['before_sha256'],(v,name)
  assert len(b)==h['after_bytes']and hashlib.sha256(b).hexdigest()==h['after_sha256']
  if h['before_exists']:
   body=''.join('@@\n'if l.startswith('@@')else l for l in list(difflib.unified_diff(a.decode().splitlines(True),b.decode().splitlines(True)))[2:])
   patches.append('*** Begin Patch\n*** Update File: '+str(root/name)+'\n'+body+'*** End Patch')
  else:
   patches.append('*** Begin Patch\n*** Add File: '+str(root/name)+'\n'+''.join('+'+l for l in b.decode().splitlines(True))+'*** End Patch');added.add(name)
  owned.add(name)
(s/'plan-tests-apply-patches.json').write_text(json.dumps(patches))
(s/'owned-plan-tests-paths.json').write_text(json.dumps(sorted(owned),indent=2)+'\n')
for filename in ['source-files.json','scoped-source-files.json','main-logic-source-files.json','scoped-logic-source-files.json']:
 p=s/filename;paths=set(json.loads(p.read_text()));assert not paths.intersection(added);paths.update(added);p.write_text(json.dumps(sorted(paths),indent=2)+'\n')
print('Validated both roots before every mutation; registered new test source')
