# Independent native Point test/capture review

Read-only review. No defect found in the native integration or capture wiring.
The nine focused tests' PASS status on both roots was reported by parent; this
review did not execute tests. It inspected current integrated source and
independently audited the four frozen v2 JSON bodies and execution receipts.

## Actual native coverage

The Source success/failure/cancel test requires actual provider calls in both
plan/cache lanes, exact old/new f32 bits, masks, dependencies, relative depth and
typed error outcomes. A provider callback independently observes positive
sound_context_frames while the new Point result marker is live; ordinary has no
Point result marker. Return/drop state requires zero Point metadata residency,
balanced result creations/drops and unchanged controller after cleanup. Work
deltas must equal the independent additional constructor receipt; no refund is
inferred from a later source error.

The cache-lane early refusal proves no constructor/provider entry and unchanged
work. The plan-work refusal proves a real failed constructor, no result/provider
entry and only accepted partial work retained. Foreign-domain/depth/range and
cancel/deadline priority tests require exact error variants before construction.
These are real boundary tests, not success-path assertions on empty activity.

Warm Preserve uses a real nonunity Stage and a cold read to seed cache. It
requires nonempty cache, unchanged cache entries and prepared-stage count on
warm read, real WAV dependency provider callbacks, exact cold/warm output, live
Point carrier during each callback and zero metadata residency afterwards.

Eviction helper is cfg(test) only. It obtains shared_original_input over exactly
MAX_OUTPUT_FRAMES (256), requires Read::Cached, and drops the temporary read
while graph/cache ownership remains. The test requires nonempty Original cache
and positive cached frames, constrains resident allowance to that actual cache
plus current caller residency, then requires a positive actual host eviction
debit in the selected lane, zero in the other, matching Point constructor
eviction receipt and reduced Original-cache count. Those conditions rule out
an empty-cache or out-of-range setup passing vacuously.

Bound setup independently queries the public Point and requires actual Bound
content, then drops that setup query before measuring the native read. The
native test requires actual WAV IO, exact old/new output, peak_live_results>1
and result_creations>1, every provider observation with live_results>1, balanced
drops and exact per-lane additional-work difference. It demonstrates nested
actual Point carriers after each constructor scope closes; nested=false in the
trace refers to overlapping constructor scopes, not overlapping live results.

## Test claim limits

The resident-refusal test requires a constructor failure, no provider IO and
zero final sound_context_frames. It does not require any prior reservation to
have succeeded or partial_work>0. At a one-frame allowance the first identity
layout may be refused. This test alone should not be cited as proof that an
already allocated intermediate was freed. The exhaustive Plan policy-fault
tests cover cleanup after real partial allocations; native successful-provider
and nested/eviction tests independently prove retained metadata lifetime.

ResultGuard is observational. Declaring it before query ensures its Drop runs
after the query variable's Drop; actual residency is independently checked via
ReadWork at provider callbacks and after return. The trace-disable test is
meaningful: disable occurs only during provider IO after a carrier was acquired,
and ResultGuard::drop uses its captured created flag even while trace is off.
It checks balanced final state and a clean reset.

## Switch and historical-body preservation

Point legacy mode is test-only TLS, false by default, RAII restored on unwind.
Trace ENABLED and CAPTURING_POINT are also false by default. The native Point
capture methods are ignored and require explicit fresh absolute /tmp output,
source manifest, variant and checkpoint; create_new prevents overwriting.

Ordinary capture enables only the Point legacy mode around the same current
raw/fade/owner caller body. The pre-raw legacy wrapper now nests Point legacy
mode, so its historical complete caller body keeps old Point accounting too.
The dedicated pre-Point complete regression compares the entire frozen body
including private state and pins its original byte SHA256. Existing raw capture
uses captured_body_with_point(...,false), so receipts() adds no Point fields to
that older body. Point capture explicitly opts into separate Point and global
host-eviction fields; it does not strip the older receipts or observations.

Both request/trace modules are cfg(test); bound_reads tests remain gated by the
existing macOS/Linux test module, and the shared_eq helper is cfg(test).
Seven common test/capture/request/trace files read identically in Main/Scope.
The helper initializer differs only for Main's existing selected_family_count
and canonical_families Graph fields, absent in Scope. The Scope helper therefore
does not import those Main-only production fields. This review performed no
publication or Git operation and does not certify a future commit's file list.

## Independent capture audit

All four v2 bodies match their proof byte counts/SHA256. Every run receipt has
exit_code=0, sources_unchanged=true, binaries_unchanged=true. Recorded output,
source digest and manifest bytes agree with each proof (resolving /tmp and
/private/tmp to the same path). Each exact named capture contains all 744
operations. Main/Scope complete cases arrays compare equal in each mode.

The ordinary scoped body's paired.new and literal requests equal the frozen
pre-Point body for all 744 operations. Since Main/Scope complete cases are equal,
this establishes the same ordinary result for both roots.

Exhaustive recursive diff of admitted vs ordinary paired.new in both roots
found changes only in plan_work/cache_plan_work at the four post-read/drop
snapshots and source-callback work snapshots, and source-callback
sound_context_frames. No PCM bits, suppression masks, dependencies, depth,
typed errors, controller payload, private input, setup or provider-call identity
changed.

The 744-operation captures exercise Point constructors on 64 operations:
56 plan and 8 cache. Ordinary receipts have 64 ordinary calls and zero admitted
results; admitted receipts have 64 creations/drops, 56+8 completed calls,
canonical work 56+8, additional work 672+96, zero partial work and zero
constructor host eviction. All traces have zero live/depth remainder and no
invalid/nested/overflow flag. These full captures therefore do not by themselves
prove Point constructor failures or evictions; the focused tests supply those
distinct cases, including genuine Stage and nested Bound behavior.

Canonical complete-cases hashes (sorted JSON, compact separators):
ordinary 70279596fc6c42f006fee07079dbda301c2938d4f8bfe541ca4f6394fd4d0d9f
admitted ceb91e3f9f2e997c4242170ee62254e82a12c94074c2ed688ea4b3205117a4c7
