# Native Structural Point content candidate v3

Scratch only. Neither actual root was edited. No Cargo/type check, native
execution, capture, expected body/oracle generation, Git action or production
setting change was performed. Rustfmt skip_children parsed/formatted the
candidate sources. The parent owns independent OLD witness freezes and production integration.

## Revision 3

Versions 1 and 2 remain untouched. Revision 2's statement that budget.check()
performs Spend(0) was incorrect. The actual Plan AudioQueryBudget::check only
compares issuer identity, and check_memory adds no spend callback. The API
candidate's original no-extra-callback description is correct. Callback tests
must retain the actual frozen helper protocol without inventing a seal event.

This revision adds control.check() immediately after the Point query exists and
its admitted-result lifetime marker is acquired, before the ordinary policy
query is constructed. The old read_signal's spend_plan_work(query.work) checked
cancellation/deadline at this point. Already-forwarded queries skip that manual
debit, so the explicit check preserves the stop checkpoint without adding work.
The existing final check remains. All before files were freshly read from both
actual roots and hash-checked before this revision was pinned.

## Inherited revision 2 type correction

Version 1 and its pins remain untouched at
/tmp/deadpan-point-content-native-candidate-2026-10-31. This separate revision
adds I: Copy + Eq to PointContentQuery's getter impl, matching the Plan carrier's
query getter and its GuardedBound dereference constraint. The enum's payload
definition needs no extra bound. Existing before files were freshly re-read and
hash-checked against both actual roots before this revision was pinned.

The borrowed numerical span loop was re-inspected: all source/stage recipe
calls already pass span directly; no newly redundant &span remains there.
No recipe or numerical semantics change was needed for that review point.


## Interface and actual native flow

Uses the Plan worker's exact proposed interface:

AudioPointDomain::content_query_admitted(
    Range<SignalSample>, AudioQueryLimits, &mut Admission
) -> AdmittedAudioPointContentQuery

Its borrowed query(), canonical_units(), additional_units(), total_units() and
was_forwarded() getters are used without cloning or detaching the payload.
The API worker's candidate is separate; this directory edits no Plan source.

read_point_domain_controlled preserves its current first cancellation/deadline,
foreign-domain, depth, frame count and checked reference-range validation. It
uses the already checked signal_at_reference(end) result for its signal end,
then preserves the existing second control check immediately before query
construction. The Point mapping is a one-to-one sample-label rebase.

The actual Point content query is constructed through a short-lived existing
sound_context_admission::Admission borrowing the controller. Its carrier then
outlives ordinary SignalSample policy construction/debit, the same existing
shallow preflight, every numerical/nested read and the final control check.
The ordinary policy still comes from domain.signal_ref().policy; this does not
admit policy. A returned query that already forwarded work is not debited again;
the defensive existing-pattern false-forwarded path debits total_units once.

An opaque private PointContentQuery enum gives test-only ordinary mode the same
borrowed consumer. Production has only the Admitted variant. The result marker
is declared before the actual query so query leases drop before the marker.

## Borrowed numerical consumer

read_signal_queries now accepts &AudioSignalQuery and iterates borrowed spans.
All actual three callers are updated: ordinary read_signal, each mix voice, and
prepared direct root sound. No query clone/detach is introduced. Policy remains
owned and its suppressed Vec transfers into the existing SignalBlock result.

Only the exact old content/policy preflight loops are factored into the small
preflight_signal_queries helper. It deliberately does not call the stronger
existing preflight_signal_query routine, which also traverses Stage/Bound
histories and would alter old behavior/work. Stage/Bound still pass their
existing recursive read admission boundary. Public Signal/Tape/PreserveTape/Mix
construction stays ordinary; this is one actual Structural Point product.

## Frozen ordinary lane

point_content_request is a separate test-only TLS flag with unwind-safe restore.
The ordinary Point lane uses the current signal_ref().query and pays its returned
work once at the old post-construction point. Raw/fade/owner admission stays
active. raw_domain_request's whole-read legacy helper nests the new Point legacy
flag so historical raw/Original/retained body regressions keep their complete
ordinary Point behavior. The new point-content native before-body regression is
wrapped only in Point legacy, keeping all other admitted products active.

This chain means existing raw-only paired fee tests which compare legacyRaw
against current now also span the new Point fee. Parent must adapt those tests
using the independent Point receipt or isolate their Point mode. No residual fee
attribution, expected-body rewriting or cap increase is supplied here.

## Independent bounded trace

point_content_query_trace is cfg(test), default-off and fixed scalar state. It
adds no slots to existing Original or retained trace tables, no event Vec, no
production callback or allocation.

Each actual constructor scope records plan/cache lane, canonical/additional
successful receipts, accepted failure-prefix work and independently observed
host eviction from the existing global accepted host-eviction receipt.
Successful admitted receipts must equal scoped actual accepted work minus host
eviction. The ordinary native lane includes its actual existing manual canonical
debit, records ordinary_calls rather than admitted/completed queries, and still
reconciles exact scoped accepted work. No whole-read residual is called query
work. Failed constructor/debit scopes retain only their actual accepted partial
prefix; no guessed canonical/additional split or refund is invented.

Result creation/drop/live/peak counters remain balanced even if a later provider
disables tracing. Actual shared preflight, numerical function entry and span
iterations emit scalar consumer markers only while an admitted Point result is
live. Nested result peaks are observed, not prohibited. Constructor depth and
other-lane debit mismatches are separately flagged.

The parent still needs to connect reset/disable/snapshot to its real-WAV tests
and NEW capture hook. Until it does, those three helper methods may be reported
unused by strict test lint. This directory intentionally does not invent tests,
fake cache payloads or modify frozen captures to silence them.

## Integration and owed validation

pins.json provides before/after SHA-256s for five existing files in each actual
root and two new files. Both per-variant patches have independent exact scratch
application checks. Before hashes were re-read from actual roots at generation
and again when pins were finalized. Do not overwrite a live source changed by
the parent; rebase into a new candidate revision directory instead.

Parent owns type/borrow checks with the Plan candidate integrated, actual
ordinary/admitted logical parity, native fee/refusal/cache/lifetime tests,
complete NEW native capture comparison, old-body regressions and strict checks.
Preserve before source and all failed attempts. No cap, old weight, refund, DSP,
format, model, media or requirement/Gate change is intended. Whole recursive
preparation and policy remain open.
