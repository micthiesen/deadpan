from pathlib import Path
import hashlib,json,difflib,re,shutil
s=Path(__file__).resolve().parent
roots={'main-inherited':Path('/Users/michael/Code/deadpan'),'scoped-published':Path('/tmp/deadpan-query-groundwork-2026-10-26/scoped')}
paths=['crates/deadpan-audio/src/stages.rs','crates/deadpan-audio/src/signal_mix.rs','crates/deadpan-audio/src/sound_events.rs','crates/deadpan-audio/src/raw_domain_request.rs','crates/deadpan-audio/src/bound_reads/point_content_host_baseline.rs']
new=['crates/deadpan-audio/src/point_content_request.rs','crates/deadpan-audio/src/point_content_query_trace.rs']
pins={}
for variant,root in roots.items():
 patch='';files={}
 for name in paths:
  before=(s/'before'/variant/name).read_bytes();after=(s/'after'/variant/name).read_bytes()
  assert(root/name).read_bytes()==before,(variant,name,'actual root changed')
  patch+=''.join(difflib.unified_diff(before.decode().splitlines(True),after.decode().splitlines(True),fromfile='a/'+name,tofile='b/'+name))
  files[name]={'before_sha256':hashlib.sha256(before).hexdigest(),'before_bytes':len(before),'after_sha256':hashlib.sha256(after).hexdigest(),'after_bytes':len(after)}
 newfiles={}
 for name in new:
  assert not(root/name).exists()
  data=(s/'new'/name).read_bytes()
  patch+=''.join(difflib.unified_diff([],data.decode().splitlines(True),fromfile='/dev/null',tofile='b/'+name))
  newfiles[name]={'sha256':hashlib.sha256(data).hexdigest(),'bytes':len(data)}
 dest=s/'patches'/(variant+'.patch');dest.parent.mkdir(exist_ok=True);dest.write_text(patch)
 check=s/'apply-check'/variant
 if check.exists():shutil.rmtree(check)
 for name in paths:
  p=check/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes((s/'before'/variant/name).read_bytes())
 for block in re.split(r'(?m)^--- ',patch)[1:]:
  first,*rest=block.splitlines(True);assert rest[0].startswith('+++ ')
  name=rest[0].strip()[4:].removeprefix('b/');p=check/name
  original=p.read_text().splitlines(True)if p.exists()else[];output=[];at=0
  for group in re.split(r'(?m)^@@ ',''.join(rest[1:]))[1:]:
   header,*body=group.splitlines(True)
   m=re.match(r'-(\d+)(?:,\d+)? \+\d+(?:,\d+)? @@',header);assert m,header
   start=max(int(m[1])-1,0);assert at<=start;output.extend(original[at:start]);at=start
   for line in body:
    if line.startswith(' '):assert at<len(original)and original[at]==line[1:],(name,at);output.append(line[1:]);at+=1
    elif line.startswith('-'):assert at<len(original)and original[at]==line[1:],(name,at);at+=1
    elif line.startswith('+'):output.append(line[1:])
    else:raise AssertionError((name,line))
  output.extend(original[at:]);p.parent.mkdir(parents=True,exist_ok=True);p.write_text(''.join(output))
  expected=s/('new'if name in new else'after/'+variant)/name
  assert p.read_bytes()==expected.read_bytes(),(variant,name)
 pins[variant]={'files':files,'new_files':newfiles,'patch':str(dest.relative_to(s)),'patch_sha256':hashlib.sha256(patch.encode()).hexdigest(),'exact_scratch_application_verified':True}
(s/'pins.json').write_text(json.dumps(pins,indent=2)+'\n')
print(json.dumps({'variants':2,'existing_files_per_variant':len(paths),'new_files':len(new),'actual_roots_unchanged':True,'exact_scratch_application':True}))
