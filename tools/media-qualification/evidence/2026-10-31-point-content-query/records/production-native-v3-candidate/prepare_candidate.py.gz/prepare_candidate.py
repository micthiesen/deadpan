from pathlib import Path
import hashlib,json,difflib
s=Path(__file__).resolve().parent
roots={'main-inherited':Path('/Users/michael/Code/deadpan'),'scoped-published':Path('/tmp/deadpan-query-groundwork-2026-10-26/scoped')}
paths=['crates/deadpan-audio/src/stages.rs','crates/deadpan-audio/src/signal_mix.rs','crates/deadpan-audio/src/sound_events.rs','crates/deadpan-audio/src/raw_domain_request.rs','crates/deadpan-audio/src/bound_reads/point_content_host_baseline.rs']
qenum="""enum PointContentQuery<'plan, I, L> {
    #[cfg(test)]
    Ordinary(AudioSignalQuery<'plan>),
    Admitted(AdmittedAudioPointContentQuery<'plan, I, L>),
}
impl<'plan, I: Copy + Eq, L> PointContentQuery<'plan, I, L> {
    fn query(&self) -> &AudioSignalQuery<'plan> {
        match self {
            #[cfg(test)]
            Self::Ordinary(value) => value,
            Self::Admitted(value) => value.query(),
        }
    }
}

"""
point_old="""        let signal_start = domain.signal_at_reference(start)?;
        domain.signal_at_reference(end)?;
        let block = self.read_signal(
            domain.signal_ref(),
            provider,
            signal_start,
            frames,
            control,
            depth,
        )?;
        control.check()?;
        Ok(block)
"""
point_new="""        let signal_start = domain.signal_at_reference(start)?;
        let signal_end = domain.signal_at_reference(end)?;
        control.check()?;
        let samples = signal_start..signal_end;
        let limits = control.query_limits()?;
        #[cfg(test)]
        let mut point_result_lifetime = point_content_query_trace::ResultGuard::new();
        #[cfg(test)]
        let query = {
            let mut trace = point_content_query_trace::ScopeGuard::new(control);
            let query = if point_content_request::legacy() {
                let query = domain.signal_ref().query(samples.clone(), limits)?;
                control.spend_plan_work(query.work)?;
                trace.completed(query.work, 0, query.work, false, true, query.spans.len());
                PointContentQuery::Ordinary(query)
            } else {
                let query = {
                    let mut admission = sound_context_admission::Admission::new(self, control);
                    domain.content_query_admitted(samples.clone(), limits, &mut admission)?
                };
                if !query.was_forwarded() {
                    control.spend_plan_work(query.total_units())?;
                }
                trace.completed(
                    query.canonical_units(),
                    query.additional_units(),
                    query.total_units(),
                    query.was_forwarded(),
                    false,
                    query.query().spans.len(),
                );
                PointContentQuery::Admitted(query)
            };
            query
        };
        #[cfg(not(test))]
        let query = {
            let query = {
                let mut admission = sound_context_admission::Admission::new(self, control);
                domain.content_query_admitted(samples.clone(), limits, &mut admission)?
            };
            if !query.was_forwarded() {
                control.spend_plan_work(query.total_units())?;
            }
            PointContentQuery::Admitted(query)
        };
        #[cfg(test)]
        if matches!(&query, PointContentQuery::Admitted(_)) {
            point_result_lifetime.acquired();
        }
        control.check()?;
        let policy = domain
            .signal_ref()
            .policy(samples, control.query_limits()?)?;
        control.spend_plan_work(policy.work)?;
        self.preflight_signal_queries(query.query(), &policy, control, depth)?;
        let block = self.read_signal_queries(query.query(), policy, provider, control, depth)?;
        control.check()?;
        Ok(block)
"""
preflight_old="""        for content in &policy.contents {
            control.preflight_content(content, &self.plan)?;
        }
        for span in &query.spans {
            match &span.content {
                AudioSignalContent::Leaf(content) => {
                    control.preflight_content(content, &self.plan)?
                }
                AudioSignalContent::ProjectedStage(stage) => {
                    self.preflight_projected(stage, control, depth + 1)?;
                }
                AudioSignalContent::Stage(_) | AudioSignalContent::Bound(_) => {}
            }
        }
        self.read_signal_queries(query, policy, provider, control, depth)
    }

    fn read_signal_queries(
"""
preflight_new="""        self.preflight_signal_queries(&query, &policy, control, depth)?;
        self.read_signal_queries(&query, policy, provider, control, depth)
    }

    fn preflight_signal_queries(
        &mut self,
        query: &AudioSignalQuery<'_>,
        policy: &AudioPolicyQuery<SignalSample>,
        control: WorkControl<'_>,
        depth: usize,
    ) -> Result<(), StageAudioError> {
        #[cfg(test)]
        point_content_query_trace::consumer(point_content_query_trace::Consumer::Preflight);
        for content in &policy.contents {
            control.preflight_content(content, &self.plan)?;
        }
        for span in &query.spans {
            match &span.content {
                AudioSignalContent::Leaf(content) => {
                    control.preflight_content(content, &self.plan)?
                }
                AudioSignalContent::ProjectedStage(stage) => {
                    self.preflight_projected(stage, control, depth + 1)?;
                }
                // Stage/Bound preparation owns its recursive admission boundary.
                AudioSignalContent::Stage(_) | AudioSignalContent::Bound(_) => {}
            }
        }
        Ok(())
    }

    fn read_signal_queries(
"""
for variant,root in roots.items():
 for name in paths:
  p=root/name;before=p.read_text();dest=s/'before'/variant/name;dest.parent.mkdir(parents=True,exist_ok=True);assert not dest.exists();dest.write_text(before)
  after=before
  if name.endswith('/stages.rs'):
   a='    AdmittedAudioBoundDomain, AudioBound, AudioBoundDomain, AudioContent, AudioDefinition,\n'
   assert after.count(a)==1
   after=after.replace(a,'    AdmittedAudioBoundDomain, AdmittedAudioPointContentQuery, AudioBound, AudioBoundDomain, AudioContent, AudioDefinition,\n')
   a='#[path = "raw_domain_request.rs"]\nmod raw_domain_request;\n'
   assert after.count(a)==1
   after=after.replace(a,a+'#[cfg(test)]\n#[path = "point_content_request.rs"]\nmod point_content_request;\n#[cfg(test)]\n#[path = "point_content_query_trace.rs"]\nmod point_content_query_trace;\n')
   a="enum RawBoundDomain<'plan, I, L> {"
   assert after.count(a)==1;after=after.replace(a,qenum+a)
   assert after.count(point_old)==1;after=after.replace(point_old,point_new)
   assert after.count(preflight_old)==1;after=after.replace(preflight_old,preflight_new)
   start=after.index('    fn read_signal_queries(\n');end=after.index('\nfn merged_suppression',start)
   part=after[start:end]
   a="        query: AudioSignalQuery<'_>,"
   assert part.count(a)==1;part=part.replace(a,"        query: &AudioSignalQuery<'_>,")
   a='        let cancelled = control.cancelled;\n'
   assert part.count(a)==1;part=part.replace(a,'        #[cfg(test)]\n        point_content_query_trace::consumer(point_content_query_trace::Consumer::Numerical);\n'+a)
   a='        for span in query.spans {\n'
   assert part.count(a)==1;part=part.replace(a,'        for span in &query.spans {\n            #[cfg(test)]\n            point_content_query_trace::consumer(point_content_query_trace::Consumer::Span);\n')
   part=part.replace('signal_source_recipe(&span,','signal_source_recipe(span,').replace('signal_stage_recipe(\n                        &span,','signal_stage_recipe(\n                        span,')
   after=after[:start]+part+after[end:]
  elif name.endswith('/signal_mix.rs'):
   a='self.read_signal_queries(voice.signal, voice.policy, provider, control, depth)?'
   assert after.count(a)==1;after=after.replace(a,'self.read_signal_queries(&voice.signal, voice.policy, provider, control, depth)?')
  elif name.endswith('/sound_events.rs'):
   a='self.read_signal_queries(signal, policy, provider, control, 0)?'
   assert after.count(a)==1;after=after.replace(a,'self.read_signal_queries(&signal, policy, provider, control, 0)?')
  elif name.endswith('/raw_domain_request.rs'):
   a='    action()\n'
   assert after.count(a)==1;after=after.replace(a,'    super::point_content_request::with_legacy_point_content(action)\n')
  elif name.endswith('/point_content_host_baseline.rs'):
   a='    let mut actual = captured_body(\n        "point-content-before-regression",\n        &"0".repeat(64),\n        "87ab6192e765a34dae9595139e10bd9010d6315e",\n    );'
   assert after.count(a)==1
   after=after.replace(a,'    let mut actual = point_content_request::with_legacy_point_content(|| {\n        captured_body(\n            "point-content-before-regression",\n            &"0".repeat(64),\n            "87ab6192e765a34dae9595139e10bd9010d6315e",\n        )\n    });')
  assert before!=after,name
  dest=s/'after'/variant/name;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_text(after)
request="""//! Test-only ordinary Structural Point content-query lane.
thread_local! {
    static LEGACY: std::cell::Cell<bool> = const { std::cell::Cell::new(false) };
}
pub(super) fn legacy() -> bool {
    LEGACY.with(std::cell::Cell::get)
}
pub(super) fn with_legacy_point_content<T>(action: impl FnOnce() -> T) -> T {
    struct Restore(bool);
    impl Drop for Restore {
        fn drop(&mut self) {
            LEGACY.with(|mode| mode.set(self.0));
        }
    }
    let _restore = Restore(LEGACY.with(|mode| mode.replace(true)));
    action()
}
"""
p=s/'new/crates/deadpan-audio/src/point_content_request.rs';p.parent.mkdir(parents=True,exist_ok=True);p.write_text(request)
raw=(roots['main-inherited']/'crates/deadpan-audio/src/raw_domain_query_trace.rs').read_text()
trace=raw.replace('fresh raw-domain constructor.','fresh Structural Point content query.')
trace=trace.replace('    kind_counts: [usize; 3],','    result_spans: usize,')
trace=trace.replace('    nested_root_callbacks: usize,\n    nested_point_callbacks: usize,','    preflight_callbacks: usize,\n    numerical_callbacks: usize,\n    span_callbacks: usize,')
start=trace.index('#[derive(Clone, Copy)]\npub(super) enum Product')
end=trace.index('#[derive(Clone, Copy)]\nenum LaneKind',start)
trace=trace[:start]+trace[end:]
trace=trace.replace('    completed: Option<(usize, usize, usize, bool, Product)>,','    completed: Option<(usize, usize, usize, bool, bool, usize)>,')
trace=trace.replace('        product: Product,','        ordinary: bool,\n        spans: usize,')
trace=trace.replace('self.completed = Some((canonical, additional, total, forwarded, product));','self.completed = Some((canonical, additional, total, forwarded, ordinary, spans));')
trace=trace.replace('if let Some((canonical, additional, total, was_forwarded, product)) = self.completed {','if let Some((canonical, additional, total, was_forwarded, ordinary, spans)) = self.completed {')
trace=trace.replace('let expected = if was_forwarded { total } else { 0 };','// Native ordinary mode retains its existing post-construction debit.\n                let expected = total;')
trace=trace.replace('                    || (was_forwarded && canonical != 0);','                    || (!ordinary && !was_forwarded);')
trace=trace.replace('add(&mut lane.kind_counts[product.index()], 1, &mut overflow);','add(&mut lane.result_spans, spans, &mut overflow);')
trace=trace.replace('                if was_forwarded {','                if !ordinary {')
trace=trace.replace("/// Declared before the actual raw value so its drop observes that value\'s cleanup.","/// Declared before the actual query so its drop observes that query\'s cleanup.")
start=trace.index('pub(super) fn nested_callback(')
trace=trace[:start]+"""#[derive(Clone, Copy)]
pub(super) enum Consumer {
    Preflight,
    Numerical,
    Span,
}
pub(super) fn consumer(consumer: Consumer) {
    if !ENABLED.with(Cell::get) {
        return;
    }
    TRACE.with(|trace| {
        let mut state = trace.get();
        if state.live_results == 0 {
            return;
        }
        let mut overflow = state.overflow;
        match consumer {
            Consumer::Preflight => add(&mut state.preflight_callbacks, 1, &mut overflow),
            Consumer::Numerical => add(&mut state.numerical_callbacks, 1, &mut overflow),
            Consumer::Span => add(&mut state.span_callbacks, 1, &mut overflow),
        }
        state.overflow = overflow;
        trace.set(state);
    });
}
"""
assert 'Product'not in trace and 'kind_counts'not in trace and 'nested_callback'not in trace
(s/'new/crates/deadpan-audio/src/point_content_query_trace.rs').write_text(trace)
print('Prepared scratch source only')
