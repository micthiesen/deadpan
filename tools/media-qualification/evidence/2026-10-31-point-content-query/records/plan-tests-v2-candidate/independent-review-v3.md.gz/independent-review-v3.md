# Independent review of integrated focused Plan tests

Static review only after parent integrated v2 and added local typed serialization
for AudioMetadataIssuerMismatch. No root or candidate source change, build,
Cargo invocation, native execution or expected generation was performed.

No correctness issue found in the reviewed prefix/shared-raw assertions.

## What the comparisons establish

Each of 359 request callbacks runs false mode against ordinary and true mode
against the existing internal helper. The two dedicated test drivers also
require complete equality to the independent initial306/supplement53 frozen
bodies. Thus helper/public parity cannot by itself hide a changed successful
helper payload, work, callback trace, lookup, nested Bound/Stage field or ledger.

Fault pairing compares complete helper/public result, receipts, events, live
ledger and post-drop ledger with identical fault configuration. Baseline prefix
comparison separately excludes before/after objects, because those objects
include the intentionally different future refusal/rotation settings. It
retains operation kind, units/layout, accepted flag, lease identity/bytes and
merge before/after byte fields. It claims callback-shape prefix equality, not
all baseline ledger fields. failed.events.len()==index+1 proves no callback
follows the targeted callback. Every earlier callback shape is unchanged.
The faulty callback itself is independently executed through the same existing
Policy wrapper for helper/public and its full event/result must agree.

The manual CancelSpend failure skips inner Policy::spend, so it does not
increment that policy's work_calls counter for the rejected callback. This is
consistent between lanes and accurately represents the wrapper rejecting
before delegate invocation. It should not be described as calling Policy::spend
and then cancelling. Rejected work remains unaccepted; accepted work is never
refunded. Merge cannot reject in this trait, so rotation after each actual merge
is the appropriate foreign-issuer post-merge test.

Each policy rotation keeps all old policy Rc states alive in issuers. This both
allows checking that every old lease was released and prevents pointer-address
reuse from masking issuer identity. accepted work is summed across those real
states and compared with accepted spend events.

## Shared raw carrier

A separate real raw-domain construction avoids contaminating the original
frozen matrix's cumulative observer state. Its actual Recording policy is used
to construct public query, so raw metadata and query genuinely share an issuer.

The test saves policy before the query, requires nonzero raw resident bytes,
then checks actual accepted_work(after)-accepted_work(before), not a reconstructed
receipt total. It compares that delta with independently recorded isolated
helper accepted work. The live-byte equality raw_live+isolated_query_live
checks the current owned bytes, not a peak estimate. After query drop the real
raw live baseline is restored and its payload is unchanged; after raw drop live
is zero. The original caller policy and Bound snapshots are still covered by
the unchanged surrounding frozen matrix assertions.

The exact resident-cap boundary comes only from a fresh query-only helper
policy's actual cumulative peak. No raw peak subtraction/reset is involved.
Both public/helper must succeed at exact peak and fail at one below. Exact and
one-below work limits use literal helper total including additional work.

## Counts derived from immutable OLD fixtures

These are read-only derived expectations, not a claim of an executed new test.

| Matrix | Requests | Ok | Error | Successful full | Spend | Reserve | Merge | Fault pairs |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| Initial | 306 | 144 | 162 | 18 | 235 | 85 | 49 | 924 |
| Supplement | 53 | 25 | 28 | 3 | 106 | 38 | 26 | 420 |
| Combined | 359 | 169 | 190 | 21 | 341 | 123 | 75 | 1344 |

Callback counts above include successful full requests only, which are exactly
the bounded sources for fault loops. Each spend contributes refusal,
cancellation and rotation; each reserve contributes refusal and rotation; each
merge contributes rotation. Supplement full queries contain three Leaf spans,
one Stage and one Bound. Initial full queries contain 18 Leaf spans.

Meaningful optional runtime summary would increment only after assertions pass:
false_checked, true_checked, shared_raw_checked, successful_full,
spend_refusal_checked, spend_cancel_checked, spend_rotation_checked,
reserve_refusal_checked, reserve_rotation_checked and merge_rotation_checked.
Combined expected completed counts are 359/359/306/21 and
341/341/341/123/123/75. A separate summary object under test TLS can assert these
without changing baseline output. Existing end-of-test request counts already
ensure all 359 callback bodies returned successfully if both tests pass.

## Remaining limits

Final-seal-only issuer-read rotation is not injected. Callback rotations cover
all real helper policy callbacks and issuer checks immediately following them,
including the last callback, but do not selectively fail each additional
callback-free public seal inspection. Drop-before-charge ordering remains a
source/lifetime invariant plus live-lease observation here; the tests do not
observe actual allocator dealloc timing. No universal uncharged-clone
prohibition is claimed for existing Clone query/span/content payloads.
