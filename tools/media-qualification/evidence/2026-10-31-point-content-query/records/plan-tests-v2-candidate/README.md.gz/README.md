# Point content focused Plan tests candidate v2

Scratch only. Production API candidate v1 is unchanged. Neither actual source
root was edited. No Cargo, test binary, native executable, capture, expected
generation or Git command ran.

Integrate only after the public API candidate. Files:

- New audio_owners/point_content_admission_tests.rs, a child of point_content_baseline.
- point_content_baseline.rs adds its module and one default-off TLS hook in
  request_scope after the existing Point/raw setup.
- point_content_supplement.rs adds the same default-off hook and makes only
  matrix_supplement pub(super) so the child can drive it. Its local error_json
  and newly added frozen regression remain unchanged.

Full per-root before/after files, narrow patches, exact hashes and fixture pins
are included. Both roots had identical current before bytes; both patch SHA256:
56e3b8c35e8118b6ad55bfded604d3ef9f2b21f6c494d18817b5d5bedc8a36eb.
Scratch patch application reproduced full after files exactly. Rustfmt parsed
and checked all after files. No type check or execution is claimed.

The two dedicated tests activate their own thread-local scope and assert the
complete initial306 and supplement53 bodies against their existing immutable
fixtures. Every request additionally compares public false to ordinary, and
public true to the existing private helper. All existing frozen tests continue
to run with the new hooks inactive. No fixture changes or candidate-derived
expected values are proposed.

False admission panics in issuer/spend/reserve/merge, including errors. True
comparison includes complete private nested query snapshots, span capacities,
literal work, canonical/additional/total/forwarded, complete callback JSON and
all real query-only policy ledger fields while live and after drop.

On successful full requests only, bounded loops iterate actual helper
callbacks. They compare helper/public refusal or cancellation at every spend,
refusal at every reservation, and issuer rotation after every spend,
reservation and merge. Merge is trusted infallible in this interface; there is
no fabricated fallible merge callback. Rotating after merge exercises its
required post-merge rejection. Each run asserts no later callback, unchanged
accepted prefix shapes, matching failure and full cleanup across issuer states.

Fresh query-only helper peak supplies exact and one-below simultaneous resident
caps. Helper total supplies exact and one-below local work limits. Raw peak is
never subtracted or reset to infer query peak.

Every initial306 request also reconstructs a separate genuine admitted raw
carrier from its existing Bound. Public query uses that carrier's actual
issuer/policy while raw bytes remain live. Assertions compare complete query
body and scalar receipt, actual accepted-work delta from before query, callback
shapes, query live-byte increment, raw baseline restored after query drop,
unchanged raw payload and final raw-drop zero. This separate construction
avoids contaminating the unchanged baseline observer's cumulative ledger.

Parent owns compiler errors and execution. Suggested test filters:
public_point_content_matches_complete_initial_old_matrix
public_point_content_matches_complete_public_supplement

This candidate does not inject issuer changes solely on an issuer read during
the final callback-free seal. Callback rotations cover all real helper policy
callbacks, including its final callback; separate final-check read injection
would be an additional narrow check. Existing Clone payload capability remains
a cooperative trusted-caller limit; no public API redesign is proposed.
