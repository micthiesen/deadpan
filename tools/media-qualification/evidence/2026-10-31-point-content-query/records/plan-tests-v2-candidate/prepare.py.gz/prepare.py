from pathlib import Path
import json,hashlib,difflib,subprocess
base=Path('/tmp/deadpan-point-content-tests-candidate-v2-2026-10-31')
roots={'main-inherited':Path('/Users/michael/Code/deadpan'),'scoped-published':Path('/tmp/deadpan-query-groundwork-2026-10-26/scoped')}
folder=Path('crates/deadpan-plan/src/audio_owners')
files=[folder/'point_content_baseline.rs',folder/'point_content_supplement.rs',folder/'point_content_admission_tests.rs']
data={}
for variant,root in roots.items():
    pins={}
    for rel in files:
        path=root/rel
        before=path.read_text() if path.exists() else ''
        if rel.name=='point_content_baseline.rs':
            anchor='''    assert_eq!(&point_before, expected_point);
    let ordinary = point'''
            assert before.count(anchor)==1
            after=before.replace(anchor,'''    assert_eq!(&point_before, expected_point);
    admission_tests::observe_request(plan, point, request, Some(bound));
    let ordinary = point''')
            after+='''\n#[path = "point_content_admission_tests.rs"]\nmod admission_tests;\n'''
        elif rel.name=='point_content_supplement.rs':
            anchor='''    let input_before = point.probe_baseline_snapshot(plan);
    let mut policy = recording();'''
            assert before.count(anchor)==1
            after=before.replace(anchor,'''    let input_before = point.probe_baseline_snapshot(plan);
    super::admission_tests::observe_request(plan, point, request, None);
    let mut policy = recording();''')
            assert after.count('fn matrix_supplement() -> Value {')==1
            after=after.replace('fn matrix_supplement() -> Value {','pub(super) fn matrix_supplement() -> Value {')
        else:
            assert not path.exists(),f'new file exists: {path}'
            after=(base/'new/point_content_admission_tests.rs').read_text()
        for kind,content in [('before',before),('after',after)]:
            out=base/kind/variant/rel
            out.parent.mkdir(parents=True,exist_ok=True)
            with out.open('x') as f:f.write(content)
        subprocess.run(['rustfmt','--edition','2024','--config','skip_children=true',str(base/'after'/variant/rel)],check=True)
        after=(base/'after'/variant/rel).read_text()
        assert path.read_text()==before if path.exists() else not before
        pins[str(rel)]={'before_exists':path.exists(),'before_sha256':hashlib.sha256(before.encode()).hexdigest(),'after_sha256':hashlib.sha256(after.encode()).hexdigest(),'before_bytes':len(before.encode()),'after_bytes':len(after.encode())}
    patch=''.join(''.join(difflib.unified_diff((base/'before'/variant/rel).read_text().splitlines(keepends=True),(base/'after'/variant/rel).read_text().splitlines(keepends=True),fromfile='a/'+str(rel) if pins[str(rel)]['before_exists'] else '/dev/null',tofile='b/'+str(rel))) for rel in files)
    out=base/'patches'/f'{variant}.patch'
    out.parent.mkdir(exist_ok=True)
    with out.open('x') as f:f.write(patch)
    data[variant]={'files':pins,'patch':str(out.relative_to(base)),'patch_sha256':hashlib.sha256(patch.encode()).hexdigest()}
for variant in roots:
    subprocess.run(['rustfmt','--check','--edition','2024','--config','skip_children=true',*[str(base/'after'/variant/f) for f in files]],check=True)
with (base/'pins.json').open('x') as f:json.dump(data,f,indent=2);f.write('\n')
print(json.dumps({k:{'patch_sha256':v['patch_sha256'],'files':len(v['files'])} for k,v in data.items()},indent=2))
