from pathlib import Path
import hashlib,json,difflib,re
s=Path(__file__).resolve().parent
roots={'main-inherited':Path('/Users/michael/Code/deadpan'),'scoped-published':Path('/tmp/deadpan-query-groundwork-2026-10-26/scoped')}
paths=['crates/deadpan-plan/src/audio_owners/raw_domain_baseline.rs','crates/deadpan-plan/src/audio_signal.rs']
new='crates/deadpan-plan/src/audio_owners/point_content_baseline.rs'
pins={}
for variant,root in roots.items():
 patch=''
 rows={}
 for name in paths:
  before=(s/'before'/variant/name).read_bytes()
  after=(s/'after'/variant/name).read_bytes()
  assert(root/name).read_bytes()==before,(variant,name,'live source changed during preparation')
  patch+=''.join(difflib.unified_diff(before.decode().splitlines(True),after.decode().splitlines(True),fromfile='a/'+name,tofile='b/'+name))
  rows[name]={'before_sha256':hashlib.sha256(before).hexdigest(),'before_bytes':len(before),'after_sha256':hashlib.sha256(after).hexdigest(),'after_bytes':len(after)}
 data=(s/'new'/new).read_bytes()
 assert not(root/new).exists()
 patch+=''.join(difflib.unified_diff([],data.decode().splitlines(True),fromfile='/dev/null',tofile='b/'+new))
 dest=s/'patches'/(variant+'.patch');dest.parent.mkdir(exist_ok=True);dest.write_text(patch)
 check=s/'apply-check'/variant
 for name in paths:
  p=check/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes((s/'before'/variant/name).read_bytes())
 files=re.split(r'(?m)^--- ',patch)[1:]
 for block in files:
  first,*rest=block.splitlines(True)
  assert rest[0].startswith('+++ ')
  name=rest[0].strip()[4:].removeprefix('b/')
  p=check/name
  original=p.read_text().splitlines(True)if p.exists()else[]
  output=[];at=0
  groups=re.split(r'(?m)^@@ ',''.join(rest[1:]))[1:]
  for group in groups:
   header,*body=group.splitlines(True)
   m=re.match(r'-(\d+)(?:,\d+)? \+\d+(?:,\d+)? @@',header);assert m,header
   start=max(int(m[1])-1,0);assert at<=start
   output.extend(original[at:start]);at=start
   for line in body:
    if line.startswith(' '):
     assert at<len(original)and original[at]==line[1:],(name,at)
     output.append(line[1:]);at+=1
    elif line.startswith('-'):
     assert at<len(original)and original[at]==line[1:],(name,at)
     at+=1
    elif line.startswith('+'):output.append(line[1:])
    else:raise AssertionError((name,line))
  output.extend(original[at:])
  p.parent.mkdir(parents=True,exist_ok=True);p.write_text(''.join(output))
  expected=(s/'new'/name)if name==new else(s/'after'/variant/name)
  assert p.read_bytes()==expected.read_bytes(),name
 pins[variant]={'files':rows,'new_file':{'path':new,'sha256':hashlib.sha256(data).hexdigest(),'bytes':len(data)},'patch':str(dest.relative_to(s)),'patch_sha256':hashlib.sha256(patch.encode()).hexdigest(),'exact_scratch_application_verified':True}
(s/'pins.json').write_text(json.dumps(pins,indent=2)+'\n')
print(json.dumps({'variants':len(pins),'existing_files_per_variant':2,'new_files':1,'live_roots_unchanged':True,'exact_scratch_patch_application':True}))
