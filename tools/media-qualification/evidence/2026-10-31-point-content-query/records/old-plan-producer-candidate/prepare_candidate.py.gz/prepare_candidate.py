from pathlib import Path
import hashlib,json,difflib
s=Path(__file__).resolve().parent
roots={'main-inherited':Path('/Users/michael/Code/deadpan'),'scoped-published':Path('/tmp/deadpan-query-groundwork-2026-10-26/scoped')}
paths=['crates/deadpan-plan/src/audio_owners/raw_domain_baseline.rs','crates/deadpan-plan/src/audio_signal.rs']
new='crates/deadpan-plan/src/audio_owners/point_content_baseline.rs'
pins={}
for variant,root in roots.items():
 records={}
 for name in paths:
  source=(root/name).read_bytes()
  b=s/'before'/variant/name;b.parent.mkdir(parents=True,exist_ok=True);b.write_bytes(source)
  text=source.decode()
  if name.endswith('raw_domain_baseline.rs'):
   anchor='    admission_tests::observe(plan, bound, caller);\n'
   assert text.count(anchor)==1
   text=text.replace(anchor,anchor+'    point_content_baseline::observe(plan, bound, caller);\n')
   anchor='''                    if let AudioSignalContent::Bound(bound) = &span.content {
                        match parent {
'''
   assert text.count(anchor)==1
   text=text.replace(anchor,'''                    if let AudioSignalContent::Bound(bound) = &span.content {
                        let _point_content_scope = point_content_baseline::DirectScope::new(
                            match parent {
                                Parent::Root(_) => "root_processing",
                                Parent::Domain(_) => "domain_processing",
                            },
                            descriptor,
                            index,
                        );
                        match parent {
''')
   anchor='''                        if let AudioSignalContent::Bound(bound) = &span.content {
                            signal_bounds += 1;
'''
   assert text.count(anchor)==1
   text=text.replace(anchor,'''                        if let AudioSignalContent::Bound(bound) = &span.content {
                            let _point_content_scope = point_content_baseline::DirectScope::new(
                                "root_signal",
                                descriptor,
                                index,
                            );
                            signal_bounds += 1;
''')
   text+='\n#[path = "point_content_baseline.rs"]\nmod point_content_baseline;\n'
  else:
   anchor='impl PartialEq for AudioStage<\'_> {\n'
   assert text.count(anchor)==1
   text=text.replace(anchor,(s/'stage_probe.txt').read_text()+anchor)
  a=s/'after'/variant/name;a.parent.mkdir(parents=True,exist_ok=True);a.write_text(text)
  records[name]={'before_sha256':hashlib.sha256(source).hexdigest(),'before_bytes':len(source),'after_sha256':hashlib.sha256(a.read_bytes()).hexdigest(),'after_bytes':a.stat().st_size}
 pins[variant]=records
(s/'before-after-pins-unformatted.json').write_text(json.dumps(pins,indent=2)+'\n')
print('Prepared scratch current-source copies only')
