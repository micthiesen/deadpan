# Ordinary Structural Point content-query OLD producer candidate

Scratch-only preparation. Neither actual root was changed. No Cargo/type check,
native executable, query capture, expected body generation, Git operation,
existing oracle change or production admission implementation was performed.
Rustfmt with skip_children=true parsed/formatted only these scratch Rust files.
Exact source hashes and independent scratch patch application pass.

## Integration after the Point borrow publication

The parent supplied and remote-verified Point borrow checkpoint
af34e1e1143e9abc11f49b77ee49c602c116aac4; the producer pins that exact value.
pins.json records exact current before/after hashes for Main and isolated.
Apply only the matching patches/<variant>.patch after checking every before
hash again. Rebase from fresh text if either existing source changes first.

The two existing files are:

- crates/deadpan-plan/src/audio_owners/raw_domain_baseline.rs: one independent
  default-off observer after the current raw observer, two direct-query scopes
  naming actual source origin/fixture/span index, and a test-only child module.
- crates/deadpan-plan/src/audio_signal.rs: one cfg(test) borrowed private Stage
  snapshot, with exhaustive Stage and descriptor destructuring. It records the
  actual child/node indices, corresponding stable IDs, full owning addresses
  and explicit false/None descriptor fields that public serialization can omit.

The new module is
crates/deadpan-plan/src/audio_owners/point_content_baseline.rs.
Add it to ALL qualified/logic named source-input lists before the first parent
build. The module is below an existing test-only ancestor; it adds no production
constructor, callback, charge or traversal.

Parent owns root integration, build/type checks, source/binary guards, captures,
equality, freeze, regression and later admission work. No native Audio executable
may overlap another native invocation. This producer is pure Plan and needs no
media, model or device.

## Exact test suffixes and environment

Both tests are ignored, with the suffixes:

- point_content_baseline::capture_old_point_content_query_baseline_v1
- point_content_baseline::point_content_matches_explicit_external_old_v1

Resolve full test names with the pinned binary's --list. Run one named test at
a time under normal unoptimized Plan settings.

Capture variables:

- DEADPAN_POINT_CONTENT_OUTPUT: fresh absolute /tmp file; parent exists.
- DEADPAN_POINT_CONTENT_VARIANT: main-inherited or scoped-published.
- DEADPAN_POINT_CONTENT_SOURCE_SHA256: complete current named source manifest.
- DEADPAN_POINT_CONTENT_PUBLISHED_CHECKPOINT: af34e1e1143e9abc11f49b77ee49c602c116aac4.

The body is fully constructed before create_new publication, then buffered,
flushed and synced. An unexpected unsupported snapshot branch aborts before an
output body is published.

External regression takes DEADPAN_POINT_CONTENT_EXPECTED pointing to the
independently captured immutable body. Equality strips only outer variant,
source_sha256 and published_point_borrow_checkpoint; nested provenance and all
actual values/work/errors remain.

## What is actually observed

The new session calls the unchanged matrix_raw driver. Its full setup body
retains actual input, retained/cached state and caller state, all genuine
Some/None/rejected setup cases, direct processing source descriptors, and the
storage-only no-document case's existing NotMeasured result. The independent
observer sees all 77 genuine Bounds while their original owning scopes remain
alive. The established corpus guard requires 18 actual Point operands; Root
operands are honestly NotApplicable for Point queries and keep their complete
fresh raw results. A regression in existing raw-domain construction fails,
rather than substituting an ordinary or nominal carrier.

Each Point first gets a real admitted raw carrier for geometry and one ordinary
full query. Reference endpoints use the actual Point mapping. Requests derive
from actual signal endpoints and returned span seams. The geometry ordinary
result is snapshotted and dropped before the geometry carrier drops.

There are at most 20 representative requests per actual Point, at most 360
request scopes: full, empty endpoints, first/last point, suffix, reversed,
one-before/one-after support, work 0/1/2, one span, literal returned work/span
counts and one below, and up to three actual seam crossings. Zero literal work
or span limits stay explicit invalid-limit requests where applicable; they are
not described as valid exact-budget successes.

Each request creates a fresh real admitted raw-domain carrier and a fresh
recording policy. It snapshots complete raw/Bound/Point/caller state, invokes
ordinary signal_ref().query, snapshots its complete result or typed error and
live state, then DROPS THAT ORDINARY RESULT before the helper lane starts.
The ordinary call must not acquire admission callbacks or change the already
accepted raw ledger. Ordinary errors expose no partial-work receipt; the body
says that rather than inventing zero accepted work.

The same raw carrier and issuer then remain alive through the already existing
structural_child_query on PointCeil with stops (true,true). Its fresh local
allowance is the request's maximum_work, independent of already accepted raw
fees. Canonical/additional/local remainder/lookup, exact accepted-work delta,
full callback prefix, requested Layout/merge events and actual cumulative ledger
states are separate from raw-construction events. Returned helper query.work is
literal even if it contains additional work. No helper/ordinary normalization or
forced complete result equality is performed. On helper drop only actual raw
leases remain; on raw drop live bytes are zero. Caller/input values stay exact.

The actual policy peak includes raw construction and query overlap and is never
reset. It is a cumulative requested-reservation observation, not a fresh query
allocator peak. Harness JSON, observer vectors, serialization allocations and
ordinary unadmitted query allocations are outside that ledger and are not
claimed to be covered by it.

## Payload completeness and branch limits

Query and every span are exhaustively destructured. Project/revision/definition,
sample/allocation ranges, exact extents, full InstancePath/repeat addresses,
gap, transforms, grid, sample map, retimes, literal work, all lookup counters and
actual Vec capacity remain. Leaf contents keep complete enum data. Bound
contents use the existing exhaustive private Bound snapshot. Stage contents use
the new exhaustive private Stage/descriptor view rather than a public descriptor
alone. Snapshots borrow real products; they do not query clones, destructively
move them, use Debug strings or simplify owning addresses.

Current Structural span_admitted has no ProjectedStage construction, and the
Point private probe asserts Structural provider. If that unexpected variant
appears, capture stops explicitly: add a complete borrowed private projection
graph snapshot before capturing it. The producer never records its incomplete
public projection descriptor as a complete value.

Projected providers, Source/Silence providers, Tape/Mix aggregation, policy,
native consumption, exact cap acceptance, failure injection, peak bounds,
allocator/RSS and performance are not established by this candidate.
Actual reachable kinds, request/error counts, work ranges and Main/isolated
equality remain unknown until parent executes guarded captures. No golden or
acceptance result exists in this scratch directory.
