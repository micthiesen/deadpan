from pathlib import Path
import subprocess
s=Path(__file__).resolve().parent
for v in ['main','scoped']:
 for mode in ['ordinary','admitted']:
  subprocess.run(['python3',str(s/'capture_point_native.py'),v,mode,f'point-content-focused-audio-{v}-build-v3',f'point-content-native-{v}-{mode}-v2'],check=True)
