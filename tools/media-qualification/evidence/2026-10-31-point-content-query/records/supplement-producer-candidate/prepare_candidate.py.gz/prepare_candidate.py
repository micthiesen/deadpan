from pathlib import Path
import hashlib,json,difflib,re
s=Path(__file__).resolve().parent
roots={'main-inherited':Path('/Users/michael/Code/deadpan'),'scoped-published':Path('/tmp/deadpan-query-groundwork-2026-10-26/scoped')}
name='crates/deadpan-plan/src/audio_owners/point_content_baseline.rs'
new='crates/deadpan-plan/src/audio_owners/point_content_supplement.rs'
pins={}
for variant,root in roots.items():
 before=(root/name).read_bytes()
 p=s/'before'/variant/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(before)
 after=before.decode()+'\n#[path = "point_content_supplement.rs"]\nmod supplement;\n'
 p=s/'after'/variant/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(after)
 data=(s/'new'/new).read_bytes()
 assert not(root/new).exists()
 patch=''.join(difflib.unified_diff(before.decode().splitlines(True),after.splitlines(True),fromfile='a/'+name,tofile='b/'+name))
 patch+=''.join(difflib.unified_diff([],data.decode().splitlines(True),fromfile='/dev/null',tofile='b/'+new))
 dest=s/'patches'/(variant+'.patch');dest.parent.mkdir(exist_ok=True);dest.write_text(patch)
 pins[variant]={'files':{name:{'before_sha256':hashlib.sha256(before).hexdigest(),'before_bytes':len(before),'after_sha256':hashlib.sha256(after.encode()).hexdigest(),'after_bytes':len(after.encode())}},'new_file':{'path':new,'sha256':hashlib.sha256(data).hexdigest(),'bytes':len(data)},'patch':str(dest.relative_to(s)),'patch_sha256':hashlib.sha256(patch.encode()).hexdigest()}
(s/'pins.json').write_text(json.dumps(pins,indent=2)+'\n')
initial=Path('/Users/michael/Code/deadpan/crates/deadpan-plan/tests/fixtures/point-content-query-baseline-v1/snapshot.json')
b=initial.read_bytes()
assert hashlib.sha256(b).hexdigest()=='b7d93aa5673d393b5b74e9e8eb152d510f66f60ab10e70d8e7b0c3cba8b8214e'
(s/'initial-witness-pin.json').write_text(json.dumps({'path':str(initial),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'read_only_verified':True},indent=2)+'\n')
print(json.dumps({'variants':2,'existing_files':1,'new_files':1,'initial_witness_exact':True}))
