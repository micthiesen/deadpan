# Additive OLD Point content-query public supplement

Scratch source candidate only, 2026-10-31. No root edits, Cargo/rustc execution, native executable runs, producer runs, or expected-body generation were performed. Parent owns integration, compilation, fresh capture, equality checks, freeze, and any follow-up public admission work.

## Integration

Apply patches/main-inherited.patch or patches/scoped-published.patch to its matching current root after checking pins.json. Each patch adds one new cfg(test)-reachable source module and appends only the supplement module declaration to audio_owners/point_content_baseline.rs. Existing producer functions and initial frozen body remain exact.

Existing-file before SHA-256 in both roots:
733eb3606258954c78440a3135c8baecf8a93f177ed664f3efe43827b8ec1a22

New source: new/crates/deadpan-plan/src/audio_owners/point_content_supplement.rs
SHA-256: 2286ee2b77271b861210d767343ba84ff21a2f7980e53fa957a3f0e1017f0e5d
Bytes: 19152

pins.json supplies patch and resulting file digests. source-before-main-inherited.json and source-before-scoped-published.json record the actual source, Cargo, and retained fixture read set independently, without Git. Their digests and exact zero-fuzz patch reconstruction results are in validation.json. verified/ is reconstruction in scratch, never an edited root.

Frozen initial witness was read-only verified at 17,636,945 bytes, SHA-256 b7d93aa5673d393b5b74e9e8eb152d510f66f60ab10e70d8e7b0c3cba8b8214e; see initial-witness-pin.json. Its source-level regression remains independent of the supplement.

## Genuine cases and limits

Four bounded checked public constructions, three intended Point inputs plus one intentional existing public rejection:

1. placed-source-multiple-leaves: a 12-frame Source with explicit 2..6-frame audio placement, fractional origin -1/3, scale 7/5, grid origin 1/7. Intends real silent prefix, source, silent suffix: three Leaf spans.
2. preserve-stage: a 6-frame nonunity Preserve of a 12-frame Source, origin -2/5, scale 3/2, grid origin 1/11. Intends genuine Stage.
3. captured-source-bound: the exact retained wide-gain-owner-baseline-v1 document nonunity_shift_fractional_point_ceil_source44100, selecting voice with public audio_definition().in_point_clock(). Its captured binding remains exact. Intends genuine Bound through ordinary public resolution, which lacks raw reconstruction's bypass. A real setup/query error is retained and counts as a gap; no binding or bypass is modified to force coverage.
4. public-sequence-point-rejection: a checked nine-child Sequence passed to public in_point_clock(), recording its genuine typed rejection. This never manufactures an unsupported composite Point.

The actual public placement validator in audio_definition.rs:154 accepts Source, Hold, Repeat gap, or nonunity Preserve, and rejects Sequence, whole Repeat and transparent Retime. Therefore this supplement does not claim a >4-span ordinary Point vector growth case. The ordinary vector's initial capacity is 4. A genuine three-span query can still exercise existing admitted helper accumulator replacements 1→2→4: audio_processing_query.rs collection::push uses exact metered doubling and charges copying old spans as additional work. Captured events and actual result coverage decide which branches were exercised, not this intent description.

The constructor shape and public timing setup follow tests/audio_signal.rs::point_grid_keeps_every_integer_position_in_fractional_source_support. New documents pass ProjectDocument::from_json validation and then RenderPlan::compile. They are pure logical fixtures, with no claim of native media qualification. The retained Bound document is not rewritten.

Each constructed Point uses the shared geometry-derived bounded request generator, at most 20 requests per input: full/empty, first/last/mid crop, reversed/outside support, literal returned work/span caps and one-below caps, and up to three actual seams. No sweep or exhaustive search. Every setup error is serialized with the unchanged document.

## Lifetimes and measurement

These are ordinary public Point inputs because the initial actual raw operand corpus reached only one Leaf. Their input storage is unadmitted and explicitly outside every query-only ledger. Full private borrowed Point/signal snapshots persist before, during and after both lanes, and checked documents remain unchanged.

Per request, a fresh real Recording policy starts with its actual zero ledger. Ordinary signal_ref().query runs and is fully serialized while that same Point is alive. It does not use admission, so its policy snapshots remain unchanged. Ordinary result is explicitly dropped before constructing the separate existing structural_child_query helper. The Point remains alive through both. There is no raw admission fee in this isolated helper lane.

The helper retains literal returned work plus separate canonical/additional work, local allowance remainder and lookup state, real reservation/spend/merge events, ledger while result is alive, and cumulative peak after cleanup. No work or peaks are reset or normalized. Dropping its result must restore real ledger live bytes to zero while input remains alive.

Policy bytes are requested Layout bytes, excluding ordinary query, public input, JSON serialization and observer allocations. This is not allocator/RSS evidence. It supplements, rather than replaces, the original shared raw-carrier issuer/lifetime evidence.

Shared exhaustive borrowed snapshots preserve query header and every span/content field, nested Bound and Stage. An unexpected ProjectedStage aborts before file publication because existing shared serializer deliberately refuses partial coverage. Current Structural path has no ProjectedStage constructor; this remains a stated gap rather than synthesized projection evidence.

## Manual test entry points

Module prefix:
plan::audio_owners::wide_gain_query_admission_tests::retained_fade_baseline::raw_domain_baseline::point_content_baseline::supplement

Ignored producer suffix:
capture_old_point_content_public_supplement_v1

Ignored external full-body regression suffix:
point_content_public_supplement_matches_explicit_external_old_v1

New schema:
old-point-content-query-public-supplement-v1

Producer requires:
- DEADPAN_POINT_SUPPLEMENT_OUTPUT: fresh absolute /tmp file; create_new, flush and sync
- DEADPAN_POINT_SUPPLEMENT_VARIANT: main-inherited or scoped-published
- DEADPAN_POINT_SUPPLEMENT_SOURCE_SHA256: parent's actual full source manifest digest at capture
- DEADPAN_POINT_SUPPLEMENT_PUBLISHED_CHECKPOINT: af34e1e1143e9abc11f49b77ee49c602c116aac4

External regression requires DEADPAN_POINT_SUPPLEMENT_EXPECTED pointing at an independently frozen complete supplement. Only variant, source_sha256, and published_point_borrow_checkpoint are stripped from its outer envelope. The original initial306 witness path+SHA remains inside semantic body. No expected supplement exists here.

## Checks performed

rustfmt --check with skip_children=true passed for new source and both existing-file after copies. validate_candidate.py reconstructed every unified patch exactly with context/deletion checks, matched resulting bytes, checked root edited-path hashes remained current and that new files were absent in roots, and pinned relevant sources twice for read stability. Initial witness hash exact. Rust typechecking and all behavioral/capture validation intentionally remain parent-owned.
