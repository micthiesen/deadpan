from pathlib import Path
import hashlib,json,re
s=Path(__file__).resolve().parent
roots={'main-inherited':Path('/Users/michael/Code/deadpan'),'scoped-published':Path('/tmp/deadpan-query-groundwork-2026-10-26/scoped')}
pins=json.loads((s/'pins.json').read_text())
report={}
for variant,root in roots.items():
 p=pins[variant]
 lines=(s/p['patch']).read_text().splitlines(True)
 cursor=0; produced={}
 while cursor<len(lines):
  assert lines[cursor].startswith('--- ')
  old_name=lines[cursor][4:].strip();cursor+=1
  assert lines[cursor].startswith('+++ ')
  name=lines[cursor][4:].strip().removeprefix('b/');cursor+=1
  before=[] if old_name=='/dev/null' else (s/'before'/variant/name).read_text().splitlines(True)
  source=0; out=[]
  while cursor<len(lines) and not lines[cursor].startswith('--- '):
   m=re.match(r'@@ -(\d+)(?:,(\d+))? \+(\d+)(?:,(\d+))? @@',lines[cursor]);assert m
   start=int(m[1]); target=max(start-1,0)
   assert source<=target
   out+=before[source:target];source=target;cursor+=1
   removed=added=0
   while cursor<len(lines) and not lines[cursor].startswith(('@@ ','--- ')):
    line=lines[cursor];cursor+=1
    assert line[0] in ' +-'
    if line[0] in ' -':
     assert source<len(before) and before[source]==line[1:]
     source+=1;removed+=1
    if line[0] in ' +':out.append(line[1:]);added+=1
   assert removed==int(m[2] or 1) and added==int(m[4] or 1)
  out+=before[source:];data=''.join(out).encode()
  expected=s/'new'/name if old_name=='/dev/null' else s/'after'/variant/name
  assert data==expected.read_bytes()
  dest=s/'verified'/variant/name;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(data)
  produced[name]=hashlib.sha256(data).hexdigest()
 for name,pin in p['files'].items():
  b=(root/name).read_bytes()
  assert len(b)==pin['before_bytes'] and hashlib.sha256(b).hexdigest()==pin['before_sha256']
 assert not (root/p['new_file']['path']).exists()
 manifest={}
 names=['Cargo.toml','Cargo.lock','rust-toolchain.toml']
 for crate in ['deadpan-core','deadpan-plan']:
  names.append(f'crates/{crate}/Cargo.toml')
  names += [str(f.relative_to(root)) for f in sorted((root/f'crates/{crate}/src').rglob('*.rs'))]
 names += ['crates/deadpan-plan/tests/audio_signal.rs','crates/deadpan-plan/tests/fixtures/wide-gain-owner-baseline-v1/snapshot.json','crates/deadpan-plan/tests/fixtures/point-content-query-baseline-v1/snapshot.json']
 for name in sorted(set(names)):
  f=root/name
  if f.exists():
   b=f.read_bytes();manifest[name]={'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
 encoded=(json.dumps(manifest,sort_keys=True,indent=2)+'\n').encode()
 (s/f'source-before-{variant}.json').write_bytes(encoded)
 for name,entry in manifest.items():assert hashlib.sha256((root/name).read_bytes()).hexdigest()==entry['sha256']
 report[variant]={'exact_patch_roundtrip':produced,'actual_roots_unchanged_at_edited_paths':True,'source_manifest_sha256':hashlib.sha256(encoded).hexdigest(),'source_manifest_files':len(manifest)}
(s/'validation.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
