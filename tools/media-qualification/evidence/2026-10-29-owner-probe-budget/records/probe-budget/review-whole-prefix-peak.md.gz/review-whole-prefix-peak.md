# Whole-prefix peak test review

No supported test-coverage or assertion flaw found. The test sets up the owner identity separately, then runs exactly one admitted `original_context_admitted` invocation per budget, so its production Q/C/P/owner decision/final-sharing path reserves through one `Policy` cap. It confirms the resulting retained carrier includes an actual Core lease, measures peak above final live residency, and checks both exact-peak success with matching total work and one-byte-short typed refusal. After each result drops, live bytes return to zero while accepted work stays unchanged.

No edits, tests, or Cargo commands were run.
