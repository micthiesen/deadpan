from pathlib import Path
import json,hashlib,difflib,subprocess
s=Path(__file__).resolve().parent;r=Path('/Users/michael/Code/deadpan');q=Path('/tmp/deadpan-query-groundwork-2026-10-26/scoped')
rows=[];patch=[]
for n in json.loads((s/'task-files.json').read_text()):
 # Parent barrels and Audio have separate isolated before snapshots.
 before=next((root/n for root in [s/'integration/scoped-before',s/'core/before',s/'plan/first-compile/before'] if (root/n).exists()),None)
 b=before.read_bytes() if before else None
 old=subprocess.run(['git','show','HEAD:'+n],cwd=r,capture_output=True)
 assert (old.returncode==0 and old.stdout==b) if b is not None else old.returncode!=0,n
 a=(q/n).read_bytes();live=(r/n).read_bytes();assert a!=(b or b''),n
 patch.extend(difflib.unified_diff((b or b'').decode().splitlines(True),a.decode().splitlines(True),fromfile='a/'+n if b is not None else '/dev/null',tofile='b/'+n))
 rows.append({'path':n,'before_sha256':hashlib.sha256(b).hexdigest() if b is not None else None,'sha256':hashlib.sha256(a).hexdigest(),'main_sha256':hashlib.sha256(live).hexdigest(),'main_equals_scoped':a==live})
(s/'task-scoped.patch').write_text(''.join(patch));(s/'task-source-pins.json').write_text(json.dumps(rows,indent=2)+'\n')
(s/'index-queries.txt').write_text(''.join(':'+x['path']+'\n' for x in rows))
n='crates/deadpan-audio/src/shared_eq/original_inputs.rs'
before=(s/'integration/main-compat-before'/n).read_text();current=(r/n).read_text()
assert current==before.replace('Context::Retained(value) => (2, Arc::as_ptr(value) as usize),','Context::Retained(value) => (2, value.as_ptr() as usize),').replace('(Context::Retained(left), Context::Retained(right)) => Arc::ptr_eq(left, right),','(Context::Retained(left), Context::Retained(right)) => left.ptr_eq(right),')
(s/'main-compatibility.json').write_text(json.dumps({'path':n,'published':False,'scope':'two actual backing-Arc identity calls only; inherited untracked cache preserved','before_sha256':hashlib.sha256(before.encode()).hexdigest(),'sha256':hashlib.sha256(current.encode()).hexdigest()},indent=2)+'\n')
print(json.dumps({'files':len(rows),'main_equal':sum(x['main_equals_scoped'] for x in rows),'scoped_patch_sha256':hashlib.sha256((s/'task-scoped.patch').read_bytes()).hexdigest()}))
