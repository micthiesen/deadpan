from pathlib import Path
import hashlib,json,difflib
r=Path('/tmp/deadpan-owner-probe-budget-2026-10-29/constructors');live=Path('/Users/michael/Code/deadpan')
pins={};chunks=[]
for p in sorted((r/'candidate').rglob('*.rs')):
 rel=p.relative_to(r/'candidate');b=p.read_bytes();pins[str(rel)]=hashlib.sha256(b).hexdigest()
 before=r/'before'/rel
 text=before.read_text() if before.exists() else ''
 if before.exists():assert before.read_bytes()==(live/rel).read_bytes(),str(rel)
 chunks.extend(difflib.unified_diff(text.splitlines(True),b.decode().splitlines(True),fromfile='a/'+str(rel) if before.exists() else '/dev/null',tofile='b/'+str(rel)))
(r/'constructors.patch').write_text(''.join(chunks))
(r/'candidate-pins.json').write_text(json.dumps(pins,indent=2)+'\n')
for p in [r/'constructors.patch',r/'candidate-pins.json']:print(p.name,hashlib.sha256(p.read_bytes()).hexdigest())
