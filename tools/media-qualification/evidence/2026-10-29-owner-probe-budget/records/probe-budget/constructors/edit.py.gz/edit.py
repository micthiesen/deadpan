from pathlib import Path
r=Path('/tmp/deadpan-owner-probe-budget-2026-10-29/constructors/candidate/crates/deadpan-plan/src')
p=r/'audio_bound.rs';s=p.read_text()
s=s.replace('use query::QueryBound;','use query::QueryBound;\n#[path = "audio_bound_probe.rs"]\nmod probe;')
start=s.index('    pub fn raw_domain(&self)')
end=s.index('\n    }\n}',start)+6
s=s[:start]+'''    pub fn raw_domain(&self) -> Result<AudioBoundDomain<'plan>, PlanError> {
        use crate::plan::audio_owners::admission::{self, Owned, Unmetered};
        let mut local = Budget {
            remaining: 65_536,
            lookup: super::LookupStats::default(),
        };
        let mut policy = Unmetered;
        let mut budget = admission::Budget::new(&mut local, &mut policy);
        admission::outer::<_, Unmetered>(self.raw_domain_admitted(&mut budget))
            .map(Owned::unmetered)
    }'''+s[end:]
p.write_text(s)
p=r/'audio_signal.rs';s=p.read_text()
start=s.index('    pub(super) fn for_placed_definition(')
end=s.index('\n    /// Relative instance',start)
s=s[:start]+'''    pub(in crate::plan) fn for_placed_definition_admitted<A: crate::AudioSoundContextAdmission>(
        definition: &AudioDefinition<'plan>,
        support: Range<ExactRatio>,
        transform: SignalTransform,
        budget: &mut crate::plan::audio_owners::admission::Budget<'_, A>,
    ) -> crate::plan::audio_owners::admission::Result<
        crate::plan::audio_owners::admission::Owned<Self, A::Issuer, A::Lease>, A,
    > {
        use crate::plan::audio_owners::admission::Owned;
        let mut result = Owned {
            value: Self {
                plan: definition.plan,
                root: definition.root,
                support: support.clone(),
                sampling_support: Some(support),
                constrain_support: true,
                repeats: Vec::new(),
                definition: None,
                placed_transform: Some(transform),
                bypass_binding: None,
                gap: None,
                provider: SignalProvider::Structural,
            },
            memory: budget.memory(),
        };
        // Same owning copies, and the same order, as the placed constructor.
        result.value.definition =
            budget.definition_ref(&mut result.memory, Some(&definition.selector))?;
        result.value.gap = budget.gap(&mut result.memory, &definition.gap)?;
        budget.check_memory(&result.memory)?;
        Ok(result)
    }
''' +s[end:]
p.write_text(s)
p=r/'audio_point_domain.rs';s=p.read_text()
start=s.index('    pub(super) fn new(')
body=s.index('        let plan = definition.plan;',start)
s=s[:start]+'''    pub(super) fn new(
        definition: &AudioDefinition<'plan>,
        placement: AudioRootPlacement,
        grid_origin: ExactRatio,
    ) -> Result<Self, PlanError> {
        use crate::plan::audio_owners::admission::{self, Owned, Unmetered};
        let mut local = super::audio::Budget {
            remaining: 65_536,
            lookup: super::LookupStats::default(),
        };
        let mut policy = Unmetered;
        let mut budget = admission::Budget::new(&mut local, &mut policy);
        admission::outer::<_, Unmetered>(
            Self::new_admitted(definition, placement, grid_origin, &mut budget),
        ).map(Owned::unmetered)
    }

    pub(in crate::plan) fn new_admitted<A: crate::AudioSoundContextAdmission>(
        definition: &AudioDefinition<'plan>,
        placement: AudioRootPlacement,
        grid_origin: ExactRatio,
        budget: &mut crate::plan::audio_owners::admission::Budget<'_, A>,
    ) -> crate::plan::audio_owners::admission::Result<
        crate::plan::audio_owners::admission::Owned<Self, A::Issuer, A::Lease>, A,
    > {
        use crate::plan::audio_owners::admission::Owned;
''' +s[body:]
start=s.index('        let signal = AudioSignal::for_placed_definition(')
end=s.index('\n    pub fn definition(',start)
s=s[:start]+'''        let mut signal = AudioSignal::for_placed_definition_admitted(
            definition, support, transform, budget,
        )?;
        // The Point selector is a distinct owning edge after signal creation.
        let mut result = Owned {
            value: None,
            memory: budget.memory(),
        };
        let selector = budget.definition_ref(&mut result.memory, Some(&definition.selector))?
            .expect("Point selector");
        result.value = Some(Self {
            plan,
            selector,
            root: definition.root,
            placement,
            grid,
            sampling,
            samples,
            signal: signal.value,
        });
        budget.check_memory(&result.memory)?;
        budget.check_memory(&signal.memory)?;
        budget.merge_checked(&mut result.memory, &mut signal.memory);
        Ok(Owned {
            value: result.value.expect("constructed Point"),
            memory: result.memory,
        })
    }
''' +s[end:]
p.write_text(s)
