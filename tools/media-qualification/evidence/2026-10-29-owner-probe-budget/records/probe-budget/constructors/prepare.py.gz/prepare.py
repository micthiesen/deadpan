from pathlib import Path
import json,hashlib
r=Path('/Users/michael/Code/deadpan');o=Path('/tmp/deadpan-owner-probe-budget-2026-10-29/constructors')
names=['audio_bound.rs','audio_point_domain.rs','audio_signal.rs']
d={}
for n in names:
 p=Path('crates/deadpan-plan/src')/n;b=(r/p).read_bytes();d[str(p)]=hashlib.sha256(b).hexdigest()
 for root in ['before','candidate']:
  q=o/root/p;q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(b)
(o/'before-pins.json').write_text(json.dumps(d,indent=2)+'\n')
