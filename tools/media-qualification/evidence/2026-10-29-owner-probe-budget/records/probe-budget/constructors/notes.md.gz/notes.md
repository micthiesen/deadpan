# Raw-domain constructors: first compile snapshot

Scratch-only candidate, no Cargo/rustc/runtime executed. Existing three source
before-pins match current live bytes at freeze. The five candidate Rust files
parse under scoped rustfmt with skip_children=true. Parent owns all integration,
compilation, runtime/source guards and Git. No golden or observer was changed.

Agreed API: AudioBound::raw_domain_admitted(&self, &mut QueryBudget<A>)
returns the actual Owned<AudioBoundDomain<'plan>, A::Issuer, A::Lease>.
The public raw_domain wrapper uses this same kernel with Unmetered and preserves
zero canonical raw-domain contribution. Its legacy local allowance is inert:
Unmetered additional work never spends it and the actual raw constructor has
no canonical debit. Admitted raw work uses the caller's remaining probe budget.

Required integration outside this ownership: make the existing
AudioDefinition::validate_physical_placement method pub(in crate::plan),
visibility only, so both branches perform the same actual old validation
after definition-handle copies and AudioRootPlacement::new and before the
Root/Point constructor. Parent owns that one-line change.

audio_bound_probe.rs implements the exact Root/Point/Empty decision. The Root
branch calls the existing actual generic root constructor with ZERO grid origin
and RoundEven, exactly as old in_root_clock, never envelope_domain_query.
The false Root evaluation uses the existing set_domain_evaluation body.
True Root evaluation preserves definition, bypass, repeats, constraint extension,
instance replacement order. Each real growing Vec admits an exact checked
capacity and preserves old/new allocation overlap. The Point branch preserves
actual scalar-grid/rebase checks before Signal creation, independent Signal and
Point selector copies, then both new evaluation copies before field replacement.

for_placed_definition was private and had only one Point caller. Its same
construction body is now for_placed_definition_admitted; no unused legacy hook
is added. Public/old Point::new remains an Unmetered wrapper over the same
new_admitted constructor, retaining all actual fields and Structural provider.

Ownership policy: values precede their guards. Temporary copied definition
dies at raw-constructor return, before returning only the actual domain's lease.
Replacement vectors have their own temporary Owned guards and merge after all
fallible issuer checks before moving into the returned container. Initial
cleared selector/instance identity and replaced Vec capacity charges remain
conservative per-domain construction bounds until domain drop. This is explicit
container overlap, not a monolithic walker workspace retained in Graph.
No Core resolver, native/media work, provider change, root substitution,
query replay, counting visitor, cache, cap, weight, refund or retry is added.

Three focused tests invoke actual bound.raw_domain_admitted from real old
Root Split and fractional 44.1kHz Point fixtures: exact full raw logical fields
including private Structural Point signal in both modes; canonical0 and exact
forwarded additional receipts; exact observed constructor peak vs one-byte-short
refusal; refusal at every actual reservation, complete cleanup and no work refund.
These tests have only parsed, not compiled or run. They do not claim Empty
fixture exercise or complete probe/owner-query/native resource closure.
