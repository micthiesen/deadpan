from pathlib import Path
import shutil
s=Path(__file__).resolve().parent;r=Path('/Users/michael/Code/deadpan');q=Path('/tmp/deadpan-query-groundwork-2026-10-26/scoped')
p=s/'candidate/crates/deadpan-audio/src/shared_eq/original_sharing_tests.rs';t=p.read_text()
old='    retained: Option<Weak<deadpan_plan::AudioOwnerRetainedInput<\'plan>>>,\n';assert t.count(old)==1;t=t.replace(old,'',1)
old='''        if let Some(value) = &b.retained {
            assert!(value.upgrade().is_none());
        }
''';assert t.count(old)==1;t=t.replace(old,'',1)
t=t.replace('test final-sharing bytes','test Original metadata bytes')
t=t.replace('fn actual_domain_and_accepted_retained_return_sites_admit_exact_bytes_and_keep_queries_once()', 'fn actual_probe_and_return_sites_preserve_work_and_exact_peak_refusal()')
old='''        let mut a = policy(usize::MAX, control);
        let carrier = Context::finish_paid_owner_input_admitted('''
new='''        // Independent legacy probe amount separates unchanged deferred owner
        // work from the P now forwarded by the actual admitted constructor.
        let old_probe_work = input
            .retained_probe_at(AudioSample(128), control.query_limits().unwrap())
            .unwrap()
            .work();
        let deferred_owner_work = old_work
            .borrow()
            .plan_work
            .checked_sub(old_probe_work)
            .unwrap();
        let mut a = policy(usize::MAX, control);
        let carrier = Context::finish_paid_owner_input_admitted('''
assert t.count(old)==1;t=t.replace(old,new,1)
old='old_work.borrow().plan_work + a.bytes.borrow().inspections';assert t.count(old)==1
t=t.replace(old,'deferred_owner_work + a.bytes.borrow().inspections',1)
old="Layout::new::<deadpan_plan::AudioOwnerRetainedInput<'_>>()";assert t.count(old)==1
t=t.replace(old,"Layout::new::<Option<deadpan_plan::AudioOwnerRetainedInput<'_>>>()",1)
old='''            assert_eq!(
                a.bytes.borrow().calls,
                1,
                "only the moved retained Arc shell"
            );
            assert_eq!(a.bytes.borrow().live, layout.size());
            a.bytes.borrow_mut().retained = Some(Arc::downgrade(value));'''
new='''            assert!(a.bytes.borrow().calls > 1, "actual probe and final shell");
            assert!(a.bytes.borrow().live >= layout.size());
            // Private Plan backing-Arc tests observe the actual opaque value's
            // destruction before Core/Plan leases; no public weak escape.
'''
assert t.count(old)==1;t=t.replace(old,new,1)
p.write_text(t)
# Previously P was legacy. It is now forwarded with Q/C; positive None remains paid.
n='crates/deadpan-audio/src/shared_eq/capture_admission_tests.rs'
for label,root in [('before',r),('scoped-before',q),('candidate',r)]:
 dest=s/label/n;assert not dest.exists();dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(root/n,dest)
p=s/'candidate'/n;t=p.read_text()
old='''        // Includes every actual Q/C/final-sharing policy debit. Only the
        // unchanged legacy None probe is billed outside those callbacks.
        assert_eq!(work.borrow().plan_work, policy.forwarded + probe_work);'''
new='''        // Q/C/P and final sharing now reach the same policy at their actual
        // sites. The positive None probe is included, never dropped or doubled.
        assert_eq!(work.borrow().plan_work, policy.forwarded);'''
assert t.count(old)==1;t=t.replace(old,new,1);p.write_text(t)
# Public barrels only. Existing legacy two-lane transfer remains guarded/plain-only.
n='crates/deadpan-plan/src/audio_domain.rs'
for label,root in [('before',r),('scoped-before',q),('candidate',r)]:
 dest=s/label/n;assert not dest.exists();dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(root/n,dest)
p=s/'candidate'/n;t=p.read_text();old='pub use sharing::{AdmittedOriginalContext, transfer_context_charges};'
new='''pub use sharing::{
    AdmittedOriginalContext, ContextChargeTransfer, SharedAudioOwnerRetainedInput,
    preflight_context_transfer, transfer_context_charges,
};'''
assert t.count(old)==1;p.write_text(t.replace(old,new,1))
p=s/'candidate/crates/deadpan-plan/src/plan.rs';t=p.read_text()
old='    AdmittedOriginalContext, AudioDomain, AudioRootPlacement, transfer_context_charges,'
new='''    AdmittedOriginalContext, AudioDomain, AudioRootPlacement, ContextChargeTransfer,
    SharedAudioOwnerRetainedInput, preflight_context_transfer, transfer_context_charges,'''
assert t.count(old)==1;t=t.replace(old,new,1)
old='    AudioOwnerRetainedInput, AudioOwnerRetainedProbe,'
assert t.count(old)==1;t=t.replace(old,'    AdmittedAudioOwnerRetainedProbe, AudioOwnerRetainedInput, AudioOwnerRetainedProbe,',1);p.write_text(t)
p=s/'candidate/crates/deadpan-plan/src/lib.rs';t=p.read_text()
old='pub use plan::{AdmittedOriginalContext, transfer_context_charges};'
new='''pub use plan::{
    AdmittedOriginalContext, ContextChargeTransfer, SharedAudioOwnerRetainedInput,
    preflight_context_transfer, transfer_context_charges,
};'''
assert t.count(old)==1;t=t.replace(old,new,1)
old='    AudioOwnerRetainedProbe,';assert t.count(old)==1
t=t.replace(old,'    AdmittedAudioOwnerRetainedProbe, AudioOwnerRetainedProbe,',1);p.write_text(t)
# Main-only inherited cache compatibility: actual backing Arc identity stays identity.
n='crates/deadpan-audio/src/shared_eq/original_inputs.rs'
before=s/'main-compat-before'/n;before.parent.mkdir(parents=True,exist_ok=True);before.write_bytes((r/n).read_bytes())
t=(r/n).read_text()
old='Context::Retained(value) => (2, Arc::as_ptr(value) as usize),';assert t.count(old)==1
t=t.replace(old,'Context::Retained(value) => (2, value.as_ptr() as usize),',1)
old='(Context::Retained(left), Context::Retained(right)) => Arc::ptr_eq(left, right),';assert t.count(old)==1
t=t.replace(old,'(Context::Retained(left), Context::Retained(right)) => left.ptr_eq(right),',1)
dest=s/'main-compat-candidate'/n;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_text(t)
print('Prepared test/API/identity compatibility deltas, no live edits.')
