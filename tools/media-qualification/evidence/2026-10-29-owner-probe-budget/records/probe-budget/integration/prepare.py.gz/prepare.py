from pathlib import Path
import shutil
s=Path(__file__).resolve().parent;r=Path('/Users/michael/Code/deadpan');q=Path('/tmp/deadpan-query-groundwork-2026-10-26/scoped')
names=['crates/deadpan-audio/src/authored_eq.rs','crates/deadpan-audio/src/shared_eq.rs','crates/deadpan-audio/src/shared_eq/node_description.rs','crates/deadpan-audio/src/shared_eq/node_description_tests.rs','crates/deadpan-audio/src/shared_eq/original_sharing_tests.rs','crates/deadpan-audio/src/sound_context_admission.rs','crates/deadpan-audio/src/sound_context_admission_tests.rs','crates/deadpan-plan/src/lib.rs','crates/deadpan-plan/src/plan.rs']
for n in names:
 for label,root in [('before',r),('scoped-before',q),('candidate',r)]:
  dest=s/label/n;assert not dest.exists();dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(root/n,dest)
n='crates/deadpan-audio/src/authored_eq.rs';p=s/'candidate'/n;t=p.read_text()
t=t.replace('AudioTreatmentBoundary,\n','AudioTreatmentBoundary, SharedAudioOwnerRetainedInput,\n',1)
assert t.count("Retained(Arc<AudioOwnerRetainedInput<'plan>>)")==1
t=t.replace("Retained(Arc<AudioOwnerRetainedInput<'plan>>)","Retained(SharedAudioOwnerRetainedInput<'plan>)",1)
a=t.index("trait FinalOriginalSharing<'plan>");b=t.index("impl<'plan> Context<'plan>",a)
prefix=r'''trait FinalOriginalSharing<'plan> {
    type Output;
    type Probe;

    fn probe(
        &mut self,
        input: &deadpan_plan::AudioOwnerInput<'plan>,
        at: AudioSample,
        limits: deadpan_plan::AudioQueryLimits,
    ) -> Result<Self::Probe, StageAudioError>;
    fn probe_input(probe: &Self::Probe) -> Option<&AudioOwnerRetainedInput<'plan>>;
    fn probe_work(probe: &Self::Probe) -> usize;
    fn probe_was_forwarded(probe: &Self::Probe) -> bool;
    fn retained(self, probe: Self::Probe) -> Result<Self::Output, StageAudioError>;
    fn domain(self, value: &AudioDomain<'plan>) -> Result<Self::Output, StageAudioError>;
}

struct LegacyOriginalSharing;
impl<'plan> FinalOriginalSharing<'plan> for LegacyOriginalSharing {
    type Output = Context<'plan>;
    type Probe = deadpan_plan::AudioOwnerRetainedProbe<'plan>;

    fn probe(
        &mut self,
        input: &deadpan_plan::AudioOwnerInput<'plan>,
        at: AudioSample,
        limits: deadpan_plan::AudioQueryLimits,
    ) -> Result<Self::Probe, StageAudioError> {
        Ok(input.retained_probe_at(at, limits)?)
    }
    fn probe_input(probe: &Self::Probe) -> Option<&AudioOwnerRetainedInput<'plan>> {
        probe.input()
    }
    fn probe_work(probe: &Self::Probe) -> usize {
        probe.work()
    }
    fn probe_was_forwarded(_: &Self::Probe) -> bool {
        false
    }
    fn retained(self, probe: Self::Probe) -> Result<Self::Output, StageAudioError> {
        Ok(Context::Retained(
            probe.into_input().expect("accepted retained probe").into_shared(),
        ))
    }
    fn domain(self, value: &AudioDomain<'plan>) -> Result<Self::Output, StageAudioError> {
        Ok(Context::Domain(Arc::new(value.clone())))
    }
}

struct AdmittedOriginalSharing<'admission, 'work, A> {
    control: WorkControl<'work>,
    admission: &'admission mut A,
}
impl<A> AdmittedOriginalSharing<'_, '_, A>
where A: deadpan_plan::AudioSoundContextAdmission<Error = StageAudioError>,
{
    fn limits(&self) -> Result<deadpan_plan::AudioQueryLimits, StageAudioError> {
        if A::METERED {
            self.control.query_limits()
        } else {
            Ok(deadpan_plan::AudioQueryLimits::default())
        }
    }
}
impl<'plan, A> FinalOriginalSharing<'plan> for AdmittedOriginalSharing<'_, '_, A>
where A: deadpan_plan::AudioSoundContextAdmission<Error = StageAudioError>,
{
    type Output = deadpan_plan::AdmittedOriginalContext<'plan, A::Issuer, A::Lease>;
    type Probe = deadpan_plan::AdmittedAudioOwnerRetainedProbe<'plan, A::Issuer, A::Lease>;

    fn probe(
        &mut self,
        input: &deadpan_plan::AudioOwnerInput<'plan>,
        at: AudioSample,
        limits: deadpan_plan::AudioQueryLimits,
    ) -> Result<Self::Probe, StageAudioError> {
        let probe = input.retained_probe_at_admitted(at, limits, self.admission)?;
        if probe.was_forwarded() != A::METERED {
            return Err(PlanError::InvalidPlan("retained probe accounting mode differs").into());
        }
        Ok(probe)
    }
    fn probe_input(probe: &Self::Probe) -> Option<&AudioOwnerRetainedInput<'plan>> {
        probe.input()
    }
    fn probe_work(probe: &Self::Probe) -> usize {
        probe.work()
    }
    fn probe_was_forwarded(probe: &Self::Probe) -> bool {
        probe.was_forwarded()
    }
    fn retained(self, probe: Self::Probe) -> Result<Self::Output, StageAudioError> {
        probe.into_shared_admitted(self.limits()?, self.admission)
    }
    fn domain(self, value: &AudioDomain<'plan>) -> Result<Self::Output, StageAudioError> {
        value.clone_shared_admitted(self.limits()?, self.admission)
    }
}

'''
t=t[:a]+prefix+t[b:]
old='''    // The actual probe, owners query and boundary decision are shared once.
    // Only the final sharing operation differs at its original return site.'''
new='''    // Both strategies use the same actual probe, owners and boundary decision.
    // The admitted strategy keeps its real probe guarded through final sharing.'''
assert t.count(old)==1;t=t.replace(old,new,1)
old='''        share: S,
    ) -> Result<S::Output, StageAudioError> {
        let probe = input.retained_probe_at(at, control.query_limits()?)?;
        control.spend_plan_work(probe.work())?;
        if let Some(retained) = probe.into_input() {'''
new='''        mut share: S,
    ) -> Result<S::Output, StageAudioError> {
        let probe = share.probe(input, at, control.query_limits()?)?;
        if !S::probe_was_forwarded(&probe) {
            control.spend_plan_work(S::probe_work(&probe))?;
        }
        if let Some(retained) = S::probe_input(&probe) {'''
assert t.count(old)==1;t=t.replace(old,new,1)
old='return share.retained(retained);';assert t.count(old)==1;t=t.replace(old,'return share.retained(probe);',1)
old='''        share.domain(input.context())
    }
}''';assert t.count(old)==1;t=t.replace(old,'''        // Rejected Some and positive-work None release their actual probe
        // before the existing fallback Domain copy begins.
        drop(probe);
        share.domain(input.context())
    }
}''',1)
p.write_text(t)
# Actual numerical Context clones the initialized handle, not another graph.
p=s/'candidate/crates/deadpan-audio/src/shared_eq/node_description.rs';t=p.read_text()
old='Context::Retained(Arc::clone(carrier.retained().expect("shared retained")))';assert t.count(old)==1
p.write_text(t.replace(old,'Context::Retained(carrier.retained().expect("shared retained").clone())',1))
# Prepare only the actual incoming-retained identity test, preserving its witness.
p=s/'candidate/crates/deadpan-audio/src/shared_eq/node_description_tests.rs';t=p.read_text()
old='''    let retained = Arc::new(
        input
            .retained_at(AudioSample(128), Default::default())
            .unwrap()
            .unwrap(),
    );'''
new='''    let retained = input
        .retained_at(AudioSample(128), Default::default())
        .unwrap()
        .unwrap()
        .into_shared();'''
assert t.count(old)==1;t=t.replace(old,new,1)
t=t.replace('Context::Retained(Arc::clone(&retained))','Context::Retained(retained.clone())',1)
assert t.count('assert!(Arc::ptr_eq(actual, &retained));')==1
t=t.replace('assert!(Arc::ptr_eq(actual, &retained));','assert!(actual.ptr_eq(&retained));',1);p.write_text(t)
print('Prepared actual shared selection strategy and nongeneric Context handle in scratch.')
