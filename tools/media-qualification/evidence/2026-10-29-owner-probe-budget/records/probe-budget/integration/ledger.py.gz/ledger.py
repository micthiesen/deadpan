from pathlib import Path
s=Path(__file__).resolve().parent
p=s/'candidate/crates/deadpan-audio/src/sound_context_admission.rs';t=p.read_text()
old='''//! Request-local admission for current-sound and final Original-sharing metadata.
//! The existing private sound_context_frames lane holds BOTH charges.
//! Earlier Original queries/capture/retained graphs remain outside this slice.'''
new='''//! Request-local admission for current-sound and actual Original metadata.
//! Query, capture, probe and final-sharing leases use sound_context_frames.
//! Retained-owner queries and Graph containers remain outside this slice.'''
assert t.count(old)==1;t=t.replace(old,new,1)
old='''    original: Option<&Lease<'work>>,
    sound: Option<&Lease<'work>>,
)''';new='''    original: Option<&Lease<'work>>,
    core: Option<&Lease<'work>>,
    buffer: Option<&Lease<'work>>,
    sound: Option<&Lease<'work>>,
)'''
assert t.count(old)==1;t=t.replace(old,new,1)
old='for lease in [original, sound].into_iter().flatten()';assert t.count(old)==1
t=t.replace(old,'for lease in [original, core, buffer, sound].into_iter().flatten()',1)
old='''    pub(super) fn commit(self, original: Option<&mut Lease<'_>>, sound: Option<&mut Lease<'_>>) {
        self.ledger.borrow_mut().sound_context_frames = self.remaining;
        if let Some(lease) = original {
            lease.frames = 0;
        }
        if let Some(lease) = sound {
            lease.frames = 0;
        }
    }'''
new='''    pub(super) fn commit(
        self,
        original: Option<&mut Lease<'_>>,
        core: Option<&mut Lease<'_>>,
        buffer: Option<&mut Lease<'_>>,
        sound: Option<&mut Lease<'_>>,
    ) {
        self.ledger.borrow_mut().sound_context_frames = self.remaining;
        for lease in [original, core, buffer, sound].into_iter().flatten() {
            lease.frames = 0;
        }
    }'''
assert t.count(old)==1;t=t.replace(old,new,1);p.write_text(t)
p=s/'candidate/crates/deadpan-audio/src/shared_eq.rs';t=p.read_text()
old='''        let original_frames = description
            .original
            .as_ref()
            .and_then(|value| value.lease())
            .map_or(0, sound_context_admission::Lease::frames);'''
new='''        let original_frames = description
            .original
            .as_ref()
            .map(|value| {
                value.leases().into_iter().flatten().try_fold(0_u64, |total, lease| {
                    total.checked_add(lease.frames()).ok_or(StageAudioError::Range)
                })
            })
            .transpose()?
            .unwrap_or(0);'''
assert t.count(old)==1;t=t.replace(old,new,1)
a=t.index('        let transfer = sound_context_admission::preflight_transfer(')
b=t.index('        let values = &mut description.values;',a)
t=t[:a]+'''        // The token borrows only the carriers. The temporary controller
        // borrow ends before the final ledger snapshot and publication.
        let context_transfer = {
            let mut admission = sound_context_admission::Admission::new(self, control);
            deadpan_plan::preflight_context_transfer(
                description.original.as_mut(),
                description.sound.as_mut(),
                &mut admission,
            )?
        };
        let [original, core, buffer, sound] = context_transfer.leases();
        let transfer = sound_context_admission::preflight_transfer(
            control, original, core, buffer, sound,
        )?;
'''+t[b:]
old='''            |original: Option<&mut sound_context_admission::Lease<'_>>,
             sound: Option<&mut sound_context_admission::Lease<'_>>| {'''
new='''            |original: Option<&mut sound_context_admission::Lease<'_>>,
             core: Option<&mut sound_context_admission::Lease<'_>>,
             buffer: Option<&mut sound_context_admission::Lease<'_>>,
             sound: Option<&mut sound_context_admission::Lease<'_>>| {'''
assert t.count(old)==1;t=t.replace(old,new,1)
assert t.count('transfer.commit(original, sound);')==1
t=t.replace('transfer.commit(original, sound);','transfer.commit(original, core, buffer, sound);',1)
old='''        deadpan_plan::transfer_context_charges(
            expected_issuer,
            description.original.as_mut(),
            description.sound.as_mut(),
            publish,
        )?;'''
assert t.count(old)==1;t=t.replace(old,'        context_transfer.commit(publish);',1)
t=t.replace('// Its heap is outside this bounded current-sound admission slice.','// Graph containers remain outside this metadata admission.',1)
p.write_text(t)
p=s/'candidate/crates/deadpan-audio/src/sound_context_admission_tests.rs';t=p.read_text()
old='preflight_transfer(b, value.lease(), None)';assert t.count(old)==1
t=t.replace(old,'preflight_transfer(b, value.lease(), None, None, None)',1)
t+=r'''

#[test]
fn joint_transfer_commits_all_four_actual_lanes_without_releasing_other_pending_work() {
    let cancelled = AtomicBool::new(false);
    let work = RefCell::new(ReadWork::default());
    work.borrow_mut().sound_context_frames = 31;
    let control = eq::control(&cancelled, &work);
    let mut original = Lease { ledger: &work, frames: 3 };
    let mut core = Lease { ledger: &work, frames: 7 };
    let mut buffer = Lease { ledger: &work, frames: 11 };
    let mut sound = Lease { ledger: &work, frames: 5 };
    let transfer = preflight_transfer(
        control, Some(&original), Some(&core), Some(&buffer), Some(&sound),
    ).unwrap();
    assert_eq!(work.borrow().sound_context_frames, 31);
    transfer.commit(
        Some(&mut original), Some(&mut core), Some(&mut buffer), Some(&mut sound),
    );
    assert_eq!(work.borrow().sound_context_frames, 5);
    assert_eq!([original.frames(), core.frames(), buffer.frames(), sound.frames()], [0; 4]);
    // Even a trusted caller repeating a zero-frame host transfer cannot consume
    // somebody else's remaining charge. The Core token additionally rejects reuse.
    let empty = preflight_transfer(
        control, Some(&original), Some(&core), Some(&buffer), Some(&sound),
    ).unwrap();
    empty.commit(
        Some(&mut original), Some(&mut core), Some(&mut buffer), Some(&mut sound),
    );
    drop((original, core, buffer, sound));
    assert_eq!(work.borrow().sound_context_frames, 5);
}

#[test]
fn every_joint_lane_rejects_a_foreign_ledger_without_mutating_either_pending_sum() {
    for foreign in 0..4 {
        let cancelled = AtomicBool::new(false);
        let left = RefCell::new(ReadWork::default());
        let right = RefCell::new(ReadWork::default());
        let amounts = [3_u64, 7, 11, 5];
        left.borrow_mut().sound_context_frames = 26 - amounts[foreign];
        right.borrow_mut().sound_context_frames = amounts[foreign];
        let leases = std::array::from_fn::<_, 4, _>(|index| Lease {
            ledger: if index == foreign { &right } else { &left },
            frames: amounts[index],
        });
        assert!(matches!(
            preflight_transfer(
                eq::control(&cancelled, &left),
                Some(&leases[0]), Some(&leases[1]), Some(&leases[2]), Some(&leases[3]),
            ),
            Err(StageAudioError::Plan(PlanError::AudioMetadataIssuerMismatch))
        ));
        assert_eq!(left.borrow().sound_context_frames, 26 - amounts[foreign]);
        assert_eq!(right.borrow().sound_context_frames, amounts[foreign]);
        drop(leases);
        assert_eq!(left.borrow().sound_context_frames, 0);
        assert_eq!(right.borrow().sound_context_frames, 0);
    }
}
'''
p.write_text(t)
print('Prepared four-lane planning, preflight and single publication in scratch.')
