# Core borrowed charge transfer, first frozen candidate

Only owned files:
- crates/deadpan-core/src/audio_binding/admission.rs
- crates/deadpan-core/src/audio_binding/admission/tests.rs

No live/scoped/index/Git/worktree/Cargo/rustc activity. Only these scratch files
were rustfmt-parsed. Live owned files still match before-pins.json. Parent owns
all compilation, root reexports, integration, review and execution. Existing
tests are byte-identical prefix; seven tests and one small fixture were appended.

## Exact fixed interface

AudioBindingValue<T,I,L>::charges() -> (Option<&L>,Option<&L>).

AudioBindingValue::preflight_charge_transfer<'value,P>(
 &'value mut self, policy:&P
) -> BuildResult<AudioBindingChargeTransfer<'value,T,I,L>,P::Error>
where P: AudioBindingAdmission<Issuer=I,Lease=L>.

AudioBindingChargeTransfer::charges() returns the same borrowed pair.
commit(self, publish:impl FnOnce(Option<&mut L>,Option<&mut L>)) -> ().

No policy borrow is stored in the token; its ONLY field is a mutable borrow
of the actual AudioBindingValue. Neither lease is taken. Commit has no policy
callback, validation, arithmetic, allocation, work/receipt mutation or refund.
The host preflights its actual ledger/identity/sums before the one trusted,
infallible, non-unwinding publication callback. Core simply gives that callback
both actual mutable charge fields, while keeping them owned by the same value.

A private charge_transferred flag initializes false in the ONE actual Build
finish constructor; finish_buffer delegates to finish. map_value preserves the
flag. Preflight first applies existing issuer/mode validation, then rejects
committed reuse with the typed Document error:
  binding charge transfer already committed
Commit sets the flag immediately before invoking its trusted callback.
A failed preflight or dropped unused token changes no state; valid retry works.
As with the existing map contract, a panicking/misbehaving trusted host callback
violates this protocol; no speculative unwind recovery is added.

Parent must reexport AudioBindingChargeTransfer from the outer Core barrel;
this task did not edit audio_binding.rs or lib.rs. Plan owner was notified of
the exact API while tests were still being written, and gets this final freeze.
No resolver, actual work debit, cap, weight, Core map allocation contract or
existing value-before-lease/buffer field order changes.

## Actual test fixture and authored coverage (UNEXECUTED)

value_with_both_charges uses existing real Build::node plus Growing::push/
finish and Build::finish_buffer. Its returned Vec owns actual copied identity,
and BOTH its payload lease and buffer lease are nonzero. It is a guard fixture,
not forged media/clock authority. No direct field constructor bypass is used.

Seven focused tests:
1. charge_transfer_borrows_both_actual_lanes_without_policy_work
   Borrowed pointer identity for both lanes, unused token retry, one callback,
   committed typed error, no new spend/reserve, work receipt still single-use.
2. charge_transfer_wrong_issuer_or_mode_leaves_valid_retry_possible
   Existing Policy and NoAdmission check typed policy failure, no allocation/
   work change, later valid preflight succeeds and cleans up both lanes.
3. charge_transfer_token_outlives_only_the_temporary_policy_borrow
   Returns token from a temporary Policy clone scope, then mutably borrows
   policy while token remains live. This is an actual compile-time lifetime
   assertion once parent compiles, not a type-erased or static fake policy.
4. charge_transfer_map_preserves_unused_and_committed_state
   Allocation-free moves before and after commit preserve availability/
   committed state and both leases. No work or reservation change.
5. charge_transfer_keeps_value_before_both_independent_charge_drops
   Uses the existing per-Lease drop sentinel on BOTH nonzero lanes; actual
   payload drop marks first, then each charge drop checks the marker.
6. charge_transfer_host_can_disarm_both_fields_without_extracting_or_dropping_value
   Host precomputes checked total/remaining, one tail changes ledger lanes and
   zeroes both actual lease amounts. Actual Vec pointer/content stay unchanged,
   fields remain owned, no new work/reserve. This models the host protocol;
   it is not proof of actual Audio Graph publication or source admission.
7. charge_transfer_empty_compatibility_value_still_commits_only_once
   False/unit backend with no charges still marks one committed handoff;
   mapping preserves it and old unpaid zero-work receipt remains intact.

No tests claim execution or full retained-probe construction/Graph/PCM closure.
Parent's coherent Plan+Audio consumer and resource/semantic verification remain
necessary before publication. The new API is not independently published as
a future-only unused hook.
