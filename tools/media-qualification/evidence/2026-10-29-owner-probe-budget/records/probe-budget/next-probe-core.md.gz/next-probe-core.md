# Next retained-probe boundary: exact current Core/Plan facts

Read-only research while parent qualifies the current capture candidate.
next-probe-core-pins.json pins22 actual current runtime/fixture files. No
source/scoped/index edits, Cargo/rustc, Git operations or tests were performed.
Reading the frozen JSON below is evidence inspection, not a new execution.

## Recommendation

Extend the OLD oracle first to borrow the actual private PointCeil AudioSignal
stored in the returned raw domain, before changing its constructors. Then close
the complete actual probe with a reviewed owning handoff through the existing
retained-owner decision and final Arc sharing. Capture's safe Box bridge is not
a proof that this latter handoff is solved.

A separately wired raw-domain-only slice is feasible and described below, but
is an option, not an automatic preference for avoiding the complete probe.
Do not publish an unused admitted-probe API or enable partial cold success.

## Exact actual call chain and authority

Audio authored_eq.rs::finish_paid_owner_input_with currently performs:
1. input.retained_probe_at(at, control.query_limits()) once.
2. control.spend_plan_work(probe.work()), including successful None.
3. Some => retained.owners(at..at+1, fresh query limits), bills its work.
4. owner.treatment_boundary(0), then ordered any matching returned boundary.
5. Accepted => the same retained value moves into final sharing; rejected or
   absent => drop it, clone/share the source Input Domain instead.

Input is now reached under the admitted query/capture guard and borrowed through
this helper. It must remain charged/alive across the probe and all decisions.
Neither an OwnerKey nor nominal clock replacement supplies these authorities.

Plan audio_owner_input.rs::retained_at is only a compatibility wrapper around
the SAME retained_probe_at. retained_probe_at validates caller limits FIRST,
checks at is inside the actual Input.context root samples SECOND, creates one
Budget and default EditorialCapture, then calls:
  context.plan.audio_walk_editorial(
    at, &mut budget, Some(&context.seed), (true,true), &mut editorial)
The actual context seed and source plan are retained. It does not issue another
membership/candidates query or substitute current Root for hidden Domain support.

audio.rs::audio_walk_editorial invokes the same shared audio_capture.rs walker
through its FALSE compatibility adapter. Full constructor execution continues
after finding an opaque processor. The new capture delivery has NOT admitted
the editorial-output lane: it still asserts !A::METERED at that assignment.

Only an actual returned Stage whose content is Bound calls bound.raw_domain.
All other complete Leaf/Stage spans and EditorialCapture values drop and yield
successful None with positive traversal work. A failed complete walk propagates;
it is never absence. On Some, processing span, editorial and actual raw domain
move into AudioOwnerRetainedInput. Nothing is cloned to form this final struct.

## Current frozen coverage and the PointCeil gap

The immutable owner-capture-baseline-v1/snapshot.json has128 events over16
cases. Its16 actual_retained_probe_result events contain12 None,3 RootRoundEven
Some and1 PointCeil Some. These are fixture counts, not hot-path percentages.

Actual Some cases/work:
- live_bound_group: RootRoundEven,18.
- split_verified_retained_owner_clipped: RootRoundEven,24.
- split_verified_retained_owner_actual_domain: RootRoundEven,24.
- retained_point_voice: PointCeil,21.
The supplemental unbound Shift stage still yields None, work9. Thus preserving
opaque-stage stopping is exercised: descending through it to force Some would
change semantics. Other None work spans8..25 in these fixtures.

Current capture_baseline::bound_domain completely records Root's private seed,
but Point records only public selector/root/placement/reference grid, samples
and affine map. It explicitly says the private signal provider is not inspected.
Calling point.signal() would CLONE the object; it is not the right observer.

The smallest oracle extension borrows &self.signal via a cfg(test) method in
audio_point_domain.rs and an exhaustive cfg(test) AudioSignal snapshot method
in audio_signal.rs. No public runtime accessor is required. Take the externally
supplied expected Plan, assert both objects belong to it BEFORE root-index
aliases, then serialize stable root node IDs instead of raw indices/pointers.
Do not resolve/query/render a second signal or regenerate existing expected data.

Exhaustively record actual AudioSignal fields:
- plan brand and root stable ID;
- support, sampling_support, constrain_support;
- repeats and definition;
- placed_transform, bypass_binding;
- gap, including stable preceding-play identity/duration;
- provider, asserting the actual Structural variant at this constructor.

For actual raw Point construction, for_placed_definition creates Structural,
not Projected/Source/RequiresOwnedInput. Record that literal rather than omitting
the provider or pretending every possible provider graph has been inspected.
The other provider variants need no recursive serialization in this slice:
an unexpected variant should fail this constructor-specific oracle assertion.
The structural definition can still describe a stage requiring later guarded
preparation; do not turn it into a fabricated projection.

Freeze an additive schema/golden under the old probe before rewriting it.
Preserve old16case logical fields/work/errors and main/scoped equality. Add
Point private fields without erasing the earlier golden's declared limitation.
Current golden has no Empty raw domain case; find a legitimately reachable
validated fixture or explicitly leave Empty branch exercise unclaimed.

## Real allocations and overlapping lifetimes

### Shared probe walk, including its discarded result

The same actual audio_capture.rs construction reaches working constraints,
editorial, Repeat and retime buffers; nested gap/identity edges; Source/Hold
descriptors; optional bound/Core graph and Box shell or Preserve stage; full
envelope/boundary vectors and final span.

For probe the editorial-output assignment is important:
  spend(editorial.len + constraints.len + repeats.len)
  EditorialCapture {
    editorial,                  // MOVES actual working editorial vector
    constraints: constraints.clone(),
    repeats: repeats.clone()
  }
Then the walker STILL finishes all boundaries/grid/sample-map/span checks.
The output editorial object may therefore be populated when a later check fails.
It needs a caller-owned value-before-charge guard, not a callee-local lease.
Guard the full span too, including the complete non-Bound span discarded on None.

The existing shared walker has separate Vec capacity lanes but a shared working
identity/payload Memory. To transfer editorial without cloning its moved vector,
a full admission implementation must preserve the actual ownership split:
editorial payload/capacity survives, copied constraints/repeats get their own
charges, and span/workspace have their independent lifetimes. A monolithic
memory sum retained in the final Graph would preserve dead construction charge.
Do not introduce a second visit, copy editorial again, or split a merged opaque
lease without a legitimate ownership mechanism. Private per-container payload
lanes at their actual construction sites are a feasible bounded continuation.

### raw_domain: no new Core traversal, but real Plan construction

audio_bound.rs::raw_domain first clones scalar support and checks positive
length. Nonpositive support returns Empty before definition construction.
Positive support:
1. definition_handle clones gap and selector identity.
2. AudioRootPlacement::new validates positive/nonnegative support and exact
   projected-end arithmetic.
3. definition.in_root_clock or in_point_clock validates physical kind/support.
4. the selected actual constructor runs, then bound evaluation fields replace
   its initial evaluation fields.

Keep this order. Moving physical validation ahead of definition_handle/new
would move old errors/clone points. New actual-site resource refusal may
legitimately precede a later old error; ample resources preserve old behavior.

RootRoundEven:
- in_root_clock validates then root_domain_on_grid(...,ZERO,RoundEven).
- audio_definition_query.rs already contains the generic actual root constructor.
- It creates definition/gap/instance owning edges and one real placement-support
  constraint Vec, plus exact transform/grid/ranges; no media/native work.
- set_domain_evaluation replaces definition/repeats, extends constraints by
  cloning bound constraints, then replaces instance. Old/new replacements and
  Vec growth overlap and must be admitted before those actual operations.
- Reuse the constructor body, but do not invoke envelope_domain_query blindly:
  that method has a DIFFERENT canonical debit and does not replace
  in_root_clock's physical-placement validation.

PointCeil:
- AudioPointDomain::new computes spacing, PointCeil grid, projected support,
  signed boundary labels, checked i64 storage length and integer-label rebase;
  then computes its exact affine map.
- AFTER those scalar checks, AudioSignal::for_placed_definition copies selector/
  gap, stores support twice as scalar ranges, constrain_support=true, initially
  empty repeats, placed_transform=Some, bypass=None, provider=Structural.
- AudioPointDomain then clones its OWN selector after signal creation. This is
  a separate owning field from the signal's selector.
- raw_domain next clones bound.definition and instance.repeats while that
  newly created domain is still live, then set_evaluation replaces embedded
  signal definition/repeats/bypass. The initial signal gap remains.
- Preserve all those copies/replacements; do not replace the signal with a
  scalar reference map or use RootRoundEven as an approximation.
- PointCeil's private provider graph is finite/Structural at this constructor.
  Public signal()/Clone or posthoc OwnedHeap::visit_heap is NOT allocation-site
  admission and cannot replace actual preallocation guards.

### Reached Core

The probe walk reaches actual bound_at_query when it encounters a retained
binding. Under today's false adapter this uses legacy resolve_in/resolve_gap_in:
environment validation, saved template validation, actual projection/scoped
Repeat paths, lattice/phase/reanchor resolution and their old scratch sets.
The actual common admitted Core constructors already exist for the future
true walk. Use them with the SAME budget/receipt issuer and keep their value
paired; don't rebuild frozen indexes or independently re-resolve the bound.

raw_domain itself reaches no new Core resolver, layout/index build or traversal.
It uses already-resolved lattice fields plus scalar grid/ratio methods and
the actual Plan constructors above. Future retained.owners is a SEPARATE query:
audio_owners.rs::AudioOwnerRetainedInput::owners builds an envelope Domain,
then query_mapped with Some(self), or an inactive span on empty support. Its
new query/temporary Domain allocations are not covered merely by admitting probe.

## Work and error obligations

Old probe.work is exactly maximum_work-budget.remaining from the full walk;
it is positive even for None. raw_domain's construction currently adds no
explicit canonical work. Its Root compatibility helper uses an internal
unmetered budget, but the underlying constructor's canonical usage is0.

Future true mode must preserve old canonical probe work, use the SAME actual
walk, count new real inspections/additions (including admitted Core), account
Core child categories locally once, and forward each actual host debit once.
New raw-domain additions should consume the remaining actual probe allowance,
not reset a max budget or manufacture another count of the old walk.
False mode preserves legacy storage/order/receipt values, including None.

Do not remove the old canonical editorial aggregate or bill its already-paid
copies twice. None must still drop constructed output and report its actual
work; no successful partial returned proof follows late failure.
Input support rejection, invalid limits, owned-Preserve refusal, grid/ratio
overflow and late raw-domain physical-placement errors remain typed.
Cancellation, deadline and policy memory/work errors remain original policy
errors, not Plan absence or Unsupported fallback.

Nested Bound work provenance follows the just-qualified Core-private witness:
root resolved.work is total described by its root linear receipt; lattice.work
is local delta. Do not subtract all root extra from lattice or blanket erase
JSON work fields. False matches the whole old JSON; true known-path provenance
assertions and aggregate controller/canonical work reconcile separately.

## Complete owning handoff remains the admission design gate

A fully admitted Some probe must own:
- actual processing span including Core-mapped bound/Box;
- actual EditorialCapture;
- actual Root/Point/Empty raw domain;
- each independent live Plan/Core charge, before no value is released.

It must retain those values/charges while the actual retained.owners query,
boundary test and final share execute. Rejected Some drops everything before
the Domain-fallback clone. Accepted Some must keep the SAME inner charges alive
with the same actual retained value through Graph lifetime, then joint commit/
Graph cleanup. Merely ending Input's source charge is unrelated to those new
probe allocations.

Current into_shared_admitted only admits Arc<Retained>'s final shell. It receives
a naked legacy value and does not own the new processing/Core construction
guard. Current Core map_value is explicitly infallible, non-unwinding AND
allocation-free. Capture's preallocated safe Box::write satisfies that contract;
it does not automatically justify Arc::new inside the callback or safe Arc
initialization via an unchecked conversion.

Parent may retain a Core wrapper whose mapped T is the actual Arc-backed value
in an owning context/Graph carrier. Precisely agreeing the allowed actual
allocation/move and carrier lifetime is the remaining handoff contract, NOT a
reason to extract naked fields/leases or clone a second retained graph. This
note adds no public API and does not rule out that narrow complete solution.
Do not activate generic editorial true mode as a finished whole-probe proof
until its actual numeric consumer and final owning handoff are wired together.

## Smaller raw-domain-only option, explicitly partial

An actual finite constructor slice can keep the existing probe walk/editorial/
Core construction legacy, admit only both raw-domain branches at the existing
raw_domain call, and move that plain retained value plus its new Plan-only raw
domain charge into final sharing Scope. The existing safe Arc::new there can
then retain shell and raw-domain charges together; no Core mapped value is
extracted because no new Core admission was claimed in this option.

This requires the SAME actual probe/constructors and numeric callsite in the
patch, truthful mixed paid/unpaid work provenance, and no naked result escaping
its Plan-only guard. It must explicitly continue to exclude the full walk,
editorial output, retained owners query and inner legacy Core allocations.
This option does not satisfy full probe or full cold closure by itself and
should not be selected solely because today's carrier shape is convenient.

## Next bounded verification contract and ownership

Before implementation:
- Extend Point private-field oracle with actual expected-Plan branding and
  Structural-provider assertion, borrowed from the actual returned object.
- Freeze old outputs in both actual runtime variants before new constructors.
- Preserve existing complete discarded spans/editorial observations and all
  Some/None work. Characterize an honest Empty case separately if reachable.

For complete probe:
- Actual success peak includes charged source Input + probe workspace +
  returned processing/Core bound + editorial output + raw-domain construction;
  accepted branch adds retained owners query and final Arc shell.
- Test exact observed peak/one-byte-short and old+new Vec replacement overlap;
  release sequential/discarded temporaries promptly.
- Early populated editorial slot then later span/raw-domain refusal publishes
  no retained object; all values drop before charges.
- Real Root Some, Point Some (fractional44.1kHz), unbound Leaf None, enclosing
  Preserve/Shift None, stable Repeat gaps/overrides and hidden Domain support.
- Full false snapshot equality; true known-provenance-only work normalization;
  no changed PCM/grid/suppression/source/depth behavior.
- Foreign/unstable issuer checks before callbacks, after construction with result
  ALREADY guarded, at cross-guard merge and final joint publication.
- Boundary rejection releases probe before fallback sharing; accepted Arc keeps
  inner charges across actual Graph reads/error cleanup, not only constructor.

Plan owns actual editorial-output lane, raw-domain/Point/signal constructors and
guarded probe handoff. Core changes, if any, must be limited to an agreed trusted
move contract, not a new resolver. Parent owns Audio’s one-time work handoff,
retained-owner decision and Graph/carrier integration. No second query/probe,
provider/native planner, cache, cap/weight change or cold activation is proposed.

## Final source-pin reconciliation

During note preparation parent applied Plan's strict-only WalkCaptures tuple
alias in audio_capture.rs. The exact independently inspected lint patch only
names the existing slot/editorial/clock tuple with independent lifetimes.
Initial pins and audit remain immutable; next-probe-core-final-pins.json
records that known transition and verifies all22 current pinned paths.
No behavioral or ownership recommendation depends on that textual alias.
