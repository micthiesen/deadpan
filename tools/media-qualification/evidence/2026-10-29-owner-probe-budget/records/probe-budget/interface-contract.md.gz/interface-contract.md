# Actual full probe admission: implementation contract

Implementation is authorized under the active full-product goal. This is an
internal reversible repository change, not a request for another approval.
Base: 4b95ee6a6f5fb3bd28373db6782618707376602c. Parent alone owns live/scoped
application, Cargo/runtime/source guards, index, Git and publication. Workers
write isolated scratch candidates, never worktrees. Preserve all concurrent WIP.

Read next-probe-core.md and full-probe-handoff-design.md. The Point supplement
has actually executed and been pushed: owner-probe-point-baseline-v1/supplement.json,
SHA 169d589017e2b89818f2c06099164c056178888ed7e7ee663d611801f66b9d0a.
Its complete immutable old v1 body and 128 observations remain literal-equal.
Only Structural provider is exercised; Empty/other providers remain unclaimed.

## Ownership

Core worker: only crates/deadpan-core/src/audio_binding/admission.rs and its
admission/tests.rs, plus new tightly scoped child test module if needed.
Parent owns all Core outer barrels/reexports, including audio_binding.rs/lib.rs.

Plan worker: actual editorial/probe/raw-domain construction and guarded handoff.
Own relevant existing Plan implementation and focused test files:
audio_capture.rs, audio_capture_storage.rs, audio_owner_query_admission.rs,
audio_bound_query.rs, audio_bound.rs, audio_owner_input.rs,
audio_owner_input/candidates.rs only if necessary, audio_point_domain.rs,
audio_signal.rs, audio_definition.rs/audio_definition_query.rs,
audio_context_sharing.rs/audio_context_sharing_tests.rs and new focused tests.
Inspect needed exact paths; no authority to change unrelated Plan behavior.
Parent owns Plan outer barrels lib.rs/plan.rs. Keep the new immutable goldens
unchanged. Observer extensions, if needed, must preserve existing inactive fast
paths and old outputs; coordinate them, do not change expectations for a new kernel.

Parent: all Audio source/tests, including authored_eq.rs shared selection helper,
Context payload, numerical node_description.rs, shared_eq.rs and
sound_context_admission.rs/tests.rs. Minimal compatibility edits to inherited
original_inputs.rs may be required in main, but its unrelated WIP must remain.
The isolated published copy excludes those unrelated overlays.

## Core API, fixed names and semantics

AudioBindingValue<T,I,L>::charges() -> (Option<&L>, Option<&L>).
These are its actual independent lease and buffer, borrowed, never taken.

AudioBindingValue<T,I,L>::preflight_charge_transfer<'value,P>(
    &'value mut self, policy: &P
) -> Result<AudioBindingChargeTransfer<'value,T,I,L>,
            AudioBindingBuildError<P::Error>>
where P: AudioBindingAdmission<Issuer=I,Lease=L>.

Token lifetime ties ONLY to the actual value, never to policy. Apply existing
issuer/mode validation, no spend/reserve/merge/receipt take. Failure preserves
the owning guarded value. Unused token drop simply ends borrow. Token has no Clone.

Token.charges() gives the same borrowed pair. Token.commit(self, callback)
is infallible and allocation-free and calls ONE trusted non-unwinding callback
with both Option<&mut L> fields. No policy callbacks, arithmetic or validation
at commit. Actual leases stay fields of the guarded value; host disarms them
into preflighted Graph residency. No naked parts, lease extraction or work reset.

Prevent a second committed transfer from being preflighted again. An explicit
private transfer state is acceptable: initialize at actual constructors, preserve
through map_value, set only on token commit, reject committed reuse as typed
Document error consistently with consumed-work receipt errors. A dropped unused
token and failed preflight must remain retryable with the valid policy.
Preserve T-before-lease/buffer drop order and all work behavior. No new resolver.

Tests must include both nonzero lease AND buffer, unused token, wrong issuer/mode,
no policy borrow lifetime held by token, committed reuse, exact borrowed leases,
no new spend/reserve, map preservation and data-before-charge destruction.
Use actual existing guard/build fixtures; this is a guard API test, no invented
audio authority. Parent will reexport the token from outer Core barrels.

## Plan result and shared handle

Add actual-consumer API AudioOwnerInput::retained_probe_at_admitted(at,limits,&mut A).
Return sealed AdmittedAudioOwnerRetainedProbe<'plan,I,L>:
input() borrows Option<&AudioOwnerRetainedInput>;
work(), canonical_units(), additional_units(), was_forwarded();
no Clone, into_input, into_parts, lease take or public commit constructor.
The input source guard remains alive in its existing Audio caller.

The actual single audio_walk_editorial shares the same generic complete walker,
with captured editorial output in caller-owned value-before-charge storage.
Preserve legacy limit validation, support check, opaque stopping, full discarded
span and late errors. The old editorial aggregate canonical debit remains once.
The editorial Vec MOVES at the old site; constraints/repeats COPY at the old site.
Do not clone the moved editorial again or move the output after later span work.

Separate actual owning payload/capacity lanes enough to move editorial output
and return processing while dropping sequential/discarded workspace promptly.
Do not retain a monolithic dead-workspace charge in the final Graph. Explicit
per-container conservative cleared owning-edge bounds may remain, like current
boundary constructors, but describe them accurately and test lifetimes.
No charge may release before its actual live value on any early/late failure.

Only actual Stage(Bound) builds raw_domain; every other complete span returns
positive-work None. Raw-domain old canonical contribution is zero; new real
inspections are additional and consume remaining SAME probe budget, never a reset.
Root uses its actual definition/physical validation/root_domain_on_grid constructor;
Point uses actual new/for_placed_definition and evaluation replacements. Preserve
old scalar checks, physical validation order, independent selector copies,
old/new replacement and capacity overlap, original point-grid/rebase/phase,
Root round-even, gap/repeat/definition/bypass and hidden-domain authority.
No root substitution, cloned public signal, counting traversal or new provider.

Processing/Core guard maps allocation-free into SAME actual Retained while
editorial/raw-domain/Plan guards remain alive outside the map, including post-map
failure. Return the guard, then borrow through the actual retained.owners and
boundary decision. Retained-owner query itself remains explicitly legacy/unclosed
in THIS slice; preserve its existing one-time debit and keep new probe charges
alive through it. Later owners-query admission is separate. No cold activation.

SharedAudioOwnerRetainedInput<'plan> is a nongeneric sealed Clone/Deref handle
to PRIVATE Arc<Option<AudioOwnerRetainedInput<'plan>>>. Only a proven Some may
be published. Provide ptr_eq(&self,&Self) and as_ptr()->*const () for existing
process-local actual Arc identity caches; neither grants ancestry/source authority.
No mutable/weak/Option escape and no unsafe conversion to Arc<T>.
Plain retained.into_shared() constructs Arc::new(Some(value)) at old legacy
allocation point, with no extra allocation. Parent's Legacy Context uses it.

Admitted probe.into_shared_admitted(limits,&mut A) consumes SAME Some only after
actual owner/boundary acceptance. Admit actual Arc<Option<Retained>> layout,
allocate private Arc::new(None) in value-before-shell-charge guard, then inside
existing allocation-free map_value use guaranteed-unique Arc::get_mut to write
Some(actual Retained) and return that SAME Arc-backed handle. No Retained clone.
Do not allocate retained Arc on rejected Some/None. The one strong/zero weak
private invariant must hold with no intervening exposure/callback receiving Arc.
Pre/post-map refusal drops actual value before every shell/Plan/Core charge.

AdmittedOriginalContext keeps the actual Core-mapped shared handle plus Plan
metadata charges through Description. retained() now borrows the nongeneric
handle; Parent Context clones only its Arc. Legacy into_shared_admitted remains
usable for plain retained and produces same handle without a Core guard.
Merge only same-issuer Plan lanes; preserve each real issued lease's rounding.

## Plan preflight API and one Audio publication

Replace the existing transfer_context_charges entry with:
preflight_context_transfer<'value,'plan,A>(
    original: Option<&'value mut AdmittedOriginalContext<'plan,A::Issuer,A::Lease>>,
    sound: Option<&'value mut AdmittedSoundContext<'plan,A::Issuer,A::Lease>>,
    admission: &mut A
) -> Result<ContextChargeTransfer<'value,'plan,A::Issuer,A::Lease>, A::Error>.

Returned token ties to values only; temporary policy/controller borrow MUST END.
It preflights all actual Plan/sound issuers and Core token through the real
CoreAdmission adapter, with no fake policy, extraction or fallible commit.
OriginalContext.leases() returns [Plan,Core lease,Core buffer] borrowed;
token.leases() returns [original Plan,Core lease,Core buffer,sound Plan] borrowed.
Original .lease() may remain as explicitly Plan-only legacy accessor for existing
plain-sharing tests, but Parent new accounting MUST use all lanes.

Token.commit(self, callback) calls ONE infallible non-unwinding callback with
four Option<&mut L> arguments in that same order. Split private borrows of the
Core wrapper and Plan charge; no generic Graph/Context lifetimes. Core token's
commit must wrap the SAME publication, not an earlier partial transfer. Dropping
token on failed Audio ledger preflight leaves all guarded values/charges intact.
Parent owns root reexports of handle/probe/token/preflight function.

Parent early metadata planning sums actual four lane frame amounts with checked
arithmetic, preserving each issued charge's rounding. Complete native work,
last cancellation/deadline check, Node Vec reserve and other resource work first.
Then create preflight Context token using a temporary real Admission (controller
borrow ends), preflight exact ledger pointers/sum/subtraction against all4 leases,
and perform ONE nofail push/set-active/set-resident/disarm-all4 callback.
No admission/eviction/callback/fallible validation between final snapshot and push.
Graph/cache values drop BEFORE graph-resident release on both exits.

Parent shares actual probe/owners/boundary decision body via private strategy:
legacy returns plain probe, admitted returns sealed guarded probe; bill P only
when not already forwarded. Existing positive None work remains. Owner query
and boundary retain their exact original order and real objects. Rejected Some
guard drops before fallback Domain sharing. Source Input remains borrowed/charged
through whole helper. No unused admitted API published without this numeric wiring.

## Verification and scope

False mode full old128-event/16-case output + Point private supplement exact.
True work normalization only known Core resolved/lattice scalar provenance as
already qualified, not blanket field erasure. Canonical totals old-identical;
all additional actual operations/callbacks bill once to same WorkControl.
Test Some Root/Point, None Leaf/opaque Preserve/Shift, early editorial slot then
late failure, real Repeat/gap/hidden support, exact live overlap/one byte short,
cancellation/unstable issuer, pre/post-map and Arc refusal, rejected/accepted
branches, same actual value identity, no duplicate allocation/graph clone,
all4 transfer lanes/foreign ledger/underflow/reuse, real Graph cleanup and PCM.
No caps/weights/native bounds/refunds/caches, scalar retry or source bypass.

No full allocator/RSS/native claim. Retained-owner query, caller keys, Node Vec/
other graph containers and whole recursive cold closure remain explicit next work.
Parent runs routine fast logic checks first, then optimized actual Audio/media,
strict gate and scoped source/index equality before scoped commit/push.
