from pathlib import Path
import hashlib,json
o=Path('/tmp/deadpan-owner-probe-budget-2026-10-29/plan')
r=Path('/Users/michael/Code/deadpan')
rel=Path('crates/deadpan-plan/src/audio_owners/legacy_snapshot_v1/capture_baseline.rs')
b=(r/rel).read_bytes()
for d in ['before','candidate']:
 p=o/d/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b)
pins=json.loads((o/'before-pins.json').read_text());pins[str(rel)]=hashlib.sha256(b).hexdigest();(o/'before-pins.json').write_text(json.dumps(pins,indent=2)+'\n')
p=o/'candidate'/rel;s=p.read_text()
start=s.index('pub(in crate::plan) fn probe_walk(');end=s.index('pub(in crate::plan) fn probe_result(',start)
old=s[start:end]
body=old[old.index('    if !active()'):];s=s[:start]+'''pub(in crate::plan) fn probe_walk(
    plan:&RenderPlan, at:AudioSample, walked:&Result<AudioWalkSpan<'_>,PlanError>,
    captured:&EditorialCapture, work:(usize,usize),
) {
    probe_walk_ref(plan,at,walked.as_ref(),captured,work);
}
pub(in crate::plan) fn probe_walk_ref(
    plan:&RenderPlan, at:AudioSample, walked:Result<&AudioWalkSpan<'_>,&PlanError>,
    captured:&EditorialCapture, work:(usize,usize),
) {
'''+body+s[end:]
# Existing wrapper may have no live caller if new false helper directly observer-ref.
# Keep wrapper reachable in the new unmetered wrapper? Generic borrowed uses ref,
# current other tests none. cfg(test) allows no deadcode? remove wrapper? preserve with allow? use new helper old wrapper by generic false map impossible.
# We'll keep and exercise wrapper in test later; clippy dead_code needs cfgtest only accepts tests usage.
p.write_text(s)
p=o/'candidate/crates/deadpan-plan/src/audio_owner_input.rs';s=p.read_text()
a=s.index('        limits.validate()?;',s.index('    pub fn retained_probe_at('))
z=s.index('\n    }\n}',a)
s=s[:a]+'''        use crate::plan::audio_owners::admission::Unmetered;
        let mut admission=Unmetered;
        Ok(self.retained_probe_at_admitted(at,limits,&mut admission)?.unmetered())
'''+s[z:]
s=s.replace('use super::audio::{AudioWalkSpan, Budget, EditorialCapture};','use super::audio::{Budget, EditorialCapture};')
anchor='mod candidates;'
s=s.replace(anchor,anchor+'''\n#[path="audio_owner_probe.rs"]
mod probe;
pub use probe::{AdmittedAudioOwnerRetainedProbe,SharedAudioOwnerRetainedInput};''')
p.write_text(s)
