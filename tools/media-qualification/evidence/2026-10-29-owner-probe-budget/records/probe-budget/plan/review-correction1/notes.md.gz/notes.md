# Review correction 1

Against CURRENT live Plan bytes after first snapshot plus private additional
handoff tests. No live/scoped/index/Git mutation, Cargo/rustc or execution claim.
Scoped rustfmt parses; before hashes and patch dry-run recorded at freeze.

## Correction

Immediately after constructing the final-sharing QueryBudget, before additional
work/reservation/Arc allocation:
- check the actual guarded Plan Memory against the budget's fixed issuer;
- obtain and end an UNUSED GuardedBound preflight token through the REAL existing
  CoreAdmission adapter (validates actual stored Core issuer/mode and committed
  state, consumes no receipt and reserves/spends/commits nothing);
- check the Plan/budget issuer again before any resource work.
Existing map pre/post checks remain. The policy borrow ends at the inner scope.
No new public infrastructure API or dummy policy was introduced.

## New exact test names (audio_owner_input::probe::tests child)

- final_shell_foreign_and_unstable_issuer_refuse_before_work_or_reservation
  The unstable policy changes between the initial outer check and Budget::new.
  Both foreign and unstable paths must produce the typed issuer error with zero
  new reserve/work calls and no leaked charge. The old final-sharing code would
  allocate the shell before detecting the unstable Plan/budget mismatch.
- actual_stored_core_issuer_is_validated_before_any_shell_reservation
  A private seam composes a real actual admitted Core value from one issuer with
  an empty Plan lane from another. Original Plan charge remains held separately
  throughout the failed call. No graph/source authority is invented or changed.
  New policy reserve/work calls must stay zero; original actual Core/Plan data
  and charges clean up. This isolates the real stored Core issuer check instead
  of relying only on the outer carrier's issuer or no-publication assertion.
- real_late_walker_policy_failure_observes_populated_charged_editorial_then_cleans_up
  Uses the validated frozen actual fractional Point/Source fixture. Bounded
  reservation-site fault scheduling fails actual operations of the SAME real
  probe. It must find a real boundary/span reservation after editorial output
  is populated AND has a live lease, preserve the exact original scheduled
  policy error, release every lease, and retain accepted work.
  The cfgtest observer borrows the actual caller-owned slot before cleanup;
  explicit kind actual_retained_probe_policy_refusal never coerces policy error
  to PlanError/None. Inactive fastpath returns before logical serialization.
- actual_original_core_and_sound_share_one_preflight_callback_without_extra_work
  Uses actual admitted Original/Core plus same-Plan actual Sound context/share.
  Readonly lane bytes sum to live metadata, unused token stays retryable, one
  commit callback receives [Plan,Core lease,None genuine buffer,Sound Plan], no
  new work/reserve happens, and both actual carriers clean up with retained Arc
  destruction before Original charges. Nonzero independent Core buffer is
  separately covered by Core's existing transfer tests; this fixture does not
  manufacture one.

All immutable goldens and earlier frozen snapshots remain untouched. No optional
branch research, Empty/provider claim, cap/weight/cache/refund/retry/native change.
