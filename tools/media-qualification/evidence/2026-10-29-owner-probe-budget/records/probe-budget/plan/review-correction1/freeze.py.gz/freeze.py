from pathlib import Path
import json,hashlib,difflib
o=Path('/tmp/deadpan-owner-probe-budget-2026-10-29/plan/review-correction1');r=Path('/Users/michael/Code/deadpan');h=lambda b:hashlib.sha256(b).hexdigest()
before=json.loads((o/'before-pins.json').read_text());after={};patch=[]
for rel,sha in before.items():
 assert h((r/rel).read_bytes())==sha,rel
 a=(o/'before'/rel).read_bytes();b=(o/'candidate'/rel).read_bytes()
 assert a!=b;after[rel]=h(b)
 patch+=list(difflib.unified_diff(a.decode().splitlines(True),b.decode().splitlines(True),fromfile='a/'+rel,tofile='b/'+rel))
(o/'review-correction.patch').write_text(''.join(patch))
(o/'candidate-pins.json').write_text(json.dumps(after,indent=2)+'\n')
(o/'manifest.json').write_text(json.dumps({str(p.relative_to(o)):h(p.read_bytes()) for p in sorted(o.rglob('*')) if p.is_file() and p.name!='manifest.json'},indent=2)+'\n')
print(json.dumps({'patch_sha256':h((o/'review-correction.patch').read_bytes()),'pins_sha256':h((o/'candidate-pins.json').read_bytes())},indent=2))
