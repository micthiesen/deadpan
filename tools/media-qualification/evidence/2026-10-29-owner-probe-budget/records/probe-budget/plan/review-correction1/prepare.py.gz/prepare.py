from pathlib import Path
import hashlib,json
o=Path('/tmp/deadpan-owner-probe-budget-2026-10-29/plan/review-correction1');r=Path('/Users/michael/Code/deadpan')
names=['audio_owner_probe.rs','audio_owner_probe_tests.rs','audio_owners/legacy_snapshot_v1/capture_baseline.rs']
pins={}
for name in names:
 rel=Path('crates/deadpan-plan/src')/name;b=(r/rel).read_bytes();pins[str(rel)]=hashlib.sha256(b).hexdigest()
 for d in ['before','candidate']:
  p=o/d/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b)
(o/'before-pins.json').write_text(json.dumps(pins,indent=2)+'\n')
p=o/'candidate/crates/deadpan-plan/src/audio_owner_probe.rs';s=p.read_text()
s=s.replace('''    pub fn into_shared_admitted<A: AudioSoundContextAdmission<Issuer = I, Lease = L>>(
        self,''','''    pub fn into_shared_admitted<A: AudioSoundContextAdmission<Issuer = I, Lease = L>>(
        mut self,''')
needle='''        tracked::outer::<_, A>((|| {
            let mut shell = Owned {'''
assert s.count(needle)==1
s=s.replace(needle,'''        tracked::outer::<_, A>((|| {
            // Check the fixed Plan/budget issuer AND the actual stored Core
            // issuer/mode before any new work, reservation or shell allocation.
            // The unused real token changes neither receipt nor transfer state.
            budget.check_memory(&self.value._memory)?;
            drop(self.value.preflight_transfer(budget.admission)?);
            budget.check_memory(&self.value._memory)?;
            let mut shell = Owned {''')
needle='''            Err(Error::Policy(_)) => {}'''
assert s.count(needle)==1
s=s.replace(needle,'''            Err(Error::Policy(_)) => capture_baseline::probe_policy_refusal(
                input.context.plan,
                at,
                &editorial.value,
                editorial.memory.lease.is_some(),
                (limits.maximum_work, budget.remaining),
            ),''')
p.write_text(s)
p=o/'candidate/crates/deadpan-plan/src/audio_owners/legacy_snapshot_v1/capture_baseline.rs';s=p.read_text()
needle='pub(in crate::plan) fn probe_result('
assert s.count(needle)==1
s=s.replace(needle,'''/// Borrow the actual caller-owned output on a POLICY failure, before cleanup.
/// It is deliberately not serialized as PlanError or as successful None.
pub(in crate::plan) fn probe_policy_refusal(
    plan:&RenderPlan, at:AudioSample, captured:&EditorialCapture,
    charged:bool, work:(usize,usize),
) {
    if !active() { return; }
    record(json!({
        "kind":"actual_retained_probe_policy_refusal","at":at.0,
        "editorial":editorial(plan,captured),"editorial_charged":charged,
        "budget_before":work.0,"budget_remaining":work.1,
        "actual_probe_work_spent":work.0-work.1,
        "attestation":"actual caller-owned editorial output before typed policy failure cleanup",
    }));
}
'''+needle)
p.write_text(s)
p=o/'candidate/crates/deadpan-plan/src/audio_owner_probe_tests.rs';s=p.read_text()
s=s.replace('''    epoch: u64,
    weak:''','''    epoch: u64,
    issuer_calls:usize,
    flip_at:Option<usize>,
    fail_reservation:Option<usize>,
    weak:''')
s=s.replace('''        (Rc::as_ptr(&self.0), self.0.borrow().epoch)''','''        let mut state=self.0.borrow_mut();
        state.issuer_calls+=1;
        if state.flip_at==Some(state.issuer_calls) { state.epoch+=1; }
        (Rc::as_ptr(&self.0), state.epoch)''')
s=s.replace('''        s.calls += 1;
        let live''','''        s.calls += 1;
        if s.fail_reservation==Some(s.calls) {
            return Err(PlanError::AudioQueryLimit("probe test scheduled refusal"));
        }
        let live''')
p.write_text(s)
