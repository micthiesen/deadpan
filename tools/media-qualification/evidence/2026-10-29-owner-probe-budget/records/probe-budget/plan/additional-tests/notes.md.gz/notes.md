# Private retained handoff delta

Two files against the current live first Plan candidate. Before bytes checked
equal first-compile snapshot and live at freeze. Initial first-compile patch,
source pins and manifest are unchanged. No live/scoped/index/Git writes,
Cargo/rustc or runtime claims. Scoped rustfmt and patch dry-run passed.

The tiny production structural change extracts the SAME allocation-free unique
Arc initializer into a private function. No callbacks, allocations, public Weak,
Option/mutable escape or new source/probe operation are introduced. Production
still performs its admitted shell reservation and allocation at the same site,
then invokes the initializer inside the same Core map. The private test module
can observe its own backing Arc after initialization.

Four initial tests:
1. Public actual admitted probe -> final share, plus plain retained final share:
   Weak witness must be dead before every nonzero owned Plan/Core charge Drop.
   Plain final sharing asserts exactly one reservation and exact published
   Arc<Option<Retained>> layout, with zero leftover charge.
2. The real admitted probe's actual Core value is mapped using the SAME private
   initializer. Only AFTER guaranteed-unique initialization the private test adds
   a weak witness and changes the policy issuer. Core's real post-map validation
   rejects it; actual initialized Retained must die before both Core and Plan
   charges. This is an actual guard/initializer seam test, not a claim that the
   whole public final-sharing entry is fault-injected at that exact phase.
3. Public actual admitted probe succeeds, then remaining cap is set to exactly
   one byte short of its actual final Arc layout. Shell refusal consumes/drops
   the real graph and releases charge without refunding prior work.
4. Existing two-lane compatibility transfer rejects a guarded Core carrier
   before callback or any counter/reservation changes.

Actual late populated-editorial-slot policy refusal and a joint nonempty Sound
combination remain separate follow-up tests, not claimed in this delta. The
parent owns real four-lane numerical ledger/Graph/native/PCM integration tests.
