from pathlib import Path
import hashlib,json,difflib,subprocess
o=Path('/tmp/deadpan-owner-probe-budget-2026-10-29/plan/additional-tests')
r=Path('/Users/michael/Code/deadpan')
h=lambda b:hashlib.sha256(b).hexdigest()
before={};after={};patch=[]
for p in sorted((o/'candidate').rglob('*.rs')):
 rel=p.relative_to(o/'candidate')
 subprocess.run(['rustfmt','--edition','2024','--config','skip_children=true',str(p)],check=True)
 src=r/rel
 a=src.read_bytes() if src.exists() else b''
 if src.exists():
  old=Path('/tmp/deadpan-owner-probe-budget-2026-10-29/plan/first-compile/candidate')/rel
  assert a==old.read_bytes(),f'current live differs from first snapshot: {rel}'
  q=o/'before'/rel;q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(a)
 b=p.read_bytes();assert b!=a
 before[str(rel)]=h(a) if src.exists() else None;after[str(rel)]=h(b)
 patch+=list(difflib.unified_diff(a.decode().splitlines(True),b.decode().splitlines(True),
    fromfile='a/'+str(rel) if src.exists() else '/dev/null',tofile='b/'+str(rel)))
(o/'additional-tests.patch').write_text(''.join(patch))
(o/'before-pins.json').write_text(json.dumps(before,indent=2)+'\n')
(o/'candidate-pins.json').write_text(json.dumps(after,indent=2)+'\n')
(o/'manifest.json').write_text(json.dumps({str(p.relative_to(o)):h(p.read_bytes()) for p in sorted(o.rglob('*')) if p.is_file() and p.name!='manifest.json'},indent=2)+'\n')
print(json.dumps({'patch_sha256':h((o/'additional-tests.patch').read_bytes()),'pins_sha256':h((o/'candidate-pins.json').read_bytes())},indent=2))
