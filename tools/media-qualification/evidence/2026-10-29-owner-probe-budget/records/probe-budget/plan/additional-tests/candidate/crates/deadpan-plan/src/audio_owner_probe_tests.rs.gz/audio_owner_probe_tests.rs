//! Private backing-Arc destruction and actual Core post-map error regression.
use super::*;
use deadpan_core::ProjectDocument;
use std::{alloc::Layout, cell::RefCell, rc::Rc, sync::Weak};

#[derive(Default)]
struct Counts<'plan> {
    live: usize,
    peak: usize,
    cap: usize,
    calls: usize,
    work: usize,
    epoch: u64,
    weak: Option<Weak<Option<AudioOwnerRetainedInput<'plan>>>>,
    assert_dead: bool,
}
struct Policy<'plan>(Rc<RefCell<Counts<'plan>>>);
struct Lease<'plan> {
    state: Rc<RefCell<Counts<'plan>>>,
    bytes: usize,
}
impl Drop for Lease<'_> {
    fn drop(&mut self) {
        if self.bytes == 0 {
            return;
        }
        let mut state = self.state.borrow_mut();
        if state.assert_dead {
            assert!(
                state.weak.as_ref().unwrap().upgrade().is_none(),
                "actual retained Arc must die before every live Plan/Core lease"
            );
        }
        state.live -= self.bytes;
    }
}
impl<'plan> AudioSoundContextAdmission for Policy<'plan> {
    type Error = PlanError;
    type Issuer = (*const RefCell<Counts<'plan>>, u64);
    type Lease = Lease<'plan>;
    fn issuer(&self) -> Self::Issuer {
        (Rc::as_ptr(&self.0), self.0.borrow().epoch)
    }
    fn spend(&mut self, n: usize) -> std::result::Result<(), PlanError> {
        self.0.borrow_mut().work += n;
        Ok(())
    }
    fn reserve(&mut self, layout: Layout) -> std::result::Result<Self::Lease, PlanError> {
        let mut s = self.0.borrow_mut();
        s.calls += 1;
        let live = s.live.checked_add(layout.size()).unwrap();
        if live > s.cap {
            return Err(PlanError::AudioQueryLimit("probe test residency"));
        }
        s.live = live;
        s.peak = s.peak.max(live);
        Ok(Lease {
            state: Rc::clone(&self.0),
            bytes: layout.size(),
        })
    }
    fn merge(&mut self, a: &mut Self::Lease, b: &mut Self::Lease) {
        assert!(Rc::ptr_eq(&a.state, &self.0) && Rc::ptr_eq(&b.state, &self.0));
        a.bytes += b.bytes;
        b.bytes = 0;
    }
}
fn policy<'plan>(cap: usize) -> Policy<'plan> {
    Policy(Rc::new(RefCell::new(Counts {
        cap,
        ..Default::default()
    })))
}
fn fixture() -> RenderPlan {
    let frozen: serde_json::Value = serde_json::from_str(include_str!(
        "../tests/fixtures/owner-capture-baseline-v1/snapshot.json"
    ))
    .unwrap();
    let f = frozen["fixtures"]
        .as_array()
        .unwrap()
        .iter()
        .find(|v| v["fixture"] == "nonunity_shift_fractional_point_ceil_source44100")
        .unwrap();
    RenderPlan::compile(&ProjectDocument::from_json(&f["document"].to_string()).unwrap()).unwrap()
}
fn input(plan: &RenderPlan) -> AudioOwnerInput<'_> {
    let candidates = plan
        .audio_owner_input_candidates_at(AudioSample(0), Default::default())
        .unwrap();
    let member = candidates.query().spans()[0]
        .owners()
        .iter()
        .position(|v| v.instance().node.as_str() == "voice")
        .unwrap();
    candidates
        .capture(member, Default::default())
        .unwrap()
        .into_input()
        .unwrap()
}
#[test]
fn guarded_and_plain_final_shells_drop_actual_arc_before_each_lease() {
    let plan = fixture();
    let input = input(&plan);
    let at = AudioSample(0);
    let mut p = policy(usize::MAX);
    let probe = input
        .retained_probe_at_admitted(at, Default::default(), &mut p)
        .unwrap();
    let original = probe
        .into_shared_admitted(Default::default(), &mut p)
        .unwrap();
    assert!(original.leases()[0].is_some() && original.leases()[1].is_some());
    p.0.borrow_mut().weak = Some(Arc::downgrade(&original.retained().unwrap().0));
    p.0.borrow_mut().assert_dead = true;
    let work = p.0.borrow().work;
    drop(original);
    assert_eq!(p.0.borrow().live, 0);
    assert_eq!(p.0.borrow().work, work);

    let plain = input
        .retained_probe_at(at, Default::default())
        .unwrap()
        .into_input()
        .unwrap();
    let layout =
        crate::audio_allocated::admission::arc::<Option<AudioOwnerRetainedInput<'_>>>().unwrap();
    let mut p = policy(layout.size());
    let original = plain
        .into_shared_admitted(Default::default(), &mut p)
        .unwrap();
    assert_eq!(p.0.borrow().calls, 1);
    assert_eq!(p.0.borrow().peak, layout.size());
    assert_eq!(p.0.borrow().live, layout.size());
    p.0.borrow_mut().weak = Some(Arc::downgrade(&original.retained().unwrap().0));
    p.0.borrow_mut().assert_dead = true;
    drop(original);
    assert_eq!(p.0.borrow().live, 0);
}
#[test]
fn actual_core_post_map_rejection_drops_initialized_retained_before_both_charge_layers() {
    let plan = fixture();
    let input = input(&plan);
    let mut p = policy(usize::MAX);
    let probe = input
        .retained_probe_at_admitted(AudioSample(0), Default::default(), &mut p)
        .unwrap();
    let spent = p.0.borrow().work;
    let state = Rc::clone(&p.0);
    let mut local = Budget {
        remaining: 65_536,
        lookup: LookupStats::default(),
    };
    let mut budget = QueryBudget::new(&mut local, &mut p);
    let mut shell = Owned {
        value: None,
        memory: budget.memory(),
    };
    budget
        .reserve(
            &mut shell.memory,
            crate::audio_allocated::admission::arc::<Option<AudioOwnerRetainedInput<'_>>>()
                .unwrap(),
        )
        .unwrap();
    shell.value = Some(Arc::new(None));
    // This test executes the real Core map of the actual probe value with the
    // SAME allocation-free initializer. Only after initialization, the test
    // inserts a weak witness and changes policy identity to exercise post-map.
    let result = probe.value.map(&mut budget, |retained| {
        let shared = initialize_shared(shell.value.take().unwrap(), retained);
        let mut state = state.borrow_mut();
        state.weak = Some(Arc::downgrade(&shared.0));
        state.assert_dead = true;
        state.epoch += 1;
        shared
    });
    assert!(matches!(
        result,
        Err(Error::Policy(PlanError::AudioMetadataIssuerMismatch))
    ));
    drop(shell);
    assert_eq!(p.0.borrow().live, 0);
    assert!(p.0.borrow().work >= spent);
}
#[test]
fn accepted_probe_arc_refusal_releases_inner_graph_without_refunding_work() {
    let plan = fixture();
    let input = input(&plan);
    let mut p = policy(usize::MAX);
    let probe = input
        .retained_probe_at_admitted(AudioSample(0), Default::default(), &mut p)
        .unwrap();
    let spent = p.0.borrow().work;
    let live = p.0.borrow().live;
    let shell =
        crate::audio_allocated::admission::arc::<Option<AudioOwnerRetainedInput<'_>>>().unwrap();
    p.0.borrow_mut().cap = live + shell.size() - 1;
    assert!(matches!(
        probe.into_shared_admitted(Default::default(), &mut p),
        Err(PlanError::AudioQueryLimit("probe test residency"))
    ));
    assert_eq!(p.0.borrow().live, 0);
    assert!(p.0.borrow().work > spent);
}
#[test]
fn legacy_two_lane_transfer_refuses_guarded_core_before_callback() {
    let plan = fixture();
    let input = input(&plan);
    let mut p = policy(usize::MAX);
    let probe = input
        .retained_probe_at_admitted(AudioSample(0), Default::default(), &mut p)
        .unwrap();
    let mut original = probe
        .into_shared_admitted(Default::default(), &mut p)
        .unwrap();
    let before = (p.0.borrow().live, p.0.borrow().calls, p.0.borrow().work);
    let mut called = false;
    assert!(matches!(
        crate::plan::audio_domain::transfer_context_charges(
            p.issuer(),
            Some(&mut original),
            None,
            |_, _| called = true
        ),
        Err(PlanError::InvalidPlan(
            "guarded retained context requires preflight transfer"
        ))
    ));
    assert!(!called);
    assert_eq!(
        (p.0.borrow().live, p.0.borrow().calls, p.0.borrow().work),
        before
    );
    drop(original);
    assert_eq!(p.0.borrow().live, 0);
}
