# First compile snapshot

Scratch-only against the actual current Plan source, base parent checkpoint
4b95ee6a6f5fb3bd28373db6782618707376602c. Every changed existing before byte
was verified against live during freeze. Fifteen changed files, four new.
No Cargo/rustc, live/scoped/index/Git mutation or runtime result is claimed.
Only scoped rustfmt parsing and patch dry-run have run.

## Actual behavior and ownership

The same complete generic walker now supports independently guarded editorial
output. Its editorial Vec MOVES at the old assignment; constraints and repeats
copy at that site under the original canonical aggregate. The actual copied
constraint payload and editorial payload/capacity have separate lanes.
Constraint workspace and seeded-gap workspace die when the complete walk returns;
only actual span and moved editorial/raw-domain metadata reach the probe result.
Per-container cleared owning-edge bounds in raw-domain replacement and existing
boundary constructors remain conservative, documented bounds, not minimum heap.

Existing plain retained_probe_at orchestration and observer remain for compatibility.
The admitted entry invokes the SAME actual walker and SAME raw-domain constructors,
with identical stops/seed/support/limit order and a separate sealed owning result.
There is no second discovery/owner query/probe, public signal clone or reconstruction.
Both false paths use the same unmetered constructor backend and have old canonical
receipts. The initial full 16-case tests compare complete returned/discarded fields.

Only actual Stage(Bound) constructs raw_domain. All other complete returned spans
drop before successful positive-work None. Policy errors remain typed; observer
does not coerce policy failures to Plan errors/absence. Root/Point constructors
are in the frozen constructors subtask included here; physical placement and
scalar error/copy/replacement order are preserved. Additional inspections consume
the same probe's remaining budget; canonical raw construction remains zero.

GuardedBound<Option<Retained>> owns actual processing/Core plus editorial/raw Plan
charge through actual retained-owner/boundary decision (parent Audio wiring).
Accepted .into_shared_admitted reserves actual Arc<Option<Retained>> layout at
the final sharing point and initializes ONE private unique Arc in the existing
allocation-free Core map. The SAME bound Box/value moves; no retained deep clone.
The nongeneric shared handle exposes only Clone/Deref/ptr_eq/as_ptr and no weak,
mutable or Option API. Context carrier retains Core guard until joint transfer.

Original leases() exposes [Plan,Core lease,Core buffer]; preflight token exposes
[Original Plan,Core lease,Core buffer,Sound Plan]. The policy borrow ends during
preflight. One commit callback is allocation-free/infallible and wraps Core commit,
with no fallible transfer or validation after a partial publication. The old
two-lane compatibility transfer explicitly rejects guarded Core context before
calling its callback. Parent owns actual four-lane Audio arithmetic/publication.

## Initial tests and deliberate pending coverage

Three constructor tests cover actual Root and fractional Point parity/peak/refusal.
New probe tests cover all 16 old cases in both modes, old canonical P + additional
host reconciliation, full actual span/editorial/returned fields, literal published
Point private supplement, exact peak/one-byte-short/cancellation cleanup, accepted
same bound Box identity, foreign policy preflight/no new reservation, unused token,
policy-borrow-ended and committed Core reuse rejection.

True normalization names only existing Core resolved.work and lattice.work paths:
outer receipt exactly explains root total/canonical/additional; nested delta is
only asserted nonnegative and bounded by outer additional. No product field edits,
blanket work erasure, new category API or changed expected golden.

Further tests of private backing-Arc Weak/drop ordering, exact late editorial-slot
failure, accepted shell refusal and four-lane sound combinations can be a separate
delta after first compiler feedback. No claim those have run or been completed.

## Integration

Parent owns audio_domain.rs reexport line, Plan lib.rs/plan.rs barrels and all Audio.
Reexport new handle from audio_context_sharing and admitted probe from owner_input.
Parent Core token patch must be present. Frozen constructors require the included
visibility-only validate_physical_placement change. No other definition behavior changes.

Retained-owner query, caller keys, Node Vec/other graph containers and recursive
cold closure remain excluded. No cache/cap/native bound/weight/refund/retry changes.
No Empty branch fixture or other provider coverage is claimed.
