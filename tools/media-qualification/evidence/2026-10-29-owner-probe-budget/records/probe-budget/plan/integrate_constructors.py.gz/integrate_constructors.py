from pathlib import Path
import json,hashlib
o=Path('/tmp/deadpan-owner-probe-budget-2026-10-29/plan');c=o.parent/'constructors'
pins=json.loads((o/'before-pins.json').read_text())
for p in (c/'candidate').rglob('*.rs'):
 rel=p.relative_to(c/'candidate');target=o/'candidate'/rel;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(p.read_bytes())
 b=c/'before'/rel
 if b.exists():
  target=o/'before'/rel;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(b.read_bytes());pins[str(rel)]=hashlib.sha256(b.read_bytes()).hexdigest()
(o/'before-pins.json').write_text(json.dumps(pins,indent=2)+'\n')
