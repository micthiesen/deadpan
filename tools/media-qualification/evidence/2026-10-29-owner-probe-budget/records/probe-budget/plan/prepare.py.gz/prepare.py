from pathlib import Path
import hashlib,json
root=Path('/Users/michael/Code/deadpan'); out=Path('/tmp/deadpan-owner-probe-budget-2026-10-29/plan')
files=['audio.rs','audio_capture.rs','audio_capture_storage.rs','audio_owner_query_admission.rs','audio_bound_query.rs','audio_owner_input.rs','audio_context_sharing.rs','audio_domain.rs']
pins={}
for name in files:
 p=Path('crates/deadpan-plan/src')/name;b=(root/p).read_bytes();pins[str(p)]=hashlib.sha256(b).hexdigest()
 for d in ['before','candidate']:
  q=out/d/p;q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(b)
(out/'before-pins.json').write_text(json.dumps(pins,indent=2)+'\n')
