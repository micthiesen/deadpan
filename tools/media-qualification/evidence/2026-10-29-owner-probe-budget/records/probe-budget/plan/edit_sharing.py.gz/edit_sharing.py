from pathlib import Path
o=Path('/tmp/deadpan-owner-probe-budget-2026-10-29/plan/candidate/crates/deadpan-plan/src')
p=o/'audio_context_sharing.rs';s=p.read_text()
s=s.replace('//! Final Original sharing only. Source Input/query/capture/retained construction\n//! remains outside these new allocation reservations.','//! Final Original sharing. Admitted retained values keep their actual probe\n//! Core/Plan charges; plain retained sharing admits only its final shell.')
s=s.replace('use crate::{AdmittedSoundContext, AudioOwnerRetainedInput, AudioSoundContextAdmission};','use crate::{AdmittedSoundContext, AudioOwnerRetainedInput, AudioSoundContextAdmission};\nuse crate::plan::audio_owner_input::SharedAudioOwnerRetainedInput;\nuse crate::plan::audio_bound::query::{GuardedBound,GuardedChargeTransfer};\nuse crate::plan::audio_owners::admission::{self as tracked,outer};')
s=s.replace('shared_retained: Option<std::sync::Arc<AudioOwnerRetainedInput<\'plan>>>','shared_retained: Option<SharedAudioOwnerRetainedInput<\'plan>>')
s=s.replace("    values: Values<'plan>,\n    issuer: I,","    values: Values<'plan>,\n    guarded_retained: Option<GuardedBound<SharedAudioOwnerRetainedInput<'plan>,I,L>>,\n    issuer: I,",1)
s=s.replace('''            values: std::mem::take(&mut self.values),
            issuer: self.issuer,''','''            values: std::mem::take(&mut self.values),
            guarded_retained: None,
            issuer: self.issuer,''',1)
s=s.replace("scope.reserve(arc::<AudioOwnerRetainedInput<'plan>>()?)?;","scope.reserve(arc::<Option<AudioOwnerRetainedInput<'plan>>>()?)?;")
s=s.replace('''scope.values.shared_retained = Some(std::sync::Arc::new(
            scope.values.retained.take().expect("retained input"),
        ));''','''scope.values.shared_retained = Some(
            scope.values.retained.take().expect("retained input").into_shared(),
        );''')
s=s.replace('''    pub fn lease(&self) -> Option<&L> {
        self.charge.as_ref()
    }''','''    /// Original Plan metadata only; numerical publication uses all leases().
    pub fn lease(&self) -> Option<&L> {
        self.leases()[0]
    }
    pub fn leases(&self)->[Option<&L>;3] {
        match &self.guarded_retained {
            Some(value)=>value.charges(),
            None=>[self.charge.as_ref(),None,None],
        }
    }
    pub(in crate::plan) fn from_guarded(
        value:GuardedBound<SharedAudioOwnerRetainedInput<'plan>,I,L>,issuer:I,
    )->Self {
        Self {values:Values::default(),guarded_retained:Some(value),issuer,charge:None}
    }''')
s=s.replace('''    pub fn retained(&self) -> Option<&std::sync::Arc<AudioOwnerRetainedInput<'plan>>> {
        self.values.shared_retained.as_ref()
    }''','''    pub fn retained(&self) -> Option<&SharedAudioOwnerRetainedInput<'plan>> {
        self.guarded_retained.as_ref().map(|value| &**value)
            .or(self.values.shared_retained.as_ref())
    }''')
a=s.index('/// Validate ALL final-sharing issuers');z=s.index('\n#[cfg(test)]',a)
# compatibility transfer wrapper stays for legacy tests only with old2lane API;
# public Root will stop reexport, actual newnumeric only preflight.
old=s[a:z]
s=s[:a]+'''/// A value-tied token. Admission/controller borrows end during preflight.
pub struct ContextChargeTransfer<'value,'plan,I,L> {
    original: Option<GuardedChargeTransfer<'value,SharedAudioOwnerRetainedInput<'plan>,I,L>>,
    plain:Option<&'value mut L>,
    sound:Option<&'value mut L>,
}
impl<I:Copy+Eq,L> ContextChargeTransfer<'_,'_,I,L> {
    pub fn leases(&self)->[Option<&L>;4] {
        let [plan,lease,buffer]=self.original.as_ref().map_or(
            [self.plain.as_deref(),None,None],|value|value.leases(),
        );
        [plan,lease,buffer,self.sound.as_deref()]
    }
    /// Trusted consumer: one infallible, non-unwinding, allocation-free publication.
    pub fn commit(self,publish:impl FnOnce(Option<&mut L>,Option<&mut L>,Option<&mut L>,Option<&mut L>)) {
        match self.original {
            Some(value)=>value.commit(|plan,lease,buffer|publish(plan,lease,buffer,self.sound)),
            None=>publish(self.plain,None,None,self.sound),
        }
    }
}
pub fn preflight_context_transfer<'value,'plan,A:AudioSoundContextAdmission>(
    original:Option<&'value mut AdmittedOriginalContext<'plan,A::Issuer,A::Lease>>,
    sound:Option<&'value mut AdmittedSoundContext<'plan,A::Issuer,A::Lease>>,
    admission:&mut A,
)->Result<ContextChargeTransfer<'value,'plan,A::Issuer,A::Lease>,A::Error> {
    let issuer=admission.issuer();
    if original.as_ref().is_some_and(|value|value.issuer()!=issuer)
        || sound.as_ref().is_some_and(|value|value.issuer()!=issuer) {
        return Err(PlanError::AudioMetadataIssuerMismatch.into());
    }
    let mut plain=None;
    let original=match original {
        Some(value)=>match &mut value.guarded_retained {
            Some(value)=>Some(outer::<_,A>(value.preflight_transfer(admission))?),
            None=>{plain=value.charge.as_mut();None},
        },
        None=>None,
    };
    if admission.issuer()!=issuer {
        return Err(PlanError::AudioMetadataIssuerMismatch.into());
    }
    Ok(ContextChargeTransfer{original,plain,sound:sound.and_then(AdmittedSoundContext::lease_mut)})
}
''' +old+s[z:]
# Legacy old transfer must NOT silently ignore admitted Core. typed rejection.
s=s.replace('''    if original
        .as_ref()
        .is_some_and(|value| value.issuer() != issuer)''','''    if original.as_ref().is_some_and(|value|value.guarded_retained.is_some()) {
        return Err(PlanError::InvalidPlan("guarded retained context requires preflight transfer"));
    }
    if original
        .as_ref()
        .is_some_and(|value| value.issuer() != issuer)''')
s=s.replace('use crate::plan::audio_owners::admission::{self as tracked,outer};','use crate::plan::audio_owners::admission::outer;')
p.write_text(s)
# inner barrel owned, outer ones parent-owned
p=o/'audio_domain.rs';s=p.read_text().replace('pub use sharing::{AdmittedOriginalContext, transfer_context_charges};','pub use sharing::{AdmittedOriginalContext, ContextChargeTransfer, preflight_context_transfer, transfer_context_charges};');p.write_text(s)
p=o/'audio_owner_probe.rs';s=p.read_text().replace("pub struct SharedAudioOwnerRetainedInput<'plan>(pub(in crate::plan) Arc<Option<AudioOwnerRetainedInput<'plan>>>);","pub struct SharedAudioOwnerRetainedInput<'plan>(Arc<Option<AudioOwnerRetainedInput<'plan>>>);")
s+='''
impl<'plan,I:Copy+Eq,L> AdmittedAudioOwnerRetainedProbe<'plan,I,L> {
    /// Consume the SAME accepted Some. The actual owner/boundary decision must
    /// precede this one final Arc shell allocation.
    pub fn into_shared_admitted<A:AudioSoundContextAdmission<Issuer=I,Lease=L>>(
        self,limits:AudioQueryLimits,admission:&mut A,
    )->std::result::Result<crate::plan::audio_domain::AdmittedOriginalContext<'plan,I,L>,A::Error> {
        self.validate(admission)?;
        limits.validate()?;
        if self.input().is_none() {
            return Err(PlanError::InvalidPlan("cannot share absent retained probe").into());
        }
        let mut local=Budget {remaining:limits.maximum_work,lookup:LookupStats::default()};
        let mut budget=QueryBudget::new(&mut local,admission);
        tracked::outer::<_,A>((||{
            let mut shell=Owned{value:None,memory:budget.memory()};
            budget.additional(1)?;
            budget.reserve(&mut shell.memory,
                crate::audio_allocated::admission::arc::<Option<AudioOwnerRetainedInput<'plan>>>()?)?;
            shell.value=Some(Arc::new(None));
            let mut value=self.value.map(&mut budget,|retained|{
                let mut arc=shell.value.take().expect("prepared retained Arc shell");
                // Exactly one strong/no weak references; Arc has never escaped
                // this private slot. No policy callback sees/clones this Arc.
                *Arc::get_mut(&mut arc).expect("private unique retained Arc")=retained;
                SharedAudioOwnerRetainedInput(arc)
            })?;
            value.merge_memory(&mut shell.memory,&mut budget)?;
            let issuer=budget.issuer;
            Ok(crate::plan::audio_domain::AdmittedOriginalContext::from_guarded(value,issuer))
        })())
    }
}
'''
p.write_text(s)
