from pathlib import Path
out=Path('/tmp/deadpan-owner-probe-budget-2026-10-29/plan/candidate/crates/deadpan-plan/src')
p=out/'audio.rs';s=p.read_text()
s=s.replace('let (mut capture, editorial, owner) = captures;','let (mut capture, mut editorial, owner) = captures;\n        let mut editorial_slot = Owned {\n            value: editorial.as_deref_mut().map(std::mem::take).unwrap_or_default(),\n            memory: Memory::empty(()),\n        };')
s=s.replace('                editorial,\n                owner,','                if editorial.is_some() { Some(&mut editorial_slot) } else { None },\n                owner,')
s=s.replace('        admission::outer::<_, Unmetered>(result.map(capture::WalkResult::unmetered))','        if let Some(editorial) = editorial {\n            *editorial = editorial_slot.value;\n        }\n        admission::outer::<_, Unmetered>(result.map(capture::WalkResult::unmetered))')
p.write_text(s)
p=out/'audio_capture.rs';s=p.read_text()
s=s.replace('    value: GuardedBound<AudioWalkSpan', '    pub(in crate::plan) value: GuardedBound<AudioWalkSpan',1)
s=s.replace('    memory: Memory<I, L>,','    pub(in crate::plan) memory: Memory<I, L>,',1)
s=s.replace("Option<&'editorial mut EditorialCapture>","Option<&'editorial mut Owned<EditorialCapture, I, L>>")
s=s.replace('        let mut constraints_capacity = budget.memory();','        let mut constraints_memory = budget.memory();\n        let mut constraints_capacity = budget.memory();',1)
s=s.replace('        let mut editorial_capacity = budget.memory();','        let mut editorial_memory = budget.memory();\n        let mut editorial_capacity = budget.memory();',1)
# Actual copied container payloads are independently owned, not final workspace.
s=s.replace('                &seed.constraints,\n                &mut memory,','                &seed.constraints,\n                &mut constraints_memory,')
s=s.replace('                &seed.editorial,\n                &mut memory,','                &seed.editorial,\n                &mut editorial_memory,')
# Every mutable editorial append occurs through append helper receiving memory.
# Inspect exact sites separately after transformation.
s=s.replace('''            assert!(!A::METERED, "editorial output remains legacy-only");
            budget.canonical(editorial.len() + constraints.len() + repeats.len())?;
            *capture = EditorialCapture {
                editorial,
                constraints: constraints.clone(),
                repeats: repeats.clone(),
            };''','''            budget.canonical(editorial.len() + constraints.len() + repeats.len())?;
            let mut next = Owned {
                value: EditorialCapture::default(),
                memory: budget.memory(),
            };
            // Move the exact editorial vector at the old site. The copies
            // below retain the prepaid canonical aggregate above.
            budget.check_memory(&editorial_memory)?;
            budget.check_memory(&editorial_capacity)?;
            budget.merge_checked(&mut editorial_memory, &mut editorial_capacity);
            next.value.editorial = editorial;
            budget.merge_checked(&mut next.memory, &mut editorial_memory);
            next.value.constraints = storage::fixed(
                &constraints, &mut next.memory, budget, |v,m,b| b.constraint(m,v),
            )?;
            next.value.repeats = storage::fixed(
                &repeats, &mut next.memory, budget, |v,m,b| b.repeat(m,v),
            )?;
            budget.check_memory(&capture.memory)?;
            budget.check_memory(&next.memory)?;
            *capture = next;''')
p.write_text(s)
