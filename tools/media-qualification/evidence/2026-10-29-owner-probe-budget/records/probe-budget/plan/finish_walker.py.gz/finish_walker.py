from pathlib import Path
p=Path('/tmp/deadpan-owner-probe-budget-2026-10-29/plan/candidate/crates/deadpan-plan/src/audio_capture.rs')
s=p.read_text()
s=s.replace('        let mut seeded_gap = None;','        let mut gap_memory = budget.memory();\n        let mut seeded_gap = None;')
s=s.replace('seeded_gap = budget.gap(&mut memory, &seed.gap)?;','seeded_gap = budget.gap(&mut gap_memory, &seed.gap)?;')
s=s.replace('''.map(|v| budget.iteration(&mut memory, v))
                            .transpose()?,
                        kinds:''','''.map(|v| budget.iteration(&mut constraints_memory, v))
                            .transpose()?,
                        kinds:''')
s=s.replace('budget.iteration(&mut memory, &location.play.iteration)?\n                                    ),','budget.iteration(&mut constraints_memory, &location.play.iteration)?\n                                    ),')
s=s.replace('budget.own_iteration(&mut memory, &location.play.iteration)?;','''budget.own_iteration(
                        if location.in_gap && location.play.gap_child.is_none() {
                            &mut gap_memory
                        } else { &mut memory },
                        &location.play.iteration,
                    )?;''')
p.write_text(s)
