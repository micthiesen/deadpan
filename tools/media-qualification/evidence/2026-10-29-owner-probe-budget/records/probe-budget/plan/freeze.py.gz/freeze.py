from pathlib import Path
import json,hashlib,difflib,shutil,subprocess
o=Path('/tmp/deadpan-owner-probe-budget-2026-10-29/plan');r=Path('/Users/michael/Code/deadpan')
snap=o/'first-compile';snap.mkdir()
h=lambda b:hashlib.sha256(b).hexdigest()
paths=[];pins={};before={};patch=[]
for p in sorted((o/'candidate').rglob('*.rs')):
 rel=p.relative_to(o/'candidate');old=o/'before'/rel
 a=old.read_bytes() if old.exists() else b'';b=p.read_bytes()
 if a==b:continue
 if old.exists():assert (r/rel).read_bytes()==a, f'drift {rel}'
 paths.append(str(rel));pins[str(rel)]=h(b);before[str(rel)]=h(a) if old.exists() else None
 q=snap/'candidate'/rel;q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(b)
 if old.exists():
  q=snap/'before'/rel;q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(a)
 patch+=list(difflib.unified_diff(a.decode().splitlines(True),b.decode().splitlines(True),
  fromfile='a/'+str(rel) if old.exists() else '/dev/null',tofile='b/'+str(rel)))
(snap/'plan.patch').write_text(''.join(patch))
(snap/'candidate-pins.json').write_text(json.dumps(pins,indent=2)+'\n')
(snap/'before-pins.json').write_text(json.dumps(before,indent=2)+'\n')
(snap/'files.json').write_text(json.dumps(paths,indent=2)+'\n')
(snap/'manifest.json').write_text(json.dumps({str(p.relative_to(snap)):h(p.read_bytes()) for p in sorted(snap.rglob('*')) if p.is_file()},indent=2)+'\n')
print(json.dumps({'files':len(paths),'patch_sha256':h((snap/'plan.patch').read_bytes()),'pins_sha256':h((snap/'candidate-pins.json').read_bytes()),'manifest_sha256':h((snap/'manifest.json').read_bytes())},indent=2))
