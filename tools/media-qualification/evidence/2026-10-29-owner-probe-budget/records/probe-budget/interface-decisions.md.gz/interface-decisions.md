# Agreed implementation details after initial contract

- Parent owns only audio_domain.rs sharing reexport, in addition to lib.rs/
  plan.rs. Plan worker owns all other relevant constructor/probe/sharing logic.
- SharedAudioOwnerRetainedInput is defined in new audio_owner_probe.rs and
  reexported by audio_context_sharing.rs for the audio_domain barrel.
- Existing transfer_context_charges may remain as explicitly legacy/plain-only
  compatibility. It must reject guarded Core contexts before callback/mutation,
  with a regression. All actual numerical full-probe handoff uses the new token.
- No public weak API is added just for tests. Existing Audio retained weak/drop
  test moves to equivalent private Plan backing-Arc tests covering actual Core
  post-map/finalcarrier destruction before all leases. Audio retains real Graph
  cleanup, full billing and final-consumer peak/error tests.
- Core first compiler result: one ambiguous invalid helper in its new test due
  to two glob imports. Parent qualified super::invalid and formatted that test
  in both copies. Production API/body unchanged by the correction.
