from pathlib import Path
import hashlib,json,re
s=Path(__file__).resolve().parent
main=Path('/Users/michael/Code/deadpan')
scoped=Path('/tmp/deadpan-query-groundwork-2026-10-26/scoped')
sha=lambda b:hashlib.sha256(b).hexdigest()
negative={'probe-core-transfer':101,'probe-build2':101,'probe-build3':101,'probe-strict':1,'probe-split':101}
receipts=[]
for p in sorted(s.glob('*.json')):
 x=json.loads(p.read_text())
 if not isinstance(x,dict) or 'started_at' not in x or 'command' not in x:continue
 assert x.get('exit_code')==negative.get(p.stem,0),(p.stem,x.get('exit_code'))
 assert x['sources_unchanged'] and x['binaries_unchanged'],p.stem
 receipts.append({'label':p.stem,'exit_code':x['exit_code'],'seconds':x['seconds'],'source_inputs':len(x['source_before']),'sha256':sha(p.read_bytes())})
for label in ['probe-final2-build','probe-scoped-final2-build','probe-strict3','probe-final2-audio','probe-final2-stages','probe-definition','probe-scoped-audio','probe-scoped-stages','probe-scoped-birth','probe-scoped-plan-guarded','probe-split']:
 x=json.loads((s/(label+'.json')).read_text())
 for n,h in x['source_after'].items():
  data=Path(n).read_bytes()
  assert len(data)==h['bytes'] and sha(data)==h['sha256'],(label,n)
rows=json.loads((s/'task-source-pins.json').read_text())
data=(s/'index-blobs.bin').read_bytes();off=0;equal=[]
for row in rows:
 end=data.index(b'\n',off);head=data[off:end].decode().split();assert head[1]=='blob'
 length=int(head[2]);body=data[end+1:end+1+length];off=end+2+length
 assert body==(scoped/row['path']).read_bytes()
 assert sha(body)==row['sha256']
 assert sha((main/row['path']).read_bytes())==row['main_sha256']
 equal.append({'path':row['path'],'blob':head[0],'sha256':row['sha256'],'scoped_index_equal':True,'main_equal':row['main_equals_scoped']})
assert off==len(data) and len(rows)==30 and sum(x['main_equal'] for x in equal)==27
(s/'index-source-equality.json').write_text(json.dumps(equal,indent=2)+'\n')
first=json.loads((s/'probe-core-transfer.json').read_text())['source_before']
owned={str(main/x['path']) for x in rows}
owned.add(str(main/'crates/deadpan-audio/src/shared_eq/original_inputs.rs'))
unchanged=0
for n,h in first.items():
 if n in owned:continue
 b=Path(n).read_bytes()
 assert len(b)==h['bytes'] and sha(b)==h['sha256'],n
 unchanged+=1
for root in [main,scoped]:
 for n,h in [
 ('crates/deadpan-plan/tests/fixtures/owner-capture-baseline-v1/snapshot.json','32661e1a8abf59eb7d8146cd2898fd979415db3763685463df576d5e916d27c0'),
 ('crates/deadpan-plan/tests/fixtures/owner-probe-point-baseline-v1/supplement.json','169d589017e2b89818f2c06099164c056178888ed7e7ee663d611801f66b9d0a')]:
  assert sha((root/n).read_bytes())==h
equality=json.loads((s/'post-test-only-binary-equality.json').read_text())
assert equality['all29_plan_binaries_identical'] and not equality['stage_binary_identical']
results={}
for name in ['probe-final-build','probe-scoped-final2-build-scope-guarded']:
 rs=json.loads((s/'plan-results'/name/'results.json').read_text())
 assert len(rs)==29 and all(x['exit_code']==0 for x in rs)
 results[name]={'targets':29,'passed':sum(int(v[1]) for r in rs for v in r['test_results']),'ignored':sum(int(v[3]) for r in rs for v in r['test_results'])}
result={'all_terminal':True,'receipts':receipts,'source_files':30,'main_equal_source_files':27,'scoped_index_source_equality':True,'other_initial_guard_inputs_unchanged':unchanged,'immutable_baselines_unchanged':True,'all29_main_plan_binaries_identical_after_test_only_change':True,'stage_rebuild_changed_and_reran':True,'plan_results':results,'negative_results_retained':negative,'scoped_patch_sha256':sha((s/'task-scoped.patch').read_bytes()),'setup_notes':['probe-build1 compiled Core plus previous Plan/Audio after the application script failed; no full-candidate credit','probe-scoped-plan used scoped binaries with main cwd/source guards; repeated as probe-scoped-plan-guarded with scoped cwd and guards']}
(s/'final-audit.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k!='receipts'}))
