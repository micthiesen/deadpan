from pathlib import Path
import sys,json,subprocess,re,hashlib
s=Path(__file__).resolve().parent
label=sys.argv[1]
pins=json.loads((s/(label+'-pins.json')).read_text())
targets=[p for p in pins if p['package']=='plan']
assert len(targets)==29
out=s/'plan-results'/(label+'-scope-guarded')
out.mkdir(parents=True,exist_ok=False)
results=[]
for pin in targets:
 path=Path(pin['path'])
 assert hashlib.sha256(path.read_bytes()).hexdigest()==pin['sha256']
 command=[str(path),'--test-threads=1']
 completed=subprocess.run(command,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
 (out/(pin['name']+'.stdout')).write_bytes(completed.stdout)
 (out/(pin['name']+'.stderr')).write_bytes(completed.stderr)
 matches=re.findall(r'test result: ([^.]+)\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out',completed.stdout.decode())
 row={'target':pin['name'],'command':command,'exit_code':completed.returncode,'test_results':matches,'binary_sha256':pin['sha256']}
 results.append(row)
 print(json.dumps(row),flush=True)
 (out/'results.json').write_text(json.dumps(results,indent=2)+'\n')
assert all(hashlib.sha256(Path(p['path']).read_bytes()).hexdigest()==p['sha256'] for p in targets)
raise SystemExit(0 if all(r['exit_code']==0 for r in results) else 1)
