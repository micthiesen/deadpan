# Review of probe-baseline corrections

No remaining concrete findings in the two-file correction patch.

The normalized output paths are constrained by canonical parent directories before the v1 producer runs, and path comparison therefore catches aliases. The unchanged-v1 comparison now covers every non-runtime-varying top-level field. The branding regression identifies the exact ownership assertion and includes a one-node foreign Plan that would make premature index lookup fail differently. No source changes, builds, or tests were run by this reviewer.
