from pathlib import Path
import json,hashlib,subprocess,os,sys
s=Path(__file__).resolve().parent
build,kind,generation=sys.argv[1:]
assert kind in ['main','scoped'] and generation.isalnum()
receipt=json.loads((s/(build+'.json')).read_text());assert receipt['exit_code']==0 and receipt['sources_unchanged']
for p,pin in receipt['source_after'].items():
 b=Path(p).read_bytes();assert len(b)==pin['bytes'] and hashlib.sha256(b).hexdigest()==pin['sha256'],p
pins=json.loads((s/(build+'-pins.json')).read_text());assert len(pins)==1 and pins[0]['package']=='plan' and pins[0]['name']=='deadpan_plan'
pin=pins[0];assert hashlib.sha256(Path(pin['path']).read_bytes()).hexdigest()==pin['sha256']
authority=s/(kind+'-authority-'+generation+'.json');assert not authority.exists()
body={'schema':1,'base_revision':(s/'base-revision.txt').read_text().strip(),'build_receipt_sha256':hashlib.sha256((s/(build+'.json')).read_bytes()).hexdigest(),'executable_sha256':pin['sha256'],'source_inputs':receipt['source_after'],'claim':'Actual compiled old probe supplement observes borrowed private Point/Structural provider; logical/work/error only, not allocation peak qualification.'}
authority.write_text(json.dumps(body,indent=2)+'\n')
v1=s/(kind+'-legacy-'+generation+'.json');output=s/(kind+'-output-'+generation+'.json');assert not v1.exists() and not output.exists()
env=dict(os.environ)
env.update({'DEADPAN_OWNER_CAPTURE_OUTPUT':str(v1),'DEADPAN_OWNER_PROBE_OUTPUT':str(output),'DEADPAN_OWNER_CAPTURE_VARIANT':{'main':'main-inherited','scoped':'scoped-published'}[kind],'DEADPAN_OWNER_CAPTURE_SOURCE_SHA256':hashlib.sha256(authority.read_bytes()).hexdigest()})
command=['python',str(s/('run.py' if kind=='main' else 'run_scoped.py')),'--binary',pin['path'],'--binary',str(authority),'--binary',str(Path(__file__).resolve()),'probe-'+kind+'-'+generation,'--',pin['path'],'plan::audio_owners::tests::legacy_snapshot_v1::capture_baseline::probe_baseline::capture_legacy_point_probe_supplement_v1','--exact','--ignored','--test-threads=1','--nocapture']
raise SystemExit(subprocess.run(command,env=env).returncode)
