from pathlib import Path
d=Path('/tmp/deadpan-owner-probe-baseline-2026-10-29/plan/candidate/crates/deadpan-plan/src')
def edit(rel,old,new):
 p=d/rel;s=p.read_text();assert s.count(old)==1,(rel,s.count(old));p.write_text(s.replace(old,new))
edit('audio_point_domain.rs',"""impl<'plan> AudioPointDomain<'plan> {
    pub(super) fn set_evaluation(""","""impl<'plan> AudioPointDomain<'plan> {
    /// Test-only borrowed view of the ACTUAL returned object after evaluation
    /// replacement. This does not call signal(), clone or query its provider.
    #[cfg(test)]
    pub(in crate::plan) fn probe_baseline_snapshot(
        &self,
        expected_plan: &RenderPlan,
    ) -> serde_json::Value {
        assert!(self.belongs_to(expected_plan));
        let Self {
            plan: _, selector, root, placement, grid, sampling, samples, signal,
        } = self;
        serde_json::json!({
            "belongs_to_expected_plan":true,
            "selector":selector,
            "root":expected_plan.nodes[*root].inspection.id.as_str(),
            "placement":placement,
            "grid":grid,
            "sampling":sampling,
            "samples":samples,
            "structural_signal":signal.probe_baseline_snapshot(expected_plan),
        })
    }

    pub(super) fn set_evaluation(""")
edit('audio_signal.rs',"""impl crate::audio_allocated::OwnedHeap for AudioStage<'_> {""","""#[cfg(test)]
impl AudioSignal<'_> {
    /// Exhaustive private fields of this constructor's Structural signal only.
    /// An unexpected provider is rejected instead of silently omitting a graph.
    pub(in crate::plan) fn probe_baseline_snapshot(
        &self,
        expected_plan: &RenderPlan,
    ) -> serde_json::Value {
        assert!(self.belongs_to(expected_plan));
        let Self {
            plan: _, root, support, sampling_support, constrain_support, repeats,
            definition, placed_transform, bypass_binding, gap, provider,
        } = self;
        assert!(matches!(provider, SignalProvider::Structural),
            "actual raw PointCeil constructor must retain Structural provider");
        let bypass=bypass_binding.map(|target| match target {
            BindingTarget::Node(index)=>serde_json::json!({
                "tag":"Node","node":expected_plan.nodes[index].inspection.id.as_str(),
            }),
            BindingTarget::Gap(index)=>serde_json::json!({
                "tag":"Gap","node":expected_plan.nodes[index].inspection.id.as_str(),
            }),
        });
        serde_json::json!({
            "belongs_to_expected_plan":true,
            "root":expected_plan.nodes[*root].inspection.id.as_str(),
            "support":support,
            "sampling_support":sampling_support,
            "constrain_support":constrain_support,
            "repeats":repeats,
            "definition":definition,
            "placed_transform":placed_transform,
            "bypass_binding":bypass,
            "gap":gap,
            "provider":"Structural",
        })
    }
}

impl crate::audio_allocated::OwnedHeap for AudioStage<'_> {""")
edit('audio_owners/legacy_snapshot_v1/capture_baseline.rs',"""use std::cell::RefCell;

""","""use std::cell::RefCell;

#[path = "probe_baseline.rs"]
pub(in crate::plan) mod probe_baseline;

""")
edit('audio_owners/legacy_snapshot_v1/capture_baseline.rs','''        "retained_input":value.map(|v|v.capture_baseline_snapshot(expected_plan)),
    }));
}''','''        "retained_input":value.map(|v|v.capture_baseline_snapshot(expected_plan)),
    }));
    probe_baseline::returned_point(expected_plan,value,work);
}''')
