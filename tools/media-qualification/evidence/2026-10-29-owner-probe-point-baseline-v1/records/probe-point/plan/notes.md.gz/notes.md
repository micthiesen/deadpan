# Additive old-probe PointCeil oracle

Scratch-only prerequisite, not probe admission. Read next-probe-core.md and
next-probe-core-final-pins.json first; input-pin-audit.json verifies all22 final
pins against current live text before copying. No live/scoped/index/Git changes,
Cargo, rustc, native, provider or media operation. Parent owns all builds/runs.

## Four-file test-only patch

Three existing files:
- audio_point_domain.rs: cfg(test) exhaustive borrowed Point snapshot.
- audio_signal.rs: cfg(test) exhaustive borrowed Structural-signal snapshot.
- audio_owners/legacy_snapshot_v1/capture_baseline.rs: test-module declaration
  and one hook after the existing actual probe_result observation.

One new test-only child:
- audio_owners/legacy_snapshot_v1/probe_baseline.rs.

There is no production body, signature, API, dependency, allocator policy, query,
work limit or error-order change. The public signal() accessor remains untouched
and is never called by the observer.

## Actual source and identity

The hook borrows the actual optional AudioOwnerRetainedInput returned by the
existing retained_probe_at. For Some Point it borrows domain() and then the
private stored signal, after bound.raw_domain/set_evaluation already completed.
No copied signal, extra query/walk/probe or reconstructed domain is an oracle.

Point snapshot asserts belongs_to(caller_expected_plan) BEFORE using its root
index. Signal snapshot independently asserts its own belongs_to(expected_plan)
BEFORE root or bypass indices. Stable node IDs replace internal indices. These
are actual expected-Plan assertions, never self.belongs_to(self.plan).

Both structs are exhaustively destructured so added fields require a serializer
decision. Signal records all11 logical fields: brand, root, support,
sampling_support, constrain_support, repeats, definition, placed_transform,
bypass_binding, gap and provider. Point additionally records selector, physical
root, placement, exact reference grid/sampling/samples. ExactRatio already uses
normalized base10 numerator/denominator strings. No pointer, Debug/raw bytes,
capacity, time or allocation counter is semantic output.

The actual signal provider MUST be Structural. Any other provider fails this
constructor-specific observation; no Projected/Source/RequiresOwnedInput/Silence
graph coverage is claimed. This does not claim that the structural recipe can
always execute without a later admitted processor.

## Separate supplement mode, unchanged v1

The new ignored producer starts a separate thread-local Point collector and
invokes the EXISTING capture_legacy_owner_capture_baseline_v1 function itself.
That function performs the same existing16case actual captures and probes once
and writes its own fresh v1 compatibility file with create_new. The supplement
does NOT reimplement its fixture matrix or probe loop.

The collector is None outside the new explicit mode. With None, the added hook
returns before serialization/allocation. The existing probe_result's inactive
case guard returns even before the added hook. Per-thread RAII clears Point
state on normal completion and unwind; ordinary tests on other threads cannot
share it. V1's literal observations are not extended or rewritten.

After that one run, the supplement reads that actual v1 file and asserts its
schema/producer, full fixture array, supplemental documents/cases and ALL128
ordered events equal the immutable owner-capture-baseline-v1 Golden. It neither
rewrites the expected JSON nor regenerates expected legacy fields. Variant and
runtime authority are intentionally external run metadata, not compared to the
main variant in the immutable Golden.

Output schema OwnerProbePointSupplementV1 contains that complete actual v1 body
under legacy_v1 and a separate point_private_signals array. It asserts exactly
one returned Point in the unchanged16cases, case retained_point_voice, with the
same actual probe work and Structural provider. Parent must execute this fixture
assumption and compare both actual runtime variants before freezing the new
supplement Golden. This note claims no execution result.

The16cases have no exercised Empty raw domain. No fixture is fabricated or old
case changed to force it; output explicitly says Empty is not covered. This is
not a claim that Empty is globally unreachable.

## Ordinary regression

borrowed_point_private_snapshot_rejects_identical_foreign_plan builds the two
real identically compiled frozen documents, obtains actual Point Some through
the existing real query/Input/probe, checks all11 signal fields/Structural and
rejects a foreign expected Plan. It does not call signal() or replace a provider.
This independent ordinary test is not the one-shot oracle producer and is not
used to populate its expected data. It is authored but not run.

## Proposed actual producer invocation

Parent first compiles/pins the Plan --lib test binary and lists its tests to
confirm the exact fully qualified name. No Cargo command was executed here.

Set fresh distinct absolute /tmp paths; existing v1 rules validate its path too.
Set the source SHA to the actual parent-pinned runtime source authority, NOT this
note's hash. Use the real compiled executable through PATH/parent runner:

    DEADPAN_OWNER_CAPTURE_OUTPUT=/tmp/deadpan-owner-probe-main-v1.json
    DEADPAN_OWNER_PROBE_OUTPUT=/tmp/deadpan-owner-probe-main-supplement.json
    DEADPAN_OWNER_CAPTURE_VARIANT=main-inherited
    DEADPAN_OWNER_CAPTURE_SOURCE_SHA256=<actual_main_source_manifest_sha256>

Then run that pinned binary with these arguments:

    --exact plan::audio_owners::tests::legacy_snapshot_v1::capture_baseline::probe_baseline::capture_legacy_point_probe_supplement_v1 --ignored --test-threads=1

Repeat on scoped-published with a different pair of fresh output paths and its
actual source/executable authority. A broad --ignored filter could also run v1
directly and collide on environment paths; use --exact. Both outputs use
create_new and sync_all. On failure retain the partial receipt/files and choose
new paths for a corrected generation; do not overwrite the immutable old Golden.

Compare legacy_v1.fixtures/supplemental/events and point_private_signals arrays
across main/scoped. Variant and authority strings differ by design. Parent pins
the two generated files and executables, then publishes an ADDITIVE supplement.

## Limits

This is logical observation only. Its serializer allocates while observed
metadata is alive, so it is not evidence for admission peaks, native/RSS, drop
counters, complete probe ownership or cold closure. No new probe API, returned
charge handoff, raw-domain admission or Core move contract is implemented.
Scoped rustfmt parsing and patch dry-run are the only checks performed here.
