from pathlib import Path
import hashlib,json,difflib
r=Path('/Users/michael/Code/deadpan');s=Path('/tmp/deadpan-owner-probe-baseline-2026-10-29/plan')
sha=lambda b:hashlib.sha256(b).hexdigest()
files=[str(p.relative_to(s/'candidate')) for p in sorted((s/'candidate').rglob('*.rs'))]
patch=[];before={};final={}
for rel in files:
 a=s/'before'/rel;b=s/'candidate'/rel
 old=a.read_text() if a.exists() else '';new=b.read_text()
 assert old!=new,rel
 if a.exists():
  assert a.read_bytes()==(r/rel).read_bytes(),'live drift '+rel
  before[rel]=sha(a.read_bytes())
 final[rel]=sha(b.read_bytes())
 patch+=difflib.unified_diff(old.splitlines(True),new.splitlines(True),
   fromfile='a/'+rel if a.exists() else '/dev/null',tofile='b/'+rel)
(s/'probe-baseline.patch').write_text(''.join(patch))
(s/'before-pins.json').write_text(json.dumps(before,indent=2)+'\n')
(s/'candidate-pins.json').write_text(json.dumps(final,indent=2)+'\n')
(s/'owned-files.txt').write_text('\n'.join(files)+'\n')
sources=[]
for crate in ['deadpan-core','deadpan-plan']:
 sources +=[str(p.relative_to(r)) for p in sorted((r/'crates'/crate/'src').rglob('*.rs'))]
 sources +=['crates/'+crate+'/Cargo.toml']
sources+=['Cargo.toml','Cargo.lock','rust-toolchain.toml',
 'crates/deadpan-plan/tests/fixtures/owner-query-baseline-v1/snapshot.json',
 'crates/deadpan-plan/tests/fixtures/owner-capture-baseline-v1/snapshot.json',
 'crates/deadpan-audio/src/authored_eq.rs','crates/deadpan-audio/src/shared_eq/node_description.rs']
authority={p:sha((r/p).read_bytes()) for p in sorted(sources)}
(s/'source-authority-before.json').write_text(json.dumps(authority,indent=2)+'\n')
authority.update(final)
(s/'source-authority-candidate.json').write_text(json.dumps(authority,indent=2)+'\n')
manifest={p.name:sha(p.read_bytes()) for p in s.iterdir() if p.is_file()}
(s/'freeze-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps({'files':len(files),'new_files':len(files)-len(before),
 'patch':manifest['probe-baseline.patch'],'pins':manifest['candidate-pins.json'],
 'notes':manifest['notes.md']},indent=2))
