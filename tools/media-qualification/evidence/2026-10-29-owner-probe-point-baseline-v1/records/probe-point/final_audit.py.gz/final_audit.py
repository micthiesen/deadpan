from pathlib import Path
import json,hashlib
s=Path(__file__).resolve().parent;r=Path('/Users/michael/Code/deadpan');q=Path('/tmp/deadpan-query-groundwork-2026-10-26/scoped')
rows=json.loads((s/'task-source-pins.json').read_text());data=(s/'index-blobs.bin').read_bytes();off=0;equal=[]
for row in rows:
 end=data.index(b'\n',off);head=data[off:end].decode().split();length=int(head[2]);body=data[end+1:end+1+length];off=end+2+length
 assert head[1]=='blob' and hashlib.sha256(body).hexdigest()==row['sha256']
 assert body==(r/row['path']).read_bytes()==(q/row['path']).read_bytes(),row['path']
 equal.append({'path':row['path'],'blob':head[0],'sha256':row['sha256'],'all_three_equal':True})
assert off==len(data) and len(rows)==4
(s/'index-source-equality.json').write_text(json.dumps(equal,indent=2)+'\n')
receipts=[]
for p in sorted(s.glob('*.json')):
 x=json.loads(p.read_text())
 if not isinstance(x,dict) or 'started_at' not in x or 'command' not in x:continue
 assert x.get('exit_code')==(101 if p.stem=='probe-main-final-library' else 0),(p.stem,x.get('exit_code'))
 assert x['sources_unchanged'] and x['binaries_unchanged'],p.stem
 receipts.append({'label':p.stem,'exit_code':x['exit_code'],'seconds':x['seconds'],'source_inputs':len(x['source_before']),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()})
for label in ['probe-build3','probe-scoped-build3','probe-main-v3','probe-scoped-v3','probe-main-library3','probe-scoped-library3','probe-strict']:
 x=json.loads((s/(label+'.json')).read_text());assert x['exit_code']==0
 for name,pin in x['source_after'].items():
  b=Path(name).read_bytes();assert len(b)==pin['bytes'] and hashlib.sha256(b).hexdigest()==pin['sha256'],name
# Removing only the new cfg(test) block restores each complete original file.
for n,start,end in [
 ('crates/deadpan-plan/src/audio_point_domain.rs','    /// Test-only borrowed view','    pub(super) fn set_evaluation('),
 ('crates/deadpan-plan/src/audio_signal.rs',"#[cfg(test)]\nimpl AudioSignal<'_> {",'impl crate::audio_allocated::OwnedHeap for AudioStage')]:
 old=(s/'plan/before'/n).read_text();new=(r/n).read_text();a=new.index(start);b=new.index(end,a)
 assert new[:a]+new[b:]==old,n
authority=json.loads((s/'plan/source-authority-before.json').read_text());owned={x['path'] for x in rows};unchanged=0
for n,h in authority.items():
 if n in owned:continue
 assert hashlib.sha256((r/n).read_bytes()).hexdigest()==h,n
 unchanged+=1
goldens=json.loads((s/'published-golden-pins.json').read_text())
for n,pin in goldens.items():
 assert hashlib.sha256((r/n).read_bytes()).hexdigest()==pin['sha256'],n
 for x in receipts:
  receipt=json.loads((s/(x['label']+'.json')).read_text())
  assert str(r/n) not in receipt['source_before'] and str(q/n) not in receipt['source_before']
old=r/'crates/deadpan-plan/tests/fixtures/owner-capture-baseline-v1/snapshot.json'
assert hashlib.sha256(old.read_bytes()).hexdigest()=='32661e1a8abf59eb7d8146cd2898fd979415db3763685463df576d5e916d27c0'
assert json.loads((s/'comparison.json').read_text())['every_immutable_old_v1_field_equal']
result={'all_terminal':True,'receipts':receipts,'four_sources_equal_main_scoped_index':True,'production_bodies_of_both_runtime_files_unchanged':True,'capture_baseline_module_and_new_child_are_cfg_test_only':True,'other_authority_inputs_unchanged':unchanged,'published_supplement_separately_pinned_not_producer_input':True,'old_golden_unchanged':True}
(s/'final-audit.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'terminal_receipts':len(receipts),'other_authority_inputs_unchanged':unchanged,'source_files':4,'all_terminal':True}))
