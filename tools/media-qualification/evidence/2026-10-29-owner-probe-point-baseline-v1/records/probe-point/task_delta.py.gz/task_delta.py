from pathlib import Path
import json,difflib,hashlib
s=Path(__file__).resolve().parent;r=Path('/Users/michael/Code/deadpan');q=Path('/tmp/deadpan-query-groundwork-2026-10-26/scoped')
rows=[];patch=[]
for n in json.loads((s/'task-files.json').read_text()):
 before=s/'plan/before'/n;old=before.read_bytes() if before.exists() else b'';new=(r/n).read_bytes()
 assert new==(q/n).read_bytes(),n
 patch.extend(difflib.unified_diff(old.decode().splitlines(True),new.decode().splitlines(True),fromfile='a/'+n if before.exists() else '/dev/null',tofile='b/'+n))
 rows.append({'path':n,'before_sha256':hashlib.sha256(old).hexdigest() if before.exists() else None,'sha256':hashlib.sha256(new).hexdigest()})
(s/'task.patch').write_text(''.join(patch));(s/'task-source-pins.json').write_text(json.dumps(rows,indent=2)+'\n')
(s/'index-queries.txt').write_text(''.join(':'+x['path']+'\n' for x in rows))
print('Four-file source delta frozen, equal main/scoped.')
