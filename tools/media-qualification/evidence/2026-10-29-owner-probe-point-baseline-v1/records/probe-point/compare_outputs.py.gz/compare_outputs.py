from pathlib import Path
import json,hashlib,copy
s=Path(__file__).resolve().parent;repo=Path('/Users/michael/Code/deadpan')
old=repo/'crates/deadpan-plan/tests/fixtures/owner-capture-baseline-v1/snapshot.json'
assert hashlib.sha256(old.read_bytes()).hexdigest()=='32661e1a8abf59eb7d8146cd2898fd979415db3763685463df576d5e916d27c0'
frozen=json.loads(old.read_text())
def logical_v1(x):return {k:v for k,v in x.items() if k not in ['variant','runtime_source_manifest_sha256']}
def logical(x):
 y=copy.deepcopy(x)
 y.pop('variant');y.pop('runtime_source_manifest_sha256')
 y['legacy_v1']=logical_v1(y['legacy_v1'])
 return y
objects=[];pins=[]
for kind in ['main','scoped']:
 p=s/(kind+'-output-v3.json');x=json.loads(p.read_text())
 assert logical_v1(x['legacy_v1'])==logical_v1(frozen)
 assert x['variant']==x['legacy_v1']['variant']
 authority=s/(kind+'-authority-v3.json')
 assert x['runtime_source_manifest_sha256']==x['legacy_v1']['runtime_source_manifest_sha256']==hashlib.sha256(authority.read_bytes()).hexdigest()
 assert len(x['point_private_signals'])==1
 private=x['point_private_signals'][0];assert private['case']=='retained_point_voice' and private['work']==21 and private['point']['structural_signal']['provider']=='Structural'
 assert len(x['legacy_v1']['events'])==128
 objects.append(x)
 for p in [p,s/(kind+'-legacy-v3.json')]:pins.append({'path':str(p),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()})
assert logical(objects[0])==logical(objects[1])
for generation in ['v1','v2']:
 previous=json.loads((s/('main-output-'+generation+'.json')).read_text())
 assert logical(previous)==logical(objects[0])
result={'both_final_variants_equal_except_runtime_metadata':True,'every_immutable_old_v1_field_equal':True,'all_three_main_generations_same_logical_output':True,'case_count':16,'ordered_v1_events':128,'actual_private_point_results':1,'empty_raw_domain_coverage':False,'common_logical_sha256':hashlib.sha256(json.dumps(logical(objects[0]),sort_keys=True,separators=(',',':')).encode()).hexdigest(),'files':pins}
(s/'comparison.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
