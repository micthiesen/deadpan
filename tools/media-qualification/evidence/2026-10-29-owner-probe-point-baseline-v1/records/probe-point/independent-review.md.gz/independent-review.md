# Independent review: PointCeil probe baseline

1. Severity: Minor  
   crates/deadpan-plan/src/audio_owners/legacy_snapshot_v1/probe_baseline.rs:113  
   The output-path guard uses Path::starts_with without rejecting .. components or canonicalizing. A path such as /tmp/../../Users/michael/new-file.json passes the prefix check and create_new can create a file outside the promised scratch directory. Reject parent components and verify the canonical parent is inside /tmp before opening.

2. Severity: Minor  
   crates/deadpan-plan/src/audio_owners/legacy_snapshot_v1/probe_baseline.rs:130-135  
   The unchanged-v1 comparison omits immutable metadata fields ratio_integer_encoding, fixture_authority, and excluded. A change to one of those fields would be copied into legacy_v1 while the supplement still passes its "unchanged" check. Compare the full v1 body after removing only the intentionally varying variant and source-authority fields.

3. Severity: Minor  
   crates/deadpan-plan/src/audio_owners/legacy_snapshot_v1/probe_baseline.rs:99-102  
   The foreign-plan test accepts any panic, so it does not protect the required ownership-check-before-index ordering. The foreign plan is compiled from the identical document, so moving the check after index-based serialization can still pass. Use a foreign plan with an incompatible node layout and assert the panic is the ownership assertion, rather than an indexing panic.

No production logic defects found in the reviewed patch. The collector is inactive outside its explicit session, snapshots borrow the returned object and check plan identity before index use, and the one-shot producer reuses the existing v1 capture/probe path.
