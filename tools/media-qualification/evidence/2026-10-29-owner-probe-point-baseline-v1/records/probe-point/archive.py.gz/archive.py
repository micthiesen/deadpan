from pathlib import Path
import gzip,json,hashlib
s=Path(__file__).resolve().parent;repo=Path('/Users/michael/Code/deadpan')
dest=repo/'tools/media-qualification/evidence/2026-10-29-owner-probe-point-baseline-v1';assert not dest.exists()
audit=json.loads((s/'final-audit.json').read_text());assert audit['all_terminal']
prior=repo/'tools/media-qualification/evidence/2026-10-29-owner-capture-budget/inventory.json';prior_sha='30e69c811b475adcfc45110d01f250f6c0d9b180b349bc2a19eda617161c9211'
assert hashlib.sha256(prior.read_bytes()).hexdigest()==prior_sha
allowed={'.rs','.json','.py','.md','.patch','.stdout','.stderr','.txt'};rows=[];excluded=[]
for p in sorted(s.rglob('*')):
 if not p.is_file() or p.suffix not in allowed:continue
 name=str(p.relative_to(s))
 if name.startswith(('full-probe-handoff','handoff-')):
  excluded.append(name);continue
 data=p.read_bytes()
 if p.suffix=='.json':
  x=json.loads(data)
  if isinstance(x,dict) and 'command' in x and 'started_at' in x:assert 'exit_code' in x and x['sources_unchanged'] and x['binaries_unchanged']
 target=dest/'records/probe-point'/p.relative_to(s);target=target.with_name(target.name+'.gz');target.parent.mkdir(parents=True,exist_ok=True)
 packed=gzip.compress(data,mtime=0);target.write_bytes(packed)
 rows.append({'path':str(target.relative_to(dest)),'bytes':len(packed),'sha256':hashlib.sha256(packed).hexdigest(),'expanded_bytes':len(data),'expanded_sha256':hashlib.sha256(data).hexdigest()})
manifest={'schema_version':1,'base_revision':(s/'base-revision.txt').read_text().strip(),'scope':'Test-only additive actual returned PointCeil Structural AudioSignal observation after old probe set_evaluation. All old128 events/16cases and immutable v1 metadata remain identical, actual main/scoped outputs agree. Includes three review corrections and failed foreign-Source fixture run. Not probe admission, heap/native qualification or full resource closure. Future full-probe handoff design excluded.','prior_capture_admission_inventory':{'path':'../2026-10-29-owner-capture-budget/inventory.json','sha256':prior_sha},'published_goldens':json.loads((s/'published-golden-pins.json').read_text()),'excluded_future_design_files':excluded,'files':rows}
p=dest/'inventory.json';p.write_text(json.dumps(manifest,indent=2)+'\n')
for row in rows:
 b=(dest/row['path']).read_bytes();a=gzip.decompress(b)
 assert len(b)==row['bytes'] and hashlib.sha256(b).hexdigest()==row['sha256']
 assert len(a)==row['expanded_bytes'] and hashlib.sha256(a).hexdigest()==row['expanded_sha256']
print(json.dumps({'files':len(rows),'stored_bytes':sum(x['bytes'] for x in rows),'expanded_bytes':sum(x['expanded_bytes'] for x in rows),'inventory_sha256':hashlib.sha256(p.read_bytes()).hexdigest()}))
