//! Positive native admission controls for an ordinary Hold inside a fixed window.

use super::*;
use deadpan_core::{FrameRange, PauseLength, PitchPolicy, RetimePurpose, Subtree};

fn exercise(output: i64, mapping_start: i64, mapping_end: i64, cursor: i64) {
    let scratch = tempfile::tempdir().unwrap();
    let (service, mut opened, _) = setup_source(&scratch.path().join("Documents"));
    // Reuse the qualified Original preparation, undoing both fixture Repeats.
    for _ in 0..2 {
        opened = command(
            &service,
            ProjectRequest::Undo {
                expected_revision: opened
                    .workspace
                    .as_ref()
                    .unwrap()
                    .document
                    .revision_id()
                    .clone(),
            },
        );
    }
    let workspace = opened.workspace.as_ref().unwrap();
    assert!(matches!(
        workspace.single_source,
        Some(SingleSourceState::Ready { .. })
    ));
    assert_eq!(workspace.plan.duration().frames(), 120);
    let path = workspace.path.clone();
    let parent = workspace.document.root().clone();
    command(&service, ProjectRequest::Close);
    let rate = node("fixed-duration-rate");
    let body = node("fixed-duration-body");
    let selected = node("fixed-duration-hold");
    let lead = node("fixed-duration-lead");
    let tail = node("fixed-duration-tail");
    let mut wrapper = BeatNode::sequence("Fixed window", vec![]);
    wrapper.kind = NodeKind::Retime {
        child: body.clone(),
        duration: FrameDuration::new(output).unwrap(),
        mapping: FrameRange::new(ProjectFrame(mapping_start), ProjectFrame(mapping_end)).unwrap(),
        pitch: PitchPolicy::FollowSpeed,
        purpose: RetimePurpose::Edit,
    };
    let mut store = ProjectStore::open(&path, AccessMode::ReadWrite).unwrap();
    seed_command(
        &mut store,
        Command::Insert {
            parent,
            index: 0,
            subtree: Subtree {
                root: rate.clone(),
                nodes: BTreeMap::from([
                    (rate.clone(), wrapper.clone()),
                    (
                        body,
                        BeatNode::sequence(
                            "Interior",
                            vec![lead.clone(), selected.clone(), tail.clone()],
                        ),
                    ),
                    (lead, BeatNode::hold("Lead", hold(2))),
                    (
                        selected.clone(),
                        BeatNode::hold("Resize this pause", hold(8)),
                    ),
                    (tail, BeatNode::hold("Suffix", hold(10))),
                ]),
                overrides: BTreeMap::new(),
                gap_overrides: BTreeMap::new(),
            },
        },
        "fixed-duration-fixture",
    );
    drop(store);
    let opened = command(&service, ProjectRequest::Open(path.clone()));
    assert!(opened.error.is_none(), "{:?}", opened.error);
    let before = opened.workspace.as_ref().unwrap();
    before.document.validate().unwrap();
    assert!(
        before
            .document
            .nodes()
            .values()
            .all(|beat| !matches!(beat.kind, NodeKind::Repeat { .. }))
    );
    let picture = before.plan.picture(ProjectFrame(cursor)).unwrap();
    let presentation = picture
        .framing
        .iter()
        .find(|layer| layer.instance.node == selected)
        .expect("the interior cursor must actually display the selected Hold")
        .instance
        .clone();
    assert!(presentation.repeats.is_empty());
    let target = Target {
        session: before.session,
        navigation: 0,
        project: before.document.project_id().clone(),
        revision: before.document.revision_id().clone(),
        scope: SequenceScope::default(),
        root: rate.clone(),
        target: ScopedNodeTarget {
            node: selected.clone(),
            repeats: vec![],
        },
        presentation: Some(presentation),
        cursor: ProjectFrame(cursor),
        also: vec![],
    };
    target.validate(before).unwrap();
    let bank = stored_bank(&path);
    // This is the existing native capture path. The baseline must fail here,
    // after validity and visibility controls, rather than in fixture preparation.
    let context = context_for(&opened, &target);
    let changed = send(
        &service,
        Operation::Apply {
            id: id(&opened, 1),
            instruction: SemanticInstruction::SetHoldDuration {
                length: PauseLength::Frames {
                    frames: NonZeroU32::new(10).unwrap(),
                },
            },
            repeat_version: None,
            scope: target.scope.clone(),
            context,
        },
    );
    let after = changed.workspace.as_ref().unwrap();
    assert_eq!(
        after.document.nodes()[&rate],
        wrapper,
        "fixed mapping and output remain authored unchanged"
    );
    assert_eq!(after.plan.duration(), before.plan.duration());
    assert!(
        matches!(&after.document.nodes()[&selected].kind, NodeKind::Hold { recipe } if recipe.duration.frames() == 10)
    );
    assert_eq!(stored_bank(&path), bank);
    let undone = command(
        &service,
        ProjectRequest::Undo {
            expected_revision: after.document.revision_id().clone(),
        },
    );
    assert_same_content(
        &undone.workspace.as_ref().unwrap().document,
        &before.document,
    );
    command(&service, ProjectRequest::Close);
}

#[test]
fn native_ordinary_fixed_retime_hold_duration_admits_interior_capture() {
    exercise(20, 0, 20, 5);
}

#[test]
fn native_ordinary_fixed_retime_hold_duration_admits_cropped_fractional_visibility() {
    // The Hold's intrinsic start maps to -2/3; visible start is the crop at 0.
    // Its visible end maps to 14/3. Frame 2 is strictly inside that interval.
    exercise(10, 3, 18, 2);
}
