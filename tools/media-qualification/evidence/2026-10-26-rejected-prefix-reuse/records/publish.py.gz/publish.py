from pathlib import Path
import gzip,hashlib,json
scratch=Path(__file__).resolve().parent
out=Path('/Users/michael/Code/deadpan/tools/media-qualification/evidence/2026-10-26-rejected-prefix-reuse')
out.mkdir(parents=True,exist_ok=False)
sources=[p for p in sorted(scratch.iterdir()) if p.is_file() and p.suffix in ('.json','.stdout','.stderr','.patch','.py','.tar','.txt')]
entries=[]
for source in sources:
    raw=source.read_bytes()
    relative=Path('records')/(source.name+'.gz')
    encoded=gzip.compress(raw,compresslevel=9,mtime=0)
    path=out/relative
    path.parent.mkdir(parents=True,exist_ok=True)
    path.write_bytes(encoded)
    entries.append({'path':relative.as_posix(),'bytes':len(encoded),'sha256':hashlib.sha256(encoded).hexdigest(),'expanded_bytes':len(raw),'expanded_sha256':hashlib.sha256(raw).hexdigest()})
inventory={'schema_version':1,'base_revision':'96177140','scope':'Rejected owned-prefix PCM/sibling-tile prototype and exact restoration of inherited Split candidate. Candidate patch and untracked tar exclude foreign files. Tests/lint do not override full matrix regression. Executables excluded; copied identities retained. No acceptance credit.','files':entries}
(out/'inventory.json').write_text(json.dumps(inventory,indent=2)+'\n')
for entry in entries:
    encoded=(out/entry['path']).read_bytes(); raw=gzip.decompress(encoded)
    assert len(encoded)==entry['bytes'] and hashlib.sha256(encoded).hexdigest()==entry['sha256']
    assert len(raw)==entry['expanded_bytes'] and hashlib.sha256(raw).hexdigest()==entry['expanded_sha256']
print(json.dumps({'files':len(entries),'stored_bytes':sum(e['bytes'] for e in entries),'expanded_bytes':sum(e['expanded_bytes'] for e in entries),'inventory_sha256':hashlib.sha256((out/'inventory.json').read_bytes()).hexdigest(),'all_payloads_verified':True}))
