//! Real shared-prefix reuse across independently selected contributions.

use super::*;
use crate::stages::controlled_reads::{Provider, fixture_document_at_rate};
use deadpan_core::*;

fn id(value: &str) -> NodeId {
    NodeId::new(value).unwrap()
}

fn sound() -> SoundId {
    SoundId::new("effect").unwrap()
}

fn control<'a>(cancelled: &'a AtomicBool, work: &'a RefCell<ReadWork>) -> WorkControl<'a> {
    WorkControl {
        cancelled,
        deadline: Instant::now() + Duration::from_secs(10),
        work,
    }
}

struct ContextProvider {
    inner: Provider,
    expected: AssetRecord,
    contextual: bool,
    invalid_context: bool,
    context_calls: usize,
}

impl AudioSourceProvider for ContextProvider {
    fn source(
        &mut self,
        project: &ProjectId,
        revision: &RevisionId,
        asset: &AssetId,
        cancelled: &AtomicBool,
    ) -> Result<&crate::PreparedSource, PreparationError> {
        self.inner.source(project, revision, asset, cancelled)
    }

    fn source_for_context(
        &mut self,
        project: &ProjectId,
        revision: &RevisionId,
        asset: &AssetId,
        expected: &AssetRecord,
        cancelled: &AtomicBool,
    ) -> Result<&crate::PreparedSource, PreparationError> {
        assert_eq!(expected, &self.expected, "complete retained contract");
        self.context_calls += 1;
        if self.invalid_context {
            return Err(PreparationError::InvalidSamples);
        }
        if !self.contextual {
            return Err(PreparationError::SourceUnavailable(
                "context revoked".into(),
            ));
        }
        self.inner.source(project, revision, asset, cancelled)
    }
}

/// A selected Original and sound enter the same saturator before an EQ. The
/// cache stores the prefix before that EQ, not independently saturated voices.
/// A clocked event on b is wholly outside the queried prefix block.
fn fixture(owner: &str, clocked: bool, muted: bool) -> (Arc<RenderPlan>, ContextProvider) {
    let rate = FrameRate::new(48_000, 1).unwrap();
    let (base, inner) = fixture_document_at_rate(rate);
    let source = SourceAudio {
        asset: AssetId::new("media").unwrap(),
        span: SourceSpan::new(
            SourceTimestamp {
                ticks: 20,
                time_base: SourceTimeBase::new(1, 48_000).unwrap(),
            },
            SourceTimestamp {
                ticks: 200,
                time_base: SourceTimeBase::new(1, 48_000).unwrap(),
            },
        )
        .unwrap(),
    };
    let event = BeatSound {
        label: "Independent effect".into(),
        mapping: SourceAudioMapping::natural_rate(source.span, rate).unwrap(),
        source,
        offset: AudioSample(13),
        treatments: AudioTreatments::default(),
        start_edge: AudioEdgePolicy::Hard,
        end_edge: AudioEdgePolicy::Hard,
        overflow: SoundOverflowPolicy::Reject,
    };
    let mut root = BeatNode::sequence("Shared root", vec![id("a"), id("b")]);
    root.audio_treatments = AudioTreatments::with_equalizer_stages(
        vec![
            AudioTreatmentStage::ClipGain,
            AudioTreatmentStage::Saturation,
            AudioTreatmentStage::Equalizer,
        ],
        Some(ClipGain::new(GainDb::new(3000).unwrap(), muted, vec![], vec![]).unwrap()),
        Some(Saturation::new(GainDb::new(9000).unwrap()).unwrap()),
        None,
        Some(
            EqualizerRecipe::new(
                [3000, 0, -3000].map(|v| GainDb::new(v).unwrap()),
                None,
                None,
            )
            .unwrap(),
        ),
    )
    .unwrap();
    let mut wire = serde_json::to_value(&base).unwrap();
    wire["nodes"] = serde_json::to_value(BTreeMap::from([
        (id("root"), root),
        (id("a"), base.nodes()[&id("a")].clone()),
        (id("b"), base.nodes()[&id("b")].clone()),
    ]))
    .unwrap();
    wire["assets"]["media"]["source_qualification"] = serde_json::json!("c".repeat(64));
    wire["beat_sounds"] = serde_json::to_value(BTreeMap::from([(
        id(owner),
        BTreeMap::from([(sound(), event)]),
    )]))
    .unwrap();
    let document = ProjectDocument::from_json(&wire.to_string()).unwrap();
    let document = if clocked {
        let timing = AudioTimingId {
            allocation: RevisionId::new("clock").unwrap(),
            ordinal: 0,
        };
        let bindings = AudioBindingState::new_with_sound_clocks(
            vec![AudioTimingRecord {
                id: timing.clone(),
                layout: FrozenAudioLayout::capture(&document).unwrap(),
            }],
            BTreeMap::new(),
            BTreeMap::new(),
            BTreeMap::from([(
                id(owner),
                BTreeMap::from([(
                    sound(),
                    SoundClockJournal::new(
                        id(owner),
                        vec![SoundClockReference::new(timing, id(owner), id(owner))],
                    )
                    .unwrap(),
                )]),
            )]),
        )
        .unwrap();
        let mut wire = serde_json::to_value(document).unwrap();
        wire["audio_bindings"] = serde_json::to_value(bindings).unwrap();
        ProjectDocument::from_json(&wire.to_string()).unwrap()
    } else {
        document
    };
    let expected = document.assets()[&AssetId::new("media").unwrap()].clone();
    (
        Arc::new(RenderPlan::compile(&document).unwrap()),
        ContextProvider {
            inner,
            expected,
            contextual: true,
            invalid_context: false,
            context_calls: 0,
        },
    )
}

fn new_graph<'plan>(
    plan: &'plan RenderPlan,
    renderer: &mut StageAudio,
    control: WorkControl<'_>,
) -> (Graph<'plan>, u64) {
    let slots = renderer.limits.maximum_cached_stages;
    let reserve = Cache::metadata_frames(slots).unwrap()
        + original_inputs::Cache::resident_frames().unwrap()
        + 128 * 3;
    renderer.make_room(reserve, false, control).unwrap();
    renderer.active_frames += reserve;
    let mut graph = Graph {
        plan,
        nodes: Vec::new(),
        resident: 0,
        wet_filters: std::array::from_fn(|_| None),
        event_tiles: BTreeMap::new(),
        event_nodes: Default::default(),
        event_filters: BTreeMap::new(),
        voices: BTreeMap::new(),
        permission_families: BTreeMap::new(),
        selected_family_count: 0,
        canonical_families: FamilyRegistry::default(),
        sends: None,
        skip: Vec::new(),
        original_only: false,
        original_inputs: original_inputs::Cache::default(),
        prefix_inputs: Some(Box::new(Cache::new(plan, slots, control).unwrap())),
    };
    assert_eq!(graph.voice(Voice::Original).unwrap(), 0);
    if let Some((owner, events)) = plan.beat_sounds().iter().next() {
        let event = events.keys().next().unwrap();
        assert_eq!(
            graph
                .voice(Voice::Beat(
                    owner.clone(),
                    event.clone(),
                    InstancePath {
                        node: owner.clone(),
                        repeats: vec![]
                    }
                ))
                .unwrap(),
            1
        );
    }
    let query = plan
        .audio_gain_owners(AudioSample(32)..AudioSample(33), Default::default())
        .unwrap();
    let root = query.spans()[0]
        .owners()
        .iter()
        .find(|owner| owner.instance().node == id("root"))
        .unwrap();
    let context = Contexts {
        original: Context::Root,
        sounds: Sounds::Root,
    };
    let parent = renderer
        .shared_eq_node(
            &mut graph,
            Program {
                context: &context,
                stop: None,
                allowed: None,
                output_voice: None,
                parent: usize::MAX,
                depth: 0,
            },
            root,
            AudioSample(32),
            Temporal::Equalizer(2),
            control,
        )
        .unwrap();
    assert_eq!(parent, 0);
    (graph, reserve)
}

fn mask(voices: &[usize]) -> Permissions {
    let mut result = Permissions::default();
    for &voice in voices {
        result.insert(voice).unwrap();
    }
    result
}

fn read(
    renderer: &mut StageAudio,
    provider: &mut ContextProvider,
    graph: &mut Graph<'_>,
    output: usize,
    control: WorkControl<'_>,
) -> Result<WideBlock, StageAudioError> {
    let context = graph.nodes[0].context.clone();
    let stop = graph.nodes[0].stop.clone();
    renderer.read_shared_program(
        provider,
        graph,
        Program {
            context: &context,
            stop: Some(&stop),
            allowed: Some(mask(&[0, 1])),
            output_voice: Some(output),
            parent: 0,
            depth: 1,
        },
        AudioSample(0),
        64,
        control,
    )
}

fn clean(graph: &mut Graph<'_>, renderer: &mut StageAudio, reserve: u64) {
    renderer.clear_shared_siblings(graph);
    graph.original_inputs.clear(renderer);
    graph.prefix_inputs.as_mut().unwrap().clear(renderer);
    renderer.active_frames -= reserve + graph.resident;
    assert!(renderer.shared_prefixes.is_empty());
    assert!(renderer.shared_siblings.is_empty());
    assert_eq!(renderer.active_frames, 0);
    assert_eq!(renderer.cached_resident_frames(), 0);
}

fn assert_same(actual: &WideBlock, expected: &WideBlock) {
    assert_eq!(
        actual
            .samples
            .iter()
            .map(|p| p.map(f64::to_bits))
            .collect::<Vec<_>>(),
        expected
            .samples
            .iter()
            .map(|p| p.map(f64::to_bits))
            .collect::<Vec<_>>()
    );
    assert_eq!(actual.suppressed, expected.suppressed);
    assert_eq!(actual.dependencies, expected.dependencies);
    assert_eq!(actual.relative_depth, expected.relative_depth);
}

#[test]
fn selected_outputs_reuse_one_complete_nonlinear_prefix_with_exact_pcm() {
    let (plan, mut provider) = fixture("a", true, false);
    let mut renderer = StageAudio::new(Arc::clone(&plan));
    let cancelled = AtomicBool::new(false);
    let work = RefCell::new(ReadWork::default());
    let control = control(&cancelled, &work);
    let (mut graph, reserve) = new_graph(&plan, &mut renderer, control);
    let before = work.borrow().plan_work;
    let original = read(&mut renderer, &mut provider, &mut graph, 0, control).unwrap();
    let first_work = work.borrow().plan_work - before;
    assert_eq!(renderer.shared_prefixes.len(), 1);
    let calls = provider.inner.calls;
    let contexts = provider.context_calls;
    let before = work.borrow().plan_work;
    let sound = read(&mut renderer, &mut provider, &mut graph, 1, control).unwrap();
    let hit_work = work.borrow().plan_work - before;
    assert_eq!(graph.prefix_inputs.as_ref().unwrap().hits, 1);
    assert!(provider.inner.calls > calls && provider.context_calls > contexts);
    assert!(hit_work < first_work, "first={first_work}, hit={hit_work}");
    assert_ne!(
        original.samples, sound.samples,
        "distinct contributions are not a total-bus substitute"
    );

    let (mut reference_graph, reference_reserve) = new_graph(&plan, &mut renderer, control);
    reference_graph.prefix_inputs = None;
    let reference = read(
        &mut renderer,
        &mut provider,
        &mut reference_graph,
        1,
        control,
    )
    .unwrap();
    assert_same(&sound, &reference);
    reference_graph.original_inputs.clear(&mut renderer);
    renderer.active_frames -= reference_reserve + reference_graph.resident;
    clean(&mut graph, &mut renderer, reserve);
}

#[test]
fn retained_admission_revocation_cannot_hide_behind_ordinary_source_access() {
    let (plan, mut provider) = fixture("a", true, false);
    let mut renderer = StageAudio::new(Arc::clone(&plan));
    let cancelled = AtomicBool::new(false);
    let work = RefCell::new(ReadWork::default());
    let control = control(&cancelled, &work);
    let (mut graph, reserve) = new_graph(&plan, &mut renderer, control);
    read(&mut renderer, &mut provider, &mut graph, 0, control).unwrap();
    assert_eq!(renderer.shared_prefixes.len(), 1);
    provider.contextual = false;
    let calls = provider.inner.calls;
    assert!(matches!(
        read(&mut renderer, &mut provider, &mut graph, 1, control),
        Err(StageAudioError::Preparation(
            PreparationError::SourceUnavailable(_)
        ))
    ));
    assert!(
        provider.inner.calls > calls,
        "ordinary source lookup still succeeds"
    );
    assert_eq!(graph.prefix_inputs.as_ref().unwrap().hits, 0);
    clean(&mut graph, &mut renderer, reserve);
}

#[test]
fn conservative_clocked_asset_probe_falls_back_when_that_event_is_outside_the_block() {
    let (plan, mut provider) = fixture("b", true, false);
    let mut renderer = StageAudio::new(Arc::clone(&plan));
    let cancelled = AtomicBool::new(false);
    let work = RefCell::new(ReadWork::default());
    let control = control(&cancelled, &work);
    let (mut graph, reserve) = new_graph(&plan, &mut renderer, control);
    let expected = read(&mut renderer, &mut provider, &mut graph, 0, control).unwrap();
    assert_eq!(provider.context_calls, 0, "the later sound is not prepared");
    provider.contextual = false;
    let actual = read(&mut renderer, &mut provider, &mut graph, 0, control).unwrap();
    assert_same(&actual, &expected);
    assert!(
        provider.context_calls > 0,
        "cache probed its conservative source set"
    );
    assert_eq!(
        graph.prefix_inputs.as_ref().unwrap().hits,
        0,
        "refusal discarded the optional payload"
    );
    clean(&mut graph, &mut renderer, reserve);
}

#[test]
fn prefix_identity_requires_exact_parent_context_range_permissions_and_depth() {
    let (plan, _) = fixture("a", false, false);
    let mut renderer = StageAudio::new(Arc::clone(&plan));
    let cancelled = AtomicBool::new(false);
    let work = RefCell::new(ReadWork::default());
    let control = control(&cancelled, &work);
    let (mut graph, reserve) = new_graph(&plan, &mut renderer, control);
    let context = graph.nodes[0].context.clone();
    let stop = graph.nodes[0].stop.clone();
    let program = Program {
        context: &context,
        stop: Some(&stop),
        allowed: Some(mask(&[0, 1])),
        output_voice: Some(0),
        parent: 0,
        depth: 1,
    };
    let base = key(&graph, program, AudioSample(0), 64).unwrap();
    assert!(
        Some(base)
            == key(
                &graph,
                Program {
                    output_voice: Some(1),
                    ..program
                },
                AudioSample(0),
                64
            )
    );
    for (changed, start, frames) in [
        (
            Program {
                depth: 2,
                ..program
            },
            AudioSample(0),
            64,
        ),
        (
            Program {
                allowed: Some(mask(&[0])),
                ..program
            },
            AudioSample(0),
            64,
        ),
        (program, AudioSample(1), 64),
        (program, AudioSample(0), 63),
    ] {
        assert!(Some(base) != key(&graph, changed, start, frames));
    }
    assert!(
        key(
            &graph,
            Program {
                output_voice: Some(2),
                ..program
            },
            AudioSample(0),
            64
        )
        .is_none()
    );
    assert!(
        key(
            &graph,
            Program {
                parent: usize::MAX,
                ..program
            },
            AudioSample(0),
            64
        )
        .is_none()
    );
    assert!(
        key(
            &graph,
            Program {
                stop: None,
                ..program
            },
            AudioSample(0),
            64
        )
        .is_none()
    );
    let foreign_context = Contexts {
        original: Context::Root,
        sounds: Sounds::Root,
    };
    assert!(
        key(
            &graph,
            Program {
                context: &foreign_context,
                ..program
            },
            AudioSample(0),
            64
        )
        .is_none()
    );
    let foreign_stop = Boundary {
        owner: stop.owner.clone(),
        before: stop.before + 1,
    };
    assert!(
        key(
            &graph,
            Program {
                stop: Some(&foreign_stop),
                ..program
            },
            AudioSample(0),
            64
        )
        .is_none()
    );
    clean(&mut graph, &mut renderer, reserve);
}

#[test]
fn pressure_evicts_prefix_payloads_and_stale_keys_prepare_again_without_leaks() {
    let (plan, mut provider) = fixture("a", true, false);
    let mut renderer = StageAudio::new(Arc::clone(&plan));
    let cancelled = AtomicBool::new(false);
    let work = RefCell::new(ReadWork::default());
    let control = control(&cancelled, &work);
    let (mut graph, reserve) = new_graph(&plan, &mut renderer, control);
    let expected = read(&mut renderer, &mut provider, &mut graph, 1, control).unwrap();
    assert_eq!(renderer.shared_prefixes.len(), 1);
    let extra = u64::from(renderer.limits.maximum_resident_frames) - renderer.active_frames;
    renderer.make_room(extra, false, control).unwrap();
    assert!(renderer.shared_prefixes.is_empty());
    let contexts = provider.context_calls;
    let actual = read(&mut renderer, &mut provider, &mut graph, 1, control).unwrap();
    assert_same(&actual, &expected);
    assert!(provider.context_calls > contexts);
    assert_eq!(graph.prefix_inputs.as_ref().unwrap().hits, 0);
    assert!(
        renderer.cache.len()
            + renderer.original_inputs.len()
            + renderer.shared_prefixes.len()
            + renderer.shared_siblings.len()
            <= renderer.limits.maximum_cached_stages
    );
    clean(&mut graph, &mut renderer, reserve);
}

#[test]
fn suppressed_prefixes_still_readmit_sources_and_cancellation_precedes_lookup() {
    let (plan, mut provider) = fixture("a", true, true);
    let mut renderer = StageAudio::new(Arc::clone(&plan));
    let cancelled = AtomicBool::new(false);
    let work = RefCell::new(ReadWork::default());
    let control = control(&cancelled, &work);
    let (mut graph, reserve) = new_graph(&plan, &mut renderer, control);
    let first = read(&mut renderer, &mut provider, &mut graph, 0, control).unwrap();
    assert!(first.samples.iter().all(|sample| *sample == [0.0; 2]));
    let calls = provider.inner.calls;
    let second = read(&mut renderer, &mut provider, &mut graph, 1, control).unwrap();
    assert!(second.samples.iter().all(|sample| *sample == [0.0; 2]));
    assert!(provider.inner.calls > calls);
    assert_eq!(graph.prefix_inputs.as_ref().unwrap().hits, 1);
    cancelled.store(true, std::sync::atomic::Ordering::Relaxed);
    let calls = provider.inner.calls;
    assert!(matches!(
        read(&mut renderer, &mut provider, &mut graph, 0, control),
        Err(StageAudioError::Preparation(PreparationError::Cancelled))
    ));
    assert_eq!(provider.inner.calls, calls);
    clean(&mut graph, &mut renderer, reserve);
}

#[test]
fn a_warm_prefix_rejects_changed_real_source_fingerprint() {
    use deadpan_media::audio_session::{AudioSession, AudioSessionLimits};
    use deadpan_media::source_index::SourceContentIdentity;
    use sha2::{Digest, Sha256};
    use std::io::Cursor;

    let (plan, mut provider) = fixture("a", true, false);
    let mut renderer = StageAudio::new(Arc::clone(&plan));
    let cancelled = AtomicBool::new(false);
    let work = RefCell::new(ReadWork::default());
    let control = control(&cancelled, &work);
    let (mut graph, reserve) = new_graph(&plan, &mut renderer, control);
    read(&mut renderer, &mut provider, &mut graph, 0, control).unwrap();
    assert_eq!(renderer.shared_prefixes.len(), 1);
    let mut bytes = std::fs::read(
        std::path::PathBuf::from(env!("CARGO_MANIFEST_DIR"))
            .join("../../native/deadpan-source/tests/audio-fixtures/pcm-stereo-48000.wav"),
    )
    .unwrap();
    let mut at = 12;
    loop {
        let length = u32::from_le_bytes(bytes[at + 4..at + 8].try_into().unwrap()) as usize;
        if &bytes[at..at + 4] == b"data" {
            assert!(length > 0);
            bytes[at + 8] ^= 1;
            break;
        }
        at += 8 + length + length % 2;
    }
    let session = AudioSession::open_verified(
        &mut Cursor::new(&bytes),
        SourceContentIdentity::new(Sha256::digest(&bytes).into(), bytes.len() as u64).unwrap(),
        0,
        AudioSessionLimits::default(),
        &cancelled,
    )
    .unwrap();
    let index = session.index().clone();
    let changed = crate::PreparedSource::with_layout(
        session,
        &index,
        provider.inner.prepared.matrix_layout(),
        &cancelled,
    )
    .unwrap();
    assert_ne!(changed.provenance(), provider.inner.prepared.provenance());
    provider.inner.prepared = changed;
    assert!(matches!(
        read(&mut renderer, &mut provider, &mut graph, 1, control),
        Err(StageAudioError::Preparation(
            PreparationError::IndexMismatch
        ))
    ));
    assert_eq!(graph.prefix_inputs.as_ref().unwrap().hits, 0);
    clean(&mut graph, &mut renderer, reserve);
}

#[test]
fn a_direct_frozen_context_graph_keeps_its_complete_source_contract_on_hits() {
    let (template, mut provider) = fixture("a", false, false);
    let (base, _) = fixture_document_at_rate(FrameRate::new(48_000, 1).unwrap());
    let owners = template
        .audio_gain_owners(AudioSample(32)..AudioSample(33), Default::default())
        .unwrap();
    let treatment = owners.spans()[0]
        .owners()
        .iter()
        .find(|o| o.instance().node == id("root"))
        .unwrap()
        .treatments()
        .unwrap();
    let mut wire = serde_json::to_value(base).unwrap();
    wire["assets"]["media"] = serde_json::to_value(&provider.expected).unwrap();
    wire["nodes"]["root"]["audio_treatments"] = serde_json::to_value(treatment).unwrap();
    let document = ProjectDocument::from_json(&wire.to_string()).unwrap();
    let plan = Arc::new(
        RenderPlan::compile_audio_context(&FrozenAudioContext::capture(&document).unwrap())
            .unwrap(),
    );
    let mut renderer = StageAudio::new(Arc::clone(&plan));
    let cancelled = AtomicBool::new(false);
    let work = RefCell::new(ReadWork::default());
    let control = control(&cancelled, &work);
    let (mut graph, reserve) = new_graph(&plan, &mut renderer, control);
    let first = read(&mut renderer, &mut provider, &mut graph, 0, control).unwrap();
    let contexts = provider.context_calls;
    let second = read(&mut renderer, &mut provider, &mut graph, 0, control).unwrap();
    assert_same(&first, &second);
    assert!(provider.context_calls > contexts);
    assert_eq!(graph.prefix_inputs.as_ref().unwrap().hits, 1);
    provider.contextual = false;
    let ordinary = provider.inner.calls;
    assert!(matches!(
        read(&mut renderer, &mut provider, &mut graph, 0, control),
        Err(StageAudioError::Preparation(
            PreparationError::SourceUnavailable(_)
        ))
    ));
    assert_eq!(
        ordinary, provider.inner.calls,
        "a frozen graph never downgrades to ordinary admission"
    );
    clean(&mut graph, &mut renderer, reserve);
}

#[test]
fn a_cached_prefix_rechecks_nested_relative_depth_before_media() {
    let (plan, mut provider) = fixture("a", true, false);
    let mut renderer = StageAudio::new(Arc::clone(&plan));
    let cancelled = AtomicBool::new(false);
    let work = RefCell::new(ReadWork::default());
    let control = control(&cancelled, &work);
    let (mut graph, reserve) = new_graph(&plan, &mut renderer, control);
    read(&mut renderer, &mut provider, &mut graph, 0, control).unwrap();
    let cached = renderer.shared_prefixes.values_mut().next().unwrap();
    Arc::get_mut(&mut cached.block).unwrap().relative_depth = renderer.limits.maximum_depth;
    let calls = provider.inner.calls;
    assert!(matches!(
        read(&mut renderer, &mut provider, &mut graph, 1, control),
        Err(StageAudioError::Limit("nested stage depth"))
    ));
    assert_eq!(calls, provider.inner.calls);
    clean(&mut graph, &mut renderer, reserve);
}

#[test]
fn optional_inventory_exhaustion_disables_prefixes_without_spending_render_work() {
    let (plan, mut provider) = fixture("a", false, false);
    let cancelled = AtomicBool::new(false);
    let reference_work = RefCell::new(ReadWork::default());
    let mut reference = StageAudio::new(Arc::clone(&plan));
    let expected = reference
        .read_shared_equalizers(
            &mut provider,
            AudioSample(0),
            64,
            control(&cancelled, &reference_work),
        )
        .unwrap();
    let mut renderer = StageAudio::new(plan);
    let work = RefCell::new(ReadWork {
        cache_plan_work: MAX_PLAN_WORK_PER_READ,
        ..Default::default()
    });
    let actual = renderer
        .read_shared_equalizers(
            &mut provider,
            AudioSample(0),
            64,
            control(&cancelled, &work),
        )
        .unwrap();
    assert_eq!(actual.samples, expected.samples);
    assert_eq!(actual.suppressed, expected.suppressed);
    assert_eq!(actual.dependencies, expected.dependencies);
    assert_eq!(work.borrow().cache_plan_work, MAX_PLAN_WORK_PER_READ);
    assert!(work.borrow().plan_work < MAX_PLAN_WORK_PER_READ);
    assert_eq!(renderer.active_frames, 0);
    assert!(renderer.shared_prefixes.is_empty());
}

fn tile(
    renderer: &mut StageAudio,
    provider: &mut ContextProvider,
    graph: &mut Graph<'_>,
    output: usize,
    control: WorkControl<'_>,
) -> Result<Arc<WideBlock>, StageAudioError> {
    renderer.shared_eq_tile(
        provider,
        graph,
        0,
        (0, mask(&[0, 1]), Some(output)),
        control,
        1,
    )
}

fn sibling_id(renderer: &StageAudio, graph: &Graph<'_>, output: usize) -> Option<u64> {
    let cache = graph.prefix_inputs.as_ref()?;
    renderer.shared_siblings.iter().find_map(|(id, tile)| {
        (tile.node == 0
            && tile.key == (0, mask(&[0, 1]), Some(output))
            && Arc::ptr_eq(&tile.scope, cache.scope()))
        .then_some(*id)
    })
}

/// Independent single-output traversal is the reference for batching. It still
/// uses the real EQ and source fixture, but cannot retain speculative siblings.
fn fresh_tile(plan: &Arc<RenderPlan>, output: usize) -> WideBlock {
    let (_, mut provider) = fixture("a", true, false);
    let mut renderer = StageAudio::new(Arc::clone(plan));
    let cancelled = AtomicBool::new(false);
    let work = RefCell::new(ReadWork::default());
    let control = control(&cancelled, &work);
    let (mut graph, reserve) = new_graph(plan, &mut renderer, control);
    graph.prefix_inputs = None;
    let block = tile(&mut renderer, &mut provider, &mut graph, output, control).unwrap();
    let result = WideBlock {
        samples: block.samples.clone(),
        suppressed: block.suppressed.clone(),
        dependencies: block.dependencies.clone(),
        relative_depth: block.relative_depth,
    };
    drop(block);
    graph.original_inputs.clear(&mut renderer);
    renderer.active_frames -= reserve + graph.resident;
    assert_eq!(renderer.active_frames, 0);
    assert_eq!(renderer.cached_resident_frames(), 0);
    result
}

#[test]
fn sibling_temporal_tiles_match_independent_traversals_and_readmit_before_consumption() {
    let (plan, mut provider) = fixture("a", true, false);
    let expected_original = fresh_tile(&plan, 0);
    let expected_sound = fresh_tile(&plan, 1);
    let mut renderer = StageAudio::new(Arc::clone(&plan));
    let cancelled = AtomicBool::new(false);
    let work = RefCell::new(ReadWork::default());
    let control = control(&cancelled, &work);
    let (mut graph, reserve) = new_graph(&plan, &mut renderer, control);
    let before = work.borrow().plan_work;
    let original = tile(&mut renderer, &mut provider, &mut graph, 0, control).unwrap();
    let preparation_work = work.borrow().plan_work - before;
    assert_same(&original, &expected_original);
    assert!(graph.prefix_inputs.as_ref().unwrap().hits > 0);
    let sibling_key = (0, mask(&[0, 1]), Some(1));
    let sibling = sibling_id(&renderer, &graph, 1).unwrap();
    let sibling_resident = renderer.shared_siblings[&sibling].resident;
    let resident = graph.resident;
    assert!(!graph.nodes[0].tiles.contains_key(&sibling_key));
    assert!(
        renderer.cache.len()
            + renderer.original_inputs.len()
            + renderer.shared_prefixes.len()
            + renderer.shared_siblings.len()
            <= renderer.limits.maximum_cached_stages
    );
    let calls = provider.inner.calls;
    let contexts = provider.context_calls;
    let before = work.borrow().plan_work;
    let sound = tile(&mut renderer, &mut provider, &mut graph, 1, control).unwrap();
    let consumption_work = work.borrow().plan_work - before;
    assert_same(&sound, &expected_sound);
    assert_ne!(original.samples, sound.samples);
    assert!(provider.inner.calls > calls && provider.context_calls > contexts);
    assert!(sibling_id(&renderer, &graph, 1).is_none());
    assert!(Arc::ptr_eq(&graph.nodes[0].tiles[&sibling_key], &sound));
    assert_eq!(graph.resident, resident + sibling_resident);
    assert!(
        consumption_work < preparation_work,
        "preparation={preparation_work}, consumption={consumption_work}"
    );
    drop((original, sound));
    clean(&mut graph, &mut renderer, reserve);
}

#[test]
fn speculative_sibling_pcm_cannot_survive_revoked_contextual_source_authority() {
    let (plan, mut provider) = fixture("a", true, false);
    let mut renderer = StageAudio::new(Arc::clone(&plan));
    let cancelled = AtomicBool::new(false);
    let work = RefCell::new(ReadWork::default());
    let control = control(&cancelled, &work);
    let (mut graph, reserve) = new_graph(&plan, &mut renderer, control);
    let original = tile(&mut renderer, &mut provider, &mut graph, 0, control).unwrap();
    let sibling_key = (0, mask(&[0, 1]), Some(1));
    assert!(sibling_id(&renderer, &graph, 1).is_some());
    let resident = graph.resident;
    let calls = provider.inner.calls;
    let contexts = provider.context_calls;
    provider.contextual = false;
    assert!(matches!(
        tile(&mut renderer, &mut provider, &mut graph, 1, control),
        Err(StageAudioError::Preparation(
            PreparationError::SourceUnavailable(_)
        ))
    ));
    assert!(
        provider.inner.calls > calls,
        "ordinary source access remains available"
    );
    assert!(provider.context_calls > contexts);
    assert!(!graph.nodes[0].tiles.contains_key(&sibling_key));
    assert!(sibling_id(&renderer, &graph, 1).is_none());
    assert_eq!(graph.resident, resident);
    assert!(
        graph.nodes[0].filter.is_some(),
        "failed recomputation returns its filter"
    );
    drop(original);
    clean(&mut graph, &mut renderer, reserve);
}

#[test]
fn constrained_temporal_residency_falls_back_to_one_output_without_leaking() {
    let (plan, mut provider) = fixture("a", true, false);
    let expected = fresh_tile(&plan, 0);
    let mut renderer = StageAudio::new(Arc::clone(&plan));
    let cancelled = AtomicBool::new(false);
    let work = RefCell::new(ReadWork::default());
    let control = control(&cancelled, &work);
    let (mut graph, reserve) = new_graph(&plan, &mut renderer, control);
    // Enough room for one real filter history and its prefix workspace, but
    // not two complete histories plus their retained output tiles.
    renderer.limits.maximum_resident_frames = u32::try_from(renderer.active_frames).unwrap()
        + u32::try_from(INPUT * 4 + OUTPUT * 4 + 3000).unwrap();
    let actual = tile(&mut renderer, &mut provider, &mut graph, 0, control).unwrap();
    assert_same(&actual, &expected);
    assert!(
        !graph.nodes[0]
            .tiles
            .contains_key(&(0, mask(&[0, 1]), Some(1)))
    );
    assert!(sibling_id(&renderer, &graph, 1).is_none());
    assert!(
        renderer.active_frames + renderer.cached_resident_frames()
            <= u64::from(renderer.limits.maximum_resident_frames)
    );
    drop(actual);
    clean(&mut graph, &mut renderer, reserve);
}

#[test]
fn required_allocation_evicts_speculative_tiles_and_the_requested_sibling_recomputes_exactly() {
    let (plan, mut provider) = fixture("a", true, false);
    let expected = fresh_tile(&plan, 1);
    let mut renderer = StageAudio::new(Arc::clone(&plan));
    let cancelled = AtomicBool::new(false);
    let work = RefCell::new(ReadWork::default());
    let control = control(&cancelled, &work);
    let (mut graph, reserve) = new_graph(&plan, &mut renderer, control);
    let original = tile(&mut renderer, &mut provider, &mut graph, 0, control).unwrap();
    assert!(sibling_id(&renderer, &graph, 1).is_some());
    let resident = graph.resident;
    let required = u64::from(renderer.limits.maximum_resident_frames) - renderer.active_frames;
    renderer.make_room(required, false, control).unwrap();
    renderer.active_frames += required;
    assert!(renderer.shared_siblings.is_empty());
    assert_eq!(
        graph.resident, resident,
        "required Original PCM remains owned"
    );
    assert!(Arc::ptr_eq(
        &graph.nodes[0].tiles[&(0, mask(&[0, 1]), Some(0))],
        &original
    ));
    assert_eq!(renderer.cached_resident_frames(), 0);
    renderer.active_frames -= required;
    let contexts = provider.context_calls;
    let sound = tile(&mut renderer, &mut provider, &mut graph, 1, control).unwrap();
    assert_same(&sound, &expected);
    assert!(
        provider.context_calls > contexts,
        "evicted PCM requires fresh source admission"
    );
    drop((original, sound));
    clean(&mut graph, &mut renderer, reserve);
}

#[test]
fn speculative_prefix_mix_never_swallows_invalid_samples_from_source_admission() {
    let (plan, mut provider) = fixture("a", true, false);
    let mut renderer = StageAudio::new(Arc::clone(&plan));
    let cancelled = AtomicBool::new(false);
    let work = RefCell::new(ReadWork::default());
    let control = control(&cancelled, &work);
    let (mut graph, reserve) = new_graph(&plan, &mut renderer, control);
    read(&mut renderer, &mut provider, &mut graph, 0, control).unwrap();
    let context = graph.nodes[0].context.clone();
    let stop = graph.nodes[0].stop.clone();
    let prefix = key(
        &graph,
        Program {
            context: &context,
            stop: Some(&stop),
            allowed: Some(mask(&[0, 1])),
            output_voice: Some(1),
            parent: 0,
            depth: 1,
        },
        AudioSample(0),
        64,
    )
    .unwrap();
    provider.invalid_context = true;
    let calls = provider.inner.calls;
    let contexts = provider.context_calls;
    assert!(matches!(
        renderer.cached_shared_prefix(&mut provider, &mut graph, prefix, (1, true), control),
        Err(StageAudioError::Preparation(
            PreparationError::InvalidSamples
        ))
    ));
    assert!(provider.inner.calls > calls && provider.context_calls > contexts);
    assert_eq!(graph.prefix_inputs.as_ref().unwrap().hits, 0);
    clean(&mut graph, &mut renderer, reserve);
}

#[test]
fn one_tile_preparation_budget_preserves_the_requested_output_without_speculation() {
    let (plan, mut provider) = fixture("a", true, false);
    let expected = fresh_tile(&plan, 0);
    let mut renderer = StageAudio::new(Arc::clone(&plan));
    renderer.limits.maximum_prepared_frames = (INPUT + OUTPUT) as u64;
    let cancelled = AtomicBool::new(false);
    let work = RefCell::new(ReadWork::default());
    let control = control(&cancelled, &work);
    let (mut graph, reserve) = new_graph(&plan, &mut renderer, control);
    let actual = tile(&mut renderer, &mut provider, &mut graph, 0, control).unwrap();
    assert_same(&actual, &expected);
    assert_eq!(work.borrow().prepared_frames, (INPUT + OUTPUT) as u64);
    assert!(sibling_id(&renderer, &graph, 1).is_none());
    assert!(
        !graph.nodes[0]
            .tiles
            .contains_key(&(0, mask(&[0, 1]), Some(1)))
    );
    drop(actual);
    clean(&mut graph, &mut renderer, reserve);
}
