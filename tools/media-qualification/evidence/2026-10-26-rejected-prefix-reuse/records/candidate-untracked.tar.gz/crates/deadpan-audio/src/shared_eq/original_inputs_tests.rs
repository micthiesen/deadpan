use super::*;
use crate::stages::controlled_reads::{Provider, fixture_document_at_rate};
use deadpan_core::FrameRate;

fn fixture() -> (Arc<RenderPlan>, Provider) {
    let (document, provider) = fixture_document_at_rate(FrameRate::new(48_000, 1).unwrap());
    (Arc::new(RenderPlan::compile(&document).unwrap()), provider)
}

fn graph(plan: &RenderPlan) -> Graph<'_> {
    Graph {
        plan,
        nodes: Vec::new(),
        resident: 0,
        wet_filters: std::array::from_fn(|_| None),
        event_tiles: BTreeMap::new(),
        event_nodes: Default::default(),
        event_filters: BTreeMap::new(),
        voices: BTreeMap::new(),
        permission_families: BTreeMap::new(),
        selected_family_count: 0,
        canonical_families: FamilyRegistry::default(),
        sends: None,
        skip: Vec::new(),
        original_only: false,
        original_inputs: Cache::default(),
        prefix_inputs: None,
    }
}

fn control<'a>(cancelled: &'a AtomicBool, work: &'a RefCell<ReadWork>) -> WorkControl<'a> {
    WorkControl {
        cancelled,
        deadline: Instant::now() + Duration::from_secs(10),
        work,
    }
}

#[test]
fn exact_original_input_reuse_rechecks_sources_and_preserves_pcm_and_masks() {
    let (plan, mut provider) = fixture();
    let mut renderer = StageAudio::new(Arc::clone(&plan));
    let mut graph = graph(&plan);
    let cancelled = AtomicBool::new(false);
    let work = RefCell::new(ReadWork::default());
    let control = control(&cancelled, &work);
    let first = renderer
        .shared_original_input(
            &mut provider,
            &mut graph,
            &Context::Root,
            AudioSample(0)..AudioSample(64),
            control,
            0,
        )
        .unwrap();
    let first_work = work.borrow().plan_work;
    let calls = provider.calls;
    let second = renderer
        .shared_original_input(
            &mut provider,
            &mut graph,
            &Context::Root,
            AudioSample(0)..AudioSample(64),
            control,
            0,
        )
        .unwrap();
    assert!(provider.calls > calls, "hit must re-admit its source");
    assert!(work.borrow().plan_work - first_work < first_work);
    let (Read::Cached(first), Read::Cached(second)) = (&first, &second) else {
        panic!("fixture must exercise an actual cache hit")
    };
    assert!(Arc::ptr_eq(first, second));
    assert_eq!(first.start, second.start);
    assert_eq!(first.suppressed, second.suppressed);
    assert_eq!(first.exhausted, second.exhausted);
    assert_eq!(first.dependencies, second.dependencies);
    assert_eq!(first.relative_depth, second.relative_depth);
    let reference = renderer
        .read_controlled(&mut provider, AudioSample(0), 64, control, true, 0)
        .unwrap();
    assert_eq!(first.samples, reference.samples);
    assert_eq!(first.suppressed, reference.suppressed);
    assert_eq!(first.exhausted, reference.exhausted);
    assert_eq!(first.dependencies, reference.dependencies);
    graph.original_inputs.clear(&mut renderer);
    assert!(renderer.original_inputs.is_empty());
}

#[test]
fn original_input_cache_shares_pressure_with_required_allocations_and_respects_pins() {
    let (plan, mut provider) = fixture();
    let mut renderer = StageAudio::new(Arc::clone(&plan));
    let mut graph = graph(&plan);
    let cancelled = AtomicBool::new(false);
    let work = RefCell::new(ReadWork::default());
    let control = control(&cancelled, &work);
    let raw = renderer
        .shared_original_input(
            &mut provider,
            &mut graph,
            &Context::Root,
            AudioSample(0)..AudioSample(64),
            control,
            0,
        )
        .unwrap();
    assert!(renderer.cached_resident_frames() > 64);
    let ceiling = u64::from(renderer.limits.maximum_resident_frames);
    assert!(matches!(
        renderer.make_room(ceiling, false, control),
        Err(StageAudioError::Limit("resident PCM or stage cache"))
    ));
    assert_eq!(renderer.original_inputs.len(), 1);
    drop(raw);
    renderer.make_room(ceiling, false, control).unwrap();
    assert!(renderer.original_inputs.is_empty());
    assert_eq!(renderer.cached_resident_frames(), 0);
    // The stale key cannot provide old PCM after generic pressure eviction.
    let raw = renderer
        .shared_original_input(
            &mut provider,
            &mut graph,
            &Context::Root,
            AudioSample(0)..AudioSample(64),
            control,
            0,
        )
        .unwrap();
    assert_eq!(graph.original_inputs.len, 1);
    assert_eq!(renderer.original_inputs.len(), 1);
    drop(raw);
    graph.original_inputs.clear(&mut renderer);
    assert_eq!(renderer.cached_resident_frames(), 0);
    assert_eq!(renderer.active_frames, 0);
}

#[test]
fn original_input_hit_refuses_unavailable_source_and_cancellation() {
    struct Unavailable(usize);
    impl AudioSourceProvider for Unavailable {
        fn source(
            &mut self,
            _: &ProjectId,
            _: &RevisionId,
            _: &AssetId,
            _: &AtomicBool,
        ) -> Result<&crate::PreparedSource, PreparationError> {
            self.0 += 1;
            Err(PreparationError::SourceUnavailable("removed".into()))
        }
    }
    let (plan, mut provider) = fixture();
    let mut renderer = StageAudio::new(Arc::clone(&plan));
    let mut graph = graph(&plan);
    let cancelled = AtomicBool::new(false);
    let work = RefCell::new(ReadWork::default());
    let control = control(&cancelled, &work);
    drop(
        renderer
            .shared_original_input(
                &mut provider,
                &mut graph,
                &Context::Root,
                AudioSample(0)..AudioSample(64),
                control,
                0,
            )
            .unwrap(),
    );
    let mut unavailable = Unavailable(0);
    assert!(
        renderer
            .shared_original_input(
                &mut unavailable,
                &mut graph,
                &Context::Root,
                AudioSample(0)..AudioSample(64),
                control,
                0,
            )
            .is_err()
    );
    assert_eq!(unavailable.0, 1);
    cancelled.store(true, std::sync::atomic::Ordering::Relaxed);
    let calls = provider.calls;
    assert!(
        renderer
            .shared_original_input(
                &mut provider,
                &mut graph,
                &Context::Root,
                AudioSample(0)..AudioSample(64),
                control,
                0,
            )
            .is_err()
    );
    assert_eq!(provider.calls, calls);
    graph.original_inputs.clear(&mut renderer);
    assert_eq!(renderer.cached_resident_frames(), 0);
}

#[test]
fn original_input_identity_keeps_ranges_depths_and_controllers_separate() {
    let (plan, mut provider) = fixture();
    let mut renderer = StageAudio::new(Arc::clone(&plan));
    let mut graph = graph(&plan);
    let cancelled = AtomicBool::new(false);
    let work = RefCell::new(ReadWork::default());
    let control = control(&cancelled, &work);
    for (start, depth) in [(0, 0), (1, 0), (0, 1)] {
        drop(
            renderer
                .shared_original_input(
                    &mut provider,
                    &mut graph,
                    &Context::Root,
                    AudioSample(start)..AudioSample(start + 64),
                    control,
                    depth,
                )
                .unwrap(),
        );
    }
    assert_eq!(renderer.original_inputs.len(), 3);
    assert_eq!(graph.original_inputs.len, 3);
    let mut other = StageAudio::new(Arc::clone(&plan));
    let calls = provider.calls;
    assert!(matches!(
        other.shared_original_input(
            &mut provider,
            &mut graph,
            &Context::Root,
            AudioSample(0)..AudioSample(64),
            control,
            0,
        ),
        Err(StageAudioError::ForeignDomain)
    ));
    assert_eq!(provider.calls, calls);
    assert!(other.original_inputs.is_empty());
    graph.original_inputs.clear(&mut renderer);
    assert!(renderer.original_inputs.is_empty());
}

#[test]
fn original_input_hit_refuses_changed_real_source_provenance() {
    use deadpan_media::audio_session::{AudioSession, AudioSessionLimits};
    use deadpan_media::source_index::SourceContentIdentity;
    use sha2::{Digest, Sha256};
    use std::io::Cursor;

    let (plan, mut provider) = fixture();
    let mut renderer = StageAudio::new(Arc::clone(&plan));
    let mut graph = graph(&plan);
    let cancelled = AtomicBool::new(false);
    let work = RefCell::new(ReadWork::default());
    let control = control(&cancelled, &work);
    drop(
        renderer
            .shared_original_input(
                &mut provider,
                &mut graph,
                &Context::Root,
                AudioSample(0)..AudioSample(64),
                control,
                0,
            )
            .unwrap(),
    );
    let mut bytes = std::fs::read(
        std::path::PathBuf::from(env!("CARGO_MANIFEST_DIR"))
            .join("../../native/deadpan-source/tests/audio-fixtures/pcm-stereo-48000.wav"),
    )
    .unwrap();
    let mut at = 12;
    loop {
        let length = u32::from_le_bytes(bytes[at + 4..at + 8].try_into().unwrap()) as usize;
        if &bytes[at..at + 4] == b"data" {
            assert!(length > 0);
            bytes[at + 8] ^= 1;
            break;
        }
        at += 8 + length + length % 2;
    }
    let session = AudioSession::open_verified(
        &mut Cursor::new(&bytes),
        SourceContentIdentity::new(Sha256::digest(&bytes).into(), bytes.len() as u64).unwrap(),
        0,
        AudioSessionLimits::default(),
        &cancelled,
    )
    .unwrap();
    let index = session.index().clone();
    let changed = crate::PreparedSource::with_layout(
        session,
        &index,
        provider.prepared.matrix_layout(),
        &cancelled,
    )
    .unwrap();
    assert_ne!(changed.provenance(), provider.prepared.provenance());
    provider.prepared = changed;
    assert!(matches!(
        renderer.shared_original_input(
            &mut provider,
            &mut graph,
            &Context::Root,
            AudioSample(0)..AudioSample(64),
            control,
            0,
        ),
        Err(StageAudioError::Preparation(
            PreparationError::IndexMismatch
        ))
    ));
    graph.original_inputs.clear(&mut renderer);
    assert!(renderer.original_inputs.is_empty());
    assert_eq!(renderer.active_frames, 0);
}

#[test]
fn original_input_domain_reuse_requires_the_same_retained_allocation() {
    let (plan, mut provider) = fixture();
    let owners = plan
        .audio_gain_owners(AudioSample(0)..AudioSample(1), Default::default())
        .unwrap();
    let owner = owners.spans()[0].owners().last().unwrap();
    let input = plan
        .audio_owner_input(owner, AudioSample(0), Default::default())
        .unwrap();
    let domain = Arc::new(input.context().clone());
    let contexts = [
        Context::Domain(Arc::clone(&domain)),
        Context::Domain(Arc::clone(&domain)),
        Context::Domain(Arc::new((*domain).clone())),
    ];
    let mut renderer = StageAudio::new(Arc::clone(&plan));
    let mut graph = graph(&plan);
    let cancelled = AtomicBool::new(false);
    let work = RefCell::new(ReadWork::default());
    let control = control(&cancelled, &work);
    let mut reads = Vec::new();
    for context in &contexts {
        reads.push(
            renderer
                .shared_original_input(
                    &mut provider,
                    &mut graph,
                    context,
                    AudioSample(0)..AudioSample(64),
                    control,
                    0,
                )
                .unwrap(),
        );
    }
    let cached = |read: &Read| match read {
        Read::Cached(block) => Arc::as_ptr(block),
        Read::Fresh(_) => panic!("fixture must retain its input"),
    };
    assert_eq!(cached(&reads[0]), cached(&reads[1]));
    assert_ne!(cached(&reads[0]), cached(&reads[2]));
    assert_eq!(reads[0].samples, reads[2].samples);
    assert_eq!(renderer.original_inputs.len(), 2);
    drop(reads);
    graph.original_inputs.clear(&mut renderer);
    assert_eq!(renderer.cached_resident_frames(), 0);
}

#[test]
fn indexed_cache_keeps_exact_collision_checks_and_lru_removal_order() {
    let (plan, mut provider) = fixture();
    let owners = plan
        .audio_gain_owners(AudioSample(0)..AudioSample(1), Default::default())
        .unwrap();
    let owner = owners.spans()[0].owners().last().unwrap();
    let input = plan
        .audio_owner_input(owner, AudioSample(0), Default::default())
        .unwrap();
    let domain = Arc::new(input.context().clone());
    let cancelled = AtomicBool::new(false);
    let work = RefCell::new(ReadWork::default());
    let control = control(&cancelled, &work);
    let mut cache = Cache::default();

    // Force an accelerator-key collision. A hit still has to validate the
    // retained full Context before it can return a cached block.
    let forced = LookupKey::new(&Context::Root, &(AudioSample(0)..AudioSample(64)), 0);
    cache
        .insert(
            Entry {
                context: Context::Domain(Arc::clone(&domain)),
                samples: AudioSample(0)..AudioSample(64),
                depth: 0,
                key: 1,
                lookup: forced,
                previous: None,
                next: None,
            },
            control,
        )
        .unwrap();
    let mut renderer = StageAudio::new(Arc::clone(&plan));
    let mut corrupted = graph(&plan);
    corrupted.original_inputs = cache;
    let source_calls = provider.calls;
    assert!(matches!(
        renderer.shared_original_input(
            &mut provider,
            &mut corrupted,
            &Context::Root,
            AudioSample(0)..AudioSample(64),
            control,
            0,
        ),
        Err(StageAudioError::ForeignDomain)
    ));
    assert_eq!(provider.calls, source_calls);
    assert!(renderer.original_inputs.is_empty());
    assert_eq!(renderer.cached_resident_frames(), 0);
    assert_eq!(renderer.active_frames, 0);
    corrupted.original_inputs.clear(&mut renderer);
    assert_eq!(corrupted.original_inputs.len, 0);
    let mut cache = Cache::default();

    let mut second_slot = None;
    for (index, start) in [(0, 0), (1, 64), (2, 128)] {
        let samples = AudioSample(start)..AudioSample(start + 64);
        let context = Context::Root;
        let slot = cache
            .insert(
                Entry {
                    context: context.clone(),
                    lookup: LookupKey::new(&context, &samples, 0),
                    samples,
                    depth: 0,
                    key: index as u64 + 10,
                    previous: None,
                    next: None,
                },
                control,
            )
            .unwrap();
        if index == 1 {
            second_slot = Some(slot);
        }
    }
    let hit = cache
        .find(
            LookupKey::new(&Context::Root, &(AudioSample(0)..AudioSample(64)), 0),
            control,
        )
        .unwrap()
        .unwrap();
    cache.touch(hit);
    assert_eq!(cache.least_recent, second_slot);
    assert_eq!(cache.remove(second_slot.unwrap(), control).unwrap().key, 11);
    assert_eq!(cache.least_recent, Some(2));
    assert_eq!(cache.most_recent, Some(0));
    assert_eq!(cache.len, 2);
    let replacement_samples = AudioSample(192)..AudioSample(256);
    let replacement_context = Context::Root;
    let reused = cache
        .insert(
            Entry {
                context: replacement_context.clone(),
                lookup: LookupKey::new(&replacement_context, &replacement_samples, 0),
                samples: replacement_samples,
                depth: 0,
                key: 99,
                previous: None,
                next: None,
            },
            control,
        )
        .unwrap();
    assert_eq!(Some(reused), second_slot);
    assert_eq!(cache.most_recent, Some(reused));
    assert_eq!(cache.len, 3);
    assert!(
        Cache::resident_frames().unwrap() >= std::mem::size_of::<Cache<'_>>().div_ceil(8) as u64
    );
}

#[test]
fn fixed_lookup_storage_is_reserved_before_audio_graph_admission() {
    let (plan, mut provider) = fixture();
    let mut renderer = StageAudio::new(Arc::clone(&plan));
    renderer.limits.maximum_resident_frames = 256;
    let cancelled = AtomicBool::new(false);
    let work = RefCell::new(ReadWork::default());
    let before = provider.calls;
    let result = renderer.read_shared_input(
        &mut provider,
        AudioSample(0),
        64,
        control(&cancelled, &work),
        InputSelection::default(),
    );
    assert!(matches!(
        result,
        Err(StageAudioError::Limit("resident PCM or stage cache"))
    ));
    assert_eq!(provider.calls, before);
    assert_eq!(renderer.active_frames, 0);
    assert_eq!(renderer.cached_resident_frames(), 0);
}
