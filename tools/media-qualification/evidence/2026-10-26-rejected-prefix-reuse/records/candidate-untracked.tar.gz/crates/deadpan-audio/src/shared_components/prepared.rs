//! Owned constant shared-prefix results. The stored routes keep their original
//! order and permission masks; final gain is consumed only by selected outputs.

use super::*;

struct PreparedRoute {
    voice: usize,
    pcm: Vec<Sample>,
    final_transfer: Option<authored_gain::PreparedTransfer>,
}

/// No plan, source handle or borrowed clock survives processing. The caller
/// retains exact graph/key authority and re-admits dependencies on every reuse.
pub(in crate::stages) struct Prepared {
    start: AudioSample,
    frames: usize,
    routes: Vec<PreparedRoute>,
}

impl Prepared {
    /// Existing PCM buffers move into the snapshot. Count their actual
    /// capacities, final channel-stage allocations and all owned headers.
    pub(in crate::stages) fn resident_frames(&self) -> Result<u64, StageAudioError> {
        let mut bytes = std::mem::size_of::<Self>()
            .checked_add(2 * std::mem::size_of::<usize>())
            .and_then(|n| {
                self.routes
                    .capacity()
                    .checked_mul(std::mem::size_of::<PreparedRoute>())
                    .and_then(|routes| n.checked_add(routes))
            })
            .ok_or(StageAudioError::Limit("constant prefix residency"))?;
        for route in &self.routes {
            bytes = route
                .pcm
                .capacity()
                .checked_mul(std::mem::size_of::<Sample>())
                .and_then(|pcm| bytes.checked_add(pcm))
                .and_then(|n| {
                    route
                        .final_transfer
                        .as_ref()
                        .map_or(Some(0), |transfer| transfer.allocated_stage_bytes())
                        .and_then(|stages| n.checked_add(stages))
                })
                .ok_or(StageAudioError::Limit("constant prefix residency"))?;
        }
        Ok(u64::try_from(bytes)
            .map_err(|_| StageAudioError::Limit("constant prefix residency"))?
            .div_ceil(std::mem::size_of::<[f32; 2]>() as u64))
    }

    pub(in crate::stages) fn mix(
        &self,
        output_voice: Option<usize>,
        output_aliases: Permissions,
        control: WorkControl<'_>,
    ) -> Result<MixedBlock, StageAudioError> {
        control.check()?;
        let selected = |route: &PreparedRoute| {
            output_voice.is_none_or(|voice| voice == route.voice)
                || output_aliases.contains(route.voice)
        };
        let mut samples = vec![[0.0; 2]; self.frames];
        // Route-major iteration preserves each sample's original route-order
        // additions while hoisting constant checkpoint/identity dispatch.
        for route in &self.routes {
            if !selected(route) {
                continue;
            }
            let Some(transfer) = &route.final_transfer else {
                continue;
            };
            control.spend_plan_work(1)?;
            if transfer.is_identity() {
                for (frame, output) in route.pcm.iter().zip(&mut samples) {
                    control.check()?;
                    if frame.permitted {
                        for (out, value) in output.iter_mut().zip(frame.value) {
                            *out += value;
                        }
                    }
                }
            } else {
                for (frame, output) in route.pcm.iter().zip(&mut samples) {
                    control.check()?;
                    if frame.permitted {
                        let value = transfer.apply_wide(frame.value, control)?;
                        for (out, value) in output.iter_mut().zip(value) {
                            *out += value;
                        }
                    }
                }
            }
        }
        let mut suppressed = Vec::new();
        for (at, frame) in samples.iter().enumerate() {
            control.check()?;
            if frame.iter().any(|value| !value.is_finite()) {
                return Err(PreparationError::InvalidSamples.into());
            }
            let permitted = self
                .routes
                .iter()
                .any(|route| selected(route) && route.pcm[at].permitted);
            if !permitted {
                let sample = AudioSample(self.start.0 + at as i64);
                suppressed.push(sample..AudioSample(sample.0 + 1));
            }
        }
        Ok(MixedBlock {
            samples,
            suppressed: merged_suppression(suppressed),
        })
    }
}

impl<'plan> Components<'plan> {
    pub(in crate::stages) fn can_prepare_reusable(&self) -> bool {
        self.send.is_none()
            && self
                .routes
                .iter()
                .all(|route| route.event_gain.is_none() || Program::constant(route, &self.owners))
    }

    /// Additional transient headers required while the old route vector and
    /// moved snapshot route vector coexist. PCM and transfer stages are already
    /// covered by resident_frames. Reserve this before finishing for reuse.
    pub(in crate::stages) fn reusable_metadata_frames(&self) -> Result<u64, StageAudioError> {
        let bytes = self
            .routes
            .len()
            .checked_mul(std::mem::size_of::<PreparedRoute>())
            .and_then(|n| n.checked_add(std::mem::size_of::<Prepared>()))
            .and_then(|n| n.checked_add(2 * std::mem::size_of::<usize>()))
            .ok_or(StageAudioError::Limit("constant prefix metadata"))?;
        Ok(u64::try_from(bytes)
            .map_err(|_| StageAudioError::Limit("constant prefix metadata"))?
            .div_ceil(std::mem::size_of::<[f32; 2]>() as u64))
    }

    pub(in crate::stages) fn finish_reusable(
        mut self,
        output_voice: Option<usize>,
        output_aliases: Permissions,
        control: WorkControl<'_>,
        equalize: impl FnMut(
            &AudioOwnerClock<'plan>,
            Temporal,
            AudioSample,
            Permissions,
            Option<usize>,
        ) -> Result<[f64; 2], StageAudioError>,
    ) -> Result<(MixedBlock, Option<Prepared>), StageAudioError> {
        let comparisons = self.routes.iter().try_fold(0usize, |count, route| {
            count
                .checked_add(1 + route.layers.len())
                .ok_or(StageAudioError::Limit("constant prefix work"))
        })?;
        control.spend_plan_work(comparisons)?;
        if !self.can_prepare_reusable() {
            return self
                .finish(output_voice, output_aliases, control, equalize)
                .map(|block| (block, None));
        }
        for route in &mut self.routes {
            // Preparing a transfer computes factors but does not consume them
            // or reject their amplitude. Only selected mix() paths apply it.
            route.program = Program::prepare(route, &self.owners, None, true, control)?;
        }
        self.process_constant(&mut [], control, equalize)?;
        control.spend_plan_work(self.routes.len())?;
        let mut routes = Vec::with_capacity(self.routes.len());
        for route in self.routes {
            let final_transfer = route
                .program
                .map(|program| program.into_final(control))
                .transpose()?;
            routes.push(PreparedRoute {
                voice: route.voice,
                pcm: route.pcm,
                final_transfer,
            });
        }
        let prepared = Prepared {
            start: self.start,
            frames: self.frames,
            routes,
        };
        let mixed = prepared.mix(output_voice, output_aliases, control)?;
        Ok((mixed, Some(prepared)))
    }
}

#[cfg(test)]
#[path = "prepared/tests.rs"]
mod tests;
