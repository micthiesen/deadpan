//! Speculative sibling outputs share the controller's evictable PCM ceiling.
//! Their complete identity lives here, so eviction leaves no graph allocation.

use super::*;

pub(super) fn validate_tile_depth(
    block: &WideBlock,
    depth: usize,
    maximum: usize,
) -> Result<(), StageAudioError> {
    if depth
        .checked_sub(1)
        .and_then(|parent| parent.checked_add(block.relative_depth))
        .is_none_or(|value| value > maximum)
    {
        return Err(StageAudioError::Limit("nested stage depth"));
    }
    Ok(())
}

impl StageAudio {
    pub(in crate::stages) fn evict_shared_sibling(
        &mut self,
        control: WorkControl<'_>,
    ) -> Result<bool, StageAudioError> {
        for (&id, cached) in &self.shared_siblings {
            control.spend_plan_work(1)?;
            if Arc::strong_count(&cached.block) == 1 {
                self.shared_siblings.remove(&id);
                return Ok(true);
            }
        }
        Ok(false)
    }

    pub(super) fn clear_shared_siblings(&mut self, graph: &Graph<'_>) {
        if let Some(cache) = &graph.prefix_inputs {
            self.shared_siblings
                .retain(|_, tile| !Arc::ptr_eq(&tile.scope, cache.scope()));
        }
    }

    pub(super) fn retain_shared_sibling(
        &mut self,
        graph: &mut Graph<'_>,
        (node, key): (usize, (i64, Permissions, Option<usize>)),
        block: Arc<WideBlock>,
        resident: u64,
        control: WorkControl<'_>,
    ) -> Result<bool, StageAudioError> {
        let Some(cache) = &graph.prefix_inputs else {
            return Ok(false);
        };
        let Some(next) = self.next_original_input.checked_add(1) else {
            return Ok(false);
        };
        loop {
            let fits = self
                .cached_resident_frames()
                .checked_add(self.active_frames)
                .and_then(|n| n.checked_add(control.work.borrow().projected_resident_frames))
                .and_then(|n| n.checked_add(resident))
                .is_some_and(|n| n <= u64::from(self.limits.maximum_resident_frames));
            if fits
                && self.cache.len()
                    + self.original_inputs.len()
                    + self.shared_prefixes.len()
                    + self.shared_siblings.len()
                    < self.limits.maximum_cached_stages
            {
                break;
            }
            if !self.evict_shared_sibling(control)? && !self.evict_shared_prefix(control)? {
                return Ok(false);
            }
        }
        let id = self.next_original_input;
        self.next_original_input = next;
        self.shared_siblings.insert(
            id,
            CachedTile {
                scope: Arc::clone(cache.scope()),
                node,
                key,
                block,
                resident,
            },
        );
        Ok(true)
    }

    pub(super) fn consume_shared_sibling(
        &mut self,
        provider: &mut impl AudioSourceProvider,
        graph: &mut Graph<'_>,
        (node, key): (usize, (i64, Permissions, Option<usize>)),
        control: WorkControl<'_>,
        depth: usize,
    ) -> Result<Option<Arc<WideBlock>>, StageAudioError> {
        let Some(cache) = &graph.prefix_inputs else {
            return Ok(None);
        };
        let mut found = None;
        for (&id, tile) in &self.shared_siblings {
            control.spend_plan_work(1)?;
            if tile.node == node && tile.key == key && Arc::ptr_eq(&tile.scope, cache.scope()) {
                found = Some(id);
                break;
            }
        }
        let Some(id) = found else {
            return Ok(None);
        };
        let tile = &self.shared_siblings[&id];
        validate_tile_depth(&tile.block, depth, self.limits.maximum_depth)?;
        let block = Arc::clone(&tile.block);
        if !prefix_inputs::admit_dependencies(provider, graph, &block.dependencies, control)? {
            self.shared_siblings.remove(&id);
            return Ok(None);
        }
        let tile = self.shared_siblings.remove(&id).unwrap();
        // Move the same already-accounted allocation from optional residency
        // to required graph residency, without briefly freeing its allowance.
        graph.resident += tile.resident;
        self.active_frames += tile.resident;
        graph.nodes[node].tiles.insert(key, Arc::clone(&block));
        Ok(Some(block))
    }
}
