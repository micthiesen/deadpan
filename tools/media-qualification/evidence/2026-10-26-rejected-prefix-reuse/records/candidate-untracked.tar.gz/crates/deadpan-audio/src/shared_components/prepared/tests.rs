use super::*;
use deadpan_core::*;

fn control<'a>(cancelled: &'a AtomicBool, work: &'a RefCell<ReadWork>) -> WorkControl<'a> {
    WorkControl {
        cancelled,
        deadline: Instant::now() + Duration::from_secs(10),
        work,
    }
}

fn id(value: &str) -> NodeId {
    NodeId::new(value).unwrap()
}

fn plan(dynamic: bool) -> RenderPlan {
    let document = ProjectDocument::new(
        ProjectId::new("reusable-prefix").unwrap(),
        RevisionId::new("revision").unwrap(),
        PresentationBasis {
            width: 16,
            height: 16,
            frame_rate: FrameRate::new(48_000, 1).unwrap(),
            color_policy: ColorPolicy::SdrRec709,
        },
        id("root"),
    )
    .unwrap();
    let mut root = BeatNode::sequence("Root", vec![id("leaf")]);
    root.audio_treatments = AudioTreatments::with_equalizer_stages(
        vec![
            AudioTreatmentStage::ClipGain,
            AudioTreatmentStage::Saturation,
            AudioTreatmentStage::Equalizer,
        ],
        Some(ClipGain::new(GainDb::new(-6000).unwrap(), false, vec![], vec![]).unwrap()),
        Some(Saturation::new(GainDb::new(9000).unwrap()).unwrap()),
        None,
        Some(
            EqualizerRecipe::new(
                [3000, 0, -3000].map(|gain| GainDb::new(gain).unwrap()),
                None,
                None,
            )
            .unwrap(),
        ),
    )
    .unwrap()
    .with_wet_sends(
        TailSends::default().with_level(TailEffect::Delay, Some(GainDb::new(-6000).unwrap())),
    );
    let mut leaf = BeatNode::hold(
        "Leaf",
        HoldRecipe {
            duration: FrameDuration::new(8).unwrap(),
            picture_context: None,
            video: HoldVideo::Background,
            audio: HoldAudio::Silence,
        },
    );
    let range = GainRange::new(ExactRatio::ZERO, ExactRatio::integer(8)).unwrap();
    let envelopes = if dynamic {
        vec![
            GainEnvelope::new(
                GainClock::OwnerOutput,
                range,
                GainDb::UNITY,
                vec![GainSegment::new(range.end(), GainDb::UNITY, GainCurve::Step).unwrap()],
            )
            .unwrap(),
        ]
    } else {
        vec![]
    };
    leaf.audio_treatments = AudioTreatments::from_clip_gain(
        ClipGain::new(GainDb::new(6000).unwrap(), false, envelopes, vec![]).unwrap(),
    )
    .with_balance(Some(StereoBalance::new(-27).unwrap()))
    .unwrap();
    let mut wire = serde_json::to_value(document).unwrap();
    wire["nodes"] =
        serde_json::to_value(BTreeMap::from([(id("root"), root), (id("leaf"), leaf)])).unwrap();
    RenderPlan::compile(&ProjectDocument::from_json(&wire.to_string()).unwrap()).unwrap()
}

fn components<'plan>(plan: &'plan RenderPlan, control: WorkControl<'_>) -> Components<'plan> {
    let query = plan
        .audio_gain_owners(AudioSample(0)..AudioSample(8), Default::default())
        .unwrap();
    assert_eq!(query.spans().len(), 1);
    let layers: Vec<_> = query.spans()[0]
        .owners()
        .iter()
        .cloned()
        .map(|owner| {
            let until = owner.treatments().map_or(0, |recipe| recipe.order().len());
            (owner, until)
        })
        .collect();
    let mut result = Components::new(AudioSample(0), 8, None, &[]);
    let original = result
        .route(
            (0, Contribution::Original),
            layers.clone(),
            0..8,
            None,
            control,
        )
        .unwrap();
    let sound = result
        .route(
            (1, Contribution::Sound(Default::default())),
            layers,
            0..8,
            None,
            control,
        )
        .unwrap();
    result.allocate();
    for at in 0..8 {
        if at != 1 {
            result
                .add(original, at, ([0.17, -0.23], [0.01, -0.02]), 0, control)
                .unwrap();
        }
        if at != 6 {
            result
                .add(sound, at, ([-0.31, 0.19], [0.02, 0.03]), 1500, control)
                .unwrap();
        }
    }
    result
}

type Calls = Vec<(String, u8, usize, i64, Option<usize>, [bool; 2])>;

fn callback(
    calls: &mut Calls,
    owner: &AudioOwnerClock<'_>,
    temporal: Temporal,
    at: AudioSample,
    permissions: Permissions,
    voice: Option<usize>,
) -> Result<[f64; 2], StageAudioError> {
    calls.push((
        owner.instance().node.as_str().into(),
        match temporal {
            Temporal::Equalizer(_) => 0,
            Temporal::Wet(_) => 1,
        },
        match temporal {
            Temporal::Equalizer(stage) => stage,
            Temporal::Wet(TailEffect::Reverb) => 0,
            Temporal::Wet(TailEffect::Delay) => 1,
        },
        at.0,
        voice,
        [permissions.contains(0), permissions.contains(1)],
    ));
    let base = if matches!(temporal, Temporal::Wet(_)) {
        0.031
    } else {
        -0.127
    };
    let value = base + voice.unwrap_or(0) as f64 * 0.013 + at.0 as f64 * 0.001;
    Ok([value, -value])
}

fn assert_same(actual: &MixedBlock, expected: &MixedBlock) {
    assert_eq!(
        actual
            .samples
            .iter()
            .map(|s| s.map(f64::to_bits))
            .collect::<Vec<_>>(),
        expected
            .samples
            .iter()
            .map(|s| s.map(f64::to_bits))
            .collect::<Vec<_>>()
    );
    assert_eq!(actual.suppressed, expected.suppressed);
}

#[test]
fn reusable_prefix_matches_live_scalar_outputs_without_repeating_shared_callbacks() {
    let cancelled = AtomicBool::new(false);
    let work = RefCell::new(ReadWork::default());
    let control = control(&cancelled, &work);
    let constant = plan(false);
    let live = plan(true);
    let candidate = components(&constant, control);
    let reservation =
        candidate.resident_frames().unwrap() + candidate.reusable_metadata_frames().unwrap();
    let mut calls = Vec::new();
    let (first, prepared) = candidate
        .finish_reusable(Some(0), Permissions::default(), control, |a, b, c, d, e| {
            callback(&mut calls, a, b, c, d, e)
        })
        .unwrap();
    let prepared = prepared.unwrap();
    assert!(prepared.resident_frames().unwrap() <= reservation);
    let callback_count = calls.len();
    for selected in [None, Some(0), Some(1), Some(17)] {
        for alias in [None, Some(0), Some(1)] {
            let mut aliases = Permissions::default();
            if let Some(alias) = alias {
                aliases.insert(alias).unwrap();
            }
            let actual = prepared.mix(selected, aliases, control).unwrap();
            let mut expected_calls = Vec::new();
            let expected = components(&live, control)
                .finish(selected, aliases, control, |a, b, c, d, e| {
                    callback(&mut expected_calls, a, b, c, d, e)
                })
                .unwrap();
            assert_same(&actual, &expected);
            if selected == Some(0) && alias.is_none() {
                assert_same(&first, &expected);
            }
            let mut actual_calls = calls.clone();
            actual_calls.sort_by_key(|call| call.3);
            expected_calls.sort_by_key(|call| call.3);
            assert_eq!(actual_calls, expected_calls);
        }
    }
    assert_eq!(calls.len(), callback_count);
}

fn plain(control: WorkControl<'_>, values: &[(usize, [f64; 2], i32)]) -> Components<'static> {
    let mut result = Components::new(AudioSample(0), 1, None, &[]);
    for &(voice, _, _) in values {
        result
            .route((voice, Contribution::Original), vec![], 0..1, None, control)
            .unwrap();
    }
    result.allocate();
    for (route, &(_, value, gain)) in values.iter().enumerate() {
        result
            .add(route, 0, (value, [0.0; 2]), gain, control)
            .unwrap();
    }
    result
}

#[test]
fn reusable_prefix_keeps_route_order_instead_of_aggregating_equal_voice_ids() {
    let cancelled = AtomicBool::new(false);
    let work = RefCell::new(ReadWork::default());
    let control = control(&cancelled, &work);
    let (first, prepared) = plain(
        control,
        &[(0, [1e16; 2], 0), (1, [1.0; 2], 0), (0, [-1e16; 2], 0)],
    )
    .finish_reusable(None, Permissions::default(), control, |_, _, _, _, _| {
        panic!("plain routes have no temporal stage")
    })
    .unwrap();
    assert_eq!(first.samples, vec![[0.0; 2]]);
    let prepared = prepared.unwrap();
    let mut aliases = Permissions::default();
    aliases.insert(1).unwrap();
    assert_same(&first, &prepared.mix(Some(0), aliases, control).unwrap());
}

#[test]
fn reusable_prefix_does_not_apply_an_unselected_overflowing_final_transfer() {
    let cancelled = AtomicBool::new(false);
    let work = RefCell::new(ReadWork::default());
    let control = control(&cancelled, &work);
    let (first, prepared) = plain(control, &[(0, [0.25; 2], 0), (1, [f64::MAX; 2], 6000)])
        .finish_reusable(Some(0), Permissions::default(), control, |_, _, _, _, _| {
            panic!("plain routes have no temporal stage")
        })
        .unwrap();
    assert_eq!(first.samples, vec![[0.25; 2]]);
    let prepared = prepared.unwrap();
    assert_same(
        &first,
        &prepared
            .mix(Some(0), Permissions::default(), control)
            .unwrap(),
    );
    assert!(matches!(
        prepared.mix(Some(1), Permissions::default(), control),
        Err(StageAudioError::Preparation(
            PreparationError::InvalidSamples
        ))
    ));
}

#[test]
fn dynamic_prefix_falls_back_and_nonfinite_temporal_output_is_rejected() {
    let cancelled = AtomicBool::new(false);
    let work = RefCell::new(ReadWork::default());
    let control = control(&cancelled, &work);
    let dynamic = plan(true);
    let (_, prepared) = components(&dynamic, control)
        .finish_reusable(None, Permissions::default(), control, |_, _, _, _, _| {
            Ok([0.1; 2])
        })
        .unwrap();
    assert!(prepared.is_none());
    let constant = plan(false);
    assert!(matches!(
        components(&constant, control).finish_reusable(
            Some(0),
            Permissions::default(),
            control,
            |_, _, _, _, _| Ok([f64::NAN; 2])
        ),
        Err(StageAudioError::Preparation(
            PreparationError::InvalidSamples
        ))
    ));
}

#[test]
fn reusable_prefix_remains_cancelled_and_accounts_owned_storage() {
    let cancelled = AtomicBool::new(false);
    let work = RefCell::new(ReadWork::default());
    let control = control(&cancelled, &work);
    let (_, prepared) = plain(control, &[(0, [0.25; 2], 0)])
        .finish_reusable(None, Permissions::default(), control, |_, _, _, _, _| {
            panic!("plain routes have no temporal stage")
        })
        .unwrap();
    let prepared = prepared.unwrap();
    let minimum = std::mem::size_of::<Prepared>()
        + std::mem::size_of::<PreparedRoute>()
        + std::mem::size_of::<Sample>();
    assert!(prepared.resident_frames().unwrap() * 8 >= minimum as u64);
    cancelled.store(true, std::sync::atomic::Ordering::Relaxed);
    assert!(prepared.mix(None, Permissions::default(), control).is_err());
}
