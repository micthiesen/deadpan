//! Prepare a small output cohort in input-chunk order. Each later voice can
//! consume the all-route prefix that the preceding voice just prepared.

use super::*;

const COHORT: usize = 4;
// BTreeMap's partially filled nodes and the owned asset key are deliberately
// charged above their packed size, matching shared-prefix dependency storage.
const DEPENDENCY_FRAMES: u64 = 128;

struct History {
    voice: Option<usize>,
    left: Vec<f64>,
    right: Vec<f64>,
    dependencies: Dependencies,
    dependency_frames: u64,
    relative_depth: usize,
    failed: bool,
}

fn cohort(
    graph: &Graph<'_>,
    id: usize,
    key: (i64, Permissions, Option<usize>),
    control: WorkControl<'_>,
) -> Result<([Option<usize>; COHORT], usize), StageAudioError> {
    let mut result = [None; COHORT];
    result[0] = key.2;
    let Some(requested) = key.2 else {
        return Ok((result, 1));
    };
    if graph.prefix_inputs.is_none()
        || !key.1.contains(requested)
        || requested >= graph.voices.len()
    {
        return Ok((result, 1));
    }

    // IDs are dense and stable inside this graph. A rolling group needs only
    // one bounded scan to find the requested voice's permitted-rank cohort.
    let mut group = [None; COHORT];
    let mut count = 0;
    let mut found = false;
    for voice in 0..graph.voices.len() {
        control.spend_plan_work(1)?;
        if !key.1.contains(voice) {
            continue;
        }
        if count == COHORT {
            count = 0;
        }
        group[count] = Some(voice);
        count += 1;
        found |= voice == requested;
        if found && count == COHORT {
            break;
        }
    }
    let mut used = 1;
    for voice in group[..count].iter().copied().flatten() {
        if voice != requested
            && !graph.nodes[id]
                .tiles
                .contains_key(&(key.0, key.1, Some(voice)))
        {
            result[used] = Some(voice);
            used += 1;
        }
    }
    Ok((result, used))
}

fn transient_frames(input: usize, output: usize, count: usize) -> Result<u64, StageAudioError> {
    let pcm = input
        .checked_mul(2)
        .and_then(|n| n.checked_mul(count))
        .and_then(|n| output.checked_mul(4).and_then(|out| n.checked_add(out)))
        .ok_or(StageAudioError::Limit("temporal cohort residency"))?;
    let headers = count
        .checked_mul(std::mem::size_of::<History>())
        .and_then(|n| n.checked_add(std::mem::size_of::<Vec<History>>() + 1024))
        .ok_or(StageAudioError::Limit("temporal cohort residency"))?;
    u64::try_from(pcm)
        .ok()
        .and_then(|n| n.checked_add((headers as u64).div_ceil(8)))
        .ok_or(StageAudioError::Limit("temporal cohort residency"))
}

fn tile_overhead_frames() -> u64 {
    // A newly allocated BTree node can hold eleven entries but initially has
    // only one. Charge its maximum node allocation to every retained entry.
    let bytes = 16
        * (std::mem::size_of::<Arc<WideBlock>>()
            + std::mem::size_of::<(i64, Permissions, Option<usize>)>()
            + 3 * std::mem::size_of::<usize>())
        + 16 * (std::mem::size_of::<CachedTile>() + 3 * std::mem::size_of::<usize>())
        + std::mem::size_of::<WideBlock>()
        + 2 * std::mem::size_of::<usize>();
    (bytes as u64).div_ceil(8)
}

fn tile_resident(capacity: usize, dependencies: u64) -> Result<u64, StageAudioError> {
    let bytes = capacity
        .checked_mul(std::mem::size_of::<[f64; 2]>())
        .ok_or(StageAudioError::Limit("temporal tile residency"))?;
    (bytes as u64)
        .div_ceil(8)
        .checked_add(tile_overhead_frames())
        .and_then(|n| n.checked_add(dependencies))
        .ok_or(StageAudioError::Limit("temporal tile residency"))
}

fn charge_prepared(
    control: WorkControl<'_>,
    frames: u64,
    maximum: u64,
) -> Result<(), StageAudioError> {
    let mut work = control.work.borrow_mut();
    work.prepared_frames = work
        .prepared_frames
        .checked_add(frames)
        .ok_or(StageAudioError::Limit("prepared frames per read"))?;
    if work.prepared_frames > maximum {
        return Err(StageAudioError::Limit("prepared frames per read"));
    }
    Ok(())
}

fn discard_history(history: &mut History) -> u64 {
    let released = history.left.capacity() as u64
        + history.right.capacity() as u64
        + history.dependency_frames;
    history.left = Vec::new();
    history.right = Vec::new();
    history.dependencies = Dependencies::new();
    history.dependency_frames = 0;
    history.failed = true;
    released
}

fn discard_optional(histories: &mut Vec<History>, count: &mut usize, input: usize) -> u64 {
    // The first requested read can fail before sibling histories are allocated.
    let unallocated = (*count - histories.len()) as u64 * input as u64 * 2;
    let released = unallocated
        + histories
            .iter_mut()
            .skip(1)
            .map(discard_history)
            .sum::<u64>();
    histories.truncate(1);
    *count = 1;
    released
}

fn discard_remaining(histories: &mut Vec<History>) -> u64 {
    let released = histories.iter_mut().map(discard_history).sum();
    histories.clear();
    released
}

impl StageAudio {
    pub(super) fn compute_shared_eq_tiles(
        &mut self,
        provider: &mut impl AudioSourceProvider,
        graph: &mut Graph<'_>,
        id: usize,
        key: (i64, Permissions, Option<usize>),
        control: WorkControl<'_>,
        depth: usize,
    ) -> Result<Arc<WideBlock>, StageAudioError> {
        control.check()?;
        let kind = graph.nodes[id].kind;
        let (history, input, output) = match kind {
            Temporal::Equalizer(_) => (RADIUS, INPUT, OUTPUT),
            Temporal::Wet(effect) => {
                let shape = crate::wet_effect_descriptor(effect);
                (
                    shape.history_frames,
                    shape.history_frames + shape.output_frames,
                    shape.output_frames,
                )
            }
        };
        if input as u32 > self.limits.maximum_input_frames
            || output as u32 > self.limits.maximum_output_frames
        {
            return Err(StageAudioError::Limit("temporal input/output frames"));
        }
        let begin = key
            .0
            .checked_sub(history as i64)
            .ok_or(TimeError::Overflow)?;
        let end = begin.checked_add(input as i64).ok_or(TimeError::Overflow)?;
        let (voices, mut count) = cohort(graph, id, key, control)?;
        let prepared = (input as u64)
            .checked_add(output as u64)
            .ok_or(StageAudioError::Limit("prepared frames per read"))?;
        let available = self
            .limits
            .maximum_prepared_frames
            .saturating_sub(control.work.borrow().prepared_frames)
            / prepared;
        count = count.min(usize::try_from(available).unwrap_or(usize::MAX).max(1));
        let mut reservation = transient_frames(input, output, count)?;
        if count > 1 {
            // Account for the eventual retained outputs too. Dependencies are
            // reserved separately, before each actual map insertion below.
            let retained = (output as u64)
                .checked_mul(2)
                .and_then(|n| n.checked_add(tile_overhead_frames()))
                .and_then(|n| n.checked_mul(count as u64))
                .ok_or(StageAudioError::Limit("temporal cohort residency"))?;
            let fits = self
                .cached_resident_frames()
                .checked_add(self.active_frames)
                .and_then(|n| n.checked_add(control.work.borrow().projected_resident_frames))
                .and_then(|n| n.checked_add(reservation))
                .and_then(|n| n.checked_add(retained))
                .is_some_and(|n| n <= u64::from(self.limits.maximum_resident_frames));
            if !fits {
                count = 1;
                reservation = transient_frames(input, output, count)?;
            }
        }
        charge_prepared(control, prepared, self.limits.maximum_prepared_frames)?;
        self.make_room(reservation, false, control)?;
        self.active_frames = self
            .active_frames
            .checked_add(reservation)
            .ok_or(StageAudioError::Range)?;
        let context = graph.nodes[id].context.clone();
        let boundary = graph.nodes[id].stop.clone();
        let filter = match kind {
            Temporal::Equalizer(_) => graph.nodes[id].filter.take(),
            Temporal::Wet(_) => None,
        };
        // All fallible work after taking the filter stays within this closure,
        // so both the filter and the growing transient reservation are restored.
        let mut filter = filter;
        let result = (|| {
            if matches!(kind, Temporal::Equalizer(_)) && filter.is_none() {
                return Err(PlanError::InvalidPlan("recursive EQ cycle").into());
            }
            let mut histories = Vec::with_capacity(count);
            let new_history = |voice| History {
                voice,
                left: vec![0.0; input],
                right: vec![0.0; input],
                dependencies: Dependencies::new(),
                dependency_frames: 0,
                relative_depth: 1,
                failed: false,
            };
            histories.push(new_history(voices[0]));
            let mut at = begin;
            while at < end {
                let frames = u32::try_from((end - at).min(i64::from(MAX_OUTPUT_FRAMES)))
                    .map_err(|_| StageAudioError::Range)?;
                let mut index = 0;
                while index < histories.len() {
                    if histories[index].failed {
                        index += 1;
                        continue;
                    }
                    let voice = histories[index].voice;
                    let program = Program {
                        context: &context,
                        stop: Some(&boundary),
                        allowed: Some(key.1),
                        output_voice: voice,
                        parent: id,
                        depth,
                    };
                    let prefix = prefix_inputs::key(graph, program, AudioSample(at), frames);
                    let block = if index == 0 {
                        match self.read_shared_program(
                            provider,
                            graph,
                            program,
                            AudioSample(at),
                            frames,
                            control,
                        ) {
                            Ok(block) => block,
                            Err(StageAudioError::Limit("resident PCM or stage cache"))
                                if count > 1 =>
                            {
                                let released = discard_optional(&mut histories, &mut count, input);
                                self.active_frames -= released;
                                reservation -= released;
                                self.read_shared_program(
                                    provider,
                                    graph,
                                    program,
                                    AudioSample(at),
                                    frames,
                                    control,
                                )?
                            }
                            Err(error) => return Err(error),
                        }
                    } else {
                        let block = match (prefix, voice) {
                            (Some(prefix), Some(voice)) => self.cached_shared_prefix(
                                provider,
                                graph,
                                prefix,
                                (voice, true),
                                control,
                            )?,
                            _ => None,
                        };
                        let Some(block) = block else {
                            let released = discard_history(&mut histories[index]);
                            self.active_frames -= released;
                            reservation -= released;
                            index += 1;
                            continue;
                        };
                        block
                    };
                    let new = block
                        .dependencies
                        .keys()
                        .filter(|asset| !histories[index].dependencies.contains_key(*asset))
                        .count();
                    control.spend_plan_work(block.dependencies.len())?;
                    let extra = (new as u64)
                        .checked_mul(DEPENDENCY_FRAMES)
                        .ok_or(StageAudioError::Limit("temporal dependency residency"))?;
                    let next_dependency = histories[index]
                        .dependency_frames
                        .checked_add(extra)
                        .ok_or(StageAudioError::Range)?;
                    match self.make_room(extra, false, control) {
                        Ok(()) => {}
                        Err(StageAudioError::Limit("resident PCM or stage cache"))
                            if index != 0 =>
                        {
                            let released = discard_history(&mut histories[index]);
                            self.active_frames -= released;
                            reservation -= released;
                            index += 1;
                            continue;
                        }
                        Err(StageAudioError::Limit("resident PCM or stage cache")) if count > 1 => {
                            let released = discard_optional(&mut histories, &mut count, input);
                            self.active_frames -= released;
                            reservation -= released;
                            self.make_room(extra, false, control)?;
                        }
                        Err(error) => return Err(error),
                    }
                    self.active_frames = self
                        .active_frames
                        .checked_add(extra)
                        .ok_or(StageAudioError::Range)?;
                    // A required reservation may have dropped optional histories.
                    reservation = reservation
                        .checked_add(extra)
                        .ok_or(StageAudioError::Range)?;
                    let candidate = &mut histories[index];
                    candidate.dependency_frames = next_dependency;
                    for (index, frame) in block.samples.iter().enumerate() {
                        candidate.left[(at - begin) as usize + index] = frame[0];
                        candidate.right[(at - begin) as usize + index] = frame[1];
                    }
                    candidate.dependencies.extend(block.dependencies);
                    candidate.relative_depth = candidate.relative_depth.max(
                        block
                            .relative_depth
                            .checked_add(1)
                            .ok_or(StageAudioError::Limit("nested stage depth"))?,
                    );
                    if at == begin && index == 0 && count > 1 {
                        let reusable = match (graph.prefix_inputs.as_ref(), prefix) {
                            (Some(cache), Some(prefix)) => {
                                cache.has_payload(self, prefix, control)?
                            }
                            _ => false,
                        };
                        if reusable {
                            let available = self
                                .limits
                                .maximum_prepared_frames
                                .saturating_sub(control.work.borrow().prepared_frames)
                                / prepared;
                            let permitted = 1
                                + (count - 1).min(usize::try_from(available).unwrap_or(usize::MAX));
                            let unused = (input as u64) * 2 * (count - permitted) as u64;
                            self.active_frames -= unused;
                            reservation -= unused;
                            count = permitted;
                            let extra = prepared
                                .checked_mul((count - 1) as u64)
                                .ok_or(StageAudioError::Limit("prepared frames per read"))?;
                            charge_prepared(control, extra, self.limits.maximum_prepared_frames)?;
                            for voice in &voices[1..count] {
                                histories.push(new_history(*voice));
                            }
                        } else {
                            // Dynamic or unretained prefixes keep their scalar
                            // traversal. Release unused PCM before continuing.
                            let unused = (input as u64) * 2 * (count - 1) as u64;
                            self.active_frames -= unused;
                            reservation -= unused;
                            count = 1;
                        }
                    }
                    index += 1;
                }
                at += i64::from(frames);
            }
            let mut requested = None;
            while !histories.is_empty() {
                control.spend_plan_work(histories.len())?;
                let mut candidate = histories.remove(0);
                if candidate.failed {
                    continue;
                }
                let mut out_left = vec![0.0; output];
                let mut out_right = vec![0.0; output];
                if let Some(filter) = &mut filter {
                    match filter.process_tile(
                        &candidate.left,
                        &candidate.right,
                        &mut out_left,
                        &mut out_right,
                        control.cancelled,
                    ) {
                        Ok(()) => {}
                        Err(deadpan_dsp::FilterError::InvalidInput) if candidate.voice != key.2 => {
                            let released = discard_history(&mut candidate);
                            self.active_frames -= released;
                            reservation -= released;
                            continue;
                        }
                        Err(error) => return Err(error.into()),
                    }
                } else if let Temporal::Wet(effect) = kind {
                    match self.process_shared_wet(
                        graph,
                        effect,
                        (&candidate.left, &candidate.right),
                        (&mut out_left, &mut out_right),
                        control,
                    ) {
                        Ok(()) => {}
                        Err(StageAudioError::Wet(deadpan_dsp::CausalFilterError::InvalidInput))
                            if candidate.voice != key.2 =>
                        {
                            let released = discard_history(&mut candidate);
                            self.active_frames -= released;
                            reservation -= released;
                            continue;
                        }
                        Err(StageAudioError::Limit("resident PCM or stage cache"))
                            if candidate.voice == key.2 && !histories.is_empty() =>
                        {
                            let released = discard_remaining(&mut histories);
                            self.active_frames -= released;
                            reservation -= released;
                            self.process_shared_wet(
                                graph,
                                effect,
                                (&candidate.left, &candidate.right),
                                (&mut out_left, &mut out_right),
                                control,
                            )?;
                        }
                        Err(StageAudioError::Limit("resident PCM or stage cache"))
                            if candidate.voice != key.2 =>
                        {
                            let released = discard_history(&mut candidate);
                            self.active_frames -= released;
                            reservation -= released;
                            continue;
                        }
                        Err(error) => return Err(error),
                    }
                }
                let samples: Vec<[f64; 2]> = out_left
                    .into_iter()
                    .zip(out_right)
                    .map(|(left, right)| [left, right])
                    .collect();
                control.check()?;
                let resident = tile_resident(samples.capacity(), candidate.dependency_frames)?;
                let block = Arc::new(WideBlock {
                    samples,
                    suppressed: Vec::new(),
                    dependencies: candidate.dependencies,
                    relative_depth: candidate.relative_depth,
                });
                if candidate.voice != key.2 {
                    self.retain_shared_sibling(
                        graph,
                        (id, (key.0, key.1, candidate.voice)),
                        block,
                        resident,
                        control,
                    )?;
                    continue;
                }
                // Dependency nodes move from the history into the retained
                // tile; only the output and entry storage needs a new charge.
                let additional = resident - candidate.dependency_frames;
                let next_resident = graph
                    .resident
                    .checked_add(resident)
                    .ok_or(StageAudioError::Range)?;
                match self.make_room(additional, false, control) {
                    Ok(()) => {}
                    Err(StageAudioError::Limit("resident PCM or stage cache"))
                        if !histories.is_empty() =>
                    {
                        let released = discard_remaining(&mut histories);
                        self.active_frames -= released;
                        reservation -= released;
                        self.make_room(additional, false, control)?;
                    }
                    Err(error) => return Err(error),
                }
                self.active_frames = self
                    .active_frames
                    .checked_add(additional)
                    .ok_or(StageAudioError::Range)?;
                graph.resident = next_resident;
                reservation -= candidate.dependency_frames;
                graph.nodes[id]
                    .tiles
                    .insert((key.0, key.1, candidate.voice), Arc::clone(&block));
                if candidate.voice == key.2 {
                    requested = Some(block);
                }
            }
            requested.ok_or(PlanError::InvalidPlan("requested temporal tile absent").into())
        })();
        graph.nodes[id].filter = filter;
        self.active_frames -= reservation;
        result
    }
}
