//! Exact temporal-prefix reuse across selected outputs. Payloads own ordered
//! contribution PCM, not borrowed queries or inferred sound permissions.

use super::*;

#[derive(Clone, Copy, PartialEq, Eq, PartialOrd, Ord)]
pub(super) struct Key {
    parent: usize,
    start: i64,
    frames: u32,
    depth: usize,
    allowed: Permissions,
}

struct Entry {
    key: Key,
    payload: u64,
    age: u64,
}

pub(super) struct Cache<'plan> {
    scope: Arc<()>,
    entries: Vec<Entry>,
    clocked_assets: Vec<&'plan AssetId>,
    age: u64,
    pub(super) hits: usize,
}

pub(in crate::stages) struct Cached {
    block: Arc<Payload>,
    pub(in crate::stages) resident: u64,
}

struct Payload {
    scope: Arc<()>,
    prepared: shared_components::Prepared,
    families: Vec<(usize, usize)>,
    dependencies: Dependencies,
    relative_depth: usize,
}

impl<'plan> Cache<'plan> {
    pub(super) fn scope(&self) -> &Arc<()> {
        &self.scope
    }
    pub(super) fn metadata_frames(slots: usize) -> Result<u64, StageAudioError> {
        let bytes = slots
            .checked_mul(std::mem::size_of::<Entry>())
            .and_then(|n| {
                n.checked_add(deadpan_core::MAX_DOCUMENT_SOUNDS * std::mem::size_of::<&AssetId>())
            })
            .and_then(|n| n.checked_add(std::mem::size_of::<Self>() + 1024))
            .ok_or(StageAudioError::Limit("shared prefix metadata"))?;
        Ok((bytes as u64).div_ceil(8))
    }

    pub(super) fn new(
        plan: &'plan RenderPlan,
        slots: usize,
        control: WorkControl<'_>,
    ) -> Result<Self, StageAudioError> {
        let mut clocked_assets = Vec::with_capacity(deadpan_core::MAX_DOCUMENT_SOUNDS);
        for (owner, sounds) in plan.beat_sounds() {
            for (sound, event) in sounds {
                control.spend_plan_work(1)?;
                if plan.beat_sound_clock_count(owner, sound) > 0 {
                    if clocked_assets.len() == deadpan_core::MAX_DOCUMENT_SOUNDS {
                        return Err(StageAudioError::Limit("shared prefix sound assets"));
                    }
                    clocked_assets.push(&event.source.asset);
                }
            }
        }
        clocked_assets.sort_unstable();
        clocked_assets.dedup();
        Ok(Self {
            scope: Arc::new(()),
            entries: Vec::with_capacity(slots),
            clocked_assets,
            age: 0,
            hits: 0,
        })
    }

    fn find(&self, key: Key, control: WorkControl<'_>) -> Result<Option<usize>, StageAudioError> {
        let mut low = 0;
        let mut high = self.entries.len();
        while low < high {
            control.spend_plan_work(1)?;
            let middle = low + (high - low) / 2;
            if self.entries[middle].key < key {
                low = middle + 1;
            } else {
                high = middle;
            }
        }
        control.spend_plan_work(1)?;
        Ok((low < self.entries.len() && self.entries[low].key == key).then_some(low))
    }

    pub(super) fn has_payload(
        &self,
        controller: &StageAudio,
        key: Key,
        control: WorkControl<'_>,
    ) -> Result<bool, StageAudioError> {
        Ok(self.find(key, control)?.is_some_and(|at| {
            controller
                .shared_prefixes
                .get(&self.entries[at].payload)
                .is_some_and(|payload| Arc::ptr_eq(&payload.block.scope, &self.scope))
        }))
    }

    fn remove(
        &mut self,
        at: usize,
        controller: &mut StageAudio,
        control: WorkControl<'_>,
    ) -> Result<(), StageAudioError> {
        control.spend_plan_work(self.entries.len() - at)?;
        controller
            .shared_prefixes
            .remove(&self.entries.remove(at).payload);
        Ok(())
    }

    pub(super) fn clear(&mut self, controller: &mut StageAudio) {
        for entry in self.entries.drain(..) {
            controller.shared_prefixes.remove(&entry.payload);
        }
    }
}

fn same_original(left: &Context<'_>, right: &Context<'_>) -> bool {
    match (left, right) {
        (Context::Root, Context::Root) => true,
        (Context::Domain(a), Context::Domain(b)) => Arc::ptr_eq(a, b),
        (Context::Retained(a), Context::Retained(b)) => Arc::ptr_eq(a, b),
        _ => false,
    }
}

/// Node identity fixes the context and stop boundary; verify that invariant
/// rather than treating a caller-supplied node number as authority.
pub(super) fn key(
    graph: &Graph<'_>,
    program: Program<'_, '_>,
    start: AudioSample,
    frames: u32,
) -> Option<Key> {
    graph.prefix_inputs.as_ref()?;
    let output = program.output_voice?;
    let allowed = program.allowed?;
    if !allowed.contains(output) {
        return None;
    }
    let node = graph.nodes.get(program.parent)?;
    let stop = program.stop?;
    if stop.owner != node.stop.owner
        || stop.before != node.stop.before
        || !same_original(&program.context.original, &node.context.original)
        || !match (&program.context.sounds, &node.context.sounds) {
            (Sounds::Root, Sounds::Root) | (Sounds::None, Sounds::None) => true,
            (Sounds::Owner(a), Sounds::Owner(b)) => Arc::ptr_eq(a, b),
            _ => false,
        }
    {
        return None;
    }
    Some(Key {
        parent: program.parent,
        start: start.0,
        frames,
        depth: program.depth,
        allowed,
    })
}

fn aliases(
    families: &[(usize, usize)],
    selected: usize,
    control: WorkControl<'_>,
) -> Result<Permissions, StageAudioError> {
    let mut result = Permissions::default();
    for (voice, family) in families {
        if *voice == selected {
            continue;
        }
        for (candidate, other) in families {
            if *candidate != selected {
                continue;
            }
            control.spend_plan_work(1)?;
            if family == other {
                result.insert(*voice)?;
                break;
            }
        }
    }
    Ok(result)
}

/// Speculative PCM does not establish continued source authority. A conservative
/// contextual refusal discards it so an ordinary read can decide relevance.
pub(super) fn admit_dependencies(
    provider: &mut impl AudioSourceProvider,
    graph: &Graph<'_>,
    dependencies: &Dependencies,
    control: WorkControl<'_>,
) -> Result<bool, StageAudioError> {
    for (asset, fingerprint) in dependencies {
        control.spend_plan_work(1)?;
        let source = resolve_source(provider, graph.plan, asset, control.cancelled)?;
        if control.observe(asset, source)? != *fingerprint {
            return Err(PreparationError::IndexMismatch.into());
        }
        if graph.plan.audio_context_assets().is_none()
            && graph
                .prefix_inputs
                .as_ref()
                .is_some_and(|cache| cache.clocked_assets.binary_search(&asset).is_ok())
        {
            let contract = graph
                .plan
                .audio_asset_contract(asset)
                .ok_or(PlanError::InvalidPlan("cached sound contract absent"))?;
            let meta = graph.plan.metadata();
            let source = match provider.source_for_context(
                &meta.project_id,
                &meta.revision_id,
                asset,
                contract,
                control.cancelled,
            ) {
                Ok(source) => source,
                Err(PreparationError::SourceUnavailable(_)) => return Ok(false),
                Err(error) => return Err(error.into()),
            };
            if control.observe(asset, source)? != *fingerprint {
                return Err(PreparationError::IndexMismatch.into());
            }
        }
    }
    Ok(true)
}

impl StageAudio {
    pub(in crate::stages) fn evict_shared_prefix(
        &mut self,
        control: WorkControl<'_>,
    ) -> Result<bool, StageAudioError> {
        for (&key, cached) in &self.shared_prefixes {
            control.spend_plan_work(1)?;
            if Arc::strong_count(&cached.block) == 1 {
                self.shared_prefixes.remove(&key);
                return Ok(true);
            }
        }
        Ok(false)
    }

    pub(super) fn cached_shared_prefix(
        &mut self,
        provider: &mut impl AudioSourceProvider,
        graph: &mut Graph<'_>,
        key: Key,
        (output, speculative): (usize, bool),
        control: WorkControl<'_>,
    ) -> Result<Option<WideBlock>, StageAudioError> {
        control.check()?;
        if !std::ptr::eq(graph.plan, self.plan.as_ref()) {
            return Err(StageAudioError::ForeignDomain);
        }
        let Some(cache) = &mut graph.prefix_inputs else {
            return Ok(None);
        };
        let Some(at) = cache.find(key, control)? else {
            return Ok(None);
        };
        let id = cache.entries[at].payload;
        let Some(cached) = self.shared_prefixes.get(&id) else {
            cache.remove(at, self, control)?;
            return Ok(None);
        };
        let block = Arc::clone(&cached.block);
        if !Arc::ptr_eq(&block.scope, &cache.scope) {
            return Err(StageAudioError::ForeignDomain);
        }
        if key
            .depth
            .checked_add(block.relative_depth)
            .is_none_or(|v| v > self.limits.maximum_depth)
        {
            return Err(StageAudioError::Limit("nested stage depth"));
        }
        if !admit_dependencies(provider, graph, &block.dependencies, control)? {
            graph
                .prefix_inputs
                .as_mut()
                .unwrap()
                .remove(at, self, control)?;
            return Ok(None);
        }
        let cache = graph.prefix_inputs.as_mut().unwrap();
        let output_aliases = aliases(&block.families, output, control)?;
        // Returned wide PCM, worst-case suppression intervals and cloned
        // dependency map coexist with the pinned optional payload.
        // Vec growth plus merged_suppression can temporarily retain two
        // interval arrays (at most 2N capacity + N exact slots), beside N
        // stereo-f64 samples. Fixed slack covers tiny-Vec minimum capacities.
        let reservation = u64::from(key.frames) * 8 + block.dependencies.len() as u64 * 128 + 128;
        if let Err(error) = self.make_room(reservation, false, control) {
            if matches!(error, StageAudioError::Limit("resident PCM or stage cache")) {
                drop(block);
                cache.remove(at, self, control)?;
                return Ok(None);
            }
            return Err(error);
        }
        self.active_frames += reservation;
        let result = block
            .prepared
            .mix(Some(output), output_aliases, control)
            .map(|mixed| WideBlock {
                samples: mixed.samples,
                suppressed: mixed.suppressed,
                dependencies: block.dependencies.clone(),
                relative_depth: block.relative_depth,
            });
        self.active_frames -= reservation;
        cache.age = cache.age.wrapping_add(1);
        cache.entries[at].age = cache.age;
        cache.hits += usize::from(result.is_ok());
        match result {
            Err(StageAudioError::Preparation(PreparationError::InvalidSamples)) if speculative => {
                Ok(None)
            }
            other => other.map(Some),
        }
    }

    pub(super) fn retain_shared_prefix(
        &mut self,
        graph: &mut Graph<'_>,
        key: Key,
        prepared: shared_components::Prepared,
        families: &[(usize, FamilyToken<'_>)],
        output: &WideBlock,
        control: WorkControl<'_>,
    ) -> Result<(), StageAudioError> {
        let dependencies = &output.dependencies;
        let Some(cache) = &mut graph.prefix_inputs else {
            return Ok(());
        };
        let extra_bytes = families
            .len()
            .checked_mul(std::mem::size_of::<(usize, usize)>())
            .and_then(|v| v.checked_add(dependencies.len() * 1024))
            .and_then(|v| v.checked_add(std::mem::size_of::<Payload>() + 1024))
            .ok_or(StageAudioError::Limit("shared prefix residency"))?;
        let resident = prepared
            .resident_frames()?
            .checked_add((extra_bytes as u64).div_ceil(8))
            .ok_or(StageAudioError::Limit("shared prefix residency"))?;
        let Some(next) = self.next_original_input.checked_add(1) else {
            return Ok(());
        };
        if let Some(at) = cache.find(key, control)? {
            cache.remove(at, self, control)?;
        }
        if cache.entries.len() == cache.entries.capacity() {
            control.spend_plan_work(cache.entries.len())?;
            let oldest = cache
                .entries
                .iter()
                .enumerate()
                .filter(|(_, e)| {
                    self.shared_prefixes
                        .get(&e.payload)
                        .is_none_or(|c| Arc::strong_count(&c.block) == 1)
                })
                .min_by_key(|(_, e)| e.age)
                .map(|(at, _)| at);
            let Some(at) = oldest else {
                return Ok(());
            };
            cache.remove(at, self, control)?;
        }
        loop {
            let fits = self
                .cached_resident_frames()
                .checked_add(self.active_frames)
                .and_then(|n| n.checked_add(control.work.borrow().projected_resident_frames))
                .and_then(|n| n.checked_add(resident))
                .is_some_and(|n| n <= u64::from(self.limits.maximum_resident_frames));
            if fits
                && self.cache.len()
                    + self.original_inputs.len()
                    + self.shared_prefixes.len()
                    + self.shared_siblings.len()
                    < self.limits.maximum_cached_stages
            {
                break;
            }
            if !self.evict_shared_sibling(control)?
                && !self.evict_shared_prefix(control)?
                && !self.evict_original_input(control)?
            {
                return Ok(());
            }
        }
        control.spend_plan_work(families.len() + dependencies.len() + cache.entries.len() + 1)?;
        let families = families
            .iter()
            .map(|(voice, family)| (*voice, family.ordinal()))
            .collect();
        let payload = self.next_original_input;
        self.next_original_input = next;
        let block = Arc::new(Payload {
            scope: Arc::clone(&cache.scope),
            prepared,
            families,
            dependencies: dependencies.clone(),
            relative_depth: output.relative_depth,
        });
        cache.age = cache.age.wrapping_add(1);
        let at = cache.entries.partition_point(|entry| entry.key < key);
        cache.entries.insert(
            at,
            Entry {
                key,
                payload,
                age: cache.age,
            },
        );
        self.shared_prefixes
            .insert(payload, Cached { block, resident });
        Ok(())
    }
}

#[cfg(all(test, any(target_os = "macos", target_os = "linux")))]
#[path = "prefix_inputs_tests.rs"]
mod tests;
