# Independent policy reconciliation review

No material finding in the current reviewed source. The third policy receipt adjustment is bounded by actual constructor/issuer/host receipts and by literal whole-matrix comparisons. It does not normalize arbitrary work fields or PCM.

This is a source review only. No Git, Cargo, native execution, captures, expected generation or actual repository writes were performed. Parent-reported Audio passes (Main 412 / Scope 406) and final policy module passes (13, including dense Domain refusal at exactly 65536 accepted / zero live and two successful dense Roots) were not used as correctness premises.

## Authority and scope

Reviewed current Scope:
- crates/deadpan-audio/src/authored_eq/legacy_tile_baseline.rs
- crates/deadpan-audio/src/authored_eq/tile_admission_tests.rs
- crates/deadpan-audio/src/original_request.rs
- crates/deadpan-audio/src/original_request/domain_policy_trace.rs
- crates/deadpan-audio/src/original_request/flattened_work_trace.rs
- crates/deadpan-audio/src/original_request/processing_admission_tests.rs
- crates/deadpan-audio/src/original_request/processing_policy_admission_tests.rs
- crates/deadpan-audio/src/original_request/policy_admission_tests.rs
- shared_eq/original_inputs.rs eviction receipt site.

All nine current files are byte-identical between Main and Scope. For the seven files available in integration-before and the processing checkpoint's published-source, those before copies are byte-identical to published-source; the six queried before copies also match main-initial-authority.json. This establishes comparison to the retained published checkpoint source without running Git or claiming a fresh remote/HEAD verification.

The authored fixture SHA-256 currently is 6dc6f9371528cf6229fa3e0c2e85ffc911f5ba4f687d3141c6e66758a06ce71a. It remains an include_str reference. No expected writes are in the test comparison.

## Third policy receipt proof

The only legacy_tile_baseline source change from the retained checkpoint copy is the explicit policy_work_trace snapshot field at counters line 55. It reports the actual third product snapshot. The complete output serializer still emits all stereo f64 bit patterns, suppression, capacities, dependencies and relative depth (lines 33-42).

tile_admission_tests query_fees (line 39) first rejects nested/invalid/overflow flags, nonzero active depth and excess depth. Each lane requires constructor_calls = completed_queries + failed_queries and:

accepted_work = canonical_units + additional_units + partial_work + host_eviction_work.

It also requires issuer_checks = issuer_work. The matrix accepts only partial_work = 0, with a diagnostic requiring separate OLD-work qualification for a real partial refusal. It does not overwrite partial work, turn it into zero, or subtract it as a fee. The allowed independent fee is additional_units + issuer_work. Canonical units are not included as newly removable fees.

The trace source supports this interpretation. ScopeGuard samples the actual ReadWork plan/cache counters and global host receipt at constructor entry/exit. A completed constructor must report was_forwarded and canonical + additional = total; its actual counter delta excluding in-scope host eviction must equal total. A failure records actual accepted delta excluding host as partial_work. Issuer work is recorded after its real separate spend succeeds and outside constructor guards.

compare_flattened_counter (line 124) removes exactly the three named instrumentation objects from actual and current ordinary reference. The reference lane fields must all be zero, including the newly added policy trace. It checks actual counters against OLD plus independently witnessed fees and the signed host receipt difference before replacing those two already-proved counter scalars. All other controller/resource/cache fields then compare literally. The imposed-controller case deliberately fixes plan work, already imposed by the operation; compare_flattened_matrix separately requires unchanged constructor traces across that operation.

All three product snapshots must expose the same global all_host_eviction_work pair. That receipt is added as current minus OLD once after summing the three products' fee categories. Per-product in-constructor host_eviction_work is used only to prove constructor conservation and is not added again. OLD global host work is not assumed zero.

reconcile_paired_flat_host_receipts (line 82) additionally keeps the non-host flattened accepted total equal between the two current Domain paths; only its separately checked accepted/host receipt scalars are aligned, then the complete remaining trace objects must be equal.

## Domain policy savings and canonical work

domain_policy_trace now stores canonical/additional policy counts from the actual admitted carrier. record_admitted checks their sum against the actual borrowed policy.work before recording. Ordinary record explicitly supplies (policy.work, 0). Admitted Original construction records these categories from policy.canonical_units()/additional_units(), not from a difference to expected output.

reconcile_domain_policy_receipts (line 494) checks both first processing and policy total/category equations for both paths. First processing canonical work remains exactly equal. Policy canonical savings are old canonical minus current canonical with checked subtraction. Any nonzero saving requires nonempty samples and actual content-only eligibility, and must equal exactly the unchanged first processing canonical receipt. Each policy lookup statistic must separately decrease by exactly its corresponding first processing lookup statistic, or remain unchanged when no saving occurred. An arbitrary canonical change cannot be hidden by adding it to the fee allowance.

The per-row comparison aligns only six explicitly proven scalars/lookup fields, then requires the complete remaining row equal: Domain instance/root/visible range, requested range, first canonical work, first lookup, eligibility and row order remain literal. There is no traversal-wide work-key filter.

compare_domain_policy_counter (line 587) applies the signed processing fee difference plus signed policy fee difference plus signed global host difference once, then subtracts the independently qualified canonical saving in the plan lane only. Cache savings remain zero. Other controller/resource/cache fields compare literally. No accepted partial work is excused here.

## Whole-output chain and error treatment

compare_matrix (line 384) retains four actual paths:
1. direct capture with the explicit literal separate Domain processing/policy route;
2. direct capture with current admitted sealed Domain reuse;
3. current certified capture;
4. full ordinary Original query reference.

Current reuse versus separate Domain queries is qualified by the per-row canonical/lookup receipts. Certified versus direct requires all three Original product receipt snapshots equal and qualifies only actual span-start query savings. Current Original admission versus full ordinary queries qualifies actual query/issuer fees and the one global host difference. The ordinary reference then compares to the original frozen authored case using the pre-existing exact tile-index/layout proof.

At each matrix stage the complete cases/operations compare after only those checked fields are aligned. PCM bits, suppression, dependencies, relative depth, source/provider observations, cache outcomes and ordinary errors remain in that full comparison.

The pre-existing imposed tile-index exhaustion branch at lines 458-474 still explicitly validates the two literal errors (old nested stage depth versus current plan work per read), requires zero newly accepted index fee, and aligns that exact result. This is an existing narrow error-order exception, not a new policy exception. The new policy reconciliation does not broaden it or edit any PCM/error body.

The aggregate constructor fee trace does not itself prove a per-query canonical receipt for every Root request. Its role here is measured additional fees and actual total conservation. Per-row Domain canonical/lookup proof, complete actual operation equality and the separate Plan frozen policy tests supply the more specific semantic evidence. The review does not claim unrecorded per-Root fields exist.

## Processing test isolation and default-policy coverage

The retained processing_admission_tests diff contains only a comment and four test wrappers/new helper names. Original bodies and all assertions remain intact. processing_policy_admission_tests similarly adds one wrapper and leaves its real bound Source/Unrelated WAV, canonical, policy, issuer and PCM assertions intact.

with_legacy_policy_queries is a cfg(test), thread-local independent toggle. Its RAII guard restores the prior value on normal return and unwind. It selects ordinary Root policy and, after an admitted first Domain processing query, the existing ordinary sealed finish_policy. It does not disable processing or flattened admission, alter their receipts, or zero their work. with_legacy_original_queries composes policy + processing + flattened toggles explicitly for the full ordinary matrix reference.

These five earlier tests intentionally continue proving the narrower processing-only accounting boundary. They no longer claim to exercise all three default admitted carriers together. Their meaningful real lease/issuer/partial-work/PCM assertions were preserved rather than rewritten with guessed policy fee offsets.

The separate new policy_admission_tests module exercises default routing with no legacy wrappers for both Root and Domain:
- actual admitted policy categories and one constructor, real source refusal with all three metadata charges live, one policy issuer comparison;
- one-work-short policy constructor failure with real positive partial accepted work, zero retained bytes and no issuer fee;
- swap only a foreign policy carrier while flat and processing remain owned, exact three issuer debits, refusal before source I/O and both ledgers released;
- unused admitted policy carrier drop releases real ReadWork charge without refund.

These four tests cover the new default policy resource/error/issuer behavior. Successful default PCM equality is additionally present in the current authored matrix path; the four tests alone are not represented as a complete PCM parity suite.

## Current source pins

| Relative to crates/deadpan-audio/src | SHA-256 |
| --- | --- |
| authored_eq/legacy_tile_baseline.rs | 6755c9a883c63e011df54a45bf9005918172e49c132934de950fc08a1bd0260f |
| authored_eq/tile_admission_tests.rs | 9c409f4b8f5559c77fc0df51c079426b641c719828c117ed6def17e48dcd532d |
| original_request.rs | 9137ceedf78678928f8672866405e0ce9a91159437b3a72faa3cd039e5c8ef70 |
| original_request/domain_policy_trace.rs | 8e231a272326c1f196ef026775da0880855a0d50204dfdcbdcf4da41f04ca61d |
| original_request/flattened_work_trace.rs | 3dc46c3906e29b06e59d844118001667612829cfabd3dc090f3f773339ea526b |
| original_request/processing_admission_tests.rs | be75b882df32a1c0a7f64a0ef9a12fa1f6eb13434df002fd1d236f5f01bcb8a0 |
| original_request/processing_policy_admission_tests.rs | cce122c5e92b93b17abbfce59774f857959ceed14adf100486cc011cf4b4c05e |
| original_request/policy_admission_tests.rs | 13f8fc7c98f4d27eb28e71c896f152b61d4b33fe9fc549f57e7aeca5a90045ba |
| shared_eq/original_inputs.rs | b029c29784b9ffc03cb84a8209eab68c3930a8fb86e2e1e87e83ff83956caba3 |
