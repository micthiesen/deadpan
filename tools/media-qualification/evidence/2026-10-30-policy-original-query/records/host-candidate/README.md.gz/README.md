# Host Original policy admission candidate

Scratch-only candidate for the parent integration. `main/` and `scoped/` contain identical formatted full-file candidates and per-file unified patches. Parent-owned production changes and concurrent repository edits were not modified.

## Changes represented

- Retains admitted flattened, processing, and policy query carriers until the exact Original read returns, then drops the prepared request as before.
- Adds a policy carrier with a private issuer checked and separately billed at the read boundary.
- Routes Root policy construction through `audio_policy_admitted` and Domain policy completion through `finish_policy_admitted`, with independent policy work tracing.
- Keeps the literal old policy path available in test-only legacy modes; the combined legacy Original helper now selects all three old constructors. Flattened-only and processing-only modes remain independent.
- Adds a third fixed TLS product slot for policy constructor work and issuer accounting; existing flattened and processing slot indices stay stable.

## Validation and limits

Rustfmt `--check` passes on all four candidate files. No Cargo build or tests were run. Candidate expects the policy API being integrated by the parent/worker: `AdmittedAudioPolicyQuery<I,L>`, `audio_policy_admitted`, and `finish_policy_admitted` with `into_queries`. In the current checkout at capture time, the `finish_policy_admitted` pair type/method is visible, but the RenderPlan policy constructor and query type have not yet been integrated, so this candidate is not claimed compile-verified.

Main and Scope candidate file contents have identical SHA-256 pins. The baseline Main `original_request.rs` and `flattened_work_trace.rs` pins were captured before candidate edits; Scope baseline files were not available as a local checkout path in this agent environment. No claim is made that the per-file patches apply to an independently changing Scope baseline without checking its base pin.
