from pathlib import Path
import json
s=Path(__file__).resolve().parent
roots={'main':Path('/Users/michael/Code/deadpan'),'scoped':Path('/tmp/deadpan-query-groundwork-2026-10-26/scoped')}
method='''    /// Construct policy with fresh admission while retaining the sealed first tape.
    pub fn finish_policy_admitted<A: crate::AudioSoundContextAdmission<Issuer = I, Lease = L>>(
        self,
        caller: &AudioDomain<'plan>,
        samples: Range<AudioSample>,
        limits: AudioQueryLimits,
        admission: &mut A,
    ) -> Result<AdmittedAudioDomainProcessingAdmittedPolicy<'plan, I, L>, A::Error> {
        if !std::ptr::eq(self.domain, caller) || self.samples != samples {
            return Err(PlanError::InvalidPlan("processing policy identity mismatch").into());
        }
        let mut local = Budget {
            remaining: limits.maximum_work,
            lookup: LookupStats::default(),
        };
        let mut budget = super::audio_owners::admission::Budget::new(&mut local, admission);
        super::audio_owners::admission::outer::<_, A>((|| {
            let processing = self.query.validate_for(&mut budget)?;
            let bindings = self
                .stops
                .permits_binding_reuse()
                .then_some(processing.query().spans.as_slice());
            let policy = super::audio_policy::query::domain_query_with_processing(
                caller,
                samples,
                limits,
                bindings,
                &mut budget,
            )?;
            Ok(AdmittedAudioDomainProcessingAdmittedPolicy { processing, policy })
        })())
    }

'''
pair='''/// Independent admitted products retain both construction leases through a read.
pub struct AdmittedAudioDomainProcessingAdmittedPolicy<'plan, I, L> {
    processing: super::audio::AdmittedAudioProcessingQuery<'plan, I, L>,
    policy: super::AdmittedAudioPolicyQuery<I, L>,
}

impl<'plan, I, L> AdmittedAudioDomainProcessingAdmittedPolicy<'plan, I, L> {
    pub fn into_queries(
        self,
    ) -> (
        super::audio::AdmittedAudioProcessingQuery<'plan, I, L>,
        super::AdmittedAudioPolicyQuery<I, L>,
    ) {
        (self.processing, self.policy)
    }
}

'''
for variant,root in roots.items():
 p=root/'crates/deadpan-plan/src/audio_domain.rs'
 text=p.read_text()
 anchor="impl<'plan, I: Copy + Eq, L> AdmittedAudioDomainProcessing<'_, 'plan, I, L> {"
 assert text.count(anchor)==1
 text=text.replace(anchor,pair+anchor)
 anchor='    /// Fresh limits cover policy only; first-query work stays separate.\n'
 assert text.count(anchor)==1
 text=text.replace(anchor,method+anchor)
 p.write_text(text)
 for rel in ['crates/deadpan-plan/src/plan.rs','crates/deadpan-plan/src/lib.rs']:
  p=root/rel
  before=s/'integration-before'/variant/rel
  if not before.exists():
   before.parent.mkdir(parents=True,exist_ok=True)
   before.write_bytes(p.read_bytes())
  text=p.read_text()
  anchor='    AdmittedAudioDomainProcessing, AdmittedAudioDomainProcessingPolicy,'
  assert text.count(anchor)==1
  text=text.replace(anchor,'    AdmittedAudioDomainProcessing, AdmittedAudioDomainProcessingAdmittedPolicy, AdmittedAudioDomainProcessingPolicy,')
  p.write_text(text)
 p=root/'crates/deadpan-plan/src/audio_owners/policy_child_admission_tests.rs'
 text=p.read_text()
 assert text.count('(3, 3)')==1
 p.write_text(text.replace('(3, 3)','(2, 4)'))
owned=set(json.loads((s/'owned-paths.json').read_text()))
owned.update(['crates/deadpan-plan/src/plan.rs','crates/deadpan-plan/src/lib.rs'])
(s/'owned-paths.json').write_text(json.dumps(sorted(owned),indent=2)+'\n')
print('Integrated sealed policy finish in both roots; type checking waits for policy module.')
