from pathlib import Path
import json,re
s=Path(__file__).resolve().parent
roots={'main':Path('/Users/michael/Code/deadpan'),'scoped':Path('/tmp/deadpan-query-groundwork-2026-10-26/scoped')}
owned=set(json.loads((s/'owned-paths.json').read_text()))
paths=['crates/deadpan-audio/src/original_request/processing_admission_tests.rs','crates/deadpan-audio/src/original_request/processing_policy_admission_tests.rs','crates/deadpan-audio/src/original_request/policy_reuse_tests.rs','crates/deadpan-audio/src/shared_eq/prepared_input_tests.rs']
for variant,root in roots.items():
 for rel in paths:
  p=root/rel;text=p.read_text()
  before=s/'integration-before'/variant/rel;before.parent.mkdir(parents=True,exist_ok=True)
  assert not before.exists();before.write_bytes(p.read_bytes())
  if rel.endswith('processing_admission_tests.rs') or rel.endswith('processing_policy_admission_tests.rs'):
   found=re.findall(r'#\[test\]\nfn (\w+)\(\) \{',text)
   assert found
   for name in found:
    anchor='#[test]\nfn '+name+'() {'
    assert text.count(anchor)==1
    replacement=anchor+'\n    with_legacy_policy_queries('+name+'_legacy_policy);\n}\n\nfn '+name+'_legacy_policy() {'
    text=text.replace(anchor,replacement)
   text=text.replace('use super::*;\n','use super::*;\n\n// Keep this earlier processing-only proof on its literal ordinary policy backend.\n',1)
  elif rel.endswith('policy_reuse_tests.rs'):
   anchor='use deadpan_plan::LookupStats;\n'
   assert text.count(anchor)==1
   text=text.replace(anchor,anchor+'''
fn with_legacy_processing_queries<T>(action: impl FnOnce() -> T) -> T {
    super::with_legacy_policy_queries(|| super::with_legacy_processing_queries(action))
}
''')
  else:
   anchor='''        hit_work + 3,
        "the hit bills sealed request validation and both actual issuer comparisons once each"'''
   assert text.count(anchor)==1
   text=text.replace(anchor,'''        hit_work + 1 + 3,
        "the hit bills sealed request validation and all three actual issuer comparisons once each"''')
  p.write_text(text);owned.add(rel)
(s/'owned-paths.json').write_text(json.dumps(sorted(owned),indent=2)+'\n')
print('Prior processing/policy-reuse proofs use their explicit old-policy mode; current mode has separate three-product coverage.')
