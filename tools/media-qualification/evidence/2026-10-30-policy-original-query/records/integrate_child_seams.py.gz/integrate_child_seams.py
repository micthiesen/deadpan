from pathlib import Path
import hashlib,json
s=Path(__file__).resolve().parent
pins=json.loads((s/'child-budget-candidate/source-pins.json').read_text())
roots={'main':Path('/Users/michael/Code/deadpan'),'scoped':Path('/tmp/deadpan-query-groundwork-2026-10-26/scoped')}
owned=set(json.loads((s/'owned-paths.json').read_text()))
files=['audio_owner_query_admission.rs','audio_signal_processing_query.rs','audio_flattened_query.rs','audio_processing_query.rs']
for variant,root in roots.items():
    for name in files+['audio_signal.rs','audio_point_domain.rs','audio_domain.rs']:
        rel='crates/deadpan-plan/src/'+name
        p=root/rel
        if rel in pins[variant]:
            assert hashlib.sha256(p.read_bytes()).hexdigest()==pins[variant][rel],rel
        elif name=='audio_point_domain.rs':
            assert hashlib.sha256(p.read_bytes()).hexdigest()=='6213b39cd0452b39e95ba8df592a33bdbb9a2627e22a1a1df95efab0e5be83ab'
        before=s/'integration-before'/variant/rel
        before.parent.mkdir(parents=True,exist_ok=True)
        assert not before.exists()
        before.write_bytes(p.read_bytes())
        owned.add(rel)
    for name in files:
        rel='crates/deadpan-plan/src/'+name
        (root/rel).write_bytes((s/'child-budget-candidate/candidate'/rel).read_bytes())
    for name in ['audio_signal.rs','audio_point_domain.rs']:
        rel='crates/deadpan-plan/src/'+name
        data=(s/'point-signal-candidate'/variant/name).read_text()
        if name=='audio_signal.rs':
            old='#[path = "audio_signal_processing_query.rs"]\nmod processing_query;'
            assert data.count(old)==1
            data=data.replace(old,'#[path = "audio_signal_processing_query.rs"]\npub(in crate::plan) mod processing_query;')
        (root/rel).write_text(data)
    rel='crates/deadpan-plan/src/audio_domain.rs'
    p=root/rel
    data=p.read_text()
    assert not 'fn audio_child_query' in data
    p.write_text(data+'\n'+(s/'child-budget-candidate/domain-wrappers.rs.fragment').read_text().split('\n',1)[1])
(s/'owned-paths.json').write_text(json.dumps(sorted(owned),indent=2)+'\n')
print(json.dumps({'integrated':files+['audio_signal.rs','audio_point_domain.rs','audio_domain.rs'],'variants':list(roots)}))
