from pathlib import Path
from datetime import datetime
import hashlib,json,re
s=Path(__file__).resolve().parent
roots={'main':Path('/Users/michael/Code/deadpan'),'scoped':Path('/tmp/deadpan-query-groundwork-2026-10-26/scoped')}
sha=lambda b:hashlib.sha256(b).hexdigest()
negative={
 'child-seams-scoped-actual':101,
 'policy-initial-main-audio-all':101,
 'policy-plan-scoped-build':101,
 'policy-plan-scoped-tests':101,
 'policy-dense-context-scoped-test':101,
 'policy-strict-scoped':101,
 'policy-strict-main':1,
 'policy-strict-scoped2':101,
 'policy-strict-main2':1,
 'policy-final-scoped-stages':-15,
 'policy-qualified-fresh-split':101,
}
receipts=[];native=[]
for p in sorted(s.glob('*.json')):
 row=json.loads(p.read_text())
 if not isinstance(row,dict) or 'command'not in row or 'started_at'not in row:continue
 assert row.get('exit_code')==negative.get(p.stem,0),(p.stem,row.get('exit_code'))
 assert row['sources_unchanged'] and row['binaries_unchanged'],p.stem
 for path,pin in row['streams'].items():
  b=Path(path).read_bytes()
  assert len(b)==pin['bytes'] and sha(b)==pin['sha256'],path
 receipts.append({'label':p.stem,'exit_code':row['exit_code'],'seconds':row['seconds'],'source_inputs':len(row['source_before']),'sha256':sha(p.read_bytes())})
 if row['binary_before'] and '-build-audio-'in row['command'][0]:
  native.append((datetime.fromisoformat(row['started_at']),datetime.fromisoformat(row['finished_at']),p.stem))
for a,b in zip(sorted(native),sorted(native)[1:]):
 assert a[1]<=b[0],('native overlap',a[2],b[2])
owned=json.loads((s/'owned-paths.json').read_text())
assert len(owned)==38
assert set((s/'index-source-paths.txt').read_text().splitlines())==set(owned)
index=json.loads((s/'index-source-equality.json').read_text())
assert len(index)==38 and all(r['scoped_index_equal']for r in index)
assert {r['path']for r in index if not r['main_equal']}=={'crates/deadpan-plan/src/plan.rs'}
preserved={}
for variant,root in roots.items():
 pins=json.loads((s/(variant+'-final-source-pins.json')).read_text())
 assert set(pins)==set(owned)
 for name,pin in pins.items():
  data=(root/name).read_bytes()
  assert len(data)==pin['bytes'] and sha(data)==pin['sha256'],(variant,name)
 initial=json.loads((s/(variant+'-initial-authority.json')).read_text())
 others={name:pin for name,pin in initial.items()if name not in owned}
 for name,pin in others.items():
  assert sha((root/name).read_bytes())==pin['sha256'],(variant,'unowned',name)
 preserved[variant]=len(others)
assert preserved=={'main':2761,'scoped':2433}
goldens=json.loads((s/'immutable-oracle-pins.json').read_text())
assert len(goldens)==16
for row in goldens:
 for root in roots.values():
  assert sha((root/row['path']).read_bytes())==row['sha256'],row['path']
expected={
 'policy-final-main-core':(827,0),'policy-final-scoped-core':(802,0),
 'policy-point-final-main-plan-deadpan-plan':(252,12),
 'policy-point-final-scoped-plan-deadpan-plan':(239,12),
 'policy-qualified-main-audio':(412,6),'policy-qualified-scoped-audio':(406,6),
 'policy-qualified-main-stages':(203,0),'policy-qualified-scoped-stages':(203,0),
 'policy-qualified-main-definition':(171,0),'policy-qualified-scoped-definition':(171,0),
}
tests={}
for label,pair in expected.items():
 matches=re.findall(r'test result: ok\. (\d+) passed; 0 failed; (\d+) ignored;', (s/(label+'.stdout')).read_text())
 assert len(matches)==1 and tuple(map(int,matches[0]))==pair,(label,matches)
 tests[label]={'passed':pair[0],'ignored':pair[1],'seconds':json.loads((s/(label+'.json')).read_text())['seconds']}
for variant in roots:
 labels=[r['label']for r in receipts if r['label'].startswith('policy-point-final-'+variant+'-plan-') and not r['label'].endswith('-deadpan-plan') and not r['label'].endswith('-build')]
 assert len(labels)==28,(variant,len(labels))
 total=0
 for label in labels:
  matches=re.findall(r'test result: ok\. (\d+) passed; 0 failed; 0 ignored;', (s/(label+'.stdout')).read_text())
  assert len(matches)==1,label
  total+=int(matches[0])
 assert total==450,(variant,total)
 tests[variant+'-plan-integration']={'executables':28,'passed':total}
for variant in roots:
 row=json.loads((s/('policy-qualified-final-'+variant+'-build.json')).read_text())
 assert row['environment']['CARGO_PROFILE_DEV_OPT_LEVEL']=='2'
 assert '[optimized + debuginfo]'in(s/('policy-qualified-final-'+variant+'-build.stderr')).read_text()
 runtime=row['source_after']
 for name in owned:
  absolute=str(roots[variant]/name)
  assert absolute in runtime
  assert runtime[absolute]['sha256']==sha((roots[variant]/name).read_bytes()),(variant,'post-native-code change',name)
current=json.loads((s/'current-native-equality.json').read_text())
a=(s/'policy-current-body-main.json').read_bytes()
assert a==(s/'policy-current-body-scoped.json').read_bytes()
assert len(a)==336979 and sha(a)=='3ee0b4c33a12fa5485ef430d69098c6d9dee0db15dd062a91ad709223505d844'
assert current['bytes']==len(a) and current['sha256']==sha(a)
assert min(current['work_deltas']['cold'])==75 and max(current['work_deltas']['cold'])==179
assert min(current['work_deltas']['repeat'])==-63 and max(current['work_deltas']['repeat'])==-24
split=(s/'policy-qualified-fresh-split.stdout').read_text()
assert '3 passed; 4 failed;'in split
result={
 'all_terminal':True,'receipts':receipts,'native_audio_runs_serial':True,
 'tests':tests,'source_paths':38,'index_scoped_equal':38,'main_scoped_equal':37,
 'preserved_initial_inputs_outside_scope':preserved,'immutable_oracles':16,
 'current_native_body':current,
 'source_patch':{'bytes':(s/'shipping-source.patch').stat().st_size,'sha256':sha((s/'shipping-source.patch').read_bytes())},
 'split':{'passed':3,'failed':4,'seconds':json.loads((s/'policy-qualified-fresh-split.json').read_text())['seconds']},
 'aborted_unoptimized_native':{'label':'policy-final-scoped-stages','exit_code':-15,'acceptance_credit':False},
}
(s/'final-audit.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items()if k!='receipts'},indent=2))
