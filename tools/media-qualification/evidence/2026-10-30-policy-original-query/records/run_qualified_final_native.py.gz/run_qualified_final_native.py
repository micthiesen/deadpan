from pathlib import Path
import subprocess,os
s=Path(__file__).resolve().parent
rows=[
 ('scoped','deadpan_audio','policy-qualified-scoped-audio',['--test-threads=1']),
 ('scoped','stages','policy-qualified-scoped-stages',['--test-threads=1']),
 ('scoped','audio_definition','policy-qualified-scoped-definition',['--test-threads=1']),
 ('scoped','deadpan_audio','policy-current-scoped',['produce_current_cached_prediction_observations','--ignored','--nocapture','--test-threads=1']),
 ('main','deadpan_audio','policy-qualified-main-audio',['--test-threads=1']),
 ('main','stages','policy-qualified-main-stages',['--skip','general_split_sound::','--test-threads=1']),
 ('main','audio_definition','policy-qualified-main-definition',['--test-threads=1']),
 ('main','deadpan_audio','policy-current-main',['produce_current_cached_prediction_observations','--ignored','--nocapture','--test-threads=1']),
 ('main','stages','policy-qualified-fresh-split',['general_split_sound::','--nocapture','--test-threads=1']),
]
for variant,target,label,args in rows:
 env=os.environ.copy()
 if label.startswith('policy-current-'):
  output=s/('policy-current-body-'+variant+'.json')
  assert not output.exists()
  env['DEADPAN_CACHED_PREDICTION_CURRENT']=str(output)
 command=['python',str(s/'run_target.py'),'policy-qualified-final-'+variant+'-build',variant,'audio',target,label,*args]
 result=subprocess.run(command,env=env)
 if result.returncode:raise SystemExit(result.returncode)
