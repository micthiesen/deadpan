# Publication review: policy Original query admission

One minor evidence mismatch:

1. docs/qualification/policy-original-query-admission-2026-10-30.md says the supplemental Point fixture “produces signed reference origin -1.” The integrated test records the actual Point context but only asserts origin < 0 (crates/deadpan-plan/src/audio_owners/policy_point_path_tests.rs:197 and :299). The test supports a signed origin and checks offset addition against that observed value, but it does not pin -1. Assert the exact value or soften the publication claim to “negative origin.”

Other reviewed claims match the supplied evidence. The dense physical-Domain refusal and four Split failures are reported as failures, the preliminary SIGTERM run is explicitly assigned no acceptance credit, and the publication keeps the broader product goal open. Final native stdout/stderr agree with the pass/fail counts; receipt times support the rounded durations. The source/index distinction (38 staged paths, 37 Main working-tree matches because of plan.rs) is consistent with final-audit.json.

The evidence-inventory link resolves from the qualification document. Its computed SHA-256 is b52b2e3bc8742ec64981f817663ffb9915fef096f9df2d7ecf99b8d49b466aab; its 1,027 records sum to 24,788,253 stored bytes and 263,561,874 expanded bytes, and all listed compressed/expanded hashes are present. This review did not decompress the evidence set or run Cargo.

The new Point instrumentation and observations are test-only (cfg(test) at crates/deadpan-plan/src/audio_policy_query.rs:2-4, with four observations at the actual Point branch). The signed repeated fixture test compares its current ordinary result, observes actual clone and offset buffers, checks exact/short totals and failure cleanup. The frozen Point test separately compares all output fields to the selected OLD row. The callback-seed change adds one case and changes the expected count from four to five.

Scope was limited to the named publication changes, supplied audits/logs/reports/inventory, and the integrated Point-path follow-up.
