# Independent policy-constructor and host review

## Findings

No material correctness or ownership findings from the assigned lens.

## Verified paths

- `RenderPlan::audio_policy_admitted` and `AudioDomain::policy_admitted` keep the non-metered path on the legacy ordinary constructors and wrap the result without forwarding work or inventing a memory lease. The metered path creates a fresh bounded Plan/Core budget and calls the actual structural policy walker.
- `AdmittedAudioPolicyQuery` exposes only borrowed query data and scalar accounting; the private `GuardedBound<PolicyBuffer<...>>` keeps both the contents-capacity lease and suppressed-output lease attached to the returned value. There is no generic detach/into-ordinary escape.
- The actual walker follows the old Root `RoundEven` and Domain physical-grid semantics: current audio query, held-content and endpoint suppression, binding walk/reuse only when the sealed first walk proves eligibility and within the existing span limit, raw Bound recursion, PointCeil remapping, and the same final sort/overlap/adjacency merge. It independently charges allocation/copy work while retaining each child value under its lease.
- `finish_policy_admitted` validates the exact Domain pointer and sample range first. It then validates forwarded mode and the Plan issuer before policy construction; Core issuer/mode validation occurs in `map_value` before the identity mapping callback. The sealed first query remains alive while the policy walk borrows its spans; it is neither cloned nor billed again. Fallback performs a new processing child query under the fresh policy budget.
- Error returns from range construction, child queries, reserve/spend, output adoption, or final zip leave the affected values and both independent lease lanes in RAII owners. Final output combines the Plan memory lane only after issuer checks; Core binding composition remains delegated to Core's paired-value API and its issuer/mode validations.
- Root/Domain host preparation stores the policy carrier alongside flattened and processing carriers, validates all three issuers before reading, and drops the request immediately after the read result is formed. The actual host policy tests exercise Root and Domain paths, policy work receipts, partial failure, foreign policy issuer rejection, live metadata at source-provider failure, and unused-carrier release.

## Prior sealed/host review

No material issue was found in the earlier sealed `finish_policy` / host integration review. The later integrated admitted path preserves the same exact Domain/range seal and adds validation before new policy callbacks. Host policy candidate was statically checked and rustfmt-checked only; this review did not run Cargo or tests.

## Limits

- This was static source review only; no Cargo/native/Git commands or source writes were performed.
- The Plan crate has no direct dedicated test calling `finish_policy_admitted`; Root/Domain host tests exercise it through the production read preparation path. A direct Plan test could narrow diagnostic localization, but I found no defect requiring it.
- The public admitted policy factories are intentionally scoped to RenderPlan/AudioDomain structural inputs. Arbitrary AudioSignal voice providers remain on their existing ordinary policy API; the private admitted walker requires structural children and Point factories verified as Structural.
