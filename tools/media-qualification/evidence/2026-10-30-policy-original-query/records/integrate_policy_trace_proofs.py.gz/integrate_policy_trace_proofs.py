from pathlib import Path
import json
s=Path(__file__).resolve().parent
roots={'main':Path('/Users/michael/Code/deadpan'),'scoped':Path('/tmp/deadpan-query-groundwork-2026-10-26/scoped')}
owned=set(json.loads((s/'owned-paths.json').read_text()))
def once(t,a,b):
 assert t.count(a)==1,(a,t.count(a))
 return t.replace(a,b)
for variant,root in roots.items():
 for rel in ['crates/deadpan-audio/src/authored_eq/legacy_tile_baseline.rs','crates/deadpan-audio/src/authored_eq/tile_admission_tests.rs']:
  p=root/rel
  before=s/'integration-before'/variant/rel
  assert not before.exists()
  before.parent.mkdir(parents=True,exist_ok=True)
  before.write_bytes(p.read_bytes())
  text=p.read_text()
  if rel.endswith('legacy_tile_baseline.rs'):
   a='        "processing_work_trace": crate::stages::original_request::flattened_work_trace::processing_snapshot(),'
   text=once(text,a,a+'\n        "policy_work_trace": crate::stages::original_request::flattened_work_trace::policy_snapshot(),')
  else:
   a='        ("processing_work_trace", "processing"),'
   assert text.count(a)==3,text.count(a)
   text=text.replace(a,a+'\n        ("policy_work_trace", "policy"),')
   a='["flattened_work_trace", "processing_work_trace"]'
   assert text.count(a)==2,text.count(a)
   text=text.replace(a,'["flattened_work_trace", "processing_work_trace", "policy_work_trace"]')
   text=once(text,'for field in ["domain_policy_trace", "processing_work_trace"] {','for field in ["domain_policy_trace", "processing_work_trace", "policy_work_trace"] {')
   a='''        let removed = number(old_row, "policy_work")
            .checked_sub(number(row, "policy_work"))
            .unwrap();'''
   b='''        for value in [row, old_row] {
            assert_eq!(
                number(value, "policy_work"),
                number(value, "policy_canonical_work")
                    .checked_add(number(value, "policy_additional_work"))
                    .unwrap(),
                "actual Domain policy receipt categories"
            );
        }
        let removed = number(old_row, "policy_canonical_work")
            .checked_sub(number(row, "policy_canonical_work"))
            .unwrap();
        assert_eq!(
            i128::from(number(row, "policy_work")) - i128::from(number(old_row, "policy_work")),
            i128::from(number(row, "policy_additional_work"))
                - i128::from(number(old_row, "policy_additional_work"))
                - i128::from(removed),
            "policy total changes only by actual additional work and the witnessed removed walk"
        );'''
   text=once(text,a,b)
   text=once(text,'''            "policy_work",
            "policy_lookup",''','''            "policy_work",
            "policy_canonical_work",
            "policy_additional_work",
            "policy_lookup",''')
   text=once(text,'''    let old_fees = query_fees(&old_processing, "processing reference");
    let removed''','''    let old_fees = query_fees(&old_processing, "processing reference");
    let policy = take_query_trace(actual, "policy_work_trace");
    let old_policy = take_query_trace(&mut old, "policy_work_trace");
    let policy_fees = query_fees(&policy, "policy");
    let old_policy_fees = query_fees(&old_policy, "policy reference");
    let removed''')
   text=once(text,'''        let old_host = host_eviction_receipt(&old_processing);
        assert_eq!(host_eviction_receipt(&actual["flattened_work_trace"]), host);''','''        let old_host = host_eviction_receipt(&old_processing);
        assert_eq!(host_eviction_receipt(&policy), host);
        assert_eq!(host_eviction_receipt(&old_policy), old_host);
        assert_eq!(host_eviction_receipt(&actual["flattened_work_trace"]), host);''')
   text=once(text,'''        let difference = i128::from(fees[lane]) - i128::from(old_fees[lane])
            + i128::from(host[lane])''','''        let difference = i128::from(fees[lane]) - i128::from(old_fees[lane])
            + i128::from(policy_fees[lane]) - i128::from(old_policy_fees[lane])
            + i128::from(host[lane])''')
   text=text.replace('both product snapshots share one actual host debit receipt','all product snapshots share one actual host debit receipt')
   text=text.replace('both actual product receipts','all actual product receipts')
   text=text.replace('only actual policy savings and separately witnessed processing fees differ','only actual policy savings and separately witnessed processing/policy fees differ')
  p.write_text(text)
  owned.add(rel)
(s/'owned-paths.json').write_text(json.dumps(sorted(owned),indent=2)+'\n')
print('Added actual third-product receipts and category-based Domain reconciliation in both roots.')
