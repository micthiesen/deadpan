# Original host policy admission test candidate

Scratch-only candidate for `crates/deadpan-audio/src/original_request/tests.rs` and its new sibling `policy_admission_tests.rs`.

Source anchor SHA-256:
- Main `original_request/tests.rs`: `411e603c2e95b61f1712fe53a0591769f12040efec082eb6ca09cf6af1f3fe22`
- Main and Scope `original_request.rs`: `9137ceedf78678928f8672866405e0ce9a91159437b3a72faa3cd039e5c8ef70`
- Main and Scope `original_request/tests.rs` initial contents matched at the first candidate pin.

Candidate SHA-256:
- `main/tests.rs`, `scoped/tests.rs`: `af2f2f91df8837d67fde9db1ba42145fc12035b57b295cb1bdea0b91f4ebc8ab`
- `main/policy_admission_tests.rs`, `scoped/policy_admission_tests.rs`: `2838cd96da62a51087629fed3d92e440206ba365c94680cd1d83a5c034219ab3`

Patch files: `tests.patch`, `policy_admission_tests.patch`.

`rustfmt --edition 2024 --check --config skip_children=true` passed on both candidate files. No Cargo/test execution was done. Candidate assumes the integrated `Policy::Admitted` API and per-product `flattened_work_trace::{policy_snapshot, reset, ScopeGuard::new_policy}`. The +3 issuer checks are intentionally distinct from the three constructor work lanes. Existing flat/proc host tests still compare canonical work to ordinary queries and assert additional forwarded work separately.
