from pathlib import Path
root=Path('/tmp/deadpan-policy-query-admission-2026-10-30/host-test-candidate')
for flavor in ('main','scoped'):
    p=root/flavor/'tests.rs'
    s=p.read_text()
    s=s.replace('    assert_eq!(actual.policy.work, expected.policy.work);\n','')
    marker='fn same_blocks(actual: &ReadBlock, expected: &ReadBlock) {'
    helper='''fn policy_work(request: &PreparedOriginalRequest<'_, '_, '_>) -> (usize, usize) {\n    match &request.queries.policy {\n        Policy::Admitted { query, .. } => {\n            assert!(query.was_forwarded());\n            assert_eq!(\n                query.work(),\n                query.canonical_units().checked_add(query.additional_units()).unwrap()\n            );\n            assert_eq!(request.queries().policy.work, query.work());\n            (query.canonical_units(), query.additional_units())\n        }\n        Policy::Legacy(query) => (query.work, 0),\n    }\n}\n\nfn assert_policy_cost(\n    request: &PreparedOriginalRequest<'_, '_, '_>,\n    ordinary: &AudioPolicyQuery<AudioSample>,\n) -> usize {\n    let (canonical, additional) = policy_work(request);\n    assert_eq!(canonical, ordinary.work);\n    assert!(additional > 0, "the real fixture must execute admitted policy work");\n    additional\n}\n\n'''
    if marker not in s: raise SystemExit(f'{flavor}: helper marker missing')
    s=s.replace(marker,helper+marker,1)
    s=s.replace('''                let additional = assert_flattened_cost(&request, &expected.flattened)\n                    + assert_processing_cost(&request, &expected.processing);''','''                let additional = assert_flattened_cost(&request, &expected.flattened)\n                    + assert_processing_cost(&request, &expected.processing)\n                    + assert_policy_cost(&request, &expected.policy);''')
    s=s.replace('''                    "the consuming read bills both actual issuer comparisons"''','''                    "the consuming read bills all three actual issuer comparisons"''')
    s=s.replace('MAX_PLAN_WORK_PER_READ - 2;', 'MAX_PLAN_WORK_PER_READ - 3;')
    s=s.replace('MAX_PLAN_WORK_PER_READ - preparation_work - 2,','MAX_PLAN_WORK_PER_READ - preparation_work - 3,')
    s=s.replace('MAX_PLAN_WORK_PER_READ - 1);','MAX_PLAN_WORK_PER_READ - 2);')
    s=s.replace('MAX_PLAN_WORK_PER_READ - 1;','MAX_PLAN_WORK_PER_READ - 2;')
    s=s.replace('spent + 2 * usize::from(failure == 2),','spent + 3 * usize::from(failure == 2),')
    s=s.replace('''            + assert_processing_cost(&reference, &ordinary.processing);''','''            + assert_processing_cost(&reference, &ordinary.processing)\n            + assert_policy_cost(&reference, &ordinary.policy);''')
    s=s.replace('''                    + ordinary.policy.work\n''','''                    + ordinary.policy.work\n''') # ordinary reference remains canonical; explicitly intentional
    s=s.replace('''"only a live control bills both issuer comparisons before depth rejection"''','''"only a live control bills all three issuer comparisons before depth rejection"''')
    s=s.replace('''"fresh source rejection follows both actual issuer comparisons"''','''"fresh source rejection follows all three actual issuer comparisons"''')
    marker='#[path = "flattened_admission_tests.rs"]\nmod flattened_admission;'
    module='#[path = "policy_admission_tests.rs"]\nmod policy_admission;\n\n'
    if marker not in s: raise SystemExit(f'{flavor}: module marker missing')
    s=s.replace(marker,module+marker,1)
    p.write_text(s)
