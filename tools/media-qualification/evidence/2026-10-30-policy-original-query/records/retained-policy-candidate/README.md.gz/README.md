# Retained OLD policy case extension

Scratch-only candidate: policy_retained_cases.rs, with policy_retained_cases.patch and source-pins.json. Intended as a child module of policy_query_baseline. No actual source changed.

The visitor adds 11 finite checked-parent descriptors: five existing physical Domains from the OLD processing visitor (default repeat gap, hidden resumed capture, retained reference Domain, fractional physical capture, and split physical capture) plus six actual checked Preserve/Shift/signed Partition Domains from policy_binding_baseline::visit_additional. Their descriptors retain actual document/input/domain provenance. A separately ported Source endpoint case starts from real public data types, captures an actual lattice, appends AudioReanchorStep::for_source_endpoint(End), validates ProjectDocument, compiles RenderPlan, and observes both Root and a Domain from an actual source-owner input.

matrix() records the default policy output without asserting success, so any actual typed error and input limits remain visible. Each checked parent gets up to three one-sample calls at its edges/midpoint parity and two adjacent page calls split at the midpoint. The source-endpoint fixture also records exact one-sample calls immediately before/at its crop start and last/at its crop end, independently for Root and Domain; out-of-support calls remain literal typed outcomes. No pages are merged or reconstructed.

Static checks: rustfmt --edition 2024 passed for the candidate; source hashes for all referenced helper/fixture files match between Main and Scope. No Cargo, compile, producer, capture, or native execution was run.

Outstanding: parent integration and type/lifetime resolution, actual Main/Scope output comparison, and confirmation that the one-sample source-owner selection succeeds on the source-endpoint port. The port follows source_endpoints.rs and is validated again at runtime, but has not been executed. retained_names is intentionally exact; if the parent visitor's descriptor spelling changes, the final produced case count should fail an explicit count assertion rather than silently omit coverage.
