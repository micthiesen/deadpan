from pathlib import Path
import json,hashlib
s=Path(__file__).resolve().parent
roots={'main':Path('/Users/michael/Code/deadpan'),'scoped':Path('/tmp/deadpan-query-groundwork-2026-10-26/scoped')}
new='crates/deadpan-plan/src/audio_policy_query.rs'
candidate=s/'policy-constructor-candidate'/new
data=candidate.read_bytes()
(s/'policy-initial-constructor-sha256.txt').write_text(hashlib.sha256(data).hexdigest()+'\n')
for variant,root in roots.items():
 p=root/new
 assert not p.exists()
 p.write_bytes(data)
 rel='crates/deadpan-plan/src/audio_policy.rs';p=root/rel
 before=s/'integration-before'/variant/rel;assert not before.exists()
 before.parent.mkdir(parents=True,exist_ok=True);before.write_bytes(p.read_bytes())
 text=p.read_text()
 anchor='use crate::{AudioBoundaryRule, PlanError};\n'
 assert text.count(anchor)==1
 text=text.replace(anchor,anchor+'\n#[path = "audio_policy_query.rs"]\npub(in crate::plan) mod query;\npub use query::AdmittedAudioPolicyQuery;\n')
 p.write_text(text)
 p=root/'crates/deadpan-plan/src/plan.rs';text=p.read_text()
 anchor='pub use audio_policy::AudioPolicyQuery;';assert text.count(anchor)==1
 p.write_text(text.replace(anchor,'pub use audio_policy::{AdmittedAudioPolicyQuery, AudioPolicyQuery};'))
 p=root/'crates/deadpan-plan/src/lib.rs';text=p.read_text()
 anchor='pub use plan::{AdmittedAudioProcessingQuery, AdmittedAudioQuery};';assert text.count(anchor)==1
 p.write_text(text.replace(anchor,'pub use plan::{AdmittedAudioPolicyQuery, AdmittedAudioProcessingQuery, AdmittedAudioQuery};'))
for name in ['owned-paths.json','source-files.json','scoped-source-files.json','main-logic-source-files.json','scoped-logic-source-files.json']:
 p=s/name;paths=set(json.loads(p.read_text()));paths.add(new)
 if name=='owned-paths.json':paths.add('crates/deadpan-plan/src/audio_policy.rs')
 p.write_text(json.dumps(sorted(paths),indent=2)+'\n')
print('Integrated guarded policy constructor in Main and Scope.')
