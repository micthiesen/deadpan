# OLD policy producer review

No producer correctness finding from this source audit. The candidate is suitable for parent integration/type checking and an initial capture after the published processing checkpoint. Its reused 33-parent corpus is not yet the complete preproduction oracle required by policy-fade-admission-next.md. Dedicated gaps below must be covered before modifying policy behavior/admission.

Read-only review of old-producer-candidate/README.md, its 585-line shared policy_query_baseline.rs, both variants' minimal patches, actual checked visitors, policy result/type/error paths, ordinary sealed finish and existing second-query observer. No actual repository edits, Git, Cargo, native execution, producer invocation, capture, freeze or expected generation.

## Fixture and patch fidelity

The candidate directly invokes processing_query_baseline::visit_cases. The actual visitor validates its 20 Root and 13 Domain counts, reconstructs Root plans from immutable checked documents, acquires Domains through the existing checked visitors, records actual parent identity and passes complete descriptors. Candidate clones the entire descriptor and adds route/observations; it does not replace documents, selectors, placement provenance or outputs. Its 33 ordinary/13 sealed count assertions agree with this source structure, not an executed coverage claim.

The storage fixture uses the existing query_storage_tests::fixture exactly. Its extra descriptor field quotes the existing constructor/helper source up to the exact fn measurement boundary; it does not recreate the fixture. That source includes fixture_with_asset, its checked ProjectDocument construction and the actual compile call. The original descriptor openly names a pinned constructor rather than a retained document. A complete runtime source manifest is still necessary because this quote alone is not all imported implementation context.

All 13 read pins match each current actual root. Every candidate hash matches candidate-pins.json. The two original patched files in each before/ variant match actual source. Independently parsed/reconstructed both complete patches in memory: exactly the declaration append, the three Observation/start/finish visibility changes and the exact shared new source, with valid hunk counts/context. No production hook/query/fixture modification or extra patch path appears. Observation remains test-only and inactive unless explicitly started; its existing Drop clears TLS on unwind.

## Complete literal output

query_snapshot destructures every AudioPolicyQuery field: suppressed, contents, lookup and work. Contents is the complete serialized Vec<AudioContent>, including each owning Source/Hold payload, not a count or asset-key projection. Lookup includes all three actual counters. The producer makes no sorting, deduplication, work replacement, zero normalization or output-body mutation. PolicyWork's existing sort/merge is the actual ordinary result algorithm, not producer normalization.

Errors use the existing exhaustive named error_json serializer, retaining InvalidAudioLimits, AudioRangeOutOfRange, InvalidPlan messages, AudioQueryLimit budget labels, Document codes/messages and Time variants. An unsupported future error fails explicitly. The ordinary API supplies no failed-policy partial receipt, so the producer records that absence as text and keeps actual second-query returns/accounting separately; it does not invent zero work.

The existing observer serializes actual Domain second processing returns before their real policy accounting, with complete private Stage/Bound payload through capture_baseline. It records accounting events separately. Root signal's own independent binding walk is not a Domain second-query event; nested Domain events can have nonzero depth. Thus these events must be interpreted by route/depth rather than treating absence as a reuse witness.

## Work, limits and Source behavior

For full/crop/empty it records default output, a literal returned-work-cap call and a real one-short call when work is positive. A failed exact returned-work cap is retained. This matches PolicyWork: enter spends one before limits() requires positive remaining allowance, so an empty returned work of one can legitimately need allowance two. No canonical work is increased to the completing cap.

When exact returned work fails, every successive valid larger cap is called and stored until the first success, with the adjacent failure identified literally. Span probes likewise call every positive cap from one through the validated default 4,096 and retain each failure until success; zero is separately called if first positive success was one. It never derives span cap from aggregate contents, which would be wrong for dense bound inventories. Searches are bounded by the actual defaults (65,536 work and 4,096 spans); the already successful default call provides the completing upper endpoint for these deterministic fixtures. No new production cap or probabilistic/binary-search boundary inference appears.

The full-window scalar matrix records zero/above-max limits, tiny positive work/spans, outside/reversed ranges, invalid-limit/range combinations and tiny-positive-work/range combinations. PolicyWork validates limits, then enters/debits before child range validation. Consequently tiny work may return recursive policy work before range error; the candidate stores the actual named result and does not force a preferred label. Existing no-binding Source parents still execute their actual current query/content/endpoint policy work. Neither Source absence nor no-binding status is translated to zero query work or presumed successful exact allowance.

## Sealed finish fidelity

Each sealed trial builds a fresh actual ordinary first query with independently recorded default limits. It captures the full first processing query before consuming finish_policy. Fresh policy limits are never reused as first-query limits or merged into first work. On success it serializes and asserts full returned-first-query equality, including private histories, then records policy work/lookup literally. It uses the actual sealed path, so no public/reconstructed first tape or invented eligibility witness enters the call.

On failure the first pre-finish body remains in the record; the API consumed the capability, so there is no fabricated returned-first value. Lease/destructor/failure lifetime proof remains outside this ordinary producer. Identity trials create a real equal cloned Domain or change the same Domain's requested range, invoke finish, require the exact current identity error, and require no observed second query. They include invalid fresh limits to preserve identity-before-limit priority. They do not claim a changed-range query was successfully prepared as the first query.

## Dedicated evidence still required before production

1. Add the actual dense_bound_repeat_inventory_uses_shared_work_not_output_span_capacity fixture. Prove valid contents density greater than a positive output span cap; the present probe strategy avoids the wrong inference but does not create that dedicated case.
2. Add a deliberate eligible sealed first tape whose fresh smaller positive span cap reaches the policy binding fallback walk. A refused current query before that branch is not fallback evidence. Inspect actual depth-zero observer events and final policy, rather than inferring reuse from missing events. Existing 26 paired tests remain separate regression evidence.
3. Add dedicated policy documents for retained hidden history, resume terms, reanchors and gap bindings, plus explicit Source endpoint versus SilentHold/raw-emptiness masks. Some current parents overlap these features; their existence is not proof the relevant policy branch/range was reached.
4. Add nonunity Preserve and shift-at-unity endpoint/fallback behavior, signed/fractional physical grids, retained Point policy, one-sample/paged seams and fractional parity. Full/crop/empty over the reused supports is not a substitute for those chosen boundary windows.
5. Creative fade/editorial/coincident-Hard/origin cases are a separate later product. Their snapshots, retained-input factory, arbitrary Signal/source-voice/ProjectedStage policies are explicitly outside this producer and must not be marked closed by its capture.
6. After the independent ordinary captures/freeze, future admission needs false-mode complete OLD comparisons, actual accepted partial failures, per-callback refusal/cancellation/issuer rotation, allocation overlap and requested-Layout peaks, sealed first-carrier failure lifetime, host four-product/source-I/O/PCM masks/dependencies and warm zero-construction evidence. None can be inferred from an ordinary returned output.

These are production-readiness gaps, not reasons to alter the existing 33 documents or normalize their observations. Supplemental real fixtures should be captured independently before the algorithm/host changes, and all existing frozen bodies must remain intact.

## Capture handoff and pins

The ignored producer requires an explicit variant, hexadecimal source-manifest SHA and published checkpoint identifier, restricts a new absolute output to canonical /tmp, uses create_new and sync_all, and does not read an expected policy golden. It opens the output before matrix evaluation; an assertion failure can leave that new output empty, so retain the failure artifact and retry with another new path. No completed snapshot should be inferred from mere file existence.

Both actual variants still need compilation, execution of every assertion, independent source/executable manifests, capture-body comparison and an eventual ordinary-body assertion test. Only the named variant, source_sha256 and published_checkpoint fields may be excluded for the cross-variant body comparison. Nothing here authorizes lookup/work/output stripping.

Candidate new-module SHA-256: ddd396093b61924e0600cd0f702b6eec9f0352f8d6e8df3cb3415e5c212bac2a. Both complete patches: c08cf705028b5e5aedb1834f3565bd7962c23b46bf322f8ff67e510e34ebf76e. candidate-pins.json file SHA-256: 45e95ddf68463e0431ae4594717eeb939342126d4b1666e10aa9f44e1ba66ba4. Source pins are read provenance, not a substitute for the complete OLD runtime manifest.
