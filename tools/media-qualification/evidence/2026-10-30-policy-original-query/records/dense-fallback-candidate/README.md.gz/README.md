# Dense Bound and reached fallback OLD cases

Scratch-only child module candidate. No repository edits, Cargo, Git, native runs, query execution, capture or freeze were performed here. This candidate is independent of the retained-history worker's child module.

## Integration

Copy the new `crates/deadpan-plan/src/audio_owners/legacy_snapshot_v1/policy_dense_fallback_cases.rs` child, or use `new-child.patch`. Append `module-declaration.rs.fragment` inside the existing `policy_query_baseline` module. No helper visibility or production hook change is needed: the child accesses the parent's private actual-call/serialization helpers and the existing second-query observer.

The parent owns matrix integration. Add `policy_dense_fallback_cases::matrix()` as a separate producer-body key, for example `dense_and_fallback_cases`. Use its custom matrix instead of routing dense cases through the basic producer's default-limit matrix. Every dense trial records the literal existing legal 256-span/65,536-work limits. Failed Domain or reduced-cap trials are recorded as typed errors; their default success is not assumed.

`pub(super) visit_cases` has the same callback shape as the processing visitor and visits five checked parents: the literal dense unbound Root, dense bound Root, an actual owner-input-produced bound Root Domain, and the existing exposed-Preserve and shift-at-unity Domains. `pub(super) matrix` records complete ordinary and sealed outputs plus separate proofs/surveys.

Expected full test paths from this declaration are below. The parent must confirm them in its actual test `--list` before using `--exact`, as the earlier basic producer's initial omitted `plan::` filter ran zero tests.

```text
plan::audio_owners::tests::legacy_snapshot_v1::policy_query_baseline::policy_dense_fallback_cases::dense_bound_inventory_exceeds_actual_output_span_cap
plan::audio_owners::tests::legacy_snapshot_v1::policy_query_baseline::policy_dense_fallback_cases::fresh_positive_span_fallback_reaches_and_accounts_second_walk
```

## Actual fixtures and evidence

`dense_documents` ports exactly the existing setup statements in `tests/audio_policy.rs::dense_bound_repeat_inventory_uses_shared_work_not_output_span_capacity`: 256 one-frame silent Hold plays, identical project/revision/timing identities, checked unbound document, real `capture_unbound_audio_bindings`, checked bound document. A text comparison verified that the entire setup from `let node` through `let bound` is identical to that original fixture. No custom Span, query, layout or binding state is fabricated.

Every dense descriptor embeds both complete documents, the selected document, the original fixture source, binding-capture timing, actual parent identity, window and setup selector. The additional Domain is produced by an actual Root owner observation at zero and checked `audio_owner_input`; its descriptor includes the complete actual captured-input serializer and the exact setup calls/limits.

Dense ordinary calls cover full/clipped/empty at the original explicit limits, full at 255 spans, actual returned-work and one-short limits when the full query completes, and the original small-work refusal. All outputs are literal actual snapshots. The separate density proof independently performs the original unbound/bound Root policy pair, requires complete suppressed-range parity, requires an actual processing Bound terminal, and asserts that the bound policy's actual content inventory exceeds 256 while its query succeeds within the original work limit. It records the full unbound policy, bound policy and private processing snapshot, not just a derived count.

The reached-fallback cases reuse the existing checked `processing_query_baseline::visit_cases` fixtures corresponding to the old sealed tests:

- `additional/exposed_preserve_and_silent_hold/domain`
- `additional/shift_at_unity_and_silent_hold/domain`

Each records an independently called complete current flattened query. Its actual two spans determine the fresh positive cap. A fresh actual sealed first query must contain Stage, and finishing with that cap must preserve the entire first processing product and match the complete ordinary policy at the same cap. The existing actual observer must report one successful depth-zero second-query return and one successful accounting event, with the full second-query fields and work retained. No computed work offset or invented reuse witness is used.

The same cases call the current flattened query independently at cap one and require the actual `AudioQueryLimit("span count")`; the sealed cap-one result must return that same typed error. Exact and one-short actual policy-work trials are recorded separately with their actual events.

The parent supplied independent seed evidence before this candidate: both reached-fallback fixtures succeeded at cap two with first tape `[Stage, Bound]`, returned/accounted a two-span depth-zero second query with canonical work 32, and failed at cap one. This supported fixture selection; it is not execution of this candidate or a frozen expected body.

## Span-length gate and bounded limitation

The reached second walk above is selected by the co-produced exposed-Stage witness. The sufficient fresh cap equals the first tape length. It does not prove that the `first_tape.len() > fresh.maximum_spans` branch can reach a second walk.

The child additionally surveys the six nonempty wider-first Domain cases already covered by the old sealed test. It builds each actual first query, records its complete private snapshot, calls the actual current flattened query at `first_tape_spans - 1`, then constructs another actual sealed first query and finishes at that same fresh cap. It requires the independently called current query to refuse span count and the sealed finish to return the identical typed error; it records all actual events. The first products from the two actual preparations must match completely.

This is a bounded, executable check of why those existing fixtures cannot demonstrate a reached cap-length-forced fallback. An absent return event alone never proves reuse or non-entry. If this survey fails, retain the actual counterexample and investigate it; do not synthesize a longer first Vec, change a witness, relabel a current-query refusal as a reached second walk, or change the ordinary algorithm. A new call-entry hook is unnecessary for the two successful reached-fallback cases and was not added.

## Pins, checks and remaining gaps

`source-pins.json` pins both actual roots' relevant fixture, producer, policy, Domain and frozen-input sources. The pins were identical across Main and Scope at preparation. `candidate-pins.json` hashes the candidate and fragments. They are integration pins, not a complete immutable OLD runtime source manifest.

Scratch rustfmt parser/format checks passed, and the dense setup text matched exactly. Rust type/lifetime/name resolution, Clippy, actual Domain setup budget, all five visitor callbacks, the density assertion, six-case span survey, both new tests, full candidate captures and Main/Scope equality remain owed to the parent. No candidate observation or coverage count has run.

Creative fades, broader retained-history cases owned by the other worker, additional source/endpoint/history fixtures, admitted reservations/Layout peaks, partial accepted policy-work receipts and host/DSP lifetimes remain outside this child. No production cap, work weight, error priority, binding history, query algorithm or expected body changed.
