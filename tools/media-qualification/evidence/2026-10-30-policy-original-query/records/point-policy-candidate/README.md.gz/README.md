# Actual Point policy path candidate

Scratch-only candidate. No actual repository edits, Cargo/Git/native work, capture or golden changes. Parent's guarded Core/Native runs must finish before integration. Initial source handoff was parser-only; parent owns compiler, borrow, lint and runtime fixes.

## Files and wiring

- New `crates/deadpan-plan/src/audio_policy_point_trace.rs`: one cfgtest-only optional scoped observer for the actual metered Point arm. It stores no query, lease, cache or global accounting state. The scope callback reads the existing test Policy ledger.
- `audio_policy_query.rs.point-hook.patch`: cfgtest child declaration after the existing inner module doc plus four calls in the actual nonempty Point arm, before/after `signal_admitted` and before/after actual offset conversion. Observations contain scalar origin/support/selection/signal-range context, first/last returned ranges plus count, and the actual shared budget counters. When inactive, the observer allocates nothing. The ordinary policy implementation and OLD producer are untouched.
- New `crates/deadpan-plan/src/audio_owners/policy_point_path_tests.rs`: child of existing `policy_admission`, reusing its private Policy/Lease/Observer/oracle helpers.
- `module-declaration.rs.fragment`: append under `audio_owners/policy_query_admission_tests.rs`.
- `extend-frozen-point-callback-seed.patch`: add the specific existing frozen Point case to the current four-seed callback sweep, changing its exact checked count to five.
- `complete.patch`: hook, combined callback-filter/test-child wiring, and both new files. Apply this or the separate pieces, not both.
- Source/read pins and candidate hashes are separate. `audio_policy_query.rs.hook-candidate` is for reviewing the tiny hook diff, not for overwriting later parent production edits.

Expected child test paths, to confirm with the parent's actual `--list` before `--exact`:

```text
plan::audio_owners::wide_gain_query_admission_tests::policy_admission::point_path::frozen_point_case_observes_actual_point_arm_and_keeps_the_complete_old_policy
plan::audio_owners::wide_gain_query_admission_tests::policy_admission::point_path::supplemental_signed_point_repeat_retains_actual_clone_and_offset_buffers
plan::audio_owners::wide_gain_query_admission_tests::policy_admission::point_path::signed_point_offset_reservation_refusal_and_rotation_release_old_and_current_ledgers
```

## Evidence the tests require

The frozen case is `wide/nonunity_shift_fractional_point_ceil_source44100/root`. Its actual checked descriptor is matched through the existing visitor and frozen body. The new test compares complete fields and canonical work using the existing assertion helper, requires actual Point arm observations with nonempty borrowed reference support/selection and nonzero origin while ledger bytes are positive, and verifies false compatibility emits no admitted Point observations or callbacks. Adding this case to the existing callback sweep covers every actual reservation/work refusal, cancellation prefix and work/reservation issuer rotation in this frozen Point path, using the existing accounting framework.

The signed supplemental fixture ports the checked public document/binding helpers from `tests/audio_fades.rs` and its `selected_origin_point_clock_uses_current_support_without_resetting_phase` reference: a Preserve selects `[1,2)` from a complete three-frame silent Hold at 32 kHz. That existing fixture's Point support is `[-1,3)`, with signed nonzero origin `-1`. The supplemental current document places the same complete Hold in an actual two-play Repeat using normal validated public Node/Iteration/ProjectDocument types, so the Point Signal clone also owns a real repeat path. The binding comes from real `FrozenAudioLayout::capture` and checked AudioBindingState, not a synthetic Point domain, Span, query or layout.

This new repeat variant is explicitly supplemental ordinary parity, not another frozen OLD result. The test calls the literal current ordinary policy and compares every returned field and canonical work to the admitted result without recursive normalization or invented work offsets. Both the reference and current/bound documents are constructed and validated anew by their actual public factories. No source/provider/PCM authority is claimed.

On each actual Point frame, the signed test requires:

- Negative nonzero reference origin and nonempty support/selection observed inside the top constructor.
- Positive old live storage before clone, higher live storage after the actual repeated-path clone, unchanged canonical counters during clone and positive actual additional work.
- A complete one-range recursive result and one-range offset result whose two endpoints equal the observed input endpoints plus the real origin.
- An actual `Layout::array::<Range<i64>>(1)` offset output reservation while the charged recursive range input and Point frame remain live. The test's thin observer delegates to the existing Policy/Observer ledger; it does not implement a second accounting framework. This independently expected Layout supplements phase/callback totals rather than deriving every peak solely from them.
- Complete output parity, total/canonical/additional/accepted-spend reconciliation, exact measured total/peak success, and one-short work/byte refusal with zero remaining live charge.

The last test arms the existing Policy's next-reservation refusal or rotation from the actual negative-origin BeforeOffset observation. It requires that next actual offset reservation to fail with the exact expected error, retain its one accepted pre-reservation work unit without refund, and leave both the retained old ledger and current issuer ledger at zero live bytes. It does not tolerate unrelated errors or raise caps. No AfterOffset success event is accepted on that failed frame.

## Checks and limits

Rustfmt parse/format passed for both new files and the complete hook candidate, with `skip_children=true` because the hook review file is stored outside its eventual source directory. No compiler, test or runtime outcome is claimed. The two-play repeated binding, exact negative origin, positive clone-byte delta, one-range offset, and expected failure positions are strict assertions awaiting the parent's actual run. A fixture failure must be investigated against the actual receipt rather than replaced with a fabricated query or arbitrary error allowance.

The initial adapter explicitly drops `observer.inner` to end its mutable ledger borrow after taking the observations; parent lint may prefer a lexical block around that adapter if `drop_non_drop` fires. Parent owns such compiler/lint fixes. The candidate intentionally was handed off as soon as it parsed.

The hook observes scalar context and actual budget counters while the real values remain owned. Test-only observer allocations are outside the admission ledger, as with other test observers; no RSS/heap allocator total is claimed. First/last ranges constitute complete offset content only because the signed fixture asserts exactly one range. Broader multi-range/nested Point tracing is not claimed. Existing direct signed-placement clone component tests remain complementary and are not presented as proof of the top policy path.

The frozen policy body remains unchanged at SHA256 `09c163d144af4532c5d815162b59a02c63fd82843c0ff0f34ea010ff4ba6e225`. Hook calls are only in the metered constructor's new Point arm. No ordinary producer, work weight, cap, history, eligibility, source-I/O or DSP behavior changed.

## Production equivalence and source freeze

The trace module, four observations and their scalar context are all `cfg(test)`. Non-test Plan code changes only from the existing `offset_ranges(ranges, origin, budget)?` tail expression to `let offset = offset_ranges(ranges, origin, budget)?; offset`. This names and returns the same Owned result, introduces no allocation, clone, debit, canonical operation, extra fallible step or guard transfer, and preserves the Point-arm drop ordering. NativeStage depends on non-test Plan, so the already-started Scope NativeStage evidence is not invalidated by this test-only addition. This is a source-equivalence statement, not a binary-byte equality or new execution claim.

Parent integrated the initial candidate into Main while Scope remained guarded by its ongoing NativeStage run. The worker's final source-pin check detected that Main change and stopped before regenerating against it. Final patch before-copies therefore use unchanged Scope bytes, verified to match the recorded original Main and Scope hashes exactly. The worker did not edit either actual root. Candidate new source files are frozen at the initially handed-off hashes; parent owns subsequent compile/runtime corrections.
