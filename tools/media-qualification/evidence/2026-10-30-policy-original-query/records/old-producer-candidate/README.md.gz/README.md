# OLD policy producer candidate

Scratch only. Do not integrate, compile, capture or freeze until the current processing checkpoint is published. No actual repository file was changed, and no query/capture/test executable was run while preparing this candidate.

## Files and wiring

- `crates/deadpan-plan/src/audio_owners/legacy_snapshot_v1/policy_query_baseline.rs`: one shared new test-only producer module for Main and Scope.
- `patches/{main,scoped}/legacy_snapshot_v1.rs.patch`: append the child module declaration to the existing test-only parent.
- `patches/{main,scoped}/policy_binding_baseline.rs.patch`: widen only existing `Observation`, `Observation::start`, and `Observation::finish` to `pub(super)` within the existing test-only legacy snapshot parent. This reuses the already inactive-by-default actual Domain second-query observer. No new production hook or query algorithm change.
- `patches/{main,scoped}/complete.patch`: those two minimal diffs plus the new module.
- `source-pins.json`: SHA256 read pins for both roots. These are integration/fixture provenance pins, not the complete OLD source manifest required for an actual capture.
- `before/{main,scoped}/...`: exact original copies of the two files patched.
- `candidate-pins.json`: hashes of the candidate source and patches.

The declaration is:

```rust
#[path = "legacy_snapshot_v1/policy_query_baseline.rs"]
pub(in crate::plan) mod policy_query_baseline;
```

## Recorded evidence

The producer reuses `processing_query_baseline::visit_cases` directly, including all 33 actual checked parents, 20 Root and 13 Domain. It preserves complete visitor descriptors and `fixture_source`. The one storage constructor descriptor names an existing builder rather than retaining its document; the new snapshot additionally embeds that exact builder and its helper source, taken from the existing file up to `fn measurement`. There is no duplicate fixture constructor.

For ordinary `RenderPlan::audio_policy` and `AudioDomain::policy`, every successful result records the complete suppressed ranges, serialized content inventory, all lookup fields and literal canonical work. Every error records the existing named typed error serializer. Actual observed Domain second-query returns/accounting events are separate, including complete private Stage/Bound history through the existing serializer.

For each full, cropped and empty window:

- Default actual policy call.
- A fresh call with `maximum_work` equal to the returned canonical work, and a fresh one-short call. Empty policy can require positive remaining allowance at a later child query without spending that allowance. The producer records a literal failure at the returned-work cap instead of rewriting work or requiring that call to succeed.
- When that literal returned-work cap fails, actual consecutive higher-cap calls find the first completing budget, recording every failure and the adjacent completing call. This is an observed allowance boundary, not an added canonical debit.
- Actual increasing positive span-cap calls find the first complete result, recording every probe and the adjacent one-short failure. If the first complete cap is one, its one-short zero-cap typed failure is also recorded. No cap is inferred from aggregate `contents.len()` or an outer processing count.

Full-window trials also cover zero and above-maximum limits, tiny positive work/spans, out-of-support and reversed ranges, invalid-limit/range priority, and tiny-positive-work/range priority.

The 13 Domain parents additionally run the same fresh-limit matrix through actual `processing_for_policy(...).finish_policy(...)`. Every trial prepares a new actual ordinary first query with separately recorded default limits; policy limits remain fresh. Successful finish must return the entire first query unchanged, and policy's own counters remain literal. The existing second-query observer records actual fallback calls without inferring a reuse witness from contents. Dedicated trials capture equal cloned Domain rejection, changed in-support/empty/outside/reversed range rejection, and identity-before-invalid-limit priority. They assert the exact current identity error and no observed policy second query on identity refusal.

This module does not read or rewrite an expected policy golden. `matrix()` is available for the eventual frozen-body check; the only test is the ignored manual producer.

## Deferred execution

After publication, the parent must revalidate the source pins, integrate the minimal candidate, and compile both variants. The exact test filter is:

```text
plan::audio_owners::tests::legacy_snapshot_v1::policy_query_baseline::capture_old_policy_query_baseline_v1
```

Required producer environment:

```text
DEADPAN_POLICY_QUERY_OUTPUT=<new absolute /tmp file>
DEADPAN_POLICY_QUERY_VARIANT=main-inherited | scoped-published
DEADPAN_POLICY_QUERY_SOURCE_SHA256=<complete immutable OLD source-manifest SHA256>
DEADPAN_POLICY_QUERY_PUBLISHED_CHECKPOINT=<published processing checkpoint identity>
```

The output uses `create_new`, writes once, and syncs. The parent owns executable/source pins, two independent actual captures, body comparison, freeze, and the later ordinary-body assertion. The provenance fields are `variant`, `source_sha256`, and `published_checkpoint`; any comparison that removes them must name exactly those fields and compare all remaining data literally. Do not normalize lookup or work.

## Checks and gaps

Scratch `rustfmt --edition 2024` and `rustfmt --check` passed, establishing parser/format acceptance. Both complete patches also passed `patch --dry-run` against the scratch before-copies, and both actual roots still match every recorded read pin. Rust name resolution, lifetime/type checking, Clippy, the producer, all matrix assertions, observer coverage counts and actual Main/Scope equality remain owed to the parent. No result count or branch coverage was measured.

The existing corpus contains eligible Bound and exposed-Stage parents, but this candidate deliberately makes no unexecuted numerical reuse/fallback coverage claim. Inspect actual depth-zero second-query events after capture. An absent event on a no-binding parent is not evidence of binding reuse. A span-refused current query can precede the intended tight-span fallback; the literal record must retain that behavior rather than relabeling it as proven fallback. Existing 26 paired sealed tests remain independent regression evidence.

Follow-up real fixtures from `policy-fade-admission-next.md` remain necessary before the larger admission unit: dedicated dense bound inventory greater than output span capacity; deliberate tight fresh-span fallback that reaches the second walk; explicit retained-history/resume/reanchor/gap policy, source endpoint and nonunity Preserve/shift-at-unity edge cases; one-sample/paged seams and fractional parity; creative fade/editorial/coincident-Hard/origin cases. Existing overlap with these semantics is not a substitute for their dedicated checks. Arbitrary Signal/source-voice/ProjectedStage policy, retained-input fade factories, additional fixture construction, fade snapshots, partial accepted policy-work receipts, admission callbacks/Layout peaks, host lifetime/source-I/O and numerical/DSP evidence are outside this producer.

No production caps, work weights, error labels, witness eligibility, ordinary algorithms or expected files changed.

## Parent filter correction

The parent type-checked both variants. Its first two commands used the incomplete filter shown in the initial handoff, ran zero tests and produced no capture. The parent confirmed the full test path with its actual test listing; the filter above now includes the leading plan module. This scratch documentation correction is not a capture/equality result. Parent execution remains authoritative.
