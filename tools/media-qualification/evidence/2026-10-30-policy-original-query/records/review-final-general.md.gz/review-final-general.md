# Final general review: policy-query admission

No concrete findings in the reviewed scope.

The new Root and physical Domain entrypoints create one metered `QueryBudget` for policy construction, including recursive bound traversal, copied Point signals, retained output storage, and the returned query lease. The sealed Domain finish path checks exact Domain identity and range, keeps the first processing query's lease live, and reports policy-only work. The Original host stores the admitted policy result, checks its issuer alongside the existing carriers before source reads, and retains its lease through the prepared request. The current construction path appears to preserve the legacy policy operations, query ordering, errors and observed output semantics; the frozen baseline and test call sites exercise ordinary and sealed cases, limits, callback refusal, cancellation, issuer rotation, and actual WAV/source-failure lifetime.

Review limits: no Cargo/native/browser checks were run, as instructed. The 14 MB frozen golden body was not read; only its structure/usages and relevant test code were inspected. `plan.rs` was reviewed through the specified isolated candidate, not the branch copy with unrelated family changes. The worker's additional cfg-test hook and signed-origin fixture were not yet integrated at review time.

## Integrated Point-path follow-up

No concrete findings in the added Point-path diff. The production policy implementation is unchanged; the new observer module and all four observation sites are `cfg(test)`. The observations are scalar snapshots of the actual `bound_policy` Point arm and do not call admission methods or mutate query state. The callback-seed addition is additive (the original four cases remain), and its expected count is updated to five.

The new tests tie a frozen nonzero-origin Point case to the OLD policy snapshot, and separately use a signed, repeated 32 kHz Point fixture to exercise clone accounting, the range offset, actual `Range<i64>` reservation, exact work/peak limits, one-short refusal, and reservation refusal/issuer rotation cleanup. I found no assertion that treats a proposal, detached helper, or fixture descriptor as proof of traversal; the trace is emitted only from the actual Point arm.

Follow-up limits: no Cargo/native checks were run, and no compilation result is assumed. The signed supplemental case compares its new fixture's metered output against the ordinary current policy constructor, while frozen-old parity is supplied by the separate selected 44.1 kHz case.
