
#[test]
fn empty_child_headers_have_local_cost_without_replaying_the_prefix() {
    let plan = crate::audio_allocated::query_storage_tests::fixture();
    let signal = plan.audio_signal();
    let mut admission = Policy::<true>::new(usize::MAX);
    let mut local = crate::plan::audio::Budget {
        remaining: 65_536,
        lookup: LookupStats::default(),
    };
    {
        let mut budget = QueryBudget::new(&mut local, &mut admission);
        budget.canonical(7).unwrap();
        budget.additional(4).unwrap();
        let start = budget.checkpoint();
        let value = signal.structural_child_query(
            SignalSample(0)..SignalSample(0),
            limits(&budget),
            AudioBoundaryRule::RoundEven,
            (false, false),
            &mut budget,
        ).unwrap();
        let usage = budget.usage_since(start).unwrap();
        assert_eq!(usage.canonical, 0);
        assert!(usage.additional > 0);
        assert_eq!(value.query.work, usage.additional);
        assert_eq!(usage.lookup, LookupStats::default());
        assert!(value.query.spans.is_empty());
        assert_eq!(value.query.project_id, plan.metadata.project_id);
        assert_eq!(value.query.revision_id, plan.metadata.revision_id);
        assert_eq!(budget.admission.0.borrow().forwarded, 11 + value.query.work);
        assert!(budget.admission.0.borrow().live > 0);
        drop(value);
    }
    assert_eq!(admission.0.borrow().live, 0);
    assert!(admission.0.borrow().peak > 0);
}
