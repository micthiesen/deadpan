# Start/End retained policy case extension

This scratch-only patch is based on the currently integrated `policy_retained_cases.rs` from Main and Scope (identical SHA-256). It parameterizes the existing source-endpoint fixture over `AudioSourceEndpoint::Start` and `AudioSourceEndpoint::End`.

The End variant preserves the prior actual fixture construction, sample windows (`8008..8264`), root and physical Domain observations, one-sample seam windows, checked End provenance, and labels. The Start variant changes only the endpoint supplied to `AudioReanchorStep::for_source_endpoint`; it is labeled as a checked-fixture variant with that changed input, not as an independently checked test. Both variants create a real `ProjectDocument`, install the captured binding state, validate it, compile `RenderPlan`, locate the real owner at sample 8008, and call the ordinary API through the same Root and physical Domain observations.

The returned source endpoint record now contains explicit `endpoint_variants` entries. This is a source-only patch; no Cargo/test execution was performed. `rustfmt --edition 2024` was run on the scratch candidate. Parent integration still needs to compile and execute the fixture to confirm Start is reachable at the retained sample windows and compare Main/Scope outputs.
