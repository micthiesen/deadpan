# Initial actual policy constructor candidate

Scratch-only new `crates/deadpan-plan/src/audio_policy_query.rs`. Parent copied the initial module into Main/Scope and owns compilation, lint, integration fixes, exports, sealed finish, host work and execution. This candidate and `initial-audio_policy_query.rs` are frozen at SHA256 `f9658ef70f06fd3d1d4083517d2e267d490dad01faf858c0350a4c77e34af59f`; do not overwrite the parent's subsequent fixes with it.

`initial-new-module.patch` adds only this file. `module-and-exports.rs.fragment` names the exact child/export wiring. `integration-read-pins.json` records the dependencies as read after the parent integrated the earlier seams/Point/Domain work. `candidate-pins.json` hashes this handoff and its source artifacts. No actual repository file, Cargo/Git/native process, capture or frozen fixture was written/run by this worker.

## Settled API

- Public immutable `AdmittedAudioPolicyQuery<I,L>` fixes the query label to `AudioSample`. It has `query`, total `work`, `canonical_units`, `additional_units`, and `was_forwarded`. There is no Clone, mutable query, public constructor or generic detach. No unmetered extractor was needed.
- `RenderPlan::audio_policy_admitted(samples, limits, &mut A)` and `AudioDomain::policy_admitted(...)` return the carrier with `A::Error`.
- Internal `audio_policy::query::domain_query_with_processing(domain, samples, limits, Option<&[AudioProcessingSpan<'plan>]>, &mut QueryBudget<A>)` returns `QueryResult<AdmittedAudioPolicyQuery<A::Issuer,A::Lease>,A>`. It validates limits. True mode requires the supplied fresh zero-counter/lookup policy budget. Parent validates the exact Domain/range identity and consumes first-carrier mode/issuer validation before calling it, then keeps the first whole carrier alive and passes Some only when its co-produced witness permits.

The module uses the accepted Structural signal child, physical flattened child, physical processing fallback child and Point `signal_admitted` clone APIs. Parent's new Domain wrappers are named `audio_child_query` and `processing_child_query`.

## Construction and billing

False mode calls literal ordinary Root/Domain policy, including sealed Domain reuse/fallback, then wraps the returned actual value with no spend/reserve callback. Existing ordinary algorithms, providers, separate local child budgets and real observer ordering are untouched.

True mode owns one QueryBudget for all recursion. Children mutate it directly and already have local query work/lookup fields. No successful child is rebilled or folded into lookup. Canonical policy enter/depth, content, retime-length and per-retained-range sites remain literal. Recursive range Vecs stay unmerged; final sort/merge/AudioSample labeling occurs once. The sort has no synthetic work estimate.

Global content inventory is an actual Vec in GuardedBound. A whole guarded current-query drain is zipped with it while real AudioContent values move into the inventory inside allocation-free checked maps. New capacity is admitted/allocated while old contents, complete current query and current span remain live; old-element moves are billed outside maps. Existing collector layouts are reused, without a general Core/GuardedBound extraction.

Range buffers are Owned values. Point offset uses a separate Vec; parent extension, final merge and labeled output have distinct buffers with original inputs alive during allocations. Additional units cover actual layouts/reservations, old-element moves and actual content/range/label transfers. No canonical category, cap, refund, graph cache or DSP behavior changes.

Consumed current query headers/span payload charges can remain conservatively in the final global guard after those metadata values drop. Actual consumed input buffer charges end after their IntoIter drops. This is explicit requested-Layout accounting; neither exact final heap equality nor RSS is claimed.

## Review and owed checks

Scratch rustfmt parse/format passed. No type, borrow, lint or runtime validation was run by this worker. Parent compilation is authoritative. `source-audit.md` reviews raw/Point lifetimes, current growth/refusals/drop ordering, literal canonical/error order, unmerged recursion and final seal. It found no material source-level issue, with limits stated there.

Focused tests still needed: the entire frozen false body; true complete fields/canonical/lookup and accepted canonical+additional conservation; independent Core paired receipts for intermediate resolutions; failed accepted prefixes; all meaningful reservation/spend refusals and issuer rotations; live input/output/replacement Layout overlap and final-storage crosscheck; successful/failed sealed reuse/fallback with first-carrier mode/issuer rejection before callbacks; actual Point clone/offset/nonzero-origin evidence; and real host policy prediction/numeric/I/O lifetime tests. The OLD compact fixture SHA remains `09c163d144af4532c5d815162b59a02c63fd82843c0ff0f34ea010ff4ba6e225` and was not regenerated.
