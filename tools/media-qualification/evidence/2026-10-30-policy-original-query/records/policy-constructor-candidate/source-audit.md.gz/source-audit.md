# Initial metered policy source audit

Audited the initial candidate `audio_policy_query.rs`, SHA256 `f9658ef70f06fd3d1d4083517d2e267d490dad01faf858c0350a4c77e34af59f`, against the literal ordinary `audio_policy.rs`, the reviewed child-budget seams, current GuardedBound composition, raw-domain builder and Point clone API. This is a read-only control/ownership review while the parent owns compilation and integration fixes. No compiler, runtime, callback sweep or memory-peak result is claimed.

No material ownership, canonical-order or retained-history defect was found in this source pass. The observations below describe exactly what was checked and what remains unproved.

## Raw domain and Point frame

`bound_policy` calls canonical enter before `raw_domain_admitted`, as the ordinary function enters before `raw_domain`. The returned `Owned<AudioBoundDomain>` remains a named recursive-frame local; matching borrows its Root/Point value. The raw domain's complete value precedes its independent charge on every scalar error, recursive refusal and unwind. Parent binding query/first-tape guards remain live in the caller throughout this borrow.

The recursive return is only an `Owned<Vec<Range<i64>>>`. Content returned into the global inventory came from actual newly constructed current queries and moved under their guards; no borrowed Bound, raw domain or temporary Signal is stored in the final public policy query. Final contents have no Plan lifetime parameter.

Root retains the actual raw Root domain and guard through recursion. Point calculates the same checked selection-minus-origin endpoints before creating `signal_admitted`; that is the old ordering before `domain.signal()` and child enter. The actual separate Signal clone stays owned through recursive current/binding policy and offset conversion. Offset conversion has its own output Vec while the complete recursive input IntoIter/buffer charge remains live, and computes both checked additions before each output growth/push. The converted Vec then stays owned through the parent's inverse mapping. No input/offset/parent output buffers are detached or reused as each other.

The raw Owned domain is conservatively retained until `bound_policy` returns, including the parent inverse-mapping loop. This is actual live storage in this implementation. It is not a claim that ordinary Rust temporaries have the same minimal lifetime or that the allocation cap equals RSS.

The actual closed Point factory installs Structural through `for_placed_definition_admitted`; evaluation replacement changes definition/repeats/bypass only. Root uses `RenderPlan::audio_signal`, also Structural. These factories do not reach the ordinary Source-voice hold-carrier branch. The new public methods admit only Root/Domain policy, and the shared Structural child rejects other providers. Existing ordinary arbitrary Signal/source-voice policy remains untouched. Omitting that ordinary-only branch from the closed metered closure does not replace meaningful Hold policy with a delivery mask.

## Current query, global inventory and growth

Each actual current query is completed before any content is inspected or transferred. Its complete guarded state is converted to an IntoIter plus owned headers/capacity, then zipped with the complete old global inventory. The inventory Option is empty only while this one named GuardedBound owns both the current query and every prior content. If any callback fails during that period, the local whole carrier owns all those values and lanes; the State's empty Option is not an escape or early release.

Current content checks and all old canonical charges precede taking the span. Actual AudioContent moves inside checked, allocation-free maps into the inventory Vec, without cloning. Source/RoomTone/Reverse owning identities remain covered by the combined actual query/inventory Plan/Core lanes. Other consumed span/header payload charges can remain conservatively in this global guard until final product drop; this is explicitly additional requested-Layout accounting, not a final-heap or RSS identity claim.

Before inventory growth, the old inventory, prior contents, whole current query and pending current span are still in the old GuardedBound. A separate Owned replacement is reserved before allocating its actual Vec. Each old-element move has its own accepted additional debit before a checked map. The old/new buffers and all original payload lanes remain owned together throughout every refusal/rotation position. No mutable Vec is placed outside its Source/Core guard.

At completed growth, the next Current state is constructed first, with new Vec before its new capacity. Only then is the old empty IntoIter/capacity dropped as an Owned pair. If an opaque old lease destructor unwinds, the new whole value still owns its Vec before its capacity, and the existing map retains the outer payload/Core lane. This avoids releasing the new buffer charge before its contents on that explicit old-capacity release boundary.

Current input buffers release only after their actual IntoIter dies. Their payload/header charges may remain in the global inventory's combined lane. Every independent binding query remains a named complete guarded local while its spans/Bounds are borrowed through recursion; it is not merged into inventory merely to borrow a Bound. Reused sealed spans remain borrowed from the parent's live actual first carrier.

## Canonical sites and error order

The metered helper prechecks `units > remaining` with recursive-policy-work before `QueryBudget::canonical`; structural/Core child failures retain their own existing labels. Enter checks policy depth before its one canonical debit. The child-limits helper still rejects remaining zero before calling even an empty child. No requested range is eagerly validated ahead of the original enter/child-limits path. Public false methods call the literal ordinary algorithms and add no spend/reserve callback or shared-budget observer fiction.

The following ordinary sites were compared directly:

- Current full query before per-span suppression/content work; content canonical one before insertion.
- Signal endpoint retime-length charge only in the selected/no-binding branch, and Domain's additional unconditional enabled endpoint-grid check before add_outside.
- Binding query after current inventory; no successful child spend/lookup fold in the shared-budget backend.
- Sealed reuse only after current query, no-binding/empty return and fresh span-length gate. The supplied tape remains subject to the parent's co-produced witness; this module does not rescan or widen eligibility.
- Per-Bound endpoint check, bound enter, raw-domain construction, empty/support decisions, reference first/last/floor/ceil/inverse arithmetic, outside-support ranges before recursive selection, then one canonical debit per returned retained range before inverse mapping.
- Separate Point offset Vec before parent inverse mapping, with checked subtract/add ordering preserved.

Recursive ranges remain unmerged. Only the final finish sorts by start, skips empty ranges, extends overlapping/touching ranges and produces the final AudioSample-labeled output. Therefore the number and encounter order of the parent's per-retained-range canonical debits is not optimized away. The sort has no invented debit or allocation estimate.

Additional units correspond to actual accepted requested layouts, replacement old-element moves, content transfers, range insertions/rehome/offset conversions and final labeling. They can cause earlier real resource refusal than ordinary canonical-only limits, as intended. They are not substituted for canonical sites, rebilled child totals, historical-work offsets or refunds.

## Final value and issuer boundaries

All range containers are Owned values with capacity memory after their actual Vec/IntoIter. Suppression input remains live while merged storage grows; merged storage remains live when the full labeled output allocation is requested. Inputs drop before their own charges. The global contents guard remains live throughout both conversions.

Final contents/capacity and labeled output are zipped and mapped into the actual immutable PolicyBuffer. GuardedBound checks both Plan memories and all actual Core composition lanes before/after their moves. The public carrier is built only after the final checked map returns; its total is reconciled with cumulative canonical/additional and actual remaining work. There is no public mutable query, Clone, generic detach or charge transfer.

The caller's fresh first-carrier validation remains the parent's responsibility before invoking `domain_query_with_processing`. The function validates limits, requires a zero-counter/lookup fresh true policy budget, and never rebills first query work or lookup. Its false branch calls the existing ordinary Domain/reuse implementation with its own actual child budgets. Any consuming mode/foreign-issuer refusal in the parent's new sealed boundary must keep that first complete carrier live until it fails/drops.

New additional/capacity operations use the existing budget's before/after issuer checks; each `.map`/`.zip` uses the existing guarded validation. There is no policy callback between an actual content's extraction from its guard and insertion into a different unguarded owner. No new arbitrary provider or Core API is needed for this closure.

## Real Point coverage gap and required execution

The independent seed corpus already has a successful nonempty Root policy case `wide/nonunity_shift_fractional_point_ceil_source44100/root` with work 22 and two inventory contents, and its checked fixture explicitly produces an actual retained Point domain. The later frozen body retains this input; Point is a reachable branch, not a speculative factory.

The OLD policy producer observes Domain second-query events and final policy values, not a dedicated Point clone/allocation entry event. That corpus alone cannot prove that the new `signal_admitted` clone and separate offset buffers are charged/live at the intended callback positions. It also does not by itself establish a nonzero signed Point reference-origin case merely from a PointCeil fixture name. Inspect actual reference_samples in a focused real fixture rather than assuming that origin is nonzero.

Required focused evidence is actual admitted Root/Domain Point policy over full/clipped/one-sample ranges, literal final fields and canonical work against the frozen body, real Point signal clone owning-edge Layout/work evidence, simultaneous recursive-input/offset-output/parent-map buffer liveness, exact/one-short work and reservation refusals, issuer rotations with zero final live charge, and any nonzero reference-origin mapping fixture that the checked corpus can actually produce. Direct helper measurements can supplement this, but do not alone prove the top policy constructor's peak or lifetime. No synthetic Span/Point domain or new hook was added here.

Parent compilation, strict lint, the frozen false regression, true no-rebill/canonical/lookup reconciliation, complete refusal/rotation sweeps, real Layout overlap/final-storage comparisons and host lifetime/I/O tests remain authoritative and owed. Compiler fixes should be reviewed against this initial source hash; this audit has not exercised the code.
