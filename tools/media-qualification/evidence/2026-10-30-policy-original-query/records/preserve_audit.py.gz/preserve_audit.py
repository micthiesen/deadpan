from pathlib import Path
import json,hashlib
s=Path(__file__).resolve().parent
owned=set(json.loads((s/'owned-paths.json').read_text()))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
roots={'main':Path('/Users/michael/Code/deadpan'),'scoped':Path('/tmp/deadpan-query-groundwork-2026-10-26/scoped')}
result={}
for variant,root in roots.items():
 initial=json.loads((s/(variant+'-initial-authority.json')).read_text())
 others={name:pin for name,pin in initial.items() if name not in owned}
 for name,pin in others.items():
  assert sha(root/name)==pin['sha256'],(variant,'unowned changed',name)
 oracles=json.loads((s/'immutable-oracle-pins.json').read_text())
 for pin in oracles:
  assert sha(root/pin['path'])==pin['sha256'],(variant,'oracle changed',pin['path'])
 result[variant]={'unowned_initial_inputs_unchanged':len(others),'immutable_bodies':len(oracles)}
print(json.dumps(result))
