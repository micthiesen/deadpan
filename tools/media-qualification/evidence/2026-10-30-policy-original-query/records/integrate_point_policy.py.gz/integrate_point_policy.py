from pathlib import Path
import json,subprocess,sys
s=Path(__file__).resolve().parent
variant=sys.argv[1]
root=Path('/Users/michael/Code/deadpan') if variant=='main' else Path('/tmp/deadpan-query-groundwork-2026-10-26/scoped')
candidate=s/'point-policy-candidate'
modified=['crates/deadpan-plan/src/audio_policy_query.rs','crates/deadpan-plan/src/audio_owners/policy_query_admission_tests.rs']
new=['crates/deadpan-plan/src/audio_policy_point_trace.rs','crates/deadpan-plan/src/audio_owners/policy_point_path_tests.rs']
for rel in modified:
 p=root/rel
 before=s/'point-policy-integration-before'/variant/rel
 assert not before.exists()
 before.parent.mkdir(parents=True,exist_ok=True)
 before.write_bytes(p.read_bytes())
for rel in new:assert not (root/rel).exists()
for name in ['audio_policy_query.rs.point-hook.patch','extend-frozen-point-callback-seed.patch']:
 subprocess.run(['patch','--dry-run','-p1','-i',str(candidate/name)],cwd=root,check=True,capture_output=True,text=True)
 subprocess.run(['patch','-p1','-i',str(candidate/name)],cwd=root,check=True,capture_output=True,text=True)
for rel in new:(root/rel).write_bytes((candidate/rel).read_bytes())
p=root/modified[1];t=p.read_text()
assert 'mod point_path;' not in t
p.write_text(t+'\n'+(candidate/'module-declaration.rs.fragment').read_text())
names=['owned-paths.json']
names+=['source-files.json','main-logic-source-files.json'] if variant=='main' else ['scoped-source-files.json','scoped-logic-source-files.json']
for name in names:
 p=s/name;paths=set(json.loads(p.read_text()));paths.update(new)
 p.write_text(json.dumps(sorted(paths),indent=2)+'\n')
print('Integrated Point test-only observation and focused signed-origin tests in '+variant)
