# Frozen policy admission test candidate

## Result and integration state

The scratch candidate supplies 12 tests using the existing real generic Policy<false> / Policy<true> and Lease harness. Five export changes expose only existing checked fixture visitors, complete snapshot serializers and observation guards inside crate::plan. There is no production API, fixture construction, expected generation or expected body change.

Parent integrated complete.patch including the descriptor_snapshot correction. Parent then corrected two Vec<Value> versus Value type errors with Value::Array(events) and removed an unused import. Scratch implementation and patch are frozen as requested; do not reapply them over those fixes.

Parent reports Scope 11 pass / 1 fail before the final dense adjustment. The one failure is admitted full dense/actual_256_repeat_bound/domain at unchanged limits 256 spans / 65536 work, returning structural-work refusal. This was an incorrect unconditional success expectation in the candidate, not evidence that the ordinary oracle should change. Parent owns its explicit resource-refusal test and execution.

## Immutable oracle and exact coverage

The read-only oracle is policy-query-baseline-v1/snapshot.json, SHA-256 09c163d144af4532c5d815162b59a02c63fd82843c0ff0f34ea010ff4ba6e225. Nothing creates or rewrites expected files.

False-mode tests replay 1613 named calls:

| Corpus | Calls |
| --- | ---: |
| 33 seed ordinary parents, all recorded limits/ranges/errors | 973 |
| 13 seed sealed Domain parents, all fresh limits and identity cases | 411 |
| 11 retained checked Domain fixtures, default and edges | 64 |
| 3 dense parents and 2 actual Stage fallback parents | 31 |
| Existing wider-first survey sealed finishes | 6 |
| Source Start/End, Root/Domain, fresh matrices and exact seams | 128 |

Seed descriptors pass through the producer's existing descriptor_snapshot, preserving pinned constructor/helper source for storage fixtures. Retained descriptors compare completely. Dedicated dense descriptors match by exact name and every supplied field. Start and End reuse the actual checked endpoint builder, compare the complete validated document, then assert recorded owner/source identity and selected owner input. No invented output pages are reconstructed.

Every false success compares the full four-field policy serialization: suppressed ranges, complete typed contents, complete lookup statistics and exact work. Every false error compares the entire existing typed error snapshot and its literal statement that ordinary errors expose no accepted partial-work receipt. Actual second-query observation events compare literally. False-mode work callbacks, reservations, accepted work and live bytes must remain zero.

True-mode seed tests compare full/crop/empty for all 33 parents, 99 calls. Complete contents, suppression and lookup match immutable OLD; canonical work equals OLD work; actual total equals canonical plus additional and equals actual accepted callback work. Only top-level work differs by those independently witnessed categories. Final policies have no Bounds; there is no nested Core normalization.

True dedicated calls cover 11 retained defaults, 12 endpoint full/crop/empty calls and dense full requests. Frozen source incorrectly expects all three dense full calls to succeed. Parent preserves two actual Root successes and makes the actual Domain full failure explicit. Bound Root positive full retains all 512 contents under output span cap 256, so no extra page or raised cap is needed for positive dense inventory.

Static OLD dense full observations, all at spans 256 / work 65536:

| Exact parent | Canonical work | Contents |
| --- | ---: | ---: |
| dense/actual_256_repeat_unbound/root | 1537 | 256 |
| dense/actual_256_repeat_bound/root | 15617 | 512 |
| dense/actual_256_repeat_bound/domain | 22033 | 512 |

Bound clipped rows are Root 15495 / 508 contents and Domain 21845 / 508 contents. Empty rows are work 1 / zero contents. These are OLD canonical observations only; admitted fees are not inferred by subtracting from them.

## Resource and lifetime assertions

The requested-layout boundary test measures each of 33 full seed calls' actual accepted work and peak requested live bytes. Exact total and measured peak succeed; one-short work and one-short positive peak refuse and release all leases. Accepted work is never refunded. InvalidAudioLimits is accepted for a zero one-short limit only when measured total is one. This does not claim physical allocator or RSS measurements.

Four actual representatives sweep every observed reservation refusal, spend refusal, distinct cancellation prefix and issuer rotation at every spend/reserve. Expected accepted prefixes come from a separate successful actual callback sequence, never expected-output subtraction. Both old and newly rotated ledgers release all live bytes. Representatives include Root, physical Domain, Preserve and active binding.

Returned queries outlive the mutable admission borrow, retaining real leases until dropped. Empty final outputs may retain zero bytes. No fabricated positive empty charge is required.

Sealed true tests exercise 13 Domains times full/crop/empty, 39 calls. A callback observer asserts the first processing carrier's live bytes stay held through each fresh policy spend/reserve/merge. Its complete current snapshot, span pointer and work remain identical across finish. Dropping policy restores exactly first-carrier live bytes; dropping first releases all. Two recorded actual Stage fresh-span fallback calls run the same helper at frozen positive cap two. Old finish_policy compatibility is checked on all 13 Domains: same literal policy, unchanged first and no fresh admission callbacks.

A real nonempty Leaf-only Domain verifies same-issuer/same-I/L mixed modes both directions, foreign issuer, cloned Domain and range identity ordering with invalid fresh limits. These fail before fresh callbacks and release first without refunding previously accepted work. Fresh zero limits and allocation refusal separately keep first held throughout callbacks and release everything on error.

## Execution and proof limits

I ran scratch rustfmt and a successful patch --dry-run -p1 against initial snapshots plus the new file. No Cargo, Git, native checks or captures. Runtime results here are explicitly the parent's execution reports.

Parent reports seed 973 false, 411 sealed false, 99 true, exact-boundary/refusal, 39 sealed true and actual Stage fallback tests passed. Parent separately reports four new host tests and broader Audio suites passing: Main 412 / Scope 406. These are separate parent evidence, not this agent's execution.

Remaining qualifications:

- Parent's dense Domain negative correction needs its actual accepted-prefix, cleanup and final module result recorded. Frozen scratch still has the failed unconditional success assertion.
- Merge-triggered issuer rotation is not swept here; parent may extend the harness.
- Cap-length-forced fallback survey remains a bounded nonclaim. Two actual Stage fallback paths are proven, not a forced first-tape-length predicate.
- Dedicated density-proof and independent current-query survey objects are not all separately re-queried. Named ordinary/sealed rows are replayed, and successful dense bound Root supplies complete inventory above cap.
- Individual old/new allocation containers and overlaps are not independently enumerated here. Measured exact requested peak, one-short refusal, real cleanup and first-carrier callback floors are the evidence.
- True mode covers defaults plus representative failure sweeps, not every tight-limit row. False mode covers all 1613 named observations.
- No source/DSP/audio-device or host cache execution was performed by this agent.
- No arbitrary work-key stripping, zero-normalized failed accepted prefixes, cap increases or expected-derived fee offsets.
