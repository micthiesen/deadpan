# Policy admission tests candidate

Frozen scratch implementation for parent integration. Do not copy this source or apply this patch over the parent's integrated module: parent has already made compile corrections and is correcting the observed dense Domain resource refusal.

- policy_query_admission_tests.rs: new child of the existing wide_gain_query_admission_tests.rs harness.
- complete.patch: new module, unique parent declaration, and narrow test-only producer/serializer visibility changes.
- patches/: five parent/export changes separately.
- before/, source-pins.json, export-base-status.json: exact source authorities; initial export sources matched both actual roots.
- exports-after/: scratch expanded visibility sources only.
- report.md: assertions, coverage and execution limits.
- output-pins.json: final frozen implementation and report hashes.

No production source or expected fixture body was changed here. No Git, Cargo, native execution, captures, expected generation or freeze was performed by this agent. Scratch rustfmt parsed/formatted the new module; patch --dry-run accepted the complete patch against before/.

The parent's first compile found two Vec<Value> versus Value comparisons and an unused import. Parent corrected both comparisons to Value::Array(events) and removed the import in both actual roots. These integration corrections are deliberately not backported after the parent's freeze instruction.

Parent's Scope run reported 11 passing tests and one failing dense-success expectation. Diagnostic execution isolated dense/actual_256_repeat_bound/domain full range 0..256, spans 256, work 65536: OLD canonical work 22033 succeeds, while the admitted call reaches literal structural-work refusal. Parent owns splitting this into an explicit accepted-prefix/cleanup negative test. The admitted bound Root full call succeeds at the same cap with 512 contents, providing the positive inventory-greater-than-span-cap witness. Keep caps and frozen OLD values unchanged.
