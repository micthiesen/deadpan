# Child-budget and Point clone review

One material scratch finding, now addressed by parent in both actual roots: Point signal clone needed a post-merge issuer check. No further source-level finding in the reviewed child-work/local-lookup or first-carrier validation seams. Type checking, actual callback/lifetime sweeps and complete regression execution remain parent-owned.

No repository edits, Git, Cargo, native execution or capture by this reviewer. Reviewed the two scratch candidates, their pinned before sources, current integrated versions and existing Budget/GuardedBound/Owned helpers. Actual roots acquired the four child candidate files during this review; that is parent integration, not unexplained source drift.

## Point finding and correction

Scratch point_signal_clone_admitted checks payload/capacity before budget.merge_checked, then originally returned Owned immediately. merge_checked calls the admission merge callback and performs no postcheck. A same-policy merge can rotate its issuer, so the helper could return Ok with stale issuer after its final callback. The required correction is budget.check_memory(&memory)? immediately after merge while the complete value remains owned ahead of both guards.

Parent initially matched an identical tail in AudioStage construction. Independent actual-versus-combined-candidate comparison identified the misplaced check and still-missing Point check. Parent then corrected using the unique Point Structural-provider/gap anchor, restored the earlier Stage tail exactly and confirmed the intended Point check in both roots. The scratch Point candidate remains the original missing-check version; integrate the corrected actual helper rather than copying the old full scratch file. This review does not claim the original candidate already passed rotation tests.

Otherwise the metered Point clone preserves actual owning-field order: repeats Vec, definition, gap, with all preceding fields scalar/borrowed. repeats/definition/gap are its complete heap-bearing Structural fields. Local declarations ensure earlier partial values drop before capacity/payload on each fallible helper call; the completed value is declared after both memories, so it drops first on postcheck failure. No values move outside their guards. Source factory proof is concrete: new_admitted -> for_placed_definition_admitted installs Structural; set_evaluation changes only definition/repeats/bypass. The new provider check cannot reject that current raw Point path. False calls the literal original clone with no spend/reserve callback and does not replace it by a borrow. The helper remains within Plan.

## Child work and lookup

QueryCheckpoint captures remaining, canonical, additional and all lookup counters. usage_since checks current issuer, uses checked subtraction for each category/lookup field and verifies entry remaining minus exit remaining equals canonical delta plus additional delta. It does not spend, reserve, merge, reset, fold lookup or fabricate a forwarded receipt. Tokens are private within Plan; each actual assembler captures its own token at entry. No new public ledger escape is introduced.

Structural, flattened and Domain processing children require child maximum_work equal current remaining. Header copies remain after span assembly. Returned child work/lookup are local checked deltas, while the one parent budget already contains those operations. Hence no policy observed(child.work) or lookup fold should follow these metered children. Parent policy integration still owes that no-rebill assertion. Unchanged child structural/Core failure sites retain their labels. Low-level physical child functions explicitly require parent range validation; the supplied Domain wrappers preserve limit validation then signed support/range checks without constructing a second budget. Root policy uses the Structural adapter's original grid/range validation.

Public flattened and Domain processing constructors still start with zero counters, so local deltas equal old whole-query fields. Their public receipts seal only at the boundary. False ordinary policy has not been switched to a shared outer budget; its existing delayed observer accounting must remain literal. Root processing conversion and seal tails remain unchanged. No new allocation/Layout/canonical debit/cap/refund is introduced by these stack-only seams.

## Ownership and public compatibility

SignalBuffer, FlatBuffer and ProcessingBuffer all put actual query before its independent capacity; enclosing Owned/GuardedBound retains other Plan/Core lanes afterward. Flat child returns separate capacity ownership and public flattening merges it only while complete FlatBuffer is owned. Its try_map closure postchecks the merge before moving out query, and Owned's failure path retains payload until the value drops. Processing child keeps each WalkResult's independent memory through adopt_memory and existing guarded collection growth; conversion only renames the completed buffer wrapper through an allocation-free checked map. No Core value is detached.

The Signal module visibility hunk is small and must be combined with Point edits, not applied by replacing its whole candidate file. New buffer visibility is only crate::plan. Existing external public query types/borrowed views and non-Structural ordinary dispatch remain compatible. The current adapters do not claim arbitrary Source/Projected policy admission.

## First carrier validation

validate_for consumes and keeps the complete first carrier. It explicitly rejects was_forwarded != A::METERED, closing the real same-Issuer/Lease mixed-mode Leaf case where Plan Memory alone has no mode bit. It then validates embedded capacity and identity-maps the whole GuardedBound, which checks outer Plan memory plus any Core mode/issuer and post-map state. Canonical/additional/forwarded scalars remain unchanged. There is no work debit, reserve, generic detach or public extraction.

The new admitted sealed finish must perform pointer/range identity priority before this validation and keep the returned first carrier through policy construction/failure. Existing ordinary finish must not gain a new mode restriction. Parent's future policy integration and final result pair are outside this seam-only review.

## Pins and verification limits

All child before/ files match source-pins.json. All child candidate files and patches match candidate-pins.json. Reversing each Point patch in memory reproduces its exact pinned base, and both Point candidate after hashes match their manifest. Four integrated child files matched candidate bytes exactly at review time. Current Signal also contains the intended visibility hunk and parent's corrected Point postcheck; Domain integration is separately parent-owned.

Parent reports a child test reached all semantic assertions but corrected its guessed fixture count from 3/3 to actual two Root/four Domain. That is parent execution evidence; this review did not run it. Compilation, visibility/lifetimes, nonzero-prefix local category/lookup tests, empty child behavior, all actual rotation/refusal points, Source owning-edge capacities and final policy integration remain owed to the parent. No baseline is regenerated or canonical scalar normalized by these candidates.
