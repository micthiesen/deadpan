# Shared-budget guarded child seams

Production candidate in scratch only. No actual repository, Cargo, Git, native execution, capture or expected-body changes. Parent owns policy recursion, public policy carriers, Domain integration and host work; the Point clone worker has no overlapping candidate files.

## Files and integration

Four full candidate files are under `candidate/crates/deadpan-plan/src/`, each with original Main/Scope copies under `before/` and per-file diffs under `patches/{main,scoped}/`:

- `audio_owner_query_admission.rs`: read-only checkpoint/usage API.
- `audio_signal_processing_query.rs`: guarded Structural signal child entry and local usage fields.
- `audio_flattened_query.rs`: unsealed actual flattened query plus independent capacity, with public sealing outside the child.
- `audio_processing_query.rs`: unsealed physical-Domain processing fallback collector, sharing its actual walk with the public factory.

`audio_signal.rs.visibility.patch` widens only the existing `processing_query` child module to `pub(in crate::plan)`, so policy can name its narrow result types. Apply this tiny hunk rather than replacing the entire Signal file over the Point worker's edits. The complete patches contain the four owned-file diffs and that visibility hunk.

`domain-wrappers.rs.fragment` is a suggested parent-owned integration fragment, not an actual Domain edit. It supplies `AudioDomain::audio_child_query` and `AudioDomain::processing_child_query`, preserving the current `limits.validate()` and signed-range checks before invoking the low-level assemblers. It does not create a second Budget. The parent may factor those identical validators in its own file.

`source-pins.json` records current Main/Scope read pins. `candidate-pins.json` hashes the source, diffs, fragment and this handoff. No frozen fixture was copied or rewritten.

## Frozen internal API

All following names are restricted to `crate::plan`:

```rust
QueryBudget::checkpoint(&self) -> QueryCheckpoint
QueryCheckpoint::remaining(self) -> usize
QueryBudget::usage_since(&self, QueryCheckpoint) -> QueryResult<QueryUsage, A>

QueryUsage { work, canonical, additional, lookup }

AudioSignal::structural_child_query(
    &self,
    samples: Range<SignalSample>,
    limits: AudioQueryLimits,
    rule: AudioBoundaryRule,
    stops: (bool, bool), // Preserve, bindings
    budget: &mut QueryBudget<'_, A>,
) -> SignalResult<'plan, A>

audio::flattened_query::child_query(
    plan: &RenderPlan,
    seed: Option<&AudioWalkSeed>,
    samples: Range<AudioSample>,
    limits: AudioQueryLimits,
    budget: &mut QueryBudget<'_, A>,
) -> QueryResult<FlatValue<A>, A>

audio::processing_query::child_domain_query(
    plan: &'plan RenderPlan,
    seed: &AudioWalkSeed,
    samples: Range<AudioSample>,
    limits: AudioQueryLimits,
    stop_at_preserve: bool,
    budget: &mut QueryBudget<'_, A>,
) -> QueryResult<ProcessingChild<'plan, A>, A>

AdmittedAudioProcessingQuery::validate_for<A>(
    self,
    budget: &mut QueryBudget<'_, A>,
) -> QueryResult<Self, A>
// A::Issuer/Lease must equal this carrier's I/L.
```

`SignalValue<'plan,A>` is a `GuardedBound<SignalBuffer { query: AudioSignalQuery, capacity: Memory }, ...>`. `FlatValue<A>` is an `Owned<FlatBuffer { query: AudioQuery, capacity: Memory }, ...>`. `ProcessingChild<'plan,A>` is a `GuardedBound<ProcessingBuffer { query: AudioProcessingQuery, capacity: Memory }, ...>`. Each actual query precedes its capacity, and the enclosing carrier retains its other Plan/Core lanes. Fields are visible within Plan so whole guarded states can be borrowed or consumed through existing checked maps/zips. No unmetered extraction, new generic detach, Core API, external mutable query or public constructor was added.

The low-level flattened and Domain-processing functions require the caller's existing Root/Domain range validation. Their public factories already perform it; the Domain fragment does the same for policy. The Structural signal method performs the original `structural_grid` validation itself, then rejects providers other than Structural. Original ordinary provider dispatch remains unchanged.

## One budget, local child fields

A checkpoint contains entry remaining work, canonical/additional counters and all three lookup counters. Its fields are private and its operations are stack-only. `usage_since` checks the current issuer, subtracts every category with checked arithmetic and verifies:

```text
entry_remaining - current_remaining == canonical_delta + additional_delta
```

It never spends, reserves, merges, resets a counter, folds a lookup, or constructs a forwarded receipt. Invalid local provenance returns `InvalidPlan("audio child query work provenance mismatch")`; aggregate arithmetic overflow keeps the existing Time overflow conversion. Actual child quota failures still originate from their unchanged structural/Core sites.

Each child assembler captures its own checkpoint before any walk or header copy. It requires `limits.maximum_work == checkpoint.remaining()`, retains the existing `maximum_work - remaining == child.work` consistency label, and writes only local work and lookup deltas into the actual child query. Header clones remain after the complete span collection. A parent checkpoint may surround the child call for additional tracing, but no external start token or counter reset is needed.

Policy integration sequence:

1. Perform the original policy enter/depth and child-limits checks on the shared budget. Preserve the recursive-policy-work label and the remaining-zero check even for an empty child.
2. Build fresh child limits with the original maximum_spans and current `budget.remaining`.
3. Call the actual guarded child: Structural `(false,false)` for current policy, Structural `(false,true)` for independent binding policy, Domain flattened for current policy, or Domain processing with `stop_at_preserve=false` for the physical binding fallback. The last always retains `stop_at_bindings=true`.
4. Retain the complete returned guard while processing its actual spans. Its work/lookup already describe newly forwarded shared-budget activity. Do not invoke the old `observed(child.work, child.lookup)` fold, debit the child again, call a public admitted constructor, or absorb the child's fields into a fabricated Core receipt.
5. Seal only the final policy product from cumulative counters.

The public flattened constructor creates its usual fresh budget, calls the same unsealed assembler and seals the zero-start cumulative receipt. It merges the child's independent capacity back into the original public Owned query at the public boundary, with the complete query still owned before every check/merge/error. No new reserve or spend site was added.

The public Domain processing factory calls the same shared actual assembler with its original co-produced stop witness. It alone checks/seals cumulative counters, then uses one allocation-free checked map to retain the original private `ProcessingValue` carrier representation. No witness is reconstructed and no second walk is introduced. The unsealed child never creates a public carrier.

The new consuming `validate_for` helper first requires `self.was_forwarded() == A::METERED`, using the existing `InvalidPlan("processing accounting mode mismatch")` label. It then checks the embedded query-capacity memory and maps the entire GuardedBound through the existing checked identity operation. Canonical, additional and forwarded fields remain unchanged; no debit, reservation or detachment occurs. The complete carrier stays owned through every precheck/Core/postcheck failure. This is needed at the new sealed-finish boundary because two real public admission policy types can share Issuer/Lease types but differ in METERED; a Leaf/Plain first product has no Core mode guard to reject that combination. Parent must call it before fresh policy callbacks and keep existing ordinary finish behavior unchanged.

## Compatibility and guard review

The actual Root processing conversion tail, including `ordinary_conversion`, is byte-identical to the original. The Root collection `Converted`/`seal` tail is also byte-identical. Existing public false dispatch and Vec push/collect backends remain in place. The public ordinary Structural/flattened/Domain calls still begin with zero counters and a separate local child budget, so local delta fields equal their original whole-query fields. They do not share the outer ordinary PolicyWork budget or alter its real delayed second-return/accounted observer ordering.

The metered policy must keep a separate false compatibility branch as required by `review-policy-design.md`. Calling shared-budget children in the ordinary policy path would change the parent's actual balance at child return. This candidate does not modify policy, observers or false policy dispatch.

No child assembler detaches a Bound or Core lane. Processing retains each WalkResult's separate Plan memory through existing `adopt_memory`; collection growth, clipping, scalar conversions, stop flags and canonical lookup/weights remain literal. All new work/lookup reconciliation executes while complete query/header/accumulator carriers remain owned. The flattened public map retains the entire FlatBuffer through its capacity merge and post-check; it moves out the query only after that capacity has been transferred to the Owned payload guard. On callback refusal, issuer rotation, provenance refusal or unwind, values therefore precede the guards covering their contents and buffers.

The new buffer wrappers and checkpoint fields are stack state. No Layout, allocation, clone, canonical copy debit, cap, graph cache, history reduction, refund or DSP change is introduced by the seams.

## Checks and owed evidence

Scratch rustfmt parser/format checks passed for all four candidate sources and the Domain fragment. Both complete patches dry-run against their scratch before-copies. At patch generation the four actual owned sources still matched their read pins. Text checks verified that Root conversion and seal tails were byte-identical. No Rust type, borrow, Clippy or runtime claim is made.

Parent still owes type/lifetime/visibility checks with its Domain wrappers and policy callers; strict lint after wiring the new internal methods; all frozen ordinary regressions and current processing/flattened admission tests; actual nonzero-prefix child checkpoint tests with independent lookup deltas; empty-child headers/remaining-two policy behavior; error priority; accepted debit and no-rebill conservation; reservation/spend refusal and issuer-rotation sweeps; and memory lifetime/overlap evidence through the eventual policy recursion. The additional public Domain seal map should be covered by the existing mode/issuer refusal tests even though it adds no allocation or work callback. The new validation boundary needs actual same-mode/same-issuer success, foreign issuer and same-I/L mixed-mode Leaf refusal tests, checking cleanup and no fresh policy callback before refusal.

The parent reported the independently captured and reviewed complete OLD policy body frozen at 14,052,074 compact bytes, SHA256 `09c163d144af4532c5d815162b59a02c63fd82843c0ff0f34ea010ff4ba6e225`, before this production candidate. This candidate has not regenerated it. No new canonical values should be expected or normalized away.
