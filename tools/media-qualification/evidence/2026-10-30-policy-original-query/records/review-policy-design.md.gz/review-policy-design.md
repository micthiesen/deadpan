# Policy admission implementation design check

Recommend one shared QueryBudget for the metered policy construction closure, with read-only child checkpoints and internal unsealed guarded child assemblers. Keep a policy-specific canonical precheck at the old policy spend sites. Retain the literal existing ordinary/false backend, including its real child-return/accounting observer order, as detailed below. Do not invoke the public admitted child constructors and then debit their returned work again.

Read-only source/design review against policy-fade-admission-next.md. Navigation used ripwire with PolicyWork, signal_policy, domain_policy_inner, bound_policy, QueryBudget, GuardedBound and exact file names before targeted reads. No actual repo edits, Git, Cargo, native work, captures or fixtures. Parent owns production and other workers own dedicated fixtures.

## Concrete budget adapter

For metered policy, retain one ordinary backing Budget initialized with fresh policy maximum_work and zero LookupStats, and one QueryBudget over it. Policy state owns maximum_spans and its output containers; there is no second independent remaining-work scalar in this metered backend. New top-level generic entrypoints validate limits first, as PolicyWork::new does now, then initialize the shared budget. Do not eagerly validate the requested range before the original enter/child-limits path.

Use a narrow private policy_spend helper at exactly the current PolicyWork::spend sites:

    if units > budget.remaining {
        return Err(PlanError::AudioQueryLimit("recursive policy work").into());
    }
    budget.canonical(units)

This preserves the old checked subtraction's failure label and no-debit behavior. QueryBudget::canonical's local.spend otherwise reports structural work. Do not globally rename that label: child structural debits must still retain structural work, and admitted Core errors must retain their existing Document/Policy translation. enter checks depth > MAX_DOCUMENT_DEPTH before calling policy_spend(1), preserving policy depth before any enter debit. A child-limits helper rejects remaining == 0 with recursive policy work and otherwise returns the current remaining allowance plus the original maximum_spans. It must run even for empty child queries. Thus empty policy's canonical one can still require allowance two; unused allowance is not a debit.

At each child call record a stack-only checkpoint of remaining, canonical_used, additional_used and all three lookup counters. Child assembly directly mutates this same QueryBudget. On success compute its work and lookup fields from checked differences; assert start.remaining - end.remaining == canonical_delta + additional_delta. The child's maximum_work should equal start.remaining. These differences describe actual observed categories; they do not mutate counters or spend again.

Existing structural_query_admitted, flattened assemble and processing finish/seal use cumulative QueryBudget counters and assume a zero-start constructor. Merely exposing/calling them after policy enter is wrong: their provenance comparison or child returned work becomes cumulative. Factor a private unsealed assembler accepting the existing budget plus start checkpoint, returning the fully guarded real child product with local work/lookup. Public child constructors call it at a zero checkpoint and retain their existing public sealing behavior. Only the top policy result seals the policy-wide cumulative receipt. Do not reset counters, replace remaining allowance, construct nested public carriers, or add a fake work offset.

The shared child's walk already updates budget.lookup and forwards canonical/additional work immediately. Therefore remove the old observed(child.work, child.lookup) action for these metered shared-budget children: no spend(child.total), account_core on a Plan child, or second lookup fold. Keep local child fields for actual new metered provenance checks. Additional admission inspections must not be added to LookupStats, which describes the original structural lookups.

### Preserve the real false observer backend

The newly prepared OLD producer captures intermediate second_returned and second_accounted events, not just final policy. In the existing ordinary algorithm, the child owns a separate local query budget: parent PolicyWork.remaining really is unchanged at child return, then observed(child.work, child.lookup) changes the parent. A shared QueryBudget child would change that parent remaining during construction, even when A::METERED=false. Reusing the observer's old hard-coded before value as an alleged actual return balance would be false; rewinding counters to recreate it would be equally wrong.

Keep existing ordinary/false policy construction and its genuine child-local budgets/observed fold. An admitted false wrapper may wrap that literal ordinary result in a plain unmetered carrier with canonical=query.work, additional=0, forwarded=false and no spend/reserve callback, following the already used processing compatibility pattern. A shared control-flow backend can select these existing operations for false, but do not replace them with the metered shared-budget operations and claim intermediate accounting stayed identical. The metered path owns the one QueryBudget described here; its actual trace must reflect immediate forwarding and must not emit a fictional delayed debit. Keep the existing test observer unchanged on ordinary calls, and add separately named metered receipt evidence if needed. This is a real evidence/ordering seam to settle before implementation, not permission to normalize the OLD event fields away or introduce a second new accounting framework.

## Narrow child seams

- Root current and independent binding walks: expose a within-Plan Structural signal adapter taking samples, rule, both original stop flags, shared budget and checkpoint. Run structural_grid validation at the original child query entry. Root remains RoundEven; retained Point remains PointCeil. Return guarded SignalBuffer state with its input span capacity, headers and all Plan/Core lanes. Keep SignalBuffer private behind this adapter or a consuming map interface.
- Physical Domain current flattened walk: factor its validation and actual flattened assembler into a shared-budget internal entry. Preserve Domain's signed support checks after child limits. Return the real Owned<AudioQuery> and its Plan charge without sealing a new independently budgeted public carrier.
- Physical Domain binding fallback: expose the existing generic processing assembler with stop_at_preserve=false, stop_at_bindings=true and a local checkpoint. Return its unsealed GuardedBound product; keep private Stage/Bound history intact. Do not substitute first-tape flags or reconstruct the tape.
- Do not stream policy content while building the current child query. Old code completes the entire current query before processing its spans. Streaming would change canonical/error order and overlap.

No new broad Core API is needed. Existing GuardedBound::map/zip plus narrow typed actual-Leaf extraction are sufficient. The already committed flattened_leaf(memory,budget) accepts the walk's separate Memory; preserve that complete guard rather than assuming one lane. I initially inferred an in-session signature change from inconsistent snippets; parent checked initial authority/HEAD and confirmed the file unchanged. There is no evidence of an external writer, and that inference is withdrawn.

## Inventory and range ownership

Keep aggregate contents global across recursion and preserve encounter order. It is bounded by the shared work allowance, not maximum_spans. content still performs its canonical one before push. The Source/RoomTone/Reverse owning asset edge moves from the completed false/false current child query; its existing payload charge must move or remain conservatively retained with it. Do not clone/deduplicate assets or reserve only a shallow enum after detaching the old owner.

For current child products that are provably Legacy/Leaf under false/false Structural walking, a narrow internal typed extraction may move their actual Plan guard into an Owned current-query state. It must reject a retained Stage/Core variant before extraction, as existing flattened_leaf does. Avoid a generic GuardedBound-to-Owned escape. Binding query guards remain borrowed/live separately through recursion and do not need to be absorbed into final inventory merely to access a Source clone from an independently queried raw domain.

Use named ownership states for vectors, pending values, payload guards and replaceable capacities. With no Core lanes, Owned state can use existing QueryBudget::grow while payload and current value remain live. With a GuardedBound state, prepare a replacement Owned<Vec<_>> first, then zip/map the complete guarded state and pending value using the existing processing collection growth pattern. Each real old-element move's additional bill happens outside the infallible map; no allocation, fallible work or external unguarded move occurs inside it. Never call grow on a detached Vec whose Source payload or independent Core guard has already dropped.

Suppressed ranges have their own capacity guards. Preserve all old pushes/extensions and their canonical zero weight. add_outside still adds no canonical work. Endpoint checks retain retimes.len canonical only when enabled. Ordinary false backends keep existing Vec push/collect and allocation-free sort rather than forcing a new always-metered allocation path.

At the top result only, sort the completed suppressed input in place with no invented estimate/debit, build the separate merged Vec while input and contents remain owned, then prepare the labeled output Vec while merged input and contents remain live. Transfer/release capacities only after the corresponding actual values/buffers die. Scalar AudioSample/SignalSample labels have the existing allocation-free conversion contract; do not generalize an admitted public result over arbitrary heap-owning S. Final policy has no project/revision header. Empty final inventory/suppression can have zero retained bytes even if its empty temporary queries had a construction peak.

Crucially, do not sort/merge suppression recursively: signal_policy/domain_policy currently return unmerged local ranges, and bound_policy canonically bills/maps each returned retained range. Early recursive merging would change the number/order of those canonical bills even if the final union matched.

## Bound Root/Point lifetime

Hold the actual guarded independent binding query while borrowing each Bound and throughout raw-domain construction and recursion. raw_domain_admitted already returns an independently Owned Root/Point/Empty domain; use it with the same policy budget. Its old private 65,536 workspace is not canonical policy work. Current helpers use only admitted additional work for its actual copies, so false mode must remain canonical zero.

For Root, borrow the raw Root domain while its Owned guard remains on the recursive frame, then call the shared domain-policy path. For Point, preserve the actual domain.signal() clone: raw_domain_admitted constructed one embedded Structural signal, and signal() then clones its repeats, definition and gap before the recursive current/binding queries. Add a narrow admitted Structural signal-copy helper retaining the exact cloned fields/order under a separate Owned guard. Borrowing the embedded signal directly would remove a real owning copy and is not this unit's accounting change. Parent raw Point and Bound/Core guards remain live while that clone is built and queried.

Keep the child returned range Vec charged during Point reference-origin conversion, and keep that converted Vec during parent inverse mapping. bound_policy's enter, endpoint add_outside, clipped support/empty decisions and per-returned-range policy_spend(1) remain at their actual sites. The endpoint-enabled Empty/raw-empty branch really creates a range vector; endpoint-disabled empty creates none. Preserve exact floor/ceil, signed origin and reference-step operations rather than inferring masks from current delivery or zero PCM.

## Reachable factory scope

The closed Root entry uses RenderPlan::audio_signal(), a Structural provider. raw_domain_admitted's Point constructor uses for_placed_definition_admitted, which explicitly installs Structural; subsequent evaluation replacement changes selector/repeats/bypass, not provider. Raw Root recursively uses a physical Domain. These paths reach current Leaf and opaque Bound bodies plus retained Root/Point/Empty branches. No Source-voice, Silence voice, arbitrary Projected provider or RequiresOwnedInput provider must be admitted merely to implement this closure.

Shared public ordinary AudioSignal policy/after_preserve APIs still serve other providers, including Source's hold-carrier branch. Keep their existing ordinary implementation/compatibility path; do not remove that branch, add a new refusal to an actually reachable closed Bound/Stage case, or expose a new arbitrary-provider admitted API. No source contradiction to the contract's closed factory scope was found. The real roadblocks are private child product visibility, cumulative child seals, current-query ownership transfer and the actual Point signal clone, all solvable within Plan.

## Sealed first query and fresh policy

Add a separate admitted finish, leaving both existing ordinary finish APIs intact. Preserve exact Domain pointer/range identity refusal before policy construction or callbacks. Keep the whole first carrier owned across validation, reuse, fallback, all fresh-limit failures and any new policy allocation failure. Do not replace it or recompute ProcessingStops.

Start a fresh policy backing Budget/QueryBudget with counters zero; the first query's canonical/additional units remain outside policy's receipt, while its memory stays live in the same host admission aggregate. Before a new allocation/spend callback, validate retained Plan memory and every Core lane against the supplied admission. Existing checked zip with an empty same-issuer GuardedBound and identity map can validate while retaining all owning lanes; no Graph charge transfer or Core detachment is appropriate.

Mode needs an explicit decision/check at this public boundary. GuardedBound can be Legacy even for a metered no-Bound query and Memory carries issuer but not METERED; therefore zip-with-empty alone does not establish first-carrier mode for Leaf cases. Public custom policies can share Issuer/Lease types while differing METERED. If admitted finish requires the same mode, compare first.was_forwarded() to A::METERED alongside issuer checks before callbacks. Existing ordinary finish on an admitted first query is intentionally allowed and must not acquire this new restriction. Test a same-typed mixed-mode Leaf case, not only Core-backed mode rejection.

Reuse borrows exactly the sealed first spans only when the co-produced witness permits; the policy implementation independently requires first tape len <= fresh maximum_spans. Otherwise perform the actual false-preserve binding fallback. Never bill reused first work or fold its lookup into policy; opaque Bound recursion remains independent and newly billed. Return an admitted first carrier and admitted policy carrier as separate owned products. Failure consumes/drops the complete capability, preserving the actual accepted policy prefix in the external ledger and releasing all live leases; no partial tape or forged completed pair escapes.

## Evidence required by this design

Before production, finish the independent OLD dedicated fixtures already assigned: dense contents greater than positive span cap, reached tight fresh-span fallback, signed/fractional Point and Root, retained resume/reanchor/gap/history, endpoints/Holds/Preserve/shift-at-unity and chosen seams. False mode must compare every complete result/work/lookup/typed error and invoke no metered spend/reserve callbacks. Include empty returned-work-one/allowance-two, tiny work before invalid range, policy-depth-before-enter and child structural-error labels.

True mode must demonstrate one total/canonical/additional receipt from actual accepted callbacks, child local checkpoint invariants, no lookup or successful child rebill, every meaningful refusal/rotation, inventory and suppression/merged/labeled overlap, exact peak/one-short actual Layouts, and sealed prior-carrier lifetime through both outcomes. Preserve the separate host eviction receipt and prior product charges; a forwarded policy child is not justification to charge its work again in original_request. No sort estimate, cap increase, graph asset deduplication, raw-history optimization or fade closure is part of this design.

## Read pins

- crates/deadpan-plan/src/audio_policy.rs: 9e28f3dc9061e2fbe64911bb8288720fd7ba81f48b3215a583e4f1781dd9a7ed (19532 bytes)
- crates/deadpan-plan/src/audio_owner_query_admission.rs: 43b8dab2975e9313cba34ec5059b1fd55f28e22ccc0be53bc3d03774cb4a34c2 (19682 bytes)
- crates/deadpan-plan/src/audio_bound_query.rs: 01a5b56b65a373e422620d14371a222e33c0394310262c14887b45f29f66e040 (27179 bytes)
- crates/deadpan-plan/src/audio_flattened_query.rs: 51c5bcc733b3a5b14d245122459ece8ca487c613a396ddcd2cb1b62ba152d3cb (5734 bytes)
- crates/deadpan-plan/src/audio_signal_processing_query.rs: da2b9cf7e108beea86c7ec647b919585de503ef92d367d073917e2f0dc3c08eb (12302 bytes)
- crates/deadpan-plan/src/audio_processing_query.rs: f11d562f043df25b2ed097fdfba137f740a2e4256bdda4899b8f6b5e0f926c2e (9957 bytes)
- crates/deadpan-plan/src/audio_signal.rs: f75819365c54fc8a5ba9f02cb4b4713085ec6d0792304b79938d50b81423490f (41704 bytes)
- crates/deadpan-plan/src/audio_bound_probe.rs: 4a1cb5629c4934bf6c05dfc595af2f4bb5b16c1f2fe7bfb5777e67c098519555 (7975 bytes)
- crates/deadpan-plan/src/audio_point_domain.rs: 6213b39cd0452b39e95ba8df592a33bdbb9a2627e22a1a1df95efab0e5be83ab (14773 bytes)
- crates/deadpan-plan/src/audio_domain.rs: 05ff57f77357cc0f65da701d9b125db24c9ce39b95ab25f91c96db136b9fd1a4 (20101 bytes)
- crates/deadpan-plan/src/audio.rs: f831ad5c87a120034de7bb8fa9151ef100d47de2d2f825b9b847d47f478c6b9b (19152 bytes)
