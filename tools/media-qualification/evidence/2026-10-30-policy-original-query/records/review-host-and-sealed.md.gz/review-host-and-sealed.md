# Host and sealed Domain finish review

## Result

No material correctness issue found in the reviewed host candidate or the current sealed Domain finish / Point clone path.

## Checks

- `AdmittedAudioDomainProcessing::finish_policy_admitted` validates exact Domain pointer and sample range before entering the admitted policy walk. It validates the retained processing query against the active admission, derives binding reuse only from its sealed stops, and returns both guarded products in `AdmittedAudioDomainPolicy`. The closure and returned pair keep the processing carrier alive while policy admission runs and through the host read.
- Root and Domain host-candidate routes retain a separate policy carrier, and the request validates flattened, processing, then policy issuers on consumption. Each successful comparison is separately charged and traced. Domain test-only policy legacy selection leaves the first processing carrier and actual trace inputs available; the combined legacy Original helper chooses all three old constructors, while single-product toggles remain independent.
- The Point admitted clone preserves the unmetered literal clone path. In metered mode it checks the issuer, rejects an unexpected provider, clones the three heap-bearing fields through admission helpers, and validates/merges the repeat capacity lease. The Point tests compare against the actual clone, cover exact and one-byte-short residency, verify release, and rotate the issuer at each observed merge.

## Limits

- The host candidate remains uncompiled here: the plan crate had not yet integrated `audio_policy_admitted` / `AdmittedAudioPolicyQuery` at review time. No Cargo/tests were run by this review.
- This is a focused static review, not evidence that every cross-crate integration or admission failure path passes.
