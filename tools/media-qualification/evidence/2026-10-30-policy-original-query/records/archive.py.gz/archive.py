from pathlib import Path
import gzip,hashlib,json
s=Path(__file__).resolve().parent
repo=Path('/Users/michael/Code/deadpan')
dest=repo/'tools/media-qualification/evidence/2026-10-30-policy-original-query'
assert not (dest/'inventory.json').exists()
audit=json.loads((s/'final-audit.json').read_text())
assert audit['all_terminal']
prior=repo/'tools/media-qualification/evidence/2026-10-30-processing-original-query/inventory.json'
prior_sha='03f2bba48a50409b219e9052bf391c1c1e302266f57690720b2d7793a53393a3'
assert hashlib.sha256(prior.read_bytes()).hexdigest()==prior_sha
allowed={'.rs','.json','.py','.md','.patch','.stdout','.stderr','.txt','.sha256','.toml'}
rows=[]
for p in sorted(s.rglob('*')):
 if not p.is_file() or p.suffix not in allowed:continue
 rel=p.relative_to(s)
 if rel.parts[0]=='base-source' or rel.name in {'qualification-draft.md','published-evidence.json'}:continue
 data=p.read_bytes()
 if p.suffix=='.json':
  obj=json.loads(data)
  if isinstance(obj,dict) and 'command'in obj and 'started_at'in obj:
   assert 'exit_code'in obj and obj['sources_unchanged'] and obj['binaries_unchanged'],str(p)
 target=(dest/'records'/rel).with_name(rel.name+'.gz')
 target.parent.mkdir(parents=True,exist_ok=True)
 packed=gzip.compress(data,mtime=0)
 target.write_bytes(packed)
 rows.append({'path':str(target.relative_to(dest)),'bytes':len(packed),'sha256':hashlib.sha256(packed).hexdigest(),'expanded_bytes':len(data),'expanded_sha256':hashlib.sha256(data).hexdigest()})
manifest={
 'schema_version':1,'base_revision':(s/'base-revision.txt').read_text().strip(),
 'scope':'Actual Root/physical-Domain policy construction, guarded child checkpoints, retained Point ownership/offset conversion, sealed first-policy finish, third Original host carrier and actual work/eviction reconciliation. Fades, other containers and complete recursive preparation remain open. General sound-bearing Split stays disabled; no requirement or gate closes.',
 'prior_processing_inventory':{'path':'../2026-10-30-processing-original-query/inventory.json','sha256':prior_sha},
 'exclusions':'Executables, nontext archives and broad extracted base source excluded. Exact owned base/current/candidate source, all frozen/captured policy bodies, source/index/executable/stream pins, commands/environment/timing, failures and reviews retained. A bounded Main Rust overlay records inherited research for the separate Split result; it is not shipping feature source. The aborted unoptimized native attempt is retained as a failure, with no acceptance credit.',
 'files':rows,
}
p=dest/'inventory.json'
assert {str(x.relative_to(dest))for x in dest.rglob('*')if x.is_file()}=={r['path']for r in rows}
p.write_text(json.dumps(manifest,indent=2)+'\n')
for row in rows:
 packed=(dest/row['path']).read_bytes();plain=gzip.decompress(packed)
 assert len(packed)==row['bytes'] and hashlib.sha256(packed).hexdigest()==row['sha256']
 assert len(plain)==row['expanded_bytes'] and hashlib.sha256(plain).hexdigest()==row['expanded_sha256']
result={'files':len(rows),'stored_bytes':sum(r['bytes']for r in rows),'expanded_bytes':sum(r['expanded_bytes']for r in rows),'inventory_sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
(s/'published-evidence.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result))
