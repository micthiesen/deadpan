# OLD policy extension review

Latest Start/End extension and complete dual-capture check appears at the end. It closes the endpoint-specific fresh-limit matrix and final-combined-capture gaps identified in this original review; the cap-length-forced fallback coverage distinction remains explicit. No new material pre-freeze defect found.

No fixture/output fidelity defect found in the two integrated Scope extensions or parent matrix wiring. They add useful literal OLD observations. They prove reached Stage-caused fallback, not the separate fresh-cap-length-caused fallback branch. That remaining distinction is explicitly and correctly stated in the output.

Read-only review of policy_retained_cases.rs, policy_dense_fallback_cases.rs, policy_query_baseline.rs wiring, exact original dense/source-endpoint tests, checked visitors and ordinary policy/finish observer. No actual repo writes, Git, Cargo, native execution, capture, freeze or expected generation. Parent owns execution.

## Retained fixture fidelity

The 11 selected parents are actual checked Domains. Five come directly from the existing processing visitor by exact names, preserving its complete descriptors: default Repeat gap, hidden resumed capture, actual retained reference, fractional physical capture and split physical capture. Six come from the existing additional visitor, preserving the actual validated document and owner-input setup: exposed Preserve/SilentHold, Shift at unity/SilentHold, input inside Preserve, opaque Bound stage with Preserve/silence, cropped inherited edit retime and signed Partition with unrelated binding. No replacement Domain or replayed seed is fabricated.

The Source endpoint port preserves the original test's semantic construction: NTSC 30,000/1001 rate, 48,000-Hz source span, duration six, offset seven, lead duration five, initial crop [0,1), captured timing, actual Source End reanchor, final crop [2,3), document validation and plan compilation. It deliberately uses different project/asset/timing IDs and asset label from the original test; this is described as a checked port, not byte-identical fixture identity. Those full actual identifiers/document are serialized, so future owning-edge Layouts must use their literal values. No expected body from the original test is silently reused.

Root is the actual compiled plan. Domain is acquired through actual gain-owner lookup at sample 8008 and audio_owner_input, and complete setup_input/physical identity is retained. Hard-coded windows 8008..8264 and endpoint samples 8007/8008/9609/9610 match the chosen original NTSC scenario; every result still comes from the actual API. The producer does not clip an out-of-range request to manufacture a successful page.

edge_observations selects bounded start/end/midpoint anchors and adjacent pages, then calls the ordinary route separately for each. Sorting/deduplicating anchors changes only the finite request list, not query output. No page result is concatenated, unioned, resampled or used to reconstruct a whole observation. These calls extend evidence at chosen windows; they do not independently prove general paging equivalence or every fractional parity.

## Typed output and first-query retention

The parent Call/observation path continues to serialize complete suppressed ranges, every AudioContent payload, all three lookup counters, literal work and named typed errors. Actual Domain second-query events are kept separately. The retained extension uses routed call(parent, Route::Ordinary, ...) at all relevant sites; no wrong-arity ordinary_call use remains in the reviewed child.

The default retained calls and endpoint calls do not force success: a typed error remains an error record. Sealed fallback goes through existing sealed_call, which prepares a fresh default first query, records it completely and asserts its whole returned body unchanged on success. First query work/limits remain separate from policy work/fresh limits. No new normalization or expected subtraction was introduced in either child.

## Exact dense port and inventory proof

Independently compared the dense fixture construction prefix with tests/audio_policy.rs: from let node through the validated bound ProjectDocument, the bytes are exactly identical, including all IDs, duration one, 256 plays, capture timing and binding capture. Only the helper returns the two checked documents for additional actual calls. The explicit 256-span/65,536-work limits are the original integration test's limits, not raised production caps.

Descriptors embed both complete documents, the original test source, exact selected document and actual compilation/Domain-selection setup. The additional Domain is obtained from the actual root Node owner and captured owner input. It is not an invented standalone Domain.

density_proof calls both actual ordinary policies and actual bound processing. It requires a returned Bound, retained.contents.len() > maximum_spans, complete unchanged suppression versus unbound, literal full 0..256 suppression, and retained work greater than unbound while within the actual work limit. It serializes both complete policies plus full actual processing. The true inventory_exceeds_output_span_cap marker follows that assertion; it is not an assumed constant replacing the count. Other dense observations preserve full/crop/empty, 255 spans, actual returned work/one-short and original 16-work refusal outputs literally. A default/other trial failure is not rewritten into success.

## Reached fallback versus cap-length survey

The two reached cases reuse the exact exposed Preserve and Shift-at-unity Domain fixtures. They independently query current flattened policy input, require two current spans, use fresh positive cap two and observe a first processing tape with two spans containing a Stage. This co-produced Stage witness causes ordinary policy fallback. Both ordinary and sealed policies must succeed and compare completely. Exactly one actual depth-zero second-query return and one accounted event must be present, both Ok, with returned second walk span count equal to cap two. Thus this is actual reached fallback, not inference from absent events or contents shape alone.

At cap one, the independent current flattened query must itself fail span count, and sealed finish must retain that same literal typed error. Those rows do not claim the binding fallback walk was reached.

The six-case wider-first survey captures complete actual first tapes, then calls current audio independently at first_count-1. It asserts current span-count refusal, records the complete typed current/finish outputs and events, and explicitly states no cap-length-forced second walk was reached. That is a sound bounded finding about these checked fixtures. It is not proof that the cap-length fallback branch is globally unreachable, nor evidence that it was exercised. The old six-case sealed test also only compares outcomes, so it cannot close this branch by itself.

## Matrix wiring and coverage limits

The parent includes both child modules and calls both matrices under separate retained_policy_cases and dense_and_fallback_cases keys. The original 33 ordinary/13 sealed case lists and counts remain intact; new counts must be read from their own sections. The dense child produces five cases (three dense parents plus two reached Stage cases), a separate density proof and a separate six-case survey. New data is not substituted into an existing expected body.

Before claiming complete preproduction coverage, retain these bounded gaps explicitly:

- No first-tape-length-gate-forced fallback is demonstrated. Find a real checked parent where current query fits the smaller cap and eligibility permits reuse, or establish a source-backed invariant explaining why that branch cannot be reached by this closed factory corpus. Do not relabel Stage fallback or current-query refusal as that missing case.
- New endpoint parents currently have default/edge/page calls, not their own complete full/crop/empty exact-work/span/error-priority matrix. Existing generic 33-parent limit evidence covers shared mechanics but is not endpoint-specific boundary evidence.
- The 11 retained cases revisit actual history/resume/gap/retime fixtures, but feature presence and chosen full/midpoint calls do not prove every reanchor/history/Point/empty-support branch was encountered. Inspect actual captured returned contents/events before assigning numerical branch coverage.
- The dense Domain is observed ordinarily; it is not a dedicated dense sealed-finish lifetime/admission witness. Current additions remain ordinary output evidence, not callback/partial-work/issuer/Layout peak or host/DSP/source-I/O proof.
- Creative fades, arbitrary Signal/source-voice/Projected factories and retained-input fades remain outside this policy-only producer.

These limits do not invalidate the new observations; they prevent overstating what was measured.

## Supplied runtime context

Inspected parent's retained-old-policy-scoped-actual.json and body: exit_code zero, sources/binary unchanged. The captured retained section contains 11 Domain descriptors, two actual endpoint parent descriptors and eight exact endpoint seam rows. The actual seam results include Root at_crop_end returning AudioRangeOutOfRange while the Domain call succeeds, demonstrating why pages must remain literal rather than assuming symmetric support. This prior retained capture does not yet include dense_and_fallback_cases.

Also inspected parent's completed dense-old-policy-scoped-tests.json/stdout: exit_code zero, sources/binary unchanged, two tests passed (density matrix and reached fallback) in 1.17 seconds. I did not execute these tests or captures. A final combined Main/Scope manual capture and complete body comparison after both modules are integrated remain parent-owned; separate earlier artifacts are not silently treated as that final capture.

## Read pins

- crates/deadpan-plan/src/audio_owners/legacy_snapshot_v1/policy_retained_cases.rs: 0b7db4c2caf885788d0459a824dca3fd278b827acab96409ebb5630c38803141 (16996 bytes)
- crates/deadpan-plan/src/audio_owners/legacy_snapshot_v1/policy_dense_fallback_cases.rs: f18998939d2c748fc5381981fcf8c976d4cf6543a60cc3b84c1b3b40a12b5f5d (18203 bytes)
- crates/deadpan-plan/src/audio_owners/legacy_snapshot_v1/policy_query_baseline.rs: fda0a76ff2f242119f5b89e2d1c77dbc256567fef9fa9b3d41d997172afae03e (20770 bytes)
- crates/deadpan-plan/tests/audio_policy.rs: 979c23841d59d789e223e48b047fce6b3c6571645f841d6cf19f8937a9a4bc60 (2976 bytes)
- crates/deadpan-plan/tests/audio_bindings/source_endpoints.rs: 4071c8d0903f4339b361ad93b112995e7f1fe9a8af722108f635558c49b523b5 (5439 bytes)
- crates/deadpan-plan/src/audio_domain_policy_reuse_tests.rs: 93c40ac109206a158dd3e4edc0ad5003613508e688787faac5ddf05451802235 (15460 bytes)

## Start/End parameterization and final combined captures

Reviewed current policy_retained_cases.rs and the parent fresh_limit_observations helper again. source_endpoint_parent now takes the actual AudioSourceEndpoint enum and passes it directly to AudioReanchorStep::for_source_endpoint. The same checked initial document/capture/final crop is rebuilt and compiled separately for each variant. Start is explicitly labelled checked_fixture_variant_with_endpoint_changed with source_endpoint_reanchor_start names. End retains checked_port_of_source_endpoint_test and the original source_endpoint_reanchor names. No policy result is derived from the other variant.

Independently compared complete serialized Root fixture documents from the actual expanded capture: Start and End differ at exactly /audio_bindings/bindings/source/reanchors/0/anchor/endpoint, with literal start/end values. All other document fields and identities are equal. Compared End with the previous retained capture: its entire fixture_source array, observations array and all eight exact_endpoint_seams rows remain exactly equal. Therefore parameterization did not overwrite the original End inputs or outputs.

Each actual Start/End variant now contains fresh_limit_matrices.root and fresh_limit_matrices.domain. Each has 22 literal observations in the supplied capture: full/cropped/empty defaults, actual returned-work and one-short behavior, actual positive span boundaries/zero one-short, zero/above-maximum invalid limits and tiny positive work/spans. The same bounded helper makes real calls; it does not reuse a result or assume returned work equals required completing allowance. No work/lookup/output normalization was added. Outside/reversed/mixed-invalid-range priority remains covered by the original generic 33-parent matrix, not newly claimed as endpoint-specific rows.

Inspected expanded-old-policy-main.json and expanded-old-policy-scoped.json: both supplied runs report exit_code zero with unchanged source/binary. I did not execute them. Independently loaded both pretty body files (44,990,244 and 44,990,246 bytes), removed exactly the named provenance fields variant, source_sha256 and published_checkpoint, and compared the complete remaining values: equal. Checked every original seed top-level field against policy-seed-canonical-body.json: all unchanged; only retained_policy_cases and dense_and_fallback_cases are newly added top-level sections. This verifies the combined capture gap is closed without replacing the original seed evidence.

The supplied equality report describes compact JSON plus newline with no data normalization: 14,052,074 bytes, SHA-256 09c163d144af4532c5d815162b59a02c63fd82843c0ff0f34ea010ff4ba6e225. This review generated or froze no canonical/expected body. Capture provenance names published checkpoint 832cdf5eab6e0474d82d864823a4cbcaaca1ea51. The original policy source still has SHA 9e28f3dc9061e2fbe64911bb8288720fd7ba81f48b3215a583e4f1781dd9a7ed, matching the prior design review; no policy production change was part of this extension.

No new material issue blocks freezing these literal OLD observations. The cap-length-forced second-walk predicate remains a documented bounded nonclaim; the same ordinary fallback implementation is exercised and observed through the two real Stage witnesses. Do not change that label into predicate coverage after freezing. Remaining true-admission partial/issuer/Layout/lifetime/host obligations and later creative fades remain future work, rather than reasons to synthesize more OLD output or normalize a branch that was not reached.

Current read pins superseding the original retained-child pin: policy_retained_cases.rs 6a98c486e8690f50369e7948653b3c16180e317aea52977aec2046104faf302d (17,930 bytes). Parent policy_query_baseline.rs remains fda0a76ff2f242119f5b89e2d1c77dbc256567fef9fa9b3d41d997172afae03e; dense child remains f18998939d2c748fc5381981fcf8c976d4cf6543a60cc3b84c1b3b40a12b5f5d.
