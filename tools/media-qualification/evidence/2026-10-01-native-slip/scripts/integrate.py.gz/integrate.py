import hashlib
from pathlib import Path
import subprocess

repo = Path('/Users/michael/Code/deadpan')
root = Path(__file__).parent
assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=repo), 'Commit the backend checkpoint first'
patches = [
    ('project-service.patch', '8cb0f3c149f4e7a813d15554a0ff2ef937bdd5895641adac957c8c53e20e9798'),
    ('ui/ui.patch', 'f8703835707d16e2d5dd84f838111bb4a51162c891162118eae80dce50794949'),
    ('harness/harness.patch', '4d56edac59a1aafdbbdf3bb5cd23bc15f12ec091fd8f5a2d2a53d054ecc52de5'),
]
paths = []
for name, expected in patches:
    path = root / name
    assert hashlib.sha256(path.read_bytes()).hexdigest() == expected, name
    paths.append(str(path))
subprocess.run(['git', 'apply', '--check', *paths], cwd=repo, check=True)
subprocess.run(['git', 'apply', *paths], cwd=repo, check=True)
subprocess.run(['git', 'diff', '--check'], cwd=repo, check=True)
print('Applied the three reviewed native Slip patches.')
