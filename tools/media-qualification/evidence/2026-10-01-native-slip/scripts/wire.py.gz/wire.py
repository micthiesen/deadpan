from pathlib import Path
s=Path('/tmp/deadpan-native-slip-20261001/work/crates/deadpan-app/src')
def edit(path, pairs):
 p=s/path;v=p.read_text()
 for old,new,count in pairs:
  assert v.count(old)==count,(path,old,v.count(old),count)
  v=v.replace(old,new)
 p.write_text(v)
edit('project.rs',[
 ('pub mod slice;','pub mod slice;\npub mod slip;',1),
 ('    pub splice_commit: Option<splice::SpliceCommitUpdate>,','    pub splice_commit: Option<splice::SpliceCommitUpdate>,\n    /// Qualified Slip proposals retain exact target and draft/change identity.\n    pub slip: Option<slip::ProposalUpdate>,\n    pub slip_commit: Option<slip::CommitUpdate>,\n    /// Last saved Slip in this session, independent of later failed requests.\n    pub saved_slip: Option<slip::CommitReceipt>,',1),
 ('    AbandonSplice(splice::ProposalId),','    AbandonSplice(splice::ProposalId),\n    PrepareSlip(slip::Proposal),\n    CommitSlip(slip::ProposalId),\n    AbandonSlip(slip::ProposalId),',1),
 ('    splice_commit_refresh_failure: AtomicBool,','    splice_commit_refresh_failure: AtomicBool,\n    #[cfg(test)]\n    slip_commit_refresh_failure: AtomicBool,',1),
 ('            splice_commit_refresh_failure: AtomicBool::new(false),','            splice_commit_refresh_failure: AtomicBool::new(false),\n            #[cfg(test)]\n            slip_commit_refresh_failure: AtomicBool::new(false),',1),
])
edit('project/service.rs',[
 ('mod splice;','mod splice;\nmod slip;',1),
 ('    splice_seen: Option<super::splice::ProposalId>,','    splice_seen: Option<super::splice::ProposalId>,\n    slip: Option<super::slip::ProposalUpdate>,\n    slip_commit: Option<super::slip::CommitUpdate>,\n    saved_slip: Option<super::slip::CommitReceipt>,\n    slip_draft: Option<slip::Draft>,\n    slip_seen: Option<super::slip::ProposalId>,',1),
 ('        splice_seen: None,','        splice_seen: None,\n        slip: None,\n        slip_commit: None,\n        saved_slip: None,\n        slip_draft: None,\n        slip_seen: None,',1),
 ('                service.invalidate_changed_splice();','                service.invalidate_changed_splice();\n                service.reconcile_slip();',2),
 ('            splice_commit: self.splice_commit.clone(),','            splice_commit: self.splice_commit.clone(),\n            slip: self.slip.clone(),\n            slip_commit: self.slip_commit.clone(),\n            saved_slip: self.saved_slip.clone(),',1),
 ('            ProjectRequest::PrepareSplice(proposal) => {','            ProjectRequest::PrepareSlip(proposal) => {\n                self.prepare_slip_command(proposal);\n                return Ok(());\n            }\n            ProjectRequest::CommitSlip(id) => {\n                self.commit_slip_command(id);\n                return Ok(());\n            }\n            ProjectRequest::AbandonSlip(id) => {\n                self.abandon_slip(&id);\n                return Ok(());\n            }\n            ProjectRequest::PrepareSplice(proposal) => {',1),
 ('            ProjectRequest::PrepareGain(proposal) => {','            ProjectRequest::PrepareSlip(_)\n            | ProjectRequest::CommitSlip(_)\n            | ProjectRequest::AbandonSlip(_) => unreachable!("Slip uses independent feedback"),\n            ProjectRequest::PrepareGain(proposal) => {',1),
 ('        self.invalidate_changed_splice();\n        Ok(())','        self.invalidate_changed_splice();\n        self.reconcile_slip();\n        Ok(())',1),
 ('        self.invalidate_splice("Slice proposal was cancelled");','        self.invalidate_splice("Slice proposal was cancelled");\n        self.invalidate_slip("Slip proposal was cancelled.");',1),
])
edit('project/tests.rs',[
 ('mod splice;','mod splice;\nmod slip;',1),
 ('        splice_commit_refresh_failure: AtomicBool::new(false),','        splice_commit_refresh_failure: AtomicBool::new(false),\n        slip_commit_refresh_failure: AtomicBool::new(false),',2),
])
