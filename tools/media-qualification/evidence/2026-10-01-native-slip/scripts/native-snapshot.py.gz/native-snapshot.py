import json
from pathlib import Path
import sqlite3
import sys

root = Path(__file__).parent / 'native'
label = sys.argv[1]
project = root / 'Slip QA.deadpan' / 'project.sqlite'
destination = root / (label + '.sqlite')
assert not destination.exists()
with sqlite3.connect('file:' + str(project) + '?mode=ro', uri=True) as source:
    with sqlite3.connect(destination) as backup:
        source.backup(backup)
with sqlite3.connect(destination) as database:
    document = json.loads(database.execute('SELECT r.document FROM revisions r JOIN state s ON r.id=s.head_revision').fetchone()[0])
    tables = [row[0] for row in database.execute("SELECT name FROM sqlite_master WHERE type='table' ORDER BY name")]
    summary = {
        'label': label,
        'revisions': database.execute('SELECT count(*) FROM revisions').fetchone()[0],
        'history': database.execute('SELECT count(*) FROM history').fetchone()[0],
        'revision': document['revision_id'],
        'tables': tables,
    }
    (root / (label + '-document.json')).write_text(json.dumps(document, indent=2) + '\n')
    (root / (label + '-summary.json')).write_text(json.dumps(summary, indent=2) + '\n')
    print(json.dumps(summary, indent=2))
