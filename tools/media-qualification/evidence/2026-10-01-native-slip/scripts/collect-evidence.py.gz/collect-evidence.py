#!/usr/bin/env python3
"""Seal complete native Slip evidence. Draft only; root owns execution.

Run from the repository after every required process has exited. Missing,
unfinished, drifted or unresolved failed evidence aborts before repository writes.
All discovered attempts are retained, including explicitly superseded failures.
"""
from __future__ import annotations

import argparse
from contextlib import closing
import datetime as dt
import difflib
import gzip
import hashlib
import json
from pathlib import Path
import re
import sqlite3
import subprocess
import sys

BASE_COMMIT = "8c282ac8a3147e784b212852540b5e44e28382b1"
FINAL = "44ed42b615d9adebf9da17a5bc7419d688ec2df0c9fe9ca73ed9917ef7ddff36"
UNIT = "9d93fbf93dc03951747ea1b2c300f06af54f5cfb470f60bca987259f78bf78b4"
BACKEND = "1fc905d263ff3f486524d866d696a22aab0fc63e401b7ed55f26426fa3bee87b"
KESTREL = "368c01df72ae4fab2efa4d38b235b56c02251f8b895f7e6402c77f6a151723c2"
SLIP_SOURCE = "crates/deadpan-app/src/preview/slip.rs"
REQUIRED_CHECKS = {
    "focused-slip": UNIT,
    "app-ui-tests": UNIT,
    "app-default-tests": UNIT,
    "formatting-final": FINAL,
    "strict-clippy": FINAL,
    "debug-build-final": FINAL,
    "visual-slip-first": UNIT,
    "visual-slip-final": FINAL,
    "release-build-final": FINAL,
    "performance-final": FINAL,
    "bundle-native": FINAL,
    "native-run-first": FINAL,
    "native-run-reopened": FINAL,
}
REQUIRED_REPLAYS = {"visual-first": "visual-slip-first",
                    "visual-final": "visual-slip-final",
                    "performance-final": "performance-final"}
NATIVE_LABELS = ("before", "cancelled", "committed", "undone", "redone", "reopened")
CAPTURES = {
    "Slip proposed +5f with actual composed Original frame 18": "proposed",
    "Slip Before comparison at the identical Edit frame": "before",
    "Slip handle clamp at compact size": "compact-clamp",
    "Saved Slip at the unchanged editor cursor": "committed",
    "Nested Partition Slip with retained Source and live ancestor camera paths": "nested-partition",
}
TEST_LINE = re.compile(r"test result: (ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out;")
HEX = re.compile(r"[0-9a-f]{64}\Z")


def sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def wire(value) -> bytes:
    return (json.dumps(value, indent=2, sort_keys=True) + "\n").encode()


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--repo", type=Path, default=Path.cwd())
    parser.add_argument("--scratch", type=Path, default=Path(__file__).resolve().parent)
    parser.add_argument("--output", type=Path, help="Defaults to the repository's native Slip evidence directory")
    args = parser.parse_args()
    repo, scratch = args.repo.resolve(), args.scratch.resolve()
    output = (args.output or repo / "tools/media-qualification/evidence/2026-10-01-native-slip").resolve()
    errors: list[str] = []
    payloads: dict[str, bytes] = {}
    inputs: dict[str, str] = {}
    checks, replays, manifests = {}, {}, {}
    attempts, image_index = {}, []

    def need(condition, message):
        if not condition:
            errors.append(message)
        return condition

    def read(path: Path, required=True):
        if not path.is_file():
            if required:
                errors.append(f"Missing required file: {path}")
            return None
        if path.is_symlink():
            errors.append(f"Refusing symlink input: {path}")
            return None
        data = path.read_bytes()
        digest = sha(data)
        previous = inputs.setdefault(str(path), digest)
        need(previous == digest, f"Input changed between reads: {path}")
        return data

    def load(path: Path, required=True):
        data = read(path, required)
        if data is None:
            return None
        try:
            return json.loads(data)
        except (ValueError, UnicodeError) as error:
            errors.append(f"Invalid JSON {path}: {error}")
            return None

    def add(name, data, compress=False):
        if data is None:
            return
        rel = Path(name)
        if rel.is_absolute() or ".." in rel.parts:
            raise ValueError(f"Unsafe retained path: {name}")
        if compress:
            name += ".gz"
            data = gzip.compress(data, mtime=0)
        if name in payloads and payloads[name] != data:
            raise ValueError(f"Conflicting retained path: {name}")
        payloads[name] = data

    def copy(path, name, compress=False, required=True):
        add(name, read(path, required), compress)

    def parse_time(value):
        try:
            return dt.datetime.fromisoformat(value.replace("Z", "+00:00")).timestamp()
        except (AttributeError, ValueError, TypeError):
            return None

    def source_manifest(path, expected):
        data = read(path)
        if data is None:
            return None
        need(sha(data) == expected, f"Source manifest content hash differs from {expected}: {path}")
        try:
            value = json.loads(data)
        except (ValueError, UnicodeError) as error:
            errors.append(f"Invalid source manifest {path}: {error}")
            return None
        if not need(isinstance(value, dict) and bool(value), f"Empty or invalid manifest: {path}"):
            return None
        for name, digest in value.items():
            need(isinstance(name, str) and not Path(name).is_absolute() and ".." not in Path(name).parts,
                 f"Unsafe manifest path: {name!r}")
            need(isinstance(digest, str) and HEX.fullmatch(digest) is not None,
                 f"Invalid source digest: {name!r}")
        return value

    # Read every journal and log, including failures and unknown future attempts.
    check_dir = scratch / "checks"
    need(check_dir.is_dir(), f"Missing checks directory: {check_dir}")
    initial_check_files = {p.name for p in check_dir.iterdir() if p.is_file()} if check_dir.is_dir() else set()
    for path in sorted(check_dir.glob("source-*.json")):
        expected = path.stem.removeprefix("source-")
        manifest = source_manifest(path, expected)
        if manifest is not None:
            manifests[expected] = manifest
        copy(path, "checks/" + path.name, True)
    for path in sorted(check_dir.glob("*.json")):
        if path.name.startswith("source-"):
            continue
        report = load(path)
        copy(path, "checks/" + path.name)
        if not isinstance(report, dict) or "command" not in report:
            continue
        name = path.stem
        checks[name] = report
        complete = (type(report.get("exit_code")) is int and
                    isinstance(report.get("seconds"), (int, float)) and report["seconds"] >= 0)
        need(complete, f"Unfinished command journal: {name}")
        need(isinstance(report.get("command"), list) and bool(report["command"]), f"Missing command: {name}")
        need(report.get("source_manifest_sha256") in manifests, f"Missing named source manifest: {name}")
        started = parse_time(report.get("started"))
        need(started is not None, f"Missing/invalid command start time: {name}")
        data = read(path.with_suffix(".log"))
        suites = []
        if data is not None:
            group, executable = "unit_integration", None
            for line in data.decode(errors="replace").splitlines():
                stripped = line.lstrip()
                if stripped.startswith("Doc-tests "):
                    group, executable = "documentation", stripped
                elif stripped.startswith("Running "):
                    group, executable = "unit_integration", stripped
                match = TEST_LINE.search(line)
                if match:
                    status, *numbers = match.groups()
                    suites.append(dict(group=group, executable=executable, status=status,
                                       **dict(zip(("passed", "failed", "ignored", "measured", "filtered_out"), map(int, numbers)))))
        report["test_suites"] = suites
        report["tests"] = {group: {key: sum(s[key] for s in suites if s["group"] == group)
                                  for key in ("passed", "failed", "ignored", "measured", "filtered_out")}
                           for group in ("unit_integration", "documentation")}
        is_test = "cargo" in report.get("command", []) and "test" in report.get("command", [])
        failed_tests = any(s["status"] != "ok" or s["failed"] for s in suites)
        if complete and report["exit_code"] == 0 and is_test:
            need(bool(suites), f"Test exit 0 without test-result lines: {name}")
            need(not failed_tests, f"Test journal exit 0 contradicts result lines: {name}")
        attempts["checks/" + name] = {"passed": complete and report.get("exit_code") == 0 and not failed_tests,
                                      "started": started, "kind": "check"}
    for path in sorted(check_dir.glob("*.log")):
        copy(path, "checks/" + path.name, True)
        need(path.with_suffix(".json").exists(), f"Log has no command journal: {path.name}")
    for name, expected in REQUIRED_CHECKS.items():
        report = checks.get(name)
        if need(report is not None, f"Required command journal missing: {name}"):
            need(attempts["checks/" + name]["passed"], f"Required command did not pass: {name}")
            need(report.get("source_manifest_sha256") == expected, f"Wrong source manifest for required command: {name}")
            need(report.get("base_commit") == BASE_COMMIT, f"Wrong backend base for required command: {name}")
    for name in ("app-ui-tests", "app-default-tests", "focused-slip"):
        report = checks.get(name)
        if report:
            need(report["tests"]["unit_integration"]["passed"] > 0, f"No executed tests in {name}")
            need(all(s["ignored"] == 0 for s in report["test_suites"]), f"Ignored test in required run: {name}")
    # Counts are derived above, not filled in from expected passing counts.
    add("checks/summary.json", wire(checks))

    # Verify current files AND the inventory, catching newly added source files.
    current, unit = manifests.get(FINAL), manifests.get(UNIT)
    need(current is not None, "Final manifest is missing")
    need(unit is not None, "Unit/default manifest is missing")
    source_proof = {"final_manifest": FINAL, "unit_manifest": UNIT, "backend_manifest": BACKEND}
    if current is not None:
        listed = subprocess.check_output(["git", "-c", "core.fsmonitor=false", "ls-files", "--cached", "--others", "--exclude-standard", "-z"], cwd=repo).decode().split("\0")
        eligible = {name for name in listed if name and (repo/name).is_file() and
                    (Path(name).suffix in (".rs", ".toml", ".lock", ".cpp", ".h", ".hpp", ".c", ".m", ".py")
                     or name.startswith((".cargo/", "crates/", "native/")))}
        need(eligible == set(current), "Source inventory drift: " + repr(sorted(eligible ^ set(current))))
        drift = []
        for name, digest in current.items():
            data = read(repo/name)
            if data is None or sha(data) != digest:
                drift.append(name)
        need(not drift, "Final source content drift: " + repr(drift))
        source_proof["source_files_rechecked"] = len(current)
    if current is not None and unit is not None:
        changed = [name for name in sorted(current.keys() | unit.keys()) if current.get(name) != unit.get(name)]
        need(changed == [SLIP_SOURCE], "Unexpected unit-to-final source differences: " + repr(changed))
        data = read(repo/SLIP_SOURCE)
        if data is not None:
            text = data.decode()
            prior = text
            translations = [("Previous picture · Left", "Previous picture · ←"),
                            ("Next picture · Right", "Next picture · →")]
            for new, old in translations:
                need(prior.count('"' + new + '"') == 1 and ('"' + old + '"') not in prior,
                     "Expected exactly one final label and no old label: " + new)
                prior = prior.replace('"' + new + '"', '"' + old + '"')
            need(sha(prior.encode()) == unit.get(SLIP_SOURCE), "Reversing exactly two label strings does not reproduce tested source")
            add("sources/slip-unit.rs", prior.encode(), True)
            add("sources/slip-final.rs", data, True)
            add("sources/labels-only.diff", "".join(difflib.unified_diff(prior.splitlines(True), text.splitlines(True),
                fromfile="unit/"+SLIP_SOURCE, tofile="final/"+SLIP_SOURCE)).encode())
            source_proof["unit_to_final"] = {"changed_files": changed, "allowed_label_replacements": translations,
                                             "reconstructed_unit_sha256": sha(prior.encode())}
    backend_path = repo / f"tools/media-qualification/evidence/2026-10-01-source-slip/source-{BACKEND}.json"
    backend = source_manifest(backend_path, BACKEND)
    copy(backend_path, "sources/backend-manifest.json", True)
    if current is not None and backend is not None:
        def backend_file(name):
            return (name.startswith(("crates/", "native/")) and not name.startswith("crates/deadpan-app/")) or name.startswith(".cargo/") or name in {"Cargo.lock", "Cargo.toml", "rust-toolchain.toml"}
        drift = [name for name in sorted(current.keys() | backend.keys()) if backend_file(name) and current.get(name) != backend.get(name)]
        need(not drift, "Backend/build configuration changed since checkpoint: " + repr(drift))
        source_proof["backend_and_build_changes"] = drift
        source_proof["backend_checkpoint"] = BASE_COMMIT
    add("source-proof.json", wire(source_proof))

    # Every top-level visual/performance attempt is retained. An unfinished
    # directory cannot disappear simply because it has no report yet.
    directories = {p for p in scratch.iterdir() if p.is_dir() and
                   (p.name.startswith(("visual-", "performance-")) or (p/"report.json").is_file())}
    directories.update(scratch/name for name in REQUIRED_REPLAYS)
    for directory in sorted(directories):
        report_path = directory / "report.json"
        report = load(report_path)
        if not isinstance(report, dict):
            continue
        copy(report_path, "replays/" + directory.name + ".json", True)
        copy(directory/"report.html", "replays/" + directory.name + ".html", True, required=False)
        scenarios = report.get("scenarios")
        if not need(isinstance(scenarios, list) and bool(scenarios), f"Empty replay report: {directory.name}"):
            continue
        need(type(report.get("failed")) is bool, f"Unfinished replay report: {directory.name}")
        failed = report.get("failed") is not False
        summary = {"failed": report.get("failed"), "mode": report.get("mode"), "metadata": report.get("metadata"), "scenarios": []}
        for scenario in scenarios:
            checks_in_scenario = scenario.get("checks", [])
            check_failures = [c.get("name") for c in checks_in_scenario if c.get("passed") is not True]
            failed = failed or scenario.get("failed") is not False or bool(check_failures)
            summary["scenarios"].append({"name": scenario.get("name"), "checks": len(checks_in_scenario),
                "failed": scenario.get("failed"), "failed_checks": check_failures,
                "findings": scenario.get("findings", []), "skipped": scenario.get("skipped", []),
                "timings": [{"name": t.get("name"), "summary": t.get("summary")} for t in scenario.get("timings", [])]})
            # Keep every failed-check run's available captures, not only the
            # last frame, so a failure earlier than teardown remains inspectable.
            if scenario.get("failed") or check_failures:
                for step in scenario.get("steps", []):
                    if step.get("screenshot"):
                        retain_image(directory, step, "failures/" + directory.name + "/" + scenario["name"], copy, image_index, need)
        summary["check_count"] = sum(s["checks"] for s in summary["scenarios"])
        summary["passed"] = not failed
        replays[directory.name] = summary
        started = report.get("metadata", {}).get("started_unix_ms")
        attempts["replays/" + directory.name] = {"passed": not failed,
            "started": started/1000 if isinstance(started, (int, float)) else None, "kind": "replay"}
        if directory.name in REQUIRED_REPLAYS:
            need(not failed, f"Required replay failed: {directory.name}")
            journal = checks.get(REQUIRED_REPLAYS[directory.name])
            if journal:
                command = journal.get("command", [])
                output_index = command.index("--output") + 1 if "--output" in command else len(command)
                recorded_output = Path(command[output_index]) if output_index < len(command) else None
                if recorded_output is not None and not recorded_output.is_absolute():
                    recorded_output = repo/recorded_output
                need(recorded_output is not None and recorded_output.resolve() == directory.resolve(),
                     f"Replay journal does not name retained directory: {directory.name}")
            audits = [s for s in scenarios if s.get("name") == "kestrel-shortcuts"]
            need(len(audits) == 1, f"Missing/ambiguous Kestrel audit: {directory.name}")
            if len(audits) == 1:
                audit_checks = audits[0].get("checks", [])
                need(len(audit_checks) == 1, f"Unexpected Kestrel checks: {directory.name}")
                if len(audit_checks) == 1:
                    actual = audit_checks[0].get("actual", {})
                    need(audit_checks[0].get("passed") is True and actual.get("reserved_bindings") == 62
                         and actual.get("routing_cases") == 17360 and actual.get("conflicts") == []
                         and actual.get("source_sha256") == KESTREL and actual.get("live_source_sha256") == KESTREL,
                         f"Kestrel live-source or routing mismatch: {directory.name}")
                    summary["kestrel"] = actual
            if directory.name == "performance-final":
                need(report.get("mode") == "performance" and report.get("metadata", {}).get("build_profile") == "release",
                     "Final performance must execute the release build in performance mode")
                harness_source = read(repo/"crates/deadpan-app/src/ui_harness.rs")
                if harness_source is not None:
                    declaration = re.search(r"const SCENARIOS:.*?= &\[(.*?)\];", harness_source.decode(), re.S)
                    need(declaration is not None, "Cannot resolve the current full replay scenario list")
                    if declaration:
                        expected_names = set(re.findall(r'"([^"\n]+)"', declaration.group(1))) | {"kestrel-shortcuts"}
                        actual_names = [s.get("name") for s in scenarios]
                        need(set(actual_names) == expected_names and len(actual_names) == len(expected_names),
                             "Final performance does not include exactly the current full scenario set")
                binary = read(repo/"target/release/deadpan-app")
                if binary is not None:
                    need(sha(binary) == report.get("metadata", {}).get("binary_sha256"),
                         "Release executable changed since final performance")
                need(bool([t for s in scenarios for t in s.get("timings", [])]), "Final performance report has no timings")
                add("performance-summary.json", wire(summary), True)
            elif directory.name == "visual-final":
                for label, stem in CAPTURES.items():
                    steps = [step for s in scenarios for step in s.get("steps", []) if step.get("input") == label and step.get("screenshot")]
                    need(len(steps) == 1, f"Missing/ambiguous final named capture: {label}")
                    if len(steps) == 1:
                        step = steps[0]
                        retain_image(directory, step, "images/" + stem, copy, image_index, need, exact_name=True)
                        if stem == "compact-clamp":
                            semantic = step.get("semantic", {})
                            need(step["screenshot"] == "slip-059.png" and semantic.get("viewport_points") == [960, 640]
                                 and semantic.get("layout_passes") == 1 and semantic.get("slip", {}).get("apply_ready") is True,
                                 "Compact final capture lost expected frame/raster/readiness evidence")
            elif directory.name == "visual-first":
                label = next(iter(CAPTURES))
                steps = [step for s in scenarios for step in s.get("steps", []) if step.get("input") == label and step.get("screenshot")]
                need(len(steps) == 1, "Missing first-run missing-arrow-glyph example")
                if len(steps) == 1:
                    retain_image(directory, steps[0], "images/first-missing-arrow-glyph", copy, image_index, need, exact_name=True)
    add("replay-summary.json", wire(replays), True)
    add("images/index.json", wire(image_index), True)

    # Future failures require a recorded successful successor and reason. This
    # never removes a run from retention or counts it as a pass.
    resolutions_path = scratch/"failure-resolutions.json"
    resolutions = load(resolutions_path, required=False) or {}
    if resolutions_path.exists():
        copy(resolutions_path, "failure-resolutions.json")
    for name, attempt in attempts.items():
        if attempt["passed"]:
            continue
        resolution = resolutions.get(name, {}) if isinstance(resolutions, dict) else {}
        successor = attempts.get(resolution.get("superseded_by"))
        need(isinstance(resolution.get("reason"), str) and bool(resolution["reason"].strip())
             and successor is not None and successor["passed"] and successor["kind"] == attempt["kind"]
             and attempt["started"] is not None and successor["started"] is not None
             and successor["started"] > attempt["started"],
             f"Unresolved failed attempt: {name}; record a later passing successor and reason in failure-resolutions.json")

    # Read consistent backup snapshots, never the live package's main SQLite.
    native = scratch/"native"
    fixture = load(native/"fixture.json")
    verification = load(native/"verification.json")
    cleanup = load(native/"cleanup.json")
    observations = read(native/"observations.md")
    need(isinstance(verification, dict) and verification.get("passed") is True, "Native verification is not explicitly passed")
    need(observations is not None and bool(observations.strip()), "Native observations are missing or empty")
    if isinstance(cleanup, dict):
        need(cleanup.get("writer_lock_released") is True, "Native writer lock not confirmed released")
        need(cleanup.get("deadpan_app_processes") == [], "Native app processes remain or cleanup inventory is missing")
        exits = cleanup.get("native_exit_codes")
        need(isinstance(exits, list) and len(exits) >= 2 and all(type(x) is int and x == 0 for x in exits), "Native launch/reopen exit codes are missing or nonzero")
    native_summary = {}
    for label in NATIVE_LABELS:
        database, summary_path, document_path = native/(label+".sqlite"), native/(label+"-summary.json"), native/(label+"-document.json")
        summary, document = load(summary_path), load(document_path)
        data = read(database)
        need(not Path(str(database)+"-wal").exists() and not Path(str(database)+"-shm").exists(), f"Snapshot is not standalone: {label}")
        if data is None or not isinstance(summary, dict) or not isinstance(document, dict):
            continue
        try:
            with closing(sqlite3.connect(database.as_uri()+"?mode=ro&immutable=1", uri=True)) as connection:
                need(connection.execute("PRAGMA integrity_check").fetchall() == [("ok",)], f"Invalid SQLite snapshot: {label}")
                tables = [row[0] for row in connection.execute("SELECT name FROM sqlite_master WHERE type='table' ORDER BY name")]
                head = json.loads(connection.execute("SELECT r.document FROM revisions r JOIN state s ON r.id=s.head_revision").fetchone()[0])
                revisions = connection.execute("SELECT count(*) FROM revisions").fetchone()[0]
                history = connection.execute("SELECT count(*) FROM history").fetchone()[0]
                need(len(tables) == 20 and tables == summary.get("tables"), f"Snapshot table inventory differs: {label}")
                need(head == document and head.get("revision_id") == summary.get("revision"), f"Snapshot document/summary mismatch: {label}")
                need((revisions, history) == (summary.get("revisions"), summary.get("history")), f"Snapshot history counts differ: {label}")
                native_summary[label] = {"sha256": sha(data), "revisions": revisions, "history": history, "revision": head.get("revision_id"), "tables": len(tables)}
        except (sqlite3.Error, ValueError, TypeError, IndexError) as error:
            errors.append(f"Cannot verify snapshot {label}: {error}")
    if "before" in native_summary:
        need((native_summary["before"]["revisions"], native_summary["before"]["history"]) == (13, 8), "Native baseline is not the captured 13-revision/8-history fixture")
    if isinstance(fixture, dict):
        before_doc = load(native/"before-document.json")
        need(fixture.get("document") == before_doc, "Native fixture differs from before snapshot")
    for path in (sorted(native.iterdir()) if native.is_dir() else []):
        if not path.is_file():
            continue  # Live package/media directories are deliberately not copied.
        if path.suffix in {".sqlite", ".py", ".log", ".txt"}:
            copy(path, "native/"+path.name, True)
        else:
            copy(path, "native/"+path.name)
    add("native/summary.json", wire(native_summary))

    # Retain every scratch Python script without generating new live .py source
    # inside the repository. Preserve existing evidence runners and reviews.
    for path in sorted(scratch.rglob("*.py")):
        if any(part.endswith(".deadpan") for part in path.relative_to(scratch).parts):
            continue
        copy(path, "scripts/"+str(path.relative_to(scratch)), True)
    for name in ("run-native.py", "summarize.py", "project-service-review.md", "ui-review.md", "harness-review.md"):
        read(output/name)
    for name in ("project-service-review.md", "ui-review.md", "harness-review.md"):
        candidate = scratch/name
        if candidate.is_file():
            scratch_review, retained_review = read(candidate), read(output/name)
            need(scratch_review == retained_review, f"Retained independent review differs from scratch: {name}")
    environment = {"backend_checkpoint": BASE_COMMIT, "source_proof": source_proof,
                   "final_visual_metadata": replays.get("visual-final", {}).get("metadata"),
                   "final_performance_metadata": replays.get("performance-final", {}).get("metadata"),
                   "native_verification": verification, "native_cleanup": cleanup,
                   "all_attempts": attempts, "failure_resolutions": resolutions,
                   "test_counts_note": "Counts are derived per run from logs; overlapping focused/default/UI runs are not summed as distinct tests."}
    add("environment.json", wire(environment))

    # Do not silently replace an earlier evidence file. Preserve all original
    # content and fail if collection would overwrite it with different bytes.
    for name, data in payloads.items():
        destination = output/name
        if destination.exists():
            need(destination.is_file() and destination.read_bytes() == data, f"Existing retained evidence differs: {destination}")
    # Detect new attempts and sources/logs/snapshots changing while preparing.
    final_check_files = {p.name for p in check_dir.iterdir() if p.is_file()} if check_dir.is_dir() else set()
    need(initial_check_files == final_check_files, "Check files were added/removed during collection")
    final_replay_directories = {p for p in scratch.iterdir() if p.is_dir() and
                                (p.name.startswith(("visual-", "performance-")) or (p/"report.json").is_file())}
    need(final_replay_directories | {scratch/name for name in REQUIRED_REPLAYS} == directories,
         "Replay attempts were added/removed during collection")
    for name, digest in inputs.items():
        path = Path(name)
        need(path.is_file() and sha(path.read_bytes()) == digest, f"Input changed during collection: {path}")
    if errors:
        print(json.dumps({"sealed": False, "errors": errors, "discovered_checks": sorted(checks),
                          "discovered_replays": sorted(replays), "retained_output_unchanged": True}, indent=2), file=sys.stderr)
        return 1
    output.mkdir(parents=True, exist_ok=True)
    for name, data in payloads.items():
        destination = output/name
        destination.parent.mkdir(parents=True, exist_ok=True)
        if not destination.exists():
            with destination.open("xb") as handle:
                handle.write(data)
    inventory = {str(path.relative_to(output)): sha(path.read_bytes()) for path in sorted(output.rglob("*"))
                 if path.is_file() and path.name != "SHA256SUMS.json"}
    seal = output/"SHA256SUMS.json"
    encoded = wire(inventory)
    if seal.exists() and seal.read_bytes() != encoded:
        print("Existing seal differs; evidence files retained, inspect before replacing SHA256SUMS.json", file=sys.stderr)
        return 1
    if not seal.exists():
        with seal.open("xb") as handle:
            handle.write(encoded)
    print(json.dumps({"sealed": True, "files": len(inventory), "bytes": sum((output/name).stat().st_size for name in inventory),
                      "source_files": source_proof.get("source_files_rechecked"), "test_results": {name: checks[name]["tests"] for name in ("focused-slip", "app-ui-tests", "app-default-tests")},
                      "replay_checks": {name: report["check_count"] for name, report in replays.items()},
                      "seal_sha256": sha(encoded)}, indent=2))
    return 0


def retain_image(directory, step, prefix, copy, index, need, exact_name=False):
    screenshot = step.get("screenshot")
    if not need(isinstance(screenshot, str) and bool(screenshot), f"Missing screenshot: {step.get('input')}"):
        return
    rel = Path(screenshot)
    if not need(not rel.is_absolute() and ".." not in rel.parts, f"Unsafe screenshot path: {screenshot}"):
        return
    name = prefix + ".png" if exact_name else prefix + "/" + rel.name
    copy(directory/rel, name)
    index.append({"path": name, "run": directory.name, "source_screenshot": screenshot,
                  "caption": step.get("input"), "frame": step.get("frame"), "semantic": step.get("semantic")})


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except (OSError, ValueError, subprocess.CalledProcessError) as error:
        print(json.dumps({"sealed": False, "error": str(error)}, indent=2), file=sys.stderr)
        raise SystemExit(1)
