from pathlib import Path
import difflib
import hashlib
import subprocess
root=Path('/tmp/deadpan-native-slip-20261001/ui')
files=sorted(p.relative_to(root/'work') for p in (root/'work').rglob('*.rs'))
subprocess.run(['rustfmt','--edition','2024','--config','skip_children=true',*[str(root/'work'/p) for p in files]],check=True)
chunks=[]
for name in files:
 before=root/'base'/name
 old=before.read_text() if before.exists() else ''
 new=(root/'work'/name).read_text()
 if old==new: continue
 header=f'diff --git a/{name} b/{name}\n'
 if not before.exists(): header+='new file mode 100644\n'
 chunks.append(header+''.join(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile='a/'+str(name) if before.exists() else '/dev/null',tofile='b/'+str(name))))
patch=root/'ui.patch';patch.write_text(''.join(chunks))
subprocess.run(['git','apply','--check',str(patch)],check=True,cwd='/Users/michael/Code/deadpan')
subprocess.run(['git','apply','--check','/tmp/deadpan-native-slip-20261001/project-service.patch',str(patch)],check=True,cwd='/Users/michael/Code/deadpan')
print('Clean UI and combined service/UI apply-check;',len(chunks),'files;',len(patch.read_text().splitlines()),'patch lines')
print('SHA256',hashlib.sha256(patch.read_bytes()).hexdigest())
subprocess.run(['git','apply','--numstat',str(patch)],check=True,cwd='/Users/michael/Code/deadpan')
