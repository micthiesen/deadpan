import copy
import datetime
import fcntl
import json
from pathlib import Path
import sqlite3
import subprocess

root = Path(__file__).parent / 'native'
labels = ['before', 'cancelled', 'committed', 'undone', 'redone', 'reopened']
documents = {label: json.loads((root / (label + '-document.json')).read_text()) for label in labels}
counts = {label: json.loads((root / (label + '-summary.json')).read_text()) for label in labels}
expected_counts = [(13, 8), (13, 8), (14, 9), (15, 9), (16, 9), (16, 9)]
for label, expected in zip(labels, expected_counts):
    assert (counts[label]['revisions'], counts[label]['history']) == expected, label

def content(document):
    value = copy.deepcopy(document)
    value.pop('revision_id')
    return value

before = documents['before']
group = before['nodes'][before['root']]['kind']['children'][0]
wrapper = before['nodes'][group]['kind']['children'][0]
physical = before['nodes'][wrapper]['kind']['child']
expected = content(before)
source = expected['nodes'][physical]['kind']['source']
for name in ['video_mapping', 'audio_mapping']:
    assert source[name]['start'] == {'numerator': '-10', 'denominator': '1'}
    source[name]['start']['numerator'] = '-12'
# The changed PCM recipe no longer shares its sibling's captured lineage.
# No retained sample binding or source effect is changed.
expected['audio_lineage'].pop(physical)
assert content(documents['committed']) == expected
assert documents['cancelled'] == before
assert content(documents['undone']) == content(before)
assert content(documents['redone']) == expected
assert documents['reopened'] == documents['redone']
assert len({documents[label]['revision_id'] for label in ['before', 'committed', 'undone', 'redone']}) == 4

def tables(label):
    with sqlite3.connect(root / (label + '.sqlite')) as db:
        names = [row[0] for row in db.execute("SELECT name FROM sqlite_master WHERE type='table' ORDER BY name")]
        return {name: sorted(db.execute('SELECT * FROM "' + name + '"').fetchall(), key=repr) for name in names}

baseline = tables('before')
assert len(baseline) == 20
assert tables('cancelled') == baseline
assert tables('reopened') == tables('redone')
unrelated = sorted(set(baseline) - {'state', 'revisions', 'history', 'redo'})
for label in labels:
    actual = tables(label)
    assert {name: actual[name] for name in unrelated} == {name: baseline[name] for name in unrelated}, label

verification = {
    'passed': True, 'counts': counts,
    'delta_frames': 2, 'group': group, 'wrapper': wrapper, 'physical_source': physical,
    'unchanged_tables_after_cancel': 20,
    'unchanged_tables_after_reopen': 20,
    'unrelated_tables_preserved': unrelated,
    'exact_document_checks': [
        'Only linked mapping starts move from -10 to -12 and changed PCM lineage is invalidated.',
        'All durations, spans, windows, Source/root camera paths, marks, overrides and sample bindings remain exact.',
        'One Undo restores the complete prior authored content; one Redo restores the saved candidate.',
        'Every authored history action has a fresh revision; reopen changes no table.',
    ],
}
(root / 'verification.json').write_text(json.dumps(verification, indent=2) + '\n')
process = subprocess.run(['pgrep', '-fl', 'deadpan-app|Deadpan.app'], capture_output=True, text=True)
assert process.returncode == 1 and not process.stdout, process.stdout
with (root / 'Slip QA.deadpan/.writer.lock').open('a+b') as lock:
    fcntl.flock(lock.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
    fcntl.flock(lock.fileno(), fcntl.LOCK_UN)
exits = [json.loads((root.parent / 'checks' / (name + '.json')).read_text())['exit_code'] for name in ['native-run-first', 'native-run-reopened']]
assert exits == [0, 0]
cleanup = {
    'recorded_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'writer_lock_released': True, 'deadpan_app_processes': [], 'native_exit_codes': exits,
    'process_check': {'command': process.args, 'exit_code': process.returncode, 'stdout': process.stdout, 'stderr': process.stderr},
    'native_app_inventory': [],
    'inventory_observation': 'cua.listApps filtered for Deadpan returned [] after the second quit.',
}
(root / 'cleanup.json').write_text(json.dumps(cleanup, indent=2) + '\n')
print(json.dumps({'passed': True, 'counts': {name: [value['revisions'], value['history']] for name, value in counts.items()}, 'cleanup': cleanup}, indent=2))
