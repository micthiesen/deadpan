from pathlib import Path
import re
repo = Path('/Users/michael/Code/deadpan')
out = Path('/tmp/deadpan-native-slip-20261001/docs')
path = None
links = 0
for line in (out/'docs.patch').read_text().splitlines():
    if line.startswith('+++ b/'):
        path = Path(line[6:])
    if not line.startswith('+') or line.startswith('+++'):
        continue
    added = line[1:]
    assert added == added.rstrip(), (path, 'trailing whitespace')
    assert '\u2014' not in added, (path, 'em dash')
    for ref in re.findall(r'\]\(([^)]+)\)', added):
        if ':' in ref or ref.startswith('#'):
            continue
        target, _, fragment = ref.partition('#')
        rel = (repo/path.parent/target).resolve().relative_to(repo)
        file = out/'work'/rel
        if not file.exists():
            file = repo/rel
        assert file.exists(), (path, ref)
        if fragment:
            headings = re.findall(r'^#+\s+(.+)$', file.read_text(), re.M)
            slugs = [re.sub(r'[^\w\- ]', '', h.lower()).replace(' ', '-') for h in headings]
            assert fragment in slugs, (path, ref, slugs)
        links += 1
print(f'Passed: {links} added relative links and fragments; added-line whitespace and em-dash checks.')
