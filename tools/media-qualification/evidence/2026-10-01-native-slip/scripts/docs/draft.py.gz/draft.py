from pathlib import Path
import difflib

repo = Path('/Users/michael/Code/deadpan')
out = Path('/tmp/deadpan-native-slip-20261001/docs')
paths = ['docs/SOURCE_SLIP.md', 'docs/KEYBINDING_COMPATIBILITY.md', 'docs/REQUIREMENTS.md', 'docs/spec/AGENT_HANDOFF.md', 'AGENTS.md']
base = {path: (repo/path).read_text() for path in paths}
work = dict(base)

def replace(path, old, new):
    assert work[path].count(old) == 1, (path, old)
    work[path] = work[path].replace(old, new)

def before(path, anchor, addition):
    replace(path, anchor, addition + anchor)

before('docs/SOURCE_SLIP.md', '## Remaining work\n', '''## Native stopped-picture preview

Native `:slip +5f` opens an unsaved preview for the selected picture beat in
Your edit. Negative, unsigned and zero whole-frame amounts are accepted; the
ASCII `f` suffix is required. Positive means later Original material. Clear any
active or finished Visual Edit selection first, including an empty one. Original,
catalog Sound and placed-sound focus do not supply a picture target.

Command entry captures the project session, revision, ordinary Sequence scope,
selected direct child and output range, both editor cursors and selection. It
captures a missing or ineligible target as a failure too. Later selection or
worker completion cannot supply a replacement. The service revalidates this
explicit target and the stored source receipt.

The preview has its own Edit inspection frame within the beat. An entry cursor
outside the selected beat is retained; only the temporary inspection frame is
clamped. Before and Proposed compare the same output coordinate. Neither changes
the real Edit or Original cursor, selected beat, group or Visual selection.

| Key or control | Action |
| --- | --- |
| `h/l` | Select material one project frame earlier/later. |
| `Shift+h/l` | Select material ten project frames earlier/later. |
| Left/Right | Inspect one delivered picture earlier/later within the beat. |
| Shift+Left/Right | Inspect ten delivered pictures earlier/later. |
| `i/o` | Inspect the first/last delivered picture. |
| `b` | Compare Before/Proposed at the same Edit frame. |
| Amount field | Enter an exact whole-frame amount such as `-3f`. |
| Tab / Shift+Tab | Traverse native controls. |
| Enter on the preview heading, or Apply | Save the displayed nonzero proposal once. |
| Escape, or Cancel | Discard the preview and restore valid entry context. |

These keys apply when the preview heading or background owns keyboard focus.
Text fields retain native editing; Enter in the amount field does not apply.
Focused buttons retain native activation. Active IME composition owns Enter and
Escape. Movement keys may repeat; Apply, comparison, endpoint inspection and
Cancel do not repeat while held. Command, Control and Option chords remain
reserved. This surface adds no `,v` binding.

The report separates requested and applied delta, exact rational handles,
inward whole-frame bounds and the limiting picture edge. After an overshoot,
one reverse nudge moves away from the reached handle immediately. Every input
in a key batch changes the intended amount; bounded preparation can coalesce to
its latest value. Invalid text retires the preceding ready proposal. An applied
zero displays the unchanged saved picture, disables Apply and creates no history.

### Display admission and saving

Preparation produces a proposed snapshot tied to the service's exact immutable
base. Apply requires all of the following: a nonzero current proposal; no pending
refinement or error; Proposed comparison; an idle project service; and matching
requested, decoded and successfully GPU-submitted picture identities at the
current inspection frame and viewer raster. A prepared snapshot or completed
decode alone does not enable Apply. Proposed pictures cannot become Camera
targets.

A refinement, inspection change, comparison switch, resize or picture failure
revokes readiness. The prior accepted picture and its caption/geometry remain
while replacement work prepares or fails. Pending picture identities are revoked
at entry, every draft change, cancel, save and captured-context invalidation,
including decoded pictures awaiting submission. Service publications reconcile
the draft before queued decoder replies are admitted. A late success or error
cannot restore a retired proposal.

Apply consumes the exact service-owned revision-bound request once. Further
Apply/Cancel input is disabled while saving. A successful transaction preserves
the captured cursor, selected Source or Partition wrapper and ordinary group.
The service saves a separate receipt before refreshing the workspace. If refresh
fails, the UI reports that Slip was saved and asks the user to reopen the project.
It does not imply the transaction failed or retry it. Duplicate delivery of the
same saved proposal returns its receipt without another write.

The latest saved receipt survives queries, rejected drafts and Undo in that
session; it clears when the project/session changes or closes. The UI consumes
it only for the matching applying draft. Historical receipts do not repeat
selection changes or stale refresh warnings after navigation or Undo. A changed
revision invalidates an unsaved proposal, including after a fresh Undo revision.
Cancel restores entry state only while that captured workspace remains valid.

Native integration and runtime verification are in progress. See the
[qualification record](qualification/native-slip-2026-10-01.md) for pending
tests, rendered replay and physical-input limits.

''')
replace('docs/SOURCE_SLIP.md', '''Native `:slip` and Trim mode are not connected by this increment. Full Trim also
requires In/Out, adjacent Roll, ripple/overwrite policy, physical Source growth,
nested occurrence editing and boundary-frame/waveform previews. Audio-only
lead/tail needs an index-derived adjacent-picture interval before it can be
admitted. Exact windows and stored receipts alone do not qualify those cases.
''', '''The native Slip preview stops playback and has no audition or waveform. It
implements the Slip contract and typed example in specification sections 6.3
and 6.4; it does not complete [Trim mode](spec/DEADPAN_SPEC.md#77-trim-mode).
Full Trim still requires In/Out, adjacent Roll, ripple/overwrite policy, physical
Source growth, nested occurrence editing and paired boundary-frame/waveform
previews. The specified `,v` entry and Tab mode cycling remain unimplemented.
Audio-only lead/tail needs an index-derived adjacent-picture interval before it
can be admitted. Exact windows and stored receipts alone do not qualify those
cases. Full physical-input, accessibility and release acceptance remain open.
''')

before('docs/KEYBINDING_COMPATIBILITY.md', '## Place slice\n', '''## Source Slip preview

**`:slip +5f`** opens a stopped-picture draft for the selected eligible Source or
neutral Partition in Your edit. Its captured target includes missing/ineligible
entry context; later selection cannot supply one. Clear any Visual Edit selection
first, including an empty range. The amount is one signed or unsigned whole-frame
integer with an ASCII `f` suffix.

On the preview heading/background, `h/l` changes material by one project frame
and Shift changes ten. Left/Right inspects one delivered picture, Shift ten;
`i/o` inspects first/last and `b` compares Before/Proposed at the same Edit frame.
Enter applies once only after the exact current Proposed picture is submitted
at the current viewer size; Escape cancels. Before, zero movement, pending
pictures and failures cannot apply. The actual Edit/Original cursors and selected
beat stay fixed during inspection. A nudge away from a clamp starts at its applied
handle, and batched movement keys retain every step.

Tab and Shift+Tab use native control traversal. Amount text, focused buttons and
IME retain their input; Enter in the amount field does not apply. Composition
owns Enter/Escape. Held movement may repeat, while Apply, Cancel, `b` and `i/o`
do not. Command, Control and Option variants remain reserved. The modal excludes
ordinary editing, transport and Render. It adds no modified global shortcut and
no `,v` binding. Full Trim's Tab mode cycling and waveform remain pending.

The production `slip` replay is drafted for the exact picture gate, clamps,
comparison, batched input, text/IME focus, late replies, cancel, one commit and
Undo/Redo. The expanded reservation matrix expects 17,360 cases over the same
62 globals. Runtime execution and the live Kestrel registry comparison remain
pending in [native Slip qualification](qualification/native-slip-2026-10-01.md).
See [Source Slip](SOURCE_SLIP.md#native-stopped-picture-preview) for the full
capture, picture and saved-receipt contract.

''')
replace('docs/KEYBINDING_COMPATIBILITY.md', 'The expanded reservation matrix has 16,368 cases over the same 62 Kestrel globals.\n', 'The marks qualification passed 16,368 cases over the same 62 Kestrel globals.\n')
replace('docs/KEYBINDING_COMPATIBILITY.md', '''text-action, inspector, room-tone, Gain and Place slice routers, including
`Bindings::key_with_selection` for empty and nonempty Edit selections. The current
source expects 192 routing cases per reservation, or 11,904 total, including
pending prefixes, counts and overflow, text/IME and repeat/focus combinations.
''', '''text-action, inspector, room-tone, Gain, Marks, Place slice and Slip routers,
including `Bindings::key_with_selection` for empty and nonempty Edit selections.
The Slip integration expects 280 routing cases per reservation, or 17,360 total,
including pending prefixes, counts and overflow, text/IME and repeat/focus
combinations. Its execution and live-source comparison remain pending in the
[native Slip record](qualification/native-slip-2026-10-01.md).
''')

before('docs/REQUIREMENTS.md', '[Exact Source windows](SOURCE_EDIT_WINDOWS.md) retain selected time before\n', '''[Native Source Slip](SOURCE_SLIP.md#native-stopped-picture-preview) is in
integration and runtime verification for DP-02/DP-05/DP-20. The `:slip`
workflow captures the selected beat and revision, reports exact clamps/no-op,
compares real stopped Before/Proposed pictures, and gates one Apply on the
current submitted picture. It preserves both cursors and retains a saved receipt
if workspace refresh fails. Service, input/presentation and production replay
checks are drafted; passing runtime results have not yet been recorded in
[this qualification](qualification/native-slip-2026-10-01.md). Full Trim,
waveforms/audition, unsupported target scopes and physical-input/accessibility
acceptance remain open. No requirement or gate changes status.

''')

before('docs/spec/AGENT_HANDOFF.md', '## Exact Source windows and atomic Slip, 2026-10-01\n', '''## Native Source Slip integration, 2026-10-01

The native integration connects `:slip +5f` to the shared qualified command
through a captured-target service, stopped Before/Proposed picture preview and
one saved transaction. Capture absence as well as valid session/revision/group/
child context. Separate the temporary inspection frame from both editor cursors.
Apply requires the current Proposed identity and frame to be GPU-submitted at
the current raster; preparation or decode alone is insufficient. Cancel and draft
changes revoke pending picture admission before a replacement is scheduled.

Keep the exact service-owned request and an independent saved receipt. A saved
edit survives refresh failure; historical receipts cannot reselect or replay
warnings after navigation/Undo. Zero movement has no proposed snapshot, Apply or
history. See [Source Slip](../SOURCE_SLIP.md#native-stopped-picture-preview) and
[keyboard routing](../KEYBINDING_COMPATIBILITY.md#source-slip-preview).

Integration and runtime verification are in progress. Service/UI reviews found
no remaining actionable findings in their reviewed drafts; draft formatting and
combined patch admission were checked. Integrated tests are running; no native
window has been opened for this increment. Run the focused service, parser/router and presentation tests, the production
`slip` replay, live Kestrel comparison and native keyboard/display checks. Keep
first failures and final source identities in the
[qualification record](../qualification/native-slip-2026-10-01.md), and close the
agent-owned native test instance after use. Full Trim, waveform/audition,
In/Out/Roll, ripple/overwrite and broader target admission remain open. No
requirement or gate is complete.

''')

before('AGENTS.md', 'Durable render jobs capture immutable project/revision/document/range/policy\n', '''Native `:slip +5f` uses a captured selected picture beat under the admitted
Source/Partition scope. Capture command-entry absence, session, revision, group,
child and both editor cursors; later replies cannot retarget it. Keep temporary
picture inspection separate from the real cursors. Require the exact current
Proposed picture to be decoded and GPU-submitted at the current inspection frame
and raster before Apply; preparation alone is insufficient. Refinement, compare,
cancel, save and stale context revoke pending presentation immediately while
retaining the prior accepted image. Zero movement has no snapshot or history.
Consume one retained command and preserve a separate saved receipt before
refresh; report a saved refresh failure without repeating the edit. Historical
receipts cannot replay selection or warnings after navigation/Undo, and clear
on session replacement. See [native Slip](docs/SOURCE_SLIP.md#native-stopped-picture-preview)
and its [pending qualification](docs/qualification/native-slip-2026-10-01.md).
The stopped-picture preview does not implement full Trim or audio audition.

''')

newpath = 'docs/qualification/native-slip-2026-10-01.md'
assert not (repo/newpath).exists()
work[newpath] = '''# Native Source Slip, 2026-10-01

Status: integration and runtime verification in progress. The reviewed native
service, UI and replay patches are applied on backend checkpoint
`8c282ac8a3147e784b212852540b5e44e28382b1`. Focused integrated compile/tests are
running; no results or native desktop execution are claimed here. Final native
implementation identity and runtime outcomes are pending. The existing
[core/store Slip qualification](source-slip-2026-10-01.md) is separate and does
not prove this native workflow. The
[retained evidence directory](../../tools/media-qualification/evidence/2026-10-01-native-slip/)
contains the runner, summarizer and independent reviews; runtime reports will
be added as verification proceeds.

## Intended supported behavior

The native `:slip +5f` entry uses the shared qualified Source command. A selected
Source or one neutral unity Partition under ordinary Sequences shifts linked
Original material without changing placement or duration. The draft displays
requested/applied movement, exact and whole-frame handles, limiting picture edge
and no-op status. It preserves the Edit and Original cursors, selected wrapper
and group while inspecting a separate stopped Edit frame. See
[the complete contract](../SOURCE_SLIP.md#native-stopped-picture-preview).

The command captures missing/ineligible entry context as well as a valid target.
Every proposal binds session, project, base revision, draft and refinement.
Before compares the same Edit coordinate. Apply requires a nonzero current
Proposed picture with matching requested, decoded and GPU-submitted identity,
inspection frame and viewer raster, plus an idle service. It cannot use an old
accepted image or an unsubmitted decode. Amount, comparison and inspection
changes retire older picture admission before new work is scheduled.

One Apply consumes the retained revision-bound request. The service records the
saved receipt before workspace refresh; failure afterward reports a saved edit
and reopening guidance. A duplicate reply does not write again. Receipt lifetime
is independent of queries, failed drafts and Undo, and ends on project/session
replacement. Only the matching applying UI consumes it.

## Reviewed corrections

The independent
[service review](../../tools/media-qualification/evidence/2026-10-01-native-slip/project-service-review.md)
and [UI review](../../tools/media-qualification/evidence/2026-10-01-native-slip/ui-review.md)
report no remaining actionable findings in their reviewed drafts. The UI review
led to two concrete lifecycle corrections:

- A failed proposed decode retains the prior submitted texture, caption, canvas
  and geometry. It revokes Apply and exposes the current picture error.
- Entry, draft changes, cancellation, successful save and context invalidation
  immediately cancel the worker and revoke pending presentation. This includes
  already decoded pictures awaiting submission. Service publications reconcile
  the draft before queued decoder replies are polled.

Pure presentation regressions cover stale success/error before replacement
request dispatch and an already decoded, unsubmitted proposal. This is a state
transition witness. Production service-before-decode ordering has been reviewed
statically; an external head-change publication with a withheld proposal reply
is not covered by the drafted real replay. Keep that distinction in final results.

The status/footer may cause a bounded resize as handles and readiness arrive.
The review found that successful fixed-raster state settles and failed rendering
revokes the ticket. Actual minimum-window paint and final assigned-desktop size
still need to be checked.

## Drafted test coverage

| Layer | Witnesses awaiting execution |
| --- | --- |
| Project service | History-neutral previews; exact request/clamp retention; zero snapshot absence; missing and stale captures; qualification recheck; failed-newer-draft retirement; abandon; transaction rollback; duplicate commit; refresh-failure receipt; session replacement; nested Partition; fresh Undo/Redo revisions. |
| Parser and modal router | Signed/unsigned/zero whole-frame syntax, checked integer bounds, mandatory ASCII `f`, extra-argument refusal; repeated movement; Shift ten; text/button/IME ownership; reserved modifier chords. |
| Draft reducer | Out-of-beat entry cursor; applied-handle reversal; complete batched nudges; overflow and invalid-text retirement; unrelated/stale update rejection. |
| Presentation | Exact current proposed identity/frame, decode versus submission, current raster, failure retention/recovery, cancellation and stale replies, and committed-only Camera exclusion. |
| Native replay | Real service/store/decoder/Metal route; Before/Proposed; clamps and reversal; batched input; first/last inspection; text/IME; no-op; cancel; one Apply; Undo/Redo; explicit entry refusals; nested Partition and retained framing. |

The `slip` replay uses the existing real `cfr-bframes.mp4` fixture. Production
keyboard input copies Original ordinals `[10,24)` and pastes before the full
Original. Typed fixture setup adds Source and live ancestor camera paths while
the service writer is closed. Every Slip then uses production command entry,
modal routing, store qualification, decoding and Metal submission.

Its independent picture oracle expects Original ordinal 13 at Edit frame 3,
18 for `+5f`, 3 for a `-100f` request clamped to `-10f`, 4 after one reverse nudge,
and 15 after the complete `l/l/h/Shift+l` batch. It checks measured PTS, decoded/
displayed ordinal and typed presentation/geometry identities. A later nested
fixture uses production Split, typed Group setup and keyboard descent.

The replay withholds an actual proposal decode before Apply, and releases late
service and decoder replies after cancellation. Named screenshot checkpoints
are requested for Proposed, Before, compact clamp, committed result and nested
Partition. They are evidence only after the replay runs and those captures are
inspected. The 960×640 and 1280×820 checks are planned raster/paint checks.

The expanded Kestrel matrix expects 62 reservations × 280 routes = 17,360 cases.
Its execution and live `Shortcuts.swift` digest comparison are pending. No new
modified shortcut is added; `,v` and full Trim mode switching remain unimplemented.

## Execution status

| Gate | Current result |
| --- | --- |
| Draft formatting and combined service/UI/harness apply-check | Reported passed by patch authors; static preparation only. |
| Independent service/UI review | Completed for reviewed drafts; no remaining actionable findings. |
| Integrated default and `ui-harness` app tests | Focused feature checks running; final outcomes pending. |
| Strict lint and final formatting | Pending. |
| Focused production `slip` visual replay | Pending. |
| Current Kestrel matrix and live registry comparison | Pending. |
| Broader affected native replay | Pending. |
| Native keyboard, resize and screenshot inspection | Pending. |
| Saved failure/reopen and current native process shutdown | Pending. |

Record the final implementation revision/source manifest, toolchain/runtime,
commands, exact counts, failures and corrections, rendered captures and native
observations here when available. Preserve original failed runs. An apply-check,
review or proposed snapshot is not a runtime pass.

## Limits

This is a stopped-picture Slip preview. It excludes waveform and audio audition,
In/Out, Roll, ripple/overwrite, physical Source growth, nested/treated or repeated
targets, FitBeat/incoherent windows and audio-only picture lead/tail. Full
[Trim mode](../spec/DEADPAN_SPEC.md#77-trim-mode) remains required.

Offscreen GPU submission does not measure physical display latency. Synthetic
egui IME events do not establish OS IME delivery, physical non-US keyboard
layouts or VoiceOver. This increment does not qualify complete playback, export,
release packaging or any full DP requirement/delivery gate. Close the agent-owned
native QA instance after verification; the user's assigned desktop/window is
available for testing but must not be left running without further test use.
'''

patch=[]
for path, data in work.items():
    old=base.get(path, '')
    for tree, value in [('base', old), ('work', data)]:
        dest=out/tree/path
        dest.parent.mkdir(parents=True, exist_ok=True)
        if tree != 'base' or path in base:
            dest.write_text(value)
    if old == data:
        continue
    patch.append(f'diff --git a/{path} b/{path}\n')
    if path not in base:
        patch.append('new file mode 100644\n')
    patch.extend(difflib.unified_diff(old.splitlines(keepends=True), data.splitlines(keepends=True), fromfile=f'a/{path}' if path in base else '/dev/null', tofile=f'b/{path}', n=3))
(out/'docs.patch').write_text(''.join(patch))
print(f'{len(work)} files; {sum(len(x.splitlines()) for x in patch)} patch lines')
