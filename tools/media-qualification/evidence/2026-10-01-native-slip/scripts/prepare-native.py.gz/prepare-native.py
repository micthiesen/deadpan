import fcntl
import hashlib
import json
from pathlib import Path
import shutil
import sqlite3

root = Path(__file__).parent
source = root / 'visual-final/projects/slip/Documents/Deadpan/cfr-bframes.deadpan'
native = root / 'native'
native.mkdir(exist_ok=True)
destination = native / 'Slip QA.deadpan'
assert not destination.exists()
with (source / '.writer.lock').open('a+b') as lock:
    fcntl.flock(lock.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
    shutil.copytree(source, destination)
    fcntl.flock(lock.fileno(), fcntl.LOCK_UN)
with sqlite3.connect('file:' + str(destination / 'project.sqlite') + '?mode=ro', uri=True) as database:
    document = json.loads(database.execute('SELECT r.document FROM revisions r JOIN state s ON r.id=s.head_revision').fetchone()[0])
(native / 'fixture.json').write_text(json.dumps({
    'source': str(source), 'destination': str(destination),
    'database_sha256': hashlib.sha256((destination / 'project.sqlite').read_bytes()).hexdigest(),
    'document': document,
}, indent=2) + '\n')
print(destination)
