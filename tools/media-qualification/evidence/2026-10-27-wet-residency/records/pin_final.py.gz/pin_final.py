from pathlib import Path
import json, hashlib, shutil
s=Path(__file__).resolve().parent
receipt=json.loads((s/'final-build.json').read_text())
assert receipt['exit_code']==0 and receipt['sources_unchanged']
bins=[]
for line in (s/'final-build.stdout').read_text().splitlines():
 try:r=json.loads(line)
 except ValueError:continue
 if r.get('reason')!='compiler-artifact' or not r.get('executable') or not r.get('profile',{}).get('test'):continue
 name=r['target']['name']
 if 'deadpan-audio#' not in r['package_id'] or name not in ['deadpan_audio','audio_definition','stages']:continue
 out=s/('final-'+name.replace('_','-'))
 assert not out.exists()
 shutil.copy2(r['executable'],out)
 bins.append(dict(name=name,path=str(out),bytes=out.stat().st_size,sha256=hashlib.sha256(out.read_bytes()).hexdigest(),artifact=r))
assert len(bins)==3
(s/'final-pins.json').write_text(json.dumps(bins,indent=2)+'\n')
print(json.dumps([{k:r[k] for k in ('name','path','sha256')} for r in bins],indent=2))
