# Cold scalar demand before one temporal output batch

Read-only source research, 2026-10-27. No repository edits, builds, providers,
PCM/native allocations or qualification claims. The worker editing finite wet
construction and event returns is independent. Anchors refer to this checkout.

## Conclusion

A useful cold proof is implementable as a **policy-only demand interpreter**,
not an effect-count formula. The successful scalar callback schedule is
independent of numeric PCM. The missing implementation is shared policy and
temporal-discovery factoring plus a resource fold over that schedule. This is
larger than adding a batching eligibility predicate. No current source or
measurement proves that its conservative bound fits the three failing fixtures.

The preferred first independently shippable change is one shared Components
metadata/policy driver. A separate hand-copied `PolicyComponents` would duplicate
the precise owner/member ordering, clock selection, wet exclusions and gates
that the proof needs to certify; it is too easy for the proof and runtime to
drift. It should share those decisions, with numeric processing supplied by the
runtime and demand collection supplied by the interpreter. Do not enable runtime
batching as part of that refactor.

## What can be established without PCM

`shared_eq.rs::read_shared_program` (261) performs these operations before
`mix.allocate` and before reading Original/sound PCM:

1. Resolve exact Original support and owner spans from the current Context.
2. Resolve current sound support; compile only the selected first historical
   plans; prepare exact root and BeatSound queries, placements, routes and fades.
3. Register all voice IDs and mix routes, including inactive candidates.
4. Establish Split families, selected-family aliases and output aliases.
5. Calculate the chunk reservation from `mix.resident_frames`.

This is a natural metadata closure to extract. Its inputs are immutable plan,
exact Contexts, stop/allowed/output/parent/depth and a <=256-frame window. It
must preserve source recipe/dependency admission, query work and historical
scope validation. It need not resolve an AudioSourceProvider. The closure's
queries must be dropped after folding the chunk; they are not a prefix cache.
The existing processing-plan cache should not be warmed incidentally by a
read-only demand query: use a local exact first-clock preparation scope or pass
the already-required scope, and include/charge actual compilation work.

The subsequent route `permitted` flags are also structural:

* Original: `admitted(original_id)`, owner support Active, and absence from
  raw `suppressed`/`exhausted`. Inactive nonzero PCM can fail, but cannot add a
  callback that this condition did not permit.
* Sound: `add_sound` (shared_eq.rs:915) uses admitted ID, `fade.length != 0`
  and absence from raw `suppressed`/`exhausted`. It does **not** test PCM value,
  numeric edge multiplier, post-treatment gate multiplier or audibility by ear.
* `read_queries` (stages.rs, final policy portion 2015) obtains suppression from
  silent flattened spans and `queries.policy.suppressed`; exhaustion comes from
  `edges::exhausted_ranges`. Factor that metadata extraction for reuse rather
  than calling the reader with zero or fake media.
* Signal queries use their policy suppression; routed queries translate Gap and
  retained-input suppression to destination labels. Occurrence raw queries
  deliberately have empty flattened spans and a silence policy derived from
  processing spans. Projected reads retain their output policy and exhausted
  support. These paths need the same policy-only adapter, not a generic claim
  that all prepared input is permitted.

For a successful Components run, EQ/wet callback owner, kind, sample, Permissions
and selected voice depend only on route/owner metadata, stage order, flags,
stop/skip, selected output aliases and `wet_allowed`. Saturation count affects
numeric processing but not whether later EQ/wet is called. Gain/PCM/finite
errors can stop execution earlier; the interpreter can conservatively assume
success and visit the remaining structural schedule without evaluating gains.
Muted gain does not erase a permitted contribution. Preserve this distinction.

Both `finish_constant_into` and the dynamic `finish_into` path implement those
decisions today. The shared driver must cover both. `SharedMix::finish` has a
separate non-Components bus path: its masks union toward parent buses and EQ
has output_voice None. Either factor its policy propagation too or decline
that subtree before histories are allocated; do not silently use Components
semantics for it.

## Preferred shared driver boundary

Split Components into route/owner layout, policy state, and numeric payload.
Layout owns the existing `Route.layers`, exact sample intervals, voice/send
metadata, owner membership/depth, stop/skip and stage boundaries. A policy bit
carrier can use four u64 words per route for the existing <=256-frame chunk;
4096 routes therefore need at most 131072 payload bytes, before layout/scratch
headers. Admit its actual fixed capacity before allocation; do not conflate
this proof scratch with future PCM. A run-interval carrier is possible later.

Use shared helpers for owner iteration, first active EQ clock, per-sample
permissions, wet permissions/clock and demanded contribution enumeration.
The runtime applies numeric transfers and invokes its existing callback at
those decisions. The policy visitor reports the same temporal requests and
does not instantiate Program/GainSum or output arrays. A callback-sequence
oracle for constant/dynamic, aliases, gaps, mute, disjoint supports, skip/stop,
explicit Tail exclusions and send modes can independently qualify this piece.

`AudioOwnerClock` is safe to clone inside the metadata closure: its fields are
an immutable `&RenderPlan` plus owned scalar/path/clock state, not references to
the AudioOwnerQuery that produced it (audio_owners.rs:51). This does **not** make
an entire retained Original context reconstructible from the owner ID.

## Exact recursive demand fold

At the one batching decision, visit the union of the **actual demanded scalar
targets** with descendants forced scalar. Keep only scalar discovery records
and checked interval/resource totals after each metadata closure. Do not count
speculative sibling outputs, and do not consume PCM or native filters to discover
keys. The sufficient implementation consists of these operations:

1. Factor `shared_eq_node` (660) into a metadata resolver and a native filter
   constructor. The resolver keeps its exact witness-at behavior: stable
   instance/definition/kind/gap/origin and affine clock matching, Original owner
   observation, sound context and retained consumer-grid resolution. Runtime
   creates the Equalizer only after ordinary admission; the proof never does.
2. Give each hypothetical node a scalar ancestry locator: parent locator,
   temporal kind/stage, full boundary signature and witness sample. To inspect
   a descendant, replay its ancestor metadata resolvers from the current real
   node's already-held Contexts. Drop each temporary query before retaining the
   next scalar record. This avoids a shadow Graph containing all borrowed
   Context/Domain/projection graphs. Charge replay work. If a compact signature
   cannot represent the exact affine relation without arithmetic refusal, decline
   eligibility; do not normalize/round it. Whole Repeat play is deliberately
   excluded by `matches_clock_at`, while child stable iteration paths remain.
3. The policy driver emits exact `(node, tile, Permissions, output_voice)` keys.
   Fold them through a bounded scalar seen set. Event demand emits the complete
   EventKey, including parent, voice, stage, allocation, audible and edges.
   Resolve Voice IDs deterministically through the same encounter order, or
   intern complete scalar Voice identities in the proof and translate masks.
   Colliding hashes cannot stand in for full key equality.
4. For each fresh shared tile, visit exactly `[tile-history, tile-history+input)`
   in <=256-frame chunks with its stop, permissions and output voice. For each
   event key, visit its window intersected with allocation/audible support;
   Prefix/EQ/wet schedules follow `event_return_tile` (246), `event_prefix` (427)
   and `event_prefix_uncached` (481). Event EQ/prefix input, node counts and
   retained output tiles all contribute separately. A cached runtime key may
   still be counted cold; this is conservative, never a hit-based prediction.
5. At raw input leaves, fold intrinsic demands as below. Record sum of future
   retained tile outputs, future pinned projected outputs, conservative ordinary
   outputs, missing charged processors, prepared-frame/stage/slot/disk counts,
   and maximum recursive transient path. Separate shared-Graph versus nested
   Graph processor slots. On reachable explicit Tail, either recurse through
   its actual separate Graph or report UnsupportedEligibility and stay scalar.
6. The proof's scalar seen records/locators are bounded before growth by existing
   work/depth/stage limits and an explicit scratch byte cap charged to the
   controller while proof runs. Scratch is released before target histories.
   Do not reserve the entire future estimate in active_frames: actual runtime
   allocations still charge normally. Compare the future inequality once, and
   retain a scalar policy flag preventing descendant batching until this group
   releases its extra histories. No restart/refund if execution later fails.

All retained tile outputs can be summed conservatively, even if scalar runtime
would later reuse keys. Transients take a path maximum. Current B already
includes ancestor/current retained allocations. Include optional Original cache
payload/pinned-read bounds or prove eviction availability; its fixed index size
is not its future payload bound. The parent group's N input histories, output
carrier capacity and one sequential native workspace are separate additions.

The union/subset invariant still needs proof: batching must not add node,
permission or intrinsic projection identities beyond the scalar-target union.
Forced-scalar descendants solve recursive extra histories, not this identity
obligation. Replaying actual metadata callbacks is preferable to deriving a
permission-count approximation such as 2^voices.

## Intrinsic preparation fold and a second concrete blocker

Ordinary `prepare_stage` (stages.rs:2049) has exact input/output counts available
from its signals before native allocation. Projected `prepare_projected`
(stage_projection.rs:55) has exact input count and output-policy sample count.
Factor a pure stream storage shape used by both `reserve_stream` (2146) and
the demand fold:

* transient resident = 2*min(input,65536) plus output if memory-backed, otherwise
  FILE_BUFFER_FRAMES;
* output retained resident/disk follows the same PcmWriter size threshold;
* input+output preparation work, and ordinary slot versus pinned projected
  output are independent fields;
* output values being zero do not make a PcmWriter destination Silence.

Extend the existing `preflight_intrinsic` (stage_projection.rs:232) visitor to
fold every Stage/Projected/Bound child preparation, complete input and output
policy. Deduplicate ordinary keys by the complete plan+descriptor. Projected
keys require the complete source/owned key or opaque projection identity; equal
authored descriptors are insufficient. Scalar identity/provenance keys are
allowed metadata, but do not retain their borrowed input graphs. Repeated
ephemeral opaque identities may be overcounted rather than falsely merged.

**Do not claim the existing fixed-256 preflight query partition predicts the
runtime preparation calls.** `build_stage` (2574) gets input windows from
`StreamingStretch::required_input`; `read_stage_input` (2720) subdivides each
window from that window's own start. `required_input` delegates to a native
renderer whose constructed handle already allocates native state
(native/deadpan-dsp/src/streaming.rs:66,89 and ffi/streaming.rs:42,60). A proof
before native allocations cannot create that handle to learn the schedule.
Complete [0,input_count) traversal covers input identities, but does not by
itself bound the number of newly constructed opaque projections/cache misses
over differently aligned runtime windows.

Resolve this with one of:

1. Expose a pure qualified scalar schedule/bound in deadpan-dsp, shared with the
   pinned native scheduler, then use its exact window starts/counts in the fold.
2. Prove a conservative per-boundary visit multiplicity from the existing
   contiguous nonoverlapping input contract, including read_stage_input window
   subdivisions. Count projected creations by that multiplicity, and upper-bound
   child transients for every possible <=256-frame subwindow. This needs a
   Plan-side interval summary proving projection/output sizes stable across
   such query partitions; current allocated_bytes visitors do not prove it.

The exact scheduler factoring is bounded, not a request to simulate DSP:
`native/deadpan-dsp/src/canonical.hpp::required_input` (91) uses scalar
position/buffered/consumed/cursor, exact ties-to-even `boundary`, input/output
lengths and initialized lookahead. `prepare`/`advance` update those scalar
positions independently of PCM. `initialize` currently obtains lookahead from
the configured Signalsmith `outputSeekLength(rate)` and runs native outputSeek.
Extract just the qualified lookahead calculation and scalar schedule into a
shared small type; do not construct Signalsmith or call outputSeek in a proof.
Compare its complete window sequence with the existing real StreamingStretch
over the supported rate/pitch/end/short-final matrix. A copy of the arithmetic
with no shared qualification would add another drift risk.

Without that piece, the full cold demand proof for projected retained-clock
fixtures remains open. Rejecting every projected input could support a narrow
first eligibility domain, but would not establish the requested fixtures or
full planner. Source-rate-dependent nonstreamed Hold inputs similarly need an
existing admitted scalar source contract or a conservative native input cap;
never open a provider early merely to make batching eligible.

## Groundwork and acceptance

Independently useful, without runtime batch credit:

1. Shared policy carrier/temporal demand driver with exact callback oracle,
   including both constant and dynamic Components engines.
2. Pure stream reservation/output storage shape reused in runtime accounting;
   tests at memory/file thresholds and arithmetic bounds.
3. Native-free intrinsic demand visitor with explicit unsupported schedule
   result, compared against complete cold preparation identities and outputs.
4. Metadata-only temporal-context resolver used by production node construction,
   with retained-grid/Repeat/alias equality regressions and no filter creation.

Before enabling the batch, compute and retain the bound for each exact failing
request, run cold/warm/mixed and threshold/disk/slot cases, prove actual ledger
high-water stays below each admitted bound, enforce descendants-scalar, preserve
source/depth/deadline admission, and require exact PCM. A diagnostic trace is an
oracle for the new cold proof, never the eligibility authority itself.

## Follow-up: first eligibility may exclude intrinsic processing

Yes. A first planner may return `IneligibleIntrinsic` before allocating extra
histories if **any reachable ordinary Preserve/Shift or projected preparation**
exists in its cold scalar subtree. Keep the existing scalar path for that case.
This removes the native streaming schedule/multiplicity obligation for admitted
batches, while retaining the general-Split goal and all scalar behavior. It does
not remove the remaining temporal demand, permission, residency, event-return,
nonstreamed Hold, Original cache and union/subset proof obligations above.

The current three failing test requests are plausible targets for this domain:

| Matrix branch | Fixture construction | Intrinsic status from source inspection |
| --- | --- | --- |
| all-owner first failure, Source/Sequence `cut-three` | Source inside ordinary root Sequence; prefix silent Holds; unity Split Partitions | No authored intrinsic stage; historical captures come from those same ordinary structures. Actual cold detector still must confirm. |
| one selected play, `prefix-two` | Shape::Sequence under Parent::Repeat, owner/root EQ+saturation+reverb | No authored intrinsic stage; prefix clocks capture that same Sequence/Repeat structure. |
| nested selected play, root_sound=false `prefix-two` | The preceding fixture plus outer Repeat | No authored intrinsic stage; no time/pitch processor introduced by prefix edits or occurrence isolation. |
| all-owner Shape::Retime or Parent::Retime variants | `PitchPolicy::Preserve` at 5/4 or 4/5 mapping | Intrinsic; stay scalar in this first domain. |
| other Source/Hold/Sequence/Repeat shapes under ordinary Sequence/Repeat | Some have RoomTone and all may have shared EQ/wet | Potentially eligible; RoomTone is nonstreamed Hold preparation, requiring its existing cold resource bound. Shared finite EQ/wet alone is not an intrinsic stretch. |

These are source-derived eligibility expectations, not executions or proof that
the full seven-test matrix passes. In particular, the all-owner test contains
both eligible and ineligible variants, and its current first failure prevents
evidence about later branches.

Detection must be semantic, not `pitch == Preserve` or current-node inspection.
`PitchPolicy::processes(unity_rate)` (core/document.rs:464) is false for plain
Preserve at unity. Split deliberately writes unity Partitions with Preserve
(core/split.rs:194,279); rejecting that enum value would wrongly exclude every
relevant split. Conversely nonunity Preserve and nonzero Shift prepare DSP.

Recommended conservative gate: add a checked Plan-side scalar capability
summary over **all live compiled nodes, retained audio definitions/binding
layouts, and every sound journal timing layout that could become first**.
Reject on any compiled `preserve_input` or any compiled Retime for which
`pitch.processes(scale == ExactRatio::ONE)`. Historical effective scales must
come from the same exact compiled/derived clock interpretation, never from
nominal authored duration alone. A conservative all-record scan may refuse for
an unrelated retained stage; it cannot falsely admit a hidden stage. Charge and
bound all visits. If historical layouts need compilation, use a bounded
temporary metadata scope and drop it; retain only the boolean/reason and work,
not a new collection of historical plans. This is source metadata work only,
with no native processor or PCM.

Use an additional fail-closed demand visitor at the actual query boundaries:

* Root and Signal processing `AudioSignalContent::Stage` or `ProjectedStage`
  means ineligible, even if the current tree looks ordinary.
* `AudioBound::intrinsic_stage()` catches a directly hidden processing
  operand; also traverse the exact `raw_domain` recursively so a bound Sequence
  cannot hide a deeper Stage. Merely checking the immediate bound is incomplete.
* `AudioSourceOccurrence::processing_projection()` catches independent sound
  processing. Check the **historical routed occurrence** as well as the current
  one (`PreparedBeatInput::Routed.query.domain.input()`); current scope can be
  transparent while the retained first-clock input processes.
* `AudioRoutedRootInput::Projected`, projected signal/tape providers and owned
  Preserve operands are ineligible before their `prepare_projected` entry.
  No intrinsic cache hit waives the gate; it must remain cold-safe.

`audio_source_occurrence_support.rs::processes` and `resolve` establish that
ordinary Source/Sequence/Repeat ancestor chains create no source-occurrence
projection: their projection callback runs only for actual processing Retime
edges. Historical layouts selected by the prefix/edit journals still need the
same check. That is why this gate can plausibly cover the failing ordinary
branches without claiming it covers Retime variants.

Do not merely add a flag at `prepare_stage`/`prepare_projected`: by the time a
future descendant reaches those functions, the outer extra histories would
already be allocated. The full cold decision must finish before batching;
runtime entry assertions can be defense in depth, not the eligibility proof.
