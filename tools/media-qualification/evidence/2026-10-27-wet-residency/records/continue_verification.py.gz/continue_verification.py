from pathlib import Path
import json
import subprocess
import sys
import time

scratch = Path(__file__).resolve().parent
deadline = time.monotonic() + 1800
stage = scratch / 'verified-full-stages.json'
while True:
    try:
        receipt = json.loads(stage.read_text())
    except json.JSONDecodeError:
        receipt = {}
    if 'exit_code' in receipt:
        break
    if time.monotonic() > deadline:
        raise SystemExit('Stage receipt did not become terminal; no later suite launched')
    time.sleep(1)
assert receipt['sources_unchanged'] and receipt['binaries_unchanged']
commands = [
    [sys.executable, str(scratch / 'run.py'), '--binary',
     str(scratch / 'verified-audio-definition'), 'audio-definition', '--',
     str(scratch / 'verified-audio-definition'), '--nocapture', '--test-threads=1'],
    [sys.executable, str(scratch / 'run_scoped.py'), '--binary',
     str(scratch / 'scoped-audio-definition'), 'scoped-birth-pcm', '--',
     str(scratch / 'scoped-audio-definition'), 'sound_clocks::new_group_birth',
     '--nocapture', '--test-threads=1'],
]
results = []
for command in commands:
    code = subprocess.run(command, check=False).returncode
    results.append(dict(command=command, exit_code=code))
(scratch / 'continuation-results.json').write_text(json.dumps(results, indent=2) + '\n')
raise SystemExit(any(row['exit_code'] != 0 for row in results))
