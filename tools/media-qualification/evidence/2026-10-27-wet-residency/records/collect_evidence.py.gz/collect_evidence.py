from pathlib import Path
import gzip
import hashlib
import json

scratch = Path(__file__).resolve().parent
dest = Path('/Users/michael/Code/deadpan/tools/media-qualification/evidence/2026-10-27-wet-residency')
assert not dest.exists(), 'refuse evidence overwrite'
summary = json.loads((scratch / 'regression-summary.json').read_text())
assert summary['all_sources_and_executed_binaries_stable']
for label in ['build', 'initial-audio-lib', 'final-build', 'audio-lib', 'strict',
              'verified-build', 'verified-audio-lib', 'verified-strict', 'full-stages', 'verified-full-stages',
              'audio-definition', 'scoped-build', 'scoped-audio-lib', 'scoped-birth-pcm']:
    receipt = json.loads((scratch / (label + '.json')).read_text())
    assert 'exit_code' in receipt and receipt['sources_unchanged'] and receipt['binaries_unchanged']
dest.mkdir(parents=True)
files = []
for path in sorted(scratch.rglob('*')):
    if not path.is_file() or path.suffix not in {'.json', '.py', '.md', '.patch', '.rs', '.before', '.stdout', '.stderr', '.txt'}:
        continue
    data = path.read_bytes()
    compressed = gzip.compress(data, mtime=0)
    out = dest / 'records' / (str(path.relative_to(scratch)) + '.gz')
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_bytes(compressed)
    files.append(dict(path=str(out.relative_to(dest)), bytes=len(compressed),
                      sha256=hashlib.sha256(compressed).hexdigest(), expanded_bytes=len(data),
                      expanded_sha256=hashlib.sha256(data).hexdigest()))
inventory = dict(schema_version=1, base_revision='e384bce4',
    scope='Three-file wet processor lifetime correction: full preparation admission unchanged, retained charge keeps whole native bound and releases only dropped Rust constructor arrays/network. Main and isolated tests, strict lint, independent review; initial test-only off-by-one failure retained. No recursive batching, cap/work refund, PCM or requirement credit.',
    runtime_baseline_evidence=dict(path='../2026-10-27-component-outputs/inventory.json',
        inventory_sha256='b5c537eaad3e75ece858c7f5f179c74d28cbed4cad3d512493b169791b89e3d1',
        note='Main retains inherited general-Split/index WIP; isolated lineage overlays only the same three task files on the prior isolated published runtime. Executable bytes/source trees are not redundantly archived.'), files=files)
out = dest / 'inventory.json'
out.write_text(json.dumps(inventory, indent=2) + '\n')
for row in files:
    data = (dest / row['path']).read_bytes()
    expanded = gzip.decompress(data)
    assert len(data) == row['bytes'] and hashlib.sha256(data).hexdigest() == row['sha256']
    assert len(expanded) == row['expanded_bytes'] and hashlib.sha256(expanded).hexdigest() == row['expanded_sha256']
print(json.dumps(dict(payloads=len(files), stored_bytes=sum(row['bytes'] for row in files),
                      expanded_bytes=sum(row['expanded_bytes'] for row in files),
                      inventory_sha256=hashlib.sha256(out.read_bytes()).hexdigest()), indent=2))
