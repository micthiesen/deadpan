# Wet retained residency correction

Owned source is frozen after narrow rustfmt. No Cargo/build/test execution by this worker.

Files:
- crates/deadpan-audio/src/finite_wet.rs
- crates/deadpan-audio/src/event_returns.rs
- NEW crates/deadpan-audio/src/event_returns/tests.rs

Exact before bytes and SHA-256 are in before/ and before.json. Final pins are after.json; wet-residency.patch is the complete scoped diff. research.md copies the prior ownership proof. No native files, limits, work formulas, PCM operations, batching paths or shared_eq.rs were edited.

Production:
- New public static FiniteWetEffect::retained_bytes_bound(effect) returns the complete existing CausalStereoFilter::native_bytes_bound for that effect's tap count.
- preparation_bytes_bound factors through it but retains the exact old value: native + stereo Rust kernels +1MiB temporary network allowance.
- process_shared_wet preserves history work, make_room(full preparation), synchronous constructor and control.check ordering. Private prepare_shared_wet factors the constructor/admission/publication lifetime boundary; process_shared_wet supplies its exact existing slot and Graph.resident. Only the successful active_frames/residency increment changes to retained native bound.
- Existing graph cleanup subtracts graph.resident; no new cleanup mechanism or counter refund.
- Docs distinguish dropped time-domain Rust kernels from retained native spectra/workspaces.

Five authored focused tests:
1. finite_wet::tests::retained_admission_releases_only_dropped_rust_construction_storage:
   both exact preparation/retained constants and native bound equality.
2. stages::shared_eq::event_returns::tests::wet_processor_retains_native_bound_once_with_full_construction_admission:
   both effects; exact full preparation headroom above a17-unit preexisting active base; private helper first publication charges retained only; repeated preparation does not charge again; exact remaining history work succeeds; process_tile on the actual installed local slot supplies the repeated PCM smoke check.
3. stages::shared_eq::event_returns::tests::wet_processor_requires_full_preparation_headroom_before_publication:
   both effects; retained-only and preparation-one-unit-short headroom fail with no slot/no residency increment; already performed history work remains billed.
4. stages::shared_eq::event_returns::tests::wet_processor_cancel_timeout_and_work_refusals_do_not_publish_or_charge_residency:
   both effects; cancelled, expired and history-work-one-unit-short admission fail with no slot/accounting mutation; aggregate work counter preserves existing failed-spend semantics.
5. stages::shared_eq::event_returns::tests::shared_wet_graph_cleanup_restores_active_residency_on_success_and_error:
   actual read_shared_input using a media-free Tone plus root wet treatment, both effects; successful temporal read and later plan-work failure restore preexisting active base. No Graph initializer, WIP-only cache field assertion, or shared_eq test helper/visibility change.

Limits:
- No artificial production injection for cancellation after native constructor. Existing check order and error cleanup were reviewed; new tests cover natural entry cancellation/timeout/work refusal.
- No new native allocation-failure injection. Existing causal ABI allocation failure/lifetime witness remains relevant and unmodified.
- Actual tests have not been compiled/run by this worker. Parent owns focused/full Audio tests, strict checks and real-WAV qualification.
- The Tone cleanup fixture is new and awaits execution; it asserts temporal relative_depth>0 so it cannot silently bypass the wet path.
- This patch does not prove batching headroom or total RSS. Existing ordinary EQ/native decoder/source-halo exclusions remain unchanged.

Revision after scoped-integration review: ledger tests now call private prepare_shared_wet with local filter/resident variables. They no longer depend on inherited Graph/cache WIP. The first Graph-coupled draft is preserved as draft-graph-coupled.patch and draft-graph-coupled-after.json; original before snapshots are unchanged. Final source remains frozen.

Late cleanup strengthening: initial-passing.patch and initial-passing-after.json preserve the parent-verified213 Audio passing revision. Final test uses successful cold-read work to initialize a fresh controller with one fewer available unit, asserts the aggregate reaches MAX_PLAN_WORK_PER_READ-1 before failing, and checks active residency returns to its preexisting base. The original MAX-at-entry refusal remains. A nonidentity -6dB send guarantees billed work follows the wet callback; exact schedule assertions await parent execution. Production files match the initial-passing manifest byte-for-byte.

Parent correction after actual execution: initial cleanup strengthening expected MAX-1 accepted work; observed MAX before final refusal (last accepted charge fills budget). Corrected exact assertion to MAX, no production change. Failed 212/1 result and patch preserved; verification reruns use verified-* labels. The preceding initial draft had all213 tests passing before late cleanup assertion was added.
