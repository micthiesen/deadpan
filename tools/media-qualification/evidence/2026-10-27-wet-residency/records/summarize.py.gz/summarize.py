from pathlib import Path
import hashlib
import json
import re

scratch = Path(__file__).resolve().parent
summary = {}
for label, expected in [
    ('verified-audio-lib', (213, 0, 0)),
    ('verified-full-stages', (207, 3, 0)),
    ('audio-definition', (171, 0, 0)),
    ('scoped-audio-lib', (196, 0, 0)),
    ('scoped-birth-pcm', (8, 0, 0)),
]:
    receipt = json.loads((scratch / (label + '.json')).read_text())
    assert receipt['sources_unchanged'] and receipt['binaries_unchanged']
    matches = re.findall(r'test result: .*? (\d+) passed; (\d+) failed; (\d+) ignored;',
                         (scratch / (label + '.stdout')).read_text())
    assert len(matches) == 1
    counts = tuple(map(int, matches[0]))
    assert counts == expected, (label, counts, expected)
    assert receipt['exit_code'] == (101 if counts[1] else 0)
    summary[label] = dict(passed=counts[0], failed=counts[1], ignored=counts[2],
                          exit_code=receipt['exit_code'], seconds=receipt['seconds'])
for label in ['build', 'final-build', 'verified-build', 'scoped-build', 'verified-strict']:
    receipt = json.loads((scratch / (label + '.json')).read_text())
    assert receipt['sources_unchanged'] and receipt['binaries_unchanged']
    assert receipt['exit_code'] == 0
    summary[label] = dict(exit_code=0, seconds=receipt['seconds'])
for name in ['source-frozen.json', 'scoped-frozen.json']:
    for path, pin in json.loads((scratch / name).read_text()).items():
        data = Path(path).read_bytes()
        assert pin == dict(bytes=len(data), sha256=hashlib.sha256(data).hexdigest())
result = dict(counts=summary, all_sources_and_executed_binaries_stable=True,
              full_stages_existing_passed=203, full_stages_split_passed=4,
              full_stages_split_failed=3, runtime_multi_output_graph_enabled=False,
              acceptance_credit=False)
out = scratch / 'regression-summary.json'
assert not out.exists()
out.write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result, indent=2))
