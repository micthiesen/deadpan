# Integration constraints after the cold-demand audit

Design notes only. No planner implementation, resource-fit result or acceptance
credit. The two research notes remain the exact source audit.

The next useful code milestone is shared Components policy/callback decisions,
with an oracle against both constant and dynamic numerical execution. Keep
numeric failure as an early refusal: it may shorten a structural demand schedule,
but cannot add a callback. A hand-copied policy mixer would make the eventual
resource proof vulnerable to semantic drift. This milestone must leave runtime
graph reads scalar.

Before batching, compute one cold structural demand fold. Sequential preparation
composition needs retained deltas plus peak scratch, not a sum of every transient:
combine A then B using retained=A.retained+B.retained and
peak=max(A.peak,A.retained+B.peak). Descendant temporal execution stays scalar
while one current group owns simultaneous borrowed histories. Count resulting
required tiles, projected/ordinary outputs, cache payload and constructor states,
not only the extra history buffers. Exact ancestry/grid and permission masks are
part of demand identity. No equal descriptor may replace a sealed projected
identity or exact source/clock admission.

For missing wet processors, after this lifetime fix a conservative order-independent
native term is the sum of missing retained bounds plus the largest missing
constructor-only excess. Full preparation remains required at the actual
constructor; this estimate is only an eligibility proof and must not be charged
again as active storage. Keep all existing separately accounted/excluded buffers
under their current policy. The budget is PCM-equivalent ownership, not RSS.

A first cold capability gate may refuse every intrinsic stretch/projected path
before allocating extra histories and use scalar execution. Check live compiled
inputs and all relevant historical timing/binding layouts; plain unity Preserve
Partitions are transparent, so an authored enum check is wrong. Query-boundary
assertions are useful defense in depth but arrive too late to establish cold
eligibility. The researched Source/Sequence/Repeat failure branches appear to be
in the possible first domain; no test proves that yet. Retime and remaining matrix
coverage are still required before general Split can be enabled.

Planning itself performs real work. Charge actual compilation, queries, visits,
policy walks and selector work under the existing budgets. Do not put demand
planning into an optional cache-key scope simply to avoid canonical work limits,
refund it after fallback, or retain a discovery/query graph to conceal its cost.
Reusing the current chunk's already-required metadata is useful; retaining every
future chunk's query view would increase the construction peak. Prove that the
new planner fits the current successful cases too, not only that the batch would
save work in a failing case. Select scalar execution before prefix/PCM work;
failed batch followed by scalar retry remains rejected.
