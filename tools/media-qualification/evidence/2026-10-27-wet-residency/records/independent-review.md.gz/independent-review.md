# Independent review: wet processor retained residency

Scope: the supplied `wet-residency.patch` against its frozen before snapshots, limited to `finite_wet.rs`, `event_returns.rs`, and new `event_returns/tests.rs`. The unrelated Components and Split work was excluded.

## Findings

No supported correctness findings. The preparation bound remains the previous complete native bound plus both Rust time-domain kernels and the 1 MiB temporary network allowance. `prepare_shared_wet` still spends the same history work, calls `make_room` with the full preparation amount, constructs synchronously, and checks cancellation/deadline before publishing. Successful publication charges only the retained native bound to `active_frames` and the owning graph's `resident`; the unchanged outer graph cleanup subtracts that amount on both success and error. The production wrapper selects effect and filter slot consistently, and repeated calls to a populated slot do not charge again.

The helper's separate `effect` and `filter` parameters could be mismatched by a future internal caller, but the only production caller maps each effect directly to its corresponding slot. I do not consider that a current defect.

## Verification limits and material gaps

- No Cargo build or tests were run, per instruction and because the main Cargo build is active. The worker also made no compilation claim.
- The test fixture is source-independent of the inherited Graph/cache WIP and its cleanup test calls the real `read_shared_input` path. Constructor cancellation/timeout/work refusal and insufficient full-preparation headroom are covered.
- There is no injected cancellation or processing failure after successful native construction in the new tests, nor native allocation-failure injection in this patch. The existing causal-filter ABI witness cited in `research.md` was not rerun here. Source control flow shows the post-construction cancellation check precedes ledger publication, so the constructed local processor drops without an increment on that path.

## Supplemental review: late cold one-short-work teardown case

Reviewed the final delta in `event_returns/tests.rs` (production files are reported byte-identical to the initial passing patch). The strengthened test records the successful cold `read_shared_input` plan-work total, gives a fresh `StageAudio` the same request with exactly one fewer unit available, and asserts the final billed count remains `MAX_PLAN_WORK_PER_READ - 1` when `spend_plan_work` refuses the next unit. With an empty fresh renderer and the same immutable plan/request, this targets the refusal after the wet processor was constructed and published; the fixture's nonidentity -6 dB send has a billed transfer after the wet callback. The expected outer cleanup then restores `active_frames` and provider count. The test logic/comment are consistent with the stated lifecycle; no new finding.

This late test-only delta has not been compiled or run in this review. The reported initial 213-pass result predates it, so final-delta verification remains with the active main build.

## Supplemental review: corrected accepted-work assertion

The strengthened test initially failed only its exact plan-work assertion: observed `16,777,216` (`MAX_PLAN_WORK_PER_READ`) versus the expected `16,777,215`; the other 212 tests and strict checks passed. The assertion was corrected to expect the cap. This matches the accounting: the last accepted charge reaches the cap, and the subsequent one-unit spend is refused without advancing the counter. No production code changed. The corrected test is awaiting the active verified build; I did not rerun Cargo.
