BEGIN TRANSACTION;
CREATE TABLE generation_attempt_heads (
    request_id TEXT PRIMARY KEY REFERENCES generation_requests(request_id),
    high_water INTEGER NOT NULL CHECK (high_water BETWEEN 1 AND 9223372036854775807),
    latest_attempt_id TEXT NOT NULL,
    selected_ready_attempt_id TEXT,
    FOREIGN KEY (request_id,latest_attempt_id)
        REFERENCES generation_attempts(request_id,attempt_id),
    FOREIGN KEY (request_id,selected_ready_attempt_id)
        REFERENCES generation_attempts(request_id,attempt_id)
) STRICT;
CREATE TABLE generation_attempts (
    request_id TEXT NOT NULL REFERENCES generation_requests(request_id),
    attempt_id TEXT NOT NULL,
    ordinal INTEGER NOT NULL CHECK (ordinal BETWEEN 1 AND 9223372036854775807),
    cancellation_token TEXT NOT NULL,
    state TEXT NOT NULL CHECK (state IN (
        'queued','preflight','loading','running','validating','ready','failed','cancelling','cancelled'
    )),
    worker_stage TEXT CHECK (worker_stage IS NULL OR worker_stage IN (
        'preflight','runtime_loading','model_loading','conditioning','inference',
        'decoding','encoding','worker_validation'
    )),
    transition_sequence INTEGER NOT NULL
        CHECK (transition_sequence BETWEEN 1 AND 9223372036854775807),
    cancel_response TEXT CHECK (cancel_response IS NULL OR cancel_response IN ('cancelled','completed')),
    worker_candidate TEXT CHECK (worker_candidate IS NULL OR json_valid(worker_candidate)),
    failure_origin TEXT CHECK (failure_origin IS NULL OR failure_origin IN ('worker','host')),
    failure_code TEXT,
    failure_detail TEXT,
    PRIMARY KEY (request_id,attempt_id),
    UNIQUE (request_id,ordinal),
    CHECK ((failure_origin IS NULL) = (failure_code IS NULL)),
    CHECK ((failure_origin IS NULL) = (failure_detail IS NULL)),
    CHECK (cancel_response!='completed' OR worker_candidate IS NOT NULL)
) STRICT;
CREATE TABLE generation_bundle_receipts (
    request_id TEXT NOT NULL,
    attempt_id TEXT NOT NULL,
    bundle TEXT NOT NULL CHECK (json_valid(bundle)),
    availability TEXT NOT NULL CHECK (availability IN ('present','evicted')),
    PRIMARY KEY (request_id,attempt_id),
    FOREIGN KEY (request_id,attempt_id)
        REFERENCES generation_attempts(request_id,attempt_id)
) STRICT;
CREATE TABLE generation_candidate_receipts (
    request_id TEXT NOT NULL,
    attempt_id TEXT NOT NULL,
    staged_ref TEXT NOT NULL UNIQUE,
    sha256 TEXT NOT NULL,
    byte_length INTEGER NOT NULL CHECK (byte_length BETWEEN 1 AND 9223372036854775807),
    video TEXT NOT NULL CHECK (json_valid(video)),
    provider TEXT NOT NULL CHECK (json_valid(provider)),
    validator_id TEXT NOT NULL,
    validator_version TEXT NOT NULL,
    availability TEXT NOT NULL CHECK (availability IN ('present','evicted')),
    PRIMARY KEY (request_id,attempt_id),
    FOREIGN KEY (request_id,attempt_id)
        REFERENCES generation_attempts(request_id,attempt_id)
) STRICT;
CREATE TABLE generation_requests (
    request_id TEXT PRIMARY KEY,
    project_id TEXT NOT NULL,
    hold_id TEXT NOT NULL,
    request_version INTEGER NOT NULL
        CHECK (request_version BETWEEN 1 AND 9223372036854775807),
    origin_revision TEXT NOT NULL REFERENCES revisions(id),
    context_sha256 TEXT NOT NULL,
    constraints TEXT NOT NULL CHECK (json_valid(constraints)),
    provider TEXT NOT NULL CHECK (json_valid(provider)),
    bridge_plan TEXT CHECK (bridge_plan IS NULL OR json_valid(bridge_plan)),
    relevance TEXT NOT NULL CHECK (relevance IN ('current','stale','detached')),
    UNIQUE (hold_id, request_version)
) STRICT;
CREATE TABLE history (
            id INTEGER PRIMARY KEY,
            parent_id INTEGER REFERENCES history(id),
            revision_id TEXT NOT NULL REFERENCES revisions(id),
            request TEXT NOT NULL CHECK (json_valid(request)),
            edit TEXT NOT NULL CHECK (json_valid(edit))
        ) STRICT;
INSERT INTO "history" VALUES(1,NULL,'18e36cb1-afc9-407d-b7ab-d9df09d17634','{"project_id":"2dbbdca8-d451-4639-8322-38047d33d7ff","expected_revision":"94af3121-2605-4161-9413-5c27a97c5287","new_revision":"18e36cb1-afc9-407d-b7ab-d9df09d17634","command":{"command":"import_source","id":"8b234d1f-32dd-40fb-b2fa-b743ced54a3d","asset":{"label":"cfr-bframes.mp4","content_hash":"blake3:16614ec12d06396d3c0f0e7b91cc902c6dc30ad89c28d74b805cf64dc60d8aa1","video":{"start":{"ticks":0,"time_base":{"numerator":1,"denominator":30000}},"end":{"ticks":120120,"time_base":{"numerator":1,"denominator":30000}}},"audio":{"start":{"ticks":0,"time_base":{"numerator":1,"denominator":48000}},"end":{"ticks":192192,"time_base":{"numerator":1,"denominator":48000}}},"still_image":false,"frame_count":120,"source_qualification":"c6bc3e81ab69906267164469d11739cf1363eea546436761ddd219069ed496b6"},"insertion":{"parent":"671d71ba-a1f9-4489-933a-9e70b0445f8e","index":0,"node":"a730de52-3bb9-4b2f-9d36-3057a494e00e","label":"cfr-bframes.mp4","source":{"duration":120,"edit_window":{"start":{"numerator":"0","denominator":"1"},"end":{"numerator":"120","denominator":"1"}},"video":{"type":"stream","asset":"8b234d1f-32dd-40fb-b2fa-b743ced54a3d","span":{"start":{"ticks":0,"time_base":{"numerator":1,"denominator":30000}},"end":{"ticks":120120,"time_base":{"numerator":1,"denominator":30000}}}},"video_mapping":{"type":"placement","start":{"numerator":"0","denominator":"1"},"frames":{"numerator":"120","denominator":"1"},"endpoints":"hold_adjacent"},"audio":{"asset":"8b234d1f-32dd-40fb-b2fa-b743ced54a3d","span":{"start":{"ticks":0,"time_base":{"numerator":1,"denominator":48000}},"end":{"ticks":192192,"time_base":{"numerator":1,"denominator":48000}}}},"audio_mapping":{"type":"placement","start":{"numerator":"0","denominator":"1"},"frames":{"numerator":"120","denominator":"1"}},"link":"linked","audio_offset":0}},"primary":{"type":"adopt","basis":{"width":320,"height":180,"frame_rate":{"numerator":30000,"denominator":1001},"color_policy":"sdr_rec709"}}}}','{"forward":{"project_id":"2dbbdca8-d451-4639-8322-38047d33d7ff","from_revision":"94af3121-2605-4161-9413-5c27a97c5287","to_revision":"18e36cb1-afc9-407d-b7ab-d9df09d17634","presentation":{"before":{"basis":{"width":1920,"height":1080,"frame_rate":{"numerator":30,"denominator":1},"color_policy":"sdr_rec709"},"state":{"rate_origin":"provisional","geometry_origin":"default","primary":null}},"after":{"basis":{"width":320,"height":180,"frame_rate":{"numerator":30000,"denominator":1001},"color_policy":"sdr_rec709"},"state":{"rate_origin":"primary_source","geometry_origin":"primary_source","primary":{"asset":"8b234d1f-32dd-40fb-b2fa-b743ced54a3d","qualification":"c6bc3e81ab69906267164469d11739cf1363eea546436761ddd219069ed496b6"}}}},"nodes":{"671d71ba-a1f9-4489-933a-9e70b0445f8e":{"before":{"label":"Sequence","kind":{"type":"sequence","children":[]}},"after":{"label":"Sequence","kind":{"type":"sequence","children":["a730de52-3bb9-4b2f-9d36-3057a494e00e"]}}},"a730de52-3bb9-4b2f-9d36-3057a494e00e":{"before":null,"after":{"label":"cfr-bframes.mp4","kind":{"type":"source","source":{"duration":120,"edit_window":{"start":{"numerator":"0","denominator":"1"},"end":{"numerator":"120","denominator":"1"}},"video":{"type":"stream","asset":"8b234d1f-32dd-40fb-b2fa-b743ced54a3d","span":{"start":{"ticks":0,"time_base":{"numerator":1,"denominator":30000}},"end":{"ticks":120120,"time_base":{"numerator":1,"denominator":30000}}}},"video_mapping":{"type":"placement","start":{"numerator":"0","denominator":"1"},"frames":{"numerator":"120","denominator":"1"},"endpoints":"hold_adjacent"},"audio":{"asset":"8b234d1f-32dd-40fb-b2fa-b743ced54a3d","span":{"start":{"ticks":0,"time_base":{"numerator":1,"denominator":48000}},"end":{"ticks":192192,"time_base":{"numerator":1,"denominator":48000}}}},"audio_mapping":{"type":"placement","start":{"numerator":"0","denominator":"1"},"frames":{"numerator":"120","denominator":"1"}},"link":"linked","audio_offset":0}}}}},"assets":{"8b234d1f-32dd-40fb-b2fa-b743ced54a3d":{"before":null,"after":{"label":"cfr-bframes.mp4","content_hash":"blake3:16614ec12d06396d3c0f0e7b91cc902c6dc30ad89c28d74b805cf64dc60d8aa1","video":{"start":{"ticks":0,"time_base":{"numerator":1,"denominator":30000}},"end":{"ticks":120120,"time_base":{"numerator":1,"denominator":30000}}},"audio":{"start":{"ticks":0,"time_base":{"numerator":1,"denominator":48000}},"end":{"ticks":192192,"time_base":{"numerator":1,"denominator":48000}}},"still_image":false,"frame_count":120,"source_qualification":"c6bc3e81ab69906267164469d11739cf1363eea546436761ddd219069ed496b6"}}},"marks":{},"overrides":{}},"inverse":{"project_id":"2dbbdca8-d451-4639-8322-38047d33d7ff","from_revision":"18e36cb1-afc9-407d-b7ab-d9df09d17634","to_revision":"94af3121-2605-4161-9413-5c27a97c5287","presentation":{"before":{"basis":{"width":320,"height":180,"frame_rate":{"numerator":30000,"denominator":1001},"color_policy":"sdr_rec709"},"state":{"rate_origin":"primary_source","geometry_origin":"primary_source","primary":{"asset":"8b234d1f-32dd-40fb-b2fa-b743ced54a3d","qualification":"c6bc3e81ab69906267164469d11739cf1363eea546436761ddd219069ed496b6"}}},"after":{"basis":{"width":1920,"height":1080,"frame_rate":{"numerator":30,"denominator":1},"color_policy":"sdr_rec709"},"state":{"rate_origin":"provisional","geometry_origin":"default","primary":null}}},"nodes":{"671d71ba-a1f9-4489-933a-9e70b0445f8e":{"before":{"label":"Sequence","kind":{"type":"sequence","children":["a730de52-3bb9-4b2f-9d36-3057a494e00e"]}},"after":{"label":"Sequence","kind":{"type":"sequence","children":[]}}},"a730de52-3bb9-4b2f-9d36-3057a494e00e":{"before":{"label":"cfr-bframes.mp4","kind":{"type":"source","source":{"duration":120,"edit_window":{"start":{"numerator":"0","denominator":"1"},"end":{"numerator":"120","denominator":"1"}},"video":{"type":"stream","asset":"8b234d1f-32dd-40fb-b2fa-b743ced54a3d","span":{"start":{"ticks":0,"time_base":{"numerator":1,"denominator":30000}},"end":{"ticks":120120,"time_base":{"numerator":1,"denominator":30000}}}},"video_mapping":{"type":"placement","start":{"numerator":"0","denominator":"1"},"frames":{"numerator":"120","denominator":"1"},"endpoints":"hold_adjacent"},"audio":{"asset":"8b234d1f-32dd-40fb-b2fa-b743ced54a3d","span":{"start":{"ticks":0,"time_base":{"numerator":1,"denominator":48000}},"end":{"ticks":192192,"time_base":{"numerator":1,"denominator":48000}}}},"audio_mapping":{"type":"placement","start":{"numerator":"0","denominator":"1"},"frames":{"numerator":"120","denominator":"1"}},"link":"linked","audio_offset":0}}},"after":null}},"assets":{"8b234d1f-32dd-40fb-b2fa-b743ced54a3d":{"before":{"label":"cfr-bframes.mp4","content_hash":"blake3:16614ec12d06396d3c0f0e7b91cc902c6dc30ad89c28d74b805cf64dc60d8aa1","video":{"start":{"ticks":0,"time_base":{"numerator":1,"denominator":30000}},"end":{"ticks":120120,"time_base":{"numerator":1,"denominator":30000}}},"audio":{"start":{"ticks":0,"time_base":{"numerator":1,"denominator":48000}},"end":{"ticks":192192,"time_base":{"numerator":1,"denominator":48000}}},"still_image":false,"frame_count":120,"source_qualification":"c6bc3e81ab69906267164469d11739cf1363eea546436761ddd219069ed496b6"},"after":null}},"marks":{},"overrides":{}},"changed_ids":["671d71ba-a1f9-4489-933a-9e70b0445f8e","a730de52-3bb9-4b2f-9d36-3057a494e00e"],"duration_delta":120,"description":"Import source media"}');
INSERT INTO "history" VALUES(2,1,'052ce465-5039-49b9-80bf-a7dfaa7129af','{"project_id":"2dbbdca8-d451-4639-8322-38047d33d7ff","expected_revision":"18e36cb1-afc9-407d-b7ab-d9df09d17634","new_revision":"052ce465-5039-49b9-80bf-a7dfaa7129af","command":{"command":"splice_source","parent":"671d71ba-a1f9-4489-933a-9e70b0445f8e","index":1,"source":{"duration":8,"edit_window":{"start":{"numerator":"0","denominator":"1"},"end":{"numerator":"8","denominator":"1"}},"video":{"type":"stream","asset":"8b234d1f-32dd-40fb-b2fa-b743ced54a3d","span":{"start":{"ticks":0,"time_base":{"numerator":1,"denominator":30000}},"end":{"ticks":120120,"time_base":{"numerator":1,"denominator":30000}}}},"video_mapping":{"type":"selected_placement","start":{"numerator":"-5","denominator":"1"},"frames":{"numerator":"120","denominator":"1"},"selection":{"start":{"numerator":"0","denominator":"1"},"end":{"numerator":"8","denominator":"1"}},"endpoints":"hold_adjacent"},"audio":{"asset":"8b234d1f-32dd-40fb-b2fa-b743ced54a3d","span":{"start":{"ticks":0,"time_base":{"numerator":1,"denominator":48000}},"end":{"ticks":192192,"time_base":{"numerator":1,"denominator":48000}}}},"audio_mapping":{"type":"selected_placement","start":{"numerator":"-5","denominator":"1"},"frames":{"numerator":"120","denominator":"1"},"selection":{"start":{"numerator":"0","denominator":"1"},"end":{"numerator":"8","denominator":"1"}}},"link":"linked","audio_offset":0},"id":"91353585-2a36-423c-bed0-6a218ea8153a","label":"cfr-bframes.mp4 [5..13)","timing":{"allocation":"052ce465-5039-49b9-80bf-a7dfaa7129af","ordinal":0}}}','{"forward":{"project_id":"2dbbdca8-d451-4639-8322-38047d33d7ff","from_revision":"18e36cb1-afc9-407d-b7ab-d9df09d17634","to_revision":"052ce465-5039-49b9-80bf-a7dfaa7129af","nodes":{"671d71ba-a1f9-4489-933a-9e70b0445f8e":{"before":{"label":"Sequence","kind":{"type":"sequence","children":["a730de52-3bb9-4b2f-9d36-3057a494e00e"]}},"after":{"label":"Sequence","kind":{"type":"sequence","children":["a730de52-3bb9-4b2f-9d36-3057a494e00e","91353585-2a36-423c-bed0-6a218ea8153a"]}}},"91353585-2a36-423c-bed0-6a218ea8153a":{"before":null,"after":{"label":"cfr-bframes.mp4 [5..13)","kind":{"type":"source","source":{"duration":8,"edit_window":{"start":{"numerator":"0","denominator":"1"},"end":{"numerator":"8","denominator":"1"}},"video":{"type":"stream","asset":"8b234d1f-32dd-40fb-b2fa-b743ced54a3d","span":{"start":{"ticks":0,"time_base":{"numerator":1,"denominator":30000}},"end":{"ticks":120120,"time_base":{"numerator":1,"denominator":30000}}}},"video_mapping":{"type":"selected_placement","start":{"numerator":"-5","denominator":"1"},"frames":{"numerator":"120","denominator":"1"},"selection":{"start":{"numerator":"0","denominator":"1"},"end":{"numerator":"8","denominator":"1"}},"endpoints":"hold_adjacent"},"audio":{"asset":"8b234d1f-32dd-40fb-b2fa-b743ced54a3d","span":{"start":{"ticks":0,"time_base":{"numerator":1,"denominator":48000}},"end":{"ticks":192192,"time_base":{"numerator":1,"denominator":48000}}}},"audio_mapping":{"type":"selected_placement","start":{"numerator":"-5","denominator":"1"},"frames":{"numerator":"120","denominator":"1"},"selection":{"start":{"numerator":"0","denominator":"1"},"end":{"numerator":"8","denominator":"1"}}},"link":"linked","audio_offset":0}}}}},"assets":{},"marks":{},"overrides":{},"audio_bindings":{"before":{"timings":[],"bindings":{}},"after":{"timings":[{"id":{"allocation":"052ce465-5039-49b9-80bf-a7dfaa7129af","ordinal":0},"layout":{"root":"671d71ba-a1f9-4489-933a-9e70b0445f8e","rate":{"numerator":30000,"denominator":1001},"nodes":{"671d71ba-a1f9-4489-933a-9e70b0445f8e":{"duration":120,"edges":{"node_start":"automatic","node_end":"automatic","source_placement_start":"automatic","source_placement_end":"automatic","repeat_gap_start":"automatic","repeat_gap_end":"automatic"},"kind":{"type":"sequence","children":["a730de52-3bb9-4b2f-9d36-3057a494e00e"]}},"a730de52-3bb9-4b2f-9d36-3057a494e00e":{"duration":120,"edges":{"node_start":"automatic","node_end":"automatic","source_placement_start":"automatic","source_placement_end":"automatic","repeat_gap_start":"automatic","repeat_gap_end":"automatic"},"kind":{"type":"source","placement":{"start":{"numerator":"0","denominator":"1"},"end":{"numerator":"120","denominator":"1"}}}}},"overrides":{}}}],"bindings":{"a730de52-3bb9-4b2f-9d36-3057a494e00e":{"lattice":{"reference":{"timing":{"allocation":"052ce465-5039-49b9-80bf-a7dfaa7129af","ordinal":0},"root":{"type":"project_root_round_even"},"physical":"a730de52-3bb9-4b2f-9d36-3057a494e00e"},"arguments":[],"births":[]},"resume":null}}}}},"inverse":{"project_id":"2dbbdca8-d451-4639-8322-38047d33d7ff","from_revision":"052ce465-5039-49b9-80bf-a7dfaa7129af","to_revision":"18e36cb1-afc9-407d-b7ab-d9df09d17634","nodes":{"671d71ba-a1f9-4489-933a-9e70b0445f8e":{"before":{"label":"Sequence","kind":{"type":"sequence","children":["a730de52-3bb9-4b2f-9d36-3057a494e00e","91353585-2a36-423c-bed0-6a218ea8153a"]}},"after":{"label":"Sequence","kind":{"type":"sequence","children":["a730de52-3bb9-4b2f-9d36-3057a494e00e"]}}},"91353585-2a36-423c-bed0-6a218ea8153a":{"before":{"label":"cfr-bframes.mp4 [5..13)","kind":{"type":"source","source":{"duration":8,"edit_window":{"start":{"numerator":"0","denominator":"1"},"end":{"numerator":"8","denominator":"1"}},"video":{"type":"stream","asset":"8b234d1f-32dd-40fb-b2fa-b743ced54a3d","span":{"start":{"ticks":0,"time_base":{"numerator":1,"denominator":30000}},"end":{"ticks":120120,"time_base":{"numerator":1,"denominator":30000}}}},"video_mapping":{"type":"selected_placement","start":{"numerator":"-5","denominator":"1"},"frames":{"numerator":"120","denominator":"1"},"selection":{"start":{"numerator":"0","denominator":"1"},"end":{"numerator":"8","denominator":"1"}},"endpoints":"hold_adjacent"},"audio":{"asset":"8b234d1f-32dd-40fb-b2fa-b743ced54a3d","span":{"start":{"ticks":0,"time_base":{"numerator":1,"denominator":48000}},"end":{"ticks":192192,"time_base":{"numerator":1,"denominator":48000}}}},"audio_mapping":{"type":"selected_placement","start":{"numerator":"-5","denominator":"1"},"frames":{"numerator":"120","denominator":"1"},"selection":{"start":{"numerator":"0","denominator":"1"},"end":{"numerator":"8","denominator":"1"}}},"link":"linked","audio_offset":0}}},"after":null}},"assets":{},"marks":{},"overrides":{},"audio_bindings":{"before":{"timings":[{"id":{"allocation":"052ce465-5039-49b9-80bf-a7dfaa7129af","ordinal":0},"layout":{"root":"671d71ba-a1f9-4489-933a-9e70b0445f8e","rate":{"numerator":30000,"denominator":1001},"nodes":{"671d71ba-a1f9-4489-933a-9e70b0445f8e":{"duration":120,"edges":{"node_start":"automatic","node_end":"automatic","source_placement_start":"automatic","source_placement_end":"automatic","repeat_gap_start":"automatic","repeat_gap_end":"automatic"},"kind":{"type":"sequence","children":["a730de52-3bb9-4b2f-9d36-3057a494e00e"]}},"a730de52-3bb9-4b2f-9d36-3057a494e00e":{"duration":120,"edges":{"node_start":"automatic","node_end":"automatic","source_placement_start":"automatic","source_placement_end":"automatic","repeat_gap_start":"automatic","repeat_gap_end":"automatic"},"kind":{"type":"source","placement":{"start":{"numerator":"0","denominator":"1"},"end":{"numerator":"120","denominator":"1"}}}}},"overrides":{}}}],"bindings":{"a730de52-3bb9-4b2f-9d36-3057a494e00e":{"lattice":{"reference":{"timing":{"allocation":"052ce465-5039-49b9-80bf-a7dfaa7129af","ordinal":0},"root":{"type":"project_root_round_even"},"physical":"a730de52-3bb9-4b2f-9d36-3057a494e00e"},"arguments":[],"births":[]},"resume":null}}},"after":{"timings":[],"bindings":{}}}},"changed_ids":["671d71ba-a1f9-4489-933a-9e70b0445f8e","91353585-2a36-423c-bed0-6a218ea8153a","a730de52-3bb9-4b2f-9d36-3057a494e00e"],"duration_delta":8,"description":"Paste source moment"}');
INSERT INTO "history" VALUES(3,1,'55d7f95c-9d25-43ae-bb16-97f2b104cd64','{"project_id":"2dbbdca8-d451-4639-8322-38047d33d7ff","expected_revision":"c9b006f2-cc9e-45a2-818e-9ec94aefd2ea","new_revision":"55d7f95c-9d25-43ae-bb16-97f2b104cd64","command":{"command":"splice_source","parent":"671d71ba-a1f9-4489-933a-9e70b0445f8e","index":0,"source":{"duration":5,"edit_window":{"start":{"numerator":"0","denominator":"1"},"end":{"numerator":"5","denominator":"1"}},"video":{"type":"stream","asset":"8b234d1f-32dd-40fb-b2fa-b743ced54a3d","span":{"start":{"ticks":0,"time_base":{"numerator":1,"denominator":30000}},"end":{"ticks":120120,"time_base":{"numerator":1,"denominator":30000}}}},"video_mapping":{"type":"selected_placement","start":{"numerator":"-30","denominator":"1"},"frames":{"numerator":"120","denominator":"1"},"selection":{"start":{"numerator":"0","denominator":"1"},"end":{"numerator":"5","denominator":"1"}},"endpoints":"hold_adjacent"},"audio":{"asset":"8b234d1f-32dd-40fb-b2fa-b743ced54a3d","span":{"start":{"ticks":0,"time_base":{"numerator":1,"denominator":48000}},"end":{"ticks":192192,"time_base":{"numerator":1,"denominator":48000}}}},"audio_mapping":{"type":"selected_placement","start":{"numerator":"-30","denominator":"1"},"frames":{"numerator":"120","denominator":"1"},"selection":{"start":{"numerator":"0","denominator":"1"},"end":{"numerator":"5","denominator":"1"}}},"link":"linked","audio_offset":0},"id":"a23d334c-36c2-49a5-a4ea-c83b554a4891","label":"cfr-bframes.mp4 [30..35)","timing":{"allocation":"55d7f95c-9d25-43ae-bb16-97f2b104cd64","ordinal":0}}}','{"forward":{"project_id":"2dbbdca8-d451-4639-8322-38047d33d7ff","from_revision":"c9b006f2-cc9e-45a2-818e-9ec94aefd2ea","to_revision":"55d7f95c-9d25-43ae-bb16-97f2b104cd64","nodes":{"671d71ba-a1f9-4489-933a-9e70b0445f8e":{"before":{"label":"Sequence","kind":{"type":"sequence","children":["a730de52-3bb9-4b2f-9d36-3057a494e00e"]}},"after":{"label":"Sequence","kind":{"type":"sequence","children":["a23d334c-36c2-49a5-a4ea-c83b554a4891","a730de52-3bb9-4b2f-9d36-3057a494e00e"]}}},"a23d334c-36c2-49a5-a4ea-c83b554a4891":{"before":null,"after":{"label":"cfr-bframes.mp4 [30..35)","kind":{"type":"source","source":{"duration":5,"edit_window":{"start":{"numerator":"0","denominator":"1"},"end":{"numerator":"5","denominator":"1"}},"video":{"type":"stream","asset":"8b234d1f-32dd-40fb-b2fa-b743ced54a3d","span":{"start":{"ticks":0,"time_base":{"numerator":1,"denominator":30000}},"end":{"ticks":120120,"time_base":{"numerator":1,"denominator":30000}}}},"video_mapping":{"type":"selected_placement","start":{"numerator":"-30","denominator":"1"},"frames":{"numerator":"120","denominator":"1"},"selection":{"start":{"numerator":"0","denominator":"1"},"end":{"numerator":"5","denominator":"1"}},"endpoints":"hold_adjacent"},"audio":{"asset":"8b234d1f-32dd-40fb-b2fa-b743ced54a3d","span":{"start":{"ticks":0,"time_base":{"numerator":1,"denominator":48000}},"end":{"ticks":192192,"time_base":{"numerator":1,"denominator":48000}}}},"audio_mapping":{"type":"selected_placement","start":{"numerator":"-30","denominator":"1"},"frames":{"numerator":"120","denominator":"1"},"selection":{"start":{"numerator":"0","denominator":"1"},"end":{"numerator":"5","denominator":"1"}}},"link":"linked","audio_offset":0}}}}},"assets":{},"marks":{},"overrides":{},"audio_bindings":{"before":{"timings":[],"bindings":{}},"after":{"timings":[{"id":{"allocation":"55d7f95c-9d25-43ae-bb16-97f2b104cd64","ordinal":0},"layout":{"root":"671d71ba-a1f9-4489-933a-9e70b0445f8e","rate":{"numerator":30000,"denominator":1001},"nodes":{"671d71ba-a1f9-4489-933a-9e70b0445f8e":{"duration":120,"edges":{"node_start":"automatic","node_end":"automatic","source_placement_start":"automatic","source_placement_end":"automatic","repeat_gap_start":"automatic","repeat_gap_end":"automatic"},"kind":{"type":"sequence","children":["a730de52-3bb9-4b2f-9d36-3057a494e00e"]}},"a730de52-3bb9-4b2f-9d36-3057a494e00e":{"duration":120,"edges":{"node_start":"automatic","node_end":"automatic","source_placement_start":"automatic","source_placement_end":"automatic","repeat_gap_start":"automatic","repeat_gap_end":"automatic"},"kind":{"type":"source","placement":{"start":{"numerator":"0","denominator":"1"},"end":{"numerator":"120","denominator":"1"}}}}},"overrides":{}}}],"bindings":{"a730de52-3bb9-4b2f-9d36-3057a494e00e":{"lattice":{"reference":{"timing":{"allocation":"55d7f95c-9d25-43ae-bb16-97f2b104cd64","ordinal":0},"root":{"type":"project_root_round_even"},"physical":"a730de52-3bb9-4b2f-9d36-3057a494e00e"},"arguments":[],"births":[]},"resume":null,"reanchors":[{"placement":{"reference":{"timing":{"allocation":"55d7f95c-9d25-43ae-bb16-97f2b104cd64","ordinal":0},"root":{"type":"project_root_round_even"},"physical":"a730de52-3bb9-4b2f-9d36-3057a494e00e"},"arguments":[],"births":[]},"window":{"start":{"numerator":"0","denominator":"1"},"end":{"numerator":"120","denominator":"1"}}}]}}}}},"inverse":{"project_id":"2dbbdca8-d451-4639-8322-38047d33d7ff","from_revision":"55d7f95c-9d25-43ae-bb16-97f2b104cd64","to_revision":"c9b006f2-cc9e-45a2-818e-9ec94aefd2ea","nodes":{"671d71ba-a1f9-4489-933a-9e70b0445f8e":{"before":{"label":"Sequence","kind":{"type":"sequence","children":["a23d334c-36c2-49a5-a4ea-c83b554a4891","a730de52-3bb9-4b2f-9d36-3057a494e00e"]}},"after":{"label":"Sequence","kind":{"type":"sequence","children":["a730de52-3bb9-4b2f-9d36-3057a494e00e"]}}},"a23d334c-36c2-49a5-a4ea-c83b554a4891":{"before":{"label":"cfr-bframes.mp4 [30..35)","kind":{"type":"source","source":{"duration":5,"edit_window":{"start":{"numerator":"0","denominator":"1"},"end":{"numerator":"5","denominator":"1"}},"video":{"type":"stream","asset":"8b234d1f-32dd-40fb-b2fa-b743ced54a3d","span":{"start":{"ticks":0,"time_base":{"numerator":1,"denominator":30000}},"end":{"ticks":120120,"time_base":{"numerator":1,"denominator":30000}}}},"video_mapping":{"type":"selected_placement","start":{"numerator":"-30","denominator":"1"},"frames":{"numerator":"120","denominator":"1"},"selection":{"start":{"numerator":"0","denominator":"1"},"end":{"numerator":"5","denominator":"1"}},"endpoints":"hold_adjacent"},"audio":{"asset":"8b234d1f-32dd-40fb-b2fa-b743ced54a3d","span":{"start":{"ticks":0,"time_base":{"numerator":1,"denominator":48000}},"end":{"ticks":192192,"time_base":{"numerator":1,"denominator":48000}}}},"audio_mapping":{"type":"selected_placement","start":{"numerator":"-30","denominator":"1"},"frames":{"numerator":"120","denominator":"1"},"selection":{"start":{"numerator":"0","denominator":"1"},"end":{"numerator":"5","denominator":"1"}}},"link":"linked","audio_offset":0}}},"after":null}},"assets":{},"marks":{},"overrides":{},"audio_bindings":{"before":{"timings":[{"id":{"allocation":"55d7f95c-9d25-43ae-bb16-97f2b104cd64","ordinal":0},"layout":{"root":"671d71ba-a1f9-4489-933a-9e70b0445f8e","rate":{"numerator":30000,"denominator":1001},"nodes":{"671d71ba-a1f9-4489-933a-9e70b0445f8e":{"duration":120,"edges":{"node_start":"automatic","node_end":"automatic","source_placement_start":"automatic","source_placement_end":"automatic","repeat_gap_start":"automatic","repeat_gap_end":"automatic"},"kind":{"type":"sequence","children":["a730de52-3bb9-4b2f-9d36-3057a494e00e"]}},"a730de52-3bb9-4b2f-9d36-3057a494e00e":{"duration":120,"edges":{"node_start":"automatic","node_end":"automatic","source_placement_start":"automatic","source_placement_end":"automatic","repeat_gap_start":"automatic","repeat_gap_end":"automatic"},"kind":{"type":"source","placement":{"start":{"numerator":"0","denominator":"1"},"end":{"numerator":"120","denominator":"1"}}}}},"overrides":{}}}],"bindings":{"a730de52-3bb9-4b2f-9d36-3057a494e00e":{"lattice":{"reference":{"timing":{"allocation":"55d7f95c-9d25-43ae-bb16-97f2b104cd64","ordinal":0},"root":{"type":"project_root_round_even"},"physical":"a730de52-3bb9-4b2f-9d36-3057a494e00e"},"arguments":[],"births":[]},"resume":null,"reanchors":[{"placement":{"reference":{"timing":{"allocation":"55d7f95c-9d25-43ae-bb16-97f2b104cd64","ordinal":0},"root":{"type":"project_root_round_even"},"physical":"a730de52-3bb9-4b2f-9d36-3057a494e00e"},"arguments":[],"births":[]},"window":{"start":{"numerator":"0","denominator":"1"},"end":{"numerator":"120","denominator":"1"}}}]}}},"after":{"timings":[],"bindings":{}}}},"changed_ids":["671d71ba-a1f9-4489-933a-9e70b0445f8e","a23d334c-36c2-49a5-a4ea-c83b554a4891","a730de52-3bb9-4b2f-9d36-3057a494e00e"],"duration_delta":5,"description":"Paste source moment"}');
INSERT INTO "history" VALUES(4,1,'ae8bcc83-8832-4efa-95ec-7d5f3683fd01','{"project_id":"2dbbdca8-d451-4639-8322-38047d33d7ff","expected_revision":"d6643e11-0c07-4bc4-8885-c779aacdb3e5","new_revision":"ae8bcc83-8832-4efa-95ec-7d5f3683fd01","command":{"command":"insert_time","at":10,"hold":{"picture_context":{"canvases":[{"width":320,"height":180,"fit":"fit","layers":[]}]},"duration":11,"video":{"type":"freeze","asset":"8b234d1f-32dd-40fb-b2fa-b743ced54a3d","timestamp":{"ticks":9009,"time_base":{"numerator":1,"denominator":30000}}},"audio":{"type":"silence"}},"id":"42f2bd41-5536-4dd1-aa51-cf9d2d6dc9f4","identities":{"nodes":["b4f09a18-ca4a-46f7-8ce5-33844d8704b1","f42a5a41-1a92-4361-b3a7-0bc794f7edeb","59797bd3-4452-416c-9ab2-9c226f00c864"]},"timing":{"allocation":"ae8bcc83-8832-4efa-95ec-7d5f3683fd01","ordinal":0}}}','{"forward":{"project_id":"2dbbdca8-d451-4639-8322-38047d33d7ff","from_revision":"d6643e11-0c07-4bc4-8885-c779aacdb3e5","to_revision":"ae8bcc83-8832-4efa-95ec-7d5f3683fd01","nodes":{"42f2bd41-5536-4dd1-aa51-cf9d2d6dc9f4":{"before":null,"after":{"label":"Pause","kind":{"type":"hold","recipe":{"picture_context":{"canvases":[{"width":320,"height":180,"fit":"fit","layers":[]}]},"duration":11,"video":{"type":"freeze","asset":"8b234d1f-32dd-40fb-b2fa-b743ced54a3d","timestamp":{"ticks":9009,"time_base":{"numerator":1,"denominator":30000}}},"audio":{"type":"silence"}}}}},"59797bd3-4452-416c-9ab2-9c226f00c864":{"before":null,"after":{"label":"cfr-bframes.mp4","kind":{"type":"source","source":{"duration":120,"edit_window":{"start":{"numerator":"0","denominator":"1"},"end":{"numerator":"120","denominator":"1"}},"video":{"type":"stream","asset":"8b234d1f-32dd-40fb-b2fa-b743ced54a3d","span":{"start":{"ticks":0,"time_base":{"numerator":1,"denominator":30000}},"end":{"ticks":120120,"time_base":{"numerator":1,"denominator":30000}}}},"video_mapping":{"type":"placement","start":{"numerator":"0","denominator":"1"},"frames":{"numerator":"120","denominator":"1"},"endpoints":"hold_adjacent"},"audio":{"asset":"8b234d1f-32dd-40fb-b2fa-b743ced54a3d","span":{"start":{"ticks":0,"time_base":{"numerator":1,"denominator":48000}},"end":{"ticks":192192,"time_base":{"numerator":1,"denominator":48000}}}},"audio_mapping":{"type":"placement","start":{"numerator":"0","denominator":"1"},"frames":{"numerator":"120","denominator":"1"}},"link":"linked","audio_offset":0}}}},"671d71ba-a1f9-4489-933a-9e70b0445f8e":{"before":{"label":"Sequence","kind":{"type":"sequence","children":["a730de52-3bb9-4b2f-9d36-3057a494e00e"]}},"after":{"label":"Sequence","kind":{"type":"sequence","children":["b4f09a18-ca4a-46f7-8ce5-33844d8704b1","42f2bd41-5536-4dd1-aa51-cf9d2d6dc9f4","f42a5a41-1a92-4361-b3a7-0bc794f7edeb"]}}},"b4f09a18-ca4a-46f7-8ce5-33844d8704b1":{"before":null,"after":{"label":"cfr-bframes.mp4","kind":{"type":"retime","child":"a730de52-3bb9-4b2f-9d36-3057a494e00e","duration":10,"mapping":{"start":0,"end":10},"pitch":"preserve","purpose":"partition"}}},"f42a5a41-1a92-4361-b3a7-0bc794f7edeb":{"before":null,"after":{"label":"cfr-bframes.mp4","kind":{"type":"retime","child":"59797bd3-4452-416c-9ab2-9c226f00c864","duration":110,"mapping":{"start":10,"end":120},"pitch":"preserve","purpose":"partition"}}}},"assets":{},"marks":{},"overrides":{},"audio_lineage":{"59797bd3-4452-416c-9ab2-9c226f00c864":{"before":null,"after":{"allocation":"ae8bcc83-8832-4efa-95ec-7d5f3683fd01","origin":"a730de52-3bb9-4b2f-9d36-3057a494e00e"}},"a730de52-3bb9-4b2f-9d36-3057a494e00e":{"before":null,"after":{"allocation":"ae8bcc83-8832-4efa-95ec-7d5f3683fd01","origin":"a730de52-3bb9-4b2f-9d36-3057a494e00e"}}},"audio_bindings":{"before":{"timings":[],"bindings":{}},"after":{"timings":[{"id":{"allocation":"ae8bcc83-8832-4efa-95ec-7d5f3683fd01","ordinal":0},"layout":{"root":"671d71ba-a1f9-4489-933a-9e70b0445f8e","rate":{"numerator":30000,"denominator":1001},"nodes":{"671d71ba-a1f9-4489-933a-9e70b0445f8e":{"duration":120,"edges":{"node_start":"automatic","node_end":"automatic","source_placement_start":"automatic","source_placement_end":"automatic","repeat_gap_start":"automatic","repeat_gap_end":"automatic"},"kind":{"type":"sequence","children":["a730de52-3bb9-4b2f-9d36-3057a494e00e"]}},"a730de52-3bb9-4b2f-9d36-3057a494e00e":{"duration":120,"edges":{"node_start":"automatic","node_end":"automatic","source_placement_start":"automatic","source_placement_end":"automatic","repeat_gap_start":"automatic","repeat_gap_end":"automatic"},"kind":{"type":"source","placement":{"start":{"numerator":"0","denominator":"1"},"end":{"numerator":"120","denominator":"1"}}}}},"overrides":{}}}],"bindings":{"59797bd3-4452-416c-9ab2-9c226f00c864":{"lattice":{"reference":{"timing":{"allocation":"ae8bcc83-8832-4efa-95ec-7d5f3683fd01","ordinal":0},"root":{"type":"project_root_round_even"},"physical":"a730de52-3bb9-4b2f-9d36-3057a494e00e"},"arguments":[],"births":[]},"resume":{"local_boundary":{"numerator":"10","denominator":"1"},"phase":{"constant":{"numerator":"0","denominator":"1"},"terms":[{"placement":{"reference":{"timing":{"allocation":"ae8bcc83-8832-4efa-95ec-7d5f3683fd01","ordinal":0},"root":{"type":"project_root_round_even"},"physical":"a730de52-3bb9-4b2f-9d36-3057a494e00e"},"arguments":[],"births":[]},"from_local":{"numerator":"0","denominator":"1"},"to_local":{"numerator":"10","denominator":"1"}}]}}},"a730de52-3bb9-4b2f-9d36-3057a494e00e":{"lattice":{"reference":{"timing":{"allocation":"ae8bcc83-8832-4efa-95ec-7d5f3683fd01","ordinal":0},"root":{"type":"project_root_round_even"},"physical":"a730de52-3bb9-4b2f-9d36-3057a494e00e"},"arguments":[],"births":[]},"resume":null}}}}},"inverse":{"project_id":"2dbbdca8-d451-4639-8322-38047d33d7ff","from_revision":"ae8bcc83-8832-4efa-95ec-7d5f3683fd01","to_revision":"d6643e11-0c07-4bc4-8885-c779aacdb3e5","nodes":{"42f2bd41-5536-4dd1-aa51-cf9d2d6dc9f4":{"before":{"label":"Pause","kind":{"type":"hold","recipe":{"picture_context":{"canvases":[{"width":320,"height":180,"fit":"fit","layers":[]}]},"duration":11,"video":{"type":"freeze","asset":"8b234d1f-32dd-40fb-b2fa-b743ced54a3d","timestamp":{"ticks":9009,"time_base":{"numerator":1,"denominator":30000}}},"audio":{"type":"silence"}}}},"after":null},"59797bd3-4452-416c-9ab2-9c226f00c864":{"before":{"label":"cfr-bframes.mp4","kind":{"type":"source","source":{"duration":120,"edit_window":{"start":{"numerator":"0","denominator":"1"},"end":{"numerator":"120","denominator":"1"}},"video":{"type":"stream","asset":"8b234d1f-32dd-40fb-b2fa-b743ced54a3d","span":{"start":{"ticks":0,"time_base":{"numerator":1,"denominator":30000}},"end":{"ticks":120120,"time_base":{"numerator":1,"denominator":30000}}}},"video_mapping":{"type":"placement","start":{"numerator":"0","denominator":"1"},"frames":{"numerator":"120","denominator":"1"},"endpoints":"hold_adjacent"},"audio":{"asset":"8b234d1f-32dd-40fb-b2fa-b743ced54a3d","span":{"start":{"ticks":0,"time_base":{"numerator":1,"denominator":48000}},"end":{"ticks":192192,"time_base":{"numerator":1,"denominator":48000}}}},"audio_mapping":{"type":"placement","start":{"numerator":"0","denominator":"1"},"frames":{"numerator":"120","denominator":"1"}},"link":"linked","audio_offset":0}}},"after":null},"671d71ba-a1f9-4489-933a-9e70b0445f8e":{"before":{"label":"Sequence","kind":{"type":"sequence","children":["b4f09a18-ca4a-46f7-8ce5-33844d8704b1","42f2bd41-5536-4dd1-aa51-cf9d2d6dc9f4","f42a5a41-1a92-4361-b3a7-0bc794f7edeb"]}},"after":{"label":"Sequence","kind":{"type":"sequence","children":["a730de52-3bb9-4b2f-9d36-3057a494e00e"]}}},"b4f09a18-ca4a-46f7-8ce5-33844d8704b1":{"before":{"label":"cfr-bframes.mp4","kind":{"type":"retime","child":"a730de52-3bb9-4b2f-9d36-3057a494e00e","duration":10,"mapping":{"start":0,"end":10},"pitch":"preserve","purpose":"partition"}},"after":null},"f42a5a41-1a92-4361-b3a7-0bc794f7edeb":{"before":{"label":"cfr-bframes.mp4","kind":{"type":"retime","child":"59797bd3-4452-416c-9ab2-9c226f00c864","duration":110,"mapping":{"start":10,"end":120},"pitch":"preserve","purpose":"partition"}},"after":null}},"assets":{},"marks":{},"overrides":{},"audio_lineage":{"59797bd3-4452-416c-9ab2-9c226f00c864":{"before":{"allocation":"ae8bcc83-8832-4efa-95ec-7d5f3683fd01","origin":"a730de52-3bb9-4b2f-9d36-3057a494e00e"},"after":null},"a730de52-3bb9-4b2f-9d36-3057a494e00e":{"before":{"allocation":"ae8bcc83-8832-4efa-95ec-7d5f3683fd01","origin":"a730de52-3bb9-4b2f-9d36-3057a494e00e"},"after":null}},"audio_bindings":{"before":{"timings":[{"id":{"allocation":"ae8bcc83-8832-4efa-95ec-7d5f3683fd01","ordinal":0},"layout":{"root":"671d71ba-a1f9-4489-933a-9e70b0445f8e","rate":{"numerator":30000,"denominator":1001},"nodes":{"671d71ba-a1f9-4489-933a-9e70b0445f8e":{"duration":120,"edges":{"node_start":"automatic","node_end":"automatic","source_placement_start":"automatic","source_placement_end":"automatic","repeat_gap_start":"automatic","repeat_gap_end":"automatic"},"kind":{"type":"sequence","children":["a730de52-3bb9-4b2f-9d36-3057a494e00e"]}},"a730de52-3bb9-4b2f-9d36-3057a494e00e":{"duration":120,"edges":{"node_start":"automatic","node_end":"automatic","source_placement_start":"automatic","source_placement_end":"automatic","repeat_gap_start":"automatic","repeat_gap_end":"automatic"},"kind":{"type":"source","placement":{"start":{"numerator":"0","denominator":"1"},"end":{"numerator":"120","denominator":"1"}}}}},"overrides":{}}}],"bindings":{"59797bd3-4452-416c-9ab2-9c226f00c864":{"lattice":{"reference":{"timing":{"allocation":"ae8bcc83-8832-4efa-95ec-7d5f3683fd01","ordinal":0},"root":{"type":"project_root_round_even"},"physical":"a730de52-3bb9-4b2f-9d36-3057a494e00e"},"arguments":[],"births":[]},"resume":{"local_boundary":{"numerator":"10","denominator":"1"},"phase":{"constant":{"numerator":"0","denominator":"1"},"terms":[{"placement":{"reference":{"timing":{"allocation":"ae8bcc83-8832-4efa-95ec-7d5f3683fd01","ordinal":0},"root":{"type":"project_root_round_even"},"physical":"a730de52-3bb9-4b2f-9d36-3057a494e00e"},"arguments":[],"births":[]},"from_local":{"numerator":"0","denominator":"1"},"to_local":{"numerator":"10","denominator":"1"}}]}}},"a730de52-3bb9-4b2f-9d36-3057a494e00e":{"lattice":{"reference":{"timing":{"allocation":"ae8bcc83-8832-4efa-95ec-7d5f3683fd01","ordinal":0},"root":{"type":"project_root_round_even"},"physical":"a730de52-3bb9-4b2f-9d36-3057a494e00e"},"arguments":[],"births":[]},"resume":null}}},"after":{"timings":[],"bindings":{}}}},"changed_ids":["42f2bd41-5536-4dd1-aa51-cf9d2d6dc9f4","59797bd3-4452-416c-9ab2-9c226f00c864","671d71ba-a1f9-4489-933a-9e70b0445f8e","a730de52-3bb9-4b2f-9d36-3057a494e00e","b4f09a18-ca4a-46f7-8ce5-33844d8704b1","f42a5a41-1a92-4361-b3a7-0bc794f7edeb"],"duration_delta":11,"description":"Insert pause"}');
INSERT INTO "history" VALUES(5,1,'1d7d0bb3-78c2-4e92-a752-e1e29ca42b49','{"project_id":"2dbbdca8-d451-4639-8322-38047d33d7ff","expected_revision":"c11c8516-05f9-4939-bcb6-4b5176302fe7","new_revision":"1d7d0bb3-78c2-4e92-a752-e1e29ca42b49","command":{"command":"splice_slice","parent":"671d71ba-a1f9-4489-933a-9e70b0445f8e","index":1,"slice":{"project_id":"2dbbdca8-d451-4639-8322-38047d33d7ff","revision_id":"ae8bcc83-8832-4efa-95ec-7d5f3683fd01","capture_timing":{"allocation":"7e040ccd-ce5a-41e1-bd7a-630565a29b7a","ordinal":0},"presentation_basis":{"width":320,"height":180,"frame_rate":{"numerator":30000,"denominator":1001},"color_policy":"sdr_rec709"},"parent":"671d71ba-a1f9-4489-933a-9e70b0445f8e","range":{"start":8,"end":25},"source_duration":131,"parts":[{"root":"b4f09a18-ca4a-46f7-8ce5-33844d8704b1","mapping":{"start":8,"end":10},"source_start":0},{"root":"42f2bd41-5536-4dd1-aa51-cf9d2d6dc9f4","mapping":{"start":0,"end":11},"source_start":10},{"root":"f42a5a41-1a92-4361-b3a7-0bc794f7edeb","mapping":{"start":0,"end":4},"source_start":21}],"nodes":{"42f2bd41-5536-4dd1-aa51-cf9d2d6dc9f4":{"label":"Pause","kind":{"type":"hold","recipe":{"picture_context":{"canvases":[{"width":320,"height":180,"fit":"fit","layers":[]}]},"duration":11,"video":{"type":"freeze","asset":"8b234d1f-32dd-40fb-b2fa-b743ced54a3d","timestamp":{"ticks":9009,"time_base":{"numerator":1,"denominator":30000}}},"audio":{"type":"silence"}}}},"59797bd3-4452-416c-9ab2-9c226f00c864":{"label":"cfr-bframes.mp4","kind":{"type":"source","source":{"duration":120,"edit_window":{"start":{"numerator":"0","denominator":"1"},"end":{"numerator":"120","denominator":"1"}},"video":{"type":"stream","asset":"8b234d1f-32dd-40fb-b2fa-b743ced54a3d","span":{"start":{"ticks":0,"time_base":{"numerator":1,"denominator":30000}},"end":{"ticks":120120,"time_base":{"numerator":1,"denominator":30000}}}},"video_mapping":{"type":"placement","start":{"numerator":"0","denominator":"1"},"frames":{"numerator":"120","denominator":"1"},"endpoints":"hold_adjacent"},"audio":{"asset":"8b234d1f-32dd-40fb-b2fa-b743ced54a3d","span":{"start":{"ticks":0,"time_base":{"numerator":1,"denominator":48000}},"end":{"ticks":192192,"time_base":{"numerator":1,"denominator":48000}}}},"audio_mapping":{"type":"placement","start":{"numerator":"0","denominator":"1"},"frames":{"numerator":"120","denominator":"1"}},"link":"linked","audio_offset":0}}},"a730de52-3bb9-4b2f-9d36-3057a494e00e":{"label":"cfr-bframes.mp4","kind":{"type":"source","source":{"duration":120,"edit_window":{"start":{"numerator":"0","denominator":"1"},"end":{"numerator":"120","denominator":"1"}},"video":{"type":"stream","asset":"8b234d1f-32dd-40fb-b2fa-b743ced54a3d","span":{"start":{"ticks":0,"time_base":{"numerator":1,"denominator":30000}},"end":{"ticks":120120,"time_base":{"numerator":1,"denominator":30000}}}},"video_mapping":{"type":"placement","start":{"numerator":"0","denominator":"1"},"frames":{"numerator":"120","denominator":"1"},"endpoints":"hold_adjacent"},"audio":{"asset":"8b234d1f-32dd-40fb-b2fa-b743ced54a3d","span":{"start":{"ticks":0,"time_base":{"numerator":1,"denominator":48000}},"end":{"ticks":192192,"time_base":{"numerator":1,"denominator":48000}}}},"audio_mapping":{"type":"placement","start":{"numerator":"0","denominator":"1"},"frames":{"numerator":"120","denominator":"1"}},"link":"linked","audio_offset":0}}},"b4f09a18-ca4a-46f7-8ce5-33844d8704b1":{"label":"cfr-bframes.mp4","kind":{"type":"retime","child":"a730de52-3bb9-4b2f-9d36-3057a494e00e","duration":10,"mapping":{"start":0,"end":10},"pitch":"preserve","purpose":"partition"}},"f42a5a41-1a92-4361-b3a7-0bc794f7edeb":{"label":"cfr-bframes.mp4","kind":{"type":"retime","child":"59797bd3-4452-416c-9ab2-9c226f00c864","duration":110,"mapping":{"start":10,"end":120},"pitch":"preserve","purpose":"partition"}}},"assets":{"8b234d1f-32dd-40fb-b2fa-b743ced54a3d":{"label":"cfr-bframes.mp4","content_hash":"blake3:16614ec12d06396d3c0f0e7b91cc902c6dc30ad89c28d74b805cf64dc60d8aa1","video":{"start":{"ticks":0,"time_base":{"numerator":1,"denominator":30000}},"end":{"ticks":120120,"time_base":{"numerator":1,"denominator":30000}}},"audio":{"start":{"ticks":0,"time_base":{"numerator":1,"denominator":48000}},"end":{"ticks":192192,"time_base":{"numerator":1,"denominator":48000}}},"still_image":false,"frame_count":120,"source_qualification":"c6bc3e81ab69906267164469d11739cf1363eea546436761ddd219069ed496b6"}},"marks":{},"overrides":{},"gap_overrides":{},"audio_lineage":{"59797bd3-4452-416c-9ab2-9c226f00c864":{"allocation":"ae8bcc83-8832-4efa-95ec-7d5f3683fd01","origin":"a730de52-3bb9-4b2f-9d36-3057a494e00e"},"a730de52-3bb9-4b2f-9d36-3057a494e00e":{"allocation":"ae8bcc83-8832-4efa-95ec-7d5f3683fd01","origin":"a730de52-3bb9-4b2f-9d36-3057a494e00e"}},"audio_bindings":{"timings":[{"id":{"allocation":"7e040ccd-ce5a-41e1-bd7a-630565a29b7a","ordinal":0},"layout":{"root":"671d71ba-a1f9-4489-933a-9e70b0445f8e","rate":{"numerator":30000,"denominator":1001},"nodes":{"42f2bd41-5536-4dd1-aa51-cf9d2d6dc9f4":{"duration":11,"edges":{"node_start":"automatic","node_end":"automatic","source_placement_start":"automatic","source_placement_end":"automatic","repeat_gap_start":"automatic","repeat_gap_end":"automatic"},"kind":{"type":"hold","audio":{"type":"silence"}}},"59797bd3-4452-416c-9ab2-9c226f00c864":{"duration":120,"edges":{"node_start":"automatic","node_end":"automatic","source_placement_start":"automatic","source_placement_end":"automatic","repeat_gap_start":"automatic","repeat_gap_end":"automatic"},"kind":{"type":"source","placement":{"start":{"numerator":"0","denominator":"1"},"end":{"numerator":"120","denominator":"1"}}}},"671d71ba-a1f9-4489-933a-9e70b0445f8e":{"duration":131,"edges":{"node_start":"automatic","node_end":"automatic","source_placement_start":"automatic","source_placement_end":"automatic","repeat_gap_start":"automatic","repeat_gap_end":"automatic"},"kind":{"type":"sequence","children":["b4f09a18-ca4a-46f7-8ce5-33844d8704b1","42f2bd41-5536-4dd1-aa51-cf9d2d6dc9f4","f42a5a41-1a92-4361-b3a7-0bc794f7edeb"]}},"a730de52-3bb9-4b2f-9d36-3057a494e00e":{"duration":120,"edges":{"node_start":"automatic","node_end":"automatic","source_placement_start":"automatic","source_placement_end":"automatic","repeat_gap_start":"automatic","repeat_gap_end":"automatic"},"kind":{"type":"source","placement":{"start":{"numerator":"0","denominator":"1"},"end":{"numerator":"120","denominator":"1"}}}},"b4f09a18-ca4a-46f7-8ce5-33844d8704b1":{"duration":10,"edges":{"node_start":"automatic","node_end":"automatic","source_placement_start":"automatic","source_placement_end":"automatic","repeat_gap_start":"automatic","repeat_gap_end":"automatic"},"kind":{"type":"retime","child":"a730de52-3bb9-4b2f-9d36-3057a494e00e","mapping":{"start":0,"end":10},"pitch":"preserve","purpose":"partition"}},"f42a5a41-1a92-4361-b3a7-0bc794f7edeb":{"duration":110,"edges":{"node_start":"automatic","node_end":"automatic","source_placement_start":"automatic","source_placement_end":"automatic","repeat_gap_start":"automatic","repeat_gap_end":"automatic"},"kind":{"type":"retime","child":"59797bd3-4452-416c-9ab2-9c226f00c864","mapping":{"start":10,"end":120},"pitch":"preserve","purpose":"partition"}}},"overrides":{},"audio_lineage":{"59797bd3-4452-416c-9ab2-9c226f00c864":{"allocation":"ae8bcc83-8832-4efa-95ec-7d5f3683fd01","origin":"a730de52-3bb9-4b2f-9d36-3057a494e00e"},"a730de52-3bb9-4b2f-9d36-3057a494e00e":{"allocation":"ae8bcc83-8832-4efa-95ec-7d5f3683fd01","origin":"a730de52-3bb9-4b2f-9d36-3057a494e00e"}}}},{"id":{"allocation":"ae8bcc83-8832-4efa-95ec-7d5f3683fd01","ordinal":0},"layout":{"root":"671d71ba-a1f9-4489-933a-9e70b0445f8e","rate":{"numerator":30000,"denominator":1001},"nodes":{"671d71ba-a1f9-4489-933a-9e70b0445f8e":{"duration":120,"edges":{"node_start":"automatic","node_end":"automatic","source_placement_start":"automatic","source_placement_end":"automatic","repeat_gap_start":"automatic","repeat_gap_end":"automatic"},"kind":{"type":"sequence","children":["a730de52-3bb9-4b2f-9d36-3057a494e00e"]}},"a730de52-3bb9-4b2f-9d36-3057a494e00e":{"duration":120,"edges":{"node_start":"automatic","node_end":"automatic","source_placement_start":"automatic","source_placement_end":"automatic","repeat_gap_start":"automatic","repeat_gap_end":"automatic"},"kind":{"type":"source","placement":{"start":{"numerator":"0","denominator":"1"},"end":{"numerator":"120","denominator":"1"}}}}},"overrides":{}}}],"bindings":{"42f2bd41-5536-4dd1-aa51-cf9d2d6dc9f4":{"lattice":{"reference":{"timing":{"allocation":"7e040ccd-ce5a-41e1-bd7a-630565a29b7a","ordinal":0},"root":{"type":"project_root_round_even"},"physical":"42f2bd41-5536-4dd1-aa51-cf9d2d6dc9f4"},"arguments":[],"births":[]},"resume":null,"reanchors":[{"placement":{"reference":{"timing":{"allocation":"7e040ccd-ce5a-41e1-bd7a-630565a29b7a","ordinal":0},"root":{"type":"project_root_round_even"},"physical":"42f2bd41-5536-4dd1-aa51-cf9d2d6dc9f4"},"arguments":[],"births":[]},"window":{"start":{"numerator":"8","denominator":"1"},"end":{"numerator":"25","denominator":"1"}}}]},"59797bd3-4452-416c-9ab2-9c226f00c864":{"lattice":{"reference":{"timing":{"allocation":"ae8bcc83-8832-4efa-95ec-7d5f3683fd01","ordinal":0},"root":{"type":"project_root_round_even"},"physical":"a730de52-3bb9-4b2f-9d36-3057a494e00e"},"arguments":[],"births":[]},"resume":{"local_boundary":{"numerator":"10","denominator":"1"},"phase":{"constant":{"numerator":"0","denominator":"1"},"terms":[{"placement":{"reference":{"timing":{"allocation":"ae8bcc83-8832-4efa-95ec-7d5f3683fd01","ordinal":0},"root":{"type":"project_root_round_even"},"physical":"a730de52-3bb9-4b2f-9d36-3057a494e00e"},"arguments":[],"births":[]},"from_local":{"numerator":"0","denominator":"1"},"to_local":{"numerator":"10","denominator":"1"}}]}},"reanchors":[{"placement":{"reference":{"timing":{"allocation":"7e040ccd-ce5a-41e1-bd7a-630565a29b7a","ordinal":0},"root":{"type":"project_root_round_even"},"physical":"59797bd3-4452-416c-9ab2-9c226f00c864"},"arguments":[],"births":[]},"window":{"start":{"numerator":"8","denominator":"1"},"end":{"numerator":"25","denominator":"1"}}}]},"a730de52-3bb9-4b2f-9d36-3057a494e00e":{"lattice":{"reference":{"timing":{"allocation":"ae8bcc83-8832-4efa-95ec-7d5f3683fd01","ordinal":0},"root":{"type":"project_root_round_even"},"physical":"a730de52-3bb9-4b2f-9d36-3057a494e00e"},"arguments":[],"births":[]},"resume":null,"reanchors":[{"placement":{"reference":{"timing":{"allocation":"7e040ccd-ce5a-41e1-bd7a-630565a29b7a","ordinal":0},"root":{"type":"project_root_round_even"},"physical":"a730de52-3bb9-4b2f-9d36-3057a494e00e"},"arguments":[],"births":[]},"window":{"start":{"numerator":"8","denominator":"1"},"end":{"numerator":"25","denominator":"1"}}}]}}}},"identities":{"authored":{"nodes":["e98151b5-18d4-4afe-b022-59f71559e154","c6bcde69-3e1b-49ca-8253-8ca70b9a3d3e","90912186-ec77-417f-82f7-d7a7bc6aa8cd","eda064d7-e231-4c02-bd84-bae991441eef","4d69bc95-afd1-410f-bebd-1e2a3c8d2671","3366c225-e0d9-4476-a8f9-188025c42f44","3a8a5062-5955-4e3b-b7a3-4344ab82a360","143232fc-8c80-42ab-8d6c-d8b631b53703"],"marks":[]},"aliases":["5c0b95ab-a4e9-4edc-8a8c-b5bea16287e3","7e77efdd-4864-4bf6-913b-8f4b652e5532","4c6a634a-2699-4171-bc31-7033b2febd91","d6bdc6a5-47ba-4f99-a294-b00adc17fc3b","34e7c155-608b-4efb-b82f-00f1d8eeafa6","eec0085d-df5f-4a40-b374-233b6a230ad9","3b2926d2-2c77-4f47-9170-2f9c2f65bf08","a53cd4f0-eeb8-480e-b5c4-35a95ff72a82","bb81209a-f71f-4df5-806b-fcfa9adf8037"]},"timing":{"allocation":"1d7d0bb3-78c2-4e92-a752-e1e29ca42b49","ordinal":0}}}','{"forward":{"project_id":"2dbbdca8-d451-4639-8322-38047d33d7ff","from_revision":"c11c8516-05f9-4939-bcb6-4b5176302fe7","to_revision":"1d7d0bb3-78c2-4e92-a752-e1e29ca42b49","nodes":{"143232fc-8c80-42ab-8d6c-d8b631b53703":{"before":null,"after":{"label":"Copied interval","kind":{"type":"retime","child":"3366c225-e0d9-4476-a8f9-188025c42f44","duration":4,"mapping":{"start":0,"end":4},"pitch":"preserve","purpose":"partition"}}},"3366c225-e0d9-4476-a8f9-188025c42f44":{"before":null,"after":{"label":"cfr-bframes.mp4","kind":{"type":"retime","child":"90912186-ec77-417f-82f7-d7a7bc6aa8cd","duration":110,"mapping":{"start":10,"end":120},"pitch":"preserve","purpose":"partition"}}},"3a8a5062-5955-4e3b-b7a3-4344ab82a360":{"before":null,"after":{"label":"Copied interval","kind":{"type":"retime","child":"4d69bc95-afd1-410f-bebd-1e2a3c8d2671","duration":2,"mapping":{"start":8,"end":10},"pitch":"preserve","purpose":"partition"}}},"4d69bc95-afd1-410f-bebd-1e2a3c8d2671":{"before":null,"after":{"label":"cfr-bframes.mp4","kind":{"type":"retime","child":"eda064d7-e231-4c02-bd84-bae991441eef","duration":10,"mapping":{"start":0,"end":10},"pitch":"preserve","purpose":"partition"}}},"671d71ba-a1f9-4489-933a-9e70b0445f8e":{"before":{"label":"Sequence","kind":{"type":"sequence","children":["a730de52-3bb9-4b2f-9d36-3057a494e00e"]}},"after":{"label":"Sequence","kind":{"type":"sequence","children":["a730de52-3bb9-4b2f-9d36-3057a494e00e","e98151b5-18d4-4afe-b022-59f71559e154"]}}},"90912186-ec77-417f-82f7-d7a7bc6aa8cd":{"before":null,"after":{"label":"cfr-bframes.mp4","kind":{"type":"source","source":{"duration":120,"edit_window":{"start":{"numerator":"0","denominator":"1"},"end":{"numerator":"120","denominator":"1"}},"video":{"type":"stream","asset":"8b234d1f-32dd-40fb-b2fa-b743ced54a3d","span":{"start":{"ticks":0,"time_base":{"numerator":1,"denominator":30000}},"end":{"ticks":120120,"time_base":{"numerator":1,"denominator":30000}}}},"video_mapping":{"type":"placement","start":{"numerator":"0","denominator":"1"},"frames":{"numerator":"120","denominator":"1"},"endpoints":"hold_adjacent"},"audio":{"asset":"8b234d1f-32dd-40fb-b2fa-b743ced54a3d","span":{"start":{"ticks":0,"time_base":{"numerator":1,"denominator":48000}},"end":{"ticks":192192,"time_base":{"numerator":1,"denominator":48000}}}},"audio_mapping":{"type":"placement","start":{"numerator":"0","denominator":"1"},"frames":{"numerator":"120","denominator":"1"}},"link":"linked","audio_offset":0}}}},"c6bcde69-3e1b-49ca-8253-8ca70b9a3d3e":{"before":null,"after":{"label":"Pause","kind":{"type":"hold","recipe":{"picture_context":{"canvases":[{"width":320,"height":180,"fit":"fit","layers":[]}]},"duration":11,"video":{"type":"freeze","asset":"8b234d1f-32dd-40fb-b2fa-b743ced54a3d","timestamp":{"ticks":9009,"time_base":{"numerator":1,"denominator":30000}}},"audio":{"type":"silence"}}}}},"e98151b5-18d4-4afe-b022-59f71559e154":{"before":null,"after":{"label":"Copied contents","kind":{"type":"sequence","children":["3a8a5062-5955-4e3b-b7a3-4344ab82a360","c6bcde69-3e1b-49ca-8253-8ca70b9a3d3e","143232fc-8c80-42ab-8d6c-d8b631b53703"]}}},"eda064d7-e231-4c02-bd84-bae991441eef":{"before":null,"after":{"label":"cfr-bframes.mp4","kind":{"type":"source","source":{"duration":120,"edit_window":{"start":{"numerator":"0","denominator":"1"},"end":{"numerator":"120","denominator":"1"}},"video":{"type":"stream","asset":"8b234d1f-32dd-40fb-b2fa-b743ced54a3d","span":{"start":{"ticks":0,"time_base":{"numerator":1,"denominator":30000}},"end":{"ticks":120120,"time_base":{"numerator":1,"denominator":30000}}}},"video_mapping":{"type":"placement","start":{"numerator":"0","denominator":"1"},"frames":{"numerator":"120","denominator":"1"},"endpoints":"hold_adjacent"},"audio":{"asset":"8b234d1f-32dd-40fb-b2fa-b743ced54a3d","span":{"start":{"ticks":0,"time_base":{"numerator":1,"denominator":48000}},"end":{"ticks":192192,"time_base":{"numerator":1,"denominator":48000}}}},"audio_mapping":{"type":"placement","start":{"numerator":"0","denominator":"1"},"frames":{"numerator":"120","denominator":"1"}},"link":"linked","audio_offset":0}}}}},"assets":{},"marks":{},"overrides":{},"audio_lineage":{"90912186-ec77-417f-82f7-d7a7bc6aa8cd":{"before":null,"after":{"allocation":"1d7d0bb3-78c2-4e92-a752-e1e29ca42b49","origin":"bb81209a-f71f-4df5-806b-fcfa9adf8037"}},"eda064d7-e231-4c02-bd84-bae991441eef":{"before":null,"after":{"allocation":"1d7d0bb3-78c2-4e92-a752-e1e29ca42b49","origin":"bb81209a-f71f-4df5-806b-fcfa9adf8037"}}},"audio_bindings":{"before":{"timings":[],"bindings":{}},"after":{"timings":[{"id":{"allocation":"1d7d0bb3-78c2-4e92-a752-e1e29ca42b49","ordinal":0},"layout":{"root":"671d71ba-a1f9-4489-933a-9e70b0445f8e","rate":{"numerator":30000,"denominator":1001},"nodes":{"671d71ba-a1f9-4489-933a-9e70b0445f8e":{"duration":120,"edges":{"node_start":"automatic","node_end":"automatic","source_placement_start":"automatic","source_placement_end":"automatic","repeat_gap_start":"automatic","repeat_gap_end":"automatic"},"kind":{"type":"sequence","children":["a730de52-3bb9-4b2f-9d36-3057a494e00e"]}},"a730de52-3bb9-4b2f-9d36-3057a494e00e":{"duration":120,"edges":{"node_start":"automatic","node_end":"automatic","source_placement_start":"automatic","source_placement_end":"automatic","repeat_gap_start":"automatic","repeat_gap_end":"automatic"},"kind":{"type":"source","placement":{"start":{"numerator":"0","denominator":"1"},"end":{"numerator":"120","denominator":"1"}}}}},"overrides":{}}},{"id":{"allocation":"1d7d0bb3-78c2-4e92-a752-e1e29ca42b49","ordinal":1},"layout":{"root":"4c6a634a-2699-4171-bc31-7033b2febd91","rate":{"numerator":30000,"denominator":1001},"nodes":{"34e7c155-608b-4efb-b82f-00f1d8eeafa6":{"duration":10,"edges":{"node_start":"automatic","node_end":"automatic","source_placement_start":"automatic","source_placement_end":"automatic","repeat_gap_start":"automatic","repeat_gap_end":"automatic"},"kind":{"type":"retime","child":"d6bdc6a5-47ba-4f99-a294-b00adc17fc3b","mapping":{"start":0,"end":10},"pitch":"preserve","purpose":"partition"}},"4c6a634a-2699-4171-bc31-7033b2febd91":{"duration":131,"edges":{"node_start":"automatic","node_end":"automatic","source_placement_start":"automatic","source_placement_end":"automatic","repeat_gap_start":"automatic","repeat_gap_end":"automatic"},"kind":{"type":"sequence","children":["34e7c155-608b-4efb-b82f-00f1d8eeafa6","5c0b95ab-a4e9-4edc-8a8c-b5bea16287e3","eec0085d-df5f-4a40-b374-233b6a230ad9"]}},"5c0b95ab-a4e9-4edc-8a8c-b5bea16287e3":{"duration":11,"edges":{"node_start":"automatic","node_end":"automatic","source_placement_start":"automatic","source_placement_end":"automatic","repeat_gap_start":"automatic","repeat_gap_end":"automatic"},"kind":{"type":"hold","audio":{"type":"silence"}}},"7e77efdd-4864-4bf6-913b-8f4b652e5532":{"duration":120,"edges":{"node_start":"automatic","node_end":"automatic","source_placement_start":"automatic","source_placement_end":"automatic","repeat_gap_start":"automatic","repeat_gap_end":"automatic"},"kind":{"type":"source","placement":{"start":{"numerator":"0","denominator":"1"},"end":{"numerator":"120","denominator":"1"}}}},"d6bdc6a5-47ba-4f99-a294-b00adc17fc3b":{"duration":120,"edges":{"node_start":"automatic","node_end":"automatic","source_placement_start":"automatic","source_placement_end":"automatic","repeat_gap_start":"automatic","repeat_gap_end":"automatic"},"kind":{"type":"source","placement":{"start":{"numerator":"0","denominator":"1"},"end":{"numerator":"120","denominator":"1"}}}},"eec0085d-df5f-4a40-b374-233b6a230ad9":{"duration":110,"edges":{"node_start":"automatic","node_end":"automatic","source_placement_start":"automatic","source_placement_end":"automatic","repeat_gap_start":"automatic","repeat_gap_end":"automatic"},"kind":{"type":"retime","child":"7e77efdd-4864-4bf6-913b-8f4b652e5532","mapping":{"start":10,"end":120},"pitch":"preserve","purpose":"partition"}}},"overrides":{},"audio_lineage":{"7e77efdd-4864-4bf6-913b-8f4b652e5532":{"allocation":"1d7d0bb3-78c2-4e92-a752-e1e29ca42b49","origin":"bb81209a-f71f-4df5-806b-fcfa9adf8037"},"d6bdc6a5-47ba-4f99-a294-b00adc17fc3b":{"allocation":"1d7d0bb3-78c2-4e92-a752-e1e29ca42b49","origin":"bb81209a-f71f-4df5-806b-fcfa9adf8037"}}}},{"id":{"allocation":"1d7d0bb3-78c2-4e92-a752-e1e29ca42b49","ordinal":2},"layout":{"root":"3b2926d2-2c77-4f47-9170-2f9c2f65bf08","rate":{"numerator":30000,"denominator":1001},"nodes":{"3b2926d2-2c77-4f47-9170-2f9c2f65bf08":{"duration":120,"edges":{"node_start":"automatic","node_end":"automatic","source_placement_start":"automatic","source_placement_end":"automatic","repeat_gap_start":"automatic","repeat_gap_end":"automatic"},"kind":{"type":"sequence","children":["a53cd4f0-eeb8-480e-b5c4-35a95ff72a82"]}},"a53cd4f0-eeb8-480e-b5c4-35a95ff72a82":{"duration":120,"edges":{"node_start":"automatic","node_end":"automatic","source_placement_start":"automatic","source_placement_end":"automatic","repeat_gap_start":"automatic","repeat_gap_end":"automatic"},"kind":{"type":"source","placement":{"start":{"numerator":"0","denominator":"1"},"end":{"numerator":"120","denominator":"1"}}}}},"overrides":{}}}],"bindings":{"90912186-ec77-417f-82f7-d7a7bc6aa8cd":{"lattice":{"reference":{"timing":{"allocation":"1d7d0bb3-78c2-4e92-a752-e1e29ca42b49","ordinal":2},"root":{"type":"project_root_round_even"},"physical":"a53cd4f0-eeb8-480e-b5c4-35a95ff72a82"},"arguments":[],"births":[]},"resume":{"local_boundary":{"numerator":"10","denominator":"1"},"phase":{"constant":{"numerator":"0","denominator":"1"},"terms":[{"placement":{"reference":{"timing":{"allocation":"1d7d0bb3-78c2-4e92-a752-e1e29ca42b49","ordinal":2},"root":{"type":"project_root_round_even"},"physical":"a53cd4f0-eeb8-480e-b5c4-35a95ff72a82"},"arguments":[],"births":[]},"from_local":{"numerator":"0","denominator":"1"},"to_local":{"numerator":"10","denominator":"1"}}]}},"reanchors":[{"placement":{"reference":{"timing":{"allocation":"1d7d0bb3-78c2-4e92-a752-e1e29ca42b49","ordinal":1},"root":{"type":"project_root_round_even"},"physical":"7e77efdd-4864-4bf6-913b-8f4b652e5532"},"arguments":[],"births":[]},"window":{"start":{"numerator":"8","denominator":"1"},"end":{"numerator":"25","denominator":"1"}}}]},"a730de52-3bb9-4b2f-9d36-3057a494e00e":{"lattice":{"reference":{"timing":{"allocation":"1d7d0bb3-78c2-4e92-a752-e1e29ca42b49","ordinal":0},"root":{"type":"project_root_round_even"},"physical":"a730de52-3bb9-4b2f-9d36-3057a494e00e"},"arguments":[],"births":[]},"resume":null},"c6bcde69-3e1b-49ca-8253-8ca70b9a3d3e":{"lattice":{"reference":{"timing":{"allocation":"1d7d0bb3-78c2-4e92-a752-e1e29ca42b49","ordinal":1},"root":{"type":"project_root_round_even"},"physical":"5c0b95ab-a4e9-4edc-8a8c-b5bea16287e3"},"arguments":[],"births":[]},"resume":null,"reanchors":[{"placement":{"reference":{"timing":{"allocation":"1d7d0bb3-78c2-4e92-a752-e1e29ca42b49","ordinal":1},"root":{"type":"project_root_round_even"},"physical":"5c0b95ab-a4e9-4edc-8a8c-b5bea16287e3"},"arguments":[],"births":[]},"window":{"start":{"numerator":"8","denominator":"1"},"end":{"numerator":"25","denominator":"1"}}}]},"eda064d7-e231-4c02-bd84-bae991441eef":{"lattice":{"reference":{"timing":{"allocation":"1d7d0bb3-78c2-4e92-a752-e1e29ca42b49","ordinal":2},"root":{"type":"project_root_round_even"},"physical":"a53cd4f0-eeb8-480e-b5c4-35a95ff72a82"},"arguments":[],"births":[]},"resume":null,"reanchors":[{"placement":{"reference":{"timing":{"allocation":"1d7d0bb3-78c2-4e92-a752-e1e29ca42b49","ordinal":1},"root":{"type":"project_root_round_even"},"physical":"d6bdc6a5-47ba-4f99-a294-b00adc17fc3b"},"arguments":[],"births":[]},"window":{"start":{"numerator":"8","denominator":"1"},"end":{"numerator":"25","denominator":"1"}}}]}}}}},"inverse":{"project_id":"2dbbdca8-d451-4639-8322-38047d33d7ff","from_revision":"1d7d0bb3-78c2-4e92-a752-e1e29ca42b49","to_revision":"c11c8516-05f9-4939-bcb6-4b5176302fe7","nodes":{"143232fc-8c80-42ab-8d6c-d8b631b53703":{"before":{"label":"Copied interval","kind":{"type":"retime","child":"3366c225-e0d9-4476-a8f9-188025c42f44","duration":4,"mapping":{"start":0,"end":4},"pitch":"preserve","purpose":"partition"}},"after":null},"3366c225-e0d9-4476-a8f9-188025c42f44":{"before":{"label":"cfr-bframes.mp4","kind":{"type":"retime","child":"90912186-ec77-417f-82f7-d7a7bc6aa8cd","duration":110,"mapping":{"start":10,"end":120},"pitch":"preserve","purpose":"partition"}},"after":null},"3a8a5062-5955-4e3b-b7a3-4344ab82a360":{"before":{"label":"Copied interval","kind":{"type":"retime","child":"4d69bc95-afd1-410f-bebd-1e2a3c8d2671","duration":2,"mapping":{"start":8,"end":10},"pitch":"preserve","purpose":"partition"}},"after":null},"4d69bc95-afd1-410f-bebd-1e2a3c8d2671":{"before":{"label":"cfr-bframes.mp4","kind":{"type":"retime","child":"eda064d7-e231-4c02-bd84-bae991441eef","duration":10,"mapping":{"start":0,"end":10},"pitch":"preserve","purpose":"partition"}},"after":null},"671d71ba-a1f9-4489-933a-9e70b0445f8e":{"before":{"label":"Sequence","kind":{"type":"sequence","children":["a730de52-3bb9-4b2f-9d36-3057a494e00e","e98151b5-18d4-4afe-b022-59f71559e154"]}},"after":{"label":"Sequence","kind":{"type":"sequence","children":["a730de52-3bb9-4b2f-9d36-3057a494e00e"]}}},"90912186-ec77-417f-82f7-d7a7bc6aa8cd":{"before":{"label":"cfr-bframes.mp4","kind":{"type":"source","source":{"duration":120,"edit_window":{"start":{"numerator":"0","denominator":"1"},"end":{"numerator":"120","denominator":"1"}},"video":{"type":"stream","asset":"8b234d1f-32dd-40fb-b2fa-b743ced54a3d","span":{"start":{"ticks":0,"time_base":{"numerator":1,"denominator":30000}},"end":{"ticks":120120,"time_base":{"numerator":1,"denominator":30000}}}},"video_mapping":{"type":"placement","start":{"numerator":"0","denominator":"1"},"frames":{"numerator":"120","denominator":"1"},"endpoints":"hold_adjacent"},"audio":{"asset":"8b234d1f-32dd-40fb-b2fa-b743ced54a3d","span":{"start":{"ticks":0,"time_base":{"numerator":1,"denominator":48000}},"end":{"ticks":192192,"time_base":{"numerator":1,"denominator":48000}}}},"audio_mapping":{"type":"placement","start":{"numerator":"0","denominator":"1"},"frames":{"numerator":"120","denominator":"1"}},"link":"linked","audio_offset":0}}},"after":null},"c6bcde69-3e1b-49ca-8253-8ca70b9a3d3e":{"before":{"label":"Pause","kind":{"type":"hold","recipe":{"picture_context":{"canvases":[{"width":320,"height":180,"fit":"fit","layers":[]}]},"duration":11,"video":{"type":"freeze","asset":"8b234d1f-32dd-40fb-b2fa-b743ced54a3d","timestamp":{"ticks":9009,"time_base":{"numerator":1,"denominator":30000}}},"audio":{"type":"silence"}}}},"after":null},"e98151b5-18d4-4afe-b022-59f71559e154":{"before":{"label":"Copied contents","kind":{"type":"sequence","children":["3a8a5062-5955-4e3b-b7a3-4344ab82a360","c6bcde69-3e1b-49ca-8253-8ca70b9a3d3e","143232fc-8c80-42ab-8d6c-d8b631b53703"]}},"after":null},"eda064d7-e231-4c02-bd84-bae991441eef":{"before":{"label":"cfr-bframes.mp4","kind":{"type":"source","source":{"duration":120,"edit_window":{"start":{"numerator":"0","denominator":"1"},"end":{"numerator":"120","denominator":"1"}},"video":{"type":"stream","asset":"8b234d1f-32dd-40fb-b2fa-b743ced54a3d","span":{"start":{"ticks":0,"time_base":{"numerator":1,"denominator":30000}},"end":{"ticks":120120,"time_base":{"numerator":1,"denominator":30000}}}},"video_mapping":{"type":"placement","start":{"numerator":"0","denominator":"1"},"frames":{"numerator":"120","denominator":"1"},"endpoints":"hold_adjacent"},"audio":{"asset":"8b234d1f-32dd-40fb-b2fa-b743ced54a3d","span":{"start":{"ticks":0,"time_base":{"numerator":1,"denominator":48000}},"end":{"ticks":192192,"time_base":{"numerator":1,"denominator":48000}}}},"audio_mapping":{"type":"placement","start":{"numerator":"0","denominator":"1"},"frames":{"numerator":"120","denominator":"1"}},"link":"linked","audio_offset":0}}},"after":null}},"assets":{},"marks":{},"overrides":{},"audio_lineage":{"90912186-ec77-417f-82f7-d7a7bc6aa8cd":{"before":{"allocation":"1d7d0bb3-78c2-4e92-a752-e1e29ca42b49","origin":"bb81209a-f71f-4df5-806b-fcfa9adf8037"},"after":null},"eda064d7-e231-4c02-bd84-bae991441eef":{"before":{"allocation":"1d7d0bb3-78c2-4e92-a752-e1e29ca42b49","origin":"bb81209a-f71f-4df5-806b-fcfa9adf8037"},"after":null}},"audio_bindings":{"before":{"timings":[{"id":{"allocation":"1d7d0bb3-78c2-4e92-a752-e1e29ca42b49","ordinal":0},"layout":{"root":"671d71ba-a1f9-4489-933a-9e70b0445f8e","rate":{"numerator":30000,"denominator":1001},"nodes":{"671d71ba-a1f9-4489-933a-9e70b0445f8e":{"duration":120,"edges":{"node_start":"automatic","node_end":"automatic","source_placement_start":"automatic","source_placement_end":"automatic","repeat_gap_start":"automatic","repeat_gap_end":"automatic"},"kind":{"type":"sequence","children":["a730de52-3bb9-4b2f-9d36-3057a494e00e"]}},"a730de52-3bb9-4b2f-9d36-3057a494e00e":{"duration":120,"edges":{"node_start":"automatic","node_end":"automatic","source_placement_start":"automatic","source_placement_end":"automatic","repeat_gap_start":"automatic","repeat_gap_end":"automatic"},"kind":{"type":"source","placement":{"start":{"numerator":"0","denominator":"1"},"end":{"numerator":"120","denominator":"1"}}}}},"overrides":{}}},{"id":{"allocation":"1d7d0bb3-78c2-4e92-a752-e1e29ca42b49","ordinal":1},"layout":{"root":"4c6a634a-2699-4171-bc31-7033b2febd91","rate":{"numerator":30000,"denominator":1001},"nodes":{"34e7c155-608b-4efb-b82f-00f1d8eeafa6":{"duration":10,"edges":{"node_start":"automatic","node_end":"automatic","source_placement_start":"automatic","source_placement_end":"automatic","repeat_gap_start":"automatic","repeat_gap_end":"automatic"},"kind":{"type":"retime","child":"d6bdc6a5-47ba-4f99-a294-b00adc17fc3b","mapping":{"start":0,"end":10},"pitch":"preserve","purpose":"partition"}},"4c6a634a-2699-4171-bc31-7033b2febd91":{"duration":131,"edges":{"node_start":"automatic","node_end":"automatic","source_placement_start":"automatic","source_placement_end":"automatic","repeat_gap_start":"automatic","repeat_gap_end":"automatic"},"kind":{"type":"sequence","children":["34e7c155-608b-4efb-b82f-00f1d8eeafa6","5c0b95ab-a4e9-4edc-8a8c-b5bea16287e3","eec0085d-df5f-4a40-b374-233b6a230ad9"]}},"5c0b95ab-a4e9-4edc-8a8c-b5bea16287e3":{"duration":11,"edges":{"node_start":"automatic","node_end":"automatic","source_placement_start":"automatic","source_placement_end":"automatic","repeat_gap_start":"automatic","repeat_gap_end":"automatic"},"kind":{"type":"hold","audio":{"type":"silence"}}},"7e77efdd-4864-4bf6-913b-8f4b652e5532":{"duration":120,"edges":{"node_start":"automatic","node_end":"automatic","source_placement_start":"automatic","source_placement_end":"automatic","repeat_gap_start":"automatic","repeat_gap_end":"automatic"},"kind":{"type":"source","placement":{"start":{"numerator":"0","denominator":"1"},"end":{"numerator":"120","denominator":"1"}}}},"d6bdc6a5-47ba-4f99-a294-b00adc17fc3b":{"duration":120,"edges":{"node_start":"automatic","node_end":"automatic","source_placement_start":"automatic","source_placement_end":"automatic","repeat_gap_start":"automatic","repeat_gap_end":"automatic"},"kind":{"type":"source","placement":{"start":{"numerator":"0","denominator":"1"},"end":{"numerator":"120","denominator":"1"}}}},"eec0085d-df5f-4a40-b374-233b6a230ad9":{"duration":110,"edges":{"node_start":"automatic","node_end":"automatic","source_placement_start":"automatic","source_placement_end":"automatic","repeat_gap_start":"automatic","repeat_gap_end":"automatic"},"kind":{"type":"retime","child":"7e77efdd-4864-4bf6-913b-8f4b652e5532","mapping":{"start":10,"end":120},"pitch":"preserve","purpose":"partition"}}},"overrides":{},"audio_lineage":{"7e77efdd-4864-4bf6-913b-8f4b652e5532":{"allocation":"1d7d0bb3-78c2-4e92-a752-e1e29ca42b49","origin":"bb81209a-f71f-4df5-806b-fcfa9adf8037"},"d6bdc6a5-47ba-4f99-a294-b00adc17fc3b":{"allocation":"1d7d0bb3-78c2-4e92-a752-e1e29ca42b49","origin":"bb81209a-f71f-4df5-806b-fcfa9adf8037"}}}},{"id":{"allocation":"1d7d0bb3-78c2-4e92-a752-e1e29ca42b49","ordinal":2},"layout":{"root":"3b2926d2-2c77-4f47-9170-2f9c2f65bf08","rate":{"numerator":30000,"denominator":1001},"nodes":{"3b2926d2-2c77-4f47-9170-2f9c2f65bf08":{"duration":120,"edges":{"node_start":"automatic","node_end":"automatic","source_placement_start":"automatic","source_placement_end":"automatic","repeat_gap_start":"automatic","repeat_gap_end":"automatic"},"kind":{"type":"sequence","children":["a53cd4f0-eeb8-480e-b5c4-35a95ff72a82"]}},"a53cd4f0-eeb8-480e-b5c4-35a95ff72a82":{"duration":120,"edges":{"node_start":"automatic","node_end":"automatic","source_placement_start":"automatic","source_placement_end":"automatic","repeat_gap_start":"automatic","repeat_gap_end":"automatic"},"kind":{"type":"source","placement":{"start":{"numerator":"0","denominator":"1"},"end":{"numerator":"120","denominator":"1"}}}}},"overrides":{}}}],"bindings":{"90912186-ec77-417f-82f7-d7a7bc6aa8cd":{"lattice":{"reference":{"timing":{"allocation":"1d7d0bb3-78c2-4e92-a752-e1e29ca42b49","ordinal":2},"root":{"type":"project_root_round_even"},"physical":"a53cd4f0-eeb8-480e-b5c4-35a95ff72a82"},"arguments":[],"births":[]},"resume":{"local_boundary":{"numerator":"10","denominator":"1"},"phase":{"constant":{"numerator":"0","denominator":"1"},"terms":[{"placement":{"reference":{"timing":{"allocation":"1d7d0bb3-78c2-4e92-a752-e1e29ca42b49","ordinal":2},"root":{"type":"project_root_round_even"},"physical":"a53cd4f0-eeb8-480e-b5c4-35a95ff72a82"},"arguments":[],"births":[]},"from_local":{"numerator":"0","denominator":"1"},"to_local":{"numerator":"10","denominator":"1"}}]}},"reanchors":[{"placement":{"reference":{"timing":{"allocation":"1d7d0bb3-78c2-4e92-a752-e1e29ca42b49","ordinal":1},"root":{"type":"project_root_round_even"},"physical":"7e77efdd-4864-4bf6-913b-8f4b652e5532"},"arguments":[],"births":[]},"window":{"start":{"numerator":"8","denominator":"1"},"end":{"numerator":"25","denominator":"1"}}}]},"a730de52-3bb9-4b2f-9d36-3057a494e00e":{"lattice":{"reference":{"timing":{"allocation":"1d7d0bb3-78c2-4e92-a752-e1e29ca42b49","ordinal":0},"root":{"type":"project_root_round_even"},"physical":"a730de52-3bb9-4b2f-9d36-3057a494e00e"},"arguments":[],"births":[]},"resume":null},"c6bcde69-3e1b-49ca-8253-8ca70b9a3d3e":{"lattice":{"reference":{"timing":{"allocation":"1d7d0bb3-78c2-4e92-a752-e1e29ca42b49","ordinal":1},"root":{"type":"project_root_round_even"},"physical":"5c0b95ab-a4e9-4edc-8a8c-b5bea16287e3"},"arguments":[],"births":[]},"resume":null,"reanchors":[{"placement":{"reference":{"timing":{"allocation":"1d7d0bb3-78c2-4e92-a752-e1e29ca42b49","ordinal":1},"root":{"type":"project_root_round_even"},"physical":"5c0b95ab-a4e9-4edc-8a8c-b5bea16287e3"},"arguments":[],"births":[]},"window":{"start":{"numerator":"8","denominator":"1"},"end":{"numerator":"25","denominator":"1"}}}]},"eda064d7-e231-4c02-bd84-bae991441eef":{"lattice":{"reference":{"timing":{"allocation":"1d7d0bb3-78c2-4e92-a752-e1e29ca42b49","ordinal":2},"root":{"type":"project_root_round_even"},"physical":"a53cd4f0-eeb8-480e-b5c4-35a95ff72a82"},"arguments":[],"births":[]},"resume":null,"reanchors":[{"placement":{"reference":{"timing":{"allocation":"1d7d0bb3-78c2-4e92-a752-e1e29ca42b49","ordinal":1},"root":{"type":"project_root_round_even"},"physical":"d6bdc6a5-47ba-4f99-a294-b00adc17fc3b"},"arguments":[],"births":[]},"window":{"start":{"numerator":"8","denominator":"1"},"end":{"numerator":"25","denominator":"1"}}}]}}},"after":{"timings":[],"bindings":{}}}},"changed_ids":["143232fc-8c80-42ab-8d6c-d8b631b53703","3366c225-e0d9-4476-a8f9-188025c42f44","3a8a5062-5955-4e3b-b7a3-4344ab82a360","4d69bc95-afd1-410f-bebd-1e2a3c8d2671","671d71ba-a1f9-4489-933a-9e70b0445f8e","90912186-ec77-417f-82f7-d7a7bc6aa8cd","a730de52-3bb9-4b2f-9d36-3057a494e00e","c6bcde69-3e1b-49ca-8253-8ca70b9a3d3e","e98151b5-18d4-4afe-b022-59f71559e154","eda064d7-e231-4c02-bd84-bae991441eef"],"duration_delta":17,"description":"Paste edited slice"}');
INSERT INTO "history" VALUES(6,1,'f25c247c-d2f8-4e6e-a894-8784e0e5bcdd','{"project_id":"2dbbdca8-d451-4639-8322-38047d33d7ff","expected_revision":"18b8d6b2-ae92-49c3-8951-86db30e35e6d","new_revision":"f25c247c-d2f8-4e6e-a894-8784e0e5bcdd","command":{"command":"delete_range","parent":"671d71ba-a1f9-4489-933a-9e70b0445f8e","range":{"start":20,"end":30},"identities":{"nodes":["8258cb00-c1be-4cc3-b9bf-dc99fe08e79c","1ebf8220-16a1-4a22-af81-d307f05ac001","91fa6571-140c-426f-8132-1b43f1e11e4b","ff341750-08d6-48de-ac48-9fec739c8d85","cef0f3ad-4409-4184-a4a9-c1869bbbb249"]},"timing":{"allocation":"f25c247c-d2f8-4e6e-a894-8784e0e5bcdd","ordinal":0}}}','{"forward":{"project_id":"2dbbdca8-d451-4639-8322-38047d33d7ff","from_revision":"18b8d6b2-ae92-49c3-8951-86db30e35e6d","to_revision":"f25c247c-d2f8-4e6e-a894-8784e0e5bcdd","nodes":{"671d71ba-a1f9-4489-933a-9e70b0445f8e":{"before":{"label":"Sequence","kind":{"type":"sequence","children":["a730de52-3bb9-4b2f-9d36-3057a494e00e"]}},"after":{"label":"Sequence","kind":{"type":"sequence","children":["8258cb00-c1be-4cc3-b9bf-dc99fe08e79c","ff341750-08d6-48de-ac48-9fec739c8d85"]}}},"8258cb00-c1be-4cc3-b9bf-dc99fe08e79c":{"before":null,"after":{"label":"cfr-bframes.mp4","kind":{"type":"retime","child":"a730de52-3bb9-4b2f-9d36-3057a494e00e","duration":20,"mapping":{"start":0,"end":20},"pitch":"preserve","purpose":"partition"}}},"cef0f3ad-4409-4184-a4a9-c1869bbbb249":{"before":null,"after":{"label":"cfr-bframes.mp4","kind":{"type":"source","source":{"duration":120,"edit_window":{"start":{"numerator":"0","denominator":"1"},"end":{"numerator":"120","denominator":"1"}},"video":{"type":"stream","asset":"8b234d1f-32dd-40fb-b2fa-b743ced54a3d","span":{"start":{"ticks":0,"time_base":{"numerator":1,"denominator":30000}},"end":{"ticks":120120,"time_base":{"numerator":1,"denominator":30000}}}},"video_mapping":{"type":"placement","start":{"numerator":"0","denominator":"1"},"frames":{"numerator":"120","denominator":"1"},"endpoints":"hold_adjacent"},"audio":{"asset":"8b234d1f-32dd-40fb-b2fa-b743ced54a3d","span":{"start":{"ticks":0,"time_base":{"numerator":1,"denominator":48000}},"end":{"ticks":192192,"time_base":{"numerator":1,"denominator":48000}}}},"audio_mapping":{"type":"placement","start":{"numerator":"0","denominator":"1"},"frames":{"numerator":"120","denominator":"1"}},"link":"linked","audio_offset":0}}}},"ff341750-08d6-48de-ac48-9fec739c8d85":{"before":null,"after":{"label":"cfr-bframes.mp4","kind":{"type":"retime","child":"cef0f3ad-4409-4184-a4a9-c1869bbbb249","duration":90,"mapping":{"start":30,"end":120},"pitch":"preserve","purpose":"partition"}}}},"assets":{},"marks":{},"overrides":{},"audio_lineage":{"a730de52-3bb9-4b2f-9d36-3057a494e00e":{"before":null,"after":{"allocation":"f25c247c-d2f8-4e6e-a894-8784e0e5bcdd","origin":"a730de52-3bb9-4b2f-9d36-3057a494e00e"}},"cef0f3ad-4409-4184-a4a9-c1869bbbb249":{"before":null,"after":{"allocation":"f25c247c-d2f8-4e6e-a894-8784e0e5bcdd","origin":"a730de52-3bb9-4b2f-9d36-3057a494e00e"}}},"audio_bindings":{"before":{"timings":[],"bindings":{}},"after":{"timings":[{"id":{"allocation":"f25c247c-d2f8-4e6e-a894-8784e0e5bcdd","ordinal":0},"layout":{"root":"671d71ba-a1f9-4489-933a-9e70b0445f8e","rate":{"numerator":30000,"denominator":1001},"nodes":{"671d71ba-a1f9-4489-933a-9e70b0445f8e":{"duration":120,"edges":{"node_start":"automatic","node_end":"automatic","source_placement_start":"automatic","source_placement_end":"automatic","repeat_gap_start":"automatic","repeat_gap_end":"automatic"},"kind":{"type":"sequence","children":["a730de52-3bb9-4b2f-9d36-3057a494e00e"]}},"a730de52-3bb9-4b2f-9d36-3057a494e00e":{"duration":120,"edges":{"node_start":"automatic","node_end":"automatic","source_placement_start":"automatic","source_placement_end":"automatic","repeat_gap_start":"automatic","repeat_gap_end":"automatic"},"kind":{"type":"source","placement":{"start":{"numerator":"0","denominator":"1"},"end":{"numerator":"120","denominator":"1"}}}}},"overrides":{}}},{"id":{"allocation":"f25c247c-d2f8-4e6e-a894-8784e0e5bcdd","ordinal":1},"layout":{"root":"671d71ba-a1f9-4489-933a-9e70b0445f8e","rate":{"numerator":30000,"denominator":1001},"nodes":{"1ebf8220-16a1-4a22-af81-d307f05ac001":{"duration":10,"edges":{"node_start":"automatic","node_end":"automatic","source_placement_start":"automatic","source_placement_end":"automatic","repeat_gap_start":"automatic","repeat_gap_end":"automatic"},"kind":{"type":"retime","child":"91fa6571-140c-426f-8132-1b43f1e11e4b","mapping":{"start":20,"end":30},"pitch":"preserve","purpose":"partition"}},"671d71ba-a1f9-4489-933a-9e70b0445f8e":{"duration":120,"edges":{"node_start":"automatic","node_end":"automatic","source_placement_start":"automatic","source_placement_end":"automatic","repeat_gap_start":"automatic","repeat_gap_end":"automatic"},"kind":{"type":"sequence","children":["8258cb00-c1be-4cc3-b9bf-dc99fe08e79c","1ebf8220-16a1-4a22-af81-d307f05ac001","ff341750-08d6-48de-ac48-9fec739c8d85"]}},"8258cb00-c1be-4cc3-b9bf-dc99fe08e79c":{"duration":20,"edges":{"node_start":"automatic","node_end":"automatic","source_placement_start":"automatic","source_placement_end":"automatic","repeat_gap_start":"automatic","repeat_gap_end":"automatic"},"kind":{"type":"retime","child":"a730de52-3bb9-4b2f-9d36-3057a494e00e","mapping":{"start":0,"end":20},"pitch":"preserve","purpose":"partition"}},"91fa6571-140c-426f-8132-1b43f1e11e4b":{"duration":120,"edges":{"node_start":"automatic","node_end":"automatic","source_placement_start":"automatic","source_placement_end":"automatic","repeat_gap_start":"automatic","repeat_gap_end":"automatic"},"kind":{"type":"source","placement":{"start":{"numerator":"0","denominator":"1"},"end":{"numerator":"120","denominator":"1"}}}},"a730de52-3bb9-4b2f-9d36-3057a494e00e":{"duration":120,"edges":{"node_start":"automatic","node_end":"automatic","source_placement_start":"automatic","source_placement_end":"automatic","repeat_gap_start":"automatic","repeat_gap_end":"automatic"},"kind":{"type":"source","placement":{"start":{"numerator":"0","denominator":"1"},"end":{"numerator":"120","denominator":"1"}}}},"cef0f3ad-4409-4184-a4a9-c1869bbbb249":{"duration":120,"edges":{"node_start":"automatic","node_end":"automatic","source_placement_start":"automatic","source_placement_end":"automatic","repeat_gap_start":"automatic","repeat_gap_end":"automatic"},"kind":{"type":"source","placement":{"start":{"numerator":"0","denominator":"1"},"end":{"numerator":"120","denominator":"1"}}}},"ff341750-08d6-48de-ac48-9fec739c8d85":{"duration":90,"edges":{"node_start":"automatic","node_end":"automatic","source_placement_start":"automatic","source_placement_end":"automatic","repeat_gap_start":"automatic","repeat_gap_end":"automatic"},"kind":{"type":"retime","child":"cef0f3ad-4409-4184-a4a9-c1869bbbb249","mapping":{"start":30,"end":120},"pitch":"preserve","purpose":"partition"}}},"overrides":{},"audio_lineage":{"91fa6571-140c-426f-8132-1b43f1e11e4b":{"allocation":"f25c247c-d2f8-4e6e-a894-8784e0e5bcdd","origin":"a730de52-3bb9-4b2f-9d36-3057a494e00e"},"a730de52-3bb9-4b2f-9d36-3057a494e00e":{"allocation":"f25c247c-d2f8-4e6e-a894-8784e0e5bcdd","origin":"a730de52-3bb9-4b2f-9d36-3057a494e00e"},"cef0f3ad-4409-4184-a4a9-c1869bbbb249":{"allocation":"f25c247c-d2f8-4e6e-a894-8784e0e5bcdd","origin":"a730de52-3bb9-4b2f-9d36-3057a494e00e"}}}}],"bindings":{"a730de52-3bb9-4b2f-9d36-3057a494e00e":{"lattice":{"reference":{"timing":{"allocation":"f25c247c-d2f8-4e6e-a894-8784e0e5bcdd","ordinal":0},"root":{"type":"project_root_round_even"},"physical":"a730de52-3bb9-4b2f-9d36-3057a494e00e"},"arguments":[],"births":[]},"resume":null},"cef0f3ad-4409-4184-a4a9-c1869bbbb249":{"lattice":{"reference":{"timing":{"allocation":"f25c247c-d2f8-4e6e-a894-8784e0e5bcdd","ordinal":0},"root":{"type":"project_root_round_even"},"physical":"a730de52-3bb9-4b2f-9d36-3057a494e00e"},"arguments":[],"births":[]},"resume":null,"reanchors":[{"placement":{"reference":{"timing":{"allocation":"f25c247c-d2f8-4e6e-a894-8784e0e5bcdd","ordinal":1},"root":{"type":"project_root_round_even"},"physical":"cef0f3ad-4409-4184-a4a9-c1869bbbb249"},"arguments":[],"births":[]},"window":{"start":{"numerator":"30","denominator":"1"},"end":{"numerator":"120","denominator":"1"}}}]}}}}},"inverse":{"project_id":"2dbbdca8-d451-4639-8322-38047d33d7ff","from_revision":"f25c247c-d2f8-4e6e-a894-8784e0e5bcdd","to_revision":"18b8d6b2-ae92-49c3-8951-86db30e35e6d","nodes":{"671d71ba-a1f9-4489-933a-9e70b0445f8e":{"before":{"label":"Sequence","kind":{"type":"sequence","children":["8258cb00-c1be-4cc3-b9bf-dc99fe08e79c","ff341750-08d6-48de-ac48-9fec739c8d85"]}},"after":{"label":"Sequence","kind":{"type":"sequence","children":["a730de52-3bb9-4b2f-9d36-3057a494e00e"]}}},"8258cb00-c1be-4cc3-b9bf-dc99fe08e79c":{"before":{"label":"cfr-bframes.mp4","kind":{"type":"retime","child":"a730de52-3bb9-4b2f-9d36-3057a494e00e","duration":20,"mapping":{"start":0,"end":20},"pitch":"preserve","purpose":"partition"}},"after":null},"cef0f3ad-4409-4184-a4a9-c1869bbbb249":{"before":{"label":"cfr-bframes.mp4","kind":{"type":"source","source":{"duration":120,"edit_window":{"start":{"numerator":"0","denominator":"1"},"end":{"numerator":"120","denominator":"1"}},"video":{"type":"stream","asset":"8b234d1f-32dd-40fb-b2fa-b743ced54a3d","span":{"start":{"ticks":0,"time_base":{"numerator":1,"denominator":30000}},"end":{"ticks":120120,"time_base":{"numerator":1,"denominator":30000}}}},"video_mapping":{"type":"placement","start":{"numerator":"0","denominator":"1"},"frames":{"numerator":"120","denominator":"1"},"endpoints":"hold_adjacent"},"audio":{"asset":"8b234d1f-32dd-40fb-b2fa-b743ced54a3d","span":{"start":{"ticks":0,"time_base":{"numerator":1,"denominator":48000}},"end":{"ticks":192192,"time_base":{"numerator":1,"denominator":48000}}}},"audio_mapping":{"type":"placement","start":{"numerator":"0","denominator":"1"},"frames":{"numerator":"120","denominator":"1"}},"link":"linked","audio_offset":0}}},"after":null},"ff341750-08d6-48de-ac48-9fec739c8d85":{"before":{"label":"cfr-bframes.mp4","kind":{"type":"retime","child":"cef0f3ad-4409-4184-a4a9-c1869bbbb249","duration":90,"mapping":{"start":30,"end":120},"pitch":"preserve","purpose":"partition"}},"after":null}},"assets":{},"marks":{},"overrides":{},"audio_lineage":{"a730de52-3bb9-4b2f-9d36-3057a494e00e":{"before":{"allocation":"f25c247c-d2f8-4e6e-a894-8784e0e5bcdd","origin":"a730de52-3bb9-4b2f-9d36-3057a494e00e"},"after":null},"cef0f3ad-4409-4184-a4a9-c1869bbbb249":{"before":{"allocation":"f25c247c-d2f8-4e6e-a894-8784e0e5bcdd","origin":"a730de52-3bb9-4b2f-9d36-3057a494e00e"},"after":null}},"audio_bindings":{"before":{"timings":[{"id":{"allocation":"f25c247c-d2f8-4e6e-a894-8784e0e5bcdd","ordinal":0},"layout":{"root":"671d71ba-a1f9-4489-933a-9e70b0445f8e","rate":{"numerator":30000,"denominator":1001},"nodes":{"671d71ba-a1f9-4489-933a-9e70b0445f8e":{"duration":120,"edges":{"node_start":"automatic","node_end":"automatic","source_placement_start":"automatic","source_placement_end":"automatic","repeat_gap_start":"automatic","repeat_gap_end":"automatic"},"kind":{"type":"sequence","children":["a730de52-3bb9-4b2f-9d36-3057a494e00e"]}},"a730de52-3bb9-4b2f-9d36-3057a494e00e":{"duration":120,"edges":{"node_start":"automatic","node_end":"automatic","source_placement_start":"automatic","source_placement_end":"automatic","repeat_gap_start":"automatic","repeat_gap_end":"automatic"},"kind":{"type":"source","placement":{"start":{"numerator":"0","denominator":"1"},"end":{"numerator":"120","denominator":"1"}}}}},"overrides":{}}},{"id":{"allocation":"f25c247c-d2f8-4e6e-a894-8784e0e5bcdd","ordinal":1},"layout":{"root":"671d71ba-a1f9-4489-933a-9e70b0445f8e","rate":{"numerator":30000,"denominator":1001},"nodes":{"1ebf8220-16a1-4a22-af81-d307f05ac001":{"duration":10,"edges":{"node_start":"automatic","node_end":"automatic","source_placement_start":"automatic","source_placement_end":"automatic","repeat_gap_start":"automatic","repeat_gap_end":"automatic"},"kind":{"type":"retime","child":"91fa6571-140c-426f-8132-1b43f1e11e4b","mapping":{"start":20,"end":30},"pitch":"preserve","purpose":"partition"}},"671d71ba-a1f9-4489-933a-9e70b0445f8e":{"duration":120,"edges":{"node_start":"automatic","node_end":"automatic","source_placement_start":"automatic","source_placement_end":"automatic","repeat_gap_start":"automatic","repeat_gap_end":"automatic"},"kind":{"type":"sequence","children":["8258cb00-c1be-4cc3-b9bf-dc99fe08e79c","1ebf8220-16a1-4a22-af81-d307f05ac001","ff341750-08d6-48de-ac48-9fec739c8d85"]}},"8258cb00-c1be-4cc3-b9bf-dc99fe08e79c":{"duration":20,"edges":{"node_start":"automatic","node_end":"automatic","source_placement_start":"automatic","source_placement_end":"automatic","repeat_gap_start":"automatic","repeat_gap_end":"automatic"},"kind":{"type":"retime","child":"a730de52-3bb9-4b2f-9d36-3057a494e00e","mapping":{"start":0,"end":20},"pitch":"preserve","purpose":"partition"}},"91fa6571-140c-426f-8132-1b43f1e11e4b":{"duration":120,"edges":{"node_start":"automatic","node_end":"automatic","source_placement_start":"automatic","source_placement_end":"automatic","repeat_gap_start":"automatic","repeat_gap_end":"automatic"},"kind":{"type":"source","placement":{"start":{"numerator":"0","denominator":"1"},"end":{"numerator":"120","denominator":"1"}}}},"a730de52-3bb9-4b2f-9d36-3057a494e00e":{"duration":120,"edges":{"node_start":"automatic","node_end":"automatic","source_placement_start":"automatic","source_placement_end":"automatic","repeat_gap_start":"automatic","repeat_gap_end":"automatic"},"kind":{"type":"source","placement":{"start":{"numerator":"0","denominator":"1"},"end":{"numerator":"120","denominator":"1"}}}},"cef0f3ad-4409-4184-a4a9-c1869bbbb249":{"duration":120,"edges":{"node_start":"automatic","node_end":"automatic","source_placement_start":"automatic","source_placement_end":"automatic","repeat_gap_start":"automatic","repeat_gap_end":"automatic"},"kind":{"type":"source","placement":{"start":{"numerator":"0","denominator":"1"},"end":{"numerator":"120","denominator":"1"}}}},"ff341750-08d6-48de-ac48-9fec739c8d85":{"duration":90,"edges":{"node_start":"automatic","node_end":"automatic","source_placement_start":"automatic","source_placement_end":"automatic","repeat_gap_start":"automatic","repeat_gap_end":"automatic"},"kind":{"type":"retime","child":"cef0f3ad-4409-4184-a4a9-c1869bbbb249","mapping":{"start":30,"end":120},"pitch":"preserve","purpose":"partition"}}},"overrides":{},"audio_lineage":{"91fa6571-140c-426f-8132-1b43f1e11e4b":{"allocation":"f25c247c-d2f8-4e6e-a894-8784e0e5bcdd","origin":"a730de52-3bb9-4b2f-9d36-3057a494e00e"},"a730de52-3bb9-4b2f-9d36-3057a494e00e":{"allocation":"f25c247c-d2f8-4e6e-a894-8784e0e5bcdd","origin":"a730de52-3bb9-4b2f-9d36-3057a494e00e"},"cef0f3ad-4409-4184-a4a9-c1869bbbb249":{"allocation":"f25c247c-d2f8-4e6e-a894-8784e0e5bcdd","origin":"a730de52-3bb9-4b2f-9d36-3057a494e00e"}}}}],"bindings":{"a730de52-3bb9-4b2f-9d36-3057a494e00e":{"lattice":{"reference":{"timing":{"allocation":"f25c247c-d2f8-4e6e-a894-8784e0e5bcdd","ordinal":0},"root":{"type":"project_root_round_even"},"physical":"a730de52-3bb9-4b2f-9d36-3057a494e00e"},"arguments":[],"births":[]},"resume":null},"cef0f3ad-4409-4184-a4a9-c1869bbbb249":{"lattice":{"reference":{"timing":{"allocation":"f25c247c-d2f8-4e6e-a894-8784e0e5bcdd","ordinal":0},"root":{"type":"project_root_round_even"},"physical":"a730de52-3bb9-4b2f-9d36-3057a494e00e"},"arguments":[],"births":[]},"resume":null,"reanchors":[{"placement":{"reference":{"timing":{"allocation":"f25c247c-d2f8-4e6e-a894-8784e0e5bcdd","ordinal":1},"root":{"type":"project_root_round_even"},"physical":"cef0f3ad-4409-4184-a4a9-c1869bbbb249"},"arguments":[],"births":[]},"window":{"start":{"numerator":"30","denominator":"1"},"end":{"numerator":"120","denominator":"1"}}}]}}},"after":{"timings":[],"bindings":{}}}},"changed_ids":["671d71ba-a1f9-4489-933a-9e70b0445f8e","8258cb00-c1be-4cc3-b9bf-dc99fe08e79c","a730de52-3bb9-4b2f-9d36-3057a494e00e","cef0f3ad-4409-4184-a4a9-c1869bbbb249","ff341750-08d6-48de-ac48-9fec739c8d85"],"duration_delta":-10,"description":"Delete selected range"}');
INSERT INTO "history" VALUES(7,1,'c34f9d51-c8f4-4f49-8fc1-4c96fc74f2c2','{"project_id":"2dbbdca8-d451-4639-8322-38047d33d7ff","expected_revision":"a7175f10-f9d2-4dd1-add9-a1304f4b829d","new_revision":"c34f9d51-c8f4-4f49-8fc1-4c96fc74f2c2","command":{"command":"splice_slice","parent":"671d71ba-a1f9-4489-933a-9e70b0445f8e","index":0,"slice":{"project_id":"2dbbdca8-d451-4639-8322-38047d33d7ff","revision_id":"18b8d6b2-ae92-49c3-8951-86db30e35e6d","capture_timing":{"allocation":"e8e9112f-8d18-4e98-92c4-449a8d786411","ordinal":0},"presentation_basis":{"width":320,"height":180,"frame_rate":{"numerator":30000,"denominator":1001},"color_policy":"sdr_rec709"},"parent":"671d71ba-a1f9-4489-933a-9e70b0445f8e","range":{"start":20,"end":30},"source_duration":120,"parts":[{"root":"a730de52-3bb9-4b2f-9d36-3057a494e00e","mapping":{"start":20,"end":30},"source_start":0}],"nodes":{"a730de52-3bb9-4b2f-9d36-3057a494e00e":{"label":"cfr-bframes.mp4","kind":{"type":"source","source":{"duration":120,"edit_window":{"start":{"numerator":"0","denominator":"1"},"end":{"numerator":"120","denominator":"1"}},"video":{"type":"stream","asset":"8b234d1f-32dd-40fb-b2fa-b743ced54a3d","span":{"start":{"ticks":0,"time_base":{"numerator":1,"denominator":30000}},"end":{"ticks":120120,"time_base":{"numerator":1,"denominator":30000}}}},"video_mapping":{"type":"placement","start":{"numerator":"0","denominator":"1"},"frames":{"numerator":"120","denominator":"1"},"endpoints":"hold_adjacent"},"audio":{"asset":"8b234d1f-32dd-40fb-b2fa-b743ced54a3d","span":{"start":{"ticks":0,"time_base":{"numerator":1,"denominator":48000}},"end":{"ticks":192192,"time_base":{"numerator":1,"denominator":48000}}}},"audio_mapping":{"type":"placement","start":{"numerator":"0","denominator":"1"},"frames":{"numerator":"120","denominator":"1"}},"link":"linked","audio_offset":0}}}},"assets":{"8b234d1f-32dd-40fb-b2fa-b743ced54a3d":{"label":"cfr-bframes.mp4","content_hash":"blake3:16614ec12d06396d3c0f0e7b91cc902c6dc30ad89c28d74b805cf64dc60d8aa1","video":{"start":{"ticks":0,"time_base":{"numerator":1,"denominator":30000}},"end":{"ticks":120120,"time_base":{"numerator":1,"denominator":30000}}},"audio":{"start":{"ticks":0,"time_base":{"numerator":1,"denominator":48000}},"end":{"ticks":192192,"time_base":{"numerator":1,"denominator":48000}}},"still_image":false,"frame_count":120,"source_qualification":"c6bc3e81ab69906267164469d11739cf1363eea546436761ddd219069ed496b6"}},"marks":{},"overrides":{},"gap_overrides":{},"audio_lineage":{},"audio_bindings":{"timings":[{"id":{"allocation":"e8e9112f-8d18-4e98-92c4-449a8d786411","ordinal":0},"layout":{"root":"671d71ba-a1f9-4489-933a-9e70b0445f8e","rate":{"numerator":30000,"denominator":1001},"nodes":{"671d71ba-a1f9-4489-933a-9e70b0445f8e":{"duration":120,"edges":{"node_start":"automatic","node_end":"automatic","source_placement_start":"automatic","source_placement_end":"automatic","repeat_gap_start":"automatic","repeat_gap_end":"automatic"},"kind":{"type":"sequence","children":["a730de52-3bb9-4b2f-9d36-3057a494e00e"]}},"a730de52-3bb9-4b2f-9d36-3057a494e00e":{"duration":120,"edges":{"node_start":"automatic","node_end":"automatic","source_placement_start":"automatic","source_placement_end":"automatic","repeat_gap_start":"automatic","repeat_gap_end":"automatic"},"kind":{"type":"source","placement":{"start":{"numerator":"0","denominator":"1"},"end":{"numerator":"120","denominator":"1"}}}}},"overrides":{}}}],"bindings":{"a730de52-3bb9-4b2f-9d36-3057a494e00e":{"lattice":{"reference":{"timing":{"allocation":"e8e9112f-8d18-4e98-92c4-449a8d786411","ordinal":0},"root":{"type":"project_root_round_even"},"physical":"a730de52-3bb9-4b2f-9d36-3057a494e00e"},"arguments":[],"births":[]},"resume":null,"reanchors":[{"placement":{"reference":{"timing":{"allocation":"e8e9112f-8d18-4e98-92c4-449a8d786411","ordinal":0},"root":{"type":"project_root_round_even"},"physical":"a730de52-3bb9-4b2f-9d36-3057a494e00e"},"arguments":[],"births":[]},"window":{"start":{"numerator":"20","denominator":"1"},"end":{"numerator":"30","denominator":"1"}}}]}}}},"identities":{"authored":{"nodes":["731ce7a8-ca45-44a3-89fc-605693b2c145","3016df70-a4a7-43f0-9cac-91e0cea6d5b6","3614b26f-5472-482b-9d3f-5d0d1ea975f7"],"marks":[]},"aliases":["e534e093-1e07-4894-ba04-274b9e99c331","b50e2535-b968-49fc-8f5e-f7dbfd3de789"]},"timing":{"allocation":"c34f9d51-c8f4-4f49-8fc1-4c96fc74f2c2","ordinal":0}}}','{"forward":{"project_id":"2dbbdca8-d451-4639-8322-38047d33d7ff","from_revision":"a7175f10-f9d2-4dd1-add9-a1304f4b829d","to_revision":"c34f9d51-c8f4-4f49-8fc1-4c96fc74f2c2","nodes":{"3016df70-a4a7-43f0-9cac-91e0cea6d5b6":{"before":null,"after":{"label":"cfr-bframes.mp4","kind":{"type":"source","source":{"duration":120,"edit_window":{"start":{"numerator":"0","denominator":"1"},"end":{"numerator":"120","denominator":"1"}},"video":{"type":"stream","asset":"8b234d1f-32dd-40fb-b2fa-b743ced54a3d","span":{"start":{"ticks":0,"time_base":{"numerator":1,"denominator":30000}},"end":{"ticks":120120,"time_base":{"numerator":1,"denominator":30000}}}},"video_mapping":{"type":"placement","start":{"numerator":"0","denominator":"1"},"frames":{"numerator":"120","denominator":"1"},"endpoints":"hold_adjacent"},"audio":{"asset":"8b234d1f-32dd-40fb-b2fa-b743ced54a3d","span":{"start":{"ticks":0,"time_base":{"numerator":1,"denominator":48000}},"end":{"ticks":192192,"time_base":{"numerator":1,"denominator":48000}}}},"audio_mapping":{"type":"placement","start":{"numerator":"0","denominator":"1"},"frames":{"numerator":"120","denominator":"1"}},"link":"linked","audio_offset":0}}}},"3614b26f-5472-482b-9d3f-5d0d1ea975f7":{"before":null,"after":{"label":"Copied interval","kind":{"type":"retime","child":"3016df70-a4a7-43f0-9cac-91e0cea6d5b6","duration":10,"mapping":{"start":20,"end":30},"pitch":"preserve","purpose":"partition"}}},"671d71ba-a1f9-4489-933a-9e70b0445f8e":{"before":{"label":"Sequence","kind":{"type":"sequence","children":["a730de52-3bb9-4b2f-9d36-3057a494e00e"]}},"after":{"label":"Sequence","kind":{"type":"sequence","children":["731ce7a8-ca45-44a3-89fc-605693b2c145","a730de52-3bb9-4b2f-9d36-3057a494e00e"]}}},"731ce7a8-ca45-44a3-89fc-605693b2c145":{"before":null,"after":{"label":"Copied contents","kind":{"type":"sequence","children":["3614b26f-5472-482b-9d3f-5d0d1ea975f7"]}}}},"assets":{},"marks":{},"overrides":{},"audio_bindings":{"before":{"timings":[],"bindings":{}},"after":{"timings":[{"id":{"allocation":"c34f9d51-c8f4-4f49-8fc1-4c96fc74f2c2","ordinal":0},"layout":{"root":"671d71ba-a1f9-4489-933a-9e70b0445f8e","rate":{"numerator":30000,"denominator":1001},"nodes":{"671d71ba-a1f9-4489-933a-9e70b0445f8e":{"duration":120,"edges":{"node_start":"automatic","node_end":"automatic","source_placement_start":"automatic","source_placement_end":"automatic","repeat_gap_start":"automatic","repeat_gap_end":"automatic"},"kind":{"type":"sequence","children":["a730de52-3bb9-4b2f-9d36-3057a494e00e"]}},"a730de52-3bb9-4b2f-9d36-3057a494e00e":{"duration":120,"edges":{"node_start":"automatic","node_end":"automatic","source_placement_start":"automatic","source_placement_end":"automatic","repeat_gap_start":"automatic","repeat_gap_end":"automatic"},"kind":{"type":"source","placement":{"start":{"numerator":"0","denominator":"1"},"end":{"numerator":"120","denominator":"1"}}}}},"overrides":{}}},{"id":{"allocation":"c34f9d51-c8f4-4f49-8fc1-4c96fc74f2c2","ordinal":1},"layout":{"root":"e534e093-1e07-4894-ba04-274b9e99c331","rate":{"numerator":30000,"denominator":1001},"nodes":{"b50e2535-b968-49fc-8f5e-f7dbfd3de789":{"duration":120,"edges":{"node_start":"automatic","node_end":"automatic","source_placement_start":"automatic","source_placement_end":"automatic","repeat_gap_start":"automatic","repeat_gap_end":"automatic"},"kind":{"type":"source","placement":{"start":{"numerator":"0","denominator":"1"},"end":{"numerator":"120","denominator":"1"}}}},"e534e093-1e07-4894-ba04-274b9e99c331":{"duration":120,"edges":{"node_start":"automatic","node_end":"automatic","source_placement_start":"automatic","source_placement_end":"automatic","repeat_gap_start":"automatic","repeat_gap_end":"automatic"},"kind":{"type":"sequence","children":["b50e2535-b968-49fc-8f5e-f7dbfd3de789"]}}},"overrides":{}}}],"bindings":{"3016df70-a4a7-43f0-9cac-91e0cea6d5b6":{"lattice":{"reference":{"timing":{"allocation":"c34f9d51-c8f4-4f49-8fc1-4c96fc74f2c2","ordinal":1},"root":{"type":"project_root_round_even"},"physical":"b50e2535-b968-49fc-8f5e-f7dbfd3de789"},"arguments":[],"births":[]},"resume":null,"reanchors":[{"placement":{"reference":{"timing":{"allocation":"c34f9d51-c8f4-4f49-8fc1-4c96fc74f2c2","ordinal":1},"root":{"type":"project_root_round_even"},"physical":"b50e2535-b968-49fc-8f5e-f7dbfd3de789"},"arguments":[],"births":[]},"window":{"start":{"numerator":"20","denominator":"1"},"end":{"numerator":"30","denominator":"1"}}}]},"a730de52-3bb9-4b2f-9d36-3057a494e00e":{"lattice":{"reference":{"timing":{"allocation":"c34f9d51-c8f4-4f49-8fc1-4c96fc74f2c2","ordinal":0},"root":{"type":"project_root_round_even"},"physical":"a730de52-3bb9-4b2f-9d36-3057a494e00e"},"arguments":[],"births":[]},"resume":null,"reanchors":[{"placement":{"reference":{"timing":{"allocation":"c34f9d51-c8f4-4f49-8fc1-4c96fc74f2c2","ordinal":0},"root":{"type":"project_root_round_even"},"physical":"a730de52-3bb9-4b2f-9d36-3057a494e00e"},"arguments":[],"births":[]},"window":{"start":{"numerator":"0","denominator":"1"},"end":{"numerator":"120","denominator":"1"}}}]}}}}},"inverse":{"project_id":"2dbbdca8-d451-4639-8322-38047d33d7ff","from_revision":"c34f9d51-c8f4-4f49-8fc1-4c96fc74f2c2","to_revision":"a7175f10-f9d2-4dd1-add9-a1304f4b829d","nodes":{"3016df70-a4a7-43f0-9cac-91e0cea6d5b6":{"before":{"label":"cfr-bframes.mp4","kind":{"type":"source","source":{"duration":120,"edit_window":{"start":{"numerator":"0","denominator":"1"},"end":{"numerator":"120","denominator":"1"}},"video":{"type":"stream","asset":"8b234d1f-32dd-40fb-b2fa-b743ced54a3d","span":{"start":{"ticks":0,"time_base":{"numerator":1,"denominator":30000}},"end":{"ticks":120120,"time_base":{"numerator":1,"denominator":30000}}}},"video_mapping":{"type":"placement","start":{"numerator":"0","denominator":"1"},"frames":{"numerator":"120","denominator":"1"},"endpoints":"hold_adjacent"},"audio":{"asset":"8b234d1f-32dd-40fb-b2fa-b743ced54a3d","span":{"start":{"ticks":0,"time_base":{"numerator":1,"denominator":48000}},"end":{"ticks":192192,"time_base":{"numerator":1,"denominator":48000}}}},"audio_mapping":{"type":"placement","start":{"numerator":"0","denominator":"1"},"frames":{"numerator":"120","denominator":"1"}},"link":"linked","audio_offset":0}}},"after":null},"3614b26f-5472-482b-9d3f-5d0d1ea975f7":{"before":{"label":"Copied interval","kind":{"type":"retime","child":"3016df70-a4a7-43f0-9cac-91e0cea6d5b6","duration":10,"mapping":{"start":20,"end":30},"pitch":"preserve","purpose":"partition"}},"after":null},"671d71ba-a1f9-4489-933a-9e70b0445f8e":{"before":{"label":"Sequence","kind":{"type":"sequence","children":["731ce7a8-ca45-44a3-89fc-605693b2c145","a730de52-3bb9-4b2f-9d36-3057a494e00e"]}},"after":{"label":"Sequence","kind":{"type":"sequence","children":["a730de52-3bb9-4b2f-9d36-3057a494e00e"]}}},"731ce7a8-ca45-44a3-89fc-605693b2c145":{"before":{"label":"Copied contents","kind":{"type":"sequence","children":["3614b26f-5472-482b-9d3f-5d0d1ea975f7"]}},"after":null}},"assets":{},"marks":{},"overrides":{},"audio_bindings":{"before":{"timings":[{"id":{"allocation":"c34f9d51-c8f4-4f49-8fc1-4c96fc74f2c2","ordinal":0},"layout":{"root":"671d71ba-a1f9-4489-933a-9e70b0445f8e","rate":{"numerator":30000,"denominator":1001},"nodes":{"671d71ba-a1f9-4489-933a-9e70b0445f8e":{"duration":120,"edges":{"node_start":"automatic","node_end":"automatic","source_placement_start":"automatic","source_placement_end":"automatic","repeat_gap_start":"automatic","repeat_gap_end":"automatic"},"kind":{"type":"sequence","children":["a730de52-3bb9-4b2f-9d36-3057a494e00e"]}},"a730de52-3bb9-4b2f-9d36-3057a494e00e":{"duration":120,"edges":{"node_start":"automatic","node_end":"automatic","source_placement_start":"automatic","source_placement_end":"automatic","repeat_gap_start":"automatic","repeat_gap_end":"automatic"},"kind":{"type":"source","placement":{"start":{"numerator":"0","denominator":"1"},"end":{"numerator":"120","denominator":"1"}}}}},"overrides":{}}},{"id":{"allocation":"c34f9d51-c8f4-4f49-8fc1-4c96fc74f2c2","ordinal":1},"layout":{"root":"e534e093-1e07-4894-ba04-274b9e99c331","rate":{"numerator":30000,"denominator":1001},"nodes":{"b50e2535-b968-49fc-8f5e-f7dbfd3de789":{"duration":120,"edges":{"node_start":"automatic","node_end":"automatic","source_placement_start":"automatic","source_placement_end":"automatic","repeat_gap_start":"automatic","repeat_gap_end":"automatic"},"kind":{"type":"source","placement":{"start":{"numerator":"0","denominator":"1"},"end":{"numerator":"120","denominator":"1"}}}},"e534e093-1e07-4894-ba04-274b9e99c331":{"duration":120,"edges":{"node_start":"automatic","node_end":"automatic","source_placement_start":"automatic","source_placement_end":"automatic","repeat_gap_start":"automatic","repeat_gap_end":"automatic"},"kind":{"type":"sequence","children":["b50e2535-b968-49fc-8f5e-f7dbfd3de789"]}}},"overrides":{}}}],"bindings":{"3016df70-a4a7-43f0-9cac-91e0cea6d5b6":{"lattice":{"reference":{"timing":{"allocation":"c34f9d51-c8f4-4f49-8fc1-4c96fc74f2c2","ordinal":1},"root":{"type":"project_root_round_even"},"physical":"b50e2535-b968-49fc-8f5e-f7dbfd3de789"},"arguments":[],"births":[]},"resume":null,"reanchors":[{"placement":{"reference":{"timing":{"allocation":"c34f9d51-c8f4-4f49-8fc1-4c96fc74f2c2","ordinal":1},"root":{"type":"project_root_round_even"},"physical":"b50e2535-b968-49fc-8f5e-f7dbfd3de789"},"arguments":[],"births":[]},"window":{"start":{"numerator":"20","denominator":"1"},"end":{"numerator":"30","denominator":"1"}}}]},"a730de52-3bb9-4b2f-9d36-3057a494e00e":{"lattice":{"reference":{"timing":{"allocation":"c34f9d51-c8f4-4f49-8fc1-4c96fc74f2c2","ordinal":0},"root":{"type":"project_root_round_even"},"physical":"a730de52-3bb9-4b2f-9d36-3057a494e00e"},"arguments":[],"births":[]},"resume":null,"reanchors":[{"placement":{"reference":{"timing":{"allocation":"c34f9d51-c8f4-4f49-8fc1-4c96fc74f2c2","ordinal":0},"root":{"type":"project_root_round_even"},"physical":"a730de52-3bb9-4b2f-9d36-3057a494e00e"},"arguments":[],"births":[]},"window":{"start":{"numerator":"0","denominator":"1"},"end":{"numerator":"120","denominator":"1"}}}]}}},"after":{"timings":[],"bindings":{}}}},"changed_ids":["3016df70-a4a7-43f0-9cac-91e0cea6d5b6","3614b26f-5472-482b-9d3f-5d0d1ea975f7","671d71ba-a1f9-4489-933a-9e70b0445f8e","731ce7a8-ca45-44a3-89fc-605693b2c145","a730de52-3bb9-4b2f-9d36-3057a494e00e"],"duration_delta":10,"description":"Paste edited slice"}');
CREATE TABLE hold_request_clocks (
    hold_id TEXT PRIMARY KEY,
    high_water INTEGER NOT NULL
        CHECK (high_water BETWEEN 1 AND 9223372036854775807)
) STRICT;
CREATE TABLE original_media (
        content_id TEXT PRIMARY KEY,
        version INTEGER NOT NULL CHECK(version > 0),
        record TEXT NOT NULL CHECK(json_valid(record))
    ) STRICT;
INSERT INTO "original_media" VALUES('blake3:16614ec12d06396d3c0f0e7b91cc902c6dc30ad89c28d74b805cf64dc60d8aa1',1,'{"object":{"content":{"algorithm":"blake3","digest":"16614ec12d06396d3c0f0e7b91cc902c6dc30ad89c28d74b805cf64dc60d8aa1"},"byte_length":39157},"sha256":[90,130,10,121,191,85,13,72,77,142,203,55,255,221,208,72,208,99,103,148,235,206,93,184,62,79,92,229,245,230,73,24],"label":"cfr-bframes.mp4","version":1,"managed":true,"linked":null}');
CREATE TABLE redo (
            position INTEGER PRIMARY KEY,
            history_id INTEGER NOT NULL REFERENCES history(id)
        ) STRICT;
INSERT INTO "redo" VALUES(1,7);
CREATE TABLE render_attempts (
        job_id TEXT NOT NULL REFERENCES render_jobs(job_id), attempt_id TEXT PRIMARY KEY,
        ordinal INTEGER NOT NULL CHECK(ordinal BETWEEN 1 AND 9223372036854775807),
        cancellation_token TEXT NOT NULL, state TEXT NOT NULL,
        transition_sequence INTEGER NOT NULL CHECK(transition_sequence BETWEEN 1 AND 9223372036854775807),
        body TEXT NOT NULL CHECK(json_valid(body)), UNIQUE(job_id,ordinal), UNIQUE(job_id,attempt_id)
    ) STRICT;
CREATE TABLE render_candidate_checkpoints (
        job_id TEXT NOT NULL, attempt_id TEXT PRIMARY KEY,
        media TEXT NOT NULL CHECK(json_valid(media)),
        FOREIGN KEY(job_id,attempt_id) REFERENCES render_attempts(job_id,attempt_id)
    ) STRICT;
CREATE TABLE render_encoding_decisions (
        job_id TEXT NOT NULL, attempt_id TEXT PRIMARY KEY,
        body TEXT NOT NULL CHECK(json_valid(body)),
        FOREIGN KEY(job_id,attempt_id) REFERENCES render_attempts(job_id,attempt_id)
    ) STRICT;
CREATE TABLE render_job_heads (
        job_id TEXT PRIMARY KEY REFERENCES render_jobs(job_id),
        high_water INTEGER NOT NULL CHECK(high_water BETWEEN 1 AND 9223372036854775807),
        latest_attempt_id TEXT NOT NULL,
        FOREIGN KEY(job_id,latest_attempt_id) REFERENCES render_attempts(job_id,attempt_id)
    ) STRICT;
CREATE TABLE render_jobs (
        job_id TEXT PRIMARY KEY, revision_id TEXT NOT NULL REFERENCES revisions(id),
        intent TEXT NOT NULL CHECK(json_valid(intent))
    ) STRICT;
CREATE TABLE render_publication_operations (
        operation_id TEXT PRIMARY KEY, publication_id TEXT NOT NULL REFERENCES render_publications(publication_id),
        ordinal INTEGER NOT NULL CHECK(ordinal BETWEEN 1 AND 9223372036854775807),
        cancellation_token TEXT NOT NULL UNIQUE, active INTEGER NOT NULL CHECK(active IN (0,1)),
        body TEXT NOT NULL CHECK(json_valid(body)), UNIQUE(publication_id,ordinal)
    ) STRICT;
CREATE TABLE render_publications (
        publication_id TEXT PRIMARY KEY, job_id TEXT NOT NULL REFERENCES render_jobs(job_id),
        sequence INTEGER NOT NULL CHECK(sequence BETWEEN 1 AND 9223372036854775807),
        body TEXT NOT NULL CHECK(json_valid(body))
    ) STRICT;
CREATE TABLE revisions (
            id TEXT PRIMARY KEY,
            parent_id TEXT REFERENCES revisions(id),
            kind TEXT NOT NULL CHECK (kind IN ('initial','edit','undo','redo')),
            document TEXT NOT NULL CHECK (json_valid(document))
        ) STRICT;
INSERT INTO "revisions" VALUES('94af3121-2605-4161-9413-5c27a97c5287',NULL,'initial','{
  "schema_version": 43,
  "project_id": "2dbbdca8-d451-4639-8322-38047d33d7ff",
  "revision_id": "94af3121-2605-4161-9413-5c27a97c5287",
  "presentation_basis": {
    "width": 1920,
    "height": 1080,
    "frame_rate": {
      "numerator": 30,
      "denominator": 1
    },
    "color_policy": "sdr_rec709"
  },
  "basis_state": {
    "rate_origin": "provisional",
    "geometry_origin": "default",
    "primary": null
  },
  "root": "671d71ba-a1f9-4489-933a-9e70b0445f8e",
  "nodes": {
    "671d71ba-a1f9-4489-933a-9e70b0445f8e": {
      "label": "Sequence",
      "kind": {
        "type": "sequence",
        "children": []
      }
    }
  },
  "assets": {},
  "marks": {},
  "overrides": {}
}
');
INSERT INTO "revisions" VALUES('18e36cb1-afc9-407d-b7ab-d9df09d17634','94af3121-2605-4161-9413-5c27a97c5287','edit','{
  "schema_version": 43,
  "project_id": "2dbbdca8-d451-4639-8322-38047d33d7ff",
  "revision_id": "18e36cb1-afc9-407d-b7ab-d9df09d17634",
  "presentation_basis": {
    "width": 320,
    "height": 180,
    "frame_rate": {
      "numerator": 30000,
      "denominator": 1001
    },
    "color_policy": "sdr_rec709"
  },
  "basis_state": {
    "rate_origin": "primary_source",
    "geometry_origin": "primary_source",
    "primary": {
      "asset": "8b234d1f-32dd-40fb-b2fa-b743ced54a3d",
      "qualification": "c6bc3e81ab69906267164469d11739cf1363eea546436761ddd219069ed496b6"
    }
  },
  "root": "671d71ba-a1f9-4489-933a-9e70b0445f8e",
  "nodes": {
    "671d71ba-a1f9-4489-933a-9e70b0445f8e": {
      "label": "Sequence",
      "kind": {
        "type": "sequence",
        "children": [
          "a730de52-3bb9-4b2f-9d36-3057a494e00e"
        ]
      }
    },
    "a730de52-3bb9-4b2f-9d36-3057a494e00e": {
      "label": "cfr-bframes.mp4",
      "kind": {
        "type": "source",
        "source": {
          "duration": 120,
          "edit_window": {
            "start": {
              "numerator": "0",
              "denominator": "1"
            },
            "end": {
              "numerator": "120",
              "denominator": "1"
            }
          },
          "video": {
            "type": "stream",
            "asset": "8b234d1f-32dd-40fb-b2fa-b743ced54a3d",
            "span": {
              "start": {
                "ticks": 0,
                "time_base": {
                  "numerator": 1,
                  "denominator": 30000
                }
              },
              "end": {
                "ticks": 120120,
                "time_base": {
                  "numerator": 1,
                  "denominator": 30000
                }
              }
            }
          },
          "video_mapping": {
            "type": "placement",
            "start": {
              "numerator": "0",
              "denominator": "1"
            },
            "frames": {
              "numerator": "120",
              "denominator": "1"
            },
            "endpoints": "hold_adjacent"
          },
          "audio": {
            "asset": "8b234d1f-32dd-40fb-b2fa-b743ced54a3d",
            "span": {
              "start": {
                "ticks": 0,
                "time_base": {
                  "numerator": 1,
                  "denominator": 48000
                }
              },
              "end": {
                "ticks": 192192,
                "time_base": {
                  "numerator": 1,
                  "denominator": 48000
                }
              }
            }
          },
          "audio_mapping": {
            "type": "placement",
            "start": {
              "numerator": "0",
              "denominator": "1"
            },
            "frames": {
              "numerator": "120",
              "denominator": "1"
            }
          },
          "link": "linked",
          "audio_offset": 0
        }
      }
    }
  },
  "assets": {
    "8b234d1f-32dd-40fb-b2fa-b743ced54a3d": {
      "label": "cfr-bframes.mp4",
      "content_hash": "blake3:16614ec12d06396d3c0f0e7b91cc902c6dc30ad89c28d74b805cf64dc60d8aa1",
      "video": {
        "start": {
          "ticks": 0,
          "time_base": {
            "numerator": 1,
            "denominator": 30000
          }
        },
        "end": {
          "ticks": 120120,
          "time_base": {
            "numerator": 1,
            "denominator": 30000
          }
        }
      },
      "audio": {
        "start": {
          "ticks": 0,
          "time_base": {
            "numerator": 1,
            "denominator": 48000
          }
        },
        "end": {
          "ticks": 192192,
          "time_base": {
            "numerator": 1,
            "denominator": 48000
          }
        }
      },
      "still_image": false,
      "frame_count": 120,
      "source_qualification": "c6bc3e81ab69906267164469d11739cf1363eea546436761ddd219069ed496b6"
    }
  },
  "marks": {},
  "overrides": {}
}
');
INSERT INTO "revisions" VALUES('052ce465-5039-49b9-80bf-a7dfaa7129af','18e36cb1-afc9-407d-b7ab-d9df09d17634','edit','{
  "schema_version": 43,
  "project_id": "2dbbdca8-d451-4639-8322-38047d33d7ff",
  "revision_id": "052ce465-5039-49b9-80bf-a7dfaa7129af",
  "presentation_basis": {
    "width": 320,
    "height": 180,
    "frame_rate": {
      "numerator": 30000,
      "denominator": 1001
    },
    "color_policy": "sdr_rec709"
  },
  "basis_state": {
    "rate_origin": "primary_source",
    "geometry_origin": "primary_source",
    "primary": {
      "asset": "8b234d1f-32dd-40fb-b2fa-b743ced54a3d",
      "qualification": "c6bc3e81ab69906267164469d11739cf1363eea546436761ddd219069ed496b6"
    }
  },
  "root": "671d71ba-a1f9-4489-933a-9e70b0445f8e",
  "nodes": {
    "671d71ba-a1f9-4489-933a-9e70b0445f8e": {
      "label": "Sequence",
      "kind": {
        "type": "sequence",
        "children": [
          "a730de52-3bb9-4b2f-9d36-3057a494e00e",
          "91353585-2a36-423c-bed0-6a218ea8153a"
        ]
      }
    },
    "91353585-2a36-423c-bed0-6a218ea8153a": {
      "label": "cfr-bframes.mp4 [5..13)",
      "kind": {
        "type": "source",
        "source": {
          "duration": 8,
          "edit_window": {
            "start": {
              "numerator": "0",
              "denominator": "1"
            },
            "end": {
              "numerator": "8",
              "denominator": "1"
            }
          },
          "video": {
            "type": "stream",
            "asset": "8b234d1f-32dd-40fb-b2fa-b743ced54a3d",
            "span": {
              "start": {
                "ticks": 0,
                "time_base": {
                  "numerator": 1,
                  "denominator": 30000
                }
              },
              "end": {
                "ticks": 120120,
                "time_base": {
                  "numerator": 1,
                  "denominator": 30000
                }
              }
            }
          },
          "video_mapping": {
            "type": "selected_placement",
            "start": {
              "numerator": "-5",
              "denominator": "1"
            },
            "frames": {
              "numerator": "120",
              "denominator": "1"
            },
            "selection": {
              "start": {
                "numerator": "0",
                "denominator": "1"
              },
              "end": {
                "numerator": "8",
                "denominator": "1"
              }
            },
            "endpoints": "hold_adjacent"
          },
          "audio": {
            "asset": "8b234d1f-32dd-40fb-b2fa-b743ced54a3d",
            "span": {
              "start": {
                "ticks": 0,
                "time_base": {
                  "numerator": 1,
                  "denominator": 48000
                }
              },
              "end": {
                "ticks": 192192,
                "time_base": {
                  "numerator": 1,
                  "denominator": 48000
                }
              }
            }
          },
          "audio_mapping": {
            "type": "selected_placement",
            "start": {
              "numerator": "-5",
              "denominator": "1"
            },
            "frames": {
              "numerator": "120",
              "denominator": "1"
            },
            "selection": {
              "start": {
                "numerator": "0",
                "denominator": "1"
              },
              "end": {
                "numerator": "8",
                "denominator": "1"
              }
            }
          },
          "link": "linked",
          "audio_offset": 0
        }
      }
    },
    "a730de52-3bb9-4b2f-9d36-3057a494e00e": {
      "label": "cfr-bframes.mp4",
      "kind": {
        "type": "source",
        "source": {
          "duration": 120,
          "edit_window": {
            "start": {
              "numerator": "0",
              "denominator": "1"
            },
            "end": {
              "numerator": "120",
              "denominator": "1"
            }
          },
          "video": {
            "type": "stream",
            "asset": "8b234d1f-32dd-40fb-b2fa-b743ced54a3d",
            "span": {
              "start": {
                "ticks": 0,
                "time_base": {
                  "numerator": 1,
                  "denominator": 30000
                }
              },
              "end": {
                "ticks": 120120,
                "time_base": {
                  "numerator": 1,
                  "denominator": 30000
                }
              }
            }
          },
          "video_mapping": {
            "type": "placement",
            "start": {
              "numerator": "0",
              "denominator": "1"
            },
            "frames": {
              "numerator": "120",
              "denominator": "1"
            },
            "endpoints": "hold_adjacent"
          },
          "audio": {
            "asset": "8b234d1f-32dd-40fb-b2fa-b743ced54a3d",
            "span": {
              "start": {
                "ticks": 0,
                "time_base": {
                  "numerator": 1,
                  "denominator": 48000
                }
              },
              "end": {
                "ticks": 192192,
                "time_base": {
                  "numerator": 1,
                  "denominator": 48000
                }
              }
            }
          },
          "audio_mapping": {
            "type": "placement",
            "start": {
              "numerator": "0",
              "denominator": "1"
            },
            "frames": {
              "numerator": "120",
              "denominator": "1"
            }
          },
          "link": "linked",
          "audio_offset": 0
        }
      }
    }
  },
  "assets": {
    "8b234d1f-32dd-40fb-b2fa-b743ced54a3d": {
      "label": "cfr-bframes.mp4",
      "content_hash": "blake3:16614ec12d06396d3c0f0e7b91cc902c6dc30ad89c28d74b805cf64dc60d8aa1",
      "video": {
        "start": {
          "ticks": 0,
          "time_base": {
            "numerator": 1,
            "denominator": 30000
          }
        },
        "end": {
          "ticks": 120120,
          "time_base": {
            "numerator": 1,
            "denominator": 30000
          }
        }
      },
      "audio": {
        "start": {
          "ticks": 0,
          "time_base": {
            "numerator": 1,
            "denominator": 48000
          }
        },
        "end": {
          "ticks": 192192,
          "time_base": {
            "numerator": 1,
            "denominator": 48000
          }
        }
      },
      "still_image": false,
      "frame_count": 120,
      "source_qualification": "c6bc3e81ab69906267164469d11739cf1363eea546436761ddd219069ed496b6"
    }
  },
  "marks": {},
  "overrides": {},
  "audio_bindings": {
    "timings": [
      {
        "id": {
          "allocation": "052ce465-5039-49b9-80bf-a7dfaa7129af",
          "ordinal": 0
        },
        "layout": {
          "root": "671d71ba-a1f9-4489-933a-9e70b0445f8e",
          "rate": {
            "numerator": 30000,
            "denominator": 1001
          },
          "nodes": {
            "671d71ba-a1f9-4489-933a-9e70b0445f8e": {
              "duration": 120,
              "edges": {
                "node_start": "automatic",
                "node_end": "automatic",
                "source_placement_start": "automatic",
                "source_placement_end": "automatic",
                "repeat_gap_start": "automatic",
                "repeat_gap_end": "automatic"
              },
              "kind": {
                "type": "sequence",
                "children": [
                  "a730de52-3bb9-4b2f-9d36-3057a494e00e"
                ]
              }
            },
            "a730de52-3bb9-4b2f-9d36-3057a494e00e": {
              "duration": 120,
              "edges": {
                "node_start": "automatic",
                "node_end": "automatic",
                "source_placement_start": "automatic",
                "source_placement_end": "automatic",
                "repeat_gap_start": "automatic",
                "repeat_gap_end": "automatic"
              },
              "kind": {
                "type": "source",
                "placement": {
                  "start": {
                    "numerator": "0",
                    "denominator": "1"
                  },
                  "end": {
                    "numerator": "120",
                    "denominator": "1"
                  }
                }
              }
            }
          },
          "overrides": {}
        }
      }
    ],
    "bindings": {
      "a730de52-3bb9-4b2f-9d36-3057a494e00e": {
        "lattice": {
          "reference": {
            "timing": {
              "allocation": "052ce465-5039-49b9-80bf-a7dfaa7129af",
              "ordinal": 0
            },
            "root": {
              "type": "project_root_round_even"
            },
            "physical": "a730de52-3bb9-4b2f-9d36-3057a494e00e"
          },
          "arguments": [],
          "births": []
        },
        "resume": null
      }
    }
  }
}
');
INSERT INTO "revisions" VALUES('c9b006f2-cc9e-45a2-818e-9ec94aefd2ea','052ce465-5039-49b9-80bf-a7dfaa7129af','undo','{
  "schema_version": 43,
  "project_id": "2dbbdca8-d451-4639-8322-38047d33d7ff",
  "revision_id": "c9b006f2-cc9e-45a2-818e-9ec94aefd2ea",
  "presentation_basis": {
    "width": 320,
    "height": 180,
    "frame_rate": {
      "numerator": 30000,
      "denominator": 1001
    },
    "color_policy": "sdr_rec709"
  },
  "basis_state": {
    "rate_origin": "primary_source",
    "geometry_origin": "primary_source",
    "primary": {
      "asset": "8b234d1f-32dd-40fb-b2fa-b743ced54a3d",
      "qualification": "c6bc3e81ab69906267164469d11739cf1363eea546436761ddd219069ed496b6"
    }
  },
  "root": "671d71ba-a1f9-4489-933a-9e70b0445f8e",
  "nodes": {
    "671d71ba-a1f9-4489-933a-9e70b0445f8e": {
      "label": "Sequence",
      "kind": {
        "type": "sequence",
        "children": [
          "a730de52-3bb9-4b2f-9d36-3057a494e00e"
        ]
      }
    },
    "a730de52-3bb9-4b2f-9d36-3057a494e00e": {
      "label": "cfr-bframes.mp4",
      "kind": {
        "type": "source",
        "source": {
          "duration": 120,
          "edit_window": {
            "start": {
              "numerator": "0",
              "denominator": "1"
            },
            "end": {
              "numerator": "120",
              "denominator": "1"
            }
          },
          "video": {
            "type": "stream",
            "asset": "8b234d1f-32dd-40fb-b2fa-b743ced54a3d",
            "span": {
              "start": {
                "ticks": 0,
                "time_base": {
                  "numerator": 1,
                  "denominator": 30000
                }
              },
              "end": {
                "ticks": 120120,
                "time_base": {
                  "numerator": 1,
                  "denominator": 30000
                }
              }
            }
          },
          "video_mapping": {
            "type": "placement",
            "start": {
              "numerator": "0",
              "denominator": "1"
            },
            "frames": {
              "numerator": "120",
              "denominator": "1"
            },
            "endpoints": "hold_adjacent"
          },
          "audio": {
            "asset": "8b234d1f-32dd-40fb-b2fa-b743ced54a3d",
            "span": {
              "start": {
                "ticks": 0,
                "time_base": {
                  "numerator": 1,
                  "denominator": 48000
                }
              },
              "end": {
                "ticks": 192192,
                "time_base": {
                  "numerator": 1,
                  "denominator": 48000
                }
              }
            }
          },
          "audio_mapping": {
            "type": "placement",
            "start": {
              "numerator": "0",
              "denominator": "1"
            },
            "frames": {
              "numerator": "120",
              "denominator": "1"
            }
          },
          "link": "linked",
          "audio_offset": 0
        }
      }
    }
  },
  "assets": {
    "8b234d1f-32dd-40fb-b2fa-b743ced54a3d": {
      "label": "cfr-bframes.mp4",
      "content_hash": "blake3:16614ec12d06396d3c0f0e7b91cc902c6dc30ad89c28d74b805cf64dc60d8aa1",
      "video": {
        "start": {
          "ticks": 0,
          "time_base": {
            "numerator": 1,
            "denominator": 30000
          }
        },
        "end": {
          "ticks": 120120,
          "time_base": {
            "numerator": 1,
            "denominator": 30000
          }
        }
      },
      "audio": {
        "start": {
          "ticks": 0,
          "time_base": {
            "numerator": 1,
            "denominator": 48000
          }
        },
        "end": {
          "ticks": 192192,
          "time_base": {
            "numerator": 1,
            "denominator": 48000
          }
        }
      },
      "still_image": false,
      "frame_count": 120,
      "source_qualification": "c6bc3e81ab69906267164469d11739cf1363eea546436761ddd219069ed496b6"
    }
  },
  "marks": {},
  "overrides": {}
}
');
INSERT INTO "revisions" VALUES('55d7f95c-9d25-43ae-bb16-97f2b104cd64','c9b006f2-cc9e-45a2-818e-9ec94aefd2ea','edit','{
  "schema_version": 43,
  "project_id": "2dbbdca8-d451-4639-8322-38047d33d7ff",
  "revision_id": "55d7f95c-9d25-43ae-bb16-97f2b104cd64",
  "presentation_basis": {
    "width": 320,
    "height": 180,
    "frame_rate": {
      "numerator": 30000,
      "denominator": 1001
    },
    "color_policy": "sdr_rec709"
  },
  "basis_state": {
    "rate_origin": "primary_source",
    "geometry_origin": "primary_source",
    "primary": {
      "asset": "8b234d1f-32dd-40fb-b2fa-b743ced54a3d",
      "qualification": "c6bc3e81ab69906267164469d11739cf1363eea546436761ddd219069ed496b6"
    }
  },
  "root": "671d71ba-a1f9-4489-933a-9e70b0445f8e",
  "nodes": {
    "671d71ba-a1f9-4489-933a-9e70b0445f8e": {
      "label": "Sequence",
      "kind": {
        "type": "sequence",
        "children": [
          "a23d334c-36c2-49a5-a4ea-c83b554a4891",
          "a730de52-3bb9-4b2f-9d36-3057a494e00e"
        ]
      }
    },
    "a23d334c-36c2-49a5-a4ea-c83b554a4891": {
      "label": "cfr-bframes.mp4 [30..35)",
      "kind": {
        "type": "source",
        "source": {
          "duration": 5,
          "edit_window": {
            "start": {
              "numerator": "0",
              "denominator": "1"
            },
            "end": {
              "numerator": "5",
              "denominator": "1"
            }
          },
          "video": {
            "type": "stream",
            "asset": "8b234d1f-32dd-40fb-b2fa-b743ced54a3d",
            "span": {
              "start": {
                "ticks": 0,
                "time_base": {
                  "numerator": 1,
                  "denominator": 30000
                }
              },
              "end": {
                "ticks": 120120,
                "time_base": {
                  "numerator": 1,
                  "denominator": 30000
                }
              }
            }
          },
          "video_mapping": {
            "type": "selected_placement",
            "start": {
              "numerator": "-30",
              "denominator": "1"
            },
            "frames": {
              "numerator": "120",
              "denominator": "1"
            },
            "selection": {
              "start": {
                "numerator": "0",
                "denominator": "1"
              },
              "end": {
                "numerator": "5",
                "denominator": "1"
              }
            },
            "endpoints": "hold_adjacent"
          },
          "audio": {
            "asset": "8b234d1f-32dd-40fb-b2fa-b743ced54a3d",
            "span": {
              "start": {
                "ticks": 0,
                "time_base": {
                  "numerator": 1,
                  "denominator": 48000
                }
              },
              "end": {
                "ticks": 192192,
                "time_base": {
                  "numerator": 1,
                  "denominator": 48000
                }
              }
            }
          },
          "audio_mapping": {
            "type": "selected_placement",
            "start": {
              "numerator": "-30",
              "denominator": "1"
            },
            "frames": {
              "numerator": "120",
              "denominator": "1"
            },
            "selection": {
              "start": {
                "numerator": "0",
                "denominator": "1"
              },
              "end": {
                "numerator": "5",
                "denominator": "1"
              }
            }
          },
          "link": "linked",
          "audio_offset": 0
        }
      }
    },
    "a730de52-3bb9-4b2f-9d36-3057a494e00e": {
      "label": "cfr-bframes.mp4",
      "kind": {
        "type": "source",
        "source": {
          "duration": 120,
          "edit_window": {
            "start": {
              "numerator": "0",
              "denominator": "1"
            },
            "end": {
              "numerator": "120",
              "denominator": "1"
            }
          },
          "video": {
            "type": "stream",
            "asset": "8b234d1f-32dd-40fb-b2fa-b743ced54a3d",
            "span": {
              "start": {
                "ticks": 0,
                "time_base": {
                  "numerator": 1,
                  "denominator": 30000
                }
              },
              "end": {
                "ticks": 120120,
                "time_base": {
                  "numerator": 1,
                  "denominator": 30000
                }
              }
            }
          },
          "video_mapping": {
            "type": "placement",
            "start": {
              "numerator": "0",
              "denominator": "1"
            },
            "frames": {
              "numerator": "120",
              "denominator": "1"
            },
            "endpoints": "hold_adjacent"
          },
          "audio": {
            "asset": "8b234d1f-32dd-40fb-b2fa-b743ced54a3d",
            "span": {
              "start": {
                "ticks": 0,
                "time_base": {
                  "numerator": 1,
                  "denominator": 48000
                }
              },
              "end": {
                "ticks": 192192,
                "time_base": {
                  "numerator": 1,
                  "denominator": 48000
                }
              }
            }
          },
          "audio_mapping": {
            "type": "placement",
            "start": {
              "numerator": "0",
              "denominator": "1"
            },
            "frames": {
              "numerator": "120",
              "denominator": "1"
            }
          },
          "link": "linked",
          "audio_offset": 0
        }
      }
    }
  },
  "assets": {
    "8b234d1f-32dd-40fb-b2fa-b743ced54a3d": {
      "label": "cfr-bframes.mp4",
      "content_hash": "blake3:16614ec12d06396d3c0f0e7b91cc902c6dc30ad89c28d74b805cf64dc60d8aa1",
      "video": {
        "start": {
          "ticks": 0,
          "time_base": {
            "numerator": 1,
            "denominator": 30000
          }
        },
        "end": {
          "ticks": 120120,
          "time_base": {
            "numerator": 1,
            "denominator": 30000
          }
        }
      },
      "audio": {
        "start": {
          "ticks": 0,
          "time_base": {
            "numerator": 1,
            "denominator": 48000
          }
        },
        "end": {
          "ticks": 192192,
          "time_base": {
            "numerator": 1,
            "denominator": 48000
          }
        }
      },
      "still_image": false,
      "frame_count": 120,
      "source_qualification": "c6bc3e81ab69906267164469d11739cf1363eea546436761ddd219069ed496b6"
    }
  },
  "marks": {},
  "overrides": {},
  "audio_bindings": {
    "timings": [
      {
        "id": {
          "allocation": "55d7f95c-9d25-43ae-bb16-97f2b104cd64",
          "ordinal": 0
        },
        "layout": {
          "root": "671d71ba-a1f9-4489-933a-9e70b0445f8e",
          "rate": {
            "numerator": 30000,
            "denominator": 1001
          },
          "nodes": {
            "671d71ba-a1f9-4489-933a-9e70b0445f8e": {
              "duration": 120,
              "edges": {
                "node_start": "automatic",
                "node_end": "automatic",
                "source_placement_start": "automatic",
                "source_placement_end": "automatic",
                "repeat_gap_start": "automatic",
                "repeat_gap_end": "automatic"
              },
              "kind": {
                "type": "sequence",
                "children": [
                  "a730de52-3bb9-4b2f-9d36-3057a494e00e"
                ]
              }
            },
            "a730de52-3bb9-4b2f-9d36-3057a494e00e": {
              "duration": 120,
              "edges": {
                "node_start": "automatic",
                "node_end": "automatic",
                "source_placement_start": "automatic",
                "source_placement_end": "automatic",
                "repeat_gap_start": "automatic",
                "repeat_gap_end": "automatic"
              },
              "kind": {
                "type": "source",
                "placement": {
                  "start": {
                    "numerator": "0",
                    "denominator": "1"
                  },
                  "end": {
                    "numerator": "120",
                    "denominator": "1"
                  }
                }
              }
            }
          },
          "overrides": {}
        }
      }
    ],
    "bindings": {
      "a730de52-3bb9-4b2f-9d36-3057a494e00e": {
        "lattice": {
          "reference": {
            "timing": {
              "allocation": "55d7f95c-9d25-43ae-bb16-97f2b104cd64",
              "ordinal": 0
            },
            "root": {
              "type": "project_root_round_even"
            },
            "physical": "a730de52-3bb9-4b2f-9d36-3057a494e00e"
          },
          "arguments": [],
          "births": []
        },
        "resume": null,
        "reanchors": [
          {
            "placement": {
              "reference": {
                "timing": {
                  "allocation": "55d7f95c-9d25-43ae-bb16-97f2b104cd64",
                  "ordinal": 0
                },
                "root": {
                  "type": "project_root_round_even"
                },
                "physical": "a730de52-3bb9-4b2f-9d36-3057a494e00e"
              },
              "arguments": [],
              "births": []
            },
            "window": {
              "start": {
                "numerator": "0",
                "denominator": "1"
              },
              "end": {
                "numerator": "120",
                "denominator": "1"
              }
            }
          }
        ]
      }
    }
  }
}
');
INSERT INTO "revisions" VALUES('d6643e11-0c07-4bc4-8885-c779aacdb3e5','55d7f95c-9d25-43ae-bb16-97f2b104cd64','undo','{
  "schema_version": 43,
  "project_id": "2dbbdca8-d451-4639-8322-38047d33d7ff",
  "revision_id": "d6643e11-0c07-4bc4-8885-c779aacdb3e5",
  "presentation_basis": {
    "width": 320,
    "height": 180,
    "frame_rate": {
      "numerator": 30000,
      "denominator": 1001
    },
    "color_policy": "sdr_rec709"
  },
  "basis_state": {
    "rate_origin": "primary_source",
    "geometry_origin": "primary_source",
    "primary": {
      "asset": "8b234d1f-32dd-40fb-b2fa-b743ced54a3d",
      "qualification": "c6bc3e81ab69906267164469d11739cf1363eea546436761ddd219069ed496b6"
    }
  },
  "root": "671d71ba-a1f9-4489-933a-9e70b0445f8e",
  "nodes": {
    "671d71ba-a1f9-4489-933a-9e70b0445f8e": {
      "label": "Sequence",
      "kind": {
        "type": "sequence",
        "children": [
          "a730de52-3bb9-4b2f-9d36-3057a494e00e"
        ]
      }
    },
    "a730de52-3bb9-4b2f-9d36-3057a494e00e": {
      "label": "cfr-bframes.mp4",
      "kind": {
        "type": "source",
        "source": {
          "duration": 120,
          "edit_window": {
            "start": {
              "numerator": "0",
              "denominator": "1"
            },
            "end": {
              "numerator": "120",
              "denominator": "1"
            }
          },
          "video": {
            "type": "stream",
            "asset": "8b234d1f-32dd-40fb-b2fa-b743ced54a3d",
            "span": {
              "start": {
                "ticks": 0,
                "time_base": {
                  "numerator": 1,
                  "denominator": 30000
                }
              },
              "end": {
                "ticks": 120120,
                "time_base": {
                  "numerator": 1,
                  "denominator": 30000
                }
              }
            }
          },
          "video_mapping": {
            "type": "placement",
            "start": {
              "numerator": "0",
              "denominator": "1"
            },
            "frames": {
              "numerator": "120",
              "denominator": "1"
            },
            "endpoints": "hold_adjacent"
          },
          "audio": {
            "asset": "8b234d1f-32dd-40fb-b2fa-b743ced54a3d",
            "span": {
              "start": {
                "ticks": 0,
                "time_base": {
                  "numerator": 1,
                  "denominator": 48000
                }
              },
              "end": {
                "ticks": 192192,
                "time_base": {
                  "numerator": 1,
                  "denominator": 48000
                }
              }
            }
          },
          "audio_mapping": {
            "type": "placement",
            "start": {
              "numerator": "0",
              "denominator": "1"
            },
            "frames": {
              "numerator": "120",
              "denominator": "1"
            }
          },
          "link": "linked",
          "audio_offset": 0
        }
      }
    }
  },
  "assets": {
    "8b234d1f-32dd-40fb-b2fa-b743ced54a3d": {
      "label": "cfr-bframes.mp4",
      "content_hash": "blake3:16614ec12d06396d3c0f0e7b91cc902c6dc30ad89c28d74b805cf64dc60d8aa1",
      "video": {
        "start": {
          "ticks": 0,
          "time_base": {
            "numerator": 1,
            "denominator": 30000
          }
        },
        "end": {
          "ticks": 120120,
          "time_base": {
            "numerator": 1,
            "denominator": 30000
          }
        }
      },
      "audio": {
        "start": {
          "ticks": 0,
          "time_base": {
            "numerator": 1,
            "denominator": 48000
          }
        },
        "end": {
          "ticks": 192192,
          "time_base": {
            "numerator": 1,
            "denominator": 48000
          }
        }
      },
      "still_image": false,
      "frame_count": 120,
      "source_qualification": "c6bc3e81ab69906267164469d11739cf1363eea546436761ddd219069ed496b6"
    }
  },
  "marks": {},
  "overrides": {}
}
');
INSERT INTO "revisions" VALUES('ae8bcc83-8832-4efa-95ec-7d5f3683fd01','d6643e11-0c07-4bc4-8885-c779aacdb3e5','edit','{
  "schema_version": 43,
  "project_id": "2dbbdca8-d451-4639-8322-38047d33d7ff",
  "revision_id": "ae8bcc83-8832-4efa-95ec-7d5f3683fd01",
  "presentation_basis": {
    "width": 320,
    "height": 180,
    "frame_rate": {
      "numerator": 30000,
      "denominator": 1001
    },
    "color_policy": "sdr_rec709"
  },
  "basis_state": {
    "rate_origin": "primary_source",
    "geometry_origin": "primary_source",
    "primary": {
      "asset": "8b234d1f-32dd-40fb-b2fa-b743ced54a3d",
      "qualification": "c6bc3e81ab69906267164469d11739cf1363eea546436761ddd219069ed496b6"
    }
  },
  "root": "671d71ba-a1f9-4489-933a-9e70b0445f8e",
  "nodes": {
    "42f2bd41-5536-4dd1-aa51-cf9d2d6dc9f4": {
      "label": "Pause",
      "kind": {
        "type": "hold",
        "recipe": {
          "picture_context": {
            "canvases": [
              {
                "width": 320,
                "height": 180,
                "fit": "fit",
                "layers": []
              }
            ]
          },
          "duration": 11,
          "video": {
            "type": "freeze",
            "asset": "8b234d1f-32dd-40fb-b2fa-b743ced54a3d",
            "timestamp": {
              "ticks": 9009,
              "time_base": {
                "numerator": 1,
                "denominator": 30000
              }
            }
          },
          "audio": {
            "type": "silence"
          }
        }
      }
    },
    "59797bd3-4452-416c-9ab2-9c226f00c864": {
      "label": "cfr-bframes.mp4",
      "kind": {
        "type": "source",
        "source": {
          "duration": 120,
          "edit_window": {
            "start": {
              "numerator": "0",
              "denominator": "1"
            },
            "end": {
              "numerator": "120",
              "denominator": "1"
            }
          },
          "video": {
            "type": "stream",
            "asset": "8b234d1f-32dd-40fb-b2fa-b743ced54a3d",
            "span": {
              "start": {
                "ticks": 0,
                "time_base": {
                  "numerator": 1,
                  "denominator": 30000
                }
              },
              "end": {
                "ticks": 120120,
                "time_base": {
                  "numerator": 1,
                  "denominator": 30000
                }
              }
            }
          },
          "video_mapping": {
            "type": "placement",
            "start": {
              "numerator": "0",
              "denominator": "1"
            },
            "frames": {
              "numerator": "120",
              "denominator": "1"
            },
            "endpoints": "hold_adjacent"
          },
          "audio": {
            "asset": "8b234d1f-32dd-40fb-b2fa-b743ced54a3d",
            "span": {
              "start": {
                "ticks": 0,
                "time_base": {
                  "numerator": 1,
                  "denominator": 48000
                }
              },
              "end": {
                "ticks": 192192,
                "time_base": {
                  "numerator": 1,
                  "denominator": 48000
                }
              }
            }
          },
          "audio_mapping": {
            "type": "placement",
            "start": {
              "numerator": "0",
              "denominator": "1"
            },
            "frames": {
              "numerator": "120",
              "denominator": "1"
            }
          },
          "link": "linked",
          "audio_offset": 0
        }
      }
    },
    "671d71ba-a1f9-4489-933a-9e70b0445f8e": {
      "label": "Sequence",
      "kind": {
        "type": "sequence",
        "children": [
          "b4f09a18-ca4a-46f7-8ce5-33844d8704b1",
          "42f2bd41-5536-4dd1-aa51-cf9d2d6dc9f4",
          "f42a5a41-1a92-4361-b3a7-0bc794f7edeb"
        ]
      }
    },
    "a730de52-3bb9-4b2f-9d36-3057a494e00e": {
      "label": "cfr-bframes.mp4",
      "kind": {
        "type": "source",
        "source": {
          "duration": 120,
          "edit_window": {
            "start": {
              "numerator": "0",
              "denominator": "1"
            },
            "end": {
              "numerator": "120",
              "denominator": "1"
            }
          },
          "video": {
            "type": "stream",
            "asset": "8b234d1f-32dd-40fb-b2fa-b743ced54a3d",
            "span": {
              "start": {
                "ticks": 0,
                "time_base": {
                  "numerator": 1,
                  "denominator": 30000
                }
              },
              "end": {
                "ticks": 120120,
                "time_base": {
                  "numerator": 1,
                  "denominator": 30000
                }
              }
            }
          },
          "video_mapping": {
            "type": "placement",
            "start": {
              "numerator": "0",
              "denominator": "1"
            },
            "frames": {
              "numerator": "120",
              "denominator": "1"
            },
            "endpoints": "hold_adjacent"
          },
          "audio": {
            "asset": "8b234d1f-32dd-40fb-b2fa-b743ced54a3d",
            "span": {
              "start": {
                "ticks": 0,
                "time_base": {
                  "numerator": 1,
                  "denominator": 48000
                }
              },
              "end": {
                "ticks": 192192,
                "time_base": {
                  "numerator": 1,
                  "denominator": 48000
                }
              }
            }
          },
          "audio_mapping": {
            "type": "placement",
            "start": {
              "numerator": "0",
              "denominator": "1"
            },
            "frames": {
              "numerator": "120",
              "denominator": "1"
            }
          },
          "link": "linked",
          "audio_offset": 0
        }
      }
    },
    "b4f09a18-ca4a-46f7-8ce5-33844d8704b1": {
      "label": "cfr-bframes.mp4",
      "kind": {
        "type": "retime",
        "child": "a730de52-3bb9-4b2f-9d36-3057a494e00e",
        "duration": 10,
        "mapping": {
          "start": 0,
          "end": 10
        },
        "pitch": "preserve",
        "purpose": "partition"
      }
    },
    "f42a5a41-1a92-4361-b3a7-0bc794f7edeb": {
      "label": "cfr-bframes.mp4",
      "kind": {
        "type": "retime",
        "child": "59797bd3-4452-416c-9ab2-9c226f00c864",
        "duration": 110,
        "mapping": {
          "start": 10,
          "end": 120
        },
        "pitch": "preserve",
        "purpose": "partition"
      }
    }
  },
  "assets": {
    "8b234d1f-32dd-40fb-b2fa-b743ced54a3d": {
      "label": "cfr-bframes.mp4",
      "content_hash": "blake3:16614ec12d06396d3c0f0e7b91cc902c6dc30ad89c28d74b805cf64dc60d8aa1",
      "video": {
        "start": {
          "ticks": 0,
          "time_base": {
            "numerator": 1,
            "denominator": 30000
          }
        },
        "end": {
          "ticks": 120120,
          "time_base": {
            "numerator": 1,
            "denominator": 30000
          }
        }
      },
      "audio": {
        "start": {
          "ticks": 0,
          "time_base": {
            "numerator": 1,
            "denominator": 48000
          }
        },
        "end": {
          "ticks": 192192,
          "time_base": {
            "numerator": 1,
            "denominator": 48000
          }
        }
      },
      "still_image": false,
      "frame_count": 120,
      "source_qualification": "c6bc3e81ab69906267164469d11739cf1363eea546436761ddd219069ed496b6"
    }
  },
  "marks": {},
  "overrides": {},
  "audio_lineage": {
    "59797bd3-4452-416c-9ab2-9c226f00c864": {
      "allocation": "ae8bcc83-8832-4efa-95ec-7d5f3683fd01",
      "origin": "a730de52-3bb9-4b2f-9d36-3057a494e00e"
    },
    "a730de52-3bb9-4b2f-9d36-3057a494e00e": {
      "allocation": "ae8bcc83-8832-4efa-95ec-7d5f3683fd01",
      "origin": "a730de52-3bb9-4b2f-9d36-3057a494e00e"
    }
  },
  "audio_bindings": {
    "timings": [
      {
        "id": {
          "allocation": "ae8bcc83-8832-4efa-95ec-7d5f3683fd01",
          "ordinal": 0
        },
        "layout": {
          "root": "671d71ba-a1f9-4489-933a-9e70b0445f8e",
          "rate": {
            "numerator": 30000,
            "denominator": 1001
          },
          "nodes": {
            "671d71ba-a1f9-4489-933a-9e70b0445f8e": {
              "duration": 120,
              "edges": {
                "node_start": "automatic",
                "node_end": "automatic",
                "source_placement_start": "automatic",
                "source_placement_end": "automatic",
                "repeat_gap_start": "automatic",
                "repeat_gap_end": "automatic"
              },
              "kind": {
                "type": "sequence",
                "children": [
                  "a730de52-3bb9-4b2f-9d36-3057a494e00e"
                ]
              }
            },
            "a730de52-3bb9-4b2f-9d36-3057a494e00e": {
              "duration": 120,
              "edges": {
                "node_start": "automatic",
                "node_end": "automatic",
                "source_placement_start": "automatic",
                "source_placement_end": "automatic",
                "repeat_gap_start": "automatic",
                "repeat_gap_end": "automatic"
              },
              "kind": {
                "type": "source",
                "placement": {
                  "start": {
                    "numerator": "0",
                    "denominator": "1"
                  },
                  "end": {
                    "numerator": "120",
                    "denominator": "1"
                  }
                }
              }
            }
          },
          "overrides": {}
        }
      }
    ],
    "bindings": {
      "59797bd3-4452-416c-9ab2-9c226f00c864": {
        "lattice": {
          "reference": {
            "timing": {
              "allocation": "ae8bcc83-8832-4efa-95ec-7d5f3683fd01",
              "ordinal": 0
            },
            "root": {
              "type": "project_root_round_even"
            },
            "physical": "a730de52-3bb9-4b2f-9d36-3057a494e00e"
          },
          "arguments": [],
          "births": []
        },
        "resume": {
          "local_boundary": {
            "numerator": "10",
            "denominator": "1"
          },
          "phase": {
            "constant": {
              "numerator": "0",
              "denominator": "1"
            },
            "terms": [
              {
                "placement": {
                  "reference": {
                    "timing": {
                      "allocation": "ae8bcc83-8832-4efa-95ec-7d5f3683fd01",
                      "ordinal": 0
                    },
                    "root": {
                      "type": "project_root_round_even"
                    },
                    "physical": "a730de52-3bb9-4b2f-9d36-3057a494e00e"
                  },
                  "arguments": [],
                  "births": []
                },
                "from_local": {
                  "numerator": "0",
                  "denominator": "1"
                },
                "to_local": {
                  "numerator": "10",
                  "denominator": "1"
                }
              }
            ]
          }
        }
      },
      "a730de52-3bb9-4b2f-9d36-3057a494e00e": {
        "lattice": {
          "reference": {
            "timing": {
              "allocation": "ae8bcc83-8832-4efa-95ec-7d5f3683fd01",
              "ordinal": 0
            },
            "root": {
              "type": "project_root_round_even"
            },
            "physical": "a730de52-3bb9-4b2f-9d36-3057a494e00e"
          },
          "arguments": [],
          "births": []
        },
        "resume": null
      }
    }
  }
}
');
INSERT INTO "revisions" VALUES('c11c8516-05f9-4939-bcb6-4b5176302fe7','ae8bcc83-8832-4efa-95ec-7d5f3683fd01','undo','{
  "schema_version": 43,
  "project_id": "2dbbdca8-d451-4639-8322-38047d33d7ff",
  "revision_id": "c11c8516-05f9-4939-bcb6-4b5176302fe7",
  "presentation_basis": {
    "width": 320,
    "height": 180,
    "frame_rate": {
      "numerator": 30000,
      "denominator": 1001
    },
    "color_policy": "sdr_rec709"
  },
  "basis_state": {
    "rate_origin": "primary_source",
    "geometry_origin": "primary_source",
    "primary": {
      "asset": "8b234d1f-32dd-40fb-b2fa-b743ced54a3d",
      "qualification": "c6bc3e81ab69906267164469d11739cf1363eea546436761ddd219069ed496b6"
    }
  },
  "root": "671d71ba-a1f9-4489-933a-9e70b0445f8e",
  "nodes": {
    "671d71ba-a1f9-4489-933a-9e70b0445f8e": {
      "label": "Sequence",
      "kind": {
        "type": "sequence",
        "children": [
          "a730de52-3bb9-4b2f-9d36-3057a494e00e"
        ]
      }
    },
    "a730de52-3bb9-4b2f-9d36-3057a494e00e": {
      "label": "cfr-bframes.mp4",
      "kind": {
        "type": "source",
        "source": {
          "duration": 120,
          "edit_window": {
            "start": {
              "numerator": "0",
              "denominator": "1"
            },
            "end": {
              "numerator": "120",
              "denominator": "1"
            }
          },
          "video": {
            "type": "stream",
            "asset": "8b234d1f-32dd-40fb-b2fa-b743ced54a3d",
            "span": {
              "start": {
                "ticks": 0,
                "time_base": {
                  "numerator": 1,
                  "denominator": 30000
                }
              },
              "end": {
                "ticks": 120120,
                "time_base": {
                  "numerator": 1,
                  "denominator": 30000
                }
              }
            }
          },
          "video_mapping": {
            "type": "placement",
            "start": {
              "numerator": "0",
              "denominator": "1"
            },
            "frames": {
              "numerator": "120",
              "denominator": "1"
            },
            "endpoints": "hold_adjacent"
          },
          "audio": {
            "asset": "8b234d1f-32dd-40fb-b2fa-b743ced54a3d",
            "span": {
              "start": {
                "ticks": 0,
                "time_base": {
                  "numerator": 1,
                  "denominator": 48000
                }
              },
              "end": {
                "ticks": 192192,
                "time_base": {
                  "numerator": 1,
                  "denominator": 48000
                }
              }
            }
          },
          "audio_mapping": {
            "type": "placement",
            "start": {
              "numerator": "0",
              "denominator": "1"
            },
            "frames": {
              "numerator": "120",
              "denominator": "1"
            }
          },
          "link": "linked",
          "audio_offset": 0
        }
      }
    }
  },
  "assets": {
    "8b234d1f-32dd-40fb-b2fa-b743ced54a3d": {
      "label": "cfr-bframes.mp4",
      "content_hash": "blake3:16614ec12d06396d3c0f0e7b91cc902c6dc30ad89c28d74b805cf64dc60d8aa1",
      "video": {
        "start": {
          "ticks": 0,
          "time_base": {
            "numerator": 1,
            "denominator": 30000
          }
        },
        "end": {
          "ticks": 120120,
          "time_base": {
            "numerator": 1,
            "denominator": 30000
          }
        }
      },
      "audio": {
        "start": {
          "ticks": 0,
          "time_base": {
            "numerator": 1,
            "denominator": 48000
          }
        },
        "end": {
          "ticks": 192192,
          "time_base": {
            "numerator": 1,
            "denominator": 48000
          }
        }
      },
      "still_image": false,
      "frame_count": 120,
      "source_qualification": "c6bc3e81ab69906267164469d11739cf1363eea546436761ddd219069ed496b6"
    }
  },
  "marks": {},
  "overrides": {}
}
');
INSERT INTO "revisions" VALUES('1d7d0bb3-78c2-4e92-a752-e1e29ca42b49','c11c8516-05f9-4939-bcb6-4b5176302fe7','edit','{
  "schema_version": 43,
  "project_id": "2dbbdca8-d451-4639-8322-38047d33d7ff",
  "revision_id": "1d7d0bb3-78c2-4e92-a752-e1e29ca42b49",
  "presentation_basis": {
    "width": 320,
    "height": 180,
    "frame_rate": {
      "numerator": 30000,
      "denominator": 1001
    },
    "color_policy": "sdr_rec709"
  },
  "basis_state": {
    "rate_origin": "primary_source",
    "geometry_origin": "primary_source",
    "primary": {
      "asset": "8b234d1f-32dd-40fb-b2fa-b743ced54a3d",
      "qualification": "c6bc3e81ab69906267164469d11739cf1363eea546436761ddd219069ed496b6"
    }
  },
  "root": "671d71ba-a1f9-4489-933a-9e70b0445f8e",
  "nodes": {
    "143232fc-8c80-42ab-8d6c-d8b631b53703": {
      "label": "Copied interval",
      "kind": {
        "type": "retime",
        "child": "3366c225-e0d9-4476-a8f9-188025c42f44",
        "duration": 4,
        "mapping": {
          "start": 0,
          "end": 4
        },
        "pitch": "preserve",
        "purpose": "partition"
      }
    },
    "3366c225-e0d9-4476-a8f9-188025c42f44": {
      "label": "cfr-bframes.mp4",
      "kind": {
        "type": "retime",
        "child": "90912186-ec77-417f-82f7-d7a7bc6aa8cd",
        "duration": 110,
        "mapping": {
          "start": 10,
          "end": 120
        },
        "pitch": "preserve",
        "purpose": "partition"
      }
    },
    "3a8a5062-5955-4e3b-b7a3-4344ab82a360": {
      "label": "Copied interval",
      "kind": {
        "type": "retime",
        "child": "4d69bc95-afd1-410f-bebd-1e2a3c8d2671",
        "duration": 2,
        "mapping": {
          "start": 8,
          "end": 10
        },
        "pitch": "preserve",
        "purpose": "partition"
      }
    },
    "4d69bc95-afd1-410f-bebd-1e2a3c8d2671": {
      "label": "cfr-bframes.mp4",
      "kind": {
        "type": "retime",
        "child": "eda064d7-e231-4c02-bd84-bae991441eef",
        "duration": 10,
        "mapping": {
          "start": 0,
          "end": 10
        },
        "pitch": "preserve",
        "purpose": "partition"
      }
    },
    "671d71ba-a1f9-4489-933a-9e70b0445f8e": {
      "label": "Sequence",
      "kind": {
        "type": "sequence",
        "children": [
          "a730de52-3bb9-4b2f-9d36-3057a494e00e",
          "e98151b5-18d4-4afe-b022-59f71559e154"
        ]
      }
    },
    "90912186-ec77-417f-82f7-d7a7bc6aa8cd": {
      "label": "cfr-bframes.mp4",
      "kind": {
        "type": "source",
        "source": {
          "duration": 120,
          "edit_window": {
            "start": {
              "numerator": "0",
              "denominator": "1"
            },
            "end": {
              "numerator": "120",
              "denominator": "1"
            }
          },
          "video": {
            "type": "stream",
            "asset": "8b234d1f-32dd-40fb-b2fa-b743ced54a3d",
            "span": {
              "start": {
                "ticks": 0,
                "time_base": {
                  "numerator": 1,
                  "denominator": 30000
                }
              },
              "end": {
                "ticks": 120120,
                "time_base": {
                  "numerator": 1,
                  "denominator": 30000
                }
              }
            }
          },
          "video_mapping": {
            "type": "placement",
            "start": {
              "numerator": "0",
              "denominator": "1"
            },
            "frames": {
              "numerator": "120",
              "denominator": "1"
            },
            "endpoints": "hold_adjacent"
          },
          "audio": {
            "asset": "8b234d1f-32dd-40fb-b2fa-b743ced54a3d",
            "span": {
              "start": {
                "ticks": 0,
                "time_base": {
                  "numerator": 1,
                  "denominator": 48000
                }
              },
              "end": {
                "ticks": 192192,
                "time_base": {
                  "numerator": 1,
                  "denominator": 48000
                }
              }
            }
          },
          "audio_mapping": {
            "type": "placement",
            "start": {
              "numerator": "0",
              "denominator": "1"
            },
            "frames": {
              "numerator": "120",
              "denominator": "1"
            }
          },
          "link": "linked",
          "audio_offset": 0
        }
      }
    },
    "a730de52-3bb9-4b2f-9d36-3057a494e00e": {
      "label": "cfr-bframes.mp4",
      "kind": {
        "type": "source",
        "source": {
          "duration": 120,
          "edit_window": {
            "start": {
              "numerator": "0",
              "denominator": "1"
            },
            "end": {
              "numerator": "120",
              "denominator": "1"
            }
          },
          "video": {
            "type": "stream",
            "asset": "8b234d1f-32dd-40fb-b2fa-b743ced54a3d",
            "span": {
              "start": {
                "ticks": 0,
                "time_base": {
                  "numerator": 1,
                  "denominator": 30000
                }
              },
              "end": {
                "ticks": 120120,
                "time_base": {
                  "numerator": 1,
                  "denominator": 30000
                }
              }
            }
          },
          "video_mapping": {
            "type": "placement",
            "start": {
              "numerator": "0",
              "denominator": "1"
            },
            "frames": {
              "numerator": "120",
              "denominator": "1"
            },
            "endpoints": "hold_adjacent"
          },
          "audio": {
            "asset": "8b234d1f-32dd-40fb-b2fa-b743ced54a3d",
            "span": {
              "start": {
                "ticks": 0,
                "time_base": {
                  "numerator": 1,
                  "denominator": 48000
                }
              },
              "end": {
                "ticks": 192192,
                "time_base": {
                  "numerator": 1,
                  "denominator": 48000
                }
              }
            }
          },
          "audio_mapping": {
            "type": "placement",
            "start": {
              "numerator": "0",
              "denominator": "1"
            },
            "frames": {
              "numerator": "120",
              "denominator": "1"
            }
          },
          "link": "linked",
          "audio_offset": 0
        }
      }
    },
    "c6bcde69-3e1b-49ca-8253-8ca70b9a3d3e": {
      "label": "Pause",
      "kind": {
        "type": "hold",
        "recipe": {
          "picture_context": {
            "canvases": [
              {
                "width": 320,
                "height": 180,
                "fit": "fit",
                "layers": []
              }
            ]
          },
          "duration": 11,
          "video": {
            "type": "freeze",
            "asset": "8b234d1f-32dd-40fb-b2fa-b743ced54a3d",
            "timestamp": {
              "ticks": 9009,
              "time_base": {
                "numerator": 1,
                "denominator": 30000
              }
            }
          },
          "audio": {
            "type": "silence"
          }
        }
      }
    },
    "e98151b5-18d4-4afe-b022-59f71559e154": {
      "label": "Copied contents",
      "kind": {
        "type": "sequence",
        "children": [
          "3a8a5062-5955-4e3b-b7a3-4344ab82a360",
          "c6bcde69-3e1b-49ca-8253-8ca70b9a3d3e",
          "143232fc-8c80-42ab-8d6c-d8b631b53703"
        ]
      }
    },
    "eda064d7-e231-4c02-bd84-bae991441eef": {
      "label": "cfr-bframes.mp4",
      "kind": {
        "type": "source",
        "source": {
          "duration": 120,
          "edit_window": {
            "start": {
              "numerator": "0",
              "denominator": "1"
            },
            "end": {
              "numerator": "120",
              "denominator": "1"
            }
          },
          "video": {
            "type": "stream",
            "asset": "8b234d1f-32dd-40fb-b2fa-b743ced54a3d",
            "span": {
              "start": {
                "ticks": 0,
                "time_base": {
                  "numerator": 1,
                  "denominator": 30000
                }
              },
              "end": {
                "ticks": 120120,
                "time_base": {
                  "numerator": 1,
                  "denominator": 30000
                }
              }
            }
          },
          "video_mapping": {
            "type": "placement",
            "start": {
              "numerator": "0",
              "denominator": "1"
            },
            "frames": {
              "numerator": "120",
              "denominator": "1"
            },
            "endpoints": "hold_adjacent"
          },
          "audio": {
            "asset": "8b234d1f-32dd-40fb-b2fa-b743ced54a3d",
            "span": {
              "start": {
                "ticks": 0,
                "time_base": {
                  "numerator": 1,
                  "denominator": 48000
                }
              },
              "end": {
                "ticks": 192192,
                "time_base": {
                  "numerator": 1,
                  "denominator": 48000
                }
              }
            }
          },
          "audio_mapping": {
            "type": "placement",
            "start": {
              "numerator": "0",
              "denominator": "1"
            },
            "frames": {
              "numerator": "120",
              "denominator": "1"
            }
          },
          "link": "linked",
          "audio_offset": 0
        }
      }
    }
  },
  "assets": {
    "8b234d1f-32dd-40fb-b2fa-b743ced54a3d": {
      "label": "cfr-bframes.mp4",
      "content_hash": "blake3:16614ec12d06396d3c0f0e7b91cc902c6dc30ad89c28d74b805cf64dc60d8aa1",
      "video": {
        "start": {
          "ticks": 0,
          "time_base": {
            "numerator": 1,
            "denominator": 30000
          }
        },
        "end": {
          "ticks": 120120,
          "time_base": {
            "numerator": 1,
            "denominator": 30000
          }
        }
      },
      "audio": {
        "start": {
          "ticks": 0,
          "time_base": {
            "numerator": 1,
            "denominator": 48000
          }
        },
        "end": {
          "ticks": 192192,
          "time_base": {
            "numerator": 1,
            "denominator": 48000
          }
        }
      },
      "still_image": false,
      "frame_count": 120,
      "source_qualification": "c6bc3e81ab69906267164469d11739cf1363eea546436761ddd219069ed496b6"
    }
  },
  "marks": {},
  "overrides": {},
  "audio_lineage": {
    "90912186-ec77-417f-82f7-d7a7bc6aa8cd": {
      "allocation": "1d7d0bb3-78c2-4e92-a752-e1e29ca42b49",
      "origin": "bb81209a-f71f-4df5-806b-fcfa9adf8037"
    },
    "eda064d7-e231-4c02-bd84-bae991441eef": {
      "allocation": "1d7d0bb3-78c2-4e92-a752-e1e29ca42b49",
      "origin": "bb81209a-f71f-4df5-806b-fcfa9adf8037"
    }
  },
  "audio_bindings": {
    "timings": [
      {
        "id": {
          "allocation": "1d7d0bb3-78c2-4e92-a752-e1e29ca42b49",
          "ordinal": 0
        },
        "layout": {
          "root": "671d71ba-a1f9-4489-933a-9e70b0445f8e",
          "rate": {
            "numerator": 30000,
            "denominator": 1001
          },
          "nodes": {
            "671d71ba-a1f9-4489-933a-9e70b0445f8e": {
              "duration": 120,
              "edges": {
                "node_start": "automatic",
                "node_end": "automatic",
                "source_placement_start": "automatic",
                "source_placement_end": "automatic",
                "repeat_gap_start": "automatic",
                "repeat_gap_end": "automatic"
              },
              "kind": {
                "type": "sequence",
                "children": [
                  "a730de52-3bb9-4b2f-9d36-3057a494e00e"
                ]
              }
            },
            "a730de52-3bb9-4b2f-9d36-3057a494e00e": {
              "duration": 120,
              "edges": {
                "node_start": "automatic",
                "node_end": "automatic",
                "source_placement_start": "automatic",
                "source_placement_end": "automatic",
                "repeat_gap_start": "automatic",
                "repeat_gap_end": "automatic"
              },
              "kind": {
                "type": "source",
                "placement": {
                  "start": {
                    "numerator": "0",
                    "denominator": "1"
                  },
                  "end": {
                    "numerator": "120",
                    "denominator": "1"
                  }
                }
              }
            }
          },
          "overrides": {}
        }
      },
      {
        "id": {
          "allocation": "1d7d0bb3-78c2-4e92-a752-e1e29ca42b49",
          "ordinal": 1
        },
        "layout": {
          "root": "4c6a634a-2699-4171-bc31-7033b2febd91",
          "rate": {
            "numerator": 30000,
            "denominator": 1001
          },
          "nodes": {
            "34e7c155-608b-4efb-b82f-00f1d8eeafa6": {
              "duration": 10,
              "edges": {
                "node_start": "automatic",
                "node_end": "automatic",
                "source_placement_start": "automatic",
                "source_placement_end": "automatic",
                "repeat_gap_start": "automatic",
                "repeat_gap_end": "automatic"
              },
              "kind": {
                "type": "retime",
                "child": "d6bdc6a5-47ba-4f99-a294-b00adc17fc3b",
                "mapping": {
                  "start": 0,
                  "end": 10
                },
                "pitch": "preserve",
                "purpose": "partition"
              }
            },
            "4c6a634a-2699-4171-bc31-7033b2febd91": {
              "duration": 131,
              "edges": {
                "node_start": "automatic",
                "node_end": "automatic",
                "source_placement_start": "automatic",
                "source_placement_end": "automatic",
                "repeat_gap_start": "automatic",
                "repeat_gap_end": "automatic"
              },
              "kind": {
                "type": "sequence",
                "children": [
                  "34e7c155-608b-4efb-b82f-00f1d8eeafa6",
                  "5c0b95ab-a4e9-4edc-8a8c-b5bea16287e3",
                  "eec0085d-df5f-4a40-b374-233b6a230ad9"
                ]
              }
            },
            "5c0b95ab-a4e9-4edc-8a8c-b5bea16287e3": {
              "duration": 11,
              "edges": {
                "node_start": "automatic",
                "node_end": "automatic",
                "source_placement_start": "automatic",
                "source_placement_end": "automatic",
                "repeat_gap_start": "automatic",
                "repeat_gap_end": "automatic"
              },
              "kind": {
                "type": "hold",
                "audio": {
                  "type": "silence"
                }
              }
            },
            "7e77efdd-4864-4bf6-913b-8f4b652e5532": {
              "duration": 120,
              "edges": {
                "node_start": "automatic",
                "node_end": "automatic",
                "source_placement_start": "automatic",
                "source_placement_end": "automatic",
                "repeat_gap_start": "automatic",
                "repeat_gap_end": "automatic"
              },
              "kind": {
                "type": "source",
                "placement": {
                  "start": {
                    "numerator": "0",
                    "denominator": "1"
                  },
                  "end": {
                    "numerator": "120",
                    "denominator": "1"
                  }
                }
              }
            },
            "d6bdc6a5-47ba-4f99-a294-b00adc17fc3b": {
              "duration": 120,
              "edges": {
                "node_start": "automatic",
                "node_end": "automatic",
                "source_placement_start": "automatic",
                "source_placement_end": "automatic",
                "repeat_gap_start": "automatic",
                "repeat_gap_end": "automatic"
              },
              "kind": {
                "type": "source",
                "placement": {
                  "start": {
                    "numerator": "0",
                    "denominator": "1"
                  },
                  "end": {
                    "numerator": "120",
                    "denominator": "1"
                  }
                }
              }
            },
            "eec0085d-df5f-4a40-b374-233b6a230ad9": {
              "duration": 110,
              "edges": {
                "node_start": "automatic",
                "node_end": "automatic",
                "source_placement_start": "automatic",
                "source_placement_end": "automatic",
                "repeat_gap_start": "automatic",
                "repeat_gap_end": "automatic"
              },
              "kind": {
                "type": "retime",
                "child": "7e77efdd-4864-4bf6-913b-8f4b652e5532",
                "mapping": {
                  "start": 10,
                  "end": 120
                },
                "pitch": "preserve",
                "purpose": "partition"
              }
            }
          },
          "overrides": {},
          "audio_lineage": {
            "7e77efdd-4864-4bf6-913b-8f4b652e5532": {
              "allocation": "1d7d0bb3-78c2-4e92-a752-e1e29ca42b49",
              "origin": "bb81209a-f71f-4df5-806b-fcfa9adf8037"
            },
            "d6bdc6a5-47ba-4f99-a294-b00adc17fc3b": {
              "allocation": "1d7d0bb3-78c2-4e92-a752-e1e29ca42b49",
              "origin": "bb81209a-f71f-4df5-806b-fcfa9adf8037"
            }
          }
        }
      },
      {
        "id": {
          "allocation": "1d7d0bb3-78c2-4e92-a752-e1e29ca42b49",
          "ordinal": 2
        },
        "layout": {
          "root": "3b2926d2-2c77-4f47-9170-2f9c2f65bf08",
          "rate": {
            "numerator": 30000,
            "denominator": 1001
          },
          "nodes": {
            "3b2926d2-2c77-4f47-9170-2f9c2f65bf08": {
              "duration": 120,
              "edges": {
                "node_start": "automatic",
                "node_end": "automatic",
                "source_placement_start": "automatic",
                "source_placement_end": "automatic",
                "repeat_gap_start": "automatic",
                "repeat_gap_end": "automatic"
              },
              "kind": {
                "type": "sequence",
                "children": [
                  "a53cd4f0-eeb8-480e-b5c4-35a95ff72a82"
                ]
              }
            },
            "a53cd4f0-eeb8-480e-b5c4-35a95ff72a82": {
              "duration": 120,
              "edges": {
                "node_start": "automatic",
                "node_end": "automatic",
                "source_placement_start": "automatic",
                "source_placement_end": "automatic",
                "repeat_gap_start": "automatic",
                "repeat_gap_end": "automatic"
              },
              "kind": {
                "type": "source",
                "placement": {
                  "start": {
                    "numerator": "0",
                    "denominator": "1"
                  },
                  "end": {
                    "numerator": "120",
                    "denominator": "1"
                  }
                }
              }
            }
          },
          "overrides": {}
        }
      }
    ],
    "bindings": {
      "90912186-ec77-417f-82f7-d7a7bc6aa8cd": {
        "lattice": {
          "reference": {
            "timing": {
              "allocation": "1d7d0bb3-78c2-4e92-a752-e1e29ca42b49",
              "ordinal": 2
            },
            "root": {
              "type": "project_root_round_even"
            },
            "physical": "a53cd4f0-eeb8-480e-b5c4-35a95ff72a82"
          },
          "arguments": [],
          "births": []
        },
        "resume": {
          "local_boundary": {
            "numerator": "10",
            "denominator": "1"
          },
          "phase": {
            "constant": {
              "numerator": "0",
              "denominator": "1"
            },
            "terms": [
              {
                "placement": {
                  "reference": {
                    "timing": {
                      "allocation": "1d7d0bb3-78c2-4e92-a752-e1e29ca42b49",
                      "ordinal": 2
                    },
                    "root": {
                      "type": "project_root_round_even"
                    },
                    "physical": "a53cd4f0-eeb8-480e-b5c4-35a95ff72a82"
                  },
                  "arguments": [],
                  "births": []
                },
                "from_local": {
                  "numerator": "0",
                  "denominator": "1"
                },
                "to_local": {
                  "numerator": "10",
                  "denominator": "1"
                }
              }
            ]
          }
        },
        "reanchors": [
          {
            "placement": {
              "reference": {
                "timing": {
                  "allocation": "1d7d0bb3-78c2-4e92-a752-e1e29ca42b49",
                  "ordinal": 1
                },
                "root": {
                  "type": "project_root_round_even"
                },
                "physical": "7e77efdd-4864-4bf6-913b-8f4b652e5532"
              },
              "arguments": [],
              "births": []
            },
            "window": {
              "start": {
                "numerator": "8",
                "denominator": "1"
              },
              "end": {
                "numerator": "25",
                "denominator": "1"
              }
            }
          }
        ]
      },
      "a730de52-3bb9-4b2f-9d36-3057a494e00e": {
        "lattice": {
          "reference": {
            "timing": {
              "allocation": "1d7d0bb3-78c2-4e92-a752-e1e29ca42b49",
              "ordinal": 0
            },
            "root": {
              "type": "project_root_round_even"
            },
            "physical": "a730de52-3bb9-4b2f-9d36-3057a494e00e"
          },
          "arguments": [],
          "births": []
        },
        "resume": null
      },
      "c6bcde69-3e1b-49ca-8253-8ca70b9a3d3e": {
        "lattice": {
          "reference": {
            "timing": {
              "allocation": "1d7d0bb3-78c2-4e92-a752-e1e29ca42b49",
              "ordinal": 1
            },
            "root": {
              "type": "project_root_round_even"
            },
            "physical": "5c0b95ab-a4e9-4edc-8a8c-b5bea16287e3"
          },
          "arguments": [],
          "births": []
        },
        "resume": null,
        "reanchors": [
          {
            "placement": {
              "reference": {
                "timing": {
                  "allocation": "1d7d0bb3-78c2-4e92-a752-e1e29ca42b49",
                  "ordinal": 1
                },
                "root": {
                  "type": "project_root_round_even"
                },
                "physical": "5c0b95ab-a4e9-4edc-8a8c-b5bea16287e3"
              },
              "arguments": [],
              "births": []
            },
            "window": {
              "start": {
                "numerator": "8",
                "denominator": "1"
              },
              "end": {
                "numerator": "25",
                "denominator": "1"
              }
            }
          }
        ]
      },
      "eda064d7-e231-4c02-bd84-bae991441eef": {
        "lattice": {
          "reference": {
            "timing": {
              "allocation": "1d7d0bb3-78c2-4e92-a752-e1e29ca42b49",
              "ordinal": 2
            },
            "root": {
              "type": "project_root_round_even"
            },
            "physical": "a53cd4f0-eeb8-480e-b5c4-35a95ff72a82"
          },
          "arguments": [],
          "births": []
        },
        "resume": null,
        "reanchors": [
          {
            "placement": {
              "reference": {
                "timing": {
                  "allocation": "1d7d0bb3-78c2-4e92-a752-e1e29ca42b49",
                  "ordinal": 1
                },
                "root": {
                  "type": "project_root_round_even"
                },
                "physical": "d6bdc6a5-47ba-4f99-a294-b00adc17fc3b"
              },
              "arguments": [],
              "births": []
            },
            "window": {
              "start": {
                "numerator": "8",
                "denominator": "1"
              },
              "end": {
                "numerator": "25",
                "denominator": "1"
              }
            }
          }
        ]
      }
    }
  }
}
');
INSERT INTO "revisions" VALUES('18b8d6b2-ae92-49c3-8951-86db30e35e6d','1d7d0bb3-78c2-4e92-a752-e1e29ca42b49','undo','{
  "schema_version": 43,
  "project_id": "2dbbdca8-d451-4639-8322-38047d33d7ff",
  "revision_id": "18b8d6b2-ae92-49c3-8951-86db30e35e6d",
  "presentation_basis": {
    "width": 320,
    "height": 180,
    "frame_rate": {
      "numerator": 30000,
      "denominator": 1001
    },
    "color_policy": "sdr_rec709"
  },
  "basis_state": {
    "rate_origin": "primary_source",
    "geometry_origin": "primary_source",
    "primary": {
      "asset": "8b234d1f-32dd-40fb-b2fa-b743ced54a3d",
      "qualification": "c6bc3e81ab69906267164469d11739cf1363eea546436761ddd219069ed496b6"
    }
  },
  "root": "671d71ba-a1f9-4489-933a-9e70b0445f8e",
  "nodes": {
    "671d71ba-a1f9-4489-933a-9e70b0445f8e": {
      "label": "Sequence",
      "kind": {
        "type": "sequence",
        "children": [
          "a730de52-3bb9-4b2f-9d36-3057a494e00e"
        ]
      }
    },
    "a730de52-3bb9-4b2f-9d36-3057a494e00e": {
      "label": "cfr-bframes.mp4",
      "kind": {
        "type": "source",
        "source": {
          "duration": 120,
          "edit_window": {
            "start": {
              "numerator": "0",
              "denominator": "1"
            },
            "end": {
              "numerator": "120",
              "denominator": "1"
            }
          },
          "video": {
            "type": "stream",
            "asset": "8b234d1f-32dd-40fb-b2fa-b743ced54a3d",
            "span": {
              "start": {
                "ticks": 0,
                "time_base": {
                  "numerator": 1,
                  "denominator": 30000
                }
              },
              "end": {
                "ticks": 120120,
                "time_base": {
                  "numerator": 1,
                  "denominator": 30000
                }
              }
            }
          },
          "video_mapping": {
            "type": "placement",
            "start": {
              "numerator": "0",
              "denominator": "1"
            },
            "frames": {
              "numerator": "120",
              "denominator": "1"
            },
            "endpoints": "hold_adjacent"
          },
          "audio": {
            "asset": "8b234d1f-32dd-40fb-b2fa-b743ced54a3d",
            "span": {
              "start": {
                "ticks": 0,
                "time_base": {
                  "numerator": 1,
                  "denominator": 48000
                }
              },
              "end": {
                "ticks": 192192,
                "time_base": {
                  "numerator": 1,
                  "denominator": 48000
                }
              }
            }
          },
          "audio_mapping": {
            "type": "placement",
            "start": {
              "numerator": "0",
              "denominator": "1"
            },
            "frames": {
              "numerator": "120",
              "denominator": "1"
            }
          },
          "link": "linked",
          "audio_offset": 0
        }
      }
    }
  },
  "assets": {
    "8b234d1f-32dd-40fb-b2fa-b743ced54a3d": {
      "label": "cfr-bframes.mp4",
      "content_hash": "blake3:16614ec12d06396d3c0f0e7b91cc902c6dc30ad89c28d74b805cf64dc60d8aa1",
      "video": {
        "start": {
          "ticks": 0,
          "time_base": {
            "numerator": 1,
            "denominator": 30000
          }
        },
        "end": {
          "ticks": 120120,
          "time_base": {
            "numerator": 1,
            "denominator": 30000
          }
        }
      },
      "audio": {
        "start": {
          "ticks": 0,
          "time_base": {
            "numerator": 1,
            "denominator": 48000
          }
        },
        "end": {
          "ticks": 192192,
          "time_base": {
            "numerator": 1,
            "denominator": 48000
          }
        }
      },
      "still_image": false,
      "frame_count": 120,
      "source_qualification": "c6bc3e81ab69906267164469d11739cf1363eea546436761ddd219069ed496b6"
    }
  },
  "marks": {},
  "overrides": {}
}
');
INSERT INTO "revisions" VALUES('f25c247c-d2f8-4e6e-a894-8784e0e5bcdd','18b8d6b2-ae92-49c3-8951-86db30e35e6d','edit','{
  "schema_version": 43,
  "project_id": "2dbbdca8-d451-4639-8322-38047d33d7ff",
  "revision_id": "f25c247c-d2f8-4e6e-a894-8784e0e5bcdd",
  "presentation_basis": {
    "width": 320,
    "height": 180,
    "frame_rate": {
      "numerator": 30000,
      "denominator": 1001
    },
    "color_policy": "sdr_rec709"
  },
  "basis_state": {
    "rate_origin": "primary_source",
    "geometry_origin": "primary_source",
    "primary": {
      "asset": "8b234d1f-32dd-40fb-b2fa-b743ced54a3d",
      "qualification": "c6bc3e81ab69906267164469d11739cf1363eea546436761ddd219069ed496b6"
    }
  },
  "root": "671d71ba-a1f9-4489-933a-9e70b0445f8e",
  "nodes": {
    "671d71ba-a1f9-4489-933a-9e70b0445f8e": {
      "label": "Sequence",
      "kind": {
        "type": "sequence",
        "children": [
          "8258cb00-c1be-4cc3-b9bf-dc99fe08e79c",
          "ff341750-08d6-48de-ac48-9fec739c8d85"
        ]
      }
    },
    "8258cb00-c1be-4cc3-b9bf-dc99fe08e79c": {
      "label": "cfr-bframes.mp4",
      "kind": {
        "type": "retime",
        "child": "a730de52-3bb9-4b2f-9d36-3057a494e00e",
        "duration": 20,
        "mapping": {
          "start": 0,
          "end": 20
        },
        "pitch": "preserve",
        "purpose": "partition"
      }
    },
    "a730de52-3bb9-4b2f-9d36-3057a494e00e": {
      "label": "cfr-bframes.mp4",
      "kind": {
        "type": "source",
        "source": {
          "duration": 120,
          "edit_window": {
            "start": {
              "numerator": "0",
              "denominator": "1"
            },
            "end": {
              "numerator": "120",
              "denominator": "1"
            }
          },
          "video": {
            "type": "stream",
            "asset": "8b234d1f-32dd-40fb-b2fa-b743ced54a3d",
            "span": {
              "start": {
                "ticks": 0,
                "time_base": {
                  "numerator": 1,
                  "denominator": 30000
                }
              },
              "end": {
                "ticks": 120120,
                "time_base": {
                  "numerator": 1,
                  "denominator": 30000
                }
              }
            }
          },
          "video_mapping": {
            "type": "placement",
            "start": {
              "numerator": "0",
              "denominator": "1"
            },
            "frames": {
              "numerator": "120",
              "denominator": "1"
            },
            "endpoints": "hold_adjacent"
          },
          "audio": {
            "asset": "8b234d1f-32dd-40fb-b2fa-b743ced54a3d",
            "span": {
              "start": {
                "ticks": 0,
                "time_base": {
                  "numerator": 1,
                  "denominator": 48000
                }
              },
              "end": {
                "ticks": 192192,
                "time_base": {
                  "numerator": 1,
                  "denominator": 48000
                }
              }
            }
          },
          "audio_mapping": {
            "type": "placement",
            "start": {
              "numerator": "0",
              "denominator": "1"
            },
            "frames": {
              "numerator": "120",
              "denominator": "1"
            }
          },
          "link": "linked",
          "audio_offset": 0
        }
      }
    },
    "cef0f3ad-4409-4184-a4a9-c1869bbbb249": {
      "label": "cfr-bframes.mp4",
      "kind": {
        "type": "source",
        "source": {
          "duration": 120,
          "edit_window": {
            "start": {
              "numerator": "0",
              "denominator": "1"
            },
            "end": {
              "numerator": "120",
              "denominator": "1"
            }
          },
          "video": {
            "type": "stream",
            "asset": "8b234d1f-32dd-40fb-b2fa-b743ced54a3d",
            "span": {
              "start": {
                "ticks": 0,
                "time_base": {
                  "numerator": 1,
                  "denominator": 30000
                }
              },
              "end": {
                "ticks": 120120,
                "time_base": {
                  "numerator": 1,
                  "denominator": 30000
                }
              }
            }
          },
          "video_mapping": {
            "type": "placement",
            "start": {
              "numerator": "0",
              "denominator": "1"
            },
            "frames": {
              "numerator": "120",
              "denominator": "1"
            },
            "endpoints": "hold_adjacent"
          },
          "audio": {
            "asset": "8b234d1f-32dd-40fb-b2fa-b743ced54a3d",
            "span": {
              "start": {
                "ticks": 0,
                "time_base": {
                  "numerator": 1,
                  "denominator": 48000
                }
              },
              "end": {
                "ticks": 192192,
                "time_base": {
                  "numerator": 1,
                  "denominator": 48000
                }
              }
            }
          },
          "audio_mapping": {
            "type": "placement",
            "start": {
              "numerator": "0",
              "denominator": "1"
            },
            "frames": {
              "numerator": "120",
              "denominator": "1"
            }
          },
          "link": "linked",
          "audio_offset": 0
        }
      }
    },
    "ff341750-08d6-48de-ac48-9fec739c8d85": {
      "label": "cfr-bframes.mp4",
      "kind": {
        "type": "retime",
        "child": "cef0f3ad-4409-4184-a4a9-c1869bbbb249",
        "duration": 90,
        "mapping": {
          "start": 30,
          "end": 120
        },
        "pitch": "preserve",
        "purpose": "partition"
      }
    }
  },
  "assets": {
    "8b234d1f-32dd-40fb-b2fa-b743ced54a3d": {
      "label": "cfr-bframes.mp4",
      "content_hash": "blake3:16614ec12d06396d3c0f0e7b91cc902c6dc30ad89c28d74b805cf64dc60d8aa1",
      "video": {
        "start": {
          "ticks": 0,
          "time_base": {
            "numerator": 1,
            "denominator": 30000
          }
        },
        "end": {
          "ticks": 120120,
          "time_base": {
            "numerator": 1,
            "denominator": 30000
          }
        }
      },
      "audio": {
        "start": {
          "ticks": 0,
          "time_base": {
            "numerator": 1,
            "denominator": 48000
          }
        },
        "end": {
          "ticks": 192192,
          "time_base": {
            "numerator": 1,
            "denominator": 48000
          }
        }
      },
      "still_image": false,
      "frame_count": 120,
      "source_qualification": "c6bc3e81ab69906267164469d11739cf1363eea546436761ddd219069ed496b6"
    }
  },
  "marks": {},
  "overrides": {},
  "audio_lineage": {
    "a730de52-3bb9-4b2f-9d36-3057a494e00e": {
      "allocation": "f25c247c-d2f8-4e6e-a894-8784e0e5bcdd",
      "origin": "a730de52-3bb9-4b2f-9d36-3057a494e00e"
    },
    "cef0f3ad-4409-4184-a4a9-c1869bbbb249": {
      "allocation": "f25c247c-d2f8-4e6e-a894-8784e0e5bcdd",
      "origin": "a730de52-3bb9-4b2f-9d36-3057a494e00e"
    }
  },
  "audio_bindings": {
    "timings": [
      {
        "id": {
          "allocation": "f25c247c-d2f8-4e6e-a894-8784e0e5bcdd",
          "ordinal": 0
        },
        "layout": {
          "root": "671d71ba-a1f9-4489-933a-9e70b0445f8e",
          "rate": {
            "numerator": 30000,
            "denominator": 1001
          },
          "nodes": {
            "671d71ba-a1f9-4489-933a-9e70b0445f8e": {
              "duration": 120,
              "edges": {
                "node_start": "automatic",
                "node_end": "automatic",
                "source_placement_start": "automatic",
                "source_placement_end": "automatic",
                "repeat_gap_start": "automatic",
                "repeat_gap_end": "automatic"
              },
              "kind": {
                "type": "sequence",
                "children": [
                  "a730de52-3bb9-4b2f-9d36-3057a494e00e"
                ]
              }
            },
            "a730de52-3bb9-4b2f-9d36-3057a494e00e": {
              "duration": 120,
              "edges": {
                "node_start": "automatic",
                "node_end": "automatic",
                "source_placement_start": "automatic",
                "source_placement_end": "automatic",
                "repeat_gap_start": "automatic",
                "repeat_gap_end": "automatic"
              },
              "kind": {
                "type": "source",
                "placement": {
                  "start": {
                    "numerator": "0",
                    "denominator": "1"
                  },
                  "end": {
                    "numerator": "120",
                    "denominator": "1"
                  }
                }
              }
            }
          },
          "overrides": {}
        }
      },
      {
        "id": {
          "allocation": "f25c247c-d2f8-4e6e-a894-8784e0e5bcdd",
          "ordinal": 1
        },
        "layout": {
          "root": "671d71ba-a1f9-4489-933a-9e70b0445f8e",
          "rate": {
            "numerator": 30000,
            "denominator": 1001
          },
          "nodes": {
            "1ebf8220-16a1-4a22-af81-d307f05ac001": {
              "duration": 10,
              "edges": {
                "node_start": "automatic",
                "node_end": "automatic",
                "source_placement_start": "automatic",
                "source_placement_end": "automatic",
                "repeat_gap_start": "automatic",
                "repeat_gap_end": "automatic"
              },
              "kind": {
                "type": "retime",
                "child": "91fa6571-140c-426f-8132-1b43f1e11e4b",
                "mapping": {
                  "start": 20,
                  "end": 30
                },
                "pitch": "preserve",
                "purpose": "partition"
              }
            },
            "671d71ba-a1f9-4489-933a-9e70b0445f8e": {
              "duration": 120,
              "edges": {
                "node_start": "automatic",
                "node_end": "automatic",
                "source_placement_start": "automatic",
                "source_placement_end": "automatic",
                "repeat_gap_start": "automatic",
                "repeat_gap_end": "automatic"
              },
              "kind": {
                "type": "sequence",
                "children": [
                  "8258cb00-c1be-4cc3-b9bf-dc99fe08e79c",
                  "1ebf8220-16a1-4a22-af81-d307f05ac001",
                  "ff341750-08d6-48de-ac48-9fec739c8d85"
                ]
              }
            },
            "8258cb00-c1be-4cc3-b9bf-dc99fe08e79c": {
              "duration": 20,
              "edges": {
                "node_start": "automatic",
                "node_end": "automatic",
                "source_placement_start": "automatic",
                "source_placement_end": "automatic",
                "repeat_gap_start": "automatic",
                "repeat_gap_end": "automatic"
              },
              "kind": {
                "type": "retime",
                "child": "a730de52-3bb9-4b2f-9d36-3057a494e00e",
                "mapping": {
                  "start": 0,
                  "end": 20
                },
                "pitch": "preserve",
                "purpose": "partition"
              }
            },
            "91fa6571-140c-426f-8132-1b43f1e11e4b": {
              "duration": 120,
              "edges": {
                "node_start": "automatic",
                "node_end": "automatic",
                "source_placement_start": "automatic",
                "source_placement_end": "automatic",
                "repeat_gap_start": "automatic",
                "repeat_gap_end": "automatic"
              },
              "kind": {
                "type": "source",
                "placement": {
                  "start": {
                    "numerator": "0",
                    "denominator": "1"
                  },
                  "end": {
                    "numerator": "120",
                    "denominator": "1"
                  }
                }
              }
            },
            "a730de52-3bb9-4b2f-9d36-3057a494e00e": {
              "duration": 120,
              "edges": {
                "node_start": "automatic",
                "node_end": "automatic",
                "source_placement_start": "automatic",
                "source_placement_end": "automatic",
                "repeat_gap_start": "automatic",
                "repeat_gap_end": "automatic"
              },
              "kind": {
                "type": "source",
                "placement": {
                  "start": {
                    "numerator": "0",
                    "denominator": "1"
                  },
                  "end": {
                    "numerator": "120",
                    "denominator": "1"
                  }
                }
              }
            },
            "cef0f3ad-4409-4184-a4a9-c1869bbbb249": {
              "duration": 120,
              "edges": {
                "node_start": "automatic",
                "node_end": "automatic",
                "source_placement_start": "automatic",
                "source_placement_end": "automatic",
                "repeat_gap_start": "automatic",
                "repeat_gap_end": "automatic"
              },
              "kind": {
                "type": "source",
                "placement": {
                  "start": {
                    "numerator": "0",
                    "denominator": "1"
                  },
                  "end": {
                    "numerator": "120",
                    "denominator": "1"
                  }
                }
              }
            },
            "ff341750-08d6-48de-ac48-9fec739c8d85": {
              "duration": 90,
              "edges": {
                "node_start": "automatic",
                "node_end": "automatic",
                "source_placement_start": "automatic",
                "source_placement_end": "automatic",
                "repeat_gap_start": "automatic",
                "repeat_gap_end": "automatic"
              },
              "kind": {
                "type": "retime",
                "child": "cef0f3ad-4409-4184-a4a9-c1869bbbb249",
                "mapping": {
                  "start": 30,
                  "end": 120
                },
                "pitch": "preserve",
                "purpose": "partition"
              }
            }
          },
          "overrides": {},
          "audio_lineage": {
            "91fa6571-140c-426f-8132-1b43f1e11e4b": {
              "allocation": "f25c247c-d2f8-4e6e-a894-8784e0e5bcdd",
              "origin": "a730de52-3bb9-4b2f-9d36-3057a494e00e"
            },
            "a730de52-3bb9-4b2f-9d36-3057a494e00e": {
              "allocation": "f25c247c-d2f8-4e6e-a894-8784e0e5bcdd",
              "origin": "a730de52-3bb9-4b2f-9d36-3057a494e00e"
            },
            "cef0f3ad-4409-4184-a4a9-c1869bbbb249": {
              "allocation": "f25c247c-d2f8-4e6e-a894-8784e0e5bcdd",
              "origin": "a730de52-3bb9-4b2f-9d36-3057a494e00e"
            }
          }
        }
      }
    ],
    "bindings": {
      "a730de52-3bb9-4b2f-9d36-3057a494e00e": {
        "lattice": {
          "reference": {
            "timing": {
              "allocation": "f25c247c-d2f8-4e6e-a894-8784e0e5bcdd",
              "ordinal": 0
            },
            "root": {
              "type": "project_root_round_even"
            },
            "physical": "a730de52-3bb9-4b2f-9d36-3057a494e00e"
          },
          "arguments": [],
          "births": []
        },
        "resume": null
      },
      "cef0f3ad-4409-4184-a4a9-c1869bbbb249": {
        "lattice": {
          "reference": {
            "timing": {
              "allocation": "f25c247c-d2f8-4e6e-a894-8784e0e5bcdd",
              "ordinal": 0
            },
            "root": {
              "type": "project_root_round_even"
            },
            "physical": "a730de52-3bb9-4b2f-9d36-3057a494e00e"
          },
          "arguments": [],
          "births": []
        },
        "resume": null,
        "reanchors": [
          {
            "placement": {
              "reference": {
                "timing": {
                  "allocation": "f25c247c-d2f8-4e6e-a894-8784e0e5bcdd",
                  "ordinal": 1
                },
                "root": {
                  "type": "project_root_round_even"
                },
                "physical": "cef0f3ad-4409-4184-a4a9-c1869bbbb249"
              },
              "arguments": [],
              "births": []
            },
            "window": {
              "start": {
                "numerator": "30",
                "denominator": "1"
              },
              "end": {
                "numerator": "120",
                "denominator": "1"
              }
            }
          }
        ]
      }
    }
  }
}
');
INSERT INTO "revisions" VALUES('a7175f10-f9d2-4dd1-add9-a1304f4b829d','f25c247c-d2f8-4e6e-a894-8784e0e5bcdd','undo','{
  "schema_version": 43,
  "project_id": "2dbbdca8-d451-4639-8322-38047d33d7ff",
  "revision_id": "a7175f10-f9d2-4dd1-add9-a1304f4b829d",
  "presentation_basis": {
    "width": 320,
    "height": 180,
    "frame_rate": {
      "numerator": 30000,
      "denominator": 1001
    },
    "color_policy": "sdr_rec709"
  },
  "basis_state": {
    "rate_origin": "primary_source",
    "geometry_origin": "primary_source",
    "primary": {
      "asset": "8b234d1f-32dd-40fb-b2fa-b743ced54a3d",
      "qualification": "c6bc3e81ab69906267164469d11739cf1363eea546436761ddd219069ed496b6"
    }
  },
  "root": "671d71ba-a1f9-4489-933a-9e70b0445f8e",
  "nodes": {
    "671d71ba-a1f9-4489-933a-9e70b0445f8e": {
      "label": "Sequence",
      "kind": {
        "type": "sequence",
        "children": [
          "a730de52-3bb9-4b2f-9d36-3057a494e00e"
        ]
      }
    },
    "a730de52-3bb9-4b2f-9d36-3057a494e00e": {
      "label": "cfr-bframes.mp4",
      "kind": {
        "type": "source",
        "source": {
          "duration": 120,
          "edit_window": {
            "start": {
              "numerator": "0",
              "denominator": "1"
            },
            "end": {
              "numerator": "120",
              "denominator": "1"
            }
          },
          "video": {
            "type": "stream",
            "asset": "8b234d1f-32dd-40fb-b2fa-b743ced54a3d",
            "span": {
              "start": {
                "ticks": 0,
                "time_base": {
                  "numerator": 1,
                  "denominator": 30000
                }
              },
              "end": {
                "ticks": 120120,
                "time_base": {
                  "numerator": 1,
                  "denominator": 30000
                }
              }
            }
          },
          "video_mapping": {
            "type": "placement",
            "start": {
              "numerator": "0",
              "denominator": "1"
            },
            "frames": {
              "numerator": "120",
              "denominator": "1"
            },
            "endpoints": "hold_adjacent"
          },
          "audio": {
            "asset": "8b234d1f-32dd-40fb-b2fa-b743ced54a3d",
            "span": {
              "start": {
                "ticks": 0,
                "time_base": {
                  "numerator": 1,
                  "denominator": 48000
                }
              },
              "end": {
                "ticks": 192192,
                "time_base": {
                  "numerator": 1,
                  "denominator": 48000
                }
              }
            }
          },
          "audio_mapping": {
            "type": "placement",
            "start": {
              "numerator": "0",
              "denominator": "1"
            },
            "frames": {
              "numerator": "120",
              "denominator": "1"
            }
          },
          "link": "linked",
          "audio_offset": 0
        }
      }
    }
  },
  "assets": {
    "8b234d1f-32dd-40fb-b2fa-b743ced54a3d": {
      "label": "cfr-bframes.mp4",
      "content_hash": "blake3:16614ec12d06396d3c0f0e7b91cc902c6dc30ad89c28d74b805cf64dc60d8aa1",
      "video": {
        "start": {
          "ticks": 0,
          "time_base": {
            "numerator": 1,
            "denominator": 30000
          }
        },
        "end": {
          "ticks": 120120,
          "time_base": {
            "numerator": 1,
            "denominator": 30000
          }
        }
      },
      "audio": {
        "start": {
          "ticks": 0,
          "time_base": {
            "numerator": 1,
            "denominator": 48000
          }
        },
        "end": {
          "ticks": 192192,
          "time_base": {
            "numerator": 1,
            "denominator": 48000
          }
        }
      },
      "still_image": false,
      "frame_count": 120,
      "source_qualification": "c6bc3e81ab69906267164469d11739cf1363eea546436761ddd219069ed496b6"
    }
  },
  "marks": {},
  "overrides": {}
}
');
INSERT INTO "revisions" VALUES('c34f9d51-c8f4-4f49-8fc1-4c96fc74f2c2','a7175f10-f9d2-4dd1-add9-a1304f4b829d','edit','{
  "schema_version": 43,
  "project_id": "2dbbdca8-d451-4639-8322-38047d33d7ff",
  "revision_id": "c34f9d51-c8f4-4f49-8fc1-4c96fc74f2c2",
  "presentation_basis": {
    "width": 320,
    "height": 180,
    "frame_rate": {
      "numerator": 30000,
      "denominator": 1001
    },
    "color_policy": "sdr_rec709"
  },
  "basis_state": {
    "rate_origin": "primary_source",
    "geometry_origin": "primary_source",
    "primary": {
      "asset": "8b234d1f-32dd-40fb-b2fa-b743ced54a3d",
      "qualification": "c6bc3e81ab69906267164469d11739cf1363eea546436761ddd219069ed496b6"
    }
  },
  "root": "671d71ba-a1f9-4489-933a-9e70b0445f8e",
  "nodes": {
    "3016df70-a4a7-43f0-9cac-91e0cea6d5b6": {
      "label": "cfr-bframes.mp4",
      "kind": {
        "type": "source",
        "source": {
          "duration": 120,
          "edit_window": {
            "start": {
              "numerator": "0",
              "denominator": "1"
            },
            "end": {
              "numerator": "120",
              "denominator": "1"
            }
          },
          "video": {
            "type": "stream",
            "asset": "8b234d1f-32dd-40fb-b2fa-b743ced54a3d",
            "span": {
              "start": {
                "ticks": 0,
                "time_base": {
                  "numerator": 1,
                  "denominator": 30000
                }
              },
              "end": {
                "ticks": 120120,
                "time_base": {
                  "numerator": 1,
                  "denominator": 30000
                }
              }
            }
          },
          "video_mapping": {
            "type": "placement",
            "start": {
              "numerator": "0",
              "denominator": "1"
            },
            "frames": {
              "numerator": "120",
              "denominator": "1"
            },
            "endpoints": "hold_adjacent"
          },
          "audio": {
            "asset": "8b234d1f-32dd-40fb-b2fa-b743ced54a3d",
            "span": {
              "start": {
                "ticks": 0,
                "time_base": {
                  "numerator": 1,
                  "denominator": 48000
                }
              },
              "end": {
                "ticks": 192192,
                "time_base": {
                  "numerator": 1,
                  "denominator": 48000
                }
              }
            }
          },
          "audio_mapping": {
            "type": "placement",
            "start": {
              "numerator": "0",
              "denominator": "1"
            },
            "frames": {
              "numerator": "120",
              "denominator": "1"
            }
          },
          "link": "linked",
          "audio_offset": 0
        }
      }
    },
    "3614b26f-5472-482b-9d3f-5d0d1ea975f7": {
      "label": "Copied interval",
      "kind": {
        "type": "retime",
        "child": "3016df70-a4a7-43f0-9cac-91e0cea6d5b6",
        "duration": 10,
        "mapping": {
          "start": 20,
          "end": 30
        },
        "pitch": "preserve",
        "purpose": "partition"
      }
    },
    "671d71ba-a1f9-4489-933a-9e70b0445f8e": {
      "label": "Sequence",
      "kind": {
        "type": "sequence",
        "children": [
          "731ce7a8-ca45-44a3-89fc-605693b2c145",
          "a730de52-3bb9-4b2f-9d36-3057a494e00e"
        ]
      }
    },
    "731ce7a8-ca45-44a3-89fc-605693b2c145": {
      "label": "Copied contents",
      "kind": {
        "type": "sequence",
        "children": [
          "3614b26f-5472-482b-9d3f-5d0d1ea975f7"
        ]
      }
    },
    "a730de52-3bb9-4b2f-9d36-3057a494e00e": {
      "label": "cfr-bframes.mp4",
      "kind": {
        "type": "source",
        "source": {
          "duration": 120,
          "edit_window": {
            "start": {
              "numerator": "0",
              "denominator": "1"
            },
            "end": {
              "numerator": "120",
              "denominator": "1"
            }
          },
          "video": {
            "type": "stream",
            "asset": "8b234d1f-32dd-40fb-b2fa-b743ced54a3d",
            "span": {
              "start": {
                "ticks": 0,
                "time_base": {
                  "numerator": 1,
                  "denominator": 30000
                }
              },
              "end": {
                "ticks": 120120,
                "time_base": {
                  "numerator": 1,
                  "denominator": 30000
                }
              }
            }
          },
          "video_mapping": {
            "type": "placement",
            "start": {
              "numerator": "0",
              "denominator": "1"
            },
            "frames": {
              "numerator": "120",
              "denominator": "1"
            },
            "endpoints": "hold_adjacent"
          },
          "audio": {
            "asset": "8b234d1f-32dd-40fb-b2fa-b743ced54a3d",
            "span": {
              "start": {
                "ticks": 0,
                "time_base": {
                  "numerator": 1,
                  "denominator": 48000
                }
              },
              "end": {
                "ticks": 192192,
                "time_base": {
                  "numerator": 1,
                  "denominator": 48000
                }
              }
            }
          },
          "audio_mapping": {
            "type": "placement",
            "start": {
              "numerator": "0",
              "denominator": "1"
            },
            "frames": {
              "numerator": "120",
              "denominator": "1"
            }
          },
          "link": "linked",
          "audio_offset": 0
        }
      }
    }
  },
  "assets": {
    "8b234d1f-32dd-40fb-b2fa-b743ced54a3d": {
      "label": "cfr-bframes.mp4",
      "content_hash": "blake3:16614ec12d06396d3c0f0e7b91cc902c6dc30ad89c28d74b805cf64dc60d8aa1",
      "video": {
        "start": {
          "ticks": 0,
          "time_base": {
            "numerator": 1,
            "denominator": 30000
          }
        },
        "end": {
          "ticks": 120120,
          "time_base": {
            "numerator": 1,
            "denominator": 30000
          }
        }
      },
      "audio": {
        "start": {
          "ticks": 0,
          "time_base": {
            "numerator": 1,
            "denominator": 48000
          }
        },
        "end": {
          "ticks": 192192,
          "time_base": {
            "numerator": 1,
            "denominator": 48000
          }
        }
      },
      "still_image": false,
      "frame_count": 120,
      "source_qualification": "c6bc3e81ab69906267164469d11739cf1363eea546436761ddd219069ed496b6"
    }
  },
  "marks": {},
  "overrides": {},
  "audio_bindings": {
    "timings": [
      {
        "id": {
          "allocation": "c34f9d51-c8f4-4f49-8fc1-4c96fc74f2c2",
          "ordinal": 0
        },
        "layout": {
          "root": "671d71ba-a1f9-4489-933a-9e70b0445f8e",
          "rate": {
            "numerator": 30000,
            "denominator": 1001
          },
          "nodes": {
            "671d71ba-a1f9-4489-933a-9e70b0445f8e": {
              "duration": 120,
              "edges": {
                "node_start": "automatic",
                "node_end": "automatic",
                "source_placement_start": "automatic",
                "source_placement_end": "automatic",
                "repeat_gap_start": "automatic",
                "repeat_gap_end": "automatic"
              },
              "kind": {
                "type": "sequence",
                "children": [
                  "a730de52-3bb9-4b2f-9d36-3057a494e00e"
                ]
              }
            },
            "a730de52-3bb9-4b2f-9d36-3057a494e00e": {
              "duration": 120,
              "edges": {
                "node_start": "automatic",
                "node_end": "automatic",
                "source_placement_start": "automatic",
                "source_placement_end": "automatic",
                "repeat_gap_start": "automatic",
                "repeat_gap_end": "automatic"
              },
              "kind": {
                "type": "source",
                "placement": {
                  "start": {
                    "numerator": "0",
                    "denominator": "1"
                  },
                  "end": {
                    "numerator": "120",
                    "denominator": "1"
                  }
                }
              }
            }
          },
          "overrides": {}
        }
      },
      {
        "id": {
          "allocation": "c34f9d51-c8f4-4f49-8fc1-4c96fc74f2c2",
          "ordinal": 1
        },
        "layout": {
          "root": "e534e093-1e07-4894-ba04-274b9e99c331",
          "rate": {
            "numerator": 30000,
            "denominator": 1001
          },
          "nodes": {
            "b50e2535-b968-49fc-8f5e-f7dbfd3de789": {
              "duration": 120,
              "edges": {
                "node_start": "automatic",
                "node_end": "automatic",
                "source_placement_start": "automatic",
                "source_placement_end": "automatic",
                "repeat_gap_start": "automatic",
                "repeat_gap_end": "automatic"
              },
              "kind": {
                "type": "source",
                "placement": {
                  "start": {
                    "numerator": "0",
                    "denominator": "1"
                  },
                  "end": {
                    "numerator": "120",
                    "denominator": "1"
                  }
                }
              }
            },
            "e534e093-1e07-4894-ba04-274b9e99c331": {
              "duration": 120,
              "edges": {
                "node_start": "automatic",
                "node_end": "automatic",
                "source_placement_start": "automatic",
                "source_placement_end": "automatic",
                "repeat_gap_start": "automatic",
                "repeat_gap_end": "automatic"
              },
              "kind": {
                "type": "sequence",
                "children": [
                  "b50e2535-b968-49fc-8f5e-f7dbfd3de789"
                ]
              }
            }
          },
          "overrides": {}
        }
      }
    ],
    "bindings": {
      "3016df70-a4a7-43f0-9cac-91e0cea6d5b6": {
        "lattice": {
          "reference": {
            "timing": {
              "allocation": "c34f9d51-c8f4-4f49-8fc1-4c96fc74f2c2",
              "ordinal": 1
            },
            "root": {
              "type": "project_root_round_even"
            },
            "physical": "b50e2535-b968-49fc-8f5e-f7dbfd3de789"
          },
          "arguments": [],
          "births": []
        },
        "resume": null,
        "reanchors": [
          {
            "placement": {
              "reference": {
                "timing": {
                  "allocation": "c34f9d51-c8f4-4f49-8fc1-4c96fc74f2c2",
                  "ordinal": 1
                },
                "root": {
                  "type": "project_root_round_even"
                },
                "physical": "b50e2535-b968-49fc-8f5e-f7dbfd3de789"
              },
              "arguments": [],
              "births": []
            },
            "window": {
              "start": {
                "numerator": "20",
                "denominator": "1"
              },
              "end": {
                "numerator": "30",
                "denominator": "1"
              }
            }
          }
        ]
      },
      "a730de52-3bb9-4b2f-9d36-3057a494e00e": {
        "lattice": {
          "reference": {
            "timing": {
              "allocation": "c34f9d51-c8f4-4f49-8fc1-4c96fc74f2c2",
              "ordinal": 0
            },
            "root": {
              "type": "project_root_round_even"
            },
            "physical": "a730de52-3bb9-4b2f-9d36-3057a494e00e"
          },
          "arguments": [],
          "births": []
        },
        "resume": null,
        "reanchors": [
          {
            "placement": {
              "reference": {
                "timing": {
                  "allocation": "c34f9d51-c8f4-4f49-8fc1-4c96fc74f2c2",
                  "ordinal": 0
                },
                "root": {
                  "type": "project_root_round_even"
                },
                "physical": "a730de52-3bb9-4b2f-9d36-3057a494e00e"
              },
              "arguments": [],
              "births": []
            },
            "window": {
              "start": {
                "numerator": "0",
                "denominator": "1"
              },
              "end": {
                "numerator": "120",
                "denominator": "1"
              }
            }
          }
        ]
      }
    }
  }
}
');
INSERT INTO "revisions" VALUES('515c85fc-0dff-45b2-b6b8-4dab503fc10a','c34f9d51-c8f4-4f49-8fc1-4c96fc74f2c2','undo','{
  "schema_version": 43,
  "project_id": "2dbbdca8-d451-4639-8322-38047d33d7ff",
  "revision_id": "515c85fc-0dff-45b2-b6b8-4dab503fc10a",
  "presentation_basis": {
    "width": 320,
    "height": 180,
    "frame_rate": {
      "numerator": 30000,
      "denominator": 1001
    },
    "color_policy": "sdr_rec709"
  },
  "basis_state": {
    "rate_origin": "primary_source",
    "geometry_origin": "primary_source",
    "primary": {
      "asset": "8b234d1f-32dd-40fb-b2fa-b743ced54a3d",
      "qualification": "c6bc3e81ab69906267164469d11739cf1363eea546436761ddd219069ed496b6"
    }
  },
  "root": "671d71ba-a1f9-4489-933a-9e70b0445f8e",
  "nodes": {
    "671d71ba-a1f9-4489-933a-9e70b0445f8e": {
      "label": "Sequence",
      "kind": {
        "type": "sequence",
        "children": [
          "a730de52-3bb9-4b2f-9d36-3057a494e00e"
        ]
      }
    },
    "a730de52-3bb9-4b2f-9d36-3057a494e00e": {
      "label": "cfr-bframes.mp4",
      "kind": {
        "type": "source",
        "source": {
          "duration": 120,
          "edit_window": {
            "start": {
              "numerator": "0",
              "denominator": "1"
            },
            "end": {
              "numerator": "120",
              "denominator": "1"
            }
          },
          "video": {
            "type": "stream",
            "asset": "8b234d1f-32dd-40fb-b2fa-b743ced54a3d",
            "span": {
              "start": {
                "ticks": 0,
                "time_base": {
                  "numerator": 1,
                  "denominator": 30000
                }
              },
              "end": {
                "ticks": 120120,
                "time_base": {
                  "numerator": 1,
                  "denominator": 30000
                }
              }
            }
          },
          "video_mapping": {
            "type": "placement",
            "start": {
              "numerator": "0",
              "denominator": "1"
            },
            "frames": {
              "numerator": "120",
              "denominator": "1"
            },
            "endpoints": "hold_adjacent"
          },
          "audio": {
            "asset": "8b234d1f-32dd-40fb-b2fa-b743ced54a3d",
            "span": {
              "start": {
                "ticks": 0,
                "time_base": {
                  "numerator": 1,
                  "denominator": 48000
                }
              },
              "end": {
                "ticks": 192192,
                "time_base": {
                  "numerator": 1,
                  "denominator": 48000
                }
              }
            }
          },
          "audio_mapping": {
            "type": "placement",
            "start": {
              "numerator": "0",
              "denominator": "1"
            },
            "frames": {
              "numerator": "120",
              "denominator": "1"
            }
          },
          "link": "linked",
          "audio_offset": 0
        }
      }
    }
  },
  "assets": {
    "8b234d1f-32dd-40fb-b2fa-b743ced54a3d": {
      "label": "cfr-bframes.mp4",
      "content_hash": "blake3:16614ec12d06396d3c0f0e7b91cc902c6dc30ad89c28d74b805cf64dc60d8aa1",
      "video": {
        "start": {
          "ticks": 0,
          "time_base": {
            "numerator": 1,
            "denominator": 30000
          }
        },
        "end": {
          "ticks": 120120,
          "time_base": {
            "numerator": 1,
            "denominator": 30000
          }
        }
      },
      "audio": {
        "start": {
          "ticks": 0,
          "time_base": {
            "numerator": 1,
            "denominator": 48000
          }
        },
        "end": {
          "ticks": 192192,
          "time_base": {
            "numerator": 1,
            "denominator": 48000
          }
        }
      },
      "still_image": false,
      "frame_count": 120,
      "source_qualification": "c6bc3e81ab69906267164469d11739cf1363eea546436761ddd219069ed496b6"
    }
  },
  "marks": {},
  "overrides": {}
}
');
CREATE TABLE single_source (
            singleton INTEGER PRIMARY KEY CHECK(singleton=1),
            profile TEXT NOT NULL CHECK(json_valid(profile)),
            baseline_history INTEGER REFERENCES history(id)
        ) STRICT;
INSERT INTO "single_source" VALUES(1,'{"state":"ready","initial_revision":"94af3121-2605-4161-9413-5c27a97c5287","asset":"8b234d1f-32dd-40fb-b2fa-b743ced54a3d","qualification":"c6bc3e81ab69906267164469d11739cf1363eea546436761ddd219069ed496b6","node":"a730de52-3bb9-4b2f-9d36-3057a494e00e","baseline_revision":"18e36cb1-afc9-407d-b7ab-d9df09d17634"}',1);
CREATE TABLE source_qualifications (
            id TEXT PRIMARY KEY,
            original_content_id TEXT NOT NULL REFERENCES original_media(content_id),
            original_ref TEXT NOT NULL CHECK(json_valid(original_ref)),
            snapshot BLOB NOT NULL
        ) STRICT;
INSERT INTO "source_qualifications" VALUES('c6bc3e81ab69906267164469d11739cf1363eea546436761ddd219069ed496b6','blake3:16614ec12d06396d3c0f0e7b91cc902c6dc30ad89c28d74b805cf64dc60d8aa1','{"content":{"algorithm":"blake3","digest":"16614ec12d06396d3c0f0e7b91cc902c6dc30ad89c28d74b805cf64dc60d8aa1"},"byte_length":39157}',X'7B22736368656D615F76657273696F6E223A312C226465636F6465725F636F6E7472616374223A2266666D7065672D382E302E332F736F757263652D6465636F6465642D7631222C2274696D696E675F706F6C6963795F76657273696F6E223A312C22636F6E74656E74223A7B22736861323536223A5B39302C3133302C31302C3132312C3139312C38352C31332C37322C37372C3134322C3230332C35352C3235352C3232312C3230382C37322C3230382C39392C3130332C3134382C3233352C3230362C39332C3138342C36322C37392C39322C3232392C3234352C3233302C37332C32345D2C22627974655F6C656E677468223A33393135377D2C226F726967696E5F7365636F6E6473223A7B226E756D657261746F72223A2230222C2264656E6F6D696E61746F72223A2231227D2C22766964656F223A7B22696E646578223A7B22736368656D615F76657273696F6E223A312C22636F6E74656E74223A7B22736861323536223A5B39302C3133302C31302C3132312C3139312C38352C31332C37322C37372C3134322C3230332C35352C3235352C3232312C3230382C37322C3230382C39392C3130332C3134382C3233352C3230362C39332C3138342C36322C37392C39322C3232392C3234352C3233302C37332C32345D2C22627974655F6C656E677468223A33393135377D2C2273747265616D5F696E646578223A302C22696E646578223A7B226173736574223A227175616C69666965642D736F75726365222C2274696D655F62617365223A7B226E756D657261746F72223A312C2264656E6F6D696E61746F72223A33303030307D2C226672616D6573223A5B7B226964656E74697479223A302C22707473223A302C227265706F727465645F6475726174696F6E223A313030312C226B65796672616D65223A747275652C227365656B5F66726F6D223A302C226465636F64655F74696D657374616D70223A307D2C7B226964656E74697479223A312C22707473223A313030312C227265706F727465645F6475726174696F6E223A313030312C226B65796672616D65223A66616C73652C227365656B5F66726F6D223A302C226465636F64655F74696D657374616D70223A313030317D2C7B226964656E74697479223A322C22707473223A323030322C227265706F727465645F6475726174696F6E223A313030312C226B65796672616D65223A66616C73652C227365656B5F66726F6D223A302C226465636F64655F74696D657374616D70223A323030327D2C7B226964656E74697479223A332C22707473223A333030332C227265706F727465645F6475726174696F6E223A313030312C226B65796672616D65223A66616C73652C227365656B5F66726F6D223A302C226465636F64655F74696D657374616D70223A333030337D2C7B226964656E74697479223A342C22707473223A343030342C227265706F727465645F6475726174696F6E223A313030312C226B65796672616D65223A66616C73652C227365656B5F66726F6D223A302C226465636F64655F74696D657374616D70223A343030347D2C7B226964656E74697479223A352C22707473223A353030352C227265706F727465645F6475726174696F6E223A313030312C226B65796672616D65223A66616C73652C227365656B5F66726F6D223A302C226465636F64655F74696D657374616D70223A353030357D2C7B226964656E74697479223A362C22707473223A363030362C227265706F727465645F6475726174696F6E223A313030312C226B65796672616D65223A66616C73652C227365656B5F66726F6D223A302C226465636F64655F74696D657374616D70223A363030367D2C7B226964656E74697479223A372C22707473223A373030372C227265706F727465645F6475726174696F6E223A313030312C226B65796672616D65223A66616C73652C227365656B5F66726F6D223A302C226465636F64655F74696D657374616D70223A373030377D2C7B226964656E74697479223A382C22707473223A383030382C227265706F727465645F6475726174696F6E223A313030312C226B65796672616D65223A66616C73652C227365656B5F66726F6D223A302C226465636F64655F74696D657374616D70223A383030387D2C7B226964656E74697479223A392C22707473223A393030392C227265706F727465645F6475726174696F6E223A313030312C226B65796672616D65223A66616C73652C227365656B5F66726F6D223A302C226465636F64655F74696D657374616D70223A393030397D2C7B226964656E74697479223A31302C22707473223A31303031302C227265706F727465645F6475726174696F6E223A313030312C226B65796672616D65223A66616C73652C227365656B5F66726F6D223A302C226465636F64655F74696D657374616D70223A31303031307D2C7B226964656E74697479223A31312C22707473223A31313031312C227265706F727465645F6475726174696F6E223A313030312C226B65796672616D65223A66616C73652C227365656B5F66726F6D223A302C226465636F64655F74696D657374616D70223A31313031317D2C7B226964656E74697479223A31322C22707473223A31323031322C227265706F727465645F6475726174696F6E223A313030312C226B65796672616D65223A66616C73652C227365656B5F66726F6D223A302C226465636F64655F74696D657374616D70223A31323031327D2C7B226964656E74697479223A31332C22707473223A31333031332C227265706F727465645F6475726174696F6E223A313030312C226B65796672616D65223A66616C73652C227365656B5F66726F6D223A302C226465636F64655F74696D657374616D70223A31333031337D2C7B226964656E74697479223A31342C22707473223A31343031342C227265706F727465645F6475726174696F6E223A313030312C226B65796672616D65223A66616C73652C227365656B5F66726F6D223A302C226465636F64655F74696D657374616D70223A31343031347D2C7B226964656E74697479223A31352C22707473223A31353031352C227265706F727465645F6475726174696F6E223A313030312C226B65796672616D65223A747275652C227365656B5F66726F6D223A31352C226465636F64655F74696D657374616D70223A31353031357D2C7B226964656E74697479223A31362C22707473223A31363031362C227265706F727465645F6475726174696F6E223A313030312C226B65796672616D65223A66616C73652C227365656B5F66726F6D223A31352C226465636F64655F74696D657374616D70223A31363031367D2C7B226964656E74697479223A31372C22707473223A31373031372C227265706F727465645F6475726174696F6E223A313030312C226B65796672616D65223A66616C73652C227365656B5F66726F6D223A31352C226465636F64655F74696D657374616D70223A31373031377D2C7B226964656E74697479223A31382C22707473223A31383031382C227265706F727465645F6475726174696F6E223A313030312C226B65796672616D65223A66616C73652C227365656B5F66726F6D223A31352C226465636F64655F74696D657374616D70223A31383031387D2C7B226964656E74697479223A31392C22707473223A31393031392C227265706F727465645F6475726174696F6E223A313030312C226B65796672616D65223A66616C73652C227365656B5F66726F6D223A31352C226465636F64655F74696D657374616D70223A31393031397D2C7B226964656E74697479223A32302C22707473223A32303032302C227265706F727465645F6475726174696F6E223A313030312C226B65796672616D65223A66616C73652C227365656B5F66726F6D223A31352C226465636F64655F74696D657374616D70223A32303032307D2C7B226964656E74697479223A32312C22707473223A32313032312C227265706F727465645F6475726174696F6E223A313030312C226B65796672616D65223A66616C73652C227365656B5F66726F6D223A31352C226465636F64655F74696D657374616D70223A32313032317D2C7B226964656E74697479223A32322C22707473223A32323032322C227265706F727465645F6475726174696F6E223A313030312C226B65796672616D65223A66616C73652C227365656B5F66726F6D223A31352C226465636F64655F74696D657374616D70223A32323032327D2C7B226964656E74697479223A32332C22707473223A32333032332C227265706F727465645F6475726174696F6E223A313030312C226B65796672616D65223A66616C73652C227365656B5F66726F6D223A31352C226465636F64655F74696D657374616D70223A32333032337D2C7B226964656E74697479223A32342C22707473223A32343032342C227265706F727465645F6475726174696F6E223A313030312C226B65796672616D65223A66616C73652C227365656B5F66726F6D223A31352C226465636F64655F74696D657374616D70223A32343032347D2C7B226964656E74697479223A32352C22707473223A32353032352C227265706F727465645F6475726174696F6E223A313030312C226B65796672616D65223A66616C73652C227365656B5F66726F6D223A31352C226465636F64655F74696D657374616D70223A32353032357D2C7B226964656E74697479223A32362C22707473223A32363032362C227265706F727465645F6475726174696F6E223A313030312C226B65796672616D65223A66616C73652C227365656B5F66726F6D223A31352C226465636F64655F74696D657374616D70223A32363032367D2C7B226964656E74697479223A32372C22707473223A32373032372C227265706F727465645F6475726174696F6E223A313030312C226B65796672616D65223A66616C73652C227365656B5F66726F6D223A31352C226465636F64655F74696D657374616D70223A32373032377D2C7B226964656E74697479223A32382C22707473223A32383032382C227265706F727465645F6475726174696F6E223A313030312C226B65796672616D65223A66616C73652C227365656B5F66726F6D223A31352C226465636F64655F74696D657374616D70223A32383032387D2C7B226964656E74697479223A32392C22707473223A32393032392C227265706F727465645F6475726174696F6E223A313030312C226B65796672616D65223A66616C73652C227365656B5F66726F6D223A31352C226465636F64655F74696D657374616D70223A32393032397D2C7B226964656E74697479223A33302C22707473223A33303033302C227265706F727465645F6475726174696F6E223A313030312C226B65796672616D65223A747275652C227365656B5F66726F6D223A33302C226465636F64655F74696D657374616D70223A33303033307D2C7B226964656E74697479223A33312C22707473223A33313033312C227265706F727465645F6475726174696F6E223A313030312C226B65796672616D65223A66616C73652C227365656B5F66726F6D223A33302C226465636F64655F74696D657374616D70223A33313033317D2C7B226964656E74697479223A33322C22707473223A33323033322C227265706F727465645F6475726174696F6E223A313030312C226B65796672616D65223A66616C73652C227365656B5F66726F6D223A33302C226465636F64655F74696D657374616D70223A33323033327D2C7B226964656E74697479223A33332C22707473223A33333033332C227265706F727465645F6475726174696F6E223A313030312C226B65796672616D65223A66616C73652C227365656B5F66726F6D223A33302C226465636F64655F74696D657374616D70223A33333033337D2C7B226964656E74697479223A33342C22707473223A33343033342C227265706F727465645F6475726174696F6E223A313030312C226B65796672616D65223A66616C73652C227365656B5F66726F6D223A33302C226465636F64655F74696D657374616D70223A33343033347D2C7B226964656E74697479223A33352C22707473223A33353033352C227265706F727465645F6475726174696F6E223A313030312C226B65796672616D65223A66616C73652C227365656B5F66726F6D223A33302C226465636F64655F74696D657374616D70223A33353033357D2C7B226964656E74697479223A33362C22707473223A33363033362C227265706F727465645F6475726174696F6E223A313030312C226B65796672616D65223A66616C73652C227365656B5F66726F6D223A33302C226465636F64655F74696D657374616D70223A33363033367D2C7B226964656E74697479223A33372C22707473223A33373033372C227265706F727465645F6475726174696F6E223A313030312C226B65796672616D65223A66616C73652C227365656B5F66726F6D223A33302C226465636F64655F74696D657374616D70223A33373033377D2C7B226964656E74697479223A33382C22707473223A33383033382C227265706F727465645F6475726174696F6E223A313030312C226B65796672616D65223A66616C73652C227365656B5F66726F6D223A33302C226465636F64655F74696D657374616D70223A33383033387D2C7B226964656E74697479223A33392C22707473223A33393033392C227265706F727465645F6475726174696F6E223A313030312C226B65796672616D65223A66616C73652C227365656B5F66726F6D223A33302C226465636F64655F74696D657374616D70223A33393033397D2C7B226964656E74697479223A34302C22707473223A34303034302C227265706F727465645F6475726174696F6E223A313030312C226B65796672616D65223A66616C73652C227365656B5F66726F6D223A33302C226465636F64655F74696D657374616D70223A34303034307D2C7B226964656E74697479223A34312C22707473223A34313034312C227265706F727465645F6475726174696F6E223A313030312C226B65796672616D65223A66616C73652C227365656B5F66726F6D223A33302C226465636F64655F74696D657374616D70223A34313034317D2C7B226964656E74697479223A34322C22707473223A34323034322C227265706F727465645F6475726174696F6E223A313030312C226B65796672616D65223A66616C73652C227365656B5F66726F6D223A33302C226465636F64655F74696D657374616D70223A34323034327D2C7B226964656E74697479223A34332C22707473223A34333034332C227265706F727465645F6475726174696F6E223A313030312C226B65796672616D65223A66616C73652C227365656B5F66726F6D223A33302C226465636F64655F74696D657374616D70223A34333034337D2C7B226964656E74697479223A34342C22707473223A34343034342C227265706F727465645F6475726174696F6E223A313030312C226B65796672616D65223A66616C73652C227365656B5F66726F6D223A33302C226465636F64655F74696D657374616D70223A34343034347D2C7B226964656E74697479223A34352C22707473223A34353034352C227265706F727465645F6475726174696F6E223A313030312C226B65796672616D65223A747275652C227365656B5F66726F6D223A34352C226465636F64655F74696D657374616D70223A34353034357D2C7B226964656E74697479223A34362C22707473223A34363034362C227265706F727465645F6475726174696F6E223A313030312C226B65796672616D65223A66616C73652C227365656B5F66726F6D223A34352C226465636F64655F74696D657374616D70223A34363034367D2C7B226964656E74697479223A34372C22707473223A34373034372C227265706F727465645F6475726174696F6E223A313030312C226B65796672616D65223A66616C73652C227365656B5F66726F6D223A34352C226465636F64655F74696D657374616D70223A34373034377D2C7B226964656E74697479223A34382C22707473223A34383034382C227265706F727465645F6475726174696F6E223A313030312C226B65796672616D65223A66616C73652C227365656B5F66726F6D223A34352C226465636F64655F74696D657374616D70223A34383034387D2C7B226964656E74697479223A34392C22707473223A34393034392C227265706F727465645F6475726174696F6E223A313030312C226B65796672616D65223A66616C73652C227365656B5F66726F6D223A34352C226465636F64655F74696D657374616D70223A34393034397D2C7B226964656E74697479223A35302C22707473223A35303035302C227265706F727465645F6475726174696F6E223A313030312C226B65796672616D65223A66616C73652C227365656B5F66726F6D223A34352C226465636F64655F74696D657374616D70223A35303035307D2C7B226964656E74697479223A35312C22707473223A35313035312C227265706F727465645F6475726174696F6E223A313030312C226B65796672616D65223A66616C73652C227365656B5F66726F6D223A34352C226465636F64655F74696D657374616D70223A35313035317D2C7B226964656E74697479223A35322C22707473223A35323035322C227265706F727465645F6475726174696F6E223A313030312C226B65796672616D65223A66616C73652C227365656B5F66726F6D223A34352C226465636F64655F74696D657374616D70223A35323035327D2C7B226964656E74697479223A35332C22707473223A35333035332C227265706F727465645F6475726174696F6E223A313030312C226B65796672616D65223A66616C73652C227365656B5F66726F6D223A34352C226465636F64655F74696D657374616D70223A35333035337D2C7B226964656E74697479223A35342C22707473223A35343035342C227265706F727465645F6475726174696F6E223A313030312C226B65796672616D65223A66616C73652C227365656B5F66726F6D223A34352C226465636F64655F74696D657374616D70223A35343035347D2C7B226964656E74697479223A35352C22707473223A35353035352C227265706F727465645F6475726174696F6E223A313030312C226B65796672616D65223A66616C73652C227365656B5F66726F6D223A34352C226465636F64655F74696D657374616D70223A35353035357D2C7B226964656E74697479223A35362C22707473223A35363035362C227265706F727465645F6475726174696F6E223A313030312C226B65796672616D65223A66616C73652C227365656B5F66726F6D223A34352C226465636F64655F74696D657374616D70223A35363035367D2C7B226964656E74697479223A35372C22707473223A35373035372C227265706F727465645F6475726174696F6E223A313030312C226B65796672616D65223A66616C73652C227365656B5F66726F6D223A34352C226465636F64655F74696D657374616D70223A35373035377D2C7B226964656E74697479223A35382C22707473223A35383035382C227265706F727465645F6475726174696F6E223A313030312C226B65796672616D65223A66616C73652C227365656B5F66726F6D223A34352C226465636F64655F74696D657374616D70223A35383035387D2C7B226964656E74697479223A35392C22707473223A35393035392C227265706F727465645F6475726174696F6E223A313030312C226B65796672616D65223A66616C73652C227365656B5F66726F6D223A34352C226465636F64655F74696D657374616D70223A35393035397D2C7B226964656E74697479223A36302C22707473223A36303036302C227265706F727465645F6475726174696F6E223A313030312C226B65796672616D65223A747275652C227365656B5F66726F6D223A36302C226465636F64655F74696D657374616D70223A36303036307D2C7B226964656E74697479223A36312C22707473223A36313036312C227265706F727465645F6475726174696F6E223A313030312C226B65796672616D65223A66616C73652C227365656B5F66726F6D223A36302C226465636F64655F74696D657374616D70223A36313036317D2C7B226964656E74697479223A36322C22707473223A36323036322C227265706F727465645F6475726174696F6E223A313030312C226B65796672616D65223A66616C73652C227365656B5F66726F6D223A36302C226465636F64655F74696D657374616D70223A36323036327D2C7B226964656E74697479223A36332C22707473223A36333036332C227265706F727465645F6475726174696F6E223A313030312C226B65796672616D65223A66616C73652C227365656B5F66726F6D223A36302C226465636F64655F74696D657374616D70223A36333036337D2C7B226964656E74697479223A36342C22707473223A36343036342C227265706F727465645F6475726174696F6E223A313030312C226B65796672616D65223A66616C73652C227365656B5F66726F6D223A36302C226465636F64655F74696D657374616D70223A36343036347D2C7B226964656E74697479223A36352C22707473223A36353036352C227265706F727465645F6475726174696F6E223A313030312C226B65796672616D65223A66616C73652C227365656B5F66726F6D223A36302C226465636F64655F74696D657374616D70223A36353036357D2C7B226964656E74697479223A36362C22707473223A36363036362C227265706F727465645F6475726174696F6E223A313030312C226B65796672616D65223A66616C73652C227365656B5F66726F6D223A36302C226465636F64655F74696D657374616D70223A36363036367D2C7B226964656E74697479223A36372C22707473223A36373036372C227265706F727465645F6475726174696F6E223A313030312C226B65796672616D65223A66616C73652C227365656B5F66726F6D223A36302C226465636F64655F74696D657374616D70223A36373036377D2C7B226964656E74697479223A36382C22707473223A36383036382C227265706F727465645F6475726174696F6E223A313030312C226B65796672616D65223A66616C73652C227365656B5F66726F6D223A36302C226465636F64655F74696D657374616D70223A36383036387D2C7B226964656E74697479223A36392C22707473223A36393036392C227265706F727465645F6475726174696F6E223A313030312C226B65796672616D65223A66616C73652C227365656B5F66726F6D223A36302C226465636F64655F74696D657374616D70223A36393036397D2C7B226964656E74697479223A37302C22707473223A37303037302C227265706F727465645F6475726174696F6E223A313030312C226B65796672616D65223A66616C73652C227365656B5F66726F6D223A36302C226465636F64655F74696D657374616D70223A37303037307D2C7B226964656E74697479223A37312C22707473223A37313037312C227265706F727465645F6475726174696F6E223A313030312C226B65796672616D65223A66616C73652C227365656B5F66726F6D223A36302C226465636F64655F74696D657374616D70223A37313037317D2C7B226964656E74697479223A37322C22707473223A37323037322C227265706F727465645F6475726174696F6E223A313030312C226B65796672616D65223A66616C73652C227365656B5F66726F6D223A36302C226465636F64655F74696D657374616D70223A37323037327D2C7B226964656E74697479223A37332C22707473223A37333037332C227265706F727465645F6475726174696F6E223A313030312C226B65796672616D65223A66616C73652C227365656B5F66726F6D223A36302C226465636F64655F74696D657374616D70223A37333037337D2C7B226964656E74697479223A37342C22707473223A37343037342C227265706F727465645F6475726174696F6E223A313030312C226B65796672616D65223A66616C73652C227365656B5F66726F6D223A36302C226465636F64655F74696D657374616D70223A37343037347D2C7B226964656E74697479223A37352C22707473223A37353037352C227265706F727465645F6475726174696F6E223A313030312C226B65796672616D65223A747275652C227365656B5F66726F6D223A37352C226465636F64655F74696D657374616D70223A37353037357D2C7B226964656E74697479223A37362C22707473223A37363037362C227265706F727465645F6475726174696F6E223A313030312C226B65796672616D65223A66616C73652C227365656B5F66726F6D223A37352C226465636F64655F74696D657374616D70223A37363037367D2C7B226964656E74697479223A37372C22707473223A37373037372C227265706F727465645F6475726174696F6E223A313030312C226B65796672616D65223A66616C73652C227365656B5F66726F6D223A37352C226465636F64655F74696D657374616D70223A37373037377D2C7B226964656E74697479223A37382C22707473223A37383037382C227265706F727465645F6475726174696F6E223A313030312C226B65796672616D65223A66616C73652C227365656B5F66726F6D223A37352C226465636F64655F74696D657374616D70223A37383037387D2C7B226964656E74697479223A37392C22707473223A37393037392C227265706F727465645F6475726174696F6E223A313030312C226B65796672616D65223A66616C73652C227365656B5F66726F6D223A37352C226465636F64655F74696D657374616D70223A37393037397D2C7B226964656E74697479223A38302C22707473223A38303038302C227265706F727465645F6475726174696F6E223A313030312C226B65796672616D65223A66616C73652C227365656B5F66726F6D223A37352C226465636F64655F74696D657374616D70223A38303038307D2C7B226964656E74697479223A38312C22707473223A38313038312C227265706F727465645F6475726174696F6E223A313030312C226B65796672616D65223A66616C73652C227365656B5F66726F6D223A37352C226465636F64655F74696D657374616D70223A38313038317D2C7B226964656E74697479223A38322C22707473223A38323038322C227265706F727465645F6475726174696F6E223A313030312C226B65796672616D65223A66616C73652C227365656B5F66726F6D223A37352C226465636F64655F74696D657374616D70223A38323038327D2C7B226964656E74697479223A38332C22707473223A38333038332C227265706F727465645F6475726174696F6E223A313030312C226B65796672616D65223A66616C73652C227365656B5F66726F6D223A37352C226465636F64655F74696D657374616D70223A38333038337D2C7B226964656E74697479223A38342C22707473223A38343038342C227265706F727465645F6475726174696F6E223A313030312C226B65796672616D65223A66616C73652C227365656B5F66726F6D223A37352C226465636F64655F74696D657374616D70223A38343038347D2C7B226964656E74697479223A38352C22707473223A38353038352C227265706F727465645F6475726174696F6E223A313030312C226B65796672616D65223A66616C73652C227365656B5F66726F6D223A37352C226465636F64655F74696D657374616D70223A38353038357D2C7B226964656E74697479223A38362C22707473223A38363038362C227265706F727465645F6475726174696F6E223A313030312C226B65796672616D65223A66616C73652C227365656B5F66726F6D223A37352C226465636F64655F74696D657374616D70223A38363038367D2C7B226964656E74697479223A38372C22707473223A38373038372C227265706F727465645F6475726174696F6E223A313030312C226B65796672616D65223A66616C73652C227365656B5F66726F6D223A37352C226465636F64655F74696D657374616D70223A38373038377D2C7B226964656E74697479223A38382C22707473223A38383038382C227265706F727465645F6475726174696F6E223A313030312C226B65796672616D65223A66616C73652C227365656B5F66726F6D223A37352C226465636F64655F74696D657374616D70223A38383038387D2C7B226964656E74697479223A38392C22707473223A38393038392C227265706F727465645F6475726174696F6E223A313030312C226B65796672616D65223A66616C73652C227365656B5F66726F6D223A37352C226465636F64655F74696D657374616D70223A38393038397D2C7B226964656E74697479223A39302C22707473223A39303039302C227265706F727465645F6475726174696F6E223A313030312C226B65796672616D65223A747275652C227365656B5F66726F6D223A39302C226465636F64655F74696D657374616D70223A39303039307D2C7B226964656E74697479223A39312C22707473223A39313039312C227265706F727465645F6475726174696F6E223A313030312C226B65796672616D65223A66616C73652C227365656B5F66726F6D223A39302C226465636F64655F74696D657374616D70223A39313039317D2C7B226964656E74697479223A39322C22707473223A39323039322C227265706F727465645F6475726174696F6E223A313030312C226B65796672616D65223A66616C73652C227365656B5F66726F6D223A39302C226465636F64655F74696D657374616D70223A39323039327D2C7B226964656E74697479223A39332C22707473223A39333039332C227265706F727465645F6475726174696F6E223A313030312C226B65796672616D65223A66616C73652C227365656B5F66726F6D223A39302C226465636F64655F74696D657374616D70223A39333039337D2C7B226964656E74697479223A39342C22707473223A39343039342C227265706F727465645F6475726174696F6E223A313030312C226B65796672616D65223A66616C73652C227365656B5F66726F6D223A39302C226465636F64655F74696D657374616D70223A39343039347D2C7B226964656E74697479223A39352C22707473223A39353039352C227265706F727465645F6475726174696F6E223A313030312C226B65796672616D65223A66616C73652C227365656B5F66726F6D223A39302C226465636F64655F74696D657374616D70223A39353039357D2C7B226964656E74697479223A39362C22707473223A39363039362C227265706F727465645F6475726174696F6E223A313030312C226B65796672616D65223A66616C73652C227365656B5F66726F6D223A39302C226465636F64655F74696D657374616D70223A39363039367D2C7B226964656E74697479223A39372C22707473223A39373039372C227265706F727465645F6475726174696F6E223A313030312C226B65796672616D65223A66616C73652C227365656B5F66726F6D223A39302C226465636F64655F74696D657374616D70223A39373039377D2C7B226964656E74697479223A39382C22707473223A39383039382C227265706F727465645F6475726174696F6E223A313030312C226B65796672616D65223A66616C73652C227365656B5F66726F6D223A39302C226465636F64655F74696D657374616D70223A39383039387D2C7B226964656E74697479223A39392C22707473223A39393039392C227265706F727465645F6475726174696F6E223A313030312C226B65796672616D65223A66616C73652C227365656B5F66726F6D223A39302C226465636F64655F74696D657374616D70223A39393039397D2C7B226964656E74697479223A3130302C22707473223A3130303130302C227265706F727465645F6475726174696F6E223A313030312C226B65796672616D65223A66616C73652C227365656B5F66726F6D223A39302C226465636F64655F74696D657374616D70223A3130303130307D2C7B226964656E74697479223A3130312C22707473223A3130313130312C227265706F727465645F6475726174696F6E223A313030312C226B65796672616D65223A66616C73652C227365656B5F66726F6D223A39302C226465636F64655F74696D657374616D70223A3130313130317D2C7B226964656E74697479223A3130322C22707473223A3130323130322C227265706F727465645F6475726174696F6E223A313030312C226B65796672616D65223A66616C73652C227365656B5F66726F6D223A39302C226465636F64655F74696D657374616D70223A3130323130327D2C7B226964656E74697479223A3130332C22707473223A3130333130332C227265706F727465645F6475726174696F6E223A313030312C226B65796672616D65223A66616C73652C227365656B5F66726F6D223A39302C226465636F64655F74696D657374616D70223A3130333130337D2C7B226964656E74697479223A3130342C22707473223A3130343130342C227265706F727465645F6475726174696F6E223A313030312C226B65796672616D65223A66616C73652C227365656B5F66726F6D223A39302C226465636F64655F74696D657374616D70223A3130343130347D2C7B226964656E74697479223A3130352C22707473223A3130353130352C227265706F727465645F6475726174696F6E223A313030312C226B65796672616D65223A747275652C227365656B5F66726F6D223A3130352C226465636F64655F74696D657374616D70223A3130353130357D2C7B226964656E74697479223A3130362C22707473223A3130363130362C227265706F727465645F6475726174696F6E223A313030312C226B65796672616D65223A66616C73652C227365656B5F66726F6D223A3130352C226465636F64655F74696D657374616D70223A3130363130367D2C7B226964656E74697479223A3130372C22707473223A3130373130372C227265706F727465645F6475726174696F6E223A313030312C226B65796672616D65223A66616C73652C227365656B5F66726F6D223A3130352C226465636F64655F74696D657374616D70223A3130373130377D2C7B226964656E74697479223A3130382C22707473223A3130383130382C227265706F727465645F6475726174696F6E223A313030312C226B65796672616D65223A66616C73652C227365656B5F66726F6D223A3130352C226465636F64655F74696D657374616D70223A3130383130387D2C7B226964656E74697479223A3130392C22707473223A3130393130392C227265706F727465645F6475726174696F6E223A313030312C226B65796672616D65223A66616C73652C227365656B5F66726F6D223A3130352C226465636F64655F74696D657374616D70223A3130393130397D2C7B226964656E74697479223A3131302C22707473223A3131303131302C227265706F727465645F6475726174696F6E223A313030312C226B65796672616D65223A66616C73652C227365656B5F66726F6D223A3130352C226465636F64655F74696D657374616D70223A3131303131307D2C7B226964656E74697479223A3131312C22707473223A3131313131312C227265706F727465645F6475726174696F6E223A313030312C226B65796672616D65223A66616C73652C227365656B5F66726F6D223A3130352C226465636F64655F74696D657374616D70223A3131313131317D2C7B226964656E74697479223A3131322C22707473223A3131323131322C227265706F727465645F6475726174696F6E223A313030312C226B65796672616D65223A66616C73652C227365656B5F66726F6D223A3130352C226465636F64655F74696D657374616D70223A3131323131327D2C7B226964656E74697479223A3131332C22707473223A3131333131332C227265706F727465645F6475726174696F6E223A313030312C226B65796672616D65223A66616C73652C227365656B5F66726F6D223A3130352C226465636F64655F74696D657374616D70223A3131333131337D2C7B226964656E74697479223A3131342C22707473223A3131343131342C227265706F727465645F6475726174696F6E223A313030312C226B65796672616D65223A66616C73652C227365656B5F66726F6D223A3130352C226465636F64655F74696D657374616D70223A3131343131347D2C7B226964656E74697479223A3131352C22707473223A3131353131352C227265706F727465645F6475726174696F6E223A313030312C226B65796672616D65223A66616C73652C227365656B5F66726F6D223A3130352C226465636F64655F74696D657374616D70223A3131353131357D2C7B226964656E74697479223A3131362C22707473223A3131363131362C227265706F727465645F6475726174696F6E223A313030312C226B65796672616D65223A66616C73652C227365656B5F66726F6D223A3130352C226465636F64655F74696D657374616D70223A3131363131367D2C7B226964656E74697479223A3131372C22707473223A3131373131372C227265706F727465645F6475726174696F6E223A313030312C226B65796672616D65223A66616C73652C227365656B5F66726F6D223A3130352C226465636F64655F74696D657374616D70223A3131373131377D2C7B226964656E74697479223A3131382C22707473223A3131383131382C227265706F727465645F6475726174696F6E223A313030312C226B65796672616D65223A66616C73652C227365656B5F66726F6D223A3130352C226465636F64655F74696D657374616D70223A3131383131387D2C7B226964656E74697479223A3131392C22707473223A3131393131392C227265706F727465645F6475726174696F6E223A313030312C226B65796672616D65223A66616C73652C227365656B5F66726F6D223A3130352C226465636F64655F74696D657374616D70223A6E756C6C7D5D2C227465726D696E616C5F656E64223A3132303132302C227465726D696E616C5F70726F76656E616E6365223A226465636F6465645F6672616D655F6475726174696F6E227D7D2C22696E746572707265746174696F6E223A7B227769647468223A3332302C22686569676874223A3138302C2273747265616D5F696E646578223A302C2274696D655F626173655F6E756D223A312C2274696D655F626173655F64656E223A33303030302C2273616D706C655F6173706563745F6E756D223A312C2273616D706C655F6173706563745F64656E223A312C22726F746174696F6E5F717561727465725F7475726E73223A302C22636F6C6F72223A7B2272616E6765223A226C696D69746564222C226D6174726978223A226274373039222C227472616E73666572223A226274373039222C227072696D6172696573223A226274373039227D2C22636F646563223A2268323634222C22706978656C5F666F726D6174223A2279757634323070222C2273747265616D5F7374617274223A302C2273747265616D5F6475726174696F6E223A3132303132302C22636F6E7461696E65725F7374617274223A6E756C6C2C22636F6E7461696E65725F6475726174696F6E223A6E756C6C2C22617564696F5F73747265616D73223A5B7B2273747265616D5F696E646578223A312C22636F646563223A22616163222C2274696D655F626173655F6E756D223A312C2274696D655F626173655F64656E223A34383030302C2273747265616D5F7374617274223A302C2273747265616D5F6475726174696F6E223A3139323139322C2273616D706C655F72617465223A34383030302C226368616E6E656C5F636F756E74223A327D5D7D7D2C22617564696F223A7B22736368656D615F76657273696F6E223A312C226465636F6465725F636F6E7472616374223A2266666D7065672D382E302E332F617564696F2D6D616E75616C2D736B69702D7631222C22636F6E74656E74223A7B22736861323536223A5B39302C3133302C31302C3132312C3139312C38352C31332C37322C37372C3134322C3230332C35352C3235352C3232312C3230382C37322C3230382C39392C3130332C3134382C3233352C3230362C39332C3138342C36322C37392C39322C3232392C3234352C3233302C37332C32345D2C22627974655F6C656E677468223A33393135377D2C2273747265616D223A7B2273747265616D5F696E646578223A312C22636F646563223A22616163222C2274696D655F62617365223A7B226E756D657261746F72223A312C2264656E6F6D696E61746F72223A34383030307D2C2273616D706C655F72617465223A34383030302C226368616E6E656C5F6C61796F7574223A7B226F72646572223A226E6174697665222C226368616E6E656C73223A322C226D61736B223A337D2C2273747265616D5F7374617274223A302C2273747265616D5F6475726174696F6E223A3139323139322C22696E697469616C5F70616464696E67223A302C22747261696C696E675F70616464696E67223A302C227365656B5F707265726F6C6C223A307D2C226F62736572766174696F6E73223A5B7B22707473223A2D313032342C2264697363617264223A747275652C226465636F64655F74696D657374616D70223A2D313032342C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A7B226C656164696E67223A313032342C22747261696C696E67223A302C226C656164696E675F726561736F6E223A302C22747261696C696E675F726561736F6E223A307D7D2C7B22707473223A302C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A302C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A313032342C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A313032342C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A323034382C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A323034382C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A333037322C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A333037322C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A343039362C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A343039362C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A353132302C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A353132302C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A363134342C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A363134342C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A373136382C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A373136382C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A383139322C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A383139322C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A393231362C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A393231362C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A31303234302C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A31303234302C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A31313236342C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A31313236342C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A31323238382C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A31323238382C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A31333331322C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A31333331322C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A31343333362C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A31343333362C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A31353336302C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A31353336302C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A31363338342C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A31363338342C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A31373430382C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A31373430382C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A31383433322C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A31383433322C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A31393435362C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A31393435362C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A32303438302C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A32303438302C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A32313530342C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A32313530342C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A32323532382C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A32323532382C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A32333535322C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A32333535322C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A32343537362C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A32343537362C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A32353630302C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A32353630302C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A32363632342C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A32363632342C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A32373634382C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A32373634382C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A32383637322C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A32383637322C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A32393639362C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A32393639362C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A33303732302C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A33303732302C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A33313734342C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A33313734342C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A33323736382C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A33323736382C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A33333739322C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A33333739322C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A33343831362C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A33343831362C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A33353834302C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A33353834302C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A33363836342C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A33363836342C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A33373838382C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A33373838382C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A33383931322C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A33383931322C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A33393933362C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A33393933362C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A34303936302C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A34303936302C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A34313938342C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A34313938342C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A34333030382C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A34333030382C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A34343033322C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A34343033322C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A34353035362C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A34353035362C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A34363038302C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A34363038302C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A34373130342C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A34373130342C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A34383132382C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A34383132382C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A34393135322C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A34393135322C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A35303137362C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A35303137362C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A35313230302C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A35313230302C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A35323232342C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A35323232342C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A35333234382C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A35333234382C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A35343237322C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A35343237322C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A35353239362C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A35353239362C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A35363332302C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A35363332302C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A35373334342C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A35373334342C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A35383336382C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A35383336382C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A35393339322C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A35393339322C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A36303431362C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A36303431362C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A36313434302C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A36313434302C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A36323436342C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A36323436342C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A36333438382C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A36333438382C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A36343531322C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A36343531322C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A36353533362C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A36353533362C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A36363536302C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A36363536302C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A36373538342C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A36373538342C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A36383630382C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A36383630382C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A36393633322C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A36393633322C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A37303635362C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A37303635362C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A37313638302C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A37313638302C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A37323730342C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A37323730342C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A37333732382C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A37333732382C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A37343735322C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A37343735322C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A37353737362C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A37353737362C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A37363830302C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A37363830302C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A37373832342C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A37373832342C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A37383834382C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A37383834382C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A37393837322C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A37393837322C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A38303839362C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A38303839362C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A38313932302C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A38313932302C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A38323934342C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A38323934342C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A38333936382C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A38333936382C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A38343939322C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A38343939322C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A38363031362C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A38363031362C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A38373034302C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A38373034302C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A38383036342C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A38383036342C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A38393038382C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A38393038382C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A39303131322C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A39303131322C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A39313133362C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A39313133362C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A39323136302C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A39323136302C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A39333138342C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A39333138342C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A39343230382C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A39343230382C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A39353233322C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A39353233322C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A39363235362C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A39363235362C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A39373238302C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A39373238302C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A39383330342C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A39383330342C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A39393332382C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A39393332382C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A3130303335322C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A3130303335322C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A3130313337362C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A3130313337362C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A3130323430302C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A3130323430302C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A3130333432342C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A3130333432342C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A3130343434382C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A3130343434382C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A3130353437322C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A3130353437322C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A3130363439362C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A3130363439362C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A3130373532302C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A3130373532302C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A3130383534342C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A3130383534342C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A3130393536382C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A3130393536382C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A3131303539322C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A3131303539322C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A3131313631362C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A3131313631362C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A3131323634302C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A3131323634302C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A3131333636342C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A3131333636342C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A3131343638382C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A3131343638382C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A3131353731322C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A3131353731322C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A3131363733362C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A3131363733362C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A3131373736302C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A3131373736302C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A3131383738342C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A3131383738342C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A3131393830382C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A3131393830382C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A3132303833322C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A3132303833322C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A3132313835362C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A3132313835362C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A3132323838302C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A3132323838302C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A3132333930342C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A3132333930342C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A3132343932382C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A3132343932382C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A3132353935322C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A3132353935322C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A3132363937362C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A3132363937362C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A3132383030302C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A3132383030302C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A3132393032342C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A3132393032342C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A3133303034382C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A3133303034382C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A3133313037322C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A3133313037322C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A3133323039362C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A3133323039362C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A3133333132302C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A3133333132302C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A3133343134342C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A3133343134342C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A3133353136382C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A3133353136382C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A3133363139322C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A3133363139322C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A3133373231362C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A3133373231362C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A3133383234302C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A3133383234302C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A3133393236342C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A3133393236342C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A3134303238382C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A3134303238382C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A3134313331322C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A3134313331322C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A3134323333362C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A3134323333362C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A3134333336302C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A3134333336302C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A3134343338342C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A3134343338342C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A3134353430382C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A3134353430382C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A3134363433322C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A3134363433322C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A3134373435362C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A3134373435362C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A3134383438302C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A3134383438302C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A3134393530342C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A3134393530342C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A3135303532382C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A3135303532382C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A3135313535322C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A3135313535322C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A3135323537362C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A3135323537362C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A3135333630302C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A3135333630302C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A3135343632342C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A3135343632342C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A3135353634382C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A3135353634382C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A3135363637322C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A3135363637322C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A3135373639362C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A3135373639362C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A3135383732302C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A3135383732302C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A3135393734342C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A3135393734342C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A3136303736382C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A3136303736382C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A3136313739322C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A3136313739322C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A3136323831362C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A3136323831362C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A3136333834302C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A3136333834302C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A3136343836342C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A3136343836342C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A3136353838382C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A3136353838382C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A3136363931322C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A3136363931322C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A3136373933362C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A3136373933362C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A3136383936302C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A3136383936302C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A3136393938342C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A3136393938342C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A3137313030382C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A3137313030382C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A3137323033322C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A3137323033322C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A3137333035362C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A3137333035362C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A3137343038302C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A3137343038302C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A3137353130342C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A3137353130342C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A3137363132382C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A3137363132382C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A3137373135322C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A3137373135322C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A3137383137362C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A3137383137362C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A3137393230302C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A3137393230302C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A3138303232342C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A3138303232342C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A3138313234382C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A3138313234382C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A3138323237322C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A3138323237322C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A3138333239362C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A3138333239362C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A3138343332302C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A3138343332302C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A3138353334342C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A3138353334342C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A3138363336382C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A3138363336382C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A3138373339322C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A3138373339322C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A3138383431362C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A3138383431362C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A3138393434302C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A3138393434302C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A3139303436342C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A3139303436342C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A3139313438382C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A3139313438382C227265706F727465645F6475726174696F6E223A3730342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D5D7D7D');
CREATE TABLE state (
            singleton INTEGER PRIMARY KEY CHECK (singleton=1),
            head_revision TEXT NOT NULL REFERENCES revisions(id),
            cursor INTEGER REFERENCES history(id),
            workflow TEXT NOT NULL DEFAULT 'generic' CHECK(workflow IN ('generic','single_source_v1'))
        ) STRICT;
INSERT INTO "state" VALUES(1,'515c85fc-0dff-45b2-b6b8-4dab503fc10a',1,'single_source_v1');
CREATE INDEX revision_parent ON revisions(parent_id);
CREATE INDEX history_revision ON history(revision_id);
CREATE UNIQUE INDEX one_current_generation_per_hold
    ON generation_requests(hold_id) WHERE relevance='current';
CREATE UNIQUE INDEX one_nonterminal_generation_attempt_per_request
    ON generation_attempts(request_id)
    WHERE state IN ('queued','preflight','loading','running','validating','cancelling');
CREATE UNIQUE INDEX one_active_render_attempt ON render_attempts((1)) WHERE state IN ('queued','encoding','encoded_retained','verifying','cancelling');
CREATE UNIQUE INDEX unique_render_cancellation_token ON render_attempts(cancellation_token);
CREATE UNIQUE INDEX one_active_publication_operation ON render_publication_operations(publication_id) WHERE active=1;
COMMIT;