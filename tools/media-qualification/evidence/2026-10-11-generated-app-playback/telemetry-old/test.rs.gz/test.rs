mod worker { use std::time::Instant;
#[derive(Clone, Copy, Debug)]
pub struct WorkerTiming {
    pub started: Instant,
    pub finished: Instant,
    pub published: Option<Instant>,
}
}
mod preview { mod repeat_queue { pub(super) const MAX_WAITING: usize = 16; }
#[path = "/tmp/deadpan-generated-playback-performance-20261011/telemetry-old/telemetry.rs"] mod telemetry; }
