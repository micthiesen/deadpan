from pathlib import Path
import difflib,hashlib,json
s=Path(__file__).resolve().parent
p='crates/deadpan-audio/src/bound_reads/point_suppression_tests.rs'
b=(Path('/Users/michael/Code/deadpan')/p).read_text();x=b
replacements=[
('    assert!(held > 0);','    assert_eq!(held, point_suppression::shell_frames().unwrap() + point_suppression::payload_frames(actual.suppressed.capacity()).unwrap());'),
('    assert!(observer.live_frames() > 0);\n    assert!(observer.live_frames() < held);','    assert_eq!(observer.live_frames(), point_suppression::shell_frames().unwrap());'),
('    assert!(base > 0);\n    let mut successful', '    assert_eq!(base, point_suppression::shell_frames().unwrap());\n    let mut successful'),
('    assert!(full_units > 0);','    assert_eq!(full_units, 6);'),
('        assert!(accepted >= prior && accepted <= MAX_PLAN_WORK_PER_READ);','        assert_eq!(accepted - prior, remaining);'),
('        assert_eq!(receipt_units, accepted - prior);','''        assert_eq!(receipt_units, accepted - prior);
        for (field, units) in [
            ("accepted_account_allocation_units", usize::from(remaining >= 1)),
            ("accepted_vector_allocation_units", usize::from(remaining >= 2)),
            ("accepted_residency_units", usize::from(remaining >= 3)),
            ("accepted_range_mapping_units", remaining.saturating_sub(3).min(2)),
            ("accepted_storage_allocation_units", usize::from(remaining >= 6)),
        ] {
            assert_eq!(trace[field], units, "remaining={remaining}, receipt={trace}");
        }'''),
('            assert!(base > 0);','            assert_eq!(base, point_suppression::shell_frames().unwrap());'),
('    cancelled.store(false, Ordering::Relaxed);\n    let result', '    cancelled.store(false, Ordering::Relaxed);\n    point_suppression::work_trace::reset();\n    let result'),
('''    let observer = renderer.owned_suppression.observer().unwrap();
    let base = observer.live_frames();
    renderer.limits.maximum_resident_frames =''','''    let trace = serde_json::to_value(point_suppression::work_trace::snapshot()).unwrap();
    point_suppression::work_trace::disable();
    assert_eq!(trace["accepted_storage_allocation_units"], 0);
    assert_eq!(trace["accepted_range_mapping_units"], 2);
    assert_eq!(trace["failed"], 1);
    let observer = renderer.owned_suppression.observer().unwrap();
    let base = observer.live_frames();
    assert_eq!(base, point_suppression::shell_frames().unwrap());
    renderer.limits.maximum_resident_frames ='''),
('    assert!(observer.live_frames() > 0);\n    assert!(observer.live_frames() < first_live);','    assert_eq!(observer.live_frames(), point_suppression::shell_frames().unwrap());'),
]
for old,new in replacements:
 assert x.count(old)==1,(old,x.count(old));x=x.replace(old,new)
a=s/'stronger-point_suppression_tests.rs';a.write_text(x)
import subprocess
subprocess.run(['rustfmt','--edition','2024',str(a)],check=True)
x=a.read_text()
patch=''.join(difflib.unified_diff(b.splitlines(True),x.splitlines(True),fromfile='a/'+p,tofile='b/'+p))
(s/'stronger-tests.patch').write_text(patch)
proof={'path':p,'before_sha256':hashlib.sha256(b.encode()).hexdigest(),'after_sha256':hashlib.sha256(x.encode()).hexdigest(),'patch_sha256':hashlib.sha256(patch.encode()).hexdigest(),'scope':'only six focused cfg(test) function assertions; production unchanged'}
(s/'stronger-tests-pins.json').write_text(json.dumps(proof,indent=2)+'\n');print(json.dumps(proof))
