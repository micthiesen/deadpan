from pathlib import Path
import hashlib,json,os,subprocess,sys
s=Path(__file__).resolve().parent;prior=Path('/tmp/deadpan-point-content-query-admission-2026-10-31')
v=sys.argv[1];assert v in ['main','scoped']
root=Path('/Users/michael/Code/deadpan') if v=='main' else Path('/tmp/deadpan-query-groundwork-2026-10-26/scoped')
build=f'point-content-focused-audio-{v}-build-v3'
receipt=json.loads((prior/(build+'.json')).read_text());assert receipt['exit_code']==0 and receipt['sources_unchanged']
pin=next(p for p in json.loads((prior/(build+'-pins.json')).read_text()) if p['name']=='deadpan_audio')
assert pin['artifact']['profile']['opt_level']=='2' and pin['artifact']['profile']['overflow_checks'] and pin['artifact']['profile']['debug_assertions']
assert hashlib.sha256(Path(pin['path']).read_bytes()).hexdigest()==pin['sha256']
manifest={}
for absolute,h in receipt['source_after'].items():
 b=Path(absolute).read_bytes();actual={'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
 assert actual==h,absolute
 manifest[str(Path(absolute).relative_to(root))]=actual
assert manifest==json.loads((s/f'{v}-initial-authority.json').read_text())
encoded=(json.dumps(manifest,sort_keys=True,separators=(',',':'))+'\n').encode()
digest=hashlib.sha256(encoded).hexdigest()
label=f'owned-suppression-old-native-{v}'
p=s/(label+'-source-manifest.json');assert not p.exists();p.write_bytes(encoded)
out=s/(label+'-body.json');assert not out.exists()
variant='main-inherited' if v=='main' else 'scoped-published'
keys={'DEADPAN_POINT_HOST_OUTPUT':str(out),'DEADPAN_POINT_HOST_VARIANT':variant,'DEADPAN_POINT_HOST_SOURCE_SHA256':digest,'DEADPAN_POINT_HOST_PUBLISHED_CHECKPOINT':'af34e1e1143e9abc11f49b77ee49c602c116aac4'}
env=os.environ.copy();env.update(keys)
test='stages::bound_reads::retained_host_baseline::pairs::raw_domain_host_baseline::capture_new_point_content_native_v1'
runner=s/('run_qualified.py' if v=='main' else 'run_scoped_qualified.py')
subprocess.run(['python3',str(runner),'--binary',pin['path'],label,'--',pin['path'],'--ignored','--exact',test,'--nocapture','--test-threads=1'],env=env,check=True)
run=json.loads((s/(label+'.json')).read_text());assert run['exit_code']==0 and run['sources_unchanged'] and run['binaries_unchanged']
for k,value in keys.items():assert run['environment'][k]==value
body=json.loads(out.read_text());assert body.pop('variant')==variant and body.pop('source_sha256')==digest
assert body['operations']==744 and body['schema']=='point-content-native-admitted-v1'
canonical=(json.dumps(body,sort_keys=True,separators=(',',':'))+'\n').encode()
sha=hashlib.sha256(canonical).hexdigest()
assert len(canonical)==27674397 and sha=='3d6338e4e4b0f5617647ab6e0fa4d80bf8882a87c87a55efe306002c3011dbdc'
p=s/(label+'-canonical.json');assert not p.exists();p.write_bytes(canonical)
proof={'variant':v,'published_baseline':(s/'base-revision.txt').read_text().strip(),'fresh_native_execution_before_output_ownership_changes':True,'source_binary_environment_guards':True,'binary_reuse':'immutable published Point-content executable; every current named code input equals its build source_after','binary_sha256':pin['sha256'],'source_inputs':len(manifest),'source_manifest_sha256':digest,'preserved_historical_capture_schema_checkpoint':True,'removed_only':['variant','source_sha256'],'canonical_bytes':len(canonical),'canonical_sha256':sha,'operations':744,'exact_named_test':test}
(s/(label+'-proof.json')).write_text(json.dumps(proof,indent=2)+'\n');print(json.dumps(proof))
