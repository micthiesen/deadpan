from pathlib import Path
import gzip,hashlib,json,sys
s=Path(__file__).resolve().parent
root=Path('/Users/michael/Code/deadpan');scope=Path('/tmp/deadpan-query-groundwork-2026-10-26/scoped')
out=root/'tools/media-qualification/evidence/2026-10-31-point-suppression-output'
assert not out.exists()
allowed={'.json','.md','.txt','.py','.patch','.rs','.stdout','.stderr','.ll','.mir'}
files={}
def collect(base,prefix):
 for p in sorted(base.rglob('*')):
  if p.is_file() and p.suffix in allowed and '__pycache__' not in p.parts and p.name not in {'qualification-draft.md', 'archive-proof.json'}:
   rel=str(p.relative_to(base))
   if 'main/' in rel and rel.endswith('/original_inputs_tests.rs'):continue
   key=prefix+'/'+rel
   assert key not in files;files[key]=p.read_bytes()
collect(s,'qualification')
for name,path in [
 ('old-observer-candidate','/tmp/deadpan-owned-suppression-old-observer-candidate-2026-10-31'),
 ('old-public-observer-candidate','/tmp/deadpan-owned-suppression-old-observer-public-candidate-2026-10-31'),
 ('public-owner-candidate','/tmp/deadpan-owned-suppression-public-candidate-2026-10-31'),
 ('design-review','/tmp/deadpan-point-policy-output-design-review-2026-10-31'),
]:collect(Path(path),name)
for path in json.loads((s/'owned-code-paths.json').read_text()):
 if path.endswith('.rs'):
  files['shipping-source/'+path]=(scope/path).read_bytes()
rows=[]
for rel,data in sorted(files.items()):
 compressed=gzip.compress(data,compresslevel=9,mtime=0);dest=out/(rel+'.gz');dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(compressed)
 assert gzip.decompress(dest.read_bytes())==data
 rows.append({'path':rel,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest(),'stored_path':rel+'.gz','stored_bytes':len(compressed),'stored_sha256':hashlib.sha256(compressed).hexdigest()})
inventory={'schema':'deadpan-qualified-gzip-evidence-v1','scope':'public Point final suppression destination only; no internal policy or whole-read admission','base_revision':(s/'base-revision.txt').read_text().strip(),'records':rows,'expanded_bytes':sum(r['bytes']for r in rows),'stored_bytes':sum(r['stored_bytes']for r in rows),'excluded':'pinned executable copies; full Main original_inputs_tests.rs unowned source (only narrow hook/proof and shipping scoped file retained)'}
b=(json.dumps(inventory,indent=2)+'\n').encode();(out/'inventory.json').write_bytes(b)
proof={'inventory_path':str((out/'inventory.json').relative_to(root)),'inventory_sha256':hashlib.sha256(b).hexdigest(),'records':len(rows),'expanded_bytes':inventory['expanded_bytes'],'stored_bytes':inventory['stored_bytes']}
(s/'archive-proof.json').write_text(json.dumps(proof,indent=2)+'\n');print(json.dumps(proof))
