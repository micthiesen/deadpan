from pathlib import Path
import hashlib,json
s=Path(__file__).resolve().parent
own=set(json.loads((s/'owned-code-paths.json').read_text()))
result={}
for v,root in [('main',Path('/Users/michael/Code/deadpan')),('scoped',Path('/tmp/deadpan-query-groundwork-2026-10-26/scoped'))]:
 old=json.loads((s/f'{v}-initial-authority.json').read_text());unchanged={}
 for p,h in old.items():
  if p in own:continue
  b=(root/p).read_bytes();actual={'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()};assert actual==h,p
  unchanged[p]=actual
 result[v]={'initial_source_inputs':len(old),'unowned_inputs_exact':len(unchanged),'unowned_authority_sha256':hashlib.sha256((json.dumps(unchanged,sort_keys=True,separators=(',',':'))+'\n').encode()).hexdigest()}
 for p in json.loads((s/'immutable-oracle-pins.json').read_text()):assert hashlib.sha256((root/p['path']).read_bytes()).hexdigest()==p['sha256'],p['path']
rows=[]
for p in sorted(own):
 a=(Path('/Users/michael/Code/deadpan')/p).read_bytes();b=(Path('/tmp/deadpan-query-groundwork-2026-10-26/scoped')/p).read_bytes()
 rows.append({'path':p,'main_sha256':hashlib.sha256(a).hexdigest(),'shipping_scoped_sha256':hashlib.sha256(b).hexdigest(),'equal':a==b})
assert [r['path'] for r in rows if not r['equal']]==['crates/deadpan-audio/src/shared_eq/original_inputs_tests.rs']
result.update({'owned_paths':rows,'shipping_authority':'scoped','immutable_payloads_exact':28,'main_in_file_unowned_preservation':'main-owned-file-unowned-preservation.json'})
(s/'final-source-audit.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({v:result[v] for v in ['main','scoped']}))
