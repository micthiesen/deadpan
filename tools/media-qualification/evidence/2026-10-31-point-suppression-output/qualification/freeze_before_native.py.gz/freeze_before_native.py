from pathlib import Path
import hashlib,json
s=Path(__file__).resolve().parent
rows=[]
for v in ['main','scoped']:
 p=json.loads((s/f'owned-suppression-old-native-{v}-proof.json').read_text())
 assert p['fresh_native_execution_before_output_ownership_changes'] and p['source_binary_environment_guards']
 rows.append((s/f'owned-suppression-old-native-{v}-canonical.json').read_bytes())
assert rows[0]==rows[1]
data=rows[0];digest=hashlib.sha256(data).hexdigest()
assert len(data)==27674397 and digest=='3d6338e4e4b0f5617647ab6e0fa4d80bf8882a87c87a55efe306002c3011dbdc'
folder='crates/deadpan-audio/tests/fixtures/owned-suppression-native-baseline-v1'
readme="""# Native before owned output-suppression storage

Fresh independent Main and isolated executions after published
dd5fda5d83205aca0fc3480b7c0dae254224f133, before output representation,
owned-account, constructor or consumer changes. All current named code inputs
equal the immutable published Point-content executables' build sources.
Binary/source/environment guards and full receipts are retained.

Complete bodies agree after removing only outer variant and source_sha256.
The body contains all744 requests, including264 successes and480 typed errors,
and all current Point content/raw/fade/owner/Original admissions. Its actual
current observations are paired.new, never the embedded earlier paired.old.
Every old field and actual Point receipt stays intact.

Historical Point-content schema/checkpoint fields remain literal. The external
proof names the actual current published code checkpoint above. This is a new
unit's genuine before body, not regeneration of any preceding expected output.
All preceding26 expected payload hashes remain fixed.

Output masks currently own plain Vec storage. This body pins existing values,
PCM, errors, work/provider/controller state and cleanup, but does not by itself
establish complete mask ownership/clone/drop pressure. Focused ownership witnesses
must be added independently, before the production ownership changes.

SHA-2563d6338e4e4b0f5617647ab6e0fa4d80bf8882a87c87a55efe306002c3011dbdc
Bytes27,674,397
"""
names=[folder+'/snapshot.json',folder+'/snapshot.sha256',folder+'/README.md']
for root in [Path('/Users/michael/Code/deadpan'),Path('/tmp/deadpan-query-groundwork-2026-10-26/scoped')]:
 p=root/folder;assert not p.exists();p.mkdir(parents=True)
 (p/'snapshot.json').write_bytes(data);(p/'snapshot.sha256').write_text(digest+'\n');(p/'README.md').write_text(readme)
p=s/'immutable-oracle-pins.json';pins=json.loads(p.read_text());assert len(pins)==26;pins.append({'path':names[0],'bytes':len(data),'sha256':digest});p.write_text(json.dumps(pins,indent=2)+'\n')
for name in ['source-files.json','scoped-source-files.json','main-logic-source-files.json','scoped-logic-source-files.json']:
 p=s/name;a=set(json.loads(p.read_text()));assert not a.intersection(names);a.update(names);p.write_text(json.dumps(sorted(a),indent=2)+'\n')
(s/'owned-code-paths.json').write_text(json.dumps(names,indent=2)+'\n')
(s/'before-native-freeze.json').write_text(json.dumps({'bytes':len(data),'sha256':digest,'immutable_payloads':27,'fresh_both_variants_before_production_changes':True},indent=2)+'\n')
print('Frozen genuine before body; all27 oracle hashes fixed')
