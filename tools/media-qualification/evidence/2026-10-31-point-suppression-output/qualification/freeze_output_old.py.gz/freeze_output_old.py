from pathlib import Path
import hashlib,json
s=Path(__file__).resolve().parent
roots=[Path('/Users/michael/Code/deadpan'),Path('/tmp/deadpan-query-groundwork-2026-10-26/scoped')]
a=(s/'owned-suppression-output-old-main-v2-canonical.json').read_bytes();assert a==(s/'owned-suppression-output-old-scoped-v2-canonical.json').read_bytes()
sha=hashlib.sha256(a).hexdigest();assert len(a)==2163557 and sha=='a52d53b51b86311ed3794e38bfeec9b8ce5c3c9027ad8d6ee7b7516c993e18a2'
v=json.loads(a);assert len(v['cases'])==5 and len(v['public_cases'])==3
for c in v['cases'][3:]:
 r=c['result_while_local_work_alive'];assert r['status']=='Ok' and r['suppressed']['len']==257 and r['suppressed']['capacity']==257
for c in v['public_cases']:
 r=c['result_after_public_method_internal_work_drop'];assert r['status']=='Ok' and r==c['result_after_provider_drop']==c['result_after_controller_drop']
prefix='crates/deadpan-audio/tests/fixtures/owned-suppression-output-baseline-v1/'
readme='''# OLD suppression output ownership and aggregate witness

Fresh native Main and isolated captures at published
dd5fda5d83205aca0fc3480b7c0dae254224f133 before production output ownership changes.
Five actual private reads and three direct public Point API reads all succeed.
Actual514-frame alternating checked SilentHold/Source sequences return257
suppression ranges at capacity257 through both shared equalizers and shared
input. Single-read256 and general preparation131072 limits stay unchanged.
Private/public SilentHold returns one actual suppression range; ordinary Source
and genuine Bound Point cases return empty masks. Public final label mapping is
actually executed. No257-range payload is synthesized.

Complete outputs retain exact PCM bits, identities, masks, capacity/Layout,
borrowed helper behavior, errors/work/controller/provider state where accessible,
and actual values after local work/provider and controller drop. Public internal
ReadWork is inaccessible and no surrogate ledger is supplied. Public masks have
no consuming-Vec or block-Clone requirement. Ordinary source masks remain
unadmitted. Requested layouts are descriptive, not leases, allocator or RSS data.

Both complete bodies agree after removing only outer variant/source_sha256.
Preceding27 immutable payloads remain exact. This newly captured independent
OLD oracle is not regenerated from a production ownership implementation.

SHA-256 a52d53b51b86311ed3794e38bfeec9b8ce5c3c9027ad8d6ee7b7516c993e18a2
Bytes2163557
'''
new={prefix+'snapshot.json':a,prefix+'snapshot.sha256':(sha+'  snapshot.json\n').encode(),prefix+'README.md':readme.encode()}
pins=json.loads((s/'immutable-oracle-pins.json').read_text())
for root in roots:
 for pin in pins:assert hashlib.sha256((root/pin['path']).read_bytes()).hexdigest()==pin['sha256']
 for p in new:assert not (root/p).exists()
for root in roots:
 for p,b in new.items():
  target=root/p;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(b)
for f in ['source-files.json','scoped-source-files.json','main-logic-source-files.json','scoped-logic-source-files.json','owned-code-paths.json']:
 p=s/f;x=json.loads(p.read_text());p.write_text(json.dumps(sorted(set(x+list(new))),indent=2)+'\n')
pins.append({'path':prefix+'snapshot.json','sha256':sha,'scope_equal':True});(s/'immutable-oracle-pins.json').write_text(json.dumps(pins,indent=2)+'\n')
proof={'new_oracle':prefix+'snapshot.json','bytes':len(a),'sha256':sha,'prior_immutable_payloads_verified':len(pins)-1,'private_successful_cases':5,'direct_public_successful_cases':3,'actual_aggregate_mask_len_capacity':257,'production_ownership_changes_started':False}
(s/'before-output-freeze.json').write_text(json.dumps(proof,indent=2)+'\n');print(json.dumps(proof))
