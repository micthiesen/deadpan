# Next Point-policy final mask lease seam

Read-only explorer result; no Point-policy implementation or admission credit.
Source is the isolated dd5fda5d shipping Plan code, unchanged in this checkpoint.

In audio_policy_query.rs, audio_policy_admitted93..122 and
 domain_query_with_processing153..188 reach the AudioSample-only finish829..905.
Internal signal_policy523..583 produces Owned<Vec<Range<i64>>,Issuer,Lease>.
Ranges236..265 retains grow() capacity in Ranges.memory. Finish drains that
storage into a separately charged merged temporary, drops the first allocation,
then builds an exact-capacity Vec<Range<AudioSample>> and its output.memory
capacity charge at855..872.

At882..883, GuardedBound::plain(value).adopt_memory(output.memory,budget) folds
the final mask lease into the general guard memory. Inventory.zip(output) then
merges output/inventory guard memory. The contents Vec capacity remains separate
as PolicyBuffer._contents_capacity at890..898. AdmittedAudioPolicyQuery only
holds GuardedBound<PolicyBuffer,...> and exposes borrowed query(); no exclusive
final-mask handoff exists. The separation seam is after final Vec construction
and before adopt_memory/zip882..890.

A future SignalSample carrier needs its own typed finalizer on actual PointCeil
labels. Do not convert a Root-labelled policy into SignalSample or reconstruct
its values. Preserve the final capacity lease separately from contents/inventory
and temporary buffers, then add a sealed exclusive handoff retaining physical
ownership and issuer provenance. Current native public output Account alone
cannot detach a Vec from that borrowed guard. Internal Point/Bound/transfer/cache
ownership closure remains prerequisite work; see the independent transfer
context contract in the evidence archive.

Ordinary audio_policy.rs85..112 uses Vec into_iter/map/collect. The source does
not establish allocation reuse; preserve that actual expression in Plain lanes.
