# Legacy-preserving unique mask representation follow-up

This supplements review.md without changing it. The new constraint is exact
legacy native regression residency, including cache admission based on
size_of::<ReadBlock>(). No frozen bodies, golden values, snapshots or caps may
be normalized to make a new representation pass.

## Decision

The niche enum is viable on the pinned host compiler and is preferable to an
inline Vec-plus-ticket owner. It preserves the actual old Vec allocation in the
Plain lane and preserves the measured ReadBlock/SignalBlock/cache-shell sizes.
Only the new Owned lane allocates and charges the additional unique storage Box.

Use an outer enum without Drop:

    enum Mask<T> {
        Plain(Vec<Range<T>>),
        Owned(OwnedMask<T>),
    }
    struct OwnedMask<T> {
        storage: Option<Box<MaskStorage<T>>>,
    }
    struct MaskStorage<T> {
        ranges: Vec<Range<T>>,
        ticket: OwnedCharge,
    }

OwnedCharge's proposed concrete layout is Arc<Account> plus u64. The account's
internal layout does not enlarge its Arc handle. The closed account handle can
itself be Option<Arc<Account>> with a custom destructor; it remains one word.

Do NOT put Drop on Mask and attempt to match/move its Owned Box after
mem::replace: safe Rust rejects that with E0509. The probe initially exposed that
error. Drop belongs to the smaller OwnedMask wrapper. It Option::take's its Box,
passes it to the safe unbox helper, then explicitly drops Vec before ticket:

    #[inline(never)]
    fn unbox<T>(boxed: Box<T>) -> T { *boxed }

    impl<T> Drop for OwnedMask<T> {
        fn drop(&mut self) {
            if let Some(boxed) = self.storage.take() {
                let MaskStorage { ranges, ticket } = unbox(boxed);
                drop(ranges);
                drop(ticket);
            }
        }
    }

The Box allocation is gone before unbox returns. The Vec allocation is then
gone before ticket drops. Keep labels closed/Copy (actual AudioSample and
SignalSample are i64 newtypes); there is no arbitrary user destructor in a range.

## Actual safe rustc evidence

Compiler: rustc 1.97.1 (8bab26f4f 2026-07-14), host
aarch64-apple-darwin, LLVM22.1.6. The source contains forbid(unsafe_code).
Standalone compilation/execution was explicitly authorized for this follow-up;
no Cargo, project build, native-media execution or fixtures were used.

production-shapes.rs is mechanically extracted from pinned shipping sources:
the entire actual ReadBlock and SignalBlock field definitions, Dependencies
alias, actual AudioSample/SignalSample declarations, and AssetId's macro-emitted
Arc<str> newtype. Only struct names and the proposed suppression field type
change. generate-production-shapes.py records their hashes in
production-shapes-pins.json.

Pinned opt0 and opt2 outputs agree:

| Type | Size | Alignment |
| --- | ---: | ---: |
| Vec<Range<AudioSample>> | 24 | 8 |
| Mask<AudioSample> | 24 | 8 |
| Mask<SignalSample> | 24 | 8 |
| OwnedMask<AudioSample> | 8 | 8 |
| MaskStorage<AudioSample> | 40 | 8 |
| OwnedCharge | 16 | 8 |
| Old / new ReadBlock | 112 / 112 | 8 / 8 |
| Old / new SignalBlock | 80 / 80 | 8 / 8 |
| Old / new Original-input Read enum | 112 / 112 | 8 / 8 |

The source adds const assertions for mask/Vec size+alignment and old/new
ReadBlock/SignalBlock/Read sizes. Carry equivalent assertions into the real code
when implementing. Rust repr(Rust) layout is not a portable ABI promise; do not
assume these measurements survive another target/compiler/extra field.

ReadBlock's suppressed/exhausted field offsets swap in this build (24/48 becomes
48/24). Its size and alignment stay equal. No raw-byte/unsafe/offset consumer is
established; named-field JSON and actual separate Vec allocation semantics can
remain identical. Thus this proves residency-relevant size equivalence, not
identical byte layout. If byte offsets themselves become required, this probe
does not prove that stronger requirement.

Pinned emitted MIR of unbox moves T from *boxed, invokes
<Box<T> as Drop>::drop, and returns only afterwards. The emitted concrete LLVM IR
for MaskStorage<AudioSample> confirms the 40-byte memcpy followed by Box::drop;
Box::drop deallocates the 40-byte allocation through Global before unbox returns.
OwnedMask::drop calls unbox, then drop(Vec), then drop(OwnedCharge). Therefore the
proof uses the current pinned compiler's generated code, rather than relying
only on the nightly std source inspected for the previous review.

Saved evidence:
- layout-probe.rs, production-shapes.rs, generation script and source pins;
- layout-probe.stdout and layout-probe-opt2.stdout;
- layout-probe.mir and layout-probe.ll;
- layout-core-artifact.json.

The exact qualified opt0 and opt2 core rlib filenames supplied in final compiler
artifact records were checked and both were absent after target hygiene.
No stale replacement artifact was globbed in. Thus the probe uses exact
source-extracted data shapes, not an imported production rlib or a rebuilt
project. That limitation is explicit. Production compile assertions and full
native frozen regressions remain owed.

## Additional exact-legacy trap: iterators

Same sizeof is necessary, not sufficient. A generic Mask::into_iter wrapper can
disable Vec::IntoIter/map/collect specialization and in-place reuse, changing
the actual old allocation/capacity trace even in Plain mode.

Keep variant-aware helpers whose Plain arm executes the original Vec expression
with its original iterator types:

    match mask {
        Mask::Plain(vec) => original_vec_map_collect(vec, ...),
        Mask::Owned(owner) => admitted_replacement(owner, ...),
    }

Likewise keep merged_suppression's old Vec body for Plain. Do not route it
through a custom charged iterator, change capacity strategy, or eagerly create
an account. The Owned arm may move its Box into a method because the outer Mask
has no Drop; that method must retain its ticket through the actual replacement
allocation/copy and charge the overlap.

Serialization should explicitly emit the same range sequence, and read-only
slices/len/capacity can dispatch without allocation. Mutation and consuming maps
must dispatch with admission in the Owned arm. No unrestricted into_vec,
DerefMut or deep Clone is safe for Owned.

## What this solves and what it does not

It solves the prior layout objection without requiring all ordinary renderer
queries to be admitted: old Plain branches can keep the exact old Vec storage,
capacities, helper expressions and cache residency calculation.

The account must initialize only when the new admitted Point lane first needs
it. Existing frozen legacy paths must reach only Plain, allocate no Box/account,
and record no extra charge. Account fields may grow StageAudio itself; verify
that no newly touched reservation uses sizeof<StageAudio>, rather than assuming
the field is always free.

Owned requires reservation before its 40-byte Box allocation and before any new
mask Vec allocation. Its ticket covers the actual Box and Vec capacity, each
rounded according to the existing admission rule. Dispose Box first, Vec
second, then release. A cache containing Owned must exclude already charged
payload bytes from its local resident scalar while retaining the ordinary
ReadBlock/outer-Arc accounting; Plain uses the exact current resident formula.

The Point/public/Bound/retained/cache ownership closure from review.md still
applies. Lazy account allocation, exact value-bound charge transfer, overlap,
wrong issuer/account, concurrent external drops and account-shell disposal
still require implementation and proof. The niche enum removes the generic
legacy representation blocker; it does not authorize detaching a Vec or
skipping downstream ownership.

All 26 complete legacy native frozen-body regressions must pass unchanged after
implementation. Do not subtract layout deltas, patch goldens, or label changed
native residency as an expected fee. New Owned charges belong only to the new
admitted lane with independent receipt fields.
