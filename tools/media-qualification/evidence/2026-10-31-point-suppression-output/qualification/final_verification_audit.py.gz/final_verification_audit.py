from pathlib import Path
import hashlib,json,re
s=Path(__file__).resolve().parent
checks=['point-suppression-main-strict-check-v2','point-suppression-scoped-clippy-v2','point-suppression-scoped-format-v1','point-suppression-main-docs-v1','point-suppression-scoped-docs-v1','point-suppression-main-hygiene-v1','point-suppression-scoped-hygiene-v1','point-suppression-main-postlint-library','point-suppression-scoped-postlint-library']
for label in checks:
 r=json.loads((s/(label+'.json')).read_text());assert r['exit_code']==0 and r['sources_unchanged'] and r['binaries_unchanged'],label
result={'final_checks':checks,'matrices':{},'native_executables_serial_across_roots':True,'scoped_lint_expectations_after_matrix':'lint-only-source-proof.json','postlint_final_library_reexecuted':True,'shipping_authority':'scoped','scope':'public Point final suppression destination only'}
for v in ['main','scoped']:
 matrix=json.loads((s/f'point-suppression-{v}-final-audio-matrix.json').read_text());assert matrix['all_pass'] and len(matrix['rows'])==21 and matrix['reused_final_identical']==7
 pins={p['name']:p for p in json.loads((s/f'public-point-suppression-{v}-all-build-v3-pins.json').read_text())};totals=[0,0,0]
 for row in matrix['rows']:
  p=pins[row['target']];assert p['sha256']==row['binary_sha256'];assert hashlib.sha256(Path(p['path']).read_bytes()).hexdigest()==p['sha256']
  profile=p['artifact']['profile'];assert profile['opt_level']=='2' and profile['overflow_checks'] and profile['debug_assertions']
  r=json.loads((s/(row['label']+'.json')).read_text());assert r['exit_code']==0 and r['sources_unchanged'] and r['binaries_unchanged']
  n=re.search(r'(\d+) passed; (\d+) failed; (\d+) ignored; \d+ measured; (\d+) filtered',row['result']);assert n and n[2]=='0'
  for i,k in enumerate([1,3,4]):totals[i]+=int(n[k])
 post=(s/f'point-suppression-{v}-postlint-library.stdout').read_text();expected=463 if v=='main' else 457
 assert f'test result: ok. {expected} passed; 0 failed; 14 ignored;' in post
 build=json.loads((s/f'point-suppression-{v}-postlint-lib-build.json').read_text());assert build['exit_code']==0 and build['sources_unchanged']
 for absolute,h in build['source_after'].items():
  b=Path(absolute).read_bytes();assert {'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}==h,absolute
 result['matrices'][v]={'targets':21,'passed':totals[0],'ignored':totals[1],'filtered':totals[2],'reused_byte_identical_v3':7,'reexecuted_v3':14,'postlint_library_passed':expected,'final_named_source_inputs':len(build['source_after'])}
assert result['matrices']['main']['passed']==1044 and result['matrices']['scoped']['passed']==1038
(s/'final-verification-audit.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
