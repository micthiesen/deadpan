# Point policy output ownership decision

Read-only design, 2026-10-31. No implementation, source/fixture edits, builds,
native execution or captures. source-pins.json records the actual sources read.

There is no correct drop-in handoff from the current borrowed policy lease into
the current owned SignalBlock. I recommend making owned suppression-buffer
accounting an explicit prerequisite, then adding Point policy admission. This
is broader than one constructor and one borrowed consumer. The public Vec and
Clone contracts are part of that scope.

## What the current transfers actually guarantee

- [Lease](/Users/michael/Code/deadpan/crates/deadpan-audio/src/sound_context_admission.rs:20)
  holds &RefCell<ReadWork>. Its destructor subtracts sound_context_frames from
  that borrowed request. Moving it into an output cannot outlive that request.
- [JointTransfer](/Users/michael/Code/deadpan/crates/deadpan-audio/src/sound_context_admission.rs:88)
  validates issuer identity and checked sums, then commit sets the precomputed
  request remainder and zeros the named source lease fields. It does not
  construct a destination owner or extend a lifetime.
- The [Graph publication tail](/Users/michael/Code/deadpan/crates/deadpan-audio/src/shared_eq.rs:981)
  precomputes next_active/next_resident, allocates and validates before commit,
  publishes the retained value, installs those destination charges, and only
  then disarms source leases. Graph cleanup owns the later physical drop and
  active_frames release. Authored EQ uses the same pattern.
- [Core charge transfer](/Users/michael/Code/deadpan/crates/deadpan-core/src/audio_binding/admission.rs:113)
  marks the value transferred and invokes one trusted non-unwinding,
  allocation-free callback. [GuardedBound](/Users/michael/Code/deadpan/crates/deadpan-plan/src/audio_bound_query.rs:619)
  borrows the actual independent charges for that preflight/commit. Neither is
  permission to extract a value and discard its accounting.
- [ReadBlock](/Users/michael/Code/deadpan/crates/deadpan-audio/src/stages.rs:402)
  and [SignalBlock](/Users/michael/Code/deadpan/crates/deadpan-audio/src/stages.rs:505)
  own plain Vec masks and no retained metadata charge. Public PCM blocks also
  expose mutable Vec masks and derive Clone.
- The [Original cache](/Users/michael/Code/deadpan/crates/deadpan-audio/src/shared_eq/original_inputs.rs:292)
  does count samples/mask capacities/dependencies when it publishes a ReadBlock.
  That is a real eventual destination owner, but many Point results return or
  undergo transfers before reaching that cache. It cannot justify an earlier
  uncharged interval.
- [read_point_domain](/Users/michael/Code/deadpan/crates/deadpan-audio/src/stages.rs:1140)
  creates request-local ReadWork, calls the controlled reader, then allocates
  another reference-labeled mask Vec and returns an owned public block.
  read_bound_at and domain/root transfers similarly move or map masks through
  owned blocks.

Thus adding SignalBlock<'work> with a leased mask would safely cover the first
return, but that lifetime propagates through ReadBlock, nested Bound/transfer
callbacks and caches. The public API still cannot return it after local ReadWork
dies. Keeping a pointer to the old ledger, dropping the lease early, or hiding a
clone in merged_suppression is incorrect.

## Concrete preferred design

Introduce one opaque, immutable native suppression-buffer owner with an
**owned** residency charge, and move the allocation and its charge together.
The charge owns an Arc-backed request residency account; it never borrows
ReadWork. This is new output ownership, not a change to Plan's policy grid.

A workable protocol is:

1. Add a distinct owned-output residency account to the request ledger and
   include its current live frames in the existing make_room_for sum. An owned
   output reservation increments this account; the buffer owner's destructor
   decrements it only after the physical allocation is freed. Keep the same
   maximum_resident_frames. The account may outlive ReadWork through returned
   output owners. Work/spend callbacks still use the existing WorkControl.
   Use account identity for transfers; do not invent provenance from byte counts.
2. The new Point-only Plan policy carrier must keep final suppressed storage
   and its actual capacity charge separately addressable from content inventory
   and temporary/result-shell charges. Expose a sealed exclusive preflight token,
   not into_vec. It validates the exact issuer and actual value-bound charges.
   No Root/Domain query or grid conversion is involved.
3. Native preflights output publication while the full policy/content carriers
   still live. Precompute actual capacity bytes/frames, destination account
   total, and any owner/Arc-shell reservation. Reserve additional shell storage
   before allocation; do not reserve the same payload a second time merely to
   transfer it. All fallible cancellation, arithmetic, allocation, issuer and
   quota checks finish before commit.
4. A trusted no-fail commit moves the actual suppressed Vec into the opaque
   output owner, installs that exact destination payload charge, then disarms
   the same source capacity lease. Remaining inventory/shell values are dropped
   physically with their own charges. Total residency is continuous across the
   transfer. Failure or an unused token leaves the original policy carrier
   intact and retryable; no work refund occurs.
5. The numerical reader borrows policy throughout preflight, source/nested
   reads, suppression application and the final control check. Only the final
   publication tail consumes the suppression transfer token. SignalBlock owns
   the new output buffer, so its returned value has no 'work lifetime.
6. All later mask moves retain the owner. Any range rebase/merge needing new
   storage admits its actual destination allocation and keeps the old owner
   live until copying/mapping and publication complete. The public Point label
   mapping still calls reference_at_signal; this is the existing Point label
   operation, never Root relabeling. If a real cache takes ownership, transfer
   into its already measured cache residency in the same no-fail style, with
   no uncharged gap or double count.

The preferred output buffer is immutable shared ownership, for example an
opaque Arc-held allocation plus its owned charge. Clone shares this allocation
and charge. It must not clone a Vec while sharing only the charge. Mutations
require an explicitly admitted replacement. Serialization can preserve exactly
the existing range-array JSON, but the Rust field type cannot remain an
unrestricted pub Vec if allocation admission is meant to remain enforced.

The owned account must support releases after the request scope without a
dangling pointer. Its lifetime is genuinely owned. Only current-request
reservations add to it through the controlled path; output drops only reduce
it. Publication must update charges rather than restoring a stale captured
total, since a separately held output owner could be dropped concurrently.
These are actual ownership/concurrent-drop conditions, not hypothetical guards.

## Honest scope and sequencing

This avoids threading 'work through every output type, but requires:

- a new native owned-output account/reservation/buffer module and inclusion in
  resident-budget checks and complete work snapshots;
- a Point policy carrier with separable final-mask ownership and sealed transfer;
- SignalBlock/ReadBlock and Point-reachable mask aggregation/transfer consumers
  to carry the owner rather than plain Vec storage;
- explicit cache publication transfers;
- public mask ownership/Clone API decisions for outputs that can contain Point
  results. JSON can stay the same, but the public Rust Vec API changes.

The alternative is wider 'work propagation plus caller-scoped/in-place public
outputs that cannot outlive the ledger. That also changes public API and every
affected transfer/cache seam. Neither is a one-file native patch.

Do not implement policy admission first and temporarily detach its mask to keep
today's return types. Publish the current content unit, freeze the actual output
ownership/pressure branches, and take this prerequisite as its own reviewable
unit. A generic Plan finalizer may reduce code duplication, but does not solve
the host lifetime problem; existing Root/Domain traces would still need exact
regression proof.

Required ownership tests include output held beyond ReadWork/controller scope,
shared clone/drop order, allocation-replacement overlap, final label-map failure,
cancel/refusal before commit, wrong issuer/account, actual cache publication and
eviction, and all success/error cleanup. These tests must observe physical
buffer ownership and the destination account, not just zeroed source charges.
