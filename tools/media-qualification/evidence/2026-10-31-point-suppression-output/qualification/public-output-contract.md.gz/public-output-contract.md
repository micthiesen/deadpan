# Public Point suppression destination ownership

Implementation unit after published dd5fda5d83205aca0fc3480b7c0dae254224f133.

Only the final reference-labelled suppression allocation returned by public
StageAudio::read_point_domain is admitted by this unit. Internal SignalBlock,
ReadBlock, policy inputs, Bound callbacks and transfer output Vecs remain the
existing ordinary storage. This does not admit Point policy construction or
establish an internal Plan-to-native lease handoff. Those remain required next.

The existing ordinary SignalSample input remains alive while the final output
maps each endpoint through domain.reference_at_signal. Its existing unadmitted
storage is reported as such. The new actual destination Vec and unique Box are
reserved before allocation, remain value-bound to a closed owned charge, and
are freed before that charge releases. A callback refusal stops immediately.
JSON remains the exact array of reference-labelled ranges. The public Rust mask
is immutable and uniquely owned; no deep Clone, mutable Vec or detach is exposed.
A default-off test lane executes the exact old Vec iterator/map/collect path.

The controller lazily owns an Arc-backed account shared only with closed mask
charges. It includes its real Arc allocation shell and live Box/Vec layouts.
Every mutable publisher is controller-scoped; outputs on other threads can only
decrease live frames. Publication adds charges and never restores a stale total.
Returned masks may outlive both local request work and the controller. All
ordinary resident checks and Original-cache warm predictions include held mask
frames under the unchanged existing cap, without double billing them as cached
PCM. Legacy paths allocate no account and retain their exact old work/values.

Before production changes, freeze complete current native reads and additive
actual private and public output/lifetime/aggregate cases. Do not manufacture a
257-range aggregate success, rewrite old snapshots, raise caps or alter weights.
Verify real public nonempty output, empty no-allocation output, mapping parity,
retention after local/controller drop, cross-request pressure, failure cleanup,
concurrent final drop, exact/short admission and cache prediction behavior.
