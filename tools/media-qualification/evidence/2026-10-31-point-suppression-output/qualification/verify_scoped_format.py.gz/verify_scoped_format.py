from pathlib import Path
import json,subprocess
s=Path(__file__).resolve().parent
paths=[p for p in json.loads((s/'owned-code-paths.json').read_text()) if p.endswith('.rs')]
raise SystemExit(subprocess.run(['rustfmt','--edition','2024','--check','--config','skip_children=true',*paths]).returncode)
