from pathlib import Path
import hashlib,json,os,subprocess,sys
s=Path(__file__).resolve().parent
v,version=sys.argv[1:];assert v in ['main','scoped']
root=Path('/Users/michael/Code/deadpan') if v=='main' else Path('/tmp/deadpan-query-groundwork-2026-10-26/scoped')
build=f'owned-suppression-observer-{v}-build-{version}'
receipt=json.loads((s/(build+'.json')).read_text());assert receipt['exit_code']==0 and receipt['sources_unchanged']
pin=next(p for p in json.loads((s/(build+'-pins.json')).read_text()) if p['name']=='deadpan_audio')
assert pin['artifact']['profile']['opt_level']=='2' and pin['artifact']['profile']['overflow_checks'] and pin['artifact']['profile']['debug_assertions']
assert hashlib.sha256(Path(pin['path']).read_bytes()).hexdigest()==pin['sha256']
manifest={}
for absolute,h in receipt['source_after'].items():
 b=Path(absolute).read_bytes();actual={'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
 assert actual==h,absolute
 manifest[str(Path(absolute).relative_to(root))]=actual
encoded=(json.dumps(manifest,sort_keys=True,separators=(',',':'))+'\n').encode();digest=hashlib.sha256(encoded).hexdigest()
label=f'owned-suppression-output-old-{v}-{version}';mp=s/(label+'-source-manifest.json');assert not mp.exists();mp.write_bytes(encoded)
out=s/(label+'-body.json');assert not out.exists()
variant='main-inherited' if v=='main' else 'scoped-published'
keys={'DEADPAN_OWNED_SUPPRESSION_OUTPUT':str(out),'DEADPAN_OWNED_SUPPRESSION_VARIANT':variant,'DEADPAN_OWNED_SUPPRESSION_SOURCE_SHA256':digest,'DEADPAN_OWNED_SUPPRESSION_PUBLISHED_CHECKPOINT':'dd5fda5d83205aca0fc3480b7c0dae254224f133'}
env=os.environ.copy();env.update(keys)
test='stages::bound_reads::retained_host_baseline::owned_suppression_baseline::capture_old_owned_suppression_output_v1'
runner=s/('run_qualified.py' if v=='main' else 'run_scoped_qualified.py')
subprocess.run(['python3',str(runner),'--binary',pin['path'],label,'--',pin['path'],'--ignored','--exact',test,'--nocapture','--test-threads=1'],env=env,check=True)
run=json.loads((s/(label+'.json')).read_text());assert run['exit_code']==0 and run['sources_unchanged'] and run['binaries_unchanged']
for k,value in keys.items():assert run['environment'][k]==value
body=json.loads(out.read_text());assert body.pop('variant')==variant and body.pop('source_sha256')==digest
assert body['schema']=='old-owned-suppression-output-ownership-v1'
canonical=(json.dumps(body,sort_keys=True,separators=(',',':'))+'\n').encode();sha=hashlib.sha256(canonical).hexdigest()
p=s/(label+'-canonical.json');assert not p.exists();p.write_bytes(canonical)
proof={'variant':v,'published_baseline':(s/'base-revision.txt').read_text().strip(),'fresh_native_execution_before_output_ownership_changes':True,'source_binary_environment_guards':True,'binary_sha256':pin['sha256'],'source_inputs':len(manifest),'source_manifest_sha256':digest,'removed_only':['variant','source_sha256'],'canonical_bytes':len(canonical),'canonical_sha256':sha,'case_count':len(body['cases']),'exact_named_test':test}
(s/(label+'-proof.json')).write_text(json.dumps(proof,indent=2)+'\n');print(json.dumps(proof))
