from pathlib import Path
import json,subprocess,sys
s=Path(__file__).resolve().parent
v,version=sys.argv[1:];assert v in ['main','scoped']
build=f'public-point-suppression-{v}-all-build-{version}'
pins=json.loads((s/(build+'-pins.json')).read_text());assert len(pins)==21
rows=[]
for p in sorted(pins,key=lambda p:p['name']):
 name=p['name'];label=f'point-suppression-{v}-{version}-audio-'+name.replace('_','-')
 args=['--test-threads=1']
 if name=='stages':args+=['--skip','general_split_sound::']
 runner=s/('run_qualified.py' if v=='main' else 'run_scoped_qualified.py')
 code=subprocess.run(['python3',str(runner),'--binary',p['path'],label,'--',p['path'],*args]).returncode
 receipt=json.loads((s/(label+'.json')).read_text());assert receipt['sources_unchanged'] and receipt['binaries_unchanged']
 output=(s/(label+'.stdout')).read_text();result=next((line for line in output.splitlines() if line.startswith('test result:')),None)
 row={'target':name,'label':label,'exit_code':code,'result':result,'binary_sha256':p['sha256'],'arguments':args}
 rows.append(row);print(json.dumps(row),flush=True)
(s/f'point-suppression-{v}-{version}-audio-matrix.json').write_text(json.dumps({'rows':rows,'all_pass':all(row['exit_code']==0 for row in rows),'native_serial':True,'separate_inherited_unfinished_split_tests_filtered':7 if v=='main' else 0},indent=2)+'\n')
raise SystemExit(any(row['exit_code']!=0 for row in rows))
