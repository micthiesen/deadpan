from pathlib import Path
import json,subprocess,sys
s=Path(__file__).resolve().parent
v=sys.argv[1];assert v in ['main','scoped']
old={p['name']:p for p in json.loads((s/f'public-point-suppression-{v}-all-build-v2-pins.json').read_text())}
new={p['name']:p for p in json.loads((s/f'public-point-suppression-{v}-all-build-v3-pins.json').read_text())}
prior={p['target']:p for p in json.loads((s/f'point-suppression-{v}-v2-audio-matrix.json').read_text())['rows']}
assert len(new)==len(old)==len(prior)==21
rows=[]
for name,p in sorted(new.items()):
 if p['sha256']==old[name]['sha256']:
  row={**prior[name],'reused_byte_identical_final_executable':True,'final_build':'v3'}
 else:
  label=f'point-suppression-{v}-v3-audio-'+name.replace('_','-')
  threads=4 if name in ['audio_definition','stages','composite_insert'] else 1
  args=[f'--test-threads={threads}']
  if name=='stages':args+=['--skip','general_split_sound::']
  runner=s/('run_qualified.py' if v=='main' else 'run_scoped_qualified.py')
  code=subprocess.run(['python3',str(runner),'--binary',p['path'],label,'--',p['path'],*args]).returncode
  receipt=json.loads((s/(label+'.json')).read_text());assert receipt['sources_unchanged'] and receipt['binaries_unchanged']
  output=(s/(label+'.stdout')).read_text();result=next((line for line in output.splitlines() if line.startswith('test result:')),None)
  row={'target':name,'label':label,'exit_code':code,'result':result,'binary_sha256':p['sha256'],'arguments':args,'reused_byte_identical_final_executable':False,'final_build':'v3'}
 rows.append(row);print(json.dumps(row),flush=True)
result={'rows':rows,'all_pass':all(row['exit_code']==0 for row in rows),'native_executables_serial':True,'inherited_main_split_tests_filtered':7 if v=='main' else 0,'reused_final_identical':sum(row['reused_byte_identical_final_executable'] for row in rows)}
(s/f'point-suppression-{v}-final-audio-matrix.json').write_text(json.dumps(result,indent=2)+'\n')
raise SystemExit(not result['all_pass'])
