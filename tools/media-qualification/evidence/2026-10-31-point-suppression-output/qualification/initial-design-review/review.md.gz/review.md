# Independent Point policy output ownership review

2026-10-31. Shipping root: /tmp/deadpan-query-groundwork-2026-10-26/scoped.
Parent-reported checkpoint: dd5fda5d83205aca0fc3480b7c0dae254224f133.
No Cargo/native execution, fixture capture/generation, source changes or Git writes.
Source hashes are in source-pins.json. Main was not used as shipping authority.

## Preferred boundary

Introduce unique immutable native suppression ownership with an owned,
controller-associated residency account, then admit fresh Structural Point
policy against that output contract. Use the proposed private Point result to
keep content/policy alive through numerical consumption. It is useful inside the
design, but cannot replace the destination owner.

Per-mask sharing is not required by the observed production callers:
SignalBlock and ReadBlock are not Clone; ReadBlock is already shared through
outer Arc<ReadBlock>. The production search found no suppressed.clone(); its
occurrence is a test helper. Public output structs derive deep Clone, but the
project explicitly permits breaking public Rust API. Remove that unadmitted
deep Clone instead of adding Arc allocation and shell invariants per mask.
Keep JSON and PCM identical.

This prerequisite is wider than a Point constructor. It must cover the actual
Point/public/Bound/retained/cache closure before being described as finished.

## What the actual callers establish

- stages.rs:1188 read_point_domain_controlled has two production consumers:
  public read_point_domain and the Point arm of read_bound_at. Both receive an
  owned SignalBlock before consuming suppression.
- read_signal_queries at 2907 takes policy by value, applies it, then passes its
  Vec into merged_suppression. That helper allocates a second Vec. Plan policy
  has already merged the ranges. Keeping an input guard alongside this output
  does not cover that different physical allocation.
- Public Point mapping calls reference_at_signal through collect. The Bound
  Point callback performs another collect to relabel the already-rebased
  carrier as AudioSample. Both have real source/destination overlap.
- signal_transfer.rs:99 RootSignalTransfer::render consumes callback blocks
  immediately, but allocates a bool mask before callbacks and a new final
  suppression Vec afterwards. It masks discrete PCM before interpolation and
  reapplies PointCeil output suppression. Its output is not the original Point
  policy allocation.
- read_retained_controlled maps Bound masks again. Public outputs outlive local
  ReadWork. PreparedBlock::from(SignalBlock) and a Bound span inside
  read_signal_queries discard masks after numerical use: they need physical
  destruction before release, not an invented destination.
- shared_eq/original_inputs.rs:293 measures mask capacities and ReadBlock shell
  for cache residency. This is a real owner, but not every Point result reaches
  it. With a new independently charged mask, retaining those same capacity
  bytes in cache residency would double count. Evicting cache entries cannot
  release a mask charge while an outer Arc<ReadBlock> still pins it.
- sound_context_admission::Lease borrows &RefCell<ReadWork>. JointTransfer
  validates/subtracts source charges; it does not create an owned destination.

The private-only proposal fails at its projected Vec. Keeping the original
policy guard until mapping completes covers the old Vec, then leaves a new live
Vec with no owner. Capturing a guard in the transfer callback covers its input,
not the transfer-produced mask. Returning the original guard publicly requires
a borrowed ledger that the public entrypoint creates locally. Calling the new
copy output projection does not admit it.

## Inline bounded-mask alternative

Reject one 128/256-range inline representation for the existing general
SignalBlock/ReadBlock/public-output closure. The ReadBlock premise is false.

MAX_EDGE_PREPARATION_FRAMES is 131_072 at stages.rs:136.
prepare_bus_inner (stages.rs:942), read_shared_input (shared_eq.rs:283) and
read_authored_equalizers (authored_eq.rs:462) accept those large windows,
consume 256-frame tiles, extend each tile's suppression and coalesce afterwards.
A larger ReadBlock can therefore require more than 256 ranges.

A static concrete counterexample permitted by the actual types: at
FrameRate::new(48_000,1), which existing Point/native tests already use,
514 one-frame spans alternating explicit SilentHold and nonsuppressed content
produce 257 separated one-sample suppression intervals. Each 256-sample tile has
at most 256 spans, so this does not require raising the native query span cap.
The aggregate is 514 samples, far below 131_072, and coalescing cannot join its
separated intervals. This is a source-derived counterexample, not a generated
or executed fixture.

For a single Point result with nonempty clipped/coalesced integer intervals
contained in its <=256-sample query, at most 128 intervals suffice. That
mathematical bound is sound. However the present policy carrier does not expose
that bound as a checked native representation, and it does not prove the
general ReadBlock paths above. A dedicated SmallReadBlock could preserve the
small bound and avoid a heap mask through the immediate Point/Bound callback.
When it enters the general retained/cache/aggregate path it still needs a real
admitted larger destination. Thus inline may optimize the small leaf, but does
not discharge the reviewed output-ownership prerequisite.

An inline field also enlarges every ReadBlock and therefore its outer Arc/cache
shell: 256 i64 ranges alone are 4096 bytes, 128 ranges are 2048 bytes, before
length/other fields. Existing resident(block) includes size_of::<ReadBlock>(),
so this is a real cap-pressure change requiring measured admission, not free
storage. A fixed array sized for the general 131_072-sample alternating case
would exceed 1 MiB per mask and is an unsuitable default.

## Exact implementation ownership

Add deadpan-audio/src/suppression_output.rs with opaque Suppression<S>:
actual Vec<Range<S>> plus an owned OutputLease, immutable slice/iteration and
transparent range-array serialization. No DerefMut, unrestricted into_vec,
deep Clone or publicly constructible charge. Declare/drop Vec before its lease.
The inline owner itself requires no additional per-buffer heap allocation.

StageAudio owns the only reservation authority for OutputResidencyAccount;
outstanding leases keep it alive and can release from another thread.
Associate it with the controller, not one request: a returned Point block held
during the next read must still count toward that controller's existing cap.
Separate per-request accounts miss that real overlap.

Initialize the account lazily under admission, reserve its actual Arc/control
shell before allocation, and retain that shell charge while StageAudio or
outputs retain a handle. Do not allocate it silently from infallible new().
The closed account wrapper must handle shell deallocation as described below.

Add this live residency to make_room_for AND the separately spelled-out sums
in original_prediction_reservation_fits and original cache publication.
Expose it independently in native work snapshots. Keep caps and existing
canonical-work fields unchanged. Concurrent releases require delta updates;
never restore a preflight-captured total.

Plan audio_policy_query.rs needs a Point-only SignalSample carrier/finalizer
using the actual signal_policy with PointCeil and endpoints=true.
The final mask capacity must be separable from inventory/scratch/shell charges;
current finish combines those into GuardedBound memory. Expose a sealed
consuming transfer token for that precise value-bound capacity, not into_vec.
The AudioPointDomain method/exports remain Structural only. Root/Domain
AudioSample policies and arbitrary voice-provider policies keep their own walks.

In stages.rs keep content and policy carriers through preflight, nested reads,
suppression application and final control check. A borrowing numerical worker
returns PCM/dependencies without cloning/merging the guarded mask. Only final
publication consumes its transfer token into Suppression<SignalSample>.
Preflight all identity/arithmetic/allocation/refusal checks; the final commit
installs the exact owned destination charge and disarms only the corresponding
source charge without allocation or callbacks. Inventory and shell values keep
their own leases until physical destruction.

Carry the opaque owner through:
- SignalBlock and public PointDomainAudioBlock;
- RootSignalBlock/TransferredSignalBlock and Point Bound transfer;
- retained/domain label mapping, ReadBlock and the reachable public outputs;
- aggregation/replacement helpers, retaining old owners through admitted copies;
- shared_eq/original_inputs cache publication/hit/pinning/eviction.

signal_transfer.rs needs a controlled allocation path for Point-derived input:
admit bool scratch and final range capacity, and retain each callback input
through validation/masking/marking. Transferring an input charge to a newly
allocated output without admitting overlap is incorrect.

The smallest cache integration keeps charged masks under the controller account
and excludes those same bytes from cache-local capacity totals. Outer
Arc<ReadBlock> then pins their owner naturally; no per-mask Arc is needed.
An internal ordinary/admitted enum can preserve unrelated existing lanes, but
every Point-derived transition must retain the admitted lane or physically
discard it. Never expose the ordinary branch as a public detach escape.

Adapt real shared numerical consumers in signal_mix.rs and sound_events.rs if
their helper signature changes; preserve their policy semantics and receipts.
This design does not authorize broad native query admission beyond the actual
Point-derived destination closure.

## Arc route, if cheap public Clone is required

Safe Arc::into_inner in EVERY opaque wrapper Drop can solve the payload-shell
ordering. The wrapper owns Option<Arc<Payload>>, exposes no Weak/raw/ordinary Arc
handle, and takes its handle in Drop. Exactly one final call extracts Payload.
With no explicit Weak, into_inner drops the implicit Weak and frees the Arc
allocation before returning Payload. Explicitly drop its Vec before its charge.
This needs no unsafe code.

Ordinary Arc<Payload{Vec,charge}> field destruction releases the charge inside
Payload before freeing the outer Arc shell. Merely ordering payload fields is
insufficient for that shell. try_unwrap(...).ok() also is not equivalent:
concurrent final drops can fail extraction and use ordinary Arc destruction.
The primary source documents that race distinction.

Apply the same closed protocol to the account Arc independently. Reserve its
shell once, retain identity and charge while handles exist, and final extraction
frees that shell before discarding accounting state. The extracted account value
then only occupies stack storage. No self-owning account Arc/cycle is needed.

The locally installed primary std source inspected was
nightly-2026-10-25/.../alloc/src/rcs/arc.rs:1171 into_inner and 2234 drop_slow.
The pinned stable toolchain's source component was absent. No target-toolchain
deallocation instrumentation or runtime concurrency experiment was run.

## Proof owed

Freeze complete ordinary Point contents/order/masks/lookup/work/errors and
actual helper callback traces independently. Preserve PointCeil/source endpoints.

Instrument physical allocation/disposal separately for policy Vec, replacement
labels, transfer bool scratch, transfer range Vec, optional payload shell,
account shell and cache. Confirm source release follows physical disposal or
exact destination publication, including every refusal/cancel/error.

Hold public output after ReadWork and StageAudio scope; hold it during a
subsequent tight-cap request to the same controller. That request must count it.
Dropping releases residency only, never accepted work.

Exercise real Point Bound/halo transfer, signed/fractional coordinates, retained
mapping, fully silent masks, and dispose-only prepared/parent paths.
Verify actual cache publication/hit/outer-Arc pinning/eviction counts payload once.
Inject wrong issuer/account, unused transfer token, failed map/provider/final
check, and every real reserve/spend refusal.

If Arc payload is chosen, concurrent final drops must extract exactly once and
show shell-free-before-charge. Account-final-drop needs equivalent proof even
with the preferred unique masks.

Full DP-01..24/Gates A..G remains active. This is a design review, not implemented
behavior, runtime verification or permission to raise caps/refund work.
