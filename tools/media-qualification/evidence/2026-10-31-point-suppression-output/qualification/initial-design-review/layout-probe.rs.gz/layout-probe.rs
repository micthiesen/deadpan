#![forbid(unsafe_code)]
#![allow(dead_code)]
use std::{collections::BTreeMap, mem::{align_of, offset_of, size_of}, ops::Range, sync::{Arc, atomic::AtomicU64}};

#[cfg(actual_core)]
use deadpan_core::{AssetId, AudioSample};
#[cfg(not(actual_core))]
#[derive(Ord, PartialOrd, Eq, PartialEq)]
struct AssetId(String);
#[cfg(not(actual_core))]
struct AudioSample(i64);

struct Account { frames: AtomicU64 }
struct OwnedCharge { account: Arc<Account>, frames: u64 }
struct MaskStorage<T> { ranges: Vec<Range<T>>, ticket: OwnedCharge }
enum Mask<T> { Plain(Vec<Range<T>>), Owned(Box<MaskStorage<T>>) }
impl<T> Drop for Mask<T> {
    fn drop(&mut self) {
        if let Self::Owned(boxed) = std::mem::replace(self, Self::Plain(Vec::new())) {
            let MaskStorage { ranges, ticket } = unbox(boxed);
            drop(ranges);
            drop(ticket);
        }
    }
}
#[inline(never)]
fn unbox<T>(b: Box<T>) -> T { *b }

struct LegacyReadBlock {
    start: AudioSample,
    samples: Vec<[f32; 2]>,
    dependencies: BTreeMap<AssetId, [u8;32]>,
    relative_depth: usize,
    suppressed: Vec<Range<AudioSample>>,
    exhausted: Vec<Range<AudioSample>>,
}
struct ProposedReadBlock {
    start: AudioSample,
    samples: Vec<[f32; 2]>,
    dependencies: BTreeMap<AssetId, [u8;32]>,
    relative_depth: usize,
    suppressed: Mask<AudioSample>,
    exhausted: Vec<Range<AudioSample>>,
}
struct LegacySignalBlock {
    samples: Vec<[f32;2]>,
    dependencies: BTreeMap<AssetId,[u8;32]>,
    suppressed: Vec<Range<AudioSample>>,
    relative_depth: usize,
}
struct ProposedSignalBlock {
    samples: Vec<[f32;2]>,
    dependencies: BTreeMap<AssetId,[u8;32]>,
    suppressed: Mask<AudioSample>,
    relative_depth: usize,
}
fn main() {
    macro_rules! layout { ($t:ty) => {
        println!("{} size={} align={}", stringify!($t), size_of::<$t>(), align_of::<$t>());
    }}
    layout!(Vec<Range<AudioSample>>);
    layout!(Mask<AudioSample>);
    layout!(MaskStorage<AudioSample>);
    layout!(OwnedCharge);
    layout!(LegacyReadBlock); layout!(ProposedReadBlock);
    layout!(LegacySignalBlock); layout!(ProposedSignalBlock);
    println!("legacy read offsets start={} samples={} dependencies={} depth={} suppressed={} exhausted={}",
        offset_of!(LegacyReadBlock,start),offset_of!(LegacyReadBlock,samples),
        offset_of!(LegacyReadBlock,dependencies),offset_of!(LegacyReadBlock,relative_depth),
        offset_of!(LegacyReadBlock,suppressed),offset_of!(LegacyReadBlock,exhausted));
    println!("new read offsets start={} samples={} dependencies={} depth={} suppressed={} exhausted={}",
        offset_of!(ProposedReadBlock,start),offset_of!(ProposedReadBlock,samples),
        offset_of!(ProposedReadBlock,dependencies),offset_of!(ProposedReadBlock,relative_depth),
        offset_of!(ProposedReadBlock,suppressed),offset_of!(ProposedReadBlock,exhausted));
    println!("legacy signal offsets samples={} dependencies={} suppressed={} depth={}",
        offset_of!(LegacySignalBlock,samples),offset_of!(LegacySignalBlock,dependencies),
        offset_of!(LegacySignalBlock,suppressed),offset_of!(LegacySignalBlock,relative_depth));
    println!("new signal offsets samples={} dependencies={} suppressed={} depth={}",
        offset_of!(ProposedSignalBlock,samples),offset_of!(ProposedSignalBlock,dependencies),
        offset_of!(ProposedSignalBlock,suppressed),offset_of!(ProposedSignalBlock,relative_depth));
    let account = Arc::new(Account{frames:AtomicU64::new(0)});
    let mask=Mask::Owned(Box::new(MaskStorage{ranges:vec![AudioSample(0)..AudioSample(1)],ticket:OwnedCharge{account,frames:1}}));
    drop(mask);
    // No recursive replacement on the Plain path.
    drop(Mask::Plain(vec![AudioSample(0)..AudioSample(1)]));
}
