# Independent implementation review: public Point suppression ownership

No material correctness finding in module
3d4eff32ba8b22f9cc798221e3b935e8e5e7d70251e97c173afea6395fdc3872 and the
current Main/scoped hooks pinned beside this report.

Read-only review. No root edits, Cargo, project/native execution, fixture work or
Git operations. The parent reported first library compilations passed; this
reviewer did not execute them. Copies in this directory and source-pins.json
freeze the exact reviewed files despite concurrent integration.

## Ownership and actual allocation

- Account initializes only after shell work, make_room(shell) and control
  checks. The closed Arc allocation then installs live=shell without a
  callback/fallible operation between allocation and installation.
- Payload Layout is checked before allocation: destination range array count,
  plus actual Storage Box size. Existing account residency participates in the
  pre-allocation make_room call. charge_after_admission validates its scalar
  addition then fetch_adds; no stale captured total is stored.
- The Pending Storage value contains ranges before charge, so a partially
  mapped destination drops its Vec before releasing the payload reservation.
  Vec::with_capacity(count) follows reservation and asserts actual capacity.
  Box allocation occurs after the complete endpoint map succeeds.
- Original SignalSample input stays live through destination construction and
  final control check, then is explicitly dropped. It remains the openly
  existing ordinary/unadmitted source mask for this checkpoint.
- OwnedMask Drop unboxes the real Box with the separate safe helper, then drops
  its Vec, then Charge. The previously pinned compiler proof establishes Box
  deallocation before helper return. Range labels are Copy i64 newtypes.
- All Handle strong references use the closed into_inner Drop path. The last
  extracted AccountData is obtained after shell deallocation, then shell frames
  are retired from its stack-resident counter. Test observers are closed handles
  and correctly retain the physical shell until their own drop.

## Concurrency and real cap gates

StageAudio's exclusive mutable publisher is the only account addition
authority. Concurrent public output drops only subtract atomically.
A live counter load can become conservative during a concurrent drop; it
cannot allow quota overrun. Charge subtraction occurs before Handle drop, so
the final handle must observe shell frames only.

Current source includes the live account in all three actual
maximum_resident_frames gates found in the native source:
make_room_for, original_prediction_reservation_fits, and optional Original
cache publication. Payloads remain independent of the unrelated cache capacity
scalar. Internal ReadBlock/SignalBlock field layouts are unchanged in this
public-only unit.

owned_suppression_residency spends one separately traced unit only when account
frames are nonzero. Its work trace is called only after successful work
acceptance. The previous fixed six-unit prediction bill remains unchanged.
No code resets accepted work on constructor/refusal/destruction paths.

## Legacy, API and coordinate semantics

The latest point_content_request legacy wrapper chains the suppression flag.
The helper's legacy arm uses the exact original Vec into_iter/map/collect
expression before any new control check, account work or allocation.
This retains the original iterator type and allocation reuse rather than
routing through a custom consuming iterator.

Opaque public PointSuppressionMask exposes immutable ranges, their actual
capacity, Debug, PartialEq and range-sequence Serialize. It has no owned
IntoIterator, Vec detach, DerefMut or deep Clone. Its borrowed IntoIterator is
safe: it returns a slice iterator whose borrow keeps the owner live.
Default creates only an allocation-free empty Plain Vec. The enclosing public
Point block intentionally loses Clone, within the authorized Rust API break.

Point mapping continues to call domain.reference_at_signal on both endpoints.
No Root/Domain policy substitution, grid conversion or content-policy admission
is introduced. Public Source/empty masks avoid account and payload allocation;
nonempty results retain their destination ownership past request/controller
scope.

## Tests reviewed and remaining proof

The module's six pure tests cover values/serialization, empty/default,
layout, output lifetime and concurrent closed-handle/payload drops.
The six public-path tests exercise real Point output, Source empty,
cross-request pressure, every measured work-prefix cutoff, endpoint mapping
failure/initial cancellation, and concurrent output disposal.
The two added cache tests reach actual warm-prediction rejection/recovery and
optional publication rejection/recovery with a held public mask. They preserve
cache identities and confirm payload is not counted as cache storage.

These are source observations, not a runtime pass claim. Before completion the
parent still owes the actual unchanged frozen native bodies, public-output
comparison, real quota/prefix/cache tests, and normal project checks. Source
layout assumptions remain qualified to the pinned host compiler and require
requalification if the account/storage shape or toolchain changes.

The broader guarded Point policy and internal Bound/retained/cache mask handoff
remain outside this unit. This implementation must not be described as their
completion.
