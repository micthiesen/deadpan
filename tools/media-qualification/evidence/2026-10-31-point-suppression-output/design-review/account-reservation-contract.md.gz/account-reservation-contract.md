# Minimal owned suppression account contract

Public-only first unit is sound: change PointDomainAudioBlock.suppressed to the
opaque niche mask, admit its existing final reference_at_signal mapping
destination, and leave internal SignalBlock/ReadBlock/transfer masks openly
ordinary for this checkpoint. This activates a real owned lane now without
pretending that Point policy or recursive output ownership is admitted.
The later Point-policy unit still owes its source-lease handoff and downstream
Bound/retained/cache closure.

No frozen legacy body, golden, cap or residency value changes. Its Plain branch
must keep the exact original Vec iterator expression. Prior review notes remain
immutable; this is the narrower recommended first implementation.

## Concrete private types and API

    #[repr(C)]
    struct AccountData { live_frames: AtomicU64 }
    struct Handle { inner: Option<Arc<AccountData>> }
    struct Account { handle: Option<Handle> } // StageAudio owns this
    struct Charge { handle: Handle, frames: u64 }
    struct Storage<T> { ranges: Vec<Range<T>>, ticket: Charge }
    struct Owned<T> { boxed: Option<Box<Storage<T>>> }
    enum Mask<T> { Plain(Vec<Range<T>>), Owned(Owned<T>) }

Only Mask's immutable read/Serialize surface is public. Handle, Charge and
Account mutation are private to the native module and trusted StageAudio host.
No Arc, Weak, Vec detach, DerefMut, generic public IntoIterator or deep Clone
escapes. Charge itself is not Clone. Private Handle clone shares the one account
allocation and allocates nothing. Samples labels are the closed Copy newtypes.

Minimal native account interface:

- account_layout_if_uninitialized(): Option<Layout>.
- initialize_after_admission(): install the real Arc, live_frames initially
  equal to its shell charge. Parent must already have admitted that exact
  Layout through its existing check/make_room gate.
- live_frames(): zero for None, atomic load for initialized.
- reserve_after_admission(frames): return Charge, atomically adding the exact
  reservation. Only the sole mutable StageAudio publisher calls this after its
  gate succeeds.
- private Handle/Charge destructors; no general public reservation interface.

Keep those after_admission methods narrow and sealed; safe Rust enforces
memory/lifetime ownership, not correct quota use. Their admission proof is the
single concrete StageAudio callsite, as with existing trusted transfer tails.

All residency sums, including explicit Original prediction/publication sums,
include the account's live scalar. Earlier output retained across a later read
must reduce that read's headroom. Account initialization is lazy and absent
from the complete old Plain lane.

## Shell admission before allocation

For the chosen AccountData only an AtomicU64 is stored. Pinned 1.97.1
aarch64-apple-darwin evidence in account-layout-probe.ll shows the actual
Arc::new<AccountData> body calls box_new_uninit(align=8,size=24): two atomic
usize reference counters plus the 8-byte AccountData.

Compute the requested Layout before allocation with a repr(C) layout-only
shape containing two AtomicUsize fields and AccountData. No raw Arc allocation,
pointer cast, allocator replacement or unsafe code is involved. On this target
the shell is 24 bytes, or three stereo-f32 frame equivalents.

The host does:

1. control.check and make_room(shell_frames), with no account allocation yet.
2. Immediately allocate Arc<AccountData> with live=shell_frames, wrap in the
   closed Handle and install it. This tail has no callback, arithmetic,
   cancellation check or other fallible action.
3. Subsequent payload admission includes this actual live shell.

A failed later payload construction may leave the empty account initialized.
Its shell really remains allocated and must remain charged until controller
and every output handle are gone. Do not zero it to imitate an unused account.

The layout calculation depends on the pinned standard-library representation.
The probe confirms actual requested allocation, not just size_of::<Arc<_>>.
Changing toolchain, target, AccountData fields or account representation
requires requalification before using the computed shell Layout.

## Current public Point mapping construction

The StageAudio helper receives the ordinary SignalSample Vec, domain and shared
WorkControl. The helper owns that input Vec throughout mapping. There is no
source charge to transfer in this first unit and no claim that the source was
admitted.

For nonempty input count n, precompute checked:

- Layout::array::<Range<ReferenceSample>>(n), exactly the destination Vec's
  requested capacity.
- Layout::new::<Storage<ReferenceSample>>(), 40 bytes on this pinned shape.
- Checked u64 frame equivalents using the existing round-up-by-eight rule.
  Both requested sizes here are multiples of eight.

After lazy account admission, host check/make_room(payload_frames) includes
the current shell and previous outputs. Obtain Charge before either new
allocation. The sole mutable publisher has exclusive addition authority.

Declare Charge before allocating the destination Vec. Use Vec::with_capacity(n)
with the precomputed requested Layout; assert/qualify capacity==n as existing
Plan code does. Push checked reference_at_signal endpoints from input.iter().
All failure paths physically discard any partially filled destination before
Charge drops. Keep the original input Vec alive through the complete checked
map, then dispose it normally.

Only after successful mapping allocate Box::new(Storage{ranges,ticket}).
The charge already includes the actual Box's Layout. The returned Mask owns the
Box and its destination Vec. If a final control check is desired, it operates
on this fully guarded owner; failure drops it through the normal closed path.

No generic Vec iterator wrapper is needed. The old test-only Plain arm retains
its exact original into_iter().map(...).collect::<Result<_,_>>() expression,
including its in-place reuse/capacity behavior. Empty outputs can remain empty
Plain and avoid creating account/Box; they own no destination allocation.

Preserve the ordinary query's existing work receipt. Do not rebill it or call
new map/account fees canonical policy work. Any decision to bill newly covered
native work needs an independent additional receipt and accepted-prefix proof.
In separately billed resident-sum checks, do not silently treat the old fixed
six-unit four-resident-plus-two-disk bill as proof for new arithmetic.

## Concurrent drops and exclusive publication

All output releases use atomic fetch_sub, never load/subtract/store.
Reservation commit uses atomic fetch_add, never a preflight-captured next total.

Between host preflight and commit, concurrent outputs may only decrease the
counter. StageAudio's exclusive mutable borrow is the only addition authority.
Therefore a preflight bound remains conservative when outputs drop; commit
cannot overwrite those releases. Check arithmetic against the preflight load
before the gate. With no competing publisher and the existing cap, the later
add cannot overflow.

Charge Drop subtracts its exact frames, then its Handle field drops.
All payload allocations must already be gone at that point. Counter operations
may be Relaxed: they publish accounting scalars, not PCM; final account lifetime
synchronization comes from Arc's release/acquire protocol. No reservation can
race controller destruction because it requires that live mutable controller.

Each Handle Drop takes its Option<Arc> and calls Arc::into_inner. Every strong
handle, including the controller's handle, follows that path. No explicit Weak
or ordinary Arc Drop escapes. Exactly one final drop extracts AccountData after
the real Arc allocation is freed. It then subtracts the shell's three frames
from the extracted stack-resident counter, which must contain only that shell.
No self-owning Arc or external abstract escrow is necessary.

The shell retirement has no external observer after the last handle disappears.
If a test retains an observer handle, that shell is still physically live and
correctly stays charged. A test-only final-retirement hook can record the
post-free zero without extending the account allocation lifetime.

## Box, Vec and charge destruction

Owned Drop takes its Box, calls the separate safe helper
fn unbox<T>(b: Box<T>) -> T { *b }, then destructures Storage, drops ranges, and
drops ticket. Pinned MIR/LLVM from the preceding follow-up establishes:

1. Box allocation physically deallocated inside unbox before it returns;
2. Vec allocation destroyed next;
3. Charge releases those frames;
4. Handle may finally free and retire account shell.

The outer Mask has no Drop. Implementing Drop there prevents moving out its
Owned variant in safe Rust (E0509). Owned's Option<Box> enables safe take without
allocating a replacement Box.

## Prepared future transfer shapes

The standalone safe pinned probe reports:

| Shape | Allocated payload size |
| --- | ---: |
| Storage{Vec,Charge} | 40 bytes |
| Option<Storage{Vec,Charge}> | 40 bytes |
| Storage{Vec,Option<Charge>} | 48 bytes |

All three outer niche Mask enums remain 24 bytes/align8. Therefore current
checked-copy construction should keep simple Box<Storage>; no prepared shell
is necessary for it.

For a later allocation-free Plan transfer tail, prefer a prepared
Box<Option<Storage>> containing None, with its real 40-byte Box charge owned by
a separate private preparation guard. Admit that Box before allocation. On
unused/failure, free Box(None) before releasing its shell charge.

After all source/destination identity, issuer, capacity and arithmetic checks,
a sealed no-fail commit can install Some(Storage{moved_source_vec,combined_ticket})
into the already allocated Box. Source payload charges and the prepared Box
charge move into the ticket at that real destination. The input allocation
must remain charged until this publication; no unadmitted clone is introduced.

The Option<Charge> alternative is larger and permits a nonempty Vec state with
no ticket. It is avoidable and less clear. Do not prematurely change the
current public-copy unit merely to scaffold the future transfer.

## Capacity-changing maps and merges

Public owner mutation is prohibited. A capacity-changing replacement admits
the entire new Vec and Box while every old owner remains live. Build and
validate replacement, publish it, then physically drop old owners.
For a two-input merge, both input charges and the complete destination charge
coexist. Coalesce in place using allocation-free operations; reduced length
does not reduce retained capacity or its charge. Do not shrink_to_fit, use an
unadmitted reserve/realloc, or clone a Vec while sharing its ticket.

For Plain operations preserve exact old Vec bodies and iterator types.
For Owned operations use separately admitted replacement helpers. Do not add a
generic IntoIterator that can remove the charge or alter Plain collect reuse.

## First-unit scope and verification

A representation-only all-Plain change can stand alone without account
placeholders, but it is not an account/reservation prerequisite. Shipping an
unused account plus Owned variant merely for later work leaves a dead
production mechanism and fails to exercise the real lifecycle. Prefer the
narrow public Point output integration now: it is a complete, honest allocation
and retention boundary and requires no generic whole-renderer refactor.

Proof still owed in real host tests:
- actual public nonempty Point output owner, source/mapped coordinate equality;
- every endpoint-map failure/cancel/reserve refusal drops destination before
  charge, without source-policy admission claims;
- output after request/controller lifetime and during later tight-cap request;
- concurrent final output drops, shell final retirement, exact capacity charges;
- full 26 frozen legacy native bodies unchanged, with actual Plain lane and no
  account/Box initialization;
- account included in every real residency/prediction path without work refunds.

The probes are layout/destruction evidence only. They do not replace host
admission, renderer pressure, allocation-failure or concurrency qualification.
No production edits, Cargo/native-media runs, fixture generation or Git writes
were performed by this reviewer.
