Parent accepted both focused proof gaps. Keep roots unchanged while the current
native matrix finishes, then strengthen only point_suppression_tests.rs:
literal shell/payload remainders, full six units, exact per-phase prefixes and
zero Storage units on endpoint-map failure. Earlier runtime passes exercised
the weaker assertions. Final stronger library proof remains owed; no production
fix or repeat of unchanged integration binaries is implied.
