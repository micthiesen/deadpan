# Final narrow review addendum

No new implementation correctness finding. Module
9006971844cd67be6f2a2bb3ba9f5bb251fb11dad1373d72fea747007b61b218 differs from
the previously reviewed module only by moving Storage spend immediately before
the Box allocation. Full payload admission still precedes Vec allocation.
Storage-work refusal now destroys the populated pending Vec before its charge.

The new complete-native regression is real: it verifies fixture SHA
3d6338e4e4b0f5617647ab6e0fa4d80bf8882a87c87a55efe306002c3011dbdc,
reconstructs captured_body_with_point over all 744 literal frozen request rows,
and compares the complete resulting Value. current_body invokes real scenario
for each request; pair retains complete actual new results and receipts.
The rewritten top-level capture schema/checkpoint/scope fields reproduce the
historical capture wrapper. Removed fields are only variant/source identity.
No PCM, mask, capacity, work, residency, typed error, accepted prefix or nested
receipt field is stripped or normalized by this new regression.

The integrated two cache tests still exercise actual WAV-backed Original cache
identity, warm rejection/recovery and publication rejection/recovery with held
public Point output. Integration is present. No full Main
original_inputs_tests.rs copy was made.

Two missing assertions weaken the new focused test claims:

1. After constructor failure or disposed result, the native tests observe
   positive live_frames as base and set quota to that observation. This does
   not by itself prove payload cleanup: leaked payload can be included in the
   observed base. Assert that the remaining initialized account equals
   point_suppression::shell_frames(), rather than accepting any positive value,
   in the work-refusal loop and failed endpoint-map test.

2. The new receipt test reconciles total accepted receipt units with the actual
   ledger delta and completed/failed status for every cutoff. That proves
   reconciliation, but not literal phase ordering. It would still pass if
   Storage were moved early again. For this exact two-range, fresh-account
   case, pin full six units and the prefix sequence:
   Account, Vector, Residency, Range, Range, Storage.
   Equivalently assert the corresponding per-field counts at each cutoff.
   At minimum assert accepted_storage_allocation_units==0 for the actual
   endpoint-map failure.

These are focused proof gaps, not observed runtime leaks or incorrect billing.
The source's ownership/drop protocol remains sound. Parent-reported runtime
passes were not independently executed by this reviewer; the current full
native matrix remains the parent's verification responsibility.

This directory pins/copies the four reviewed owned files from both roots and
pins the scoped helpers/frozen body used to inspect the complete regression.
No root edits, Cargo, native execution, fixture changes or Git operations.
