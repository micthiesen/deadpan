#![forbid(unsafe_code)]
#![allow(dead_code)]
use std::{
    alloc::Layout,
    mem::{align_of,size_of},
    ops::Range,
    sync::{Arc, atomic::{AtomicU64,AtomicUsize,Ordering}},
};

#[repr(C)]
struct AccountData { live_frames: AtomicU64 }
// This is a layout calculation, never a raw Arc allocation or pointer cast.
#[repr(C)]
struct AccountShellLayout {
    strong: AtomicUsize,
    weak: AtomicUsize,
    data: AccountData,
}
struct Handle { inner: Option<Arc<AccountData>> }
impl Handle {
    #[inline(never)]
    fn initialize_shape_probe() -> Self {
        Self {inner:Some(Arc::new(AccountData {
            live_frames:AtomicU64::new(account_shell_frames())
        }))}
    }
}
impl Drop for Handle {
    fn drop(&mut self) {
        if let Some(arc)=self.inner.take() {
            if let Some(data)=Arc::into_inner(arc) {
                // The Arc shell is already deallocated; the counter now lives
                // only in this stack value.
                let before=data.live_frames.fetch_sub(account_shell_frames(),Ordering::Relaxed);
                assert_eq!(before,account_shell_frames());
            }
        }
    }
}
fn account_shell_frames()->u64 {
    u64::try_from(Layout::new::<AccountShellLayout>().size()).unwrap().div_ceil(8)
}
struct Charge { handle:Handle, frames:u64 }
struct Storage<T> {ranges:Vec<Range<T>>,ticket:Charge}
struct StorageOptionalCharge<T> {ranges:Vec<Range<T>>,ticket:Option<Charge>}
struct Owned<T> {boxed:Option<Box<Storage<T>>>}
struct OwnedPrepared<T> {boxed:Option<Box<Option<Storage<T>>>>}
struct OwnedOptionalTicket<T> {boxed:Option<Box<StorageOptionalCharge<T>>>}
enum Mask<T> {Plain(Vec<Range<T>>),Owned(Owned<T>)}
enum MaskPrepared<T> {Plain(Vec<Range<T>>),Owned(OwnedPrepared<T>)}
enum MaskOptionalTicket<T> {Plain(Vec<Range<T>>),Owned(OwnedOptionalTicket<T>)}
const _: () = {
    assert!(size_of::<AccountData>()==8);
    assert!(size_of::<AccountShellLayout>()==24);
    assert!(size_of::<Handle>()==8);
    assert!(size_of::<Charge>()==16);
    assert!(size_of::<Mask<i64>>()==24);
    assert!(size_of::<MaskPrepared<i64>>()==24);
    assert!(size_of::<MaskOptionalTicket<i64>>()==24);
};
fn main() {
    macro_rules! layout { ($t:ty) => {
        println!("{} size={} align={}",stringify!($t),size_of::<$t>(),align_of::<$t>());
    }}
    layout!(AccountData);layout!(AccountShellLayout);layout!(Handle);
    layout!(Charge);layout!(Option<Charge>);
    layout!(Storage<i64>);layout!(Option<Storage<i64>>);
    layout!(StorageOptionalCharge<i64>);
    layout!(Mask<i64>);layout!(MaskPrepared<i64>);layout!(MaskOptionalTicket<i64>);
    drop(Handle::initialize_shape_probe());
}
