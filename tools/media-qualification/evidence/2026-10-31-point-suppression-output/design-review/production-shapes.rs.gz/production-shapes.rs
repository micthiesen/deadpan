pub struct AssetId(Arc<str>);
pub struct AudioSample(pub i64);
pub struct SignalSample(pub i64);
pub(crate) type Dependencies = BTreeMap<AssetId, [u8; 32]>;
struct LegacyReadBlock {
    start: AudioSample,
    samples: Vec<[f32; 2]>,
    // Complete for this block, even if this read already observed the asset or
    // obtained its samples from an admitted preparation cache entry.
    dependencies: Dependencies,
    // Maximum recursive preparation depth below this read's entry depth.
    relative_depth: usize,
    suppressed: Vec<Range<AudioSample>>,
    exhausted: Vec<Range<AudioSample>>,
}
struct ProposedReadBlock {
    start: AudioSample,
    samples: Vec<[f32; 2]>,
    // Complete for this block, even if this read already observed the asset or
    // obtained its samples from an admitted preparation cache entry.
    dependencies: Dependencies,
    // Maximum recursive preparation depth below this read's entry depth.
    relative_depth: usize,
    suppressed: Mask<AudioSample>,
    exhausted: Vec<Range<AudioSample>>,
}
struct LegacySignalBlock {
    samples: Vec<[f32; 2]>,
    dependencies: Dependencies,
    suppressed: Vec<Range<SignalSample>>,
    // Retained with cached PCM so reuse at a deeper caller is re-admitted.
    relative_depth: usize,
}
struct ProposedSignalBlock {
    samples: Vec<[f32; 2]>,
    dependencies: Dependencies,
    suppressed: Mask<SignalSample>,
    // Retained with cached PCM so reuse at a deeper caller is re-admitted.
    relative_depth: usize,
}
