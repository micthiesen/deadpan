; ModuleID = 'layout_probe.3d4b7dd556b46567-cgu.0'
source_filename = "layout_probe.3d4b7dd556b46567-cgu.0"
target datalayout = "e-m:o-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-n32:64-S128-Fn32"
target triple = "arm64-apple-macosx11.0.0"

%"core::fmt::rt::Argument<'_>" = type { %"core::fmt::rt::ArgumentType<'_>" }
%"core::fmt::rt::ArgumentType<'_>" = type { ptr, [1 x i64] }
%"core::ops::range::Range<AudioSample>" = type { i64, i64 }

@alloc_26a51afc4914d9aad979fc6b86f30741 = private unnamed_addr constant [74 x i8] c"/tmp/deadpan-point-policy-output-design-review-2026-10-31/layout-probe.rs\00", align 1
@alloc_bde030761eab71afc037d38a38c38d46 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_26a51afc4914d9aad979fc6b86f30741, [16 x i8] c"I\00\00\00\00\00\00\00\16\00\00\00\1F\00\00\00" }>, align 8
@vtable.0 = private unnamed_addr constant <{ [24 x i8], ptr, ptr, ptr }> <{ [24 x i8] c"\00\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00", ptr @_RNSNvYNCINvNtCsa9BKTri5B3M_3std2rt10lang_startuE0INtNtNtCsgtPOCBgevO_4core3ops8function6FnOnceuE9call_once6vtableCs5ggOHDaYt9z_12layout_probe, ptr @_RNCINvNtCsa9BKTri5B3M_3std2rt10lang_startuE0Cs5ggOHDaYt9z_12layout_probe, ptr @_RNCINvNtCsa9BKTri5B3M_3std2rt10lang_startuE0Cs5ggOHDaYt9z_12layout_probe }>, align 8
@alloc_2e8a8255ac1e4854557f85ee639aaab0 = private unnamed_addr constant [77 x i8] c"/rustc/8bab26f4f68e0e26f0bb7960be334d5b520ea452/library/alloc/src/vec/mod.rs\00", align 1
@alloc_09d0336a64f3c3999c7f6c0a13f00bae = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_2e8a8255ac1e4854557f85ee639aaab0, [16 x i8] c"L\00\00\00\00\00\00\00\AF\04\00\00\09\00\00\00" }>, align 8
@alloc_575e3e9e87bf5bff8fd0764fe2792fb6 = private unnamed_addr constant [79 x i8] c"/rustc/8bab26f4f68e0e26f0bb7960be334d5b520ea452/library/core/src/ptr/unique.rs\00", align 1
@alloc_d59c3b01578993e4397b7dc92b88b8dd = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_575e3e9e87bf5bff8fd0764fe2792fb6, [16 x i8] c"N\00\00\00\00\00\00\00X\00\00\00$\00\00\00" }>, align 8
@alloc_b1a1c27c6d41023e30ee48eec611ccbe = private unnamed_addr constant [8 x i8] c"\18\00\00\00\00\00\00\00", align 8
@alloc_a30fbd7ee764311b5438e9cf554fd24e = private unnamed_addr constant [8 x i8] c"\08\00\00\00\00\00\00\00", align 8
@alloc_9f19d303bb3853d42ba0d138ef9ef4d3 = private unnamed_addr constant [43 x i8] c"\1DVec<Range<AudioSample>> size=\C0\07 align=\C0\01\0A\00", align 1
@alloc_4fb46cb07e5178099a6b84464b3b903d = private unnamed_addr constant [37 x i8] c"\17Mask<AudioSample> size=\C0\07 align=\C0\01\0A\00", align 1
@alloc_6a05004c5f69d0e521e3f36abd3957a3 = private unnamed_addr constant [8 x i8] c"(\00\00\00\00\00\00\00", align 8
@alloc_92c7f7eb65650f16fcb6bdf544af9ad9 = private unnamed_addr constant [44 x i8] c"\1EMaskStorage<AudioSample> size=\C0\07 align=\C0\01\0A\00", align 1
@alloc_87930ff84f26c4dc0d3a344636709737 = private unnamed_addr constant [8 x i8] c"\10\00\00\00\00\00\00\00", align 8
@alloc_eb0ed900cbd40804efef2743d4d27838 = private unnamed_addr constant [31 x i8] c"\11OwnedCharge size=\C0\07 align=\C0\01\0A\00", align 1
@alloc_be0cf8af63cd2974ea5f03dc4db922d4 = private unnamed_addr constant [42 x i8] c"\1COwnedMask<AudioSample> size=\C0\07 align=\C0\01\0A\00", align 1
@alloc_859c6556eb1a98008f60aff4e8b40432 = private unnamed_addr constant [38 x i8] c"\18Mask<SignalSample> size=\C0\07 align=\C0\01\0A\00", align 1
@alloc_dec37d155f9ccfe245243e7958243af4 = private unnamed_addr constant [8 x i8] c"p\00\00\00\00\00\00\00", align 8
@alloc_920b38cc3fa11cb4e7cf5d661e1e881f = private unnamed_addr constant [30 x i8] c"\10LegacyRead size=\C0\07 align=\C0\01\0A\00", align 1
@alloc_f652c65efd922dbc20af566e4791c42c = private unnamed_addr constant [32 x i8] c"\12ProposedRead size=\C0\07 align=\C0\01\0A\00", align 1
@alloc_a508c046562d0b0ff8e58bc558b81a8a = private unnamed_addr constant [35 x i8] c"\15LegacyReadBlock size=\C0\07 align=\C0\01\0A\00", align 1
@alloc_d48d5321be02b7f4fa13e8cbe7dec595 = private unnamed_addr constant [37 x i8] c"\17ProposedReadBlock size=\C0\07 align=\C0\01\0A\00", align 1
@alloc_45c5b8d9661cc4b9c8e770e6215d84b9 = private unnamed_addr constant [8 x i8] c"P\00\00\00\00\00\00\00", align 8
@alloc_3559fccbd92f94e00f10c87e755d3a60 = private unnamed_addr constant [37 x i8] c"\17LegacySignalBlock size=\C0\07 align=\C0\01\0A\00", align 1
@alloc_bd98adaaf97fec0749116a590a5cad0c = private unnamed_addr constant [39 x i8] c"\19ProposedSignalBlock size=\C0\07 align=\C0\01\0A\00", align 1
@alloc_1faaba7c4c011edfc8833a88ffd8dff5 = private unnamed_addr constant [8 x i8] c"H\00\00\00\00\00\00\00", align 8
@alloc_53973d2fe29b4adba8bb7390b5678745 = private unnamed_addr constant [8 x i8] zeroinitializer, align 8
@alloc_21650c376254a4bd195df1c3eab4eb42 = private unnamed_addr constant [8 x i8] c"h\00\00\00\00\00\00\00", align 8
@alloc_28b4525213e621d91e2b40299762a7fc = private unnamed_addr constant [8 x i8] c"0\00\00\00\00\00\00\00", align 8
@alloc_0cba1a6c244db3fe5049cd85fee661d6 = private unnamed_addr constant [94 x i8] c"\1Alegacy read offsets start=\C0\09 samples=\C0\0E dependencies=\C0\07 depth=\C0\0C suppressed=\C0\0B exhausted=\C0\01\0A\00", align 1
@alloc_075a430f08414687328efd2f9b044a26 = private unnamed_addr constant [91 x i8] c"\17new read offsets start=\C0\09 samples=\C0\0E dependencies=\C0\07 depth=\C0\0C suppressed=\C0\0B exhausted=\C0\01\0A\00", align 1
@alloc_4e14e83ded74d5e8fc48e682727f5111 = private unnamed_addr constant [74 x i8] c"\1Elegacy signal offsets samples=\C0\0E dependencies=\C0\0C suppressed=\C0\07 depth=\C0\01\0A\00", align 1
@alloc_2def2677f68019b00d48075d2b6f0eb7 = private unnamed_addr constant [71 x i8] c"\1Bnew signal offsets samples=\C0\0E dependencies=\C0\0C suppressed=\C0\07 depth=\C0\01\0A\00", align 1
@alloc_b755494a2e20c213ca2de9520fa65445 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_26a51afc4914d9aad979fc6b86f30741, [16 x i8] c"I\00\00\00\00\00\00\00>\00\00\00P\00\00\00" }>, align 8
@alloc_35ed1ddd5bcb0b3e67c4fb3f3f092de9 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_26a51afc4914d9aad979fc6b86f30741, [16 x i8] c"I\00\00\00\00\00\00\00A\00\00\00\16\00\00\00" }>, align 8
@alloc_29f3d0da34f44a1b2e1ac3f11dfc75b8 = private unnamed_addr constant [81 x i8] c"/rustc/8bab26f4f68e0e26f0bb7960be334d5b520ea452/library/core/src/ptr/non_null.rs\00", align 1
@alloc_8d5a0ee98b8cdf2f5afa900e7e86c059 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_29f3d0da34f44a1b2e1ac3f11dfc75b8, [16 x i8] c"P\00\00\00\00\00\00\00\A7\05\00\00\12\00\00\00" }>, align 8
@anon.730379407b893e35326a836a497d6d4b.0 = private unnamed_addr constant <{ [8 x i8], [8 x i8] }> <{ [8 x i8] zeroinitializer, [8 x i8] undef }>, align 8
@alloc_5ff1c8aa34f46974b9857da735e490e2 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_29f3d0da34f44a1b2e1ac3f11dfc75b8, [16 x i8] c"P\00\00\00\00\00\00\00\0D\01\00\00\1B\00\00\00" }>, align 8
@alloc_929e9b2e7b7429614ca4fc017efff666 = private unnamed_addr constant [41 x i8] c"there is no such thing as a relaxed fence", align 1
@alloc_313179c4ebce8162b6e6b899782d13de = private unnamed_addr constant [80 x i8] c"/rustc/8bab26f4f68e0e26f0bb7960be334d5b520ea452/library/core/src/sync/atomic.rs\00", align 1
@alloc_51bc672182609c8619102955545c9936 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_313179c4ebce8162b6e6b899782d13de, [16 x i8] c"O\00\00\00\00\00\00\00'\11\00\00\18\00\00\00" }>, align 8
@alloc_0625062a5eee489a7813ee965a38d15a = private unnamed_addr constant [198 x i8] c"unsafe precondition(s) violated: Alignment::new_unchecked requires a power of two\0A\0AThis indicates a bug in the program. This Undefined Behavior check is optional, and cannot be relied on for safety.", align 1
@alloc_8cf3531fd3c828ab298b686071a40c17 = private unnamed_addr constant [259 x i8] c"unsafe precondition(s) violated: Layout::from_size_alignment_unchecked requires that the rounded-up allocation size does not exceed isize::MAX\0A\0AThis indicates a bug in the program. This Undefined Behavior check is optional, and cannot be relied on for safety.", align 1
@alloc_560a59ed819b9d9a5841f6e731c4c8e5 = private unnamed_addr constant [210 x i8] c"unsafe precondition(s) violated: NonNull::new_unchecked requires that the pointer is non-null\0A\0AThis indicates a bug in the program. This Undefined Behavior check is optional, and cannot be relied on for safety.", align 1
@alloc_82a99021b1306c9239507412b95c0e74 = private unnamed_addr constant [205 x i8] c"unsafe precondition(s) violated: Vec::from_raw_parts_in requires that length <= capacity\0A\0AThis indicates a bug in the program. This Undefined Behavior check is optional, and cannot be relied on for safety.", align 1
@alloc_3535064d29b1815564de3b8811671deb = private unnamed_addr constant [82 x i8] c"/rustc/8bab26f4f68e0e26f0bb7960be334d5b520ea452/library/core/src/mem/alignment.rs\00", align 1
@alloc_94ac603a76bcb1c7cd512525db170514 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_3535064d29b1815564de3b8811671deb, [16 x i8] c"Q\00\00\00\00\00\00\00\7F\00\00\00\12\00\00\00" }>, align 8
@alloc_9bba1da638456c1bff660b3ae7593675 = private unnamed_addr constant [81 x i8] c"/rustc/8bab26f4f68e0e26f0bb7960be334d5b520ea452/library/core/src/alloc/layout.rs\00", align 1
@alloc_632d33230a33b678beb09f7f8dd3a0db = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_9bba1da638456c1bff660b3ae7593675, [16 x i8] c"P\00\00\00\00\00\00\00\01\01\00\00\12\00\00\00" }>, align 8

; layout_probe::unbox::<layout_probe::MaskStorage<layout_probe::AudioSample>>
; Function Attrs: noinline uwtable
define internal void @_RINvCs5ggOHDaYt9z_12layout_probe5unboxINtB2_11MaskStorageNtB2_11AudioSampleEEB2_(ptr sret([40 x i8]) align 8 %_0, ptr align 8 %0) unnamed_addr #0 {
start:
  %b = alloca [8 x i8], align 8
  store ptr %0, ptr %b, align 8
  %_4 = load ptr, ptr %b, align 8
  %_6 = ptrtoint ptr %_4 to i64
  %_8 = and i64 %_6, 7
  %_9 = icmp eq i64 %_8, 0
  br i1 %_9, label %bb2, label %panic

bb2:                                              ; preds = %start
  %_11 = ptrtoint ptr %_4 to i64
  %_13 = icmp eq i64 %_11, 0
  %_14 = and i1 %_13, true
  %_15 = xor i1 %_14, true
  br i1 %_15, label %bb3, label %panic1

panic:                                            ; preds = %start
; call core::panicking::panic_misaligned_pointer_dereference
  call void @_RNvNtCsgtPOCBgevO_4core9panicking36panic_misaligned_pointer_dereference(i64 8, i64 %_6, ptr align 8 @alloc_bde030761eab71afc037d38a38c38d46) #15
  unreachable

bb3:                                              ; preds = %bb2
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_4, i64 40, i1 false)
; call <alloc::boxed::Box<layout_probe::MaskStorage<layout_probe::AudioSample>> as core::ops::drop::Drop>::drop
  call void @_RNvXs8_NtCslJsSqIQKwiA_5alloc5boxedINtB5_3BoxINtCs5ggOHDaYt9z_12layout_probe11MaskStorageNtBK_11AudioSampleEENtNtNtCsgtPOCBgevO_4core3ops4drop4Drop4dropBK_(ptr align 8 %b)
  ret void

panic1:                                           ; preds = %bb2
; call core::panicking::panic_null_pointer_dereference
  call void @_RNvNtCsgtPOCBgevO_4core9panicking30panic_null_pointer_dereference(ptr align 8 @alloc_bde030761eab71afc037d38a38c38d46) #15
  unreachable
}

; <core::fmt::rt::Argument>::new_display::<usize>
; Function Attrs: inlinehint uwtable
define internal void @_RINvMNtNtCsgtPOCBgevO_4core3fmt2rtNtB3_8Argument11new_displayjECs5ggOHDaYt9z_12layout_probe(ptr sret([16 x i8]) align 8 %_0, ptr align 8 %x) unnamed_addr #1 {
start:
  %_2 = alloca [16 x i8], align 8
  store ptr %x, ptr %_2, align 8
  %0 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr @_RNvXsi_NtNtNtCsgtPOCBgevO_4core3fmt3num3impjNtB9_7Display3fmt, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 16, i1 false)
  ret void
}

; <core::fmt::Arguments>::new::<30, 2>
; Function Attrs: inlinehint uwtable
define internal { ptr, ptr } @_RINvMs2_NtCsgtPOCBgevO_4core3fmtNtB6_9Arguments3newKj1e_Kj2_ECs5ggOHDaYt9z_12layout_probe(ptr %template, ptr align 8 %args) unnamed_addr #1 {
start:
  %0 = insertvalue { ptr, ptr } poison, ptr %template, 0
  %1 = insertvalue { ptr, ptr } %0, ptr %args, 1
  ret { ptr, ptr } %1
}

; <core::fmt::Arguments>::new::<31, 2>
; Function Attrs: inlinehint uwtable
define internal { ptr, ptr } @_RINvMs2_NtCsgtPOCBgevO_4core3fmtNtB6_9Arguments3newKj1f_Kj2_ECs5ggOHDaYt9z_12layout_probe(ptr %template, ptr align 8 %args) unnamed_addr #1 {
start:
  %0 = insertvalue { ptr, ptr } poison, ptr %template, 0
  %1 = insertvalue { ptr, ptr } %0, ptr %args, 1
  ret { ptr, ptr } %1
}

; <core::fmt::Arguments>::new::<32, 2>
; Function Attrs: inlinehint uwtable
define internal { ptr, ptr } @_RINvMs2_NtCsgtPOCBgevO_4core3fmtNtB6_9Arguments3newKj20_Kj2_ECs5ggOHDaYt9z_12layout_probe(ptr %template, ptr align 8 %args) unnamed_addr #1 {
start:
  %0 = insertvalue { ptr, ptr } poison, ptr %template, 0
  %1 = insertvalue { ptr, ptr } %0, ptr %args, 1
  ret { ptr, ptr } %1
}

; <core::fmt::Arguments>::new::<35, 2>
; Function Attrs: inlinehint uwtable
define internal { ptr, ptr } @_RINvMs2_NtCsgtPOCBgevO_4core3fmtNtB6_9Arguments3newKj23_Kj2_ECs5ggOHDaYt9z_12layout_probe(ptr %template, ptr align 8 %args) unnamed_addr #1 {
start:
  %0 = insertvalue { ptr, ptr } poison, ptr %template, 0
  %1 = insertvalue { ptr, ptr } %0, ptr %args, 1
  ret { ptr, ptr } %1
}

; <core::fmt::Arguments>::new::<37, 2>
; Function Attrs: inlinehint uwtable
define internal { ptr, ptr } @_RINvMs2_NtCsgtPOCBgevO_4core3fmtNtB6_9Arguments3newKj25_Kj2_ECs5ggOHDaYt9z_12layout_probe(ptr %template, ptr align 8 %args) unnamed_addr #1 {
start:
  %0 = insertvalue { ptr, ptr } poison, ptr %template, 0
  %1 = insertvalue { ptr, ptr } %0, ptr %args, 1
  ret { ptr, ptr } %1
}

; <core::fmt::Arguments>::new::<38, 2>
; Function Attrs: inlinehint uwtable
define internal { ptr, ptr } @_RINvMs2_NtCsgtPOCBgevO_4core3fmtNtB6_9Arguments3newKj26_Kj2_ECs5ggOHDaYt9z_12layout_probe(ptr %template, ptr align 8 %args) unnamed_addr #1 {
start:
  %0 = insertvalue { ptr, ptr } poison, ptr %template, 0
  %1 = insertvalue { ptr, ptr } %0, ptr %args, 1
  ret { ptr, ptr } %1
}

; <core::fmt::Arguments>::new::<39, 2>
; Function Attrs: inlinehint uwtable
define internal { ptr, ptr } @_RINvMs2_NtCsgtPOCBgevO_4core3fmtNtB6_9Arguments3newKj27_Kj2_ECs5ggOHDaYt9z_12layout_probe(ptr %template, ptr align 8 %args) unnamed_addr #1 {
start:
  %0 = insertvalue { ptr, ptr } poison, ptr %template, 0
  %1 = insertvalue { ptr, ptr } %0, ptr %args, 1
  ret { ptr, ptr } %1
}

; <core::fmt::Arguments>::new::<42, 2>
; Function Attrs: inlinehint uwtable
define internal { ptr, ptr } @_RINvMs2_NtCsgtPOCBgevO_4core3fmtNtB6_9Arguments3newKj2a_Kj2_ECs5ggOHDaYt9z_12layout_probe(ptr %template, ptr align 8 %args) unnamed_addr #1 {
start:
  %0 = insertvalue { ptr, ptr } poison, ptr %template, 0
  %1 = insertvalue { ptr, ptr } %0, ptr %args, 1
  ret { ptr, ptr } %1
}

; <core::fmt::Arguments>::new::<43, 2>
; Function Attrs: inlinehint uwtable
define internal { ptr, ptr } @_RINvMs2_NtCsgtPOCBgevO_4core3fmtNtB6_9Arguments3newKj2b_Kj2_ECs5ggOHDaYt9z_12layout_probe(ptr %template, ptr align 8 %args) unnamed_addr #1 {
start:
  %0 = insertvalue { ptr, ptr } poison, ptr %template, 0
  %1 = insertvalue { ptr, ptr } %0, ptr %args, 1
  ret { ptr, ptr } %1
}

; <core::fmt::Arguments>::new::<44, 2>
; Function Attrs: inlinehint uwtable
define internal { ptr, ptr } @_RINvMs2_NtCsgtPOCBgevO_4core3fmtNtB6_9Arguments3newKj2c_Kj2_ECs5ggOHDaYt9z_12layout_probe(ptr %template, ptr align 8 %args) unnamed_addr #1 {
start:
  %0 = insertvalue { ptr, ptr } poison, ptr %template, 0
  %1 = insertvalue { ptr, ptr } %0, ptr %args, 1
  ret { ptr, ptr } %1
}

; <core::fmt::Arguments>::new::<71, 4>
; Function Attrs: inlinehint uwtable
define internal { ptr, ptr } @_RINvMs2_NtCsgtPOCBgevO_4core3fmtNtB6_9Arguments3newKj47_Kj4_ECs5ggOHDaYt9z_12layout_probe(ptr %template, ptr align 8 %args) unnamed_addr #1 {
start:
  %0 = insertvalue { ptr, ptr } poison, ptr %template, 0
  %1 = insertvalue { ptr, ptr } %0, ptr %args, 1
  ret { ptr, ptr } %1
}

; <core::fmt::Arguments>::new::<74, 4>
; Function Attrs: inlinehint uwtable
define internal { ptr, ptr } @_RINvMs2_NtCsgtPOCBgevO_4core3fmtNtB6_9Arguments3newKj4a_Kj4_ECs5ggOHDaYt9z_12layout_probe(ptr %template, ptr align 8 %args) unnamed_addr #1 {
start:
  %0 = insertvalue { ptr, ptr } poison, ptr %template, 0
  %1 = insertvalue { ptr, ptr } %0, ptr %args, 1
  ret { ptr, ptr } %1
}

; <core::fmt::Arguments>::new::<91, 6>
; Function Attrs: inlinehint uwtable
define internal { ptr, ptr } @_RINvMs2_NtCsgtPOCBgevO_4core3fmtNtB6_9Arguments3newKj5b_Kj6_ECs5ggOHDaYt9z_12layout_probe(ptr %template, ptr align 8 %args) unnamed_addr #1 {
start:
  %0 = insertvalue { ptr, ptr } poison, ptr %template, 0
  %1 = insertvalue { ptr, ptr } %0, ptr %args, 1
  ret { ptr, ptr } %1
}

; <core::fmt::Arguments>::new::<94, 6>
; Function Attrs: inlinehint uwtable
define internal { ptr, ptr } @_RINvMs2_NtCsgtPOCBgevO_4core3fmtNtB6_9Arguments3newKj5e_Kj6_ECs5ggOHDaYt9z_12layout_probe(ptr %template, ptr align 8 %args) unnamed_addr #1 {
start:
  %0 = insertvalue { ptr, ptr } poison, ptr %template, 0
  %1 = insertvalue { ptr, ptr } %0, ptr %args, 1
  ret { ptr, ptr } %1
}

; std::rt::lang_start::<()>
; Function Attrs: uwtable
define hidden i64 @_RINvNtCsa9BKTri5B3M_3std2rt10lang_startuECs5ggOHDaYt9z_12layout_probe(ptr %main, i64 %argc, ptr %argv, i8 %sigpipe) unnamed_addr #2 {
start:
  %_7 = alloca [8 x i8], align 8
  store ptr %main, ptr %_7, align 8
; call std::rt::lang_start_internal
  %_0 = call i64 @_RNvNtCsa9BKTri5B3M_3std2rt19lang_start_internal(ptr %_7, ptr align 8 @vtable.0, i64 %argc, ptr %argv, i8 %sigpipe)
  ret i64 %_0
}

; core::mem::drop::<layout_probe::Mask<layout_probe::AudioSample>>
; Function Attrs: inlinehint uwtable
define internal void @_RINvNtCsgtPOCBgevO_4core3mem4dropINtCs5ggOHDaYt9z_12layout_probe4MaskNtBy_11AudioSampleEEBy_(ptr align 8 %_x) unnamed_addr #1 {
start:
; call core::ptr::drop_glue::<layout_probe::Mask<layout_probe::AudioSample>>
  call void @_RINvNtCsgtPOCBgevO_4core3ptr9drop_glueINtCs5ggOHDaYt9z_12layout_probe4MaskNtBD_11AudioSampleEEBD_(ptr align 8 %_x)
  ret void
}

; core::mem::drop::<alloc::vec::Vec<core::ops::range::Range<layout_probe::AudioSample>>>
; Function Attrs: inlinehint uwtable
define internal void @_RINvNtCsgtPOCBgevO_4core3mem4dropINtNtCslJsSqIQKwiA_5alloc3vec3VecINtNtNtB4_3ops5range5RangeNtCs5ggOHDaYt9z_12layout_probe11AudioSampleEEEB1u_(ptr align 8 %_x) unnamed_addr #1 {
start:
; call core::ptr::drop_glue::<alloc::vec::Vec<core::ops::range::Range<layout_probe::AudioSample>>>
  call void @_RINvNtCsgtPOCBgevO_4core3ptr9drop_glueINtNtCslJsSqIQKwiA_5alloc3vec3VecINtNtNtB4_3ops5range5RangeNtCs5ggOHDaYt9z_12layout_probe11AudioSampleEEEB1z_(ptr align 8 %_x)
  ret void
}

; core::mem::drop::<layout_probe::OwnedCharge>
; Function Attrs: inlinehint uwtable
define internal void @_RINvNtCsgtPOCBgevO_4core3mem4dropNtCs5ggOHDaYt9z_12layout_probe11OwnedChargeEBx_(ptr %0, i64 %1) unnamed_addr #1 {
start:
  %_x = alloca [16 x i8], align 8
  store ptr %0, ptr %_x, align 8
  %2 = getelementptr inbounds i8, ptr %_x, i64 8
  store i64 %1, ptr %2, align 8
; call core::ptr::drop_glue::<layout_probe::OwnedCharge>
  call void @_RINvNtCsgtPOCBgevO_4core3ptr9drop_glueNtCs5ggOHDaYt9z_12layout_probe11OwnedChargeEBC_(ptr align 8 %_x)
  ret void
}

; core::ptr::drop_glue::<layout_probe::MaskStorage<layout_probe::AudioSample>>
; Function Attrs: uwtable
define internal void @_RINvNtCsgtPOCBgevO_4core3ptr9drop_glueINtCs5ggOHDaYt9z_12layout_probe11MaskStorageNtBD_11AudioSampleEEBD_(ptr align 8 %_1) unnamed_addr #2 personality ptr @rust_eh_personality {
start:
  %0 = alloca [16 x i8], align 8
; invoke core::ptr::drop_glue::<alloc::vec::Vec<core::ops::range::Range<layout_probe::AudioSample>>>
  invoke void @_RINvNtCsgtPOCBgevO_4core3ptr9drop_glueINtNtCslJsSqIQKwiA_5alloc3vec3VecINtNtNtB4_3ops5range5RangeNtCs5ggOHDaYt9z_12layout_probe11AudioSampleEEEB1z_(ptr align 8 %_1)
          to label %bb4 unwind label %cleanup

bb3:                                              ; preds = %cleanup
  %1 = getelementptr inbounds i8, ptr %_1, i64 24
; invoke core::ptr::drop_glue::<layout_probe::OwnedCharge>
  invoke void @_RINvNtCsgtPOCBgevO_4core3ptr9drop_glueNtCs5ggOHDaYt9z_12layout_probe11OwnedChargeEBC_(ptr align 8 %1) #16
          to label %bb1 unwind label %terminate

cleanup:                                          ; preds = %start
  %2 = landingpad { ptr, i32 }
          cleanup
  %3 = extractvalue { ptr, i32 } %2, 0
  %4 = extractvalue { ptr, i32 } %2, 1
  store ptr %3, ptr %0, align 8
  %5 = getelementptr inbounds i8, ptr %0, i64 8
  store i32 %4, ptr %5, align 8
  br label %bb3

bb4:                                              ; preds = %start
  %6 = getelementptr inbounds i8, ptr %_1, i64 24
; call core::ptr::drop_glue::<layout_probe::OwnedCharge>
  call void @_RINvNtCsgtPOCBgevO_4core3ptr9drop_glueNtCs5ggOHDaYt9z_12layout_probe11OwnedChargeEBC_(ptr align 8 %6)
  ret void

terminate:                                        ; preds = %bb3
  %7 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_in_cleanup
  call void @_RNvNtCsgtPOCBgevO_4core9panicking16panic_in_cleanup() #17
  unreachable

bb1:                                              ; preds = %bb3
  %8 = load ptr, ptr %0, align 8
  %9 = getelementptr inbounds i8, ptr %0, i64 8
  %10 = load i32, ptr %9, align 8
  %11 = insertvalue { ptr, i32 } poison, ptr %8, 0
  %12 = insertvalue { ptr, i32 } %11, i32 %10, 1
  resume { ptr, i32 } %12
}

; core::ptr::drop_glue::<layout_probe::Mask<layout_probe::AudioSample>>
; Function Attrs: uwtable
define internal void @_RINvNtCsgtPOCBgevO_4core3ptr9drop_glueINtCs5ggOHDaYt9z_12layout_probe4MaskNtBD_11AudioSampleEEBD_(ptr align 8 %_1) unnamed_addr #2 {
start:
  %0 = load i64, ptr %_1, align 8
  %1 = icmp eq i64 %0, -1
  %_2 = select i1 %1, i64 1, i64 0
  %2 = icmp eq i64 %_2, 0
  br i1 %2, label %bb2, label %bb3

bb2:                                              ; preds = %start
; call core::ptr::drop_glue::<alloc::vec::Vec<core::ops::range::Range<layout_probe::AudioSample>>>
  call void @_RINvNtCsgtPOCBgevO_4core3ptr9drop_glueINtNtCslJsSqIQKwiA_5alloc3vec3VecINtNtNtB4_3ops5range5RangeNtCs5ggOHDaYt9z_12layout_probe11AudioSampleEEEB1z_(ptr align 8 %_1)
  br label %bb1

bb3:                                              ; preds = %start
  %3 = getelementptr inbounds i8, ptr %_1, i64 8
; call core::ptr::drop_glue::<layout_probe::OwnedMask<layout_probe::AudioSample>>
  call void @_RINvNtCsgtPOCBgevO_4core3ptr9drop_glueINtCs5ggOHDaYt9z_12layout_probe9OwnedMaskNtBD_11AudioSampleEEBD_(ptr align 8 %3)
  br label %bb1

bb1:                                              ; preds = %bb3, %bb2
  ret void
}

; core::ptr::drop_glue::<layout_probe::OwnedMask<layout_probe::AudioSample>>
; Function Attrs: uwtable
define internal void @_RINvNtCsgtPOCBgevO_4core3ptr9drop_glueINtCs5ggOHDaYt9z_12layout_probe9OwnedMaskNtBD_11AudioSampleEEBD_(ptr align 8 %_1) unnamed_addr #2 personality ptr @rust_eh_personality {
start:
  %0 = alloca [16 x i8], align 8
; invoke <layout_probe::OwnedMask<layout_probe::AudioSample> as core::ops::drop::Drop>::drop
  invoke void @_RNvXCs5ggOHDaYt9z_12layout_probeINtB2_9OwnedMaskNtB2_11AudioSampleENtNtNtCsgtPOCBgevO_4core3ops4drop4Drop4dropB2_(ptr align 8 %_1)
          to label %bb4 unwind label %cleanup

bb3:                                              ; preds = %cleanup
; invoke core::ptr::drop_glue::<core::option::Option<alloc::boxed::Box<layout_probe::MaskStorage<layout_probe::AudioSample>>>>
  invoke void @_RINvNtCsgtPOCBgevO_4core3ptr9drop_glueINtNtB4_6option6OptionINtNtCslJsSqIQKwiA_5alloc5boxed3BoxINtCs5ggOHDaYt9z_12layout_probe11MaskStorageNtB1y_11AudioSampleEEEEB1y_(ptr align 8 %_1) #16
          to label %bb1 unwind label %terminate

cleanup:                                          ; preds = %start
  %1 = landingpad { ptr, i32 }
          cleanup
  %2 = extractvalue { ptr, i32 } %1, 0
  %3 = extractvalue { ptr, i32 } %1, 1
  store ptr %2, ptr %0, align 8
  %4 = getelementptr inbounds i8, ptr %0, i64 8
  store i32 %3, ptr %4, align 8
  br label %bb3

bb4:                                              ; preds = %start
; call core::ptr::drop_glue::<core::option::Option<alloc::boxed::Box<layout_probe::MaskStorage<layout_probe::AudioSample>>>>
  call void @_RINvNtCsgtPOCBgevO_4core3ptr9drop_glueINtNtB4_6option6OptionINtNtCslJsSqIQKwiA_5alloc5boxed3BoxINtCs5ggOHDaYt9z_12layout_probe11MaskStorageNtB1y_11AudioSampleEEEEB1y_(ptr align 8 %_1)
  ret void

terminate:                                        ; preds = %bb3
  %5 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_in_cleanup
  call void @_RNvNtCsgtPOCBgevO_4core9panicking16panic_in_cleanup() #17
  unreachable

bb1:                                              ; preds = %bb3
  %6 = load ptr, ptr %0, align 8
  %7 = getelementptr inbounds i8, ptr %0, i64 8
  %8 = load i32, ptr %7, align 8
  %9 = insertvalue { ptr, i32 } poison, ptr %6, 0
  %10 = insertvalue { ptr, i32 } %9, i32 %8, 1
  resume { ptr, i32 } %10
}

; core::ptr::drop_glue::<core::option::Option<alloc::boxed::Box<layout_probe::MaskStorage<layout_probe::AudioSample>>>>
; Function Attrs: uwtable
define internal void @_RINvNtCsgtPOCBgevO_4core3ptr9drop_glueINtNtB4_6option6OptionINtNtCslJsSqIQKwiA_5alloc5boxed3BoxINtCs5ggOHDaYt9z_12layout_probe11MaskStorageNtB1y_11AudioSampleEEEEB1y_(ptr align 8 %_1) unnamed_addr #2 {
start:
  %0 = load ptr, ptr %_1, align 8
  %1 = ptrtoint ptr %0 to i64
  %2 = icmp eq i64 %1, 0
  %_2 = select i1 %2, i64 0, i64 1
  %3 = icmp eq i64 %_2, 0
  br i1 %3, label %bb1, label %bb2

bb1:                                              ; preds = %bb2, %start
  ret void

bb2:                                              ; preds = %start
; call core::ptr::drop_glue::<alloc::boxed::Box<layout_probe::MaskStorage<layout_probe::AudioSample>>>
  call void @_RINvNtCsgtPOCBgevO_4core3ptr9drop_glueINtNtCslJsSqIQKwiA_5alloc5boxed3BoxINtCs5ggOHDaYt9z_12layout_probe11MaskStorageNtB1c_11AudioSampleEEEB1c_(ptr align 8 %_1)
  br label %bb1
}

; core::ptr::drop_glue::<alloc::vec::Vec<core::ops::range::Range<layout_probe::AudioSample>>>
; Function Attrs: uwtable
define internal void @_RINvNtCsgtPOCBgevO_4core3ptr9drop_glueINtNtCslJsSqIQKwiA_5alloc3vec3VecINtNtNtB4_3ops5range5RangeNtCs5ggOHDaYt9z_12layout_probe11AudioSampleEEEB1z_(ptr align 8 %_1) unnamed_addr #2 personality ptr @rust_eh_personality {
start:
  %0 = alloca [16 x i8], align 8
; invoke <alloc::vec::Vec<core::ops::range::Range<layout_probe::AudioSample>> as core::ops::drop::Drop>::drop
  invoke void @_RNvXso_NtCslJsSqIQKwiA_5alloc3vecINtB5_3VecINtNtNtCsgtPOCBgevO_4core3ops5range5RangeNtCs5ggOHDaYt9z_12layout_probe11AudioSampleEENtNtBK_4drop4Drop4dropB1m_(ptr align 8 %_1)
          to label %bb4 unwind label %cleanup

bb3:                                              ; preds = %cleanup
; invoke core::ptr::drop_glue::<alloc::raw_vec::RawVec<core::ops::range::Range<layout_probe::AudioSample>>>
  invoke void @_RINvNtCsgtPOCBgevO_4core3ptr9drop_glueINtNtCslJsSqIQKwiA_5alloc7raw_vec6RawVecINtNtNtB4_3ops5range5RangeNtCs5ggOHDaYt9z_12layout_probe11AudioSampleEEEB1G_(ptr align 8 %_1) #16
          to label %bb1 unwind label %terminate

cleanup:                                          ; preds = %start
  %1 = landingpad { ptr, i32 }
          cleanup
  %2 = extractvalue { ptr, i32 } %1, 0
  %3 = extractvalue { ptr, i32 } %1, 1
  store ptr %2, ptr %0, align 8
  %4 = getelementptr inbounds i8, ptr %0, i64 8
  store i32 %3, ptr %4, align 8
  br label %bb3

bb4:                                              ; preds = %start
; call core::ptr::drop_glue::<alloc::raw_vec::RawVec<core::ops::range::Range<layout_probe::AudioSample>>>
  call void @_RINvNtCsgtPOCBgevO_4core3ptr9drop_glueINtNtCslJsSqIQKwiA_5alloc7raw_vec6RawVecINtNtNtB4_3ops5range5RangeNtCs5ggOHDaYt9z_12layout_probe11AudioSampleEEEB1G_(ptr align 8 %_1)
  ret void

terminate:                                        ; preds = %bb3
  %5 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_in_cleanup
  call void @_RNvNtCsgtPOCBgevO_4core9panicking16panic_in_cleanup() #17
  unreachable

bb1:                                              ; preds = %bb3
  %6 = load ptr, ptr %0, align 8
  %7 = getelementptr inbounds i8, ptr %0, i64 8
  %8 = load i32, ptr %7, align 8
  %9 = insertvalue { ptr, i32 } poison, ptr %6, 0
  %10 = insertvalue { ptr, i32 } %9, i32 %8, 1
  resume { ptr, i32 } %10
}

; core::ptr::drop_glue::<alloc::sync::Arc<layout_probe::Account>>
; Function Attrs: uwtable
define internal void @_RINvNtCsgtPOCBgevO_4core3ptr9drop_glueINtNtCslJsSqIQKwiA_5alloc4sync3ArcNtCs5ggOHDaYt9z_12layout_probe7AccountEEB1a_(ptr align 8 %_1) unnamed_addr #2 {
start:
; call <alloc::sync::Arc<layout_probe::Account> as core::ops::drop::Drop>::drop
  call void @_RNvXsD_NtCslJsSqIQKwiA_5alloc4syncINtB5_3ArcNtCs5ggOHDaYt9z_12layout_probe7AccountENtNtNtCsgtPOCBgevO_4core3ops4drop4Drop4dropBI_(ptr align 8 %_1)
  ret void
}

; core::ptr::drop_glue::<alloc::sync::Weak<layout_probe::Account, &alloc::alloc::Global>>
; Function Attrs: uwtable
define internal void @_RINvNtCsgtPOCBgevO_4core3ptr9drop_glueINtNtCslJsSqIQKwiA_5alloc4sync4WeakNtCs5ggOHDaYt9z_12layout_probe7AccountRNtNtBF_5alloc6GlobalEEB1b_(ptr align 8 %_1) unnamed_addr #2 {
start:
; call <alloc::sync::Weak<layout_probe::Account, &alloc::alloc::Global> as core::ops::drop::Drop>::drop
  call void @_RNvXsN_NtCslJsSqIQKwiA_5alloc4syncINtB5_4WeakNtCs5ggOHDaYt9z_12layout_probe7AccountRNtNtB7_5alloc6GlobalENtNtNtCsgtPOCBgevO_4core3ops4drop4Drop4dropBJ_(ptr align 8 %_1)
  ret void
}

; core::ptr::drop_glue::<alloc::boxed::Box<layout_probe::MaskStorage<layout_probe::AudioSample>>>
; Function Attrs: uwtable
define internal void @_RINvNtCsgtPOCBgevO_4core3ptr9drop_glueINtNtCslJsSqIQKwiA_5alloc5boxed3BoxINtCs5ggOHDaYt9z_12layout_probe11MaskStorageNtB1c_11AudioSampleEEEB1c_(ptr align 8 %_1) unnamed_addr #2 personality ptr @rust_eh_personality {
start:
  %0 = alloca [16 x i8], align 8
  %_6 = load ptr, ptr %_1, align 8
; invoke core::ptr::drop_glue::<layout_probe::MaskStorage<layout_probe::AudioSample>>
  invoke void @_RINvNtCsgtPOCBgevO_4core3ptr9drop_glueINtCs5ggOHDaYt9z_12layout_probe11MaskStorageNtBD_11AudioSampleEEBD_(ptr align 8 %_6)
          to label %bb3 unwind label %cleanup

bb4:                                              ; preds = %cleanup
; invoke <alloc::boxed::Box<layout_probe::MaskStorage<layout_probe::AudioSample>> as core::ops::drop::Drop>::drop
  invoke void @_RNvXs8_NtCslJsSqIQKwiA_5alloc5boxedINtB5_3BoxINtCs5ggOHDaYt9z_12layout_probe11MaskStorageNtBK_11AudioSampleEENtNtNtCsgtPOCBgevO_4core3ops4drop4Drop4dropBK_(ptr align 8 %_1) #16
          to label %bb1 unwind label %terminate

cleanup:                                          ; preds = %start
  %1 = landingpad { ptr, i32 }
          cleanup
  %2 = extractvalue { ptr, i32 } %1, 0
  %3 = extractvalue { ptr, i32 } %1, 1
  store ptr %2, ptr %0, align 8
  %4 = getelementptr inbounds i8, ptr %0, i64 8
  store i32 %3, ptr %4, align 8
  br label %bb4

bb3:                                              ; preds = %start
; call <alloc::boxed::Box<layout_probe::MaskStorage<layout_probe::AudioSample>> as core::ops::drop::Drop>::drop
  call void @_RNvXs8_NtCslJsSqIQKwiA_5alloc5boxedINtB5_3BoxINtCs5ggOHDaYt9z_12layout_probe11MaskStorageNtBK_11AudioSampleEENtNtNtCsgtPOCBgevO_4core3ops4drop4Drop4dropBK_(ptr align 8 %_1)
  ret void

terminate:                                        ; preds = %bb4
  %5 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_in_cleanup
  call void @_RNvNtCsgtPOCBgevO_4core9panicking16panic_in_cleanup() #17
  unreachable

bb1:                                              ; preds = %bb4
  %6 = load ptr, ptr %0, align 8
  %7 = getelementptr inbounds i8, ptr %0, i64 8
  %8 = load i32, ptr %7, align 8
  %9 = insertvalue { ptr, i32 } poison, ptr %6, 0
  %10 = insertvalue { ptr, i32 } %9, i32 %8, 1
  resume { ptr, i32 } %10
}

; core::ptr::drop_glue::<alloc::raw_vec::RawVec<core::ops::range::Range<layout_probe::AudioSample>>>
; Function Attrs: uwtable
define internal void @_RINvNtCsgtPOCBgevO_4core3ptr9drop_glueINtNtCslJsSqIQKwiA_5alloc7raw_vec6RawVecINtNtNtB4_3ops5range5RangeNtCs5ggOHDaYt9z_12layout_probe11AudioSampleEEEB1G_(ptr align 8 %_1) unnamed_addr #2 {
start:
; call <alloc::raw_vec::RawVec<core::ops::range::Range<layout_probe::AudioSample>> as core::ops::drop::Drop>::drop
  call void @_RNvXs1_NtCslJsSqIQKwiA_5alloc7raw_vecINtB5_6RawVecINtNtNtCsgtPOCBgevO_4core3ops5range5RangeNtCs5ggOHDaYt9z_12layout_probe11AudioSampleEENtNtBR_4drop4Drop4dropB1t_(ptr align 8 %_1)
  ret void
}

; core::ptr::drop_glue::<layout_probe::OwnedCharge>
; Function Attrs: uwtable
define internal void @_RINvNtCsgtPOCBgevO_4core3ptr9drop_glueNtCs5ggOHDaYt9z_12layout_probe11OwnedChargeEBC_(ptr align 8 %_1) unnamed_addr #2 {
start:
; call core::ptr::drop_glue::<alloc::sync::Arc<layout_probe::Account>>
  call void @_RINvNtCsgtPOCBgevO_4core3ptr9drop_glueINtNtCslJsSqIQKwiA_5alloc4sync3ArcNtCs5ggOHDaYt9z_12layout_probe7AccountEEB1a_(ptr align 8 %_1)
  ret void
}

; std::sys::backtrace::__rust_begin_short_backtrace::<fn(), ()>
; Function Attrs: noinline uwtable
define internal void @_RINvNtNtCsa9BKTri5B3M_3std3sys9backtrace28___rust_begin_short_backtraceFEuuECs5ggOHDaYt9z_12layout_probe(ptr %f) unnamed_addr #0 {
start:
; call <fn() as core::ops::function::FnOnce<()>>::call_once
  call void @_RNvYFEuINtNtNtCsgtPOCBgevO_4core3ops8function6FnOnceuE9call_onceCs5ggOHDaYt9z_12layout_probe(ptr %f)
  call void asm sideeffect "", "~{memory}"(), !srcloc !3
  ret void
}

; std::rt::lang_start::<()>::{closure#0}
; Function Attrs: inlinehint uwtable
define internal i32 @_RNCINvNtCsa9BKTri5B3M_3std2rt10lang_startuE0Cs5ggOHDaYt9z_12layout_probe(ptr align 8 %_1) unnamed_addr #1 {
start:
  %_4 = load ptr, ptr %_1, align 8
; call std::sys::backtrace::__rust_begin_short_backtrace::<fn(), ()>
  call void @_RINvNtNtCsa9BKTri5B3M_3std3sys9backtrace28___rust_begin_short_backtraceFEuuECs5ggOHDaYt9z_12layout_probe(ptr %_4)
; call <() as std::process::Termination>::report
  %self = call i8 @_RNvXsZ_NtCsa9BKTri5B3M_3std7processuNtB5_11Termination6reportCs5ggOHDaYt9z_12layout_probe()
  %_0 = zext i8 %self to i32
  ret i32 %_0
}

; <std::rt::lang_start<()>::{closure#0} as core::ops::function::FnOnce<()>>::call_once::{shim:vtable#0}
; Function Attrs: inlinehint uwtable
define internal i32 @_RNSNvYNCINvNtCsa9BKTri5B3M_3std2rt10lang_startuE0INtNtNtCsgtPOCBgevO_4core3ops8function6FnOnceuE9call_once6vtableCs5ggOHDaYt9z_12layout_probe(ptr %_1) unnamed_addr #1 {
start:
  %_2 = alloca [0 x i8], align 1
  %0 = load ptr, ptr %_1, align 8
; call <std::rt::lang_start<()>::{closure#0} as core::ops::function::FnOnce<()>>::call_once
  %_0 = call i32 @_RNvYNCINvNtCsa9BKTri5B3M_3std2rt10lang_startuE0INtNtNtCsgtPOCBgevO_4core3ops8function6FnOnceuE9call_onceCs5ggOHDaYt9z_12layout_probe(ptr %0)
  ret i32 %_0
}

; layout_probe::main
; Function Attrs: uwtable
define hidden void @_RNvCs5ggOHDaYt9z_12layout_probe4main() unnamed_addr #2 personality ptr @rust_eh_personality {
start:
  %0 = alloca [16 x i8], align 8
  %capacity.i23 = alloca [8 x i8], align 8
  %capacity.i = alloca [8 x i8], align 8
  %1 = alloca [24 x i8], align 8
  %2 = alloca [16 x i8], align 8
  %3 = alloca [8 x i8], align 8
  %4 = alloca [8 x i8], align 8
  %_252 = alloca [1 x i8], align 1
  %_203 = alloca [24 x i8], align 8
  %_202 = alloca [24 x i8], align 8
  %_193 = alloca [24 x i8], align 8
  %_192 = alloca [40 x i8], align 8
  %mask = alloca [24 x i8], align 8
  %_187 = alloca [8 x i8], align 8
  %_186 = alloca [8 x i8], align 8
  %account = alloca [8 x i8], align 8
  %_182 = alloca [16 x i8], align 8
  %_181 = alloca [16 x i8], align 8
  %_180 = alloca [16 x i8], align 8
  %_179 = alloca [16 x i8], align 8
  %args19 = alloca [64 x i8], align 8
  %args18 = alloca [32 x i8], align 8
  %_168 = alloca [16 x i8], align 8
  %_167 = alloca [16 x i8], align 8
  %_166 = alloca [16 x i8], align 8
  %_165 = alloca [16 x i8], align 8
  %args17 = alloca [64 x i8], align 8
  %args16 = alloca [32 x i8], align 8
  %_154 = alloca [16 x i8], align 8
  %_153 = alloca [16 x i8], align 8
  %_152 = alloca [16 x i8], align 8
  %_151 = alloca [16 x i8], align 8
  %_150 = alloca [16 x i8], align 8
  %_149 = alloca [16 x i8], align 8
  %args15 = alloca [96 x i8], align 8
  %args14 = alloca [48 x i8], align 8
  %_136 = alloca [16 x i8], align 8
  %_135 = alloca [16 x i8], align 8
  %_134 = alloca [16 x i8], align 8
  %_133 = alloca [16 x i8], align 8
  %_132 = alloca [16 x i8], align 8
  %_131 = alloca [16 x i8], align 8
  %args13 = alloca [96 x i8], align 8
  %args12 = alloca [48 x i8], align 8
  %_118 = alloca [16 x i8], align 8
  %_117 = alloca [16 x i8], align 8
  %args11 = alloca [32 x i8], align 8
  %_108 = alloca [16 x i8], align 8
  %_107 = alloca [16 x i8], align 8
  %args10 = alloca [32 x i8], align 8
  %_98 = alloca [16 x i8], align 8
  %_97 = alloca [16 x i8], align 8
  %args9 = alloca [32 x i8], align 8
  %_88 = alloca [16 x i8], align 8
  %_87 = alloca [16 x i8], align 8
  %args8 = alloca [32 x i8], align 8
  %_78 = alloca [16 x i8], align 8
  %_77 = alloca [16 x i8], align 8
  %args7 = alloca [32 x i8], align 8
  %_68 = alloca [16 x i8], align 8
  %_67 = alloca [16 x i8], align 8
  %args6 = alloca [32 x i8], align 8
  %_58 = alloca [16 x i8], align 8
  %_57 = alloca [16 x i8], align 8
  %args5 = alloca [32 x i8], align 8
  %_48 = alloca [16 x i8], align 8
  %_47 = alloca [16 x i8], align 8
  %args4 = alloca [32 x i8], align 8
  %_38 = alloca [16 x i8], align 8
  %_37 = alloca [16 x i8], align 8
  %args3 = alloca [32 x i8], align 8
  %_28 = alloca [16 x i8], align 8
  %_27 = alloca [16 x i8], align 8
  %args2 = alloca [32 x i8], align 8
  %_18 = alloca [16 x i8], align 8
  %_17 = alloca [16 x i8], align 8
  %args1 = alloca [32 x i8], align 8
  %_8 = alloca [16 x i8], align 8
  %_7 = alloca [16 x i8], align 8
  %args = alloca [32 x i8], align 8
  store i8 0, ptr %_252, align 1
; call <core::fmt::rt::Argument>::new_display::<usize>
  call void @_RINvMNtNtCsgtPOCBgevO_4core3fmt2rtNtB3_8Argument11new_displayjECs5ggOHDaYt9z_12layout_probe(ptr sret([16 x i8]) align 8 %_7, ptr align 8 @alloc_b1a1c27c6d41023e30ee48eec611ccbe)
; call <core::fmt::rt::Argument>::new_display::<usize>
  call void @_RINvMNtNtCsgtPOCBgevO_4core3fmt2rtNtB3_8Argument11new_displayjECs5ggOHDaYt9z_12layout_probe(ptr sret([16 x i8]) align 8 %_8, ptr align 8 @alloc_a30fbd7ee764311b5438e9cf554fd24e)
  %5 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %5, ptr align 8 %_7, i64 16, i1 false)
  %6 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %6, ptr align 8 %_8, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<43, 2>
  %7 = call { ptr, ptr } @_RINvMs2_NtCsgtPOCBgevO_4core3fmtNtB6_9Arguments3newKj2b_Kj2_ECs5ggOHDaYt9z_12layout_probe(ptr @alloc_9f19d303bb3853d42ba0d138ef9ef4d3, ptr align 8 %args)
  %_2.0 = extractvalue { ptr, ptr } %7, 0
  %_2.1 = extractvalue { ptr, ptr } %7, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsa9BKTri5B3M_3std2io5stdio6__print(ptr %_2.0, ptr %_2.1)
; call <core::fmt::rt::Argument>::new_display::<usize>
  call void @_RINvMNtNtCsgtPOCBgevO_4core3fmt2rtNtB3_8Argument11new_displayjECs5ggOHDaYt9z_12layout_probe(ptr sret([16 x i8]) align 8 %_17, ptr align 8 @alloc_b1a1c27c6d41023e30ee48eec611ccbe)
; call <core::fmt::rt::Argument>::new_display::<usize>
  call void @_RINvMNtNtCsgtPOCBgevO_4core3fmt2rtNtB3_8Argument11new_displayjECs5ggOHDaYt9z_12layout_probe(ptr sret([16 x i8]) align 8 %_18, ptr align 8 @alloc_a30fbd7ee764311b5438e9cf554fd24e)
  %8 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args1, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %8, ptr align 8 %_17, i64 16, i1 false)
  %9 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args1, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %9, ptr align 8 %_18, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<37, 2>
  %10 = call { ptr, ptr } @_RINvMs2_NtCsgtPOCBgevO_4core3fmtNtB6_9Arguments3newKj25_Kj2_ECs5ggOHDaYt9z_12layout_probe(ptr @alloc_4fb46cb07e5178099a6b84464b3b903d, ptr align 8 %args1)
  %_12.0 = extractvalue { ptr, ptr } %10, 0
  %_12.1 = extractvalue { ptr, ptr } %10, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsa9BKTri5B3M_3std2io5stdio6__print(ptr %_12.0, ptr %_12.1)
; call <core::fmt::rt::Argument>::new_display::<usize>
  call void @_RINvMNtNtCsgtPOCBgevO_4core3fmt2rtNtB3_8Argument11new_displayjECs5ggOHDaYt9z_12layout_probe(ptr sret([16 x i8]) align 8 %_27, ptr align 8 @alloc_6a05004c5f69d0e521e3f36abd3957a3)
; call <core::fmt::rt::Argument>::new_display::<usize>
  call void @_RINvMNtNtCsgtPOCBgevO_4core3fmt2rtNtB3_8Argument11new_displayjECs5ggOHDaYt9z_12layout_probe(ptr sret([16 x i8]) align 8 %_28, ptr align 8 @alloc_a30fbd7ee764311b5438e9cf554fd24e)
  %11 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args2, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %11, ptr align 8 %_27, i64 16, i1 false)
  %12 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args2, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %12, ptr align 8 %_28, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<44, 2>
  %13 = call { ptr, ptr } @_RINvMs2_NtCsgtPOCBgevO_4core3fmtNtB6_9Arguments3newKj2c_Kj2_ECs5ggOHDaYt9z_12layout_probe(ptr @alloc_92c7f7eb65650f16fcb6bdf544af9ad9, ptr align 8 %args2)
  %_22.0 = extractvalue { ptr, ptr } %13, 0
  %_22.1 = extractvalue { ptr, ptr } %13, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsa9BKTri5B3M_3std2io5stdio6__print(ptr %_22.0, ptr %_22.1)
; call <core::fmt::rt::Argument>::new_display::<usize>
  call void @_RINvMNtNtCsgtPOCBgevO_4core3fmt2rtNtB3_8Argument11new_displayjECs5ggOHDaYt9z_12layout_probe(ptr sret([16 x i8]) align 8 %_37, ptr align 8 @alloc_87930ff84f26c4dc0d3a344636709737)
; call <core::fmt::rt::Argument>::new_display::<usize>
  call void @_RINvMNtNtCsgtPOCBgevO_4core3fmt2rtNtB3_8Argument11new_displayjECs5ggOHDaYt9z_12layout_probe(ptr sret([16 x i8]) align 8 %_38, ptr align 8 @alloc_a30fbd7ee764311b5438e9cf554fd24e)
  %14 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args3, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %14, ptr align 8 %_37, i64 16, i1 false)
  %15 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args3, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %15, ptr align 8 %_38, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<31, 2>
  %16 = call { ptr, ptr } @_RINvMs2_NtCsgtPOCBgevO_4core3fmtNtB6_9Arguments3newKj1f_Kj2_ECs5ggOHDaYt9z_12layout_probe(ptr @alloc_eb0ed900cbd40804efef2743d4d27838, ptr align 8 %args3)
  %_32.0 = extractvalue { ptr, ptr } %16, 0
  %_32.1 = extractvalue { ptr, ptr } %16, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsa9BKTri5B3M_3std2io5stdio6__print(ptr %_32.0, ptr %_32.1)
; call <core::fmt::rt::Argument>::new_display::<usize>
  call void @_RINvMNtNtCsgtPOCBgevO_4core3fmt2rtNtB3_8Argument11new_displayjECs5ggOHDaYt9z_12layout_probe(ptr sret([16 x i8]) align 8 %_47, ptr align 8 @alloc_a30fbd7ee764311b5438e9cf554fd24e)
; call <core::fmt::rt::Argument>::new_display::<usize>
  call void @_RINvMNtNtCsgtPOCBgevO_4core3fmt2rtNtB3_8Argument11new_displayjECs5ggOHDaYt9z_12layout_probe(ptr sret([16 x i8]) align 8 %_48, ptr align 8 @alloc_a30fbd7ee764311b5438e9cf554fd24e)
  %17 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args4, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %17, ptr align 8 %_47, i64 16, i1 false)
  %18 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args4, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %18, ptr align 8 %_48, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<42, 2>
  %19 = call { ptr, ptr } @_RINvMs2_NtCsgtPOCBgevO_4core3fmtNtB6_9Arguments3newKj2a_Kj2_ECs5ggOHDaYt9z_12layout_probe(ptr @alloc_be0cf8af63cd2974ea5f03dc4db922d4, ptr align 8 %args4)
  %_42.0 = extractvalue { ptr, ptr } %19, 0
  %_42.1 = extractvalue { ptr, ptr } %19, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsa9BKTri5B3M_3std2io5stdio6__print(ptr %_42.0, ptr %_42.1)
; call <core::fmt::rt::Argument>::new_display::<usize>
  call void @_RINvMNtNtCsgtPOCBgevO_4core3fmt2rtNtB3_8Argument11new_displayjECs5ggOHDaYt9z_12layout_probe(ptr sret([16 x i8]) align 8 %_57, ptr align 8 @alloc_b1a1c27c6d41023e30ee48eec611ccbe)
; call <core::fmt::rt::Argument>::new_display::<usize>
  call void @_RINvMNtNtCsgtPOCBgevO_4core3fmt2rtNtB3_8Argument11new_displayjECs5ggOHDaYt9z_12layout_probe(ptr sret([16 x i8]) align 8 %_58, ptr align 8 @alloc_a30fbd7ee764311b5438e9cf554fd24e)
  %20 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args5, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %20, ptr align 8 %_57, i64 16, i1 false)
  %21 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args5, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %21, ptr align 8 %_58, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<38, 2>
  %22 = call { ptr, ptr } @_RINvMs2_NtCsgtPOCBgevO_4core3fmtNtB6_9Arguments3newKj26_Kj2_ECs5ggOHDaYt9z_12layout_probe(ptr @alloc_859c6556eb1a98008f60aff4e8b40432, ptr align 8 %args5)
  %_52.0 = extractvalue { ptr, ptr } %22, 0
  %_52.1 = extractvalue { ptr, ptr } %22, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsa9BKTri5B3M_3std2io5stdio6__print(ptr %_52.0, ptr %_52.1)
; call <core::fmt::rt::Argument>::new_display::<usize>
  call void @_RINvMNtNtCsgtPOCBgevO_4core3fmt2rtNtB3_8Argument11new_displayjECs5ggOHDaYt9z_12layout_probe(ptr sret([16 x i8]) align 8 %_67, ptr align 8 @alloc_dec37d155f9ccfe245243e7958243af4)
; call <core::fmt::rt::Argument>::new_display::<usize>
  call void @_RINvMNtNtCsgtPOCBgevO_4core3fmt2rtNtB3_8Argument11new_displayjECs5ggOHDaYt9z_12layout_probe(ptr sret([16 x i8]) align 8 %_68, ptr align 8 @alloc_a30fbd7ee764311b5438e9cf554fd24e)
  %23 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args6, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %23, ptr align 8 %_67, i64 16, i1 false)
  %24 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args6, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %24, ptr align 8 %_68, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<30, 2>
  %25 = call { ptr, ptr } @_RINvMs2_NtCsgtPOCBgevO_4core3fmtNtB6_9Arguments3newKj1e_Kj2_ECs5ggOHDaYt9z_12layout_probe(ptr @alloc_920b38cc3fa11cb4e7cf5d661e1e881f, ptr align 8 %args6)
  %_62.0 = extractvalue { ptr, ptr } %25, 0
  %_62.1 = extractvalue { ptr, ptr } %25, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsa9BKTri5B3M_3std2io5stdio6__print(ptr %_62.0, ptr %_62.1)
; call <core::fmt::rt::Argument>::new_display::<usize>
  call void @_RINvMNtNtCsgtPOCBgevO_4core3fmt2rtNtB3_8Argument11new_displayjECs5ggOHDaYt9z_12layout_probe(ptr sret([16 x i8]) align 8 %_77, ptr align 8 @alloc_dec37d155f9ccfe245243e7958243af4)
; call <core::fmt::rt::Argument>::new_display::<usize>
  call void @_RINvMNtNtCsgtPOCBgevO_4core3fmt2rtNtB3_8Argument11new_displayjECs5ggOHDaYt9z_12layout_probe(ptr sret([16 x i8]) align 8 %_78, ptr align 8 @alloc_a30fbd7ee764311b5438e9cf554fd24e)
  %26 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args7, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %26, ptr align 8 %_77, i64 16, i1 false)
  %27 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args7, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %27, ptr align 8 %_78, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<32, 2>
  %28 = call { ptr, ptr } @_RINvMs2_NtCsgtPOCBgevO_4core3fmtNtB6_9Arguments3newKj20_Kj2_ECs5ggOHDaYt9z_12layout_probe(ptr @alloc_f652c65efd922dbc20af566e4791c42c, ptr align 8 %args7)
  %_72.0 = extractvalue { ptr, ptr } %28, 0
  %_72.1 = extractvalue { ptr, ptr } %28, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsa9BKTri5B3M_3std2io5stdio6__print(ptr %_72.0, ptr %_72.1)
; call <core::fmt::rt::Argument>::new_display::<usize>
  call void @_RINvMNtNtCsgtPOCBgevO_4core3fmt2rtNtB3_8Argument11new_displayjECs5ggOHDaYt9z_12layout_probe(ptr sret([16 x i8]) align 8 %_87, ptr align 8 @alloc_dec37d155f9ccfe245243e7958243af4)
; call <core::fmt::rt::Argument>::new_display::<usize>
  call void @_RINvMNtNtCsgtPOCBgevO_4core3fmt2rtNtB3_8Argument11new_displayjECs5ggOHDaYt9z_12layout_probe(ptr sret([16 x i8]) align 8 %_88, ptr align 8 @alloc_a30fbd7ee764311b5438e9cf554fd24e)
  %29 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args8, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %29, ptr align 8 %_87, i64 16, i1 false)
  %30 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args8, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %30, ptr align 8 %_88, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<35, 2>
  %31 = call { ptr, ptr } @_RINvMs2_NtCsgtPOCBgevO_4core3fmtNtB6_9Arguments3newKj23_Kj2_ECs5ggOHDaYt9z_12layout_probe(ptr @alloc_a508c046562d0b0ff8e58bc558b81a8a, ptr align 8 %args8)
  %_82.0 = extractvalue { ptr, ptr } %31, 0
  %_82.1 = extractvalue { ptr, ptr } %31, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsa9BKTri5B3M_3std2io5stdio6__print(ptr %_82.0, ptr %_82.1)
; call <core::fmt::rt::Argument>::new_display::<usize>
  call void @_RINvMNtNtCsgtPOCBgevO_4core3fmt2rtNtB3_8Argument11new_displayjECs5ggOHDaYt9z_12layout_probe(ptr sret([16 x i8]) align 8 %_97, ptr align 8 @alloc_dec37d155f9ccfe245243e7958243af4)
; call <core::fmt::rt::Argument>::new_display::<usize>
  call void @_RINvMNtNtCsgtPOCBgevO_4core3fmt2rtNtB3_8Argument11new_displayjECs5ggOHDaYt9z_12layout_probe(ptr sret([16 x i8]) align 8 %_98, ptr align 8 @alloc_a30fbd7ee764311b5438e9cf554fd24e)
  %32 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args9, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %32, ptr align 8 %_97, i64 16, i1 false)
  %33 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args9, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %33, ptr align 8 %_98, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<37, 2>
  %34 = call { ptr, ptr } @_RINvMs2_NtCsgtPOCBgevO_4core3fmtNtB6_9Arguments3newKj25_Kj2_ECs5ggOHDaYt9z_12layout_probe(ptr @alloc_d48d5321be02b7f4fa13e8cbe7dec595, ptr align 8 %args9)
  %_92.0 = extractvalue { ptr, ptr } %34, 0
  %_92.1 = extractvalue { ptr, ptr } %34, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsa9BKTri5B3M_3std2io5stdio6__print(ptr %_92.0, ptr %_92.1)
; call <core::fmt::rt::Argument>::new_display::<usize>
  call void @_RINvMNtNtCsgtPOCBgevO_4core3fmt2rtNtB3_8Argument11new_displayjECs5ggOHDaYt9z_12layout_probe(ptr sret([16 x i8]) align 8 %_107, ptr align 8 @alloc_45c5b8d9661cc4b9c8e770e6215d84b9)
; call <core::fmt::rt::Argument>::new_display::<usize>
  call void @_RINvMNtNtCsgtPOCBgevO_4core3fmt2rtNtB3_8Argument11new_displayjECs5ggOHDaYt9z_12layout_probe(ptr sret([16 x i8]) align 8 %_108, ptr align 8 @alloc_a30fbd7ee764311b5438e9cf554fd24e)
  %35 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args10, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %35, ptr align 8 %_107, i64 16, i1 false)
  %36 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args10, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %36, ptr align 8 %_108, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<37, 2>
  %37 = call { ptr, ptr } @_RINvMs2_NtCsgtPOCBgevO_4core3fmtNtB6_9Arguments3newKj25_Kj2_ECs5ggOHDaYt9z_12layout_probe(ptr @alloc_3559fccbd92f94e00f10c87e755d3a60, ptr align 8 %args10)
  %_102.0 = extractvalue { ptr, ptr } %37, 0
  %_102.1 = extractvalue { ptr, ptr } %37, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsa9BKTri5B3M_3std2io5stdio6__print(ptr %_102.0, ptr %_102.1)
; call <core::fmt::rt::Argument>::new_display::<usize>
  call void @_RINvMNtNtCsgtPOCBgevO_4core3fmt2rtNtB3_8Argument11new_displayjECs5ggOHDaYt9z_12layout_probe(ptr sret([16 x i8]) align 8 %_117, ptr align 8 @alloc_45c5b8d9661cc4b9c8e770e6215d84b9)
; call <core::fmt::rt::Argument>::new_display::<usize>
  call void @_RINvMNtNtCsgtPOCBgevO_4core3fmt2rtNtB3_8Argument11new_displayjECs5ggOHDaYt9z_12layout_probe(ptr sret([16 x i8]) align 8 %_118, ptr align 8 @alloc_a30fbd7ee764311b5438e9cf554fd24e)
  %38 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args11, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %38, ptr align 8 %_117, i64 16, i1 false)
  %39 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args11, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %39, ptr align 8 %_118, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<39, 2>
  %40 = call { ptr, ptr } @_RINvMs2_NtCsgtPOCBgevO_4core3fmtNtB6_9Arguments3newKj27_Kj2_ECs5ggOHDaYt9z_12layout_probe(ptr @alloc_bd98adaaf97fec0749116a590a5cad0c, ptr align 8 %args11)
  %_112.0 = extractvalue { ptr, ptr } %40, 0
  %_112.1 = extractvalue { ptr, ptr } %40, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsa9BKTri5B3M_3std2io5stdio6__print(ptr %_112.0, ptr %_112.1)
  store ptr @alloc_1faaba7c4c011edfc8833a88ffd8dff5, ptr %args12, align 8
  %41 = getelementptr inbounds i8, ptr %args12, i64 8
  store ptr @alloc_53973d2fe29b4adba8bb7390b5678745, ptr %41, align 8
  %42 = getelementptr inbounds i8, ptr %args12, i64 16
  store ptr @alloc_45c5b8d9661cc4b9c8e770e6215d84b9, ptr %42, align 8
  %43 = getelementptr inbounds i8, ptr %args12, i64 24
  store ptr @alloc_21650c376254a4bd195df1c3eab4eb42, ptr %43, align 8
  %44 = getelementptr inbounds i8, ptr %args12, i64 32
  store ptr @alloc_b1a1c27c6d41023e30ee48eec611ccbe, ptr %44, align 8
  %45 = getelementptr inbounds i8, ptr %args12, i64 40
  store ptr @alloc_28b4525213e621d91e2b40299762a7fc, ptr %45, align 8
  %_232 = load ptr, ptr %args12, align 8
; call <core::fmt::rt::Argument>::new_display::<usize>
  call void @_RINvMNtNtCsgtPOCBgevO_4core3fmt2rtNtB3_8Argument11new_displayjECs5ggOHDaYt9z_12layout_probe(ptr sret([16 x i8]) align 8 %_131, ptr align 8 %_232)
  %46 = getelementptr inbounds i8, ptr %args12, i64 8
  %_233 = load ptr, ptr %46, align 8
; call <core::fmt::rt::Argument>::new_display::<usize>
  call void @_RINvMNtNtCsgtPOCBgevO_4core3fmt2rtNtB3_8Argument11new_displayjECs5ggOHDaYt9z_12layout_probe(ptr sret([16 x i8]) align 8 %_132, ptr align 8 %_233)
  %47 = getelementptr inbounds i8, ptr %args12, i64 16
  %_234 = load ptr, ptr %47, align 8
; call <core::fmt::rt::Argument>::new_display::<usize>
  call void @_RINvMNtNtCsgtPOCBgevO_4core3fmt2rtNtB3_8Argument11new_displayjECs5ggOHDaYt9z_12layout_probe(ptr sret([16 x i8]) align 8 %_133, ptr align 8 %_234)
  %48 = getelementptr inbounds i8, ptr %args12, i64 24
  %_235 = load ptr, ptr %48, align 8
; call <core::fmt::rt::Argument>::new_display::<usize>
  call void @_RINvMNtNtCsgtPOCBgevO_4core3fmt2rtNtB3_8Argument11new_displayjECs5ggOHDaYt9z_12layout_probe(ptr sret([16 x i8]) align 8 %_134, ptr align 8 %_235)
  %49 = getelementptr inbounds i8, ptr %args12, i64 32
  %_236 = load ptr, ptr %49, align 8
; call <core::fmt::rt::Argument>::new_display::<usize>
  call void @_RINvMNtNtCsgtPOCBgevO_4core3fmt2rtNtB3_8Argument11new_displayjECs5ggOHDaYt9z_12layout_probe(ptr sret([16 x i8]) align 8 %_135, ptr align 8 %_236)
  %50 = getelementptr inbounds i8, ptr %args12, i64 40
  %_237 = load ptr, ptr %50, align 8
; call <core::fmt::rt::Argument>::new_display::<usize>
  call void @_RINvMNtNtCsgtPOCBgevO_4core3fmt2rtNtB3_8Argument11new_displayjECs5ggOHDaYt9z_12layout_probe(ptr sret([16 x i8]) align 8 %_136, ptr align 8 %_237)
  %51 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args13, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %51, ptr align 8 %_131, i64 16, i1 false)
  %52 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args13, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %52, ptr align 8 %_132, i64 16, i1 false)
  %53 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args13, i64 2
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %53, ptr align 8 %_133, i64 16, i1 false)
  %54 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args13, i64 3
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %54, ptr align 8 %_134, i64 16, i1 false)
  %55 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args13, i64 4
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %55, ptr align 8 %_135, i64 16, i1 false)
  %56 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args13, i64 5
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %56, ptr align 8 %_136, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<94, 6>
  %57 = call { ptr, ptr } @_RINvMs2_NtCsgtPOCBgevO_4core3fmtNtB6_9Arguments3newKj5e_Kj6_ECs5ggOHDaYt9z_12layout_probe(ptr @alloc_0cba1a6c244db3fe5049cd85fee661d6, ptr align 8 %args13)
  %_122.0 = extractvalue { ptr, ptr } %57, 0
  %_122.1 = extractvalue { ptr, ptr } %57, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsa9BKTri5B3M_3std2io5stdio6__print(ptr %_122.0, ptr %_122.1)
  store ptr @alloc_1faaba7c4c011edfc8833a88ffd8dff5, ptr %args14, align 8
  %58 = getelementptr inbounds i8, ptr %args14, i64 8
  store ptr @alloc_53973d2fe29b4adba8bb7390b5678745, ptr %58, align 8
  %59 = getelementptr inbounds i8, ptr %args14, i64 16
  store ptr @alloc_45c5b8d9661cc4b9c8e770e6215d84b9, ptr %59, align 8
  %60 = getelementptr inbounds i8, ptr %args14, i64 24
  store ptr @alloc_21650c376254a4bd195df1c3eab4eb42, ptr %60, align 8
  %61 = getelementptr inbounds i8, ptr %args14, i64 32
  store ptr @alloc_28b4525213e621d91e2b40299762a7fc, ptr %61, align 8
  %62 = getelementptr inbounds i8, ptr %args14, i64 40
  store ptr @alloc_b1a1c27c6d41023e30ee48eec611ccbe, ptr %62, align 8
  %_238 = load ptr, ptr %args14, align 8
; call <core::fmt::rt::Argument>::new_display::<usize>
  call void @_RINvMNtNtCsgtPOCBgevO_4core3fmt2rtNtB3_8Argument11new_displayjECs5ggOHDaYt9z_12layout_probe(ptr sret([16 x i8]) align 8 %_149, ptr align 8 %_238)
  %63 = getelementptr inbounds i8, ptr %args14, i64 8
  %_239 = load ptr, ptr %63, align 8
; call <core::fmt::rt::Argument>::new_display::<usize>
  call void @_RINvMNtNtCsgtPOCBgevO_4core3fmt2rtNtB3_8Argument11new_displayjECs5ggOHDaYt9z_12layout_probe(ptr sret([16 x i8]) align 8 %_150, ptr align 8 %_239)
  %64 = getelementptr inbounds i8, ptr %args14, i64 16
  %_240 = load ptr, ptr %64, align 8
; call <core::fmt::rt::Argument>::new_display::<usize>
  call void @_RINvMNtNtCsgtPOCBgevO_4core3fmt2rtNtB3_8Argument11new_displayjECs5ggOHDaYt9z_12layout_probe(ptr sret([16 x i8]) align 8 %_151, ptr align 8 %_240)
  %65 = getelementptr inbounds i8, ptr %args14, i64 24
  %_241 = load ptr, ptr %65, align 8
; call <core::fmt::rt::Argument>::new_display::<usize>
  call void @_RINvMNtNtCsgtPOCBgevO_4core3fmt2rtNtB3_8Argument11new_displayjECs5ggOHDaYt9z_12layout_probe(ptr sret([16 x i8]) align 8 %_152, ptr align 8 %_241)
  %66 = getelementptr inbounds i8, ptr %args14, i64 32
  %_242 = load ptr, ptr %66, align 8
; call <core::fmt::rt::Argument>::new_display::<usize>
  call void @_RINvMNtNtCsgtPOCBgevO_4core3fmt2rtNtB3_8Argument11new_displayjECs5ggOHDaYt9z_12layout_probe(ptr sret([16 x i8]) align 8 %_153, ptr align 8 %_242)
  %67 = getelementptr inbounds i8, ptr %args14, i64 40
  %_243 = load ptr, ptr %67, align 8
; call <core::fmt::rt::Argument>::new_display::<usize>
  call void @_RINvMNtNtCsgtPOCBgevO_4core3fmt2rtNtB3_8Argument11new_displayjECs5ggOHDaYt9z_12layout_probe(ptr sret([16 x i8]) align 8 %_154, ptr align 8 %_243)
  %68 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args15, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %68, ptr align 8 %_149, i64 16, i1 false)
  %69 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args15, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %69, ptr align 8 %_150, i64 16, i1 false)
  %70 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args15, i64 2
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %70, ptr align 8 %_151, i64 16, i1 false)
  %71 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args15, i64 3
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %71, ptr align 8 %_152, i64 16, i1 false)
  %72 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args15, i64 4
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %72, ptr align 8 %_153, i64 16, i1 false)
  %73 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args15, i64 5
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %73, ptr align 8 %_154, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<91, 6>
  %74 = call { ptr, ptr } @_RINvMs2_NtCsgtPOCBgevO_4core3fmtNtB6_9Arguments3newKj5b_Kj6_ECs5ggOHDaYt9z_12layout_probe(ptr @alloc_075a430f08414687328efd2f9b044a26, ptr align 8 %args15)
  %_140.0 = extractvalue { ptr, ptr } %74, 0
  %_140.1 = extractvalue { ptr, ptr } %74, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsa9BKTri5B3M_3std2io5stdio6__print(ptr %_140.0, ptr %_140.1)
  store ptr @alloc_53973d2fe29b4adba8bb7390b5678745, ptr %args16, align 8
  %75 = getelementptr inbounds i8, ptr %args16, i64 8
  store ptr @alloc_28b4525213e621d91e2b40299762a7fc, ptr %75, align 8
  %76 = getelementptr inbounds i8, ptr %args16, i64 16
  store ptr @alloc_b1a1c27c6d41023e30ee48eec611ccbe, ptr %76, align 8
  %77 = getelementptr inbounds i8, ptr %args16, i64 24
  store ptr @alloc_1faaba7c4c011edfc8833a88ffd8dff5, ptr %77, align 8
  %_244 = load ptr, ptr %args16, align 8
; call <core::fmt::rt::Argument>::new_display::<usize>
  call void @_RINvMNtNtCsgtPOCBgevO_4core3fmt2rtNtB3_8Argument11new_displayjECs5ggOHDaYt9z_12layout_probe(ptr sret([16 x i8]) align 8 %_165, ptr align 8 %_244)
  %78 = getelementptr inbounds i8, ptr %args16, i64 8
  %_245 = load ptr, ptr %78, align 8
; call <core::fmt::rt::Argument>::new_display::<usize>
  call void @_RINvMNtNtCsgtPOCBgevO_4core3fmt2rtNtB3_8Argument11new_displayjECs5ggOHDaYt9z_12layout_probe(ptr sret([16 x i8]) align 8 %_166, ptr align 8 %_245)
  %79 = getelementptr inbounds i8, ptr %args16, i64 16
  %_246 = load ptr, ptr %79, align 8
; call <core::fmt::rt::Argument>::new_display::<usize>
  call void @_RINvMNtNtCsgtPOCBgevO_4core3fmt2rtNtB3_8Argument11new_displayjECs5ggOHDaYt9z_12layout_probe(ptr sret([16 x i8]) align 8 %_167, ptr align 8 %_246)
  %80 = getelementptr inbounds i8, ptr %args16, i64 24
  %_247 = load ptr, ptr %80, align 8
; call <core::fmt::rt::Argument>::new_display::<usize>
  call void @_RINvMNtNtCsgtPOCBgevO_4core3fmt2rtNtB3_8Argument11new_displayjECs5ggOHDaYt9z_12layout_probe(ptr sret([16 x i8]) align 8 %_168, ptr align 8 %_247)
  %81 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args17, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %81, ptr align 8 %_165, i64 16, i1 false)
  %82 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args17, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %82, ptr align 8 %_166, i64 16, i1 false)
  %83 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args17, i64 2
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %83, ptr align 8 %_167, i64 16, i1 false)
  %84 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args17, i64 3
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %84, ptr align 8 %_168, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<74, 4>
  %85 = call { ptr, ptr } @_RINvMs2_NtCsgtPOCBgevO_4core3fmtNtB6_9Arguments3newKj4a_Kj4_ECs5ggOHDaYt9z_12layout_probe(ptr @alloc_4e14e83ded74d5e8fc48e682727f5111, ptr align 8 %args17)
  %_158.0 = extractvalue { ptr, ptr } %85, 0
  %_158.1 = extractvalue { ptr, ptr } %85, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsa9BKTri5B3M_3std2io5stdio6__print(ptr %_158.0, ptr %_158.1)
  store ptr @alloc_53973d2fe29b4adba8bb7390b5678745, ptr %args18, align 8
  %86 = getelementptr inbounds i8, ptr %args18, i64 8
  store ptr @alloc_28b4525213e621d91e2b40299762a7fc, ptr %86, align 8
  %87 = getelementptr inbounds i8, ptr %args18, i64 16
  store ptr @alloc_b1a1c27c6d41023e30ee48eec611ccbe, ptr %87, align 8
  %88 = getelementptr inbounds i8, ptr %args18, i64 24
  store ptr @alloc_1faaba7c4c011edfc8833a88ffd8dff5, ptr %88, align 8
  %_248 = load ptr, ptr %args18, align 8
; call <core::fmt::rt::Argument>::new_display::<usize>
  call void @_RINvMNtNtCsgtPOCBgevO_4core3fmt2rtNtB3_8Argument11new_displayjECs5ggOHDaYt9z_12layout_probe(ptr sret([16 x i8]) align 8 %_179, ptr align 8 %_248)
  %89 = getelementptr inbounds i8, ptr %args18, i64 8
  %_249 = load ptr, ptr %89, align 8
; call <core::fmt::rt::Argument>::new_display::<usize>
  call void @_RINvMNtNtCsgtPOCBgevO_4core3fmt2rtNtB3_8Argument11new_displayjECs5ggOHDaYt9z_12layout_probe(ptr sret([16 x i8]) align 8 %_180, ptr align 8 %_249)
  %90 = getelementptr inbounds i8, ptr %args18, i64 16
  %_250 = load ptr, ptr %90, align 8
; call <core::fmt::rt::Argument>::new_display::<usize>
  call void @_RINvMNtNtCsgtPOCBgevO_4core3fmt2rtNtB3_8Argument11new_displayjECs5ggOHDaYt9z_12layout_probe(ptr sret([16 x i8]) align 8 %_181, ptr align 8 %_250)
  %91 = getelementptr inbounds i8, ptr %args18, i64 24
  %_251 = load ptr, ptr %91, align 8
; call <core::fmt::rt::Argument>::new_display::<usize>
  call void @_RINvMNtNtCsgtPOCBgevO_4core3fmt2rtNtB3_8Argument11new_displayjECs5ggOHDaYt9z_12layout_probe(ptr sret([16 x i8]) align 8 %_182, ptr align 8 %_251)
  %92 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args19, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %92, ptr align 8 %_179, i64 16, i1 false)
  %93 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args19, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %93, ptr align 8 %_180, i64 16, i1 false)
  %94 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args19, i64 2
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %94, ptr align 8 %_181, i64 16, i1 false)
  %95 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args19, i64 3
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %95, ptr align 8 %_182, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<71, 4>
  %96 = call { ptr, ptr } @_RINvMs2_NtCsgtPOCBgevO_4core3fmtNtB6_9Arguments3newKj47_Kj4_ECs5ggOHDaYt9z_12layout_probe(ptr @alloc_2def2677f68019b00d48075d2b6f0eb7, ptr align 8 %args19)
  %_172.0 = extractvalue { ptr, ptr } %96, 0
  %_172.1 = extractvalue { ptr, ptr } %96, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsa9BKTri5B3M_3std2io5stdio6__print(ptr %_172.0, ptr %_172.1)
; call <core::sync::atomic::Atomic<u64>>::new
  %97 = call i64 @_RNvMs1e_NtNtCsgtPOCBgevO_4core4sync6atomicINtB6_6AtomicyE3newCs5ggOHDaYt9z_12layout_probe(i64 0)
  store i64 %97, ptr %4, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_187, ptr align 8 %4, i64 8, i1 false)
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_186, ptr align 8 %_187, i64 8, i1 false)
  store i8 1, ptr %_252, align 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %3, ptr align 8 %_186, i64 8, i1 false)
  %98 = load i64, ptr %3, align 8
; call <alloc::sync::Arc<layout_probe::Account>>::new
  %99 = call ptr @_RNvMse_NtCslJsSqIQKwiA_5alloc4syncINtB5_3ArcNtCs5ggOHDaYt9z_12layout_probe7AccountE3newBI_(i64 %98)
  store ptr %99, ptr %account, align 8
; invoke alloc::boxed::box_new_uninit
  %_1.i26 = invoke align 8 ptr @_RNvNtCslJsSqIQKwiA_5alloc5boxed14box_new_uninitCs5ggOHDaYt9z_12layout_probe(i64 8, i64 16)
          to label %_RNvMNtCslJsSqIQKwiA_5alloc5boxedINtB2_3BoxAINtNtNtCsgtPOCBgevO_4core3ops5range5RangeNtCs5ggOHDaYt9z_12layout_probe11AudioSampleEj1_E10new_uninitB1m_.exit27 unwind label %cleanup

_RNvMNtCslJsSqIQKwiA_5alloc5boxedINtB2_3BoxAINtNtNtCsgtPOCBgevO_4core3ops5range5RangeNtCs5ggOHDaYt9z_12layout_probe11AudioSampleEj1_E10new_uninitB1m_.exit27: ; preds = %start
  br label %bb79

bb88:                                             ; preds = %cleanup.body
  %100 = load i8, ptr %_252, align 1
  %101 = trunc nuw i8 %100 to i1
  br i1 %101, label %bb87, label %bb86

cleanup:                                          ; preds = %start, %bb82, %bb84, %bb81
  %102 = landingpad { ptr, i32 }
          cleanup
  br label %cleanup.body

cleanup.body:                                     ; preds = %bb2.i, %cleanup
  %eh.lpad-body = phi { ptr, i32 } [ %102, %cleanup ], [ %121, %bb2.i ]
  %103 = extractvalue { ptr, i32 } %eh.lpad-body, 0
  %104 = extractvalue { ptr, i32 } %eh.lpad-body, 1
  store ptr %103, ptr %2, align 8
  %105 = getelementptr inbounds i8, ptr %2, i64 8
  store i32 %104, ptr %105, align 8
  br label %bb88

bb79:                                             ; preds = %_RNvMNtCslJsSqIQKwiA_5alloc5boxedINtB2_3BoxAINtNtNtCsgtPOCBgevO_4core3ops5range5RangeNtCs5ggOHDaYt9z_12layout_probe11AudioSampleEj1_E10new_uninitB1m_.exit27
  %_261 = ptrtoint ptr %_1.i26 to i64
  %_263 = and i64 %_261, 7
  %_264 = icmp eq i64 %_263, 0
  br i1 %_264, label %bb90, label %panic

bb90:                                             ; preds = %bb79
  %_266 = ptrtoint ptr %_1.i26 to i64
  %_268 = icmp eq i64 %_266, 0
  %_269 = and i1 %_268, true
  %_270 = xor i1 %_269, true
  br i1 %_270, label %bb91, label %panic20

panic:                                            ; preds = %bb79
; call core::panicking::panic_misaligned_pointer_dereference
  call void @_RNvNtCsgtPOCBgevO_4core9panicking36panic_misaligned_pointer_dereference(i64 8, i64 %_261, ptr align 8 @alloc_b755494a2e20c213ca2de9520fa65445) #15
  unreachable

bb91:                                             ; preds = %bb90
  %106 = getelementptr inbounds nuw %"core::ops::range::Range<AudioSample>", ptr %_1.i26, i64 0
  store i64 0, ptr %106, align 8
  %107 = getelementptr inbounds i8, ptr %106, i64 8
  store i64 1, ptr %107, align 8
; call <alloc::vec::Vec<_, _>>::from_raw_parts_in::precondition_check
  call void @_RNvNvMs_NtCslJsSqIQKwiA_5alloc3vecINtB6_3VecppE17from_raw_parts_in18precondition_checkCs5ggOHDaYt9z_12layout_probe(i64 1, i64 1, ptr align 8 @alloc_09d0336a64f3c3999c7f6c0a13f00bae) #18
  store i64 1, ptr %capacity.i23, align 8
; call <core::ptr::non_null::NonNull<_>>::new_unchecked::precondition_check
  call void @_RNvNvMs1_NtNtCsgtPOCBgevO_4core3ptr8non_nullINtB7_7NonNullpE13new_unchecked18precondition_checkCs5ggOHDaYt9z_12layout_probe(ptr align 8 %_1.i26, ptr align 8 @alloc_d59c3b01578993e4397b7dc92b88b8dd) #18
  %_12.0.i24 = load i64, ptr %capacity.i23, align 8
  store i64 %_12.0.i24, ptr %_193, align 8
  %108 = getelementptr inbounds i8, ptr %_193, i64 8
  store ptr %_1.i26, ptr %108, align 8
  %109 = getelementptr inbounds i8, ptr %_193, i64 16
  store i64 1, ptr %109, align 8
  br label %bb80

panic20:                                          ; preds = %bb90
; call core::panicking::panic_null_pointer_dereference
  call void @_RNvNtCsgtPOCBgevO_4core9panicking30panic_null_pointer_dereference(ptr align 8 @alloc_b755494a2e20c213ca2de9520fa65445) #15
  unreachable

bb80:                                             ; preds = %bb91
  store i8 0, ptr %_252, align 1
  %_199 = load ptr, ptr %account, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_192, ptr align 8 %_193, i64 24, i1 false)
  %110 = getelementptr inbounds i8, ptr %_192, i64 24
  store ptr %_199, ptr %110, align 8
  %111 = getelementptr inbounds i8, ptr %110, i64 8
  store i64 1, ptr %111, align 8
; invoke alloc::boxed::box_new_uninit
  %_3.i = invoke ptr @_RNvNtCslJsSqIQKwiA_5alloc5boxed14box_new_uninitCs5ggOHDaYt9z_12layout_probe(i64 8, i64 40)
          to label %_RNvMNtCslJsSqIQKwiA_5alloc5boxedINtB2_3BoxINtCs5ggOHDaYt9z_12layout_probe11MaskStorageNtBH_11AudioSampleEE3newBH_.exit unwind label %cleanup.i

cleanup.i:                                        ; preds = %bb80
  %112 = landingpad { ptr, i32 }
          cleanup
  %113 = extractvalue { ptr, i32 } %112, 0
  %114 = extractvalue { ptr, i32 } %112, 1
  store ptr %113, ptr %0, align 8
  %115 = getelementptr inbounds i8, ptr %0, i64 8
  store i32 %114, ptr %115, align 8
; invoke core::ptr::drop_glue::<layout_probe::MaskStorage<layout_probe::AudioSample>>
  invoke void @_RINvNtCsgtPOCBgevO_4core3ptr9drop_glueINtCs5ggOHDaYt9z_12layout_probe11MaskStorageNtBD_11AudioSampleEEBD_(ptr align 8 %_192) #16
          to label %bb2.i unwind label %terminate.i

terminate.i:                                      ; preds = %cleanup.i
  %116 = landingpad { ptr, i32 }
          cleanup
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_in_cleanup
  call void @_RNvNtCsgtPOCBgevO_4core9panicking16panic_in_cleanup() #17
  unreachable

bb2.i:                                            ; preds = %cleanup.i
  %117 = load ptr, ptr %0, align 8
  %118 = getelementptr inbounds i8, ptr %0, i64 8
  %119 = load i32, ptr %118, align 8
  %120 = insertvalue { ptr, i32 } poison, ptr %117, 0
  %121 = insertvalue { ptr, i32 } %120, i32 %119, 1
  br label %cleanup.body

_RNvMNtCslJsSqIQKwiA_5alloc5boxedINtB2_3BoxINtCs5ggOHDaYt9z_12layout_probe11MaskStorageNtBH_11AudioSampleEE3newBH_.exit: ; preds = %bb80
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_3.i, ptr align 8 %_192, i64 40, i1 false)
  br label %bb81

bb81:                                             ; preds = %_RNvMNtCslJsSqIQKwiA_5alloc5boxedINtB2_3BoxINtCs5ggOHDaYt9z_12layout_probe11MaskStorageNtBH_11AudioSampleEE3newBH_.exit
  %122 = getelementptr inbounds i8, ptr %mask, i64 8
  store ptr %_3.i, ptr %122, align 8
  store i64 -1, ptr %mask, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %1, ptr align 8 %mask, i64 24, i1 false)
; invoke core::mem::drop::<layout_probe::Mask<layout_probe::AudioSample>>
  invoke void @_RINvNtCsgtPOCBgevO_4core3mem4dropINtCs5ggOHDaYt9z_12layout_probe4MaskNtBy_11AudioSampleEEBy_(ptr align 8 %1)
          to label %bb82 unwind label %cleanup

bb82:                                             ; preds = %bb81
; invoke alloc::boxed::box_new_uninit
  %_1.i25 = invoke align 8 ptr @_RNvNtCslJsSqIQKwiA_5alloc5boxed14box_new_uninitCs5ggOHDaYt9z_12layout_probe(i64 8, i64 16)
          to label %_RNvMNtCslJsSqIQKwiA_5alloc5boxedINtB2_3BoxAINtNtNtCsgtPOCBgevO_4core3ops5range5RangeNtCs5ggOHDaYt9z_12layout_probe11AudioSampleEj1_E10new_uninitB1m_.exit unwind label %cleanup

_RNvMNtCslJsSqIQKwiA_5alloc5boxedINtB2_3BoxAINtNtNtCsgtPOCBgevO_4core3ops5range5RangeNtCs5ggOHDaYt9z_12layout_probe11AudioSampleEj1_E10new_uninitB1m_.exit: ; preds = %bb82
  br label %bb83

bb83:                                             ; preds = %_RNvMNtCslJsSqIQKwiA_5alloc5boxedINtB2_3BoxAINtNtNtCsgtPOCBgevO_4core3ops5range5RangeNtCs5ggOHDaYt9z_12layout_probe11AudioSampleEj1_E10new_uninitB1m_.exit
  %_256 = ptrtoint ptr %_1.i25 to i64
  %_258 = and i64 %_256, 7
  %_259 = icmp eq i64 %_258, 0
  br i1 %_259, label %bb89, label %panic21

bb89:                                             ; preds = %bb83
  %_272 = ptrtoint ptr %_1.i25 to i64
  %_274 = icmp eq i64 %_272, 0
  %_275 = and i1 %_274, true
  %_276 = xor i1 %_275, true
  br i1 %_276, label %bb92, label %panic22

panic21:                                          ; preds = %bb83
; call core::panicking::panic_misaligned_pointer_dereference
  call void @_RNvNtCsgtPOCBgevO_4core9panicking36panic_misaligned_pointer_dereference(i64 8, i64 %_256, ptr align 8 @alloc_35ed1ddd5bcb0b3e67c4fb3f3f092de9) #15
  unreachable

bb92:                                             ; preds = %bb89
  %123 = getelementptr inbounds nuw %"core::ops::range::Range<AudioSample>", ptr %_1.i25, i64 0
  store i64 0, ptr %123, align 8
  %124 = getelementptr inbounds i8, ptr %123, i64 8
  store i64 1, ptr %124, align 8
; call <alloc::vec::Vec<_, _>>::from_raw_parts_in::precondition_check
  call void @_RNvNvMs_NtCslJsSqIQKwiA_5alloc3vecINtB6_3VecppE17from_raw_parts_in18precondition_checkCs5ggOHDaYt9z_12layout_probe(i64 1, i64 1, ptr align 8 @alloc_09d0336a64f3c3999c7f6c0a13f00bae) #18
  store i64 1, ptr %capacity.i, align 8
; call <core::ptr::non_null::NonNull<_>>::new_unchecked::precondition_check
  call void @_RNvNvMs1_NtNtCsgtPOCBgevO_4core3ptr8non_nullINtB7_7NonNullpE13new_unchecked18precondition_checkCs5ggOHDaYt9z_12layout_probe(ptr align 8 %_1.i25, ptr align 8 @alloc_d59c3b01578993e4397b7dc92b88b8dd) #18
  %_12.0.i = load i64, ptr %capacity.i, align 8
  store i64 %_12.0.i, ptr %_203, align 8
  %125 = getelementptr inbounds i8, ptr %_203, i64 8
  store ptr %_1.i25, ptr %125, align 8
  %126 = getelementptr inbounds i8, ptr %_203, i64 16
  store i64 1, ptr %126, align 8
  br label %bb84

panic22:                                          ; preds = %bb89
; call core::panicking::panic_null_pointer_dereference
  call void @_RNvNtCsgtPOCBgevO_4core9panicking30panic_null_pointer_dereference(ptr align 8 @alloc_35ed1ddd5bcb0b3e67c4fb3f3f092de9) #15
  unreachable

bb84:                                             ; preds = %bb92
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_202, ptr align 8 %_203, i64 24, i1 false)
; invoke core::mem::drop::<layout_probe::Mask<layout_probe::AudioSample>>
  invoke void @_RINvNtCsgtPOCBgevO_4core3mem4dropINtCs5ggOHDaYt9z_12layout_probe4MaskNtBy_11AudioSampleEEBy_(ptr align 8 %_202)
          to label %bb85 unwind label %cleanup

bb85:                                             ; preds = %bb84
  store i8 0, ptr %_252, align 1
  ret void

bb86:                                             ; preds = %bb87, %bb88
  %127 = load ptr, ptr %2, align 8
  %128 = getelementptr inbounds i8, ptr %2, i64 8
  %129 = load i32, ptr %128, align 8
  %130 = insertvalue { ptr, i32 } poison, ptr %127, 0
  %131 = insertvalue { ptr, i32 } %130, i32 %129, 1
  resume { ptr, i32 } %131

bb87:                                             ; preds = %bb88
; invoke core::ptr::drop_glue::<alloc::sync::Arc<layout_probe::Account>>
  invoke void @_RINvNtCsgtPOCBgevO_4core3ptr9drop_glueINtNtCslJsSqIQKwiA_5alloc4sync3ArcNtCs5ggOHDaYt9z_12layout_probe7AccountEEB1a_(ptr align 8 %account) #16
          to label %bb86 unwind label %terminate

terminate:                                        ; preds = %bb87
  %132 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_in_cleanup
  call void @_RNvNtCsgtPOCBgevO_4core9panicking16panic_in_cleanup() #17
  unreachable
}

; <core::option::Option<alloc::boxed::Box<layout_probe::MaskStorage<layout_probe::AudioSample>>>>::take
; Function Attrs: inlinehint uwtable
define internal align 8 ptr @_RNvMNtCsgtPOCBgevO_4core6optionINtB2_6OptionINtNtCslJsSqIQKwiA_5alloc5boxed3BoxINtCs5ggOHDaYt9z_12layout_probe11MaskStorageNtB1i_11AudioSampleEEE4takeB1i_(ptr align 8 %self) unnamed_addr #1 {
start:
  %_0 = load ptr, ptr %self, align 8
  store ptr null, ptr %self, align 8
  ret ptr %_0
}

; <alloc::alloc::Global>::alloc_impl_runtime
; Function Attrs: inlinehint uwtable
define internal { ptr, i64 } @_RNvMNtCslJsSqIQKwiA_5alloc5allocNtB2_6Global18alloc_impl_runtimeCs5ggOHDaYt9z_12layout_probe(i64 %layout.0, i64 %layout.1, i1 zeroext %zeroed) unnamed_addr #1 {
start:
  %self1 = alloca [8 x i8], align 8
  %self = alloca [8 x i8], align 8
  %_9 = alloca [8 x i8], align 8
  %raw_ptr = alloca [8 x i8], align 8
  %_0 = alloca [16 x i8], align 8
  %0 = icmp eq i64 %layout.1, 0
  br i1 %0, label %bb2, label %bb1

bb2:                                              ; preds = %start
  %data = inttoptr i64 %layout.0 to ptr
  %data2 = inttoptr i64 %layout.0 to ptr
  br label %bb8

bb1:                                              ; preds = %start
  br i1 %zeroed, label %bb3, label %bb4

bb8:                                              ; preds = %bb2
  %_19 = inttoptr i64 %layout.0 to ptr
; call <core::ptr::non_null::NonNull<_>>::new_unchecked::precondition_check
  call void @_RNvNvMs1_NtNtCsgtPOCBgevO_4core3ptr8non_nullINtB7_7NonNullpE13new_unchecked18precondition_checkCs5ggOHDaYt9z_12layout_probe(ptr %_19, ptr align 8 @alloc_8d5a0ee98b8cdf2f5afa900e7e86c059) #18
  br label %bb10

bb10:                                             ; preds = %bb8
  store ptr %data2, ptr %_0, align 8
  %1 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 0, ptr %1, align 8
  br label %bb6

bb6:                                              ; preds = %bb22, %bb10
  br label %bb7

bb4:                                              ; preds = %bb1
; call __rustc::__rust_no_alloc_shim_is_unstable_v2
  call void @_RNvCs9wFQrvczXsK_7___rustc35___rust_no_alloc_shim_is_unstable_v2() #18
; call __rustc::__rust_alloc
  %2 = call ptr @_RNvCs9wFQrvczXsK_7___rustc12___rust_alloc(i64 %layout.1, i64 %layout.0) #18
  store ptr %2, ptr %raw_ptr, align 8
  br label %bb5

bb3:                                              ; preds = %bb1
; call __rustc::__rust_no_alloc_shim_is_unstable_v2
  call void @_RNvCs9wFQrvczXsK_7___rustc35___rust_no_alloc_shim_is_unstable_v2() #18
; call __rustc::__rust_alloc_zeroed
  %3 = call ptr @_RNvCs9wFQrvczXsK_7___rustc19___rust_alloc_zeroed(i64 %layout.1, i64 %layout.0) #18
  store ptr %3, ptr %raw_ptr, align 8
  br label %bb5

bb5:                                              ; preds = %bb3, %bb4
  %4 = load ptr, ptr %raw_ptr, align 8
  %_29 = ptrtoint ptr %4 to i64
  %5 = icmp eq i64 %_29, 0
  br i1 %5, label %bb15, label %bb16

bb15:                                             ; preds = %bb5
  store ptr null, ptr %self1, align 8
  store ptr null, ptr %self, align 8
  %6 = load ptr, ptr @anon.730379407b893e35326a836a497d6d4b.0, align 8
  %7 = load i64, ptr getelementptr inbounds (i8, ptr @anon.730379407b893e35326a836a497d6d4b.0, i64 8), align 8
  store ptr %6, ptr %_0, align 8
  %8 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %7, ptr %8, align 8
  br label %bb7

bb16:                                             ; preds = %bb5
  br label %bb17

bb7:                                              ; preds = %bb6, %bb15
  %9 = load ptr, ptr %_0, align 8
  %10 = getelementptr inbounds i8, ptr %_0, i64 8
  %11 = load i64, ptr %10, align 8
  %12 = insertvalue { ptr, i64 } poison, ptr %9, 0
  %13 = insertvalue { ptr, i64 } %12, i64 %11, 1
  ret { ptr, i64 } %13

bb17:                                             ; preds = %bb16
  %_31 = load ptr, ptr %raw_ptr, align 8
; call <core::ptr::non_null::NonNull<_>>::new_unchecked::precondition_check
  call void @_RNvNvMs1_NtNtCsgtPOCBgevO_4core3ptr8non_nullINtB7_7NonNullpE13new_unchecked18precondition_checkCs5ggOHDaYt9z_12layout_probe(ptr %_31, ptr align 8 @alloc_5ff1c8aa34f46974b9857da735e490e2) #18
  br label %bb19

bb19:                                             ; preds = %bb17
  %_28 = load ptr, ptr %raw_ptr, align 8
  store ptr %_28, ptr %self1, align 8
  %v = load ptr, ptr %self1, align 8
  store ptr %v, ptr %self, align 8
  %v3 = load ptr, ptr %self, align 8
  store ptr %v3, ptr %_9, align 8
  %ptr = load ptr, ptr %_9, align 8
  br label %bb20

bb20:                                             ; preds = %bb19
; call <core::ptr::non_null::NonNull<_>>::new_unchecked::precondition_check
  call void @_RNvNvMs1_NtNtCsgtPOCBgevO_4core3ptr8non_nullINtB7_7NonNullpE13new_unchecked18precondition_checkCs5ggOHDaYt9z_12layout_probe(ptr %ptr, ptr align 8 @alloc_8d5a0ee98b8cdf2f5afa900e7e86c059) #18
  br label %bb22

bb22:                                             ; preds = %bb20
  store ptr %ptr, ptr %_0, align 8
  %14 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %layout.1, ptr %14, align 8
  br label %bb6
}

; <core::sync::atomic::Atomic<u64>>::new
; Function Attrs: inlinehint uwtable
define internal i64 @_RNvMs1e_NtNtCsgtPOCBgevO_4core4sync6atomicINtB6_6AtomicyE3newCs5ggOHDaYt9z_12layout_probe(i64 %v) unnamed_addr #1 {
start:
  %_0 = alloca [8 x i8], align 8
  store i64 %v, ptr %_0, align 8
  %0 = load i64, ptr %_0, align 8
  ret i64 %0
}

; <alloc::sync::Arc<layout_probe::Account>>::new
; Function Attrs: inlinehint uwtable
define internal ptr @_RNvMse_NtCslJsSqIQKwiA_5alloc4syncINtB5_3ArcNtCs5ggOHDaYt9z_12layout_probe7AccountE3newBI_(i64 %0) unnamed_addr #1 personality ptr @rust_eh_personality {
start:
  %1 = alloca [16 x i8], align 8
  %_4 = alloca [8 x i8], align 8
  %_3 = alloca [24 x i8], align 8
  %2 = alloca [8 x i8], align 8
  %data = alloca [8 x i8], align 8
  store i64 %0, ptr %2, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %data, ptr align 8 %2, i64 8, i1 false)
  store i64 1, ptr %_4, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_3, ptr align 8 %_4, i64 8, i1 false)
  %3 = getelementptr inbounds i8, ptr %_3, i64 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %3, ptr align 8 %_4, i64 8, i1 false)
  %4 = getelementptr inbounds i8, ptr %_3, i64 16
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %4, ptr align 8 %data, i64 8, i1 false)
; invoke alloc::boxed::box_new_uninit
  %_3.i = invoke ptr @_RNvNtCslJsSqIQKwiA_5alloc5boxed14box_new_uninitCs5ggOHDaYt9z_12layout_probe(i64 8, i64 24)
          to label %_RNvMNtCslJsSqIQKwiA_5alloc5boxedINtB2_3BoxINtNtB4_4sync8ArcInnerNtCs5ggOHDaYt9z_12layout_probe7AccountEE3newB12_.exit unwind label %cleanup.i

cleanup.i:                                        ; preds = %start
  %5 = landingpad { ptr, i32 }
          cleanup
  %6 = extractvalue { ptr, i32 } %5, 0
  %7 = extractvalue { ptr, i32 } %5, 1
  store ptr %6, ptr %1, align 8
  %8 = getelementptr inbounds i8, ptr %1, i64 8
  store i32 %7, ptr %8, align 8
  %9 = load ptr, ptr %1, align 8
  %10 = getelementptr inbounds i8, ptr %1, i64 8
  %11 = load i32, ptr %10, align 8
  %12 = insertvalue { ptr, i32 } poison, ptr %9, 0
  %13 = insertvalue { ptr, i32 } %12, i32 %11, 1
  resume { ptr, i32 } %13

_RNvMNtCslJsSqIQKwiA_5alloc5boxedINtB2_3BoxINtNtB4_4sync8ArcInnerNtCs5ggOHDaYt9z_12layout_probe7AccountEE3newB12_.exit: ; preds = %start
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_3.i, ptr align 8 %_3, i64 24, i1 false)
  ret ptr %_3.i
}

; <alloc::sync::Arc<layout_probe::Account>>::drop_slow
; Function Attrs: noinline uwtable
define internal void @_RNvMsn_NtCslJsSqIQKwiA_5alloc4syncINtB5_3ArcNtCs5ggOHDaYt9z_12layout_probe7AccountE9drop_slowBI_(ptr align 8 %self) unnamed_addr #0 personality ptr @rust_eh_personality {
start:
  %0 = alloca [16 x i8], align 8
  %_weak = alloca [16 x i8], align 8
  %_3 = load ptr, ptr %self, align 8
  %_4 = getelementptr inbounds i8, ptr %self, i64 8
  store ptr %_3, ptr %_weak, align 8
  %1 = getelementptr inbounds i8, ptr %_weak, i64 8
  store ptr %_4, ptr %1, align 8
  %self1 = load ptr, ptr %self, align 8
  %_9 = getelementptr inbounds i8, ptr %self1, i64 16
  br label %bb4

bb4:                                              ; preds = %start
; call core::ptr::drop_glue::<alloc::sync::Weak<layout_probe::Account, &alloc::alloc::Global>>
  call void @_RINvNtCsgtPOCBgevO_4core3ptr9drop_glueINtNtCslJsSqIQKwiA_5alloc4sync4WeakNtCs5ggOHDaYt9z_12layout_probe7AccountRNtNtBF_5alloc6GlobalEEB1b_(ptr align 8 %_weak)
  ret void

bb2:                                              ; No predecessors!
; invoke core::ptr::drop_glue::<alloc::sync::Weak<layout_probe::Account, &alloc::alloc::Global>>
  invoke void @_RINvNtCsgtPOCBgevO_4core3ptr9drop_glueINtNtCslJsSqIQKwiA_5alloc4sync4WeakNtCs5ggOHDaYt9z_12layout_probe7AccountRNtNtBF_5alloc6GlobalEEB1b_(ptr align 8 %_weak) #16
          to label %bb3 unwind label %terminate

terminate:                                        ; preds = %bb2
  %2 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_in_cleanup
  call void @_RNvNtCsgtPOCBgevO_4core9panicking16panic_in_cleanup() #17
  unreachable

bb3:                                              ; preds = %bb2
  %3 = load ptr, ptr %0, align 8
  %4 = getelementptr inbounds i8, ptr %0, i64 8
  %5 = load i32, ptr %4, align 8
  %6 = insertvalue { ptr, i32 } poison, ptr %3, 0
  %7 = insertvalue { ptr, i32 } %6, i32 %5, 1
  resume { ptr, i32 } %7
}

; alloc::boxed::box_new_uninit
; Function Attrs: inlinehint uwtable
define internal ptr @_RNvNtCslJsSqIQKwiA_5alloc5boxed14box_new_uninitCs5ggOHDaYt9z_12layout_probe(i64 %layout.0, i64 %layout.1) unnamed_addr #1 {
start:
  %_2 = alloca [16 x i8], align 8
; call <alloc::alloc::Global>::alloc_impl_runtime
  %0 = call { ptr, i64 } @_RNvMNtCslJsSqIQKwiA_5alloc5allocNtB2_6Global18alloc_impl_runtimeCs5ggOHDaYt9z_12layout_probe(i64 %layout.0, i64 %layout.1, i1 zeroext false)
  %1 = extractvalue { ptr, i64 } %0, 0
  %2 = extractvalue { ptr, i64 } %0, 1
  store ptr %1, ptr %_2, align 8
  %3 = getelementptr inbounds i8, ptr %_2, i64 8
  store i64 %2, ptr %3, align 8
  %4 = load ptr, ptr %_2, align 8
  %5 = getelementptr inbounds i8, ptr %_2, i64 8
  %6 = load i64, ptr %5, align 8
  %7 = ptrtoint ptr %4 to i64
  %8 = icmp eq i64 %7, 0
  %_3 = select i1 %8, i64 1, i64 0
  %9 = trunc nuw i64 %_3 to i1
  br i1 %9, label %bb2, label %bb3

bb2:                                              ; preds = %start
; call alloc::alloc::handle_alloc_error
  call void @_RNvNtCslJsSqIQKwiA_5alloc5alloc18handle_alloc_error(i64 %layout.0, i64 %layout.1) #19
  unreachable

bb3:                                              ; preds = %start
  %ptr.0 = load ptr, ptr %_2, align 8
  %10 = getelementptr inbounds i8, ptr %_2, i64 8
  %ptr.1 = load i64, ptr %10, align 8
  ret ptr %ptr.0

bb1:                                              ; No predecessors!
  unreachable
}

; core::sync::atomic::fence
; Function Attrs: inlinehint uwtable
define internal void @_RNvNtNtCsgtPOCBgevO_4core4sync6atomic5fenceCs5ggOHDaYt9z_12layout_probe(i8 %order) unnamed_addr #1 {
start:
  %_2 = zext i8 %order to i64
  switch i64 %_2, label %bb1 [
    i64 0, label %bb2
    i64 1, label %bb5
    i64 2, label %bb6
    i64 3, label %bb4
    i64 4, label %bb3
  ]

bb1:                                              ; preds = %start
  unreachable

bb2:                                              ; preds = %start
; call core::panicking::panic_fmt
  call void @_RNvNtCsgtPOCBgevO_4core9panicking9panic_fmt(ptr @alloc_929e9b2e7b7429614ca4fc017efff666, ptr inttoptr (i64 83 to ptr), ptr align 8 @alloc_51bc672182609c8619102955545c9936) #19
  unreachable

bb5:                                              ; preds = %start
  fence release
  br label %bb7

bb6:                                              ; preds = %start
  fence acquire
  br label %bb7

bb4:                                              ; preds = %start
  fence acq_rel
  br label %bb7

bb3:                                              ; preds = %start
  fence seq_cst
  br label %bb7

bb7:                                              ; preds = %bb3, %bb4, %bb6, %bb5
  ret void
}

; <core::mem::alignment::Alignment>::new_unchecked::precondition_check
; Function Attrs: inlinehint nounwind uwtable
define internal void @_RNvNvMNtNtCsgtPOCBgevO_4core3mem9alignmentNtB4_9Alignment13new_unchecked18precondition_checkCs5ggOHDaYt9z_12layout_probe(i64 %align, ptr align 8 %0) unnamed_addr #3 {
start:
  %1 = alloca [4 x i8], align 4
  %2 = call i64 @llvm.ctpop.i64(i64 %align)
  %3 = trunc i64 %2 to i32
  store i32 %3, ptr %1, align 4
  %_5 = load i32, ptr %1, align 4
  %4 = icmp eq i32 %_5, 1
  br i1 %4, label %bb1, label %bb2

bb1:                                              ; preds = %start
  ret void

bb2:                                              ; preds = %start
; call core::panicking::panic_nounwind_fmt
  call void @_RNvNtCsgtPOCBgevO_4core9panicking18panic_nounwind_fmt(ptr @alloc_0625062a5eee489a7813ee965a38d15a, ptr inttoptr (i64 397 to ptr), i1 zeroext false, ptr align 8 %0) #15
  unreachable
}

; <core::alloc::layout::Layout>::from_size_alignment_unchecked::precondition_check
; Function Attrs: inlinehint nounwind uwtable
define internal void @_RNvNvMNtNtCsgtPOCBgevO_4core5alloc6layoutNtB4_6Layout29from_size_alignment_unchecked18precondition_checkCs5ggOHDaYt9z_12layout_probe(i64 %size, i64 %alignment, ptr align 8 %0) unnamed_addr #3 {
start:
  %_7 = sub nuw i64 -9223372036854775808, %alignment
  %_3 = icmp ule i64 %size, %_7
  br i1 %_3, label %bb1, label %bb2

bb2:                                              ; preds = %start
; call core::panicking::panic_nounwind_fmt
  call void @_RNvNtCsgtPOCBgevO_4core9panicking18panic_nounwind_fmt(ptr @alloc_8cf3531fd3c828ab298b686071a40c17, ptr inttoptr (i64 519 to ptr), i1 zeroext false, ptr align 8 %0) #15
  unreachable

bb1:                                              ; preds = %start
  ret void
}

; <core::ptr::non_null::NonNull<_>>::new_unchecked::precondition_check
; Function Attrs: inlinehint nounwind uwtable
define internal void @_RNvNvMs1_NtNtCsgtPOCBgevO_4core3ptr8non_nullINtB7_7NonNullpE13new_unchecked18precondition_checkCs5ggOHDaYt9z_12layout_probe(ptr %ptr, ptr align 8 %0) unnamed_addr #3 {
start:
  %_5 = ptrtoint ptr %ptr to i64
  %1 = icmp eq i64 %_5, 0
  br i1 %1, label %bb1, label %bb2

bb1:                                              ; preds = %start
; call core::panicking::panic_nounwind_fmt
  call void @_RNvNtCsgtPOCBgevO_4core9panicking18panic_nounwind_fmt(ptr @alloc_560a59ed819b9d9a5841f6e731c4c8e5, ptr inttoptr (i64 421 to ptr), i1 zeroext false, ptr align 8 %0) #15
  unreachable

bb2:                                              ; preds = %start
  ret void
}

; <alloc::vec::Vec<_, _>>::from_raw_parts_in::precondition_check
; Function Attrs: inlinehint nounwind uwtable
define internal void @_RNvNvMs_NtCslJsSqIQKwiA_5alloc3vecINtB6_3VecppE17from_raw_parts_in18precondition_checkCs5ggOHDaYt9z_12layout_probe(i64 %length, i64 %capacity, ptr align 8 %0) unnamed_addr #3 {
start:
  %_3 = icmp ule i64 %length, %capacity
  br i1 %_3, label %bb1, label %bb2

bb2:                                              ; preds = %start
; call core::panicking::panic_nounwind_fmt
  call void @_RNvNtCsgtPOCBgevO_4core9panicking18panic_nounwind_fmt(ptr @alloc_82a99021b1306c9239507412b95c0e74, ptr inttoptr (i64 411 to ptr), i1 zeroext false, ptr align 8 %0) #15
  unreachable

bb1:                                              ; preds = %start
  ret void
}

; <layout_probe::OwnedMask<layout_probe::AudioSample> as core::ops::drop::Drop>::drop
; Function Attrs: uwtable
define internal void @_RNvXCs5ggOHDaYt9z_12layout_probeINtB2_9OwnedMaskNtB2_11AudioSampleENtNtNtCsgtPOCBgevO_4core3ops4drop4Drop4dropB2_(ptr align 8 %self) unnamed_addr #2 personality ptr @rust_eh_personality {
start:
  %0 = alloca [16 x i8], align 8
  %_14 = alloca [1 x i8], align 1
  %_13 = alloca [1 x i8], align 1
  %_10 = alloca [24 x i8], align 8
  %_8 = alloca [40 x i8], align 8
  %ticket = alloca [16 x i8], align 8
  %ranges = alloca [24 x i8], align 8
  %_2 = alloca [8 x i8], align 8
  store i8 0, ptr %_14, align 1
  store i8 0, ptr %_13, align 1
; call <core::option::Option<alloc::boxed::Box<layout_probe::MaskStorage<layout_probe::AudioSample>>>>::take
  %1 = call align 8 ptr @_RNvMNtCsgtPOCBgevO_4core6optionINtB2_6OptionINtNtCslJsSqIQKwiA_5alloc5boxed3BoxINtCs5ggOHDaYt9z_12layout_probe11MaskStorageNtB1i_11AudioSampleEEE4takeB1i_(ptr align 8 %self)
  store ptr %1, ptr %_2, align 8
  %2 = load ptr, ptr %_2, align 8
  %3 = ptrtoint ptr %2 to i64
  %4 = icmp eq i64 %3, 0
  %_4 = select i1 %4, i64 0, i64 1
  %5 = trunc nuw i64 %_4 to i1
  br i1 %5, label %bb2, label %bb6

bb2:                                              ; preds = %start
  %boxed = load ptr, ptr %_2, align 8
; call layout_probe::unbox::<layout_probe::MaskStorage<layout_probe::AudioSample>>
  call void @_RINvCs5ggOHDaYt9z_12layout_probe5unboxINtB2_11MaskStorageNtB2_11AudioSampleEEB2_(ptr sret([40 x i8]) align 8 %_8, ptr align 8 %boxed)
  store i8 1, ptr %_14, align 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %ranges, ptr align 8 %_8, i64 24, i1 false)
  store i8 1, ptr %_13, align 1
  %6 = getelementptr inbounds i8, ptr %_8, i64 24
  %7 = load ptr, ptr %6, align 8
  %8 = getelementptr inbounds i8, ptr %6, i64 8
  %9 = load i64, ptr %8, align 8
  store ptr %7, ptr %ticket, align 8
  %10 = getelementptr inbounds i8, ptr %ticket, i64 8
  store i64 %9, ptr %10, align 8
  store i8 0, ptr %_14, align 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_10, ptr align 8 %ranges, i64 24, i1 false)
; invoke core::mem::drop::<alloc::vec::Vec<core::ops::range::Range<layout_probe::AudioSample>>>
  invoke void @_RINvNtCsgtPOCBgevO_4core3mem4dropINtNtCslJsSqIQKwiA_5alloc3vec3VecINtNtNtB4_3ops5range5RangeNtCs5ggOHDaYt9z_12layout_probe11AudioSampleEEEB1u_(ptr align 8 %_10)
          to label %bb4 unwind label %cleanup

bb6:                                              ; preds = %bb5, %start
  ret void

bb9:                                              ; preds = %cleanup
  %11 = load i8, ptr %_13, align 1
  %12 = trunc nuw i8 %11 to i1
  br i1 %12, label %bb8, label %bb7

cleanup:                                          ; preds = %bb4, %bb2
  %13 = landingpad { ptr, i32 }
          cleanup
  %14 = extractvalue { ptr, i32 } %13, 0
  %15 = extractvalue { ptr, i32 } %13, 1
  store ptr %14, ptr %0, align 8
  %16 = getelementptr inbounds i8, ptr %0, i64 8
  store i32 %15, ptr %16, align 8
  br label %bb9

bb4:                                              ; preds = %bb2
  store i8 0, ptr %_13, align 1
  %_12.0 = load ptr, ptr %ticket, align 8
  %17 = getelementptr inbounds i8, ptr %ticket, i64 8
  %_12.1 = load i64, ptr %17, align 8
; invoke core::mem::drop::<layout_probe::OwnedCharge>
  invoke void @_RINvNtCsgtPOCBgevO_4core3mem4dropNtCs5ggOHDaYt9z_12layout_probe11OwnedChargeEBx_(ptr %_12.0, i64 %_12.1)
          to label %bb5 unwind label %cleanup

bb5:                                              ; preds = %bb4
  store i8 0, ptr %_13, align 1
  store i8 0, ptr %_14, align 1
  br label %bb6

bb7:                                              ; preds = %bb8, %bb9
  %18 = load i8, ptr %_14, align 1
  %19 = trunc nuw i8 %18 to i1
  br i1 %19, label %bb10, label %bb11

bb8:                                              ; preds = %bb9
; invoke core::ptr::drop_glue::<layout_probe::OwnedCharge>
  invoke void @_RINvNtCsgtPOCBgevO_4core3ptr9drop_glueNtCs5ggOHDaYt9z_12layout_probe11OwnedChargeEBC_(ptr align 8 %ticket) #16
          to label %bb7 unwind label %terminate

terminate:                                        ; preds = %bb10, %bb8
  %20 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_in_cleanup
  call void @_RNvNtCsgtPOCBgevO_4core9panicking16panic_in_cleanup() #17
  unreachable

bb11:                                             ; preds = %bb10, %bb7
  %21 = load ptr, ptr %0, align 8
  %22 = getelementptr inbounds i8, ptr %0, i64 8
  %23 = load i32, ptr %22, align 8
  %24 = insertvalue { ptr, i32 } poison, ptr %21, 0
  %25 = insertvalue { ptr, i32 } %24, i32 %23, 1
  resume { ptr, i32 } %25

bb10:                                             ; preds = %bb7
; invoke core::ptr::drop_glue::<alloc::vec::Vec<core::ops::range::Range<layout_probe::AudioSample>>>
  invoke void @_RINvNtCsgtPOCBgevO_4core3ptr9drop_glueINtNtCslJsSqIQKwiA_5alloc3vec3VecINtNtNtB4_3ops5range5RangeNtCs5ggOHDaYt9z_12layout_probe11AudioSampleEEEB1z_(ptr align 8 %ranges) #16
          to label %bb11 unwind label %terminate

bb12:                                             ; No predecessors!
  unreachable
}

; <&alloc::alloc::Global as core::alloc::Allocator>::deallocate
; Function Attrs: inlinehint uwtable
define internal void @_RNvXs0_NtCsgtPOCBgevO_4core5allocRNtNtCslJsSqIQKwiA_5alloc5alloc6GlobalNtB5_9Allocator10deallocateCs5ggOHDaYt9z_12layout_probe(ptr align 8 %self, ptr %ptr, i64 %layout.0, i64 %layout.1) unnamed_addr #1 {
start:
  %_4 = load ptr, ptr %self, align 8
; call <alloc::alloc::Global as core::alloc::Allocator>::deallocate
  call void @_RNvXs_NtCslJsSqIQKwiA_5alloc5allocNtB4_6GlobalNtNtCsgtPOCBgevO_4core5alloc9Allocator10deallocateCs5ggOHDaYt9z_12layout_probe(ptr %_4, ptr %ptr, i64 %layout.0, i64 %layout.1)
  ret void
}

; <alloc::raw_vec::RawVec<core::ops::range::Range<layout_probe::AudioSample>> as core::ops::drop::Drop>::drop
; Function Attrs: uwtable
define internal void @_RNvXs1_NtCslJsSqIQKwiA_5alloc7raw_vecINtB5_6RawVecINtNtNtCsgtPOCBgevO_4core3ops5range5RangeNtCs5ggOHDaYt9z_12layout_probe11AudioSampleEENtNtBR_4drop4Drop4dropB1t_(ptr align 8 %self) unnamed_addr #2 {
start:
; call <alloc::raw_vec::RawVecInner>::deallocate
  call void @_RNvMs2_NtCslJsSqIQKwiA_5alloc7raw_vecNtB5_11RawVecInner10deallocateCsjevKHkJAzVy_5gimli(ptr align 8 %self, i64 8, i64 16)
  ret void
}

; <alloc::boxed::Box<layout_probe::MaskStorage<layout_probe::AudioSample>> as core::ops::drop::Drop>::drop
; Function Attrs: inlinehint uwtable
define internal void @_RNvXs8_NtCslJsSqIQKwiA_5alloc5boxedINtB5_3BoxINtCs5ggOHDaYt9z_12layout_probe11MaskStorageNtBK_11AudioSampleEENtNtNtCsgtPOCBgevO_4core3ops4drop4Drop4dropBK_(ptr align 8 %self) unnamed_addr #1 {
start:
  %0 = alloca [8 x i8], align 8
  %1 = alloca [8 x i8], align 8
  %ptr = load ptr, ptr %self, align 8
  store i64 40, ptr %1, align 8
  %size = load i64, ptr %1, align 8
  store i64 8, ptr %0, align 8
  %align = load i64, ptr %0, align 8
  br label %bb6

bb6:                                              ; preds = %start
; call <core::mem::alignment::Alignment>::new_unchecked::precondition_check
  call void @_RNvNvMNtNtCsgtPOCBgevO_4core3mem9alignmentNtB4_9Alignment13new_unchecked18precondition_checkCs5ggOHDaYt9z_12layout_probe(i64 %align, ptr align 8 @alloc_94ac603a76bcb1c7cd512525db170514) #18
  br label %bb7

bb7:                                              ; preds = %bb6
  br label %bb8

bb8:                                              ; preds = %bb7
; call <core::alloc::layout::Layout>::from_size_alignment_unchecked::precondition_check
  call void @_RNvNvMNtNtCsgtPOCBgevO_4core5alloc6layoutNtB4_6Layout29from_size_alignment_unchecked18precondition_checkCs5ggOHDaYt9z_12layout_probe(i64 %size, i64 %align, ptr align 8 @alloc_632d33230a33b678beb09f7f8dd3a0db) #18
  br label %bb9

bb9:                                              ; preds = %bb8
  %2 = icmp eq i64 %size, 0
  br i1 %2, label %bb3, label %bb1

bb3:                                              ; preds = %bb1, %bb9
  ret void

bb1:                                              ; preds = %bb9
  %_7 = getelementptr inbounds i8, ptr %self, i64 8
; call <alloc::alloc::Global as core::alloc::Allocator>::deallocate
  call void @_RNvXs_NtCslJsSqIQKwiA_5alloc5allocNtB4_6GlobalNtNtCsgtPOCBgevO_4core5alloc9Allocator10deallocateCs5ggOHDaYt9z_12layout_probe(ptr %_7, ptr %ptr, i64 %align, i64 %size)
  br label %bb3
}

; <alloc::sync::Arc<layout_probe::Account> as core::ops::drop::Drop>::drop
; Function Attrs: inlinehint uwtable
define internal void @_RNvXsD_NtCslJsSqIQKwiA_5alloc4syncINtB5_3ArcNtCs5ggOHDaYt9z_12layout_probe7AccountENtNtNtCsgtPOCBgevO_4core3ops4drop4Drop4dropBI_(ptr align 8 %self) unnamed_addr #1 {
start:
  %0 = alloca [8 x i8], align 8
  %_10 = load ptr, ptr %self, align 8
  %1 = atomicrmw sub ptr %_10, i64 1 release, align 8
  store i64 %1, ptr %0, align 8
  %_2 = load i64, ptr %0, align 8
  %2 = icmp eq i64 %_2, 1
  br i1 %2, label %bb2, label %bb1

bb2:                                              ; preds = %start
; call core::sync::atomic::fence
  call void @_RNvNtNtCsgtPOCBgevO_4core4sync6atomic5fenceCs5ggOHDaYt9z_12layout_probe(i8 2)
; call <alloc::sync::Arc<layout_probe::Account>>::drop_slow
  call void @_RNvMsn_NtCslJsSqIQKwiA_5alloc4syncINtB5_3ArcNtCs5ggOHDaYt9z_12layout_probe7AccountE9drop_slowBI_(ptr align 8 %self)
  br label %bb4

bb1:                                              ; preds = %start
  br label %bb4

bb4:                                              ; preds = %bb1, %bb2
  ret void
}

; <alloc::sync::Weak<layout_probe::Account, &alloc::alloc::Global> as core::ops::drop::Drop>::drop
; Function Attrs: uwtable
define internal void @_RNvXsN_NtCslJsSqIQKwiA_5alloc4syncINtB5_4WeakNtCs5ggOHDaYt9z_12layout_probe7AccountRNtNtB7_5alloc6GlobalENtNtNtCsgtPOCBgevO_4core3ops4drop4Drop4dropBJ_(ptr align 8 %self) unnamed_addr #2 {
start:
  %0 = alloca [8 x i8], align 8
  %1 = alloca [8 x i8], align 8
  %2 = alloca [8 x i8], align 8
  %_2 = alloca [16 x i8], align 8
  %self1 = load ptr, ptr %self, align 8
  %_20 = ptrtoint ptr %self1 to i64
  %3 = icmp eq i64 %_20, -1
  br i1 %3, label %bb7, label %bb8

bb7:                                              ; preds = %start
  br label %bb6

bb8:                                              ; preds = %start
  %_19 = getelementptr inbounds i8, ptr %self1, i64 8
  store ptr %_19, ptr %_2, align 8
  %4 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr %self1, ptr %4, align 8
  %inner = load ptr, ptr %_2, align 8
  %5 = getelementptr inbounds i8, ptr %_2, i64 8
  %inner2 = load ptr, ptr %5, align 8
  %6 = atomicrmw sub ptr %inner, i64 1 release, align 8
  store i64 %6, ptr %2, align 8
  %_3 = load i64, ptr %2, align 8
  %7 = icmp eq i64 %_3, 1
  br i1 %7, label %bb1, label %bb4

bb6:                                              ; preds = %bb5, %bb7
  ret void

bb1:                                              ; preds = %bb8
; call core::sync::atomic::fence
  call void @_RNvNtNtCsgtPOCBgevO_4core4sync6atomic5fenceCs5ggOHDaYt9z_12layout_probe(i8 2)
  %_8 = getelementptr inbounds i8, ptr %self, i64 8
  %self3 = load ptr, ptr %self, align 8
  %self4 = load ptr, ptr %self, align 8
  store i64 24, ptr %1, align 8
  %size = load i64, ptr %1, align 8
  store i64 8, ptr %0, align 8
  %align = load i64, ptr %0, align 8
  br label %bb12

bb4:                                              ; preds = %bb8
  br label %bb5

bb12:                                             ; preds = %bb1
; call <core::mem::alignment::Alignment>::new_unchecked::precondition_check
  call void @_RNvNvMNtNtCsgtPOCBgevO_4core3mem9alignmentNtB4_9Alignment13new_unchecked18precondition_checkCs5ggOHDaYt9z_12layout_probe(i64 %align, ptr align 8 @alloc_94ac603a76bcb1c7cd512525db170514) #18
  br label %bb13

bb13:                                             ; preds = %bb12
  br label %bb14

bb14:                                             ; preds = %bb13
; call <core::alloc::layout::Layout>::from_size_alignment_unchecked::precondition_check
  call void @_RNvNvMNtNtCsgtPOCBgevO_4core5alloc6layoutNtB4_6Layout29from_size_alignment_unchecked18precondition_checkCs5ggOHDaYt9z_12layout_probe(i64 %size, i64 %align, ptr align 8 @alloc_632d33230a33b678beb09f7f8dd3a0db) #18
  br label %bb15

bb15:                                             ; preds = %bb14
; call <&alloc::alloc::Global as core::alloc::Allocator>::deallocate
  call void @_RNvXs0_NtCsgtPOCBgevO_4core5allocRNtNtCslJsSqIQKwiA_5alloc5alloc6GlobalNtB5_9Allocator10deallocateCs5ggOHDaYt9z_12layout_probe(ptr align 8 %_8, ptr %self3, i64 %align, i64 %size)
  br label %bb5

bb5:                                              ; preds = %bb4, %bb15
  br label %bb6
}

; <() as std::process::Termination>::report
; Function Attrs: inlinehint uwtable
define internal i8 @_RNvXsZ_NtCsa9BKTri5B3M_3std7processuNtB5_11Termination6reportCs5ggOHDaYt9z_12layout_probe() unnamed_addr #1 {
start:
  ret i8 0
}

; <alloc::alloc::Global as core::alloc::Allocator>::deallocate
; Function Attrs: inlinehint uwtable
define internal void @_RNvXs_NtCslJsSqIQKwiA_5alloc5allocNtB4_6GlobalNtNtCsgtPOCBgevO_4core5alloc9Allocator10deallocateCs5ggOHDaYt9z_12layout_probe(ptr %self, ptr %ptr, i64 %layout.0, i64 %layout.1) unnamed_addr #1 {
start:
  %0 = icmp eq i64 %layout.1, 0
  br i1 %0, label %bb2, label %bb1

bb2:                                              ; preds = %bb1, %start
  ret void

bb1:                                              ; preds = %start
; call __rustc::__rust_dealloc
  call void @_RNvCs9wFQrvczXsK_7___rustc14___rust_dealloc(ptr %ptr, i64 %layout.1, i64 %layout.0) #18
  br label %bb2
}

; <alloc::vec::Vec<core::ops::range::Range<layout_probe::AudioSample>> as core::ops::drop::Drop>::drop
; Function Attrs: uwtable
define internal void @_RNvXso_NtCslJsSqIQKwiA_5alloc3vecINtB5_3VecINtNtNtCsgtPOCBgevO_4core3ops5range5RangeNtCs5ggOHDaYt9z_12layout_probe11AudioSampleEENtNtBK_4drop4Drop4dropB1m_(ptr align 8 %self) unnamed_addr #2 {
start:
  %0 = getelementptr inbounds i8, ptr %self, i64 8
  %_5 = load ptr, ptr %0, align 8
  %1 = getelementptr inbounds i8, ptr %self, i64 16
  %len = load i64, ptr %1, align 8
  ret void
}

; <fn() as core::ops::function::FnOnce<()>>::call_once
; Function Attrs: inlinehint uwtable
define internal void @_RNvYFEuINtNtNtCsgtPOCBgevO_4core3ops8function6FnOnceuE9call_onceCs5ggOHDaYt9z_12layout_probe(ptr %_1) unnamed_addr #1 {
start:
  %_2 = alloca [0 x i8], align 1
  call void %_1()
  ret void
}

; <std::rt::lang_start<()>::{closure#0} as core::ops::function::FnOnce<()>>::call_once
; Function Attrs: inlinehint uwtable
define internal i32 @_RNvYNCINvNtCsa9BKTri5B3M_3std2rt10lang_startuE0INtNtNtCsgtPOCBgevO_4core3ops8function6FnOnceuE9call_onceCs5ggOHDaYt9z_12layout_probe(ptr %0) unnamed_addr #1 personality ptr @rust_eh_personality {
start:
  %1 = alloca [16 x i8], align 8
  %_2 = alloca [0 x i8], align 1
  %_1 = alloca [8 x i8], align 8
  store ptr %0, ptr %_1, align 8
; invoke std::rt::lang_start::<()>::{closure#0}
  %_0 = invoke i32 @_RNCINvNtCsa9BKTri5B3M_3std2rt10lang_startuE0Cs5ggOHDaYt9z_12layout_probe(ptr align 8 %_1)
          to label %bb1 unwind label %cleanup

bb3:                                              ; preds = %cleanup
  %2 = load ptr, ptr %1, align 8
  %3 = getelementptr inbounds i8, ptr %1, i64 8
  %4 = load i32, ptr %3, align 8
  %5 = insertvalue { ptr, i32 } poison, ptr %2, 0
  %6 = insertvalue { ptr, i32 } %5, i32 %4, 1
  resume { ptr, i32 } %6

cleanup:                                          ; preds = %start
  %7 = landingpad { ptr, i32 }
          cleanup
  %8 = extractvalue { ptr, i32 } %7, 0
  %9 = extractvalue { ptr, i32 } %7, 1
  store ptr %8, ptr %1, align 8
  %10 = getelementptr inbounds i8, ptr %1, i64 8
  store i32 %9, ptr %10, align 8
  br label %bb3

bb1:                                              ; preds = %start
  ret i32 %_0
}

; core::panicking::panic_misaligned_pointer_dereference
; Function Attrs: cold minsize noinline noreturn nounwind optsize uwtable
declare void @_RNvNtCsgtPOCBgevO_4core9panicking36panic_misaligned_pointer_dereference(i64, i64, ptr align 8) unnamed_addr #4

; core::panicking::panic_null_pointer_dereference
; Function Attrs: cold minsize noinline noreturn nounwind optsize uwtable
declare void @_RNvNtCsgtPOCBgevO_4core9panicking30panic_null_pointer_dereference(ptr align 8) unnamed_addr #4

; Function Attrs: nocallback nofree nounwind willreturn memory(argmem: readwrite)
declare void @llvm.memcpy.p0.p0.i64(ptr noalias writeonly captures(none), ptr noalias readonly captures(none), i64, i1 immarg) #5

; <usize as core::fmt::Display>::fmt
; Function Attrs: uwtable
declare zeroext i1 @_RNvXsi_NtNtNtCsgtPOCBgevO_4core3fmt3num3impjNtB9_7Display3fmt(ptr align 8, ptr align 8) unnamed_addr #2

; std::rt::lang_start_internal
; Function Attrs: uwtable
declare i64 @_RNvNtCsa9BKTri5B3M_3std2rt19lang_start_internal(ptr, ptr align 8, i64, ptr, i8) unnamed_addr #2

; Function Attrs: nounwind uwtable
declare i32 @rust_eh_personality(i32, i32, i64, ptr, ptr) unnamed_addr #6

; core::panicking::panic_in_cleanup
; Function Attrs: cold minsize noinline noreturn nounwind optsize uwtable
declare void @_RNvNtCsgtPOCBgevO_4core9panicking16panic_in_cleanup() unnamed_addr #4

; std::io::stdio::_print
; Function Attrs: uwtable
declare void @_RNvNtNtCsa9BKTri5B3M_3std2io5stdio6__print(ptr, ptr) unnamed_addr #2

; __rustc::__rust_no_alloc_shim_is_unstable_v2
; Function Attrs: nounwind uwtable
declare void @_RNvCs9wFQrvczXsK_7___rustc35___rust_no_alloc_shim_is_unstable_v2() unnamed_addr #6

; __rustc::__rust_alloc
; Function Attrs: nounwind allockind("alloc,uninitialized,aligned") allocsize(0) uwtable
declare noalias ptr @_RNvCs9wFQrvczXsK_7___rustc12___rust_alloc(i64, i64 allocalign) unnamed_addr #7

; __rustc::__rust_alloc_zeroed
; Function Attrs: nounwind allockind("alloc,zeroed,aligned") allocsize(0) uwtable
declare noalias ptr @_RNvCs9wFQrvczXsK_7___rustc19___rust_alloc_zeroed(i64, i64 allocalign) unnamed_addr #8

; alloc::alloc::handle_alloc_error
; Function Attrs: cold minsize noreturn optsize uwtable
declare void @_RNvNtCslJsSqIQKwiA_5alloc5alloc18handle_alloc_error(i64, i64) unnamed_addr #9

; core::panicking::panic_fmt
; Function Attrs: cold noinline noreturn uwtable
declare void @_RNvNtCsgtPOCBgevO_4core9panicking9panic_fmt(ptr, ptr, ptr align 8) unnamed_addr #10

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i64 @llvm.ctpop.i64(i64) #11

; core::panicking::panic_nounwind_fmt
; Function Attrs: cold noinline noreturn nounwind uwtable
declare void @_RNvNtCsgtPOCBgevO_4core9panicking18panic_nounwind_fmt(ptr, ptr, i1 zeroext, ptr align 8) unnamed_addr #12

; <alloc::raw_vec::RawVecInner>::deallocate
; Function Attrs: uwtable
declare void @_RNvMs2_NtCslJsSqIQKwiA_5alloc7raw_vecNtB5_11RawVecInner10deallocateCsjevKHkJAzVy_5gimli(ptr align 8, i64, i64) unnamed_addr #2

; __rustc::__rust_dealloc
; Function Attrs: nounwind allockind("free") uwtable
declare void @_RNvCs9wFQrvczXsK_7___rustc14___rust_dealloc(ptr allocptr captures(address), i64, i64) unnamed_addr #13

define i32 @main(i32 %0, ptr %1) unnamed_addr #14 {
top:
  %2 = sext i32 %0 to i64
; call std::rt::lang_start::<()>
  %3 = call i64 @_RINvNtCsa9BKTri5B3M_3std2rt10lang_startuECs5ggOHDaYt9z_12layout_probe(ptr @_RNvCs5ggOHDaYt9z_12layout_probe4main, i64 %2, ptr %1, i8 0)
  %4 = trunc i64 %3 to i32
  ret i32 %4
}

attributes #0 = { noinline uwtable "frame-pointer"="non-leaf" "probe-stack"="inline-asm" "target-cpu"="apple-m1" }
attributes #1 = { inlinehint uwtable "frame-pointer"="non-leaf" "probe-stack"="inline-asm" "target-cpu"="apple-m1" }
attributes #2 = { uwtable "frame-pointer"="non-leaf" "probe-stack"="inline-asm" "target-cpu"="apple-m1" }
attributes #3 = { inlinehint nounwind uwtable "frame-pointer"="non-leaf" "probe-stack"="inline-asm" "target-cpu"="apple-m1" }
attributes #4 = { cold minsize noinline noreturn nounwind optsize uwtable "frame-pointer"="non-leaf" "probe-stack"="inline-asm" "target-cpu"="apple-m1" }
attributes #5 = { nocallback nofree nounwind willreturn memory(argmem: readwrite) }
attributes #6 = { nounwind uwtable "frame-pointer"="non-leaf" "probe-stack"="inline-asm" "target-cpu"="apple-m1" }
attributes #7 = { nounwind allockind("alloc,uninitialized,aligned") allocsize(0) uwtable "alloc-family"="__rust_alloc" "alloc-variant-zeroed"="_RNvCs9wFQrvczXsK_7___rustc19___rust_alloc_zeroed" "frame-pointer"="non-leaf" "probe-stack"="inline-asm" "target-cpu"="apple-m1" }
attributes #8 = { nounwind allockind("alloc,zeroed,aligned") allocsize(0) uwtable "alloc-family"="__rust_alloc" "frame-pointer"="non-leaf" "probe-stack"="inline-asm" "target-cpu"="apple-m1" }
attributes #9 = { cold minsize noreturn optsize uwtable "frame-pointer"="non-leaf" "probe-stack"="inline-asm" "target-cpu"="apple-m1" }
attributes #10 = { cold noinline noreturn uwtable "frame-pointer"="non-leaf" "probe-stack"="inline-asm" "target-cpu"="apple-m1" }
attributes #11 = { nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none) }
attributes #12 = { cold noinline noreturn nounwind uwtable "frame-pointer"="non-leaf" "probe-stack"="inline-asm" "target-cpu"="apple-m1" }
attributes #13 = { nounwind allockind("free") uwtable "alloc-family"="__rust_alloc" "frame-pointer"="non-leaf" "probe-stack"="inline-asm" "target-cpu"="apple-m1" }
attributes #14 = { "frame-pointer"="non-leaf" "target-cpu"="apple-m1" }
attributes #15 = { noreturn nounwind }
attributes #16 = { cold }
attributes #17 = { cold noreturn nounwind }
attributes #18 = { nounwind }
attributes #19 = { noreturn }

!llvm.module.flags = !{!0, !1}
!llvm.ident = !{!2}

!0 = !{i32 8, !"PIC Level", i32 2}
!1 = !{i32 7, !"PIE Level", i32 2}
!2 = !{!"rustc version 1.97.1 (8bab26f4f 2026-07-14)"}
!3 = !{i64 19547920882037400}
