# Account/output contract, short form

Recommended first unit: own only the public PointDomainAudioBlock.suppressed
mapping destination. Internal SignalBlock/ReadBlock/transfer masks remain
ordinary and explicitly outside this checkpoint. This is real runtime
activation; Point policy admission and internal charge transfer remain owed.

1. StageAudio owns lazy Account{Option<Handle>}; Handle privately wraps
   Option<Arc<AccountData>>. AccountData contains only live_frames: AtomicU64.
   Output Charge owns a private Handle and exact u64 frames. No Arc/Weak
   escape, public mutation, deep Clone, or generic public IntoIterator.

2. Pinned rustc1.97.1 aarch64 actual Arc::new requests Layout24/align8 for
   AccountData8: two atomic usize counters plus data. Compute this Layout
   before allocation. Parent control.check/make_room(3frames), then allocate
   and install live=3 in a closed no-fail tail. Legacy Plain never initializes it.

3. New nonempty mapping: checked Layout::array::<Range<ReferenceSample>>(n)
   plus Layout::new::<Storage<ReferenceSample>>()40. Host admits full payload
   while prior outputs/shell remain counted, then account fetch_add reserves
   exact frames before either allocation. Never store a captured next total.

4. Declare Charge first, then allocate Vec capacity n. Retain the original
   ordinary SignalSample Vec throughout checked reference_at_signal mapping.
   On failure destination Vec drops before Charge. After success allocate
   Box<Storage{ranges,ticket}>. The same ticket covers both real allocations.
   Empty output can be allocation-free Plain.

5. Sole mutable StageAudio is the only publisher; concurrent output drops only
   fetch_sub. A checked preflight can become conservative as drops happen,
   never unsafe. Include live_frames in every residency/prediction/publication
   sum. Preserve the old work receipt; new fees cannot become canonical policy work.

6. Owned wrapper stores Option<Box<Storage>> and owns Drop; outer Mask has no
   Drop. Option::take Box, call safe noinline unbox(b)->T{*b}, drop Vec, then
   Charge. Pinned MIR+LLVM confirm Box freed before helper return.
   Charge subtracts payload frames before dropping its Handle.

7. Every Handle Drop calls Arc::into_inner. No ordinary Arc or Weak escape.
   Final extraction has already freed actual Arc shell; only then retire its
   three-frame charge from the extracted stack counter. At that point exactly
   shell frames must remain. No self-Arc or abstract escrow.

8. Capacity-changing replacement admits complete destination Box+Vec while
   every old owner lives. Coalesce in place; shorter length does not refund
   retained capacity. Publish replacement before physically dropping inputs.
   Plain helpers retain original Vec bodies/iterator types and collect reuse.

9. Future allocation-free source transfer can preallocate Box<Option<Storage>>
   as None under a real shell guard, then install Some in sealed no-fail commit.
   This payload is40 bytes too. Box<Storage{Vec,Option<Charge>}> is48 and allows
   a nonempty uncharged Vec state, so avoid it. Current public-copy unit needs
   no prepared placeholder.

Layout is qualified for pinned host only; quota correctness still depends on
the sealed parent's admission callsites. Exact old26 native regressions, real
output-after-controller/cross-request pressure, concurrent final-drop and
map/refusal cleanup tests remain required. No goldens/caps/counter normalization.

Full detail: account-reservation-contract.md. Proofs: account-layout-probe.rs,
.mir, .ll, .stdout, account-layout-rustc.txt and account-contract-pins.json.
