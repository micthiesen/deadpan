; ModuleID = 'account_layout_probe.2b78432631c35b7b-cgu.0'
source_filename = "account_layout_probe.2b78432631c35b7b-cgu.0"
target datalayout = "e-m:o-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-n32:64-S128-Fn32"
target triple = "arm64-apple-macosx11.0.0"

%"core::fmt::rt::Argument<'_>" = type { %"core::fmt::rt::ArgumentType<'_>" }
%"core::fmt::rt::ArgumentType<'_>" = type { ptr, [1 x i64] }

@vtable.0 = private unnamed_addr constant <{ [24 x i8], ptr, ptr, ptr }> <{ [24 x i8] c"\00\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00", ptr @_RNSNvYNCINvNtCsa9BKTri5B3M_3std2rt10lang_startuE0INtNtNtCsgtPOCBgevO_4core3ops8function6FnOnceuE9call_once6vtableCs3Jo5JWeNlGx_20account_layout_probe, ptr @_RNCINvNtCsa9BKTri5B3M_3std2rt10lang_startuE0Cs3Jo5JWeNlGx_20account_layout_probe, ptr @_RNCINvNtCsa9BKTri5B3M_3std2rt10lang_startuE0Cs3Jo5JWeNlGx_20account_layout_probe }>, align 8
@alloc_eecf79bdd864d42c7684ee401169f874 = private unnamed_addr constant [82 x i8] c"/tmp/deadpan-point-policy-output-design-review-2026-10-31/account-layout-probe.rs\00", align 1
@alloc_aef890203b0be7aaedef1af2da49abbb = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_eecf79bdd864d42c7684ee401169f874, [16 x i8] c"Q\00\00\00\00\00\00\00)\00\00\00?\00\00\00" }>, align 8
@alloc_381a7855202e08b2725fc041e3c0d1cc = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_eecf79bdd864d42c7684ee401169f874, [16 x i8] c"Q\00\00\00\00\00\00\00)\00\00\00H\00\00\00" }>, align 8
@alloc_a30fbd7ee764311b5438e9cf554fd24e = private unnamed_addr constant [8 x i8] c"\08\00\00\00\00\00\00\00", align 8
@alloc_492a4481e302e20096f3cf6d1501b511 = private unnamed_addr constant [31 x i8] c"\11AccountData size=\C0\07 align=\C0\01\0A\00", align 1
@alloc_b1a1c27c6d41023e30ee48eec611ccbe = private unnamed_addr constant [8 x i8] c"\18\00\00\00\00\00\00\00", align 8
@alloc_3e54cbba07e61d7952782682c8e27b03 = private unnamed_addr constant [38 x i8] c"\18AccountShellLayout size=\C0\07 align=\C0\01\0A\00", align 1
@alloc_df17e820ce44158ea0e0da3efd1d9c70 = private unnamed_addr constant [26 x i8] c"\0CHandle size=\C0\07 align=\C0\01\0A\00", align 1
@alloc_87930ff84f26c4dc0d3a344636709737 = private unnamed_addr constant [8 x i8] c"\10\00\00\00\00\00\00\00", align 8
@alloc_d30d101b877a6637e732fae7636f8260 = private unnamed_addr constant [26 x i8] c"\0CCharge size=\C0\07 align=\C0\01\0A\00", align 1
@alloc_9e22e40936c246bd6aef8ceff10913b5 = private unnamed_addr constant [34 x i8] c"\14Option<Charge> size=\C0\07 align=\C0\01\0A\00", align 1
@alloc_6a05004c5f69d0e521e3f36abd3957a3 = private unnamed_addr constant [8 x i8] c"(\00\00\00\00\00\00\00", align 8
@alloc_72e5f099c1da7486163215b481af1360 = private unnamed_addr constant [32 x i8] c"\12Storage<i64> size=\C0\07 align=\C0\01\0A\00", align 1
@alloc_118c437227d8fe2518affbdad1d36b50 = private unnamed_addr constant [40 x i8] c"\1AOption<Storage<i64>> size=\C0\07 align=\C0\01\0A\00", align 1
@alloc_28b4525213e621d91e2b40299762a7fc = private unnamed_addr constant [8 x i8] c"0\00\00\00\00\00\00\00", align 8
@alloc_f4328527bada43b73f18a9c2194e29a5 = private unnamed_addr constant [46 x i8] c" StorageOptionalCharge<i64> size=\C0\07 align=\C0\01\0A\00", align 1
@alloc_4fcc5b5debf291c6560aa9668a3f798a = private unnamed_addr constant [29 x i8] c"\0FMask<i64> size=\C0\07 align=\C0\01\0A\00", align 1
@alloc_25aa2ec3bdbab5819bc19fee38d8640b = private unnamed_addr constant [37 x i8] c"\17MaskPrepared<i64> size=\C0\07 align=\C0\01\0A\00", align 1
@alloc_a1f7b75ef8dd5626c3f5ae0cf21a37d7 = private unnamed_addr constant [43 x i8] c"\1DMaskOptionalTicket<i64> size=\C0\07 align=\C0\01\0A\00", align 1
@vtable.1 = private unnamed_addr constant <{ [24 x i8], ptr }> <{ [24 x i8] c"\00\00\00\00\00\00\00\00\01\00\00\00\00\00\00\00\01\00\00\00\00\00\00\00", ptr @_RNvXs6_NtNtCsgtPOCBgevO_4core3num5errorNtB5_15TryFromIntErrorNtNtB9_3fmt5Debug3fmtCs3Jo5JWeNlGx_20account_layout_probe }>, align 8
@alloc_00ae4b301f7fab8ac9617c03fcbd7274 = private unnamed_addr constant [43 x i8] c"called `Result::unwrap()` on an `Err` value", align 1
@alloc_29f3d0da34f44a1b2e1ac3f11dfc75b8 = private unnamed_addr constant [81 x i8] c"/rustc/8bab26f4f68e0e26f0bb7960be334d5b520ea452/library/core/src/ptr/non_null.rs\00", align 1
@alloc_8d5a0ee98b8cdf2f5afa900e7e86c059 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_29f3d0da34f44a1b2e1ac3f11dfc75b8, [16 x i8] c"P\00\00\00\00\00\00\00\A7\05\00\00\12\00\00\00" }>, align 8
@anon.78236e53da2646531455d85acb4a15f4.0 = private unnamed_addr constant <{ [8 x i8], [8 x i8] }> <{ [8 x i8] zeroinitializer, [8 x i8] undef }>, align 8
@alloc_5ff1c8aa34f46974b9857da735e490e2 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_29f3d0da34f44a1b2e1ac3f11dfc75b8, [16 x i8] c"P\00\00\00\00\00\00\00\0D\01\00\00\1B\00\00\00" }>, align 8
@alloc_929e9b2e7b7429614ca4fc017efff666 = private unnamed_addr constant [41 x i8] c"there is no such thing as a relaxed fence", align 1
@alloc_313179c4ebce8162b6e6b899782d13de = private unnamed_addr constant [80 x i8] c"/rustc/8bab26f4f68e0e26f0bb7960be334d5b520ea452/library/core/src/sync/atomic.rs\00", align 1
@alloc_51bc672182609c8619102955545c9936 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_313179c4ebce8162b6e6b899782d13de, [16 x i8] c"O\00\00\00\00\00\00\00'\11\00\00\18\00\00\00" }>, align 8
@alloc_0625062a5eee489a7813ee965a38d15a = private unnamed_addr constant [198 x i8] c"unsafe precondition(s) violated: Alignment::new_unchecked requires a power of two\0A\0AThis indicates a bug in the program. This Undefined Behavior check is optional, and cannot be relied on for safety.", align 1
@alloc_8cf3531fd3c828ab298b686071a40c17 = private unnamed_addr constant [259 x i8] c"unsafe precondition(s) violated: Layout::from_size_alignment_unchecked requires that the rounded-up allocation size does not exceed isize::MAX\0A\0AThis indicates a bug in the program. This Undefined Behavior check is optional, and cannot be relied on for safety.", align 1
@alloc_560a59ed819b9d9a5841f6e731c4c8e5 = private unnamed_addr constant [210 x i8] c"unsafe precondition(s) violated: NonNull::new_unchecked requires that the pointer is non-null\0A\0AThis indicates a bug in the program. This Undefined Behavior check is optional, and cannot be relied on for safety.", align 1
@vtable.2 = private unnamed_addr constant <{ [24 x i8], ptr }> <{ [24 x i8] c"\00\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00", ptr @_RNvXs1g_NtCsgtPOCBgevO_4core3fmtRNtNtNtB8_3num5error12IntErrorKindNtB6_5Debug3fmtCs1mTuhq77BFi_14rustc_demangle }>, align 8
@alloc_5cb263f26a5d50117adfcc5c7225745e = private unnamed_addr constant [15 x i8] c"TryFromIntError", align 1
@alloc_3535064d29b1815564de3b8811671deb = private unnamed_addr constant [82 x i8] c"/rustc/8bab26f4f68e0e26f0bb7960be334d5b520ea452/library/core/src/mem/alignment.rs\00", align 1
@alloc_94ac603a76bcb1c7cd512525db170514 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_3535064d29b1815564de3b8811671deb, [16 x i8] c"Q\00\00\00\00\00\00\00\7F\00\00\00\12\00\00\00" }>, align 8
@alloc_9bba1da638456c1bff660b3ae7593675 = private unnamed_addr constant [81 x i8] c"/rustc/8bab26f4f68e0e26f0bb7960be334d5b520ea452/library/core/src/alloc/layout.rs\00", align 1
@alloc_632d33230a33b678beb09f7f8dd3a0db = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_9bba1da638456c1bff660b3ae7593675, [16 x i8] c"P\00\00\00\00\00\00\00\01\01\00\00\12\00\00\00" }>, align 8
@alloc_bb47e1cb3d6132880125efe73e3158a6 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_eecf79bdd864d42c7684ee401169f874, [16 x i8] c"Q\00\00\00\00\00\00\00#\00\00\00\11\00\00\00" }>, align 8

; <core::fmt::rt::Argument>::new_display::<usize>
; Function Attrs: inlinehint uwtable
define internal void @_RINvMNtNtCsgtPOCBgevO_4core3fmt2rtNtB3_8Argument11new_displayjECs3Jo5JWeNlGx_20account_layout_probe(ptr sret([16 x i8]) align 8 %_0, ptr align 8 %x) unnamed_addr #0 {
start:
  %_2 = alloca [16 x i8], align 8
  store ptr %x, ptr %_2, align 8
  %0 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr @_RNvXsi_NtNtNtCsgtPOCBgevO_4core3fmt3num3impjNtB9_7Display3fmt, ptr %0, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_0, ptr align 8 %_2, i64 16, i1 false)
  ret void
}

; <core::alloc::layout::Layout>::new::<account_layout_probe::AccountShellLayout>
; Function Attrs: inlinehint uwtable
define internal { i64, i64 } @_RINvMNtNtCsgtPOCBgevO_4core5alloc6layoutNtB3_6Layout3newNtCs3Jo5JWeNlGx_20account_layout_probe18AccountShellLayoutEBU_() unnamed_addr #0 {
start:
  ret { i64, i64 } { i64 8, i64 24 }
}

; <core::fmt::Arguments>::new::<26, 2>
; Function Attrs: inlinehint uwtable
define internal { ptr, ptr } @_RINvMs2_NtCsgtPOCBgevO_4core3fmtNtB6_9Arguments3newKj1a_Kj2_ECs3Jo5JWeNlGx_20account_layout_probe(ptr %template, ptr align 8 %args) unnamed_addr #0 {
start:
  %0 = insertvalue { ptr, ptr } poison, ptr %template, 0
  %1 = insertvalue { ptr, ptr } %0, ptr %args, 1
  ret { ptr, ptr } %1
}

; <core::fmt::Arguments>::new::<29, 2>
; Function Attrs: inlinehint uwtable
define internal { ptr, ptr } @_RINvMs2_NtCsgtPOCBgevO_4core3fmtNtB6_9Arguments3newKj1d_Kj2_ECs3Jo5JWeNlGx_20account_layout_probe(ptr %template, ptr align 8 %args) unnamed_addr #0 {
start:
  %0 = insertvalue { ptr, ptr } poison, ptr %template, 0
  %1 = insertvalue { ptr, ptr } %0, ptr %args, 1
  ret { ptr, ptr } %1
}

; <core::fmt::Arguments>::new::<31, 2>
; Function Attrs: inlinehint uwtable
define internal { ptr, ptr } @_RINvMs2_NtCsgtPOCBgevO_4core3fmtNtB6_9Arguments3newKj1f_Kj2_ECs3Jo5JWeNlGx_20account_layout_probe(ptr %template, ptr align 8 %args) unnamed_addr #0 {
start:
  %0 = insertvalue { ptr, ptr } poison, ptr %template, 0
  %1 = insertvalue { ptr, ptr } %0, ptr %args, 1
  ret { ptr, ptr } %1
}

; <core::fmt::Arguments>::new::<32, 2>
; Function Attrs: inlinehint uwtable
define internal { ptr, ptr } @_RINvMs2_NtCsgtPOCBgevO_4core3fmtNtB6_9Arguments3newKj20_Kj2_ECs3Jo5JWeNlGx_20account_layout_probe(ptr %template, ptr align 8 %args) unnamed_addr #0 {
start:
  %0 = insertvalue { ptr, ptr } poison, ptr %template, 0
  %1 = insertvalue { ptr, ptr } %0, ptr %args, 1
  ret { ptr, ptr } %1
}

; <core::fmt::Arguments>::new::<34, 2>
; Function Attrs: inlinehint uwtable
define internal { ptr, ptr } @_RINvMs2_NtCsgtPOCBgevO_4core3fmtNtB6_9Arguments3newKj22_Kj2_ECs3Jo5JWeNlGx_20account_layout_probe(ptr %template, ptr align 8 %args) unnamed_addr #0 {
start:
  %0 = insertvalue { ptr, ptr } poison, ptr %template, 0
  %1 = insertvalue { ptr, ptr } %0, ptr %args, 1
  ret { ptr, ptr } %1
}

; <core::fmt::Arguments>::new::<37, 2>
; Function Attrs: inlinehint uwtable
define internal { ptr, ptr } @_RINvMs2_NtCsgtPOCBgevO_4core3fmtNtB6_9Arguments3newKj25_Kj2_ECs3Jo5JWeNlGx_20account_layout_probe(ptr %template, ptr align 8 %args) unnamed_addr #0 {
start:
  %0 = insertvalue { ptr, ptr } poison, ptr %template, 0
  %1 = insertvalue { ptr, ptr } %0, ptr %args, 1
  ret { ptr, ptr } %1
}

; <core::fmt::Arguments>::new::<38, 2>
; Function Attrs: inlinehint uwtable
define internal { ptr, ptr } @_RINvMs2_NtCsgtPOCBgevO_4core3fmtNtB6_9Arguments3newKj26_Kj2_ECs3Jo5JWeNlGx_20account_layout_probe(ptr %template, ptr align 8 %args) unnamed_addr #0 {
start:
  %0 = insertvalue { ptr, ptr } poison, ptr %template, 0
  %1 = insertvalue { ptr, ptr } %0, ptr %args, 1
  ret { ptr, ptr } %1
}

; <core::fmt::Arguments>::new::<40, 2>
; Function Attrs: inlinehint uwtable
define internal { ptr, ptr } @_RINvMs2_NtCsgtPOCBgevO_4core3fmtNtB6_9Arguments3newKj28_Kj2_ECs3Jo5JWeNlGx_20account_layout_probe(ptr %template, ptr align 8 %args) unnamed_addr #0 {
start:
  %0 = insertvalue { ptr, ptr } poison, ptr %template, 0
  %1 = insertvalue { ptr, ptr } %0, ptr %args, 1
  ret { ptr, ptr } %1
}

; <core::fmt::Arguments>::new::<43, 2>
; Function Attrs: inlinehint uwtable
define internal { ptr, ptr } @_RINvMs2_NtCsgtPOCBgevO_4core3fmtNtB6_9Arguments3newKj2b_Kj2_ECs3Jo5JWeNlGx_20account_layout_probe(ptr %template, ptr align 8 %args) unnamed_addr #0 {
start:
  %0 = insertvalue { ptr, ptr } poison, ptr %template, 0
  %1 = insertvalue { ptr, ptr } %0, ptr %args, 1
  ret { ptr, ptr } %1
}

; <core::fmt::Arguments>::new::<46, 2>
; Function Attrs: inlinehint uwtable
define internal { ptr, ptr } @_RINvMs2_NtCsgtPOCBgevO_4core3fmtNtB6_9Arguments3newKj2e_Kj2_ECs3Jo5JWeNlGx_20account_layout_probe(ptr %template, ptr align 8 %args) unnamed_addr #0 {
start:
  %0 = insertvalue { ptr, ptr } poison, ptr %template, 0
  %1 = insertvalue { ptr, ptr } %0, ptr %args, 1
  ret { ptr, ptr } %1
}

; std::rt::lang_start::<()>
; Function Attrs: uwtable
define hidden i64 @_RINvNtCsa9BKTri5B3M_3std2rt10lang_startuECs3Jo5JWeNlGx_20account_layout_probe(ptr %main, i64 %argc, ptr %argv, i8 %sigpipe) unnamed_addr #1 {
start:
  %_7 = alloca [8 x i8], align 8
  store ptr %main, ptr %_7, align 8
; call std::rt::lang_start_internal
  %_0 = call i64 @_RNvNtCsa9BKTri5B3M_3std2rt19lang_start_internal(ptr %_7, ptr align 8 @vtable.0, i64 %argc, ptr %argv, i8 %sigpipe)
  ret i64 %_0
}

; core::mem::drop::<account_layout_probe::Handle>
; Function Attrs: inlinehint uwtable
define internal void @_RINvNtCsgtPOCBgevO_4core3mem4dropNtCs3Jo5JWeNlGx_20account_layout_probe6HandleEBx_(ptr %0) unnamed_addr #0 {
start:
  %_x = alloca [8 x i8], align 8
  store ptr %0, ptr %_x, align 8
; call core::ptr::drop_glue::<account_layout_probe::Handle>
  call void @_RINvNtCsgtPOCBgevO_4core3ptr9drop_glueNtCs3Jo5JWeNlGx_20account_layout_probe6HandleEBC_(ptr align 8 %_x)
  ret void
}

; core::ptr::drop_glue::<core::option::Option<alloc::sync::Arc<account_layout_probe::AccountData>>>
; Function Attrs: uwtable
define internal void @_RINvNtCsgtPOCBgevO_4core3ptr9drop_glueINtNtB4_6option6OptionINtNtCslJsSqIQKwiA_5alloc4sync3ArcNtCs3Jo5JWeNlGx_20account_layout_probe11AccountDataEEEB1w_(ptr align 8 %_1) unnamed_addr #1 {
start:
  %0 = load ptr, ptr %_1, align 8
  %1 = ptrtoint ptr %0 to i64
  %2 = icmp eq i64 %1, 0
  %_2 = select i1 %2, i64 0, i64 1
  %3 = icmp eq i64 %_2, 0
  br i1 %3, label %bb1, label %bb2

bb1:                                              ; preds = %bb2, %start
  ret void

bb2:                                              ; preds = %start
; call core::ptr::drop_glue::<alloc::sync::Arc<account_layout_probe::AccountData>>
  call void @_RINvNtCsgtPOCBgevO_4core3ptr9drop_glueINtNtCslJsSqIQKwiA_5alloc4sync3ArcNtCs3Jo5JWeNlGx_20account_layout_probe11AccountDataEEB1a_(ptr align 8 %_1)
  br label %bb1
}

; core::ptr::drop_glue::<alloc::sync::Arc<account_layout_probe::AccountData>>
; Function Attrs: uwtable
define internal void @_RINvNtCsgtPOCBgevO_4core3ptr9drop_glueINtNtCslJsSqIQKwiA_5alloc4sync3ArcNtCs3Jo5JWeNlGx_20account_layout_probe11AccountDataEEB1a_(ptr align 8 %_1) unnamed_addr #1 {
start:
; call <alloc::sync::Arc<account_layout_probe::AccountData> as core::ops::drop::Drop>::drop
  call void @_RNvXsD_NtCslJsSqIQKwiA_5alloc4syncINtB5_3ArcNtCs3Jo5JWeNlGx_20account_layout_probe11AccountDataENtNtNtCsgtPOCBgevO_4core3ops4drop4Drop4dropBI_(ptr align 8 %_1)
  ret void
}

; core::ptr::drop_glue::<alloc::sync::Weak<account_layout_probe::AccountData>>
; Function Attrs: uwtable
define internal void @_RINvNtCsgtPOCBgevO_4core3ptr9drop_glueINtNtCslJsSqIQKwiA_5alloc4sync4WeakNtCs3Jo5JWeNlGx_20account_layout_probe11AccountDataEEB1b_(ptr align 8 %_1) unnamed_addr #1 {
start:
; call <alloc::sync::Weak<account_layout_probe::AccountData> as core::ops::drop::Drop>::drop
  call void @_RNvXsN_NtCslJsSqIQKwiA_5alloc4syncINtB5_4WeakNtCs3Jo5JWeNlGx_20account_layout_probe11AccountDataENtNtNtCsgtPOCBgevO_4core3ops4drop4Drop4dropBJ_(ptr align 8 %_1)
  ret void
}

; core::ptr::drop_glue::<alloc::sync::Weak<account_layout_probe::AccountData, &alloc::alloc::Global>>
; Function Attrs: uwtable
define internal void @_RINvNtCsgtPOCBgevO_4core3ptr9drop_glueINtNtCslJsSqIQKwiA_5alloc4sync4WeakNtCs3Jo5JWeNlGx_20account_layout_probe11AccountDataRNtNtBF_5alloc6GlobalEEB1b_(ptr align 8 %_1) unnamed_addr #1 {
start:
; call <alloc::sync::Weak<account_layout_probe::AccountData, &alloc::alloc::Global> as core::ops::drop::Drop>::drop
  call void @_RNvXsN_NtCslJsSqIQKwiA_5alloc4syncINtB5_4WeakNtCs3Jo5JWeNlGx_20account_layout_probe11AccountDataRNtNtB7_5alloc6GlobalENtNtNtCsgtPOCBgevO_4core3ops4drop4Drop4dropBJ_(ptr align 8 %_1)
  ret void
}

; core::ptr::drop_glue::<account_layout_probe::Handle>
; Function Attrs: uwtable
define internal void @_RINvNtCsgtPOCBgevO_4core3ptr9drop_glueNtCs3Jo5JWeNlGx_20account_layout_probe6HandleEBC_(ptr align 8 %_1) unnamed_addr #1 personality ptr @rust_eh_personality {
start:
  %0 = alloca [16 x i8], align 8
; invoke <account_layout_probe::Handle as core::ops::drop::Drop>::drop
  invoke void @_RNvXs_Cs3Jo5JWeNlGx_20account_layout_probeNtB4_6HandleNtNtNtCsgtPOCBgevO_4core3ops4drop4Drop4drop(ptr align 8 %_1)
          to label %bb4 unwind label %cleanup

bb3:                                              ; preds = %cleanup
; invoke core::ptr::drop_glue::<core::option::Option<alloc::sync::Arc<account_layout_probe::AccountData>>>
  invoke void @_RINvNtCsgtPOCBgevO_4core3ptr9drop_glueINtNtB4_6option6OptionINtNtCslJsSqIQKwiA_5alloc4sync3ArcNtCs3Jo5JWeNlGx_20account_layout_probe11AccountDataEEEB1w_(ptr align 8 %_1) #16
          to label %bb1 unwind label %terminate

cleanup:                                          ; preds = %start
  %1 = landingpad { ptr, i32 }
          cleanup
  %2 = extractvalue { ptr, i32 } %1, 0
  %3 = extractvalue { ptr, i32 } %1, 1
  store ptr %2, ptr %0, align 8
  %4 = getelementptr inbounds i8, ptr %0, i64 8
  store i32 %3, ptr %4, align 8
  br label %bb3

bb4:                                              ; preds = %start
; call core::ptr::drop_glue::<core::option::Option<alloc::sync::Arc<account_layout_probe::AccountData>>>
  call void @_RINvNtCsgtPOCBgevO_4core3ptr9drop_glueINtNtB4_6option6OptionINtNtCslJsSqIQKwiA_5alloc4sync3ArcNtCs3Jo5JWeNlGx_20account_layout_probe11AccountDataEEEB1w_(ptr align 8 %_1)
  ret void

terminate:                                        ; preds = %bb3
  %5 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_in_cleanup
  call void @_RNvNtCsgtPOCBgevO_4core9panicking16panic_in_cleanup() #17
  unreachable

bb1:                                              ; preds = %bb3
  %6 = load ptr, ptr %0, align 8
  %7 = getelementptr inbounds i8, ptr %0, i64 8
  %8 = load i32, ptr %7, align 8
  %9 = insertvalue { ptr, i32 } poison, ptr %6, 0
  %10 = insertvalue { ptr, i32 } %9, i32 %8, 1
  resume { ptr, i32 } %10
}

; std::sys::backtrace::__rust_begin_short_backtrace::<fn(), ()>
; Function Attrs: noinline uwtable
define internal void @_RINvNtNtCsa9BKTri5B3M_3std3sys9backtrace28___rust_begin_short_backtraceFEuuECs3Jo5JWeNlGx_20account_layout_probe(ptr %f) unnamed_addr #2 {
start:
; call <fn() as core::ops::function::FnOnce<()>>::call_once
  call void @_RNvYFEuINtNtNtCsgtPOCBgevO_4core3ops8function6FnOnceuE9call_onceCs3Jo5JWeNlGx_20account_layout_probe(ptr %f)
  call void asm sideeffect "", "~{memory}"(), !srcloc !3
  ret void
}

; std::rt::lang_start::<()>::{closure#0}
; Function Attrs: inlinehint uwtable
define internal i32 @_RNCINvNtCsa9BKTri5B3M_3std2rt10lang_startuE0Cs3Jo5JWeNlGx_20account_layout_probe(ptr align 8 %_1) unnamed_addr #0 {
start:
  %_4 = load ptr, ptr %_1, align 8
; call std::sys::backtrace::__rust_begin_short_backtrace::<fn(), ()>
  call void @_RINvNtNtCsa9BKTri5B3M_3std3sys9backtrace28___rust_begin_short_backtraceFEuuECs3Jo5JWeNlGx_20account_layout_probe(ptr %_4)
; call <() as std::process::Termination>::report
  %self = call i8 @_RNvXsZ_NtCsa9BKTri5B3M_3std7processuNtB5_11Termination6reportCs3Jo5JWeNlGx_20account_layout_probe()
  %_0 = zext i8 %self to i32
  ret i32 %_0
}

; <std::rt::lang_start<()>::{closure#0} as core::ops::function::FnOnce<()>>::call_once::{shim:vtable#0}
; Function Attrs: inlinehint uwtable
define internal i32 @_RNSNvYNCINvNtCsa9BKTri5B3M_3std2rt10lang_startuE0INtNtNtCsgtPOCBgevO_4core3ops8function6FnOnceuE9call_once6vtableCs3Jo5JWeNlGx_20account_layout_probe(ptr %_1) unnamed_addr #0 {
start:
  %_2 = alloca [0 x i8], align 1
  %0 = load ptr, ptr %_1, align 8
; call <std::rt::lang_start<()>::{closure#0} as core::ops::function::FnOnce<()>>::call_once
  %_0 = call i32 @_RNvYNCINvNtCsa9BKTri5B3M_3std2rt10lang_startuE0INtNtNtCsgtPOCBgevO_4core3ops8function6FnOnceuE9call_onceCs3Jo5JWeNlGx_20account_layout_probe(ptr %0)
  ret i32 %_0
}

; account_layout_probe::account_shell_frames
; Function Attrs: uwtable
define internal i64 @_RNvCs3Jo5JWeNlGx_20account_layout_probe20account_shell_frames() unnamed_addr #1 personality ptr @rust_eh_personality {
start:
  %0 = alloca [16 x i8], align 8
  %e.i = alloca [1 x i8], align 1
  %_5 = alloca [16 x i8], align 8
  %_2 = alloca [16 x i8], align 8
; call <core::alloc::layout::Layout>::new::<account_layout_probe::AccountShellLayout>
  %1 = call { i64, i64 } @_RINvMNtNtCsgtPOCBgevO_4core5alloc6layoutNtB3_6Layout3newNtCs3Jo5JWeNlGx_20account_layout_probe18AccountShellLayoutEBU_()
  %2 = extractvalue { i64, i64 } %1, 0
  %3 = extractvalue { i64, i64 } %1, 1
  store i64 %2, ptr %_5, align 8
  %4 = getelementptr inbounds i8, ptr %_5, i64 8
  store i64 %3, ptr %4, align 8
; call <core::alloc::layout::Layout>::size
  %_3 = call i64 @_RNvMNtNtCsgtPOCBgevO_4core5alloc6layoutNtB2_6Layout4sizeCs3Jo5JWeNlGx_20account_layout_probe(ptr align 8 %_5)
; call <u64 as core::convert::TryFrom<usize>>::try_from
  call void @_RNvXs1_NtNtNtCsgtPOCBgevO_4core7convert3num18ptr_try_from_implsyINtB9_7TryFromjE8try_fromCs3Jo5JWeNlGx_20account_layout_probe(ptr sret([16 x i8]) align 8 %_2, i64 %_3)
  %5 = load i8, ptr %_2, align 8
  %6 = trunc nuw i8 %5 to i1
  %_2.i = zext i1 %6 to i64
  br i1 %6, label %bb2.i, label %_RNvMNtCsgtPOCBgevO_4core6resultINtB2_6ResultyNtNtNtB4_3num5error15TryFromIntErrorE6unwrapCs3Jo5JWeNlGx_20account_layout_probe.exit

bb2.i:                                            ; preds = %start
  %7 = getelementptr inbounds i8, ptr %_2, i64 1
  %8 = load i8, ptr %7, align 1
  store i8 %8, ptr %e.i, align 1
; invoke core::result::unwrap_failed
  invoke void @_RNvNtCsgtPOCBgevO_4core6result13unwrap_failed(ptr @alloc_00ae4b301f7fab8ac9617c03fcbd7274, i64 43, ptr %e.i, ptr align 8 @vtable.1, ptr align 8 @alloc_aef890203b0be7aaedef1af2da49abbb) #18
          to label %unreachable.i unwind label %cleanup.i

cleanup.i:                                        ; preds = %bb2.i
  %9 = landingpad { ptr, i32 }
          cleanup
  %10 = extractvalue { ptr, i32 } %9, 0
  %11 = extractvalue { ptr, i32 } %9, 1
  store ptr %10, ptr %0, align 8
  %12 = getelementptr inbounds i8, ptr %0, i64 8
  store i32 %11, ptr %12, align 8
  %13 = load ptr, ptr %0, align 8
  %14 = getelementptr inbounds i8, ptr %0, i64 8
  %15 = load i32, ptr %14, align 8
  %16 = insertvalue { ptr, i32 } poison, ptr %13, 0
  %17 = insertvalue { ptr, i32 } %16, i32 %15, 1
  resume { ptr, i32 } %17

unreachable.i:                                    ; preds = %bb2.i
  unreachable

_RNvMNtCsgtPOCBgevO_4core6resultINtB2_6ResultyNtNtNtB4_3num5error15TryFromIntErrorE6unwrapCs3Jo5JWeNlGx_20account_layout_probe.exit: ; preds = %start
  %18 = getelementptr inbounds i8, ptr %_2, i64 8
  %t.i = load i64, ptr %18, align 8
; call <u64>::div_ceil
  %_0 = call i64 @_RNvMs7_NtCsgtPOCBgevO_4core3numy8div_ceilCs3Jo5JWeNlGx_20account_layout_probe(i64 %t.i, i64 8, ptr align 8 @alloc_381a7855202e08b2725fc041e3c0d1cc)
  ret i64 %_0
}

; account_layout_probe::main
; Function Attrs: uwtable
define hidden void @_RNvCs3Jo5JWeNlGx_20account_layout_probe4main() unnamed_addr #1 {
start:
  %_108 = alloca [16 x i8], align 8
  %_107 = alloca [16 x i8], align 8
  %args10 = alloca [32 x i8], align 8
  %_98 = alloca [16 x i8], align 8
  %_97 = alloca [16 x i8], align 8
  %args9 = alloca [32 x i8], align 8
  %_88 = alloca [16 x i8], align 8
  %_87 = alloca [16 x i8], align 8
  %args8 = alloca [32 x i8], align 8
  %_78 = alloca [16 x i8], align 8
  %_77 = alloca [16 x i8], align 8
  %args7 = alloca [32 x i8], align 8
  %_68 = alloca [16 x i8], align 8
  %_67 = alloca [16 x i8], align 8
  %args6 = alloca [32 x i8], align 8
  %_58 = alloca [16 x i8], align 8
  %_57 = alloca [16 x i8], align 8
  %args5 = alloca [32 x i8], align 8
  %_48 = alloca [16 x i8], align 8
  %_47 = alloca [16 x i8], align 8
  %args4 = alloca [32 x i8], align 8
  %_38 = alloca [16 x i8], align 8
  %_37 = alloca [16 x i8], align 8
  %args3 = alloca [32 x i8], align 8
  %_28 = alloca [16 x i8], align 8
  %_27 = alloca [16 x i8], align 8
  %args2 = alloca [32 x i8], align 8
  %_18 = alloca [16 x i8], align 8
  %_17 = alloca [16 x i8], align 8
  %args1 = alloca [32 x i8], align 8
  %_8 = alloca [16 x i8], align 8
  %_7 = alloca [16 x i8], align 8
  %args = alloca [32 x i8], align 8
; call <core::fmt::rt::Argument>::new_display::<usize>
  call void @_RINvMNtNtCsgtPOCBgevO_4core3fmt2rtNtB3_8Argument11new_displayjECs3Jo5JWeNlGx_20account_layout_probe(ptr sret([16 x i8]) align 8 %_7, ptr align 8 @alloc_a30fbd7ee764311b5438e9cf554fd24e)
; call <core::fmt::rt::Argument>::new_display::<usize>
  call void @_RINvMNtNtCsgtPOCBgevO_4core3fmt2rtNtB3_8Argument11new_displayjECs3Jo5JWeNlGx_20account_layout_probe(ptr sret([16 x i8]) align 8 %_8, ptr align 8 @alloc_a30fbd7ee764311b5438e9cf554fd24e)
  %0 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %0, ptr align 8 %_7, i64 16, i1 false)
  %1 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %1, ptr align 8 %_8, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<31, 2>
  %2 = call { ptr, ptr } @_RINvMs2_NtCsgtPOCBgevO_4core3fmtNtB6_9Arguments3newKj1f_Kj2_ECs3Jo5JWeNlGx_20account_layout_probe(ptr @alloc_492a4481e302e20096f3cf6d1501b511, ptr align 8 %args)
  %_2.0 = extractvalue { ptr, ptr } %2, 0
  %_2.1 = extractvalue { ptr, ptr } %2, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsa9BKTri5B3M_3std2io5stdio6__print(ptr %_2.0, ptr %_2.1)
; call <core::fmt::rt::Argument>::new_display::<usize>
  call void @_RINvMNtNtCsgtPOCBgevO_4core3fmt2rtNtB3_8Argument11new_displayjECs3Jo5JWeNlGx_20account_layout_probe(ptr sret([16 x i8]) align 8 %_17, ptr align 8 @alloc_b1a1c27c6d41023e30ee48eec611ccbe)
; call <core::fmt::rt::Argument>::new_display::<usize>
  call void @_RINvMNtNtCsgtPOCBgevO_4core3fmt2rtNtB3_8Argument11new_displayjECs3Jo5JWeNlGx_20account_layout_probe(ptr sret([16 x i8]) align 8 %_18, ptr align 8 @alloc_a30fbd7ee764311b5438e9cf554fd24e)
  %3 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args1, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %3, ptr align 8 %_17, i64 16, i1 false)
  %4 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args1, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %4, ptr align 8 %_18, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<38, 2>
  %5 = call { ptr, ptr } @_RINvMs2_NtCsgtPOCBgevO_4core3fmtNtB6_9Arguments3newKj26_Kj2_ECs3Jo5JWeNlGx_20account_layout_probe(ptr @alloc_3e54cbba07e61d7952782682c8e27b03, ptr align 8 %args1)
  %_12.0 = extractvalue { ptr, ptr } %5, 0
  %_12.1 = extractvalue { ptr, ptr } %5, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsa9BKTri5B3M_3std2io5stdio6__print(ptr %_12.0, ptr %_12.1)
; call <core::fmt::rt::Argument>::new_display::<usize>
  call void @_RINvMNtNtCsgtPOCBgevO_4core3fmt2rtNtB3_8Argument11new_displayjECs3Jo5JWeNlGx_20account_layout_probe(ptr sret([16 x i8]) align 8 %_27, ptr align 8 @alloc_a30fbd7ee764311b5438e9cf554fd24e)
; call <core::fmt::rt::Argument>::new_display::<usize>
  call void @_RINvMNtNtCsgtPOCBgevO_4core3fmt2rtNtB3_8Argument11new_displayjECs3Jo5JWeNlGx_20account_layout_probe(ptr sret([16 x i8]) align 8 %_28, ptr align 8 @alloc_a30fbd7ee764311b5438e9cf554fd24e)
  %6 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args2, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %6, ptr align 8 %_27, i64 16, i1 false)
  %7 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args2, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %7, ptr align 8 %_28, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<26, 2>
  %8 = call { ptr, ptr } @_RINvMs2_NtCsgtPOCBgevO_4core3fmtNtB6_9Arguments3newKj1a_Kj2_ECs3Jo5JWeNlGx_20account_layout_probe(ptr @alloc_df17e820ce44158ea0e0da3efd1d9c70, ptr align 8 %args2)
  %_22.0 = extractvalue { ptr, ptr } %8, 0
  %_22.1 = extractvalue { ptr, ptr } %8, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsa9BKTri5B3M_3std2io5stdio6__print(ptr %_22.0, ptr %_22.1)
; call <core::fmt::rt::Argument>::new_display::<usize>
  call void @_RINvMNtNtCsgtPOCBgevO_4core3fmt2rtNtB3_8Argument11new_displayjECs3Jo5JWeNlGx_20account_layout_probe(ptr sret([16 x i8]) align 8 %_37, ptr align 8 @alloc_87930ff84f26c4dc0d3a344636709737)
; call <core::fmt::rt::Argument>::new_display::<usize>
  call void @_RINvMNtNtCsgtPOCBgevO_4core3fmt2rtNtB3_8Argument11new_displayjECs3Jo5JWeNlGx_20account_layout_probe(ptr sret([16 x i8]) align 8 %_38, ptr align 8 @alloc_a30fbd7ee764311b5438e9cf554fd24e)
  %9 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args3, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %9, ptr align 8 %_37, i64 16, i1 false)
  %10 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args3, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %10, ptr align 8 %_38, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<26, 2>
  %11 = call { ptr, ptr } @_RINvMs2_NtCsgtPOCBgevO_4core3fmtNtB6_9Arguments3newKj1a_Kj2_ECs3Jo5JWeNlGx_20account_layout_probe(ptr @alloc_d30d101b877a6637e732fae7636f8260, ptr align 8 %args3)
  %_32.0 = extractvalue { ptr, ptr } %11, 0
  %_32.1 = extractvalue { ptr, ptr } %11, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsa9BKTri5B3M_3std2io5stdio6__print(ptr %_32.0, ptr %_32.1)
; call <core::fmt::rt::Argument>::new_display::<usize>
  call void @_RINvMNtNtCsgtPOCBgevO_4core3fmt2rtNtB3_8Argument11new_displayjECs3Jo5JWeNlGx_20account_layout_probe(ptr sret([16 x i8]) align 8 %_47, ptr align 8 @alloc_b1a1c27c6d41023e30ee48eec611ccbe)
; call <core::fmt::rt::Argument>::new_display::<usize>
  call void @_RINvMNtNtCsgtPOCBgevO_4core3fmt2rtNtB3_8Argument11new_displayjECs3Jo5JWeNlGx_20account_layout_probe(ptr sret([16 x i8]) align 8 %_48, ptr align 8 @alloc_a30fbd7ee764311b5438e9cf554fd24e)
  %12 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args4, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %12, ptr align 8 %_47, i64 16, i1 false)
  %13 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args4, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %13, ptr align 8 %_48, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<34, 2>
  %14 = call { ptr, ptr } @_RINvMs2_NtCsgtPOCBgevO_4core3fmtNtB6_9Arguments3newKj22_Kj2_ECs3Jo5JWeNlGx_20account_layout_probe(ptr @alloc_9e22e40936c246bd6aef8ceff10913b5, ptr align 8 %args4)
  %_42.0 = extractvalue { ptr, ptr } %14, 0
  %_42.1 = extractvalue { ptr, ptr } %14, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsa9BKTri5B3M_3std2io5stdio6__print(ptr %_42.0, ptr %_42.1)
; call <core::fmt::rt::Argument>::new_display::<usize>
  call void @_RINvMNtNtCsgtPOCBgevO_4core3fmt2rtNtB3_8Argument11new_displayjECs3Jo5JWeNlGx_20account_layout_probe(ptr sret([16 x i8]) align 8 %_57, ptr align 8 @alloc_6a05004c5f69d0e521e3f36abd3957a3)
; call <core::fmt::rt::Argument>::new_display::<usize>
  call void @_RINvMNtNtCsgtPOCBgevO_4core3fmt2rtNtB3_8Argument11new_displayjECs3Jo5JWeNlGx_20account_layout_probe(ptr sret([16 x i8]) align 8 %_58, ptr align 8 @alloc_a30fbd7ee764311b5438e9cf554fd24e)
  %15 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args5, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %15, ptr align 8 %_57, i64 16, i1 false)
  %16 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args5, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %16, ptr align 8 %_58, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<32, 2>
  %17 = call { ptr, ptr } @_RINvMs2_NtCsgtPOCBgevO_4core3fmtNtB6_9Arguments3newKj20_Kj2_ECs3Jo5JWeNlGx_20account_layout_probe(ptr @alloc_72e5f099c1da7486163215b481af1360, ptr align 8 %args5)
  %_52.0 = extractvalue { ptr, ptr } %17, 0
  %_52.1 = extractvalue { ptr, ptr } %17, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsa9BKTri5B3M_3std2io5stdio6__print(ptr %_52.0, ptr %_52.1)
; call <core::fmt::rt::Argument>::new_display::<usize>
  call void @_RINvMNtNtCsgtPOCBgevO_4core3fmt2rtNtB3_8Argument11new_displayjECs3Jo5JWeNlGx_20account_layout_probe(ptr sret([16 x i8]) align 8 %_67, ptr align 8 @alloc_6a05004c5f69d0e521e3f36abd3957a3)
; call <core::fmt::rt::Argument>::new_display::<usize>
  call void @_RINvMNtNtCsgtPOCBgevO_4core3fmt2rtNtB3_8Argument11new_displayjECs3Jo5JWeNlGx_20account_layout_probe(ptr sret([16 x i8]) align 8 %_68, ptr align 8 @alloc_a30fbd7ee764311b5438e9cf554fd24e)
  %18 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args6, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %18, ptr align 8 %_67, i64 16, i1 false)
  %19 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args6, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %19, ptr align 8 %_68, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<40, 2>
  %20 = call { ptr, ptr } @_RINvMs2_NtCsgtPOCBgevO_4core3fmtNtB6_9Arguments3newKj28_Kj2_ECs3Jo5JWeNlGx_20account_layout_probe(ptr @alloc_118c437227d8fe2518affbdad1d36b50, ptr align 8 %args6)
  %_62.0 = extractvalue { ptr, ptr } %20, 0
  %_62.1 = extractvalue { ptr, ptr } %20, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsa9BKTri5B3M_3std2io5stdio6__print(ptr %_62.0, ptr %_62.1)
; call <core::fmt::rt::Argument>::new_display::<usize>
  call void @_RINvMNtNtCsgtPOCBgevO_4core3fmt2rtNtB3_8Argument11new_displayjECs3Jo5JWeNlGx_20account_layout_probe(ptr sret([16 x i8]) align 8 %_77, ptr align 8 @alloc_28b4525213e621d91e2b40299762a7fc)
; call <core::fmt::rt::Argument>::new_display::<usize>
  call void @_RINvMNtNtCsgtPOCBgevO_4core3fmt2rtNtB3_8Argument11new_displayjECs3Jo5JWeNlGx_20account_layout_probe(ptr sret([16 x i8]) align 8 %_78, ptr align 8 @alloc_a30fbd7ee764311b5438e9cf554fd24e)
  %21 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args7, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %21, ptr align 8 %_77, i64 16, i1 false)
  %22 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args7, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %22, ptr align 8 %_78, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<46, 2>
  %23 = call { ptr, ptr } @_RINvMs2_NtCsgtPOCBgevO_4core3fmtNtB6_9Arguments3newKj2e_Kj2_ECs3Jo5JWeNlGx_20account_layout_probe(ptr @alloc_f4328527bada43b73f18a9c2194e29a5, ptr align 8 %args7)
  %_72.0 = extractvalue { ptr, ptr } %23, 0
  %_72.1 = extractvalue { ptr, ptr } %23, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsa9BKTri5B3M_3std2io5stdio6__print(ptr %_72.0, ptr %_72.1)
; call <core::fmt::rt::Argument>::new_display::<usize>
  call void @_RINvMNtNtCsgtPOCBgevO_4core3fmt2rtNtB3_8Argument11new_displayjECs3Jo5JWeNlGx_20account_layout_probe(ptr sret([16 x i8]) align 8 %_87, ptr align 8 @alloc_b1a1c27c6d41023e30ee48eec611ccbe)
; call <core::fmt::rt::Argument>::new_display::<usize>
  call void @_RINvMNtNtCsgtPOCBgevO_4core3fmt2rtNtB3_8Argument11new_displayjECs3Jo5JWeNlGx_20account_layout_probe(ptr sret([16 x i8]) align 8 %_88, ptr align 8 @alloc_a30fbd7ee764311b5438e9cf554fd24e)
  %24 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args8, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %24, ptr align 8 %_87, i64 16, i1 false)
  %25 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args8, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %25, ptr align 8 %_88, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<29, 2>
  %26 = call { ptr, ptr } @_RINvMs2_NtCsgtPOCBgevO_4core3fmtNtB6_9Arguments3newKj1d_Kj2_ECs3Jo5JWeNlGx_20account_layout_probe(ptr @alloc_4fcc5b5debf291c6560aa9668a3f798a, ptr align 8 %args8)
  %_82.0 = extractvalue { ptr, ptr } %26, 0
  %_82.1 = extractvalue { ptr, ptr } %26, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsa9BKTri5B3M_3std2io5stdio6__print(ptr %_82.0, ptr %_82.1)
; call <core::fmt::rt::Argument>::new_display::<usize>
  call void @_RINvMNtNtCsgtPOCBgevO_4core3fmt2rtNtB3_8Argument11new_displayjECs3Jo5JWeNlGx_20account_layout_probe(ptr sret([16 x i8]) align 8 %_97, ptr align 8 @alloc_b1a1c27c6d41023e30ee48eec611ccbe)
; call <core::fmt::rt::Argument>::new_display::<usize>
  call void @_RINvMNtNtCsgtPOCBgevO_4core3fmt2rtNtB3_8Argument11new_displayjECs3Jo5JWeNlGx_20account_layout_probe(ptr sret([16 x i8]) align 8 %_98, ptr align 8 @alloc_a30fbd7ee764311b5438e9cf554fd24e)
  %27 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args9, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %27, ptr align 8 %_97, i64 16, i1 false)
  %28 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args9, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %28, ptr align 8 %_98, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<37, 2>
  %29 = call { ptr, ptr } @_RINvMs2_NtCsgtPOCBgevO_4core3fmtNtB6_9Arguments3newKj25_Kj2_ECs3Jo5JWeNlGx_20account_layout_probe(ptr @alloc_25aa2ec3bdbab5819bc19fee38d8640b, ptr align 8 %args9)
  %_92.0 = extractvalue { ptr, ptr } %29, 0
  %_92.1 = extractvalue { ptr, ptr } %29, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsa9BKTri5B3M_3std2io5stdio6__print(ptr %_92.0, ptr %_92.1)
; call <core::fmt::rt::Argument>::new_display::<usize>
  call void @_RINvMNtNtCsgtPOCBgevO_4core3fmt2rtNtB3_8Argument11new_displayjECs3Jo5JWeNlGx_20account_layout_probe(ptr sret([16 x i8]) align 8 %_107, ptr align 8 @alloc_b1a1c27c6d41023e30ee48eec611ccbe)
; call <core::fmt::rt::Argument>::new_display::<usize>
  call void @_RINvMNtNtCsgtPOCBgevO_4core3fmt2rtNtB3_8Argument11new_displayjECs3Jo5JWeNlGx_20account_layout_probe(ptr sret([16 x i8]) align 8 %_108, ptr align 8 @alloc_a30fbd7ee764311b5438e9cf554fd24e)
  %30 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args10, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %30, ptr align 8 %_107, i64 16, i1 false)
  %31 = getelementptr inbounds nuw %"core::fmt::rt::Argument<'_>", ptr %args10, i64 1
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %31, ptr align 8 %_108, i64 16, i1 false)
; call <core::fmt::Arguments>::new::<43, 2>
  %32 = call { ptr, ptr } @_RINvMs2_NtCsgtPOCBgevO_4core3fmtNtB6_9Arguments3newKj2b_Kj2_ECs3Jo5JWeNlGx_20account_layout_probe(ptr @alloc_a1f7b75ef8dd5626c3f5ae0cf21a37d7, ptr align 8 %args10)
  %_102.0 = extractvalue { ptr, ptr } %32, 0
  %_102.1 = extractvalue { ptr, ptr } %32, 1
; call std::io::stdio::_print
  call void @_RNvNtNtCsa9BKTri5B3M_3std2io5stdio6__print(ptr %_102.0, ptr %_102.1)
; call <account_layout_probe::Handle>::initialize_shape_probe
  %_112 = call ptr @_RNvMCs3Jo5JWeNlGx_20account_layout_probeNtB2_6Handle22initialize_shape_probe()
; call core::mem::drop::<account_layout_probe::Handle>
  call void @_RINvNtCsgtPOCBgevO_4core3mem4dropNtCs3Jo5JWeNlGx_20account_layout_probe6HandleEBx_(ptr %_112)
  ret void
}

; <account_layout_probe::Handle>::initialize_shape_probe
; Function Attrs: noinline uwtable
define internal ptr @_RNvMCs3Jo5JWeNlGx_20account_layout_probeNtB2_6Handle22initialize_shape_probe() unnamed_addr #2 {
start:
  %0 = alloca [8 x i8], align 8
  %1 = alloca [8 x i8], align 8
  %_4 = alloca [8 x i8], align 8
  %_3 = alloca [8 x i8], align 8
; call account_layout_probe::account_shell_frames
  %_5 = call i64 @_RNvCs3Jo5JWeNlGx_20account_layout_probe20account_shell_frames()
; call <core::sync::atomic::Atomic<u64>>::new
  %2 = call i64 @_RNvMs1e_NtNtCsgtPOCBgevO_4core4sync6atomicINtB6_6AtomicyE3newCs3Jo5JWeNlGx_20account_layout_probe(i64 %_5)
  store i64 %2, ptr %1, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_4, ptr align 8 %1, i64 8, i1 false)
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_3, ptr align 8 %_4, i64 8, i1 false)
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %0, ptr align 8 %_3, i64 8, i1 false)
  %3 = load i64, ptr %0, align 8
; call <alloc::sync::Arc<account_layout_probe::AccountData>>::new
  %_2 = call ptr @_RNvMse_NtCslJsSqIQKwiA_5alloc4syncINtB5_3ArcNtCs3Jo5JWeNlGx_20account_layout_probe11AccountDataE3newBI_(i64 %3)
  ret ptr %_2
}

; <core::option::Option<alloc::sync::Arc<account_layout_probe::AccountData>>>::take
; Function Attrs: inlinehint uwtable
define internal ptr @_RNvMNtCsgtPOCBgevO_4core6optionINtB2_6OptionINtNtCslJsSqIQKwiA_5alloc4sync3ArcNtCs3Jo5JWeNlGx_20account_layout_probe11AccountDataEE4takeB1g_(ptr align 8 %self) unnamed_addr #0 {
start:
  %_0 = load ptr, ptr %self, align 8
  store ptr null, ptr %self, align 8
  ret ptr %_0
}

; <alloc::alloc::Global>::alloc_impl_runtime
; Function Attrs: inlinehint uwtable
define internal { ptr, i64 } @_RNvMNtCslJsSqIQKwiA_5alloc5allocNtB2_6Global18alloc_impl_runtimeCs3Jo5JWeNlGx_20account_layout_probe(i64 %layout.0, i64 %layout.1, i1 zeroext %zeroed) unnamed_addr #0 {
start:
  %self1 = alloca [8 x i8], align 8
  %self = alloca [8 x i8], align 8
  %_9 = alloca [8 x i8], align 8
  %raw_ptr = alloca [8 x i8], align 8
  %_0 = alloca [16 x i8], align 8
  %0 = icmp eq i64 %layout.1, 0
  br i1 %0, label %bb2, label %bb1

bb2:                                              ; preds = %start
  %data = inttoptr i64 %layout.0 to ptr
  %data2 = inttoptr i64 %layout.0 to ptr
  br label %bb8

bb1:                                              ; preds = %start
  br i1 %zeroed, label %bb3, label %bb4

bb8:                                              ; preds = %bb2
  %_19 = inttoptr i64 %layout.0 to ptr
; call <core::ptr::non_null::NonNull<_>>::new_unchecked::precondition_check
  call void @_RNvNvMs1_NtNtCsgtPOCBgevO_4core3ptr8non_nullINtB7_7NonNullpE13new_unchecked18precondition_checkCs3Jo5JWeNlGx_20account_layout_probe(ptr %_19, ptr align 8 @alloc_8d5a0ee98b8cdf2f5afa900e7e86c059) #19
  br label %bb10

bb10:                                             ; preds = %bb8
  store ptr %data2, ptr %_0, align 8
  %1 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 0, ptr %1, align 8
  br label %bb6

bb6:                                              ; preds = %bb22, %bb10
  br label %bb7

bb4:                                              ; preds = %bb1
; call __rustc::__rust_no_alloc_shim_is_unstable_v2
  call void @_RNvCs9wFQrvczXsK_7___rustc35___rust_no_alloc_shim_is_unstable_v2() #19
; call __rustc::__rust_alloc
  %2 = call ptr @_RNvCs9wFQrvczXsK_7___rustc12___rust_alloc(i64 %layout.1, i64 %layout.0) #19
  store ptr %2, ptr %raw_ptr, align 8
  br label %bb5

bb3:                                              ; preds = %bb1
; call __rustc::__rust_no_alloc_shim_is_unstable_v2
  call void @_RNvCs9wFQrvczXsK_7___rustc35___rust_no_alloc_shim_is_unstable_v2() #19
; call __rustc::__rust_alloc_zeroed
  %3 = call ptr @_RNvCs9wFQrvczXsK_7___rustc19___rust_alloc_zeroed(i64 %layout.1, i64 %layout.0) #19
  store ptr %3, ptr %raw_ptr, align 8
  br label %bb5

bb5:                                              ; preds = %bb3, %bb4
  %4 = load ptr, ptr %raw_ptr, align 8
  %_29 = ptrtoint ptr %4 to i64
  %5 = icmp eq i64 %_29, 0
  br i1 %5, label %bb15, label %bb16

bb15:                                             ; preds = %bb5
  store ptr null, ptr %self1, align 8
  store ptr null, ptr %self, align 8
  %6 = load ptr, ptr @anon.78236e53da2646531455d85acb4a15f4.0, align 8
  %7 = load i64, ptr getelementptr inbounds (i8, ptr @anon.78236e53da2646531455d85acb4a15f4.0, i64 8), align 8
  store ptr %6, ptr %_0, align 8
  %8 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %7, ptr %8, align 8
  br label %bb7

bb16:                                             ; preds = %bb5
  br label %bb17

bb7:                                              ; preds = %bb6, %bb15
  %9 = load ptr, ptr %_0, align 8
  %10 = getelementptr inbounds i8, ptr %_0, i64 8
  %11 = load i64, ptr %10, align 8
  %12 = insertvalue { ptr, i64 } poison, ptr %9, 0
  %13 = insertvalue { ptr, i64 } %12, i64 %11, 1
  ret { ptr, i64 } %13

bb17:                                             ; preds = %bb16
  %_31 = load ptr, ptr %raw_ptr, align 8
; call <core::ptr::non_null::NonNull<_>>::new_unchecked::precondition_check
  call void @_RNvNvMs1_NtNtCsgtPOCBgevO_4core3ptr8non_nullINtB7_7NonNullpE13new_unchecked18precondition_checkCs3Jo5JWeNlGx_20account_layout_probe(ptr %_31, ptr align 8 @alloc_5ff1c8aa34f46974b9857da735e490e2) #19
  br label %bb19

bb19:                                             ; preds = %bb17
  %_28 = load ptr, ptr %raw_ptr, align 8
  store ptr %_28, ptr %self1, align 8
  %v = load ptr, ptr %self1, align 8
  store ptr %v, ptr %self, align 8
  %v3 = load ptr, ptr %self, align 8
  store ptr %v3, ptr %_9, align 8
  %ptr = load ptr, ptr %_9, align 8
  br label %bb20

bb20:                                             ; preds = %bb19
; call <core::ptr::non_null::NonNull<_>>::new_unchecked::precondition_check
  call void @_RNvNvMs1_NtNtCsgtPOCBgevO_4core3ptr8non_nullINtB7_7NonNullpE13new_unchecked18precondition_checkCs3Jo5JWeNlGx_20account_layout_probe(ptr %ptr, ptr align 8 @alloc_8d5a0ee98b8cdf2f5afa900e7e86c059) #19
  br label %bb22

bb22:                                             ; preds = %bb20
  store ptr %ptr, ptr %_0, align 8
  %14 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %layout.1, ptr %14, align 8
  br label %bb6
}

; <core::alloc::layout::Layout>::size
; Function Attrs: inlinehint uwtable
define internal i64 @_RNvMNtNtCsgtPOCBgevO_4core5alloc6layoutNtB2_6Layout4sizeCs3Jo5JWeNlGx_20account_layout_probe(ptr align 8 %self) unnamed_addr #0 {
start:
  %0 = getelementptr inbounds i8, ptr %self, i64 8
  %_0 = load i64, ptr %0, align 8
  ret i64 %_0
}

; <core::sync::atomic::Atomic<u64>>::new
; Function Attrs: inlinehint uwtable
define internal i64 @_RNvMs1e_NtNtCsgtPOCBgevO_4core4sync6atomicINtB6_6AtomicyE3newCs3Jo5JWeNlGx_20account_layout_probe(i64 %v) unnamed_addr #0 {
start:
  %_0 = alloca [8 x i8], align 8
  store i64 %v, ptr %_0, align 8
  %0 = load i64, ptr %_0, align 8
  ret i64 %0
}

; <core::sync::atomic::Atomic<u64>>::fetch_sub
; Function Attrs: inlinehint uwtable
define internal i64 @_RNvMs1e_NtNtCsgtPOCBgevO_4core4sync6atomicINtB6_6AtomicyE9fetch_subCs3Jo5JWeNlGx_20account_layout_probe(ptr align 8 %self, i64 %val, i8 %order) unnamed_addr #0 {
start:
  %_0 = alloca [8 x i8], align 8
  %_6 = zext i8 %order to i64
  switch i64 %_6, label %bb2 [
    i64 0, label %bb7
    i64 1, label %bb5
    i64 2, label %bb6
    i64 3, label %bb4
    i64 4, label %bb3
  ]

bb2:                                              ; preds = %start
  unreachable

bb7:                                              ; preds = %start
  %0 = atomicrmw sub ptr %self, i64 %val monotonic, align 8
  store i64 %0, ptr %_0, align 8
  br label %bb1

bb5:                                              ; preds = %start
  %1 = atomicrmw sub ptr %self, i64 %val release, align 8
  store i64 %1, ptr %_0, align 8
  br label %bb1

bb6:                                              ; preds = %start
  %2 = atomicrmw sub ptr %self, i64 %val acquire, align 8
  store i64 %2, ptr %_0, align 8
  br label %bb1

bb4:                                              ; preds = %start
  %3 = atomicrmw sub ptr %self, i64 %val acq_rel, align 8
  store i64 %3, ptr %_0, align 8
  br label %bb1

bb3:                                              ; preds = %start
  %4 = atomicrmw sub ptr %self, i64 %val seq_cst, align 8
  store i64 %4, ptr %_0, align 8
  br label %bb1

bb1:                                              ; preds = %bb3, %bb4, %bb6, %bb5, %bb7
  %5 = load i64, ptr %_0, align 8
  ret i64 %5
}

; <u64>::div_ceil
; Function Attrs: inlinehint uwtable
define internal i64 @_RNvMs7_NtCsgtPOCBgevO_4core3numy8div_ceilCs3Jo5JWeNlGx_20account_layout_probe(i64 %self, i64 %rhs, ptr align 8 %0) unnamed_addr #0 {
start:
  %_0 = alloca [8 x i8], align 8
  %_4 = icmp eq i64 %rhs, 0
  br i1 %_4, label %panic, label %bb1

bb1:                                              ; preds = %start
  %d = udiv i64 %self, %rhs
  br i1 %_4, label %panic1, label %bb2

panic:                                            ; preds = %start
; call core::panicking::panic_const::panic_const_div_by_zero
  call void @_RNvNtNtCsgtPOCBgevO_4core9panicking11panic_const23panic_const_div_by_zero(ptr align 8 %0) #18
  unreachable

bb2:                                              ; preds = %bb1
  %r = urem i64 %self, %rhs
  %_6 = icmp ugt i64 %r, 0
  br i1 %_6, label %bb3, label %bb4

panic1:                                           ; preds = %bb1
; call core::panicking::panic_const::panic_const_rem_by_zero
  call void @_RNvNtNtCsgtPOCBgevO_4core9panicking11panic_const23panic_const_rem_by_zero(ptr align 8 %0) #18
  unreachable

bb4:                                              ; preds = %bb2
  store i64 %d, ptr %_0, align 8
  br label %bb5

bb3:                                              ; preds = %bb2
  %1 = add i64 %d, 1
  store i64 %1, ptr %_0, align 8
  br label %bb5

bb5:                                              ; preds = %bb3, %bb4
  %2 = load i64, ptr %_0, align 8
  ret i64 %2
}

; <alloc::sync::Arc<account_layout_probe::AccountData>>::new
; Function Attrs: inlinehint uwtable
define internal ptr @_RNvMse_NtCslJsSqIQKwiA_5alloc4syncINtB5_3ArcNtCs3Jo5JWeNlGx_20account_layout_probe11AccountDataE3newBI_(i64 %0) unnamed_addr #0 personality ptr @rust_eh_personality {
start:
  %1 = alloca [16 x i8], align 8
  %_4 = alloca [8 x i8], align 8
  %_3 = alloca [24 x i8], align 8
  %2 = alloca [8 x i8], align 8
  %data = alloca [8 x i8], align 8
  store i64 %0, ptr %2, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %data, ptr align 8 %2, i64 8, i1 false)
  store i64 1, ptr %_4, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_3, ptr align 8 %_4, i64 8, i1 false)
  %3 = getelementptr inbounds i8, ptr %_3, i64 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %3, ptr align 8 %_4, i64 8, i1 false)
  %4 = getelementptr inbounds i8, ptr %_3, i64 16
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %4, ptr align 8 %data, i64 8, i1 false)
; invoke alloc::boxed::box_new_uninit
  %_3.i = invoke ptr @_RNvNtCslJsSqIQKwiA_5alloc5boxed14box_new_uninitCs3Jo5JWeNlGx_20account_layout_probe(i64 8, i64 24)
          to label %_RNvMNtCslJsSqIQKwiA_5alloc5boxedINtB2_3BoxINtNtB4_4sync8ArcInnerNtCs3Jo5JWeNlGx_20account_layout_probe11AccountDataEE3newB12_.exit unwind label %cleanup.i

cleanup.i:                                        ; preds = %start
  %5 = landingpad { ptr, i32 }
          cleanup
  %6 = extractvalue { ptr, i32 } %5, 0
  %7 = extractvalue { ptr, i32 } %5, 1
  store ptr %6, ptr %1, align 8
  %8 = getelementptr inbounds i8, ptr %1, i64 8
  store i32 %7, ptr %8, align 8
  %9 = load ptr, ptr %1, align 8
  %10 = getelementptr inbounds i8, ptr %1, i64 8
  %11 = load i32, ptr %10, align 8
  %12 = insertvalue { ptr, i32 } poison, ptr %9, 0
  %13 = insertvalue { ptr, i32 } %12, i32 %11, 1
  resume { ptr, i32 } %13

_RNvMNtCslJsSqIQKwiA_5alloc5boxedINtB2_3BoxINtNtB4_4sync8ArcInnerNtCs3Jo5JWeNlGx_20account_layout_probe11AccountDataEE3newB12_.exit: ; preds = %start
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_3.i, ptr align 8 %_3, i64 24, i1 false)
  ret ptr %_3.i
}

; <alloc::sync::Arc<account_layout_probe::AccountData>>::into_inner
; Function Attrs: inlinehint uwtable
define internal void @_RNvMsf_NtCslJsSqIQKwiA_5alloc4syncINtB5_3ArcNtCs3Jo5JWeNlGx_20account_layout_probe11AccountDataE10into_innerBI_(ptr sret([16 x i8]) align 8 %_0, ptr %this) unnamed_addr #0 personality ptr @rust_eh_personality {
start:
  %0 = alloca [16 x i8], align 8
  %1 = alloca [8 x i8], align 8
  %_18 = alloca [8 x i8], align 8
  %_x = alloca [8 x i8], align 8
  %inner = alloca [8 x i8], align 8
  %this1 = alloca [8 x i8], align 8
  store ptr %this, ptr %this1, align 8
  %_21 = load ptr, ptr %this1, align 8
  %2 = atomicrmw sub ptr %_21, i64 1 release, align 8
  store i64 %2, ptr %1, align 8
  %_3 = load i64, ptr %1, align 8
  %3 = icmp eq i64 %_3, 1
  br i1 %3, label %bb2, label %bb1

bb2:                                              ; preds = %start
; call core::sync::atomic::fence
  call void @_RNvNtNtCsgtPOCBgevO_4core4sync6atomic5fenceCs3Jo5JWeNlGx_20account_layout_probe(i8 2)
  %_25 = load ptr, ptr %this1, align 8
  %4 = getelementptr inbounds i8, ptr %_25, i64 16
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %inner, ptr align 8 %4, i64 8, i1 false)
  %src = getelementptr inbounds i8, ptr %this1, i64 8
  %_16 = load ptr, ptr %this1, align 8
  store ptr %_16, ptr %_x, align 8
; invoke core::ptr::drop_glue::<alloc::sync::Weak<account_layout_probe::AccountData>>
  invoke void @_RINvNtCsgtPOCBgevO_4core3ptr9drop_glueINtNtCslJsSqIQKwiA_5alloc4sync4WeakNtCs3Jo5JWeNlGx_20account_layout_probe11AccountDataEEB1b_(ptr align 8 %_x)
          to label %bb8 unwind label %cleanup

bb1:                                              ; preds = %start
  store i64 0, ptr %_0, align 8
  br label %bb4

bb5:                                              ; preds = %cleanup
  %5 = load ptr, ptr %0, align 8
  %6 = getelementptr inbounds i8, ptr %0, i64 8
  %7 = load i32, ptr %6, align 8
  %8 = insertvalue { ptr, i32 } poison, ptr %5, 0
  %9 = insertvalue { ptr, i32 } %8, i32 %7, 1
  resume { ptr, i32 } %9

cleanup:                                          ; preds = %bb2
  %10 = landingpad { ptr, i32 }
          cleanup
  %11 = extractvalue { ptr, i32 } %10, 0
  %12 = extractvalue { ptr, i32 } %10, 1
  store ptr %11, ptr %0, align 8
  %13 = getelementptr inbounds i8, ptr %0, i64 8
  store i32 %12, ptr %13, align 8
  br label %bb5

bb8:                                              ; preds = %bb2
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %_18, ptr align 8 %inner, i64 8, i1 false)
  %14 = getelementptr inbounds i8, ptr %_0, i64 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %14, ptr align 8 %_18, i64 8, i1 false)
  store i64 1, ptr %_0, align 8
  br label %bb4

bb4:                                              ; preds = %bb1, %bb8
  ret void
}

; <alloc::sync::Arc<account_layout_probe::AccountData>>::drop_slow
; Function Attrs: noinline uwtable
define internal void @_RNvMsn_NtCslJsSqIQKwiA_5alloc4syncINtB5_3ArcNtCs3Jo5JWeNlGx_20account_layout_probe11AccountDataE9drop_slowBI_(ptr align 8 %self) unnamed_addr #2 personality ptr @rust_eh_personality {
start:
  %0 = alloca [16 x i8], align 8
  %_weak = alloca [16 x i8], align 8
  %_3 = load ptr, ptr %self, align 8
  %_4 = getelementptr inbounds i8, ptr %self, i64 8
  store ptr %_3, ptr %_weak, align 8
  %1 = getelementptr inbounds i8, ptr %_weak, i64 8
  store ptr %_4, ptr %1, align 8
  %self1 = load ptr, ptr %self, align 8
  %_9 = getelementptr inbounds i8, ptr %self1, i64 16
  br label %bb4

bb4:                                              ; preds = %start
; call core::ptr::drop_glue::<alloc::sync::Weak<account_layout_probe::AccountData, &alloc::alloc::Global>>
  call void @_RINvNtCsgtPOCBgevO_4core3ptr9drop_glueINtNtCslJsSqIQKwiA_5alloc4sync4WeakNtCs3Jo5JWeNlGx_20account_layout_probe11AccountDataRNtNtBF_5alloc6GlobalEEB1b_(ptr align 8 %_weak)
  ret void

bb2:                                              ; No predecessors!
; invoke core::ptr::drop_glue::<alloc::sync::Weak<account_layout_probe::AccountData, &alloc::alloc::Global>>
  invoke void @_RINvNtCsgtPOCBgevO_4core3ptr9drop_glueINtNtCslJsSqIQKwiA_5alloc4sync4WeakNtCs3Jo5JWeNlGx_20account_layout_probe11AccountDataRNtNtBF_5alloc6GlobalEEB1b_(ptr align 8 %_weak) #16
          to label %bb3 unwind label %terminate

terminate:                                        ; preds = %bb2
  %2 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_in_cleanup
  call void @_RNvNtCsgtPOCBgevO_4core9panicking16panic_in_cleanup() #17
  unreachable

bb3:                                              ; preds = %bb2
  %3 = load ptr, ptr %0, align 8
  %4 = getelementptr inbounds i8, ptr %0, i64 8
  %5 = load i32, ptr %4, align 8
  %6 = insertvalue { ptr, i32 } poison, ptr %3, 0
  %7 = insertvalue { ptr, i32 } %6, i32 %5, 1
  resume { ptr, i32 } %7
}

; alloc::boxed::box_new_uninit
; Function Attrs: inlinehint uwtable
define internal ptr @_RNvNtCslJsSqIQKwiA_5alloc5boxed14box_new_uninitCs3Jo5JWeNlGx_20account_layout_probe(i64 %layout.0, i64 %layout.1) unnamed_addr #0 {
start:
  %_2 = alloca [16 x i8], align 8
; call <alloc::alloc::Global>::alloc_impl_runtime
  %0 = call { ptr, i64 } @_RNvMNtCslJsSqIQKwiA_5alloc5allocNtB2_6Global18alloc_impl_runtimeCs3Jo5JWeNlGx_20account_layout_probe(i64 %layout.0, i64 %layout.1, i1 zeroext false)
  %1 = extractvalue { ptr, i64 } %0, 0
  %2 = extractvalue { ptr, i64 } %0, 1
  store ptr %1, ptr %_2, align 8
  %3 = getelementptr inbounds i8, ptr %_2, i64 8
  store i64 %2, ptr %3, align 8
  %4 = load ptr, ptr %_2, align 8
  %5 = getelementptr inbounds i8, ptr %_2, i64 8
  %6 = load i64, ptr %5, align 8
  %7 = ptrtoint ptr %4 to i64
  %8 = icmp eq i64 %7, 0
  %_3 = select i1 %8, i64 1, i64 0
  %9 = trunc nuw i64 %_3 to i1
  br i1 %9, label %bb2, label %bb3

bb2:                                              ; preds = %start
; call alloc::alloc::handle_alloc_error
  call void @_RNvNtCslJsSqIQKwiA_5alloc5alloc18handle_alloc_error(i64 %layout.0, i64 %layout.1) #18
  unreachable

bb3:                                              ; preds = %start
  %ptr.0 = load ptr, ptr %_2, align 8
  %10 = getelementptr inbounds i8, ptr %_2, i64 8
  %ptr.1 = load i64, ptr %10, align 8
  ret ptr %ptr.0

bb1:                                              ; No predecessors!
  unreachable
}

; core::sync::atomic::fence
; Function Attrs: inlinehint uwtable
define internal void @_RNvNtNtCsgtPOCBgevO_4core4sync6atomic5fenceCs3Jo5JWeNlGx_20account_layout_probe(i8 %order) unnamed_addr #0 {
start:
  %_2 = zext i8 %order to i64
  switch i64 %_2, label %bb1 [
    i64 0, label %bb2
    i64 1, label %bb5
    i64 2, label %bb6
    i64 3, label %bb4
    i64 4, label %bb3
  ]

bb1:                                              ; preds = %start
  unreachable

bb2:                                              ; preds = %start
; call core::panicking::panic_fmt
  call void @_RNvNtCsgtPOCBgevO_4core9panicking9panic_fmt(ptr @alloc_929e9b2e7b7429614ca4fc017efff666, ptr inttoptr (i64 83 to ptr), ptr align 8 @alloc_51bc672182609c8619102955545c9936) #18
  unreachable

bb5:                                              ; preds = %start
  fence release
  br label %bb7

bb6:                                              ; preds = %start
  fence acquire
  br label %bb7

bb4:                                              ; preds = %start
  fence acq_rel
  br label %bb7

bb3:                                              ; preds = %start
  fence seq_cst
  br label %bb7

bb7:                                              ; preds = %bb3, %bb4, %bb6, %bb5
  ret void
}

; <core::mem::alignment::Alignment>::new_unchecked::precondition_check
; Function Attrs: inlinehint nounwind uwtable
define internal void @_RNvNvMNtNtCsgtPOCBgevO_4core3mem9alignmentNtB4_9Alignment13new_unchecked18precondition_checkCs3Jo5JWeNlGx_20account_layout_probe(i64 %align, ptr align 8 %0) unnamed_addr #3 {
start:
  %1 = alloca [4 x i8], align 4
  %2 = call i64 @llvm.ctpop.i64(i64 %align)
  %3 = trunc i64 %2 to i32
  store i32 %3, ptr %1, align 4
  %_5 = load i32, ptr %1, align 4
  %4 = icmp eq i32 %_5, 1
  br i1 %4, label %bb1, label %bb2

bb1:                                              ; preds = %start
  ret void

bb2:                                              ; preds = %start
; call core::panicking::panic_nounwind_fmt
  call void @_RNvNtCsgtPOCBgevO_4core9panicking18panic_nounwind_fmt(ptr @alloc_0625062a5eee489a7813ee965a38d15a, ptr inttoptr (i64 397 to ptr), i1 zeroext false, ptr align 8 %0) #20
  unreachable
}

; <core::alloc::layout::Layout>::from_size_alignment_unchecked::precondition_check
; Function Attrs: inlinehint nounwind uwtable
define internal void @_RNvNvMNtNtCsgtPOCBgevO_4core5alloc6layoutNtB4_6Layout29from_size_alignment_unchecked18precondition_checkCs3Jo5JWeNlGx_20account_layout_probe(i64 %size, i64 %alignment, ptr align 8 %0) unnamed_addr #3 {
start:
  %_7 = sub nuw i64 -9223372036854775808, %alignment
  %_3 = icmp ule i64 %size, %_7
  br i1 %_3, label %bb1, label %bb2

bb2:                                              ; preds = %start
; call core::panicking::panic_nounwind_fmt
  call void @_RNvNtCsgtPOCBgevO_4core9panicking18panic_nounwind_fmt(ptr @alloc_8cf3531fd3c828ab298b686071a40c17, ptr inttoptr (i64 519 to ptr), i1 zeroext false, ptr align 8 %0) #20
  unreachable

bb1:                                              ; preds = %start
  ret void
}

; <core::ptr::non_null::NonNull<_>>::new_unchecked::precondition_check
; Function Attrs: inlinehint nounwind uwtable
define internal void @_RNvNvMs1_NtNtCsgtPOCBgevO_4core3ptr8non_nullINtB7_7NonNullpE13new_unchecked18precondition_checkCs3Jo5JWeNlGx_20account_layout_probe(ptr %ptr, ptr align 8 %0) unnamed_addr #3 {
start:
  %_5 = ptrtoint ptr %ptr to i64
  %1 = icmp eq i64 %_5, 0
  br i1 %1, label %bb1, label %bb2

bb1:                                              ; preds = %start
; call core::panicking::panic_nounwind_fmt
  call void @_RNvNtCsgtPOCBgevO_4core9panicking18panic_nounwind_fmt(ptr @alloc_560a59ed819b9d9a5841f6e731c4c8e5, ptr inttoptr (i64 421 to ptr), i1 zeroext false, ptr align 8 %0) #20
  unreachable

bb2:                                              ; preds = %start
  ret void
}

; <&alloc::alloc::Global as core::alloc::Allocator>::deallocate
; Function Attrs: inlinehint uwtable
define internal void @_RNvXs0_NtCsgtPOCBgevO_4core5allocRNtNtCslJsSqIQKwiA_5alloc5alloc6GlobalNtB5_9Allocator10deallocateCs3Jo5JWeNlGx_20account_layout_probe(ptr align 8 %self, ptr %ptr, i64 %layout.0, i64 %layout.1) unnamed_addr #0 {
start:
  %_4 = load ptr, ptr %self, align 8
; call <alloc::alloc::Global as core::alloc::Allocator>::deallocate
  call void @_RNvXs_NtCslJsSqIQKwiA_5alloc5allocNtB4_6GlobalNtNtCsgtPOCBgevO_4core5alloc9Allocator10deallocateCs3Jo5JWeNlGx_20account_layout_probe(ptr %_4, ptr %ptr, i64 %layout.0, i64 %layout.1)
  ret void
}

; <u64 as core::convert::TryFrom<usize>>::try_from
; Function Attrs: inlinehint uwtable
define internal void @_RNvXs1_NtNtNtCsgtPOCBgevO_4core7convert3num18ptr_try_from_implsyINtB9_7TryFromjE8try_fromCs3Jo5JWeNlGx_20account_layout_probe(ptr sret([16 x i8]) align 8 %_0, i64 %value) unnamed_addr #0 {
start:
  %0 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %value, ptr %0, align 8
  store i8 0, ptr %_0, align 8
  ret void
}

; <core::num::error::TryFromIntError as core::fmt::Debug>::fmt
; Function Attrs: inlinehint uwtable
define internal zeroext i1 @_RNvXs6_NtNtCsgtPOCBgevO_4core3num5errorNtB5_15TryFromIntErrorNtNtB9_3fmt5Debug3fmtCs3Jo5JWeNlGx_20account_layout_probe(ptr %self, ptr align 8 %f) unnamed_addr #0 {
start:
  %_5 = alloca [8 x i8], align 8
  store ptr %self, ptr %_5, align 8
; call <core::fmt::Formatter>::debug_tuple_field1_finish
  %_0 = call zeroext i1 @_RNvMsa_NtCsgtPOCBgevO_4core3fmtNtB5_9Formatter25debug_tuple_field1_finish(ptr align 8 %f, ptr @alloc_5cb263f26a5d50117adfcc5c7225745e, i64 15, ptr %_5, ptr align 8 @vtable.2)
  ret i1 %_0
}

; <alloc::sync::Arc<account_layout_probe::AccountData> as core::ops::drop::Drop>::drop
; Function Attrs: inlinehint uwtable
define internal void @_RNvXsD_NtCslJsSqIQKwiA_5alloc4syncINtB5_3ArcNtCs3Jo5JWeNlGx_20account_layout_probe11AccountDataENtNtNtCsgtPOCBgevO_4core3ops4drop4Drop4dropBI_(ptr align 8 %self) unnamed_addr #0 {
start:
  %0 = alloca [8 x i8], align 8
  %_10 = load ptr, ptr %self, align 8
  %1 = atomicrmw sub ptr %_10, i64 1 release, align 8
  store i64 %1, ptr %0, align 8
  %_2 = load i64, ptr %0, align 8
  %2 = icmp eq i64 %_2, 1
  br i1 %2, label %bb2, label %bb1

bb2:                                              ; preds = %start
; call core::sync::atomic::fence
  call void @_RNvNtNtCsgtPOCBgevO_4core4sync6atomic5fenceCs3Jo5JWeNlGx_20account_layout_probe(i8 2)
; call <alloc::sync::Arc<account_layout_probe::AccountData>>::drop_slow
  call void @_RNvMsn_NtCslJsSqIQKwiA_5alloc4syncINtB5_3ArcNtCs3Jo5JWeNlGx_20account_layout_probe11AccountDataE9drop_slowBI_(ptr align 8 %self)
  br label %bb4

bb1:                                              ; preds = %start
  br label %bb4

bb4:                                              ; preds = %bb1, %bb2
  ret void
}

; <alloc::sync::Weak<account_layout_probe::AccountData> as core::ops::drop::Drop>::drop
; Function Attrs: uwtable
define internal void @_RNvXsN_NtCslJsSqIQKwiA_5alloc4syncINtB5_4WeakNtCs3Jo5JWeNlGx_20account_layout_probe11AccountDataENtNtNtCsgtPOCBgevO_4core3ops4drop4Drop4dropBJ_(ptr align 8 %self) unnamed_addr #1 {
start:
  %0 = alloca [8 x i8], align 8
  %1 = alloca [8 x i8], align 8
  %2 = alloca [8 x i8], align 8
  %_2 = alloca [16 x i8], align 8
  %self1 = load ptr, ptr %self, align 8
  %_20 = ptrtoint ptr %self1 to i64
  %3 = icmp eq i64 %_20, -1
  br i1 %3, label %bb7, label %bb8

bb7:                                              ; preds = %start
  br label %bb6

bb8:                                              ; preds = %start
  %_19 = getelementptr inbounds i8, ptr %self1, i64 8
  store ptr %_19, ptr %_2, align 8
  %4 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr %self1, ptr %4, align 8
  %inner = load ptr, ptr %_2, align 8
  %5 = getelementptr inbounds i8, ptr %_2, i64 8
  %inner2 = load ptr, ptr %5, align 8
  %6 = atomicrmw sub ptr %inner, i64 1 release, align 8
  store i64 %6, ptr %2, align 8
  %_3 = load i64, ptr %2, align 8
  %7 = icmp eq i64 %_3, 1
  br i1 %7, label %bb1, label %bb4

bb6:                                              ; preds = %bb5, %bb7
  ret void

bb1:                                              ; preds = %bb8
; call core::sync::atomic::fence
  call void @_RNvNtNtCsgtPOCBgevO_4core4sync6atomic5fenceCs3Jo5JWeNlGx_20account_layout_probe(i8 2)
  %_8 = getelementptr inbounds i8, ptr %self, i64 8
  %self3 = load ptr, ptr %self, align 8
  %self4 = load ptr, ptr %self, align 8
  store i64 24, ptr %1, align 8
  %size = load i64, ptr %1, align 8
  store i64 8, ptr %0, align 8
  %align = load i64, ptr %0, align 8
  br label %bb12

bb4:                                              ; preds = %bb8
  br label %bb5

bb12:                                             ; preds = %bb1
; call <core::mem::alignment::Alignment>::new_unchecked::precondition_check
  call void @_RNvNvMNtNtCsgtPOCBgevO_4core3mem9alignmentNtB4_9Alignment13new_unchecked18precondition_checkCs3Jo5JWeNlGx_20account_layout_probe(i64 %align, ptr align 8 @alloc_94ac603a76bcb1c7cd512525db170514) #19
  br label %bb13

bb13:                                             ; preds = %bb12
  br label %bb14

bb14:                                             ; preds = %bb13
; call <core::alloc::layout::Layout>::from_size_alignment_unchecked::precondition_check
  call void @_RNvNvMNtNtCsgtPOCBgevO_4core5alloc6layoutNtB4_6Layout29from_size_alignment_unchecked18precondition_checkCs3Jo5JWeNlGx_20account_layout_probe(i64 %size, i64 %align, ptr align 8 @alloc_632d33230a33b678beb09f7f8dd3a0db) #19
  br label %bb15

bb15:                                             ; preds = %bb14
; call <alloc::alloc::Global as core::alloc::Allocator>::deallocate
  call void @_RNvXs_NtCslJsSqIQKwiA_5alloc5allocNtB4_6GlobalNtNtCsgtPOCBgevO_4core5alloc9Allocator10deallocateCs3Jo5JWeNlGx_20account_layout_probe(ptr %_8, ptr %self3, i64 %align, i64 %size)
  br label %bb5

bb5:                                              ; preds = %bb4, %bb15
  br label %bb6
}

; <alloc::sync::Weak<account_layout_probe::AccountData, &alloc::alloc::Global> as core::ops::drop::Drop>::drop
; Function Attrs: uwtable
define internal void @_RNvXsN_NtCslJsSqIQKwiA_5alloc4syncINtB5_4WeakNtCs3Jo5JWeNlGx_20account_layout_probe11AccountDataRNtNtB7_5alloc6GlobalENtNtNtCsgtPOCBgevO_4core3ops4drop4Drop4dropBJ_(ptr align 8 %self) unnamed_addr #1 {
start:
  %0 = alloca [8 x i8], align 8
  %1 = alloca [8 x i8], align 8
  %2 = alloca [8 x i8], align 8
  %_2 = alloca [16 x i8], align 8
  %self1 = load ptr, ptr %self, align 8
  %_20 = ptrtoint ptr %self1 to i64
  %3 = icmp eq i64 %_20, -1
  br i1 %3, label %bb7, label %bb8

bb7:                                              ; preds = %start
  br label %bb6

bb8:                                              ; preds = %start
  %_19 = getelementptr inbounds i8, ptr %self1, i64 8
  store ptr %_19, ptr %_2, align 8
  %4 = getelementptr inbounds i8, ptr %_2, i64 8
  store ptr %self1, ptr %4, align 8
  %inner = load ptr, ptr %_2, align 8
  %5 = getelementptr inbounds i8, ptr %_2, i64 8
  %inner2 = load ptr, ptr %5, align 8
  %6 = atomicrmw sub ptr %inner, i64 1 release, align 8
  store i64 %6, ptr %2, align 8
  %_3 = load i64, ptr %2, align 8
  %7 = icmp eq i64 %_3, 1
  br i1 %7, label %bb1, label %bb4

bb6:                                              ; preds = %bb5, %bb7
  ret void

bb1:                                              ; preds = %bb8
; call core::sync::atomic::fence
  call void @_RNvNtNtCsgtPOCBgevO_4core4sync6atomic5fenceCs3Jo5JWeNlGx_20account_layout_probe(i8 2)
  %_8 = getelementptr inbounds i8, ptr %self, i64 8
  %self3 = load ptr, ptr %self, align 8
  %self4 = load ptr, ptr %self, align 8
  store i64 24, ptr %1, align 8
  %size = load i64, ptr %1, align 8
  store i64 8, ptr %0, align 8
  %align = load i64, ptr %0, align 8
  br label %bb12

bb4:                                              ; preds = %bb8
  br label %bb5

bb12:                                             ; preds = %bb1
; call <core::mem::alignment::Alignment>::new_unchecked::precondition_check
  call void @_RNvNvMNtNtCsgtPOCBgevO_4core3mem9alignmentNtB4_9Alignment13new_unchecked18precondition_checkCs3Jo5JWeNlGx_20account_layout_probe(i64 %align, ptr align 8 @alloc_94ac603a76bcb1c7cd512525db170514) #19
  br label %bb13

bb13:                                             ; preds = %bb12
  br label %bb14

bb14:                                             ; preds = %bb13
; call <core::alloc::layout::Layout>::from_size_alignment_unchecked::precondition_check
  call void @_RNvNvMNtNtCsgtPOCBgevO_4core5alloc6layoutNtB4_6Layout29from_size_alignment_unchecked18precondition_checkCs3Jo5JWeNlGx_20account_layout_probe(i64 %size, i64 %align, ptr align 8 @alloc_632d33230a33b678beb09f7f8dd3a0db) #19
  br label %bb15

bb15:                                             ; preds = %bb14
; call <&alloc::alloc::Global as core::alloc::Allocator>::deallocate
  call void @_RNvXs0_NtCsgtPOCBgevO_4core5allocRNtNtCslJsSqIQKwiA_5alloc5alloc6GlobalNtB5_9Allocator10deallocateCs3Jo5JWeNlGx_20account_layout_probe(ptr align 8 %_8, ptr %self3, i64 %align, i64 %size)
  br label %bb5

bb5:                                              ; preds = %bb4, %bb15
  br label %bb6
}

; <() as std::process::Termination>::report
; Function Attrs: inlinehint uwtable
define internal i8 @_RNvXsZ_NtCsa9BKTri5B3M_3std7processuNtB5_11Termination6reportCs3Jo5JWeNlGx_20account_layout_probe() unnamed_addr #0 {
start:
  ret i8 0
}

; <account_layout_probe::Handle as core::ops::drop::Drop>::drop
; Function Attrs: uwtable
define internal void @_RNvXs_Cs3Jo5JWeNlGx_20account_layout_probeNtB4_6HandleNtNtNtCsgtPOCBgevO_4core3ops4drop4Drop4drop(ptr align 8 %self) unnamed_addr #1 {
start:
  %_16 = alloca [8 x i8], align 8
  %before = alloca [8 x i8], align 8
  %data = alloca [8 x i8], align 8
  %_6 = alloca [16 x i8], align 8
  %_2 = alloca [8 x i8], align 8
; call <core::option::Option<alloc::sync::Arc<account_layout_probe::AccountData>>>::take
  %0 = call ptr @_RNvMNtCsgtPOCBgevO_4core6optionINtB2_6OptionINtNtCslJsSqIQKwiA_5alloc4sync3ArcNtCs3Jo5JWeNlGx_20account_layout_probe11AccountDataEE4takeB1g_(ptr align 8 %self)
  store ptr %0, ptr %_2, align 8
  %1 = load ptr, ptr %_2, align 8
  %2 = ptrtoint ptr %1 to i64
  %3 = icmp eq i64 %2, 0
  %_4 = select i1 %3, i64 0, i64 1
  %4 = trunc nuw i64 %_4 to i1
  br i1 %4, label %bb2, label %bb9

bb2:                                              ; preds = %start
  %arc = load ptr, ptr %_2, align 8
; call <alloc::sync::Arc<account_layout_probe::AccountData>>::into_inner
  call void @_RNvMsf_NtCslJsSqIQKwiA_5alloc4syncINtB5_3ArcNtCs3Jo5JWeNlGx_20account_layout_probe11AccountDataE10into_innerBI_(ptr sret([16 x i8]) align 8 %_6, ptr %arc)
  %_7 = load i64, ptr %_6, align 8
  %5 = trunc nuw i64 %_7 to i1
  br i1 %5, label %bb4, label %bb9

bb9:                                              ; preds = %bb4, %bb2, %start
  ret void

bb4:                                              ; preds = %bb2
  %6 = getelementptr inbounds i8, ptr %_6, i64 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %data, ptr align 8 %6, i64 8, i1 false)
; call account_layout_probe::account_shell_frames
  %_11 = call i64 @_RNvCs3Jo5JWeNlGx_20account_layout_probe20account_shell_frames()
; call <core::sync::atomic::Atomic<u64>>::fetch_sub
  %7 = call i64 @_RNvMs1e_NtNtCsgtPOCBgevO_4core4sync6atomicINtB6_6AtomicyE9fetch_subCs3Jo5JWeNlGx_20account_layout_probe(ptr align 8 %data, i64 %_11, i8 0)
  store i64 %7, ptr %before, align 8
; call account_layout_probe::account_shell_frames
  %8 = call i64 @_RNvCs3Jo5JWeNlGx_20account_layout_probe20account_shell_frames()
  store i64 %8, ptr %_16, align 8
  %_20 = load i64, ptr %before, align 8
  %_21 = load i64, ptr %_16, align 8
  %_19 = icmp eq i64 %_20, %_21
  br i1 %_19, label %bb9, label %bb8

bb8:                                              ; preds = %bb4
; call core::panicking::assert_failed::<u64, u64>
  call void @_RINvNtCsgtPOCBgevO_4core9panicking13assert_failedyyEB4_(i8 0, ptr align 8 %before, ptr align 8 %_16, ptr null, ptr undef, ptr align 8 @alloc_bb47e1cb3d6132880125efe73e3158a6) #18
  unreachable

bb10:                                             ; No predecessors!
  unreachable
}

; <alloc::alloc::Global as core::alloc::Allocator>::deallocate
; Function Attrs: inlinehint uwtable
define internal void @_RNvXs_NtCslJsSqIQKwiA_5alloc5allocNtB4_6GlobalNtNtCsgtPOCBgevO_4core5alloc9Allocator10deallocateCs3Jo5JWeNlGx_20account_layout_probe(ptr %self, ptr %ptr, i64 %layout.0, i64 %layout.1) unnamed_addr #0 {
start:
  %0 = icmp eq i64 %layout.1, 0
  br i1 %0, label %bb2, label %bb1

bb2:                                              ; preds = %bb1, %start
  ret void

bb1:                                              ; preds = %start
; call __rustc::__rust_dealloc
  call void @_RNvCs9wFQrvczXsK_7___rustc14___rust_dealloc(ptr %ptr, i64 %layout.1, i64 %layout.0) #19
  br label %bb2
}

; <fn() as core::ops::function::FnOnce<()>>::call_once
; Function Attrs: inlinehint uwtable
define internal void @_RNvYFEuINtNtNtCsgtPOCBgevO_4core3ops8function6FnOnceuE9call_onceCs3Jo5JWeNlGx_20account_layout_probe(ptr %_1) unnamed_addr #0 {
start:
  %_2 = alloca [0 x i8], align 1
  call void %_1()
  ret void
}

; <std::rt::lang_start<()>::{closure#0} as core::ops::function::FnOnce<()>>::call_once
; Function Attrs: inlinehint uwtable
define internal i32 @_RNvYNCINvNtCsa9BKTri5B3M_3std2rt10lang_startuE0INtNtNtCsgtPOCBgevO_4core3ops8function6FnOnceuE9call_onceCs3Jo5JWeNlGx_20account_layout_probe(ptr %0) unnamed_addr #0 personality ptr @rust_eh_personality {
start:
  %1 = alloca [16 x i8], align 8
  %_2 = alloca [0 x i8], align 1
  %_1 = alloca [8 x i8], align 8
  store ptr %0, ptr %_1, align 8
; invoke std::rt::lang_start::<()>::{closure#0}
  %_0 = invoke i32 @_RNCINvNtCsa9BKTri5B3M_3std2rt10lang_startuE0Cs3Jo5JWeNlGx_20account_layout_probe(ptr align 8 %_1)
          to label %bb1 unwind label %cleanup

bb3:                                              ; preds = %cleanup
  %2 = load ptr, ptr %1, align 8
  %3 = getelementptr inbounds i8, ptr %1, i64 8
  %4 = load i32, ptr %3, align 8
  %5 = insertvalue { ptr, i32 } poison, ptr %2, 0
  %6 = insertvalue { ptr, i32 } %5, i32 %4, 1
  resume { ptr, i32 } %6

cleanup:                                          ; preds = %start
  %7 = landingpad { ptr, i32 }
          cleanup
  %8 = extractvalue { ptr, i32 } %7, 0
  %9 = extractvalue { ptr, i32 } %7, 1
  store ptr %8, ptr %1, align 8
  %10 = getelementptr inbounds i8, ptr %1, i64 8
  store i32 %9, ptr %10, align 8
  br label %bb3

bb1:                                              ; preds = %start
  ret i32 %_0
}

; <usize as core::fmt::Display>::fmt
; Function Attrs: uwtable
declare zeroext i1 @_RNvXsi_NtNtNtCsgtPOCBgevO_4core3fmt3num3impjNtB9_7Display3fmt(ptr align 8, ptr align 8) unnamed_addr #1

; Function Attrs: nocallback nofree nounwind willreturn memory(argmem: readwrite)
declare void @llvm.memcpy.p0.p0.i64(ptr noalias writeonly captures(none), ptr noalias readonly captures(none), i64, i1 immarg) #4

; std::rt::lang_start_internal
; Function Attrs: uwtable
declare i64 @_RNvNtCsa9BKTri5B3M_3std2rt19lang_start_internal(ptr, ptr align 8, i64, ptr, i8) unnamed_addr #1

; Function Attrs: nounwind uwtable
declare i32 @rust_eh_personality(i32, i32, i64, ptr, ptr) unnamed_addr #5

; core::panicking::panic_in_cleanup
; Function Attrs: cold minsize noinline noreturn nounwind optsize uwtable
declare void @_RNvNtCsgtPOCBgevO_4core9panicking16panic_in_cleanup() unnamed_addr #6

; std::io::stdio::_print
; Function Attrs: uwtable
declare void @_RNvNtNtCsa9BKTri5B3M_3std2io5stdio6__print(ptr, ptr) unnamed_addr #1

; core::result::unwrap_failed
; Function Attrs: cold noinline noreturn uwtable
declare void @_RNvNtCsgtPOCBgevO_4core6result13unwrap_failed(ptr, i64, ptr, ptr align 8, ptr align 8) unnamed_addr #7

; __rustc::__rust_no_alloc_shim_is_unstable_v2
; Function Attrs: nounwind uwtable
declare void @_RNvCs9wFQrvczXsK_7___rustc35___rust_no_alloc_shim_is_unstable_v2() unnamed_addr #5

; __rustc::__rust_alloc
; Function Attrs: nounwind allockind("alloc,uninitialized,aligned") allocsize(0) uwtable
declare noalias ptr @_RNvCs9wFQrvczXsK_7___rustc12___rust_alloc(i64, i64 allocalign) unnamed_addr #8

; __rustc::__rust_alloc_zeroed
; Function Attrs: nounwind allockind("alloc,zeroed,aligned") allocsize(0) uwtable
declare noalias ptr @_RNvCs9wFQrvczXsK_7___rustc19___rust_alloc_zeroed(i64, i64 allocalign) unnamed_addr #9

; core::panicking::panic_const::panic_const_div_by_zero
; Function Attrs: cold noinline noreturn uwtable
declare void @_RNvNtNtCsgtPOCBgevO_4core9panicking11panic_const23panic_const_div_by_zero(ptr align 8) unnamed_addr #7

; core::panicking::panic_const::panic_const_rem_by_zero
; Function Attrs: cold noinline noreturn uwtable
declare void @_RNvNtNtCsgtPOCBgevO_4core9panicking11panic_const23panic_const_rem_by_zero(ptr align 8) unnamed_addr #7

; alloc::alloc::handle_alloc_error
; Function Attrs: cold minsize noreturn optsize uwtable
declare void @_RNvNtCslJsSqIQKwiA_5alloc5alloc18handle_alloc_error(i64, i64) unnamed_addr #10

; core::panicking::panic_fmt
; Function Attrs: cold noinline noreturn uwtable
declare void @_RNvNtCsgtPOCBgevO_4core9panicking9panic_fmt(ptr, ptr, ptr align 8) unnamed_addr #7

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i64 @llvm.ctpop.i64(i64) #11

; core::panicking::panic_nounwind_fmt
; Function Attrs: cold noinline noreturn nounwind uwtable
declare void @_RNvNtCsgtPOCBgevO_4core9panicking18panic_nounwind_fmt(ptr, ptr, i1 zeroext, ptr align 8) unnamed_addr #12

; <&core::num::error::IntErrorKind as core::fmt::Debug>::fmt
; Function Attrs: uwtable
declare zeroext i1 @_RNvXs1g_NtCsgtPOCBgevO_4core3fmtRNtNtNtB8_3num5error12IntErrorKindNtB6_5Debug3fmtCs1mTuhq77BFi_14rustc_demangle(ptr align 8, ptr align 8) unnamed_addr #1

; <core::fmt::Formatter>::debug_tuple_field1_finish
; Function Attrs: uwtable
declare zeroext i1 @_RNvMsa_NtCsgtPOCBgevO_4core3fmtNtB5_9Formatter25debug_tuple_field1_finish(ptr align 8, ptr, i64, ptr, ptr align 8) unnamed_addr #1

; core::panicking::assert_failed::<u64, u64>
; Function Attrs: cold minsize noinline noreturn optsize uwtable
declare void @_RINvNtCsgtPOCBgevO_4core9panicking13assert_failedyyEB4_(i8, ptr align 8, ptr align 8, ptr, ptr, ptr align 8) unnamed_addr #13

; __rustc::__rust_dealloc
; Function Attrs: nounwind allockind("free") uwtable
declare void @_RNvCs9wFQrvczXsK_7___rustc14___rust_dealloc(ptr allocptr captures(address), i64, i64) unnamed_addr #14

define i32 @main(i32 %0, ptr %1) unnamed_addr #15 {
top:
  %2 = sext i32 %0 to i64
; call std::rt::lang_start::<()>
  %3 = call i64 @_RINvNtCsa9BKTri5B3M_3std2rt10lang_startuECs3Jo5JWeNlGx_20account_layout_probe(ptr @_RNvCs3Jo5JWeNlGx_20account_layout_probe4main, i64 %2, ptr %1, i8 0)
  %4 = trunc i64 %3 to i32
  ret i32 %4
}

attributes #0 = { inlinehint uwtable "frame-pointer"="non-leaf" "probe-stack"="inline-asm" "target-cpu"="apple-m1" }
attributes #1 = { uwtable "frame-pointer"="non-leaf" "probe-stack"="inline-asm" "target-cpu"="apple-m1" }
attributes #2 = { noinline uwtable "frame-pointer"="non-leaf" "probe-stack"="inline-asm" "target-cpu"="apple-m1" }
attributes #3 = { inlinehint nounwind uwtable "frame-pointer"="non-leaf" "probe-stack"="inline-asm" "target-cpu"="apple-m1" }
attributes #4 = { nocallback nofree nounwind willreturn memory(argmem: readwrite) }
attributes #5 = { nounwind uwtable "frame-pointer"="non-leaf" "probe-stack"="inline-asm" "target-cpu"="apple-m1" }
attributes #6 = { cold minsize noinline noreturn nounwind optsize uwtable "frame-pointer"="non-leaf" "probe-stack"="inline-asm" "target-cpu"="apple-m1" }
attributes #7 = { cold noinline noreturn uwtable "frame-pointer"="non-leaf" "probe-stack"="inline-asm" "target-cpu"="apple-m1" }
attributes #8 = { nounwind allockind("alloc,uninitialized,aligned") allocsize(0) uwtable "alloc-family"="__rust_alloc" "alloc-variant-zeroed"="_RNvCs9wFQrvczXsK_7___rustc19___rust_alloc_zeroed" "frame-pointer"="non-leaf" "probe-stack"="inline-asm" "target-cpu"="apple-m1" }
attributes #9 = { nounwind allockind("alloc,zeroed,aligned") allocsize(0) uwtable "alloc-family"="__rust_alloc" "frame-pointer"="non-leaf" "probe-stack"="inline-asm" "target-cpu"="apple-m1" }
attributes #10 = { cold minsize noreturn optsize uwtable "frame-pointer"="non-leaf" "probe-stack"="inline-asm" "target-cpu"="apple-m1" }
attributes #11 = { nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none) }
attributes #12 = { cold noinline noreturn nounwind uwtable "frame-pointer"="non-leaf" "probe-stack"="inline-asm" "target-cpu"="apple-m1" }
attributes #13 = { cold minsize noinline noreturn optsize uwtable "frame-pointer"="non-leaf" "probe-stack"="inline-asm" "target-cpu"="apple-m1" }
attributes #14 = { nounwind allockind("free") uwtable "alloc-family"="__rust_alloc" "frame-pointer"="non-leaf" "probe-stack"="inline-asm" "target-cpu"="apple-m1" }
attributes #15 = { "frame-pointer"="non-leaf" "target-cpu"="apple-m1" }
attributes #16 = { cold }
attributes #17 = { cold noreturn nounwind }
attributes #18 = { noreturn }
attributes #19 = { nounwind }
attributes #20 = { noreturn nounwind }

!llvm.module.flags = !{!0, !1}
!llvm.ident = !{!2}

!0 = !{i32 8, !"PIC Level", i32 2}
!1 = !{i32 7, !"PIE Level", i32 2}
!2 = !{!"rustc version 1.97.1 (8bab26f4f 2026-07-14)"}
!3 = !{i64 18913627226714549}
