from pathlib import Path
import hashlib,json,re
root=Path('/tmp/deadpan-query-groundwork-2026-10-26/scoped')
out=Path('/tmp/deadpan-point-policy-output-design-review-2026-10-31')
def block(text,start):
    first=text.index(start); left=text.index('{',first); depth=0
    for i in range(left,len(text)):
        if text[i]=='{':depth+=1
        elif text[i]=='}':
            depth-=1
            if depth==0:return text[first:i+1]
    raise ValueError(start)
stages=(root/'crates/deadpan-audio/src/stages.rs').read_text()
doc=(root/'crates/deadpan-core/src/document.rs').read_text()
time=(root/'crates/deadpan-core/src/time.rs').read_text()
signal=(root/'crates/deadpan-plan/src/audio_signal.rs').read_text()
identity=re.search(r'pub struct \$name\(Arc<str>\);',doc).group().replace('$name','AssetId')
audio=re.search(r'pub struct AudioSample\(pub i64\);',time).group()
sig=re.search(r'pub struct SignalSample\(pub i64\);',signal).group()
alias=re.search(r'pub\(crate\) type Dependencies = [^\n]+',stages).group()
read=block(stages,'struct ReadBlock {')
small=block(stages,'struct SignalBlock {')
data='\n'.join([identity,audio,sig,alias,
read.replace('struct ReadBlock','struct LegacyReadBlock'),
read.replace('struct ReadBlock','struct ProposedReadBlock').replace('suppressed: Vec<Range<AudioSample>>','suppressed: Mask<AudioSample>'),
small.replace('struct SignalBlock','struct LegacySignalBlock'),
small.replace('struct SignalBlock','struct ProposedSignalBlock').replace('suppressed: Vec<Range<SignalSample>>','suppressed: Mask<SignalSample>')])+'\n'
(out/'production-shapes.rs').write_text(data)
sources=['crates/deadpan-audio/src/stages.rs','crates/deadpan-core/src/document.rs','crates/deadpan-core/src/time.rs','crates/deadpan-plan/src/audio_signal.rs']
(out/'production-shapes-pins.json').write_text(json.dumps({str(root/p):hashlib.sha256((root/p).read_bytes()).hexdigest() for p in sources},indent=2)+'\n')
