#![forbid(unsafe_code)]
#![allow(dead_code)]
use std::{collections::BTreeMap, mem::{align_of, offset_of, size_of}, ops::Range, sync::{Arc, atomic::AtomicU64}};

include!("production-shapes.rs");

struct Account { frames: AtomicU64 }
struct OwnedCharge { account: Arc<Account>, frames: u64 }
struct MaskStorage<T> { ranges: Vec<Range<T>>, ticket: OwnedCharge }
struct OwnedMask<T> { storage: Option<Box<MaskStorage<T>>> }
enum Mask<T> { Plain(Vec<Range<T>>), Owned(OwnedMask<T>) }
impl<T> Drop for OwnedMask<T> {
    fn drop(&mut self) {
        if let Some(boxed) = self.storage.take() {
            let MaskStorage { ranges, ticket } = unbox(boxed);
            drop(ranges);
            drop(ticket);
        }
    }
}
#[inline(never)]
fn unbox<T>(b: Box<T>) -> T { *b }

enum LegacyRead { Cached(Arc<LegacyReadBlock>), Fresh(LegacyReadBlock) }
enum ProposedRead { Cached(Arc<ProposedReadBlock>), Fresh(ProposedReadBlock) }
const _: () = {
    assert!(size_of::<Mask<AudioSample>>() == size_of::<Vec<Range<AudioSample>>>());
    assert!(align_of::<Mask<AudioSample>>() == align_of::<Vec<Range<AudioSample>>>());
    assert!(size_of::<LegacyReadBlock>() == size_of::<ProposedReadBlock>());
    assert!(align_of::<LegacyReadBlock>() == align_of::<ProposedReadBlock>());
    assert!(size_of::<LegacySignalBlock>() == size_of::<ProposedSignalBlock>());
    assert!(size_of::<LegacyRead>() == size_of::<ProposedRead>());
};
fn main() {
    macro_rules! layout { ($t:ty) => {
        println!("{} size={} align={}", stringify!($t), size_of::<$t>(), align_of::<$t>());
    }}
    layout!(Vec<Range<AudioSample>>);
    layout!(Mask<AudioSample>);
    layout!(MaskStorage<AudioSample>);
    layout!(OwnedCharge);
    layout!(OwnedMask<AudioSample>);
    layout!(Mask<SignalSample>);
    layout!(LegacyRead); layout!(ProposedRead);
    layout!(LegacyReadBlock); layout!(ProposedReadBlock);
    layout!(LegacySignalBlock); layout!(ProposedSignalBlock);
    println!("legacy read offsets start={} samples={} dependencies={} depth={} suppressed={} exhausted={}",
        offset_of!(LegacyReadBlock,start),offset_of!(LegacyReadBlock,samples),
        offset_of!(LegacyReadBlock,dependencies),offset_of!(LegacyReadBlock,relative_depth),
        offset_of!(LegacyReadBlock,suppressed),offset_of!(LegacyReadBlock,exhausted));
    println!("new read offsets start={} samples={} dependencies={} depth={} suppressed={} exhausted={}",
        offset_of!(ProposedReadBlock,start),offset_of!(ProposedReadBlock,samples),
        offset_of!(ProposedReadBlock,dependencies),offset_of!(ProposedReadBlock,relative_depth),
        offset_of!(ProposedReadBlock,suppressed),offset_of!(ProposedReadBlock,exhausted));
    println!("legacy signal offsets samples={} dependencies={} suppressed={} depth={}",
        offset_of!(LegacySignalBlock,samples),offset_of!(LegacySignalBlock,dependencies),
        offset_of!(LegacySignalBlock,suppressed),offset_of!(LegacySignalBlock,relative_depth));
    println!("new signal offsets samples={} dependencies={} suppressed={} depth={}",
        offset_of!(ProposedSignalBlock,samples),offset_of!(ProposedSignalBlock,dependencies),
        offset_of!(ProposedSignalBlock,suppressed),offset_of!(ProposedSignalBlock,relative_depth));
    let account = Arc::new(Account{frames:AtomicU64::new(0)});
    let mask=Mask::Owned(OwnedMask { storage: Some(Box::new(MaskStorage{ranges:vec![AudioSample(0)..AudioSample(1)],ticket:OwnedCharge{account,frames:1}})) });
    drop(mask);
    // No recursive replacement on the Plain path.
    drop(Mask::Plain(vec![AudioSample(0)..AudioSample(1)]));
}
