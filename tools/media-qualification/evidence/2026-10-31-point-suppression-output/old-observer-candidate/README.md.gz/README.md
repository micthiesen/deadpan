# OLD returned suppression ownership/pressure observer

Scratch-only candidate for the output-mask ownership unit based on published dd5fda5d83205aca0fc3480b7c0dae254224f133. No root edit, Cargo/rustc/native execution, capture, Git operation, expected-body generation, cap/weight change or ownership implementation.

## Integration and pins

New source:
new/crates/deadpan-audio/src/bound_reads/owned_suppression_baseline.rs
20,819 bytes, SHA-25659c66d97aaec3b5caa4822f0f915ccfb50db8e70ececfaa64d2678b0f71c12a7.

Each per-root patch adds that file and appends only a child module hook to retained_host_baseline.rs. No existing driver/observer behavior is edited.
Both existing-file before SHA8887fac71782789e66c6ac4886aa047b47349bb980569be447e5a61dc95a636b; after SHA39634a3d70736a3a665ab70c6aebfe3fc26d93fdbc7576f04d50084e207f6081.
Both patch SHAd85c2906f5f189145f55a4f44c8bda360c964522577406d25270c4006dda849f.
pins.json contains exact per-root pins and independent scratch patch reconstruction. before/, after/, apply-check/ are scratch copies only.

Fresh source-before manifests pin relevant Core/Plan/Audio Rust files, Cargo/toolchain, actual WAV and immutable current-before native body separately for each root. Both roots' baseline body was read-only verified27,674,397 bytes, SHA3d6338e4e4b0f5617647ab6e0fa4d80bf8882a87c87a55efe306002c3011dbdc.

## Five bounded actual cases

1. public-point-silent-hold: checked64-frame SilentHold at FrameRate48000, public definition/in_point_clock, actual16..32 reference read.
2. public-point-source: checked64-frame Source selecting real WAV0..64, same public Point read.
3. public-point-genuine-bound: unchanged cases[1].current Source a, same public Point construction/read16..32 as the existing proved native Bound test. The standalone ordinary query records actual content tags and literal work, then drops before the native reader. It is proof only, outside measured admission; no private binding or Point is forged.
4. aggregate-alternating-514-via-shared-equalizers: actual checked514 one-frame alternating SilentHold/Source sequence at FrameRate48000, every Source selecting real WAV0..1; request514 frames through read_shared_equalizers.
5. aggregate-alternating-514-via-shared-input: exact same checked514 document/request through read_shared_input(InputSelection::default).

These aggregate calls use existing general ReadBlock limit131072 and existing256-frame tiling. No caps are raised, no mask ranges are synthesized, and no257-range success is asserted. The real returned values and mask lengths, or actual document/compile/Point/budget errors, decide coverage. Aggregate document validation is fallible and retained, before compilation. The native WAV adapter/descriptor and observed provider reuse the actual retained_host_cases helpers.

## Complete returned values and real lifetime

SignalBlock and ReadBlock snapshots exhaustively destructure every current field. PCM f32 bits, dependencies, relative depth, ReadBlock start, suppressed and exhausted mask contents remain exact. Each actual mask includes len, capacity, Layout::array bytes/alignment from actual capacity, emptiness, full values and borrowed Vec helper/iterator outcomes. PCM Vec capacity/Layout is also recorded.

The actual result stays owned across:
- result snapshot while local ReadWork and observed provider live, with complete actual work/controller/provider snapshots;
- provider drop, then local ReadWork drop, followed by another borrowed result snapshot;
- controller drop, followed by a third borrowed result snapshot;
- only then final actual owning mask into_iter, including len/size_hint/as_slice, next/next_back and remaining order.

The three retained output snapshots must match exactly. There is no block clone, detached reconstruction, assumed lifetime extension or post-drop fake ReadWork snapshot. Plan and checked source document stay alive separately and unchanged. Errors remain complete typed native error snapshots with no invented successful output.

Old masks are ordinary unadmitted Vec storage. Requested Layout bytes are descriptive allocation requests, not accepted leases or allocator/RSS evidence. Observer JSON/provider snapshot allocations are harness work outside measured admission. Work/controller snapshots remain literal; no old counters or peaks are normalized.

Actual size/alignment is reported for SignalBlock, ReadBlock, Vec/Range for both clocks, PreparedBlock and PreparedStage. No new mask/storage/account type is introduced, and no future niche-layout size is asserted. The final owning iterator checks actual old Vec helpers without requiring public block Clone.

Existing parent snapshots may use their established diagnostic Debug fields for cache keys; these are reused unchanged. Actual returned mask/PCM/dependency/depth fields are serialized structurally and completely.

## Ignored entry points

Prefix:
stages::bound_reads::retained_host_baseline::owned_suppression_baseline

Capture:
capture_old_owned_suppression_output_v1

External independent full-body regression:
owned_suppression_output_matches_external_old_v1

Schema: old-owned-suppression-output-ownership-v1

Capture env:
DEADPAN_OWNED_SUPPRESSION_OUTPUT (fresh absolute /tmp file)
DEADPAN_OWNED_SUPPRESSION_VARIANT (main-inherited or scoped-published)
DEADPAN_OWNED_SUPPRESSION_SOURCE_SHA256 (parent's actual complete source manifest digest)
DEADPAN_OWNED_SUPPRESSION_PUBLISHED_CHECKPOINT (full dd5fda5d83205aca0fc3480b7c0dae254224f133)

Regression env: DEADPAN_OWNED_SUPPRESSION_EXPECTED, pointing at an independent immutable captured body. Only variant and source_sha256 outer fields are stripped. Checkpoint and prior native hash stay in semantic body. Capture creates its full body before create_new, then pretty-writes, flushes and syncs.

## Validation and owed work

Rustfmt parsed/formatted new source and rustfmt --check skip_children passed new source plus both existing-file after copies. prepare_candidate.py independently reconstructs every exact unified diff with context/deletion checking and compares resulting bytes; root before hashes remain current at generation and new files remain absent. Relevant source manifests were checked twice for read stability.

No typecheck or producer execution was performed. Parent owns compilation, fixing genuine compile errors, actual both-root native capture/equality, coverage adjudication and freezing before output ownership production integration. No expected body exists here.
