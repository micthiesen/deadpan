from pathlib import Path
import hashlib,json
s=Path(__file__).resolve().parent
source=(s/'point_suppression.rs').read_text()
prefix=source[source.index('const FRAME_BYTES'):source.index('impl Serialize for PointSuppressionMask')]
frames=source[source.index('fn frames_for('):source.index('#[cfg(test)]\nthread_local!')]
probe='''#![forbid(unsafe_code)]
use std::sync::Arc;
use std::sync::atomic::{AtomicU64,AtomicUsize,Ordering};
use std::ops::{Range,Deref};
use std::alloc::Layout;
use std::fmt;
#[derive(Clone,Copy,Debug,PartialEq,Eq)]
pub struct ReferenceSample(pub i64);
#[derive(Debug)]
pub enum StageAudioError { Range }
mod stages {
 use super::*;
 mod point_suppression {
 use super::*;
'''+prefix+frames+'''
#[cfg(test)]
mod probes {
 use super::*;
 fn mask(account:&mut Account, n:i64)->PointSuppressionMask {
  if account.handle.is_none() { account.initialize_after_admission(shell_frames().unwrap()); }
  let mut ranges=Vec::with_capacity(1);
  ranges.push(ReferenceSample(n)..ReferenceSample(n+1));
  let charge=account.charge_after_admission(payload_frames(ranges.capacity()).unwrap()).unwrap();
  PointSuppressionMask {value:Value::Owned(OwnedMask{storage:Some(Box::new(Storage{ranges,charge}))})}
 }
 #[test] fn retained_account_and_closed_observer() {
  let mut account=Account::default();let mask=mask(&mut account,0);let observer=account.observer().unwrap();
  let copy=observer.clone();assert_eq!(observer.live_frames(),10);drop(account);drop(copy);
  assert_eq!(observer.live_frames(),10);drop(mask);assert_eq!(observer.live_frames(),3);drop(observer);
 }
 #[test] fn simultaneous_last_handles_release_after_payloads() {
  for _ in 0..128 {
   let mut account=Account::default();
   let masks=(0..16).map(|n|mask(&mut account,n)).collect::<Vec<_>>();
   std::thread::scope(|scope|{scope.spawn(move||drop(account));for mask in masks{scope.spawn(move||drop(mask));}});
  }
 }
 #[test] fn remaining_observer_reads_base_after_concurrent_drops() {
  let mut account=Account::default();let masks=(0..64).map(|n|mask(&mut account,n)).collect::<Vec<_>>();
  let observer=account.observer().unwrap();assert_eq!(observer.live_frames(),3+64*7);drop(account);
  std::thread::scope(|scope|{for mask in masks {scope.spawn(move||drop(mask));}});
  assert_eq!(observer.live_frames(),3);
 }
 #[test] fn niche_layout_and_borrowed_values() {
  assert_eq!(std::mem::size_of::<PointSuppressionMask>(),24);
  assert_eq!(std::mem::size_of::<Charge>(),16);assert_eq!(std::mem::size_of::<Storage>(),40);
  assert_eq!(Layout::new::<ArcShell>().size(),24);
  let mut account=Account::default();let mask=mask(&mut account,-4);
  let values=vec![ReferenceSample(-4)..ReferenceSample(-3)];
  assert_eq!(mask,values);assert_eq!(values,mask);assert_eq!((&mask).into_iter().count(),1);
  assert_eq!(mask.capacity(),1);assert_eq!(mask.get(1),None);
 }
}
}}
'''
(s/'account-mask-microprobe.rs').write_text(probe)
(s/'microprobe-source-pin.json').write_text(json.dumps({'production_candidate_sha256':hashlib.sha256(source.encode()).hexdigest(),'extraction':'exact constFRAME through non-Serialize mask implementations + exact frames_for/shell_frames/payload_frames; ReferenceSample and error stubs only; no StageAudio runtime','probe_sha256':hashlib.sha256(probe.encode()).hexdigest()},indent=2)+'\n')
