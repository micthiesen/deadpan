# Narrow public Point suppression ownership candidate

Only point_suppression.rs is owned here. It is intended for crates/deadpan-audio/src/point_suppression.rs under the parent's stages module hook. No root edits, Cargo/project builds, native media/producer execution, captures, Git, cap changes, old-weight changes or golden changes. Parent owns stages hooks, public exports, ceiling integration and real-WAV tests.

Source: point_suppression.rs,18,827bytes, SHA3d4eff32ba8b22f9cc798221e3b935e8e5e7d70251e97c173afea6395fdc3872. module-pin.json records it. Rustfmt --check passed. Parent may integrate this exact source immediately and own compiler/test follow-ups.

## Bounded surface

ONLY public PointDomainAudioBlock.suppressed changes to PointSuppressionMask. Internal SignalBlock/ReadBlock/transfer masks remain Vec. This does not solve private Point policy admission or internal handoff ownership.

PointSuppressionMask provides immutable as_slice,iter,len,is_empty,capacity, borrowed IntoIterator and Deref to a slice. Debug, PartialEq<Self>, PartialEq<Vec> in both directions, Eq and Serialize expose only range values; JSON remains the same array. No Clone, detach, owning iterator, DerefMut, mutable range access or public storage/account access exists. External callers can still explicitly copy the returned slice; this cooperative API does not claim to meter arbitrary caller allocations.

Plain(Vec) retains the literal historical into_iter().map(domain.reference_at_signal).collect::<Result<_,_>>() conversion in the cfg(test) legacy lane. with_legacy_point_suppression(action) is unwind-safe and restores the prior TLS mode. Empty true mode returns an empty Plain Vec without initializing account, allocating destination Vec/Box or charging mapping work; it still checks the current stop condition.

Owned stores unique Option<Box<Storage{ranges:Vec,charge:Charge}>> behind a niche enum. OwnedMask Drop takes the Box, calls the noninlined safe unbox helper to free its allocation, drops the Vec, then drops Charge. On pre-Box failure, Storage fields put Vec before Charge. ReferenceSample labels are closed Copy values.

## Account and reservation

Account::default() is lazy. Account::live_frames() includes the actual heap shell while any closed handle keeps it alive. AccountData contains only AtomicU64 live_frames. Qualified pinned standard-library Arc layout is two AtomicUsize counters plus AccountData:24bytes/align8,3 stereo frame-equivalents. Design-review allocation probe/evidence is at /tmp/deadpan-point-policy-output-design-review-2026-10-31/account-reservation-contract.md and account-layout-probe.ll.

Every closed Handle drop takes its Option<Arc> and calls Arc::into_inner. The final extraction frees the Arc allocation before retiring its3 shell frames from the extracted stack counter. No Weak, raw Arc, try_unwrap race or self-Arc exists. Charge owns a closed Handle plus frames, releasing payload only after storage physically frees. Controller drop can precede masks and observers.

The sole mutable StageAudio publisher adds using atomic fetch_add. External concurrent mask/observer drops only subtract. A checked pre-add maximum protects overflow without storing a stale load-plus-add total. Account initialization and private charge methods are reached only after the runtime make_room/check gates; pure module tests use them directly to test ownership, not as runtime quota evidence.

admit_point_suppression(input Vec<SignalSample ranges>,domain,control):
- checks current cancellation/deadline and keeps the original ordinary unadmitted input Vec alive throughout;
- for the first nonempty mask, spends new account-allocation work, checks shell quota via make_room, checks stop, then initializes Arc with its live base;
- spends new destination-Vec and Storage-Box allocation work, checks exact Vec(count)+Storage payload quota, checks stop, and obtains the atomic payload charge BEFORE allocations;
- creates destination Vec with admitted exact capacity, checks that actual capacity equals count, maps each range only after its work/stop debit, then boxes completed Storage;
- performs the final stop check while the complete owned mask and input are still alive, drops input, then publishes.

A failure after account initialization leaves its actual shell resident until the controller/last handle drops. This is physical storage, not refunded work or a dead payload reservation. Mapping/quota/cancellation errors drop pending destination storage before payload charge. There are no accepted-work refunds.

Each range operation has exactly1 new host work unit covering two checked endpoint conversions and one push. Account, destination Vec and Box allocations each have1 separate new host work unit. These are additional native host work only; no canonical Plan receipt or historical work field is repriced.

## Parent hooks / tests

Production:
self.owned_suppression: point_suppression::Account
self.admit_point_suppression(block.suppressed,domain,control)
all parent resident ceilings include self.owned_suppression.live_frames()

cfg(test):
with_legacy_point_suppression(action)
Account::observer() -> Option<Observer>
Observer: Clone with live_frames(); every cloned observer remains a closed handle
work_trace::reset(), snapshot(), disable()
work_trace::residency_spent() immediately AFTER a successful parent ceiling spend_plan_work(1)

Snapshot is serde serializable and records constructor completed/failed/empty/ordinary counts plus accepted_account_allocation_units, accepted_vector_allocation_units, accepted_storage_allocation_units, accepted_range_mapping_units, accepted_residency_units and overflow. Trace callbacks add no work and are cfg(test), default-off, scalar-only. Parent's ceiling marker is independent from mapping/constructor phases and belongs after accepted debit, never before.

Holding an observer keeps the actual Arc shell resident: after controller and masks drop, observer.live_frames()==3 until observer itself drops. Do not fabricate an observable0 counter by forgetting the observer's physical shell.

Six in-module tests cover immutable value/Vec/serde parity, retained masks after controller/observer copies drop, concurrent payload drops, concurrent last handles, allocation-free default, and qualified layout. They do not exercise StageAudio quota/real media; parent owns those tests.

## Standalone verification performed

No Cargo or project executable was run. Authorized safe rustc microprobe mechanically extracted the actual account/mask implementations and frame-layout helpers, with only closed ReferenceSample/error stubs and independent standard-library tests. Source extraction/pins are recorded in microprobe-source-pin.json. Four tests passed: retained account observer, simultaneous last handles across128 batches, concurrent payload release with a remaining observer, and niche/value/Vec helper layout. Actual qualified outputs: mask24,Charge16,Storage40,ArcShell24; first one-range mask live10 frames(3base+7payload). The probe excludes serde/runtime control and is not a claim the full module compiles in the project.

Known bounds: only public final output ownership; Arc layout tied to the pinned qualified standard library; old input Vec and other public block metadata remain outside this new account; controller static Account field overhead is outside dynamic heap charge; internal masks/consumer metadata/recursive preparation remain separate.
