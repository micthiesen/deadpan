#![forbid(unsafe_code)]
use std::sync::Arc;
use std::sync::atomic::{AtomicU64,AtomicUsize,Ordering};
use std::ops::{Range,Deref};
use std::alloc::Layout;
use std::fmt;
#[derive(Clone,Copy,Debug,PartialEq,Eq)]
pub struct ReferenceSample(pub i64);
#[derive(Debug)]
pub enum StageAudioError { Range }
mod stages {
 use super::*;
 mod point_suppression {
 use super::*;
const FRAME_BYTES: u64 = std::mem::size_of::<[f32; 2]>() as u64;

struct AccountData {
    live_frames: AtomicU64,
}

// The pinned standard library's Arc allocation has these two counters before T.
// The qualified allocation-layout probe is part of this unit's evidence.
#[repr(C)]
struct ArcShell {
    strong: AtomicUsize,
    weak: AtomicUsize,
    data: AccountData,
}

struct Handle(Option<Arc<AccountData>>);
impl Handle {
    fn data(&self) -> &AccountData {
        self.0.as_ref().expect("live closed account handle")
    }

    fn duplicate(&self) -> Self {
        Self(Some(Arc::clone(
            self.0.as_ref().expect("live closed account handle"),
        )))
    }
}
impl Drop for Handle {
    fn drop(&mut self) {
        if let Some(handle) = self.0.take()
            && let Some(data) = Arc::into_inner(handle)
        {
            // into_inner has freed the Arc allocation before returning its data.
            let shell = frames_for(Layout::new::<ArcShell>()).expect("qualified Arc shell size");
            let previous = data.live_frames.fetch_sub(shell, Ordering::AcqRel);
            debug_assert_eq!(previous, shell, "all payload charges precede their handles");
        }
    }
}

#[derive(Default)]
pub(super) struct Account {
    handle: Option<Handle>,
}
impl Account {
    pub(super) fn live_frames(&self) -> u64 {
        self.handle.as_ref().map_or(0, |handle| {
            handle.data().live_frames.load(Ordering::Acquire)
        })
    }

    fn initialize_after_admission(&mut self, shell: u64) {
        debug_assert!(self.handle.is_none());
        self.handle = Some(Handle(Some(Arc::new(AccountData {
            live_frames: AtomicU64::new(shell),
        }))));
    }

    fn charge_after_admission(&mut self, frames: u64) -> Result<Charge, StageAudioError> {
        let handle = self.handle.as_ref().expect("admitted account shell");
        // This mutable controller is the sole publisher. Other threads only drop.
        handle
            .data()
            .live_frames
            .load(Ordering::Acquire)
            .checked_add(frames)
            .ok_or(StageAudioError::Range)?;
        handle
            .data()
            .live_frames
            .fetch_add(frames, Ordering::AcqRel);
        Ok(Charge {
            handle: handle.duplicate(),
            frames,
        })
    }

    #[cfg(test)]
    pub(super) fn observer(&self) -> Option<Observer> {
        self.handle
            .as_ref()
            .map(|handle| Observer(handle.duplicate()))
    }
}

#[cfg(test)]
pub(super) struct Observer(Handle);
#[cfg(test)]
impl Observer {
    pub(super) fn live_frames(&self) -> u64 {
        self.0.data().live_frames.load(Ordering::Acquire)
    }
}
#[cfg(test)]
impl Clone for Observer {
    fn clone(&self) -> Self {
        Self(self.0.duplicate())
    }
}

struct Charge {
    handle: Handle,
    frames: u64,
}
impl Drop for Charge {
    fn drop(&mut self) {
        let previous = self
            .handle
            .data()
            .live_frames
            .fetch_sub(self.frames, Ordering::AcqRel);
        debug_assert!(previous >= self.frames);
    }
}

struct Storage {
    ranges: Vec<Range<ReferenceSample>>,
    charge: Charge,
}

struct OwnedMask {
    storage: Option<Box<Storage>>,
}

// Keep physical Box deallocation ahead of both the Vec and its charge.
#[inline(never)]
fn unbox<T>(boxed: Box<T>) -> T {
    *boxed
}
impl Drop for OwnedMask {
    fn drop(&mut self) {
        if let Some(storage) = self.storage.take() {
            let Storage { ranges, charge } = unbox(storage);
            drop(ranges);
            drop(charge);
        }
    }
}

enum Value {
    Plain(Vec<Range<ReferenceSample>>),
    Owned(OwnedMask),
}

/// Immutable suppression ranges whose admitted storage may outlive StageAudio.
pub struct PointSuppressionMask {
    value: Value,
}
impl PointSuppressionMask {
    pub fn as_slice(&self) -> &[Range<ReferenceSample>] {
        self.ranges()
    }

    pub fn iter(&self) -> std::slice::Iter<'_, Range<ReferenceSample>> {
        self.as_slice().iter()
    }

    pub fn len(&self) -> usize {
        self.as_slice().len()
    }

    pub fn is_empty(&self) -> bool {
        self.as_slice().is_empty()
    }

    pub fn capacity(&self) -> usize {
        self.ranges().capacity()
    }

    fn ranges(&self) -> &Vec<Range<ReferenceSample>> {
        match &self.value {
            Value::Plain(value) => value,
            Value::Owned(value) => {
                &value
                    .storage
                    .as_ref()
                    .expect("live unique mask storage")
                    .ranges
            }
        }
    }
}
impl Default for PointSuppressionMask {
    fn default() -> Self {
        Self {
            value: Value::Plain(Vec::new()),
        }
    }
}
impl Deref for PointSuppressionMask {
    type Target = [Range<ReferenceSample>];
    fn deref(&self) -> &Self::Target {
        self.as_slice()
    }
}
impl<'a> IntoIterator for &'a PointSuppressionMask {
    type Item = &'a Range<ReferenceSample>;
    type IntoIter = std::slice::Iter<'a, Range<ReferenceSample>>;
    fn into_iter(self) -> Self::IntoIter {
        self.iter()
    }
}
impl PartialEq for PointSuppressionMask {
    fn eq(&self, other: &Self) -> bool {
        self.as_slice() == other.as_slice()
    }
}
impl PartialEq<Vec<Range<ReferenceSample>>> for PointSuppressionMask {
    fn eq(&self, other: &Vec<Range<ReferenceSample>>) -> bool {
        self.as_slice() == other.as_slice()
    }
}
impl PartialEq<PointSuppressionMask> for Vec<Range<ReferenceSample>> {
    fn eq(&self, other: &PointSuppressionMask) -> bool {
        self.as_slice() == other.as_slice()
    }
}
impl Eq for PointSuppressionMask {}
impl fmt::Debug for PointSuppressionMask {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.as_slice().fmt(f)
    }
}
fn frames_for(layout: Layout) -> Result<u64, StageAudioError> {
    Ok(u64::try_from(layout.size())
        .map_err(|_| StageAudioError::Range)?
        .div_ceil(FRAME_BYTES))
}
pub(super) fn shell_frames() -> Result<u64, StageAudioError> {
    frames_for(Layout::new::<ArcShell>())
}
pub(super) fn payload_frames(capacity: usize) -> Result<u64, StageAudioError> {
    let vector =
        Layout::array::<Range<ReferenceSample>>(capacity).map_err(|_| StageAudioError::Range)?;
    frames_for(vector)?
        .checked_add(frames_for(Layout::new::<Storage>())?)
        .ok_or(StageAudioError::Range)
}


#[cfg(test)]
mod probes {
 use super::*;
 fn mask(account:&mut Account, n:i64)->PointSuppressionMask {
  if account.handle.is_none() { account.initialize_after_admission(shell_frames().unwrap()); }
  let mut ranges=Vec::with_capacity(1);
  ranges.push(ReferenceSample(n)..ReferenceSample(n+1));
  let charge=account.charge_after_admission(payload_frames(ranges.capacity()).unwrap()).unwrap();
  PointSuppressionMask {value:Value::Owned(OwnedMask{storage:Some(Box::new(Storage{ranges,charge}))})}
 }
 #[test] fn retained_account_and_closed_observer() {
  let mut account=Account::default();let mask=mask(&mut account,0);let observer=account.observer().unwrap();
  let copy=observer.clone();assert_eq!(observer.live_frames(),10);drop(account);drop(copy);
  assert_eq!(observer.live_frames(),10);drop(mask);assert_eq!(observer.live_frames(),3);drop(observer);
 }
 #[test] fn simultaneous_last_handles_release_after_payloads() {
  for _ in 0..128 {
   let mut account=Account::default();
   let masks=(0..16).map(|n|mask(&mut account,n)).collect::<Vec<_>>();
   std::thread::scope(|scope|{scope.spawn(move||drop(account));for mask in masks{scope.spawn(move||drop(mask));}});
  }
 }
 #[test] fn remaining_observer_reads_base_after_concurrent_drops() {
  let mut account=Account::default();let masks=(0..64).map(|n|mask(&mut account,n)).collect::<Vec<_>>();
  let observer=account.observer().unwrap();assert_eq!(observer.live_frames(),3+64*7);drop(account);
  std::thread::scope(|scope|{for mask in masks {scope.spawn(move||drop(mask));}});
  assert_eq!(observer.live_frames(),3);
 }
 #[test] fn niche_layout_and_borrowed_values() {
  assert_eq!(std::mem::size_of::<PointSuppressionMask>(),24);
  assert_eq!(std::mem::size_of::<Charge>(),16);assert_eq!(std::mem::size_of::<Storage>(),40);
  assert_eq!(Layout::new::<ArcShell>().size(),24);
  let mut account=Account::default();let mask=mask(&mut account,-4);
  let values=vec![ReferenceSample(-4)..ReferenceSample(-3)];
  assert_eq!(mask,values);assert_eq!(values,mask);assert_eq!((&mask).into_iter().count(),1);
  assert_eq!(mask.capacity(),1);assert_eq!(mask.get(1),None);
 }
}
}}
