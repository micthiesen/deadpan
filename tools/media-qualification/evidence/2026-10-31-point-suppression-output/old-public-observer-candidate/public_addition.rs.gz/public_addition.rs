
fn public_mask<T: Copy>(value: &[Range<T>], capacity: usize, at: fn(T) -> i64) -> Value {
    let range = |r: &Range<T>| [at(r.start), at(r.end)];
    let mut iterator = value.iter();
    let initial = iterator.size_hint();
    let first = iterator.next().map(range);
    let last = iterator.next_back().map(range);
    json!({"len":value.len(),"capacity":capacity,"is_empty":value.is_empty(),
        "requested_storage":vector_layout::<Range<T>>(capacity),
        "values":value.iter().map(range).collect::<Vec<_>>(),
        "helpers":{"first":value.first().map(range),"last":value.last().map(range),
            "get_at_len":value.get(value.len()).map(range),
            "forward_prefix":value.iter().take(3).map(range).collect::<Vec<_>>(),
            "reverse_prefix":value.iter().rev().take(3).map(range).collect::<Vec<_>>(),
            "nth_two":value.iter().nth(2).map(range),
            "iterator_initial_size_hint":initial,
            "iterator_first":first,"iterator_last_after_first":last,
            "iterator_remaining_len":iterator.len(),
            "iterator_remaining_size_hint":iterator.size_hint()}})
}
fn public_result(value: &Result<PointDomainAudioBlock, StageAudioError>) -> Value {
    match value {
        Ok(block) => {
            let PointDomainAudioBlock {
                schema_version,
                stage,
                project_id,
                revision_id,
                definition,
                root,
                placement,
                reference_grid,
                reference_samples,
                start,
                samples,
                suppressed,
            } = block;
            json!({"status":"Ok","kind":"PointDomainAudioBlock","schema_version":schema_version,
                "stage":stage,"project_id":project_id,"revision_id":revision_id,
                "definition":definition,"root":root,"placement":placement,
                "reference_grid":reference_grid,"reference_samples":reference_samples,
                "start":start.0,"f32_bits":samples.iter().map(|s|s.map(f32::to_bits)).collect::<Vec<_>>(),
                "sample_storage":vector_layout::<[f32;2]>(samples.capacity()),
                "suppressed":public_mask(suppressed.as_slice(),suppressed.capacity(),|at:ReferenceSample|at.0)})
        }
        Err(value) => json!({"status":"Error","kind":"PointDomainAudioBlock","error":error(value)}),
    }
}
struct PublicProvider {
    prepared: crate::PreparedSource,
    calls: usize,
    events: Vec<Value>,
}
impl AudioSourceProvider for PublicProvider {
    fn source(
        &mut self,
        project: &ProjectId,
        revision: &RevisionId,
        asset: &AssetId,
        cancelled: &AtomicBool,
    ) -> Result<&crate::PreparedSource, PreparationError> {
        self.calls += 1;
        self.events.push(json!({"ordinal":self.calls,"project_id":project,"revision_id":revision,
            "asset":asset,"cancelled_before":cancelled.load(Ordering::Relaxed),
            "outcome":"PreparedSource","prepared_provenance":self.prepared.provenance(),
            "prepared_index":self.prepared.index(),"matrix_layout":self.prepared.matrix_layout()}));
        Ok(&self.prepared)
    }
}
fn public_case_owned(case: Case, name: &'static str) -> Value {
    let mut row = json!({"name":name,"source":case.source,"checked_document_wire":case.checked_wire,
        "wav":cases::wav_descriptor(cases::Wav::Stereo48000),
        "scope":{"reader":"actual public StageAudio::read_point_domain final conversion",
            "work":"public method owns and drops its inaccessible internal ReadWork before returning; no external ledger substituted",
            "lifetime":"returned public block held beyond public method return and controller drop",
            "mask_observation":"borrowed values/helpers/capacity only; no block clone or owning mask iteration"}});
    let document = match case.document {
        Ok(value) => value,
        Err(value) => {
            row["setup"] = json!({"status":"DocumentValidationError",
                "error":error(&StageAudioError::from(PlanError::from(value)))});
            return row;
        }
    };
    row["document_before"] = serde_json::to_value(&document).unwrap();
    let plan = match RenderPlan::compile(&document) {
        Ok(value) => Arc::new(value),
        Err(value) => {
            row["setup"] = json!({"status":"CompileError","error":error(&value.into())});
            row["document_after"] = serde_json::to_value(&document).unwrap();
            assert_eq!(row["document_before"],row["document_after"]);
            return row;
        }
    };
    let Reader::Point { node,offset,frames } = case.reader else {
        unreachable!("only the three actual Point cases feed the public observer")
    };
    let domain = match point(&plan,node) {
        Ok(value) => value,
        Err(value) => {
            row["setup"] = json!({"status":"PointConstructionError","error":error(&value)});
            row["document_after"] = serde_json::to_value(&document).unwrap();
            assert_eq!(row["document_before"],row["document_after"]);
            return row;
        }
    };
    row["setup"] = json!({"status":"Ready","plan":plan_identity(&plan),
        "point":point_snapshot(&domain,&plan)});
    let start = ReferenceSample(domain.reference_samples().start.0.checked_add(offset).unwrap());
    row["request"] = json!({"reader":"StageAudio::read_point_domain","start":start.0,
        "frames":frames,"timeout_seconds":TIMEOUT.as_secs()});
    let mut renderer = StageAudio::new(Arc::clone(&plan));
    let cancelled = AtomicBool::new(false);
    let mut provider = PublicProvider {
        prepared:cases::prepared(cases::Wav::Stereo48000),
        calls:0,events:Vec::new(),
    };
    row["controller_before"] = controller_snapshot(&renderer);
    let result = renderer.read_point_domain(&mut provider,&domain,start,frames,TIMEOUT,&cancelled);
    row["result_after_public_method_internal_work_drop"] = public_result(&result);
    row["controller_result_alive"] = controller_snapshot(&renderer);
    row["provider_calls"] = json!(provider.calls);
    row["provider_events"] = json!(provider.events);
    row["cancelled_at_end"] = json!(cancelled.load(Ordering::Relaxed));
    drop(provider);
    row["result_after_provider_drop"] = public_result(&result);
    assert_eq!(row["result_after_public_method_internal_work_drop"],row["result_after_provider_drop"]);
    row["point_after_read"] = point_snapshot(&domain,&plan);
    assert_eq!(row["setup"]["point"],row["point_after_read"]);
    drop(renderer);
    row["result_after_controller_drop"] = public_result(&result);
    assert_eq!(row["result_after_public_method_internal_work_drop"],row["result_after_controller_drop"]);
    drop(result);
    row["actual_public_result_dropped_after_controller"] = json!(true);
    row["document_after"] = serde_json::to_value(&document).unwrap();
    assert_eq!(row["document_before"],row["document_after"]);
    row
}
fn public_cases_owned() -> Vec<Value> {
    let names = ["public-api-point-silent-hold","public-api-point-source","public-api-point-genuine-bound"];
    cases_owned().into_iter().take(3).zip(names).map(|(case,name)|public_case_owned(case,name)).collect()
}
