# Additive direct public Point output OLD observer

Scratch-only follow-up to the integrated59c66d97... observer. No root edits, build/native execution, captures, expected bodies, mask/account implementation or Git actions.

Each per-root patch changes only bound_reads/owned_suppression_baseline.rs. Fresh before hash is59c66d97aaec3b5caa4822f0f915ccfb50db8e70ececfaa64d2678b0f71c12a7. pins.json gives exact after/patch hashes and successful independent exact context/deletion reconstruction. Rustfmt --check passed both after copies.

Existing five private reader cases and their literal functions/data remain unchanged. Three additive public_cases entries directly call actual StageAudio::read_point_domain for the same checked SilentHold,Source and genuineBound documents, selecting public definitions and reading actual16..32 reference positions. The existing public native method performs its real final mask conversion. No private fake Point/binding is introduced.

public_result exhaustively destructures EVERY current PointDomainAudioBlock field, including identity, definition/root/placement, reference grid/support/start, stage/schema, exact PCM f32 bits/capacity, and actual mask borrowed values/helpers/len/capacity/Layout. It captures the actual result after method return (thus its internal ReadWork has already dropped), after provider drop, and after controller drop; snapshots must stay equal. The actual public result is dropped last. No public block Clone or owning mask iterator is required. Public mask access uses as_slice()/capacity(), matching the planned immutable opaque surface.

PublicProvider reuses the real retained WAV preparation and records actual callback identities/provenance/index/layout/cancellation state. It deliberately has no fake external work ledger: the public method's internal ReadWork is inaccessible, and scope says this explicitly. Private five-case work/controller/provider evidence remains separate and unchanged.

matrix_owned adds public_cases and actual PointDomainAudioBlock size/align. Same ignored capture/external regression names, schema and five DEADPAN_OWNED_SUPPRESSION_* env names as prior candidate. No captures have been generated. Parent compiles, captures both variants, adjudicates all8cases, freezes OLD body before runtime ownership changes, and later owns compatibility adaptation. This source adds no future represented type.
