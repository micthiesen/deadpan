from pathlib import Path
import hashlib,json,difflib
s=Path(__file__).resolve().parent
roots={'main-inherited':Path('/Users/michael/Code/deadpan'),'scoped-published':Path('/tmp/deadpan-query-groundwork-2026-10-26/scoped')}
name='crates/deadpan-audio/src/bound_reads/owned_suppression_baseline.rs'
pins={}
addition=(s/'public_addition.rs').read_text()
for variant,root in roots.items():
 before=(root/name).read_bytes()
 assert hashlib.sha256(before).hexdigest()=='59c66d97aaec3b5caa4822f0f915ccfb50db8e70ececfaa64d2678b0f71c12a7'
 text=before.decode()
 anchor='fn matrix_owned() -> Value {'
 assert text.count(anchor)==1
 after=text.replace(anchor,addition+'\n'+anchor)
 anchor='"cases":cases_owned().into_iter().map(case_owned).collect::<Vec<_>>(),'
 assert after.count(anchor)==1
 after=after.replace(anchor,anchor+'\n        "public_cases":public_cases_owned(),')
 anchor='"actual_layouts":{"SignalBlock":structure::<SignalBlock>(),"ReadBlock":structure::<ReadBlock>(),'
 assert after.count(anchor)==1
 after=after.replace(anchor,anchor+'\n            "PointDomainAudioBlock":structure::<PointDomainAudioBlock>(),')
 for folder,data in [('before',before),('after',after.encode())]:
  p=s/folder/variant/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data)
 pins[variant]={'path':name,'before_bytes':len(before),'before_sha256':hashlib.sha256(before).hexdigest()}
(s/'before-pins.json').write_text(json.dumps(pins,indent=2)+'\n')
