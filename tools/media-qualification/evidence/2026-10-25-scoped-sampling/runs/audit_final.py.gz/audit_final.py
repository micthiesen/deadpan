from pathlib import Path
import gzip,hashlib,json,sys
scratch=Path('/tmp/deadpan-scoped-sampling-2026-10-25')
evidence=Path(sys.argv[1])
sha=lambda b:hashlib.sha256(b).hexdigest()
inv=json.loads((evidence/'inventory.json').read_text())
errors=[]
for e in inv['files']:
    b=(evidence/e['path']).read_bytes()
    if len(b)!=e['stored_bytes'] or sha(b)!=e['stored_sha256']:
        errors.append('stored:'+e['path']); continue
    raw=gzip.decompress(b) if e['compression']=='gzip' else b
    if len(raw)!=e['source_bytes'] or sha(raw)!=e['source_sha256']:
        errors.append('payload:'+e['path'])
for n,m in inv['metadata'].items():
    b=(evidence/n).read_bytes()
    if len(b)!=m['bytes'] or sha(b)!=m['sha256']: errors.append('metadata:'+n)
for o in inv['omissions']:
    p=Path(o['source'])
    if p.exists():
        b=p.read_bytes()
        if len(b)!=o['bytes'] or sha(b)!=o['sha256']: errors.append('omission:'+str(p))

def j(path): return json.loads(Path(path).read_text())
names=['check-fifth','release-build-first','release-visual-first','release-quiet-first','media-first','media-second','native-debug-third']
receipts={n:j(scratch/(n+'.json')) for n in names}
run_summary={n:{'exit_code':d.get('exit_code'),'sources_unchanged':d.get('sources_unchanged'),'binaries_unchanged':d.get('binaries_unchanged'),'source_count':len(d.get('source_before',{}))} for n,d in receipts.items()}
for n,d in receipts.items():
    if d.get('exit_code')!=0 and n!='media-first': errors.append('unexpected run status '+n+':'+str(d.get('exit_code')))
    if n!='media-first' and (not d.get('sources_unchanged') or not d.get('binaries_unchanged')): errors.append('identity changed:'+n)
# Complete source-map equality across final, media and native qualification receipts.
base=receipts['media-second'].get('source_before',{})
for n in ('media-second','release-visual-first','release-quiet-first','native-debug-third'):
    d=receipts[n]
    if d.get('source_before')!=d.get('source_after'): errors.append('per-run source diff:'+n)
    if d.get('source_before')!=base: errors.append('cross-run source map diff:'+n)
# Build/binary manifests and runtime pins.
manifest=j(scratch/'release-binaries.json')
app=manifest['deadpan-app']
for n in ('release-visual-first','release-quiet-first'):
    d=receipts[n]
    values=list(d.get('binary_after',{}).values())
    if not any(v.get('sha256')==app['sha256'] and v.get('bytes')==app['bytes'] for v in values): errors.append('app pin mismatch:'+n)
result=j(scratch/'media-second'/'result.json')
for rel,expected in [('native-ranged.mp4',result['native_movie_sha256']),('captured-static-control.mp4',result['static_control_movie_sha256'])]:
    b=(scratch/'media-second'/rel).read_bytes()
    if sha(b)!=expected: errors.append('movie hash mismatch:'+rel)
comparison=j(scratch/'media-second'/'source-package-comparison.json')
if not comparison.get('persistent_path_bytes_and_sha256_equal') or comparison.get('changed_persistent_files') or comparison.get('added_persistent_paths') or comparison.get('removed_persistent_paths'): errors.append('source package preservation')
if result.get('frames_checked')!=240 or result.get('canonical_stereo_sample_frames')!=384384 or not result.get('authored_limited_and_limiter_gain_bits_equal'): errors.append('media proof assertion')
pixels=j(scratch/'media-second'/'all-240-decoded-picture-comparison.json')
same=[x for x in pixels if x.get('reference_identical') is True]
changed=[x for x in pixels if x.get('reference_identical') is False]
changed_frames=sorted(x['frame'] for x in changed)
if len(pixels)!=240 or len(same)!=210 or len(changed)!=30 or changed_frames!=list(range(170,200)):
    errors.append('canonical picture identity classification')
cross=j(scratch/'media-second'/'static-reference-cross-verification.json')
if not cross.get('passed') or cross.get('summary',{}).get('pictures_checked')!=210 or cross.get('summary',{}).get('pictures_failed')!=0:
    errors.append('unchanged picture cross verification')
negative_controls=[]
for fn in ('final-against-static-negative.json','static-against-final-negative.json'):
    d=j(scratch/'media-second'/fn)
    n={'passed':d.get('passed'),'checked':d.get('summary',{}).get('pictures_checked'),'failed':d.get('summary',{}).get('pictures_failed')}
    negative_controls.append(n)
    if d.get('passed') is not False or n['checked']!=30 or n['failed']!=30: errors.append('30-frame negative control:'+fn)
if receipts['media-first'].get('exit_code')!=1: errors.append('media-first failure not retained')
oracle=j(scratch/'media'/'oracle-boundary-check.json')
recon=scratch/'media'/'media-first-driver-reconstructed.py'
if sha(recon.read_bytes())!=oracle.get('source_sha256'): errors.append('reconstructed media driver does not match prior pin')
# The two selected screenshots match across debug and final release runs.
shots={}
for n in (128,129):
    key=f'scoped-follow-creep-{n}.png'
    p=scratch/'release-visual-first'/key
    b=p.read_bytes(); shots[key]={'bytes':len(b),'sha256':sha(b)}
    pd=scratch/'native-debug-third'/key
    if sha(pd.read_bytes())!=sha(b): errors.append('screenshot mismatch:'+key)
out={'result':'pass' if not errors else 'fail','errors':errors,'inventory_counts':inv['counts'],'inventory_sha256':sha((evidence/'inventory.json').read_bytes()),'readme_sha256':sha((evidence/'README.md').read_bytes()),'run_summary':run_summary,'source_map_files':len(base),'release_app_binary':app,'media':{'frames':result['frames_checked'],'canonical_sample_frames':result['canonical_stereo_sample_frames'],'identical_to_static':len(same),'changed_frames':changed_frames,'unchanged_cross_verified':cross['summary']['pictures_checked'],'negative_controls':negative_controls,'authored_limited_limiter_bits_equal':result['authored_limited_and_limiter_gain_bits_equal'],'source_package_equal':comparison['persistent_path_bytes_and_sha256_equal'],'native_mp4_sha256':result['native_movie_sha256'],'static_mp4_sha256':result['static_control_movie_sha256']},'reconstructed_media_first_script_sha256':sha(recon.read_bytes()),'screenshot_hashes':shots}
print(json.dumps(out,sort_keys=True))
if errors: raise SystemExit(1)
