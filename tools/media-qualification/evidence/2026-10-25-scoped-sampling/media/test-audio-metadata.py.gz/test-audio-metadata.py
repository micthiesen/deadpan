#!/usr/bin/env python3
"""Offline positive/tamper controls over retained native document copies."""
import copy
import hashlib
import json
from pathlib import Path
import sqlite3

HERE = Path(__file__).resolve().parent
RUN = HERE.parent / 'media-first'
SOURCE = HERE / 'media.py'
namespace = {}
prefix = SOURCE.read_text().split('parser = argparse.ArgumentParser', 1)[0]
exec(compile(prefix, str(SOURCE), 'exec'), namespace)
check = namespace['isolated_audio_metadata']
baseline = json.loads((RUN / 'read-only-helper/baseline-document.json').read_text())
document = json.loads((RUN / 'read-only-helper/final-document.json').read_text())
report = json.loads((RUN / 'native-report.json').read_text())
effects = [c for c in report['scenarios'][-1]['checks']
           if c['name'].startswith('Sampled Time framing changes')]
aliases = effects[-1]['actual']['aliases']
with sqlite3.connect((RUN / 'portable-final.deadpan/project.sqlite').as_uri() + '?mode=ro', uri=True) as db:
    rows = db.execute('SELECT id FROM revisions WHERE parent_id=? AND kind=?',
                      (baseline['revision_id'], 'edit')).fetchall()
assert len(rows) == 1
allocation = rows[0][0]
positive = check(baseline, document, aliases, allocation)
source = next(k for k, node in baseline['nodes'].items() if node['kind']['type'] == 'source')
cloned_source = next(k for k, old in aliases.items() if old == source)
repeat = next(k for k in aliases if document['nodes'][k]['kind']['type'] == 'repeat')
old_repeat = aliases[repeat]
seeded = next(k for k in set(aliases.values()) if k not in baseline['audio_lineage'])
controls = []


def deny(name, mutate):
    changed = copy.deepcopy(document)
    mutate(changed)
    try:
        check(baseline, changed, aliases, allocation)
    except AssertionError as error:
        controls.append({'name': name, 'rejected': True, 'reason': str(error)})
    else:
        raise AssertionError(f'tamper control accepted: {name}')


deny('original lineage changed', lambda d: d['audio_lineage'][source].update(origin=old_repeat))
deny('new original seed omitted', lambda d: d['audio_lineage'].pop(seeded))
deny('clone lineage allocation changed', lambda d: d['audio_lineage'][cloned_source].update(allocation=allocation))
deny('clone lineage origin changed', lambda d: d['audio_lineage'][cloned_source].update(origin=cloned_source))
deny('original timing table changed', lambda d: d['audio_bindings']['timings'][0]['layout'].update(rate={'numerator': 30, 'denominator': 1}))
deny('original binding changed', lambda d: d['audio_bindings']['bindings'][source]['lattice']['reference'].update(physical=cloned_source))
deny('clone historical physical alias changed', lambda d: d['audio_bindings']['bindings'][cloned_source]['lattice']['reference'].update(physical=cloned_source))
deny('clone live Repeat was not remapped', lambda d: d['audio_bindings']['bindings'][cloned_source]['reanchors'][0]['placement']['arguments'][0]['value'].update(repeat=old_repeat))
deny('clone historical Repeat alias was remapped', lambda d: d['audio_bindings']['bindings'][cloned_source]['reanchors'][0]['placement']['arguments'][0].update(reference_repeat=repeat))
deny('clone birth owner was not remapped', lambda d: d['audio_bindings']['bindings'][cloned_source]['reanchors'][0]['placement']['births'][0].update(repeat=old_repeat))
deny('clone reanchor window changed', lambda d: d['audio_bindings']['bindings'][cloned_source]['reanchors'][0]['window']['start'].update(numerator='37'))
deny('clone gap issuer was not remapped', lambda d: d['audio_bindings']['gap_bindings'][repeat]['lattice']['gap_after'].update(repeat=old_repeat))
deny('original gap binding removed', lambda d: d['audio_bindings']['gap_bindings'].pop(old_repeat))
deny('unexpected binding added', lambda d: d['audio_bindings']['bindings'].update({repeat: copy.deepcopy(d['audio_bindings']['bindings'][source])}))
result = {'driver_sha256': hashlib.sha256(SOURCE.read_bytes()).hexdigest(),
          'test_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
          'fixture': str(RUN), 'positive': positive, 'tamper_controls': controls,
          'passed': len(controls) == 14 and all(row['rejected'] for row in controls)}
(HERE / 'audio-metadata-controls.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({'passed': result['passed'], 'tamper_controls': len(controls),
                  'final_lineage_entries': positive['final_lineage_entries'],
                  'final_binding_entries': positive['final_binding_entries'],
                  'final_gap_binding_entries': positive['final_gap_binding_entries']}))
