#!/usr/bin/env python3
"""Build the read-only helper using artifacts of one completed Cargo invocation.

This does not invoke Cargo. Call only after the parent has finished its release
build. --cargo-artifacts is that invocation's --message-format=json stdout.
Refuses ambiguous artifacts rather than choosing the newest or scanning deps.
With -vv stderr, --cargo-build-log can prove the runtime serde_json selection.
"""
import argparse
import hashlib
import json
import os
from pathlib import Path
import shlex
import subprocess
import time

p = argparse.ArgumentParser(description=__doc__)
p.add_argument('--bin', type=Path, required=True)
p.add_argument('--ffmpeg-prefix', type=Path, required=True)
p.add_argument('--cargo-artifacts', type=Path, required=True)
p.add_argument('--cargo-build-log', type=Path)
p.add_argument('--output', type=Path, required=True)
a = p.parse_args()
a.bin = a.bin.resolve(strict=True)
a.ffmpeg_prefix = a.ffmpeg_prefix.resolve(strict=True)
a.cargo_artifacts = a.cargo_artifacts.resolve(strict=True)
if a.cargo_build_log is not None:
    a.cargo_build_log = a.cargo_build_log.resolve(strict=True)
a.output = a.output.absolute()
assert not a.output.exists()
source = Path(__file__).with_name('media-helper.rs').resolve(strict=True)
deps = a.bin / 'deps'
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
events = []
for number, raw in enumerate(a.cargo_artifacts.read_bytes().splitlines(), 1):
    if raw.strip():
        message = json.loads(raw)
        assert isinstance(message, dict), (a.cargo_artifacts, number, 'not an event object')
        events.append({'line': number, 'raw_sha256': hashlib.sha256(raw).hexdigest(),
                       'message': message})
finished = [row for row in events if row['message'].get('reason') == 'build-finished']
assert len(finished) == 1 and finished[0]['message'].get('success') is True, 'require one successfully completed build eventstream'


def candidates(name):
    paths = {}
    for row in events:
        message = row['message']
        if (message.get('reason') != 'compiler-artifact' or
                message.get('target', {}).get('name') != name or
                not set(message['target'].get('kind', [])).intersection(('lib', 'rlib'))):
            continue
        for filename in message.get('filenames', []):
            path = Path(filename).resolve(strict=True)
            if path.suffix == '.rlib':
                assert path.parent in (deps, a.bin), ('unexpected release artifact directory', name, path, deps)
                paths.setdefault(path, []).append(row)
    assert paths, ('no compiler-artifact rlib in supplied build stream', name)
    return paths


selected = {}
candidate_sets = {name: candidates(name) for name in
                  ['deadpan_cli', 'deadpan_core', 'deadpan_plan', 'deadpan_store', 'serde_json']}
for name, paths in candidate_sets.items():
    if len(paths) == 1:
        selected[name] = next(iter(paths))
    elif name != 'serde_json':
        raise AssertionError(('ambiguous current-build artifacts; no newest-file fallback', name, list(map(str, paths))))

verbose_witnesses = []
if 'serde_json' not in selected and a.cargo_build_log is not None:
    # The artifact suffix identifies the exact library invocation, excluding
    # unrelated host/build dependencies and any other feature-set compilation.
    cli_hash = sha(selected['deadpan_cli'])
    for number, line in enumerate(a.cargo_build_log.read_text().splitlines(), 1):
        if 'Running `' not in line:
            continue
        command = line.split('Running `', 1)[1]
        if command.endswith('`'):
            command = command[:-1]
        words = shlex.split(command)
        if '--crate-name' not in words:
            continue
        crate = words[words.index('--crate-name') + 1]
        if crate not in ('deadpan_cli', 'deadpan_app'):
            continue
        externs = [words[index + 1] for index, word in enumerate(words[:-1]) if word == '--extern']
        # A fresh CLI may have no Running rustc line. The final app invocation
        # proves the same runtime dependencies when both exact externs match
        # artifacts in this one successful stream.
        if crate == 'deadpan_app':
            cli_paths = [Path(value.split('=', 1)[1]).resolve(strict=True)
                         for value in externs if value.startswith('deadpan_cli=')]
            if cli_paths != [selected['deadpan_cli']]:
                continue
        codegen = [words[index + 1] for index, word in enumerate(words[:-1]) if word == '-C']
        suffixes = [value.removeprefix('extra-filename=') for value in codegen
                    if value.startswith('extra-filename=')]
        if len(suffixes) != 1:
            continue
        assert '--out-dir' in words
        out_dir = Path(words[words.index('--out-dir') + 1]).resolve(strict=True)
        if out_dir != deps:
            continue
        if crate == 'deadpan_cli':
            invoked_library = out_dir / ('libdeadpan_cli' + suffixes[0] + '.rlib')
            if not invoked_library.is_file() or sha(invoked_library) != cli_hash:
                continue
        else:
            invoked_library = selected['deadpan_cli']
            # Require the exact app binary artifact too, not just any app
            # command whose shared dependency happens to have matching bytes.
            app_events = [row for row in events if row['message'].get('reason') == 'compiler-artifact'
                          and row['message'].get('target', {}).get('name') == 'deadpan-app'
                          and row['message'].get('executable') is not None
                          and Path(row['message']['executable']).resolve(strict=True) == a.bin / 'deadpan-app']
            assert app_events, 'app dependency witness lacks final app executable in supplied stream'
        serde_paths = [Path(value.split('=', 1)[1]).resolve(strict=True)
                       for value in externs if value.startswith('serde_json=')]
        assert len(serde_paths) == 1, ('matching CLI command lacks one serde_json extern', number)
        path = serde_paths[0]
        assert path in candidate_sets['serde_json'], ('verbose selection absent from supplied artifact stream', path)
        verbose_witnesses.append({'line': number, 'raw_sha256': hashlib.sha256(line.encode()).hexdigest(),
                                  'command': command, 'witness_crate': crate, 'serde_json_artifact': str(path),
                                  'deadpan_cli_invoked_library': str(invoked_library),
                                  'deadpan_cli_invoked_library_sha256': cli_hash})
    paths = {Path(row['serde_json_artifact']) for row in verbose_witnesses}
    assert len(paths) == 1, ('require an unambiguous matching deadpan_cli rustc --extern witness', verbose_witnesses)
    selected['serde_json'] = next(iter(paths))
if 'serde_json' not in selected:
    details = [{'path': str(path), 'messages': [row['message'] for row in rows]}
               for path, rows in candidate_sets['serde_json'].items()]
    raise AssertionError(('ambiguous serde_json: supply --cargo-build-log with this build\'s -vv stderr; '
                          'the matching deadpan_cli extra-filename and --extern path are required', details))

# Cargo's release rlibs use linker-plugin-lto and contain LLVM bitcode instead
# of ordinary machine objects. Match the final binary's explicit ThinLTO so
# rustc consumes that bitcode before the platform linker. -O alone only gives
# local ThinLTO, which does not consume the cross-crate bitcode-only inputs.
# The remaining flags match this project's qualified release profile, including
# checked integer arithmetic in the helper's own qualification code.
argv = ['rustc', '--edition=2024', '-O', '-C', 'lto=thin',
        '-C', 'codegen-units=1', '-C', 'overflow-checks=on',
        str(source), '-o', str(a.output),
        '-L', 'dependency=' + str(deps), '-L', 'native=' + str(a.ffmpeg_prefix / 'lib'),
        '-C', 'link-arg=-Wl,-rpath,' + str(a.ffmpeg_prefix / 'lib')]
inputs = [source, a.bin / 'deadpan-cli', a.bin / 'deadpan-app']
for name, artifact in selected.items():
    inputs.append(artifact)
    argv += ['--extern', name + '=' + str(artifact)]
executable_events = {}
for binary in [a.bin / 'deadpan-cli', a.bin / 'deadpan-app']:
    matches = [row for row in events if row['message'].get('reason') == 'compiler-artifact'
               and row['message'].get('executable') is not None
               and Path(row['message']['executable']).resolve(strict=True) == binary]
    assert matches, ('pinned binary absent from this build artifact stream', binary)
    executable_events[str(binary)] = matches
# Only current build-script-executed metadata, never stale build/*/output files.
searches = {'native=' + str(a.ffmpeg_prefix / 'lib')}
build_scripts = []
for row in events:
    message = row['message']
    if message.get('reason') == 'build-script-executed' and message.get('linked_paths'):
        build_scripts.append(row)
        for value in message['linked_paths']:
            location = value.split('=', 1)[1] if '=' in value else value
            assert Path(location).is_dir(), ('missing native build path', value)
            searches.add(value)
for search in sorted(searches):
    argv += ['-L', search]
manifest = {'argv': argv, 'inputs': {str(x): sha(x) for x in inputs},
            'helper_codegen': {'opt_level': 3, 'lto': 'thin', 'codegen_units': 1,
                               'overflow_checks': True,
                               'reason': 'consume current Cargo release linker-plugin-lto bitcode rlibs with rustc ThinLTO; match release arithmetic policy',
                               'reference': 'https://doc.rust-lang.org/rustc/codegen-options/index.html#linker-plugin-lto'},
            'cargo_artifacts': {'path': str(a.cargo_artifacts), 'bytes': a.cargo_artifacts.stat().st_size,
                                'sha256': sha(a.cargo_artifacts)},
            'selected_artifacts': {name: {'path': str(path), 'sha256': sha(path),
                                         'events': candidate_sets[name][path]}
                                   for name, path in selected.items()},
            'binary_artifact_events': executable_events,
            'native_search_paths': sorted(searches), 'build_script_events': build_scripts,
            'serde_json_verbose_witnesses': verbose_witnesses,
            'started_unix': time.time(), 'cwd': os.getcwd()}
if a.cargo_build_log is not None:
    manifest['cargo_build_log'] = {'path': str(a.cargo_build_log), 'sha256': sha(a.cargo_build_log),
                                  'bytes': a.cargo_build_log.stat().st_size}
receipt = a.output.with_suffix('.build.json')
receipt.write_text(json.dumps(manifest, indent=2) + '\n')
result = subprocess.run(argv)
manifest['exit_code'] = result.returncode
if result.returncode == 0:
    manifest['binary_sha256'] = sha(a.output)
receipt.write_text(json.dumps(manifest, indent=2) + '\n')
result.check_returncode()
print(receipt)
