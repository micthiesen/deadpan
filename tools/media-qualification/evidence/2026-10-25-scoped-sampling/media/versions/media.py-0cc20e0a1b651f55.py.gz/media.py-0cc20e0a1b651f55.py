#!/usr/bin/env python3
"""Verify actual native-authored nested scoped sampled-target Creep, without authoring it.

The report supplies the real pre-Creep baseline and final native revisions.
Read-only library preparation retrieves and compares both saved documents.
Only disposable portable copies are rendered or navigated. No document recipe
is created or patched by this driver.
"""
import argparse
import copy
from fractions import Fraction
import hashlib
import json
import math
import os
from pathlib import Path
import sqlite3
import stat
import subprocess
import time


def sha(path):
    h = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            h.update(block)
    return h.hexdigest()


def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':'))


def package_inventory(package, destination, phase):
    """Pin every persistent regular file, including SQLite WAL and media.

    SQLite's exact root project.sqlite-shm is the sole exclusion. Its bytes
    are still observed/reported, with no equality or persistence assertion.
    Reject symlinks, special files and paths outside the captured package.
    Publish incrementally so later failures retain the available input evidence.
    """
    inventory = {'source_project': str(package), 'phase': phase, 'complete': False,
                 'persistent_files': [], 'directories': [], 'excluded_transient_files': [],
                 'exclusion_rule': 'only root project.sqlite-shm; bytes observed separately; no persistence claim'}

    def publish():
        destination.write_text(json.dumps(inventory, indent=2) + '\n')

    def regular(path, relative):
        flags = os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK
        fd = os.open(path, flags)
        try:
            before = os.fstat(fd)
            assert stat.S_ISREG(before.st_mode), ('unexpected non-regular source package file', path)
            h = hashlib.sha256()
            size = 0
            while True:
                block = os.read(fd, 1024 * 1024)
                if not block:
                    break
                h.update(block)
                size += len(block)
            after = os.fstat(fd)
            signature = lambda value: (value.st_dev, value.st_ino, value.st_mode, value.st_size, value.st_mtime_ns)
            assert signature(before) == signature(after) and size == before.st_size, ('source file changed while hashing', path)
            return {'relative_path': relative, 'bytes': size, 'sha256': h.hexdigest()}
        finally:
            os.close(fd)

    def walk(directory):
        with os.scandir(directory) as listing:
            entries = sorted(listing, key=lambda entry: entry.name)
        for entry in entries:
            path = Path(entry.path)
            relative = path.relative_to(package).as_posix()
            assert relative and not relative.startswith('/') and all(part not in ('.', '..', '') for part in Path(relative).parts), ('unexpected package-relative path', path)
            metadata = entry.stat(follow_symlinks=False)
            assert not stat.S_ISLNK(metadata.st_mode), ('source package symlink refused', relative)
            if stat.S_ISDIR(metadata.st_mode):
                inventory['directories'].append(relative)
                publish()
                walk(path)
            elif stat.S_ISREG(metadata.st_mode):
                row = regular(path, relative)
                if relative == 'project.sqlite-shm':
                    row['reason'] = 'transient SQLite shared-memory bytes; no persistence assertion'
                    inventory['excluded_transient_files'].append(row)
                else:
                    inventory['persistent_files'].append(row)
                publish()
            else:
                raise AssertionError(('unexpected source package special file', relative, stat.S_IFMT(metadata.st_mode)))

    publish()
    try:
        assert stat.S_ISDIR(package.lstat().st_mode), 'source package must be a real directory'
        walk(package)
        inventory['persistent_files'].sort(key=lambda row: row['relative_path'])
        inventory['directories'].sort()
        inventory['complete'] = True
        inventory['persistent_inventory_sha256'] = hashlib.sha256(canonical({
            'directories': inventory['directories'], 'files': inventory['persistent_files']}).encode()).hexdigest()
        publish()
        return inventory
    except BaseException as error:
        inventory['error'] = repr(error)
        publish()
        raise


def compare_package_inventories(before, after, destination):
    left = {row['relative_path']: row for row in before['persistent_files']}
    right = {row['relative_path']: row for row in after['persistent_files']}
    comparison = {
        'persistent_path_bytes_and_sha256_equal': left == right,
        'directories_equal': before['directories'] == after['directories'],
        'added_persistent_paths': sorted(set(right) - set(left)),
        'removed_persistent_paths': sorted(set(left) - set(right)),
        'changed_persistent_files': [{'before': left[path], 'after': right[path]}
                                     for path in sorted(set(left) & set(right)) if left[path] != right[path]],
        'before_persistent_inventory_sha256': before['persistent_inventory_sha256'],
        'after_persistent_inventory_sha256': after['persistent_inventory_sha256'],
        'excluded_transient_before': before['excluded_transient_files'],
        'excluded_transient_after': after['excluded_transient_files'],
        'transient_exclusion_claim': 'reported path/size/hash observations only; equality/persistence not asserted',
    }
    destination.write_text(json.dumps(comparison, indent=2) + '\n')
    assert comparison['persistent_path_bytes_and_sha256_equal'], 'persistent source-package paths or bytes changed; see inventory comparison'
    assert comparison['directories_equal'], 'source-package directory paths changed; see inventory comparison'
    return comparison


def ratio(value):
    return Fraction(int(value['numerator']), int(value['denominator']))


def round_even(value):
    whole, remainder = divmod(value.numerator, value.denominator)
    return whole + int(2 * remainder > value.denominator or
                       (2 * remainder == value.denominator and whole % 2 != 0))


Q = 1 << 32
FRAMES, SAMPLES, RASTER = 240, 384384, (320, 180)
OWNER, WINDOW, CHANGED = (164, 200), (170, 188), (170, 200)
FRAME_BYTES = 320 * 180 * 3 // 2


def quantized(value):
    return Fraction(round_even(value * Q), Q)


def selected_pose(j):
    # Independent fixture arithmetic. Samples are evaluated at picture centers.
    # Creep samples root Out-1=187: local23 -> Original ordinal15 -> center70%.
    def wire(value):
        return {'numerator': str(value.numerator), 'denominator': str(value.denominator)}
    def interpolate(first, last):
        assert 6 <= j < 24, 'grid interpolation is only used inside the ramp'
        first, last = round_even(first * Q), round_even(last * Q)
        progress = round_even(Fraction((2 * (j - 6) + 1) * Q, 36))
        return Fraction(first + round_even(Fraction((last - first) * progress, Q)), Q)
    if j < 6:
        x, y, scale = Fraction(1, 2), Fraction(1, 2), Fraction(1)
    elif j >= 24:
        # A held envelope segment preserves its authored terminal pose.
        # Only the sampled center is already Q32; scale remains exact 11/5.
        x, y, scale = quantized(Fraction(7, 10)), Fraction(1, 2), Fraction(11, 5)
    else:
        x, y, scale = interpolate(Fraction(1, 2), Fraction(7, 10)), Fraction(1, 2), interpolate(Fraction(3, 2), Fraction(11, 5))
    return {key: wire(value) for key, value in zip(('center_x', 'center_y', 'scale'), (x, y, scale))}


def history(package):
    # Include WAL; immutable=1 would be incorrect for a retained live package.
    with sqlite3.connect((package / 'project.sqlite').as_uri() + '?mode=ro', uri=True) as db:
        queries = {
            'revisions': 'SELECT id,parent_id,kind FROM revisions ORDER BY id',
            'history': 'SELECT id,parent_id,revision_id,request,edit FROM history ORDER BY id',
            'redo': 'SELECT position,history_id FROM redo ORDER BY position',
            'state': 'SELECT head_revision,cursor,workflow FROM state ORDER BY singleton',
        }
        values = {name: db.execute(query).fetchall() for name, query in queries.items()}
    return {'counts': {name: len(rows) for name, rows in values.items()},
            'sha256': hashlib.sha256(canonical(values).encode()).hexdigest(),
            'state': values['state'],
            'revision_kinds': {kind: sum(row[2] == kind for row in values['revisions'])
                               for kind in ('initial', 'edit', 'undo', 'redo')}}


def retained_history(package):
    """Hash every column of immutable revision and history rows, including docs."""
    with sqlite3.connect((package / 'project.sqlite').as_uri() + '?mode=ro', uri=True) as db:
        result = {}
        for table in ('revisions', 'history'):
            cursor = db.execute(f'SELECT * FROM {table} ORDER BY id')
            columns = [column[0] for column in cursor.description]
            id_index = columns.index('id')
            result[table] = {
                row[id_index]: hashlib.sha256(canonical([
                    {'blob_hex': value.hex()} if isinstance(value, bytes) else value
                    for value in row]).encode()).hexdigest()
                for row in cursor.fetchall()}
    return result


def retains(before, after):
    for table, rows in before.items():
        assert all(after[table].get(key) == value for key, value in rows.items()), (
            'portable navigation lost or changed retained history', table)


def isolated_audio_metadata(baseline, document, aliases, allocation):
    """Check the complete transparent-copy metadata from structural aliases.

    Immutable timing aliases stay historical. Only live Repeat arguments,
    gap issuers and birth owners follow the cloned tree. Infer those live
    owners from each new node's actual ancestors, not an observed binding.
    """
    old_nodes, nodes = baseline['nodes'], document['nodes']
    parents = {}
    for owner, node in nodes.items():
        kind = node['kind']
        children = kind.get('children', []) if kind['type'] == 'sequence' else (
            [kind['child']] if kind['type'] in ('repeat', 'retime') else [])
        for child in children:
            assert child not in parents, ('multiple physical parents', child)
            parents[child] = owner
    # An override root has its Repeat as parent, independently of its default.
    for owner, entries in document.get('overrides', {}).items():
        for entry in entries:
            child = entry['root']
            assert child not in parents, ('shared override root', child)
            parents[child] = owner

    expected_lineage = copy.deepcopy(baseline.get('audio_lineage', {}))
    for old in set(aliases.values()):
        expected_lineage.setdefault(old, {'allocation': allocation, 'origin': old})
    for new, old in aliases.items():
        assert new not in old_nodes and new in nodes and old in old_nodes
        expected_lineage[new] = copy.deepcopy(expected_lineage[old])
    assert document.get('audio_lineage', {}) == expected_lineage, 'isolated audio lineage differs from exact transparent-copy relation'

    expected_bindings = copy.deepcopy(baseline.get('audio_bindings', {}))
    for group in ('bindings', 'gap_bindings'):
        original = baseline.get('audio_bindings', {}).get(group, {})
        expected = expected_bindings.setdefault(group, {})
        for new, old in aliases.items():
            if old not in original:
                continue
            live_repeats = {}
            owner = new
            visited = set()
            while owner is not None:
                assert owner not in visited, ('cyclic isolated owner ancestry', new)
                visited.add(owner)
                if owner in aliases and nodes[owner]['kind']['type'] == 'repeat':
                    live_repeats[aliases[owner]] = owner
                owner = parents.get(owner)
            binding = copy.deepcopy(original[old])
            placements = [binding['lattice']]
            placements.extend(step['placement'] for step in binding.get('reanchors', []))
            placements.extend(term['placement'] for term in binding.get('resume', {}).get('phase', {}).get('terms', []))
            for placement in placements:
                values = [argument['value'] for argument in placement.get('arguments', [])]
                if 'gap_after' in placement:
                    values.append(placement['gap_after'])
                for value in values:
                    if value['type'] == 'live':
                        value['repeat'] = live_repeats.get(value['repeat'], value['repeat'])
                for clause in placement.get('births', []):
                    clause['repeat'] = live_repeats.get(clause['repeat'], clause['repeat'])
            expected[new] = binding
    assert document.get('audio_bindings', {}) == expected_bindings, 'isolated audio bindings differ from exact retained-clock copies'
    return {'allocation': allocation, 'aliases': aliases,
            'complete_lineage_sha256': hashlib.sha256(canonical(expected_lineage).encode()).hexdigest(),
            'complete_bindings_sha256': hashlib.sha256(canonical(expected_bindings).encode()).hexdigest(),
            'original_lineage_entries': len(baseline.get('audio_lineage', {})),
            'final_lineage_entries': len(expected_lineage),
            'original_binding_entries': len(baseline.get('audio_bindings', {}).get('bindings', {})),
            'final_binding_entries': len(expected_bindings['bindings']),
            'original_gap_binding_entries': len(baseline.get('audio_bindings', {}).get('gap_bindings', {})),
            'final_gap_binding_entries': len(expected_bindings['gap_bindings']),
            'timings_and_all_other_binding_fields_unchanged': True}


parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--project', type=Path, required=True)
parser.add_argument('--bin', type=Path, required=True)
parser.add_argument('--native-report', type=Path, required=True)
parser.add_argument('--helper', type=Path, required=True)
parser.add_argument('--ffmpeg', type=Path, required=True)
parser.add_argument('--output', type=Path, required=True)
args = parser.parse_args()
assert not args.project.is_symlink(), 'source package root symlink refused'
for key in ('project', 'bin', 'native_report', 'helper', 'ffmpeg'):
    setattr(args, key, getattr(args, key).resolve(strict=True))
args.output = args.output.resolve(strict=False)
assert not args.output.exists()
assert args.project not in args.output.parents and args.output not in args.project.parents
args.output.mkdir()
# This is deliberately before any CLI, SQLite open, helper or portable copy.
# The early file remains available if validation or a later assertion fails.
source_inventory_before = package_inventory(
    args.project, args.output / 'source-package-before.json', 'before any source read/copy')

def final_source_inventory():
    after = package_inventory(args.project, args.output / 'source-package-after.json',
                              'after reads/copies or failure')
    return compare_package_inventories(source_inventory_before, after,
                                       args.output / 'source-package-comparison.json')

try:
    assert any(row['relative_path'] == 'project.sqlite-wal' and row['bytes'] > 0
               for row in source_inventory_before['persistent_files']), 'qualification needs the retained nonempty WAL'
    cli, app = args.bin / 'deadpan-cli', args.bin / 'deadpan-app'
    binary_paths = [cli, app, args.helper, args.ffmpeg]
    for name in ('deadpan-media-worker', 'deadpan-transcribe', 'deadpan-track'):
        path = args.bin / name
        if path.is_file():
            binary_paths.append(path)
    pins = {str(path): sha(path) for path in binary_paths}
    pins[str(Path(__file__).resolve())] = sha(Path(__file__).resolve())
    report_bytes = args.native_report.read_bytes()
    report_sha256 = sha(args.native_report)
    (args.output / 'native-report.json').write_bytes(report_bytes)
    build_receipt = args.helper.with_suffix('.build.json')
    assert build_receipt.is_file(), 'retain the helper build input/pin receipt'
    helper_build = json.loads(build_receipt.read_text())
    assert helper_build['binary_sha256'] == pins[str(args.helper)]
    helper_executables = {}
    for executable in (cli, app):
        built = [(path, digest) for path, digest in helper_build['inputs'].items()
                 if Path(path).name == executable.name]
        assert len(built) == 1, ('ambiguous helper build executable', executable, built)
        built_path, built_digest = built[0]
        assert built_digest == pins[str(executable)], 'copied executable differs from helper build input'
        helper_executables[executable.name] = {
            'build_input': built_path, 'executed_copy': str(executable), 'sha256': built_digest}
    (args.output / 'helper-executables.json').write_text(json.dumps(helper_executables, indent=2) + '\n')
    (args.output / 'helper-build.json').write_bytes(build_receipt.read_bytes())
    report = json.loads(report_bytes)
    assert report['metadata']['build_profile'] == 'release'
    assert report['metadata']['binary_sha256'] == pins[str(app)]
    scenarios = [s for s in report['scenarios'] if s['name'] == 'scoped-follow-creep']
    assert len(scenarios) == 1
    scenario = scenarios[0]
    assert scenario['checks'] and all(c['passed'] for c in scenario['checks'])
    assert not any(f['severity'] == 'failure' for f in scenario.get('findings', []))
    assert scenario.get('skipped', []) == [
        'OS picker behavior: only its selected path is scripted',
        'Physical display presentation, VoiceOver, OS IME delivery and audio device output',
    ]


    def last_check(name):
        matches = [c for c in scenario['checks'] if c['name'] == name]
        assert matches, name
        return matches[-1]


    identity = last_check("Final sampled native Creep fixture identity for emitted-media verification")
    captured = identity['expected']
    assert all(identity['actual'][key] == value for key, value in captured.items())
    assert captured['root_owner'] == list(OWNER)
    assert captured['root_range'] == list(WINDOW) and captured['root_sample'] == 187
    assert captured['total_frames'] == FRAMES and captured['sampled_center_percent'] == 70
    assert captured['target_id'] == 'target-1'
    effect = last_check("Sampled Time framing changes exactly one explicit nested Play; independent root-clock poses, every provider, gap, caption and complete audio remain exact")
    assert effect['expected'] == {
        'root_owner': list(OWNER), 'root_range': list(WINDOW),
        'sampled_center_percent': 70, 'creep': True, 'pictures': FRAMES,
        'selected_pictures': 36, 'audio_samples': SAMPLES}
    proof = effect['actual']
    assert all(proof[key] for key in ('fixed_recipe', 'frames_exact', 'audio', 'originals', 'clones', 'address', 'isolation'))
    assert proof['pictures'] == 36
    baseline_revision = captured['baseline_revision']

    commands = []


    def run(name, executable, *arguments, timeout=1800, expect_failure=False):
        assert sha(executable) == pins[str(executable)], 'binary changed during qualification'
        command = [str(executable), *map(str, arguments)]
        started = time.monotonic()
        row = {'name': name, 'argv': command, 'started_unix': time.time(),
               'environment': {key: os.environ.get(key) for key in (
                   'DEADPAN_FFMPEG_PREFIX', 'DYLD_LIBRARY_PATH', 'DYLD_FALLBACK_LIBRARY_PATH',
                   'DEADPAN_PAUSE_ROUTE_PROFILE')}}
        commands.append(row)
        (args.output / 'commands.json').write_text(json.dumps(commands, indent=2) + '\n')
        with (args.output / f'{name}.stdout').open('xb') as stdout:
            with (args.output / f'{name}.stderr').open('xb') as stderr:
                try:
                    result = subprocess.run(command, stdout=stdout, stderr=stderr, timeout=timeout)
                except BaseException as error:
                    row.update(error=repr(error), seconds=time.monotonic() - started)
                    (args.output / 'commands.json').write_text(json.dumps(commands, indent=2) + '\n')
                    raise
        row.update(exit_code=result.returncode, seconds=time.monotonic() - started)
        (args.output / 'commands.json').write_text(json.dumps(commands, indent=2) + '\n')
        if expect_failure:
            assert result.returncode != 0, ('negative control unexpectedly passed', name)
        else:
            result.check_returncode()
        return (args.output / f'{name}.stdout').read_text()


    def cli_run(name, *arguments):
        return run(name, cli, *arguments)


    document = json.loads(cli_run('source-dump', 'project', 'dump', args.project, '--json'))
    revision = document['revision_id']
    assert captured['sampled_revision'] == revision
    before_history = history(args.project)
    retained_before = retained_history(args.project)
    (args.output / 'source-complete-history-digests.json').write_text(json.dumps(retained_before, indent=2) + '\n')
    assert before_history['state'][0][0] == revision
    assert all(before_history['revision_kinds'][kind] > 0 for kind in ('edit', 'undo', 'redo'))

    portable = args.output / 'portable-final.deadpan'
    control = args.output / 'portable-static-control.deadpan'
    cli_run('portable-copy', 'project', 'copy-portable', args.project, portable)
    cli_run('portable-validate', 'project', 'validate', portable)
    assert json.loads(cli_run('portable-dump', 'project', 'dump', portable, '--json')) == document
    assert history(portable) == before_history
    assert retained_history(portable) == retained_before

    helper_output = args.output / 'read-only-helper'
    helper_output.mkdir()
    run('read-only-helper', args.helper, portable, baseline_revision, revision, helper_output)
    baseline = json.loads((helper_output / 'baseline-document.json').read_text())
    assert baseline['revision_id'] == baseline_revision
    assert json.loads((helper_output / 'final-document.json').read_text()) == document
    (args.output / 'captured-static-baseline.json').write_text(json.dumps(baseline, indent=2) + '\n')
    assert document['targets'] == baseline['targets']
    assert not baseline.get('overrides', {}) and not baseline.get('gap_overrides', {})
    assert document.get('gap_overrides', {}) == baseline.get('gap_overrides', {})
    assert document['presentation_basis'] == baseline['presentation_basis']
    assert document['presentation_basis']['frame_rate'] == {'numerator': 30000, 'denominator': 1001}
    assert (document['presentation_basis']['width'], document['presentation_basis']['height']) == RASTER
    assert len(document['targets']) == 1
    target = document['targets']['target-1']
    clock = {'numerator': 1, 'denominator': 30000}
    assert target['region'] == {'center': [300000, 500000]}
    assert not target.get('samples', [])
    assert target['corrections'] == [
        {'at': 6006, 'region': {'center': [550000, 500000]}},
        {'at': 12012, 'region': {'center': [700000, 500000]}},
        {'at': 16016, 'region': {'center': [400000, 500000]}}]
    assert target['display_aspect'] == {'numerator': '16', 'denominator': '9'}
    assert target['span'] == {'start': {'ticks': 0, 'time_base': clock},
                              'end': {'ticks': 120120, 'time_base': clock}}
    nodes, old_nodes = document['nodes'], baseline['nodes']
    root = nodes[document['root']]['kind']
    assert root['type'] == 'sequence' and len(root['children']) == 1
    outer = root['children'][0]
    outer_kind = nodes[outer]['kind']
    assert outer_kind['type'] == 'repeat'
    inner = outer_kind['child']
    inner_kind = nodes[inner]['kind']
    assert inner_kind['type'] == 'repeat'
    template = inner_kind['child']
    retime = nodes[template]['kind']
    assert retime == {'type': 'retime', 'child': retime['child'], 'duration': 36,
                      'mapping': {'start': 0, 'end': 24}, 'pitch': 'follow_speed'}


    def iterations(kind, count):
        values = []
        for part in kind['iterations']['runs']:
            values.extend({'allocation': part['allocation'], 'ordinal': part['first'] + j}
                          for j in range(part['count']))
        assert len(values) == count
        return values


    outer_iterations, inner_iterations = iterations(outer_kind, 2), iterations(inner_kind, 3)
    overrides = document['overrides']
    assert len(overrides) == 2 and len(overrides[outer]) == 1
    assert overrides[outer][0]['iteration'] == outer_iterations[1]
    cloned_inner = overrides[outer][0]['root']
    assert len(overrides[cloned_inner]) == 1
    assert overrides[cloned_inner][0]['iteration'] == inner_iterations[1]
    selected = overrides[cloned_inner][0]['root']
    assert set(overrides) == {outer, cloned_inner}
    assert captured['owner'] == selected
    aliases = {}


    def children(table, name):
        kind = table[name]['kind']
        if kind['type'] == 'sequence':
            return kind['children']
        if kind['type'] in ('repeat', 'retime'):
            return [kind['child']]
        return []


    def pair(new, old):
        assert new != old and new not in old_nodes
        if new in aliases:
            assert aliases[new] == old
            return
        aliases[new] = old
        assert nodes[new]['kind']['type'] == old_nodes[old]['kind']['type']
        assert len(children(nodes, new)) == len(children(old_nodes, old))
        for a, b in zip(children(nodes, new), children(old_nodes, old)):
            pair(a, b)


    pair(cloned_inner, inner)
    pair(selected, template)
    assert aliases == proof['aliases']


    def normalize(value):
        if isinstance(value, str):
            return aliases.get(value, value)
        if isinstance(value, list):
            return [normalize(v) for v in value]
        if isinstance(value, dict):
            return {k: normalize(v) for k, v in value.items()}
        return value


    assert normalize(captured['occurrence']) == {
        'node': template,
        'repeats': [{'node': outer, 'iteration': outer_iterations[1]},
                    {'node': inner, 'iteration': inner_iterations[1]}]}
    fixed = old_nodes[template]['framing']
    assert fixed == {'value': {'type': 'static', 'pose': selected_pose(0)}}
    animated = nodes[selected]['framing']
    assert animated == proof['framing'] and 'clock' not in animated
    assert animated['value']['type'] == 'envelope'
    assert 'follow' not in canonical(animated) and 'target-1' not in canonical(animated)
    # Every authored segment and all poses remain recorded in the documents. The
    # independent expected picture oracle below checks the complete interpolation.

    for name, old in old_nodes.items():
        assert nodes[name] == old, ('changed baseline node', name)
    for new, old in aliases.items():
        expected = copy.deepcopy(old_nodes[old])
        if new == selected:
            expected['framing'] = animated
        assert normalize(nodes[new]) == expected, (new, old)
    assert set(nodes) == set(old_nodes) | set(aliases)
    # Undo/Redo gives the current document a new revision, but transparent
    # isolation retains the never-reused allocation of its original edit.
    with sqlite3.connect((portable / 'project.sqlite').as_uri() + '?mode=ro', uri=True) as db:
        edits = db.execute('SELECT r.id,h.request FROM revisions r JOIN history h ON h.revision_id=r.id WHERE r.parent_id=? AND r.kind=?',
                           (baseline_revision, 'edit')).fetchall()
    assert len(edits) == 1, 'expected one original framing edit from the native static baseline'
    allocation, encoded_request = edits[0]
    request = json.loads(encoded_request)
    assert request['expected_revision'] == baseline_revision and request['new_revision'] == allocation
    assert request['project_id'] == document['project_id']
    assert request['command']['command'] == 'edit_scoped'
    assert request['command']['target']['node'] == template
    assert request['command']['edit'] == {'type': 'set_framing', 'framing': animated}
    metadata_proof = isolated_audio_metadata(baseline, document, aliases, allocation)
    (args.output / 'isolated-audio-metadata.json').write_text(json.dumps(metadata_proof, indent=2) + '\n')
    unchanged_document, unchanged_baseline = copy.deepcopy(document), copy.deepcopy(baseline)
    for value in (unchanged_document, unchanged_baseline):
        for key in ('revision_id', 'nodes', 'overrides', 'audio_lineage', 'audio_bindings'):
            value.pop(key, None)
    assert unchanged_document == unchanged_baseline, 'authored state outside isolated framing changed'

    cli_run('control-copy', 'project', 'copy-portable', portable, control)
    assert history(control) == before_history
    assert retained_history(control) == retained_before
    cli_run('control-undo', 'project', 'undo', control, '--expected', revision)
    control_document = json.loads(cli_run('control-dump', 'project', 'dump', control, '--json'))
    control_revision = control_document['revision_id']
    expected = copy.deepcopy(baseline)
    expected['revision_id'] = control_revision
    assert control_document == expected, 'one genuine Undo must recover the native pre-Creep static fixture'
    assert control_revision != baseline_revision
    cli_run('control-validate', 'project', 'validate', control)
    retained_undo = retained_history(control)
    retains(retained_before, retained_undo)

    pcm_before, pcm_after = helper_output / 'baseline-pcm.bin', helper_output / 'final-pcm.bin'
    assert pcm_before.stat().st_size == pcm_after.stat().st_size == SAMPLES * 24
    assert sha(pcm_before) == sha(pcm_after)
    helper_result = json.loads((helper_output / 'helper-result.json').read_text())
    assert helper_result['canonical_pcm_bits_equal'] and helper_result['read_only']
    before_plan = json.loads((helper_output / 'baseline-plan.json').read_text())
    after_plan = json.loads((helper_output / 'final-plan.json').read_text())
    for plan in (before_plan, after_plan):
        assert len(plan['pictures']) == FRAMES
    old_audio = copy.deepcopy(before_plan['audio'])
    new_audio = normalize(copy.deepcopy(after_plan['audio']))
    for audio in (old_audio, new_audio):
        audio.pop('revision_id')
        audio.pop('lookup')
        audio.pop('work', None)
    assert old_audio == new_audio, 'complete audio allocation/content/clock plan changed'
    oracle = []
    for f, (old, actual) in enumerate(zip(before_plan['pictures'], after_plan['pictures'])):
        op, ol = divmod(f, 124)
        ip, j = divmod(ol, 40)
        outer_gap = ol >= 116
        gap = outer_gap or j >= 36
        ordinal = 23 if gap else (2 * j + 1) // 3
        ticks = Fraction(23023) if gap else Fraction((2 * j + 1) * 1001, 3)
        picture = old['picture']
        assert picture['type'] == ('freeze' if gap else 'source')
        assert picture['asset'] == target['asset']
        assert ratio(picture['point']['ticks']) == ticks
        assert picture['point']['time_base'] == clock
        expected = copy.deepcopy(old)
        matching = [layer for layer in expected['framing'] if layer['instance'] == {
            'node': template, 'repeats': [{'node': outer, 'iteration': outer_iterations[1]},
                                        {'node': inner, 'iteration': inner_iterations[1]}]} and not layer['escalation']]
        assert bool(matching) == (OWNER[0] <= f < OWNER[1])
        pose = None
        if matching:
            assert len(matching) == 1
            layer = matching[0]
            assert ratio(layer['local_position']) == Fraction(2 * j + 1, 2)
            assert ratio(layer['effective_duration']) == 36
            pose = layer['pose']
            assert pose == selected_pose(0), ('baseline owner must be static identity', f)
            pose = selected_pose(j)
            layer['pose'] = pose
        actual = normalize(copy.deepcopy(actual))
        for value in (expected, actual):
            value.pop('revision_id')
            value.pop('lookup')
        assert actual == expected, ('independent complete picture plan oracle', f)
        oracle.append({'frame': f, 'gap': gap, 'Original_ordinal': ordinal, 'source_ticks': str(ticks),
                       'class': 'ramp' if WINDOW[0] <= f < WINDOW[1] else
                                'terminal_hold' if WINDOW[1] <= f < OWNER[1] else
                                'selected_static_prefix' if OWNER[0] <= f < WINDOW[0] else 'unchanged',
                       'expected_selected_pose': pose})
    (args.output / 'independent-native-oracle.json').write_text(json.dumps(oracle, indent=2) + '\n')


    def verify(label, package, head):
        movie = args.output / (label + '.mp4')
        cli_run(label + '-render', 'render', package, '--output', args.output,
                '--name', movie.name, '--expected', head)
        report_path = args.output / (label + '-verification.json')
        cli_run(label + '-verify', 'verify-export', package, '--movie', movie,
                '--revision', head, '--every', 1, '--samples', f'0:{SAMPLES}', '--report', report_path)
        verification = json.loads(report_path.read_text())
        assert verification['passed'] and not verification['failures']
        assert verification['revision_id'] == head and verification['range'] == [0, FRAMES]
        assert verification['frame_rate'] == [30000, 1001]
        assert verification['canvas'] == verification['raster'] == list(RASTER)
        assert verification['movie']['video_frames'] == verification['movie']['expected_video_frames'] == FRAMES
        assert verification['movie']['expected_audio_samples'] == SAMPLES
        assert verification['movie']['audio']['presented_end'] == SAMPLES and not verification['movie']['audio']['gaps']
        assert verification['summary']['pictures_checked'] == FRAMES
        assert verification['summary']['pictures_failed'] == 0
        assert len(verification['pictures']) == FRAMES
        for f, picture in enumerate(verification['pictures']):
            assert picture['passed'] and picture['output_frame'] == picture['project_frame'] == f
            assert picture['provenance'] == {
                'kind': 'original', 'asset': target['asset'], 'source_frame': oracle[f]['Original_ordinal'],
                'source_pts': 1001 * oracle[f]['Original_ordinal']}
        assert len(verification['audio']) == 1
        audio = verification['audio'][0]
        assert audio['window'] == audio['project_samples'] == [0, SAMPLES]
        assert audio['passed'] and audio['uncovered_samples'] == 0
        assert audio['offset_status'] == 'verified_zero' and audio['measured_offset_samples'] == 0
        assert audio['segments'] and all(s['status'] == 'verified_zero' and s['peak_lag'] == 0 for s in audio['segments'])
        assert verification['summary']['nonzero_offsets'] == verification['summary']['audio_windows_failed'] == 0
        return movie


    final_movie = verify('native-ranged', portable, revision)
    control_movie = verify('captured-static-control', control, control_revision)
    outside = ','.join(str(f) for f in range(FRAMES) if not CHANGED[0] <= f < CHANGED[1])
    cli_run('static-reference-cross-verify', 'verify-export', control, '--movie', final_movie,
            '--revision', control_revision, '--frames', outside, '--no-audio',
            '--report', args.output / 'static-reference-cross-verification.json')
    cross = json.loads((args.output / 'static-reference-cross-verification.json').read_text())
    assert cross['passed'] and not cross['failures'] and cross['summary']['pictures_checked'] == FRAMES - (CHANGED[1] - CHANGED[0])

    changed_frames = ','.join(map(str, range(*CHANGED)))
    for label, package, head, movie in [
            ('final-against-static-negative', control, control_revision, final_movie),
            ('static-against-final-negative', portable, revision, control_movie)]:
        report_path = args.output / (label + '.json')
        run(label, cli, 'verify-export', package, '--movie', movie, '--revision', head,
            '--frames', changed_frames, '--no-audio', '--report', report_path,
            expect_failure=True)
        negative = json.loads(report_path.read_text())
        assert negative['passed'] is False and negative['failures']
        assert negative['summary']['pictures_checked'] == CHANGED[1] - CHANGED[0]
        assert negative['summary']['pictures_failed'] > 0, 'changed-region control must expose an observable picture failure'
        assert negative['thresholds'] == cross['thresholds'], 'negative controls use unchanged real thresholds'

    for label, movie in [('final', final_movie), ('baseline', control_movie)]:
        run(label + '-independent-decode', args.ffmpeg, '-v', 'error', '-nostdin', '-i', movie,
            '-map', '0:v:0', '-an', '-fps_mode', 'passthrough', '-pix_fmt', 'yuv420p',
            '-f', 'rawvideo', args.output / (label + '-decoded.yuv'), timeout=120)


    def metrics(left, right):
        error = [abs(a - b) for a, b in zip(left, right)]
        assert len(error) == len(left) == len(right)
        squared = sum(value * value for value in error)
        return {'identical': squared == 0, 'max_abs_error': max(error),
                'mean_abs_error': sum(error) / len(error),
                'psnr_db': 100.0 if squared == 0 else 10 * math.log10(255 * 255 * len(error) / squared)}


    comparison = []
    paths = [helper_output / 'baseline-reference.yuv', helper_output / 'final-reference.yuv',
             args.output / 'baseline-decoded.yuv', args.output / 'final-decoded.yuv']
    assert all(path.stat().st_size == FRAMES * FRAME_BYTES for path in paths)
    streams = [path.open('rb') for path in paths]
    try:
        for f in range(FRAMES):
            base_ref, final_ref, base_dec, final_dec = [stream.read(FRAME_BYTES) for stream in streams]
            changed = CHANGED[0] <= f < CHANGED[1]
            assert (base_ref != final_ref) == changed, ('canonical pixel changes outside recipe', f)
            row = {'frame': f, 'class': oracle[f]['class'], 'reference_identical': base_ref == final_ref,
                   'decoded_identical': base_dec == final_dec,
                   'reference_sha256': [hashlib.sha256(value).hexdigest() for value in (base_ref, final_ref)],
                   'decoded_sha256': [hashlib.sha256(value).hexdigest() for value in (base_dec, final_dec)],
                   'planes': []}
            start = 0
            for count in (320 * 180, 320 * 180 // 4, 320 * 180 // 4):
                end = start + count
                plane = {'reference_change': metrics(base_ref[start:end], final_ref[start:end]),
                         'decoded_change': metrics(base_dec[start:end], final_dec[start:end]),
                         'baseline_decode_error': metrics(base_ref[start:end], base_dec[start:end]),
                         'final_decode_error': metrics(final_ref[start:end], final_dec[start:end])}
                assert plane['baseline_decode_error']['psnr_db'] >= 32
                assert plane['final_decode_error']['psnr_db'] >= 32
                row['planes'].append(plane)
                start = end
            row['decoded_difference_interpretation'] = ('expected authored framing change plus codec residual'
                if changed else 'no authored pixel change; any decoded difference is bounded codec residual')
            comparison.append(row)
    finally:
        for stream in streams:
            stream.close()
    (args.output / 'all-240-decoded-picture-comparison.json').write_text(json.dumps(comparison, indent=2) + '\n')

    # Separate process opens prove a reopen; navigation is confined to the control.
    cli_run('control-redo', 'project', 'redo', control, '--expected', control_revision)
    redone = json.loads(cli_run('control-redone-dump', 'project', 'dump', control, '--json'))
    expected = copy.deepcopy(document)
    expected['revision_id'] = redone['revision_id']
    assert redone == expected
    cli_run('control-checkpoint', 'project', 'checkpoint', control)
    assert json.loads(cli_run('control-redone-reopen-dump', 'project', 'dump', control, '--json')) == redone
    retained_redo = retained_history(control)
    retains(retained_undo, retained_redo)
    (args.output / 'control-history-retention.json').write_text(json.dumps({
        'before': retained_before, 'after_undo': retained_undo,
        'after_redo_and_reopen': retained_redo,
        'all_original_revision_and_history_columns_retained': True}, indent=2) + '\n')
    cli_run('portable-checkpoint', 'project', 'checkpoint', portable)
    assert json.loads(cli_run('portable-reopen-dump', 'project', 'dump', portable, '--json')) == document
    assert history(portable) == before_history
    assert retained_history(portable) == retained_before
    assert history(args.project) == before_history
    assert retained_history(args.project) == retained_before
    assert json.loads(cli_run('source-final-dump', 'project', 'dump', args.project, '--json')) == document
    source_inventory_after = package_inventory(
        args.project, args.output / 'source-package-after.json', 'after final source read/copy')
    source_package_preservation = compare_package_inventories(
        source_inventory_before, source_inventory_after, args.output / 'source-package-comparison.json')
    assert sha(args.native_report) == report_sha256
    assert all(sha(Path(path)) == value for path, value in pins.items())
    result = {
        'fixture': 'actual native-authored nested explicit Play2/Play2 sampled-target ranged Creep',
        'fixture_origin': 'retained native project/report; driver authors no range or framing recipe',
        'source_project': str(args.project), 'native_revision': revision,
        'captured_static_baseline_revision': baseline_revision, 'control_undo_revision': control_revision,
        'native_report_sha256': report_sha256, 'pins': pins,
        'frames_checked': FRAMES, 'live_frames': 216, 'captured_gap_frames': 24,
        'owner_range': list(OWNER), 'authored_window': list(WINDOW),
        'expected_reference_pixel_change_range': list(CHANGED),
        'canonical_stereo_sample_frames': SAMPLES,
        'authored_limited_and_limiter_gain_bits_equal': True,
        'canonical_pcm_record_sha256': sha(pcm_before),
        'shared_reference_pixels_changed_frames': sum(not row['reference_identical'] for row in comparison),
        'unchanged_frames_with_codec_pixel_residual': sum(row['reference_identical'] and not row['decoded_identical'] for row in comparison),
        'source_history_unchanged_and_portable_equal': before_history,
        'source_package_path_bytes_and_hash_preservation': source_package_preservation,
        'native_movie_sha256': sha(final_movie), 'static_control_movie_sha256': sha(control_movie),
        'commands': len(commands),
        'evidence_scope': {
            'native_exclusions': scenario['skipped'],
            'oracle': 'independent half-even Fraction/Q32 sampled-center recipe, all240 source points, poses, other layers and complete audio allocation',
            'canonical': 'exact shared-engine authored/limited PCM and limiter-gain bits, different block partitions, from actual retained revisions in portable copy',
            'pixels': 'all240 shared canonical I420 pictures compared bitwise with staticbaseline; all240 emitted pictures independently decoded by pinned FFmpeg and compared perplane; verify-export qualifies each movie and cross-verifies210 unchanged pictures against staticbaseline; changed-region controls fail both directions at unchanged actual thresholds',
            'history': 'source revision/history request/edit digests unchanged; all persistent source-package paths/bytes/SHA256 unchanged including SQLite WAL and retained media; root project.sqlite-shm observed separately with no persistence claim; portable exact history; disposable control Undo/Redo and freshprocess reopen',
            'not_claimed': 'independent DSP or renderer, tracking accuracy, acoustic listening, physical display/input, encoded byte identity'}
    }
    (args.output / 'result.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(result))
except BaseException as error:
    import traceback
    (args.output / 'failure.json').write_text(json.dumps({
        'error': repr(error), 'traceback': traceback.format_exc(),
        'observed_unix': time.time()}, indent=2) + '\n')
    raise
finally:
    final_source_inventory()
