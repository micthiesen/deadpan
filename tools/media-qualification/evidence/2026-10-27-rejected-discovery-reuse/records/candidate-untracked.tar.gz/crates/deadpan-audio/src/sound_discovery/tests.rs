use super::*;

use deadpan_core::{
    AssetId, AssetRecord, AudioBindingState, AudioEdgePolicy, AudioSample, AudioTimingId,
    AudioTimingRecord, BeatNode, BeatSound, ColorPolicy, FrameDuration, FrameRate,
    FrozenAudioLayout, HoldAudio, HoldRecipe, HoldVideo, NodeId, PresentationBasis,
    ProjectDocument, ProjectId, RevisionId, SoundClockJournal, SoundClockReference, SoundId,
    SoundOverflowPolicy, SourceAudio, SourceAudioMapping, SourceQualificationId, SourceSpan,
    SourceTimeBase, SourceTimestamp,
};
use std::{
    cell::RefCell,
    sync::Arc,
    sync::atomic::AtomicBool,
    time::{Duration, Instant},
};

fn id(value: &str) -> NodeId {
    NodeId::new(value).unwrap()
}

fn revision(value: &str) -> RevisionId {
    RevisionId::new(value).unwrap()
}

fn source_span() -> SourceSpan {
    let time_base = SourceTimeBase::new(1, 48_000).unwrap();
    SourceSpan::new(
        SourceTimestamp {
            ticks: 10,
            time_base,
        },
        SourceTimestamp {
            ticks: 4_810,
            time_base,
        },
    )
    .unwrap()
}

fn asset(label: &str) -> AssetRecord {
    AssetRecord {
        label: label.into(),
        content_hash: "a".repeat(64),
        video: None,
        audio: Some(source_span()),
        still_image: false,
        frame_count: None,
        source_qualification: Some(SourceQualificationId::new("b".repeat(64)).unwrap()),
    }
}

fn beat_sound(label: &str, asset: &str) -> BeatSound {
    let source = SourceAudio {
        asset: AssetId::new(asset).unwrap(),
        span: source_span(),
    };
    BeatSound {
        label: label.into(),
        mapping: SourceAudioMapping::natural_rate(
            source.span,
            FrameRate::new(30_000, 1_001).unwrap(),
        )
        .unwrap(),
        source,
        offset: AudioSample(0),
        treatments: deadpan_core::AudioTreatments::default(),
        start_edge: AudioEdgePolicy::Automatic,
        end_edge: AudioEdgePolicy::Automatic,
        overflow: SoundOverflowPolicy::Reject,
    }
}

fn document(event_assets: &[&str], clocks_per_event: usize) -> ProjectDocument {
    document_shape(event_assets, clocks_per_event, false, false)
}

fn document_shape(
    event_assets: &[&str],
    clocks_per_event: usize,
    preserve: bool,
    audible_source: bool,
) -> ProjectDocument {
    let rate = FrameRate::new(30_000, 1_001).unwrap();
    let owner = id("owner");
    // A retained branch must include every enclosing processor. The owner
    // remains the source alias; only its captured/live scope widens here.
    let scope = if preserve {
        id("stretch")
    } else {
        owner.clone()
    };
    let root = id("root");
    let document = ProjectDocument::new(
        ProjectId::new("sound-clock-cache").unwrap(),
        revision("live"),
        PresentationBasis {
            width: 16,
            height: 16,
            frame_rate: rate,
            color_policy: ColorPolicy::SdrRec709,
        },
        root.clone(),
    )
    .unwrap();
    let mut wire = serde_json::to_value(&document).unwrap();
    wire["nodes"] = serde_json::to_value(BTreeMap::from([
        (root, BeatNode::sequence("Root", vec![owner.clone()])),
        (
            owner.clone(),
            BeatNode::hold(
                "Owner",
                HoldRecipe {
                    duration: FrameDuration::new(if preserve { 4 } else { 100 }).unwrap(),
                    video: HoldVideo::Background,
                    picture_context: None,
                    audio: HoldAudio::Silence,
                },
            ),
        ),
    ]))
    .unwrap();
    if audible_source {
        let source = SourceAudio {
            asset: AssetId::new(event_assets[0]).unwrap(),
            span: source_span(),
        };
        wire["nodes"]["owner"] = serde_json::to_value(BeatNode {
            framing: None,
            label: "Audible Original and independent sound".into(),
            audio_treatments: Default::default(),
            audio_editorial_edges: Default::default(),
            audio_edges: Default::default(),
            kind: deadpan_core::NodeKind::Source {
                source: deadpan_core::SourceNode {
                    edit_window: None,
                    duration: FrameDuration::new(if preserve { 4 } else { 100 }).unwrap(),
                    video: deadpan_core::SourceVideo::Blank,
                    video_mapping: deadpan_core::SourceVideoMapping::FitBeat,
                    audio_mapping: SourceAudioMapping::natural_rate(source.span, rate).unwrap(),
                    audio: Some(source),
                    audio_offset: AudioSample(0),
                    link: deadpan_core::LinkRelation::Independent,
                },
            },
            cutaways: Vec::new(),
            captions: Vec::new(),
        })
        .unwrap();
    }
    if preserve {
        wire["nodes"]["root"]["kind"]["children"] = serde_json::json!(["stretch"]);
        wire["nodes"]["stretch"] = serde_json::to_value(BeatNode {
            framing: None,
            label: "Preserve parent".into(),
            audio_treatments: Default::default(),
            audio_editorial_edges: Default::default(),
            audio_edges: Default::default(),
            kind: deadpan_core::NodeKind::Retime {
                child: owner.clone(),
                duration: FrameDuration::new(8).unwrap(),
                mapping: deadpan_core::FrameRange::new(
                    deadpan_core::ProjectFrame(0),
                    deadpan_core::ProjectFrame(4),
                )
                .unwrap(),
                pitch: deadpan_core::PitchPolicy::Preserve,
                purpose: deadpan_core::RetimePurpose::Edit,
            },
            cutaways: Vec::new(),
            captions: Vec::new(),
        })
        .unwrap();
    }
    wire["assets"] = serde_json::to_value(
        event_assets
            .iter()
            .map(|name| (AssetId::new((*name).to_owned()).unwrap(), asset(name)))
            .collect::<BTreeMap<_, _>>(),
    )
    .unwrap();
    wire["beat_sounds"] = serde_json::to_value(BTreeMap::from([(
        owner.clone(),
        event_assets
            .iter()
            .enumerate()
            .map(|(index, asset_name)| {
                let sound = SoundId::new(format!("sound-{index}")).unwrap();
                (sound, beat_sound(&format!("Sound {index}"), asset_name))
            })
            .collect::<BTreeMap<_, _>>(),
    )]))
    .unwrap();
    let document = ProjectDocument::from_json(&wire.to_string()).unwrap();
    let layout = FrozenAudioLayout::capture(&document).unwrap();

    let mut timing_records = Vec::new();
    let mut clocks_by_sound = BTreeMap::new();
    for (event_index, _) in event_assets.iter().enumerate() {
        let sound = SoundId::new(format!("sound-{event_index}")).unwrap();
        let mut clocks = Vec::with_capacity(clocks_per_event);
        for ordinal in 0..clocks_per_event {
            let timing = AudioTimingId {
                allocation: revision(&format!("timing-{event_index}-{ordinal}")),
                ordinal: 0,
            };
            clocks.push(SoundClockReference::new(
                timing.clone(),
                scope.clone(),
                owner.clone(),
            ));
            timing_records.push(AudioTimingRecord {
                id: timing,
                layout: layout.clone(),
            });
        }
        clocks_by_sound.insert(
            sound,
            SoundClockJournal::new(scope.clone(), clocks).unwrap(),
        );
    }
    let bindings = AudioBindingState::new_with_sound_clocks(
        timing_records,
        BTreeMap::new(),
        BTreeMap::new(),
        BTreeMap::from([(owner, clocks_by_sound)]),
    )
    .unwrap();
    let mut wire = serde_json::to_value(document).unwrap();
    wire["audio_bindings"] = serde_json::to_value(bindings).unwrap();
    ProjectDocument::from_json(&wire.to_string()).unwrap()
}

fn control<'a>(cancelled: &'a AtomicBool, work: &'a RefCell<ReadWork>) -> WorkControl<'a> {
    WorkControl {
        cancelled,
        deadline: Instant::now() + Duration::from_secs(30),
        work,
    }
}

fn instance(name: &str) -> InstancePath {
    InstancePath {
        node: id(name),
        repeats: Vec::new(),
    }
}

fn batch<'plan>(
    plan: &'plan RenderPlan,
    range: Range<AudioSample>,
    control: WorkControl<'_>,
) -> deadpan_plan::AudioSourceOccurrences<'plan> {
    let (owner, events) = plan.beat_sounds().first_key_value().unwrap();
    let (sound, event) = events.first_key_value().unwrap();
    current_occurrences(
        plan,
        None,
        owner,
        event,
        range,
        plan.beat_sound_clock_count(owner, sound),
        control,
    )
    .unwrap()
}

#[test]
fn discovery_key_is_exact_and_taken_storage_stays_leased() {
    let plan = RenderPlan::compile(&document(&["asset-a", "asset-b"], 1)).unwrap();
    let foreign = plan.clone();
    let stage = StageAudio::new(Arc::new(plan.clone()));
    let cancelled = AtomicBool::new(false);
    let work = RefCell::new(ReadWork {
        projected_resident_frames: 7,
        ..Default::default()
    });
    let control = control(&cancelled, &work);
    let range = AudioSample(0)..AudioSample(1);
    let mut memo = DiscoveredSounds::new(&stage, &plan, range.clone(), None, control)
        .unwrap()
        .unwrap();
    let fixed = work.borrow().projected_resident_frames;
    assert!(fixed > 7);
    let (owner, events) = plan.beat_sounds().first_key_value().unwrap();
    let (sound, _) = events.first_key_value().unwrap();
    memo.retain(
        &stage,
        owner,
        sound,
        batch(&plan, range.clone(), control),
        control,
    )
    .unwrap();
    let first = work.borrow().projected_resident_frames;
    assert!(first > fixed);
    let (second, event) = events.last_key_value().unwrap();
    let more = current_occurrences(&plan, None, owner, event, range.clone(), 1, control).unwrap();
    memo.retain(&stage, owner, second, more, control).unwrap();
    assert!(work.borrow().projected_resident_frames > first);
    let full = work.borrow().projected_resident_frames;
    assert!(
        memo.take(&foreign, &range, None, owner, sound, control)
            .unwrap()
            .is_none()
    );
    assert!(
        memo.take(
            &plan,
            &(AudioSample(0)..AudioSample(2)),
            None,
            owner,
            sound,
            control
        )
        .unwrap()
        .is_none()
    );
    let context = plan
        .audio_sound_instance_context(&instance("owner"), Default::default())
        .unwrap();
    assert!(
        memo.take(&plan, &range, Some(&context), owner, sound, control)
            .unwrap()
            .is_none()
    );
    assert!(
        memo.take(
            &plan,
            &range,
            None,
            owner,
            &SoundId::new("absent").unwrap(),
            control
        )
        .unwrap()
        .is_none()
    );
    assert!(
        memo.take(&plan, &range, None, owner, sound, control)
            .unwrap()
            .is_some()
    );
    assert!(
        memo.take(&plan, &range, None, owner, sound, control)
            .unwrap()
            .is_none()
    );
    assert_eq!(work.borrow().projected_resident_frames, full);
    let bad_context = foreign
        .audio_sound_instance_context(&instance("owner"), Default::default())
        .unwrap();
    assert!(matches!(
        memo.take(&plan, &range, Some(&bad_context), owner, sound, control),
        Err(StageAudioError::ForeignDomain)
    ));
    drop(memo);
    assert_eq!(work.borrow().projected_resident_frames, 7);
}

#[test]
fn scoped_empty_batch_and_fallback_budgets_preserve_cleanup() {
    let plan = RenderPlan::compile(&document(&["asset-a"], 1)).unwrap();
    let mut stage = StageAudio::new(Arc::new(plan.clone()));
    let cancelled = AtomicBool::new(false);
    let work = RefCell::new(ReadWork::default());
    let request = control(&cancelled, &work);
    let range = AudioSample(1_000_000)..AudioSample(1_000_001);
    let context = plan
        .audio_sound_instance_context(&instance("owner"), Default::default())
        .unwrap();
    let mut memo = DiscoveredSounds::new(&stage, &plan, range.clone(), Some(&context), request)
        .unwrap()
        .unwrap();
    let (owner, events) = plan.beat_sounds().first_key_value().unwrap();
    let (sound, event) = events.first_key_value().unwrap();
    let empty = current_occurrences(
        &plan,
        Some(&context),
        owner,
        event,
        range.clone(),
        1,
        request,
    )
    .unwrap();
    assert!(empty.voices().is_empty());
    memo.retain(&stage, owner, sound, empty, request).unwrap();
    let equivalent = plan
        .audio_sound_instance_context(&instance("owner"), Default::default())
        .unwrap();
    assert!(
        memo.take(&plan, &range, Some(&equivalent), owner, sound, request)
            .unwrap()
            .unwrap()
            .voices()
            .is_empty()
    );
    drop(memo);
    assert_eq!(work.borrow().projected_resident_frames, 0);

    // The following unscoped fallback checks use an in-project query. The
    // deliberately outside-project range above is valid only after the checked
    // owner context clamps its discovery support.
    let range = AudioSample(0)..AudioSample(1);
    // Fixed metadata itself must fit before allocating its bounded slot Vec.
    stage.limits.maximum_resident_frames = 1;
    assert!(
        DiscoveredSounds::new(&stage, &plan, range.clone(), None, request)
            .unwrap()
            .is_none()
    );
    assert_eq!(work.borrow().projected_resident_frames, 0);
    stage.limits = StageLimits::default();
    let mut memo = DiscoveredSounds::new(&stage, &plan, range.clone(), None, request)
        .unwrap()
        .unwrap();
    let fixed = work.borrow().projected_resident_frames;
    stage.limits.maximum_resident_frames = u32::try_from(fixed).unwrap();
    memo.retain(
        &stage,
        owner,
        sound,
        batch(&plan, range.clone(), request),
        request,
    )
    .unwrap();
    assert!(
        memo.take(&plan, &range, None, owner, sound, request)
            .unwrap()
            .is_none()
    );
    assert_eq!(work.borrow().projected_resident_frames, fixed);
    drop(memo);
    assert_eq!(work.borrow().projected_resident_frames, 0);

    stage.limits = StageLimits::default();
    let exhausted = RefCell::new(ReadWork {
        cache_plan_work: MAX_PLAN_WORK_PER_READ,
        ..Default::default()
    });
    assert!(
        DiscoveredSounds::new(&stage, &plan, range, None, control(&cancelled, &exhausted))
            .unwrap()
            .is_none()
    );
    assert_eq!(exhausted.borrow().plan_work, 0);
    assert_eq!(exhausted.borrow().projected_resident_frames, 0);
}

#[test]
fn discovery_lease_releases_on_error_and_never_masks_cancellation() {
    let plan = RenderPlan::compile(&document(&["asset-a"], 1)).unwrap();
    let stage = StageAudio::new(Arc::new(plan.clone()));
    let cancelled = AtomicBool::new(false);
    let work = RefCell::new(ReadWork::default());
    let request = control(&cancelled, &work);
    let result: Result<(), StageAudioError> = (|| {
        let _memo =
            DiscoveredSounds::new(&stage, &plan, AudioSample(0)..AudioSample(1), None, request)?
                .unwrap();
        assert!(work.borrow().projected_resident_frames > 0);
        Err(StageAudioError::Limit("witness error after discovery"))
    })();
    assert!(result.is_err());
    assert_eq!(work.borrow().projected_resident_frames, 0);
    let limited = RefCell::new(ReadWork {
        plan_work: MAX_PLAN_WORK_PER_READ - 1,
        ..Default::default()
    });
    let mut failing_stage = StageAudio::new(Arc::new(plan.clone()));
    assert!(matches!(
        failing_stage.prepare_sound_processing_plans_with_discovery(
            &plan,
            AudioSample(0)..AudioSample(1),
            control(&cancelled, &limited),
            None,
        ),
        Err(StageAudioError::Limit("plan work per read"))
    ));
    assert_eq!(limited.borrow().projected_resident_frames, 0);
    cancelled.store(true, std::sync::atomic::Ordering::Relaxed);
    assert!(
        DiscoveredSounds::new(&stage, &plan, AudioSample(0)..AudioSample(1), None, request)
            .is_err()
    );
    assert_eq!(work.borrow().projected_resident_frames, 0);
}

#[test]
fn discovery_distinguishes_stable_repeat_plays_in_the_full_context_path() {
    use deadpan_core::{
        Command, CommandRequest, RepeatSelectionIdentities, SliceCaptureSelection, SplitIdentities,
    };
    let document = document(&["asset-a"], 1);
    let edit = deadpan_core::apply(
        &document,
        &CommandRequest {
            project_id: document.project_id().clone(),
            expected_revision: document.revision_id().clone(),
            new_revision: revision("wrapped"),
            command: Command::RepeatSelection {
                parent: id("root"),
                selection: SliceCaptureSelection::Child { node: id("owner") },
                plays: 2,
                identities: RepeatSelectionIdentities {
                    repeat: id("repeat"),
                    group: None,
                    split: SplitIdentities::default(),
                },
                timing: AudioTimingId {
                    allocation: revision("wrapped"),
                    ordinal: 0,
                },
            },
        },
    )
    .unwrap();
    let document = edit.forward.apply(&document).unwrap();
    let plan = RenderPlan::compile(&document).unwrap();
    let stage = StageAudio::new(Arc::new(plan.clone()));
    let paths = plan
        .audio_owner_occurrences(
            &id("owner"),
            AudioSample(0)..AudioSample(320_320),
            Default::default(),
        )
        .unwrap();
    assert_eq!(paths.occurrences().len(), 2);
    let first = plan
        .audio_sound_instance_context(paths.occurrences()[0].instance(), Default::default())
        .unwrap();
    let second = plan
        .audio_sound_instance_context(paths.occurrences()[1].instance(), Default::default())
        .unwrap();
    assert_eq!(first.owner().node, second.owner().node);
    assert_ne!(first.owner().repeats, second.owner().repeats);
    let cancelled = AtomicBool::new(false);
    let work = RefCell::new(ReadWork::default());
    let request = control(&cancelled, &work);
    let range = AudioSample(0)..AudioSample(1);
    let mut memo = DiscoveredSounds::new(&stage, &plan, range.clone(), Some(&first), request)
        .unwrap()
        .unwrap();
    let (owner, events) = plan.beat_sounds().first_key_value().unwrap();
    let (sound, event) = events.first_key_value().unwrap();
    let batch = current_occurrences(
        &plan,
        Some(&first),
        owner,
        event,
        range.clone(),
        plan.beat_sound_clock_count(owner, sound),
        request,
    )
    .unwrap();
    memo.retain(&stage, owner, sound, batch, request).unwrap();
    assert!(
        memo.take(&plan, &range, Some(&second), owner, sound, request)
            .unwrap()
            .is_none()
    );
    assert!(
        memo.take(&plan, &range, Some(&first), owner, sound, request)
            .unwrap()
            .is_some()
    );
    drop(memo);
    assert_eq!(work.borrow().projected_resident_frames, 0);
}

#[test]
fn paired_helper_budget_fallback_preserves_legacy_canonical_work() {
    let plan = Arc::new(RenderPlan::compile(&document(&["asset-a", "asset-b"], 1)).unwrap());
    let cancelled = AtomicBool::new(false);
    for limited_key_budget in [false, true] {
        let mut legacy = StageAudio::new(Arc::clone(&plan));
        let mut fallback = StageAudio::new(Arc::clone(&plan));
        if !limited_key_budget {
            fallback.limits.maximum_resident_frames = 1;
        }
        let legacy_work = RefCell::new(ReadWork::default());
        let fallback_work = RefCell::new(ReadWork {
            cache_plan_work: if limited_key_budget {
                MAX_PLAN_WORK_PER_READ
            } else {
                0
            },
            ..Default::default()
        });
        let old = control(&cancelled, &legacy_work);
        let new = control(&cancelled, &fallback_work);
        let range = AudioSample(0)..AudioSample(1);
        let legacy_plans = legacy
            .prepare_sound_processing_plans_in_context(&plan, range.clone(), old, None)
            .unwrap();
        let (fallback_plans, mut memo) = fallback
            .prepare_sound_processing_plans_with_discovery(&plan, range.clone(), new, None)
            .unwrap();
        assert!(memo.is_none());
        let legacy_sounds = legacy
            .prepare_beat_sounds(&plan, &legacy_plans, range.clone(), old, None)
            .unwrap();
        let fallback_sounds = fallback
            .prepare_beat_sounds_with_discovery(
                &plan,
                &fallback_plans,
                range,
                new,
                None,
                memo.as_mut(),
            )
            .unwrap();
        assert_eq!(legacy_sounds.len(), fallback_sounds.len());
        assert_eq!(
            legacy_work.borrow().plan_work,
            fallback_work.borrow().plan_work
        );
        assert_eq!(fallback_work.borrow().projected_resident_frames, 0);
        if !limited_key_budget {
            assert_eq!(fallback_work.borrow().cache_plan_work, 1);
        }
    }
}

#[cfg(any(target_os = "macos", target_os = "linux"))]
struct Provider {
    prepared: crate::PreparedSource,
    calls: Vec<(ProjectId, RevisionId, AssetId, bool)>,
}

#[test]
fn unclocked_and_empty_plans_add_no_discovery_allocation_or_key_work() {
    for has_event in [false, true] {
        let mut wire = serde_json::to_value(document(&["asset-a"], 1)).unwrap();
        wire["audio_bindings"] = serde_json::to_value(AudioBindingState::default()).unwrap();
        if !has_event {
            wire["beat_sounds"] = serde_json::json!({});
        }
        let document = ProjectDocument::from_json(&wire.to_string()).unwrap();
        let plan = Arc::new(RenderPlan::compile(&document).unwrap());
        let mut legacy = StageAudio::new(Arc::clone(&plan));
        let mut reused = StageAudio::new(Arc::clone(&plan));
        let cancelled = AtomicBool::new(false);
        let old_work = RefCell::new(ReadWork::default());
        let new_work = RefCell::new(ReadWork::default());
        let old = control(&cancelled, &old_work);
        let new = control(&cancelled, &new_work);
        let range = AudioSample(0)..AudioSample(1);
        let old_plans = legacy
            .prepare_sound_processing_plans_in_context(&plan, range.clone(), old, None)
            .unwrap();
        let (new_plans, mut memo) = reused
            .prepare_sound_processing_plans_with_discovery(&plan, range.clone(), new, None)
            .unwrap();
        assert!(memo.is_none());
        assert_eq!(old_plans.len(), new_plans.len());
        let old_sounds = legacy
            .prepare_beat_sounds(&plan, &old_plans, range.clone(), old, None)
            .unwrap();
        let new_sounds = reused
            .prepare_beat_sounds_with_discovery(&plan, &new_plans, range, new, None, memo.as_mut())
            .unwrap();
        assert_eq!(old_sounds.len(), new_sounds.len());
        assert_eq!(old_work.borrow().plan_work, new_work.borrow().plan_work);
        assert_eq!(new_work.borrow().cache_plan_work, 0);
        assert_eq!(new_work.borrow().projected_resident_frames, 0);
    }
}

#[cfg(any(target_os = "macos", target_os = "linux"))]
impl Provider {
    fn new() -> Self {
        use deadpan_media::audio_index::AudioChannelLayout;
        use deadpan_media::audio_session::{AudioSession, AudioSessionLimits};
        use deadpan_media::source_index::SourceContentIdentity;
        use sha2::{Digest, Sha256};
        let bytes = std::fs::read(
            std::path::Path::new(env!("CARGO_MANIFEST_DIR"))
                .join("../../native/deadpan-source/tests/audio-fixtures/pcm-stereo-48000.wav"),
        )
        .unwrap();
        let cancelled = AtomicBool::new(false);
        let session = AudioSession::open_verified(
            &mut std::io::Cursor::new(&bytes),
            SourceContentIdentity::new(Sha256::digest(&bytes).into(), bytes.len() as u64).unwrap(),
            0,
            AudioSessionLimits::default(),
            &cancelled,
        )
        .unwrap();
        let index = session.index().clone();
        Self {
            prepared: crate::PreparedSource::with_layout(
                session,
                &index,
                AudioChannelLayout::Native {
                    channels: 2,
                    mask: 3,
                },
                &cancelled,
            )
            .unwrap(),
            calls: Vec::new(),
        }
    }
}

#[cfg(any(target_os = "macos", target_os = "linux"))]
impl AudioSourceProvider for Provider {
    fn source(
        &mut self,
        project: &ProjectId,
        revision: &RevisionId,
        asset: &AssetId,
        _: &AtomicBool,
    ) -> Result<&crate::PreparedSource, PreparationError> {
        self.calls
            .push((project.clone(), revision.clone(), asset.clone(), false));
        Ok(&self.prepared)
    }
    fn source_for_context(
        &mut self,
        project: &ProjectId,
        revision: &RevisionId,
        asset_id: &AssetId,
        expected: &AssetRecord,
        _: &AtomicBool,
    ) -> Result<&crate::PreparedSource, PreparationError> {
        assert_eq!(expected, &asset(asset_id.as_str()));
        self.calls
            .push((project.clone(), revision.clone(), asset_id.clone(), true));
        Ok(&self.prepared)
    }
}

#[cfg(any(target_os = "macos", target_os = "linux"))]
#[test]
fn paired_discovery_removes_only_duplicate_canonical_construction_and_keeps_pcm() {
    let plan = Arc::new(RenderPlan::compile(&document(&["asset-a", "asset-b"], 2)).unwrap());
    for scoped in [false, true] {
        let context = scoped.then(|| {
            plan.audio_sound_instance_context(&instance("owner"), Default::default())
                .unwrap()
        });
        let range = AudioSample(19)..AudioSample(147);
        let mut legacy = StageAudio::new(Arc::clone(&plan));
        let mut reused = StageAudio::new(Arc::clone(&plan));
        let cancelled = AtomicBool::new(false);
        let legacy_work = RefCell::new(ReadWork::default());
        let reused_work = RefCell::new(ReadWork::default());
        let legacy_control = control(&cancelled, &legacy_work);
        let reused_control = control(&cancelled, &reused_work);
        let probe_work = RefCell::new(ReadWork::default());
        let probe = control(&cancelled, &probe_work);
        for (owner, events) in plan.beat_sounds() {
            for (sound, event) in events {
                current_occurrences(
                    &plan,
                    context.as_ref(),
                    owner,
                    event,
                    range.clone(),
                    plan.beat_sound_clock_count(owner, sound),
                    probe,
                )
                .unwrap();
            }
        }
        let expected_removed = probe_work.borrow().plan_work;
        assert!(expected_removed > 0);
        let legacy_plans = legacy
            .prepare_sound_processing_plans_in_context(
                &plan,
                range.clone(),
                legacy_control,
                context.as_ref(),
            )
            .unwrap();
        let (reused_plans, mut memo) = reused
            .prepare_sound_processing_plans_with_discovery(
                &plan,
                range.clone(),
                reused_control,
                context.as_ref(),
            )
            .unwrap();
        assert_eq!(
            legacy_plans.keys().collect::<Vec<_>>(),
            reused_plans.keys().collect::<Vec<_>>()
        );
        assert!(memo.is_some());
        let legacy_sounds = legacy
            .prepare_beat_sounds(
                &plan,
                &legacy_plans,
                range.clone(),
                legacy_control,
                context.as_ref(),
            )
            .unwrap();
        let reused_sounds = reused
            .prepare_beat_sounds_with_discovery(
                &plan,
                &reused_plans,
                range.clone(),
                reused_control,
                context.as_ref(),
                memo.as_mut(),
            )
            .unwrap();
        assert_eq!(
            legacy_work.borrow().plan_work - reused_work.borrow().plan_work,
            expected_removed
        );
        assert!(reused_work.borrow().cache_plan_work > 0);
        assert!(reused_work.borrow().projected_resident_frames > 0);
        let mut old_provider = Provider::new();
        let mut new_provider = Provider::new();
        assert_eq!(legacy_sounds.len(), reused_sounds.len());
        for (old, new) in legacy_sounds.into_iter().zip(reused_sounds) {
            assert_eq!((old.owner, old.id), (new.owner, new.id));
            assert_eq!(old.occurrences.len(), new.occurrences.len());
            for (old, new) in old.occurrences.into_iter().zip(new.occurrences) {
                assert_eq!(old.voice.instance(), new.voice.instance());
                assert_eq!(old.samples, new.samples);
                assert_eq!(old.fades, new.fades);
                assert_eq!(old.post_fades, new.post_fades);
                let old = legacy
                    .read_prepared_beat_sound(
                        &mut old_provider,
                        old.input,
                        old.samples,
                        legacy_control,
                    )
                    .unwrap();
                let new = reused
                    .read_prepared_beat_sound(
                        &mut new_provider,
                        new.input,
                        new.samples,
                        reused_control,
                    )
                    .unwrap();
                assert_eq!(
                    old.samples
                        .iter()
                        .map(|s| s.map(f32::to_bits))
                        .collect::<Vec<_>>(),
                    new.samples
                        .iter()
                        .map(|s| s.map(f32::to_bits))
                        .collect::<Vec<_>>()
                );
                assert!(old.samples.iter().any(|frame| *frame != [0.0; 2]));
                assert_eq!(old.suppressed, new.suppressed);
                assert_eq!(old.exhausted, new.exhausted);
                assert_eq!(old.dependencies, new.dependencies);
                assert_eq!(old.relative_depth, new.relative_depth);
            }
        }
        assert_eq!(old_provider.calls, new_provider.calls);
        assert_eq!(
            legacy_work.borrow().source_checks,
            reused_work.borrow().source_checks
        );
        assert_eq!(
            legacy_work.borrow().prepared_frames,
            reused_work.borrow().prepared_frames
        );
        assert_eq!(
            legacy_work.borrow().prepared_stages,
            reused_work.borrow().prepared_stages
        );
        assert_eq!(
            legacy_work.borrow().plan_work - reused_work.borrow().plan_work,
            expected_removed
        );
        drop(memo);
        assert_eq!(
            reused_work.borrow().projected_resident_frames,
            legacy_work.borrow().projected_resident_frames
        );
    }
}

#[cfg(any(target_os = "macos", target_os = "linux"))]
fn assert_no_memo_lease(work: &RefCell<ReadWork>) {
    let work = work.borrow();
    let required_projection_frames: u64 = work
        .projected
        .iter()
        .map(|(_, block)| block.samples.resident_frames())
        .sum();
    assert_eq!(work.projected_resident_frames, required_projection_frames);
}

#[cfg(any(target_os = "macos", target_os = "linux"))]
fn charged_work(work: &RefCell<ReadWork>) -> [u64; 5] {
    let work = work.borrow();
    [
        work.plan_work as u64,
        work.cache_plan_work as u64,
        u64::from(work.prepared_stages),
        work.prepared_frames,
        u64::from(work.source_checks),
    ]
}

#[cfg(any(target_os = "macos", target_os = "linux"))]
fn limited_stage(plan: &Arc<RenderPlan>, resident: u32) -> StageAudio {
    StageAudio::with_limits(
        Arc::clone(plan),
        StageLimits {
            maximum_resident_frames: resident,
            ..Default::default()
        },
    )
    .unwrap()
}

#[cfg(any(target_os = "macos", target_os = "linux"))]
fn same_root_pcm(expected: &ReadBlock, actual: &ReadBlock) {
    assert_eq!(expected.start, actual.start);
    assert_eq!(
        expected
            .samples
            .iter()
            .map(|frame| frame.map(f32::to_bits))
            .collect::<Vec<_>>(),
        actual
            .samples
            .iter()
            .map(|frame| frame.map(f32::to_bits))
            .collect::<Vec<_>>()
    );
    assert_eq!(expected.suppressed, actual.suppressed);
    assert_eq!(expected.exhausted, actual.exhausted);
    assert_eq!(expected.dependencies, actual.dependencies);
    assert_eq!(expected.relative_depth, actual.relative_depth);
}

#[cfg(any(target_os = "macos", target_os = "linux"))]
#[test]
fn tight_root_residency_retries_without_discovery_and_keeps_all_attempt_work() {
    use crate::stages::shared_eq::InputSelection;
    for preserve in [false, true] {
        let plan = Arc::new(
            RenderPlan::compile(&document_shape(&["asset-a"], 1, preserve, true)).unwrap(),
        );
        let cancelled = AtomicBool::new(false);
        let start = AudioSample(1024);
        let frames = 128;
        let mut provider = Provider::new();
        // At most24 probes locate an actual required-PCM threshold. The
        // optional memo's allocator/layout size is deliberately not hardcoded.
        let mut low = 1;
        let mut high = StageLimits::default().maximum_resident_frames;
        while low < high {
            let middle = low + (high - low) / 2;
            let mut stage = limited_stage(&plan, middle);
            let work = RefCell::new(ReadWork::default());
            let result = stage.read_shared_input_attempt(
                &mut provider,
                start,
                frames,
                control(&cancelled, &work),
                InputSelection::default(),
                (false, &mut false),
            );
            assert_eq!(stage.active_frames, 0);
            assert_no_memo_lease(&work);
            match result {
                Ok(_) => high = middle,
                Err(StageAudioError::Limit("resident PCM or stage cache")) => low = middle + 1,
                Err(error) => {
                    panic!("unexpected legacy probe error ({preserve}, {middle}): {error}")
                }
            }
        }
        let mut baseline = limited_stage(&plan, high);
        let baseline_work = RefCell::new(ReadWork::default());
        let expected = baseline
            .read_shared_input_attempt(
                &mut provider,
                start,
                frames,
                control(&cancelled, &baseline_work),
                InputSelection::default(),
                (false, &mut false),
            )
            .unwrap();
        assert!(expected.samples.iter().any(|frame| *frame != [0.0; 2]));
        assert_no_memo_lease(&baseline_work);

        let mut manual = limited_stage(&plan, high);
        let mut manual_provider = Provider::new();
        let manual_work = RefCell::new(ReadWork::default());
        let request = control(&cancelled, &manual_work);
        let mut used = false;
        let first = manual.read_shared_input_attempt(
            &mut manual_provider,
            start,
            frames,
            request,
            InputSelection::default(),
            (true, &mut used),
        );
        assert!(
            used,
            "the tight-cap witness must actually retain discovery ({preserve}, {high})"
        );
        assert!(matches!(
            first,
            Err(StageAudioError::Limit("resident PCM or stage cache"))
        ));
        assert_eq!(manual.active_frames, 0);
        assert_no_memo_lease(&manual_work);
        let failed_work = charged_work(&manual_work);
        assert!(failed_work[0] > 0);
        let retried = manual
            .read_shared_input_attempt(
                &mut manual_provider,
                start,
                frames,
                request,
                InputSelection::default(),
                (false, &mut false),
            )
            .unwrap();
        same_root_pcm(&expected, &retried);
        assert_eq!(manual.active_frames, 0);
        assert_no_memo_lease(&manual_work);
        let combined_work = charged_work(&manual_work);
        assert!(combined_work[0] > failed_work[0]);

        let mut automatic = limited_stage(&plan, high);
        let mut automatic_provider = Provider::new();
        let automatic_work = RefCell::new(ReadWork::default());
        let actual = automatic
            .read_shared_input(
                &mut automatic_provider,
                start,
                frames,
                control(&cancelled, &automatic_work),
                InputSelection::default(),
            )
            .unwrap();
        same_root_pcm(&expected, &actual);
        assert_eq!(automatic.active_frames, 0);
        assert_no_memo_lease(&automatic_work);
        assert_eq!(combined_work, charged_work(&automatic_work));
        assert_eq!(manual_provider.calls, automatic_provider.calls);
    }
}
