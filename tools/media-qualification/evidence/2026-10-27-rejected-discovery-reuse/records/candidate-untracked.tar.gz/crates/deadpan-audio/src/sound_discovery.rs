//! Request-local reuse of the clocked sound discovery already needed to choose
//! retained processing plans. This bounds retained, post-construction storage;
//! it does not bound the baseline query constructor's transient allocations.

use super::*;
use deadpan_core::{MAX_DOCUMENT_SOUNDS, NodeId, SoundId};
use deadpan_plan::{AudioSoundOwnerContext, AudioSourceOccurrences};

struct Entry<'plan> {
    owner: &'plan NodeId,
    sound: &'plan SoundId,
    batch: Option<AudioSourceOccurrences<'plan>>,
}

/// The charge remains pinned after a batch is taken, since prepared voices may
/// retain shared allocations until the caller has consumed its prepared sounds.
struct MemoryLease<'work> {
    work: &'work RefCell<ReadWork>,
    frames: u64,
}

impl<'work> MemoryLease<'work> {
    fn new(control: WorkControl<'work>) -> Self {
        Self {
            work: control.work,
            frames: 0,
        }
    }

    fn extend(
        &mut self,
        controller: &StageAudio,
        bytes: usize,
        control: WorkControl<'_>,
    ) -> Result<bool, StageAudioError> {
        control.check()?;
        let Ok(bytes) = u64::try_from(bytes) else {
            return Ok(false);
        };
        let frames = bytes.div_ceil(std::mem::size_of::<[f32; 2]>() as u64);
        let mut work = self.work.borrow_mut();
        let Some(next) = work.projected_resident_frames.checked_add(frames) else {
            return Ok(false);
        };
        let fits = controller
            .cached_resident_frames()
            .checked_add(controller.active_frames)
            .and_then(|n| n.checked_add(next))
            .is_some_and(|n| n <= u64::from(controller.limits.maximum_resident_frames));
        let Some(leased) = self.frames.checked_add(frames) else {
            return Ok(false);
        };
        if !fits {
            return Ok(false);
        }
        work.projected_resident_frames = next;
        self.frames = leased;
        Ok(true)
    }
}

impl Drop for MemoryLease<'_> {
    fn drop(&mut self) {
        self.work.borrow_mut().projected_resident_frames -= self.frames;
    }
}

pub(in crate::stages) struct DiscoveredSounds<'plan, 'work> {
    plan: &'plan RenderPlan,
    samples: Range<AudioSample>,
    context: Option<InstancePath>,
    entries: Vec<Entry<'plan>>,
    lease: MemoryLease<'work>,
}

// Cloning an identifier pins its Arc payload. Charge that payload too, even
// when another key or query already owns it. Padding conservatively covers Arc
// counters/alignment without depending on the core identifier's representation.
fn identity_bytes(text: &str) -> Option<usize> {
    text.len().checked_add(4 * std::mem::size_of::<usize>())
}

fn context_bytes(
    context: Option<&AudioSoundOwnerContext<'_>>,
    control: WorkControl<'_>,
) -> Result<Option<usize>, StageAudioError> {
    let Some(context) = context else {
        return Ok(Some(0));
    };
    let path = context.owner();
    control.spend_plan_work(1 + path.repeats.len() * 3)?;
    let mut bytes = path
        .repeats
        .len()
        .checked_mul(std::mem::size_of::<deadpan_core::RepeatInstance>())
        .and_then(|n| identity_bytes(path.node.as_str()).and_then(|id| n.checked_add(id)));
    for repeat in &path.repeats {
        bytes = bytes
            .and_then(|n| identity_bytes(repeat.node.as_str()).and_then(|id| n.checked_add(id)))
            .and_then(|n| {
                identity_bytes(repeat.iteration.allocation.as_str())
                    .and_then(|id| n.checked_add(id))
            });
    }
    Ok(bytes)
}

fn optional<T>(result: Result<T, StageAudioError>) -> Result<Option<T>, StageAudioError> {
    match result {
        Ok(value) => Ok(Some(value)),
        Err(StageAudioError::Limit(CACHE_KEY_WORK_LIMIT)) => Ok(None),
        Err(error) => Err(error),
    }
}

impl<'plan, 'work> DiscoveredSounds<'plan, 'work> {
    pub(in crate::stages) fn new(
        controller: &StageAudio,
        plan: &'plan RenderPlan,
        samples: Range<AudioSample>,
        context: Option<&AudioSoundOwnerContext<'plan>>,
        control: WorkControl<'work>,
    ) -> Result<Option<Self>, StageAudioError> {
        control.check()?;
        if context.is_some_and(|context| !context.belongs_to(plan)) {
            return Err(StageAudioError::ForeignDomain);
        }
        let metadata = {
            let _scope = control.cache_key_scope();
            optional((|| {
                control.spend_plan_work(1)?;
                let Some(key) = context_bytes(context, control)? else {
                    return Ok(None);
                };
                Ok(MAX_DOCUMENT_SOUNDS
                    .checked_mul(std::mem::size_of::<Entry<'plan>>())
                    .and_then(|n| n.checked_add(std::mem::size_of::<Self>()))
                    .and_then(|n| n.checked_add(key)))
            })())?
        };
        let Some(Some(metadata)) = metadata else {
            return Ok(None);
        };
        let mut lease = MemoryLease::new(control);
        if !lease.extend(controller, metadata, control)? {
            return Ok(None);
        }
        Ok(Some(Self {
            plan,
            samples,
            context: context.map(|context| context.owner().clone()),
            entries: Vec::with_capacity(MAX_DOCUMENT_SOUNDS),
            lease,
        }))
    }

    pub(in crate::stages) fn retain(
        &mut self,
        controller: &StageAudio,
        owner: &'plan NodeId,
        sound: &'plan SoundId,
        batch: AudioSourceOccurrences<'plan>,
        control: WorkControl<'_>,
    ) -> Result<(), StageAudioError> {
        control.check()?;
        if self.entries.len() == self.entries.capacity() {
            return Ok(());
        }
        let measured = {
            let _scope = control.cache_key_scope();
            optional((|| {
                let maximum = control.query_limits()?.maximum_work;
                let (bytes, work) = match batch.allocated_bytes_bound(maximum) {
                    Ok(measured) => measured,
                    Err(PlanError::AudioQueryLimit(_)) => {
                        // An exhausted visitor spent its supplied allowance;
                        // keep that optional cost distinct from canonical work.
                        control.spend_plan_work(maximum)?;
                        return Ok(None);
                    }
                    Err(error) => return Err(error.into()),
                };
                control.spend_plan_work(work)?;
                Ok(Some(bytes))
            })())?
        };
        let Some(Some(bytes)) = measured else {
            return Ok(());
        };
        if self.lease.extend(controller, bytes, control)? {
            self.entries.push(Entry {
                owner,
                sound,
                batch: Some(batch),
            });
        }
        Ok(())
    }

    pub(in crate::stages) fn take(
        &mut self,
        plan: &RenderPlan,
        samples: &Range<AudioSample>,
        context: Option<&AudioSoundOwnerContext<'_>>,
        owner: &NodeId,
        sound: &SoundId,
        control: WorkControl<'_>,
    ) -> Result<Option<AudioSourceOccurrences<'plan>>, StageAudioError> {
        control.check()?;
        if context.is_some_and(|context| !context.belongs_to(plan)) {
            return Err(StageAudioError::ForeignDomain);
        }
        let found = {
            let _scope = control.cache_key_scope();
            optional((|| {
                control.spend_plan_work(1 + context.map_or(0, |c| c.owner().repeats.len()))?;
                if !std::ptr::eq(self.plan, plan)
                    || self.samples != *samples
                    || self.context.as_ref() != context.map(|context| context.owner())
                {
                    return Ok(None);
                }
                for (index, entry) in self.entries.iter().enumerate() {
                    control.spend_plan_work(1)?;
                    if entry.owner == owner && entry.sound == sound {
                        return Ok(Some(index));
                    }
                }
                Ok(None)
            })())?
        };
        Ok(found
            .flatten()
            .and_then(|index| self.entries[index].batch.take()))
    }
}

#[cfg(test)]
#[path = "sound_discovery/tests.rs"]
mod tests;
