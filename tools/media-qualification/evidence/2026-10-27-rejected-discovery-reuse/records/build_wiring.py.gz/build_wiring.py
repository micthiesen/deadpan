from pathlib import Path
import difflib
import hashlib
import subprocess
root = Path('/Users/michael/Code/deadpan')
scratch = Path('/tmp/deadpan-discovery-reuse-2026-10-26')
paths = [
    'crates/deadpan-audio/src/sound_clocks.rs',
    'crates/deadpan-audio/src/beat_sounds.rs',
    'crates/deadpan-audio/src/shared_eq.rs',
]
originals = {p: (root / p).read_text() for p in paths}
def replace(text, old, new):
    assert text.count(old) == 1, old[:150]
    return text.replace(old, new)
text = originals[paths[0]]
text = replace(text,
    'pub(super) type SoundProcessingPlans = BTreeMap<AudioTimingId, Arc<RenderPlan>>;',
    '''#[path = "sound_discovery.rs"]
pub(super) mod discovery;

pub(super) type SoundProcessingPlans = BTreeMap<AudioTimingId, Arc<RenderPlan>>;''')
anchor = '''    ) -> Result<SoundProcessingPlans, StageAudioError> {
        // Births can make a different reference first for different occurrences.'''
text = replace(text, anchor, '''    ) -> Result<SoundProcessingPlans, StageAudioError> {
        self.prepare_sound_processing_plans_discovered(plan, samples, control, context, false)
            .map(|(plans, _)| plans)
    }

    pub(super) fn prepare_sound_processing_plans_with_discovery<'plan, 'work>(
        &mut self,
        plan: &'plan RenderPlan,
        samples: Range<AudioSample>,
        control: WorkControl<'work>,
        context: Option<&deadpan_plan::AudioSoundOwnerContext<'plan>>,
    ) -> Result<(SoundProcessingPlans, Option<discovery::DiscoveredSounds<'plan, 'work>>), StageAudioError> {
        self.prepare_sound_processing_plans_discovered(plan, samples, control, context, true)
    }

    fn prepare_sound_processing_plans_discovered<'plan, 'work>(
        &mut self,
        plan: &'plan RenderPlan,
        samples: Range<AudioSample>,
        control: WorkControl<'work>,
        context: Option<&deadpan_plan::AudioSoundOwnerContext<'plan>>,
        retain_discovery: bool,
    ) -> Result<(SoundProcessingPlans, Option<discovery::DiscoveredSounds<'plan, 'work>>), StageAudioError> {
        let mut discovery = if retain_discovery {
            discovery::DiscoveredSounds::new(self, plan, samples.clone(), context, control)?
        } else {
            None
        };
        // Births can make a different reference first for different occurrences.''')
first = text.index('                if batch.voices().is_empty() {')
last = text.index('\n            }\n        }\n        let mut selected_assets', first)
body = text[first:last]
head = '''                if batch.voices().is_empty() {
                    continue;
                }
'''
assert body.startswith(head)
remaining = body[len(head):]
text = text[:first] + '''                if !batch.voices().is_empty() {
''' + ''.join('    ' + line + '\n' for line in remaining.splitlines()).rstrip('\n') + '''
                }
                if let Some(discovery) = &mut discovery {
                    discovery.retain(self, owner, sound, batch, control)?;
                }''' + text[last:]
text = replace(text, '        Ok(prepared)\n    }\n}', '        Ok((prepared, discovery))\n    }\n}')
(scratch / 'sound_clocks.rs').write_text(text)

text = originals[paths[1]]
anchor = '''    ) -> Result<Vec<PreparedBeatSound<'plan, 'history>>, StageAudioError> {
        let mut prepared = Vec::new();'''
text = replace(text, anchor, '''    ) -> Result<Vec<PreparedBeatSound<'plan, 'history>>, StageAudioError> {
        self.prepare_beat_sounds_with_discovery(plan, retained, samples, control, context, None)
    }

    pub(super) fn prepare_beat_sounds_with_discovery<'plan, 'history>(
        &mut self,
        plan: &'plan RenderPlan,
        retained: &'history super::sound_clocks::SoundProcessingPlans,
        samples: Range<AudioSample>,
        control: WorkControl<'_>,
        context: Option<&deadpan_plan::AudioSoundOwnerContext<'plan>>,
        mut discovery: Option<&mut super::sound_clocks::discovery::DiscoveredSounds<'plan, '_>>,
    ) -> Result<Vec<PreparedBeatSound<'plan, 'history>>, StageAudioError> {
        let mut prepared = Vec::new();''')
text = replace(text, '''                let batch = super::sound_clocks::current_occurrences(
                    plan,
                    context,
                    owner,
                    event,
                    samples.clone(),
                    plan.beat_sound_clock_count(owner, sound),
                    control,
                )?;''', '''                let discovered = if let Some(memo) = discovery.as_deref_mut() {
                    memo.take(plan, &samples, context, owner, sound, control)?
                } else {
                    None
                };
                let batch = if let Some(batch) = discovered {
                    batch
                } else {
                    super::sound_clocks::current_occurrences(
                        plan,
                        context,
                        owner,
                        event,
                        samples.clone(),
                        plan.beat_sound_clock_count(owner, sound),
                        control,
                    )?
                };''')
(scratch / 'beat_sounds.rs').write_text(text)

text = originals[paths[2]]
text = replace(text, '''        let retained = if sound_range.start < sound_range.end {
            self.prepare_sound_processing_plans_in_context(''', '''        // This lease stays live while prepared voices can retain discovered
        // query allocations, through their later PCM consumption below.
        let (retained, mut discovery) = if sound_range.start < sound_range.end {
            self.prepare_sound_processing_plans_with_discovery(''')
text = replace(text, '''        } else {
            BTreeMap::new()
        };
        let beats = if sound_range.start < sound_range.end {
            self.prepare_beat_sounds(plan, &retained, sound_range.clone(), control, context)?''', '''        } else {
            (BTreeMap::new(), None)
        };
        let beats = if sound_range.start < sound_range.end {
            self.prepare_beat_sounds_with_discovery(
                plan, &retained, sound_range.clone(), control, context, discovery.as_mut(),
            )?''')
(scratch / 'shared_eq.rs').write_text(text)
for path in paths:
    subprocess.run(['rustfmt', '--edition', '2024', '--config', 'skip_children=true', str(scratch / Path(path).name)], check=True)
diff = []
for path in paths:
    modified = (scratch / Path(path).name).read_text()
    diff.extend(difflib.unified_diff(originals[path].splitlines(True), modified.splitlines(True), fromfile=path, tofile=path))
(scratch / 'wiring.patch').write_text(''.join(diff))
(scratch / 'base-sha256.txt').write_text(''.join(f'{hashlib.sha256(originals[p].encode()).hexdigest()}  {p}\n' for p in paths))
print(f'Drafted {len(diff)} patch lines; existing files untouched.')
