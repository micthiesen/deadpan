#!/bin/sh
set -eu
export DEADPAN_FFMPEG_PREFIX=/Users/michael/Library/Developer/Deadpan/ffmpeg-8.0.3-opus-1.6.1-dav1d-1.5.4-qualified-3/prefix
export CARGO_PROFILE_DEV_OPT_LEVEL=2
export DEADPAN_REQUIRE_PHYSICAL_MAC=1
export DEADPAN_REQUIRE_SYNTHETIC_WORKER=1
export DEADPAN_PREVIEW_EXPORT_KEEP=1
s=/tmp/deadpan-selected-fixed-retime-duration-2026-10-22
export DEADPAN_SELECTED_FIXED_RETIME_DURATION_RESULTS="$s/integration-real-media-results.json"
cargo fmt --all > "$s/integration-format.log" 2>&1
cargo check --locked -p deadpan-store -p deadpan-cli --all-targets > "$s/integration-check.log" 2>&1
python "$s/freeze.py" integration > "$s/integration-freeze.log"
filter='test(selected_fixed_retime)'
cargo nextest list --locked -p deadpan-store -p deadpan-cli -E "$filter" --message-format json > "$s/integration-list.json" 2> "$s/integration-build.log"
python "$s/identity.py" integration > "$s/integration-identity.log"
cargo nextest run --locked -p deadpan-store -p deadpan-cli -E "$filter" --no-fail-fast > "$s/integration.log" 2>&1
