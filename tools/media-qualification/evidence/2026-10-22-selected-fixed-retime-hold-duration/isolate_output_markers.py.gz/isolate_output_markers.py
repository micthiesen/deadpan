from pathlib import Path
import hashlib,json,os,re,subprocess
s=Path('/tmp/deadpan-selected-fixed-retime-duration-2026-10-22')
binary=json.loads((s/'output-marker-binary.json').read_text());p=Path(binary['retained'])
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
assert sha(p)==binary['sha256']
env=os.environ.copy()
env.update(DEADPAN_FFMPEG_PREFIX='/Users/michael/Library/Developer/Deadpan/ffmpeg-8.0.3-opus-1.6.1-dav1d-1.5.4-qualified-3/prefix',DEADPAN_REQUIRE_PHYSICAL_MAC='1',DEADPAN_REQUIRE_SYNTHETIC_WORKER='1')
cases=set()
for name in ['regression-attempt-1.log','regression-final.log']:
 for line in (s/name).read_text().splitlines():
  if 'LEAK [' in line:
   prefix='deadpan-app::bin/deadpan-app '
   assert prefix in line,line
   cases.add(line.split(prefix,1)[1].strip())
reports=[]
for i,case in enumerate(sorted(cases)):
 result=subprocess.run([str(p),'--exact',case,'--nocapture'],env=env,capture_output=True,text=True,timeout=30)
 (s/f'output-marker-{i}.stdout').write_text(result.stdout)
 (s/f'output-marker-{i}.stderr').write_text(result.stderr)
 assert result.returncode==0 and '1 passed; 0 failed' in result.stdout,(case,result.returncode,result.stdout,result.stderr)
 reports.append({'case':case,'exit_code':result.returncode,'passed':True,'stdio_eof_within_seconds':30,'stdout':f'output-marker-{i}.stdout','stderr':f'output-marker-{i}.stderr'})
assert sha(p)==binary['sha256']
(s/'output-markers-isolated.json').write_text(json.dumps({'source_stage':'regression-final','binary_sha256':binary['sha256'],'cases':reports,'pre_post_binary_unchanged':True},indent=2)+'\n')
print(len(reports),'normal-feature output-marker cases pass in isolated exact binary runs and return stdio EOF')
