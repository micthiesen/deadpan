#!/bin/sh
set -eu
export DEADPAN_FFMPEG_PREFIX=/Users/michael/Library/Developer/Deadpan/ffmpeg-8.0.3-opus-1.6.1-dav1d-1.5.4-qualified-3/prefix
export CARGO_PROFILE_DEV_OPT_LEVEL=2
s=/tmp/deadpan-selected-fixed-retime-duration-2026-10-22
python "$s/check_test_run.py" regression-final
python "$s/check_test_run.py" ui-lint-final
python "$s/check_test_run.py" app-final
test -f "$s/whitespace.log"
python "$s/guard.py" app-final > "$s/pre-release-source-guard.log"
python "$s/freeze.py" final > "$s/final-freeze.log"
cargo build --locked -p deadpan-app --release --features ui-harness --bin deadpan-app > "$s/release-app.log" 2>&1
sh "$s/native.sh"
sh "$s/encoded.sh"
