from pathlib import Path
import json,subprocess,hashlib,os
s=Path('/tmp/deadpan-selected-fixed-retime-duration-2026-10-22')
binary=s/'encoded-bin/deadpan-cli'
rows=json.loads((s/'encoded-binaries.json').read_text())
assert hashlib.sha256(binary.read_bytes()).hexdigest()==rows['deadpan-cli']['sha256']
env=os.environ.copy()
env['DEADPAN_FFMPEG_PREFIX']='/Users/michael/Library/Developer/Deadpan/ffmpeg-8.0.3-opus-1.6.1-dav1d-1.5.4-qualified-3/prefix'
reports=[]
for owner in json.loads((s/'owner-fixtures-identity.json').read_text()):
 row={'case':owner['case'],'package':owner['extracted']}
 for action,args in [('validate',['project','validate',owner['extracted']]),('doctor',['doctor','--project',owner['extracted']])]:
  result=subprocess.run([str(binary),*args],capture_output=True,text=True,env=env)
  (s/('owner-'+owner['case']+'-'+action+'.stdout')).write_text(result.stdout)
  (s/('owner-'+owner['case']+'-'+action+'.stderr')).write_text(result.stderr)
  row[action]={'exit_code':result.returncode}
  assert result.returncode==0,(row,result.stdout,result.stderr)
 reports.append(row)
(s/'owner-fixtures-validation.json').write_text(json.dumps(reports,indent=2)+'\n')
print(len(reports),'extracted owner packages pass full validation and doctor')
