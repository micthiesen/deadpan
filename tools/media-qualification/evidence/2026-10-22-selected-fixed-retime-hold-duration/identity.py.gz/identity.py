from pathlib import Path
import hashlib,json,shutil,sys
s=Path('/tmp/deadpan-selected-fixed-retime-duration-2026-10-22')
stage=sys.argv[1]
for name,digest in json.loads((s/(stage+'-source-identities.json')).read_text()).items():
 assert hashlib.sha256(Path(name).read_bytes()).hexdigest()==digest,name
listing=json.loads((s/(stage+'-list.json')).read_text())
rows=[]
for name,suite in listing['rust-suites'].items():
 tests=[n for n,t in suite.get('testcases',{}).items() if t['filter-match']['status']=='matches']
 if not tests: continue
 p=Path(suite['binary-path']); t=s/(stage+'-bin')/p.name
 t.parent.mkdir(exist_ok=True)
 if len(sys.argv)<3 or sys.argv[2]!='hash-only': shutil.copy2(p,t)
 rows.append({'suite':name,'executed':str(p),'retained':str(t) if len(sys.argv)<3 or sys.argv[2]!='hash-only' else None,'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'bytes':p.stat().st_size,'tests':tests})
(s/(stage+'-binaries.json')).write_text(json.dumps(rows,indent=2)+'\n')
print(sum(len(r['tests']) for r in rows),'tests in',len(rows),'hashed binaries; source identities unchanged')

helpers={}
for name in ['deadpan-cli','deadpan-media-worker','deadpan-transcribe','deadpan-track']:
 p=Path('target/debug')/name
 if not p.exists(): continue
 t=s/(stage+'-helpers')/name
 t.parent.mkdir(exist_ok=True); shutil.copy2(p,t)
 digest=hashlib.sha256(p.read_bytes()).hexdigest()
 assert hashlib.sha256(t.read_bytes()).hexdigest()==digest
 helpers[name]={'path':str(p.resolve()),'retained':str(t),'sha256':digest,'bytes':p.stat().st_size}
(s/(stage+'-helper-binaries.json')).write_text(json.dumps(helpers,indent=2)+'\n')
print(len(helpers),'runtime helpers copied and pre-hashed')
