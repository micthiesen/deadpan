#!/bin/sh
set -eu
export DEADPAN_FFMPEG_PREFIX=/Users/michael/Library/Developer/Deadpan/ffmpeg-8.0.3-opus-1.6.1-dav1d-1.5.4-qualified-3/prefix
export CARGO_PROFILE_DEV_OPT_LEVEL=2
export DEADPAN_REQUIRE_PHYSICAL_MAC=1
export DEADPAN_REQUIRE_SYNTHETIC_WORKER=1
export DEADPAN_PREVIEW_EXPORT_KEEP=1
export DEADPAN_SELECTED_FIXED_RETIME_DURATION_RESULTS=/tmp/deadpan-selected-fixed-retime-duration-2026-10-22/second-real-media-results.json
s=/tmp/deadpan-selected-fixed-retime-duration-2026-10-22
cargo fmt --all > "$s/second-format.log" 2>&1
cargo check --locked -p deadpan-core -p deadpan-audio -p deadpan-store -p deadpan-app -p deadpan-cli --all-targets > "$s/second-check.log" 2>&1
python "$s/freeze.py" focused-second > "$s/focused-second-freeze.log"
filter=$(cat "$s/focused-filter.txt")
cargo nextest list --locked -p deadpan-core -p deadpan-plan -p deadpan-audio -p deadpan-store -p deadpan-app -p deadpan-cli -E "$filter" --message-format json > "$s/focused-second-list.json" 2> "$s/focused-second-build.log"
python "$s/identity.py" focused-second > "$s/focused-second-identity.log"
cargo nextest run --locked -p deadpan-core -p deadpan-plan -p deadpan-audio -p deadpan-store -p deadpan-app -p deadpan-cli -E "$filter" --no-fail-fast > "$s/focused-second.log" 2>&1
