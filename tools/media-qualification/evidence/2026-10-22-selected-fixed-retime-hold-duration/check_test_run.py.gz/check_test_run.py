from pathlib import Path
import json,re,sys
s=Path('/tmp/deadpan-selected-fixed-retime-duration-2026-10-22')
stage=sys.argv[1]
expected=sum(len(row['tests']) for row in json.loads((s/(stage+'-binaries.json')).read_text()))
text=re.sub(r'\x1b\[[0-9;]*m','',(s/(stage+'.log')).read_text())
assert re.search(rf'{expected} tests run: {expected} passed',text),text[-5000:]
print(stage,expected,'passed')
