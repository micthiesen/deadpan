#!/bin/sh
set -eu
export DEADPAN_FFMPEG_PREFIX=/Users/michael/Library/Developer/Deadpan/ffmpeg-8.0.3-opus-1.6.1-dav1d-1.5.4-qualified-3/prefix
export CARGO_PROFILE_DEV_OPT_LEVEL=2
export DEADPAN_REQUIRE_PHYSICAL_MAC=1
export DEADPAN_REQUIRE_SYNTHETIC_WORKER=1
s=/tmp/deadpan-selected-fixed-retime-duration-2026-10-22
filter='test(semantic) | test(macros) | test(scoped) | test(hold_duration) | test(retime) | test(completion) | test(registry) | test(owned_gap)'
cargo fmt --all -- --check > "$s/final-format.log" 2>&1
python "$s/freeze.py" app-final > "$s/app-freeze.log"
cargo nextest list --locked -p deadpan-core -p deadpan-plan -p deadpan-audio -p deadpan-store -p deadpan-app -p deadpan-cli -E "package(deadpan-app) & ($filter)" --message-format json > "$s/app-final-list.json" 2> "$s/app-final-list-build.log"
python "$s/identity.py" app-final hash-only > "$s/app-final-identity.log"
cargo nextest run --locked -p deadpan-core -p deadpan-plan -p deadpan-audio -p deadpan-store -p deadpan-app -p deadpan-cli --no-fail-fast -E "package(deadpan-app) & ($filter)" > "$s/app-final.log" 2>&1
python "$s/post.py" app-final > "$s/app-final-post.log"
python "$s/freeze.py" ui-lint-final > "$s/ui-lint-freeze.log"
cargo nextest list --locked -p deadpan-app --features ui-harness -E "$filter" --message-format json > "$s/ui-lint-final-list.json" 2> "$s/ui-lint-final-list-build.log"
python "$s/identity.py" ui-lint-final hash-only > "$s/ui-lint-final-identity.log"
cargo nextest run --locked -p deadpan-app --features ui-harness --no-fail-fast -E "$filter" > "$s/ui-lint-final.log" 2>&1
python "$s/post.py" ui-lint-final > "$s/ui-lint-final-post.log"
cargo xtask check --since c424c8732874e37b37c335962849ae6205d1d23e --no-test > "$s/lint.log" 2>&1
cargo clippy --locked -p deadpan-app --features ui-harness --all-targets -- -D warnings > "$s/ui-lint.log" 2>&1
cargo fmt --all -- --check > "$s/final-format.log" 2>&1
git diff --check > "$s/whitespace.log" 2>&1
