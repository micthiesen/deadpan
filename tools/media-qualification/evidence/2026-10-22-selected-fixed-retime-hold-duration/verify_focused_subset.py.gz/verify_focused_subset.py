from pathlib import Path
import json
s=Path('/tmp/deadpan-selected-fixed-retime-duration-2026-10-22')
def cases(stage):
 return {(r['suite'],t) for r in json.loads((s/(stage+'-binaries.json')).read_text()) for t in r['tests']}
focused=cases('focused-second'); broad=cases('regression-final')
missing=focused-broad
assert not missing,missing
result={'focused_cases':len(focused),'final_broad_cases':len(broad),'missing':[]}
(s/'focused-subset.json').write_text(json.dumps(result,indent=2)+'\n')
print(result)
