//! Public many-target isolation and raw duration controls for fixed windows.
//! Silent structural evidence only; this does not qualify audible phase.

use super::*;
use deadpan_core::{LeafEdit, ResolvedStep, ResolvedTransaction, ScopedTargetEdit};

fn select_both_inner_plays(document: ProjectDocument) -> State {
    let mut selected = state(document, "outer", 16);
    selected.switch_play_in(2).unwrap();
    assert!(selected.enter_in().unwrap()); // Outer second Play -> Inner
    selected.switch_plays_in(&[1, 2]).unwrap();
    assert!(selected.enter_in().unwrap()); // selected Inner Plays -> fixed Stage
    assert!(selected.enter_in().unwrap()); // fixed Stage -> Body Sequence
    selected.select_in(1).unwrap(); // Held in both selected Inner Plays
    selected
}

fn sampled_identity(
    plan: &deadpan_plan::RenderPlan,
    instance: &InstancePath,
    start: ExactRatio,
    end: ExactRatio,
) {
    let half = ExactRatio::new(1, 2).unwrap();
    let first = start.checked_sub(half).unwrap().ceil().unwrap();
    let terminal = end.checked_sub(half).unwrap().ceil().unwrap();
    assert!(first < terminal);
    for frame in [first, terminal.checked_sub(1).unwrap()] {
        assert!(
            plan.picture(ProjectFrame(i64::try_from(frame).unwrap()))
                .unwrap()
                .framing
                .iter()
                .any(|layer| &layer.instance == instance),
            "Hold identity at frame {frame}"
        );
    }
}

#[test]
fn native_selected_fixed_retime_hold_duration_offers_entry_after_public_many_control() {
    let before = nested_fixed_retime_fixture();
    before.validate().unwrap();
    assert_eq!(before.duration().unwrap().frames(), 42);
    assert!(before.overrides().is_empty());
    assert!(before.gap_overrides().is_empty());
    assert!(before.sounds().is_empty() && before.beat_sounds().is_empty());

    let before_selected = select_both_inner_plays(before.clone());
    let primary = before_selected.selected.clone();
    let also = before_selected.also_targets().unwrap();
    assert_eq!(also.len(), 1);
    let targets = [primary.clone(), also[0].clone()];
    assert_eq!(targets[0].node, node("held"));
    assert_eq!(targets[1].node, node("held"));
    assert_ne!(targets[0], targets[1]);
    for (inner, target) in targets.iter().enumerate() {
        assert_eq!(target.repeats.len(), 2);
        assert_eq!(target.repeats[0], branch(&before, "outer", Some(1)));
        assert_eq!(
            target.repeats[1],
            branch(&before, "inner", Some(u32::try_from(inner).unwrap()))
        );
        target.validate(&before).unwrap();
    }
    let held = [
        nested_instance(&before, "held", 1, 0),
        nested_instance(&before, "held", 1, 1),
    ];
    for (target, instance) in targets.iter().zip(&held) {
        assert!(target.matches_instance(&before, instance).unwrap());
    }
    assert_eq!(before_selected.cursor, ProjectFrame(16));
    assert_eq!(presentation(&before_selected).instance, held[0]);
    assert_eq!(presentation(&before_selected).frames, 16..18);
    assert_eq!(presentation(&before_selected).exact, ExactRatio::new(33, 2).unwrap()..ExactRatio::integer(18));

    // The public many-target Rename stages real isolation in request order.
    // Both targets address the same shared Hold initially, but different Plays.
    let edits = targets
        .iter()
        .enumerate()
        .map(|(index, target)| ScopedTargetEdit {
            target: target.clone(),
            edit: ScopedNodeEdit::Rename {
                label: format!("Selected fixed window isolation control {index}"),
            },
        })
        .collect::<Vec<_>>();
    let requirements = before.scoped_many_requirements(&edits).unwrap();
    assert_eq!(requirements.len(), 2);
    assert_eq!(
        requirements.iter().map(|need| (need.nodes, need.marks, need.unchanged)).collect::<Vec<_>>(),
        vec![(11, 0, false), (5, 0, false)]
    );
    let identities = requirements
        .iter()
        .enumerate()
        .map(|(member, need)| OccurrenceIdentities {
            nodes: (0..need.nodes)
                .map(|index| node(&format!("selected-fixed-control-{member}-{index}")))
                .collect(),
            marks: Vec::new(),
        })
        .collect();
    let isolation_request = CommandRequest {
        project_id: before.project_id().clone(),
        expected_revision: before.revision_id().clone(),
        new_revision: revision("selected-fixed-isolation-control"),
        command: Command::EditScopedMany { edits, identities },
    };
    let prepared = prepare_scoped_edit(&before, &isolation_request).unwrap();
    assert_eq!(prepared.transaction, apply(&before, &isolation_request).unwrap());
    assert_eq!(prepared.transaction.duration_delta, 0);
    assert_eq!(prepared.isolation().steps().len(), 3);
    let isolated = &prepared.document;
    assert_eq!(isolated.nodes().len(), before.nodes().len() + 16);
    assert_eq!(isolated.duration().unwrap().frames(), 42);
    let mapped_targets = targets
        .iter()
        .map(|target| prepared.map_target(&before, target).unwrap())
        .collect::<Vec<_>>();
    let mapped_held = held
        .iter()
        .map(|instance| prepared.map_instance(&before, instance).unwrap())
        .collect::<Vec<_>>();
    assert_eq!(prepared.target, mapped_targets[0]);
    assert_ne!(mapped_targets[0].node, mapped_targets[1].node);
    for (target, instance) in mapped_targets.iter().zip(&mapped_held) {
        assert!(target.matches_instance(isolated, instance).unwrap());
        assert_eq!(target.node, instance.node);
        assert_ne!(instance.node, node("held"));
    }

    // Apply ordinary raw duration reducers only after executed proof mapping.
    // This control does not invoke the selected duration policy under test.
    let resize_request = CommandRequest {
        project_id: isolated.project_id().clone(),
        expected_revision: isolated.revision_id().clone(),
        new_revision: revision("selected-fixed-duration-control"),
        command: Command::Compound {
            transaction: ResolvedTransaction::new(
                0,
                BTreeMap::new(),
                mapped_targets
                    .iter()
                    .enumerate()
                    .map(|(index, target)| ResolvedStep::Edit {
                        edit: LeafEdit::new(
                            revision(&format!("selected-fixed-duration-member-{index}")),
                            Command::SetHoldDuration {
                                node: target.node.clone(),
                                duration: frames(4),
                            },
                        ).unwrap(),
                    })
                    .collect(),
            ).unwrap(),
        },
    };
    let resized = apply(isolated, &resize_request).unwrap();
    assert_eq!(resized.duration_delta, 0);
    let after = resized.forward.apply(isolated).unwrap();
    after.validate().unwrap();
    assert_eq!(after.duration().unwrap().frames(), 42);
    assert_eq!(after.nodes().len(), isolated.nodes().len());
    assert_eq!(after.overrides(), isolated.overrides());
    assert_eq!(after.gap_overrides(), isolated.gap_overrides());
    for target in &mapped_targets {
        assert!(matches!(&after.nodes()[&target.node].kind,
            NodeKind::Hold { recipe } if recipe.duration == frames(4)));
    }

    let before_plan = deadpan_plan::RenderPlan::compile(&before).unwrap();
    let after_plan = deadpan_plan::RenderPlan::compile(&after).unwrap();
    for (inner, (old_start, old_end, new_end, sampled)) in [
        (ExactRatio::new(33, 2).unwrap(), ExactRatio::integer(18), ExactRatio::new(39, 2).unwrap(), 16..19),
        (ExactRatio::new(45, 2).unwrap(), ExactRatio::integer(24), ExactRatio::new(51, 2).unwrap(), 22..25),
    ].into_iter().enumerate() {
        let inner_play = u32::try_from(inner).unwrap();
        let original_stage = nested_instance(&before, "fixed-stage", 1, inner_play);
        let stage_instance = prepared.map_instance(&before, &original_stage).unwrap();
        let speech_instance = prepared.map_instance(&before, &nested_instance(&before, "speech", 1, inner_play)).unwrap();
        let mut body_target = targets[inner].clone();
        body_target.node = node("fixed-body");
        let mapped_body = prepared.map_target(&before, &body_target).unwrap().node;
        assert_eq!(exact_nested_boundary(&before, &held[inner], 0), old_start);
        assert_eq!(exact_nested_boundary(&before, &held[inner], 2), old_end);
        assert_eq!(exact_nested_boundary(&after, &mapped_held[inner], 0), old_start);
        assert_eq!(exact_nested_boundary(&after, &mapped_held[inner], 4), new_end);
        assert_eq!(exact_nested_boundary(&after, &speech_instance, 0), new_end);
        assert_eq!(exact_nested_boundary(&after, &stage_instance, 0), ExactRatio::integer(if inner == 0 { 15 } else { 21 }));
        let mut expected_stage = before.nodes()[&node("fixed-stage")].clone();
        let NodeKind::Retime { child, duration, mapping, pitch, purpose } = &mut expected_stage.kind else {
            panic!("fixed Edit Retime");
        };
        assert_eq!(*duration, frames(6));
        assert_eq!(*mapping, FrameRange::new(ProjectFrame(0), ProjectFrame(8)).unwrap());
        assert_eq!(*pitch, PitchPolicy::FollowSpeed);
        assert_eq!(*purpose, RetimePurpose::Edit);
        *child = mapped_body;
        assert_eq!(after.nodes()[&stage_instance.node], expected_stage);
        sampled_identity(&before_plan, &held[inner], old_start, old_end);
        sampled_identity(&after_plan, &mapped_held[inner], old_start, new_end);
        let half = ExactRatio::new(1, 2).unwrap();
        assert_eq!(u64::try_from(old_start.checked_sub(half).unwrap().ceil().unwrap()).unwrap()..u64::try_from(new_end.checked_sub(half).unwrap().ceil().unwrap()).unwrap(), sampled);
    }

    // All four other outer/inner occurrences keep the complete Hold recipe,
    // exact boundaries, and actual sampled picture identity.
    let mut unchanged_uses = 0;
    for outer in [0, 2] {
        for inner in 0..2 {
            unchanged_uses += 1;
            let original = nested_instance(&before, "held", outer, inner);
            let mapped = prepared.map_instance(&before, &original).unwrap();
            assert_eq!(after.nodes()[&mapped.node], before.nodes()[&original.node]);
            let start = exact_nested_boundary(&before, &original, 0);
            let end = exact_nested_boundary(&before, &original, 2);
            assert_eq!(exact_nested_boundary(&after, &mapped, 0), start);
            assert_eq!(exact_nested_boundary(&after, &mapped, 2), end);
            sampled_identity(&before_plan, &original, start, end);
            sampled_identity(&after_plan, &mapped, start, end);
        }
    }
    assert_eq!(unchanged_uses, 4);
    // Every picture outside the selected outer family remains identical,
    // including the complete lead/tail and both other outer families.
    for frame in (0..15).chain(27..42) {
        let mut expected = before_plan.picture(ProjectFrame(frame)).unwrap();
        let actual = after_plan.picture(ProjectFrame(frame)).unwrap();
        // Revisions and diagnostic traversal work are not picture semantics.
        expected.revision_id = actual.revision_id.clone();
        expected.lookup = actual.lookup.clone();
        assert_eq!(expected, actual);
    }
    for (id, beat) in before.nodes() {
        assert_eq!(&after.nodes()[id], beat);
    }
    let isolated_selected = select_both_inner_plays(isolated.clone());
    assert_eq!(isolated_selected.selected, mapped_targets[0]);
    assert_eq!(isolated_selected.also_targets().unwrap(), mapped_targets[1..]);
    assert_eq!(presentation(&isolated_selected).frames, 16..18);
    let after_selected = select_both_inner_plays(after.clone());
    assert_eq!(after_selected.selected, mapped_targets[0]);
    assert_eq!(after_selected.also_targets().unwrap(), mapped_targets[1..]);
    assert_eq!(after_selected.cursor, ProjectFrame(16));
    assert_eq!(presentation(&after_selected).instance, mapped_held[0]);
    assert_eq!(presentation(&after_selected).frames, 16..19);
    assert_eq!(presentation(&after_selected).exact, ExactRatio::new(33, 2).unwrap()..ExactRatio::new(39, 2).unwrap());

    assert_eq!(resized.inverse.apply(&after).unwrap(), *isolated);
    assert_eq!(prepared.transaction.inverse.apply(isolated).unwrap(), before);
    for document in [&before, isolated, &after] {
        assert_eq!(ProjectDocument::from_json(&document.to_json().unwrap()).unwrap(), *document);
    }
    assert_eq!(*before_selected.index.document, before);
    assert_eq!(before_selected.selected, primary);
    assert_eq!(before_selected.also_targets().unwrap(), also);
    assert_eq!(presentation(&before_selected).instance, held[0]);

    // Sole intended old-code failure, after every independent public control.
    assert!(
        before_selected.hold_duration_available(),
        "Both selected Inner Plays in Outer second Play must offer Change duration inside their fixed Edit Retime windows"
    );
}
