from pathlib import Path
import json,sys
s=Path('/tmp/deadpan-selected-fixed-retime-duration-2026-10-22')
rows=json.loads((s/sys.argv[1]).read_text())
windows=[(r,w) for r in rows for w in r['report']['audio']]
minimum=min(r['report']['summary']['min_block_snr_db'] for r in rows)
result={'cases':len(rows),'pictures':sum(r['report']['summary']['pictures_checked'] for r in rows),'windows':len(windows),
'presented_samples':sum(w['project_samples'][1]-w['project_samples'][0] for _,w in windows),
'failed_pictures':sum(r['report']['summary']['pictures_failed'] for r in rows),
'failed_windows':sum(r['report']['summary']['audio_windows_failed'] for r in rows),
'nonzero_offsets':sum(r['report']['summary']['nonzero_offsets'] for r in rows),
'offset_unobservable_windows':sum(r['report']['summary']['offset_unobservable_windows'] for r in rows),
'observable_neighbors':sum(r['report']['summary']['index_observable_comparisons'] for r in rows),
'unobservable_neighbors':sum(r['report']['summary']['index_unobservable_comparisons'] for r in rows),
'minimum_block_snr_db':minimum,'low_snr_blocks':sum(w['blocks']['low_snr_blocks'] for _,w in windows),
'uncovered_samples':sum(w['uncovered_samples'] for _,w in windows),
'lowest_block_details':[{'selection':r['selection'],'case':Path(r['package']).parent.name,'movie':Path(r['movie']).name,
'minimum_block_snr_db':w['blocks']['min_snr_db'],'minimum_block_start':w['blocks']['min_snr_block_start'],'window_snr_db':w['snr_db'],'flags':w['flags']}
for r,w in windows if w['blocks']['min_snr_db']==minimum],
'thresholds':rows[0]['report']['thresholds'],
'qualification_limit':'No listening or full mastering qualification. Retain local block and complete-window SNR separately.'}
assert len(rows)==16
assert all(r['report']['passed'] for r in rows)
assert all(w['offset_status']=='verified_zero' and w['measured_offset_samples']==0 and not w['flags'] and w['uncovered_samples']==0 and w['blocks']['low_snr_blocks']==0 for _,w in windows)
(s/sys.argv[2]).write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
