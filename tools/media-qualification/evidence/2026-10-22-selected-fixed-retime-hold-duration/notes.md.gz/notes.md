# Selected fixed-Retime old-code witness draft

Draft only. No Cargo, rustfmt, Git, compiler, test, replay, or other runtime execution was performed. Repository files were read only. This is not measured evidence and the predicted counts remain assertions to verify.

Install `draft-baseline.rs` as a direct child module of the existing `crates/deadpan-app/src/preview/scoped/model/tests/nested_fixed_retime_duration.rs`; for example, a neighboring `selected_fixed_retime_duration.rs` file registered with a `#[path = "selected_fixed_retime_duration.rs"] mod selected_fixed_retime_duration;` declaration. `use super::*` relies on that exact placement to reuse the existing silent fixture and its private helpers. No production changes are included.

The single test navigates via existing private native State test APIs: Outer Play 2, enter Inner, `switch_plays_in(&[1, 2])`, enter fixed Stage and Body, select Held. It captures both actual authoring targets with `also_targets()`, preserving their shared initial Hold ID and distinct explicit Inner Play identities. The initial retained representative is Outer second / Inner first at cursor 16.

The isolation control uses public `scoped_many_requirements` and `Command::EditScopedMany` with two Rename edits, allocating the identities returned by the query. It asserts the source-derived expected staged pools `(11, 0)` and `(5, 0)`, total 16 nodes, and three actual proof steps. It runs `prepare_scoped_edit`, compares its transaction with ordinary public `apply`, and maps both shared authoring targets and both concrete instances through the complete executed proof. No clone names or proof maps are invented.

Only then does a raw `Command::Compound` execute ordinary `SetHoldDuration` leaves on both mapped Hold nodes, 2 to 4 authored frames. Its exact expected controls are:

- Primary `[33/2, 18)` to `[33/2, 39/2)`, sampled `[16, 18)` to `[16, 19)`.
- Second `[45/2, 24)` to `[45/2, 51/2)`, sampled `[22, 24)` to `[22, 25)`.
- Both mapped Edit Retime stages retain their original six output frames, input crop `[0, 8)`, FollowSpeed policy, Edit purpose, and mapped Body child.
- All four other outer/inner occurrences retain their full Hold node and exact boundaries. Actual RenderPlan framing identity is checked at first and last sampled frames for both chosen and all unselected Holds, before and after.
- All pictures in `[0, 15)` and `[27, 42)` are compared across the complete `PictureSample` after excluding only committed revision identity and diagnostic lookup-work counters. Project identity, instance, all framing, picture data, clocks, captions, and geometry remain compared.
- The original authored definitions remain unchanged, project duration stays 42, override maps stay fixed across raw duration changes, native re-navigation retains both mapped selected targets and the expected primary presentation, both inverses and all document JSON round trips pass.

The only positive `hold_duration_available()` assertion is the last assertion after every control. Current selected policy rejects the fixed Retime ancestor, so this last assertion is expected to fail on old code. That remains a prediction until root installs, compiles, freezes, hashes, and runs the draft.

Review caveats before installation: `Presentation.frames` uses `Range<u64>`; the explicit sampled range assertions use checked conversions from the exact i128 ceiling. `PictureSample` equality includes revision and diagnostics, so the comparison intentionally replaces those two non-product fields only. The fixture is silent Background/Silence structural evidence; it makes no audible phase, encoded output, or native rendering claim. The existing second Inner Play is unowned initially; separate already-owned, no-op, refusal, staged-loss, sound, and additional selected-axis coverage belongs in implementation tests after this baseline witness.
