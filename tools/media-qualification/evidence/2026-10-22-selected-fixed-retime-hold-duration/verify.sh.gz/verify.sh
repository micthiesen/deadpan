#!/bin/sh
set -eu
export DEADPAN_FFMPEG_PREFIX=/Users/michael/Library/Developer/Deadpan/ffmpeg-8.0.3-opus-1.6.1-dav1d-1.5.4-qualified-3/prefix
export CARGO_PROFILE_DEV_OPT_LEVEL=2
export DEADPAN_REQUIRE_PHYSICAL_MAC=1
export DEADPAN_REQUIRE_SYNTHETIC_WORKER=1
s=/tmp/deadpan-selected-fixed-retime-duration-2026-10-22
python "$s/check_test_run.py" focused-second
cargo fmt --all > "$s/final-candidate-format.log" 2>&1
cargo check --locked -p deadpan-app --features ui-harness --all-targets > "$s/ui-check.log" 2>&1
python "$s/freeze.py" regression-final > "$s/regression-final-freeze.log"
cargo build --locked -p deadpan-app --features ui-harness --bin deadpan-app > "$s/dev-native-build.log" 2>&1
python "$s/guard.py" regression-final > "$s/pre-debug-source-guard.log"
python "$s/debug_identity.py" > "$s/debug-identity.log"
"$s/debug-bin/deadpan-app" --ui-check --scenario selected-fixed-duration --mode visual --output "$s/debug-visual" --kestrel-source /Users/michael/.dotfiles/kestrel/Sources/Kestrel/Shortcuts.swift > "$s/debug-visual.log" 2>&1
filter='test(semantic) | test(macros) | test(scoped) | test(hold_duration) | test(retime) | test(completion) | test(registry) | test(owned_gap)'
normal="package(deadpan-core) | package(deadpan-plan) | package(deadpan-audio) | package(deadpan-store) | $filter"
cargo nextest list --locked -p deadpan-core -p deadpan-plan -p deadpan-audio -p deadpan-store -p deadpan-app -p deadpan-cli -E "$normal" --message-format json > "$s/regression-final-list.json" 2> "$s/regression-final-list-build.log"
python "$s/identity.py" regression-final hash-only > "$s/regression-final-identity.log"
cargo nextest run --locked -p deadpan-core -p deadpan-plan -p deadpan-audio -p deadpan-store -p deadpan-app -p deadpan-cli --no-fail-fast -E "$normal" > "$s/regression-final.log" 2>&1
python "$s/post.py" regression-final > "$s/regression-final-post.log"
python "$s/freeze.py" ui-final > "$s/ui-freeze.log"
cargo nextest list --locked -p deadpan-app --features ui-harness -E "$filter" --message-format json > "$s/ui-final-list.json" 2> "$s/ui-final-list-build.log"
python "$s/identity.py" ui-final hash-only > "$s/ui-final-identity.log"
cargo nextest run --locked -p deadpan-app --features ui-harness --no-fail-fast -E "$filter" > "$s/ui-final.log" 2>&1
python "$s/post.py" ui-final > "$s/ui-final-post.log"
cargo xtask check --since c424c8732874e37b37c335962849ae6205d1d23e --no-test > "$s/lint.log" 2>&1
cargo clippy --locked -p deadpan-app --features ui-harness --all-targets -- -D warnings > "$s/ui-lint.log" 2>&1
cargo fmt --all -- --check > "$s/final-format.log" 2>&1
git diff --check > "$s/whitespace.log" 2>&1
