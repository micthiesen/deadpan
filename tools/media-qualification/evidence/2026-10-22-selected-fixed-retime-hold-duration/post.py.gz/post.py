from pathlib import Path
import hashlib,json,subprocess,sys
s=Path('/tmp/deadpan-selected-fixed-retime-duration-2026-10-22')
stage=sys.argv[1]
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
sources=json.loads((s/(stage+'-source-identities.json')).read_text())
assert set(sources)==set(subprocess.check_output(['rg','--files','-g','*.rs'],text=True).splitlines())
for name,digest in sources.items(): assert sha(Path(name))==digest,name
binaries=json.loads((s/(stage+'-binaries.json')).read_text())
for row in binaries: assert sha(Path(row['executed']))==row['sha256'],row['executed']
helpers=json.loads((s/(stage+'-helper-binaries.json')).read_text())
for row in helpers.values(): assert sha(Path(row['path']))==row['sha256'],row['path']
lock=sha(Path('Cargo.lock'))
assert lock=='1e39d18ae4de6c7b898edad39eb7104235fb3ffe3af84521ca94df2b6c25b71b',lock
result={'stage':stage,'rust_files':len(sources),'test_binaries':len(binaries),'tests':sum(len(row['tests']) for row in binaries),'helpers':len(helpers),'all_pre_post_hashes_identical':True,'root_lock_sha256':lock}
(s/(stage+'-post.json')).write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result))
