from pathlib import Path
p=Path('docs/REQUIREMENTS.md')
t=p.read_text()
lines=t.splitlines()
for i,line in enumerate(lines):
 if line.startswith('| DP-06 |'):
  anchor='[Owned-gap Hold lengths](qualification/owned-gap-hold-duration-semantics-2026-10-22.md)'
  addition='[Selected fixed-Retime lengths](qualification/selected-fixed-retime-hold-duration-2026-10-22.md) extend either selected axis through one unclocked fixed window, retaining literal other-level choices, staged counterparts, cropped continuation and duration-only macro intent. '
  assert line.count(anchor)==1
  lines[i]=line.replace(anchor,addition+anchor)
 if line.startswith('| DP-07 |'):
  anchor='[Owned-gap lengths](qualification/owned-gap-hold-duration-semantics-2026-10-22.md)'
  addition='[Selected fixed-Retime lengths](qualification/selected-fixed-retime-hold-duration-2026-10-22.md) preserve physical phase and accepted-provider history at fixed extent, including Undo closure of clone-born intents; sixteen release exports verify 1,312 pictures and 2,101,304 presented samples at zero offset. '
  assert line.count(anchor)==1
  lines[i]=line.replace(anchor,addition+anchor)
t='\n'.join(lines)+'\n'
header='| Area | What remains for the owner | Related |\n| --- | --- | --- |\n'
assert t.count(header)==1
row='| Selected-play Hold lengths through one fixed Retime: physical keys, speech and listening | 1. Extract each 91f unit-growth archive into its own folder: [inner selected under All plays](../tools/media-qualification/evidence/2026-10-22-selected-fixed-retime-hold-duration/inner-default-unit-grow.deadpan.tar.gz), [inner selected under This play](../tools/media-qualification/evidence/2026-10-22-selected-fixed-retime-hold-duration/inner-play-unit-grow.deadpan.tar.gz), [outer selected with inner All plays](../tools/media-qualification/evidence/2026-10-22-selected-fixed-retime-hold-duration/outer-default-unit-grow.deadpan.tar.gz), and [outer selected with inner This play](../tools/media-qualification/evidence/2026-10-22-selected-fixed-retime-hold-duration/outer-play-unit-grow.deadpan.tar.gz). 2. Open each package and enter its outer Repeat. For the inner-selected cases choose outer `:scope all` or `:scope play 2`, then inner `:scope plays 1,2`. For outer-selected cases choose outer `:scope plays 1,2`, then inner `:scope all` or `:scope play 2`. Enter the fixed stage/body and select the frozen Hold. Physical Enter must prefill `hold-duration 5f`, with both scopes and the selected-play explanation readable. Set `3f`: output stays 91f, the selected families change and all other Holds keep 3f. One Undo restores the selected 5f Holds; Redo restores 3f. Check physical Enter/Escape, focus, breadcrumb and VoiceOver speech, and exercise recording/Run/dot after explicitly reselecting the pair. 3. Listen across changed and unchanged families and compare exports. Also inspect the [73f affine fixture](../tools/media-qualification/evidence/2026-10-22-selected-fixed-retime-hold-duration/inner-default-affine-grow.deadpan.tar.gz) and [its encoded file](../tools/media-qualification/evidence/2026-10-22-selected-fixed-retime-hold-duration/encoded-inner-default-affine-grow.mp4), especially 2.20 to 2.35 seconds around the retained 12.008dB local-block SNR minimum. Local routing, exact PCM, history and emitted files are qualified; physical delivery, speech and acoustic judgement remain unverified. | [Selected fixed-Retime qualification](qualification/selected-fixed-retime-hold-duration-2026-10-22.md), DP-06, DP-07, DP-20 |\n'
p.write_text(t.replace(header,header+row))
