from pathlib import Path
import hashlib,json,shutil
s=Path('/tmp/deadpan-selected-fixed-retime-duration-2026-10-22')
rows={}
for name in ['deadpan-app','deadpan-media-worker','deadpan-transcribe','deadpan-track']:
 p=Path('target/debug')/name
 t=s/'debug-bin'/name
 t.parent.mkdir(exist_ok=True); shutil.copy2(p,t)
 digest=hashlib.sha256(p.read_bytes()).hexdigest()
 assert hashlib.sha256(t.read_bytes()).hexdigest()==digest
 rows[name]={'source':str(p),'executed':str(t),'sha256':digest}
(s/'debug-binaries.json').write_text(json.dumps(rows,indent=2)+'\n')
print('Four debug executables copied and hashed')
