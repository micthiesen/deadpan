from pathlib import Path
import json,subprocess
s=Path(__file__).parent
paths=json.loads((s/'owned-code-paths.json').read_text())
for root in ['/Users/michael/Code/deadpan','/tmp/deadpan-query-groundwork-2026-10-26/scoped']:
 subprocess.run(['rustfmt','--edition','2024',*[str(Path(root)/p) for p in paths]],check=True)
for name in ['run_qualified.py','run_scoped_qualified.py']:
 p=s/name
 text=p.read_text()
 old="        'DEADPAN_INTERNAL_MASK_AFTER_OUTPUT', 'DEADPAN_INTERNAL_MASK_AFTER_VARIANT',"
 assert text.count(old)==1
 p.write_text(text.replace(old,"        'DEADPAN_QUERY_INTERVAL_AFTER_OUTPUT', 'DEADPAN_QUERY_INTERVAL_AFTER_VARIANT',\n        'DEADPAN_QUERY_INTERVAL_AFTER_SOURCE_SHA256', 'DEADPAN_QUERY_INTERVAL_AFTER_PUBLISHED_CHECKPOINT',\n"+old))
