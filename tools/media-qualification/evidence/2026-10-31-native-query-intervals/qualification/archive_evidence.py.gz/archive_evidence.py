from pathlib import Path
import gzip,hashlib,json
s=Path(__file__).resolve().parent
root=Path('/Users/michael/Code/deadpan');scope=Path('/tmp/deadpan-query-groundwork-2026-10-26/scoped')
out=root/'tools/media-qualification/evidence/2026-10-31-native-query-intervals'
assert not out.exists()
allowed={'.json','.md','.txt','.py','.patch','.rs','.stdout','.stderr'}
files={}
excluded={'archive-proof.json','qualification-draft.md','publication-proof.json','index-publication-audit.json','publication-inputs.json','publication-sources.txt','publication-index-info.txt','publication-blobs.txt','next-handoff-ripwire.txt'}
for p in sorted(s.rglob('*')):
 if not p.is_file() or p.suffix not in allowed or '__pycache__' in p.parts:continue
 rel=p.relative_to(s)
 if rel.parts[:2]==('before','main') or p.name in excluded:continue
 files['qualification/'+str(rel)]=p.read_bytes()
for name in ['native-query-interval-review','native-query-interval-capture-review']:
 p=Path('/tmp')/(f'deadpan-{name}-2026-10-31.md')
 assert p.exists(),p
 files['independent-review/'+p.name]=p.read_bytes()
for directory in [
 '/tmp/deadpan-native-query-interval-trace-candidate-2026-10-31',
 '/tmp/deadpan-native-query-interval-trace-tests-candidate-2026-10-31',
 '/tmp/deadpan-native-query-interval-native-tests-candidate-2026-10-31']:
 d=Path(directory)
 for p in sorted(d.iterdir()):
  if p.is_file() and p.suffix in allowed:
   files['proposal/'+d.name+'/'+p.name]=p.read_bytes()
for rel in json.loads((s/'owned-code-paths.json').read_text()):
 files['shipping-source/'+rel]=(scope/rel).read_bytes()
rows=[]
for key,data in sorted(files.items()):
 zipped=gzip.compress(data,compresslevel=9,mtime=0);dest=out/(key+'.gz')
 dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(zipped);assert gzip.decompress(dest.read_bytes())==data
 rows.append({'path':key,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest(),'stored_path':key+'.gz','stored_bytes':len(zipped),'stored_sha256':hashlib.sha256(zipped).hexdigest()})
body={'schema':'deadpan-qualified-gzip-evidence-v1','scope':'test-only additive native/raw Point query intervals; actual both-lane native tests, immutable prior complete body, 744+10+4 observed bodies and literal partial prefix; no policy/preparation admission or new product acceptance','base_revision':(s/'base-revision.txt').read_text().strip(),'records':rows,'expanded_bytes':sum(r['bytes']for r in rows),'stored_bytes':sum(r['stored_bytes']for r in rows),'excluded':'pinned executable copies; full Main before snapshots containing unowned WIP; future Signal policy handoff proposals not integrated in this checkpoint'}
b=(json.dumps(body,indent=2)+'\n').encode();(out/'inventory.json').write_bytes(b)
proof={'inventory_path':str((out/'inventory.json').relative_to(root)),'inventory_sha256':hashlib.sha256(b).hexdigest(),'records':len(rows),'expanded_bytes':body['expanded_bytes'],'stored_bytes':body['stored_bytes']}
(s/'archive-proof.json').write_text(json.dumps(proof,indent=2)+'\n');print(json.dumps(proof))
