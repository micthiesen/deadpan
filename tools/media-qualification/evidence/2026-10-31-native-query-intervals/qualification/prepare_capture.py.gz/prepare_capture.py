from pathlib import Path
import difflib,json
root=Path('/Users/michael/Code/deadpan')
s=Path(__file__).parent
files={}
def edit(rel,old,new):
 text=files.get(rel,(root/rel).read_text())
 assert text.count(old)==1,(rel,old)
 files[rel]=text.replace(old,new,1)
base='crates/deadpan-audio/src/bound_reads/'
rel=base+'native_mask_after.rs'
edit(rel,'    static CAPTURING: Cell<bool> = const { Cell::new(false) };','    static CAPTURING: Cell<bool> = const { Cell::new(false) };\n    static INTERVALS: Cell<bool> = const { Cell::new(false) };')
edit(rel,'        point_suppression::ops::trace::disable();\n        CAPTURING.set(false);','        if INTERVALS.replace(false) {\n            crate::stages::native_query_interval_trace::disable();\n        }\n        point_suppression::ops::trace::disable();\n        CAPTURING.set(false);')
edit(rel,'        point_suppression::ops::trace::reset();','        point_suppression::ops::trace::reset();\n        if INTERVALS.get() {\n            crate::stages::native_query_interval_trace::reset();\n        }')
edit(rel,'#[test]\n#[ignore = "manual current internal mask qualification; fresh /tmp and pinned sources"]\nfn capture_active_internal_mask_after_v1() {\n    let output = std::env::var("DEADPAN_INTERNAL_MASK_AFTER_OUTPUT").expect("fresh output path");','''pub(super) fn interval_receipt_if_capturing() -> Option<Value> {
    INTERVALS.get().then(|| {
        serde_json::to_value(crate::stages::native_query_interval_trace::snapshot()).unwrap()
    })
}

#[test]
#[ignore = "manual current internal mask qualification; fresh /tmp and pinned sources"]
fn capture_active_internal_mask_after_v1() {
    capture_after("DEADPAN_INTERNAL_MASK_AFTER", false);
}

#[test]
#[ignore = "manual additive query intervals; fresh /tmp and pinned sources"]
fn capture_active_query_intervals_v1() {
    capture_after("DEADPAN_QUERY_INTERVAL_AFTER", true);
}

fn capture_after(prefix: &str, intervals: bool) {
    let output = std::env::var(format!("{prefix}_OUTPUT")).expect("fresh output path");''')
edit(rel,'std::env::var("DEADPAN_INTERNAL_MASK_AFTER_VARIANT")','std::env::var(format!("{prefix}_VARIANT"))')
edit(rel,'std::env::var("DEADPAN_INTERNAL_MASK_AFTER_SOURCE_SHA256")','std::env::var(format!("{prefix}_SOURCE_SHA256"))')
edit(rel,'std::env::var("DEADPAN_INTERNAL_MASK_AFTER_PUBLISHED_CHECKPOINT").unwrap(),\n        CHECKPOINT','std::env::var(format!("{prefix}_PUBLISHED_CHECKPOINT")).unwrap(),\n        if intervals {\n            "ab211a2f132379a246157c3596d95fc42121541c"\n        } else {\n            CHECKPOINT\n        }')
edit(rel,'    let _capture = Capture::new();','    let _capture = Capture::new();\n    INTERVALS.set(intervals);')
edit(rel,'    let internal = super::super::internal_suppression_baseline::current_owned_mask_observations();\n    let value = json!({','    let internal = super::super::internal_suppression_baseline::current_owned_mask_observations_with_intervals(intervals);\n    let mut value = json!({')
edit(rel,'    let file = OpenOptions::new()','''    if intervals {
        value["schema"] = json!("active-query-interval-after-v1");
        value["observer_checkpoint"] = json!("ab211a2f132379a246157c3596d95fc42121541c");
        value["scope"] = json!(
            "Additive actual raw/Point query intervals with literal completion claims and independent native/host boundaries. Parent rows include child rows and cannot be summed. Partial intervals have no invented query debit. Old receipts and invalid flags remain literal; no whole preparation ownership claim."
        );
    }
    let file = OpenOptions::new()''')
rel=base+'retained_host_pairs.rs'
edit(rel,'    if let Some(mask) = native_mask_after::receipt_if_capturing() {\n        value["native_mask_work"] = mask;\n    }','    if let Some(mask) = native_mask_after::receipt_if_capturing() {\n        value["native_mask_work"] = mask;\n    }\n    if let Some(intervals) = native_mask_after::interval_receipt_if_capturing() {\n        value["native_query_intervals"] = intervals;\n    }')
rel=base+'internal_suppression_baseline.rs'
edit(rel,'pub(super) fn current_owned_mask_observations() -> Value {','pub(super) fn current_owned_mask_observations_with_intervals(intervals: bool) -> Value {')
edit(rel,'        point_suppression::ops::trace::reset();\n        let mut row = case_internal(case);','        point_suppression::ops::trace::reset();\n        if intervals {\n            crate::stages::native_query_interval_trace::reset();\n        }\n        let mut row = case_internal(case);')
edit(rel,'        point_suppression::ops::trace::disable();\n        row["scope"]["internal_masks"]','        if intervals {\n            row["native_query_intervals_whole_case"] = serde_json::to_value(\n                crate::stages::native_query_interval_trace::snapshot(),\n            ).unwrap();\n            crate::stages::native_query_interval_trace::disable();\n        }\n        point_suppression::ops::trace::disable();\n        row["scope"]["internal_masks"]')
edit(rel,'transfer_entries::current_owned_transfer_observations()','transfer_entries::current_owned_transfer_observations(intervals)')
rel=base+'internal_transfer_entries.rs'
edit(rel,'pub(super) fn current_owned_transfer_observations() -> Value {','pub(super) fn current_owned_transfer_observations(intervals: bool) -> Value {')
edit(rel,'        point_suppression::ops::trace::reset();\n        let mut row = case(entry, anchor, name);','        point_suppression::ops::trace::reset();\n        if intervals {\n            crate::stages::native_query_interval_trace::reset();\n        }\n        let mut row = case(entry, anchor, name);')
edit(rel,'        point_suppression::ops::trace::disable();\n        row\n','        if intervals {\n            row["native_query_intervals_whole_case"] = serde_json::to_value(\n                crate::stages::native_query_interval_trace::snapshot(),\n            ).unwrap();\n            crate::stages::native_query_interval_trace::disable();\n        }\n        point_suppression::ops::trace::disable();\n        row\n')
for rel,new in files.items():
 old=(root/rel).read_text()
 diff=''.join(list(difflib.unified_diff(old.splitlines(True),new.splitlines(True),n=3))[2:])
 (s/('capture-'+Path(rel).name+'.patch')).write_text('*** Begin Patch\n*** Update File: ROOT/'+rel+'\n'+diff+'*** End Patch\n')
p=s/'owned-code-paths.json'
p.write_text(json.dumps(sorted(set(json.loads(p.read_text()))|set(files)),indent=2)+'\n')
