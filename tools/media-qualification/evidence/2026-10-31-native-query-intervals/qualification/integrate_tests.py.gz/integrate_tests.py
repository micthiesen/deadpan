from pathlib import Path
import json
roots=[Path('/Users/michael/Code/deadpan'),Path('/tmp/deadpan-query-groundwork-2026-10-26/scoped')]
s=Path(__file__).parent
tests=Path('/tmp/deadpan-native-query-interval-trace-tests-candidate-2026-10-31')
mapping={
 'crates/deadpan-audio/src/native_query_interval_trace_tests.rs':tests/'native_query_interval_trace_tests.rs',
 'crates/deadpan-audio/src/point_suppression/ops_trace_epoch_tests.rs':tests/'ops_trace_epoch_tests.rs',
 'crates/deadpan-audio/src/original_request/host_epoch_tests.rs':tests/'host_epoch_tests.rs',
 'crates/deadpan-audio/src/bound_reads/native_query_interval_tests.rs':Path('/tmp/deadpan-native-query-interval-native-tests-candidate-2026-10-31/native_query_interval_tests.rs'),
}
for root in roots:
 for rel,source in mapping.items():
  dest=root/rel
  assert not dest.exists()
  dest.write_bytes(source.read_bytes())
owned=set(json.loads((s/'owned-code-paths.json').read_text()))|set(mapping)
(s/'owned-code-paths.json').write_text(json.dumps(sorted(owned),indent=2)+'\n')
for name in ['source-files.json','scoped-source-files.json']:
 p=s/name
 p.write_text(json.dumps(sorted(set(json.loads(p.read_text()))|set(mapping)),indent=2)+'\n')
