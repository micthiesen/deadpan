from pathlib import Path
from collections import Counter
import hashlib,json,copy
s=Path(__file__).parent
phase_order=['account','scan','map','zero','mark','allocate_vector','allocate_storage','host_residency']
counts=Counter();hist=Counter();partial=[];mismatches=[];nested=[]
def visit(value,path=''):
 if isinstance(value,dict):
  if value.get('schema')=='native-mask-query-intervals-v1':
   counts['snapshots']+=1
   assert value['active_intervals']==value['dropped_intervals']==0,path
   assert not value['misnested'] and not value['overflow'],path
   assert value['phase_order']==phase_order
   hist[str(len(value['rows']))]+=1
   if value['nested']:nested.append(path)
   for r in value['rows']:
    counts['rows']+=1;counts[r['kind']]+=1
    assert r['attributable'] and not r['foreign_work_overlap'],(path,r)
    assert r['native_before']['enabled'] and r['native_after']['enabled']
    for prefix in ['native','host']:
     a=r[prefix+'_before'];b=r[prefix+'_after']
     assert a['reset_epoch'] is not None and a['reset_epoch']==b['reset_epoch'] and not a['overflow'] and not b['overflow']
    claim=r['claim']
    if claim is None:
     counts['partial_rows']+=1
     partial.append({'path':path,'row':r})
     continue
    counts['completed_rows']+=1
    assert claim['total']==claim['canonical']+claim['additional']
    for lane in range(2):
     native=[b-a for a,b in zip(r['native_before']['lanes'][lane],r['native_after']['lanes'][lane])]
     host=r['host_after']['units'][lane]-r['host_before']['units'][lane]
     observed=r['work_after'][lane]-r['work_before'][lane]
     assert min(native)>=0 and host>=0 and observed>=0
     explicit=(claim['expected_debit'] if lane==r['selected_lane'] else 0)+sum(native)+host
     if explicit!=observed:mismatches.append({'path':path,'lane':lane,'observed':observed,'explicit':explicit,'row':r})
     if native[-1]:counts['completed_lanes_with_residency']+=1
     if host:counts['completed_lanes_with_host_eviction']+=1
  else:
   for key,item in value.items():visit(item,path+'/'+key)
 elif isinstance(value,list):
  for i,item in enumerate(value):visit(item,path+'/'+str(i))
def strip(value):
 if isinstance(value,dict):
  return {k:strip(v) for k,v in value.items() if k not in ['native_query_intervals','native_query_intervals_whole_case','observer_checkpoint']}
 if isinstance(value,list):return [strip(v) for v in value]
 return value
pairs={}
for variant in ['main','scoped']:
 old=(s/f'interval-off-{variant}-canonical.json').read_bytes()
 assert hashlib.sha256(old).hexdigest()=='af7a292718365c34fa03692e2cbe58a2cfb3c6d444b5ae29d52647e1fdbbff14'
 raw=(s/f'interval-on-{variant}-canonical.json').read_bytes()
 pairs[variant]={'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}
 new=json.loads(raw)
 if variant=='scoped':visit(new)
 reverted=strip(new)
 expected=json.loads(old)
 reverted['schema']=expected['schema'];reverted['scope']=expected['scope']
 assert reverted==expected,variant
assert pairs['main']==pairs['scoped']
proof={'schema':'deadpan-native-query-interval-qualification-v1','old_body_bytes':34885733,'old_body_sha256':'af7a292718365c34fa03692e2cbe58a2cfb3c6d444b5ae29d52647e1fdbbff14','old_body_exact_after_removing_only_additive_fields':True,'new_bodies':pairs,'counts':counts,'rows_per_snapshot':hist,'inclusive_nested_snapshot_paths':nested,'partial_rows':partial,'completed_equation_mismatches':mismatches,'limits':'Both lanes independently reconciled from literal completion expected_debit plus independent native phase and host eviction deltas; parent/child rows never summed. Partial rows retain boundaries without a successful query fee claim.'}
(s/'capture-analysis.json').write_text(json.dumps(proof,indent=2)+'\n')
print(json.dumps({k:v for k,v in proof.items() if k not in ['partial_rows','inclusive_nested_snapshot_paths','limits','completed_equation_mismatches']}))
print(json.dumps({'nested_snapshots':len(nested),'partials':len(partial),'mismatches':len(mismatches)}))
assert not mismatches
