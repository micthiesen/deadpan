# Native query interval observer review

Reviewed read-only at `/Users/michael/Code/deadpan`, 2026-10-31. No builds, native execution, or Git operations.

## Findings

No material implementation defect found in the bounded observer or accepted-work hooks.

One interpretation constraint: `Row.attributable` is a local interval result, not a complete-capture verdict. `native_query_interval_trace.rs:264-300` computes it from that guard's LIFO closure, its own `ReadWork` identity, monotonic counters, enabled/reset epochs, and boundary overflow flags. Capture-wide `misnested` and interval `overflow` are tracked separately. Thus a row can remain locally attributable when a different row was dropped at the bound, and the still-open child after a non-LIFO outer close can be locally attributable even though `Snapshot.misnested` is true. Consumers must gate analysis on `active_intervals == 0`, `misnested == false`, `overflow == false`, and `dropped_intervals == 0` before trusting a set of rows. The actual integration helper `native_query_interval_tests.rs:64-76` does this in `complete()` before its row assertions. Candidate bookkeeping tests exercise these structural flags. This is already represented in the schema; no code change is required unless row-level standalone interpretation is intended.

## Evidence

- `ScopeGuard::new` caps active rows at 16 and retained rows at 128 (`native_query_interval_trace.rs:8-9, 168-183`); `reset` reserves exactly those bounded capacities, and scope creation records dropped/overflow rather than allocating past them (`:92-113, 177-183`). Snapshot clones only at most 128 rows (`:115-136`).
- Attribution invalidation checks both work lanes are monotonic, current interval is LIFO, no different `ReadWork` overlapped, native trace stayed enabled and in the same non-unknown epoch, and host trace stayed in the same non-unknown epoch; both boundary overflows invalidate it (`:264-300`). Entering a nested interval with a different work ledger taints its enclosing intervals even absent debit (`:185-205`). Same-work nesting is inclusive and consumers/tests explicitly avoid summing parent and child (`native_query_interval_trace_tests.rs:137-172`; `bound_reads/native_query_interval_tests.rs:105-133`).
- Accepted native mask debits are hooked only after `spend_plan_work` succeeds (`point_suppression/ops.rs:21-34`); host-eviction receipt is hooked after its real scan debit (`original_request/flattened_work_trace.rs:62-75`); lazy account-residency debit is hooked after successful spend (`stages.rs:2510-2522`). The observer stores raw interval counters without changing WorkControl admission.
- Point and raw intervals open at the respective query trace guard constructors and record their claim only after query completion (`point_content_query_trace.rs:100-165`; `raw_domain_query_trace.rs:114-178`). The interval module and all trace modules are `#[cfg(test)]` in `stages.rs:74-85`; production/default behavior does not compile this observer.
- Existing Point/raw `Snapshot` structs and serializers are unchanged. New reset epochs live on the native/host boundary accessors, not legacy Snapshot values. Tests explicitly check old invalid flags literally and compare the `ReadWork` deltas with query claim, native phases, and host eviction (`bound_reads/native_query_interval_tests.rs:64-133, 232-267`).
- Candidate tests are integrated at `native_query_interval_trace.rs:305-306`; real constructor checks live in `bound_reads/internal_suppression_baseline.rs:806-807`. The integration file exercises actual Point, held-public-mask residency, genuine bound raw+Point nesting, work-budget partial prefixes, and cache preflight in both Plan/cache lanes.

## Pins (SHA-256)

- `crates/deadpan-audio/src/native_query_interval_trace.rs`: `d067f28e3f04f7883675ae5d1e94b4a5bbbd92396e54ca0abc3b2c2bf85aef08`
- `crates/deadpan-audio/src/native_query_interval_trace_tests.rs`: `2170f1b51287622b98f35189cfd1935af9f5d30cb6d216efcff374280f9f1b3c`
- `crates/deadpan-audio/src/bound_reads/native_query_interval_tests.rs`: `b85c96b222922a81e358e26ed4d053129a788d83b2d94172cc360076285a6102`
- `crates/deadpan-audio/src/bound_reads/internal_suppression_baseline.rs`: `a2fb05dffb8e2eafe2fa095b69249038be5e28e3c4ffb6d1961d098a58e388ea`
- `crates/deadpan-audio/src/raw_domain_query_trace.rs`: `30adb97a3e08f79dfc35caba186bada5850f53b442293fecf386b0a41e5078db`
- `crates/deadpan-audio/src/point_content_query_trace.rs`: `36a13467f98979e18d2bf08dafe91570c082b3982972b35b567dde1898aaa638`
- `crates/deadpan-audio/src/point_suppression/ops.rs`: `a26d85f167ecca23b53dd2d60e290fc9f2602ee045dcb9a83c25a8ded1385d70`
- `crates/deadpan-audio/src/point_suppression/ops_trace.rs`: `d17ac33d3cd4c8c4587c0d95a7f17179ff9a71f15aa2f10fbcfadd4dad482777`
- `crates/deadpan-audio/src/original_request/flattened_work_trace.rs`: `5bfba29339be29f5e670377434aab563a5a4adac023eb28d7a526193e3807da5`
- `crates/deadpan-audio/src/stages.rs`: `3358c1408d66745bba44e49d78b37b15bda24b7988cbdc0b62ba93dfb268f1c8`

## Limits

This is static review only. I did not independently typecheck or execute the tests. The trace describes inclusive constructor intervals and uses the `ReadWork` identity to flag foreign work; it does not decompose parent/child intervals into disjoint fees.
