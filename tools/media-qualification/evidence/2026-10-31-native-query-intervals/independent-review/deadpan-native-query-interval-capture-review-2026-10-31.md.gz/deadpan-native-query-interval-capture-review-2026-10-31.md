# Final T capture glue and tests review

No material correctness or capture-contamination finding. The current source and supplied qualification receipts support publishing T within its stated raw/Point interval scope. This was a read-only source/JSON review; I ran no builds, native binary, test or Git command and changed no root files.

## Independent evidence checked

Both off canonical bodies are exactly 34,885,733 bytes, SHA af7a292718365c34fa03692e2cbe58a2cfb3c6d444b5ae29d52647e1fdbbff14. Both on canonical bodies are exactly 35,439,545 bytes, SHA f64d3a00a10967cc3822083d21705bd454f2d33ff2198da30e25671092ab5a53. I recomputed these hashes and sizes against all four proofs.

My independent recursive on/off comparison found exactly:

- 744 added native_query_intervals keys under native request paired.receipts.
- 14 added native_query_intervals_whole_case keys for ten internal and four public-transfer cases.
- One added observer_checkpoint.
- Changes to top-level schema and scope only.
- No removed keys, altered existing values, list-length changes or other payload differences.

Thus old PCM, typed errors, setup provenance, work/lookup/residency fields, old invalid flags and legacy receipts are preserved. The analyzer's equivalence check also restores those two envelope strings; describe this precisely rather than implying that only key removal is involved.

The proof manifests identify qualified optimized binaries, actual per-root source manifests and no source/binary mutation during each run. Main/scoped binary and source digests legitimately differ; their complete canonical bodies match. Three actual observer-on runs per build are now verified: six completed proof/receipt pairs in total, all with the same 35,439,545-byte f64d3a00... canonical body. The earlier caution about wording that implied three runs is withdrawn.

The analysis reports 758 snapshots, 478 rows, 75 Point and 403 raw rows, 477 completed rows and one partial. Both lanes reconcile completed rows from the literal completion debit plus independent native-phase and host-eviction deltas. No parent/child rows are summed. Snapshot completeness/attribution/reset-generation conditions are checked.

## Capture glue

native_mask_after separates interval capture with DEADPAN_QUERY_INTERVAL_AFTER and active-query-interval-after-v1. The old capture method, prefix and body remain available. The checkpoint precondition for T is ab211a2f132379a246157c3596d95fc42121541c. The retained old published_checkpoint/before_authorities are historical B envelope fields; observer_checkpoint identifies T's B authority. Documentation should name af7a... as T's actual off comparator rather than treating older embedded authorities as the T baseline.

Capture flags are thread-local. The outer Capture requires non-nesting, resets/disables only after actual constructor cleanup, and clears INTERVALS/CAPTURING on Drop. Paired receipt resets occur at the existing invocation boundary; native and interval snapshots are added only when the capture mode is active. Internal/public-transfer helpers reset once per complete case, capture whole-case observations, then disable. Their scope strings correctly retain warmup/held-output work in the case receipt and do not pretend it belongs only to the final request.

The paired active-capture branch preserves old invalid flags while retaining overflow and active-depth assertions; outside active capture, the stronger existing assertions still run. The exact off capture and on/off structural comparison are stronger evidence than a schema label alone that this branch did not contaminate established capture behavior.

Files use create_new under an explicit absolute /tmp parent, flush and sync. Source/variant provenance is supplied and independently checked by the runner; it is not guessed from a build path.

## Partial and nesting evidence

The single captured partial is the held-public-mask-lower-quota-private-point case. It is an actual resident-limit Error with no successful result. Its second Point interval has work [0,0] to [6,0], native residency 2 to3 and claim=null. The earlier completed warmup Point interval is preserved separately. No canonical/additional split is assigned to the remaining failed-constructor work.

The native budget-partial test is separate: it uses real accepted prior WorkControl spending, searches a bounded 1..35 remainder range for an actual partial prefix, retains the typed failure and excludes provider callbacks. The cache test truthfully shows an earlier guard refusal with no interval and no new work. Neither test assigns a fake remaining budget or synthesizes a completed receipt.

Actual native captured snapshots report no inclusive interval nesting. The genuine Bound native test observes both real raw and Point rows and a nested_point_callbacks count, but does not turn that consumer callback into a claim of overlapping constructor intervals. Same-ReadWork inclusive nesting, foreign-request non-attribution and non-LIFO behavior are explicitly tested by the bookkeeping tests. Keep this distinction in the final coverage description.

Completed captured intervals include 68 lanes with accepted residency. The supplied analysis records no positive host-eviction interval count. Separate host fields are preserved and the bookkeeping path is tested, but these native captures should not be described as positive in-scope eviction coverage.

## Tests and interpretation

The five native tests use actual checked public fixtures, actual Preserve Bound values, real provider/account/controller state and both Plan/cache lanes. The held owner test checks literal 36 =26 +10, including the old invalid=true, and distinguishes whole-call native work from the scoped amount. No residual is relabeled as a fee.

The seven bookkeeping tests remain byte-identical to the reviewed candidate. Their direct scopes and marker claims are labeled bookkeeping-only. Actual ops debits, cache RAII and host debit/receipt ordering are used; work caps/weights are not changed. Reset/disable, foreign actual ReadWork, row/active/ordinal bounds and unwind cleanup are covered. The two private epoch tests restore observer state and add no public setters.

I read the successful parent test outputs: five native tests, seven bookkeeping tests and 515 audio library tests passed on the supplied main run. Their execution belongs to the parent; this review did not rerun them.

## Source pins

All listed files currently match byte-for-byte between roots.

| Relative source | Bytes | SHA256 |
|---|---:|---|
| crates/deadpan-audio/src/bound_reads/native_mask_after.rs | 5581 | eac2c07e4499c6bb1ab9f2f021edf87dff07c8998a177eed27a8be0072f0f275 |
| crates/deadpan-audio/src/bound_reads/retained_host_pairs.rs | 24949 | 0e9253c59f5fe1ba39e07f1ad970fbf487cde735790cf9aa8c0b7b04b46be634 |
| crates/deadpan-audio/src/bound_reads/internal_suppression_baseline.rs | 33671 | a2fb05dffb8e2eafe2fa095b69249038be5e28e3c4ffb6d1961d098a58e388ea |
| crates/deadpan-audio/src/bound_reads/internal_transfer_entries.rs | 17555 | b5ecd923e814e199c9b980ca7f37e11f6e5ae7007fd3e9a97a4cc333710d6d3f |
| crates/deadpan-audio/src/bound_reads/native_query_interval_tests.rs | 17503 | b85c96b222922a81e358e26ed4d053129a788d83b2d94172cc360076285a6102 |
| crates/deadpan-audio/src/native_query_interval_trace.rs | 9375 | d067f28e3f04f7883675ae5d1e94b4a5bbbd92396e54ca0abc3b2c2bf85aef08 |
| crates/deadpan-audio/src/native_query_interval_trace_tests.rs | 13763 | 2170f1b51287622b98f35189cfd1935af9f5d30cb6d216efcff374280f9f1b3c |
| crates/deadpan-audio/src/point_suppression/ops_trace_epoch_tests.rs | 1444 | 8317b886d4dc1c225a6667c4f56a5f81bbde2a2d770eb1457c9ddab08c69a291 |
| crates/deadpan-audio/src/original_request/host_epoch_tests.rs | 1328 | 77e06e0d2a3951d5baa6eb019e0134ef1fac9be25c9864bbc169d9e06c1904ba |

Proof-file SHA256 pins:

- interval-off-main-proof.json: 76bc5fdf0a772f20d8db76ba5fec92eefdaf753396e4ec980609d1d13c9825bb
- interval-off-scoped-proof.json: ad68cbc6699c6878c9287b81294d44fa0cc845478960440ed85b322a85c63663
- interval-on-main-proof.json: 62bd842b831e8f5d0136a6fd946b64d67f3c9c2f7d86c4792fcc978e84cf9524
- interval-on-scoped-proof.json: 5a62eae870c4b8e73ad58424263be6c1ea0311b40e21f309d6670913b7188057

Review limits: this establishes bounded T observation and capture isolation, not whole preparation admission, a positive native nested-constructor sample, positive native in-scope eviction, or the upcoming policy-lease handoff.


## Repeated-run addendum

I bounded-verified interval-on-{main,scoped}{,-2,-3}: successful exact capture test, guarded source/binary equality, variant/output/checkpoint/source-manifest environment, source-manifest digest, stdout/stderr hashes, and streamed canonical body size/hash. During this repeated-run check I did not parse or rerun the huge bodies. capture-analysis.json/repeated_captures exactly enumerates these six proof objects.

All six canonical bodies are 35,439,545 bytes and SHA f64d3a00a10967cc3822083d21705bd454f2d33ff2198da30e25671092ab5a53. This supports “three complete 744+10+4 observer-on captures per build,” with the separately verified observer-off baseline retained unchanged.

| Completed run | Proof JSON SHA256 | Guarded receipt JSON SHA256 |
|---|---|---|
| interval-on-main | 62bd842b831e8f5d0136a6fd946b64d67f3c9c2f7d86c4792fcc978e84cf9524 | 7c6e9c983e95601088805d22dceff9d73a54733a03959d39dff84cb41b1c6e74 |
| interval-on-main-2 | 62bd842b831e8f5d0136a6fd946b64d67f3c9c2f7d86c4792fcc978e84cf9524 | 50f38c17d8846500688d2a7424cf56626c293c22e88214bfcbeb9eaf71eca810 |
| interval-on-main-3 | 62bd842b831e8f5d0136a6fd946b64d67f3c9c2f7d86c4792fcc978e84cf9524 | 1112494d8606763cee87b2f1a17b876d108684bd774443fbb786da71d6cfc107 |
| interval-on-scoped | 5a62eae870c4b8e73ad58424263be6c1ea0311b40e21f309d6670913b7188057 | 361bb662b85f6469dcc8a5ac037ea74f7ed8d480fd6c72ebdb436e73e3a37903 |
| interval-on-scoped-2 | 5a62eae870c4b8e73ad58424263be6c1ea0311b40e21f309d6670913b7188057 | 7f1d2e41ae11b585995af5190cb3a75e9221e8fcc756a0a62a5ccc6573e0fd7c |
| interval-on-scoped-3 | 5a62eae870c4b8e73ad58424263be6c1ea0311b40e21f309d6670913b7188057 | d9b1b1eb8e1db96bc3928adb0988741174d6ab534550c4edf268a3ddc125d048 |
