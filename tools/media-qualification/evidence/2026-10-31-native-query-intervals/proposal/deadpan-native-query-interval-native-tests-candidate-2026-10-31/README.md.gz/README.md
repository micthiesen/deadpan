# Real native interval observer test proposals

Candidate child for bound_reads/internal_suppression_baseline.rs:

```rust
#[path = "native_query_interval_tests.rs"]
mod native_intervals;
```

Requires the additive native_query_interval_trace candidate and its hooks from
/tmp/deadpan-native-query-interval-trace-candidate-2026-10-31. No extra production
visibility is needed: this child uses the same actual private read surfaces
already exercised by the baseline and serializes pub(super) snapshots.

Five tests use checked Point domains, the real historical Preserve Bound,
the existing qualified WAV-backed provider, real WorkControl/ReadWork, and
an actual held public output. No fake Bound, copied mask, synthetic query scope,
manually supplied completion claim, or invented fee is used.

1. Point success in Plan and cache lanes. Each completed row is reconciled in
   both lanes from its literal expected_debit plus independent eight-phase
   native deltas and host eviction deltas. The Point constructor has no native
   phase debit without a prior owner, while actual final mask construction
   makes whole-invocation native totals positive outside that interval.
2. Held public Point followed by selected Source Point, in both lanes. Requires
   actual canonical2 + additional24 = claim26 and work delta36, native phases
   [0,0,0,0,0,0,0,10], no host evictions. Requires the old Point observer's literal
   invalid=true/accepted36 to remain untouched. The new equation explains it;
   it does not normalize the old receipt. Whole-invocation native totals exceed
   this one interval's10 because final construction occurs after it.
3. Genuine Bound is borrowed from its real public checked Point query. Direct
   read_bound_at must produce actual raw_domain and point_content completed
   rows and one raw nested Point callback, each in the selected real lane.
4. Plan budget partial: before capture, a real spend_plan_work accepted debit
   leaves1..35 units in a bounded sweep. A partial row with native accepted work
   must have claim=None, actual Error, no WAV call, and literal prefix matching
   the old partial receipt. No canonical or query work is inferred by residual.
5. Cache budget: real cache_key_scope plus a real accepted prior debit leaves
   less than the ordinary Core allowance. Existing cache query_limits refuses
   before a constructor interval. Requires zero rows, zero new native work,
   unchanged actual work counters, zero media calls and stable held charge.

All completed attributable rows use checked subtraction/sums and are checked
independently. Inclusive parent/child rows are never added together. Each row's
native amount is compared independently with the whole-call native totals.
Snapshot completeness requires active_intervals0, dropped_intervals0,
misnestedfalse and overflowfalse; the actual nested flag is retained. Existing
raw/Point cleanup requires active_depth0, live_results0, balanced result drops,
metadata frames0 and no overflow. Existing invalid flags are never cleared.

Capture resets existing receipts and native work at the operation boundary,
then enables intervals. Public warmup and the deliberate prior budget debit
occur before capture. Disable happens only after all intervals close. Partial
rows preserve both raw boundaries but intentionally have no successful debit
equation; unknown query-prefix work is not manufactured from subtraction.

These tests do not exercise foreign-request overlap, reset during a live scope,
non-LIFO observer use, or the observer's row/depth limits. Those are independent
bookkeeping tests in the observer author's qualification proposal, not actual
native path claims made here. No full oracle body or old producer is modified.

Only rustfmt edition2024 parsed/formatted the scratch candidate. No roots were
edited, no build/native test/capture/fixture generation ran, and no Git operation
was performed. Parent must integrate and run these tests under both roots.
