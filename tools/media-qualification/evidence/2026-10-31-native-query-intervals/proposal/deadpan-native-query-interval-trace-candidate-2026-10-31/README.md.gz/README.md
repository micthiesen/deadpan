# Narrow native/query interval observer follow-up

This is an additive follow-up after B qualification/publication. It is not a prerequisite for B and does not redefine any of the 30 frozen before bodies or existing old query receipts.

Scope is only actual raw-domain and Structural Point constructor intervals. No Original/retained graph telemetry or ledger epoch registry is added. Candidate patch adds 389 test-only lines, including a 303-line new module and 86 accessor/guard/hook lines; removes zero lines. Observer bounds are 16 active and 128 retained closed intervals per reset. All observer allocations are separate test overhead outside the measured mask account.

## Files and verification

- New source: new/native_query_interval_trace.rs.
- Exact existing-source proposals and new source: after/crates/deadpan-audio/src/.
- Integration patch: candidate.patch.
- Before/after hashes: before-pins.json and pins.json.
- Reproducible scratch preparation and exact hunk reconstruction: prepare_hooks.py and finalize.py.
- Execution obligations: tests-proposal.md.

Rustfmt edition2024 parses/checks the proposals. Exact patch reconstruction passes entirely within scratch. Old serialized headers for Point/raw and ops Snapshot types are byte-identical. Actual current scoped sources retain all pinned before hashes. No root edit, build, native executable, capture, fixture write or Git operation was performed.

## Finding

Existing query traces record both work lanes and subtract accepted host eviction work only. They then expect the selected lane to equal the constructor's literal canonical+additional/forwarding receipt. B adds actual owned-account residency and native operations inside some of those exact intervals. Their accepted debits therefore legitimately leave old invalid=true. This observer records an additional interval explanation; it never clears that flag or rewrites that equality.

Original/processing/policy/fade and retained traces have analogous equality assumptions, but this narrow follow-up does not add separate intervals for them. Their old flags remain literal. A raw/Point interval may contain their existing scopes, but that is not a claim of separate per-product attribution.

## Minimal integration

1. stages.rs declares native_query_interval_trace under cfg(test).
2. Existing raw/Point ScopeGuard gets one independent field, constructed before the existing enable check. It receives the same actual completion inputs even if the old observer is disabled. Its Drop runs after the existing guard's Drop body, which performs no accepted host work. Old fields, conditions, aggregations and serialized Snapshot definitions are unchanged.
3. ops_trace exposes work_boundary(): current enabled state, reset generation, both lanes' seven actual accepted native phases plus actual host residency, and existing overflow. Existing ops Snapshot JSON is unchanged.
4. flattened_work_trace exposes host_eviction_boundary(): existing actual host counters/overflow plus independent reset generation. Existing host receipt JSON and counters remain unchanged.
5. Three accepted-event hooks mark foreign ReadWork overlap only: actual ops spend_work, actual owned-account residency debit, actual host eviction debit. They neither spend nor count work; phase/host totals come solely from existing cumulative counters.

Transient scope ordinals and parent ordinals identify inclusive nesting. The actual ReadWork address is used only for equality while scopes are live; it is never dereferenced or serialized. A foreign accepted work event or nested foreign request makes the enclosing interval non-attributable rather than attributing its global native counters to another ledger.

## Capture lifecycle

At the new after producer's existing operation boundary, reset the existing native ops trace and existing host receipts in their usual places, then call native_query_interval_trace::reset(). The new reset does not reset any existing observer. Disable the new observer only after actual constructor cleanup. Add its snapshot only to a new named after field or sidecar, for example receipts.native_query_intervals. Do not change old driver/schema behavior or old expected bodies to add this key.

Default is off. While off, no interval rows or native boundary snapshots are collected. Old native trace reset/disable remain independently visible through new boundary metadata.

A snapshot contains completed interval rows and the count of still-open intervals. It does not fabricate after-work fields for an open provider callback interval. Final-operation reconciliation requires active_intervals=0; earlier callback snapshots may have a nonzero count.

## Literal row contents and reconciliation

Each row includes both work lanes before/after, both native-counter lanes before/after, host eviction counters separately before/after, selected entry lane, exact constructor kind and optional completion claim. Missing completion means partial/uncompleted; no error kind or successful canonical amount is invented.

For an attributable completed row with nonoverflowing checked arithmetic:

1. Compute each lane's actual work delta using checked subtraction.
2. Independently compute each accepted phase delta and host eviction delta from that same row's before/after boundaries.
3. Check canonical+additional equals the literal reported total.
4. Compare work delta directly with explicit claimed query debit plus the sum of those independent native phase deltas plus host eviction delta. Query debit belongs only to the selected lane. Raw expected_debit follows the old raw trace's exact forwarding rule; Point expected_debit is its literal total.

This is an explicit sum of independently recorded accepted debits. Never obtain a native fee by subtracting an unexplained residual. If the equality fails, preserve the failure and investigate; do not normalize any amount. Partial rows retain actual accepted native/host prefixes but do not infer missing query work by residual.

Nested same-request rows are inclusive. Check each equation independently. Never sum parent and child native deltas or treat them as disjoint whole-invocation fees. Existing whole-invocation ops receipts remain the separate global evidence.

## Failure and trust limits

A row is non-attributable after foreign-request overlap, non-LIFO scope close, backwards work counters, disabled native capture, changed/reset-overflowed native or host generation, or counter overflow. All raw boundaries remain serialized. Scope truncation, dropped rows and misnesting are explicit snapshot flags; reject a full-body completeness claim when any occurs. Bounds do not change production caps or old fixed observer slots.

Counters reset mid-interval are detected by new generation metadata, even if reset counters later grow beyond their former values. Reset generations are not added to old Snapshot JSON. New observer reset/disable require no active interval.

The observer covers B native phases and account residency plus existing host eviction only. It makes no assertion that every other host operation is admitted or represented. It does not alter canonical query weights, work allowances, cancellation/deadline behavior, result liveness or cleanup.
