from pathlib import Path
import hashlib,json,difflib
s=Path(__file__).resolve().parent
root=Path('/tmp/deadpan-query-groundwork-2026-10-26/scoped')
base='crates/deadpan-audio/src/'
names=['point_suppression/ops_trace.rs','original_request/flattened_work_trace.rs',
       'point_suppression/ops.rs','stages.rs','point_content_query_trace.rs','raw_domain_query_trace.rs']
pins={}
def replace_once(t,a,b):
 assert t.count(a)==1,(a,t.count(a))
 return t.replace(a,b,1)
for name in names:
 path=base+name
 before=(root/path).read_bytes();t=before.decode()
 if name=='point_suppression/ops_trace.rs':
  t=replace_once(t,'    static ENABLED: Cell<bool> = const { Cell::new(false) };',
   '    static RESET_EPOCH: Cell<Option<u64>> = const { Cell::new(Some(0)) };\n    static ENABLED: Cell<bool> = const { Cell::new(false) };')
  t=replace_once(t,'pub(crate) fn reset() {\n','pub(crate) fn reset() {\n    RESET_EPOCH.with(|epoch| epoch.set(epoch.get().and_then(|value| value.checked_add(1))));\n')
  t+='''\n#[derive(Clone, Copy, Serialize)]
pub(crate) struct WorkBoundary {
    pub(crate) enabled: bool,
    pub(crate) reset_epoch: Option<u64>,
    pub(crate) lanes: [[usize; 8]; 2],
    pub(crate) overflow: bool,
}
pub(crate) fn work_boundary() -> WorkBoundary {
    let value = snapshot();
    let units = |lane: Lane| [
        lane.accepted_account_units, lane.accepted_scan_units,
        lane.accepted_map_units, lane.accepted_zero_units,
        lane.accepted_mark_units, lane.accepted_vector_units,
        lane.accepted_storage_units, lane.accepted_host_residency_units,
    ];
    WorkBoundary {
        enabled: ENABLED.with(Cell::get), reset_epoch: RESET_EPOCH.with(Cell::get),
        lanes: [units(value.plan), units(value.cache)], overflow: value.overflow,
    }
}
'''
 elif name=='original_request/flattened_work_trace.rs':
  t=replace_once(t,'    static HOST_EVICTIONS: Cell<HostEvictions>',
   '    static HOST_RESET_EPOCH: Cell<Option<u64>> = const { Cell::new(Some(0)) };\n    static HOST_EVICTIONS: Cell<HostEvictions>')
  t=replace_once(t,'pub(in crate::stages) fn host_eviction_spent(control: WorkControl<\'_>) {\n',
   'pub(in crate::stages) fn host_eviction_spent(control: WorkControl<\'_>) {\n    crate::stages::native_query_interval_trace::accepted_work(control);\n')
  t=replace_once(t,'pub(in crate::stages) fn reset() {\n','pub(in crate::stages) fn reset() {\n    HOST_RESET_EPOCH.with(|epoch| epoch.set(epoch.get().and_then(|value| value.checked_add(1))));\n')
  t+='''\npub(in crate::stages) fn host_eviction_boundary() -> ([usize; 2], bool, Option<u64>) {
    let (units, overflow) = host_eviction_units();
    (units, overflow, HOST_RESET_EPOCH.with(Cell::get))
}
'''
 elif name=='point_suppression/ops.rs':
  t=replace_once(t,'    control.spend_plan_work(units)?;\n',
   '    control.spend_plan_work(units)?;\n    #[cfg(test)]\n    crate::stages::native_query_interval_trace::accepted_work(control);\n')
 elif name=='stages.rs':
  anchor='#[cfg(test)]\n#[path = "point_content_query_trace.rs"]'
  t=replace_once(t,anchor,'#[cfg(test)]\n#[path = "native_query_interval_trace.rs"]\nmod native_query_interval_trace;\n'+anchor)
  anchor='''        if frames != 0 {
            control.spend_plan_work(1)?;
            #[cfg(test)]
            point_suppression::work_trace::residency_spent();'''
  t=replace_once(t,anchor,'''        if frames != 0 {
            control.spend_plan_work(1)?;
            #[cfg(test)]
            native_query_interval_trace::accepted_work(control);
            #[cfg(test)]
            point_suppression::work_trace::residency_spent();''')
 elif name in ['point_content_query_trace.rs','raw_domain_query_trace.rs']:
  kind='PointContent' if name.startswith('point_') else 'RawDomain'
  t=replace_once(t,"pub(super) struct ScopeGuard<'work> {\n",
   "pub(super) struct ScopeGuard<'work> {\n    native_interval: crate::stages::native_query_interval_trace::ScopeGuard<'work>,\n")
  t=replace_once(t,"    pub(super) fn new(control: WorkControl<'work>) -> Self {\n",
   f"    pub(super) fn new(control: WorkControl<'work>) -> Self {{\n        let native_interval = crate::stages::native_query_interval_trace::ScopeGuard::new(\n            crate::stages::native_query_interval_trace::Kind::{kind}, control,\n        );\n")
  t=replace_once(t,'            return Self {\n                control,','            return Self {\n                native_interval,\n                control,')
  t=replace_once(t,'        Self {\n            control,','        Self {\n            native_interval,\n            control,')
  if kind=='PointContent':
   anchor='''    ) {
        if self.tracked {
            self.completed = Some((canonical, additional, total, forwarded, ordinary, spans));'''
   repl='''    ) {
        self.native_interval.completed(crate::stages::native_query_interval_trace::Claim {
            canonical, additional, total, expected_debit: total, forwarded, ordinary,
            raw_kind: None, result_spans: Some(spans),
        });
        if self.tracked {
            self.completed = Some((canonical, additional, total, forwarded, ordinary, spans));'''
  else:
   anchor='''    ) {
        if self.tracked {
            self.completed = Some((canonical, additional, total, forwarded, product));'''
   repl='''    ) {
        self.native_interval.completed(crate::stages::native_query_interval_trace::Claim {
            canonical, additional, total, expected_debit: if forwarded { total } else { 0 },
            forwarded, ordinary: !forwarded, result_spans: None,
            raw_kind: Some(match product { Product::Root => "root", Product::Point => "point", Product::Empty => "empty" }),
        });
        if self.tracked {
            self.completed = Some((canonical, additional, total, forwarded, product));'''
  t=replace_once(t,anchor,repl)
 for folder,data in [('before',before),('after',t.encode())]:
  p=s/folder/path;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data)
 pins[path]={'bytes':len(before),'sha256':hashlib.sha256(before).hexdigest()}
newpath=base+'native_query_interval_trace.rs'
p=s/'after'/newpath;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes((s/'new/native_query_interval_trace.rs').read_bytes())
(s/'before-pins.json').write_text(json.dumps({'root':str(root),'source':pins},indent=2)+'\n')
print('Prepared six source hook proposals and one new module entirely in scratch.')
