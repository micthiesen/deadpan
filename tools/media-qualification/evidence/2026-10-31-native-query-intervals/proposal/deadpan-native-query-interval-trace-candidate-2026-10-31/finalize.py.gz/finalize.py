from pathlib import Path
import hashlib,json,difflib,re
s=Path(__file__).resolve().parent
before=json.loads((s/'before-pins.json').read_text())
root=Path(before['root'])
files=sorted(p for p in (s/'after').rglob('*.rs'))
patch=[]
pins={}
added=removed=0
for after in files:
 path=str(after.relative_to(s/'after'));bp=s/'before'/path
 old=bp.read_text() if bp.exists() else ''
 new=after.read_text()
 if bp.exists():
  assert hashlib.sha256((root/path).read_bytes()).hexdigest()==before['source'][path]['sha256'],path
 lines=list(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile='a/'+path if old else '/dev/null',tofile='b/'+path))
 patch.extend(lines)
 added+=sum(x.startswith('+') and not x.startswith('+++') for x in lines)
 removed+=sum(x.startswith('-') and not x.startswith('---') for x in lines)
 pins[path]={'bytes':len(new.encode()),'sha256':hashlib.sha256(new.encode()).hexdigest()}
 # Any original preexisting serialized receipt type is byte-exact.
 if path.endswith(('point_content_query_trace.rs','raw_domain_query_trace.rs')):
  def scalar_header(t):return t[:t.index('#[derive(Clone, Copy)]')]
  assert scalar_header(old)==scalar_header(new),path
 if path.endswith('ops_trace.rs'):
  assert old[:old.index('thread_local!')]==new[:new.index('thread_local!')],path
(s/'candidate.patch').write_text(''.join(patch))
# Verify every exact hunk entirely within scratch; no Git or roots.
current=None;oldlines=[];cursor=0;out=[]
for line in ''.join(patch).splitlines(True)+['--- END\n']:
 if line.startswith('--- '):
  if current is not None:
   out.extend(oldlines[cursor:])
   got=''.join(out)
   assert got==(s/'after'/current).read_text(),current
   check=s/'apply-check'/current;check.parent.mkdir(parents=True,exist_ok=True);check.write_text(got)
  current=None
 elif line.startswith('+++ '):
  current=line[6:].strip();p=s/'before'/current
  oldlines=p.read_text().splitlines(True) if p.exists() else []
  cursor=0;out=[]
 elif line.startswith('@@'):
  m=re.match(r'@@ -(\d+)(?:,\d+)? \+',line);at=max(int(m.group(1))-1,0)
  out.extend(oldlines[cursor:at]);cursor=at
 elif current is not None and line[:1] in (' ','-','+'):
  if line[0] in ' -':
   assert oldlines[cursor]==line[1:];cursor+=1
  if line[0] in ' +':out.append(line[1:])
result={'root':str(root),'before':before['source'],'after':pins,'patch_sha256':hashlib.sha256((s/'candidate.patch').read_bytes()).hexdigest(),'diff_added_lines':added,'diff_removed_lines':removed,'verification':'rustfmt2024 + exact scratch patch reconstruction + serialized old trace headers byte-exact; no build/native/root edits'}
(s/'pins.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:result[k] for k in ['patch_sha256','diff_added_lines','diff_removed_lines','verification']},indent=2))
