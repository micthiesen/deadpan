# Qualification owed for the additive follow-up

No tests executed.

1. Default-off compatibility:
   Run all current old/new whole-body regressions with the new observer off. Compare complete existing receipts and invalid flags byte-for-byte. The old serialized trace type headers already compare exactly in scratch; actual full qualification remains required.

2. Real raw/Point success and partial failure:
   Reuse actual admitted raw/Point fixtures and real owning account. Enable native plus interval observers only at the existing operation boundary. Reconcile exact per-row lane equations for successful constructors; on budget refusal retain actual accepted native/host prefixes and claim=None. Preserve the old invalid=true where it actually occurs.

3. Scope isolation:
   Perform accepted native work immediately before/after a real constructor and show it changes the whole-invocation native totals but is excluded from that interval's counter delta. Nest same-ReadWork raw/Point scopes and check each inclusive interval independently. Perform real accepted native work using a separate actual ReadWork inside an observed scope and require foreign_work_overlap/non-attributable instead of subtraction.

4. Reset, overflow and bound behavior:
   In observer-local bookkeeping tests, reset/disable native capture or reset host receipt generation during an open interval. Require non-attribution even if counters catch up later. Exercise checked generation/counter overflow, non-LIFO close and 16-active/128-row limits without changing any production admission cap. Assert explicit overflow/dropped/misnested markers and no unbounded row growth.

5. Capture proof:
   Add only the new named after receipt/sidecar. Preserve all existing before JSON, old trace fields and global whole-invocation ops receipts. Require active_intervals=0 and all completeness flags clear before interpreting complete row coverage. Keep provider snapshots honest when intervals remain open. Native after evidence and exact old fixture regression are parent-owned.
