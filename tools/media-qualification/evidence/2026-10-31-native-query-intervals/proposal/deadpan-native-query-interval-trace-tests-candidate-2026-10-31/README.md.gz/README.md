# Interval observer bookkeeping tests candidate

Scratch-only tests for /tmp/deadpan-native-query-interval-trace-candidate-2026-10-31. No source integration, root modification, build, native executable, capture, Git operation or expected-body generation performed.

## Hooks

Main test file is a private child of native_query_interval_trace.rs:

    #[path = "native_query_interval_trace_tests.rs"]
    mod tests;

Optional private reset-epoch accessor tests:

In point_suppression/ops_trace.rs, with ops_trace_epoch_tests.rs beside that source:

    #[path = "ops_trace_epoch_tests.rs"]
    mod epoch_tests;

In original_request/flattened_work_trace.rs, with host_epoch_tests.rs beside that source:

    #[path = "host_epoch_tests.rs"]
    mod epoch_tests;

These existing trace modules are already cfg(test). No new production visibility, exported epoch setter or root helper is proposed.

## Coverage

Seven main tests cover default-off behavior; accepted work before/inside/after an interval; real Plan/cache lane separation; distinct host eviction counters; inclusive same-ReadWork nesting and optional completion metadata; foreign accepted work from a second actual ReadWork and foreign nesting without work; native reset/disable/re-enable plus host reset while counters later catch up; non-LIFO closure; 16-active and 128-row limits; private ordinal overflow; reset/disable rejection while open; and partial-interval cleanup during unwinding.

Every accepted work operation uses the actual WorkControl debit through ops::spend_work. The direct host bookkeeping helper performs the actual one-unit WorkControl debit before calling the existing accepted-host receipt hook. Cache selection uses the actual WorkControl.cache_key_scope RAII API. No real work counters, cap or canonical weights are overwritten/reset. Fresh ReadWork instances are genuine request ledgers.

Direct ScopeGuard construction and zero-valued completion markers are bookkeeping inputs only. They are explicitly not real raw/Point constructor, media, allocation, eviction or native-capture evidence. These tests establish observer behavior, not producer semantics.

Two optional epoch tests run inside their owning modules and access only private observer bookkeeping. They temporarily set that module's reset generation to Some(u64::MAX), then exercise actual reset/disable accessors and restore all prior observer state with RAII. They never alter admission/work counters or add visibility. They verify sticky unknown epochs and unchanged serialized legacy Snapshot shape.

## Cleanup and bounds

Session is declared before each test's scope guards. Guards therefore close before session disable during normal return or unwinding. Row snapshots are independent owned observer copies. Non-LIFO and bounded guard vectors are fully closed, and rejected guards remain no-ops. Busy reset/disable assertions are caught without dropping the enclosing live guard; subsequent real spending and closure verify the RefCell bookkeeping remains usable.

Ordinal overflow modifies only native_query_interval_trace::State.next through this private test child. It asserts explicit overflow and no active/retained interval, without requiring an invented dropped-row count for that separate failure branch.

## Verification and remaining obligations

Rustfmt edition2024 parsing/check passes. The source has not been compiled or executed. Exact candidate/dependency hashes are in pins.json. Parent owns integration, typechecking and execution.

These do not replace the proposed observer's real-constructor native tests, foreign-runtime callbacks or complete after-body qualification. Existing old receipts and all frozen oracle bytes remain immutable.
