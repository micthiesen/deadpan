from pathlib import Path
import gzip,hashlib,json
scratch=Path(__file__).resolve().parent
out=Path('/Users/michael/Code/deadpan/tools/media-qualification/evidence/2026-10-26-constant-sound-blocks')
out.mkdir(parents=True,exist_ok=False)
sources=[]
for base in [scratch,scratch/'standalone']:
    sources.extend(p for p in sorted(base.iterdir()) if p.is_file() and p.suffix in ('.json','.stdout','.stderr','.patch','.py'))
sources.append(scratch/'block-before-lint.rs')
entries=[]
for source in sources:
    raw=source.read_bytes()
    relative=Path('records')/source.relative_to(scratch)
    relative=relative.with_name(relative.name+'.gz')
    encoded=gzip.compress(raw,compresslevel=9,mtime=0)
    path=out/relative
    path.parent.mkdir(parents=True,exist_ok=True)
    path.write_bytes(encoded)
    entries.append({'path':relative.as_posix(),'bytes':len(encoded),'sha256':hashlib.sha256(encoded).hexdigest(),'expanded_bytes':len(raw),'expanded_sha256':hashlib.sha256(raw).hexdigest()})
inventory={'schema_version':1,'base_revision':'b0d2170647afb5baf12319bf2b192c1377ffadb0','implementation_revision':'a735863e','scope':'Six-file constant Audio optimization, isolated HEAD overlay checks and integrated unfinished Split diagnostics. Four passes/three work-limit failures; not full-product acceptance. Executables excluded, identities retained. Foreign files excluded.','files':entries}
(out/'inventory.json').write_text(json.dumps(inventory,indent=2)+'\n')
for entry in entries:
    encoded=(out/entry['path']).read_bytes()
    raw=gzip.decompress(encoded)
    assert len(encoded)==entry['bytes'] and hashlib.sha256(encoded).hexdigest()==entry['sha256']
    assert len(raw)==entry['expanded_bytes'] and hashlib.sha256(raw).hexdigest()==entry['expanded_sha256']
print(json.dumps({'files':len(entries),'stored_bytes':sum(x['bytes'] for x in entries),'expanded_bytes':sum(x['expanded_bytes'] for x in entries),'inventory_sha256':hashlib.sha256((out/'inventory.json').read_bytes()).hexdigest(),'all_payloads_verified':True}))
