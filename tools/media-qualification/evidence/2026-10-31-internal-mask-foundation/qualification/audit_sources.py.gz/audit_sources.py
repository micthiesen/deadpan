from pathlib import Path
import hashlib,json
s=Path(__file__).resolve().parent
owned=set(json.loads((s/'owned-code-paths.json').read_text()))
roots={'main':Path('/Users/michael/Code/deadpan'),'scoped':Path('/tmp/deadpan-query-groundwork-2026-10-26/scoped')}
result={}
for v,root in roots.items():
 initial=json.loads((s/f'{v}-initial-authority.json').read_text());unchanged={}
 for path,h in initial.items():
  if path in owned:continue
  b=(root/path).read_bytes();assert {'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}==h,path
  unchanged[path]=h
 result[v]={'initial_named_inputs':len(initial),'unowned_inputs_exact':len(unchanged),'unowned_manifest_sha256':hashlib.sha256((json.dumps(unchanged,sort_keys=True,separators=(',',':'))+'\n').encode()).hexdigest()}
 for pin in json.loads((s/'immutable-oracle-pins.json').read_text()):
  assert hashlib.sha256((root/pin['path']).read_bytes()).hexdigest()==pin['sha256'],pin['path']
rows=[]
for path in sorted(owned):
 a=(roots['main']/path).read_bytes();b=(roots['scoped']/path).read_bytes();assert a==b,path
 rows.append({'path':path,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'main_scope_exact':True})
result.update({'owned_paths':rows,'shipping_authority':'scoped','immutable_payloads_exact':29})
(s/'final-source-audit.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({v:result[v] for v in roots}))
