from pathlib import Path
import gzip,hashlib,json
s=Path(__file__).resolve().parent
root=Path('/Users/michael/Code/deadpan');scope=Path('/tmp/deadpan-query-groundwork-2026-10-26/scoped')
out=root/'tools/media-qualification/evidence/2026-10-31-internal-mask-foundation'
assert not out.exists()
files={}
allowed={'.json','.md','.txt','.py','.patch','.rs','.stdout','.stderr'}
def collect(base,prefix):
 for p in sorted(base.rglob('*')):
  if p.is_file() and p.suffix in allowed and '__pycache__' not in p.parts and p.name not in {'archive-proof.json','qualification-draft.md'}:
   key=prefix+'/'+str(p.relative_to(base));assert key not in files;files[key]=p.read_bytes()
collect(s,'qualification')
collect(Path('/tmp/deadpan-internal-suppression-old-observer-candidate-2026-10-31'),'old-observer')
collect(Path('/tmp/deadpan-internal-suppression-generic-review-2026-10-31'),'independent-review')
for path in json.loads((s/'owned-code-paths.json').read_text()):
 if path.endswith('.rs'):files['shipping-source/'+path]=(scope/path).read_bytes()
rows=[]
for key,data in sorted(files.items()):
 zipped=gzip.compress(data,compresslevel=9,mtime=0);dest=out/(key+'.gz')
 dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(zipped);assert gzip.decompress(dest.read_bytes())==data
 rows.append({'path':key,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest(),'stored_path':key+'.gz','stored_bytes':len(zipped),'stored_sha256':hashlib.sha256(zipped).hexdigest()})
body={'schema':'deadpan-qualified-gzip-evidence-v1','scope':'typed existing public mask and independent before-only internal-path observer; internal production masks remain unowned','base_revision':(s/'base-revision.txt').read_text().strip(),'records':rows,'expanded_bytes':sum(r['bytes'] for r in rows),'stored_bytes':sum(r['stored_bytes'] for r in rows),'excluded':'pinned executable copies; scratch-only future controlled-transfer/owned-builder candidates are not integrated or qualified'}
b=(json.dumps(body,indent=2)+'\n').encode();(out/'inventory.json').write_bytes(b)
proof={'inventory_path':str((out/'inventory.json').relative_to(root)),'inventory_sha256':hashlib.sha256(b).hexdigest(),'records':len(rows),'expanded_bytes':body['expanded_bytes'],'stored_bytes':body['stored_bytes']}
(s/'archive-proof.json').write_text(json.dumps(proof,indent=2)+'\n');print(json.dumps(proof))
