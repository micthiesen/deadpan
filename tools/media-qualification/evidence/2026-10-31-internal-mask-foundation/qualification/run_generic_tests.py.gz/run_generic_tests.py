from pathlib import Path
import hashlib,json,os,subprocess,sys
s=Path(__file__).resolve().parent;v=sys.argv[1]
build=f'internal-mask-{v}-generic-build'
subprocess.run(['python3',str(s/'pin.py'),build],check=True)
pin=next(p for p in json.loads((s/(build+'-pins.json')).read_text()) if p['name']=='deadpan_audio')
runner=s/('run_qualified.py' if v=='main' else 'run_scoped_qualified.py')
cmd=['python3',str(runner),'--binary',pin['path'],f'internal-mask-{v}-generic-library','--',pin['path'],'--test-threads=1']
subprocess.run(cmd,check=True)
expected='/Users/michael/Code/deadpan/crates/deadpan-audio/tests/fixtures/internal-suppression-paths-baseline-v1/snapshot.json'
env=os.environ.copy();env['DEADPAN_INTERNAL_SUPPRESSION_EXPECTED']=expected
test='stages::bound_reads::retained_host_baseline::internal_suppression_baseline::internal_suppression_paths_match_external_old_v1'
subprocess.run(['python3',str(runner),'--binary',pin['path'],f'internal-mask-{v}-generic-before-regression','--',pin['path'],'--ignored','--exact',test,'--test-threads=1'],env=env,check=True)
