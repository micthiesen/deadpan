from pathlib import Path
import hashlib,json,os,subprocess,sys
s=Path(__file__).resolve().parent;prior=Path('/tmp/deadpan-owned-suppression-output-2026-10-31')
v=sys.argv[1];assert v in ['main','scoped']
root=Path('/Users/michael/Code/deadpan') if v=='main' else Path('/tmp/deadpan-query-groundwork-2026-10-26/scoped')
build=f'point-suppression-{v}-postlint-lib-build'
r=json.loads((prior/(build+'.json')).read_text());assert r['exit_code']==0 and r['sources_unchanged']
pin=next(p for p in json.loads((prior/(build+'-pins.json')).read_text()) if p['name']=='deadpan_audio')
assert pin['artifact']['profile']['opt_level']=='2' and pin['artifact']['profile']['overflow_checks'] and pin['artifact']['profile']['debug_assertions']
assert hashlib.sha256(Path(pin['path']).read_bytes()).hexdigest()==pin['sha256']
manifest={}
for absolute,h in r['source_after'].items():
 b=Path(absolute).read_bytes();assert {'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}==h
 manifest[str(Path(absolute).relative_to(root))]=h
assert manifest==json.loads((s/f'{v}-initial-authority.json').read_text())
encoded=(json.dumps(manifest,sort_keys=True,separators=(',',':'))+'\n').encode();digest=hashlib.sha256(encoded).hexdigest()
variant='main-inherited' if v=='main' else 'scoped-published'
runner=s/('run_qualified.py' if v=='main' else 'run_scoped_qualified.py')
base='stages::bound_reads::retained_host_baseline::'
cases=[('complete','DEADPAN_POINT_HOST_',base+'pairs::raw_domain_host_baseline::capture_new_point_content_native_v1','af34e1e1143e9abc11f49b77ee49c602c116aac4','3d6338e4e4b0f5617647ab6e0fa4d80bf8882a87c87a55efe306002c3011dbdc'),('outputs','DEADPAN_OWNED_SUPPRESSION_',base+'owned_suppression_baseline::capture_old_owned_suppression_output_v1','dd5fda5d83205aca0fc3480b7c0dae254224f133','a52d53b51b86311ed3794e38bfeec9b8ce5c3c9027ad8d6ee7b7516c993e18a2')]
proof=[]
for kind,prefix,test,legacy_checkpoint,expected in cases:
 label=f'internal-mask-before-{v}-{kind}';out=s/(label+'-body.json');assert not out.exists()
 mp=s/(label+'-source-manifest.json');assert not mp.exists();mp.write_bytes(encoded)
 keys={prefix+'OUTPUT':str(out),prefix+'VARIANT':variant,prefix+'SOURCE_SHA256':digest,prefix+'PUBLISHED_CHECKPOINT':legacy_checkpoint}
 env=os.environ.copy();env.update(keys)
 subprocess.run(['python3',str(runner),'--binary',pin['path'],label,'--',pin['path'],'--ignored','--exact',test,'--nocapture','--test-threads=1'],env=env,check=True)
 run=json.loads((s/(label+'.json')).read_text());assert run['exit_code']==0 and run['sources_unchanged'] and run['binaries_unchanged']
 for k,value in keys.items():assert run['environment'][k]==value
 body=json.loads(out.read_text());assert body.pop('variant')==variant and body.pop('source_sha256')==digest
 data=(json.dumps(body,sort_keys=True,separators=(',',':'))+'\n').encode();sha=hashlib.sha256(data).hexdigest();assert sha==expected
 (s/(label+'-canonical.json')).write_bytes(data)
 row={'kind':kind,'actual_published_base':(s/'base-revision.txt').read_text().strip(),'historical_schema_checkpoint_preserved':legacy_checkpoint,'variant':v,'source_inputs':len(manifest),'source_manifest_sha256':digest,'binary_sha256':pin['sha256'],'fresh_before_internal_ownership':True,'reused_executable_every_named_source_exact':True,'bytes':len(data),'sha256':sha,'existing_immutable_fixture_reused_without_regeneration':True}
 (s/(label+'-proof.json')).write_text(json.dumps(row,indent=2)+'\n');proof.append(row)
print(json.dumps(proof))
