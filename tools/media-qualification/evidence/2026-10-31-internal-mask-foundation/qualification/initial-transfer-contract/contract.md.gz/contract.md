# Next ownership unit: concrete transfer and aggregate API

Preferred next unit: establish native Point mask ownership and every direct
copy/move destination first, while its Plan policy remains ordinary. Afterwards
replace that ordinary policy with the admitted SignalSample carrier and a
sealed source-charge transfer. Do not combine Plan policy traversal changes
with this native API/ownership change.

## One mutable context solves transfer admission

Keep public RootSignalTransfer::render and its existing Vec callback API as
the unchanged Plain path. Add this crate-private native entrypoint:

    fn render_controlled<C: MaskContext>(
        &self, start: SignalSample, frames: u32, cancelled: &AtomicBool,
        context: &mut C,
        read: impl FnMut(&mut C, AudioSample, u32)
            -> Result<ControlledRootBlock, StageAudioError>,
    ) -> Result<ControlledTransferredBlock, StageAudioError>

ControlledRootBlock holds start, PCM and Mask<AudioSample>;
ControlledTransferredBlock holds start, PCM and Mask<SignalSample>.
Both mask types own their charge, with no context lifetime.

    struct StageTransferContext<'r, 'p, 'w, P> {
        renderer: &'r mut StageAudio,
        provider: &'p mut P,
        control: WorkControl<'w>,
        dependencies: Dependencies,
        relative_depth: usize,
    }

MaskContext offers check, separately traced work spending, begin_flags(len)
and begin_ranges<S>(capacity). Begin returns an owning builder/scratch guard
whose ticket retains the existing Account. It must NOT return a value borrowing
&mut context. Finish takes the same context for final Storage work/check and
returns a closed unique boxed mask.

The read closure receives context rather than capturing renderer/provider.
It temporarily reborrows its two fields, performs the actual recursive read,
then maps the returned mask with the same context and updates dependencies/
depth. Thus the transfer can admit scratch before the callback and its final
range storage afterwards, with no competing mutable capture or hidden ledger.

Generalize current point_suppression ownership to a sealed Copy sample-label
parameter. Keep Account and unique Box protocol. Its module may become
pub(crate) for transfer helpers; public PointSuppressionMask remains the
ReferenceSample alias. No public consuming iterator/detach/Clone is added.

## Exact transfer capacity and work sequence

1. Validate complete request/support with existing Resampler math before any
   new allocation. The Plain render body keeps its original Vec expressions.
2. Controlled transfer admits Layout::array::<bool>(frames) before creating its
   bool mask. This scratch uses Vec plus an owned ticket, with Vec dropped first;
   it needs no separate Box. It remains charged across every recursive read.
3. Retain each ControlledRootBlock owner through root-block validation,
   discrete PCM suppression and mark_interval. Append PCM with the existing
   operation, then physically drop the consumed input mask before next callback.
4. The ordinary interleaved PCM/window/resampling algorithm is unchanged.
   This unit does not claim new PCM/dependency-container admission.
5. Once bool output policy is final, count its runs allocation-free while
   retaining scratch and all still-live inputs. Admit exact run-count Vec
   Layout plus its unique Storage Box, then allocate and populate ranges.
   Keep scratch live until final output construction/control check succeeds.
   Count the new scan/copy work separately; never call it canonical Plan work.
6. Finish output, then drop scratch. Every error releases physical allocations
   before their tickets. No input charge is transferred to a different newly
   allocated output; both reservations coexist at the actual overlap peak.

Share existing point_boundary/mark_interval/mark_outside_support and numerical
validation logic. Avoid a generic renderer framework or generic consuming
iterator to unify Plain and Owned storage: preserving exact old Vec capacity/
reuse expressions is more important than removing this small adapter branch.

## Concrete native callers

stages.rs has exactly three current RootSignalTransfer render callsites:
- read_domain_transferred_controlled: restore anchor on input reads and subtract
  that same integer anchor from mask endpoints.
- read_bound_at Point arm: read_point_domain_controlled, then map Signal labels
  to already-rebased Audio carrier labels without rounding.
- public read_transferred: read_controlled, union exhausted, and return the
  native transferred mask through its owning public result.

Each gains an explicit historical Plain branch and a controlled context branch.
The callback cannot call public read entrypoints or renew timeout/work.
Use the existing WorkControl, including its plan/cache lane selection.

## Maps, aggregates and cache have real destinations

Change private SignalBlock.suppressed and ReadBlock.suppressed to Mask<S>.
Keep exhausted as its existing ordinary Vec initially; admitting that separate
product is not necessary to retain a Point-owned mask. The enum must retain the
Vec-size niche; add actual final production size/layout assertions.

Use distinct consuming helpers map_mask, extend_mask, append_exhausted and
merge_mask. Plain/Plain arms execute the exact previous Vec bodies and iterator
types. Owned arms never return an uncharged Vec:
- Checked label map allocates a new charged destination while source owner lives.
- Aggregate promotion from Plain+Owned builds a charged destination while both
  source values live, then drops sources. This is the real larger owner.
- Owned target may append in place only after proving existing capacity is
  sufficient. Otherwise admit a full replacement before any allocation.
- Owned merge sorts/compacts in place without reducing capacity charge.
  Preserve current handling of ordering/adjacency/empty ranges exactly.
- No shrink_to_fit or unadmitted reserve/realloc. No capacity-sized 256 shortcut;
  the actual shared aggregate can contain 257 ranges.

Required direct-copy/mutation sites:
stages.rs public Point map, retained mapping, Domain callback, bus aggregate;
shared_eq.rs read_shared_input; authored_eq.rs raw append and wide/tile aggregation;
sound_events.rs and beat_sounds.rs fade/outer-silence additions; routed.rs and
retained_sound_input.rs maps/moves. A public block field receiving an Owned mask
must become opaque Mask<S>; no final into_vec convenience conversion is allowed.
Compile errors identify moves, but every .extend/.append/.push/.collect must be
reviewed for capacity-changing behavior and complete old Plain equivalence.

In shared_eq/original_inputs.rs resident(block), keep the exact current capacity
formula for Plain. For Owned count zero mask payload there because its Box+Vec
already live in the controller account; retain ordinary ReadBlock/outer-Arc
shell, PCM/dependency and exhausted charges. Cached Arc<ReadBlock> pins the owned
mask naturally; eviction needs no mask charge transfer or early release.

## Smallest executable split and honest remaining edges

A. Generalize the existing active public owner and native builders with current
public Point output still exercising them. Avoid shipping unused account APIs.
B. One tightly coupled native closure: Point SignalBlock owner, controlled
transfer and callbacks, retained/maps/aggregates/cache and receiving public
fields. Initially own a real native copy of ordinary policy output under
admission. No Plan source lease is being transferred in this unit.
C. Afterwards, fresh Point admitted policy and allocation-free final handoff:
preallocate Box<Option<Storage>> under a real shell guard and move the precise
guarded Plan Vec plus its capacity charge into it. This replaces B's ordinary
native copy and does not change Root/Domain grids or policies.

Do not split B midway by detaching into a plain Vec to satisfy old signatures.
The existing direct consumers that discard mask after use, including
PreparedBlock::from and Bound numerical spans, should simply destroy it and
release its charge.

One edge requires explicit scope rather than inference: shared component
mix code consumes input policy then independently constructs a new bus mask
through Output.suppressed: &mut Vec. Keeping the input owner alive proves that
input's lifetime; it does not admit this separate destination. If B promises
that bus destination, its output adapter must receive the same MaskContext/
owning builder BEFORE allocation, including its pre-admitted multiple-output
capacity and existing Graph charge owner. If it is already physically charged
to Graph, transfer that precise charge or avoid double billing. Otherwise keep
it explicitly outside B's claim and do not say all renderer suppression is
admitted. Do not invent a post-hoc lineage tag after allocations have occurred.

Before B, freeze exact Plain callback/map/aggregate capacity traces and actual
Point/Bound/retained/cache cases, including the 257-range aggregate. New owned
work/residency has independent receipts and error prefixes. Caps remain fixed;
no refunds or normalized frozen-body fields.
