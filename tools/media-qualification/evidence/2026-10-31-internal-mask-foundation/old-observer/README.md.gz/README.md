# OLD internal suppression path observer candidate

Scratch-only additive observer based on published ebb779155a776f0c25ffaf407e27a7d5cf6286f3. No root edits, Cargo/rustc/native runs, capture, expected-body generation, Git, internal owner/account implementation, cap raises, old-work changes or fixed trace-slot expansion.

## Delivery

New source:
new/crates/deadpan-audio/src/bound_reads/internal_suppression_baseline.rs
31,638bytes; SHAc805f89728ada78271e4023b281bc551525c0bf46984ca47da632c1df12c40f8.

Each per-root patch adds that source and appends only its child module hook to retained_host_baseline.rs. Both fresh before hashes:
655148e4f9aa49f4e532d05b248c38d29f898e047ed8056f15533b04cc60beb6
Both after-hook hashes:
bce6fe598af6a2e97113d6ebc0f058e4b9252683455d161711f9c309717bf1d3
Both patch hashes:
2c042a107456905ed42d8aaa74be4ecebb5980d4900524a3e24b66120f816626

pins.json, before/, after/, apply-check/ and patches/ record exact source/patch provenance and independently reconstructed exact-context patches. Source-before manifests independently pin current Core/Plan/Audio sources, Cargo/toolchain, WAV and the immutable eight-case output before fixture. That fixture remains2,163,557bytes SHAa52d53b51b86311ed3794e38bfeec9b8ce5c3c9027ad8d6ee7b7516c993e18a2 in both roots. All source-manifest inputs were re-read for hash stability; no oracle was changed.

## Ten bounded actual cases

1. private-point-silent-hold: checked public Hold Point, actual private Point read16frames.
2. private-point-source-padding: checked Source with SelectedPlacement selecting16..48 inside a64-frame/WAV0..64 mapping; actual32-frame Point read includes selected endpoint intent and source I/O.
3. private-point-genuine-preserve-bound: checked current b=Preserve(group[SilentHold16,Source48],64→128). The historical document wraps b in an outer Preserve clock128→256. Public FrozenAudioLayout/AudioBindingState produce a b binding on actual PreserveInputPointCeil; public audio_definition/in_point_clock produce the queried Point. Intent is explicit Hold policy INSIDE actual raw Point support, not zero-PCM inference.
4. direct-genuine-preserve-bound-point-transfer: same checked bound-Preserve construction, but borrows actual Bound from ordinary public Point query and calls existing read_bound_at. No private Bound clone, mutation or substitute.
5. aggregate-514-shared-equalizers:514 checked alternating one-frame SilentHold/Source children at FrameRate48000; real source0..1;514-frame general aggregate.
6. aggregate-514-shared-input: same checked construction and request via direct read_shared_input(default).
7. held-public-mask-then-private-point: actual public SilentHold mask remains alive while a later private selected-Source Point read uses the same controller/account.
8. held-public-mask-lower-quota-private-point: same held owner, then lower the resident ceiling to its actual observed live account frames. Record actual native refusal or success; no accepted-work counter is injected and no cap is raised.
9. direct-selected-source-bound-transfer-endpoints: checked selected-Source binding, genuine borrowed Bound read. Source raw-support clipping can yield transfer endpoint masks while the child callback itself has empty policy. Capture retains this distinction.
10. held-public-mask-then-aggregate: actual public SilentHold owner plus514-frame aggregate after its64-frame prefix.

Source-only Placement padding is missing input, not suppression; this candidate deliberately uses SelectedPlacement endpoints and an explicit SilentHold within Preserve instead. The existing cases[1].current Sourcea with empty output mask is not relabeled as positive coverage.

Every construction passes checked public Core document validation and compilation. Historical layout capture/binding assembly is fallible and retained. Native/setup/ordinary input-query errors and missing actual Bound are preserved; a missing Bound produces NotRun with its genuine proof, never a fabricated native error or replacement. No positive mask, callback,257-range count, native Preserve success or cache path is claimed until parent execution.

## Exact observed fields / lifetimes

SignalBlock and ReadBlock snapshots exhaustively destructure their actual current fields: complete PCM f32 bits, sample Vec capacity/Layout, dependencies, relative depth, start where present, suppression and exhausted masks. Masks include literal order, len/capacity/is_empty, requested Layout from capacity, first/last/out-of-range access, iterator hints and full reverse iteration. No range merge, replacement, zero-PCM inference, deep clone or normalization is used.

Actual results remain alive through local ReadWork/provider drop, then controller drop. Snapshots after both drops must equal the original complete returned value. The real result is dropped only afterward. Held public blocks are fully serialized after their method's internal work has dropped, after the later internal read, and after controller drop; they are dropped after the internal result. No public mask owning iterator or public block Clone is required.

Every phase retains existing parent work_snapshot/controller_snapshot and observed real-WAV provider behavior. Controller wrapper adds actual owned_suppression.live_frames. A closed optional Account Observer records actual live frames across controller/internal result/public result drops. None explicitly means no available handle and serializes live_frames:null; it never pretends to read a dead or inaccessible account as0. The final observer keeps the physical hub alive until it drops, so base-only3 is legitimate current behavior.

Warmup uses the actual PUBLIC read_point_domain. Its local ReadWork is inaccessible, so PublicProvider explicitly has no substitute outer zero ledger. Actual public callback identity/provenance/index/layout/cancellation and existing scalar receipts are recorded. Internal provider uses the actual local WorkControl and appends scalar receipts/optional account observer at each real source callback.

Ordinary Point input query is built outside measured native work and retained as the real owning Bound input. Its literal work/capacity/content kinds/public inspection are recorded. Public inspection is explicitly not called an exhaustive private Plan-field serializer; the checked current/historical documents and separate Plan witnesses remain authority for those fields.

## Existing control-flow receipts

No fixed table or production code is modified. Each phase resets/reads existing:
- raw_domain_query_trace: actual product kinds, constructor/full/prefix work and raw-result/nested Root/Point callback lifetimes.
- point_content_query_trace: actual Point constructor/full/prefix work and admitted-result/preflight/numerical/span lifetime overlap.
- point_suppression::work_trace: existing public owner constructor/mapping/ceiling accepted work.
- existing Original flattened/processing/policy/fade scalar receipts and global accepted host-eviction units.

Public warmup receipts remain separate from later internal receipts. No fees are inferred from a whole-read residual. Nested result peaks are recorded rather than prohibited. Before/after snapshots retain work/lookup/canonical/additional counters literally.

The general aggregate reaches its real Graph/Original-input cache route. Graph private node payloads are not directly serialized by this module: existing controller/work/provider/original receipts plus complete returned blocks record observable behavior. This is not a claim to have inspected or solved every private Graph cache ownership field. Future runtime implementation still needs independent transfer/account/cache tests.

## Manual entry points

Prefix:
stages::bound_reads::retained_host_baseline::internal_suppression_baseline

Ignored capture:
capture_old_internal_suppression_paths_v1

Ignored external whole-body regression:
internal_suppression_paths_match_external_old_v1

Schema: old-internal-suppression-paths-v1

Capture env:
DEADPAN_INTERNAL_SUPPRESSION_OUTPUT (fresh absolute/tmp file)
DEADPAN_INTERNAL_SUPPRESSION_VARIANT (main-inherited or scoped-published)
DEADPAN_INTERNAL_SUPPRESSION_SOURCE_SHA256 (actual parent guarded source manifest digest)
DEADPAN_INTERNAL_SUPPRESSION_PUBLISHED_CHECKPOINT (full ebb779155a776f0c25ffaf407e27a7d5cf6286f3)

Regression env: DEADPAN_INTERNAL_SUPPRESSION_EXPECTED, an independent immutable actual before body. Only outer variant/source_sha256 are removed. Checkpoint/prior body hash and every actual output/state/receipt remain compared. The producer constructs its complete body before create_new, pretty-writes, flushes and syncs.

## Verification / owed execution

Rustfmt parsed the candidate; rustfmt --check skip_children passed candidate plus both after-hook files. Exact unified diff reconstruction checked every context/deletion and output byte. No compilation or native execution occurred. Parent owns both-root compile, all actual source/WAV/setup errors, fresh capture/equality, positive-mask/raw-callback/257-range adjudication, and freezing before internal production ownership changes. There is no expected body here.
