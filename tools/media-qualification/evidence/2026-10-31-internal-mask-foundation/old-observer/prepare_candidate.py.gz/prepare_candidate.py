from pathlib import Path
import hashlib,json,difflib,re
s=Path(__file__).resolve().parent
roots={'main-inherited':Path('/Users/michael/Code/deadpan'),'scoped-published':Path('/tmp/deadpan-query-groundwork-2026-10-26/scoped')}
existing='crates/deadpan-audio/src/bound_reads/retained_host_baseline.rs'
new='crates/deadpan-audio/src/bound_reads/internal_suppression_baseline.rs'
hook='\n#[path = "internal_suppression_baseline.rs"]\nmod internal_suppression_baseline;\n'
pins={}
for variant,root in roots.items():
 before=(root/existing).read_bytes()
 assert b'internal_suppression_baseline' not in before
 assert not(root/new).exists()
 p=s/'before'/variant/existing;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(before)
 after=before+hook.encode()
 p=s/'after'/variant/existing;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(after)
 data=(s/'new'/new).read_bytes()
 patch=''.join(difflib.unified_diff(before.decode().splitlines(True),after.decode().splitlines(True),fromfile='a/'+existing,tofile='b/'+existing))
 patch+=''.join(difflib.unified_diff([],data.decode().splitlines(True),fromfile='/dev/null',tofile='b/'+new))
 dest=s/'patches'/(variant+'.patch');dest.parent.mkdir(exist_ok=True);dest.write_text(patch)
 # Independent exact context/deletion reconstruction, without Git or root writes.
 lines=patch.splitlines(True);cursor=0;produced={}
 while cursor<len(lines):
  assert lines[cursor].startswith('--- ')
  oldname=lines[cursor][4:].strip();cursor+=1
  assert lines[cursor].startswith('+++ ')
  name=lines[cursor][4:].strip().removeprefix('b/');cursor+=1
  original=[]if oldname=='/dev/null'else(s/'before'/variant/name).read_text().splitlines(True)
  used=0;out=[]
  while cursor<len(lines)and not lines[cursor].startswith('--- '):
   m=re.match(r'@@ -(\d+)(?:,(\d+))? \+(\d+)(?:,(\d+))? @@',lines[cursor]);assert m
   target=max(int(m[1])-1,0);assert used<=target
   out+=original[used:target];used=target;cursor+=1;removed=added=0
   while cursor<len(lines)and not lines[cursor].startswith(('--- ','@@ ')):
    line=lines[cursor];cursor+=1;assert line[0]in' +-'
    if line[0]in' -':
     assert original[used]==line[1:];used+=1;removed+=1
    if line[0]in' +':out.append(line[1:]);added+=1
   assert removed==int(m[2] or 1)and added==int(m[4] or 1)
  out+=original[used:];result=''.join(out).encode()
  expected=s/'new'/name if oldname=='/dev/null'else s/'after'/variant/name
  assert result==expected.read_bytes()
  p=s/'apply-check'/variant/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(result)
  produced[name]=hashlib.sha256(result).hexdigest()
 assert(root/existing).read_bytes()==before
 pins[variant]={'existing_path':existing,'before_sha256':hashlib.sha256(before).hexdigest(),'after_sha256':hashlib.sha256(after).hexdigest(),'new_path':new,'new_bytes':len(data),'new_sha256':hashlib.sha256(data).hexdigest(),'patch':str(dest.relative_to(s)),'patch_sha256':hashlib.sha256(patch.encode()).hexdigest(),'exact_scratch_patch_roundtrip':produced}
 manifest={}
 names=['Cargo.toml','Cargo.lock','rust-toolchain.toml','native/deadpan-source/tests/audio-fixtures/pcm-stereo-48000.wav','crates/deadpan-audio/tests/fixtures/owned-suppression-output-baseline-v1/snapshot.json']
 for crate in['deadpan-core','deadpan-plan','deadpan-audio']:
  names.append(f'crates/{crate}/Cargo.toml')
  names += [str(p.relative_to(root))for p in sorted((root/f'crates/{crate}/src').rglob('*.rs'))]
 for name in sorted(set(names)):
  p=root/name
  if p.exists():
   b=p.read_bytes();manifest[name]={'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
 raw=(json.dumps(manifest,sort_keys=True,indent=2)+'\n').encode()
 (s/f'source-before-{variant}.json').write_bytes(raw)
 for name,pin in manifest.items():assert hashlib.sha256((root/name).read_bytes()).hexdigest()==pin['sha256']
 baseline=manifest['crates/deadpan-audio/tests/fixtures/owned-suppression-output-baseline-v1/snapshot.json']
 assert baseline['sha256']=='a52d53b51b86311ed3794e38bfeec9b8ce5c3c9027ad8d6ee7b7516c993e18a2'
 pins[variant]['source_manifest_sha256']=hashlib.sha256(raw).hexdigest()
 pins[variant]['source_manifest_files']=len(manifest)
 pins[variant]['prior_native_baseline']=baseline
(s/'pins.json').write_text(json.dumps(pins,indent=2)+'\n')
print(json.dumps(pins,indent=2))
