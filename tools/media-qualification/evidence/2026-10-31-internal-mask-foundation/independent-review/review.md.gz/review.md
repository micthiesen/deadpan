# Step A generic mask and OLD observer review

No material finding in current step A implementation. Both current module
copies are pinned beside this review; scoped SHA:
3318de50f53cce1093f53b5d0f5a961c2007a8a9b60359c5da05e460603bd254.

Read-only source review plus inspection of a parent-produced capture.
No builds, native execution, rustc probes, root edits or Git operations.

## Minimal API and implementation assessment

The current implementation is the preferred minimal step:

- Storage<S>, OwnedMask<S>, Value<S>, SuppressionMask<S>, bounded by MaskSample.
- Public PointSuppressionMask remains the concrete ReferenceSample alias.
- Private sealed::Sample permits only ReferenceSample, SignalSample and
  AudioSample. Public MaskSample requires Copy, Eq, Debug and Serialize.
- There is no sample conversion method, erased i64 representation, generic
  cross-label equality, mutation API, owned iterator, detach or new builder.
- All existing immutable APIs remain the same typed slice operations.
  Manual generic Default creates Vec::new without demanding S: Default.
  Serialize uses a distinct serializer type parameter and the same typed
  slice-sequence serialization.
- Current public mapper retains its complete prior operation/control/work order.
  payload_frames(count) stays the Reference wrapper around active private
  payload_frames_for::<ReferenceSample>; this avoids unconstrained generic
  inference at current callsites and preserves the old current API.
- Generic Storage keeps Vec before Charge. OwnedMask still takes its Box,
  unboxes through the noinline helper, drops Vec, then drops Charge.
  Outer Value/Mask have no Drop. AccountData/Handle/Charge are unchanged.
- The generic marker adds no field or allocation. Current layout test covers
  all three concrete mask/Vec Layout equalities, Storage40 and one-range
  payload7. The new shared-account test retains distinct signed values and
  checks total24 then17,10,3 as the three typed owners drop.

This is an active generalization of the already used Reference owner, not an
unused reservation framework. Keep builder/transfer/mutation APIs out until
their actual native consumers are integrated. A public generic type in the
private module can be reachable through the existing public alias; no public
Vec constructor or wider export is required merely to perform step A.

Actual runtime/strict compilation of the generic monomorphizations remains the
parent's verification. Type name/ABI identity is not claimed; JSON values,
capacity, charge and existing current mapper work semantics are the contract.

## OLD observer: actual setup and path coverage

The candidate uses checked public documents and retained historical layouts,
then actual readers; it does not synthesize private mask ranges.

Document validation, compilation, Point construction and ordinary query errors
are retained as values. A missing/failed Bound query becomes explicit NotRun.
Bound is borrowed from the actual ordinary query; there is no private replacement
when that query lacks one. Unwraps in fixed rates/ranges/id helpers are constant
fixture construction, not swallowed runtime setup failures.

The ordinary input query is explicitly outside measured work and is retained
through the actual Bound read. The measured work/provider objects are genuinely
local; internal result then leaves that scope and is inspected after work drop,
provider drop and controller drop. Public warmup owns its real inaccessible
local ledger and is not attributed to a surrogate ReadWork. Held result,
closed account observer, controller and internal result have distinct drop
snapshots. Provider callbacks report an unavailable observer as None rather
than inventing zero residency.

The inspected parent-produced canonical body is:
- 6,553,153 bytes;
- SHA e81a3ecd80ad0155e754e7a708e14efd6f045613deab797154ef0999b266e076;
- all ten setups Ready;
- nine actual successes and one real resident-limit refusal;
- direct genuine Preserve Bound success: mask1/capacity4 and one nested Point
  callback;
- selected Source Bound endpoint success: mask1/capacity4 and one nested Point
  callback;
- both 514-frame aggregates: 257 ranges/capacity257;
- held public Point result remains live during the subsequent actual read.

These are observations from the supplied saved body, not runs by this reviewer.
The capture does not independently cover retained-label mapping, Original
cache publication, every transfer entrypoint, future aggregate ownership, or
every failure/cancellation phase. Prior captures/tests may cover those paths;
this ten-case observer should not be described as their replacement.
The external regression compares the complete matrix after stripping only
variant/source identity.

## invalid:true is an attribution limitation, not reset contamination

In held-public-mask-then-private-point:

- receipts before the internal read are reset and invalid:false;
- Point accepted_work is36;
- actual canonical2 + additional24 is26;
- host eviction is0;
- independently accepted owned-account residency work is10;
- therefore36 = 26 + 10;
- result creations1 and drops1, final live_results0, active_depth0;
- nested:false and overflow:false.

Admission::reserve calls make_room, whose active owned account check spends a
host unit. Point ScopeGuard subtracts only host eviction before comparing its
gross selected-lane delta with the Plan query's26 units. It therefore flags the
real extra10 host units invalid. The current reset/lifetime evidence is clean.

The held lower-quota refusal similarly records partial_work6, including one
independent owned-residency unit. invalid:false on that failed construction
does not establish that all six are a pure Plan forwarded prefix.

Preserve the immutable body's actual invalid:true and literal counters.
Do not clear it, move resets, inflate canonical/additional query units, or
rewrite accepted work to26. Future receipts should add an independently scoped
host-residency lane and retain the full native debit, with before/after
attribution to the actual Point constructor interval. That work must stay
separate from query canonical/additional and real host evictions.
