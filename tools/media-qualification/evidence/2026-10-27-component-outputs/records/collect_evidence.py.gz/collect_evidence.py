from pathlib import Path
import gzip
import hashlib
import json

scratch = Path(__file__).resolve().parent
dest = Path('/Users/michael/Code/deadpan/tools/media-qualification/evidence/2026-10-27-component-outputs')
assert not dest.exists(), 'refuse evidence overwrite'
for label in ['build', 'audio-lib', 'strict', 'full-stages', 'audio-definition',
              'scoped-build', 'scoped-audio-lib', 'scoped-birth-pcm']:
    receipt = json.loads((scratch / (label + '.json')).read_text())
    assert 'exit_code' in receipt and receipt['sources_unchanged'] and receipt['binaries_unchanged']
    assert receipt['exit_code'] == (101 if label == 'full-stages' else 0)
summary = json.loads((scratch / 'regression-summary.json').read_text())
assert summary['all_sources_and_executed_binaries_stable']
dest.mkdir(parents=True)
files = []
for path in sorted(scratch.iterdir()):
    if not path.is_file() or path.suffix not in {'.json', '.py', '.md', '.patch', '.rs', '.before', '.stdout', '.stderr', '.txt'}:
        continue
    data = path.read_bytes()
    compressed = gzip.compress(data, mtime=0)
    out = dest / 'records' / (path.name + '.gz')
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_bytes(compressed)
    files.append(dict(path=str(out.relative_to(dest)), bytes=len(compressed),
                      sha256=hashlib.sha256(compressed).hexdigest(), expanded_bytes=len(data),
                      expanded_sha256=hashlib.sha256(data).hexdigest()))
inventory = dict(schema_version=1, base_revision='a8b35993',
                 scope='Six-file Components borrowed-output primitive. Scalar runtime remains single-output; recursive batching is not enabled. Main 208 Audio/171 definition/203 prior stages pass; seven unfinished Split cases remain four pass/three work failures. Isolated published-runtime patch passes 191 Audio and eight birth/processing PCM tests. Strict lint and independent review pass. No product acceptance credit.',
                 runtime_baseline_evidence=dict(path='../2026-10-27-input-index/inventory.json',
                     inventory_sha256='1f355b2da5f6c5bb76e62c242c1cee9c799e9e413397c077e61c88d0b797a780',
                     note='Main retains inherited general-Split and index WIP. Scoped lineage instead starts from the published-runtime placement receipt and overlays only the exact six-file patch. No redundant executable/source-tree archive.'),
                 files=files)
out = dest / 'inventory.json'
out.write_text(json.dumps(inventory, indent=2) + '\n')
for row in files:
    data = (dest / row['path']).read_bytes()
    expanded = gzip.decompress(data)
    assert len(data) == row['bytes'] and hashlib.sha256(data).hexdigest() == row['sha256']
    assert len(expanded) == row['expanded_bytes'] and hashlib.sha256(expanded).hexdigest() == row['expanded_sha256']
print(json.dumps(dict(payloads=len(files), stored_bytes=sum(row['bytes'] for row in files),
                      expanded_bytes=sum(row['expanded_bytes'] for row in files),
                      inventory_sha256=hashlib.sha256(out.read_bytes()).hexdigest()), indent=2))
