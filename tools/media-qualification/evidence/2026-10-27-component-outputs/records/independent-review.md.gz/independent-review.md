# Independent review: scoped Components outputs refactor

Scope reviewed: supplied `components.patch` against the pinned per-file before snapshots, with current source inspection limited to `shared_components.rs`, `shared_components/block.rs`, `shared_components/program.rs`, `shared_components/program/tests.rs`, `shared_components/outputs.rs`, and `shared_components/outputs_tests.rs`. The unrelated `generalSplit` WIP was excluded.

## Findings

No supported correctness findings in the requested lens. The one-output wrapper preserves the legacy per-route final addition order and work accounting; multi-output selection is per target (including aliases), applies final gain once for a route shared by targets, retains route-order f64 sums, and emits target-specific suppression. Constant send uses and overwrites the first destination only after capturing each frame's common send; dynamic send retains the same common-send behavior. All sink shapes and suppression capacities are checked before any sink is mutated or callback runs. Multiple-output suppression is bounded by `frames` entries and requires sufficient preallocated capacity. Runtime graph integration remains out of scope and still requests one output.

## Verification limits and material gaps

- No Cargo build or tests were run, per task instruction and because the main Cargo build is active. The worker notes also explicitly make no compile/execute claim.
- Existing tests cover scalar oracle equality across constant/dynamic, aliases, send, skip/stop, suppression, invalid sink prevalidation, unrequested final-gain failure, callback/cancellation, and work limits. They are pure four-frame Components fixtures; they do not exercise real provider/reader integration, recursive graph batching, or prove a recursive peak-memory admission bound. Those are explicitly outside this primitive's contract.
