# Wet processor construction versus retained residency

Read-only source audit, 2026-10-27. No source edits, Cargo, new measurements, limit changes, or batching authorization.

## Finding and preferred narrow change

A distinct retained bound is justified by ownership. Keep the complete existing preparation admission through successful FiniteWetEffect::new(), then retain **the entire existing CausalStereoFilter::native_bytes_bound(taps)**. Only release the additional Rust coefficient/network construction allowance:

  preparation = native_bytes_bound(taps) + taps*2*sizeof(f64) + 1,048,576
  retained    = native_bytes_bound(taps)

There is no existing retained/resident API for this processor. An appropriately documented FiniteWetEffect::retained_bytes_bound(effect) could expose the formula. An instance method is also viable if avoiding any possibility of an effect/processor mismatch; the installed processor's descriptor supplies its exact history. This is accurate lifetime accounting for freed construction storage, not a lower native-memory estimate.

| Effect | Preparation bytes | Retained conservative bytes | Released after successful construction | Retained ledger units | Released units |
|---|---:|---:|---:|---:|---:|
| Reverb,192001 taps | 38,723,600 | 34,603,008 | 4,120,592 | 4,325,376 | 515,074 |
| Delay,384001 taps | 75,350,032 | 68,157,440 | 7,192,592 | 8,519,680 | 899,074 |

Each number divides exactly by8. The two retained processors together would occupy102,760,448 charged bytes, leaving30MiB of the existing128MiB-equivalent default ledger before all other reservations. This does not prove batching or either failing request fits.

## Exact ownership and drop points

1. finite_wet.rs:58-84, finite_wet_coefficients:
   - Allocates two Vec<f64>, each exactly history_frames+1 elements using vec![0.0;count].
   - Creates a local Box<dyn Effect> via hold_effects::effect_engine.
   - The engine generates the impulse response, then the function returns only the two coefficient Vecs.
   - The boxed engine is dropped before this return reaches FiniteWetEffect::new. Its allocation and all delay-line Vecs are gone before C++ filter construction starts.

2. hold_effects.rs:209-362:
   - Reverb owns two Vec<Comb> and two Vec<AllPass>, whose DelayLine members each own a Vec<f64>. The left eight comb/four allpass lengths and right lengths+25 are fixed. No member escapes the local boxed engine.
   - Delay owns two DelayLine Vecs of14,400 f64 samples.
   - Neither engine uses shared ownership, thread-local state, a global cache, nor leaks a delay line to the coefficient output.
   - The extra1MiB in preparation_bytes_bound is explicitly documented as covering this temporary network's delay lines and metadata. Do not reinterpret it as native retained-state slack.

3. finite_wet.rs:93-99, FiniteWetEffect::new:
   - Local coefficients are passed by shared slice to CausalStereoFilter::new.
   - The returned Self stores only effect and filter.
   - After the cancellation check succeeds, returning Self drops the local coefficient arrays before control reaches its caller. There is no coefficient Vec in Self.
   - Cancellation after native creation drops both filter and coefficient Vecs. Failure during coefficient generation drops its partial engine/Vecs. No successful installed processor exists on either error path.

4. native/deadpan-dsp/src/ffi/causal_filter.rs:28-47:
   - CausalFilterEngine stores only a NonNull native handle.
   - Create is synchronous; no Rust kernel pointer survives it. The FFI comment promises copied kernels, and the C++ source establishes that ownership below.
   - Drop destroys that native handle exactly once.

5. native/deadpan-dsp/src/causal_filter.cpp:43-65:
   - CausalFilter owns its RealFFT object, two complex kernel spectra, time buffer, spectrum, product, and inline stereo staged outputs.
   - Constructor's coefficients pointer array is local. Each channel is copied into owned time, FFT-transformed into an owned kernels vector. Neither input pointer is stored.
   - CausalFilter::read uses those same retained vectors and FFT workspace. It overwrites time/spectrum/product/staged on every tile.
   - Those arrays remain alive until dp_dsp_causal_destroy. Releasing them as construction scratch would be wrong.

6. vendor/signalsmith-linear/fft.h:
   - RealFFT retains complexFft, tmpFreq, tmpTime and twiddle vectors (around957-999,1352-1358).
   - The underlying SplitFFT/Pow2FFT retains its own work, twiddles and plan vectors (around159-160,458-478).
   - “tmp” or “working” in a name does not mean constructor-only. FFT and inverse calls use them.
   - Keep their complete existing bound. No new FFT allocation formula is needed for the narrow release.

The Rust FiniteWetEffect/filter/handle scalar headers live inline in Graph.wet_filters, not in a separately retained Rust coefficient/network allocation. Normal allocator page retention after Vec drop is not an owned-buffer lifetime and does not turn this ledger into an RSS limit.

## Existing evidence and what it does not justify

The current raw ABI test native/deadpan-dsp/tests/causal_filter_abi_probe.cpp measures both native_peak_bytes and native_resident_bytes, injects every constructor allocation failure, checks zero processing allocations, and checks all native allocations are released on destruction.

The retained qualification report tools/audio-qualification/evidence/2026-10-12-finite-wet/causal-abi-final.json records:
-192001 taps: peak=resident=23,659,040 bytes; bound34,603,008.
-384001 taps: peak=resident=47,252,000 bytes; bound68,157,440.
All eight recorded cases have peak==resident. The sanitized-final report gives the same ownership result. These are existing observations, not a new run.

The gap between measured native bytes and the conservative native bound is **not** evidence of freed construction workspace. Lowering native_bytes_bound to those measured values would be a separate portable bound derivation/qualification task. This proposal keeps all that slack.

The proven removable part is the Rust coefficient Vecs plus the separately documented temporary network allowance. Actual network and coefficient storage do not overlap for the whole constructor, but keep the current preparation sum rather than changing its peak formula in the same patch.

## Integration point and accounting order

event_returns.rs:583-613, process_shared_wet is the only production consumer of FiniteWetEffect::preparation_bytes_bound. It currently:
  computes preparation units;
  spends history_frames+1 work;
  make_room(preparation);
  calls FiniteWetEffect::new;
  control.check();
  adds preparation to active_frames and graph.resident;
  installs graph.wet_filters[slot].

Preferred change, if later authorized:
- Preserve the same history work, cancellation/deadline checks and full make_room(preparation) admission before construction.
- Keep that preparation headroom until new() has returned successfully and its local arrays have dropped.
- At the existing successful publication point, add retained units, not preparation units, to active_frames and graph.resident.
- Install the same processor in the same slot, then run process_tile exactly as today.
- Existing Graph teardown subtracts graph.resident, so it must subtract the retained amount actually added.
- No work counter refund, prepared-frame change, cache authority change, native filter change, or deadline reset is involved.

Current code guards construction headroom with make_room but adds active_frames only after construction. This is safe for its synchronous constructor because new() performs no recursive StageAudio admission or callback; exclusive &mut StageAudio prevents another controller allocation. Keeping that sequence avoids introducing a new partially initialized reservation lifetime. If a reservation RAII guard is introduced instead, all failure/cancellation paths must release it exactly once and successful publication must replace only its preparation portion with retained storage.

Do not reduce the constructor make_room to retained: during native create the complete Rust kernel remains live alongside native arrays. Do not release anything after make_room but before new() returns. The effect slot remains one per kind per Graph; this change must not alter that sharing.

## Focused verification needed for an implementation

1. API formula tests for both effect kinds: preparation == retained + taps*16 +1MiB; retained == existing native_bytes_bound; preparation>retained. Keep existing full-preparation bound test.
2. Real process_shared_wet ledger test: after first successful construction, active_frames/graph.resident increase by retained amount; second same-kind call does not add it again; Graph cleanup restores the initial amount.
3. Constructor budget boundary: a budget that fits retained but not preparation must still refuse before constructing. Exact preparation admission succeeds. Existing history work remains identical.
4. Cancellation before construction, after construction/publication check where injectable, and native failure: no installed slot and no leaked ledger increment/handle. No fake ledger refund of work.
5. Existing causal ABI allocation-lifetime/processing-allocation witness plus finite-wet PCM tests. A small Rust allocator witness can directly confirm coefficient/network lifetimes if desired, but source ownership already proves they cannot be retained by Self. Native measured peak values must remain evidence, not constants in a portable bound.
6. Full StageAudio regression and existing real-WAV cases under unchanged limits. Any improvement only establishes accurate resource accounting; batching remains a separate resource/semantics gate.

Ordinary owner EQ FFT state, decoder caches and one bounded source/resampling halo keep their existing separate accounting status. The wet processor is explicitly included in the ledger today; retaining its complete native bound preserves that inclusion.
