# Borrowed output types and pure Components tests

Worker ownership was limited to two NEW files:

- crates/deadpan-audio/src/shared_components/outputs.rs
- crates/deadpan-audio/src/shared_components/outputs_tests.rs

No existing source, Cargo, graph runtime, source provider, plan ownership or preparation limit was changed by this worker. Parent owns integration/driver/formatting of its files, all builds, tests, docs and Git. Only these two files were rustfmt'd, with skip_children=true. Trailing-whitespace audit passed. No execution or compilation claim is made.

`worker-files.json` pins exact bytes and `worker.patch` contains just these two additions.

## Contract

OutputSelection holds target voice and its own alias Permissions; selects performs no union or authority inference. The types have pub(in crate::stages) visibility to permit the parent's existing pub(super) reexport from shared_components. Fields and helper methods remain pub(super) to shared_components and its children. This is internal visibility only.

OutputSamples borrows interleaved stereo or planar channel slices. frames returns None for unequal planar lengths; frame/set/add preserve exact channel order with no reassociated sum. clear writes positive zero. From conversions construct either borrowed layout, including a real planar constructor outside cfg(test). No PCM/cache/owned output allocation occurs here.

Output.validate checks full frame shape and empty optional suppression vector. Multiple-output suppressors must have capacity>=frames, so at most one pushed range per frame cannot grow them. Single-output suppressors retain the explicitly agreed legacy Vec growth behavior. mark_suppressed appends unit ranges; finish_into returns those unmerged and tests normalize them only after borrowed sinks are no longer used. The scalar wrapper retains merged_suppression. A partial execution error leaves output scratch unspecified; invalid shape is expected to be detected for ALL destinations before callback or buffer mutation.

## Six authored tests

1. borrowed_layouts_preserve_channel_addition_and_selection: interleaved/planar bit equality, left/right operations, cancellation-prone route-order addition (1e16+1-1e16), signed zero and selectors.
2. multiple_outputs_match_independent_dynamic_oracle_for_aliases_sends_skip_and_stop: batch constant AND dynamic drivers against independent single-output dynamic render_selection, four targets in explicit order (voice1, voice0+alias1, all, absent17), planar/interleaved sinks, gain order, mute, tail send mode, skipped root and stopped inner owner. Exact sample bits, normalized suppression and unchanged suppressor capacities. The common callback sequence per sample equals ONE oracle sequence rather than one sequence per output.
3. multiple_outputs_traverse_once_and_spend_less_than_independent_constant_calls: same local builder for batch and independent constant single calls, exact raw callback sequence, bitwise outputs and strict actual-work savings. This avoids attributing savings to the existing fixture's separate checkpoint-inspection overhead.
4. output_validation_precedes_callbacks_and_all_buffer_mutation: later invalid sink (short interleaved, unequal planar, nonempty suppression or insufficient multiple capacity) rejects before callback or any earlier/later buffer/suppression mutation.
5. unrequested_final_gain_failure_stays_unconsumed_but_aliases_consume_it: admitted finite routes with an enormous final event gain; an unrequested bad voice does not fail, while a required alias consumes it and returns InvalidSamples.
6. multi_output_callback_cancellation_and_exact_work_failures_propagate: callback error, cancellation, exact measured finishing allowance and one unit less. New work is never reset/refunded during execution.

The four-frame builder copies the existing deterministic program fixture's two admitted routes, concrete owner clocks, per-frame permissions, dry/wet values and event gain. It deliberately performs no media I/O and makes no source-admission assertion. Parent made program::tests visible plus plan/render_selection callable within shared_components; the tests depend on that agreed wiring and on Components::finish_into. No runtime graph batching or recursive-memory reservation proof is implied by this milestone.
