# Required-output runtime batching: resource bound research

Read-only source audit, 2026-10-27. No repository edits, Cargo, or execution claims. The six Components output files remain frozen. Paths and line anchors below refer to the current shared checkout; this note does not authorize runtime batching.

## Decision

A small whole-structure bound is possible in principle, but the existing Plan summary is not sufficient to make it useful for the failing retained-clock fixtures. Do not admit a batch from N input histories plus the authored effect count, or from one warm scalar peak.

For the interval while extra histories are live, the missing information is a finite structural demand summary: instantiated temporal contexts, their possible tile intervals and permission sets, and distinct intrinsic preparation inputs/extents. A bounded scalar preflight can compute conservative versions without keeping query graphs or PCM. An even smaller first implementation can refuse every intrinsic projection and explicit Tail and use a compact structural fold for the remaining graph. It still needs to account for retained clock/delivery scopes and permission breakpoints; refusing all retained clocks would exclude the target Split cases.

There is no demonstrated default-budget fit for these fixtures yet. Authored stage/Repeat counts alone are not that demonstration. The right next proof step is a read-only summary for one exact failing request, with all bounds reconciled against the reservation formulas below, before implementing a runtime batch.

## Existing ledger and exact formulas

StageLimits is explicitly a PCM-equivalent residency limit, not an RSS limit (stages.rs:118). Default maximum_resident_frames is 16,777,216 units; one unit is 8 bytes. Existing caches, active reservations and ReadWork.projected_resident_frames share it. Native FFT state other than the explicitly reserved wet/event processors, decoder caches, and one bounded resampling halo are separate. Do not start charging those excluded allocations merely to call the result a total-memory proof.

All counts below are ledger units. Let I be full native input frames, O output frames:

| Kind | I | O | scalar shared tile reservation 2(I+2O) | retained output tile 2O | extra input history per extra target 2I |
|---|---:|---:|---:|---:|---:|
| EQ | 5,120 | 1,024 | 14,336 | 2,048 | 10,240 |
| Reverb | 196,096 | 4,096 | 408,576 | 8,192 | 392,192 |
| Delay | 388,096 | 4,096 | 792,576 | 8,192 | 776,192 |

Source: shared_eq.rs:748-895. Event return tiles add 2,048 units to the scalar reservation; event Prefix has I=O=1,024 and no temporal history (event_returns.rs:242-414). Event loops clamp actual recursive reads to allocation and audible support, but the full native arrays are still allocated. Shared owner tile loops visit the whole fixed input interval, including blank context.

Extra Reverb input history is 3,137,536 bytes; extra Delay input history is 6,209,536 bytes. If native filtering/conversion stays sequential, do not multiply the scalar output-workspace reservation by N. Reserve all N input histories, one native output/conversion workspace at a time, and every already-finished retained tile. New target/sink/dependency/alias carriers require their actual additional storage bound.

One shared wet processor per effect per Graph is reserved by event_returns.rs:583:
- Reverb preparation_bytes_bound: 38,723,600 bytes = 4,840,450 units.
- Delay: 75,350,032 bytes = 9,418,754 units.
Both together consume 14,259,204 units, leaving 2,518,012 units before other reservations under the default limit. Subtract processors already present when calculating *future* additions. The conservative bound includes temporary kernels/network arrays and remains charged after construction.

Event EQ filters reserve 2,129,928 bytes = 266,241 units each. Ordinary owner EQ construction in shared_eq_node is not charged to this ledger; that is an existing explicit exclusion, not free physical memory.

read_shared_input (shared_eq.rs:164-254) holds 3*requested_frames plus sizeof(original_inputs::Cache)/8 throughout one Graph. A chunk holds 12*frames + mix.resident_frames(), frames<=256 (shared_eq.rs:440). Components::resident_frames (shared_components.rs:198) reserves:
  ceil((routes*(frames*sizeof(Sample)+GainSum::maximum_bytes)
       + sum Program::resident_bytes(route)
       + frames*sizeof([f64;2])
       + optional GainSum::maximum_bytes)/8).
Sample is the value/send_input/permitted carrier. Use sizeof and Program::resident_bytes/layout directly rather than guessed platform constants. SharedMix's nonseparate path instead uses (buses+1)*frames*(2+64) units (shared_mix.rs:399).

Routes are allocated for all discovered candidates, including currently unpermitted/dormant routes. The input permission mask or number of demanded outputs cannot bound this allocation alone. Program preparation can omit inactive routes, but the current full future-program estimate reserves them conservatively before allocation.

Intrinsic preparations:
- reserve(input,output): 2*input+output (stages.rs:2128).
- reserve_stream: 2*min(input,65,536) + (output when memory-backed, otherwise 2,048 file-buffer units), plus 8*output disk bytes when output>maximum_memory_stage_frames (stages.rs:2146).
- prepare_projected releases the transient reservation, then pins the complete output for the rest of ReadWork (stage_projection.rs:64-135).
- PcmWriter chooses memory/file solely from output size and threshold and reserves the complete destination; PCM zero values do not make it turn into Silence (prepared_pcm.rs:140-240).
- Ordinary prepared cache publishing can retain full intrinsic outputs, and cache hits can substitute for cold construction. Disk bytes and slot ceilings are separate from residency.

## Scope the proof to the extra lifetime

There is an important smaller alternative to bounding the remainder of the complete Graph. Allow batching at exactly one current demanded-output group and force every descendant request to scalar execution. Prove the cold scalar dependency subtree while the extra outer histories are live. Once this group releases those histories, normal scalar resource admission resumes.

This is sufficient only if the integration also proves the group leaves no additional required temporal nodes/tile keys/projected identities beyond the union of the scalar calls it replaces. The same actual demanded targets, common context/parent/permission set and per-target aliases are essential here. Native outputs remain processed sequentially. The proof cannot include speculative sibling outputs, a new prefix cache or earlier unneeded projections. Optional raw-cache order may differ, so subsequent cache misses still need ordinary admission; there is no guarantee of a warm hit. If this union/subset invariant is not established, use the broader whole-remaining-Graph bound.

Thus the “future” sums below can cover only the current group's transitive dependency subtree rather than all later independent calls, with that invariant. This avoids needing to count unrelated Graph work after the extra memory is gone. Do not assume this invariant merely from the borrowed-sink API.

## A sufficient conservative equation

At the decision point snapshot existing ledger B without eviction:
  B = cached_resident_frames + active_frames + work.projected_resident_frames.
Those counters already include current Graph retained data and ancestor reservations. Do not count them again.

For the chosen lifetime/scope above, a sufficient (deliberately overcounting) successful-read condition is:
  B + NewInputHistories + NewCarrierStorage
    + AllFutureRetainedTiles
    + AllFuturePinnedProjectedOutputs
    + AllFutureOrdinaryPreparedOutputs
    + FutureOriginalCacheOrPinnedReadAllowance
    + MissingChargedProcessorBounds
    + MaxAdditionalRecursiveTransient <= maximum_resident_frames.

Use only additions not already in B. A simpler implementation may pessimistically count all future outputs as cold and as newly retained, even when a current cache has them, provided it does not subtract the current cached copy. This covers a future cache miss/eviction; it costs eligibility.

The transient term is a maximum over actual prefix-dependency paths, not the sum of all siblings and not maximum_depth*maximum_input_frames. Each path consists of:
- every simultaneously live outer multi-target input history;
- one current chunk's raw/Components reservation at each recursive level;
- scalar/event native output workspace while its ancestors remain alive;
- any intrinsic stage streaming/nonstream reservation on that path.
If descendants can batch, it must include their new history groups too. Do not prove the root N group while letting child groups independently spend the same headroom. Prefer forcing descendants scalar for the first proof; a more general compositional bound must be parameterized by the batching policy at every descendant.

Original PCM payloads need an explicit term too. original_inputs::resident (:264) charges sample capacity, suppressed/exhausted capacities, 1,024 bytes per dependency, ReadBlock/Arc headers and 1,024 bytes controller-node overhead. Cache::resident_frames only covers its fixed identity/index storage. Future optional Original payloads cannot be ignored merely because there are64 slots. A simple safe bound includes their maximum simultaneously live total (using actual route/source/interval bounds); a tighter proof can exclude evictable payloads only by proving the existing eviction path can reclaim them before required reservations. Never sum every optional insertion over the request: old payloads evict. Optional caching already refuses storage or evicts other Original payloads rather than unrelated prepared stages (:420-470); retain that behavior.

Check disk headroom and future controller cache slots separately. A very conservative no-eviction policy can require current slots plus all potentially new ordinary entries <=64. Pinned projected outputs are separate from ordinary cache slots but share residency/disk/preflight stage limits.

The bound is an eligibility proof, not a new charge. Actual existing reservations and every performed query remain billed normally. Do not add the entire future estimate to active_frames and then bill those same reservations again. Exclusive &mut StageAudio ownership means no independent controller allocation can invalidate a local proof; callbacks must not acquire unplanned batches or plan scopes.

## Static facts the equation actually requires

A compact Plan-side fold can count authored tree edges, Repeat run multiplicities and sparse overrides with checked arithmetic without expanding plays. However StorageStats.referenced_plays is a sum of authored counts, not the occurrence count of nested repeats. inspect() exposes kind/duration/ID but not treatment recipes, preserve inputs, gap recipes or all retained layouts; a new narrow Plan-side visitor/summary would be needed.

For each participating live/historical scope the summary must bound:
1. Actual candidate routes/voices and owner layers in every possible 256-frame prefix query, including delivery aliases, stable Repeat paths, current Holds and inactive/out-of-support candidates.
2. Temporal *instances*, not just declared recipes. shared_eq_node reuses by parent, kind, boundary stage and matches_clock_at (shared_eq.rs:660). The same authored owner/stage under different parents or retained affine clocks can create different nodes. Event keys additionally carry parent, voice, stage, allocation, audible bounds and edge flags (event_returns.rs:15).
3. Retained tile key count over the complete Graph lifetime. Owner tiles are keyed by (tile, Permissions, output_voice), not just tile or effect. Earlier finished sibling tiles remain live during later recursion. Taking a maximum active stack omits this accumulation.
4. Exact outward-rounded interval transport through each retained/current mapping, with fixed halos and negative-time blank context preserved. Root duration alone cannot bound a historical local query interval. Nonunity retimes, fractional sample grids and delivery routes require the existing exact arithmetic.
5. The number of structurally distinct permission configurations within those intervals, or a safe upper bound. 2^voice_count is safe but usually useless; demanded-output count is insufficient because nondemanded driver routes and alias families affect masks. Counting endpoint/breakpoint occurrences arithmetically could provide a useful bound, but must include current Hold masks, exhaustion, retained supports, Repeat gaps and transported/rounded boundaries.
6. Distinct intrinsic input identities and output extents, including projected stages hidden inside source occurrences. stage_projection::ProjectionCacheKey explicitly says equal authored descriptors can have different selected live inputs. Counting one output per authored Preserve is unsound.
7. Maximum recursive prefix dependency path and the charged processor effect set; event Prefix tiles count too, despite not consuming a temporal-owner slot.

One can replace some counts with existing limits (e.g.64 temporal nodes) to get a mathematically safe but coarse upper bound. The existing prepared-frame budget alone permits more retained EQ/Prefix PCM than the entire residency budget, so that route does not establish a useful default fit. Summing all possible masks, all64 nodes and every global halo tile likewise tends to reject. This is why a closer scalar demand summary, rather than another query/PCM cache, is the unresolved prerequisite for these fixtures.

A bounded preflight need not retain query graphs: fold one exact query/window at a time into scalar upper counts and checked interval bounds; use compact Repeat multiplicities or decline when arithmetic/structure cannot be summarized. But it must charge every actual query/visit, honor the same per-query65,536 and aggregate16,777,216 work units, and bound its own scratch storage before allocation. Existing allocated_bytes visitors measure already-built graph ownership and explicitly do not bound construction transients (audio_allocated.rs:1-6). They are not a prospective allocator proof. If this preflight is substantial duplicate traversal, quantify its work before proceeding.

## Cold-cache, admission and PCM dependencies

Cache-hit observations cannot certify future cold resources:
- a hit avoids a whole streaming/native preparation while a miss can pin its output;
- ordinary prepared entries can evict; projected outputs remain pinned;
- a Source provider's actual sample rate, layout and decoder state are not established by Plan allocation/count metadata;
- exact source/context/fingerprint and depth admission still run on hits. No resource certificate is media authority.

Plan/current source contracts and existing first-clock compilation stay unchanged. A structural bound can pessimistically include a native source-transform's allowed full input/output caps or decline it; computing actual source-frame length from a provider can require normal authorized admission. Do not resolve sources early merely to make an optimization eligible, or skip unavailable sources because a structural footprint is small.

PCM magnitude influences finite/peak refusals and output values. Do not evaluate gains or process dormant routes in the decision. The upper bound should assume every structurally permitted candidate participates, including zero PCM. PcmWriter output size is deterministic; source resampling is independently bounded by MAX_SOURCE_FRAMES32,706; streamed DSP required windows are bounded65,536. Refusal can only shorten this upper schedule; it must still propagate at the existing execution boundary.

## Excluded physical allocations and the no-multiplication obligation

The ledger proof does not include a new RSS ceiling. Separately preserve:
- ordinary owner EQ native FFT/coefficient state, one per actual node;
- source decoder/session/provider caches and one source/resampler halo;
- StreamingStretch native state;
- baseline query/route/dependency/BTreeMap/path metadata that existing reservations do not explicitly count byte-for-byte.

Direct borrowed sinks must not create N processors, decoder sessions, simultaneous source windows, retained query graphs, route PCM snapshots or historical-plan pins. Perform native filtering sequentially using the existing node filter; wet uses one workspace per effect per Graph acquired only after recursive input preparation. Borrow and consume the current chunk once. A valid common context/parent/permission demand shape should not create more node identities than the same required scalar calls, but that is an integration invariant to test, not something OutputSamples itself proves.

Explicit Tail can create another Graph while the outer Tail reservation is live (stages.rs:2318-2402). That nested Graph has its own wet processor slots and Original cache. Either include it recursively or decline batching for any reachable Tail. Merely seeing one Reverb kind in the project is insufficient to count one processor globally.

## Verification obligations before runtime integration

1. A diagnostic summary for the three failing exact requests showing the bound fits actual custom/default limits, with existing B and every future component listed. A structural bound that only fits a smaller unrelated fixture is insufficient evidence for the product goal.
2. Cold, warm and mixed cache tests; pinned projected output; identical descriptor with distinct inputs; cache entries initially filling slots; memory and disk thresholds; reachability through historical plan scopes; explicit Tail fallback.
3. Actual ledger high-water <= proposed bound for each admitted batch, including every recursive child; exact boundary passes and one-unit less selects scalar before prefix work. A bound miss must not evict or allocate target histories.
4. Repeat2/nested Repeat, sparse gaps/overrides, split births/aliases, fractional44.1/48k clocks, nonunity Preserve/Shift; prove tile intervals, permission and node counts against actual constructed identities.
5. Required native processor counts remain unchanged, no overlapping source windows, new carriers' actual capacities bounded, and no retained query/plan ownership.
6. PCM bitwise oracle, all current permission/Hold/alias/send gates, unconsumed final-overflow laziness, source fingerprint revocation, depth, cancellation and deadline. Cancellation checks in the proof must be bounded; errors after execution starts propagate without retry, deadline reset, counter refund or partial-token reuse.

No present source fact proves a useful whole-structure bound for these retained-clock requests without the missing summary. Prefer demonstrating that summary and its cost before another runtime batching prototype.
