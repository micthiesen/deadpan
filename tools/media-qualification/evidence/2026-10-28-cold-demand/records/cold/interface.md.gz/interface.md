# Proposed narrow parent interface (before implementation)

Only member_phases.rs and member_phases_tests.rs are owned here. Parent supplies
the sealed private CompletedPolicy type in shared_components; no constructor
will exist in this module.

Required contract:
- CompletedPolicy::validate(&self, routes: &[Route], start: AudioSample,
  frames: usize) -> Result<(), StageAudioError>: exact carrier/routes/current
  window pairing and completed metadata population, not allocation alone.
- CompletedPolicy::flags(&self) -> &permissions::SamplePermissions.
- CompletedPolicy::active(&self, route: usize, control: WorkControl) -> Result<bool>:
  scan actual row words, spending before each inspected word. No cached PCM mask.
- Program::constant visibility becomes pub(super); algorithm unchanged.

Child API:
- cold_order(routes, owners, completed, start, frames, control) -> ColdOrder
  validates completion, scans actual admitted route activity, precharges the
  existing layer-level structural constant predicate traversal, and reuses
  Program::constant. No per-route Vec or retained activity table.
- run_cold_owner(routes, OwnerPhase, ColdExtent, completed, control, demand)
  checks exact witness/carrier pairing then enters the SAME private drive_owner
  body as run_owner. Extents are Block / Sample(at); caller's whole traversal
  uses the returned ColdOrder, just as the numerical outer adapters do.
- demand is an HRTB borrowed TemporalDemand callback returning Result<(),Error>,
  not a numerical callback returning a fabricated stereo value.

Internal typed Dispatch distinguishes real numeric callback from metadata demand
callback. Only numeric dispatch writes PCM, evaluates gains/finite sums, applies
transfers, or accumulates returned samples. Cold still traverses actual shared
stage/member/wet loops with real recipe/policy selection and charges every
additional inspection before it happens. A cold error stops at that prefix.

The parent whole cold adapter must preserve outer block owner order or dynamic
sample/owner order and bracket empty traversal with control.check. This child
does not construct any completion witness, own a plan, open media or prove
recursive resource admission. Tests need parent-authorized completed-policy
fixture construction or a parent fixture builder; this module will not use
observed numeric marks as that authority.

Final parent agreements:
- CompletedPolicy has two lifetimes, borrows exact immutable Components, and
  validates with control as an additional argument.
- Cold must use immutable Routes, never mutable aliases of that witness.
- Parent supplies borrowed inspected context helpers and constant_inspected.
- Parent supplies authentic completion::tests::with_completed_fixture and
  CompletedPolicy::visit_demands. Child tests call those directly.
See notes.md for final APIs and full contract; this earlier proposal is retained
as design lineage, not an additional source implementation.
