# Completed cold owner demand dispatch candidate

Scratch only. Based on the frozen four-file numerical owner-driver candidate
under /tmp/deadpan-demand-driver-2026-10-27, not a new repository checkout.
Only member_phases.rs and member_phases_tests.rs copies change.
No live writes, compiler, Cargo, tests, commits or worktrees.

Source/test files are FROZEN. Parent owns type-check, integration, all required
sibling helper/proof/outer-adapter edits, actual fixture completion and testing.
before.json records the nine copied candidate inputs; after.json the two
modified inputs. audit.json records exact patch/hash scope. The before test
file predates parent's numerical Temporal Debug fix; this candidate applies
an equivalent readable tuple mapping and preserves every compared field.

## API

The original run_owner signature remains a numerical wrapper. It enters the
same private drive_owner procedure as run_cold_owner.

- cold_order(routes, owners, completed, (start, frames), control) validates the
  exact CompletedPolicy, finds actual active rows through completed.active,
  and reuses Program::constant_inspected. It returns a non-Clone ColdOrder whose
  private order bit cannot be supplied as unchecked scalar input.
- ColdOrder::is_block tells the parent's outer adapter which existing order to
  use: owner-wise Block, or sample-then-owner Sample.
- run_cold_owner(routes, OwnerPhase, &order, at, control, demand) uses immutable
  routes. at=None is valid only for Block; a dynamic at must exist and be inside
  the exact frame extent. It revalidates completed routes/window/carrier before
  traversal. The callback is a borrowed HRTB TemporalDemand -> Result<(),Error>.
- Neither function constructs PopulationComplete or accepts a standalone bool
  that purports to mean population finished.

Parent's CompletedPolicy::visit_demands closes all route/map/owner construction
over its exact privately borrowed Components. The low-level sibling helpers
are private implementation pieces; they do not accept external owner authority.
The witness validates route slice identity, window, shape and flags. An owner
from a foreign map must not enter that outer adapter.

## Shared sequencing and distinct dispatch

There is one dry stage loop, its one sample loop, one shared EQ-member visitor
call, one wet-owner member loop, one wet sample loop and one effect visitor.
There is no separate cold callback walker.

Routes::Numeric borrows mutable real routes. Routes::Cold borrows immutable
real routes, compatible with the witness's immutable Components borrow.
Routes::cold returns the original immutable slice lifetime, not a borrow of the
access enum. This lets cold phase clocks borrow original route clocks while
the same procedure's numerical branch can mutate only Numeric storage.

Typed Dispatch distinguishes:
- Numeric callback -> real stereo PCM, returned as Some(value);
- Demand callback -> Result<(),Error>, returned as None.

Only Some enters PCM writes, transfer applications, send accumulation and
finite checks. Demand never invokes a numerical callback with fake/zero samples.
Cold skips all gain preparation/application, shared numeric sum/factor work,
saturation shaping, send accumulation, Program take/checkpoint state and final
output arithmetic. It still validates reached scalar stage structure.

The numerical branches preserve the old synchronous finite/gain/callback
barriers. Constant wet's taken Program and next_transfers slice still enclose
the full route sample loop and are restored only on complete success.
Sample output finalization remains in the existing numerical outer adapter
before its next sample. Cold assumes numerical success and therefore emits
the full success demand schedule; a real numerical error may shorten it.
A cold callback/error/budget/cancel failure stops at its own exact reached prefix.

## Required sibling adapters (parent-owned)

- CompletedPolicy<'view,'plan>::validate(routes,start,frames,control), flags(),
  active(route,control); completion from actual successful populate only.
- CompletedPolicy::visit_demands outer ordering and pre-admitted metadata scratch.
- Program::constant_inspected(route,owners,inspect), sharing the original layer
  predicate and short circuit. Parent uses a billed borrowed OwnerKey scan in
  this cold form; numerical constant retains its original lookup/key clone.
- visitors::visit_equalizer_members(route_count,&phase,inspect,visit(id)) and
  EqualizerPhase::demand(voice). The original numerical visitor wraps that same
  admitted-id walk. Carrier validation/id bounds remain at their original point.
- policy::permissions_inspected, first_clock_ref_inspected,
  WetContextRef and wet_context_ref_inspected, using a shared fallible member
  primitive. Numeric helpers preserve their no-op inspected walks and old
  first-admitted clock clone point.
- Route::wet_allowed_inspected bills the reached original/header and later-layer
  explicit Tail probes, preserving short circuit; numeric wrapper is a no-op.
- completion::tests::with_completed_fixture supplies authentic query/populate
  completion for cold tests. No convenience completion-from-marks constructor.

Cold borrows first clocks; numerical first_clock/wet_context still clone exactly
once at their old phase scope. No new cold clock/path clone is introduced.

## Work and storage

The normal numerical path adds no spend/check position. Its existing gains,
Program checkpoints, loops and actual applications retain old work charges.
The cold traversal is additional work and is all kept. It bills:
- witness/order/window/carrier/extent validation;
- actual active-row and constant-predicate probes through parent helpers;
- owner, reached stage, sample, wet-owner, wet-member and sends probes;
- actual dry/wet member scans, including inactive members and reached Tail tests;
- first-clock probes only until the first admitted member;
- EQ carrier shape and actual member visits;
- both effect probes, including absent sends, before each probe.

Inspected helpers spend before examining the relevant item, so budget or
callback failure retains only the actual admitted prefix and no refund.
Cold doesn't precharge a full first-clock/layer walk that may short circuit.
One inspection unit names a structural probe, not per-byte string/RSS billing.

No activity Vec, demand Vec, plan Arc, query, PCM or native result is stored in
the driver. It holds scalar extent/order/dispatch headers and transient borrowed
contexts. Parent will admit the owner-order reference scratch before allocation.
Numeric owned contexts and their original clone lifetimes are retained.
This is not a total RSS or recursive preparation-resource proof. Callback
consumers must fold synchronously or separately admit any storage they choose.

## Tests authored, not run

Six numerical tests from the frozen predecessor remain, with readable Temporal
display mapping to avoid requiring Debug. They cover literal Block/Sample
Reverb+Delay order, distinct voices 5/2 and selected2, gaps/skip/stop, channel
bits, shared-sum overflow before EQ, first-wet-add overflow before Delay,
callback/cancel prefixes and exact/one-short remaining numerical work.

Four new cold tests call the real parent completion fixture/outer adapter:
1. authenticated_cold_driver_matches_literal_block_and_sample_orders:
   dynamic/gap/skip/stop matrix compared to the same independent literal vectors.
2. authenticated_cold_callback_errors_stop_at_exact_prefix:
   error on the first demand returns the exact one-demand prefix.
3. authenticated_cold_cancellation_stops_at_exact_prefix:
   the first demand cancels/checks; no later demand occurs.
4. authenticated_cold_exact_remaining_work_and_partial_failure_are_billed:
   measure actual cold work, rerun with exactly that remainder or one less;
   exact succeeds at MAX, one less refuses with accepted partial spend retained,
   and emitted demands form the literal schedule prefix.

Fixture contract: two samples0/1, effect owner root, [ClipGain,Equalizer] so EQ
stage1, both Reverb+Delay unity sends, insertion voices5 then2; gap removes
voice5 at1; skip removes owner stages/wet; stop removes only wet. The dynamic
fixture uses a unity-valued envelope, preserving successful PCM while selecting
sample order. Fixture completion must come from real Root query/populate policy,
not numerical observed flags or a fabricated zero-sized token. Fixture should
assert pre-PCM route state and avoid post-closure cancellation-sensitive checks.

The cold tests collect test-owned scalar tuples only. They do not retain clock
references, invoke numeric helpers, open a source or establish media admission.
A parent real integration test still needs to demonstrate the whole authentic
population->cold visit->actual read chain and independent flag verification.

## Limits of this unit

No batching, native execution, cache, resource closure, source permission grant,
new limit, changed weight or accepted full-Split result is claimed.
TemporalDemand metadata still lacks the complete Graph/context/parent/raw-grid
authority and recursive reservation fold needed to plan actual prefix reads.
Actual media reads retain all existing admission/deadline/depth/fingerprint
and query checks. Unsupported recursive forms remain explicit scalar fallback
before speculative prefix work.
