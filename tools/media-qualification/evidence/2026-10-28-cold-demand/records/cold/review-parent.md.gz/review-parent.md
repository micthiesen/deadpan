# Independent review: focused parent integration

Scope: `focused-integration.patch` (`f873aa8bd6c581bcf571a8e9939b17dbb795792d3934aa9fb7214b7919bb615c`) and the corresponding current source. Read-only; no Cargo run.

## Findings

None supported in the assigned lens.

## Checks and limits

- `PopulationComplete` is constructed only at the successful tail of `policy_prediction::populate`; that path completes Original exclusion, Root/beat scans, route-count checks, and a final cancellation/deadline check first. `CompletedPolicy` holds an immutable borrow of the exact `Components`, and every visit validates route-slice identity, start, frame count, and permission shape. The witness is not made from observed PCM or a caller-supplied boolean.
- Permission activity checks use the exact stride and mask unused bits in the final 64-bit word, so a set padding bit cannot make a row active. Partial work is charged before each reached word/owner/depth comparison and callback traversal; cancellation and callback failures stop at the reached prefix.
- Owner references are stably insertion-sorted by descending depth, preserving map order at equal depth. `visit_resident_frames` accounts for the vector header and a pointer slot per map owner; the fixture admits that amount before visiting and releases it on normal and refused runs. The API documents this as a caller-side admission requirement. This is not a claim that recursive or native allocations have been proved/admitted; the cold entry is explicitly unconnected to production resource admission.
- The borrowed cold path shares `Program::constant_inspected`'s predicate with numeric preparation, uses borrowed clocks, and has no PCM/numeric callback path. Numeric key cloning remains at the numeric lookup path.
- The prepared-Root test reaches the real `policy_prediction::populate` implementation through its test-only Root adapter; it asserts empty PCM capacity and no provider/source reads before cold visitation. Literal block/sample callback-order, dynamic/static cases, gap/skip/stop cases, callback error/cancellation, and partial-work behavior are also covered. I did not independently execute tests.

The implementation supports a completed metadata-policy visitor milestone only. The fixture is not source-admission evidence, and this patch does not establish recursive/native memory safety or enable batching.

## Final frozen-source supplement

I checked the refreshed final patch and the post-review deltas. No additional supported findings.

The new inactive-dynamic Beat fixture is meaningful: it creates the Beat route before the Root route, selects only voice 2, proves route 0 is nonconstant but inactive and route 1 is constant and active, then checks the literal EQ/Reverb/Delay sample callback order and that every emitted permission excludes voice 5. This exercises the branch where an inactive dynamic route must not force the active constant route onto the sample schedule. It uses real `prepare_beat_sounds` and `policy_prediction::populate` through the test adapter.

`PopulationComplete(())` still has a private tuple field, and a source search finds exactly one constructor expression, at the successful end of `policy_prediction::populate`; the test-only fixture adapter calls that same producer rather than manufacturing the token. `Program::constant_inspected` uses `OwnerKey::matches` over borrowed keys, while the numerical `constant` path retains the previous `OwnerKey::new` clone lookup. The inspected predicate still uses `constant_layer` and preserves its per-layer/stage work hooks.

Parent reports 273 library tests and strict all-target lint passing on this final source; I did not rerun them. The prior scope limits remain: this is metadata-policy traversal groundwork, without recursive/native resource proof or production batching integration.

## Scalar completion accounting correction

Reviewed `demand-only-completion.patch` against the current source. No supported defect in this correction. Scalar `shared_eq` reads now call `populate`, which returns `Result<()>` after the same complete prediction walk and final `control.check()` as before, then proceeds to numeric allocation and actual observation. Only explicit cold planning calls `populate_completed`; that wrapper invokes the same producer first, then pays `complete_policy`'s work/shape/time validation and receives the immutable witness. Test adapters for cold fixtures also use `populate_completed`. The private `PopulationComplete(())` construction remains only in that wrapper, after successful producer return. This removes the unused seal charge from scalar reads without changing the policy population checks, work weights, or cold seal validation. Parent reports strict lint passing and cold-build4 running; I did not run Cargo.
