from pathlib import Path
import hashlib,difflib,subprocess,json
s=Path(__file__).resolve().parent
r=Path('/Users/michael/Code/deadpan');q=Path('/tmp/deadpan-query-groundwork-2026-10-26/scoped')
p=s/'parent';parts=[]
for f in sorted((p/'source').rglob('*.rs')):
 name=str(f.relative_to(p/'source'));before=p/'before'/name
 old=before.read_text() if before.exists() else ''
 if before.exists():assert (r/name).read_text()==old,name
 parts.extend(difflib.unified_diff(old.splitlines(True),f.read_text().splitlines(True),fromfile='a/'+name,tofile='b/'+name))
patch=s/'parent-integration.patch';patch.write_text(''.join(parts))
for root in [r,q]:
 dry=subprocess.run(['patch','--dry-run','-p1','-i',str(patch)],cwd=root,capture_output=True,text=True)
 assert dry.returncode==0,(dry.stdout,dry.stderr)
 applied=subprocess.run(['patch','-p1','-i',str(patch)],cwd=root,capture_output=True,text=True)
 assert applied.returncode==0,(applied.stdout,applied.stderr)
 print(applied.stdout)
name='crates/deadpan-audio/src/shared_components/member_phases.rs'
expected=json.loads((s/'before.json').read_text())[name]
for root in [r,q]:
 assert hashlib.sha256((root/name).read_bytes()).hexdigest()==expected,name
 (root/name).write_bytes((s/'source'/name).read_bytes())
 name_test='crates/deadpan-audio/src/shared_components/member_phases_tests.rs'
 existing=(root/name_test).read_text();assert 'fn record_demand(' not in existing
 cold=(s/'source'/name_test).read_text();tail=cold[cold.index('fn record_demand('):]
 tail=tail.replace('fn record_demand(', '#[cfg(any(target_os = "macos", target_os = "linux"))]\nfn record_demand(',1)
 assert tail.count('#[test]\nfn authenticated_')==4
 tail=tail.replace('#[test]\nfn authenticated_', '#[cfg(any(target_os = "macos", target_os = "linux"))]\n#[test]\nfn authenticated_')
 (root/name_test).write_text(existing.rstrip()+'\n\n'+tail)
print('Integrated shared cold driver and preserved parent numeric trace formatting')
