from pathlib import Path
import json,re
s=Path(__file__).resolve().parent
labels=['cold-build4','cold-library4','definition','stages-enabled','strict3','scoped-build2','scoped-library','scoped-stages','scoped-birth','root-regression2','split-rest']
expected={'cold-library4':(273,0,0,0,0),'definition':(171,0,0,0,0),'stages-enabled':(203,0,0,0,7),'scoped-library':(254,0,0,0,0),'scoped-stages':(203,0,0,0,0),'scoped-birth':(8,0,0,0,163),'root-regression2':(1,0,0,0,209),'split-rest':(3,3,0,0,204)}
rows={}
for label in labels:
 r=json.loads((s/(label+'.json')).read_text());assert 'exit_code' in r and r['sources_unchanged'] and r['binaries_unchanged'],label
 assert r['exit_code']==(101 if label=='split-rest' else 0),(label,r['exit_code'])
 counts=[tuple(map(int,m)) for m in re.findall(r'test result: (?:ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out;',(s/(label+'.stdout')).read_text())]
 if label in expected:assert counts==[expected[label]],(label,counts)
 rows[label]={'seconds':round(r['seconds'],2),'exit_code':r['exit_code'],'test_counts':counts}
(s/'result-summary.json').write_text(json.dumps(rows,indent=2)+'\n')
print(json.dumps(rows,indent=2))
