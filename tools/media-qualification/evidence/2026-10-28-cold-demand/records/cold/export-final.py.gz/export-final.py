from pathlib import Path
import json,difflib,hashlib
s=Path(__file__).resolve().parent;n=Path('/tmp/deadpan-demand-driver-2026-10-27')
r=Path('/Users/michael/Code/deadpan');q=Path('/tmp/deadpan-query-groundwork-2026-10-26/scoped')
c=json.loads((s/'changed-files.json').read_text());published=[];live=[];comparison=[]
for name in c['changed']+c['added']:
 if name in c['added']:before=''
 elif name in ['crates/deadpan-audio/src/shared_components.rs','crates/deadpan-audio/src/shared_components/block.rs']:before=(n/'before'/name).read_text()
 elif name=='crates/deadpan-audio/src/shared_components/permission_tests.rs':before=(s/'parent/permission_tests.before.rs').read_text()
 else:before=(s/'parent/before'/name).read_text()
 data=(r/name).read_bytes()
 live.extend(difflib.unified_diff(before.splitlines(True),data.decode().splitlines(True),fromfile='a/'+name,tofile='b/'+name))
 a='' if name in c['added'] else (s/'published-before'/name.removeprefix('crates/deadpan-audio/src/')).read_text()
 b=(q/name).read_bytes()
 published.extend(difflib.unified_diff(a.splitlines(True),b.decode().splitlines(True),fromfile='a/'+name,tofile='b/'+name))
 comparison.append({'path':name,'main_sha256':hashlib.sha256(data).hexdigest(),'published_sha256':hashlib.sha256(b).hexdigest(),'equal':data==b})
 for folder,bytes_ in [('final-live-source',data),('final-published-source',b)]:
  path=s/folder/name;path.parent.mkdir(parents=True,exist_ok=True);path.write_bytes(bytes_)
(s/'final-live.patch').write_text(''.join(live));(s/'final-published.patch').write_text(''.join(published))
(s/'published-main-comparison.json').write_text(json.dumps(comparison,indent=2)+'\n')
for label,basefile,finalfile,root in [('main','before-manifest.json','source-frozen.json',r),('scoped','scoped-before-manifest.json','scoped-source-frozen.json',q)]:
 def norm(m):return {k.removeprefix(str(root)+'/'):v for k,v in m.items()}
 before=norm(json.loads((s/basefile).read_text()));after=norm(json.loads((s/finalfile).read_text()))
 changed=sorted(p for p in before.keys()&after.keys() if before[p]!=after[p]);added=sorted(after.keys()-before.keys());removed=sorted(before.keys()-after.keys())
 assert not removed
 for p,v in after.items():
  f=root/p;assert f.stat().st_size==v['bytes'] and hashlib.sha256(f.read_bytes()).hexdigest()==v['sha256'],p
 (s/(label+'-lineage.json')).write_text(json.dumps({'base_count':len(before),'final_count':len(after),'changed':changed,'added':added,'removed':removed,'all_current_bytes_match':True},indent=2)+'\n')
 print(label,len(before),len(after),'changed',len(changed),'added',len(added))
print('published',len(comparison),'differing inherited overlays',[v['path'] for v in comparison if not v['equal']])
