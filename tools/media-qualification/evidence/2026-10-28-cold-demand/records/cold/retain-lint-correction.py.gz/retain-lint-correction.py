from pathlib import Path
import json,hashlib,difflib,subprocess
s=Path(__file__).resolve().parent
r=Path('/Users/michael/Code/deadpan')
name='crates/deadpan-audio/src/shared_components/member_phases.rs'
after=(r/name).read_text();before=after
before=before.replace('for (id, route) in routes.iter().enumerate() {','for id in 0..routes.len() {',1)
before=before.replace('Program::constant_inspected(route, owners, || control.spend_plan_work(1))?','Program::constant_inspected(&routes[id], owners, || control.spend_plan_work(1))?',1)
child=(s/'source'/name).read_text()
old_enum=child[child.index("enum Dispatch<'a, 'plan>"):child.index("impl<'plan> Dispatch")]
a=before.index("type NumericCallback<");b=before.index("impl<'plan> Dispatch",a)
before=before[:a]+old_enum+before[b:]
out=s/'strict1-member_phases.rs';out.write_text(before)
subprocess.run(['rustfmt','--edition','2024','--config','skip_children=true',str(out)],check=True)
before=out.read_text()
receipt=json.loads((s/'strict.json').read_text())
pin=receipt['source_before'][str(r/name)]
assert len(out.read_bytes())==pin['bytes'] and hashlib.sha256(out.read_bytes()).hexdigest()==pin['sha256'], 'reconstruction does not match actual failing-source receipt'
(s/'lint-correction.patch').write_text(''.join(difflib.unified_diff(before.splitlines(True),after.splitlines(True),fromfile='a/'+name,tofile='b/'+name)))
(s/'lint-correction.json').write_text(json.dumps({'reconstructed_before_verified_against':'strict.json/source_before','before_sha256':pin['sha256'],'after_sha256':hashlib.sha256((r/name).read_bytes()).hexdigest(),'semantic_change':'none; iterator binding and equivalent callback type alias only'},indent=2)+'\n')
print('Recovered exact failing lint source and verified its receipt hash')
