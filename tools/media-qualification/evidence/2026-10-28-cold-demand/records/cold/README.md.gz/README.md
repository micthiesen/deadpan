# Shared owner phases and authenticated cold demands

Base commit: 429724c03c7c3c8f7e6a185cdaf436ede7be6e48.
Main / isolated roots and qualified environment are fixed in run.py and
run_scoped.py. They retain exact source/binary pins, commands, stdout/stderr,
terminal exits, timing, cancellation/dependency context and removed-file guards.

The new production driver shares the constant and dynamic owner body, preserving
their different outer orders and numerical barriers. Typed demand dispatch emits
borrowed TemporalDemand metadata without executing gain, PCM, transfers, providers
or native state. Cold policy clocks borrow existing route clocks. Pure predicates
and member probes are shared; all extra reached cold inspections are billed.

Completion is a private capability created only by populate_completed after the
actual policy_prediction::populate succeeds and its allocated shape validates.
An allocated or all-false carrier alone cannot construct it. Scalar numerical
population retains its prior Result<()> path and never asks for unused sealing.
The cold entry closes over that exact Components owner/map/window/flags, derives
activity from real bits (ignoring padding), and reuses the same constant-layer
predicate. The insertion-order vector is explicitly estimated and admitted by
the caller. There is no recursive/native resource proof, raw-context
correspondence proof or batching activation. Narrow non-test dead-code
expectations explain the intentionally unconnected cold entry, not test failures.

Main retains inherited Split/index and Original-cache WIP. final-published.patch
is the independently publishable 16-file change; all 16 match isolated source and
staged bytes. Only shared_eq.rs differs in the main overlay. final-live.patch
includes the same task over that inherited working source. Source guards cover
1,422 main / 1,193 isolated inputs, against 1,417 / 1,188 baseline inputs. Exact lineages
must show 11 changed + five added and no unrelated source changes.

Failures retained:
- Numeric first build: only three test assertions (six diagnostics) requiring
  Debug for Temporal; readable tuple diagnostics preserve every compared field.
- First cold build: two check() return sites expected unit but got Duration.
  Both now explicitly check()? and return Ok(()); no behavior/assertion waiver.
- Strict lint: range-loop/index style and a long numeric callback type; iterator
  binding and an equivalent lifetime-aware alias fix them. strict1-member_phases
  is reconstructed by exact reverse edits and verifies against the failure's
  recorded source hash; lint-correction.patch/json retain that proof.
- A fresh processed-root test exhausted work after a completion witness was
  unnecessarily sealed then discarded for every scalar chunk. The final
  populate_completed wrapper requests that real work only for cold planning;
  scalar populate returns unit as before. No performed work is refunded or
  unbilled, and no weights/caps/cache/fallback retry change. The exact failing
  root receipt and the restored positive result are retained.

Seventeen new tests cover literal two-voice/two-sample EQ/Reverb/Delay schedules,
PCM bits, finite/callback/cancel prefixes, exact/one-short work, authentic Root
and Beat query population, immutable completion/window errors, inactive dynamic
routes, borrowed clocks, Tail exclusions, padded bits and empty traversal.
The WAV fixture is setup; this does not establish cold source admission.

Worker numeric candidate and before snapshots are in the separate
/tmp/deadpan-demand-driver-2026-10-27 directory. The archive includes that
candidate, compiler/test receipts and independent review. Cold child candidates,
parent scratch/before snapshots and final source are here. No executable bytes
or copied whole workspace are archived; Cargo inventories and SHA-256 pins are.

Read-only exact-context research is in
/tmp/deadpan-cold-context-2026-10-28. It identifies the missing typed ancestry
authority and recursive heap/native bounds; it is not implementation evidence.
