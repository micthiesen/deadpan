from pathlib import Path
import hashlib,json,gzip
s=Path(__file__).resolve().parent
repo=Path('/Users/michael/Code/deadpan')
dest=repo/'tools/media-qualification/evidence/2026-10-28-cold-demand'
assert not dest.exists(),'Archive once final receipts are terminal'
roots={'cold':s,'numeric':Path('/tmp/deadpan-demand-driver-2026-10-27'),'context-research':Path('/tmp/deadpan-cold-context-2026-10-28')}
allowed={'.rs','.json','.py','.md','.patch','.stdout','.stderr','.txt'}
entries=[]
for group,root in roots.items():
 for p in sorted(root.rglob('*')):
  if not p.is_file() or p.suffix not in allowed or p.name=='qualification-draft.md':continue
  data=p.read_bytes()
  if p.suffix=='.json':
   value=json.loads(data)
   if isinstance(value,dict) and 'command' in value and 'started_at' in value:
    assert 'exit_code' in value and value['sources_unchanged'] and value['binaries_unchanged'],str(p)
  relative=Path('records')/group/p.relative_to(root)
  out=dest/relative;out=out.with_name(out.name+'.gz');out.parent.mkdir(parents=True,exist_ok=True)
  compressed=gzip.compress(data,mtime=0);out.write_bytes(compressed)
  entries.append({'path':str(out.relative_to(dest)),'bytes':len(compressed),'sha256':hashlib.sha256(compressed).hexdigest(),'expanded_bytes':len(data),'expanded_sha256':hashlib.sha256(data).hexdigest()})
manifest={'schema_version':1,'base_revision':(s/'base-revision.txt').read_text().strip(),'scope':'Sixteen-file shared production constant/dynamic owner driver and authenticated cold metadata consumer. Seventeen new tests. Cold completion is requested explicitly; unused scalar sealing removed, with all performed checks still billed when requested. Cold is not connected to recursive resource admission or batching. Exact published source equals isolated and staged bytes; main retains inherited WIP. Full final-source Split coverage remains four pass/three work failures. Read-only context research is not implementation evidence.','prior_runtime_evidence':{'path':'../2026-10-27-permission-population/inventory.json','inventory_sha256':'cf8d87495b24f8b68972a35652b7386fb22cd5a271ba97a6d86c4a3ade6faf3e'},'files':entries}
file=dest/'inventory.json';file.write_text(json.dumps(manifest,indent=2)+'\n')
stored=expanded=0
for row in entries:
 data=(dest/row['path']).read_bytes();plain=gzip.decompress(data)
 assert len(data)==row['bytes'] and hashlib.sha256(data).hexdigest()==row['sha256']
 assert len(plain)==row['expanded_bytes'] and hashlib.sha256(plain).hexdigest()==row['expanded_sha256']
 stored+=len(data);expanded+=len(plain)
print(json.dumps({'files':len(entries),'stored_bytes':stored,'expanded_bytes':expanded,'inventory_sha256':hashlib.sha256(file.read_bytes()).hexdigest()}))
