from pathlib import Path
import json,hashlib,subprocess,shutil
s=Path(__file__).resolve().parent;prior=Path('/tmp/deadpan-demand-driver-2026-10-27')
r=Path('/Users/michael/Code/deadpan');q=Path('/tmp/deadpan-query-groundwork-2026-10-26/scoped')
for name in ['run.py','run_scoped.py','pin.py','removed-files.json','source-files.json','scoped-source-files.json','base-revision.txt','before-manifest.json','scoped-before-manifest.json','initial-status.txt']:
 if not (s/name).exists():(s/name).write_bytes((prior/name).read_bytes())
for name in ['shared_components/member_phases.rs','shared_components/permission_tests.rs','shared_components/completion_tests.rs']:
 p='crates/deadpan-audio/src/'+name
 (q/p).write_bytes((r/p).read_bytes())
baseline=json.loads((s/'before-manifest.json').read_text())
baseline={k.removeprefix(str(r)+'/'):v for k,v in baseline.items()}
changes=[];added=[]
for p in (r/'crates/deadpan-audio/src').rglob('*.rs'):
 n=str(p.relative_to(r));data=p.read_bytes()
 if n not in baseline:added.append(n);continue
 if hashlib.sha256(data).hexdigest()!=baseline[n]['sha256']:changes.append(n)
for root in [r,q]:
 subprocess.run(['rustfmt','--edition','2024','--config','skip_children=true',*[str(root/n) for n in sorted(changes+added)]],check=True)
for root,listname,frozen in [(r,'source-files.json','source-frozen.json'),(q,'scoped-source-files.json','scoped-source-frozen.json')]:
 files=set(json.loads((s/listname).read_text()))
 files.update(str(p.relative_to(root)) for p in (root/'crates/deadpan-audio/src').rglob('*.rs'))
 (s/listname).write_text(json.dumps(sorted(files),indent=2)+'\n')
 pins={str(root/p):{'bytes':(root/p).stat().st_size,'sha256':hashlib.sha256((root/p).read_bytes()).hexdigest()} for p in sorted(files)}
 (s/frozen).write_text(json.dumps(pins,indent=2)+'\n')
 print(root,len(pins),'frozen inputs')
(s/'changed-files.json').write_text(json.dumps({'changed':sorted(changes),'added':sorted(added)},indent=2)+'\n')
print('changed',len(changes),'added',len(added))
