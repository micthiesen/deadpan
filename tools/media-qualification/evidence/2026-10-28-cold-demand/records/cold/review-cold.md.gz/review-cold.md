# Independent review: cold owner-demand extension

Reviewed `cold-demand.patch` (SHA-256 `f5ec4f3c7cdd7b96d4e1b9e00340b07ed0c63d49be3a0982506569a98ea90587`) against the frozen numeric owner-phase candidate and the proposed parent interface. No Cargo or repository edits.

## Supported findings

No supported concrete defect found in this child patch's cold-vs-numeric phase sequencing, typed dispatch separation, bounded sample extent checks, or use of borrowed route clocks. Cold demand dispatch cannot return sample values; PCM mutation, gain evaluation, shared sums/finiteness, transfer application, and send accumulation are inside numeric branches only. Block and Sample retain the same owner body and callback sequence boundaries. Cold EQ and wet requests borrow existing route clocks; they do not clone them or invoke the numeric callback. `CompletedPolicy` is validated against the current routes/window before the traversal and again per owner, and the per-owner API checks the exact policy carrier pointer and requires Block/None or Sample/Some(in-range) extent pairing.

Cold inspections are charged before each corresponding traversal: active-row scans and constant predicate scans in `cold_order`; stage/sample/owner probes; permission/member walks; first-clock/wet-context checks; and both wet-effect probes, including absent effects. The shared visitors stop on callback/error refusal. The new tests compare literal callback order in both modes, exercise callback error/cancellation prefixes, and test exact and partial work exhaustion. Their fixture calls `completion::tests::with_completed_fixture`, which is supplied by parent integration rather than this two-file patch; these tests cannot be treated as independently runnable until that fixture exists.

## Integration work still owed

The child API intentionally accepts an `OwnerPhase` on every `run_cold_owner` call and does not itself enforce that the caller visits all owners in the established depth order, visits every sample exactly once in dynamic mode, or brackets an empty outer traversal with a final control check. The parent cold adapter must guarantee those properties, as `interface.md` says; this patch alone is not a complete cold consumer or resource-admission proof.

The review assumes the parent `CompletedPolicy::validate` enforces exact carrier/route/window identity and complete population, while `active` scans the actual row words and charges each inspected word. That implementation is outside this patch and still needs review. No conclusion is made about the truth of the completion witness, authenticated producer integration, whole-render work/residency, or recursive resource admission.
