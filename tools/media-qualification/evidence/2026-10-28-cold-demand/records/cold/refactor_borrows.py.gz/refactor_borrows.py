from pathlib import Path
p=Path('/tmp/deadpan-cold-demand-2026-10-28/source/crates/deadpan-audio/src/shared_components/member_phases.rs')
s=p.read_text().replace("impl<'plan> Routes<'_, 'plan> {","impl<'routes, 'plan> Routes<'routes, 'plan> {")
needle="    fn numeric(&mut self) -> Result<&mut [Route<'plan>], StageAudioError> {"
assert s.count(needle)==1
s=s.replace(needle,"""    fn cold(&self) -> Result<&'routes [Route<'plan>], StageAudioError> {
        match self {
            Self::Cold(routes) => Ok(routes),
            Self::Numeric(_) => {
                Err(PlanError::InvalidPlan("numerical contribution requested cold storage").into())
            }
        }
    }

"""+needle)
s=s.replace("""policy::first_clock_ref_inspected(
                            routes.get(),""","""policy::first_clock_ref_inspected(
                            routes.cold()?,""")
a=s.index("                    // Cold's borrowed clock")
b=s.index("\n                }\n            }\n        } else if",a)
s=s[:a]+"""                    visitors::visit_equalizer_members(
                        routes.get().len(),
                        &phase,
                        || inspect(cold, control),
                        |id| {
                            let request = phase.demand(routes.get()[id].voice)?;
                            if let Some(frame) = dispatch.call(request)? {
                                let route = &mut routes.numeric()?[id];
                                route.pcm[at].value = frame;
                                if frame.iter().any(|value| !value.is_finite()) {
                                    return Err(PreparationError::InvalidSamples.into());
                                }
                            }
                            Ok(())
                        },
                    )?;"""+s[b:]
a=s.index("        let owned_context;",s.index("    if owner.wet {"))
b=s.index("    Ok(())\n}",a)
s=s[:a]+"""        let owned_context = if !cold && let Some(at) = mode.at() {
            Some(policy::wet_context(routes.get(), owner, |id| permitted.contains(id, at))?)
        } else {
            None
        };
        let context = if cold && let Some(at) = mode.at() {
            Some(policy::wet_context_ref_inspected(
                routes.cold()?,
                owner,
                |id| permitted.contains(id, at),
                || control.spend_plan_work(1),
            )?)
        } else {
            owned_context.as_ref().map(|owned| policy::WetContextRef {
                permissions: owned.permissions,
                clock: owned.clock.as_ref(),
            })
        };
        for &(id, layer) in &owner.members {
            inspect(cold, control)?;
            let route = &routes.get()[id];
            if let Some(at) = mode.at()
                && !permitted.contains(id, at)
            {
                continue;
            }
            let allowed = if cold {
                route.wet_allowed_inspected(layer, || control.spend_plan_work(1))?
            } else {
                route.wet_allowed(layer)
            };
            if !allowed {
                continue;
            }
            if mode.is_block() {
                let active = if cold {
                    completed
                        .ok_or(PlanError::InvalidPlan("cold contribution completion absent"))?
                        .active(id, control)?
                } else {
                    route.program.is_some()
                };
                if !active {
                    continue;
                }
            }
            inspect(cold, control)?;
            let sends = route.layers[layer]
                .0
                .treatments()
                .map(|recipe| recipe.wet_sends())
                .unwrap_or_default();
            if sends.is_empty() {
                continue;
            }
            let samples = mode.samples(frames);
            match &mut mode {
                Mode::Cold { .. } => {
                    wet_samples_cold_or_numeric(
                        Routes::Cold(routes.cold()?),
                        WetSamples {
                            permitted,
                            owner,
                            id,
                            start,
                            samples,
                            sends,
                            context: context.as_ref(),
                            check_samples: mode.is_block(),
                        },
                        WetNumerics::Cold,
                        control,
                        &mut dispatch,
                    )?;
                }
                Mode::Numeric(Numerics::Block { .. }) => {
                    let routes = routes.numeric()?;
                    routes[id].transfer_block(permitted.row(id), control)?;
                    let mut program = routes[id].program.take().ok_or(PlanError::InvalidPlan(
                        "constant contribution program absent",
                    ))?;
                    let count =
                        usize::from(sends.level(deadpan_core::TailEffect::Reverb).is_some())
                            + usize::from(sends.level(deadpan_core::TailEffect::Delay).is_some());
                    let transfers = program.next_transfers(count, control)?;
                    wet_samples_cold_or_numeric(
                        Routes::Numeric(routes),
                        WetSamples {
                            permitted,
                            owner,
                            id,
                            start,
                            samples,
                            sends,
                            context: None,
                            check_samples: true,
                        },
                        WetNumerics::Block(transfers),
                        control,
                        &mut dispatch,
                    )?;
                    routes[id].program = Some(program);
                }
                Mode::Numeric(Numerics::Sample { gains, .. }) => {
                    wet_samples_cold_or_numeric(
                        Routes::Numeric(routes.numeric()?),
                        WetSamples {
                            permitted,
                            owner,
                            id,
                            start,
                            samples,
                            sends,
                            context: context.as_ref(),
                            check_samples: false,
                        },
                        WetNumerics::Sample(&mut gains[id]),
                        control,
                        &mut dispatch,
                    )?;
                }
            }
        }
    }
"""+s[b:]
s=s.replace("""policy::first_clock_ref_inspected(
                    routes.get(),""","""policy::first_clock_ref_inspected(
                    routes.cold()?,""")
p.write_text(s)
