from pathlib import Path
import subprocess
s=Path(__file__).resolve().parent
cases=[
 ('run.py','split-rest','cold-build4-stages',['general_split_sound','--skip','root_sound_and_shared_root_processor_survive_child_splits_without_clock_recapture','--test-threads=1','--nocapture'],101),
 ('run.py','definition','cold-build4-audio-definition',['--test-threads=4'],0),
 ('run.py','stages-enabled','cold-build4-stages',['--skip','general_split_sound','--test-threads=4'],0),
 ('run_scoped.py','scoped-stages','scoped-build2-stages',['--test-threads=4'],0),
 ('run_scoped.py','scoped-birth','scoped-build2-audio-definition',['new_group_birth::','--nocapture','--test-threads=1'],0),
]
for runner,label,binary,arguments,expected in cases:
 command=['python',str(s/runner),'--binary',str(s/binary),label,'--',str(s/binary),*arguments]
 result=subprocess.run(command)
 assert result.returncode==expected,(label,result.returncode,expected)
