//! One owner-phase sequence for the block and sample execution extents.
//! Numerical boundaries remain synchronous. This is not a cold demand API:
//! its inputs borrow the actual numerical state of the selected engine.

use super::*;

/// The existing engine's live state. A block borrows its actual send workspace;
/// a sample borrows its actual gain sums and ordered send accumulation.
pub(super) enum Numerics<'a, 'samples> {
    Block {
        output: &'a mut OutputSamples<'samples>,
    },
    Sample {
        at: usize,
        gains: &'a mut [authored_gain::GainSum],
        sent: &'a mut [f64; 2],
    },
}

impl Numerics<'_, '_> {
    fn samples(&self, frames: usize) -> Range<usize> {
        match self {
            Self::Block { .. } => 0..frames,
            Self::Sample { at, .. } => *at..*at + 1,
        }
    }

    fn is_block(&self) -> bool {
        matches!(self, Self::Block { .. })
    }
}

/// Both engines enter the same owner body. Block keeps owner/stage/sample
/// order; Sample is entered inside the existing sample/owner outer loop.
/// The callbacks are reached only after each preceding numerical barrier.
pub(super) struct OwnerPhase<'a, 'plan> {
    pub(super) permitted: &'a permissions::SamplePermissions,
    pub(super) owner: &'a Owner<'plan>,
    pub(super) start: AudioSample,
    pub(super) frames: usize,
    pub(super) send: Option<deadpan_core::TailEffect>,
}

pub(super) fn run_owner<'plan>(
    routes: &mut [Route<'plan>],
    phase: OwnerPhase<'_, 'plan>,
    mut numerics: Numerics<'_, '_>,
    control: WorkControl<'_>,
    equalize: &mut impl FnMut(
        &AudioOwnerClock<'plan>,
        Temporal,
        AudioSample,
        Permissions,
        Option<usize>,
    ) -> Result<[f64; 2], StageAudioError>,
) -> Result<(), StageAudioError> {
    let OwnerPhase {
        permitted,
        owner,
        start,
        frames,
        send,
    } = phase;
    let sample_permissions = match &mut numerics {
        Numerics::Block { .. } => {
            control.check()?;
            None
        }
        Numerics::Sample { at, gains, .. } => {
            let mask = policy::permissions(routes, owner, |id| permitted.contains(id, *at), false)?;
            if mask.is_empty() {
                return Ok(());
            }
            let sample = AudioSample(start.0 + *at as i64);
            for &(id, layer) in &owner.members {
                if permitted.contains(id, *at) && !owner.skipped && routes[id].program.is_none() {
                    gains[id].owner_slice(
                        &routes[id].layers[layer].0,
                        sample,
                        0..0,
                        true,
                        control,
                    )?;
                }
            }
            Some(mask)
        }
    };
    let recipe = owner.clock.treatments();
    for stage in 0..owner.until {
        let kind = recipe
            .and_then(|recipe| recipe.order().get(stage))
            .copied()
            .ok_or(PlanError::InvalidPlan("contribution stage absent"))?;
        let eq = policy::is_equalizer(kind, recipe);
        if kind == AudioTreatmentStage::Saturation || eq {
            if numerics.is_block() {
                for &(id, _) in &owner.members {
                    routes[id].transfer_block(permitted.row(id), control)?;
                }
            }
            for at in numerics.samples(frames) {
                if numerics.is_block() {
                    control.check()?;
                }
                let mask = if let Some(mask) = sample_permissions {
                    mask
                } else {
                    policy::permissions(routes, owner, |id| permitted.contains(id, at), false)?
                };
                if numerics.is_block() && mask.is_empty() {
                    continue;
                }
                let mut sum = [0.0; 2];
                let mut count = 0;
                for &(id, _) in &owner.members {
                    if permitted.contains(id, at) {
                        count += 1;
                        let route = &mut routes[id];
                        match &mut numerics {
                            Numerics::Block { .. } => {
                                for (out, value) in sum.iter_mut().zip(route.pcm[at].value) {
                                    *out += value;
                                }
                            }
                            Numerics::Sample { gains, .. } => {
                                let frame = route.apply_gain(
                                    &mut gains[id],
                                    route.pcm[at].value,
                                    control,
                                )?;
                                route.pcm[at].value = frame;
                                for channel in 0..2 {
                                    sum[channel] += frame[channel];
                                }
                            }
                        }
                    }
                }
                if sum.iter().any(|value| !value.is_finite()) {
                    return Err(PreparationError::InvalidSamples.into());
                }
                let saturation = recipe.and_then(|recipe| recipe.saturation());
                let factor = if kind == AudioTreatmentStage::Saturation {
                    let saturation = saturation
                        .ok_or(PlanError::InvalidPlan("contribution saturation absent"))?;
                    sum.map(|value| {
                        if value == 0.0 {
                            saturation.drive_factor()
                        } else {
                            saturation.shape(value) / value
                        }
                    })
                } else {
                    [1.0; 2]
                };
                // Clone the first admitted phase clock once, after the shared
                // sum's finite check, retaining both engines' original point.
                let eq_clock = if eq {
                    policy::first_clock(routes, owner, |id| permitted.contains(id, at), false)
                } else {
                    None
                };
                if eq {
                    visitors::visit_equalizer(
                        routes,
                        visitors::EqualizerPhase {
                            owner,
                            permitted,
                            at,
                            sample: AudioSample(start.0 + at as i64),
                            stage,
                            permissions: &mask,
                            clock: eq_clock.as_ref(),
                        },
                        || Ok(()),
                        |_, route, request| {
                            let frame = &mut route.pcm[at];
                            frame.value = request.read(equalize)?;
                            if frame.value.iter().any(|value| !value.is_finite()) {
                                return Err(PreparationError::InvalidSamples.into());
                            }
                            Ok(())
                        },
                    )?;
                } else {
                    for &(id, _) in &owner.members {
                        let route = &mut routes[id];
                        if permitted.contains(id, at) {
                            let frame = &mut route.pcm[at];
                            frame.value = if count == 1 {
                                let saturation = saturation.ok_or(PlanError::InvalidPlan(
                                    "contribution saturation absent",
                                ))?;
                                sum.map(|value| saturation.shape(value))
                            } else {
                                std::array::from_fn(|ch| frame.value[ch] * factor[ch])
                            };
                            if frame.value.iter().any(|value| !value.is_finite()) {
                                return Err(PreparationError::InvalidSamples.into());
                            }
                        }
                    }
                }
            }
        } else if let Numerics::Sample { at, gains, .. } = &mut numerics {
            let sample = AudioSample(start.0 + *at as i64);
            for &(id, layer) in &owner.members {
                if permitted.contains(id, *at) && routes[id].program.is_none() {
                    gains[id].owner_slice(
                        &routes[id].layers[layer].0,
                        sample,
                        stage..stage + 1,
                        false,
                        control,
                    )?;
                }
            }
        }
    }
    if let Some(effect) = send {
        for &(id, layer) in &owner.members {
            match &mut numerics {
                Numerics::Block { output } => {
                    if routes[id].layers[layer]
                        .0
                        .treatments()
                        .and_then(|recipe| recipe.tail_sends().level(effect))
                        .is_some()
                    {
                        routes[id].send_block(output, false, permitted.row(id), control)?;
                    }
                }
                Numerics::Sample { at, gains, sent } => {
                    let route = &mut routes[id];
                    if permitted.contains(id, *at)
                        && let Some(level) = route.layers[layer]
                            .0
                            .treatments()
                            .and_then(|recipe| recipe.tail_sends().level(effect))
                    {
                        control.spend_plan_work(1)?;
                        let value =
                            route.send_sample(&gains[id], route.pcm[*at].value, level, control)?;
                        for ch in 0..2 {
                            sent[ch] += value[ch];
                        }
                    }
                }
            }
        }
    }
    if owner.wet {
        // Dynamic retains one combined walk per owner/sample. Block retains
        // its separate walks per eligible route/sample in wet_samples.
        let context = if let Numerics::Sample { at, .. } = &numerics {
            Some(policy::wet_context(routes, owner, |id| {
                permitted.contains(id, *at)
            })?)
        } else {
            None
        };
        for &(id, layer) in &owner.members {
            let route = &mut routes[id];
            match &numerics {
                Numerics::Block { .. } => {
                    if !route.wet_allowed(layer) || route.program.is_none() {
                        continue;
                    }
                }
                Numerics::Sample { at, .. } => {
                    if !permitted.contains(id, *at) || !route.wet_allowed(layer) {
                        continue;
                    }
                }
            }
            let sends = route.layers[layer]
                .0
                .treatments()
                .map(|recipe| recipe.wet_sends())
                .unwrap_or_default();
            if sends.is_empty() {
                continue;
            }
            let samples = numerics.samples(frames);
            match &mut numerics {
                Numerics::Block { .. } => {
                    route.transfer_block(permitted.row(id), control)?;
                    let mut program = routes[id].program.take().ok_or(PlanError::InvalidPlan(
                        "constant contribution program absent",
                    ))?;
                    let count =
                        usize::from(sends.level(deadpan_core::TailEffect::Reverb).is_some())
                            + usize::from(sends.level(deadpan_core::TailEffect::Delay).is_some());
                    let transfers = program.next_transfers(count, control)?;
                    wet_samples(
                        routes,
                        WetSamples {
                            permitted,
                            owner,
                            id,
                            start,
                            samples,
                            sends,
                            context: None,
                            check_samples: true,
                        },
                        control,
                        equalize,
                        |_, _| Ok(()),
                        |route, at, effect, _, wet| {
                            let wet = transfers
                                .get(effect)
                                .ok_or(PlanError::InvalidPlan("wet gain checkpoint absent"))?
                                .apply_wide(wet, control)?;
                            add_wet(route, at, wet)
                        },
                    )?;
                    routes[id].program = Some(program);
                }
                Numerics::Sample { gains, .. } => {
                    wet_samples(
                        routes,
                        WetSamples {
                            permitted,
                            owner,
                            id,
                            start,
                            samples,
                            sends,
                            context: context.as_ref(),
                            check_samples: false,
                        },
                        control,
                        equalize,
                        |route, at| {
                            route.pcm[at].value =
                                route.apply_gain(&mut gains[id], route.pcm[at].value, control)?;
                            Ok(())
                        },
                        |route, at, _, level, wet| {
                            let wet = route.send_sample(
                                &authored_gain::GainSum::default(),
                                wet,
                                level,
                                control,
                            )?;
                            add_wet(route, at, wet)
                        },
                    )?;
                }
            }
        }
    }
    Ok(())
}

fn add_wet(route: &mut Route<'_>, at: usize, wet: [f64; 2]) -> Result<(), StageAudioError> {
    for (out, input) in route.pcm[at].value.iter_mut().zip(wet) {
        *out += input;
    }
    if route.pcm[at].value.iter().any(|value| !value.is_finite()) {
        return Err(PreparationError::InvalidSamples.into());
    }
    Ok(())
}

/// The same sample/effect sequence runs inside the block Program's borrowed
/// transfer lifetime or the dynamic sample's gain lifetime.
struct WetSamples<'a, 'plan> {
    permitted: &'a permissions::SamplePermissions,
    owner: &'a Owner<'plan>,
    id: usize,
    start: AudioSample,
    samples: Range<usize>,
    sends: deadpan_core::TailSends,
    context: Option<&'a policy::WetContext<'plan>>,
    check_samples: bool,
}

fn wet_samples<'plan>(
    routes: &mut [Route<'plan>],
    phase: WetSamples<'_, 'plan>,
    control: WorkControl<'_>,
    equalize: &mut impl FnMut(
        &AudioOwnerClock<'plan>,
        Temporal,
        AudioSample,
        Permissions,
        Option<usize>,
    ) -> Result<[f64; 2], StageAudioError>,
    mut before: impl FnMut(&mut Route<'plan>, usize) -> Result<(), StageAudioError>,
    mut returned: impl FnMut(
        &mut Route<'plan>,
        usize,
        usize,
        deadpan_core::GainDb,
        [f64; 2],
    ) -> Result<(), StageAudioError>,
) -> Result<(), StageAudioError> {
    let WetSamples {
        permitted,
        owner,
        id,
        start,
        samples,
        sends,
        context,
        check_samples,
    } = phase;
    for at in samples {
        if check_samples {
            control.check()?;
            if !permitted.contains(id, at) {
                continue;
            }
        }
        let local;
        let context = if let Some(context) = context {
            context
        } else {
            // Keep the block engine's two original metadata walks.
            let mask =
                policy::permissions(routes, owner, |member| permitted.contains(member, at), true)?;
            let clock =
                policy::first_clock(routes, owner, |member| permitted.contains(member, at), true);
            local = policy::WetContext {
                permissions: mask,
                clock,
            };
            &local
        };
        let route = &mut routes[id];
        before(route, at)?;
        let mut effect = 0;
        visitors::visit_wet_effects(
            visitors::WetPhase {
                sample: AudioSample(start.0 + at as i64),
                permissions: &context.permissions,
                clock: context.clock.as_ref(),
                voice: route.voice,
                sends,
            },
            || Ok(()),
            |level, request| {
                let wet = request.read(equalize)?;
                let current = effect;
                effect += 1;
                returned(route, at, current, level, wet)
            },
        )?;
    }
    Ok(())
}

#[cfg(test)]
#[path = "member_phases_tests.rs"]
mod tests;
