# Exact context derivation for authenticated temporal demands

Read-only research. No Cargo/rustc, numerical experiment, live-source edit, or implementation. Live source is authoritative over the earlier cold integration patch. The observed HEAD is `429724c03c7c3c8f7e6a185cdaf436ede7be6e48`; the tree has inherited uncommitted product work as well as the cold extension. `source-sha256.json` pins every source cited below, including uncommitted/untracked files. This is a proposed next boundary, not recursive admission or batching completion.

## Recommendation

Extract **one StageAudio-independent metadata constructor** for the supported exact-membership case, and make numerical node creation and a future cold fold call that same constructor. Keep its inputs as the actual parent `Contexts` plus the actual borrowed demand clock. Do not reconstruct a parent from an owner ID, an affine clock, a sample range, or a freshly compiled plan. Do not transfer the old node-search predicate into the cold proof.

The existing published APIs can resolve an owner checked in its exact Root/Domain context. They cannot publish a proof that a different sound/current clock corresponds to the retained Original clock which happens to have the same `OwnerKey`. That is an explicit unsupported case, not a reason to reuse the old key comparison. Retained recursive population is independently unsupported by the current completed-policy producer.

Do not wire the cold visitor to additional histories or native construction until all demands' exact contexts and recursive resource requirements are admitted. All product/Split requirements remain open.

## Current demand and continuation boundary

`shared_components/visitors.rs::TemporalDemand<'phase,'plan>` contains exactly:

* `clock: &'phase AudioOwnerClock<'plan>`;
* `kind: Temporal` (`Equalizer(stage)` or `Wet(effect)`);
* `sample: AudioSample`;
* `permissions: Permissions`;
* `voice: Option<usize>`.

The clock is borrowed from the first admitted member in the actual owner-phase sequence (`policy::first_clock_ref_inspected` / `wet_context_ref_inspected`). It is not necessarily an Original clock. It carries no parent context, no parent node identity, and no proof that another clock is equivalent.

The callback must therefore close over the **same incoming Program** (`context`, `stop`, `allowed`, `parent`, `depth`) used to populate the completed policy. `CompletedPolicy` authenticates its actual immutable Components slice, start/window, and flags; it does not authenticate an arbitrary new parent supplied later. Demand values cannot be detached and replayed with a parent inferred from `clock.instance()`.

The numerical callback in `shared_eq.rs` currently does:

1. `shared_eq_node(graph, program, owner, at, kind, control)`;
2. `width = kind.output_frames()`;
3. `tile = at.div_euclid(width) * width` with checked multiplication;
4. `shared_eq_tile(..., (tile, permissions, voice), ..., program.depth + 1)`;
5. select `[at - tile]` from that tile.

Those five request fields and this exact parent continuation are the resource fold's inputs. `permissions`/`voice` must retain their actual request-local voice registry meaning. Neither family labels nor source/sound IDs can rebuild them.

## Inherited numerical behavior versus currently published proof

### Inherited shared node creation (still live)

`shared_eq_node` first reuses a node when parent index, temporal kind, treatment stage, and `node.boundary.matches_clock_at(owner, at)` match. Its new-node branch:

1. checks `graph.nodes.len() + graph.event_nodes.len()` against `maximum_prepared_stages`;
2. creates `OwnerKey` from instance, Node/default-gap kind, and `gap_after`;
3. creates a current `AudioSoundOwnerContext` for Node owners unless `original_only`;
4. clips `[at, at+1)` against the incoming Original context;
5. queries that context's owners and selects the **first OwnerKey-equal** clock;
6. resolves `Context::owner_context` using that selected clock, or substitutes the current sound processing domain if none was selected;
7. constructs EQ coefficients/native filter, if needed;
8. pushes a `Node` with context, boundary, legacy stop, filter, kind, and an empty tile map.

`OwnerKey` omits definition, retained origin, exact sampling map, and Repeat `play`. `AudioTreatmentBoundary::matches_clock_at` checks more but explicitly does not identify a raw context, and intentionally does not include a whole Repeat's current play. These are inherited lookup behaviors, not cold ancestry proofs.

### Published capabilities usable now

* `RenderPlan::audio_owner_input(owner, at, limits)` re-queries the root owner stack and calls `resolve_input`.
* `AudioDomain::owner_input(owner, at, limits)` re-queries with **that Domain's stored seed**, including hidden physical support, then calls the same resolver.
* `resolve_input` accepts only `candidate.same_at(owner, at)` in the actual query. `same_at` is private to Plan and includes plan, definition, full instance, kind, gap, Repeat play, retained origin, affine slope, and equal local value at the resolving sample. It then captures the raw context through `audio_walk_owner_input` using the actual checked seed.
* The returned `AudioOwnerInput` exposes `owner()`, `observed_at()`, `context()`, `scope()` (`Owner` / `EnclosingProcessor`), `work()`, and `retained_at(at, limits)`.
* `retained_at` walks the captured context at the resolving sample. It does not descend through an enclosing Preserve to find a binding.
* `AudioOwnerRetainedInput` retains its real processing span, allocated start, editorial capture, `AudioBound`, and `AudioBoundDomain`. `reference_at(sample)` subtracts the original allocated consumer start before applying the bound's exact reference map. The reference slope and RootRoundEven/PointCeil distinction are not nominal automation clocks.
* `AudioOwnerRetainedInput::owners` maps owner clocks onto that retained processor's consumer grid and excludes exterior ancestors. It preserves explicit inactive support.
* `AudioDomain` exposes plan membership, definition, placement, root support/extent, visible support, instance, and gap. Its `AudioWalkSeed`, grid, constraints, editorial ancestry, retimes, and binding bypass are private. These public inspection fields are insufficient to reconstruct or compare the complete Domain.
* `AudioBoundDomain` is explicitly Root / Point / Empty. `AudioBound` has full typed Eq including plan, current target, resolved lattice/binding, reference anchor/step, support, envelope scale, and constraints. That Eq does not turn two arbitrary Domains or clocks into the same parent context.

The actual `AudioOwnerInput` / Domain / Retained handles are the grid and ancestry witnesses. Carry them. Do not replace them with tuples of visible fields or invert `owner.sampling()` to fabricate a physical reference grid.

### HEAD versus frozen working tree

The checked-in baseline and live tree both retain the OwnerKey/matches_clock_at node-selection logic. The live tree adds authenticated cold demand emission, current policy completion/population support, exact Original request handling, bounded Original cache plumbing, and permission-family canonicalization around that numerical path. The cold visitor is deliberately dead-code-expected outside tests and is not called by `shared_eq_node`/`shared_eq_tile` for recursive resource admission. Existing Original/query/discovery caches are not a solution to the missing ancestry proof and are excluded from this proposal.

## Proposed one shared metadata constructor

Conceptual API, not an implementation:

```rust
fn describe_temporal_node<'plan>(
    plan: &'plan RenderPlan,
    incoming: &Contexts<'plan>,
    owner: &AudioOwnerClock<'plan>,
    sample: AudioSample,
    kind: Temporal,
    original_only: bool,
    control: WorkControl<'_>,
) -> Result<ExactNodeDescription<'plan>, StageAudioError>;

struct ExactNodeDescription<'plan> {
    context: Contexts<'plan>,
    boundary: AudioTreatmentBoundary<'plan>,
    kind: Temporal,
    original_observed_at: AudioSample,
    original_scope: AudioOwnerInputScope,
    // Keep the checked opaque resolved Original handle/context, not a clock key.
    // An execution adapter may additionally emit the legacy Boundary stop.
}
```

It has no `StageAudio`, `Graph`, media provider, numerical callback, filter, PCM, cache lookup, or fake completion input. It can perform bounded Plan queries and checked metadata arithmetic; "pure metadata" does not mean zero heap or zero work.

For the initial supported branch:

1. Validate same-plan membership of the actual parent Domain/Retained handle and demand clock; checked `sample+1`; declared stage/boundary compatibility. No metadata/native publication yet.
2. Retain the actual incoming context capability. For Root/Domain with the resolving sample inside the physical support, call **that exact context's existing `owner_input` with the demand clock itself**. Do not pre-query and choose a clock by OwnerKey.
3. Use the returned observed owner and `AudioOwnerInput` to preserve current `Context::owner_context`'s retained-at-resolution behavior. Factor its conversion body rather than duplicate it: resolve `retained_at` at the recorded resolving sample; query the retained owner stack on that consumer grid; retain the actual Retained handle when its checked owner is present, otherwise retain the captured Domain. An enclosing Preserve must remain opaque.
4. Resolve Sounds separately under the inherited rule: None for `original_only`; otherwise current checked Node sound-owner context. Validate that this is a current, definition-free structural owner and preserve that context's actual `processing_domain`/support. Do not inherit the parent's Sounds or treat a historical definition-relative path as a current path.
5. Publish the checked `AudioTreatmentBoundary` and resulting `Contexts` together only on full success. Keep the original resolving sample and Owner/EnclosingProcessor classification as diagnostics/proof inputs.

The numerical new-node path for this supported branch must call this function and consume its returned contexts and boundary **before** `Equalizer::new` or graph insertion. The future cold consumer calls the same function. Do not leave a second hand-maintained context-construction body in the numerical path. A wrapper which extracts only tile arithmetic while numerical code continues using its OwnerKey resolver would not meet this requirement.

The old numerical node-cache hit path currently bypasses all those queries. If a cold pass already created a description, numerical execution must consume that admitted description/continuation rather than redo its construction or take a broader clock-key hit. Designing the exact inventory/one-shot continuation and native reuse is a separate task. Do not claim its work/cardinality is proved by this extraction.

With the published API, exact-membership success is implementable now, but a missing exact owner is still a typed Plan failure, not a separately exposed eligibility result. Preserve that failure in the initial constructor. The later Plan API below is needed for a non-error absent/separate-clock classification; do not invent one by inspecting error text.

The returned checked boundary is the proof-bearing stop. The old `shared_mix::Boundary { OwnerKey, before }` may remain an execution adapter temporarily; it cannot serve as exact context/ancestry identity for folding or deduplication. Any future deduplication requires a complete opaque context/ancestry witness, not public Domain fields or `matches_clock_at`.

## Exact unsupported forms for the initial cold fold

Reject/decline these before allocating additional histories or native states. This does not mean the ordinary product renderer may stop supporting them.

1. **Incoming `Context::Retained`.** Current `policy_prediction::available` already returns false, and `validate_original` cannot authenticate a retained original request. No completed-policy recursion is available merely because numerical Retained reads work.
2. **A Root/Domain demand clock which is not an exact observation in that parent.** This includes a current/sound clock paired with a different retained Original clock. No owner-ID or nominal-affine substitution. Existing `owner_input` reports a Plan membership error; do not classify it by matching its message string or catch arbitrary `InvalidPlan` errors as eligibility.
3. **A child Original that resolves to Retained when recursive policy/native admission is needed.** The metadata handle may be derivable and retained for diagnostics, but a complete recursive fold still cannot populate that context with the current producer. Do not advertise it as recursively admitted.
4. **No exact Original observation inside a nonempty incoming Original support.** The inherited implementation falls back to a sound context after its OwnerKey lookup. Absence under an exact clock comparison is not proof that Original is absent; it can be a clock/provenance mismatch. Do not use the sound fallback here.
5. **Definition-relative/current-sound mapping without a published correspondence.** `audio_sound_instance_context(instance)` is a checked current structural lookup, not a proof that a definition-relative or differently placed retained clock refers to that current owner. In the initial non-original-only branch, decline those cases unless exact current membership is independently established.
6. **Missing or foreign ancestor/context, malformed boundary/stage, arithmetic overflow, or an unavailable owner at the resolving sample.** Propagate typed Plan/time/foreign errors. They are not permission to zero pad, change to Root, or repeat a failed cold operation numerically.
7. **Event-local treatment recursion and intrinsic input support not authenticated by actual policy.** Shared owner demands do not inventory every `event_prefix`/`event_return` node or every Preserve/Bound raw preparation. Root/Domain identity alone does not establish their resource eligibility. Existing policy Support::Unsupported remains a refusal.

A geometry-empty Root/Domain Original interval could eventually use the sound-only fallback after the sound processing Domain itself proves exact membership of the demand clock on that sample. This is narrower than "no OwnerKey match". Keep it out of the first constructor unless that proof and its work are explicitly implemented and tested.

No failed cold batch should be retried through scalar execution. A future optimization must distinguish an upfront unsupported form from an error during admitted visitation. No speculative execution/fallback policy is proposed here.

## Smallest typed Plan ancestry API to cover the rejected mapping later

Add one **Plan-owned resolution capability**, conceptually:

```rust
resolve_shared_owner_ancestry(
    parent: AudioOwnerParentRef<'_, 'plan>, // Root / actual Domain / actual Retained
    requested: &AudioOwnerClock<'plan>,
    at: AudioSample,
    limits: AudioQueryLimits,
) -> Result<AudioSharedOwnerAncestry<'plan>, PlanError>
```

`AudioOwnerParentRef` must borrow real checked handles, not accept public seed fields. The result should distinguish `ExactObserved`, `SeparateOriginalClock`, and `OriginalAbsent`, with private construction and charged traversal work. It should expose the resolved `AudioOwnerInput`/Retained handle needed by Audio, the actual observed Original owner, `observed_at`, and Owner/EnclosingProcessor scope. A not-observed result must also report work if it is an eligibility outcome; string matching the existing membership error is insufficient.

For `SeparateOriginalClock`, Plan must return an opaque relation witnessing ALL of:

* membership of the requested sound/current owner in its checked current processing ancestry;
* the actual incoming physical parent seed/retained consumer span and the Original owner selected by that walk;
* the structural correspondence through the resolved binding/reference ancestry, including definition, full concrete Repeat path/play, Node/default-gap distinction, gap identity, and retained clock origin;
* the captured raw input seed and exact consumer-to-reference mapping, including allocated consumer start, RootRoundEven versus PointCeil lattice, reference anchor/step, support, constraints/editorial state, and enclosing Preserve/binding boundary;
* no substitution of exterior ancestors excluded by the retained processor.

Internally this belongs next to `audio_owner_input::resolve_input` / `audio_walk_owner_input` and the existing retained owner walk. Extend the actual walk to publish its correspondence evidence. Do not implement the new API as a public wrapper around `.find(OwnerKey == ...)`, `AudioTreatmentBoundary::matches_clock_at`, or a second root lookup. `AudioOwnerClock::same_at` is appropriate for verifying membership in an already fixed actual parent; it alone cannot manufacture a relation to a different Original clock.

This is the minimum missing authority. It does not authorize media or prove silence/permission. Numerical and cold metadata creation must both consume the same returned capability once it exists.

## Query/work charges and resource inputs

Use the existing canonical WorkControl/query limits for actual context construction, not a fresh budget or optional cache-key allowance. Inherited successful new-node derivation currently charges:

* `audio_sound_instance_context`'s `construction_work()`;
* incoming `Context::owners` query `work()` plus treatment-layer validation;
* `audio_owner_input`/`Domain::owner_input`'s total `input.work()` (includes its own owner query and capture);
* successful `retained_at`'s `retained.work()`;
* retained owner re-query's `owners.work()`.

The extra preselection owner query exists only to choose a key-equal Original clock. An exact resolver using the actual demand can remove that redundant query for supported forms, but must still charge all real queries it does execute. If it introduces an additional current-sound membership query, that is new canonical work. Plan's present failure API does not return partial query work; do not invent a successful-work refund. New typed not-observed outcomes should expose their performed work. Explicit new metadata scans/clones/boundary inspections also need charges and bounded heap admission; the current node `.position`/`.find` loops are not a precharged proof inventory.

The pure description provides the context/recipe; a separate admission fold needs:

* checked parent depth + 1 and maximum depth, plus eventual retained relative-depth obligations;
* exact boundary/kind and exact parent continuation, then exact integer output tile, permission mask and selected voice;
* temporal owner count combined with event nodes, without deduplication by owner-ID/clock shorthand;
* EQ: history2048, input5120, output1024, taps4097; native construction bound `Equalizer::preparation_bytes_bound()` and the existing taps work charge. Its coefficients/native state must not be built by the metadata constructor;
* wet: output4096, Reverb history192000/input196096, Delay history384000/input388096; effect-specific `FiniteWetEffect::preparation_bytes_bound` versus `retained_bytes_bound`, and history+1 preparation work. Existing execution shares one native workspace per effect per Graph and constructs it only after recursive inputs finish; that cardinality/peak order must be proved, not guessed from demands;
* current tile transient PCM allowance `(input + 2*output)*2` f32-stereo-frame units (8bytes/unit), output retention `2*output`, dependency/proof/container capacity, actual nested query/route/policy metadata and request/result buffers;
* current completed-policy traversal order-vector header/payload from `visit_resident_frames`, plus separately admitted callback/recursive scratch;
* original/root/beat raw intrinsic processing, gates, processing clocks, event prefixes, media admission and finiteness. None becomes admitted just because the demand metadata resolved.

There is also a metadata accounting gap to close: the public retained-heap visitor currently measures RoutedRoot, SourceOccurrence(s), and ProcessingQuery. Domain has a private OwnedHeap implementation, but OwnerInput/OwnerRetainedInput/SoundOwnerContext do not publish a retained-byte bound through that visitor. A cold inventory that owns new Domain/Retained/Sounds handles must admit their real capacity/Arc storage with an explicit conservative bound or a Plan-published visitor. The metadata constructor cannot be called "allocation-free," and the already-admitted completed-policy order Vec does not pay for those new handles. Existing query limits bound query construction work; they do not by themselves prove the proposed inventory's retained bytes.

Current `shared_eq_node` calls `Equalizer::new` before a native residency admission even though Equalizer publishes a conservative preparation bound. That is inherited behavior, not an acceptable cold native-resource proof. The wet helper does synchronously admit its larger preparation bound and retain only its smaller native bound afterward. Treat construction peak and retained native state separately.

## Error and cleanup boundary

Resolve/validate bounded metadata and all unsupported forms before taking an EQ filter out of a live node, allocating extra histories/output buffers, generating wet kernels, or publishing new numerical nodes/tiles. Metadata success is provisional until all later independent admission/observation checks succeed.

The new pure constructor owns only bounded metadata handles. An error drops them; it must not alter StageAudio's PCM cache, graph filter slots, source observations, active frames, prepared-frame counters, or published node inventory. Performed metadata/query work remains spent. Any future resident metadata lease needs an RAII lifetime through all consumers of its Arcs, not an early refund after handing them to another structure.

Existing numerical `shared_eq_tile` takes its EQ filter, runs inside a Result closure, subtracts its transient active reservation, and restores the filter after success/error. Graph-level cleanup subtracts retained graph residency. Preserve those boundaries. A cold failure must leave no native state to restore because it must not have acquired it.

## Evidence and limits

Read the live source and its HEAD differences; used ripwire for initial navigation, then direct bounded reads. Did not run any build, test, native processor, source read, browser, or media acquisition. This memo makes no new PCM/performance claim and does not close any product gate. The exact typed ancestry mapping and complete recursive/native admission remain required work.
