# Shared owner-phase extraction candidate

Scratch candidate only, 2026-10-27. Baseline captured from the live runtime
before editing any copies. Parent later confirmed it committed the unchanged
baseline as 429724c03c7c3c8f7e6a185cdaf436ede7be6e48.
No Cargo/rustc, tests, lint, Git writes, worktree or live-source edits performed.

## Scope

Modified copies:
- crates/deadpan-audio/src/shared_components.rs
- crates/deadpan-audio/src/shared_components/block.rs

New private modules:
- crates/deadpan-audio/src/shared_components/member_phases.rs
- crates/deadpan-audio/src/shared_components/member_phases_tests.rs

Other copied inputs are read context only and do not appear in the patch.
Formatting used rustfmt on these four scratch files, with skip_children=true.
The first rustfmt attempt failed resolving an uncopied child test module;
no compiler was run and the final explicit formatting pass succeeded.

## What is actually shared

Both engines call ONE run_owner body with actual Block or Sample numerical
state. It owns the owner dry stages, sample/member visits, tail-send phase and
wet member/sample/effect sequence. Common EQ/wet callbacks still use the current
production visitors and shared policy helpers. The outer engine adapters remain
at their original sites: constant owner order; dynamic sample then owner order.
Initial event sends, route Program preparation and terminal output/gain loops
remain at their original sites too. They cannot emit temporal demands.

This is real shared numerical owner sequencing, not a metadata walker, complete
resource proof or batching. There is deliberately NO cold entry, invented
policy-completion token, fake PCM, provider, retained graph or new cache.
Numerics currently requires the live engine's real state. A subsequent cold
entry still needs a genuinely completed planned view and scoped numerical
continuations. Do not claim this patch already enables that consumer.

## Numerical and work order audit

Block:
1. Owner control.check; stage-kind validation.
2. For EQ/saturation, every member's original transfer_block, followed by each
   sample's control.check, dry permission walk and inactive-mask skip.
3. Sum the same active values in member/channel order, validate finite, derive
   saturation factor, clone first admitted EQ clock at its old point, invoke
   the shared member visitor or apply saturation.
4. Original owner-tail send_block calls remain in member order.
5. Wet eligibility checks wet_allowed before program.is_none; sends-empty check;
   transfer_block; take Program; next_transfers(count) once for the whole route.
6. The common wet helper's per-sample check, inactive skip, separate permission
   and first-clock walks stay inside that Program borrow. No per-request clone.
7. Reverb then Delay, transfer application, channel addition, finite check.
   Restore Program only on successful whole-route completion, as before.

Sample:
1. Original dry permission walk/inactive-owner skip precedes gain owner entry.
2. Existing member owner_slice and per-stage memoryless updates unchanged.
3. Active shared-stage gains are flushed and summed in original channel order
   before the same finite/factor/clock/visitor boundaries.
4. Tail sends retain per-member permission and level checks, work and sums.
5. Dynamic wet_context remains ONE combined owner/sample walk even when all
   individual members subsequently have no sends.
6. Member permission/wet_allowed/sends checks precede dry gain flush. The common
   helper does NOT repeat its admitted-member bit check for this extent.
7. Callback, dynamic send_sample, channel addition and finite check occur before
   any later callback. Sample output finalization still precedes the next sample.

All existing spend_plan_work amounts and check points remain. No gains or
arithmetic are reassociated. Structural dispatch adds no new walk or allocated
collection. New owner/extent/context headers are stack state; the existing
owner-order Vec and existing phase clock clones remain. No RSS or recursive
residency guarantee is asserted.

One narrow structural substitution: the common constant wet continuation uses
transfers.get(effect_index) instead of constructing a fresh slice iterator at
each sample then calling next(). Both select the same immutable element in
effect order and retain one bounds/absent-check immediately before apply_wide.
next_transfers(count) is still called exactly once at the original point and
bills the same count; actual transfer applications still bill themselves.
The effect index advances after the callback and before applying the transfer,
matching the old iterator's advancement point.

Route::transfer_block and send_block visibility only broadens to their parent
private Components module so the sibling owner driver can call them.

## Tests authored, not executed

All in stages::shared_components::member_phases::tests:
- owner_driver_preserves_literal_block_and_sample_callback_orders_and_pcm:
  two samples, distinct voices 5/2, selected output2 while voice5 remains a
  driver, nonunity EQ plus Reverb/Delay, independent literal orders for both
  modes, gap and stop mutations, exact selected PCM channel bits.
- skipped_owner_has_no_dry_or_wet_callbacks: stage and wet skip.
- shared_sum_failure_precedes_equalizer_callbacks: finite input per route,
  overflow only at shared sum, no EQ callback.
- failed_first_wet_application_stops_before_delay: finite callbacks whose
  returned addition overflows; exact emitted prefix stops before Delay.
- callback_error_and_cancellation_emit_no_later_demand: first callback fails or
  checks cancellation; exact one-callback prefix.
- owner_driver_exact_remaining_work_succeeds_and_one_less_fails:
  measured real execution delta leaves exactly that remaining canonical work;
  exact passes, one less fails, both extents.

Existing independent Program/PCM, alias/output, ancestry/first-clock and explicit
Tail exclusion tests remain the necessary broader regression oracles. New tests
make no source-admission or cold-resource claim. Parent must compile and run.
Suggested counterfactual: wire only this test module directly into the captured
old Components tree (its tests call existing public-private finish API, not new
run_owner), and verify traces/PCM/work match the candidate. For an exact legacy
work witness, parent may record the measured delta from both builds; the unit
boundary test alone does not assert an old hard-coded work total.

## Remaining contract

A complete cold consumer cannot call this numerical driver with empty PCM:
it must first separate the synchronous numeric boundaries into scoped
continuations while preserving the constant wet Program borrow bracket. It
must use a completed planned carrier, derive active-route/constant-mode
classification without amplitude inspection and retain all additional work.
Current row allocation or an unfinished prediction is not completion.
No public stub or unused cold API is included.
