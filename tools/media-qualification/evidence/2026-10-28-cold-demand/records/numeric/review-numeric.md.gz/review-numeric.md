# Independent numeric-sequencing review

## Findings

No supported concrete correctness finding in `owner-phases.patch` (SHA-256 `4345f5d5afccb91b99fe146d40eca2dd3267eca0cd11e54e0f27199cbcde7c27`). Reviewed against the exact `before/` snapshots and `notes.md`; no Cargo or repository edits.

## Review notes

The two original engines now share one `run_owner` body while retaining their original outer order: Block enters owner, stage, sample; Sample enters sample, owner. The Sample entry still performs its permission walk and empty-mask skip before gain owner initialization. Block still checks control at owner entry, transfers before each temporal stage, checks every sample, and skips empty permission masks. Shared sums retain member/channel order and their finite check precedes saturation/EQ dispatch; first EQ clock selection remains after that check. Saturation arithmetic and per-route finite checks remain in the same places. Memoryless dynamic gain calls remain in stage/member order.

Tail-send behavior stays in each corresponding owner tail phase. Block calls `send_block` in member order. Sample tests permission and level, charges one unit, calls `send_sample`, then adds channels in order. Dynamic wet context is still constructed once per owner/sample before member eligibility checks, including when no eligible member later has wet sends. Per member, the permission/wet gate and empty-sends skip still precede the final dry gain flush; the helper does not repeat the member permission test.

The shared wet helper preserves Block's sample check and permission skip, then separate permission and first-clock walks, followed by effect visitation. The Program remains taken for the entire Block wet sample loop after its one `next_transfers(count)` call, and is restored only after the whole member succeeds. `get(effect_index)` picks the same transfer as the old iterator; the index advances after successful request read and before applying the transfer, matching the former `next()` location. The first transfer/apply failure still stops later effects and drops the taken Program on error, as before. Sample uses the one previously-created WetContext and retains per-sample gain flush, callback, send application, channel addition and finite check order.

The send workspace remains `outputs[0]`: it is cleared once before initial sends when a common send exists, each owner uses the same workspace for tail send, and finalization reads the same frame before overwriting it. No second output buffer is introduced. Structural state is stack-only; the patch retains the existing owner-order vector and clock clones without a per-callback clone.

The six authored tests cover literal callback order for both constant and dynamic paths, one dry EQ stage plus Reverb and Delay, selected-output/driver separation, gap and stop mutations, exact PCM bits, skipped owner, shared-sum finite failure, wet finite failure before the next effect, callback error/cancellation prefixes, and exact/one-unit-short work budgets. These are focused sequencing oracles; they do not establish cold resource admission. Parent reports compilation is in progress; I did not run Cargo.

Scope limit: this is a refactor of the live numerical owner body. There is no cold consumer, completed-policy API or resource proof in this candidate, and the report makes no such claim.
