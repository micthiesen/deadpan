use super::*;
use crate::{InsertionBias, IterationId, RepeatInstance, RepeatLayout, ScopedNodeTarget};

/// The ordinary insertion path or a single concrete Repeat play/gap. Existing
/// Sequence seams retain their owner; Repeat seams choose their left branch.
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum PauseInsertionTarget {
    Ordinary(InsertTimeTarget),
    Occurrence(OccurrencePauseTarget),
    /// Inside a FollowSpeed speed change, through `Command::InsertTime`.
    Retimed(RetimedPauseTarget),
}

/// A pause inside one FollowSpeed Retime. The Retime stays the live owner of
/// the pause, so a frozen picture captures only scopes below `picture_parent`.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct RetimedPauseTarget {
    /// Ordinary Sequence containing the speed change.
    pub navigation_parent: NodeId,
    pub retime: NodeId,
    /// The structure that will own the pause: a Sequence inside the speed
    /// change, or the speed change itself when it wraps a single beat.
    pub picture_parent: NodeId,
    /// Fresh node identities the command consumes besides the pause itself.
    pub required_ids: usize,
    /// Insertion-site frames per project frame across every enclosing stage.
    pub slope: ExactRatio,
    /// Intermediate input clocks matter even when the net speed is unity.
    pub(crate) stage_slopes: Vec<ExactRatio>,
    /// Whether the cut or the document already needs exact derived clocks.
    pub(crate) exact: bool,
}

impl RetimedPauseTarget {
    /// Whether a pause of `frames` leaves derived clocks in the document:
    /// a fractional child cut, a fractional child span for the pause, or a
    /// document that already has them.
    pub fn needs_exact_clocks(&self, frames: FrameDuration) -> bool {
        self.exact
            || self.stage_slopes.iter().any(|slope| {
                ExactRatio::integer(frames.frames())
                    .checked_mul(*slope)
                    .map_or(true, |span| span.denominator() != 1)
            })
    }
}

impl PauseInsertionTarget {
    pub fn navigation_parent(&self) -> &NodeId {
        match self {
            Self::Ordinary(target) => &target.parent,
            Self::Occurrence(target) => &target.navigation_parent,
            Self::Retimed(target) => &target.navigation_parent,
        }
    }
    pub fn picture_parent(&self) -> InstancePath {
        match self {
            Self::Ordinary(target) => InstancePath {
                node: target.lift.clone().unwrap_or_else(|| target.parent.clone()),
                repeats: Vec::new(),
            },
            Self::Occurrence(target) => target.picture_parent.clone(),
            Self::Retimed(target) => InstancePath {
                node: target.picture_parent.clone(),
                repeats: Vec::new(),
            },
        }
    }
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct OccurrencePauseTarget {
    /// Ordinary Sequence containing the outermost selected Repeat.
    pub navigation_parent: NodeId,
    /// Existing live parent, before the implicit transparent container exists.
    pub picture_parent: InstancePath,
    pub isolation_nodes: usize,
    pub isolation_marks: usize,
    pub split_nodes: usize,
    pub container: bool,
    pub gap: bool,
    pub(crate) site: Site,
    scope: Option<ScopedNodeTarget>,
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub(crate) enum Site {
    Sequence {
        instance: InstancePath,
        index: usize,
    },
    Physical {
        instance: InstancePath,
        at: FrameDuration,
        sequence: Option<(NodeId, usize)>,
    },
    Gap {
        repeat: InstancePath,
        after: IterationId,
        at: FrameDuration,
        duration: FrameDuration,
    },
}

impl OccurrencePauseTarget {
    pub(crate) fn scope(&self) -> ScopedNodeTarget {
        if let Some(scope) = &self.scope {
            return scope.clone();
        }
        let instance = match &self.site {
            Site::Sequence { instance, .. } | Site::Physical { instance, .. } => instance,
            Site::Gap { repeat, .. } => repeat,
        };
        ScopedNodeTarget {
            node: instance.node.clone(),
            repeats: instance
                .repeats
                .iter()
                .map(|step| crate::RepeatEditStep {
                    repeat: step.node.clone(),
                    branch: crate::RepeatEditBranch::Play {
                        iteration: step.iteration.clone(),
                    },
                })
                .collect(),
        }
    }
}

impl ProjectDocument {
    pub fn pause_insertion_target(
        &self,
        at: ProjectFrame,
    ) -> Result<PauseInsertionTarget, EditError> {
        resolve(self, at, None, true)
    }

    /// Resolve a pause within one inspected occurrence. Its start and end
    /// belong to that occurrence even when the adjacent play shares the same
    /// project boundary. The caller must choose a concrete Repeat instance.
    pub fn pause_insertion_within(
        &self,
        at: ProjectFrame,
        within: &InstancePath,
    ) -> Result<OccurrencePauseTarget, EditError> {
        for_command(self, at, Some(within))
    }

    /// Resolve one concrete cut while retaining explicit default/play authority.
    pub fn pause_insertion_scoped(
        &self,
        at: ProjectFrame,
        target: &ScopedNodeTarget,
        within: &InstancePath,
    ) -> Result<OccurrencePauseTarget, EditError> {
        for_authority(self, at, Some(within), Some(target), false)
    }
}

pub(super) fn for_authority(
    document: &ProjectDocument,
    at: ProjectFrame,
    within: Option<&InstancePath>,
    authority: Option<&ScopedNodeTarget>,
    all_plays: bool,
) -> Result<OccurrencePauseTarget, EditError> {
    if authority.is_some() && (within.is_none() || all_plays) {
        return Err(invalid(
            "explicit pause authority requires within and excludes all_plays",
        ));
    }
    if let Some(authority) = authority
        && !authority.matches_instance(document, within.expect("checked within"))?
    {
        return Err(invalid(
            "pause authority does not match its inspected occurrence",
        ));
    }
    let mut target = match resolve(document, at, within, false)? {
        PauseInsertionTarget::Occurrence(target) => target,
        _ => {
            return Err(invalid(
                "occurrence pause requires a concrete Repeat branch",
            ));
        }
    };
    let mut scope = target.scope();
    if let Some(authority) = authority {
        if scope.repeats.len() < authority.repeats.len()
            || !scope
                .repeats
                .iter()
                .zip(&authority.repeats)
                .all(|(actual, supplied)| actual.repeat == supplied.repeat)
        {
            return Err(invalid("pause site is outside its explicit authority"));
        }
        scope.repeats[..authority.repeats.len()].clone_from_slice(&authority.repeats);
    } else if all_plays {
        for step in &mut scope.repeats {
            step.branch = crate::RepeatEditBranch::Default;
        }
    }
    scope.validate(document)?;
    let isolation = crate::scoped_edit::temporal_requirements(document, &scope)?;
    target.isolation_nodes = isolation.nodes;
    target.isolation_marks = isolation.marks;
    target.scope = Some(scope);
    check_node_count(document, &target)?;
    if super::is_shared(&target) {
        super::all_plays_site(document, &target, at)?;
    }
    Ok(target)
}

pub(super) fn for_command(
    document: &ProjectDocument,
    at: ProjectFrame,
    within: Option<&InstancePath>,
) -> Result<OccurrencePauseTarget, EditError> {
    match resolve(document, at, within, true)? {
        PauseInsertionTarget::Occurrence(target) => Ok(target),
        PauseInsertionTarget::Ordinary(_) | PauseInsertionTarget::Retimed(_) => Err(invalid(
            "occurrence pause requires a concrete Repeat branch",
        )),
    }
}

fn resolve(
    document: &ProjectDocument,
    at: ProjectFrame,
    within: Option<&InstancePath>,
    check_growth: bool,
) -> Result<PauseInsertionTarget, EditError> {
    if within.is_none()
        && let Some(target) = super::super::retimed::pause_target(document, at)?
    {
        return Ok(PauseInsertionTarget::Retimed(target));
    }
    // Outside a FollowSpeed interior, clocked speed changes are moved whole,
    // and their integral recipes are exact (see `with_sealed`).
    if !document.derived_clocks().is_empty() && !crate::derived_clock::sealed_active() {
        return crate::derived_clock::with_sealed(|| resolve(document, at, within, check_growth));
    }
    let durations = document.durations()?;
    if at.0 < 0 || at.0 > durations[document.root()].frames() {
        return Err(invalid("pause boundary is outside the project"));
    }
    let mut instance = InstancePath {
        node: document.root().clone(),
        repeats: Vec::new(),
    };
    let mut position = at.0;
    let mut sequence = None;
    let mut parent = instance.clone();
    let mut navigation_parent = document.root().clone();
    if let Some(within) = within {
        let start = scoped_start(document, &durations, at, within)?;
        instance = within.clone();
        position = start.position;
        parent = start.parent;
        sequence = start.sequence;
        navigation_parent = start.navigation_parent;
    }
    for _ in 0..=crate::MAX_DOCUMENT_DEPTH {
        let (site, split_nodes, container, gap) = match &document.nodes()[&instance.node].kind {
            NodeKind::Sequence { children } => {
                if instance.repeats.is_empty() {
                    navigation_parent = instance.node.clone();
                }
                let boundary =
                    super::super::root_boundary(children, &durations, ProjectFrame(position))?;
                if let Some((child, cut)) = boundary.interior {
                    parent = instance.clone();
                    sequence = Some((instance.node.clone(), boundary.slot));
                    instance.node = child;
                    position = cut;
                    continue;
                }
                parent = instance.clone();
                (
                    Site::Sequence {
                        instance: instance.clone(),
                        index: boundary.slot,
                    },
                    0,
                    false,
                    false,
                )
            }
            NodeKind::Repeat {
                child,
                iterations,
                gap,
                ..
            } => {
                let layout = RepeatLayout::compile_with_gap_overrides(
                    iterations,
                    child,
                    document.overrides().get(&instance.node),
                    gap.as_ref().map_or(FrameDuration::ZERO, |gap| gap.duration),
                    document.gap_overrides().get(&instance.node),
                    &durations,
                )?;
                // A named scope can start at zero; inward bias selects its
                // first play rather than the preceding external object.
                let bias = if position == 0 {
                    InsertionBias::Right
                } else {
                    InsertionBias::Left
                };
                let location = layout.locate(ExactRatio::integer(position), bias)?;
                if location.position.denominator() != 1 {
                    return Err(invalid(
                        "pause insertion needs an exact local frame boundary",
                    ));
                }
                position = i64::try_from(location.position.numerator()).map_err(|_| overflow())?;
                parent = instance.clone();
                if location.in_gap && location.play.gap_child.is_none() {
                    let recipe = gap
                        .as_ref()
                        .ok_or_else(|| invalid("pause gap has no recipe"))?;
                    if !super::super::ordinary_hold(recipe) {
                        return Err(invalid("pause insertion needs an ordinary gap Hold"));
                    }
                    let interior = position > 0 && position < recipe.duration.frames();
                    (
                        Site::Gap {
                            repeat: instance.clone(),
                            after: location.play.iteration,
                            at: FrameDuration::new(position).map_err(crate::DocumentError::from)?,
                            duration: recipe.duration,
                        },
                        if interior { 4 } else { 0 },
                        !interior,
                        true,
                    )
                } else {
                    instance.repeats.push(RepeatInstance {
                        node: instance.node.clone(),
                        iteration: location.play.iteration,
                    });
                    instance.node = if location.in_gap {
                        location.play.gap_child.expect("owned gap")
                    } else {
                        location.play.child
                    };
                    sequence = None;
                    continue;
                }
            }
            _ => {
                if let Err(error) = super::super::physical(document, &instance.node) {
                    // Outside Repeats a pitch-processing speed change splits
                    // through the ordinary path; inside one it still refuses.
                    let ordinary = instance.repeats.is_empty() && within.is_none();
                    if !ordinary
                        || super::super::processing_stage(document, &instance.node)?.is_none()
                    {
                        return Err(error);
                    }
                }
                let interior = position > 0 && position < durations[&instance.node].frames();
                if !interior && let Some((owner, index)) = &sequence {
                    let site = Site::Sequence {
                        instance: InstancePath {
                            node: owner.clone(),
                            repeats: instance.repeats.clone(),
                        },
                        index: index + usize::from(position != 0),
                    };
                    return finish(
                        document,
                        navigation_parent,
                        parent,
                        site,
                        0,
                        false,
                        false,
                        check_growth,
                    );
                }
                let split_nodes = if interior {
                    super::super::split_node_count(document, &instance.node)?
                        + usize::from(sequence.is_none())
                } else {
                    0
                };
                let container = !interior && sequence.is_none();
                (
                    Site::Physical {
                        instance: instance.clone(),
                        at: FrameDuration::new(position).map_err(crate::DocumentError::from)?,
                        sequence,
                    },
                    split_nodes,
                    container,
                    false,
                )
            }
        };
        if instance.repeats.is_empty() && !gap {
            return document
                .insert_time_target(at)
                .map(PauseInsertionTarget::Ordinary);
        }
        return finish(
            document,
            navigation_parent,
            parent,
            site,
            split_nodes,
            container,
            gap,
            check_growth,
        );
    }
    Err(limit("pause insertion exceeds the document depth limit"))
}

#[expect(
    clippy::too_many_arguments,
    reason = "one resolved site and its exact allocation policy"
)]
fn finish(
    document: &ProjectDocument,
    navigation_parent: NodeId,
    picture_parent: InstancePath,
    site: Site,
    split_nodes: usize,
    container: bool,
    gap: bool,
    check_growth: bool,
) -> Result<PauseInsertionTarget, EditError> {
    let mut target = OccurrencePauseTarget {
        navigation_parent,
        picture_parent,
        isolation_nodes: 0,
        isolation_marks: 0,
        split_nodes,
        container,
        gap,
        site,
        scope: None,
    };
    if check_growth {
        let isolation = crate::scoped_edit::temporal_requirements(document, &target.scope())?;
        target.isolation_nodes = isolation.nodes;
        target.isolation_marks = isolation.marks;
        check_node_count(document, &target)?;
    }
    Ok(PauseInsertionTarget::Occurrence(target))
}

fn check_node_count(
    document: &ProjectDocument,
    target: &OccurrencePauseTarget,
) -> Result<(), EditError> {
    let required = target
        .isolation_nodes
        .checked_add(target.split_nodes)
        .and_then(|count| {
            count.checked_add(usize::from(target.container) + usize::from(target.gap) + 1)
        })
        .ok_or_else(|| limit("pause identity count"))?;
    if document
        .nodes()
        .len()
        .checked_add(required)
        .is_none_or(|count| count > crate::MAX_DOCUMENT_NODES)
    {
        return Err(limit("pause insertion exceeds the document node limit"));
    }
    Ok(())
}

struct ScopedStart {
    position: i64,
    parent: InstancePath,
    sequence: Option<(NodeId, usize)>,
    navigation_parent: NodeId,
}

fn scoped_start(
    document: &ProjectDocument,
    durations: &std::collections::BTreeMap<NodeId, FrameDuration>,
    at: ProjectFrame,
    within: &InstancePath,
) -> Result<ScopedStart, EditError> {
    within.validate(document)?;
    let outer = within
        .repeats
        .first()
        .map(|step| &step.node)
        .or_else(|| {
            matches!(document.nodes()[&within.node].kind, NodeKind::Repeat { .. })
                .then_some(&within.node)
        })
        .ok_or_else(|| invalid("scoped pause requires an explicitly selected Repeat play"))?;
    let index = crate::AnchorIndex::from_durations(document, durations.clone())?;
    let mut ancestor = &within.node;
    while let Some((parent, _)) = index.parents.get(ancestor) {
        if matches!(document.nodes()[parent].kind, NodeKind::Retime { .. }) {
            return Err(invalid(
                "pause inside Retime needs exact derived-clock authoring",
            ));
        }
        ancestor = parent;
    }
    let start = index
        .resolve_target(&crate::AnchorTarget {
            boundary: crate::BoundaryAnchor {
                coordinate: crate::Anchor::Occurrence {
                    instance: within.clone(),
                    position: ExactRatio::ZERO,
                },
                bias: InsertionBias::Right,
            },
            occurrence: None,
        })
        .map_err(|error| invalid(&error.to_string()))?;
    if start.exact_frame.denominator() != 1 {
        return Err(invalid("scoped pause needs an integral occurrence clock"));
    }
    let position = at.0.checked_sub(start.frame.0).ok_or_else(overflow)?;
    if position < 0 || position > durations[&within.node].frames() {
        return Err(invalid("pause boundary is outside the selected occurrence"));
    }
    let parent_node = &index.parents[&within.node].0;
    let mut parent = InstancePath {
        node: parent_node.clone(),
        repeats: within.repeats.clone(),
    };
    if matches!(document.nodes()[parent_node].kind, NodeKind::Repeat { .. }) {
        parent.repeats.pop();
    }
    let sequence = if let NodeKind::Sequence { children } = &document.nodes()[parent_node].kind {
        Some((
            parent_node.clone(),
            children
                .iter()
                .position(|id| id == &within.node)
                .ok_or_else(|| invalid("scoped pause lost its Sequence parent"))?,
        ))
    } else {
        None
    };
    Ok(ScopedStart {
        position,
        parent,
        sequence,
        navigation_parent: index.parents[outer].0.clone(),
    })
}
