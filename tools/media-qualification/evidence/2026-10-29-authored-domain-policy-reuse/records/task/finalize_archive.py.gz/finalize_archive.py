from pathlib import Path
import gzip,hashlib,json

s=Path(__file__).resolve().parent
dest=Path('/Users/michael/Code/deadpan/tools/media-qualification/evidence/2026-10-29-authored-domain-policy-reuse')
p=dest/'inventory.json'
assert hashlib.sha256(p.read_bytes()).hexdigest()=='1f821a4a9efd33e8484f676209c821affd55953eeaf9515da552c2db485f5637'
manifest=json.loads(p.read_text())
check=json.loads((s/'policy-strict-final.json').read_text())
assert check['exit_code']==0 and check['sources_unchanged']and check['binaries_unchanged']
audit=json.loads((s/'final-audit.json').read_text());assert audit['all_terminal']and len(audit['receipts'])==42
sources=[(s/'policy-strict-final.json','policy-strict-final.json'),(s/'policy-strict-final.stdout','policy-strict-final.stdout'),(s/'policy-strict-final.stderr','policy-strict-final.stderr'),(s/'final-audit.json','final-audit-after-docs.json'),(Path(__file__),'finalize_archive.py')]
for source,name in sources:
    data=source.read_bytes();target=dest/'records/task'/str(name+'.gz');assert not target.exists()
    packed=gzip.compress(data,mtime=0);target.write_bytes(packed)
    manifest['files'].append({'path':str(target.relative_to(dest)),'bytes':len(packed),'sha256':hashlib.sha256(packed).hexdigest(),'expanded_bytes':len(data),'expanded_sha256':hashlib.sha256(data).hexdigest()})
manifest['final_audit_record']='records/task/final-audit-after-docs.json.gz'
manifest['post_documentation_strict_check']='records/task/policy-strict-final.json.gz'
p.write_text(json.dumps(manifest,indent=2)+'\n')
for row in manifest['files']:
    packed=(dest/row['path']).read_bytes();plain=gzip.decompress(packed)
    assert len(packed)==row['bytes']and hashlib.sha256(packed).hexdigest()==row['sha256']
    assert len(plain)==row['expanded_bytes']and hashlib.sha256(plain).hexdigest()==row['expanded_sha256']
result={'files':len(manifest['files']),'stored_bytes':sum(r['bytes']for r in manifest['files']),'expanded_bytes':sum(r['expanded_bytes']for r in manifest['files']),'inventory_sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
(s/'published-evidence-final.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result))
