from pathlib import Path
import gzip,hashlib,json

s=Path(__file__).resolve().parent
profile=Path('/tmp/deadpan-split-work-profile-2026-10-29')
repo=Path('/Users/michael/Code/deadpan')
dest=repo/'tools/media-qualification/evidence/2026-10-29-authored-domain-policy-reuse'
assert not dest.exists()
audit=json.loads((s/'final-audit.json').read_text());assert audit['all_terminal']
prior=repo/'tools/media-qualification/evidence/2026-10-29-authored-span-start-capture/inventory.json'
prior_sha='ecded01d7022e30ef6b78c2215b167da099297d5bc0769c88905cd552ac75ece'
assert hashlib.sha256(prior.read_bytes()).hexdigest()==prior_sha
rows=[]
allowed={'.rs','.json','.py','.md','.patch','.stdout','.stderr','.txt','.sha256','.toml'}
for prefix,root in [('task',s),('profile',profile)]:
    for p in sorted(root.rglob('*')):
        if not p.is_file()or p.suffix not in allowed:continue
        rel=p.relative_to(root)
        if prefix=='profile'and rel.parts[0]=='diagnostic':continue
        data=p.read_bytes()
        if p.suffix=='.json':
            obj=json.loads(data)
            if isinstance(obj,dict)and 'command'in obj and 'started_at'in obj:
                assert 'exit_code'in obj,str(p)
                assert obj['sources_unchanged']and obj['binaries_unchanged'],str(p)
        target=dest/'records'/prefix/rel
        target=target.with_name(target.name+'.gz');target.parent.mkdir(parents=True,exist_ok=True)
        packed=gzip.compress(data,mtime=0);target.write_bytes(packed)
        rows.append({'path':str(target.relative_to(dest)),'bytes':len(packed),'sha256':hashlib.sha256(packed).hexdigest(),'expanded_bytes':len(data),'expanded_sha256':hashlib.sha256(data).hexdigest()})
manifest={'schema_version':1,'base_revision':(s/'base-revision.txt').read_text().strip(),'scope':'Scratch-only actual work profiling and restricted same-Domain processing-tape reuse at the top policy second-query phase. Old full private corpus frozen independently in both variants before production. Existing walk co-produces fail-closed terminal witness; first query billed once; policy reports only actual new work. Root/Retained/direct APIs and recursive Bound policy unchanged. Exact fallback/new budgets and native three-way complete PCM/work receipts verified. Test-only wet cleanup fault injection replaces an unstable cross-renderer measured budget. All11goldens preserved. GeneralSplit stays disabled:3pass4resourcefailures. No caps/weights/refunds/coldactivation/acceptance/speed/peakmemory changes claimed.','prior_span_start_inventory':{'path':'../2026-10-29-authored-span-start-capture/inventory.json','sha256':prior_sha},'profile_scope_note':'The full diagnostic filesystem copy and executables are excluded. Complete source/executable/stream hash manifests, instrumentation before/after snapshots and patches, raw receipts and all analyses are included. Main observed context patch and unchanged untracked source snapshots support reproduction without shipping inherited runtime changes.','files':rows}
p=dest/'inventory.json';p.write_text(json.dumps(manifest,indent=2)+'\n')
for row in rows:
    packed=(dest/row['path']).read_bytes();plain=gzip.decompress(packed)
    assert len(packed)==row['bytes']and hashlib.sha256(packed).hexdigest()==row['sha256']
    assert len(plain)==row['expanded_bytes']and hashlib.sha256(plain).hexdigest()==row['expanded_sha256']
result={'files':len(rows),'stored_bytes':sum(r['bytes']for r in rows),'expanded_bytes':sum(r['expanded_bytes']for r in rows),'inventory_sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
(s/'published-evidence.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result))
