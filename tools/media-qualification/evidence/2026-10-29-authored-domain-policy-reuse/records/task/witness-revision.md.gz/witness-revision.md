# Revised witness proposal for judge

Both independent critics reject paid freshpolicy scans because ineligible Stage fallback can regress at exactoldbudget. Moving S to firstquery preserveslocalpolicybudget butsemanticcritic stillrejects globalfallbackregression withoutreuse.

Prefer co-producing a private stop witness at the EXISTING actual stop_at_preserve Stage emission branch (audio_capture.rs563). No new linear scan, lookup, ownedcopy or allocation; ordinary node/Stage emission canonical weights remain unchanged. This is constant terminal-result bookkeeping of an already billed node visit, not an additional traversal whose work is silently omitted. Must decide whether this accounting is valid under current work-unit convention.

Concrete narrow seam already exists: audio_capture.rs has private WalkCaptures typealias naming owner/editorial/observed-clock tuple; audio_walk_inner_admitted has only3 actual callers (audio.rs wrapper, audio_owner_input.rs, audio_owner_probe.rs). Add optional private processing-stop observer to that capture group, defaultNone for alloldcallers. Mark it only at actual successful exposedStage emission. No signaturewidecounter fields/Layoutchanges in QueryBudget/Work/AudioProcessingQuery.

Keepold audio_walk_inner triplewrapper by delegating to new private inner with extendedcaptures4, or equivalentgrouped typed adapter; new firstprocessing factory selects observerroute, old methods useNone. Existing processing loop stays same and recordswitnessacrosscursors. No eligibility pass over completedspans. A failedquery cannotproduceproduct. Bound stops don't mark, opaqueBoundPreserve stays eligibletop-level. Current Domain walk cannotemitProjectedStage; still conservatively ensureall exposedprocessing-terminal creationpaths rejectfutureunsupportedProjectedStage (judge may require explicitemissionhelper/tagcoverage).

Sealedproduct keeps actualDomainborrow/range/actualquery; finishpolicy consumesproduct. IfwitnesssaysStage, call ordinarypolicy (no extra policywork, queryfirstoldwork unchanged). Else currentpolicy domain.audio/content/endpoint loopruns asbefore; at actualbindingphase/nonempty borrowheldfirsttape insteadofsecondquery; recursionunchanged. Freshpolicybudgetactualonly, no observed(reusedQ). Completedowningpair canreturnownedqueries afterconsumingcapability; no separatememorylease currentlyplainqueryAPI, no persistentdata/newBoundclones/selfrefs.

Preserve ownedfallbackiterdrop order, ordinaryAPIs/Root/Retained/errororder. Testexactineligibleglobal/localbudgets, exposedPreserve/Shift+unrelatedbinding actualfallback, oldcompleteprivatetapes/worklookup/policy bothvariants beforeproduction, observednodecounts/layout/sourcepreservation andfullPCM.

No productionreuseyet. OLDproducer onlycfgtesthooks/newfile, currentlyaddingunrelatedbindings to exposedStagecases beforefirstbuild.
