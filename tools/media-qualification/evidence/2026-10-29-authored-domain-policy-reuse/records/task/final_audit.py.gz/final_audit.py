from pathlib import Path
import hashlib,json,re

s=Path(__file__).resolve().parent
main=Path('/Users/michael/Code/deadpan')
scope=Path('/tmp/deadpan-query-groundwork-2026-10-26/scoped')
sha=lambda b:hashlib.sha256(b).hexdigest()
negative={'policy-old-main':101,'policy-strict1':1,'policy-audio-main3':101}
split_text=(s/'policy-split.stdout').read_text()
split=re.findall(r'^test (general_split_sound::[\w:]+) \.\.\. (ok|FAILED)',split_text,re.M)
assert len(split)==7,split
split_failed=sum(v=='FAILED'for _,v in split)
if split_failed:negative['policy-split']=101
receipts=[]
for p in sorted(s.glob('*.json')):
    r=json.loads(p.read_text())
    if not isinstance(r,dict)or 'started_at'not in r or 'command'not in r:continue
    assert r.get('exit_code')==negative.get(p.stem,0),(p.stem,r.get('exit_code'))
    assert r['sources_unchanged']and r['binaries_unchanged'],p.stem
    for name,h in r['streams'].items():
        data=Path(name).read_bytes()
        assert len(data)==h['bytes']and sha(data)==h['sha256'],name
    receipts.append({'label':p.stem,'exit_code':r['exit_code'],'seconds':r['seconds'],'receipt_sha256':sha(p.read_bytes()),'source_inputs':len(r['source_before'])})
final=['policy-audio-build4','policy-scoped-audio-build4','policy-audio-main4','policy-audio-scoped4','policy-strict3','policy-stages-main','policy-stages-scoped','policy-definition','policy-scoped-birth','policy-split']
for label in final:
    r=json.loads((s/(label+'.json')).read_text())
    for name,h in r['source_after'].items():
        data=Path(name).read_bytes()
        assert len(data)==h['bytes']and sha(data)==h['sha256'],(label,name)
rows=json.loads((s/'task-source-pins.json').read_text())
raw=(s/'index-blobs.bin').read_bytes();offset=0;equality=[]
for row in rows:
    end=raw.index(b'\n',offset);header=raw[offset:end].decode().split();assert header[1]=='blob'
    n=int(header[2]);data=raw[end+1:end+1+n];offset=end+2+n
    assert data==(scope/row['path']).read_bytes()and sha(data)==row['sha256']
    if row['path']!='crates/deadpan-plan/src/plan.rs':assert data==(main/row['path']).read_bytes()
    equality.append({'path':row['path'],'blob':header[0],'sha256':row['sha256'],'scoped_index_equal':True,'main_equal':data==(main/row['path']).read_bytes()})
assert offset==len(raw)and len(rows)==22 and sum(r['main_equal']for r in equality)==21
(s/'index-source-equality.json').write_text(json.dumps(equality,indent=2)+'\n')
owned={r['path']for r in rows};unchanged={}
for variant,root in [('main',main),('scoped',scope)]:
    initial=json.loads((s/(variant+'-initial-authority.json')).read_text());count=0
    for name,h in initial.items():
        if name in owned:continue
        assert sha((root/name).read_bytes())==h,(variant,name)
        count+=1
    unchanged[variant]=count
assert unchanged=={'main':1491,'scoped':1262}
oracles=json.loads((s/'immutable-oracle-pins.json').read_text());assert len(oracles)==11
for row in oracles:
    for root in [main,scope]:assert sha((root/row['path']).read_bytes())==row['sha256']
a,b=[json.loads((s/name).read_text())for name in ['policy-old-main3-snapshot.json','policy-old-scoped2-snapshot.json']]
for obj in [a,b]:
    for key in ['variant','source_sha256']:obj.pop(key)
assert a==b
tests={}
for label,count in {'policy-audio-main4':377,'policy-audio-scoped4':358,'policy-stages-main':203,'policy-stages-scoped':203,'policy-definition':171,'policy-scoped-birth':8}.items():
    matches=re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;', (s/(label+'.stdout')).read_text())
    assert len(matches)==1 and int(matches[0][0])==count and int(matches[0][1])==0,(label,matches)
    tests[label]={'passed':count,'ignored':int(matches[0][2]),'seconds':json.loads((s/(label+'.json')).read_text())['seconds']}
plan=[]
for label,count in [('policy-build3',643),('policy-scoped-build3',630)]:
    rr=json.loads((s/'plan-results'/label/'results.json').read_text());assert len(rr)==29 and all(r['exit_code']==0 for r in rr)
    passed=sum(int(m[1])for r in rr for m in r['test_results']);ignored=sum(int(m[3])for r in rr for m in r['test_results'])
    assert passed==count and ignored==9
    plan.append({'build':label,'targets':29,'passed':passed,'ignored':ignored})
proof=json.loads((s/'plan-executable-source-proof.json').read_text());assert all(r['all_plan_core_inputs_current']and r['not_plan_dependencies']for r in proof)
preserve=json.loads((s/'source-preservation-preaudit.json').read_text());assert preserve['plan_export_delta_equal']and preserve['main_inherited_plan_preserved']
result={'all_terminal':True,'receipts':receipts,'negative_results_retained':negative,'source_files':22,'rust_files':19,'all_scoped_index_equal':True,'twenty_one_main_files_equal_with_plan_export_delta_equal_over_distinct_preserved_baselines':True,'other_initial_inputs_unchanged':unchanged,'all_relevant_compiled_sources_current':True,'tests':tests,'plan':plan,'immutable_oracles_unchanged':11,'old_policy_complete_cross_variant_bodies_equal':True,'old_eligible_query_full_private_equality':json.loads((s/'old-v4-eligible-query-equality.json').read_text()),'plan_source_reuse_proof':proof,'split':{'passed':7-split_failed,'failed':split_failed,'cases':split,'seconds':json.loads((s/'policy-split.json').read_text())['seconds']},'scoped_patch_sha256':sha((s/'task-scoped.patch').read_bytes()),'native_scheduling':json.loads((s/'native-scheduling-note.json').read_text()),'cleanup_failure_and_same_executable_repeat_retained':json.loads((s/'cleanup-repeatability.json').read_text())}
(s/'final-audit.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items()if k not in ['receipts','old_eligible_query_full_private_equality','plan_source_reuse_proof','cleanup_failure_and_same_executable_repeat_retained']}))
