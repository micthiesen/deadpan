# Final parent review

The production query-reuse implementation remains the independently reviewed design. Later production-source edits only name the existing argument tuple and add a cfg(test)-only wet-processing callback. The alias preserves five independent borrows. The callback is absent from production builds and does nothing in tests unless the one-shot thread-local fault is armed.

The cleanup fault runs after successful native wet processing, checks that the actual processor exists and its retained bound is represented in both graph and renderer residency, then exhausts the test controller. The following ordinary charge fails. The full public shared read must release the graph and return residency to its entry value. The flag is consumed once, resets on unwind, and the test fails if the publication point is never reached. It does not manufacture a successful or failed PCM result or change a golden.

The exact-new-budget tests exercise the five actual eligible binding cases from the frozen Plan corpus, plus Source/Unrelated binding Audio preparations with fades on/off. They independently bound new policy work and the whole host preparation bill; old work is not refunded or silently subtracted from fresh limits.

Final strict lint, both complete Audio libraries and all ordinary Stage and definition/birth checks pass. The four remaining Split resource refusals remain failures and General Split remains disabled. All index source bytes equal the independently tested scoped candidate; unrelated Main source and every immutable golden remain preserved.
