# Plan production review

Lens: sealed ownership, same-domain query restriction, fresh budget/span caps, fallback/error/drop ordering.

Scope reviewed: crates/deadpan-plan/src/audio.rs, audio_capture.rs, audio_domain.rs, audio_policy.rs, audio_owner_input.rs, audio_owner_probe.rs, and the narrow plan.rs / lib.rs exports. Compared task changes against both supplied before/main and before/scoped snapshots; unrelated plan.rs changes were excluded.

Findings: none.

The new product can only be made by AudioDomain::processing_for_policy; it retains the borrowed domain identity and exact requested range, and finish_policy consumes it after checking pointer identity and range equality. The first processing walk is unchanged apart from a stack-only terminal observer. Observer classification is exhaustive and shared with final terminal dispatch; it records Stage/ProjectedStage emission and leaves Bound recursion to the existing policy recursion.

On the reuse path, current-domain policy work still runs first. The reused tape is considered only for the old second-query binding phase, and only if its span count fits the fresh policy cap; otherwise the original processing query path runs. Nested Bound policy remains independently queried. Policy counters omit only the skipped second query, and the first query remains separately available for billing. A Stage witness takes caller.policy directly, preserving old fallback budgets and errors. Ownership remains single-use, with no persistent borrowed tape or independent allocation added.
