# Superseding frozen source v4

Use candidate-v4, candidate-v4-pins.json and main-v4.patch/scoped-v4.patch. v3-to-v4 patches isolate this exact amendment. v1/v2/v3 snapshots and real build/capture/equality evidence are preserved.

Both v3 OLD variants passed and complete JSON bodies matched except variant/source (parent reported raw906804 bytes SHA91f831140204c3ccf7571396c952c576aab30ab1e8f4864d30baa47a9d26fa74; common body e0e69c4dc740d667a3f79f91ad8cb9c386771c6ceca301bd96ebb7ab0877112f). v3 measured negative_domain_records=0: ordinary Edit clipped physical Domain to1..9 despite affine origin-3.

The retained Edit case is truthfully renamed cropped_group_domain_with_inherited_edit_retime. A second case uses the existing checked cropped_group_input_keeps_hidden_siblings_and_signed_root_grid Partition construction from audio_owners/input_tests.rs17, adding an unrelated valid physical prefix Hold binding. Actual owner_input context asserts root_samples -3..13, visible1..9, plan-global bindings. Coverage separately requires a real default policy top-depth second query from an actual negative binding Domain. No unchecked seed or negative Source coordinate is substituted. Existing Stage fallback coverage assertion remains.

Expected26window records/up to56actualpolicy calls; actual v4 coverage/equality await parent runs. Both producer patches were applied independently and rustfmt edition2024 skip_children=true passed. No Cargo/native/Git by worker. Existing hook files unchanged fromv3. Worker now read-only; parent owns all builds/runs.
