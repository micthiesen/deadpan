# Superseding frozen source v2

Use candidate-v2, candidate-v2-pins.json and main-v2.patch/scoped-v2.patch. README.md still describes reproduction and observer semantics. Initial candidate snapshots are retained intact.

Parent requested a material fallback witness before compilation: both exposed Preserve and unity Shift constructors now bind their unrelated silent sibling to its identical old document. This causes plan-global has_audio_bindings to be true without hiding the exposed Stage. Default/exact OLD policy work/one-short policy runs therefore record the actual second-query path. Coverage derives noneligible_binding_records_with_actual_top_second_query from actual events and refuses to emit if zero. No equivalence or cost is manufactured. Parent must confirm literal actual counts and exact/short outcomes after running OLD pinned executables.

No Cargo/native/Git commands were run by the source worker. rustfmt with edition2024 and skip_children=true succeeded in both trees. Worker is read-only after this v2 handoff.
