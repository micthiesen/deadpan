# OLD Domain policy-binding-query producer

Prepared 2026-10-29 before any production processing-tape reuse. No Cargo, native test, or Git command was run by this source worker. Both trees received independent narrow edits to their original hook files; only the wholly new producer was copied between trees. Main/Scope inherited production baselines were preserved.

## Reproduction by parent

Ignored test filter:

`plan::audio_owners::tests::legacy_snapshot_v1::policy_binding_baseline::capture_old_policy_binding_baseline_v1`

Run each already-pinned test executable with the exact filter, `--ignored --exact --nocapture`. Environment:

- `DEADPAN_POLICY_BINDING_OUTPUT`: a new absolute output path whose existing parent canonicalizes beneath `/tmp` (create_new, never overwrite).
- `DEADPAN_POLICY_BINDING_VARIANT`: `main` or `scoped`.
- `DEADPAN_POLICY_BINDING_SOURCE_SHA256`: parent-computed 64-hex complete source-manifest SHA256 for that pinned executable.

Parent must run both OLD executables before production reuse, compare complete JSON except the top-level `variant` and `source_sha256`, retain build/executable/source-manifest pins, and freeze successful outputs. No golden fixture is installed by this producer.

## What the records prove

The immutable wide14 snapshot reconstructs its 7 actual Domain parents through its checked visitor. Its 7 Root parents are labelled out-of-scope references. Five extra deterministic documents construct actual owner-input contexts: exposed Preserve with silent Hold, Shift at unity, a group inside Preserve, an opaque Bound operand containing Preserve and silence, and an inherited ordinary Edit retime with a hidden negative physical Domain. Extra construction claims must be checked against the actual output; there are no generated equivalence claims or guessed work values.

Each physical Domain has a full requested window and an empty window: expected 24 records. Each record independently captures the actual first processing(true), a separate complete processing(false), and full policy output with ordered owned content, suppression, work and lookup. Private Domain seed and complete Bound/mapping snapshots use existing exhaustive legacy serializers. Source/selected-placement documents, Repeat/default-gap, resumed, bypass-binding and retained-reference parents come from wide14.

Nonempty successful policy cases also run exact OLD total-policy work and one-short limits. Two selected contexts add minimum-work and invalid-span-limit refusals. This is at most 52 actual policy calls if all default cases succeed. The output's `coverage` is derived from actual observed data, including Stage/Bound counts, negative/inherited/bypass Domains, Source/silent-Hold policy content and suppression ranges. Counts are not pre-certified before the parent runs the producer. There is no synthetic ProjectedStage coverage and no general Split-path claim.

The test-only observer wraps the actual domain_policy second processing_inner(false) result, recording its real returned query/error, depth, endpoints, physical Domain, window and exact policy remaining before/at return. A separate scalar event records real work accounting before/after and accounting errors. Depth zero and retained-child second-query calls are distinguishable. Partial query work on an error is explicitly unknown because the OLD Result exposes no partial receipt; it is never inferred from total policy work. The separate false query is labelled separately from these actual policy events.

Outside an active manual capture, observer callbacks return before allocating/serializing. No extra query, accounting fee/refund, public diagnostic-copy API, cap change or production API is introduced. The non-test production query and accounting expressions are unchanged; owned binding spans still move through the original loop in the original order. A top-level Leaf/Bound certificate does not assert the absence of Preserve inside a Bound operand or inherited retime.

## Frozen source package

`before/{main,scoped}` holds the two existing hook files before edits; the new producer did not exist. `candidate/{main,scoped}` holds exactly the three owned resulting files. `before-pins.json`, `candidate-pins.json`, `main.patch` and `scoped.patch` record exact deltas. All snapshot files are made read-only. Live checkout sources are handed to the parent and this worker remains read-only after handoff.
