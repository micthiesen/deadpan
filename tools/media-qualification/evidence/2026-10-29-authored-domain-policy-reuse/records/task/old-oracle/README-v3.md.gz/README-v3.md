# Superseding frozen source v3

Use candidate-v3, candidate-v3-pins.json and main-v3.patch/scoped-v3.patch. Earlier immutable snapshots and failed first-run source/executable evidence remain intact. README.md describes reproduction; README-v2.md describes the actual Stage fallback witness.

First guarded Main OLD build passed (parent reported 9.06197s); producer failed before emitting output with InvalidTree: audio binding requires a node physical recipe. The opaque fixture used the generic bind helper to reference Sequence group as a Node physical recipe. Validation permits Source, Hold or a processing Retime, not Sequence (audio_binding.rs physical/validate_build). The fix references physical Preserve stage instead and renames this case opaque_bound_stage_with_preserve_and_silence. No unrelated silent Hold binding or coverage assertion was removed. No production implementation change.

No Cargo/native/Git commands by source worker. rustfmt edition2024 skip_children=true passed both. Source worker read-only after v3 handoff; parent retains run/build ownership.
