# Original query reuse research

Read-only research of current Main a21abab03 plus preserved inherited WIP. No source, Cargo, native or Git writes. Ripwire was run first; source bodies below were inspected.

## Correct profile attribution

Main and diagnostic original_request.rs are byte-identical at these sites:

| Line | Actual charge | Phase 1 calls | Accepted units |
| --- | --- | ---: | ---: |
| 127 | domain.audio flattened query | 11,304 | 183,696 |
| 129 | domain.processing(true) | 11,304 | 1,056,046 |
| 131 | domain.policy | 11,304 | 1,600,621 |
| 134 | domain.fades | 8,444 | 1,221,890 |

The three large rows total 3,878,557 units, but they are processing, policy and fades. They are not flat/processing/policy. Complete Original-request file attribution, including Root sites, is 4,074,574. The actual observed profile remains bounded by the failing request; these are not full successful-render totals. Near-cap refusal prefixes vary with actual pointer-hash collision work and must remain separately recorded.

## Preferred candidate: reuse the actual processing tape for policy only when its Preserve stop did not fire

The second top-level walk in domain_policy (audio_policy.rs341) is:

domain.processing_inner(range, work.limits()?, false)

The existing earlier Domain processing query in prepare_original_domain (original_request.rs128) calls:

domain.processing(range, limits) -> processing_inner(range, limits, true)

Both processing_inner bodies use exactly the same actual physical Domain seed, range, cursor advancement and stop_at_bindings=true. Only stop_at_preserve differs.

A successful COMPLETE earlier processing tape containing only AudioSignalContent::Leaf and AudioSignalContent::Bound is a sufficient structural condition for equivalence of these two top-level traversals, subject to the sealed origin/range contract below. This is grounded in the actual walker:

- audio_capture.rs has one operational use of stop_at_preserve, at563. At a Retime, true plus pitch.processes(scale==ONE) breaks with AudioSignalContent::Stage through stage_content. It cannot return a Leaf or Bound after taking that branch.
- The Bound stops at219 (seeded gap) and391 (node) are guarded by stop_at_bindings and occur before the Retime branch. That flag is true in both queries.
- A successful full tape with no Stage/ProjectedStage therefore proves the true-only branch did not fire at any span cursor. All visited-node decisions, transforms, constraints, allocations, retimes, sampling maps and Bound construction before each common Leaf/Bound stop are independent of stop_at_preserve.
- Both queries restart from the same seed at each cursor, clip against the same requested end and advance by allocated_samples.end. Thus their complete span vectors/order agree for successful walks, not merely at a single point.
- Repeat locate_bounded can refuse when work is insufficient. It does not choose a different successful path based on the remaining budget. Reuse removes that actual second traversal, so a new policy operation may legitimately succeed where the old duplicate traversal exhausted its local budget.

This is NOT a claim that the entire provider or a Bound operand contains no Preserve. A Bound can hide arbitrary preserved/retained processing. Both top-level walks stop before entering that operand, so it does not invalidate their equivalence. The existing bound_policy(&bound, ...) recursion must run unchanged afterward. Likewise inherited seed.retimes may describe Preserve before the captured physical seed; both walks copy and use those inherited values identically. The certificate only says that this particular processing walk did not stop at a Preserve.

Additional edge conditions:
- Owned Preserve input rejection at audio_capture.rs558 precedes the flag branch and is identical in both modes; a failed walk cannot mint the certificate.
- Reject Stage and ProjectedStage conservatively. The root walker directly emits Stage or Bound today, but do not let a future ProjectedStage silently become eligible.
- An empty range does not create a saving: domain_policy returns before its second processing query when samples.is_empty(). Do not count a vacuous eligibility check as removed work.
- Original incoming Retained is a separate path. Do not promote this Domain condition into a retained-input or Root-global substitution.
- Preserve detection must retain pitch.processes(scale==ONE), including nonzero Shift at unity. A Preserve-enum-only test is wrong.

### Required sealed design, not an arbitrary public query argument

AudioProcessingQuery fields are public and Clone. A public API that accepts an arbitrary existing query and a Domain cannot establish this proof.

Prefer a Plan-owned query product constructed by the actual Domain processing factory. It retains the actual Domain borrow, original interval and actual successful processing result. Policy uses this sealed product for that same Domain/range. The ordinary direct APIs keep their behavior.

Preserve the current Audio sequence: flattened query and bill, processing query and bill, then policy. Inside policy preserve current-domain policy evaluation before the binding-tape phase. At the phase that currently calls processing_inner(false), perform a bounded, charged eligibility scan. If eligible, iterate the existing tape by borrow; if not, perform the existing false-mode query. Do not move policy before processing merely to combine factories.

The policy binding loop already calls bound_policy with &AudioBound (audio_policy.rs347-355). Borrowing the existing Bound spans needs no new Bound clone. Leaf endpoint checks also work by borrow. The current first-domain.audio policy loop can stay unchanged initially, preserving policy.contents ownership and its current order.

Receipts must distinguish actual work:
- The earlier processing query stays billed once.
- The new policy receipt includes its actual current-policy traversal/evaluation, eligibility inspection, retained recursion, inverse mapping and emission work.
- Do not call work.observed(cached.work, cached.lookup) to pretend the reused traversal ran again.
- Policy lookup stats must omit visits that were actually removed, with an explicit separate attribution if provenance is useful.
- No cap, prior weight, refund, cold/batch activation or numerical-processing change follows from this reuse.

Strongest blocker before implementation is empirical qualification and accounting, not an observed semantic counterexample: freeze actual OLD true/false complete private tapes, their actual work/lookup and full policy output before production. Cover seeded physical Domains, hidden/negative support, Bypass Binding, Repeat/default gap, retained reference Domains, Bound operands containing Preserve, inherited processing retimes, Shift-at-unity, explicit SilentHold and source endpoints. Compare full Bound snapshots and maps, not public/coarse keys. Include noneligible Stage/ProjectedStage fallbacks and exact/short budgets. The existing capture_baseline.rs content/processing serializers and AudioBound::capture_baseline_snapshot are relevant starting points.

I found no existing public unified-query or sealed no-Preserve processing product. This would be a new narrow Plan-owned product over existing actual walker results.

## Two weaker reuse ideas and why not start with them

1. Top-level policy does repeat the earlier flattened query: domain_policy at313 calls domain.audio with the same actual Domain/range. Reusing that fact is semantically plausible. But policy currently consumes this new query and moves AudioContent into policy.contents; borrowing the earlier flattened result introduces an ownership/copy/view decision. The directly billed earlier Domain flat row is only183,696 units (about1.1% of this failing global budget), not the3.88million total. Do not make a large API change on an inflated savings claim.

2. Fades and processing both initially walk with true/true when the plan has no editorial edges (audio_fades.rs104). This is not directly reusable from AudioProcessingQuery: into_processing discards Leaf envelope_extent, envelope_samples, envelope and boundaries at audio.rs345-362. Fades need those fields. With editorial edges it additionally needs EditorialCapture. Audio fades can also perform a second false/false flatten walk for Stage/ProjectedStage and recursively evaluate retained envelope domains. A generic derive-fades-from-processing shortcut is invalid without retaining the missing private facts in a richer actual-walk product.

## Bounded diagnostic to measure eligible removed work

Before designing the production product, measure the second processing walk that is actually executed by current policy, not an estimate from whole policy.work.

In the diagnostic copy, keep a stack-scoped observation around the exact domain.policy call in prepare_original_domain. Its local earlier processing query and actual Domain borrow remain alive throughout the call. Record eligibility (complete tape, all Leaf/Bound), earlier processing work and span counts. At domain_policy depth0, record the actual second processing_inner(false) work/lookup/spans, separately from recursive domain_policy calls.

A scoped callback/observer tied to this direct call is preferable to a long-lived raw-pointer dictionary. If a scoped TLS bridge is used, its RAII scope must retain the actual lexical Domain borrow, match the actual range, restore on nested calls/unwind, and clear before the Domain can drop. No pointer value surviving that scope proves identity. Record counts and accepted actual units in fixed scalar buckets: eligible, noneligible, empty/no-binding, and failed second queries. Preserve successful OLD output and failure order; never skip the walk during profiling.

This gives the actual top-level policy binding-query units eligible for removal. It does not require a cross-request cache or any additional owning context clone.

## Optional frequency probe for complete-query cache reuse

There is another concrete repeated-work seam worth measuring if the above eligible amount is small: shared_eq.rs496-514 builds PreparedOriginalRequest before policy prediction. Later original_inputs.rs375-408 validates that request and may return an existing exact PCM-cache payload without consuming its queries. The cache Entry retains its Context Arc and checks actual Context/range/depth; it already prevents address-reuse aliasing.

Add fixed scalar diagnostic counters at the existing successful Cached return:
- whether prepared is Some;
- each prepared query product's actual already-billed work;
- whether validation matched the exact incoming Root/Domain and range;
- payload-hit count versus stale-key/miss.

Do not add a generic pointer-frequency cache. The existing live Entry and validate_original are the identity proof. For per-key frequency, use diagnostic counters parallel to Graph's64 live slots, reset on existing insert/remove and folded when the actual entry retires. Avoid putting counters into Cache/Entry themselves: Cache::resident_frames uses size_of::<Self>(), so changing those layouts would perturb real admission. A diagnostic owner next to Graph can track live slot generations without retaining extra Context Arcs. Aggregate scalar counts may be enough.

If a large amount of prepared-query work is rebuilt on actual live cache hits, a future extension could retain exact sealed query products with existing entries and make them available before policy prediction. That remains a candidate, not proven savings. Existing cached payloads retain no RootReadQueries. Moving a lookup earlier, retaining query allocations/leases and avoiding Graph self-borrows across recursive preparation all require design. Source/fingerprint, depth and cancellation checks on PCM hits remain mandatory; prediction availability is not resource or intrinsic-processing eligibility.

## Conclusion

Prefer measuring and qualifying the restricted actual processing-tape reuse for top-level Domain policy. It has a direct walker proof and can avoid new Bound clones while leaving recursive policy and numerical work untouched. The present profile does not yet establish its eligible work amount. Do not merge all three query types or infer whole-pipeline reuse from matching public spans.
