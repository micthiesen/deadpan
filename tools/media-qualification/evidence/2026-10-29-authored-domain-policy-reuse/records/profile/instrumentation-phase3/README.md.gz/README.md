# Phase 3 actual duplicate-walk and PCM-hit probes

Diagnostic filesystem copy only. No production reuse, optimization or query elimination. All old walks, bills, failure order and numerical operations still execute. No Cargo/native/Git run by this worker. Phase 1 and 2 source snapshots are preserved.

## Actual top-level second processing walk

AudioDomain::policy_with_diagnostic_observer is a diagnostic-only public method using the same policy body as ordinary policy. The original private domain_policy signature wraps domain_policy_observed with no observer; recursive bound_policy remains unchanged and passes through that ordinary wrapper. PolicyWork and AudioPolicyQuery layouts do not change.

The observed entry uses a borrowed FnMut callback on the stack, never TLS/raw-pointer identity storage. Only depth zero reports:
0 no bindings, 1 empty range, 2 actual second processing_inner(false) success with its exact work/lookup/span count, 3 actual second-walk error. Failure before the second walk yields no callback; no unknown partial work is invented.

prepare_original_domain retains its actual earlier processing result and physical Domain throughout the call. It computes eligibility as all actual complete earlier spans Leaf/Bound and makes lexical borrows inside the callback. Stage/ProjectedStage are excluded. It ALWAYS performs the existing false-mode query. No Bound or query is cloned.

Only after whole policy returns Ok and its existing control.spend_plan_work(policy.work) succeeds does the scalar observation enter the accepted bucket. Policy errors and refused whole-query bills are separate buckets. Successful second-walk work inside a later failed policy remains only in the corresponding failed bucket, not accepted-work savings. Skipped no-binding/empty cases are explicit, so vacuous eligibility is not counted as a removed walk.

DP_POLICY_SECOND is nonadditive attribution grouped by outcome=accepted/policy_error/bill_error and eligible=true/false. It includes calls, earlier work/spans, callback count, skip/success/failure/before-second counts, actual successful second work/spans/lookup and whole returned policy work where known. accepted_subset is true only for accepted buckets whose second work is <= the actual accepted whole policy work. This is gross old duplicate-walk quantity, not net savings after a future eligibility scan or production implementation.

Probe recording uses try_borrow_mut so diagnostics cannot introduce a borrow panic on an original error path. To establish complete accepted-policy coverage in the actual run, parent should reconcile accepted probe calls with the actual Domain policy bill call count and check observer counts/status totals. An unavailable optional probe record is skipped rather than changing the original outcome.

## Successful exact PCM-cache payload hit

At the existing successful Read::Cached return, after exact prepared-request validation, parent/range/depth checks, dependency/fingerprint readmission and final control.check, a scalar hit counter records prepared Some/None. With Some it borrows the existing query products and records their already-billed flat/processing/policy/fades work plus fades-present count. It performs no lookup, allocation, Arc clone or new charge.

DP_ORIGINAL_PCM_HITS reports those nonadditive scalars. No Cache, Entry, graph or payload layout changes. Only diagnostic ReadWork-owned scalar state grows. This measures real successful payload returns; the old original_inputs.rs:401 site counts dependency-readmission iterations, NOT PCM hits. The earlier read-only investigation wording was corrected accordingly.

## Preserved evidence and validity

Phase 1/2 Stage/global acceptance logic, transfer labels, Core error diagnostics and actual numerical assertions are unchanged. Parent owes the optimized pinned exact explicit-play run with same outer prefix-two limited 0+4096 resource-exhaustion window, exact global conservation and zero overflow. Existing address-hash collision comparison variation can alter the exact near-cap error prefix, which must still be preserved verbatim. Instrumented elapsed time is not speed evidence.
