//! Diagnostic-copy-only accepted-work attribution. No per-charge allocation/I/O.
use super::StageAudioError;
use std::panic::Location;

const SLOTS: usize = 512;

#[derive(Clone, Copy)]
pub(super) struct Site {
    location: &'static Location<'static>,
    admission: bool,
    transfer_identity: Option<bool>,
}
impl Site {
    pub(super) fn direct(location: &'static Location<'static>) -> Self {
        Self {
            location,
            admission: false,
            transfer_identity: None,
        }
    }
    pub(super) fn admission(location: &'static Location<'static>) -> Self {
        Self {
            location,
            admission: true,
            transfer_identity: None,
        }
    }
    pub(super) fn transfer(location: &'static Location<'static>, identity: bool) -> Self {
        Self {
            location,
            admission: false,
            transfer_identity: Some(identity),
        }
    }
    fn key(self, cache: bool) -> usize {
        let address = self.location as *const Location<'static> as usize;
        let transfer = match self.transfer_identity {
            None => 0,
            Some(false) => 4,
            Some(true) => 8,
        };
        (address >> 3)
            .wrapping_mul(0x9e37_79b9)
            .wrapping_add(usize::from(self.admission) * 2 + usize::from(cache) + transfer)
    }
    fn same(self, other: Self) -> bool {
        std::ptr::eq(self.location, other.location)
            && self.admission == other.admission
            && self.transfer_identity == other.transfer_identity
    }
    fn transfer_label(self) -> &'static str {
        match self.transfer_identity {
            None => "none",
            Some(false) => "false",
            Some(true) => "true",
        }
    }
}

#[derive(Clone, Copy)]
struct Slot {
    site: Site,
    cache: bool,
    calls: usize,
    units: usize,
}
#[derive(Clone, Copy)]
struct Rejected {
    site: Site,
    cache: bool,
    amount: usize,
    before: usize,
    reason: &'static str,
}
#[derive(Clone, Copy)]
struct Query {
    location: &'static Location<'static>,
    cache: bool,
    remaining: usize,
    maximum: usize,
}

#[derive(Clone, Copy)]
pub(super) struct PolicySample {
    pub(super) eligible: bool,
    pub(super) earlier_work: usize,
    pub(super) earlier_spans: usize,
    pub(super) observer_events: usize,
    pub(super) status: u8,
    pub(super) second_work: usize,
    pub(super) second_lookup: [usize; 3],
    pub(super) second_spans: usize,
    // 0: whole policy succeeded and its original bill was accepted;
    // 1: policy returned error; 2: whole policy returned but bill was refused.
    pub(super) outcome: usize,
    pub(super) policy_work: usize,
}

#[derive(Clone, Copy, Default)]
struct PolicyTotals {
    calls: usize,
    earlier_work: usize,
    earlier_spans: usize,
    observer_events: usize,
    skipped_no_binding: usize,
    skipped_empty: usize,
    second_success: usize,
    second_failed: usize,
    before_second: usize,
    second_work: usize,
    second_lookup: [usize; 3],
    second_spans: usize,
    policy_work: usize,
}

#[derive(Clone, Copy, Default)]
struct PcmHitTotals {
    prepared: usize,
    unprepared: usize,
    prepared_with_fades: usize,
    query_work: [usize; 4],
}

#[derive(Clone, Copy)]
pub(super) struct Trace {
    slots: [Option<Slot>; SLOTS],
    overflow_calls: [usize; 2],
    overflow_units: [usize; 2],
    rejected: Option<Rejected>,
    last_query: Option<Query>,
    policy: [PolicyTotals; 6],
    pcm_hits: PcmHitTotals,
    pub(super) dumped: bool,
}
impl Default for Trace {
    fn default() -> Self {
        Self {
            slots: [None; SLOTS],
            overflow_calls: [0; 2],
            overflow_units: [0; 2],
            rejected: None,
            last_query: None,
            policy: [PolicyTotals::default(); 6],
            pcm_hits: PcmHitTotals::default(),
            dumped: false,
        }
    }
}
impl Trace {
    pub(super) fn policy_sample(&mut self, sample: PolicySample) {
        let total = &mut self.policy[sample.outcome * 2 + usize::from(sample.eligible)];
        total.calls += 1;
        total.earlier_work += sample.earlier_work;
        total.earlier_spans += sample.earlier_spans;
        total.observer_events += sample.observer_events;
        total.policy_work += sample.policy_work;
        match sample.status {
            0 => total.skipped_no_binding += 1,
            1 => total.skipped_empty += 1,
            2 => {
                total.second_success += 1;
                total.second_work += sample.second_work;
                total.second_spans += sample.second_spans;
                for (out, value) in total.second_lookup.iter_mut().zip(sample.second_lookup) {
                    *out += value;
                }
            }
            3 => total.second_failed += 1,
            _ => total.before_second += 1,
        }
    }

    pub(super) fn original_pcm_hit(&mut self, prepared: Option<([usize; 4], bool)>) {
        if let Some((work, fades)) = prepared {
            self.pcm_hits.prepared += 1;
            self.pcm_hits.prepared_with_fades += usize::from(fades);
            for (out, value) in self.pcm_hits.query_work.iter_mut().zip(work) {
                *out += value;
            }
        } else {
            self.pcm_hits.unprepared += 1;
        }
    }

    pub(super) fn accept(&mut self, site: Site, cache: bool, amount: usize) {
        let first = site.key(cache) & (SLOTS - 1);
        for probe in 0..SLOTS {
            let index = (first + probe) & (SLOTS - 1);
            match &mut self.slots[index] {
                Some(slot) if slot.cache == cache && slot.site.same(site) => {
                    slot.calls = slot.calls.saturating_add(1);
                    slot.units += amount;
                    return;
                }
                None => {
                    self.slots[index] = Some(Slot {
                        site,
                        cache,
                        calls: 1,
                        units: amount,
                    });
                    return;
                }
                _ => {}
            }
        }
        let lane = usize::from(cache);
        self.overflow_calls[lane] = self.overflow_calls[lane].saturating_add(1);
        self.overflow_units[lane] += amount;
    }

    pub(super) fn reject(
        &mut self,
        site: Site,
        cache: bool,
        amount: usize,
        before: usize,
        reason: &'static str,
    ) {
        if self.rejected.is_none() {
            self.rejected = Some(Rejected {
                site,
                cache,
                amount,
                before,
                reason,
            });
        }
    }

    pub(super) fn query(
        &mut self,
        location: &'static Location<'static>,
        cache: bool,
        remaining: usize,
        maximum: usize,
    ) {
        self.last_query = Some(Query {
            location,
            cache,
            remaining,
            maximum,
        });
    }

    pub(super) fn dump(
        &self,
        canonical: usize,
        cache: usize,
        maximum: usize,
        start: i64,
        frames: u32,
        error: &StageAudioError,
    ) {
        let mut totals = self.overflow_units;
        for slot in self.slots.iter().flatten() {
            totals[usize::from(slot.cache)] += slot.units;
        }
        eprintln!(
            "DP_WORK_TRACE_BEGIN start={start} frames={frames} error={error:?} canonical={canonical} cache={cache} maximum={maximum} canonical_remaining={} cache_remaining={} accepted_canonical={} accepted_cache={} conserved={} overflow_calls={:?} overflow_units={:?} slots={SLOTS}",
            maximum.saturating_sub(canonical),
            maximum.saturating_sub(cache),
            totals[0],
            totals[1],
            totals == [canonical, cache],
            self.overflow_calls,
            self.overflow_units,
        );
        for (index, total) in self.policy.iter().enumerate() {
            if total.calls == 0 {
                continue;
            }
            let outcome = ["accepted", "policy_error", "bill_error"][index / 2];
            eprintln!(
                "DP_POLICY_SECOND nonadditive=true outcome={outcome} eligible={} calls={} earlier_work={} earlier_spans={} observer_events={} skipped_no_binding={} skipped_empty={} second_success={} second_failed={} before_second={} second_work={} second_spans={} visited_nodes={} sequence_comparisons={} iteration_comparisons={} policy_result_work={} accepted_subset={}",
                index % 2 == 1,
                total.calls,
                total.earlier_work,
                total.earlier_spans,
                total.observer_events,
                total.skipped_no_binding,
                total.skipped_empty,
                total.second_success,
                total.second_failed,
                total.before_second,
                total.second_work,
                total.second_spans,
                total.second_lookup[0],
                total.second_lookup[1],
                total.second_lookup[2],
                total.policy_work,
                index / 2 == 0 && total.second_work <= total.policy_work,
            );
        }
        eprintln!(
            "DP_ORIGINAL_PCM_HITS nonadditive=true prepared={} unprepared={} prepared_with_fades={} prepared_flat_work={} prepared_processing_work={} prepared_policy_work={} prepared_fades_work={}",
            self.pcm_hits.prepared,
            self.pcm_hits.unprepared,
            self.pcm_hits.prepared_with_fades,
            self.pcm_hits.query_work[0],
            self.pcm_hits.query_work[1],
            self.pcm_hits.query_work[2],
            self.pcm_hits.query_work[3],
        );
        if let Some(query) = self.last_query {
            eprintln!(
                "DP_WORK_QUERY cache={} remaining={} maximum={} site={}:{}:{}",
                query.cache,
                query.remaining,
                query.maximum,
                query.location.file(),
                query.location.line(),
                query.location.column(),
            );
        }
        if let Some(rejected) = self.rejected {
            eprintln!(
                "DP_WORK_REJECT cache={} admission={} transfer_identity={} amount={} before={} reason={} site={}:{}:{}",
                rejected.cache,
                rejected.site.admission,
                rejected.site.transfer_label(),
                rejected.amount,
                rejected.before,
                rejected.reason,
                rejected.site.location.file(),
                rejected.site.location.line(),
                rejected.site.location.column(),
            );
        }
        for slot in self.slots.iter().flatten() {
            eprintln!(
                "DP_WORK_SITE cache={} admission={} transfer_identity={} calls={} units={} site={}:{}:{}",
                slot.cache,
                slot.site.admission,
                slot.site.transfer_label(),
                slot.calls,
                slot.units,
                slot.site.location.file(),
                slot.site.location.line(),
                slot.site.location.column(),
            );
        }
        eprintln!("DP_WORK_TRACE_END");
    }
}
