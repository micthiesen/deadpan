# Phase 2 transfer identity attribution

Diagnostic filesystem copy only; no production optimization. No Cargo/native/Git run by this worker. Phase 1 before/candidate evidence is preserved.

PreparedTransfer::apply_wide now uses track_caller and passes its existing exact 1 + stages.len() charge through the same WorkControl::spend_plan_work_at helper, with Site::transfer(caller, self.is_identity()). The charge remains before apply_transfer. The identity check only labels the diagnostic; it skips no charge, arithmetic or sample processing.

Site adds an Option<bool> transfer identity dimension. Direct and admission-construction categories set None; transfer categories set the existing is_identity() result. Pointer hash and equality include this dimension. There is no per-call string hash, allocation, formatting or extra work charge. Existing global acceptance/overflow/conservation semantics are unchanged.

DP_WORK_SITE and DP_WORK_REJECT now include transfer_identity=none/true/false immediately after the admission field. Transfer sites name the actual apply_wide caller instead of the shared application implementation. The dump-only label conversion returns static strings.

Only authored_gain.rs and work_diagnostic.rs change in phase 2. stages.rs is preserved byte-identical, as are all phase 1 Core files and sound_context_admission.rs. No visibility change was needed because the helper is visible to child modules. All 1,506 Main baseline inputs remain unchanged.

Parent owes an optimized pinned exact-filter run of the same selected-play witness, unchanged prefix-two limited 0+4096 Core binding failure, global conservation and zero overflow. There is no current identity-cost conclusion until that run.
