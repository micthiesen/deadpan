//! Diagnostic-copy-only accepted-work attribution. No per-charge allocation/I/O.
use super::StageAudioError;
use std::panic::Location;

const SLOTS: usize = 512;

#[derive(Clone, Copy)]
pub(super) struct Site {
    location: &'static Location<'static>,
    admission: bool,
    transfer_identity: Option<bool>,
}
impl Site {
    pub(super) fn direct(location: &'static Location<'static>) -> Self {
        Self {
            location,
            admission: false,
            transfer_identity: None,
        }
    }
    pub(super) fn admission(location: &'static Location<'static>) -> Self {
        Self {
            location,
            admission: true,
            transfer_identity: None,
        }
    }
    pub(super) fn transfer(location: &'static Location<'static>, identity: bool) -> Self {
        Self {
            location,
            admission: false,
            transfer_identity: Some(identity),
        }
    }
    fn key(self, cache: bool) -> usize {
        let address = self.location as *const Location<'static> as usize;
        let transfer = match self.transfer_identity {
            None => 0,
            Some(false) => 4,
            Some(true) => 8,
        };
        (address >> 3)
            .wrapping_mul(0x9e37_79b9)
            .wrapping_add(usize::from(self.admission) * 2 + usize::from(cache) + transfer)
    }
    fn same(self, other: Self) -> bool {
        std::ptr::eq(self.location, other.location)
            && self.admission == other.admission
            && self.transfer_identity == other.transfer_identity
    }
    fn transfer_label(self) -> &'static str {
        match self.transfer_identity {
            None => "none",
            Some(false) => "false",
            Some(true) => "true",
        }
    }
}

#[derive(Clone, Copy)]
struct Slot {
    site: Site,
    cache: bool,
    calls: usize,
    units: usize,
}
#[derive(Clone, Copy)]
struct Rejected {
    site: Site,
    cache: bool,
    amount: usize,
    before: usize,
    reason: &'static str,
}
#[derive(Clone, Copy)]
struct Query {
    location: &'static Location<'static>,
    cache: bool,
    remaining: usize,
    maximum: usize,
}

#[derive(Clone, Copy)]
pub(super) struct Trace {
    slots: [Option<Slot>; SLOTS],
    overflow_calls: [usize; 2],
    overflow_units: [usize; 2],
    rejected: Option<Rejected>,
    last_query: Option<Query>,
    pub(super) dumped: bool,
}
impl Default for Trace {
    fn default() -> Self {
        Self {
            slots: [None; SLOTS],
            overflow_calls: [0; 2],
            overflow_units: [0; 2],
            rejected: None,
            last_query: None,
            dumped: false,
        }
    }
}
impl Trace {
    pub(super) fn accept(&mut self, site: Site, cache: bool, amount: usize) {
        let first = site.key(cache) & (SLOTS - 1);
        for probe in 0..SLOTS {
            let index = (first + probe) & (SLOTS - 1);
            match &mut self.slots[index] {
                Some(slot) if slot.cache == cache && slot.site.same(site) => {
                    slot.calls = slot.calls.saturating_add(1);
                    slot.units += amount;
                    return;
                }
                None => {
                    self.slots[index] = Some(Slot {
                        site,
                        cache,
                        calls: 1,
                        units: amount,
                    });
                    return;
                }
                _ => {}
            }
        }
        let lane = usize::from(cache);
        self.overflow_calls[lane] = self.overflow_calls[lane].saturating_add(1);
        self.overflow_units[lane] += amount;
    }

    pub(super) fn reject(
        &mut self,
        site: Site,
        cache: bool,
        amount: usize,
        before: usize,
        reason: &'static str,
    ) {
        if self.rejected.is_none() {
            self.rejected = Some(Rejected {
                site,
                cache,
                amount,
                before,
                reason,
            });
        }
    }

    pub(super) fn query(
        &mut self,
        location: &'static Location<'static>,
        cache: bool,
        remaining: usize,
        maximum: usize,
    ) {
        self.last_query = Some(Query {
            location,
            cache,
            remaining,
            maximum,
        });
    }

    pub(super) fn dump(
        &self,
        canonical: usize,
        cache: usize,
        maximum: usize,
        start: i64,
        frames: u32,
        error: &StageAudioError,
    ) {
        let mut totals = self.overflow_units;
        for slot in self.slots.iter().flatten() {
            totals[usize::from(slot.cache)] += slot.units;
        }
        eprintln!(
            "DP_WORK_TRACE_BEGIN start={start} frames={frames} error={error:?} canonical={canonical} cache={cache} maximum={maximum} canonical_remaining={} cache_remaining={} accepted_canonical={} accepted_cache={} conserved={} overflow_calls={:?} overflow_units={:?} slots={SLOTS}",
            maximum.saturating_sub(canonical),
            maximum.saturating_sub(cache),
            totals[0],
            totals[1],
            totals == [canonical, cache],
            self.overflow_calls,
            self.overflow_units,
        );
        if let Some(query) = self.last_query {
            eprintln!(
                "DP_WORK_QUERY cache={} remaining={} maximum={} site={}:{}:{}",
                query.cache,
                query.remaining,
                query.maximum,
                query.location.file(),
                query.location.line(),
                query.location.column(),
            );
        }
        if let Some(rejected) = self.rejected {
            eprintln!(
                "DP_WORK_REJECT cache={} admission={} transfer_identity={} amount={} before={} reason={} site={}:{}:{}",
                rejected.cache,
                rejected.site.admission,
                rejected.site.transfer_label(),
                rejected.amount,
                rejected.before,
                rejected.reason,
                rejected.site.location.file(),
                rejected.site.location.line(),
                rejected.site.location.column(),
            );
        }
        for slot in self.slots.iter().flatten() {
            eprintln!(
                "DP_WORK_SITE cache={} admission={} transfer_identity={} calls={} units={} site={}:{}:{}",
                slot.cache,
                slot.site.admission,
                slot.site.transfer_label(),
                slot.calls,
                slot.units,
                slot.site.location.file(),
                slot.site.location.line(),
                slot.site.location.column(),
            );
        }
        eprintln!("DP_WORK_TRACE_END");
    }
}
