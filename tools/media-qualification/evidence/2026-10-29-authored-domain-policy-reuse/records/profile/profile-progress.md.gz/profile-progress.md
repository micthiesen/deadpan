Base pushed checkpoint a21abab03bcd40c365dd86cfe597d9d530bd7f02, full goal remains active.
Current Main physical source includes preserved inherited WIP; all1506baseline inputs unchanged.
Phase1 accepted-work profile reproduced exact current explicit-play prefix-two limited0+4096 Core audio-binding refusal, exit101; 13.424241s is diagnostic time only.
Canonical/global accepted16777216 exactly cap, cache0, conservationtrue, no slot/Core overflow and no unavailable snapshots.
Last localquery191; binding localused139+attempt2=>141 maximum139. This Core refusal follows exhaustion of the global allowance.
Largest exact rows: PreparedTransfer::apply_wide3407314 (20.3%); Original domain processing/policy/fade trio3878557 (23.1%; initial labels corrected by exact line audit); sharedEq admitted owner query2526399 (15.1%).
No optimization chosen yet. Worker phase2 refines gain transfer charge by actual caller plus identity classification, preserving exact actualcharge. Parent Cargo/native only, no run active until phase2freeze.

Exact line attribution correction: original_request.rs127=flattened183696 (the remaining12321 file units are Root query sites),129=processing1056046,131=policy1600621,134=fades1221890. Initial flat/process/policy naming of the three largest rows was wrong; no savings/optimization was chosen from it. Source Main and diagnostic original_request.rs are byte-identical.

Phase2 and SAME-binary repeat are terminal, source/exe/command guards exactlyequal. Both conserve all acceptedunits, zero detailed/Coreoverflow.
Phase2:16777214accepted/rem2, frozen-projection workexhausted.
Repeat:16777192accepted/rem24, source-occurrence construction work.
Both same one-selected-play prefix-two limited0+4096; rawerrors retained.
Controlled exactsamebinary differs only3of77 rawsite rows: OriginalInputCache collision comparisons+26; finalcutoff soundclock rows-20/-28, net-22. Fixedlookup/insertion/removal/LRUiteration rows agree. Line401 is dependency readmission iterations, NOT a direct cache-hit counter.
Existing pointer-hashed64bucket acceleration accounts actualcollisioncomparisons, so exact near-budget errorprefix varies without codechange. Original strict exacterrorcriterion failed; validity now explicitly uses samewindow resourceexhaustion, exact acceptedconservation, zerooverflow and retainedrawprefixes. No witness acceptance claimed.
Fine transferclassifier:3407314nonidentityunits,0identity; 2768840 shared_components/block.rs25 +638474 member_phases.rs726. Existingcode already skips wholeidentitypasses. No new gainfastpath chosen.
Preferred nextmeasure: actual policy.second top-level processing_inner(false) units eligible for reuse of successful sameDomain/range earlier processing(true) complete Leaf/Bound-only tape. Sole Preserve-stop branch emitsStage, both stopBindings=true, opaqueBound/inheritedretimes not globalnoPreserve. Recursivebound_policy remains mandatory. Needs sealedPlan-owned queryproduct, chargedeligibility at oldsecondqueryphase, freshlimits/newworkreceipts, ordinaryAPIs unchanged and OLDwholeprivate tapes/policies bothvariants frozen before production.
Phase3 worker /root/split_profile_instrumentation now editing diagnostic copy only: safe lexicalborrowed FnMut observer around actual domain.policy (newdiagmethod) plus scalar actual prepared-query work on successful PCM-cachehit afterexisting validations. No Cache/Entry layoutchange; ReadWork counters only. Aggregate successfulsecondwalk only after wholepolicy+globalspend success. Alloldwalks still execute. Parent soleCargo/native, no runactive untilfreeze.
Explorer report original-query-research.md contains exactcodeproof/constraints. Main remains a21abab03 plus inheritedWIP; fullgoalactive, generalSplitdisabled.
