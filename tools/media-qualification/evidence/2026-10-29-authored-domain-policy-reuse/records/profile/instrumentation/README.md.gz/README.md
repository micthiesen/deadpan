# Diagnostic-only accepted work trace

Only the ordinary diagnostic filesystem copy changes. Main's 1,506 pinned inputs remain byte-identical; 1,501 existing diagnostic inputs outside the five owned files remain unchanged. One new diagnostic module is added. No Cargo, native test or Git command was run by this worker.

The first rustfmt invocation omitted the explicit edition and rejected existing 2024 let-chain syntax. The final invocation used edition 2024 and skip_children=true on all six owned files and passed. No acceptance credit comes from rustfmt.

## Global accepted work

ReadWork owns a fixed 512-slot open-addressed table. Keys hash the static Location pointer plus canonical/cache lane and direct/admission category. There is no per-spend file-string hash, allocation, sorting, backtrace or output. Each lookup probes at most 512 slots. Full-table amounts enter explicit lane overflow counters. Interpretation requires both overflow lanes to remain zero; otherwise detailed attribution is incomplete.

Direct Audio charges capture their track_caller site. The actual sound-context admission adapter captures the construction track_caller site once and uses it as its forwarding attribution category. There is still only one charge in WorkControl. Existing canonical/cache checked addition, hard limit and assignment retain their order. Trace acceptance happens only after that assignment. Cancellation/deadline or counter rejection records the first rejected attempt separately without adding it to accepted totals.

Parent review caught that borrowing the ledger after a cancelled/timeout check would introduce a potential panic where the original returned immediately. The rejected-control record now uses try_borrow_mut and passively skips that optional diagnostic if unavailable, preserving the original error. Accepted work still adds zero.

The current preparation bus body is verbatim in prepare_bus_diagnostic_inner. Its wrapper retains the existing prepare_bus_inner entry point and dumps on any returned error, including Plan/Core errors. One flag belongs to the actual ReadWork, so repeated/nested use of that budget dumps at most once. The wrapper copies the fixed trace plus authoritative counters, releases its RefCell borrow, then formats. It uses try_borrow_mut; unavailable snapshots print an explicit incomplete marker and preserve the original returned error. It does not dump successful requests.

Output:
- DP_WORK_TRACE_BEGIN: requested bus interval/error; actual canonical/cache counters and remaining global allowances; table sums including overflow; exact conservation boolean; overflow calls/units.
- DP_WORK_QUERY: last successful control.query_limits call, its static caller, cache lane, remaining global allowance and actual local work cap.
- DP_WORK_REJECT: first globally rejected attempt if one occurred, kept out of accepted units. A rejected control check with an unavailable ledger cannot record this optional field.
- DP_WORK_SITE: every occupied slot's lane/category, accepted calls/units and static file:line:column.
- DP_WORK_TRACE_END.
- DP_WORK_TRACE_UNAVAILABLE: no complete snapshot because the ledger was borrowed. Any occurrence makes global attribution incomplete.

The selected LimitedAudio witness reaches prepare_bus via bus_block. A Core binding failure from that preparation is therefore inside this error wrapper. The dump's bus interval can be the limiter's internal required-context interval; the integration panic retains the outer prefix-two limited 0+4096 witness.

## Core local refusals

The three exact local seams retain their old mutation/error semantics:
- Binding Work::spend commits checked addition before the used > maximum refusal. Its record includes that refused raw increment. Overflow leaves raw used unchanged.
- Binding Work::remaining refuses without changing used.
- Build::local projection and audio_reference::spend keep checked-filter assignment, so refusal leaves used unchanged.

track_caller propagates through Build spend/additional/local/remaining. Caller Location is captured before error closures to avoid attributing an Option closure caller instead of the actual structural site.

DP_CORE_LOCAL_REFUSAL records process sequence, limit 64, seam kind, actual local Work/counter identity, used_before, attempted amount, used_after, maximum and static site. These are local raw counters, never a second global charge or part of global conservation. All three seams share the bounded refusal counter. The 65th event emits DP_CORE_LOCAL_OVERFLOW; later events are suppressed. Any overflow means final local attribution cannot be assumed complete. Do not infer request equality from pointer values: this exact integration test is sequential, and the final error sequence/window must establish the association.

This first pass does not include a per-site Core accepted-prefix table or a second forwarding table. Global admission construction sites provide coarse current attribution; more detail can be added only if the actual result needs it.

## Validity checks owed to parent

Run only the existing exact explicit-play integration filter in the optimized pinned target, with all numerical assertions intact. Require the same final prefix-two limited 0+4096 Core audio binding work exhausted failure as the uninstrumented current run. Reject the cost diagnosis if instrumentation changes that to timeout or another error. Verify global table sums including overflow equal the authoritative canonical/cache counters and detailed overflow is zero. Preserve full source/executable pins, command/environment, stdout/stderr and elapsed time. Instrumented duration, stack size and process memory are not speed or memory improvement evidence.
