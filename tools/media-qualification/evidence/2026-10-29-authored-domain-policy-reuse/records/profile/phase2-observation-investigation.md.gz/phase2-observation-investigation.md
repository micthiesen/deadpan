# Read-only phase 2 refusal investigation

No source edits, Cargo, native execution or Git commands by this worker.

The first phase 2 run and its repeat have identical recorded commands, pinned executable guards and source manifests. Each reports 77 accepted-work sites, conserved global totals and zero table overflow. Their raw site-record multisets differ at exactly three records; all other 74 records, including both nonidentity transfer callers, are literally equal. There are 76 distinct printed keys because one printed location has two distinct static-location slots. Analysis sums duplicate printed keys rather than discarding a record; raw-row totals still conserve the authoritative counters.

The changed existing Original input hash-chain comparison site, shared_eq/original_inputs.rs:145, bills one unit per candidate. It has 9,838 accepted comparisons in the first phase 2 run and 9,864 in the repeat: +26. The fixed hash-call count 8,487, dependency-readmission iteration count 5,350 (not a proven PCM-hit count), insert count 3,029, remove count 2,901 and LRU probe count 2,901 are equal across both runs and phase 1. Phase 1 had 10,004 hash-chain comparisons.

The only other changed sites in the phase 2 repeat are sound_clocks.rs:62 (-2 calls, -20 units) and sound_clocks.rs:300 (-1 call, -28 units), at the exhausted work prefix. Net accepted-unit difference is +26 -20 -28 = -22, exactly the global difference 16,777,192 -16,777,214. This is not a normalization; the distinct errors and raw totals remain intact.

## Exact address-dependent work mechanism

shared_eq/original_inputs.rs:69-72 constructs LookupKey.context from Arc::as_ptr for Domain or retained.as_ptr for Retained. LookupKey::bucket at lines61-65 hashes that address plus the other fixed key fields with DefaultHasher and reduces modulo the fixed 64 buckets. find at139 bills the fixed hash work, then145 bills one unit for each candidate in that bucket's intrusive collision chain. Actual allocation addresses can differ across processes; the collision-chain comparison count is therefore capable of changing even when exact-key hits, LRU operations and numerical requests stay the same. This mechanism is in the existing inherited source and phase 2 does not edit it.

The repeated SAME phase 2 executable already demonstrates actual accepted-comparison variation without any diagnostic code/layout change between those two runs. Thus a changed exact near-cap refusal is not by itself proof that phase 2 changed the transfer charge or arithmetic. It also does not establish PCM equivalence for the rejected final request, which returns no result.

## Layout path review

Phase 2 adds one Option<bool> label to diagnostic Site and no fields to PreparedTransfer, WorkControl, Issuer, Lease or any graph/cache payload. stages.rs and sound_context_admission.rs are byte-identical to phase 1. The existing issuer/lease store references to RefCell<ReadWork>, not ReadWork inline. CoreAdmission holds a mutable reference to the outer adapter. The searches found no admission Layout/size_of query for ReadWork, PreparationBudget, WorkControl, Trace, Site or the admission adapter, nor a generic admission/policy-by-value reservation. The diagnostic label is consumed only by diagnostic hashing/equality/dump; apply_wide still performs exactly the existing 1+stages.len() charge before the same apply_transfer call.

Rust repr(Rust) layout sizes were not compiled/measured in this read-only review, so this is not a claim that every diagnostic stack type has equal size. A label/layout/compiler change could alter allocation addresses or timing indirectly. The key evidence is that address-dependent charged comparisons also vary across identical phase 2 executable runs. No production fix or diagnostic validity-criterion change is authorized by this note.
