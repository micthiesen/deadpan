# Borrowed shared-stop snapshot

At base f75cb108f, add a metered `AdmittedStop::from_boundary` that copies the exact borrowed `Boundary` into a local non-Clone wrapper, reserving its actual repeated-instance array before allocation/copy. Keep legacy `new(owner, before)` behavior intact. Unmetered snapshots use the old ordinary clone and make no admission calls. Metered snapshots charge field/repeat copy work and check stable issuer around spend/reserve; failure drops any live lease without refunding accepted work.

Give SharedMix an independent stop-borrow lifetime and hold `Option<&Boundary>`. Route stop matching uses `OwnerKey::matches` without allocating a comparison key. Adapt policy prediction's SharedMix type signatures. Persistent bus/route/layer clocks and other stop copies remain outside this increment.

Owned files: `crates/deadpan-audio/src/shared_mix.rs`, `crates/deadpan-audio/src/shared_mix/caller_key.rs`, `crates/deadpan-audio/src/shared_mix/caller_key_tests.rs`, `crates/deadpan-audio/src/shared_eq/policy_prediction.rs`. Parent owns the renderer call-site integration and Cargo verification. No Cargo or Git mutation was performed by this subtask.
