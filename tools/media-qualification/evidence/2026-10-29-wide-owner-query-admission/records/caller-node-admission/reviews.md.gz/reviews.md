# Independent reviews for wide queries and temporary stop admission

Three fresh read-only reviewers compared the scoped candidate against base f75cb108f. Parent owned all Cargo/runtime and source corrections.

wide_plan_review, focused shared-budget and provenance: no findings. Range/limits/seed validation order follows the legacy Root and Domain paths. One remaining budget tracks actual canonical and additional copy work. Result allocations stay leased through return/use and release on failure or drop. Existing retained query algorithm and query_tracked walker are unchanged.

wide_audio_review, focused lifetime/validation/accounting: no findings. The real wide guards survive raw reads and recursive tile processing, then drop at their established use scopes. The exact tile-local stop snapshot is built before taking the filter, survives nested reads and mix finish, and releases after the worker is restored. Root mix routing selects its root before route-level validation. SharedMix borrows this stop, eliminating a second copy.

wide_general_review: no verified correctness, validation-order, lifetime, accounting or regression findings. Exact old query and stop identity semantics remain. Its independent scope excluded the documented remaining route/bus/layer owner copies, other Graph containers, authored Graph boundary copies and full recursive cold-resource closure.

The new native query-headroom test initially asserted that failed node admission did no work. Runtime showed the accepted node prefix remained spent, as required. Parent corrected that test to capture its increased accepted work and assert that dropping the query releases memory without refund. Product code did not change for this correction; all 29 final Main Plan executables are byte-identical to the prior passing run.
