# Bounded next-step research: wide renderer owner enumeration

Read-only research against the concurrent checkout on 2026-10-29. No Cargo, tests, Git mutations, or repository writes were performed. The current caller checkpoint must be verified before implementing any proposal below. Read `interface-contract.md`; ran ripwire with `Context::owners`, `read_shared_program`, `read_program`, `authored_eq.rs`, and `shared_eq.rs` in the task.

## Current exact gap

`crates/deadpan-audio/src/authored_eq.rs:199 Context::owners` returns an unguarded `AudioOwnerQuery`. It dispatches to `RenderPlan::audio_gain_owners`, `AudioDomain::gain_owners`, or `AudioOwnerRetainedInput::owners`, then calls `admit_owner_query`: spend `query.work()` once, THEN validate every span's treatment layers. That order matters for false mode and layer-invalid results.

The current admitted `node_description.rs` one-sample retained branch is separate and already avoids rebilling forwarded work. It must not be conflated with these wide calls.

The two wide consumers are `authored_eq.rs:424 read_eq_program` and `shared_eq.rs:299 read_shared_program`. There is no function literally named `read_program` in these files.

### Actual query lifetimes

* `read_eq_program` obtains owners after its PCM reservation and result allocation. It keeps that query through the controlled raw read and the complete span loop. Owner references feed `eq_node`, `eq_tile` recursion, and per-sample gain. None is returned in `WideBlock`. The query naturally drops when the closure exits, before the outer `active_frames -= reservation`. A guard must remain alive across raw reads and recursive tiles; constructing a query guard only long enough to extract/copy the naked query would reopen this gap.
* `read_shared_program` obtains `Option<query>` before sound-plan/beat/root preparation, mix construction, voice registration, route construction, prediction, and PCM admission. Its span/owner slices are read during `original_routes`; prediction borrows them through `policy_prediction::Original` only during `populate`. Later `if let Some(owners) = owners` MOVES the query into the Original processing branch. It remains live during `shared_original_input[_prepared]` and its span/sample loop, then drops at the end of that branch, before the subsequent root/beat processing and `mix.finish`. Nothing borrows this query in the returned `WideBlock`.
* `read_shared_program:410` separately calls `plan.audio_gain_owners(root_range, ...)` for root mix routing. It spends the work once, takes first span/first owner, verifies the root node identity, and builds all root routes. This query is block-local and drops immediately after that collection. It does NOT use `Context::validate_owner_query_layers`; each `SharedMix::route` independently validates the supplied owners before stop matching/range checks. Preserve that order rather than adding whole-query validation ahead of root identity selection.
* `SharedMix::route` makes independent owned clock copies into route layers, component layers, and bus runs. The wide-query lease does not account those copies. Keeping the original query guard longer cannot be claimed to admit them.

## APIs that actually exist

Public admitted wide API today: only `AudioOwnerRetainedInput::owners_admitted(samples, limits, admission) -> AdmittedAudioOwnerQuery<'plan, I, L>` in `deadpan-plan/src/audio_owners.rs:521`.

Public `RenderPlan::audio_gain_owners` and `AudioDomain::gain_owners` have no `_admitted` counterparts. The admitted one-sample APIs `audio_owner_input_candidates_at_admitted` and `owner_input_candidates_at_admitted` are NOT substitutes: they manufacture `at..at+1` and a candidate capture object.

Implementation building blocks already exist in `deadpan-plan/src/audio_owner_query.rs`: guarded `query_tracked` returning `Product`, `State::from_seed`, plus `root_candidates_query` and `domain_candidates_query`. The latter helpers are hard-coded one-sample queries. Existing `AdmittedAudioOwnerQuery` lives in `audio_retained_owner_query.rs`; it owns the actual `Owned<AudioOwnerQuery, I, L>` and exposes borrowed `query()`, work/canonical/additional and `was_forwarded()`. It does not borrow the admission object and exposes no public naked extraction/Clone. Its current fields are module-private, so non-retained construction needs a crate-internal checked constructor or moving/generalizing this wrapper into a common owner-query module, not bypassing its ownership.

### Validation/error order to preserve

Root legacy: range bound and `audio_duration` check, `Walk::root`, set `allow_inactive`, then `query_tracked` validates limits and reversed range. Domain legacy: physical range bound, unmetered `Walk::from_seed` clone, set `allow_inactive`, then query limits/reversed range validation. A metered domain seed copy needs to precede the same inherited limit validation, as existing `domain_candidates_query` explicitly documents; new resource refusal may preempt subsequent work, but false mode must keep the old order and output/backend behavior.

Retained legacy already calls the admitted implementation with `Unmetered`, whose entry validates limits before reversed range/envelope traversal. Its additional empty-support debit and zero-remainder second-validation behavior are documented in `audio_retained_owner_query.rs` and should be reused unchanged.

Audio wrapper false mode: call old-equivalent query with supplied limits, spend its canonical work exactly once only AFTER successful construction, then validate layers. True mode: query forwards actual canonical+additional work as it executes; do not spend it again; validate layers afterward. Do not replace supplied false limits with defaults. Check `was_forwarded` against admission mode as current caller code does.

## Narrow wide-query proposal

1. Plan: add public `RenderPlan::audio_gain_owners_admitted` and `AudioDomain::gain_owners_admitted`, sharing the current query walk/backend rather than reconstructing queries or replaying one-sample candidate calls. Reuse the current wrapper with a checked internal Product-to-wrapper constructor. Keep old APIs as the false path/oracle. Limit this increment to the AudioSample gain-owner flavor needed by Context and the root mix query; no definition/SignalSample or unrelated Graph APIs.
2. Audio: add `Context::owners_admitted(..., &mut A)` with the same dispatch and layer-validation policy. Return the wrapper, not a copied query. Switch both wide consumers and the separate root mix query to retain wrappers for the exact lifetimes above; read through `guard.query()` at each existing use, including prediction input.
3. At each call site use a lexical construction block: compute limits first; create `let mut admission = Admission::new(self, control)` inside the block; construct and return the guard; exit block to drop the mutable controller borrow before doing sound preparation, raw reads, `make_room`, or recursive renderer work. The returned Lease references only the request `RefCell<ReadWork>`, not `StageAudio`, so it survives safely while later mutable self calls see outstanding metadata through `make_room`. Do not keep Admission as a field or callback that surrounds recursion.
4. Verification owned by parent: immutable false-mode query field/work snapshots for Root/Domain/Retained, exact and one-short allocation/work failures with repeated owners, layer-validation/debit order, root clock error order, peak retained across nested native admission, release at actual use scopes, cancellation and wrong issuer, unchanged audio oracle. Keep existing no-refund behavior. No Graph transfer is needed for these temporary queries.

Scope excludes other Graph maps, mix route/bus owner copies, batching/cold recursive closure, source/PCM/cache policies, and historical numerical receipt edits.

## Stop snapshots and SharedMix are independently isolatable

There are two distinct transient stop copies in the current shared renderer:

* `shared_eq.rs:1028 let boundary = graph.nodes[id].stop.clone()` invokes Boundary::clone THROUGH AdmittedStop's Deref. It copies the repeat-array into a naked local Boundary even though the stored Graph stop is admitted. It stays alive through the entire tile recursion, then drops on tile exit. Borrowing `&graph.nodes[id].stop` cannot replace it directly: recursive `read_shared_program` needs `&mut Graph` and may grow/reallocate nodes.
* `shared_eq.rs:374 program.stop.cloned()` makes a second Boundary copy for SharedMix. SharedMix merely reads the stop and is consumed synchronously by finish; it need not own that copy.

A coherent smaller next increment can therefore close JUST transient shared stop ownership without requiring new Plan wide APIs:

1. Add an admitted copy constructor from the exact borrowed Boundary in `shared_mix/caller_key.rs` (or carefully reuse AdmittedStop::new with the stored full boundary owner and exact before stage). Reserve the actual repeat array before copying and retain a local opaque lease; do not clone the disarmed Graph charge or obtain a naked Boundary. Prefer copy-from-Boundary to avoid making reconstruction identity a new hidden assumption. Keep value before lease. False mode remains the old boundary copy with zero extra callbacks; true mode meters the copy. Construct it with a short Admission scope before filter.take, so a refused snapshot leaves the graph worker intact.
2. Give `SharedMix` a separate stop-borrow lifetime and store `Option<&Boundary>`. Pass `program.stop` directly. This removes its duplicate repeat allocation entirely. The borrow originates in tile-local admitted snapshot (or caller-owned program input), never a graph node held across mutable recursion. Update SharedMix type annotations in `shared_eq.rs` and `shared_eq/policy_prediction.rs`.
3. Replace stop matching `OwnerKey::new(owner) == stop.owner` with existing `stop.owner.matches(owner)` to remove the transient comparison allocation as an exact same-key predicate. `register` still has two temporary OwnerKey comparisons that can use a borrowed identity predicate; do not silently roll in persistent bus keys, clock clones, route layers, components or runs.
4. Verify matching counterexamples, exact/one-short snapshot peak, stop lease alive through nested render admission, early error worker restoration, no duplicate second stop allocation, and unchanged false/audio oracle. This scope does not close authored_eq.rs's separate `AudioTreatmentBoundary::clone` at line 711 or any mix clock clone.

Recommendation: choose one increment after checkpoint verification. The shared stop snapshot plus borrowed SharedMix stop is smaller and self-contained; wide Context query admission is the next distinct Plan+Audio increment and requires the two missing public APIs. Neither should be described as full renderer ownership closure.
