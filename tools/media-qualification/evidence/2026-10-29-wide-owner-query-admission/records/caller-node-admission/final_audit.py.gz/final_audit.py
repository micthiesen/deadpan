from pathlib import Path
import hashlib,json,re
s=Path(__file__).resolve().parent
main=Path('/Users/michael/Code/deadpan');scope=Path('/tmp/deadpan-query-groundwork-2026-10-26/scoped')
sha=lambda b:hashlib.sha256(b).hexdigest()
negative={'wide-integrated-build1':101,'wide-integrated-build3':101,'wide-audio1':101,'wide-split':101}
receipts=[]
for p in sorted(s.glob('*.json')):
 r=json.loads(p.read_text())
 if not isinstance(r,dict) or 'started_at' not in r or 'command' not in r:continue
 assert r.get('exit_code')==negative.get(p.stem,0),(p.stem,r.get('exit_code'))
 assert r['sources_unchanged'] and r['binaries_unchanged'],p.stem
 for name,h in r['streams'].items():
  b=Path(name).read_bytes();assert len(b)==h['bytes'] and sha(b)==h['sha256']
 receipts.append({'label':p.stem,'exit_code':r['exit_code'],'seconds':r['seconds'],'sha256':sha(p.read_bytes()),'source_inputs':len(r['source_before'])})
final=['wide-qualified-build2','wide-audio2','wide-stages','wide-scoped-qualified-build2','wide-scoped-audio','wide-scoped-plan','wide-scoped-stages','wide-definition','wide-scoped-birth','wide-strict1','wide-split']
for label in final:
 r=json.loads((s/(label+'.json')).read_text())
 for name,h in r['source_after'].items():
  b=Path(name).read_bytes();assert len(b)==h['bytes'] and sha(b)==h['sha256'],(label,name)
before={(r['package'],r['name']):r for r in json.loads((s/'wide-qualified-build1-pins.json').read_text())}
after={(r['package'],r['name']):r for r in json.loads((s/'wide-qualified-build2-pins.json').read_text())}
assert before.keys()==after.keys()
plan_keys=[k for k in after if k[0]=='plan'];assert len(plan_keys)==29
for k in plan_keys:
 assert before[k]['sha256']==after[k]['sha256']
 for row in [before[k],after[k]]:assert sha(Path(row['path']).read_bytes())==row['sha256']
r=json.loads((s/'wide-plan1.json').read_text())
changed=[]
for name,h in r['source_after'].items():
 b=Path(name).read_bytes()
 if len(b)!=h['bytes'] or sha(b)!=h['sha256']:changed.append(name)
assert changed==[str(main/'crates/deadpan-audio/src/shared_eq/wide_query_graph_tests.rs')],changed
reuse={'receipt':'wide-plan1','final_build':'wide-qualified-build2','all_29_plan_executables_identical':True,'source_difference_only_in_unlinked_audio_test':changed,'other_source_inputs_current':True}
(s/'main-plan-reuse-audit.json').write_text(json.dumps(reuse,indent=2)+'\n')
rows=json.loads((s/'task-source-pins.json').read_text())
data=(s/'index-blobs.bin').read_bytes();offset=0;equality=[]
for row in rows:
 end=data.index(b'\n',offset);header=data[offset:end].decode().split();assert header[1]=='blob'
 length=int(header[2]);body=data[end+1:end+1+length];offset=end+2+length
 assert body==(scope/row['path']).read_bytes() and sha(body)==row['sha256']
 assert sha((main/row['path']).read_bytes())==row['main_sha256']
 equality.append({'path':row['path'],'blob':header[0],'sha256':row['sha256'],'scoped_index_equal':True,'main_equal':row['main_equals_scoped']})
assert offset==len(data) and len(rows)==18 and sum(r['main_equal'] for r in equality)==15
(s/'index-source-equality.json').write_text(json.dumps(equality,indent=2)+'\n')
owned={r['path'] for r in rows};unchanged={}
for variant,root in [('main',main),('scoped',scope)]:
 pins=json.loads((s/(variant+'-initial-authority.json')).read_text());count=0
 for n,h in pins.items():
  if n in owned:continue
  assert sha((root/n).read_bytes())==h,(variant,n)
  count+=1
 unchanged[variant]=count
for row in json.loads((s/'immutable-oracle-pins.json').read_text()):
 for root in [main,scope]:assert sha((root/row['path']).read_bytes())==row['sha256']
plans={}
for label in ['wide-qualified-build1','wide-scoped-qualified-build2']:
 rs=json.loads((s/'plan-results'/label/'results.json').read_text())
 assert len(rs)==29 and all(r['exit_code']==0 for r in rs)
 plans[label]={'targets':29,'passed':sum(int(v[1]) for r in rs for v in r['test_results']),'ignored':sum(int(v[3]) for r in rs for v in r['test_results'])}
split_text=(s/'wide-split.stdout').read_text();split=re.findall(r'^test ([\w:]+) \.\.\. (ok|FAILED|ignored)',split_text,re.M)
assert len(split)==7 and sum(v=='ok' for _,v in split)==3 and sum(v=='FAILED' for _,v in split)==4
diagnostics=(s/'wide-split.stderr').read_text()
for text in ['Source/Sequence refinement, revision cut-three, limited 0+511','nested selected play root_sound=false, revision prefix-two, limited 0+4096','one selected play, revision prefix-two, limited 0+4096','root sound processed=true, revision root-sound-refinement, limited 0+511']:
 assert text in diagnostics
result={'all_terminal':True,'receipts':receipts,'negative_results_retained':negative,'source_files':18,'rust_files':16,'main_equal_source_files':15,'scope_index_equal':True,'other_initial_inputs_unchanged':unchanged,'final_compiled_sources_current':True,'main_plan_reuse':reuse,'plan_results':plans,'immutable_oracles_unchanged':True,'split':{'passed':3,'failed':4,'cases':split,'seconds':json.loads((s/'wide-split.json').read_text())['seconds'],'new_failure_since_previous_checkpoint':'root sound processed=true, root-sound-refinement, limited0+511: plan work per read'},'scoped_patch_sha256':sha((s/'task-scoped.patch').read_bytes())}
(s/'final-audit.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k not in ['receipts','split','main_plan_reuse']}))
