# Next bounded resource closure: Authored EQ node publication

Read-only research, 2026-10-29. Inspected RepoMain at /Users/michael/Code/deadpan; authored_eq.rs is byte-identical to /tmp/deadpan-query-groundwork-2026-10-26/scoped at research time. No repository edits, Cargo commands, native runs, or Git mutations.

## Recommendation

Close the Authored EQ **new-node metadata and node-vector publication** boundary next. Preserve Authored's current owner-input membership lookup and final context choice; reuse the shared node-publication accounting pattern, not the shared node-description selection algorithm.

This bounded increment comprises:
1. An exact admitted counterpart to Plan's direct owner-input resolution, preserving its existing membership test and error order.
2. An Authored-only guarded description of its actual context plus treatment boundary.
3. Admitted Authored Node vector capacity and a preflighted metadata/native/capacity handoff into Graph.resident.

Leave Authored's temporary tile boundary copy, tile-map/storage bookkeeping, other shared Graph maps, and shared mix route-clock copies as named later closures. This is not a claim to close every Graph allocation.

## Current Authored path and allocation lifetimes

crates/deadpan-audio/src/authored_eq.rs:

- Context (29) is Root, Domain(Arc<AudioDomain>), or Retained(SharedAudioOwnerRetainedInput). Context::owner_context (283) calls the **legacy** RenderPlan::audio_owner_input or AudioDomain::owner_input for Root/Domain, bills the returned input.work once, then finish_paid_owner_input. Retained returns the same shared retained handle immediately; this branch deliberately performs no fresh membership query.
- finish_paid_owner_input_with (333) already shares one numerical decision between LegacyOriginalSharing and AdmittedOriginalSharing: actual retained probe; if Some, actual retained one-sample owners query and matches_treatment_owner check; accepted probe becomes Retained; rejected Some and positive-work None drop the probe before copying the fallback Domain. Context::finish_paid_owner_input_admitted already exists at 312. Do not recreate it.
- LegacyOriginalSharing::domain (114) deep-clones the Domain then allocates an Arc. Its retained branch (105) shares the actual unguarded probe graph. Both become persistent Node.context storage today.
- Node (372) stores parent, Context, an ordinary AudioTreatmentBoundary, native filter, and BTreeMap<i64, Arc<WideBlock>>. Graph (380) owns Vec<Node>, resident, and a borrowed skip slice.
- eq_node (684) first searches the current cache using parent + before_stage + matches_clock_at, then checks the EQ owner count. On miss it resolves context, checks recipe, clones the treatment boundary, computes native bound, pays FINITE_FILTER_TAPS, admits native bytes, constructs the filter, checks control, and pushes a node. Its graph.resident currently covers the native bound only, not context/boundary/vector storage. Retaining the existing cache fast path before metadata work is part of the contract.
- read_authored_equalizers (412) drops the entire Graph before subtracting graph.resident and the output reservation (477-479). The new persistent charges should use the same physical-destruction-before-accounting-release boundary.
- eq_tile (742) clones Node.context and Node.boundary at 772-773, before taking the filter. Context clone is a shared handle clone, not a new deep Domain/retained graph. The ordinary boundary clone deep-copies the owner payload and is a **separate unadmitted temporary allocation**. It lasts through recursive read_eq_program calls and filter processing, ending at tile return. The existing filter restoration tail must continue to cover every failure after take.
- eq_tile inserts into Node.tiles at 849; the existing tile PCM charge does not itself establish admission of BTreeMap node overhead, Arc shell, suppression/dependency containers, or arbitrary bookkeeping capacity. Those are separate from the proposed node metadata/vector increment.

The wide query in read_eq_program (523-532) is already admitted and retained in the local owners carrier through span traversal/recursive uses. It does not pay for owner_context's later independent membership query or persistent Node metadata. Do not remove that later query merely because the wide query already observed the selected owner.

## Actual admitted Plan APIs and missing seam

crates/deadpan-plan/src/audio_owner_input.rs:
- RenderPlan::audio_owner_input (360), AudioDomain::owner_input (380) are public direct-owner APIs, currently legacy only.
- resolve_input (398) chooses the first owner in the first actual one-sample span satisfying candidate.same_at(owner, at), otherwise "audio input owner is not current at sample". It then captures against the same root or Domain seed, with remaining budget = supplied maximum minus actual query work.
- AudioOwnerClock::same_at is pub(super), in audio_owners.rs:147. It compares same plan, definition, instance, kind, gap_after, **play**, origin, sampling rate, and local sample at the observation. Public getters do not expose play. matches_treatment_owner omits play and affine sampling; AudioTreatmentBoundary::matches_clock_at omits play. Neither is an exact replacement for direct owner-input membership.

Public admitted building blocks already available in audio_owner_input/candidates.rs:
- RenderPlan::audio_owner_input_candidates_at_admitted (351)
- AudioDomain::owner_input_candidates_at_admitted (379)
- AdmittedAudioOwnerInputCandidates::capture(member, limits, admission) (252)
- without_selection, query, work, canonical_units, additional_units, was_forwarded
- AdmittedAudioOwnerInputCapture::input, query/capture work and canonical/additional receipts, was_forwarded (174 onward).
The candidate owns the actual query and borrows the precise parent; capture consumes an index from its actual first span and keeps query storage charged through capture. The resulting source Input remains independently guarded while borrowed for final probe/sharing. These are sufficient internal mechanics; they do not supply the direct API's private same_at selection to Audio.

Prefer narrow admitted direct-owner methods inside Plan, reusing candidate query/capture kernels while retaining the existing private same_at test. A sealed candidate capture-for-observed-owner method is an alternative, but callers must still preserve direct API prechecks: limits validation, foreign-owner rejection before query, checked end overflow, same actual query, exact first-span same_at selection and missing-owner error, same seed, same remaining total Q+C bound. Do not export or reconstruct equality ad hoc in Audio.

Canonical work must remain old Q+C, followed by old probe/retained-membership/final-copy behavior. Metered additional inspections/copies may increase total work; each receipt must retain canonical/additional provenance and forwarded work must not be billed again. New resource refusal/cancellation necessarily can expose an earlier admitted prefix; successful ample-budget numerical behavior and non-resource errors must remain old behavior.

## Reuse, and the important non-reuse

Reuse:
- Context::finish_paid_owner_input_admitted and its existing shared legacy/admitted selection function.
- Plan AdmittedOriginalContext, AdmittedAudioTreatmentBoundary, and AudioOwnerClock::treatment_boundary_admitted (audio_treatment_boundary_admission.rs:72). Boundary construction validates legacy stage first, then limits, and records zero canonical work plus actual additional copy work.
- sound_context_admission::Admission/Lease/issuer and preflight_transfer/JointTransfer. Reservations enter request sound_context_frames and make_room sees them alongside active_frames.
- preflight_context_transfer / ContextChargeTransfer (audio_context_sharing.rs:420-479), including all three Original Plan/Core/buffer lanes. The old two-lane transfer helper explicitly rejects guarded retained Core contexts. Graph publication must use the newer value-tied preflight token.
- shared_eq/node_capacity.rs's generic PendingNodeCapacity<T>: reserve replacement while old buffer remains live; defer allocation until after native construction; validate actual allocator capacity; prepay actual moves; validate current vector; publish without fallible work; physically free old buffer before retiring old charge. It is generic in T but private to shared_eq and currently hard-codes "temporal owner count" / "zero-sized shared EQ node" wording. Reuse by a minimal visibility/module extraction with caller-specific old error semantics, rather than silently changing Authored's "EQ owner count".
- shared_eq_node (shared_eq.rs:794-1000) shows summing original/sound/key/boundary metadata, issuer checks, capacity reservation before native admission, checked future active/resident totals, full preflight, one no-fail publication tail, and disarming each lease exactly once.

Do not use shared_eq/node_description::describe_admitted as Authored's description:
- It creates an AdmittedStop/OwnerKey before context lookup.
- Root/Domain Original selection uses the first OwnerKey match from a candidate membership query (instance/gap/after only).
- It validates query layers at this phase.
- It can choose current-sound processing-domain fallback or return "missing shared EQ Original context".
- Its tests deliberately assert removal of one legacy membership query (node_description_tests.rs:275).
Authored has neither current-sound fallback nor this looser first-key selection; its direct membership Q must remain. Authored also does not need an extra persistent shared-mix Stop key. The existing treatment boundary is its stop and cache identity.

Guard/lifetime shape: an Authored description should hold owning Context clones before the original carrier, so errors drop actual shared handles before their guards. Keep the actual captured source Input alive through finish_paid_owner_input_admitted. On successful publication sum original three-lane + boundary + vector capacity + native bound, preflight issuers and arithmetic, publish the actual node, then transfer/disarm all relevant leases in one infallible tail. Retained incoming Context may share a parent-owned allocation already charged to this same Graph; an Arc clone is not a second deep metadata allocation. Any reasoning here must prove the parent/Graph lifetime rather than mint a synthetic independent charge.

## Explicit later scopes

- Authored eq_tile's boundary.clone: a temporary independent owner copy, not persistent Node storage. It requires its own admitted exact copy/guard through recursion; the persistent boundary carrier is intentionally non-Clone. Could use its owner + before_stage to construct another admitted boundary while preserving actual values. Do not equate this to shared_eq_tile, which already uses AdmittedStop::from_boundary (shared_eq.rs:1055) and copies a smaller shared-mix key, not a full treatment boundary.
- Shared Graph (shared_eq.rs:94) maps/sets: event_tiles, event_nodes, event_filters, voices; permission_families nested maps, canonical_families registry, skip.to_vec at 237, and Node.tiles entries. Node vector capacity is already closed, but it proves nothing about these other containers. original_inputs cache has its own reservation/lifecycle and should not be reclassified from the struct listing alone.
- Shared mix Route/Run clocks (shared_mix.rs): route at 227 clones owner into component_layers (268), Layer (286), and prefix Layer (316); creates OwnerKey and by_owner/Buses storage; register at 336 clones full layers for each uncovered Run via layers.to_vec (409). Those copies persist for mix route/run scope after the source query carrier can leave, and need their own caller-copy admission. Distinct from Authored Node context and boundary.

## Old-oracle and verification requirements for implementation

Before replacing direct resolution, preserve an independently runnable old oracle for Authored owner_context/eq_node selection and receipts, not merely two wrappers calling the new same helper. Existing frozen Plan owner-query-baseline-v1 and owner-capture-baseline-v1 fixtures and owner_capture_admission_tests already pin complete actual captured/discarded span, exact provenance, hidden Domain support, canonical Q/C, retained/core receipts. Extend/use those rather than regenerate goldens from the new implementation.

Cover:
- Root and actual Domain, including hidden support; retained incoming context skips fresh membership exactly as today.
- Repeat play, default gap, retained origin/definition, nontrivial affine grids, and same instance with unequal play/clock: direct same_at behavior versus weaker treatment/key matches.
- Exact accepted retained, rejected Some, positive-work None fallback and drop-before-fallback ordering; retained reference mapping and entire owner observation, not just final Domain range.
- Foreign owner, absent/current-at-sample, overflow, invalid stage, layer error order, cached node hit, owner limit, cancellation, tight canonical work thresholds and exact native boundary. New added-work receipts stay separate; no removed membership Q, duplicate forwarding, refund of accepted work, or synthetic zero spend on absence.
- Every actual metadata/capacity reservation refusal; old/new vector simultaneous peak, spare capacity, replacement growth, move work, issuer mismatch, late cancellation; no published node/filter/tile on failure, baseline active/request ledger restored, successful retry.
- Successful Graph handoff has zero outstanding request metadata charge, Graph.resident includes exact retained metadata/capacity/native units once, cache hit adds nothing, dropping Graph frees storage before releasing resident totals.
- Ample-budget old/new actual Authored renders compare f32 bits, suppressed/exhausted ranges, dependencies, relative depth and provider reads. Existing eq_admission/checks.rs is useful for native bound/filter restoration/retry but is not an independent selection/canonical receipt oracle. Authored wide_query_tests compares the wide query only; shared Description tests intentionally use different selection/work semantics and cannot stand in for this oracle.

No implementation or validation was run during this research.
