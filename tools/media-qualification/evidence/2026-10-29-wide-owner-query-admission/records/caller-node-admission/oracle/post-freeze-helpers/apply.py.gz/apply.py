from pathlib import Path
helper=r'''
/// Test-only parent reconstructed from the immutable wide-query oracle.
#[derive(Clone, Copy)]
pub(in crate::plan) enum Parent<'context, 'plan> {
    Root(&'plan RenderPlan),
    Domain(&'context AudioDomain<'plan>),
}

impl<'plan> Parent<'_, 'plan> {
    pub(in crate::plan) fn plan(self) -> &'plan RenderPlan {
        match self {
            Self::Root(plan) => plan,
            Self::Domain(domain) => domain.plan,
        }
    }
}

/// Keep the original full logical serializer unchanged and narrowly accessible.
pub(in crate::plan) fn query_snapshot(
    value: &AudioOwnerQuery<'_>,
    plan: &RenderPlan,
) -> Value {
    super::query(value, plan, |sample| sample.0)
}

/// Rebuild each actual checked parent from the immutable document and setup
/// identity. The visitor borrows the physical Domain only during its call.
pub(in crate::plan) fn visit_cases(
    snapshot: &Value,
    mut visit: impl FnMut(Parent<'_, '_>, &Value),
) {
    let mut visited = 0;
    for fixture in snapshot["documents"].as_array().expect("frozen documents") {
        let document = ProjectDocument::from_json(&fixture["document"].to_string()).unwrap();
        let plan = RenderPlan::compile(&document).unwrap();
        for case in snapshot["cases"].as_array().expect("frozen cases").iter()
            .filter(|case| case["fixture"] == fixture["fixture"])
        {
            match case["api"].as_str().expect("frozen public API") {
                "RenderPlan::audio_gain_owners" => visit(Parent::Root(&plan), case),
                "AudioDomain::gain_owners" => {
                    let seed = &case["seed_identity"];
                    let setup = &seed["setup_input"];
                    let owner = &setup["owner"];
                    let alias = owner["instance"]["node"].as_str().unwrap();
                    let kind = match owner["kind"].as_str().unwrap() {
                        "Node" => AudioOwnerKind::Node,
                        "DefaultGap" => AudioOwnerKind::DefaultGap,
                        other => panic!("unknown frozen owner kind: {other}"),
                    };
                    let at = AudioSample(setup["observed_at"].as_i64().unwrap());
                    let selected = setup_input(&plan, alias, kind, at);
                    assert_eq!(input(&selected), *setup, "actual setup identity: {}", case["name"]);
                    match seed["source"].as_str().expect("actual Domain source") {
                        "audio_owner_input.context" => {
                            let physical = selected.context();
                            assert_eq!(domain(physical), seed["measured_domain"]);
                            visit(Parent::Domain(physical), case);
                        }
                        "audio_owner_input.retained_at.domain.Root" => {
                            let retained = selected.retained_at(at, Default::default()).unwrap().unwrap();
                            let AudioBoundDomain::Root(physical) = retained.domain() else {
                                panic!("frozen actual retained RootRoundEven Domain")
                            };
                            assert_eq!(domain(physical), seed["measured_domain"]);
                            visit(Parent::Domain(physical), case);
                        }
                        other => panic!("unknown frozen physical Domain source: {other}"),
                    }
                }
                other => panic!("unknown frozen query API: {other}"),
            }
            visited += 1;
        }
    }
    assert_eq!(visited, snapshot["cases"].as_array().unwrap().len());
    assert_eq!(visited, 14);
}

#[test]
fn legacy_wide_gain_queries_match_immutable_full_matrix() {
    let mut frozen: Value = serde_json::from_str(include_str!(
        "../../../tests/fixtures/wide-gain-owner-baseline-v1/snapshot.json"
    )).unwrap();
    let metadata = frozen.as_object_mut().unwrap();
    metadata.remove("variant");
    metadata.remove("runtime_source_manifest_sha256");
    // The original producer matrix and every canonical receipt stay literal.
    assert_eq!(matrix(), frozen);
}

#[test]
fn wide_case_visitor_reconstructs_actual_parents_and_full_old_queries() {
    let frozen: Value = serde_json::from_str(include_str!(
        "../../../tests/fixtures/wide-gain-owner-baseline-v1/snapshot.json"
    )).unwrap();
    visit_cases(&frozen, |parent, case| {
        let request = &case["request"];
        let window = sample_window(
            request["window"]["start"].as_i64().unwrap(),
            request["window"]["end"].as_i64().unwrap(),
        );
        let limits = AudioQueryLimits {
            maximum_spans: usize::try_from(request["limits"]["maximum_spans"].as_u64().unwrap()).unwrap(),
            maximum_work: usize::try_from(request["limits"]["maximum_work"].as_u64().unwrap()).unwrap(),
        };
        let actual = match parent {
            Parent::Root(plan) => plan.audio_gain_owners(window, limits),
            Parent::Domain(domain) => domain.gain_owners(window, limits),
        }.unwrap();
        assert_eq!(query_snapshot(&actual, parent.plan()), case["query"], "{}", case["name"]);
    });
}
'''
for root in ['/Users/michael/Code/deadpan','/tmp/deadpan-query-groundwork-2026-10-26/scoped']:
 src=Path(root)/'crates/deadpan-plan/src/audio_owners'
 p=src/'legacy_snapshot_v1.rs';s=p.read_text();old='#[path = "legacy_snapshot_v1/wide_baseline.rs"]\nmod wide_baseline;'
 assert s.count(old)==1;p.write_text(s.replace(old,old.replace('mod wide_baseline;','pub(in crate::plan) mod wide_baseline;')))
 p=src/'legacy_snapshot_v1/wide_baseline.rs';s=p.read_text()
 assert 'pub(in crate::plan) enum Parent' not in s
 p.write_text(s+helper)
