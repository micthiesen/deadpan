from pathlib import Path
import json,hashlib,difflib
d=Path(__file__).resolve().parent
files=json.loads((d/'task-files.json').read_text())
pins={}
for label,root in [('main',Path('/Users/michael/Code/deadpan')),('scoped',Path('/tmp/deadpan-query-groundwork-2026-10-26/scoped'))]:
 patch=[]
 for f in files:
  b=(root/f).read_bytes();out=d/'candidate'/label/f;out.parent.mkdir(parents=True,exist_ok=True);out.write_bytes(b)
  pins[label+'/'+f]=hashlib.sha256(b).hexdigest()
  before=d/'before'/label/f
  patch.extend(difflib.unified_diff(before.read_text().splitlines(True) if before.exists() else [],b.decode().splitlines(True),fromfile='a/'+f,tofile='b/'+f))
 (d/(label+'.patch')).write_text(''.join(patch))
(d/'candidate-pins.json').write_text(json.dumps(pins,indent=2)+'\n')
manifest=hashlib.sha256((d/'candidate-pins.json').read_bytes()).hexdigest()
(d/'FREEZE.json').write_text(json.dumps({
 'status':'frozen-old-producer','candidate_pins_sha256':manifest,
 'task_files':files,'expected_fixture':'none; parent captures OLD output before any new expected fixture',
 'verification':'rustfmt parse/format only; parent solely owns Cargo/runtime',
 'capture_test':'plan::audio_owners::tests::legacy_snapshot_v1::wide_baseline::capture_old_wide_gain_query_snapshot_v1',
 'env':['DEADPAN_WIDE_OWNER_OUTPUT','DEADPAN_WIDE_OWNER_VARIANT','DEADPAN_WIDE_OWNER_SOURCE_SHA256']
},indent=2)+'\n')
print(manifest)
print(json.dumps(pins,indent=2))
