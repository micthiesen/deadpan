from pathlib import Path
import difflib
s=Path(__file__).resolve().parent
for variant,root in [('main',Path('/Users/michael/Code/deadpan')),('scoped',Path('/tmp/deadpan-query-groundwork-2026-10-26/scoped'))]:
 p=root/'crates/deadpan-audio/src/authored_eq.rs'
 t=p.read_text();old=t
 anchor="    pub(super) fn owners(\n"
 assert t.count(anchor)==1
 methods='''    /// Retain the actual guarded query through its renderer use scope.
    pub(super) fn owners_admitted<A: deadpan_plan::AudioSoundContextAdmission<Error = StageAudioError>>(
        &self,
        plan: &'plan RenderPlan,
        range: Range<AudioSample>,
        control: WorkControl<'_>,
        admission: &mut A,
    ) -> Result<deadpan_plan::AdmittedAudioOwnerQuery<'plan, A::Issuer, A::Lease>, StageAudioError> {
        let query = self.owner_query_admitted(plan, range, control, admission)?;
        Self::validate_owner_query_layers(query.query())?;
        Ok(query)
    }

    /// Pay the exact query once. Most callers then validate every layer via
    /// owners_admitted. Root mix routing instead selects its checked root
    /// first and validates only that route, preserving its established order.
    pub(super) fn owner_query_admitted<A: deadpan_plan::AudioSoundContextAdmission<Error = StageAudioError>>(
        &self,
        plan: &'plan RenderPlan,
        range: Range<AudioSample>,
        control: WorkControl<'_>,
        admission: &mut A,
    ) -> Result<deadpan_plan::AdmittedAudioOwnerQuery<'plan, A::Issuer, A::Lease>, StageAudioError> {
        let limits = control.query_limits()?;
        let query = match self {
            Self::Root => plan.audio_gain_owners_admitted(range, limits, admission)?,
            Self::Domain(domain) => domain.gain_owners_admitted(range, limits, admission)?,
            Self::Retained(input) => input.owners_admitted(range, limits, admission)?,
        };
        if query.was_forwarded() != A::METERED {
            return Err(PlanError::InvalidPlan("wide owner query accounting mode differs").into());
        }
        if !query.was_forwarded() {
            control.spend_plan_work(query.work())?;
        }
        Ok(query)
    }

    #[cfg(test)]
'''
 t=t.replace(anchor,methods+anchor)
 a='            let owners = program.context.owners(graph.plan, range.clone(), control)?;'
 assert t.count(a)==1
 t=t.replace(a,'''            let owners = {
                let mut admission = sound_context_admission::Admission::new(self, control);
                program.context.owners_admitted(
                    graph.plan, range.clone(), control, &mut admission,
                )?
            };''')
 assert t.count('for span in owners.spans() {')==1
 t=t.replace('for span in owners.spans() {','for span in owners.query().spans() {')
 (s/(variant+'-authored-eq-before.rs')).write_text(old);p.write_text(t)
 (s/(variant+'-authored-wide.patch')).write_text(''.join(difflib.unified_diff(old.splitlines(True),t.splitlines(True),fromfile=str(p),tofile=str(p))))
 p=root/'crates/deadpan-audio/src/shared_eq.rs'
 t=p.read_text();old=t
 a='''            Some(
                program
                    .context
                    .original
                    .owners(plan, original_range.clone(), control)?,
            )'''
 assert t.count(a)==1
 t=t.replace(a,'''            Some({
                let mut admission = sound_context_admission::Admission::new(self, control);
                program.context.original.owners_admitted(
                    plan, original_range.clone(), control, &mut admission,
                )?
            })''')
 a='''                owners
                    .spans()'''
 assert t.count(a)==1
 t=t.replace(a,'''                owners
                    .query()
                    .spans()''')
 a='''            let root_owners =
                plan.audio_gain_owners(root_range.clone(), control.query_limits()?)?;
            control.spend_plan_work(root_owners.work())?;'''
 assert t.count(a)==1
 t=t.replace(a,'''            let root_owners = {
                let mut admission = sound_context_admission::Admission::new(self, control);
                Context::Root.owner_query_admitted(
                    plan, root_range.clone(), control, &mut admission,
                )?
            };''')
 a='''            let root = root_owners
                .spans()'''
 assert t.count(a)==1
 t=t.replace(a,'''            let root = root_owners
                .query()
                .spans()''')
 a='''                        queries: request.queries(),
                        owners,
                        routes: &original_routes,'''
 assert t.count(a)==1
 t=t.replace(a,'''                        queries: request.queries(),
                        owners: owners.query(),
                        routes: &original_routes,''')
 assert t.count('for (span, route) in owners.spans().iter().zip(original_routes) {')==1
 t=t.replace('for (span, route) in owners.spans().iter().zip(original_routes) {','for (span, route) in owners.query().spans().iter().zip(original_routes) {')
 (s/(variant+'-shared-eq-wide-before.rs')).write_text(old);p.write_text(t)
 (s/(variant+'-shared-wide.patch')).write_text(''.join(difflib.unified_diff(old.splitlines(True),t.splitlines(True),fromfile=str(p),tofile=str(p))))
