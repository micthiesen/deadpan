#!/usr/bin/env python3
"""Scoped worker bundle qualification. Build and verify are separately authorized runs.

This script does not run product commands without --execute. See --help and
package-plan.md. Each attempt/stage is single-use; failed attempts are retained.
Official bundle-verify is skipped because its AI checks are unconditional.
"""
import argparse
import datetime
import hashlib
import json
import os
from pathlib import Path
import plistlib
import re
import shutil
import sqlite3
import stat
import subprocess
import sys
import time

REPO = Path("/Users/michael/Code/deadpan")
BASE = Path("/tmp/deadpan-camera-regions-2026-10-25")
PREFIX = Path("/Users/michael/Library/Developer/Deadpan/ffmpeg-8.0.3-opus-1.6.1-dav1d-1.5.4-qualified-3/prefix")
TOOLS = ("deadpan-app", "deadpan-cli", "deadpan-media-worker", "deadpan-transcribe", "deadpan-track")
WORKERS = {"deadpan-media-worker", "deadpan-transcribe", "deadpan-track"}
LIBRARIES = {"avcodec", "avformat", "avutil", "swscale", "avfilter"}
FACE_ENGINE = "Apple Vision VNDetectFaceRectanglesRequest"
SALIENCY_ENGINE = "Apple Vision VNGenerateObjectnessBasedSaliencyImageRequest"
TIMINGS = {"elapsed_ms", "worker_elapsed_ms", "decode_elapsed_ms", "vision_elapsed_ms"}
SKIPPED_VERIFY = {
    "status": "skipped_incompatible",
    "command": ["cargo", "xtask", "bundle-verify", "APP", "--fixture", "CONFIGURED_FIXTURE", "--keep"],
    "reason": "Current bundle-verify::exercise calls unconditional ai_runtime_checks, incompatible with intentional --without-ai-runtime",
    "scope": "Scoped worker relocation only; no full packaging, release or AI runtime claim",
}
MACHO = {
    b"\xfe\xed\xfa\xce", b"\xce\xfa\xed\xfe", b"\xfe\xed\xfa\xcf",
    b"\xcf\xfa\xed\xfe", b"\xca\xfe\xba\xbe", b"\xbe\xba\xfe\xca",
    b"\xca\xfe\xba\xbf", b"\xbf\xba\xfe\xca",
}
TRANSIENT_PROJECT_FILES = {"project.sqlite-shm", ".writer.lock"}


def require(condition, message):
    if not condition:
        raise RuntimeError(message)


def utc():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def sha(path):
    digest = hashlib.sha256()
    with Path(path).open("rb") as source:
        for block in iter(lambda: source.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def json_write(path, value):
    # These are this invocation's own status records, never earlier attempts.
    temporary = path.with_name(path.name + ".writing")
    temporary.write_text(json.dumps(value, indent=2, sort_keys=True) + "\n")
    temporary.replace(path)


def json_parse(text):
    def object_from_pairs(pairs):
        result = {}
        for key, value in pairs:
            require(key not in result, f"duplicate JSON key: {key}")
            result[key] = value
        return result

    def invalid_constant(value):
        raise ValueError(f"nonfinite JSON constant: {value}")

    return json.loads(text, object_pairs_hook=object_from_pairs,
                      parse_constant=invalid_constant)


def json_read(path):
    return json_parse(Path(path).read_text())


def inside(path, root):
    try:
        Path(path).resolve().relative_to(Path(root).resolve())
        return True
    except (ValueError, TypeError):
        return False


def pin(path):
    path = Path(path)
    require(path.is_file() and not path.is_symlink(), f"expected regular non-symlink file: {path}")
    return {"path": str(path.resolve()), "bytes": path.stat().st_size, "sha256": sha(path)}


def pinned_input(record):
    require(isinstance(record, dict) and set(record) >= {"path", "sha256"}, "input needs path and sha256")
    path = Path(record["path"])
    require(path.is_absolute(), f"input must be absolute: {path}")
    observed = pin(path)
    require(observed["sha256"] == record["sha256"], f"input SHA256 differs: {path}")
    return path.resolve(), observed


def fixture_input(config):
    path, observed = pinned_input(config["fixture"])
    manifest_path, manifest_pin = pinned_input(config["fixture_manifest"])
    manifest = json_read(manifest_path)
    row = manifest["fixtures"][path.name]
    require(row["sha256"] == observed["sha256"] and row["bytes"] == observed["bytes"],
            "fixture differs from its measured manifest entry")
    numerator, denominator = row["video"]["time_base"].split("/")
    time_base = [int(numerator), int(denominator)]
    require(all(value > 0 for value in time_base), "invalid fixture time base")
    require(row["frames"] and all(frame["duration"] > 0 for frame in row["frames"]),
            "fixture lacks complete measured picture durations")
    starts = [section["start"] for section in manifest["sections"]]
    require(len(starts) == 3 and len(set(starts)) == 3, "expected3 measured fixture sections")
    require(all(isinstance(start, int) and 0 <= start < len(row["frames"]) for start in starts),
            "fixture section starts exceed its measured index")
    return {"input": observed, "manifest": manifest_pin, "row": row,
            "time_base": time_base, "section_starts": starts}


def native_project_binding(report, provided_project, fixture, identity):
    """Bind the real report's retained private Documents root and final Core doc.

    Native reports intentionally contain no leaf package-path pointer. Accept
    only the unique direct package in their retained Documents/Deadpan folder.
    """
    require(report["schema_version"] == 1 and report["failed"] is False,
            "native report is not a successful schema1 run")
    scenarios = [scenario for scenario in report["scenarios"] if scenario["name"] == "regions"]
    require(len(scenarios) == 1, "native report must contain exactly1 regions scenario")
    scenario = scenarios[0]
    require(scenario["failed"] is False and scenario["checks"]
            and all(check["passed"] is True for check in scenario["checks"]),
            "native regions scenario has not passed all recorded checks")
    retained = [check for check in scenario["checks"] if check["name"] ==
                "Private replay project root retained for native QA after worker shutdown"]
    require(len(retained) == 1 and retained[0]["passed"] is True,
            "missing successful private replay retention check")
    flags = {"scenario": "regions", "exclusive_creation": True, "cleanup_on_exit": False}
    require(retained[0]["expected"] == flags, "retention check expectations differ")
    actual = retained[0]["actual"]
    for key, value in flags.items():
        require(type(actual.get(key)) is type(value) and actual.get(key) == value,
                f"retention flag differs: {key}")
    raw_documents = Path(actual["documents_root"])
    require(raw_documents.is_absolute() and raw_documents.name == "Documents"
            and raw_documents.is_dir() and not raw_documents.is_symlink(),
            "retained Documents root is not an absolute real directory")
    documents = raw_documents.resolve(strict=True)
    require(inside(documents, BASE), "retained Documents root escapes task scratch")
    library = documents / "Deadpan"
    require(library.is_dir() and not library.is_symlink()
            and library.resolve(strict=True).parent == documents,
            "reported Documents/Deadpan is not a direct real directory")
    candidates = sorted(path for path in library.iterdir() if path.suffix == ".deadpan")
    require(len(candidates) == 1, "reported Documents/Deadpan must contain exactly1 direct .deadpan package")
    candidate = candidates[0]
    require(candidate.is_dir() and not candidate.is_symlink()
            and candidate.resolve(strict=True).parent == library,
            "retained package is not a direct real .deadpan directory")
    provided = Path(provided_project)
    require(provided.is_absolute() and provided.is_dir() and not provided.is_symlink()
            and provided.resolve(strict=True) == candidate.resolve(strict=True),
            "supplied project is not the report's unique direct retained package")
    durable_name = "The atomic region:N Redo and its history replay validate in SQLite"
    durable = [check for check in scenario["checks"] if check["name"] == durable_name]
    require(len(durable) == 1 and durable[0]["passed"] is True
            and durable[0]["expected"] == "SQLite head equals the complete displayed document",
            "native report lacks the final successful durable region document check")
    document = durable[0]["actual"]
    require(isinstance(document, dict)
            and set(document) >= {"schema_version", "project_id", "revision_id", "root", "nodes", "assets"}
            and isinstance(document["project_id"], str) and document["project_id"]
            and document["revision_id"] == identity["revision"],
            "final durable native Core document identity differs from baseline")
    require(report["metadata"]["fixture_sha256"] == fixture["input"]["sha256"]
            and Path(report["metadata"]["fixture_identity_file"]).resolve() == Path(fixture["input"]["path"]),
            "native report fixture identity differs from configured input")
    return {"project": str(candidate.resolve(strict=True)), "documents_root": str(documents),
            "library": str(library), "retention_check": retained[0]["name"],
            "durable_check": durable_name, "head_document": document}


def inventory(root, exclude=()):
    root = Path(root)
    files = {}
    excluded = {}
    for path in sorted(root.rglob("*")):
        relative = str(path.relative_to(root))
        mode = path.lstat().st_mode
        if stat.S_ISDIR(mode):
            continue
        if stat.S_ISLNK(mode):
            require(inside(path, root), f"symlink escapes inventory root: {path}")
            row = {"symlink": os.readlink(path), "mode": stat.S_IMODE(mode)}
        else:
            require(stat.S_ISREG(mode), f"nonregular file in inventory: {path}")
            row = {"bytes": path.stat().st_size, "sha256": sha(path), "mode": stat.S_IMODE(mode)}
        (excluded if relative in exclude else files)[relative] = row
    return {"files": files, "excluded_transient": excluded}


def source_snapshot(config, stage):
    """Manifest schema: {"files": {"relative/path": {"sha256": "..."} }}.

    source_manifest_key can select another top-level dictionary in a Root manifest.
    Every entry must carry an expected hash; no invented current-source manifest.
    """
    manifest_path, manifest_pin = pinned_input(config["source_manifest"])
    manifest = json_read(manifest_path)
    entries = manifest[config.get("source_manifest_key", "files")]
    require(isinstance(entries, dict) and entries, "source manifest entries must be a nonempty dictionary")
    result = {}
    for name, record in sorted(entries.items()):
        require(isinstance(name, str), "source path must be text")
        relative = Path(name)
        require(not relative.is_absolute() and ".." not in relative.parts, f"source path is not repository relative: {name}")
        path = REPO / relative
        require(inside(path, REPO), f"source path escapes repository: {name}")
        expected = record if isinstance(record, str) else record.get("sha256")
        require(isinstance(expected, str) and len(expected) == 64, f"source needs SHA256: {name}")
        observed = pin(path)
        require(observed["sha256"] == expected, f"source no longer matches final manifest: {name}")
        result[name] = observed
        destination = stage / "source" / (name + ".txt")
        destination.parent.mkdir(parents=True, exist_ok=True)
        data = path.read_bytes()
        require(hashlib.sha256(data).hexdigest() == observed["sha256"]
                and len(data) == observed["bytes"], f"source changed while copying: {name}")
        destination.write_bytes(data)
    require("Cargo.lock" in result, "source manifest must bind Cargo.lock")
    json_write(stage / "sources.json", {"manifest": manifest_pin, "files": result})
    return {"manifest": manifest_pin, "files": result}


def current_sources(initial):
    return {"manifest": pin(initial["manifest"]["path"]),
            "files": {name: pin(REPO / name) for name in initial["files"]}}


def semantic(report):
    require(isinstance(report, dict), "proposal report is not an object")
    return {key: value for key, value in report.items() if key not in TIMINGS}


def sqlite_snapshot(project, destination):
    """Read the live WAL-aware database in one read-only transaction."""
    database = project / "project.sqlite"
    require(database.is_file(), f"missing project database: {database}")
    uri = database.resolve().as_uri() + "?mode=ro"
    connection = sqlite3.connect(uri, uri=True)
    try:
        connection.execute("PRAGMA query_only=ON")
        connection.execute("BEGIN")
        integrity = [row[0] for row in connection.execute("PRAGMA quick_check")]
        require(integrity == ["ok"], f"SQLite quick_check failed: {integrity}")
        names = [row[0] for row in connection.execute(
            "SELECT name FROM sqlite_master WHERE type='table' ORDER BY name")]
        counts = {}
        for name in names:
            quoted = '"' + name.replace('"', '""') + '"'
            counts[name] = connection.execute(f"SELECT COUNT(*) FROM {quoted}").fetchone()[0]
        heads = connection.execute(
            "SELECT state.head_revision,state.cursor,revisions.document FROM state "
            "JOIN revisions ON revisions.id=state.head_revision WHERE state.singleton=1").fetchall()
        require(len(heads) == 1, "project does not have exactly1 authoritative SQLite head")
        head_revision, history_cursor, document_json = heads[0]
        require(isinstance(document_json, str), "SQLite stored document is not text")
        document = json_parse(document_json)
        # Store revisions are periodic keyframes plus patches. An ordinary
        # edit/Undo/Redo head normally stores the exact JSON literal null.
        # ProjectStore::snapshot (through the bundled CLI below) owns rebuilding
        # that head; this read-only SQL view preserves its raw representation.
        require(document_json == "null" or isinstance(document, dict),
                "SQLite stored document is neither the elision marker nor a keyframe")
        if document is not None:
            require(document["revision_id"] == head_revision, "SQLite keyframe/head revision differs")
        stored_bytes = document_json.encode("utf-8")
        storage = {"representation": "elided" if document is None else "keyframe",
                   "stored_json_sha256": hashlib.sha256(stored_bytes).hexdigest(),
                   "stored_json_bytes": len(stored_bytes), "stored_document": document}
        dump = "\n".join(connection.iterdump()) + "\n"
        destination.write_text(dump)
        return {"sql_dump_sha256": sha(destination), "tables": counts,
                "head_revision": head_revision, "history_cursor": history_cursor, "head_storage": storage,
                "quick_check": integrity, "inventory": inventory(project, TRANSIENT_PROJECT_FILES)}
    finally:
        connection.close()


class Run:
    def __init__(self, stage, build_env):
        self.stage = stage
        self.build_env = build_env
        self.counter = 0

    def command(self, label, argv, cwd, env):
        require(all(isinstance(arg, str) for arg in argv), "argv must contain strings")
        self.counter += 1
        stem = self.stage / f"{self.counter:03d}-{label}"
        receipt = {
            "label": label, "argv": argv, "cwd": str(cwd), "started_at": utc(),
            "state": "running",
            "environment": {key: env.get(key) for key in (
                "PATH", "HOME", "CARGO_TARGET_DIR", "DEADPAN_FFMPEG_PREFIX",
                "CARGO_ENCODED_RUSTFLAGS", "RUSTFLAGS", "CFLAGS", "CXXFLAGS",
                "DYLD_LIBRARY_PATH", "DEADPAN_TRACK_WORKER", "DEADPAN_DEVELOPER_BRIDGE")},
            "environment_kind": "scrubbed" if set(env) == {"HOME", "PATH"} else "build_host",
        }
        json_write(stem.with_suffix(".json"), receipt)
        started = time.monotonic()
        try:
            with stem.with_suffix(".stdout").open("xb") as out, stem.with_suffix(".stderr").open("xb") as err:
                # Bare tool names use PATH. Product binaries are absolute paths
                # inside the copied bundle. No shell/eval, hidden launch or polling.
                result = subprocess.run(argv, cwd=cwd, env=env, stdout=out, stderr=err, check=False)
            receipt.update(state="finished", exit_code=result.returncode,
                           seconds=time.monotonic() - started, finished_at=utc())
            json_write(stem.with_suffix(".json"), receipt)
        except BaseException as error:
            receipt.update(state="launch_or_wait_failed", error=repr(error),
                           seconds=time.monotonic() - started, finished_at=utc())
            json_write(stem.with_suffix(".json"), receipt)
            raise
        require(result.returncode == 0, f"{label} exited {result.returncode}; see {stem}")
        return stem.with_suffix(".stdout"), stem.with_suffix(".stderr")

    def json_command(self, label, argv, cwd, env):
        out, _ = self.command(label, argv, cwd, env)
        # Exact JSON only, never skip leading diagnostics to reinterpret failure.
        return json_read(out)


def build_environment(config):
    require(Path(config.get("ffmpeg_prefix", str(PREFIX))).resolve() == PREFIX.resolve(),
            "this check requires the selected qualified FFmpeg8 prefix")
    require(PREFIX.is_dir(), "qualified prefix missing")
    env = os.environ.copy()
    env["CARGO_TARGET_DIR"] = str(Path(config.get("target_directory", str(REPO / "target"))).resolve())
    env["DEADPAN_FFMPEG_PREFIX"] = str(PREFIX)
    return env


def build(config, attempt):
    stage = attempt / "build-check"
    stage.mkdir()
    status = {"state": "running", "started_at": utc(), "scope": SKIPPED_VERIFY["scope"]}
    json_write(stage / "status.json", status)
    initial = None
    try:
        initial = source_snapshot(config, stage)
        fixture = fixture_input(config)
        json_write(stage / "fixture.json", fixture)
        run = Run(stage, build_environment(config))
        for name, argv in (
            ("os", ["sw_vers"]), ("machine", ["uname", "-a"]),
            ("rustc", ["rustc", "-vV"]), ("xcode", ["xcodebuild", "-version"]),
            ("sdk", ["xcrun", "--show-sdk-version"])):
            run.command(name, argv, REPO, run.build_env)
        cache = Path(run.build_env["CARGO_TARGET_DIR"]) / "bundle/release"
        json_write(stage / "old-cache-binaries.json",
                   {name: pin(cache / name) for name in TOOLS if (cache / name).is_file()})
        run.command("official-bundle", ["cargo", "xtask", "bundle", "--output",
                    str(attempt / "build"), "--without-ai-runtime"], REPO, run.build_env)
        app = attempt / "build/Deadpan.app"
        require(app.is_dir(), "official build returned without an app")
        json_write(stage / "built-bundle.json", inventory(app))
        json_write(stage / "built-binaries.json", {name: pin(app / "Contents/MacOS" / name) for name in TOOLS})
        artifacts = {}
        for name in ("Deadpan.app.SHA256SUMS", "Deadpan.sbom.cdx.json", "Deadpan.release.json"):
            artifacts[name] = pin(attempt / "build" / name)
        for name in ("build-provenance.json", "Notices/sbom.cdx.json"):
            artifacts[name] = pin(app / "Contents/Resources" / name)
        json_write(stage / "artifacts.json", artifacts)
        evidence = stage / "production-artifacts"
        evidence.mkdir()
        for name, record in artifacts.items():
            destination = evidence / name
            destination.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(record["path"], destination)
        after = current_sources(initial)
        require(after == initial, "source or manifest changed during official build")
        require(fixture_input(config) == fixture, "fixture or measured manifest changed during official build")
        status.update(state="passed_scoped_build", finished_at=utc(), sources_unchanged=True)
    except BaseException as error:
        status.update(state="failed", finished_at=utc(), error=repr(error))
        raise
    finally:
        if initial:
            try:
                after = current_sources(initial)
                json_write(stage / "sources-after.json", after)
                status["sources_unchanged"] = after == initial
                if not status["sources_unchanged"]:
                    status["state"] = "failed"
            except BaseException as error:
                status["source_recheck_error"] = repr(error)
                status["state"] = "failed"
        json_write(stage / "status.json", status)


def assert_doctor(doctor, app):
    runtime = doctor["runtime"]
    require(runtime["packaged"] is True, "doctor did not recognize packaged app")
    require(inside(runtime["executable"], app / "Contents/MacOS"), "doctor executable outside copied bundle")
    require({worker["name"] for worker in runtime["workers"]} == WORKERS, "worker inventory differs")
    for worker in runtime["workers"]:
        require(worker["present"] is True and worker["inside_bundle"] is True
                and inside(worker["path"], app / "Contents/MacOS"),
                f"worker is not inside copied bundle: {worker}")
    require({library["library"] for library in runtime["ffmpeg"]} == LIBRARIES, "mapped FFmpeg inventory differs")
    for library in runtime["ffmpeg"]:
        require(library["loaded"] is True and library["inside_bundle"] is True
                and inside(library["path"], app / "Contents/Frameworks"),
                f"FFmpeg mapped outside copied bundle: {library}")
    downloader = doctor["downloader"]
    require(downloader["source"] == "bundled", "downloader selected external baseline")
    require(downloader["helpers"], "empty helper inventory")
    for helper in downloader["helpers"]:
        require(helper["present"] is True and inside(helper["path"], app / "Contents/Resources/helpers"),
                f"helper outside copied bundle: {helper}")


def assert_report(report, identity, fixture):
    require(report["protocol"] == 2, "proposal protocol differs")
    require(report["selection"] in ("both", "salient_regions"), "proposal selection differs")
    both = report["selection"] == "both"
    for name in ("content", "asset", "revision"):
        require(report[name] == identity[name], f"proposal {name} differs from retained project identity")
    ordinal = report["picture"]
    require(isinstance(ordinal, int) and ordinal in fixture["section_starts"],
            "proposal picture is not a measured fixture section start")
    require(report["pts"] == fixture["row"]["frames"][ordinal]["pts"],
            "exact picture PTS differs from fixture's measured index")
    require(report["stream"] == {"stream_index": identity["stream_index"],
                                "time_base": fixture["time_base"],
                                "rotation_quarter_turns": identity["rotation_quarter_turns"]},
            "Original stream identity differs")
    salient = report["salient_regions"]
    require(salient["runtime"] == {"detector": "salient_regions", "engine": SALIENCY_ENGINE,
                                  "request_revision": 2}, "saliency runtime differs")
    require(len(salient["regions"]) <= 64, "salient result count exceeds protocol bound")
    for index, found in enumerate(salient["regions"], 1):
        require(found["region_number"] == index, "salient numbering differs")
        region = found["region"]
        require(set(region) == {"x", "y", "width", "height"}, "unexpected region fields")
    if both:
        faces = report["faces"]
        require(faces["runtime"] == {"detector": "faces", "engine": FACE_ENGINE,
                                    "request_revision": identity["face_request_revision"]},
                "face runtime differs")
        require(faces["faces"] == [], "non-face fixture unexpectedly contains faces")
    else:
        require(report["faces"] is None, "Regions-only returned faces")


def verify(config, attempt):
    stage = attempt / "verify-check"
    stage.mkdir()
    status = {"state": "running", "started_at": utc(), "scope": SKIPPED_VERIFY["scope"]}
    json_write(stage / "status.json", status)
    json_write(stage / "official-bundle-verify-skipped.json", SKIPPED_VERIFY)
    initial = None
    before = None
    bundle_before = None
    immutable_runtime_inputs = None
    project = None
    app = None
    try:
        require(json_read(attempt / "build-check/status.json")["state"] == "passed_scoped_build",
                "same attempt has no successful official build")
        initial = source_snapshot(config, stage)
        built_sources = json_read(attempt / "build-check/sources.json")
        require(initial["files"] == built_sources["files"], "verification source differs from built source")
        fixture = fixture_input(config)
        require(fixture == json_read(attempt / "build-check/fixture.json"),
                "runtime fixture differs from build input")
        skipped = dict(SKIPPED_VERIFY)
        skipped["command"] = ["cargo", "xtask", "bundle-verify",
                              str(attempt / "relocated/Deadpan.app"), "--fixture",
                              fixture["input"]["path"], "--keep"]
        json_write(stage / "official-bundle-verify-skipped.json", skipped)
        native_path, native_pin = pinned_input(config["native_report"])
        native_report = json_read(native_path)
        identity = config["identities"]
        require(set(identity) >= {"content", "asset", "revision", "stream_index",
                                  "rotation_quarter_turns", "face_request_revision"},
                "incomplete retained project identities")
        require("native_project_pointer" not in config,
                "obsolete arbitrary native-project pointer is not part of the raw-report contract")
        native_binding = native_project_binding(native_report, config["project"], fixture, identity)
        project = Path(native_binding["project"])
        json_write(stage / "native-project-binding.json", native_binding)
        baselines = {}
        baseline_pins = {}
        require(len(config["baseline_reports"]) == 6, "exactly6 baseline reports required")
        seen_cases = set()
        for label, baseline_record in sorted(config["baseline_reports"].items()):
            require(re.fullmatch(r"[a-z0-9-]+", label), "unsafe baseline case label")
            path, observed = pinned_input(baseline_record)
            baselines[label] = json_read(path)
            baseline_pins[label] = observed
            assert_report(baselines[label], identity, fixture)
            key = (baselines[label]["picture"], baselines[label]["selection"])
            require(key not in seen_cases, "duplicate baseline section/selection")
            seen_cases.add(key)
        require(seen_cases == {(start, selection) for start in fixture["section_starts"]
                               for selection in ("salient_regions", "both")},
                "baseline cases do not cover both selections at all measured section starts")
        reference = config["baseline_provenance"]
        _, cli_pin = pinned_input(reference["cli"])
        _, worker_pin = pinned_input(reference["worker"])
        require(reference["source_manifest_sha256"] == initial["manifest"]["sha256"],
                "baseline report source manifest differs")
        json_write(stage / "runtime-inputs.json", {
            "native_report": native_pin, "project": str(project), "identities": identity,
            "native_binding": native_binding,
            "baseline_reports": baseline_pins, "baseline_cli": cli_pin, "baseline_worker": worker_pin,
            "fixture": fixture,
        })
        immutable_runtime_inputs = [native_pin, cli_pin, worker_pin, fixture["input"], fixture["manifest"],
                                    *baseline_pins.values()]
        run = Run(stage, build_environment(config))
        home = attempt / "home"
        work = attempt / "work"
        home.mkdir()
        work.mkdir()
        scrubbed = {"HOME": str(home), "PATH": "/usr/bin:/bin"}
        copied = attempt / "relocated"
        copied.mkdir()
        app = copied / "Deadpan.app"
        built = attempt / "build/Deadpan.app"
        require(inventory(built) == json_read(attempt / "build-check/built-bundle.json"),
                "built bundle changed since official build")
        run.command("copy-bundle", ["ditto", str(built), str(app)], work, scrubbed)
        bundle_before = inventory(app)
        require(bundle_before == inventory(built), "relocated bundle differs from built bytes/modes")
        json_write(stage / "relocated-bundle-before.json", bundle_before)
        json_write(stage / "relocated-binaries.json", {name: pin(app / "Contents/MacOS" / name) for name in TOOLS})
        info = plistlib.loads((app / "Contents/Info.plist").read_bytes())
        require(info["DeadpanPackaging"] == "xtask-bundle-1" and info["LSMinimumSystemVersion"] == "15.0",
                "unexpected bundle packaging marker/minimum")
        require(not (app / "Contents/Resources/ai-runtime").exists(), "unexpected AI runtime in narrow bundle")
        json_write(stage / "info-plist.json", info)
        run.command("signature-verify", ["codesign", "--verify", "--deep", "--strict", str(app)], work, scrubbed)
        out, err = run.command("signature-identity", ["codesign", "-d", "--verbose=4", str(app)], work, scrubbed)
        signature = out.read_text() + err.read_text()
        require("Signature=adhoc" in signature.splitlines()
                and re.search(r"flags=0x[0-9a-fA-F]+\([^)]*\bruntime\b", signature),
                "not ad-hoc hardened runtime signature")
        run.command("bundle-audit", ["cargo", "xtask", "bundle-audit", str(app)], REPO, run.build_env)
        macho_files = []
        for relative in bundle_before["files"]:
            path = app / relative
            if path.is_symlink():
                continue
            with path.open("rb") as stream:
                magic = stream.read(4)
            if magic in MACHO:
                macho_files.append(relative)
                label = "macho-" + str(len(macho_files))
                run.command(label + "-loads", ["otool", "-L", str(path)], work, scrubbed)
                run.command(label + "-commands", ["otool", "-l", str(path)], work, scrubbed)
        require(macho_files, "no Mach-O files audited")
        json_write(stage / "macho-inventory.json", macho_files)
        cli = app / "Contents/MacOS/deadpan-cli"
        gui = app / "Contents/MacOS/deadpan-app"
        doctor = run.json_command("cli-doctor", [str(cli), "doctor"], work, scrubbed)
        assert_doctor(doctor, app)
        doctor_gui = run.json_command("app-headless-doctor", [str(gui), "--headless", "doctor"], work, scrubbed)
        assert_doctor(doctor_gui, app)
        helpers = run.json_command("helper-probe", [str(cli), "downloader", "status", "--probe"], work, scrubbed)
        require(helpers["source"] == "bundled" and helpers["helpers"]
                and all(helper["verified"] is True and inside(helper["path"], app / "Contents/Resources/helpers")
                        for helper in helpers["helpers"])
                and helpers["probe"]["matches_pins"] is True, "bundled helper probe failed")
        before = sqlite_snapshot(project, stage / "project-before.sql")
        json_write(stage / "project-before.json", before)
        require(before["head_revision"] == identity["revision"],
                "retained SQLite head revision differs from final durable native regions document")
        project_dump = run.json_command("project-before", [str(cli), "project", "dump", str(project), "--json"],
                                        work, scrubbed)
        require(project_dump == native_binding["head_document"]
                and project_dump["revision_id"] == before["head_revision"],
                "bundled CLI project dump differs from final durable native regions document")
        reports = {}
        for label, baseline in sorted(baselines.items()):
            argv = [str(cli), "detect-regions", str(project), "--at", str(baseline["pts"])]
            if config.get("asset_argument"):
                argv += ["--asset", identity["asset"]]
            if baseline["selection"] == "both":
                argv.append("--include-faces")
            report = run.json_command(label, argv, work, scrubbed)
            assert_report(report, identity, fixture)
            require(semantic(report) == semantic(baselines[label]), f"{label} differs from unbundled final-source baseline")
            reports[label] = report
        for ordinal in fixture["section_starts"]:
            pair = {report["selection"]: report for report in reports.values() if report["picture"] == ordinal}
            require(pair["salient_regions"]["salient_regions"] == pair["both"]["salient_regions"],
                    f"picture{ordinal} Regions-only/Both salient collections differ")
        after_dump = run.json_command("project-after", [str(cli), "project", "dump", str(project), "--json"],
                                      work, scrubbed)
        require(after_dump == project_dump, "authored project dump changed")
        after = sqlite_snapshot(project, stage / "project-after.sql")
        json_write(stage / "project-after.json", after)
        require(after["sql_dump_sha256"] == before["sql_dump_sha256"] and after["tables"] == before["tables"],
                "SQLite authored/history/operational rows changed")
        require(after["inventory"]["files"] == before["inventory"]["files"], "persistent project bytes changed")
        require(inventory(app) == bundle_before, "copied bundle bytes changed during qualification")
        require(current_sources(initial) == initial, "source or manifest changed during runtime qualification")
        require(all(pin(record["path"]) == record for record in immutable_runtime_inputs),
                "runtime reference inputs changed during qualification")
        status.update(state="passed_scoped_worker_relocation", finished_at=utc(),
                      six_cases_passed=True, sqlite_and_project_unchanged=True,
                      bundle_unchanged=True, sources_unchanged=True)
    except BaseException as error:
        status.update(state="failed", finished_at=utc(), error=repr(error))
        raise
    finally:
        # Even a failed proposal case retains conservation evidence.
        if immutable_runtime_inputs:
            try:
                after_inputs = [pin(record["path"]) for record in immutable_runtime_inputs]
                json_write(stage / "runtime-inputs-after.json", after_inputs)
                status["reference_inputs_unchanged"] = after_inputs == immutable_runtime_inputs
                if not status["reference_inputs_unchanged"]:
                    status["state"] = "failed"
            except BaseException as error:
                status["reference_input_recheck_error"] = repr(error)
                status["state"] = "failed"
        if before and project:
            try:
                after = sqlite_snapshot(project, stage / "project-final.sql")
                json_write(stage / "project-final.json", after)
                status["sqlite_and_project_unchanged"] = (
                    after["sql_dump_sha256"] == before["sql_dump_sha256"] and
                    after["inventory"]["files"] == before["inventory"]["files"])
                if not status["sqlite_and_project_unchanged"]:
                    status["state"] = "failed"
            except BaseException as error:
                status["project_recheck_error"] = repr(error)
                status["state"] = "failed"
        if bundle_before and app:
            try:
                after_bundle = inventory(app)
                json_write(stage / "relocated-bundle-after.json", after_bundle)
                status["bundle_unchanged"] = after_bundle == bundle_before
                if not status["bundle_unchanged"]:
                    status["state"] = "failed"
            except BaseException as error:
                status["bundle_recheck_error"] = repr(error)
                status["state"] = "failed"
        if initial:
            try:
                after = current_sources(initial)
                json_write(stage / "sources-after.json", after)
                status["sources_unchanged"] = after == initial
                if not status["sources_unchanged"]:
                    status["state"] = "failed"
            except BaseException as error:
                status["source_recheck_error"] = repr(error)
                status["state"] = "failed"
        json_write(stage / "status.json", status)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("mode", choices=("build", "verify", "all"))
    parser.add_argument("--config", required=True, type=Path,
                        help="Root-supplied input JSON; see package-checks-config.example.json")
    parser.add_argument("--attempt", required=True, type=Path, help="new scratch attempt, or built attempt for verify")
    parser.add_argument("--execute", action="store_true", help="required after Root execution authorization")
    args = parser.parse_args()
    require(args.execute, "preparation only: no commands run without --execute after Root authorization")
    attempt = args.attempt.resolve()
    require(inside(attempt, BASE) and attempt != BASE.resolve(), "attempt must be a child of task scratch")
    config_path = args.config.resolve()
    config = json_read(config_path)
    if args.mode in ("build", "all"):
        attempt.mkdir(parents=True, exist_ok=False)
    else:
        require(attempt.is_dir(), "verify requires an existing built attempt")
    stage_name = "verify-check" if args.mode == "verify" else "build-check"
    require(not (attempt / stage_name).exists(), "stage already attempted; preserve it and choose a new attempt")
    prefix = "verify" if args.mode == "verify" else "build"
    shutil.copyfile(config_path, attempt / f"{prefix}-input-config.json")
    shutil.copyfile(Path(__file__), attempt / f"{prefix}-driver.py.txt")
    json_write(attempt / f"{prefix}-driver.json", {
        "driver": pin(Path(__file__)), "config": pin(config_path),
        "retained_driver": pin(attempt / f"{prefix}-driver.py.txt"),
        "retained_config": pin(attempt / f"{prefix}-input-config.json"),
    })
    if args.mode in ("build", "all"):
        build(config, attempt)
        require(json_read(attempt / "build-check/status.json")["state"] == "passed_scoped_build",
                "build final invariants failed")
    if args.mode in ("verify", "all"):
        verify(config, attempt)
        require(json_read(attempt / "verify-check/status.json")["state"] == "passed_scoped_worker_relocation",
                "runtime final invariants failed")
    print(json.dumps({"attempt": str(attempt), "mode": args.mode, "scope": SKIPPED_VERIFY["scope"]}))


if __name__ == "__main__":
    try:
        main()
    except Exception as error:
        print(f"package-checks: FAILED: {error}", file=sys.stderr)
        raise SystemExit(1)
