#!/usr/bin/env python3
"""Collect approved Camera salient-region evidence; never runs product commands.

Preparation only. A separate final plan, final identity manifest, and all
producer receipts must be frozen before invocation. Publication is one new
directory, exclusive and fail-closed.
"""
import argparse
import hashlib
import json
from pathlib import Path
import runpy
import shutil
import tempfile

SCRATCH = Path(__file__).resolve().parent
HELPERS = SCRATCH / "bundle-helpers.py"
HELPER_SHA256 = "2758fa2c837e63d41b33f38b34f728017feda8b0c05aa21499eeb40f4764df13"
helper_bytes = HELPERS.read_bytes()
assert hashlib.sha256(helper_bytes).hexdigest() == HELPER_SHA256
H = runpy.run_path(str(HELPERS))
read = H["read_regular"]
digest = H["digest"]
json_bytes = H["json_bytes"]
require = H["require"]
identity = H["hash_regular"]
safe_name = H["safe_name"]

def package_totals(raw_payload_bytes, inventory, inventory_bytes, encodings, metadata_blobs, limit):
    """Return exact package budgets, including the files.json file itself."""
    metadata_bytes = sum(len(data) for data in metadata_blobs) + len(inventory_bytes)
    stored_bytes = sum(row["bytes"] for row in inventory.values()) + len(inventory_bytes)
    decoded_bytes = sum(row["decoded_bytes"] for row in encodings) + metadata_bytes
    raw_and_metadata_bytes = raw_payload_bytes + metadata_bytes
    require(stored_bytes <= limit, "stored package including final inventory exceeds 256 MiB")
    require(decoded_bytes <= limit, "decoded package including identity metadata exceeds 256 MiB")
    require(raw_and_metadata_bytes <= limit, "raw payload and identity metadata exceed 256 MiB")
    return stored_bytes, decoded_bytes, metadata_bytes, raw_and_metadata_bytes

def verify_archive_witnesses(witnesses, limit):
    """Refuse publication if an archive tree changed after it was captured."""
    for root, expected in witnesses.items():
        found = {name: identity(path, limit) for name, path in H["safe_tree"](Path(root))}
        require(found == expected, f"archive changed during collection: {root}")

def expected_archive_map(expected_members):
    require(isinstance(expected_members, list), "archive lacks reviewed expected_members map")
    expected = {}
    for row in expected_members:
        require(isinstance(row, dict) and set(row) == {"path", "bytes", "sha256"},
                "malformed reviewed archive member")
        name = safe_name(row["path"])
        require(name not in expected, f"duplicate reviewed archive member: {name}")
        require(isinstance(row["bytes"], int) and row["bytes"] >= 0,
                f"invalid reviewed archive size: {name}")
        require(isinstance(row["sha256"], str) and len(row["sha256"]) == 64,
                f"invalid reviewed archive digest: {name}")
        expected[name] = {"bytes": row["bytes"], "sha256": row["sha256"]}
    return expected

def verify_archive_plan(root, expected_members, limit):
    """Bind current source-tree bytes to the plan before archive capture."""
    expected = expected_archive_map(expected_members)
    found = {name: identity(path, limit) for name, path in H["safe_tree"](Path(root))}
    require(found == expected, f"archive source differs from reviewed plan: {root}")
    return expected

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--plan", type=Path, required=True)
    parser.add_argument("--approved-script-sha256", required=True)
    parser.add_argument("--approved-plan-sha256", required=True)
    parser.add_argument("--approved-identities-sha256", required=True)
    args = parser.parse_args()
    limit = 256 * 1024 * 1024
    script = Path(__file__).resolve(strict=True)
    plan_path = args.plan.resolve(strict=True)
    script_bytes = read(script, limit)
    plan_bytes = read(plan_path, limit)
    require(digest(script_bytes) == args.approved_script_sha256, "collector differs from approved digest")
    require(digest(plan_bytes) == args.approved_plan_sha256, "plan differs from approved digest")
    require(HELPERS.read_bytes() == helper_bytes, "pinned helper changed")
    plan = json.loads(plan_bytes)
    require(plan.get("schema_version") == 1, "unsupported plan schema")
    require(plan.get("ready_for_collection") is True, "draft plan is not executable")
    require(plan.get("raw_byte_limit") == limit, "plan must use the exact 256 MiB bound")
    require(plan.get("collector_sha256") == digest(script_bytes),
            "plan does not pin this exact collector")

    repo = Path(plan["repository"]).resolve(strict=True)
    scratch = Path(plan["scratch"]).resolve(strict=True)
    require(scratch == SCRATCH.resolve(strict=True), "plan scratch root differs from collector directory")
    destination = repo / safe_name(plan["destination"])
    require(not destination.exists() and not destination.is_symlink(), "destination already exists")
    require(destination.parent.is_dir(), "destination parent is missing")
    require(scratch.stat().st_dev == destination.parent.stat().st_dev, "cross-device publication refused")

    identities_path = scratch / safe_name(plan["identities_manifest"])
    identities_bytes = read(identities_path, limit)
    require(digest(identities_bytes) == args.approved_identities_sha256,
            "final identities manifest differs from approved digest")
    identities = json.loads(identities_bytes)
    require(identities.get("profile") == plan.get("required_profile"),
            "identity manifest profile differs")
    require(len(identities.get("sources", {})) == plan.get("required_source_count"),
            "final Rust/source count differs from reviewed plan")
    require(len(identities.get("binaries", {})) == plan.get("required_binary_count"),
            "final executable count differs from reviewed plan")

    tracked = {
        str(script): identity(script, limit),
        str(plan_path): identity(plan_path, limit),
        str(HELPERS): identity(HELPERS, limit),
        str(identities_path): identity(identities_path, limit),
    }
    stage = Path(tempfile.mkdtemp(prefix=".regions-evidence-staging-", dir=scratch))
    published = False
    try:
        collector = H["Collector"]({"raw_byte_limit": limit, "gzip_threshold_bytes": 8192}, stage)
        collector.retain("packaging/collect-regions.py.txt", script_bytes, str(script))
        collector.retain("packaging/collect-plan.json", plan_bytes, str(plan_path))
        collector.retain("packaging/bundle-helpers.py.txt", helper_bytes, str(HELPERS))
        collector.retain("identities/final-identities.json", identities_bytes, str(identities_path))

        # Bind and retain every final-source byte named by the actual, approved
        # release identity manifest; never infer source membership from git.
        rust_snapshot = bytearray()
        for relative, expected in sorted(identities["sources"].items()):
            path = repo / safe_name(relative)
            require(identity(path, limit) == expected, f"final source identity differs: {relative}")
            data = read(path, limit)
            require({"bytes": len(data), "sha256": digest(data)} == expected,
                    f"final source changed between identity check and retained read: {relative}")
            tracked[str(path)] = expected
            collector.retain("source/" + safe_name(relative) + ".txt", data, str(path))
            if relative.endswith(".rs"):
                rust_snapshot.extend(b"\n// ===== " + relative.encode("utf-8") + b" =====\n")
                rust_snapshot.extend(data)
                if not data.endswith(b"\n"):
                    rust_snapshot.extend(b"\n")
        collector.retain("source/snapshots.rs.txt", bytes(rust_snapshot),
                         "concatenated exact Rust sources from the pinned release identity manifest")

        # Binary bytes are intentionally not copied by default. Still verify
        # every final executable at its recorded execution path and recheck it
        # before publication; the pinned identity manifest remains the durable
        # receipt of the exact five executable bytes.
        for name, row in sorted(identities["binaries"].items()):
            path = Path(row["executed"]).resolve(strict=True)
            expected = {"bytes": row["bytes"], "sha256": row["sha256"]}
            require(identity(path, limit) == expected, f"final binary identity differs: {name}")
            tracked[str(path)] = expected

        for item in plan["files"]:
            source = Path(item["source"])
            if item.get("root", "scratch") == "scratch":
                source = scratch / safe_name(str(source))
                require(source.resolve(strict=True).is_relative_to(scratch), "file input escaped scratch")
            elif item["root"] == "repository":
                source = repo / safe_name(str(source))
                require(source.resolve(strict=True).is_relative_to(repo), "file input escaped repository")
            else:
                raise RuntimeError("file root must be scratch or repository")
            data = read(source, limit)
            require("sha256" in item, f"file input lacks reviewed SHA-256 pin: {source}")
            require(digest(data) == item["sha256"], f"file pin mismatch: {source}")
            tracked[str(source)] = {"bytes": len(data), "sha256": digest(data)}
            if item.get("png"):
                require(data.startswith(b"\x89PNG\r\n\x1a\n"), f"invalid PNG input: {source}")
            collector.retain(safe_name(item["path"]), data, str(source), viewable_png=bool(item.get("png")))

        # Each archive root is a single immutable package. The helper rejects
        # symlinks and non-regular entries, records every member, and checks
        # each member again before publication.
        for item in plan["archives"]:
            root = scratch / safe_name(item["root"])
            require(root.resolve(strict=True).is_relative_to(scratch), "archive root escaped scratch")
            root = root.resolve(strict=True)
            expected = verify_archive_plan(root, item.get("expected_members"), limit)
            collector.archive(item["name"], root)
            require(collector.witnesses.get(str(root)) == expected,
                    f"captured archive differs from reviewed plan: {root}")

        collector.verify_encoded()
        encoding_ledger = json_bytes(collector.encodings)
        archive_ledger = json_bytes(collector.archives)
        collector.put("encoding-ledger.json", encoding_ledger)
        collector.put("archive-ledger.json", archive_ledger)
        collection = json_bytes({
            "schema_version": 1,
            "collector_sha256": digest(script_bytes),
            "plan_sha256": digest(plan_bytes),
            "identities_sha256": digest(identities_bytes),
            "source_count": len(identities["sources"]),
            "binary_identity_count": len(identities["binaries"]),
            "raw_payload_bytes": collector.raw_bytes,
            "payload_limit_bytes": limit,
            "claim": "Retained byte identities and execution receipts only; no automatic product qualification."
        })
        collector.put("collection.json", collection)
        inventory = {name: identity(path, limit) for name, path in H["safe_tree"](stage)}
        inventory_bytes = json_bytes(inventory)
        stored_bytes, decoded_bytes, metadata_bytes, raw_and_metadata_bytes = package_totals(
            collector.raw_bytes, inventory, inventory_bytes, collector.encodings,
            [encoding_ledger, archive_ledger, collection], limit
        )
        collector.put("files.json", inventory_bytes)
        require({name: identity(path, limit) for name, path in H["safe_tree"](stage)
                 if name != "files.json"} == inventory, "final inventory differs")
        for path, expected in tracked.items():
            require(identity(Path(path), limit) == expected, f"input changed during collection: {path}")
        # Archive inputs may change after the first snapshot. Re-enumerate and
        # re-hash every complete source tree at the publication boundary.
        verify_archive_witnesses(collector.witnesses, limit)
        H["exclusive_publish"](stage, destination)
        published = True
        print(json.dumps({
            "published": str(destination),
            "payload_count": len(inventory),
            "stored_bytes": stored_bytes,
            "raw_payload_bytes": collector.raw_bytes,
            "identity_metadata_bytes": metadata_bytes,
            "raw_and_metadata_bytes": raw_and_metadata_bytes,
            "inventory_sha256": digest(json_bytes(inventory)),
        }, sort_keys=True))
    finally:
        if not published:
            shutil.rmtree(stage)

if __name__ == "__main__":
    main()
