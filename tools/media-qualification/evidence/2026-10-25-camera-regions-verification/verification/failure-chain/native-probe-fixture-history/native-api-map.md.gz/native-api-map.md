# Native objectness region API and real fixture probe

Read-only planning complete. No repository write, Git, product Cargo, native product execution, browser interaction, external download, or owner application mutation was performed. The two bounded Swift prototypes create and inspect their own synthetic pixels under this scratch directory.

## Recommendation

Use a combined face-plus-objectness operation over one admitted exact picture and one owned BGRA pixel buffer, with one VNImageRequestHandler and one synchronous perform array. Pin only the new objectness request to revision 2. Keep the existing face request constructor, default/revision selection, options and confidence behavior unchanged; report its actual revision as today. Region scores remain absent in the model. The prototype's explicit face revision 3 is experimental configuration, not a proposed face policy change.

This recommendation fits the real deployment boundary: .cargo/config.toml:2 sets MACOSX_DEPLOYMENT_TARGET=15.0, crates/xtask/src/bundle.rs:457 writes LSMinimumSystemVersion=15.0, and docs/PACKAGING.md:81 agrees. The selected SDK declares objectness request/revision 1 from macOS 10.15 and revision 2 from macOS 14.0. No new minimum OS is needed. Both revisions produced real boxes on the retained synthetic inputs; this sample does not establish comparative accuracy, performance or memory.

## Pinned objc2-vision 0.3.2

- Add the single Cargo feature VNGenerateObjectnessBasedSaliencyImageRequest. Existing VNRequest, VNObservation, VNRequestHandler, VNTypes, objc2-core-foundation, objc2-core-video and Foundation NSArray/NSDictionary support already cover the needed types.
- The class is VNGenerateObjectnessBasedSaliencyImageRequest, a VNImageBasedRequest/VNRequest subclass. Its new/init constructor and results getter are unsafe Objective-C binding calls and belong inside the existing narrow vision.rs boundary.
- results is Option<Retained<NSArray<VNSaliencyImageObservation>>>. VNSaliencyImageObservation is already supplied by VNObservation. salientObjects is Option<Retained<NSArray<VNRectangleObservation>>>. VNRectangleObservation and its inherited boundingBox also come from VNObservation; no separate rectangle-request feature is needed.
- VNGenerateObjectnessBasedSaliencyImageRequestRevision1=1 and Revision2=2 are exported constants. Set revision before performing, read revision afterward, require the pin. Check supportedRevisions on the concrete saliency class, using the same concrete-class msg_send pattern already documented by Tracker::new_pinned. Calling the generated VNRequest associated capability query would query the superclass instead of the intended concrete class.
- No block2 completion-handler feature is needed for the current synchronous perform pattern. No heatmap access or custom connected-component extraction is needed: salientObjects supplies discrete rectangle observations directly. VNRequestRevisionProviding is only needed if production chooses to read observation.requestRevision; reading the actual request.revision suffices for the worker identity report.
- Native confidence is deliberately not used. VNObservation's binding documentation allows a constant 1.0 when confidence has no meaning. The Apple saliency article discusses scores, but the salientObjects property has unspecified order and the public observation contract does not give this app a calibrated probability or a stable saliency rank. Raw experimental confidence properties are retained in reports only.

## API and geometry authority

Apple's salientObjects documentation says the bounds are computed lazily and not ordered:
https://developer.apple.com/documentation/vision/vnsaliencyimageobservation/salientobjects

Apple's objectness overview describes foreground/object-based regions and discusses up to three bounding boxes:
https://developer.apple.com/documentation/vision/cropping-images-using-saliency

Apple's box contract uses normalized processed-image coordinates with a lower-left origin:
https://developer.apple.com/documentation/vision/vndetectedobjectobservation/boundingbox

Use the existing analysis picture contract rather than mixing canvas geometry into native detection. Current exact path is: open descriptor below input/, verify length/SHA-256, open interpreted SourceDecoder, check stream identity, seek captured PTS, advance metadata until the exact PTS or fail, copy_current_rgba once, then vision_picture once. vision_picture calls square_pixel_picture: it covers the clean aperture, corrects sample aspect to square pixels, preserves normalized coordinates over the full clean image, and leaves rotation to the caller. Convert/copy that one raster into one owned BGRA CVPixelBuffer once for both requests.

Native request orientation stays coded/up, matching the present face adapter. For a raw Vision box (x,y,w,h), convert to coded top-left (x,1-y-h,w,h), validate finite positive bounds, then use the existing NormalizedRect displayed_from_coded quarter-turn mapping. Retain the explicit coded-to-upright conversion for 90/180/270 degrees. Camera's later source-to-input mapping through retained framing is a separate host responsibility. Do not pre-rotate the buffer and then rotate boxes again.

Evaluate salientObjects and copy its bounded values inside the same autorelease pool while request, observation, handler and pixel buffer remain retained. Include lazy box extraction in vision timing and cancellation/deadline accounting; its work is not necessarily done when perform returns.

## Native count and failure bounds to carry into implementation

Treat at most one saliency image observation and at most three salient rectangles as explicit admission bounds. The current SDK results property is an array and supplies no stronger count type; zero/nil observations or zero/nil salientObjects remain an explicit empty proposal result, not a manufactured centered region. Reject a result above the cap rather than reading an unbounded array or silently truncating. Existing face bound remains 64, checked separately. A combined protocol could therefore cap accepted proposals at 67 before existing host saved-target limits; the shared protocol owner decides the final smaller policy.

The three-box bound is supported by Apple's article and these observations, not a claim that an arbitrary future request revision can never return more. Keep the bounds pinned to the admitted revision and fail truthfully on excess. Do not read the floating saliency pixel buffer merely to claim detection.

Validate every returned rectangle as finite, positive-area, within normalized processed-image bounds; then apply the agreed clipping/upright conversion policy explicitly. Sorting must be host-defined and deterministic, for example kind then x/y/width/height, followed by exact deduplication within the same detector kind. Do not sort by an absent score or infer native order as relevance.

Check cancellation before decode, after raster preparation, before/after the synchronous combined request, and around bounded extraction. Existing worker supervision owns the hard process deadline; Vision's synchronous API and cancellation are cooperative. Keep native unsupported revision/API failure distinct from empty success and do not silently fall back to another detector revision.

## Real prototype results

Runtime: macOS 26.5.2 (25F84), arm64 Mac17,7, Xcode 26.6 (17F113), SDK 26.5, Swift 6.3.3. Framework identity and complete hashes are retained in native-probe-receipt.json.

Both runs use one 640x360 opaque BGRA pixel buffer and one handler.perform([face,saliency]) per image. Face revision 3 was explicitly requested and reported; supported face revisions were 1,2,3. Objectness supported revisions were 1,2, and each run reported its requested revision. Raw input and PNG SHA-256 values are identical between revision 1 and revision 2 runs for all six synthetic controls.

| Programmatic input | Faces, both runs | Objectness boxes rev 1 | Objectness boxes rev 2 |
| --- | ---: | ---: | ---: |
| blank-control | 0 | 0 | 0 |
| red-square | 0 | 1 | 1 |
| shaded-orange | 0 | 1 | 1 |
| ceramic-mug | 0 | 1 | 1 |
| toy-house | 0 | 1 | 1 |
| two-objects | 0 | 2 | 2 |

These are actual salientObjects rectangles, not scripted observations or heatmap-only detections. All observed boxes passed finite positive normalized bounds and count caps. Both processes exited 0, both stderr files are empty. Box geometry differs between revisions, so pinning matters. The timings in each report include perform and lazy extraction; they are prototype elapsed measurements only and are not a comparative benchmark.

Preferred positive fixture: probe-v1/ceramic-mug.png. It is an original programmatic drawing of one blue mug on a pale background, not copied media and contains no human likeness. Local visual inspection confirms the generated content. The real face detector returned zero and revision 2 objectness returned one bounded region. Prefer this single region for acceptance and geometry tests; retain two-objects for ordering/count coverage and blank-control for honest empty success.

Mug PNG SHA-256: 5df85d511659a008b734a5e843cc5b13b9ea8e989c4b00423e036feb8667f1e8
Mug raw BGRA SHA-256: 3d25eeef97d37494ec42f8d4acf7393290c8aea12801eb9e78cd73e6aaf6bd27
Revision 2 upright top-left rectangle: {"height": 0.437744140625, "width": 0.2998046875, "x": 0.53955078125, "y": 0.328369140625}
Revision 1 upright top-left rectangle: {"height": 0.421875, "width": 0.2548828125, "x": 0.5439453125, "y": 0.33349609375}

## Exact retained experiment and limits

- saliency-probe.swift plus probe-v1/{report.json,*.png,*.bgra}; stdout/stderr at probe-v1.stdout and probe-v1.stderr. This is the explicit revision 2 run.
- saliency-probe-revision1.swift plus probe-revision1/{report.json,*.png,*.bgra}; stdout/stderr alongside the directory. Only the objectRevision constant differs from the first script.
- native-probe-receipt.json contains exact argv, source/runtime/input/output pins and the comparison. Each command used timeout 90 and a scratch Swift module cache. Total: twelve bounded image evaluations, six per revision.
- Saved Apple Markdown files and pinned local SDK/binding source hashes accompany this map. No observed system API failure was replaced with synthetic output.

Still-image probe success does not qualify the product's verified snapshot, descriptor decoder, exact PTS, clean aperture, SAR, rotation, subprocess cancellation, Camera stale-result admission, explicit save or export. The next production fixture should encode the retained generated image losslessly with explicit source interpretation using existing fixture tools, then actually run the combined worker on an indexed exact picture and verify its decoded bytes, zero faces, nonempty bounded saliency boxes and actual revision. Do not infer that video/container conversion retains the PNG results; run it. Separate rotated/aperture/anamorphic cases must check upright geometry through the existing native decode path. No unsupported semantic object label should be inferred from objectness; it proposes salient foreground regions and can include people in real media.
