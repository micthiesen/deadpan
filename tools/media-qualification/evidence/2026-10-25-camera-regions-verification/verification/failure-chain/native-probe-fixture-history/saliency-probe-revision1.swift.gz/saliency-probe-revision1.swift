import Foundation
import Vision
import CoreVideo
import CoreGraphics
import ImageIO
import UniformTypeIdentifiers
import CryptoKit

let output = URL(fileURLWithPath: CommandLine.arguments[1], isDirectory: true)
try FileManager.default.createDirectory(at: output, withIntermediateDirectories: true)
let width = 640, height = 360
let faceRevision = 3
let objectRevision = 1
let maximumObjects = 3
let maximumFaces = 64
let names = ["blank-control", "red-square", "shaded-orange", "ceramic-mug", "toy-house", "two-objects"]

func hash(_ data: Data) -> String { SHA256.hash(data: data).map { String(format: "%02x", $0) }.joined() }
func rect(_ r: CGRect) -> [String: Double] {
    ["x":r.origin.x, "y":r.origin.y, "width":r.width, "height":r.height]
}
func revisions(_ set: IndexSet) -> [Int] { Array(set) }
func fill(_ c: CGContext, _ color: CGColor, _ r: CGRect) { c.setFillColor(color); c.fill(r) }
func rgb(_ r: CGFloat, _ g: CGFloat, _ b: CGFloat) -> CGColor { CGColor(red:r,green:g,blue:b,alpha:1) }
func draw(_ c: CGContext, _ name: String) {
    fill(c, rgb(0.84,0.87,0.88), CGRect(x:0,y:0,width:width,height:height))
    if name == "blank-control" { return }
    if name == "red-square" {
        fill(c,rgb(0.82,0.05,0.02),CGRect(x:370,y:95,width:120,height:140))
        return
    }
    if name == "shaded-orange" || name == "two-objects" {
        c.saveGState()
        c.setShadow(offset:CGSize(width:8,height:-10),blur:12,color:rgb(0.35,0.37,0.38))
        c.setFillColor(rgb(0.95,0.37,0.03))
        c.fillEllipse(in:CGRect(x:340,y:90,width:155,height:155))
        c.restoreGState()
        c.saveGState()
        c.addEllipse(in:CGRect(x:340,y:90,width:155,height:155))
        c.clip()
        let colors=[rgb(1,0.83,0.27),rgb(1,0.46,0.04),rgb(0.57,0.16,0.01)] as CFArray
        let gradient=CGGradient(colorsSpace:CGColorSpaceCreateDeviceRGB(),colors:colors,locations:[0,0.55,1])!
        c.drawRadialGradient(gradient,startCenter:CGPoint(x:385,y:205),startRadius:0,
            endCenter:CGPoint(x:420,y:170),endRadius:115,options:.drawsAfterEndLocation)
        c.restoreGState()
        c.setFillColor(rgb(0.12,0.42,0.10))
        c.fillEllipse(in:CGRect(x:409,y:232,width:55,height:19))
    }
    if name == "ceramic-mug" || name == "two-objects" {
        let x:CGFloat = name == "two-objects" ? 110 : 360
        c.setStrokeColor(rgb(0.1,0.27,0.60)); c.setLineWidth(17)
        c.strokeEllipse(in:CGRect(x:x+100,y:135,width:63,height:70))
        c.setFillColor(rgb(0.12,0.40,0.82))
        c.addPath(CGPath(roundedRect:CGRect(x:x,y:95,width:120,height:140),cornerWidth:15,cornerHeight:15,transform:nil))
        c.fillPath()
        c.setFillColor(rgb(0.08,0.15,0.30)); c.fillEllipse(in:CGRect(x:x+4,y:218,width:112,height:21))
        c.setFillColor(rgb(0.43,0.67,0.96)); c.fill(CGRect(x:x+12,y:110,width:15,height:100))
    }
    if name == "toy-house" {
        fill(c,rgb(0.87,0.59,0.21),CGRect(x:345,y:80,width:170,height:140))
        c.setFillColor(rgb(0.66,0.12,0.09)); c.beginPath()
        c.move(to:CGPoint(x:325,y:215));c.addLine(to:CGPoint(x:430,y:290));c.addLine(to:CGPoint(x:535,y:215));c.closePath();c.fillPath()
        fill(c,rgb(0.14,0.25,0.34),CGRect(x:411,y:80,width:44,height:80))
        fill(c,rgb(0.50,0.75,0.92),CGRect(x:361,y:154,width:32,height:36))
        fill(c,rgb(0.50,0.75,0.92),CGRect(x:474,y:154,width:26,height:36))
    }
}

var report: [String:Any] = [
    "kind":"read-only prototype, not production qualification",
    "os":ProcessInfo.processInfo.operatingSystemVersionString,
    "face_request_revision_requested":faceRevision,
    "saliency_request_revision_requested":objectRevision,
    "face_supported_revisions":revisions(VNDetectFaceRectanglesRequest.supportedRevisions),
    "objectness_supported_revisions":revisions(VNGenerateObjectnessBasedSaliencyImageRequest.supportedRevisions),
    "width":width, "height":height, "orientation":"up/coded", "pixel_format":"32BGRA",
    "maximum_objects_accepted":maximumObjects, "maximum_faces_accepted":maximumFaces,
    "coordinates":"raw lower-left and converted upright top-left; no rotation",
    "confidence_policy":"native property recorded without interpreting it as rank or probability",
    "one_perform_call_per_input":true
]
var rows:[[String:Any]]=[]
for name in names {
    let started=ContinuousClock.now
    do {
        guard VNDetectFaceRectanglesRequest.supportedRevisions.contains(faceRevision),
            VNGenerateObjectnessBasedSaliencyImageRequest.supportedRevisions.contains(objectRevision) else {
            throw NSError(domain:"Probe",code:1,userInfo:[NSLocalizedDescriptionKey:"Requested revisions unsupported"])
        }
        var allocated:CVPixelBuffer?
        let status=CVPixelBufferCreate(kCFAllocatorDefault,width,height,kCVPixelFormatType_32BGRA,nil,&allocated)
        guard status==kCVReturnSuccess, let buffer=allocated else { throw NSError(domain:"Probe",code:Int(status)) }
        CVPixelBufferLockBaseAddress(buffer,[])
        guard let base=CVPixelBufferGetBaseAddress(buffer), let c=CGContext(data:base,width:width,height:height,
            bitsPerComponent:8,bytesPerRow:CVPixelBufferGetBytesPerRow(buffer),space:CGColorSpaceCreateDeviceRGB(),
            bitmapInfo:CGImageAlphaInfo.premultipliedFirst.rawValue | CGBitmapInfo.byteOrder32Little.rawValue) else {
            CVPixelBufferUnlockBaseAddress(buffer,[]); throw NSError(domain:"Probe",code:2)
        }
        draw(c,name)
        let bytes=Data(bytes:base,count:CVPixelBufferGetBytesPerRow(buffer)*height)
        let rawURL=output.appendingPathComponent(name+".bgra")
        try bytes.write(to:rawURL)
        let pngURL=output.appendingPathComponent(name+".png")
        guard let cg=c.makeImage(),let destination=CGImageDestinationCreateWithURL(pngURL as CFURL,UTType.png.identifier as CFString,1,nil) else {
            CVPixelBufferUnlockBaseAddress(buffer,[]); throw NSError(domain:"Probe",code:3)
        }
        CGImageDestinationAddImage(destination,cg,nil)
        guard CGImageDestinationFinalize(destination) else { CVPixelBufferUnlockBaseAddress(buffer,[]);throw NSError(domain:"Probe",code:4) }
        CVPixelBufferUnlockBaseAddress(buffer,[])
        let face=VNDetectFaceRectanglesRequest(); face.revision=faceRevision
        let saliency=VNGenerateObjectnessBasedSaliencyImageRequest(); saliency.revision=objectRevision
        face.regionOfInterest=CGRect(x:0,y:0,width:1,height:1)
        saliency.regionOfInterest=CGRect(x:0,y:0,width:1,height:1)
        let handler=VNImageRequestHandler(cvPixelBuffer:buffer,orientation:.up,options:[:])
        let visionStarted=ContinuousClock.now
        try handler.perform([face,saliency])
        let faces=face.results ?? []
        guard faces.count<=maximumFaces else {throw NSError(domain:"Probe",code:5,userInfo:[NSLocalizedDescriptionKey:"Face bound exceeded"])}
        let observations=saliency.results ?? []
        guard observations.count<=1 else {throw NSError(domain:"Probe",code:6,userInfo:[NSLocalizedDescriptionKey:"Saliency observation bound exceeded"])}
        var boxes:[[String:Any]]=[]
        var salientNil=true
        for observation in observations {
            if let objects=observation.salientObjects {
                salientNil=false
                guard objects.count<=maximumObjects else {throw NSError(domain:"Probe",code:7,userInfo:[NSLocalizedDescriptionKey:"Salient object bound exceeded"])}
                for object in objects {
                    let box=object.boundingBox
                    guard box.origin.x.isFinite,box.origin.y.isFinite,box.width.isFinite,box.height.isFinite,
                        box.width>0,box.height>0,box.minX>=0,box.minY>=0,box.maxX<=1,box.maxY<=1 else {
                        throw NSError(domain:"Probe",code:8,userInfo:[NSLocalizedDescriptionKey:"Invalid native object box"])
                    }
                    boxes.append(["raw_lower_left":rect(box),
                        "upright_top_left":rect(CGRect(x:box.minX,y:1-box.minY-box.height,width:box.width,height:box.height)),
                        "native_confidence_property":Double(object.confidence),
                        "observation_request_revision":object.requestRevision])
                }
            }
        }
        let visionElapsed=visionStarted.duration(to:.now)
        let png=try Data(contentsOf:pngURL)
        rows.append(["name":name,"face_count":faces.count,"face_boxes":faces.map{rect($0.boundingBox)},
            "saliency_observation_count":observations.count,"salient_objects_nil":salientNil,
            "salient_box_count":boxes.count,"salient_boxes":boxes,
            "positive_non_face_candidate":faces.isEmpty && !boxes.isEmpty,
            "face_revision_actual":face.revision,"saliency_revision_actual":saliency.revision,
            "raw_sha256":hash(bytes),"png_sha256":hash(png),"row_stride":CVPixelBufferGetBytesPerRow(buffer),
            "vision_seconds":Double(visionElapsed.components.seconds)+Double(visionElapsed.components.attoseconds)/1e18,
            "total_seconds":Double(started.duration(to:.now).components.seconds)+Double(started.duration(to:.now).components.attoseconds)/1e18])
    } catch {
        rows.append(["name":name,"error":String(describing:error)])
    }
}
report["inputs"]=rows
let data=try JSONSerialization.data(withJSONObject:report,options:[.prettyPrinted,.sortedKeys])
try data.write(to:output.appendingPathComponent("report.json"))
print(String(decoding:data,as:UTF8.self))
