#!/usr/bin/env python3
"""Verify the retained native regions replay project; never author a fixture."""
import argparse
import bisect
from fractions import Fraction
import hashlib
import json
import math
import os
from pathlib import Path
import sqlite3
import subprocess
import time
import traceback
import wave

BINARIES = ['deadpan-app', 'deadpan-cli', 'deadpan-media-worker',
            'deadpan-transcribe', 'deadpan-track']
FACE_ENGINE = 'Apple Vision VNDetectFaceRectanglesRequest'
SALIENCY_ENGINE = 'Apple Vision VNGenerateObjectnessBasedSaliencyImageRequest'
EXCLUSIONS = [
    'Blank and mug proposal checks use the actual installed Vision worker. The later explicitly scripted ordering, failure, mode, late-result, transient Presentation::render_failed injection and save-cancellation cases qualify guards only. The presentation fault is injected through the existing failure seam; real Camera field previews restore the captured pose/ticket before ordinary f retry. No physical display, detector recall or semantic object recognition is claimed.',
    'OS picker behavior: only its selected path is scripted',
    'Physical display presentation, VoiceOver, OS IME delivery and audio device output',
]
REQUIRED_CHECKS = [
    'Real Both analysis of the blank video picture returns two empty collections without saving',
    'The real mug worker finds no faces and proposes a usable non-face region without an edit',
    'A keyboard choice saves exactly one untracked region and preserves scope, cursors and draft scale',
    'Escape retains the accepted region and restores exact entry framing',
    'The accepted region and escaped framing are durable in SQLite',
    'One Undo removes the explicit region acceptance with no hidden framing edit',
    'Redo restores the exact saved region',
    'The real Both completion preserves the saved region identity and digit',
    'Enter changes only the Follow target and preserves the entire clock, scale, fallback and transition',
    'Selected detector failure', 'Reported mode mismatch',
    'A late scripted batch cannot reopen Camera or save a target',
    'Scripted Both batches retain saved/fixed digits and order faces before regions without cross-kind deduplication',
    'Tab and Shift Tab page heterogeneous proposals while preserving the animated draft',
    'Ordinary f after stale completion starts a fresh batch and admits only its explicitly scripted proposals',
    'A sampled region:N target refuses macro recording before detector work or authored edits',
    'Real region:N requests only saliency and atomically saves one region plus sampled framing',
    'One Undo removes both atomic region:N changes and restores the preceding animation',
    'One Redo durably restores the atomic region:N target and framing',
    'Save cancellation retains the committed region in SQLite',
    'The atomic region:N Redo and its history replay validate in SQLite',
    'All region acceptance, framing, cancellation and Undo/Redo preserve the complete placed sound and audio support',
]


def sha(path):
    digest = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            digest.update(block)
    return digest.hexdigest()


def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':'))


def ratio(value):
    return Fraction(int(value['numerator']), int(value['denominator']))


def authority(package):
    with sqlite3.connect((package / 'project.sqlite').as_uri() + '?mode=ro', uri=True) as db:
        tables = ['revisions', 'history', 'redo', 'state',
                  'register_state', 'register_contents', 'registers', 'transaction_steps']
        values = {}
        for table in tables:
            # All columns, including immutable revision documents and edit bytes.
            rows = db.execute(f'SELECT * FROM "{table}"').fetchall()
            values[table] = sorted(rows, key=repr)
        head, cursor, workflow = db.execute(
            'SELECT head_revision,cursor,workflow FROM state WHERE singleton=1').fetchone()
        # Ordinary edit/Undo/Redo checkpoints may be the literal JSON null.
        # Preserve those bytes above; normal CLI dump reconstructs the head.
        stored_checkpoint = json.loads(db.execute(
            'SELECT document FROM revisions WHERE id=?', (head,)).fetchone()[0])
        kind_counts = dict(db.execute('SELECT kind,count(*) FROM revisions GROUP BY kind'))
        history = [dict(zip(['id', 'parent', 'revision', 'request', 'edit'], row))
                   for row in db.execute(
                       'SELECT id,parent_id,revision_id,request,edit FROM history ORDER BY id')]
    # These tables use text/numeric columns, with no storage-path rewriting.
    return {'sha256': hashlib.sha256(canonical(values).encode()).hexdigest(),
            'counts': {key: len(rows) for key, rows in values.items()},
            'head': head, 'cursor': cursor, 'workflow': workflow,
            'kind_counts': kind_counts}, stored_checkpoint, history


def database_bytes(package):
    return {name: sha(package / name) for name in ['project.sqlite', 'project.sqlite-wal']
            if (package / name).exists()}


def validate_regions(found):
    regions = found['regions']
    assert len(regions) <= 64
    keys = []
    for number, entry in enumerate(regions, 1):
        assert entry['region_number'] == number and 'confidence' not in entry
        rect = entry['region']
        assert set(rect) == {'x', 'y', 'width', 'height'}
        x, y, w, h = [rect[key] for key in ('x', 'y', 'width', 'height')]
        assert all(math.isfinite(v) for v in (x, y, w, h))
        assert 0 <= x < 1 and 0 <= y < 1 and 0 < w <= 1 and 0 < h <= 1
        assert x + w <= 1 and y + h <= 1
        keys.append((x, y, w, h))
    assert all(a < b for a, b in zip(keys, keys[1:]))
    assert found['runtime'] == {
        'detector': 'salient_regions', 'engine': SALIENCY_ENGINE, 'request_revision': 2}
    return regions



def validate_audio_evidence(verification, samples):
    """Apply the verifier's unshifted block and observable-offset policy.

    Source: export_verification/audio_check.rs and metrics.rs. A periodic
    segment does not establish an offset. At least one unique zero witness
    remains mandatory; no offset or uncorrelated segment is accepted.
    """
    thresholds = verification['thresholds']
    expected = {'silence_dbfs': -70.0, 'silent_max_peak_dbfs': -50.0,
                'silent_block_max_dbfs': -60.0, 'block_floor_dbfs': -60.0,
                'min_block_snr_db': 1.5, 'max_block_level_db': 3.0,
                'min_alignment_correlation': 0.5}
    assert all(thresholds[key] == value for key, value in expected.items())
    audio, = verification['audio']
    assert audio['kind'] == 'signal' and not audio['flags'] and audio['passed']
    assert audio['window'] == audio['project_samples'] == [0, samples]
    assert audio['uncovered_samples'] == 0
    assert audio['offset_status'] == 'verified_zero' and audio['measured_offset_samples'] == 0
    blocks = audio['blocks']
    # The complete fixture has continuous signal; every 480-sample block,
    # including the short terminal block, must receive content or silence gates.
    assert blocks['compared'] > 0
    assert blocks['compared'] + blocks['silent'] == (samples + 479) // 480
    assert blocks['low_snr_blocks'] == blocks['level_blocks'] == blocks['sound_in_silence_blocks'] == 0
    assert math.isfinite(blocks['min_snr_db']) and blocks['min_snr_db'] >= thresholds['min_block_snr_db']
    assert math.isfinite(blocks['max_level_difference_db']) and blocks['max_level_difference_db'] <= thresholds['max_block_level_db']
    segments = audio['segments']
    assert 0 < len(segments) <= 8
    assert len({row['segment_start'] for row in segments}) == len(segments)
    identifiable = []
    periodic = []
    for row in segments:
        assert 0 <= row['segment_start'] < samples
        assert 0 < row['segment_samples'] <= 4096
        assert row['segment_start'] + row['segment_samples'] <= samples
        assert abs(row['peak_lag']) <= 2048
        peak, zero = row['peak_correlation'], row['zero_lag_correlation']
        assert math.isfinite(peak) and math.isfinite(zero)
        assert peak >= thresholds['min_alignment_correlation']
        if row['status'] == 'verified_zero':
            assert row['peak_lag'] == 0 and zero == peak
            secondary = row['secondary_correlation']
            assert secondary is None or secondary < peak - 1e-3
            identifiable.append(row['segment_start'])
        else:
            assert row['status'] == 'periodic'
            secondary = row['secondary_correlation']
            assert secondary is not None and math.isfinite(secondary)
            assert row['secondary_lag'] is not None and abs(row['secondary_lag']) <= 2048
            assert abs(row['secondary_lag'] - row['peak_lag']) >= 32
            # These are the existing correlation-periodicity tests, not a
            # time-offset tolerance. A nonzero periodic peak is not called zero.
            assert secondary >= peak - 1e-3 and zero >= peak - 1e-3
            periodic.append({'start': row['segment_start'], 'peak_lag': row['peak_lag']})
    assert identifiable, 'Purely periodic audio cannot establish zero offset'
    summary = verification['summary']
    assert summary['signal_windows'] == summary['offset_verified_windows'] == 1
    assert summary['offset_unobservable_windows'] == 0
    assert summary['nonzero_offsets'] == summary['audio_windows_failed'] == 0
    assert summary['blocks_compared'] == blocks['compared']
    return {'identifiable_zero_segment_starts': identifiable,
            'periodic_segments_unobservable_individually': periodic,
            'unshifted_blocks_compared': blocks['compared'],
            'unshifted_blocks_silent': blocks['silent']}


def main(args):
    project = args.project.resolve(strict=True)
    binaries = args.bin.resolve(strict=True)
    native_path = args.native_report.resolve(strict=True)
    identities_path = args.identities.resolve(strict=True)
    native_receipt_path = args.native_receipt.resolve(strict=True)
    fixture_manifest_path = args.fixture_manifest.resolve(strict=True)
    identities = json.loads(identities_path.read_text())
    binary_pins = {name: sha(binaries / name) for name in BINARIES}
    assert set(identities['binaries']) == set(BINARIES)
    for name in BINARIES:
        entry = identities['binaries'][name]
        assert entry['sha256'] == binary_pins[name]
        assert Path(entry['executed']).resolve() == binaries / name
        assert entry['bytes'] == (binaries / name).stat().st_size
    native_receipt = json.loads(native_receipt_path.read_text())
    assert native_receipt['exit_code'] == 0
    assert native_receipt['binary_before'] == native_receipt['binary_after']
    receipt_pins = native_receipt['binary_before']
    for name in BINARIES:
        matches = [pin for path, pin in receipt_pins.items()
                   if Path(path).resolve() == binaries / name]
        pin, = matches
        assert pin['sha256'] == binary_pins[name]
    native_command = native_receipt.get('command', native_receipt.get('argv'))
    assert native_command and Path(native_command[0]).resolve() == binaries / 'deadpan-app'
    assert '--scenario' in native_command and native_command[native_command.index('--scenario') + 1] == 'regions'
    assert '--retain-projects' in native_command
    assert Path(native_command[native_command.index('--output') + 1]).resolve() == native_path.parent
    native = json.loads(native_path.read_text())
    metadata = native['metadata']
    assert metadata['build_profile'] == 'release'
    assert metadata['binary_sha256'] == binary_pins['deadpan-app']
    scenario, = [row for row in native['scenarios'] if row['name'] == 'regions']
    assert scenario['checks'] and all(row['passed'] for row in scenario['checks'])
    assert not any(row['severity'] == 'failure' for row in scenario.get('findings', []))
    assert scenario['skipped'] == EXCLUSIONS
    checks = scenario['checks']

    def check(name):
        matches = [row for row in checks if row['name'] == name]
        assert matches, name
        return matches[-1]['actual']

    retained = check('Private replay project root retained for native QA after worker shutdown')
    assert retained['scenario'] == 'regions' and retained['exclusive_creation']
    assert retained['cleanup_on_exit'] is False
    assert project.is_relative_to(Path(retained['documents_root']).resolve(strict=True))
    for name in REQUIRED_CHECKS:
        check(name)
    fixture = Path(metadata['region_scenario_fixture']).resolve(strict=True)
    audio_fixture = Path(metadata['region_scenario_audio_fixture']).resolve(strict=True)
    assert sha(fixture) == metadata['region_scenario_fixture_sha256']
    assert sha(audio_fixture) == metadata['region_scenario_audio_fixture_sha256']
    manifest = json.loads(fixture_manifest_path.read_text())
    measured = manifest['fixtures'][fixture.name]
    assert measured['sha256'] == sha(fixture)
    audio_info = manifest['audio_fixture']
    assert audio_info['sha256'] == sha(audio_fixture)
    with wave.open(str(audio_fixture), 'rb') as wav:
        samples, channels, sample_rate = wav.getnframes(), wav.getnchannels(), wav.getframerate()
        assert wav.getsampwidth() == 2 and wav.getcomptype() == 'NONE'
        assert (samples, channels, sample_rate) == (
            audio_info['samples'], audio_info['channels'], audio_info['rate'])
        pcm = wav.readframes(samples)
        assert any(pcm), 'Separate WAV must contain nonzero signal, not silence-only verification'
    frames = len(measured['frames'])
    pts = [row['pts'] for row in measured['frames']]
    assert pts == sorted(set(pts))
    source_time_base = Fraction(measured['video']['time_base'])
    assert len(manifest['sections']) == 3
    rate = Fraction(measured['video']['avg_frame_rate'])
    assert samples == round(Fraction(frames * sample_rate, 1) / rate)
    pins = {'runner': sha(Path(__file__)), 'binaries': binary_pins,
            'native_report': sha(native_path), 'native_receipt': sha(native_receipt_path),
            'identities': sha(identities_path),
            'fixture_manifest': sha(fixture_manifest_path),
            'video_fixture': sha(fixture), 'audio_fixture': sha(audio_fixture)}
    for name, source in [('native-report.json', native_path),
                         ('native-identities.json', identities_path),
                         ('native-receipt.json', native_receipt_path),
                         ('fixture-manifest.json', fixture_manifest_path)]:
        (args.output / name).write_bytes(source.read_bytes())
    (args.output / 'pins.json').write_text(json.dumps(pins, indent=2) + '\n')
    commands = []

    def stable():
        assert {name: sha(binaries / name) for name in BINARIES} == binary_pins
        assert sha(native_path) == pins['native_report']
        assert sha(native_receipt_path) == pins['native_receipt']
        assert sha(identities_path) == pins['identities']
        assert sha(fixture_manifest_path) == pins['fixture_manifest']
        assert sha(fixture) == pins['video_fixture'] and sha(audio_fixture) == pins['audio_fixture']

    def run(name, *arguments):
        stable()
        command = [str(binaries / 'deadpan-cli'), *map(str, arguments)]
        row = {'name': name, 'argv': command, 'cwd': str(Path.cwd()),
               'started_unix': time.time(), 'environment': {key: os.environ.get(key) for key in (
                   'PATH', 'DEADPAN_FFMPEG_PREFIX', 'CARGO_TARGET_DIR',
                   'DYLD_LIBRARY_PATH', 'DYLD_FALLBACK_LIBRARY_PATH',
                   'DEADPAN_MEDIA_WORKER', 'DEADPAN_PAUSE_ROUTE_PROFILE')}}
        commands.append(row)
        (args.output / 'commands.json').write_text(json.dumps(commands, indent=2) + '\n')
        started = time.monotonic()
        with (args.output / f'{name}.stdout').open('xb') as out:
            with (args.output / f'{name}.stderr').open('xb') as err:
                result = subprocess.run(command, stdout=out, stderr=err)
        row.update(exit_code=result.returncode, seconds=time.monotonic() - started,
                   stdout_sha256=sha(args.output / f'{name}.stdout'),
                   stderr_sha256=sha(args.output / f'{name}.stderr'))
        (args.output / 'commands.json').write_text(json.dumps(commands, indent=2) + '\n')
        stable()
        result.check_returncode()
        return (args.output / f'{name}.stdout').read_text()

    before, stored_checkpoint, history = authority(project)
    document = json.loads(run('dump', 'project', 'dump', project, '--json'))
    if stored_checkpoint is not None:
        assert document == stored_checkpoint
    assert document == check('The atomic region:N Redo and its history replay validate in SQLite')
    revision = document['revision_id']
    assert revision == before['head']
    assert all(before['kind_counts'].get(kind, 0) > 0 for kind in ('edit', 'undo', 'redo'))
    actual_atomic = check('Real region:N requests only saliency and atomically saves one region plus sampled framing')
    (accepted_id, accepted_target), = actual_atomic['added']
    assert document['targets'][accepted_id] == accepted_target
    framing = actual_atomic['framing']
    assert framing['value']['type'] == 'follow' and framing['value']['target'] == accepted_id
    assert ratio(framing['value']['scale']) == Fraction(6, 5)
    assert framing['value'].get('scale_transition') is None
    assert not accepted_target.get('samples', []) and not accepted_target.get('corrections', [])
    assert accepted_target.get('provenance') is None
    assert 'size' in accepted_target['region']
    nodes = document['nodes']
    root = nodes[document['root']]['kind']
    assert root['type'] == 'sequence' and len(root['children']) == 1
    owner = root['children'][0]
    assert nodes[owner]['framing'] == framing
    assert nodes[owner]['kind']['type'] == 'source'
    source = nodes[owner]['kind']['source']
    assert source['duration'] == frames
    video = source['video']
    assert video['type'] == 'stream' and video['asset'] == accepted_target['asset']
    asset = video['asset']
    basis = document['presentation_basis']
    assert Fraction(basis['frame_rate']['numerator'], basis['frame_rate']['denominator']) == rate
    assert (basis['width'], basis['height']) == (measured['video']['width'], measured['video']['height'])
    # Prove final edit is the actual atomic SaveFramed revision restored by Redo.
    active, = [row for row in history if row['id'] == before['cursor']]
    edit = json.loads(active['edit'])
    patch = edit['forward']
    assert patch['targets'][accepted_id] == {'before': None, 'after': accepted_target}
    assert set(patch['targets']) == {accepted_id}
    changed_owner = patch['nodes'][owner]
    assert changed_owner['after'] == nodes[owner]
    assert changed_owner['before']['kind'] == nodes[owner]['kind']
    prior_owner = dict(changed_owner['before'])
    prior_owner['framing'] = framing
    assert prior_owner == nodes[owner] and set(patch['nodes']) == {owner}
    assert edit['duration_delta'] == 0
    # Full native durable snapshots bind both sides even when the corresponding
    # SQLite revision checkpoints are elided. The CLI above uses Store's normal
    # reconstruction; this driver does not implement another history replayer.
    prior = check('Save cancellation retains the committed region in SQLite')
    assert prior['revision_id'] == patch['from_revision']
    assert active['revision'] == patch['to_revision']
    assert accepted_id not in prior['targets']
    assert changed_owner['before'] == prior['nodes'][owner]
    assert document['targets'] == {**prior['targets'], accepted_id: accepted_target}
    assert document['nodes'] == {**prior['nodes'], owner: nodes[owner]}
    # Redo uses a fresh revision header; all authored content is exact.
    def content(value):
        return {key: item for key, item in value.items() if key != 'revision_id'}
    expected = dict(prior)
    expected['targets'] = document['targets']
    expected['nodes'] = document['nodes']
    assert content(expected) == content(document)
    # If Store retained either checkpoint, additionally bind it. Null is
    # legitimate and remains part of the exact eight-table conservation hash.
    with sqlite3.connect((project / 'project.sqlite').as_uri() + '?mode=ro', uri=True) as db:
        for header, observed in [(patch['from_revision'], prior),
                                 (patch['to_revision'], document)]:
            checkpoint = json.loads(db.execute(
                'SELECT document FROM revisions WHERE id=?', (header,)).fetchone()[0])
            if checkpoint is not None:
                assert checkpoint['revision_id'] == header
                assert content(checkpoint) == content(observed)
    (args.output / 'history-before.json').write_text(json.dumps(before, indent=2) + '\n')
    sound = check('All region acceptance, framing, cancellation and Undo/Redo preserve the complete placed sound and audio support')
    assert sound['picture_frames'] == frames and sound['audio_end'] == samples
    assert len(document['sounds']) == len(sound['sounds']) == 1
    sound_event = next(iter(document['sounds'].values()))
    assert sound_event == sound['sounds'][0]['event']
    assert sound_event['owner'] == document['root'] and sound_event['offset'] == 0
    assert sound_event['source']['span']['start']['ticks'] == 0
    assert sound_event['source']['span']['end']['ticks'] == samples
    assert sound_event['source']['asset'] != asset

    # Independent exact provider mapping from the authored Source and producer's
    # measured frame index; no CLI pose-introspection API is assumed.
    mapping = source['video_mapping']
    span = video['span']
    assert span['start']['time_base'] == span['end']['time_base']
    authored_base = Fraction(span['start']['time_base']['numerator'],
                             span['start']['time_base']['denominator'])
    start, end = span['start']['ticks'], span['end']['ticks']
    if mapping['type'] == 'fit_beat':
        offset, support = Fraction(0), Fraction(frames)
    else:
        assert mapping['type'] in ('duration', 'placement', 'selected_placement')
        offset = ratio(mapping['start']) if 'start' in mapping else Fraction(0)
        support = ratio(mapping['frames'])
    oracle = []
    for frame in range(frames):
        ticks = start + (Fraction(2 * frame + 1, 2) - offset) * (end - start) / support
        ticks = ticks * authored_base / source_time_base
        ordinal = bisect.bisect_right(pts, ticks) - 1
        assert 0 <= ordinal < frames
        oracle.append({'frame': frame, 'ticks': str(ticks), 'ordinal': ordinal, 'pts': pts[ordinal]})
    (args.output / 'provider-oracle.json').write_text(json.dumps(oracle, indent=2) + '\n')

    # Six independent real worker invocations, not native scripted observations.
    # Use measured section midpoints, never guessed rate-derived container PTS.
    expected_geometry = {}
    for section in manifest['sections']:
        ordinal = (section['start'] + section['end'] - 1) // 2
        at = pts[ordinal]
        for both in (False, True):
            label = f"detect-{section['image']}-{'both' if both else 'regions'}"
            db_before = database_bytes(project)
            args_cli = ['detect-regions', project, '--asset', asset, '--at', at]
            if both:
                args_cli.append('--include-faces')
            found = json.loads(run(label, *args_cli))
            assert authority(project)[0] == before and database_bytes(project) == db_before
            assert found['revision'] == revision and found['asset'] == asset
            assert found['pts'] == at and found['picture'] == ordinal
            assert found['stream']['time_base'] == [source_time_base.numerator, source_time_base.denominator]
            assert found['selection'] == ('both' if both else 'salient_regions')
            regions = validate_regions(found['salient_regions'])
            if section['image'] == 'blank':
                assert not regions
            elif section['image'] == 'mug':
                assert regions
                rect = regions[0]['region']
                # Independent millionth conversion: normalized positive values,
                # nearest with half ties away from zero, as the authored target
                # contract specifies. Same generated mug pixels in this section.
                units = lambda value, minimum: max(minimum, min(1000000, math.floor(value * 1000000 + 0.5)))
                region = {'center': [units(rect['x'] + rect['width'] / 2, 0),
                                     units(rect['y'] + rect['height'] / 2, 0)],
                          'size': [units(rect['width'], 1), units(rect['height'], 1)]}
                assert region == accepted_target['region']
            else:
                assert section['image'] == 'mug_and_orange' and len(regions) >= 2
            if both:
                assert found['faces']['faces'] == []
                runtime = found['faces']['runtime']
                assert runtime['detector'] == 'faces' and runtime['engine'] == FACE_ENGINE
                assert runtime['request_revision'] > 0
            else:
                assert found['faces'] is None
            expected_geometry[(section['image'], both)] = [entry['region'] for entry in regions]
        assert expected_geometry[(section['image'], False)] == expected_geometry[(section['image'], True)]

    run('validate', 'project', 'validate', project)
    movie = args.output / 'camera-regions.mp4'
    run('render', 'render', project, '--output', args.output, '--name', movie.name, '--expected', revision)
    run('verify', 'verify-export', project, '--movie', movie, '--revision', revision,
        '--every', 1, '--samples', f'0:{samples}', '--report', args.output / 'verification.json')
    verification = json.loads((args.output / 'verification.json').read_text())
    assert verification['passed'] and not verification['failures']
    assert verification['revision_id'] == revision and verification['range'] == [0, frames]
    assert verification['frame_rate'] == [rate.numerator, rate.denominator]
    assert verification['canvas'] == verification['raster'] == [basis['width'], basis['height']]
    assert verification['movie']['video_frames'] == verification['movie']['expected_video_frames'] == frames
    assert verification['movie']['expected_audio_samples'] == samples
    assert verification['movie']['audio']['presented_end'] == samples
    assert not verification['movie']['audio']['gaps']
    assert verification['summary']['pictures_checked'] == len(verification['pictures']) == frames
    assert verification['summary']['pictures_failed'] == 0
    for expected, picture in zip(oracle, verification['pictures']):
        assert picture['passed'] and picture['output_frame'] == picture['project_frame'] == expected['frame']
        assert picture['provenance'] == {'kind': 'original', 'asset': asset,
                                        'source_frame': expected['ordinal'], 'source_pts': expected['pts']}
    audio_evidence = validate_audio_evidence(verification, samples)
    portable = args.output / 'portable.deadpan'
    run('copy', 'project', 'copy-portable', project, portable)
    run('portable-validate', 'project', 'validate', portable)
    assert json.loads(run('portable-dump', 'project', 'dump', portable, '--json')) == document
    assert authority(portable)[0] == before
    run('checkpoint', 'project', 'checkpoint', project)
    run('portable-checkpoint', 'project', 'checkpoint', portable)
    assert authority(project)[0] == authority(portable)[0] == before
    assert len(commands) == 9 + 2 * len(manifest['sections'])
    stable()
    result = {'fixture_origin': 'actual retained native regions replay project; no driver-authored document',
              'derived_fixture': False, 'project': str(project), 'revision': revision,
              'pins': pins, 'native_checks_passed': len(checks), 'exclusions': EXCLUSIONS,
              'accepted_target': accepted_id, 'owner': owner, 'frames': frames,
              'audio_samples': samples, 'channels': channels, 'audio_alignment': audio_evidence, 'history': before,
              'commands': len(commands), 'movie_sha256': sha(movie),
              'verification_sha256': sha(args.output / 'verification.json'),
              'evidence_scope': {
                  'native': 'all regions checks passed; first blank/mug and final atomic region:N use real worker; scripted guard cases are not detector capability',
                  'independent': 'authored Source rational provider clocks and measured index; real CLI mode/runtime/geometry/count guards; native final document and accepted target/history binding; nonzero separate WAV support',
                  'export': 'shared-reference picture fidelity at every output frame; complete unshifted PCM/block gates and observable aggregate zero offset; periodic segments retained as individually unobservable',
                  'not_claimed': 'independent renderer/DSP, CLI pose introspection, detector recall or semantic recognition, listening, physical display/OS input, performance or voice quality'}}
    (args.output / 'result.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(result))


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--project', type=Path, required=True)
    parser.add_argument('--bin', type=Path, required=True)
    parser.add_argument('--native-report', type=Path, required=True)
    parser.add_argument('--identities', type=Path, required=True)
    parser.add_argument('--native-receipt', type=Path, required=True)
    parser.add_argument('--fixture-manifest', type=Path, default=Path('/Users/michael/Code/deadpan/native/deadpan-track/tests/fixtures/salient-regions-fixtures.json'))
    parser.add_argument('--output', type=Path, required=True)
    arguments = parser.parse_args()
    arguments.output = arguments.output.absolute()
    assert not arguments.output.exists(), 'Unique immutable output required'
    assert arguments.project.resolve() not in arguments.output.parents
    assert arguments.output not in arguments.project.resolve().parents
    arguments.output.mkdir()
    try:
        main(arguments)
    except BaseException as error:
        (arguments.output / 'failure.json').write_text(json.dumps({
            'type': type(error).__name__, 'error': str(error),
            'traceback': traceback.format_exc()}, indent=2) + '\n')
        raise
