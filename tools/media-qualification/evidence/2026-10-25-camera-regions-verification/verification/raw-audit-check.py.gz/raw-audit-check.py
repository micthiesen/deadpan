"""Read-only evidence audit. No subprocesses, Cargo, product invocation or source writes."""
import hashlib
import json
import math
from pathlib import Path
import sqlite3

BASE = Path("/tmp/deadpan-camera-regions-2026-10-25")
REPO = Path("/Users/michael/Code/deadpan")
findings = []
checks = []
pins = {}

def sha(path):
    path = Path(path)
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()

def read(name):
    path = Path(name)
    if not path.is_absolute():
        path = BASE / path
    pins[str(path)] = {"sha256": sha(path), "bytes": path.stat().st_size}
    return json.loads(path.read_text())

def require(value, message):
    if not value:
        raise AssertionError(message)

def audit(name, fn):
    try:
        detail = fn()
        checks.append({"name": name, "passed": True, "detail": detail})
    except Exception as error:
        findings.append({"name": name, "error": repr(error)})
        checks.append({"name": name, "passed": False, "error": repr(error)})

identities = read("verified-identities.json")
config = read("package-verified-config.json")
native = read(config["native_report"]["path"])
regions = next(s for s in native["scenarios"] if s["name"] == "regions")
durable = next(c["actual"] for c in regions["checks"] if c["name"] == "The atomic region:N Redo and its history replay validate in SQLite")
build = BASE / "package-verified/build-check"
verify = BASE / "package-verified/verify-check"
media = BASE / "media-verified"

def source_binary_chain():
    require(len(identities["sources"]) == 59 and len(identities["binaries"]) == 5, "identity inventory count")
    require(identities["profile"] == "release", "release identity")
    for name, row in identities["sources"].items():
        require(sha(REPO / name) == row["sha256"], "current source pin " + name)
    for name, row in identities["binaries"].items():
        require(sha(row["executed"]) == row["sha256"], "current binary pin " + name)
    names = ["native-regions-performance-verified", "native-regions-verified", "native-faces-verified",
             "package-verified-run", "package-baselines-verified-run", "media-verified-run"]
    result = {}
    for name in names:
        receipt = read(name + ".json")
        require(receipt["exit_code"] == 0 and receipt["sources_unchanged"] and receipt["binaries_unchanged"], name + " runner terminal state")
        require(receipt["source_before"] == receipt["source_after"], name + " source drift")
        require(receipt["binary_before"] == receipt["binary_after"], name + " binary drift")
        require({str(Path(p).relative_to(REPO)): row for p, row in receipt["source_before"].items()} == identities["sources"], name + " source basis")
        for path, row in receipt["binary_before"].items():
            require(row["sha256"] == identities["binaries"][Path(path).name]["sha256"], name + " binary basis")
        for path, row in receipt.get("streams", {}).items():
            require(sha(path) == row["sha256"], name + " stream hash")
        result[name] = {"exit_code": 0, "seconds": receipt["seconds"], "sources": len(receipt["source_before"])}
    require(sha(BASE / "package-checks.py") == "82ea0022ccee613672b911e6bafa402e274807946d9a0a1de485396e5eb225d7", "package driver identity")
    require(sha(BASE / "media.py") == "739c2522410f287623f4823e9e032df0f2d573fe0e0cbce1fccd3d0272b7f38e", "media driver identity")
    return result

def native_bindings():
    for report_name, scenario_name, count in [
        ("native-regions-performance-verified/report.json", "regions", 109),
        ("native-regions-verified/report.json", "regions", 110),
        ("native-faces-verified/report.json", "faces", 69)]:
        report = read(report_name)
        require(report["failed"] is False and report["metadata"]["build_profile"] == "release", "native run failure/profile")
        require(report["metadata"]["binary_sha256"] == identities["binaries"]["deadpan-app"]["sha256"], "native App identity")
        scenario = next(s for s in report["scenarios"] if s["name"] == scenario_name)
        require(not scenario["failed"] and len(scenario["checks"]) == count and all(c["passed"] for c in scenario["checks"]), report_name + " checks")
    require(sha(config["native_report"]["path"]) == config["native_report"]["sha256"], "raw report hash")
    require(native["metadata"]["fixture_sha256"] == config["fixture"]["sha256"] == sha(config["fixture"]["path"]), "fixture chain")
    require(Path(native["metadata"]["fixture_identity_file"]).resolve() == Path(config["fixture"]["path"]).resolve(), "native fixture path")
    require(sha(config["fixture_manifest"]["path"]) == config["fixture_manifest"]["sha256"], "fixture manifest hash")
    retain = next(c for c in regions["checks"] if c["name"] == "Private replay project root retained for native QA after worker shutdown")
    flags = {"scenario": "regions", "exclusive_creation": True, "cleanup_on_exit": False}
    require(retain["passed"] and retain["expected"] == flags and all(retain["actual"][k] == v for k,v in flags.items()), "retention flags")
    library = Path(retain["actual"]["documents_root"]) / "Deadpan"
    packages = list(library.glob("*.deadpan"))
    require(len(packages) == 1 and packages[0].resolve() == Path(config["project"]).resolve(), "retained package identity")
    require(durable["revision_id"] == config["identities"]["revision"], "native durable revision")
    for name in ["A sampled region:N target refuses macro recording before detector work or authored edits",
                 "Native record-cancel discards the empty refused macro without starting detection or changing the edit",
                 "Real region:N requests only saliency and atomically saves one region plus sampled framing"]:
        require(next(c for c in regions["checks"] if c["name"] == name)["passed"], name)
    return {"regions_visual_checks":110,"regions_performance_checks":109,"faces_checks":69,
            "revision":durable["revision_id"],"project_id":durable["project_id"],
            "guard_scope":"Sampled region:N refused while recording; saved-target naming is separate. Scripted later batches prove guards, not detector ability."}

def package_sources_build():
    manifest_path = config["source_manifest"]["path"]
    require(sha(manifest_path) == config["source_manifest"]["sha256"], "package manifest hash")
    manifest = read(manifest_path)
    require(len(manifest["files"]) == 62, "62 packaging inputs")
    require(set(manifest["files"]) - set(identities["sources"]) == {"Cargo.lock","Cargo.toml","rust-toolchain.toml"}, "extra packaging inputs")
    for name, row in manifest["files"].items():
        expected = row if isinstance(row,str) else row["sha256"]
        require(sha(REPO / name) == expected, "packaging source pin " + name)
    for part in [build, verify]:
        sources = read(part / "sources.json")
        after = read(part / "sources-after.json")
        require(sources == after, "package source snapshot drift")
        require(sources["manifest"]["sha256"] == config["source_manifest"]["sha256"], "source snapshot manifest")
        for name, row in sources["files"].items():
            require(sha(part / "source" / (name + ".txt")) == row["sha256"], "exact source snapshot bytes")
    require(read(build / "sources.json")["files"] == read(verify / "sources.json")["files"], "build/runtime source match")
    require(read(build / "status.json")["state"] == "passed_scoped_build", "build status")
    command = read(build / "006-official-bundle.json")
    require(command["exit_code"] == 0 and command["argv"][-1] == "--without-ai-runtime" and "--no-build" not in command["argv"], "official normal build")
    require(command["environment"]["DEADPAN_FFMPEG_PREFIX"] == config["ffmpeg_prefix"], "qualified prefix")
    return {"source_files":62,"actual_feature_source_files":59,"normal_official_build":True,"without_ai_runtime":True}

def package_conservation():
    before, after, final = [read(verify / f"project-{name}.json") for name in ["before","after","final"]]
    for other in [after, final]:
        require(before["sql_dump_sha256"] == other["sql_dump_sha256"] and before["tables"] == other["tables"], "all SQL/table conservation")
        require(before["inventory"]["files"] == other["inventory"]["files"], "persistent byte conservation")
        require(before["head_revision"] == other["head_revision"] and before["history_cursor"] == other["history_cursor"] and before["head_storage"] == other["head_storage"], "raw head/history/storage conservation")
    for name in ["before","after","final"]:
        require(sha(verify / f"project-{name}.sql") == before["sql_dump_sha256"], "actual SQL dump bytes")
    require(before["head_revision"] == durable["revision_id"] and before["head_storage"]["representation"] == "elided", "elided authoritative head")
    for name in ["034-project-before.stdout","041-project-after.stdout"]:
        require(read(verify / name) == durable, "reconstructed bundled doc equals complete native durable actual")
    binding = read(verify / "native-project-binding.json")
    require(binding["head_document"] == durable and Path(binding["project"]).resolve() == Path(config["project"]).resolve(), "native project binding")
    status = read(verify / "status.json")
    require(status["state"] == "passed_scoped_worker_relocation" and all(status[k] for k in ["bundle_unchanged","reference_inputs_unchanged","six_cases_passed","sources_unchanged","sqlite_and_project_unchanged"]), "runtime status")
    return {"all_tables":len(before["tables"]),"persistent_files":len(before["inventory"]["files"]),"head":before["head_revision"],"history_cursor":before["history_cursor"],"sql_sha256":before["sql_dump_sha256"]}

def package_receipts():
    receipts = []
    for path in sorted(verify.glob("[0-9][0-9][0-9]-*.json")):
        row=read(path)
        require(row["exit_code"] == 0 and row["state"] == "finished", path.name + " command success")
        for ext in ["stdout","stderr"]:
            p=path.with_suffix("."+ext); require(p.is_file(), "actual command output")
        receipts.append(row)
    require(len(receipts)==41,"runtime command count")
    signature=(verify/"003-signature-identity.stderr").read_text()
    require("Signature=adhoc" in signature and "(adhoc,runtime)" in signature,"actual hardened ad-hoc identity")
    require("13 Mach-O files, 0 problems" in (verify/"004-bundle-audit.stdout").read_text(),"actual load audit")
    app=BASE/"package-verified/relocated/Deadpan.app"
    bins=read(verify/"relocated-binaries.json")
    for name,row in bins.items():require(sha(row["path"])==row["sha256"],"relocated executable hash "+name)
    for doctor_name in ["031-cli-doctor.stdout","032-app-headless-doctor.stdout"]:
        doctor=read(verify/doctor_name); runtime=doctor["runtime"]
        require(runtime["packaged"] and Path(runtime["bundle"]).resolve()==app.resolve(),"doctor bundle")
        require(len(runtime["workers"])==3 and all(w["present"] and w["inside_bundle"] and Path(w["path"]).resolve().is_relative_to(app.resolve()) for w in runtime["workers"]),"sibling workers")
        require(len(runtime["ffmpeg"])==5 and all(v["loaded"] and v["inside_bundle"] and Path(v["path"]).resolve().is_relative_to(app.resolve()) for v in runtime["ffmpeg"]),"mapped FFmpeg")
        require(runtime["ai_runtime"]["ready"] is False and runtime["ai_runtime"]["identity"] is None,"AI omission truthful")
    helper=read(verify/"033-helper-probe.stdout")
    require(helper["source"]=="bundled" and helper["probe"]["matches_pins"] and all(h["verified"] for h in helper["helpers"]),"helper probe")
    for h in helper["helpers"]:
        require(Path(h["path"]).resolve().is_relative_to(app.resolve()),"helper local path")
    for name in ["relocated-bundle-before.json","relocated-bundle-after.json"]:
        inventory=read(verify/name)
        for relative,row in inventory["files"].items():
            path=app/relative
            if "sha256" in row:require(sha(path)==row["sha256"],"actual copied bundle bytes "+relative)
    require(read(verify/"relocated-bundle-before.json")==read(verify/"relocated-bundle-after.json")==read(build/"built-bundle.json"),"build/copy/end inventory equality")
    require(not (app/"Contents/Resources/ai-runtime").exists(),"narrow bundle excludes AI runtime")
    skipped=read(verify/"official-bundle-verify-skipped.json")
    require(skipped["status"]=="skipped_incompatible","official verifier limitation")
    return {"actual_runtime_commands":41,"MachO_load_audit":13,"signature":"ad-hoc,hardened runtime","workers":3,"mapped_FFmpeg_libraries":5,"helper_probe":"matched bundled pins","official_bundle_verify":"skipped incompatible AI requirement"}

def package_cases():
    labels = {"blank":0,"mug":40,"two":80}
    timings={"elapsed_ms","worker_elapsed_ms","decode_elapsed_ms","vision_elapsed_ms"}
    rows=[]
    for label, expected_ordinal in labels.items():
        pair={}
        for mode in ["regions","both"]:
            key=label+"-"+mode; reference=config["baseline_reports"][key]
            require(sha(reference["path"])==reference["sha256"],"baseline hash "+key)
            baseline=read(reference["path"])
            output=next(verify.glob("[0-9][0-9][0-9]-"+key+".stdout"))
            actual=read(output)
            require({k:v for k,v in actual.items() if k not in timings} == {k:v for k,v in baseline.items() if k not in timings},"actual six-case semantic equality "+key)
            require(actual["protocol"]==2 and actual["selection"]==("both" if mode=="both" else "salient_regions"),"typed selection")
            require(actual["picture"]==expected_ordinal and actual["pts"]==expected_ordinal*1001 and actual["stream"]=={"stream_index":0,"time_base":[1,30000],"rotation_quarter_turns":0},"exact case clock")
            require(all(actual[k]==config["identities"][k] for k in ["content","asset","revision"]),"project/source identities")
            salient=actual["salient_regions"]; require(salient["runtime"]=={"detector":"salient_regions","engine":"Apple Vision VNGenerateObjectnessBasedSaliencyImageRequest","request_revision":2},"saliency provenance")
            require(len(salient["regions"])=={"blank":0,"mug":1,"two":2}[label],"real fixture counts")
            for row in salient["regions"]:
                q=row["region"];require(set(q)=={"x","y","width","height"} and all(math.isfinite(v) for v in q.values()),"geometry finite shape")
                require(0<=q["x"] and 0<=q["y"] and q["width"]>0 and q["height"]>0 and q["x"]+q["width"]<=1 and q["y"]+q["height"]<=1,"canonical upright geometry")
            if mode=="both":
                require(actual["faces"]=={"faces":[],"runtime":{"detector":"faces","engine":"Apple Vision VNDetectFaceRectanglesRequest","request_revision":3}},"actual empty faces with unchanged revision")
            else:require(actual["faces"] is None,"Regions-only omitted face detector")
            pair[mode]=salient
            receipt=read(output.with_suffix(".json"))
            require(receipt["environment_kind"]=="scrubbed" and receipt["environment"]["PATH"]=="/usr/bin:/bin" and receipt["environment"]["HOME"]==str(BASE.resolve()/"package-verified/home"),"scrubbed execution")
            rows.append({"case":key,"picture":actual["picture"],"pts":actual["pts"],"regions":len(salient["regions"])})
        require(pair["regions"]==pair["both"],"independent selected-mode region equality")
    return rows

def authority(package):
    with sqlite3.connect((Path(package)/"project.sqlite").resolve().as_uri()+"?mode=ro",uri=True) as db:
        db.execute("PRAGMA query_only=ON");db.execute("BEGIN")
        names=["revisions","history","redo","state","register_state","register_contents","registers","transaction_steps"]
        values={name:sorted(db.execute('SELECT * FROM "'+name+'"').fetchall(),key=repr) for name in names}
        head,cursor,workflow=db.execute("SELECT head_revision,cursor,workflow FROM state WHERE singleton=1").fetchone()
    canonical=json.dumps(values,sort_keys=True,separators=(",",":"))
    return {"sha256":hashlib.sha256(canonical.encode()).hexdigest(),"counts":{name:len(rows) for name,rows in values.items()},"head":head,"cursor":cursor,"workflow":workflow}

def media_conservation():
    result=read(media/"result.json");commands=read(media/"commands.json")
    require(result["derived_fixture"] is False and result["commands"]==len(commands)==15,"actual full media execution count")
    for row in commands:
        require(row["exit_code"]==0,"media exit "+row["name"])
        require(sha(media/(row["name"]+".stdout"))==row["stdout_sha256"] and sha(media/(row["name"]+".stderr"))==row["stderr_sha256"],"actual command stream pins")
    require(read(media/"dump.stdout")==durable==read(media/"portable-dump.stdout"),"full durable source/portable document match")
    before=read(media/"history-before.json")
    for package in [config["project"],media/"portable.deadpan"]:
        actual=authority(package)
        require(all(actual[k]==before[k] for k in actual),"current full eight-table authority "+str(package))
    require(result["history"]==before,"result full authority pin")
    require(result["verification_sha256"]==sha(media/"verification.json") and result["movie_sha256"]==sha(media/"camera-regions.mp4"),"actual media pins")
    mp=read(media/"pins.json")
    require(mp["runner"]==sha(BASE/"media.py") and mp["native_report"]==sha(config["native_report"]["path"]) and mp["identities"]==sha(BASE/"verified-identities.json"),"media raw input bindings")
    require(mp["binaries"]=={name:row["sha256"] for name,row in identities["binaries"].items()},"media actual binary pins")
    return {"commands":15,"full_doc_equal":True,"eight_tables_full_columns_equal":True,"history":before}

def emitted_media():
    result=read(media/"result.json");r=read(media/"verification.json");oracle=read(media/"provider-oracle.json")
    require(r["passed"] and not r["failures"] and r["revision_id"]==durable["revision_id"],"full emitted verification")
    require(r["range"]==[0,120] and r["frame_rate"]==[30000,1001],"output clock")
    require(r["movie"]["video_frames"]==r["movie"]["expected_video_frames"]==120 and r["movie"]["expected_audio_samples"]==r["movie"]["audio"]["presented_end"]==192192,"full output frame/audio endpoint")
    require(not r["movie"]["audio"]["gaps"],"full PCM coverage")
    require(len(r["pictures"])==len(oracle)==r["summary"]["pictures_checked"]==120 and r["summary"]["pictures_failed"]==0,"all120 comparisons")
    for i,(picture,expected) in enumerate(zip(r["pictures"],oracle)):
        require(picture["passed"] and picture["output_frame"]==picture["project_frame"]==expected["frame"]==i,"picture comparison")
        require(picture["provenance"]=={"kind":"original","asset":config["identities"]["asset"],"source_frame":expected["ordinal"],"source_pts":expected["pts"]},"provider clock oracle")
    a,=r["audio"]
    require(a["kind"]=="signal" and a["window"]==a["project_samples"]==[0,192192] and a["uncovered_samples"]==0 and a["passed"] and not a["flags"],"complete unshifted audio window")
    require(a["offset_status"]=="verified_zero" and a["measured_offset_samples"]==0,"aggregate zero")
    require(a["blocks"]["compared"]==401 and a["blocks"]["silent"]==0 and all(a["blocks"][k]==0 for k in ["low_snr_blocks","level_blocks","sound_in_silence_blocks"]),"all block gates")
    require(a["blocks"]["min_snr_db"]>=1.5 and a["blocks"]["max_level_difference_db"]<=3,"block extrema")
    unique=[s for s in a["segments"] if s["status"]=="verified_zero"];periodic=[s for s in a["segments"] if s["status"]=="periodic"]
    require(len(unique)==1 and unique[0]["segment_start"]==45056 and unique[0]["peak_lag"]==0 and len(periodic)==7,"honest segment statuses")
    for s in periodic: require(s["secondary_correlation"]>=s["peak_correlation"]-1e-3 and s["zero_lag_correlation"]>=s["peak_correlation"]-1e-3 and abs(s["secondary_lag"]-s["peak_lag"])>=32,"source periodicity criterion")
    return {"pictures":120,"audio_samples":192192,"blocks":401,"min_SNR_dB":a["blocks"]["min_snr_db"],"max_level_difference_dB":a["blocks"]["max_level_difference_db"],"unique_zero_segments":1,"periodic_unobservable_segments":7,"index_observable_neighbor_comparisons":r["summary"]["index_observable_comparisons"],"index_unobservable_neighbor_comparisons":r["summary"]["index_unobservable_comparisons"]}

for name,fn in [
    ("source_binary_chain",source_binary_chain),("native_report_fixture_and_durable_binding",native_bindings),
    ("official_build_source_manifest",package_sources_build),("package_full_SQL_and_byte_conservation",package_conservation),
    ("actual_signature_doctor_helper_and_copy_receipts",package_receipts),("six_scrubbed_proposal_cases",package_cases),
    ("media_full_document_history_portable_binding",media_conservation),("full_emitted_picture_audio_evidence",emitted_media)]:
    audit(name,fn)
result={"scope":"Read-only raw audit; no product/Cargo/replay/network/source/collection edits. Only this audit script and new raw-audit outputs written.",
        "findings":findings,"checks":checks,"input_pins":pins,
        "limits":["Scoped no-AI worker relocation on this Mac; official bundle-verify skipped for incompatible unconditional AI checks.",
                  "No full packaging/release/AI/clean-Mac qualification.",
                  "Picture comparisons cover all120 frames;234 adjacent-index comparisons are unobservable because fixture sections repeat pixels. Do not claim120 unique image-order observations.",
                  "One unique audio segment supports aggregate zero;7periodic segments remain individually unobservable. No shifting/trimming/alignment.",
                  "Later scripted proposal tests cover guards only; no detector recall/semantic recognition, physical display, listening or performance percentile claim.",
                  "Portable equality is complete Core document plus all columns of the specified8authored/history tables. Export creates operational render rows; do not claim entire database unchanged across render. Package's6read-only probes separately conserve full SQL and persistent bytes."]}
out=BASE/"raw-audit.json"
require(not out.exists(),"new audit output only")
out.write_text(json.dumps(result,indent=2)+"\n")
print(json.dumps({"checks_passed":sum(c["passed"] for c in checks),"findings":findings,"receipt_sha256":sha(out)},indent=2))
