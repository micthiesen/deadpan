# Fixed-Retime output-owned sound dependency proposal

Scratch only. No repository edits, Cargo or Git. No runtime claims.

## Normative contract and bounded goal

Spec §§5.3–5.4 and §6.3 preserve host-local ownership and the meaning of linked
edits. SOUND_EVENTS.md Required ownership and timing/Structural edit contract
states: a sound on Retime enters after the stage; a sound beneath Retime enters
its input. Changing the Original/RoomTone operand does not implicitly change the
independent sound authored in the stage output.

First family: ordinary SetHoldDuration beneath one fixed non-Partition Retime,
with a BeatSound owned by that exact Retime, unchanged node identity, output
extent, selected input range, pitch, purpose, treatments and placement. Prove
rather than assume that no outer processor was omitted. The witness uses Preserve.
Do not silently claim new nested-processor, input-owned, changed-stage-rate,
partial-owner, Split, Repeat or arbitrary attachment transport.

## Current refusal

insert_time/hold_duration/tests/processing.rs:
ordinary_hold_duration_processing_changed_attachment_scope_refuses_atomically
attaches to processing, then changes its interior hold 2 -> 3. It expects
InvalidCommand: "sound clock processing subtree changed".

sound_clock/edit.rs::SoundClockEditCapture::restore chooses the top root branch
when there is no prior journal. Here that branch and the event owner are both
processing. It calls full sound_clock_correspondence_with_repeats before
testing changed placement. That proof walks the entire child operand and fails
because body duration changed. Existing no-op and moved-unchanged-stage controls
have the same child before/after and succeed.

A prior journal has the same issue in historical proof/validation/readers.
Changing the reducer alone is insufficient.

## Proposed minimal API distinction, no wire change

Keep sound_clock_correspondence[_with_repeats] strictly meaning COMPLETE
processing-subtree correspondence, with its current tests and behavior.

Add an owner-aware helper, name provisional:
FrozenAudioLayout::sound_owner_clock_correspondence_with_repeats(
    current: &FrozenAudioLayout,
    historical_scope: &NodeId,
    live_scope: &NodeId,
    historical_owner: &NodeId,
    live_owner: &NodeId,
    repeats: &SoundClockRepeatMap,
    maximum_work: usize,
) -> Result<SoundClockCorrespondence, DocumentError>

The normal case delegates to today's full proof. The narrowly proven
independent OUTPUT dependency can stop descent at the exact event owner only
when historical_owner == historical_scope and live_owner == live_scope, both
are the same admitted fixed Retime family, and their own output contract is
unchanged. Retain checked placement/ancestor maps, rate, derived-clock, crop and
all work accounting. No omitted enclosing processor and no identity inferred
from equal-looking nodes. Current event/source mapping/offset is validated
independently, exactly as today.

This helper returns the existing proof type containing only the proven owner
and placement ancestry. It must not claim any changed child as a corresponding
node. Do not make a full proof partial or invent an event clock serialized tag.
The persisted reference already carries scope and owner; equality plus the
validated node contract can select this dependency class on read.

Do not append a sound reference when placement did not change. Fresh unchanged
placement leaves sound_clocks empty; existing output journals and their frozen
tables retain their identity. Hold's PHYSICAL Original/input timing capture
still uses the complete old ordinal-zero layout. This is not a reason to clear
a journal, skip historical validation or mutate Original bindings.

## Required consistent consumers

- core/src/audio_reference.rs: owner-aware proof plus bounded tests, retain
  old full proof strict.
- core/src/sound_clock/edit.rs: current and prior-reference proofs; key caches
  by owner pair/dependency class as well as scope. Existing scope-only caches
  MUST NOT reuse an output-only proof for an input-owned sibling sound.
- core/src/audio_binding.rs (~1472): persisted sound-journal validation and its
  checked-proof cache need the same owner-aware call/key.
- plan/src/plan.rs::RenderPlan::beat_sound_clock_scopes (~1151): same proof
  selection when restoring historical event voices.
- core/src/edit_slice/{sound_clocks,rename}.rs: existing saved-event proofs
  must handle the newly admitted journal if copied/renamed. If copying is not
  qualified in this slice, keep its exact refusal explicit; do not reinterpret
  the reference as a full-child proof or infer unproven descendants.

Audio consumers already prepare an independent sound voice through
audio_sound_instance_context and retained_sound_input/sound_clocks. They must
continue to apply CURRENT owner/ancestor policy and current treatments after
retained source preparation. No DSP change is justified by this proposal alone.

## Witness construction and exact geometry

output_owned.rs is a child of existing hold_duration/tests/processing.rs, reusing
fixture/rate/processing/attach_effect/span/request helpers. SetBeatSound itself
is executed publicly; prior-journal variants publicly grow lead 3 -> 4 first.
All factory, no-op and no-event-grow/shrink controls occur before desired success.

Project 30000/1001 fps, mix C = 8008/5 samples/frame.
body = Source3 + RoomTone Hold2 + Source4, exact extent 9.
processing = Retime(body, duration4, input[1,8), Preserve, Edit).
root = RoomTone lead3 + processing4 + Source tail3.
Interior shrink to1 leaves body8, so [1,8) remains valid.
Interior grow to3 leaves body10. Stage output node and root duration stay fixed.
No Silence Hold or allowance is present.

event = qualified same-asset span3100..3200 at 44.1kHz, natural mapping
10000/147147 project frames, offset +37 MIX samples = 185/8008 frames, hard
edges, Reject overflow. Its complete local support stays strictly inside[0,4).
Owner origin3: support RoundEven [4842,4951).
Public lead3->4 root ripple produces genuine retained sound clock ordinal0,
allocation move-unchanged-stage, owner/scope processing. Current origin4:
support RoundEven [6443,6552). Those current placement endpoints must not
redefine historical source phase.

The complete source-processing proof is expected to keep rejecting the altered
body in a no-event control. This proves the new output-owner proof must be
distinct, not weakened general equality.

Four positive tests independently cover grow/shrink, fresh/journaled. Current
code is expected to fail at the final public apply expect after prefix controls.
Root must execute and pin that actual result before implementation.

## PCM oracle, not unchanged total master audio

The inherited Hold is RoomTone, not Silence, and that is asserted. The changing
Original/RoomTone bus is NOT an unchanged-PCM oracle.

Use a separate event asset with independently known 44.1-kHz samples and a
provider supplying finite zeros for the other physical audio asset, retaining
the NON-SILENT RoomTone policies. This isolates the event contribution through
the ordinary public bus without muting an ancestor or changing Hold policy.
Then repeat with nonzero Original/RoomTone and verify the composed current bus
against its components/current suppression policy, not against the old total.

At fresh origin3 event onset ideal=4841.8, first allocated sample4842:
native phase3100 + (1/5)*(44100/48000) = 3100+147/800,
step147/160 native samples/mix sample. Hard endpoints exclude extra envelope
progress assumptions. After genuine journaled root movement, the same retained
native phase must survive at current onset6443; recomputing from new ideal
6443.4 gives3100-147/400 and is the WRONG phase.

Compare all surviving event samples, before/after onset and terminal support,
continuous/irregular/shuffled cold reads and revoked source admission. Keep a
simultaneous child-owned event control: its changed input still refuses
atomically. Do not mask a policy change by aligning audio events.

## Durable and export tests

Extend store/tests/source_registration/sounds/sound_clocks/{partial,repeats}.rs
or a focused new child: real measured 44.1-kHz event, preview/commit parity,
unchanged event recipe/journal, exact input clock reanchor, dry-run/no writes,
Undo/Redo/reopen/full-history validation. One late Compound descendant-sound
failure must preserve snapshot, steps, bank and history after a successful
first control preview.

One public release export compares all pictures and complete independent event
windows at measured offset zero; retain event-only analytic oracle and revised
mixed-bus current-policy checks. This does not qualify acoustic listening,
physical input, multiple processors or arbitrary sound routing.
