//! An unchanged Retime output-owned sound is independent of its child signal.
//!
//! Intended child of insert_time/hold_duration/tests/processing.rs.
use super::*;

fn ratio(numerator: i128, denominator: i128) -> ExactRatio {
    ExactRatio::new(numerator, denominator).unwrap()
}

fn changed(before: &ProjectDocument, command: Command, revision: &str) -> ProjectDocument {
    let request = CommandRequest {
        project_id: before.project_id().clone(),
        expected_revision: before.revision_id().clone(),
        new_revision: rev(revision),
        command,
    };
    let transaction = apply(before, &request).unwrap();
    let after = transaction.forward.apply(before).unwrap();
    assert_eq!(transaction.inverse.apply(&after).unwrap(), *before);
    assert_eq!(
        ProjectDocument::from_json(&after.to_json().unwrap()).unwrap(),
        after
    );
    after
}

fn output_sound(previous_journal: bool, grouped: bool) -> (ProjectDocument, SoundId) {
    let mut before = processing(PitchPolicy::Preserve, 1, false);
    if grouped {
        before.nodes.insert(
            id("group"),
            BeatNode::sequence("Group", vec![id("processing"), id("tail")]),
        );
        before.nodes.insert(
            id("root"),
            BeatNode::sequence("Root", vec![id("lead"), id("group")]),
        );
        before.validate().unwrap();
    }
    // Reuse the existing fixture recipe, but admit the attachment through its
    // public command rather than introducing it during the target edit.
    let mut template = before.clone();
    let effect = attach_effect(&mut template, "processing");
    let event = template.beat_sounds[&id("processing")][&effect].clone();
    let attached = changed(
        &before,
        Command::SetBeatSound {
            owner: id("processing"),
            id: effect.clone(),
            event,
        },
        "attach-output-sound",
    );
    assert_eq!(attached.nodes(), before.nodes());
    let document = if previous_journal {
        // Existing supported control: move the entire unchanged stage by
        // growing the preceding Hold. This retains a genuine sound journal.
        changed(
            &attached,
            Command::SetHoldDuration {
                node: id("lead"),
                duration: frames(4),
            },
            "move-unchanged-stage",
        )
    } else {
        attached
    };
    (document, effect)
}

fn output_projection(document: &ProjectDocument) -> FrozenAudioProjection {
    FrozenAudioLayout::capture(document)
        .unwrap()
        .project(
            &instance("processing", &[]),
            ExactRatio::ZERO,
            None,
            MAX_DOCUMENT_NODES,
        )
        .unwrap()
}

fn assert_fixed_output_resize(length: i64, previous_journal: bool, grouped: bool) {
    let (before, effect) = output_sound(previous_journal, grouped);
    before.validate().unwrap();
    let snapshot = before.to_json().unwrap();
    let event = before.beat_sounds[&id("processing")][&effect].clone();
    let stage = before.nodes()[&id("processing")].clone();
    let origin = if previous_journal { 4 } else { 3 };
    assert_eq!(
        before.presentation_basis().frame_rate,
        FrameRate::new(30_000, 1001).unwrap()
    );
    assert_eq!(event.source.span, span(3100, 3200)); // 100 native 44.1-kHz samples.
    assert_eq!(event.offset, AudioSample(37));
    assert_eq!(
        event.mapping,
        SourceAudioMapping::natural_rate(event.source.span, before.presentation_basis().frame_rate)
            .unwrap()
    );
    assert_eq!(event.overflow, SoundOverflowPolicy::Reject);
    assert_eq!(event.start_edge, AudioEdgePolicy::Hard);
    assert_eq!(event.end_edge, AudioEdgePolicy::Hard);
    let NodeKind::Retime {
        child,
        duration,
        mapping,
        pitch,
        purpose,
    } = &stage.kind
    else {
        panic!("fixture must have a real processing stage")
    };
    assert_eq!(child, &id("body"));
    assert_eq!(*duration, frames(4));
    assert_eq!(
        *mapping,
        FrameRange::new(ProjectFrame(1), ProjectFrame(8)).unwrap()
    );
    assert_eq!(*pitch, PitchPolicy::Preserve);
    assert_eq!(*purpose, RetimePurpose::Edit);
    assert_eq!(before.node_duration(&id("body")).unwrap(), frames(9));
    let projection = output_projection(&before);
    assert_eq!(projection.origin, ExactRatio::integer(origin));
    assert_eq!(projection.frames_per_local_frame, ExactRatio::ONE);
    assert_eq!(projection.local_extent, ExactRatio::integer(4));
    assert_eq!(projection.local_duration, frames(4));
    assert_eq!(projection.instance, instance("processing", &[]));
    // No silent Hold is introduced by this fixture. Its independent event
    // signal, not its changing Original+RoomTone bus, is the PCM invariant.
    for owner in ["lead", "hold"] {
        assert!(matches!(
            &before.nodes()[&id(owner)].kind,
            NodeKind::Hold { recipe }
                if matches!(recipe.audio, HoldAudio::RoomTone { .. })
        ));
    }
    assert!(before.sound_allowances().is_empty());
    let selection = event
        .mapping
        .selection_frames_with_offset(
            frames(4),
            event.offset,
            before.presentation_basis().frame_rate,
        )
        .unwrap();
    assert_eq!(selection.start, ratio(185, 8008));
    assert_eq!(
        selection.end,
        ratio(185, 8008).checked_add(ratio(10000, 147147)).unwrap()
    );
    assert!(selection.start.compare_integer(0).is_gt());
    assert!(selection.end.compare_integer(4).is_lt());
    // Absolute root allocation is derived from the unchanged owner transform;
    // the offset stays an independent mix-sample offset, never native samples.
    let samples_per_frame = ratio(8008, 5);
    let start = projection
        .origin
        .checked_add(selection.start)
        .unwrap()
        .checked_mul(samples_per_frame)
        .unwrap()
        .round_even()
        .unwrap();
    let end = projection
        .origin
        .checked_add(selection.end)
        .unwrap()
        .checked_mul(samples_per_frame)
        .unwrap()
        .round_even()
        .unwrap();
    assert_eq!(
        (start, end),
        if previous_journal {
            (6443, 6552)
        } else {
            (4842, 4951)
        }
    );
    if previous_journal {
        let journal = &before.audio_bindings().sound_clocks()[&id("processing")][&effect];
        let scope = id(if grouped { "group" } else { "processing" });
        assert_eq!(journal.scope(), &scope);
        assert_eq!(journal.clocks().len(), 1);
        let clock = &journal.clocks()[0];
        assert_eq!(clock.scope(), &scope);
        assert_eq!(clock.owner(), &id("processing"));
        assert_eq!(clock.timing().allocation, rev("move-unchanged-stage"));
        assert_eq!(clock.timing().ordinal, 0);
    } else {
        assert!(before.audio_bindings().sound_clocks().is_empty());
    }

    // Unchanged-edit control comes first. Presence, 44.1-kHz mapping, offset,
    // existing journals and the ordinary command are independently admitted.
    let noop = changed(
        &before,
        Command::SetHoldDuration {
            node: id("hold"),
            duration: frames(2),
        },
        "unchanged-output-sound",
    );
    assert_eq!(noop.nodes(), before.nodes());
    assert_eq!(noop.beat_sounds, before.beat_sounds);
    assert_eq!(noop.audio_bindings(), before.audio_bindings());
    assert_eq!(output_projection(&noop), projection);
    assert_eq!(before.to_json().unwrap(), snapshot);

    // The exact same interior edit without that one attachment already works.
    // Deletion uses its public lifecycle and prunes only its sound journal.
    let no_event = changed(
        &before,
        Command::DeleteBeatSound {
            owner: id("processing"),
            id: effect.clone(),
        },
        "remove-output-sound-control",
    );
    assert!(no_event.beat_sounds.is_empty());
    let ordinary = changed(
        &no_event,
        Command::SetHoldDuration {
            node: id("hold"),
            duration: frames(length),
        },
        "resize-without-output-sound",
    );
    assert_eq!(ordinary.nodes()[&id("processing")], stage);
    assert_eq!(
        ordinary.node_duration(&id("body")).unwrap(),
        frames(7 + length)
    );
    assert_eq!(ordinary.duration().unwrap(), before.duration().unwrap());
    assert_eq!(output_projection(&ordinary).origin, projection.origin);
    assert_eq!(
        output_projection(&ordinary).frames_per_local_frame,
        projection.frames_per_local_frame
    );
    assert_eq!(
        output_projection(&ordinary).local_extent,
        projection.local_extent
    );
    // Complete Original-processing subtree identity genuinely changed.
    // The existing general correspondence must remain strict; only an
    // independent owner's output dependency proof may use the narrower fact.
    assert_eq!(
        FrozenAudioLayout::capture(&no_event)
            .unwrap()
            .sound_clock_correspondence(
                &FrozenAudioLayout::capture(&ordinary).unwrap(),
                &id("processing"),
                &id("processing"),
                MAX_DOCUMENT_NODES,
            )
            .unwrap_err()
            .message,
        "sound clock processing subtree changed"
    );

    let request = CommandRequest {
        project_id: before.project_id().clone(),
        expected_revision: before.revision_id().clone(),
        new_revision: rev("resize-with-output-sound"),
        command: Command::SetHoldDuration {
            node: id("hold"),
            duration: frames(length),
        },
    };
    // Old code must fail HERE, after every valid factory/control assertion.
    let transaction = apply(&before, &request).expect(
        "an unchanged stage-output-owned sound must not depend on its changed child signal",
    );
    let after = transaction.forward.apply(&before).unwrap();
    assert_eq!(after.nodes()[&id("processing")], stage);
    assert_eq!(after.beat_sounds, before.beat_sounds);
    if grouped && previous_journal {
        // This valid older capture includes the surrounding Sequence group.
        // The output-only proof narrows its dependency without inventing a new
        // clock or changing the historical owner, timing identity, or layout.
        let old = &before.audio_bindings().sound_clocks()[&id("processing")][&effect];
        let new = &after.audio_bindings().sound_clocks()[&id("processing")][&effect];
        assert_eq!(new.scope(), &id("processing"));
        assert_eq!(new.clocks().len(), old.clocks().len());
        for (old, new) in old.clocks().iter().zip(new.clocks()) {
            assert_eq!(new.scope(), &id("processing"));
            assert_eq!(new.owner(), old.owner());
            assert_eq!(new.timing(), old.timing());
            assert_eq!(new.repeats(), old.repeats());
            assert_eq!(
                after.audio_bindings().timings()[new.timing()],
                before.audio_bindings().timings()[old.timing()]
            );
        }
    } else {
        assert_eq!(
            after.audio_bindings().sound_clocks(),
            before.audio_bindings().sound_clocks()
        );
    }
    let current_projection = output_projection(&after);
    assert_eq!(current_projection.origin, projection.origin);
    assert_eq!(
        current_projection.frames_per_local_frame,
        projection.frames_per_local_frame
    );
    assert_eq!(current_projection.local_extent, projection.local_extent);
    assert_eq!(
        after.node_duration(&id("body")).unwrap(),
        frames(7 + length)
    );
    assert_eq!(after.duration().unwrap(), before.duration().unwrap());
    assert_eq!(after.marks(), before.marks());
    assert_eq!(after.nodes()[&id("lead")], before.nodes()[&id("lead")]);
    assert_eq!(after.nodes()[&id("tail")], before.nodes()[&id("tail")]);
    after.validate().unwrap();
    assert_eq!(transaction.inverse.apply(&after).unwrap(), before);
    assert_eq!(
        ProjectDocument::from_json(&after.to_json().unwrap()).unwrap(),
        after
    );
    assert_eq!(before.to_json().unwrap(), snapshot);
}

#[test]
fn fixed_retime_output_owned_sound_grow_ignores_changed_child_dependency() {
    assert_fixed_output_resize(3, false, false);
}

#[test]
fn fixed_retime_output_owned_sound_shrink_ignores_changed_child_dependency() {
    assert_fixed_output_resize(1, false, false);
}

#[test]
fn fixed_retime_output_owned_sound_grow_preserves_existing_output_journal() {
    assert_fixed_output_resize(3, true, false);
}

#[test]
fn fixed_retime_output_owned_sound_shrink_preserves_existing_output_journal() {
    assert_fixed_output_resize(1, true, false);
}

#[test]
fn fixed_retime_output_owned_sound_under_sequence_group_grow_ignores_child_dependency() {
    assert_fixed_output_resize(3, false, true);
}

#[test]
fn fixed_retime_output_owned_sound_under_sequence_group_shrink_narrows_existing_journal() {
    assert_fixed_output_resize(1, true, true);
}

#[test]
fn fixed_retime_descendant_owned_sound_keeps_changed_input_refusal() {
    let base = processing(PitchPolicy::Preserve, 1, false);
    let mut template = base.clone();
    let effect = attach_effect(&mut template, "after");
    let before = changed(
        &base,
        Command::SetBeatSound {
            owner: id("after"),
            id: effect.clone(),
            event: template.beat_sounds[&id("after")][&effect].clone(),
        },
        "attach-input-sound",
    );
    assert!(
        before
            .children(&id("body"))
            .any(|owner| owner == &id("after"))
    );
    assert_ne!(id("after"), id("processing"));
    let noop = changed(
        &before,
        Command::SetHoldDuration {
            node: id("hold"),
            duration: frames(2),
        },
        "unchanged-input-sound",
    );
    assert_eq!(noop.beat_sounds, before.beat_sounds);
    let snapshot = before.to_json().unwrap();
    for length in [1, 3] {
        let request = CommandRequest {
            project_id: before.project_id().clone(),
            expected_revision: before.revision_id().clone(),
            new_revision: rev("still-refused-input-sound"),
            command: Command::SetHoldDuration {
                node: id("hold"),
                duration: frames(length),
            },
        };
        let error = apply(&before, &request).unwrap_err();
        assert_eq!(error.code, EditErrorCode::InvalidCommand);
        assert_eq!(error.message, "sound clock processing subtree changed");
        assert_eq!(before.to_json().unwrap(), snapshot);
    }
}
