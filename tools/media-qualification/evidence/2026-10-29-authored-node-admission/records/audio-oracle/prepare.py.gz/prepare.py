from pathlib import Path
import hashlib,json
root=Path('/tmp/deadpan-authored-owner-admission-2026-10-29/audio-oracle')
repos={'main':Path('/Users/michael/Code/deadpan'),'scoped':Path('/tmp/deadpan-query-groundwork-2026-10-26/scoped')}
files=['crates/deadpan-audio/src/authored_eq.rs','crates/deadpan-audio/src/authored_eq/legacy_node_baseline.rs']
pins={}
for name,repo in repos.items():
 for f in files:
  p=repo/f
  dest=root/'before'/name/f
  dest.parent.mkdir(parents=True,exist_ok=True)
  if p.exists():
   dest.write_bytes(p.read_bytes());pins[name+'/'+f]=hashlib.sha256(p.read_bytes()).hexdigest()
  else:pins[name+'/'+f]=None
(root/'before-pins.json').write_text(json.dumps(pins,indent=2)+'\n')
(root/'task-files.json').write_text(json.dumps(files,indent=2)+'\n')
