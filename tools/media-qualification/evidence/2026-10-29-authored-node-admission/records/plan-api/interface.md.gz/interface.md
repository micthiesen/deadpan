# Draft only, awaiting parent OLD freeze/apply permission

Public additions:
- RenderPlan::audio_owner_input_admitted<A: AudioSoundContextAdmission>(&self, owner: &AudioOwnerClock<'_>, at: AudioSample, limits: AudioQueryLimits, admission: &mut A) -> Result<AdmittedAudioOwnerInputCapture<'_, A::Issuer, A::Lease>, A::Error>
- AudioDomain<'plan>::owner_input_admitted: same arguments, returning AdmittedAudioOwnerInputCapture<'plan, ...>.

Normal direct APIs call those same orchestrators with private unit Unmetered and extract only the guaranteed actual selected Input. Metered carrier stays borrow-only and non-Clone with no public extraction.

Ordering: original caller limits, foreign owner, candidate kernel checked at+1, actual gain-owner Q, first actual span exact private same_at selection, missing owner error, actual capture with original remaining Q+C budget. No public index-selection behavior is substituted; exact play, sampling, origin and definition comparisons stay inside Plan. Public candidate capture keeps its existing mode/issuer, caller-limits, index, and remaining-budget order.

True additional selection work is one first-span inspection and one per inspected owner, including failed membership. Selection charges the same remaining local capture budget and is recorded in capture_additional. Source Input work includes query work + selection work + actual capture work. Query canonical Q and capture canonical C remain separately unchanged. Original zero-query-remainder capture is never revalidated as caller limits.

Actual Q storage and its charge survive selection and capture; returned actual source Input and its independent charge survive caller borrowing for final sharing. Shared private capture_in_parent kernel and borrowed finish_capture receipt checker preserve physical query destruction before query charge release. No inherited production query, Core, capture walk, or retained algorithms change.

New tests draft assumes oracle worker post-freeze direct_input_baseline::{visit_cases,input_snapshot,error_snapshot}, reusing wide_baseline::Parent. Expected new fixture path tests/fixtures/direct-owner-input-baseline-v1/snapshot.json (awaiting oracle-worker confirmation). False compares all cases including exact/short errors and complete actual discard events literally. True compares all ample successes/errors, every complete Input field and canonical Q+C, selected observation/captured seed/discarded span with separate Core-work proofs; resource tests cover exact/short peak+work, query/source overlap, all reservation/work callback refusals, cancellation, issuer changes, zero Q remainder, and accepted failed-membership inspection work.

Rustfmt parsed the draft. No Cargo/Git or shared-source edits.
