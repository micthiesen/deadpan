from pathlib import Path
import hashlib,json,re
s=Path(__file__).resolve().parent
main=Path('/Users/michael/Code/deadpan');scope=Path('/tmp/deadpan-query-groundwork-2026-10-26/scoped')
sha=lambda b:hashlib.sha256(b).hexdigest()
negative={'direct-oracle-main':101,'authored-audio1':101,'authored-strict1':1,'authored-split':101}
receipts=[]
for p in sorted(s.glob('*.json')):
 if p.name=='direct-oracle-main-snapshot.json':
  assert p.read_bytes()==b''
  continue
 r=json.loads(p.read_text())
 if not isinstance(r,dict) or 'started_at'not in r or 'command'not in r:continue
 assert r.get('exit_code')==negative.get(p.stem,0),(p.stem,r.get('exit_code'))
 assert r['sources_unchanged']and r['binaries_unchanged'],p.stem
 for name,h in r['streams'].items():
  b=Path(name).read_bytes();assert len(b)==h['bytes']and sha(b)==h['sha256']
 receipts.append({'label':p.stem,'exit_code':r['exit_code'],'seconds':r['seconds'],'sha256':sha(p.read_bytes()),'source_inputs':len(r['source_before'])})
final=['authored-build4','authored-audio3','authored-stages2','authored-definition2','authored-scoped-build3','authored-scoped-audio2','authored-scoped-stages','authored-scoped-birth','authored-strict2','authored-split']
for label in final:
 r=json.loads((s/(label+'.json')).read_text())
 for name,h in r['source_after'].items():
  b=Path(name).read_bytes();assert len(b)==h['bytes']and sha(b)==h['sha256'],(label,name)
rows=json.loads((s/'task-source-pins.json').read_text())
raw=(s/'index-blobs.bin').read_bytes();offset=0;equality=[]
for row in rows:
 end=raw.index(b'\n',offset);h=raw[offset:end].decode().split();assert h[1]=='blob'
 n=int(h[2]);body=raw[end+1:end+1+n];offset=end+2+n
 assert body==(scope/row['path']).read_bytes()and sha(body)==row['sha256']
 assert sha((main/row['path']).read_bytes())==row['main_sha256']
 equality.append({'path':row['path'],'blob':h[0],'sha256':row['sha256'],'scoped_index_equal':True,'main_equal':row['main_equals_scoped']})
assert offset==len(raw)and len(rows)==17 and sum(r['main_equal']for r in equality)==16
(s/'index-source-equality.json').write_text(json.dumps(equality,indent=2)+'\n')
owned={r['path']for r in rows};unchanged={}
for variant,root in [('main',main),('scoped',scope)]:
 before=json.loads((s/(variant+'-initial-authority.json')).read_text());count=0
 for rel,h in before.items():
  if rel in owned:continue
  assert sha((root/rel).read_bytes())==h,(variant,rel)
  count+=1
 unchanged[variant]=count
rel='crates/deadpan-audio/src/shared_eq.rs'
old=(s/'audio-production/before/main'/rel).read_text()
assert (main/rel).read_text()==old.replace('mod node_capacity;','pub(super) mod node_capacity;',1)
for row in json.loads((s/'immutable-oracle-pins.json').read_text()):
 for root in [main,scope]:assert sha((root/row['path']).read_bytes())==row['sha256']
plans={}
for label in ['authored-build1','authored-scoped-build2']:
 rs=json.loads((s/'plan-results'/label/'results.json').read_text())
 assert len(rs)==29 and all(r['exit_code']==0 for r in rs)
 plans[label]={'targets':29,'passed':sum(int(v[1])for r in rs for v in r['test_results']),'ignored':sum(int(v[3])for r in rs for v in r['test_results'])}
reused=json.loads((s/'plan-binary-reuse-audit.json').read_text())
assert len(reused)==2 and all(r['all_29_plan_binaries_identical']for r in reused)
tests={}
expected={'authored-audio3':351,'authored-scoped-audio2':332,'authored-stages2':203,'authored-definition2':171,'authored-scoped-stages':203,'authored-scoped-birth':8}
for label,n in expected.items():
 text=(s/(label+'.stdout')).read_text()
 m=re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;',text)
 assert len(m)==1 and int(m[0][0])==n and int(m[0][1])==0,(label,m)
 tests[label]={'passed':n,'ignored':int(m[0][2]),'seconds':json.loads((s/(label+'.json')).read_text())['seconds']}
empty=(s/'authored-scoped-history.stdout').read_text()
assert '0 passed; 0 failed'in empty
split=re.findall(r'^test ([\w:]+) \.\.\. (ok|FAILED|ignored)',(s/'authored-split.stdout').read_text(),re.M)
assert len(split)==7
result={'all_terminal':True,'receipts':receipts,'negative_results_retained':negative,'source_files':17,'rust_files':13,'main_equal_source_files':16,'scope_index_equal':True,'other_initial_inputs_unchanged':unchanged,'final_compiled_sources_current':True,'plan_binary_reuse':reused,'plan_results':plans,'tests':tests,'immutable_oracles_unchanged':7,'no_credit_zero_test_receipt':'authored-scoped-history','split':{'passed':sum(v=='ok'for _,v in split),'failed':sum(v=='FAILED'for _,v in split),'cases':split,'seconds':json.loads((s/'authored-split.json').read_text())['seconds']},'scoped_patch_sha256':sha((s/'task-scoped.patch').read_bytes())}
(s/'final-audit.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items()if k not in ['receipts','plan_binary_reuse']}))
