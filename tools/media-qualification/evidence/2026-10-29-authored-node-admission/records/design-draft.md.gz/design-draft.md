# Authored ownership closure draft

Base 43419eb4f. Keep the full product goal active; no cap/weight/refund/cold activation changes. General sound Split stays disabled; prior wide checkpoint ordinary suites pass and matrix3/4 remains open.

## Frozen old paths before refactor

Independent Plan old direct input producer and actual native Authored eq_node producer are now test-only additions. Both source variants must run before applying any production draft. The direct API actually uses audio_gain_owners/gain_owners, not the strict audio_owners flavor. Its private same_at includes hidden play and affine sampling. Shared Description's coarse OwnerKey selection and current-sound fallback cannot replace this path.

Existing direct order: limits -> foreign owner -> checked at+1 -> actual gain query -> first-span same_at selection -> missing-owner error or capture with original remaining Q+C budget. Keep the membership query even when the wide renderer query already observed the owner.

## Exact Plan seam

Add narrow admitted direct Root/Domain input APIs returning the actual guarded source capture. Old normal APIs share false orchestration. Preserve Q/C canonical provenance and every ample-budget/non-resource error. Metered additional selection work can preempt later work under the unchanged budget and is never refunded.

Retain Q value/charge until capture finishes; retain the independent source Input value/charge through final probe/sharing. No duplicate query, public reconstruction of hidden play, arbitrary synthetic charge, or naked value extraction. Private unit/false extraction for the normal API is allowed as elsewhere.

The draft implementation author proposes one first-span inspection and one per examined owner as additional capture work. Public candidate.capture keeps its existing external validation/index order and shares only the inner parent capture/receipt mechanics. Do not revalidate a zero internal remainder and replace the old structural-work error with InvalidAudioLimits.

## Authored Graph caller

Create an Authored-only description, not Shared Description. Root/Domain use the exact new direct API, bill false source input once and skip streamed true input work, then reuse existing finish_paid_owner_input_admitted. Incoming Retained keeps the exact shared Arc and skips a fresh membership query. It creates no new underlying deep allocation; preserve the owning parent/context lifetime.

Preserve eq_node cache hit before metadata/cancellation work, then old owner-count check, context resolution, recipe lookup, boundary construction, native bound/tap charge and native construction order. New capacity admission precedes native construction, with old/new Vec live and charged together; actual replacement allocation remains after native construction.

Use the same actual Plan/Core/buffer context transfer, boundary guard, native bound and generic pending capacity. Seven named lanes remain available with sound/key absent. Preflight every issuer, sum, subtraction, work/cancel and capacity invariant before any node move. Publish once, physically drop old Vec before retiring its capacity, update checked active/resident totals and disarm the actual leases. Graph drops before aggregate release.

Node/Graph gain the request work lifetime for their boundary carrier. Values precede charges. Generic node capacity needs minimal Stage-internal visibility so Authored can reuse it; no agent-managed checkout/worktree. Preserve Authored EQ-owner-count semantics before calling the generic helper; investigate any additional count/error label parameter only if a reachable difference requires it.

## Temporary Authored tile boundary

The non-Clone persistent wrapper prevents the existing boundary.clone from compiling. Prefer closing this temporary copy in the same increment: construct a second admitted boundary from the stored owner and exact before stage with the actual query policy before filter.take. This holds an independent full owner-copy lease through recursive tile reads, unlike the smaller shared-mix stop key.

To avoid adding an owned extraction or raw cloned boundary API, use an Audio-only borrowed stop view with the existing owner getter and exact before value. Program only needs matches (delegating to matches_treatment_owner) and before_stage. This small view can borrow the local admitted boundary owner; it does not borrow Graph across recursion or add a work lifetime to every Program use. Verify the complete existing plain-boundary predicate before implementation. An alternative must preserve no naked uncharged copy, no new Arc solely for the handoff, and exact old stop behavior.

This temporary-copy choice still needs a focused independent design review before source implementation. Authored/shared tile maps, Arc shell/bookkeeping containers, other shared Graph maps and mix route/bus/layer clock copies remain later work.
