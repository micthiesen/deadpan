#[test]
fn actual_incoming_retained_has_only_boundary_and_native_work_and_no_new_context_carrier() {
    let mut observed = 0;
    let _ = baseline::cases(|plan, incoming, owner, at, stage, parent, owner_limit| {
        let Context::Retained(expected) = incoming else {
            return Value::Null;
        };
        assert!(owner_limit.is_none());
        observed += 1;
        let cancelled = AtomicBool::new(false);
        let work = RefCell::new(ReadWork::default());
        let control = fixture::control(&cancelled, &work);
        let mut renderer = StageAudio::new(Arc::clone(plan));
        let mut admission = sound_context_admission::Admission::new(&mut renderer, control);
        let boundary = owner
            .treatment_boundary_admitted(stage, control.query_limits().unwrap(), &mut admission)
            .unwrap();
        let boundary_fee = boundary.additional_units();
        let boundary_frames = boundary.lease().unwrap().frames();
        assert_eq!(boundary.canonical_units(), 0);
        assert_eq!(work.borrow().plan_work, boundary_fee);
        drop(boundary);
        assert_eq!(work.borrow().sound_context_frames, 0);
        drop(admission);

        let description_work = RefCell::new(ReadWork::default());
        let description_control = fixture::control(&cancelled, &description_work);
        let description = {
            let mut admission =
                sound_context_admission::Admission::new(&mut renderer, description_control);
            node_description::describe_admitted(
                plan,
                request(incoming, owner, at, stage),
                description_control,
                &mut admission,
            )
            .unwrap()
        };
        assert!(
            description.original.is_none(),
            "incoming context already owns its allocation"
        );
        let Context::Retained(actual) = &description.context else {
            panic!("actual retained consumer was replaced");
        };
        assert!(actual.ptr_eq(expected));
        assert_eq!(
            description_work.borrow().plan_work,
            boundary_fee,
            "no direct membership, capture, probe, retained membership or context copy"
        );
        assert_eq!(
            description_work.borrow().sound_context_frames,
            boundary_frames
        );
        drop(description);
        assert_eq!(description_work.borrow().sound_context_frames, 0);
        assert_eq!(description_work.borrow().plan_work, boundary_fee);

        let node = baseline::measured(plan, incoming, owner, at, stage, parent, None);
        assert_eq!(
            node["controller_plan_work"],
            json!(
                boundary_fee
                    .checked_add(deadpan_dsp::FINITE_FILTER_TAPS)
                    .unwrap()
            )
        );
        assert_eq!(
            node["accounting"]["graph_resident"],
            json!(
                fixture::units()
                    .checked_add(boundary_frames)
                    .unwrap()
                    .checked_add(capacity_frames::<Node<'_, '_>>(4))
                    .unwrap()
            )
        );
        Value::Null
    });
    assert_eq!(
        observed, 1,
        "the frozen oracle has exactly one actual incoming retained case"
    );
}
