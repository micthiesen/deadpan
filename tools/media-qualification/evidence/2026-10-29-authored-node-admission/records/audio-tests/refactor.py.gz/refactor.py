from pathlib import Path
root=Path('/Users/michael/Code/deadpan')
p=root/'crates/deadpan-audio/src/authored_eq/legacy_node_baseline.rs'
s=p.read_text()
s=s.replace('//! One-shot native OLD-node oracle. This calls the actual eq_node and observes\n//! its published Node; it does not duplicate owner selection or sharing logic.','//! Reusable observations and fixture reconstruction after the independent OLD\n//! native oracle was frozen. The immutable golden is never generated here.')
s=s.replace('use std::io::Write;\n','')
for name in ['clock','context','measured','render','frozen','observed']:
 s=s.replace('fn '+name+'(', 'pub(super) fn '+name+'(').replace('fn '+name+"<'plan>", 'pub(super) fn '+name+"<'plan>")
s=s.replace('        resident: 0,\n        skip:', '        resident: 0,\n        node_capacity_frames: 0,\n        skip:')
s=s.replace('''                assert_eq!(
                    construction_work,
                    deadpan_dsp::FINITE_FILTER_TAPS,
                    "incoming retained skips direct membership/probe/copy work"
                );
''','')
start=s.index('fn checked_output(')
body_start=s.index('    let plan = eq_admission_fixture::fixture();',start)
body_end=s.index('\n    let result = json!({',body_start)
body=s[body_start:body_end].replace('measured(', 'observe(')
s=s[:start]+'''/// Recreate the exact thirteen independently frozen inputs. Observation queries
/// and the actual incoming retained Arc are established outside measured work.
pub(super) fn cases(
    mut observe: impl for<'plan> FnMut(
        &'plan Arc<RenderPlan>,
        &Context<'plan>,
        &AudioOwnerClock<'plan>,
        AudioSample,
        usize,
        usize,
        Option<u32>,
    ) -> Value,
) -> Vec<Value> {
'''+body+'''
    cases
}
'''
p.write_text(s)
