from pathlib import Path
p=Path('/Users/michael/Code/deadpan/crates/deadpan-audio/src/authored_eq/node_admission_tests.rs')
s=p.read_text()
s=s.replace('    let mut trace = Trace::new(&mut renderer, success_control, &cancelled);',
'''    let (reservations, spends) = {
    let mut trace = Trace::new(&mut renderer, success_control, &cancelled);''',1)
s=s.replace('    drop(trace);\n    for (reservation, spend)', '    (reservations, spends)\n    };\n    for (reservation, spend)',1)
s=s.replace('        let mut trace = Trace::new(&mut renderer, control, &cancelled);',
'''        {
        let mut trace = Trace::new(&mut renderer, control, &cancelled);''',1)
s=s.replace('        drop(trace);\n        assert_eq!(renderer.active_frames, BASE);','        }\n        assert_eq!(renderer.active_frames, BASE);',1)
old='''        let mut admission = sound_context_admission::Admission::new(&mut renderer, control);
        let boundary = owner
            .treatment_boundary_admitted(stage, control.query_limits().unwrap(), &mut admission)
            .unwrap();'''
new='''        let (boundary_fee, boundary_frames) = {
        let mut admission = sound_context_admission::Admission::new(&mut renderer, control);
        let boundary = owner
            .treatment_boundary_admitted(stage, control.query_limits().unwrap(), &mut admission)
            .unwrap();'''
assert s.count(old)==1
s=s.replace(old,new)
s=s.replace('        drop(admission);\n\n        let description_work', '        (boundary_fee, boundary_frames)\n        };\n\n        let description_work',1)
Path('/tmp/deadpan-authored-owner-admission-2026-10-29/audio-tests/node_admission_tests.scopes.rs').write_text(s)
