from pathlib import Path
p=Path('/Users/michael/Code/deadpan/crates/deadpan-audio/src/authored_eq/node_admission_tests.rs')
s=p.read_text()
s=s.replace('    let actual = baseline::cases(baseline::measured);','    let actual = baseline::cases(baseline::measured);\n    let retained_receipts = independent_retained_receipts();')
s=s.replace('''        let observed = &actual["observation"];
        let expected = &expected["observation"];
        for field in [''','''        let mut observed = actual["observation"].clone();
        let expected = &expected["observation"];
        if actual["name"] == "live_owner_actual_retained_probe_selection" {
            // Only these three actual bound/probe receipts change under true
            // accounting. Prove each against an independent direct capture and
            // probe before comparing every other frozen field literally.
            for (path, canonical, metered) in &retained_receipts {
                assert_eq!(expected.pointer(path).unwrap(), canonical, "{path}");
                assert_eq!(observed.pointer(path).unwrap(), metered, "{path}");
                let old = canonical.as_u64().unwrap();
                let total = metered.as_u64().unwrap();
                let additional = total.checked_sub(old).unwrap();
                assert_eq!(old.checked_add(additional).unwrap(), total);
                *observed.pointer_mut(path).unwrap() = canonical.clone();
            }
        }
        for field in [''')
s=s.replace('    assert_eq!(input.work(), canonical_input);','''    assert_eq!(
        input.work(),
        canonical_input.checked_add(additional_input).unwrap()
    );''')
insert=s.index('\n#[test]\nfn actual_authored_pcm_bits')
helper='''
/// The returned fields are obtained from the actual legacy and admitted probe
/// graphs, not inferred from the node under test or globally ignored by name.
fn independent_retained_receipts() -> Vec<(&'static str, Value, Value)> {
    let plan = baseline::frozen("hidden_resumed_retained_domain_vs_live_root", "group");
    let owner = baseline::observed(&plan, "group", 1, false);
    let at = AudioSample(1);
    let legacy_input = plan.audio_owner_input(&owner, at, Default::default()).unwrap();
    let legacy_probe = legacy_input.retained_probe_at(at, Default::default()).unwrap();
    let legacy = legacy_probe.input().unwrap();
    let legacy_bound = serde_json::to_value(legacy.bound()).unwrap();

    let cancelled = AtomicBool::new(false);
    let work = RefCell::new(ReadWork::default());
    let control = fixture::control(&cancelled, &work);
    let mut renderer = StageAudio::new(Arc::clone(&plan));
    let mut admission = sound_context_admission::Admission::new(&mut renderer, control);
    let input = plan.audio_owner_input_admitted(
        &owner, at, control.query_limits().unwrap(), &mut admission,
    ).unwrap();
    let input_canonical = input.query_canonical_units()
        .checked_add(input.capture_canonical_units()).unwrap();
    let input_additional = input.query_additional_units()
        .checked_add(input.capture_additional_units()).unwrap();
    assert_eq!(input_canonical, legacy_input.work());
    assert_eq!(input.work(), input_canonical.checked_add(input_additional).unwrap());
    let probe = input.input().unwrap().retained_probe_at_admitted(
        at, control.query_limits().unwrap(), &mut admission,
    ).unwrap();
    assert_eq!(probe.canonical_units(), legacy_probe.work());
    assert_eq!(probe.work(), probe.canonical_units().checked_add(probe.additional_units()).unwrap());
    assert_eq!(work.borrow().plan_work, input.work().checked_add(probe.work()).unwrap());
    let metered = probe.input().unwrap();
    let metered_bound = serde_json::to_value(metered.bound()).unwrap();
    let receipts = vec![
        ("/result/context/bound/resolved/lattice/work",
            legacy_bound["resolved"]["lattice"]["work"].clone(),
            metered_bound["resolved"]["lattice"]["work"].clone()),
        ("/result/context/bound/resolved/work",
            legacy_bound["resolved"]["work"].clone(),
            metered_bound["resolved"]["work"].clone()),
        ("/result/context/retained_lookup_work", json!(legacy.work()), json!(metered.work())),
    ];
    let paid = work.borrow().plan_work;
    drop(probe);
    drop(input);
    assert_eq!(work.borrow().sound_context_frames, 0);
    assert_eq!(work.borrow().plan_work, paid);
    receipts
}
'''
s=s[:insert]+helper+s[insert:]
p.write_text(s)
