from pathlib import Path
body=r'''
/// Reuse the complete original Input serializer without creating another shape.
pub(in crate::plan) fn input_snapshot(value: &AudioOwnerInput<'_>) -> Value {
    super::input(value)
}

/// Reuse the original typed Plan error serializer.
pub(in crate::plan) fn error_snapshot(value: &PlanError) -> Value {
    super::error_json(value)
}

/// Rebuild the same actual checked parent and base observation, then apply only
/// the isolated mutation recorded by the OLD direct-input oracle. The visitor
/// cannot retain the locally borrowed owner or foreign Plan.
pub(in crate::plan) fn visit_cases(
    snapshot: &Value,
    mut visit: impl FnMut(WideParent<'_, '_>, &AudioOwnerClock<'_>, &Value),
) {
    let wide: Value = serde_json::from_str(include_str!(
        "../../../tests/fixtures/wide-gain-owner-baseline-v1/snapshot.json"
    )).unwrap();
    assert_eq!(snapshot["documents"],wide["documents"],"same immutable fixture documents");
    let mut visited = 0;
    wide_baseline::visit_cases(&wide, |parent, parent_case| {
        let parent_name = parent_case["name"].as_str().unwrap();
        let window = &parent_case["request"]["window"];
        let samples = AudioSample(window["start"].as_i64().unwrap())
            ..AudioSample(window["end"].as_i64().unwrap());
        let observed = setup_query(parent,samples);
        let full_setup = wide_baseline::query_snapshot(&observed,parent.plan());
        assert_eq!(full_setup,parent_case["query"]);
        for case in snapshot["cases"].as_array().expect("frozen direct cases").iter()
            .filter(|case|case["setup"]["parent_case"]==parent_name)
        {
            let setup = &case["setup"];
            assert_eq!(setup["observed_query"],full_setup,"complete setup query: {}",case["name"]);
            assert_eq!(setup["parent_identity"],parent_case["seed_identity"]);
            assert_eq!(setup["fixture"],parent_case["fixture"]);
            let span_index = usize::try_from(setup["selected_span_index"].as_u64().unwrap()).unwrap();
            let member = usize::try_from(setup["selected_member_index"].as_u64().unwrap()).unwrap();
            let span = &observed.spans()[span_index];
            let selected = &span.owners()[member];
            let kind = case["case_kind"].as_str().unwrap();
            let mut candidate = selected.clone();
            match kind {
                "actual_checked_member"|"exact"|"one_short" => {}
                "valid_owner_at_ownerless_sample" => {
                    assert_eq!(setup["owner_observed_at"],json!(span.samples().start.0));
                    let target_index = usize::try_from(
                        setup["ownerless_target_span_index"].as_u64().unwrap()
                    ).unwrap();
                    let target = &observed.spans()[target_index];
                    assert!(target.owners().is_empty());
                    assert_eq!(case["request"]["at"],json!(target.samples().start.0));
                }
                "absent_instance" => {
                    candidate.instance.node = NodeId::new("not-a-current-direct-input-owner").unwrap();
                }
                "sampling_phase_mismatch" => {
                    candidate.sampling = crate::AudioSampleMap::new(
                        selected.sampling.anchor(),
                        selected.sampling.local_at_anchor().checked_add(ExactRatio::integer(1)).unwrap(),
                        selected.sampling.local_frames_per_sample(),
                    ).unwrap();
                }
                "sampling_slope_mismatch_same_local_at_observation" => {
                    let at = AudioSample(case["request"]["at"].as_i64().unwrap());
                    candidate.sampling = crate::AudioSampleMap::new(
                        at,selected.sampling.local_at(at).unwrap(),
                        selected.sampling.local_frames_per_sample().checked_mul(ExactRatio::integer(2)).unwrap(),
                    ).unwrap();
                }
                "hidden_play_mismatch" => {
                    candidate.play = Some(selected.play.map_or(0,|play|play.checked_add(1).unwrap()));
                }
                "foreign_plan_same_document"|"invalid_limits_precede_foreign_owner" => {
                    let fixture = snapshot["documents"].as_array().unwrap().iter()
                        .find(|fixture|fixture["fixture"]==parent_case["fixture"]).unwrap();
                    let document = ProjectDocument::from_json(&fixture["document"].to_string()).unwrap();
                    let foreign = RenderPlan::compile(&document).unwrap();
                    candidate.plan = &foreign;
                    assert_eq!(clock(&candidate,candidate.plan,|sample|sample.0),
                        case["request"]["selected_owner"]);
                    assert_eq!(json!(candidate.belongs_to(parent.plan())),
                        case["request"]["selected_owner_belongs_to_request_plan"]);
                    visit(parent,&candidate,case);
                    visited += 1;
                    continue;
                }
                "checked_sample_plus_one_overflow" => {}
                other => panic!("unknown frozen direct-input case kind: {other}"),
            }
            assert_eq!(clock(&candidate,candidate.plan,|sample|sample.0),
                case["request"]["selected_owner"],"exact selected owner: {}",case["name"]);
            assert_eq!(json!(candidate.belongs_to(parent.plan())),
                case["request"]["selected_owner_belongs_to_request_plan"]);
            visit(parent,&candidate,case);
            visited += 1;
        }
    });
    assert_eq!(visited,snapshot["cases"].as_array().unwrap().len());
    assert_eq!(visited,258);
}

#[test]
fn legacy_direct_owner_input_matches_immutable_full_matrix() {
    let mut frozen: Value = serde_json::from_str(include_str!(
        "../../../tests/fixtures/direct-owner-input-baseline-v1/snapshot.json"
    )).unwrap();
    let metadata = frozen.as_object_mut().unwrap();
    metadata.remove("variant");
    metadata.remove("runtime_source_manifest_sha256");
    assert_eq!(matrix(),frozen);
}
'''
for root in ['/Users/michael/Code/deadpan','/tmp/deadpan-query-groundwork-2026-10-26/scoped']:
 src=Path(root)/'crates/deadpan-plan/src/audio_owners'
 p=src/'legacy_snapshot_v1/direct_input_baseline.rs';s=p.read_text()
 assert 'pub(in crate::plan) fn visit_cases' not in s
 p.write_text(s+body)
 p=src/'legacy_snapshot_v1.rs';s=p.read_text()
 old='#[path = "legacy_snapshot_v1/direct_input_baseline.rs"]\nmod direct_input_baseline;'
 assert s.count(old)==1;p.write_text(s.replace(old,old.replace('mod direct_input_baseline;','pub(in crate::plan) mod direct_input_baseline;')))
