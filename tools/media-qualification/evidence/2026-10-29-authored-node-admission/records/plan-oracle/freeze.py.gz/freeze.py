from pathlib import Path
import json,hashlib,difflib
d=Path(__file__).resolve().parent;files=json.loads((d/'task-files.json').read_text());pins={}
for label,root in [('main',Path('/Users/michael/Code/deadpan')),('scoped',Path('/tmp/deadpan-query-groundwork-2026-10-26/scoped'))]:
 patch=[]
 for f in files:
  data=(root/f).read_bytes();dest=d/'candidate'/label/f;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(data)
  pins[label+'/'+f]=hashlib.sha256(data).hexdigest()
  before=d/'before'/label/f
  patch.extend(difflib.unified_diff(before.read_text().splitlines(True) if before.exists() else [],data.decode().splitlines(True),fromfile='a/'+f,tofile='b/'+f))
 (d/(label+'.patch')).write_text(''.join(patch))
(d/'candidate-pins.json').write_text(json.dumps(pins,indent=2)+'\n')
manifest=hashlib.sha256((d/'candidate-pins.json').read_bytes()).hexdigest()
(d/'FREEZE.json').write_text(json.dumps({
 'status':'frozen-old-direct-input-producer','candidate_pins_sha256':manifest,'task_files':files,
 'test_filter':'capture_old_direct_owner_input_snapshot_v1',
 'env':['DEADPAN_DIRECT_OWNER_OUTPUT','DEADPAN_DIRECT_OWNER_VARIANT','DEADPAN_DIRECT_OWNER_SOURCE_SHA256'],
 'validation':'rustfmt parse/format only; parent owns all Cargo/runtime',
 'expected_fixture':'none until parent captures OLD executable output',
 'serializer_changes':'none: unchanged super::input and capture_baseline::observe_case/capture_ref'
},indent=2)+'\n')
print(manifest);print(json.dumps(pins,indent=2))
