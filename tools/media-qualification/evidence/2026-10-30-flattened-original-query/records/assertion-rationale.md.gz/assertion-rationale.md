# Existing Audio assertions for flattened admission

Scratch-only adaptation of the current integrated test sources in exactly:
- original_request/tests.rs
- original_request/policy_reuse_tests.rs
- shared_eq/prepared_input_tests.rs

Both variants are byte-identical. Parent owns actual integration, Cargo, native
execution and Git. No production, new host-admission tests, old oracle or fixture
is changed here.

## Content and work are separately complete

same_queries accepts two RootReadQueriesRef values, resolving the private
PreparedQueries-vs-RootReadQueries mismatch at policy_reuse_tests' prepared
reference comparison. It compares every flattened AudioQuery content field
(project/revision, sample range, all spans, lookup) and all existing processing,
policy and fade content/work assertions. Flattened work is no longer compared
as if ordinary and admitted construction had identical totals.

A test-only helper in original_request/tests matches the real private
Flattened::Admitted carrier. It asserts was_forwarded, total equals checked
canonical+additional, and query.work equals that carrier's total. The ordinary
oracle comparisons separately assert canonical equals ordinary AudioQuery.work,
additional is positive for this actual fixture, and the ledger's difference
is exactly that additional work. Admitted-vs-admitted comparisons assert equal
canonical/additional receipts; no private production helper is needed.

The existing content/PCM/provider/source-check comparisons remain. There is no
global legacy override and no new synthetic reservation or invented work refund.

## Deliberate budget adaptation

The root/simple Domain preparation boundary is measured using the real admitted
factory. Its exact boundary must finish; one short must fail in the final fade
query, keep the exact earlier flattened+processing+policy bills, and release all
metadata leases. The fixture explicitly asserts nonzero final fade work. The
ordinary oracle keeps a separate exact/one-short boundary and the same final
error string. Dropping the successful reference cannot refund work.

The exposed-Stage fallback first measures its ordinary oracle and real admitted
preparation, asserts exact canonical/additional difference and complete content,
then tests both policy-reuse arms at the admitted exact/one-short boundary.
Completed/forwarded earlier bills survive the failed final query.

The first-processing failure witness measures its actual admitted flattened
cost and then gives exactly that cost plus first processing work minus one.
Both actual old/new policy arms must fail before recording policy, retain the
complete forwarded flattened bill and release the query lease. The first
processing/policy behavior and error comparison are preserved.

The eligible Domain boundary already measured real production preparation.
It now checks the carrier's total decomposition, compares prepared reference
views correctly, and asserts release on all success/failure paths. The old
extra policy-walk arm still must exceed that measured new boundary.

## Issuer work and release

The prepared Source read receives exactly one unit for its mandatory consuming
issuer comparison. It reaches the cap and reads actual PCM without requerying.
The wrapper boundary includes measured preparation plus that one unit. A fresh
prepared request with zero remaining units must reject before source I/O, retain
the spent-work cap and release metadata.

Cancellation/deadline reject before spend. Invalid depth and source-unavailable
reject after the live issuer comparison and therefore add exactly one unit.
Their existing error and source-I/O assertions remain.

The actual shared prepared-hit test records positive live query metadata before
consumption, checks the same metadata amount on repeated preparation and zero
after each consumption. Its difference from the plain cached hit is exactly two
units: existing sealed-request validation and the actual issuer comparison.

## Assumptions and verification limit

The existing fixture's final fade query has positive work; this is asserted.
Stage fallback remains ineligible for terminal content-only reuse; this is
asserted using the actual existing policy trace. Other query constructors remain
unadmitted and keep completed-query billing, so a failed final processing/policy/
fade query adds no completed-query bill; earlier real flat callbacks stay billed.

Only targeted rustfmt --edition 2024 --config skip_children=true was run.
No compilation or behavioral pass is claimed. Parent must compile and run the
two existing modules plus shared prepared-input tests and the new admission
tests supplied by the other owner.

assertion-before holds exact original copies. assertion-before-pins.json and
assertion-candidate-pins.json pin sources. assertion-{main,scoped}.patch are exact
unified diffs. Actual files were rechecked against before copies at freeze.
