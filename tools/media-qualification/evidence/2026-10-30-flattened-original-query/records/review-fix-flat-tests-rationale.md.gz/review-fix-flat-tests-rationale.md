# Flattened admission test strengthening

Scratch-only change to the Plan admission test file; the repository source was not edited.

The added test derives Arc<str> allocation layouts from std::alloc::Layout and independently walks identity-bearing keys in the frozen OLD query for the small Source/Repeat Root case. In that fixture, the catalog-sound asset appears as two independently owned source edges, and query-storage is the project header; both strings have the same length and therefore the same Arc allocation layout. The frozen query contains exactly three identity owner edges of that layout. The test compares this expected count to the accepted reserve-layout events, so removing either source asset reservation or the project header reservation cannot be hidden by unrelated aggregate retained-charge slack.

It uses the existing layout observer and frozen logical fixture, adds no allocator/RSS claim or new production helper, and leaves all existing tests intact. The candidate was formatted with rustfmt edition 2024. No Cargo, typecheck, test, native, or Git command was run; parent owns builds.
