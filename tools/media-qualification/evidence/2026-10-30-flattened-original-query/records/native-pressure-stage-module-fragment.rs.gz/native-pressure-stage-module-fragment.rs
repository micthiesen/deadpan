#[path = "stages/flattened_metadata.rs"]
mod flattened_metadata;
