from pathlib import Path
import json, subprocess, sys

s = Path(__file__).resolve().parent
build, variant, prefix = sys.argv[1:]
rows = json.loads((s / (build + '-pins.json')).read_text())
results = []
for row in rows:
    if row['name'] == 'deadpan_plan':
        continue
    label = prefix + '-' + row['name'].replace('_', '-')
    code = subprocess.run(['python', str(s / 'run_logic_target.py'), build,
                           variant, 'plan', row['name'], label]).returncode
    results.append({'target': row['name'], 'label': label, 'exit_code': code})
(s / (prefix + '-summary.json')).write_text(json.dumps(results, indent=2) + '\n')
raise SystemExit(any(row['exit_code'] for row in results))
