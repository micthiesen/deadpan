from pathlib import Path
import gzip
import hashlib
import json

s = Path(__file__).resolve().parent
repo = Path('/Users/michael/Code/deadpan')
dest = repo / 'tools/media-qualification/evidence/2026-10-30-flattened-original-query'
assert not (dest / 'inventory.json').exists()
audit = json.loads((s / 'final-audit.json').read_text())
assert audit['all_terminal'] and audit['split']['passed'] == 3 and audit['split']['failed'] == 4
prior = repo / 'tools/media-qualification/evidence/2026-10-29-cached-original-prediction/inventory.json'
prior_sha = '33c29d3f1c7eb544a49a17afb987bf68624810bd4fb1ac0cf97490ba3b5d5e3a'
assert hashlib.sha256(prior.read_bytes()).hexdigest() == prior_sha
rows = []
allowed = {'.rs', '.json', '.py', '.md', '.patch', '.stdout', '.stderr', '.txt', '.sha256', '.toml'}
for p in sorted(s.rglob('*')):
    if not p.is_file() or p.suffix not in allowed:
        continue
    rel = p.relative_to(s)
    if rel.name in {'qualification-draft.md', 'published-evidence.json'}:
        continue
    data = p.read_bytes()
    empty_new_file_baseline = not data and rel.parts[0] == 'published-before'
    if p.suffix == '.json' and not empty_new_file_baseline:
        obj = json.loads(data)
        if isinstance(obj, dict) and 'command' in obj and 'started_at' in obj:
            assert 'exit_code' in obj and obj['sources_unchanged'] and obj['binaries_unchanged'], str(p)
    target = (dest / 'records' / rel).with_name(rel.name + '.gz')
    target.parent.mkdir(parents=True, exist_ok=True)
    packed = gzip.compress(data, mtime=0)
    target.write_bytes(packed)
    rows.append({
        'path': str(target.relative_to(dest)), 'bytes': len(packed),
        'sha256': hashlib.sha256(packed).hexdigest(), 'expanded_bytes': len(data),
        'expanded_sha256': hashlib.sha256(data).hexdigest(),
    })
manifest = {
    'schema_version': 1,
    'base_revision': (s / 'base-revision.txt').read_text().strip(),
    'scope': 'Actual flattened Root/Domain Original query construction admission, sealed request-local lease through policy prediction and numeric read, independent OLD complete query witnesses, exact work and Layout pressure tests. Processing/policy/fade construction and full recursive admission remain open. General sound-bearing Split stays disabled; no requirement or gate closes.',
    'prior_prediction_inventory': {
        'path': '../2026-10-29-cached-original-prediction/inventory.json', 'sha256': prior_sha,
    },
    'exclusions': 'Executables, nontext batch blobs and entire filesystem copies excluded. Exact assigned before/candidate/shipping sources, patch, source/executable/stream hashes, failed and passing receipts, actual observations and independent review reports retained. Main diagnostic overlay preserves only Rust sources differing from the published candidate; it is research context, not shipping feature code. All final linted ordinary and Split runs use final source. Core is unchanged by this checkpoint.',
    'files': rows,
}
p = dest / 'inventory.json'
assert {str(x.relative_to(dest)) for x in dest.rglob('*') if x.is_file()} == {row['path'] for row in rows}
p.write_text(json.dumps(manifest, indent=2) + '\n')
for row in rows:
    packed = (dest / row['path']).read_bytes()
    plain = gzip.decompress(packed)
    assert len(packed) == row['bytes'] and hashlib.sha256(packed).hexdigest() == row['sha256']
    assert len(plain) == row['expanded_bytes'] and hashlib.sha256(plain).hexdigest() == row['expanded_sha256']
result = {
    'files': len(rows), 'stored_bytes': sum(row['bytes'] for row in rows),
    'expanded_bytes': sum(row['expanded_bytes'] for row in rows),
    'inventory_sha256': hashlib.sha256(p.read_bytes()).hexdigest(),
}
(s / 'published-evidence.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result))
