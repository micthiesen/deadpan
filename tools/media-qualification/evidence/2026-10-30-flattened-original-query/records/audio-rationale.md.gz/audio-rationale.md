# Scratch Audio integration: admitted flattened query

Candidate based on the parent-stated pushed revision dd13fdc4c. All edits are under
audio-candidate/{main,scoped}. No actual source, Cargo, native executable, Git,
old oracle, fixture, or parent guard-manifest mutation was performed.

## Ownership and API

PreparedOriginalRequest now has lifetimes <'context,'plan,'work>. Its private
PreparedQueries owns a private Flattened carrier plus the existing processing,
policy and fade queries. RootReadQueries and RootReadQueriesRef stay unchanged.
queries() returns only a borrowed RootReadQueriesRef over the actual carrier.

Production Flattened::Admitted owns
AdmittedAudioQuery<sound_context_admission::Issuer<'work>,
sound_context_admission::Lease<'work>> and separately saves the exact issuer
used by construction. The carrier API has no detach or mutable query added.
The only additional variant is cfg(test) Legacy(AudioQuery).

prepare_original_root/domain require &mut StageAudio while their actual
sound_context_admission::Admission is alive. Their returned lifetime refers only
to ReadWork, so that adapter/controller borrow ends before processing, policy,
fade construction, later prediction, or the raw read. Each production flattened
constructor uses audio_admitted at the actual allocation sites. No allocation
measurement, late reservation, inferred charge, or second work bill is added.
The constructor forwards canonical and additional work through Admission::spend;
its work() total is deliberately not billed again. The unadmitted
prepare_domain_policy flow, first processing/policy walk and terminal witness
remain byte-for-byte unchanged.

The Plan carrier owns the actual value before its charge; failure in subsequent
processing/policy/fade construction drops the local carrier. On a consuming read,
request.validate_issuer runs before borrowing its flattened query or calling
source I/O. The completed ReadBlock is held locally, the prepared request is
explicitly dropped, and only then is the ReadBlock returned. A shared prepared
cache hit also drops its unused request on return. No PCM pin/drop boundary,
cache eviction policy, warm-probe branch, identity, or Graph accounting changes.

## Runtime issuer identity and work

Both policy_prediction::validate_original and read_prepared_original reject a
foreign WorkControl ledger with PlanError::AudioMetadataIssuerMismatch. Each
actual admitted issuer comparison has a separate spend_plan_work(1). The old
exact-origin/window validation's charge is unchanged. Thus a prepared cache
hit adds two units over the plain cache hit: existing sealed-request validation
and the new issuer comparison. An admitted miss performs issuer validation at
both the shared prepared boundary and the consuming read boundary.

The cfg(test) Legacy variant has no admitted lease or issuer comparison and
retains the original single completed-query work charge. Private
with_legacy_flattened_queries uses scoped TLS and RAII restoration, including
nested scopes and unwind. cached_prediction_trace::with_legacy wraps this helper
while keeping its existing scoped legacy prediction flag. The independent
query_oracle always enters only the flattened compatibility scope, even while
the surrounding measured matrix uses the current production path. Its old
ordinary query fields/work therefore stay independent of admitted construction.
No test suite is globally forced into legacy mode.

## Exact changed and unchanged files

Seven paths change per variant:
- original_request.rs
- shared_eq/original_inputs.rs, only the prepared request's third lifetime
- shared_eq/policy_prediction.rs, typed lifetime and issuer validation
- shared_eq/cached_prediction_trace.rs, nested compatibility scope
- shared_eq/cached_prediction_baseline.rs, mutable creator borrow and ordinary
  flattened compatibility scope, no output-field or fixture changes
- original_request/tests.rs, four necessary mutable-reader bindings only
- original_request/policy_reuse_tests.rs, four necessary mutable-reader bindings only

stages.rs and shared_eq/prepared_input_tests.rs are preserved exact in the
candidate. Actual callers in policy_prediction_tests.rs and cached_policy_tests.rs
already have mutable renderers and need no edits. Main/Scope family differences
are retained; their patches differ only in baseline-helper line numbers.

## Assertions requiring parent qualification

Existing test expectations were deliberately not weakened or silently changed:
- original_request/tests.rs: previous ordinary query work equality and exact
  ordinary preparation budgets now exclude real admitted construction work.
- prepared_source_read_does_not_requery_with_no_plan_work_remaining must provide
  the actual newly billed issuer comparison rather than assert zero available
  plan work while that comparison is mandatory.
- original_request/policy_reuse_tests.rs: ordinary flattened partial-work and
  exact old-budget expectations require measured admitted flattened costs for
  production-mode tests; terminal processing/policy behavior itself is unchanged.
- shared_eq/prepared_input_tests.rs: prepared-hit +1 must account separately for
  the new issuer comparison (+2 total relative to plain cache hit).

Parent owns intentional behavioral qualification, new metered allocation/issuer
proofs, immutable-old comparisons, Cargo/native checks and integration. The eight
frozen legacy cached prediction cases use the explicit compatibility wrapper;
no OLD oracle bytes were regenerated or written.

## Freeze evidence

audio-before/{main,scoped} contains 18 exact original source copies.
audio-before-pins.json pins all originals.
audio-main.patch and audio-scoped.patch are exact unified diffs.
audio-candidate-pins.json includes before/candidate SHA-256, bytes and changed
status for all copies. Actual source hashes were rechecked against every before
copy after editing and all 18 matched.

Targeted rustfmt --edition 2024 --config skip_children=true ran on changed
candidate Rust files only. Entire diffs were inspected. Rustfmt parsing is the
only executable source check claimed; no typecheck or behavioral result is claimed.
