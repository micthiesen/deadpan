# Bound read existing budget witness

Only bound_reads_share_cancellation_work_and_complete_cached_dependencies is
changed. Its two first-query-only probes previously allowed the ordinary
flattened query's canonical work. With allocation-site forwarding that is less
than the actual first flattened query's full work, so the call could fail during
the first query rather than at the intended second-query boundary.

Each Root and exact Domain probe now independently executes the actual
audio_admitted constructor through sound_context_admission::Admission with an
ample fresh request ledger. It checks was_forwarded, ordinary work equals
canonical_units, additional_units is positive, actual ledger plan_work equals
work(), and total=canonical+additional. It drops the carrier and checks metadata
release before setting up the existing first-only probe.

That probe receives exactly the actual complete first-query work. Its next
processing query still must reject with StageAudioError::Limit("plan work per
read"), with an explicit debug print of any actual different error. The work
counter must reach the cap without a refund, query leases must release, and
provider.calls must remain unchanged. Cancellation, already exhausted work,
complete cached dependencies, prepared-stage refusal and changed-source checks
remain untouched.

No production, golden, limit, global legacy override, arbitrary error acceptance
or synthetic residency is changed. No actual repository files were written.

Main/Scope candidates are byte-identical at:
regression-candidate/{main,scoped}/crates/deadpan-audio/src/bound_reads.rs
SHA256 bfb7c5be0f5f80dfe37785286b0a3f4ecb25de49c99ede22adc7631348ebf2fc
Exact before copies and bound-only patches are saved alongside the task scratch.

Targeted rustfmt parsed/formatted the changed candidate files. No Cargo/native/
Git execution or behavioral pass is claimed. Parent owns guarded execution.
Authored tile tests are still unchanged pending a legitimate actual-receipt seam;
see regression-authored-trace-proposal.md.
