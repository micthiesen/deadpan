#[path = "flattened_original_admission_tests.rs"]
mod flattened_original_admission;
