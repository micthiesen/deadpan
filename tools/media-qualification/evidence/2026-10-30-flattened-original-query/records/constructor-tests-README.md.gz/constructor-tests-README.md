# Flattened constructor unit-test candidate

Scratch-only, 2026-10-29. The constructor worker ran Rustfmt parsing only, with no Cargo, native execution, Git, actual-repository writes, or changes to the seven frozen production candidate files.

## Integration

For each variant, apply `constructor-tests-main.patch` or `constructor-tests-scoped.patch` after its production constructor patch and the parent's frozen producer/fixture work. Full files are under `constructor-tests/{main,scoped}/crates/deadpan-plan/src/audio_owners/`.

The only existing-file change is appending this declaration to `wide_gain_query_admission_tests.rs`:

```rust
#[path = "flattened_query_admission_tests.rs"]
mod flattened;
```

That existing module is already test-only through its declaration in audio_owners.rs. Its child can reuse the existing private `Policy<M>`, `PolicyState`, `Lease`, checked `Parent`, and wide fixture helper imports without exposing them or duplicating accounting. The new forwarding Layout observer records only requested size/alignment and existing policy live charge before/after; all admission and lease accounting still runs through the original Policy implementation.

`constructor-tests-pins.json` pins the two candidate existing files, two new test files, and original existing-file versions. Each main/scoped test file is identical.

Required parent-owned frozen fixture:

`crates/deadpan-plan/tests/fixtures/flattened-query-baseline-v1/snapshot.json`

Expected contents are exactly `flat-query-old-body.json`, SHA256 `3e81167eee65ef7eae5d6cebf153861f90b77fcd2639d9088830e1c865ac63d4`. Tests compare `flat::matrix()` against that entire frozen body without removing or normalizing any fields. Each checked visitor descriptor is then compared field-by-field before the associated observations are used.

## Tests and filters

Use the parent-owned Cargo target/locking discipline. New module filter:

`audio_owners::wide_gain_query_admission_tests::flattened::`

Or the shared name prefix `flattened_` for all eleven tests:

1. `flattened_ordinary_and_unmetered_match_all_57_frozen_observations`
2. `flattened_metered_full_crop_and_empty_preserve_every_old_field_and_canonical_work`
3. `flattened_actual_requested_layout_peak_fits_exactly_and_one_byte_short_refuses`
4. `flattened_exact_and_one_short_total_work_and_legacy_error_priority`
5. `flattened_every_reservation_and_work_refusal_releases_partial_values_without_refunds`
6. `flattened_issuer_rotations_release_old_and_new_ledgers_at_every_callback`
7. `flattened_empty_query_admits_both_header_identities_before_ownership`
8. `flattened_outer_growth_retains_old_buffer_prior_spans_and_current_span`
9. `flattened_retained_storage_observer_is_billed_separately_including_failed_inspection`
10. `flattened_live_carrier_is_visible_to_later_required_query_reservations`
11. `flattened_narrow_extraction_rejects_actual_preserve_and_core_bound_walks`

Metered full/crop/empty cover eighteen actual observations across all six parents. Callback failure/rotation sweeps cover every actual callback position for each of these observations. Cancellation thresholds are actual successful prefixes observed through work refusal, avoiding a guessed maximum-work debit. Local exact and one-short work limits are based on the actual new total, including the empty-query header work; canonical work is separately compared with literal OLD data. A zero work limit retains its existing validation error.

The five-span repeat case asserts the actual output capacity eight, observes required outer-buffer layout requests at capacities one/two/four/eight, and checks that pre-request charge includes the old buffer plus retained heap for prior/current spans. Exact/one-byte-short cap checks use fresh ledgers. These are requested-Layout charge observations, not global heap allocator/RSS measurements.

The separate retained-storage cross-check bills successful observer work before taking byte results, including a deliberately short failed observation. It establishes no constructor admission and makes no claim about discarded temporary allocations.

The narrow extractor test uses actual old wide fixtures with alternate stopping flags and the existing nested-Preserve fixture. It requires both real Stage and metered Core-backed rejection and zero live charge afterwards; it does not introduce a test-only escape API or fabricate a GuardedBound payload.

## Verification status and limits

Rustfmt parsed the new test source. Parent must compile/run it; no test success is claimed. The exact Core-stop coverage assertion is intentionally mandatory rather than silently skipped. If existing wide fixtures fail to exercise a Core-backed stop, identify the checked existing binding fixture needed before replacing the assertion.

No new synthetic fixture constructors were added. Legal fixed limits and the existing finite fixtures cannot reach usize layout overflow in outer span growth; this candidate does not manufacture an overflow path and does not claim to test it. Existing shared layout/grow checks remain in production. Host request lifetime, numerical cache paths, and aggregate required PCM admission belong to the independent host integration test work.
