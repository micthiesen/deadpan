# Authored matrix flattened-work receipts

Scratch-only candidates, Main and Scope byte-identical, with no Cargo, native,
Git, actual repository writes, golden writes or oracle regeneration.

## Scope

The approved expansion changes only original_request.rs cfg(test) insertions,
new original_request/flattened_work_trace.rs,
authored_eq/legacy_tile_baseline.rs and authored_eq/tile_admission_tests.rs.
The earlier separately frozen bound_reads test adaptation is also present in
regression-candidate and the complete regression patches. Parent has already
integrated that exact bound candidate into both actual trees; it is not a new
source divergence to overwrite.

No original_request/tests.rs or shared_eq/cached_prediction_baseline.rs writes
were made, preserving the other owner's host-test/module work.

## Receipts

The new TLS trace holds only fixed scalar structs in Cell, with no Vec, strings,
logging, allocation, ReadWork mutation, reservation or work refund. It records
plan and cache lanes independently.

A scoped guard starts immediately before the actual admitted constructor. On
success it receives canonical/additional/total/forwarded fields from the actual
immutable AdmittedAudioQuery and checks the successfully accepted ledger delta
against their total. On every early constructor error Drop records the real
accepted partial work. The guard ends before processing/policy/fade construction.
It records constructor/completion/failure counts, accepted work, canonical units,
additional units and partial work, plus active/max depth, nested, invalid and
overflow flags. Crossover or unreconciled callback work fails the receipt rather
than being assigned an invented fee.

The issuer hook runs immediately after the real spend_plan_work(1) succeeds.
It records the corresponding lane and one successfully billed comparison,
including one that then discovers a foreign issuer. No rejected spend is counted.

All four insertions in original_request.rs are cfg(test). Removing those exact
insertions restores the before source byte-for-byte, independently checked in
regression-production-cfg-proof.json. The cfg(not(test)) path is unchanged.

## Matrix qualification

The three admitted current observations remain:
- old Domain-policy/direct span reference
- reused Domain-policy/direct span reference
- reused Domain-policy/certified span reference

Their original comparisons remain and now also require literal equality of the
new flat receipts where those optimizations should leave flat construction alone.

A fourth observation explicitly nests with_legacy_flattened_queries around old
Domain-policy/direct span construction. Only this fourth observation supplies the
literal flattened-work reference to the unchanged GOLDEN comparison. The existing
index/layout normalization and all immutable old work literals remain unchanged.
The ignored OLD producer also explicitly enters ordinary flattened compatibility
mode so its label cannot silently acquire admitted work.

The current old-policy/direct observation is independently compared to that
ordinary-flat reference. Every constructor receipt reconciles accepted work as
canonical+additional+partial. Only additional units plus real issuer units are
used to explain current work over the ordinary reference. Both plan/cache lanes
are checked. Imposed plan-work probes must have identical before/after flat
receipts; their injected cap replaces the cumulative plan total, so only that
explicit imposed plan value avoids a cumulative fee addition.

The bounded matrix requires partial constructor work zero. A nonzero observed
partial refuses qualification with the full trace; it is not automatically
called an added fee, because the ordinary path might have completed different
canonical work before refusing. The trace still preserves every real accepted
partial charge for such a follow-up. Completed queries, additional units and
issuer work must all be positive somewhere in the actual corpus. All scopes must
be unnested, inactive at snapshots and free of overflow/invalid flags.

After these witnessed work checks, only the two proven work-counter differences
and the explicit trace field are normalized. Every other complete counter,
PCM bit, suppression, dependency, provider count, cache/depth/error result,
operation and case remains literal.

## Evidence and remaining checks

regression-before contains exact before copies. regression-candidate-pins.json
pins before/candidate files, including the new absent-before module.
regression-{main,scoped}.patch are complete exact diffs and byte-identical.
regression-handoff-pins.json pins the reports and diffs.
regression-production-cfg-proof.json proves unchanged non-test production text.

All newly edited candidate files were parsed/formatted with targeted rustfmt
--edition 2024 --config skip_children=true. Full diffs were inspected.
No typecheck or behavioral pass is claimed. Parent owns compilation and native
execution of the bound witness and both existing authored matrix tests, including
checking whether this corpus ever reaches nonzero partial flat work.
