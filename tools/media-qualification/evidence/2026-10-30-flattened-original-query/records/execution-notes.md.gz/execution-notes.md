# Execution notes

The guarded receipts retain the original compiler, library, Plan-test, native Stage and lint failures. The successful replacement runs use unique labels and pinned executables. `pressure-scoped-gain` selected zero tests because an incomplete name was combined with `--exact`; it is not coverage. `pressure-scoped-gain-exact` used the full `gain::` name and ran one test.

The following are transcribed tool/agent outcomes, not standalone captured streams:

- The first host-file integration script found a nonunique six-line tail and stopped before applying any edits. It reread the files and selected longer unique anchors.
- Registering new host files initially used the wrong Main guard-list filename. The list is `source-files.json`; both full lists were updated before the next guarded build.
- The first native helper declaration left two module declarations adjacent. `cargo fmt --all --check` wanted them sorted. Adding the conventional blank separator restored the surrounding module style; subsequent formatting and project checks pass.
- A Luna worker attempted the identity fixture correction but returned no usable patch. Its scratch candidate stayed unchanged. The parent reused the existing fixture through an asset parameter and checked the exact two-edge Layout-histogram delta; a separate static review and the actual Plan test then passed.
- The first staging patch lacked Git new-file mode headers. Its dry run failed with ten `dev/null: does not exist in index` errors; the orchestration also attempted the apply, which Git rejected atomically. The index remained empty. The invalid patch is retained separately; the corrected patch passed its dry run and all 34 resulting index blobs match the isolated candidate. Later orchestration stops on a failed dry run.

No failed or incomplete capture was substituted for an expected result. The fourteen immutable oracle bodies were never regenerated. Main's unrelated family/Split inputs are checked against the initial authority map.

The first evidence archival attempt stopped while parsing the intentionally empty
published-before JSON marker for a newly added fixture. It wrote no inventory.
The retry preserves that zero-byte before marker without interpreting it as a
JSON document, checks the complete destination file set, and re-reads every
compressed and expanded hash before publishing the inventory.
