# Flattened query admission test review

1. **Severity: Minor** — audio_owners/flattened_query_admission_tests.rs:214-238, 619-627 — The metered heap assertions are self-derived from the callback trace: peak is whatever the implementation reserved, the exact-cap replay uses that same value, and retained measurement only requires measured_bytes <= live_charge. A regression that omits a reserve for one retained allocation can still pass if the remaining conservative charges cover the measured total; exact-cap and one-byte-short then validate only the reduced trace. Add an independent expected admission receipt or per-category required-byte assertions so a removed identity/array/buffer reservation fails even when aggregate slack masks it.

The OLD logical witness is strong: the serializer destructures all AudioQuery/AudioSpan fields, 57 frozen observations are compared, and ordinary errors/work are not reconstructed from the new metered result. Refusal tests cover every observed callback/work index, issuer rotations, empty headers, and outer-vector overlap. Stage and metered-Core stop shapes are exercised separately.

Limits: static review only. I did not run tests or inspect production implementation beyond what these test cases exercise. The identified issue is test coverage, not a demonstrated production defect.
