# Next unit: actual Root/Domain processing-query admission

Read-only source research, 2026-10-30. No implementation, actual-repository writes, Cargo, native execution, or Git. Relevant Main and Scope files are currently byte-identical; exact SHA-256/size evidence is in processing-query-admission-next-pins.json.

## Recommendation

The next product unit is **admitted AudioProcessingQuery construction for the actual RenderPlan::audio_processing and AudioDomain::processing paths, including Domain's sealed processing-for-policy flow and the request lifetime**. It must accept the currently supported Leaf, Stage and Bound cases. Excluding Bound would cut out real existing callers.

This unit has one ownership prerequisite flattening avoided: a **guard-preserving composition operation for independent Core-backed values**. Resolve and test that seam before changing either outer collector. The closed GuardedBound::flattened_leaf extractor cannot be widened for this purpose. Existing Core APIs do not provide a conventional owned query collector while preserving all independent Core guards through every failure.

Keep the unit limited to these actual factories. Root constructs a Structural signal itself; Domain uses the physical capture walker. This source-proven boundary excludes arbitrary AudioSignal/source-voice/projected queries without refusing a valid Root/Domain result. Policy/fade constructors remain unadmitted.

## Actual paths and their common seam

| Site | Actual behavior | Required extension |
| --- | --- | --- |
| audio_signal.rs:703 RenderPlan::audio_signal | Root Structural handle with empty repeats, no definition/gap/bypass/placed transform/provider Arc. | Its scalar/empty handle needs no heap charge. Preserve this factory boundary. |
| audio_signal.rs:719 RenderPlan::audio_processing | Calls query_inner with RoundEven and both stop flags true; consumes signal query and fallibly maps its vector to processing spans. Moves header IDs. | Admit structural signal construction, retained intermediate buffer, and actual output conversion. |
| audio_signal.rs:1007 AudioSignal::query_inner | Limits, owned-input refusal, transform/grid/bounds, provider dispatch, structural push loop, then header clones. | Factor an admitted generic structural path used by both ordinary/admitted Root; leave unrelated provider branches intact. |
| audio_signal.rs:1124 AudioSignal::span | Separate structural signal walk with sampling support, binding stops, transparent retimes and opaque Preserve stages. | Guard this actual walk with existing helpers; do not substitute the physical capture traversal. |
| audio_domain.rs:424 AudioDomain::processing | Calls processing_inner with Preserve stop true. | Admitted equivalent reaches generic physical outer assembly. |
| audio_domain.rs:458 processing_observing | Domain/range validation, audio_walk_processing, into_processing, clipping/push, end header clones. | Use actual audio_walk_inner_admitted with same seed, bindings stop true, selected Preserve stop and optional witness; admit collection/header. |
| audio.rs:428 audio_walk_processing; audio_capture.rs:133 audio_walk_inner_admitted | Compatibility wrapper already instantiates Unmetered around actual guarded deep construction. | Reuse directly, without an unmetered extraction. |
| audio_domain.rs:434 processing_for_policy; :179 finish_policy | First actual walk co-produces the witness; sealed exact Domain/range capability chooses tape reuse or fallback. | Capability owns admitted query throughout both branches and failures; no second eligibility walk. |

Share accounting, storage helpers, headers, outer collection and ownership-preserving content mapping. Keep the two existing traversals.

A concrete equivalence hazard: Root AudioSignal::span calls AudioStage::for_node without a new local canonical copy debit. Physical capture at audio_capture.rs:619 performs its existing canonical(repeats.len()+1) before that constructor. Capture also builds physical envelope/boundary data before Leaf-to-processing conversion. Replacing Root traversal with capture therefore risks both receipts and behavior.

## Existing guards to reuse

- audio_owner_query_admission.rs:87 Memory, :99 Owned, :135 Budget, :197 account_core, :273 revision, :286 project, :298 source, :376 definition_ref, :405 gap_ref, :472 repeat, :486 repeats, :580 grow.
- Budget::grow admits the whole replacement while the old buffer remains live; false mode preserves the ordinary push/extend allocator backend. Use it for signal-span/output/guard vectors, with values before all capacity guards.
- audio_capture_storage.rs:9 copy_vec, :29 fixed, :58 retime, :76 hold guard finite exact-capacity copies and nested ownership. Visibility is currently capture-local: narrowly share this module, rather than copy its accounting framework.
- audio_signal.rs:177 AudioStage::for_node_admitted already admits descriptor project/revision/definition/instance/child ownership in the original failure order. Its selection retains the uncut authored intrinsic input.
- audio_bound_query.rs:212 bound_at_query, :149 boxed, :79 map plus CoreAdmission admit actual resolution, Plan metadata and Box shell. take_work/account_core reconcile successful Core work once.
- Domain's actual capture walker already guards seed/constraint/editorial/repeat/retime copies, stage/binding/envelope construction and terminal values.
- audio_flattened_query.rs:39 Build supplies the value-before-memory layout for partial headers, previous spans and replaceable capacity. Its narrow Leaf extractor is not a processing extraction seam.

## New actual Root ownership sites

| audio_signal.rs site | Admission before ownership |
| --- | --- |
| 1140..1143 initial repeats/gap copies | Vector capacity and nested node/allocation IDs; optional gap identity. Root itself supplies empty/None, but broader shared structural callers must not copy silently. |
| 1147..1189 gap dispatch | Existing bound_at_query/boxed/map, or storage::hold, plus actual gap-after ownership; preserve arithmetic/error ordering. |
| 1208..1230 node binding dispatch | Actual admitted binding resolution/Box, retaining Core payload/buffer and Plan metadata. |
| 1270 audible Source | Budget::source before the owning source identity clone. Preserve selection/sampling arithmetic and silence branches. |
| 1284..1292 Hold | storage::hold for RoomTone/Reverse owning source IDs and scalar-only variants. |
| 1321..1332 opaque Retime | Reuse for_node_admitted with full descriptor/history. |
| 1334..1342 transparent retime push | Full replacement capacity before growth; node identity before clone; retain Partition exclusion. |
| 1353..1389 Repeat branches | Path capacity and node/iteration ownership, following existing guarded capture's actual Repeat pattern; keep locate_bounded comparison work/errors canonical. |
| 1404..1420 returned span | Definition/final instance node, retained repeats/retimes, and current content combined under one live guard. |
| 1069..1082 signal query | Outer signal vector and end header identities; definition is None for Root. |

Domain's new outer sites are audio_domain.rs:465..493: prior output plus current span at vector replacement, original end-of-query header clone point, and into_processing.

### Domain Leaf conversion discards charged fields

AudioWalkSpan::into_processing (audio.rs:357) moves processing fields and drops the Leaf envelope/boundaries. At audio_capture.rs:859..908 the walker already merges that Leaf envelope charge into its returned Plan Memory.

Retaining all returned Plan memory is safe but conservative after the discarded fields die. State that explicitly if used in the first implementation and its tests; it is not exact final-live-byte accounting. Releasing just the discarded ownership requires splitting its actual memory lane before the existing merge. A later size inspection/subtraction is not a valid refund or admission proof. Avoid rewriting traversal to skip old allocations/copy weights as an incidental optimization.

## Root conversion is a second construction phase

At audio_signal.rs:729..772 the actual AudioSignalQuery is the input to a fallible iterator conversion. Owned content/IDs/repeats/retimes move; AudioSampleGrid::new and AudioSampleMap::new can still fail.

The admitted backend must reserve its actual output allocation before creation while retaining the input buffer, remaining input values, earlier output values and all guards. Keep partially moved input/output in a value-before-charge state on conversion failure. Release the input buffer charge only after the buffer dies. Header IDs move from the signal query, with no second clone or bill.

Do not assume the ordinary fallible Result collect either allocates a second buffer or reuses the input. Preserve that literal backend for METERED=false. A shared scalar per-span conversion plus an explicit metered collection is a defensible seam; test its real capacities and requested Layouts.

A direct Root processing constructor that eliminates the signal query would change this implementation and peak. That is a separate optimization requiring its own ordinary error/work equivalence proof.

## Guarded collection prerequisite

The present ownership chain is:

- audio_capture.rs:10 WalkResult owns GuardedBound<AudioWalkSpan> before independent Plan memory.
- audio_bound_query.rs:43 BoundValue::Metered owns Core AudioBindingValue<T,I,L>.
- Core audio_binding/admission.rs:91 stores the private actual value before independent payload/buffer leases.
- Core :173 map_value is an infallible, allocation-free ownership map followed by validation. It returns another guard; it exposes no metered T.
- Core :140 preflight_charge_transfer/:105 transfer token only borrow actual charges for trusted publication. They do not extract values. Plan's GuardedChargeTransfer at audio_bound_query.rs:527 preserves that rule.
- Plan's flattened_leaf at audio_bound_query.rs:105 correctly refuses Core-backed payloads.

A conventional Vec<AudioProcessingSpan> needs owned spans, but real Bound spans cannot lose their Core carriers. Do not solve this with unmetered extraction, callback mutation of an external output Vec, detached charge certificates, or admission around an ordinary finished query. Charge-transfer publication does not authorize query-value extraction.

Preferred prerequisite direction: a small reviewed Core operation that **combines independent guarded values and permits fallible ownership-preserving collection/mapping while every intermediate precedes all input lease lanes**. Plan can keep an accumulated Vec/query inside a guard and return a sealed carrier borrowing that actual query. It needs no unchecked unwrap or public mutable query access.

This report does not claim a generic join signature alone solves the problem. Existing map callbacks cannot run Budget::grow's fallible per-item policy work; Root conversion also has fallible scalar operations. Prototype the concrete collection/conversion transition first, with issuer/mode/already-transferred checks and exact successful receipt reconciliation, then test failure/destruction before using it in constructors. The needed Core extension is justified by current Bound callers.

An alternative is a Vec<GuardedBound<AudioProcessingSpan>> exposed through an iterator-based processing view. It avoids extraction but changes RootReadQueriesRef, numerical readers and the policy tape's &[AudioProcessingSpan] contract. It spreads a constructor concern across numerical code, so it is not preferred.

## ProjectedStage and complete history

AudioSignalContent has four variants, but these exact Root/Domain factories do not currently construct ProjectedStage:

- Root audio_signal at audio_signal.rs:703..715 selects Structural.
- Structural span constructs Leaf, Stage and Bound only.
- Physical capture constructs the same three. Its Terminal::ProjectedStage matcher recognizes a shape but has no creation arm.
- ProjectedStage creation is projected_span at audio_signal.rs:1086, selected only by SignalProvider::Projected at :1027 from for_projection at :933.
- The projected ownership test at audio_allocated/query_storage_tests.rs:327 reaches voice.processing, not either Root/Domain factory.

Thus this unit can preserve the actual factory boundary without accepting then rejecting a valid result. Before reusing its generic code for arbitrary signals/source voices, admit the Arc edge and complete projection graph at that owning site. Arc::clone creates ownership even when it allocates no new payload; final measurement cannot authorize it.

For Stage retain descriptor selection, duration/rate, child/node/definition/repeat identity and exact plan borrow. input_signal at audio_signal.rs:377 retains the complete intrinsic selection; outer request clipping must never crop that history. Existing owned-Preserve splice/projection errors remain where they are. Bound retains the complete resolved binding and separate raw/envelope domains, not a cropped replacement or eager numerical body.

## Carrier and host lifetime

Use a sealed read-only admitted processing carrier owning the actual immutable query before Core/Plan guards, with canonical/additional receipt proof, no Clone/mutable query/public detach, and no Graph publication. It has a plan lifetime because Stage/Bound borrow the plan.

Domain needs an admitted processing-for-policy capability owning that carrier plus exact borrowed Domain, requested range and co-produced ProcessingStops:

1. Construct/forward actual first-query work once.
2. Keep the carrier while finish_policy checks pointer/range and receives fresh remaining limits.
3. Reuse only under the existing witness and fresh span cap; otherwise run the existing ordinary fallback.
4. Return admitted processing plus ordinary policy. Policy failure drops processing and all guards.
5. Preserve ordinary processing_for_policy/finish_policy types and behavior through Unmetered. A free admitted query must not become a caller-built witness.

PreparedQueries.processing in deadpan-audio/src/original_request.rs becomes the carrier; queries() borrows its actual AudioProcessingQuery into RootReadQueriesRef. prepare_domain_policy must return that carrier, not ordinary query plus a lease. Flattened and processing charges coexist through later policy/fade construction, prediction and numerical read. Remove the host processing.work bill only when the actual admitted constructor forwards it; keep policy's current successful-receipt bill and fresh allowance semantics.

Extend the existing real ReadWork issuer validation to both carriers at consuming boundaries. Preserve read_prepared_original's metadata drop before returned PCM lifetime, unused-request/late-hit release, and early warm Probe building neither product.

## Existing oracles and gaps

Reuse these existing sources:

- audio_domain_policy_reuse_tests.rs:46 visit reconstructs 26 frozen Domain cases from wide checked parents and policy_binding_baseline::visit_additional.
- :110 full private old corpus; :201 exact fresh policy work; :255 pointer/range refusal; :290 first factory budget/errors; :329 exposed-Stage fallback; :395 fresh span caps already enforce the witness contract.
- policy-binding-baseline-v1/snapshot.json records actual first processing(true), separate false and recursive second-query observations. Its producer explicitly excludes Root and synthetic ProjectedStage from certification.
- capture_baseline::processing is its existing complete private span serializer. Reuse Stage/Bound private fields, plan identity and explicit query.work/lookup.
- audio_allocated/query_storage_tests.rs:137 checks final root product ownership with a nested-Preserve fixture. It is neither a frozen constructor/failure oracle nor a peak test.
- Current flattened OLD matrix certifies AudioQuery only.

Before refactoring Root, freeze an actual OLD Root processing matrix on Main/Scope using existing fixtures: Source/absent/selected Source, owning-ID Hold variants, default/named Repeat gaps, transparent retimes, cropped/nested Preserve and active binding. Include full/crop/empty, limits/range error priority, exact/one-short canonical work and positive span cap. Pin private parent/span serialization, lookup and work before changing producers.

Required new tests:

- Ordinary/METERED=false match literal OLD fields, canonical work, failure labels/order and allocator backend. METERED=true reconciles total with actual additional work.
- Multiple independently Core-backed spans mixed with Leaf/Stage; collection/conversion failure after an earlier Bound; both Core lease lanes; foreign issuer/mode/used-transfer refusal and value-before-charge destruction.
- Actual Root input/output vector overlap, outer growth with prior/current spans live, empty headers and callback refusal/rotation. Layout/lease peaks only, not RSS.
- Full Stage selection/history under clipped output, nested Preserve, inherited retime/definition/signed Domain and Bound raw/envelope history.
- Witness reuse and Stage fallback while processing charge remains live, exactly one first bill, unchanged fresh policy work/span limits.
- Actual failed admitted debits/cleanup; unchanged Unmetered failed-call receipt behavior; separately billed retained-storage observation.
- Host flat+processing aggregate residency, later policy/fade failure release, live charge during prediction/read, foreign ReadWork refusal, late-hit cleanup, zero warm query phases and required PCM admission under both charges.

## Acceptance boundary

Accept the product unit when actual Root/Domain cold Original processing construction, independent Core-backed storage, the sealed policy witness and consuming lifetime are admitted together. The guarded-collection prerequisite belongs to its design; it is not permission for arbitrary Core detachment.

Together with flattened admission this closes two Original products. Recursive policy, optional fade, arbitrary signal/source-voice/ProjectedStage and wider renderer construction remain open. No Graph pack, query cache, budget/weight increase, refund, DSP change, native release build or model artifact is required.
