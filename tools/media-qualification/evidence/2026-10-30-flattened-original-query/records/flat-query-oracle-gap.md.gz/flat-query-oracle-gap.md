# Ordinary flattened-query oracle gap

Read-only finding, 2026-10-29. No actual source edits, producer, Cargo/native execution, or Git.

**No existing immutable corpus I inspected freezes a complete ordinary Root/Domain AudioQuery together with its canonical work. Capture a small OLD supplement before factoring either audio() entry point.**

## What the existing evidence does freeze

| Existing path, relative to crates/ | Exact useful keys or test | Gap for this change |
| --- | --- | --- |
| deadpan-plan/tests/fixtures/owner-capture-baseline-v1/snapshot.json | events[].observation.walk.discarded_span, when tag=Leaf, contains every AudioSpan logical field; observation.actual_capture_work_spent, budget_before, budget_remaining describe the actual inner capture walk. | A discarded span at one owner-input/probe point is not the top-level AudioQuery: no complete project/revision header, requested query range, ordered clipped span collection, outer-loop work/lookup, or top-level span-cap failure. |
| deadpan-plan/src/audio_owners/legacy_snapshot_v1/capture_baseline.rs:236 span; :297 capture_ref | Explicit exhaustive Leaf destructure, including boundaries, source content, retimes, sampling and grid parity. | Excellent serializer to reuse, but its current caller is the owner capture/probe path. Do not relabel those events as ordinary audio() results. |
| deadpan-plan/tests/fixtures/policy-binding-baseline-v1/snapshot.json | cases[].first_processing_true.query, separate_processing_false.query, policy_cases[].output.policy, actual_second_query_events[].query.query | Complete AudioProcessingQuery and policy, including work/lookup; no flattened AudioQuery output. physical_domain records the actual private seed, which is reusable setup evidence. |
| deadpan-plan/tests/fixtures/owner-query-baseline-v1, wide-gain-owner-baseline-v1 | Owner-query spans, clocks, seeds, work/lookup. | These are gain-owner query products. |
| deadpan-plan/tests/fixtures/direct-owner-input-baseline-v1, span-start-input-baseline-v1, owner-probe-point-baseline-v1 | Actual owner input/probe/Point-domain observations and costs. | They do not assemble/freeze the ordinary flattened query. |
| deadpan-audio/tests/fixtures/{authored-node-baseline-v1,authored-tile-baseline-v1,caller-description-baseline-v1,cached-original-prediction-baseline-v1,cached-original-zero-prediction-baseline-v1} | Caller/node/tile state, masks, PCM and work traces. | These cannot recover complete flat-query fields from caller outcomes or phase totals. |

I checked the immutable snapshot/supplement/cost JSON shapes and their producers. The only objects containing all project_id/revision_id/samples/spans/lookup keys in that fixture corpus are the policy-binding processing-query records, not AudioQuery records.

Other committed tests are useful but do not fill the OLD gap:

- deadpan-plan/src/audio_allocated/query_storage_tests.rs:138 actual_root_query_products_measure_all_owned_storage_without_mutating_fields compares serialization before/after inspecting the same live query. Its fixture() at :60 gives actual Source, Repeat and nested Preserve. The test is not an immutable expected query; AudioQuery's derived Serialize also skips work.
- deadpan-plan/tests/audio_context.rs:164 compare_audio does assert equality of complete Root AudioQuery values, including PartialEq's work field, between two live compiled plans. Both results use the implementation being changed, so a shared drift can pass.
- deadpan-plan/tests/audio_plan.rs has detailed independent boundary/source/partition checks and bounded-work assertions; its property tests compare selected geometry and per-sample spans across live query partitions. deadpan-plan/tests/audio_domain.rs tests signed/NTSC domains, hidden input and limits. Neither supplies a complete frozen OLD Root/Domain query plus exact work.

## Minimal OLD supplement

Reuse existing real documents/setup. Five parent cases are enough to cover the distinct outer builder and seeded ownership branches without copying the wide matrix wholesale:

1. **Root Source/Repeat/nested Preserve**: query_storage_tests.rs fixture(). Record full Root range, an interior crop spanning both repeat plays, and an empty range. Full range is derived from audio_duration(), not a handwritten assumption. This carries source identifiers, nested retimes, owning boundaries, repeated instance paths and clipping in one small plan.
2. **Root Repeat overrides/default gaps**: owner-query-baseline-v1/snapshot.json fixtures[1], fixture name stable_repeat_plays_default_gap_and_overrides. Reuse its document and full Root query; include a crop crossing a voice/gap seam. It exercises a multi-span sequence, override occurrence and actual gap ownership/content.
3. **Domain default gap**: wide-gain-owner-baseline-v1/snapshot.json cases[4], name repeat_actual_default_gap_domain_full; policy-binding-baseline-v1/snapshot.json cases[4] supplies the exact physical_domain. Its actual range is 8..10. Reconstruct through wide_baseline::visit_cases; do not deserialize/manufacture an AudioDomain from snapshot JSON. This covers the definition/gap seed branch absent from the storage fixture.
4. **Signed physical Domain**: policy-binding-baseline-v1/snapshot.json cases[24], name hidden_signed_partition_group_with_unrelated_binding; additional_documents[5]. Reuse policy_binding_baseline::visit_additional. Its full root_samples is -3..13 and visible_samples is 1..9. Record full physical range, an interior crop that includes negative history, and empty. This prevents accidentally substituting visible delivery for physical support.
5. **Inherited-retime physical Domain**: same corpus cases[22], name cropped_group_domain_with_inherited_edit_retime; additional_documents[4]. Actual range is 1..9. Reuse visit_additional. This covers a nonempty inherited seed.retimes path that the signed Partition example is not a substitute for.

If the factor touches grid/seed mapping beyond reusing the existing walker, also include the existing fractional_actual_physical_capture_domain at wide cases[10]/policy cases[10] (0..3), reconstructed by wide_baseline::visit_cases. Existing capture fixtures already exercise fractional grid fields inside the walker; this sixth parent adds direct top-level proof at little setup cost.

For each parent capture default full, default clipped and default empty results where meaningful. For each successful nonempty full result, add exact canonical work, one-short canonical work (when valid), and a deliberately insufficient positive span cap when the output has more than one span. Add one representative invalid zero-work/zero-span limit and outside-support range for Root and Domain. AudioQueryLimits::validate rejects maximum_work=0, even for empty output; empty query work=0 must use valid positive limits.

## Exact output contract

Each row should freeze:

- case name, actual validated document and actual Domain reconstruction identity/seed when relevant;
- requested samples and both limits;
- Result tag, exact PlanError variant/static label on failure;
- on success, **project_id, revision_id, samples, all ordered AudioSpan fields, lookup's three counters, explicit canonical work**.

Use an exhaustive AudioQuery/AudioSpan observer, borrowing the returned OLD value. The capture_baseline Leaf serializer is the existing field map; extracting a direct flat-span helper is sufficient. A bare serde_json::to_value(&query) loses work unless it is explicitly added. Do not infer output fields from owner queries, reconstruct them from masks, or invoke a second query as the observation of the first.

OLD ordinary query errors do not expose partial work. Freeze that fact as unknown/not-exposed; do not invent a zero-work receipt. Parent's pinned OLD Main and Scope producers should agree on every logical output/error/work/lookup field, removing only provenance. Use create_new output and pin producer source/executable/output before changing construction.

The ordinary compatibility path and the new admitted path should both compare their complete query values and canonical work against this supplement. New admitted bookkeeping work is a separately observed actual cost, never a normalized change to OLD canonical work. Allocation peaks and failure cleanup need separate admission tests; this logical oracle cannot establish either.
