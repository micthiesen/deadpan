from pathlib import Path
from datetime import datetime
import hashlib, json, re, sys

s = Path(__file__).resolve().parent
roots = {'main': Path('/Users/michael/Code/deadpan'),
         'scoped': Path('/tmp/deadpan-query-groundwork-2026-10-26/scoped')}
sha = lambda b: hashlib.sha256(b).hexdigest()
passed, failed = map(int, sys.argv[1:])
assert passed + failed == 7
negative = {'audio-scoped-build': 101, 'host-scoped-build': 101,
            'integration-scoped-lib': 101, 'review-flat-scoped-plan': 101,
            'receipts-scoped-stages': 101, 'final-main-check': 1}
if failed:
    negative['fresh-split'] = 101
receipts, intervals = [], []
for p in sorted(s.glob('*.json')):
    row = json.loads(p.read_text())
    if not isinstance(row, dict) or 'command' not in row or 'started_at' not in row:
        continue
    assert row.get('exit_code') == negative.get(p.stem, 0), (p.stem, row.get('exit_code'))
    assert row['sources_unchanged'] and row['binaries_unchanged'], p.stem
    for path, pin in row['streams'].items():
        b = Path(path).read_bytes()
        assert len(b) == pin['bytes'] and sha(b) == pin['sha256'], path
    receipts.append({'label': p.stem, 'exit_code': row['exit_code'],
                     'seconds': row['seconds'], 'source_inputs': len(row['source_before']),
                     'sha256': sha(p.read_bytes())})
    if row['binary_before'] and '-audio-' in row['command'][0]:
        intervals.append((datetime.fromisoformat(row['started_at']),
                          datetime.fromisoformat(row['finished_at']), p.stem))
for a, b in zip(sorted(intervals), sorted(intervals)[1:]):
    assert a[1] <= b[0], ('native Audio overlap', a[2], b[2])

paths = json.loads((s / 'published-source-paths.json').read_text())
assert len(paths) == 34
index = json.loads((s / 'index-source-equality.json').read_text())
assert len(index) == 34 and all(r['scoped_index_equal'] for r in index)
assert sum(r['main_equal'] for r in index) == 32
preserved = {}
for variant, root in roots.items():
    pins = json.loads((s / (variant + '-published-source-pins.json')).read_text())
    assert set(pins) == set(paths)
    for p, pin in pins.items():
        b = (root / p).read_bytes()
        assert len(b) == pin['bytes'] and sha(b) == pin['sha256'], (variant, p)
    initial = json.loads((s / (variant + '-initial-authority.json')).read_text())
    other = {p: pin for p, pin in initial.items() if p not in paths}
    for p, pin in other.items():
        assert sha((root / p).read_bytes()) == pin['sha256'], (variant, p)
    preserved[variant] = len(other)
assert preserved == {'main': 2737, 'scoped': 2409}
baseline = json.loads((s / 'scoped-baseline-head-equality.json').read_text())
assert sum(r['existing'] for r in baseline) == 24
assert all(r['scoped_initial_matches_HEAD'] for r in baseline if r['existing'])
goldens = json.loads((s / 'immutable-oracle-pins.json').read_text())
assert len(goldens) == 14
for row in goldens:
    for root in roots.values():
        assert sha((root / row['path']).read_bytes()) == row['sha256'], row['path']

expected = {'constructor-main-core': (816, 0), 'constructor-scoped-core': (791, 0),
            'linted-main-plan': (211, 10), 'linted-scoped-plan': (198, 10),
            'linted-main-audio-lib': (398, 6), 'linted-scoped-audio-lib': (392, 6),
            'linted-main-stages': (203, 0), 'linted-scoped-stages': (203, 0),
            'linted-main-definition': (171, 0), 'linted-scoped-definition': (171, 0)}
tests = {}
for label, pair in expected.items():
    matches = re.findall(r'test result: ok\. (\d+) passed; 0 failed; (\d+) ignored;',
                         (s / (label + '.stdout')).read_text())
    assert len(matches) == 1 and tuple(map(int, matches[0])) == pair, (label, matches)
    tests[label] = {'passed': pair[0], 'ignored': pair[1],
                    'seconds': json.loads((s / (label + '.json')).read_text())['seconds']}
for variant in roots:
    rows = json.loads((s / ('linted-plan-' + variant + '-integration-summary.json')).read_text())
    assert len(rows) == 28 and all(r['exit_code'] == 0 for r in rows)
    count = 0
    for row in rows:
        match = re.search(r'test result: ok\. (\d+) passed; 0 failed; 0 ignored;',
                          (s / (row['label'] + '.stdout')).read_text())
        assert match
        count += int(match[1])
    assert count == 450

a = (s / 'linted-current-body-main.json').read_bytes()
b = (s / 'linted-current-body-scoped.json').read_bytes()
assert a == b == (s / 'current-body-main.json').read_bytes()
assert sha(a) == 'c23ffd1025812a48bfbf5b3c876b6aa2a963e778771e377f97077b1d8d743080'
split_rows = re.findall(r'^test (general_split_sound::[\w:]+) \.\.\. (ok|FAILED)',
                        (s / 'fresh-split.stdout').read_text(), re.M)
assert len(split_rows) == 7
assert sum(state == 'ok' for _, state in split_rows) == passed
assert sum(state == 'FAILED' for _, state in split_rows) == failed
reviews = ['review-constructor-general.md', 'review-audio-integration.md',
           'review-flat-tests.md', 'review-host-tests.md',
           'review-flat-work-receipts.md', 'review-identity-delta.md',
           'review-native-pressure.md', 'review-findings-resolution.md']
assert all((s / p).is_file() for p in reviews)
result = {'all_terminal': True, 'receipts': receipts, 'expected_negative_results': negative,
          'tests': tests, 'plan_integrations_per_variant': {'executables': 28, 'tests': 450},
          'source_paths': 34, 'existing_scope_baselines_equal_HEAD': 24,
          'all_scoped_index_equal': True, 'main_also_equal': 32,
          'unrelated_initial_inputs_unchanged': preserved,
          'immutable_oracles_unchanged': 14, 'native_audio_suites_serial': True,
          'native_audio_intervals': len(intervals), 'reviews': reviews,
          'source_patch_sha256': sha((s / 'published-source.patch').read_bytes()),
          'current_observation_sha256': sha(a),
          'split': {'passed': passed, 'failed': failed, 'cases': split_rows,
                    'seconds': json.loads((s / 'fresh-split.json').read_text())['seconds']},
          'zero_test_filter_not_coverage': 'pressure-scoped-gain'}
(s / 'final-audit.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({k: result[k] for k in ['all_terminal', 'tests', 'split', 'source_patch_sha256']}))
