from pathlib import Path
scratch=Path('/tmp/deadpan-flattened-query-admission-2026-10-29')

def replace(p,old,new):
 s=p.read_text(); assert s.count(old)==1,(p,old[:80],s.count(old)); p.write_text(s.replace(old,new))
for variant in ['main','scoped']:
 root=scratch/'constructor-candidate'/variant/'crates/deadpan-plan/src'
 p=root/'audio.rs'
 replace(p,'#[path = "audio_capture.rs"]\npub(in crate::plan) mod capture;','#[path = "audio_capture.rs"]\npub(in crate::plan) mod capture;\n#[path = "audio_flattened_query.rs"]\npub(in crate::plan) mod flattened_query;\npub use flattened_query::AdmittedAudioQuery;')
 s=p.read_text(); start=s.index('        limits.validate()?;',s.index('    pub fn audio(\n')); end=s.index('    pub(super) fn audio_walk',start)
 s=s[:start]+'''        use super::audio_owners::admission::Unmetered;
        self.audio_admitted(samples, limits, &mut Unmetered)
            .map(AdmittedAudioQuery::unmetered)
    }

'''+s[end:];p.write_text(s)
 p=root/'audio_domain.rs'
 s=p.read_text();start=s.index('        let mut budget = self.budget(&samples, limits)?;',s.index('    pub fn audio(\n'));end=s.index('    /// Resolve processing',start)
 s=s[:start]+'''        use super::audio_owners::admission::Unmetered;
        self.audio_admitted(samples, limits, &mut Unmetered)
            .map(super::audio::AdmittedAudioQuery::unmetered)
    }

    /// Construct the actual flattened query under one allocation/work policy.
    /// The returned carrier retains its charge for every immutable query borrow.
    pub fn audio_admitted<A: crate::AudioSoundContextAdmission>(
        &self,
        samples: Range<AudioSample>,
        limits: AudioQueryLimits,
        admission: &mut A,
    ) -> Result<super::audio::AdmittedAudioQuery<A::Issuer, A::Lease>, A::Error> {
        let local = self.budget(&samples, limits)?;
        super::audio::flattened_query::query(
            self.plan,
            Some(&self.seed),
            samples,
            limits,
            local,
            admission,
        )
    }

'''+s[end:];p.write_text(s)
 p=root/'audio_capture.rs'
 replace(p,"impl<'plan> WalkResult<'plan, (), ()> {",'''impl<'plan, I: Copy + Eq, L> WalkResult<'plan, I, L> {
    /// Flattening never stops at bindings or Preserve stages. Retain both actual
    /// Plan guards while extracting only that closed legacy Leaf shape.
    pub(in crate::plan) fn flattened_leaf<
        A: AudioSoundContextAdmission<Issuer = I, Lease = L>,
    >(
        self,
        budget: &mut QueryBudget<'_, A>,
    ) -> Result<Owned<AudioSpan, I, L>, A> {
        self.value.flattened_leaf(self.memory, budget)
    }
}
impl<'plan> WalkResult<'plan, (), ()> {''')
 p=root/'audio_bound_query.rs'
 anchor="impl<'plan, I: Copy + Eq, L> GuardedBound<AudioBound<'plan>, I, L> {"
 method='''// This extraction is deliberately limited to the actual flattened walker.
// A Core-backed value cannot escape its independent Core guard through it.
impl<'plan, I: Copy + Eq, L> GuardedBound<crate::plan::audio::AudioWalkSpan<'plan>, I, L> {
    pub(in crate::plan) fn flattened_leaf<
        A: AudioSoundContextAdmission<Issuer = I, Lease = L>,
    >(
        self,
        memory: Memory<I, L>,
        budget: &mut QueryBudget<'_, A>,
    ) -> Result<Owned<crate::plan::audio::AudioSpan, I, L>, A> {
        use crate::plan::audio::AudioWalkSpan;
        // Check while the complete value precedes both independent guards.
        let guarded = Owned { value: self, memory };
        budget.check_memory(&guarded.memory)?;
        budget.check_memory(&guarded.value._memory)?;
        let GuardedBound { value, mut _memory } = guarded.value;
        let span = match value {
            BoundValue::Legacy(AudioWalkSpan::Leaf(span)) => span,
            BoundValue::Legacy(AudioWalkSpan::Stage(_)) => {
                return Err(PlanError::InvalidPlan("flattened audio retained a stage").into());
            }
            BoundValue::Metered(_) => {
                return Err(PlanError::InvalidPlan("flattened audio retained a metered binding").into());
            }
        };
        let mut result = Owned { value: span, memory: guarded.memory };
        // No fallible operation separates the moved Leaf from either guard.
        budget.merge_checked(&mut result.memory, &mut _memory);
        budget.check_memory(&result.memory)?;
        Ok(result)
    }
}
'''
 replace(p,anchor,method+anchor)
 p=root/'audio_sound_admission.rs'
 replace(p,'//! Allocation-site admission for the closed current-sound context only.\n//! Borrowed plan storage and Original/retained query construction are separate.','//! Allocation-site admission for the closed current-sound context and flattened\n//! Root/Domain AudioQuery construction, including cold Original flattened queries.\n//! Original processing, policy and fade construction peaks remain separate.')
 p=root/'lib.rs';replace(p,'    AudioDomainProcessing, AudioDomainProcessingPolicy, AudioQuery, AudioQueryLimits,','    AdmittedAudioQuery, AudioDomainProcessing, AudioDomainProcessingPolicy, AudioQuery, AudioQueryLimits,')
 (root/'audio_flattened_query.rs').write_text('''//! Actual flattened Root/Domain construction, shared with compatibility queries.
use super::*;
use crate::AudioSoundContextAdmission;
use crate::plan::audio_owners::admission::{self, Budget as QueryBudget, Memory, Owned, Result};

/// An immutable flattened query and its independent RAII charge stay inseparable.
/// No public constructor or detachment can certify an unadmitted query.
pub struct AdmittedAudioQuery<I, L> {
    query: Owned<AudioQuery, I, L>,
    canonical: usize,
    additional: usize,
    forwarded: bool,
}
impl<I, L> AdmittedAudioQuery<I, L> {
    pub fn query(&self) -> &AudioQuery {
        &self.query.value
    }
    pub fn work(&self) -> usize {
        self.query.value.work
    }
    pub fn canonical_units(&self) -> usize {
        self.canonical
    }
    pub fn additional_units(&self) -> usize {
        self.additional
    }
    pub fn was_forwarded(&self) -> bool {
        self.forwarded
    }
}
impl AdmittedAudioQuery<(), ()> {
    pub(in crate::plan) fn unmetered(self) -> AudioQuery {
        self.query.unmetered()
    }
}

// Every actual value precedes its payload and replaceable vector-buffer charge,
// including a partial header clone and all earlier spans on any failed walk.
struct Build<I, L> {
    project_id: Option<ProjectId>,
    revision_id: Option<RevisionId>,
    spans: Vec<AudioSpan>,
    payload: Memory<I, L>,
    capacity: Memory<I, L>,
}

impl RenderPlan {
    /// Bounded flattened lookup with actual work and allocation-site admission.
    /// The carrier keeps its charge live until the query's last borrow ends.
    pub fn audio_admitted<A: AudioSoundContextAdmission>(
        &self,
        samples: Range<AudioSample>,
        limits: AudioQueryLimits,
        admission: &mut A,
    ) -> std::result::Result<AdmittedAudioQuery<A::Issuer, A::Lease>, A::Error> {
        limits.validate()?;
        if samples.start.0 < 0
            || samples.end < samples.start
            || samples.end > self.audio_duration()?
        {
            return Err(PlanError::AudioRangeOutOfRange.into());
        }
        let local = Budget {
            remaining: limits.maximum_work,
            lookup: LookupStats::default(),
        };
        query(self, None, samples, limits, local, admission)
    }
}

pub(super) fn query<A: AudioSoundContextAdmission>(
    plan: &RenderPlan,
    seed: Option<&AudioWalkSeed>,
    samples: Range<AudioSample>,
    limits: AudioQueryLimits,
    mut local: Budget,
    admission: &mut A,
) -> std::result::Result<AdmittedAudioQuery<A::Issuer, A::Lease>, A::Error> {
    let mut budget = QueryBudget::new(&mut local, admission);
    admission::outer::<_, A>(assemble(plan, seed, samples, limits, &mut budget))
}

fn assemble<A: AudioSoundContextAdmission>(
    plan: &RenderPlan,
    seed: Option<&AudioWalkSeed>,
    samples: Range<AudioSample>,
    limits: AudioQueryLimits,
    budget: &mut QueryBudget<'_, A>,
) -> Result<AdmittedAudioQuery<A::Issuer, A::Lease>, A> {
    let mut build = Build {
        project_id: None,
        revision_id: None,
        spans: Vec::new(),
        payload: budget.memory(),
        capacity: budget.memory(),
    };
    let mut cursor = samples.start;
    while cursor < samples.end {
        if build.spans.len() == limits.maximum_spans {
            return Err(PlanError::AudioQueryLimit("span count").into());
        }
        let mut span = plan
            .audio_walk_inner_admitted(
                cursor,
                budget,
                seed,
                false,
                false,
                (None, None, None, None),
            )?
            .flattened_leaf(budget)?;
        span.value.samples = cursor..span.value.allocated_samples.end.min(samples.end);
        cursor = span.value.samples.end;
        let needed = build.spans.len().checked_add(1).ok_or(TimeError::Overflow)?;
        // The whole replacement, the old buffer, earlier contents and this
        // current span remain charged together while grow allocates and moves.
        budget.grow(&mut build.spans, &mut build.capacity, needed)?;
        budget.check_memory(&build.payload)?;
        budget.check_memory(&span.memory)?;
        build.spans.push(span.value);
        budget.merge_checked(&mut build.payload, &mut span.memory);
    }
    // Preserve the legacy header-clone point after every span is constructed.
    build.project_id = Some(budget.project(&mut build.payload, &plan.metadata.project_id)?);
    build.revision_id = Some(budget.revision(&mut build.payload, &plan.metadata.revision_id)?);
    budget.check_memory(&build.payload)?;
    budget.check_memory(&build.capacity)?;
    budget.merge_checked(&mut build.payload, &mut build.capacity);
    let canonical = budget.canonical_used;
    let additional = budget.additional_used;
    let work = canonical.checked_add(additional).ok_or(TimeError::Overflow)?;
    if limits.maximum_work.checked_sub(budget.remaining) != Some(work) {
        return Err(PlanError::InvalidPlan("flattened query work provenance mismatch").into());
    }
    let query = Owned {
        value: AudioQuery {
            project_id: build.project_id.expect("completed flattened project header"),
            revision_id: build.revision_id.expect("completed flattened revision header"),
            samples,
            spans: build.spans,
            lookup: budget.lookup,
            work,
        },
        memory: build.payload,
    };
    budget.check_memory(&query.memory)?;
    Ok(AdmittedAudioQuery { query, canonical, additional, forwarded: A::METERED })
}
''')
