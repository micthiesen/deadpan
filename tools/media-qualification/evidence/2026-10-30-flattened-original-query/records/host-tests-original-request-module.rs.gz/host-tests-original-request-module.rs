#[path = "flattened_admission_tests.rs"]
mod flattened_admission;
