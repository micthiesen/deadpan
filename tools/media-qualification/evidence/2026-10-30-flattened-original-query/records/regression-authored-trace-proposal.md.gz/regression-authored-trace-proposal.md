# Bounded authored matrix receipt proposal

The current three observations already compare admitted flattened mode against
admitted flattened mode for Domain policy reuse and certified span-start reuse.
Those comparisons reach the immutable work check without failing. The literal
OLD assertion now sees 168 vs 112 (metered) and 167 vs 111 (false index-work), an
actual 56-unit difference in the first reached operation. That difference alone
is not an independent fee oracle and must not become a normalization constant.

Keep those three current observations. Add one explicitly ordinary-flat
reference by nesting original_request::with_legacy_flattened_queries around the
existing with_domain_policy_trace(true) plus span_start::with_direct_reference.
Compare that reference to the unchanged frozen GOLDEN with the existing index
fee/layout normalization. This preserves its old work literals and complete
semantic/PCM/controller comparison without disabling current mode for the test.

Reconcile the current old-domain-policy/direct observation against the added
old-flat reference using actual flattened receipts, not total-work subtraction.
A narrow cfg(test) fixed TLS counter seam in original_request can supply:
- completed canonical units
- completed additional units
- successful issuer comparison units/count
- accepted partial flattened work on any failed constructor
- a sticky overflow flag

A scoped guard is created only for the production admitted flattened constructor,
after the test-only ordinary branch. It retains WorkControl and the actual
pre-construction plan/cache counters. On successful completion it checks the
actual accepted delta against canonical+additional from AdmittedAudioQuery.
On any early failure Drop records the actual accepted delta as partial work.
The issuer hook records only after the real successful spend_plan_work(1).
The seam never reserves memory, modifies ReadWork, refunds work, or counts a
weight that was not actually spent.

Expose reset/snapshot only cfg(test), comparable to existing Domain and span-start
receipts. Add its cumulative snapshot as one new field in legacy_tile_baseline
counters(), reset at each scenario start. For the old-flat reference all fee
receipts must be zero. For this bounded authored corpus, assert partial work zero
at every comparison; if native execution disproves that assumption, qualify the
specific refusal with exact partial receipts instead of pretending parity.

For each setup/operation/final counter pair:
- assert overflow=false, partial_work=0
- assert current total controller work = ordinary-flat counterpart total plus
  actual completed additional units plus actual successful issuer units, except
  imposed work values where the corpus must prove no new receipts
- normalize only that independently witnessed work delta and remove only the
  added trace field
- assert every other complete counter, PCM/dependency/provider/cache/depth/error
  field equal

After that current-v-ordinary proof, retain existing Domain-policy and certified
comparisons on the unmodified current observations. The extra ordinary reference
alone goes through unchanged golden/index/layout validation.

The ignored OLD producer should also enter with_legacy_flattened_queries if it is
ever intentionally rerun, because its current OLD label otherwise no longer
describes literal query work. This is provenance protection, not a golden rewrite.

Ownership expansion needed: original_request's cfg(test) hook/module and
authored_eq/legacy_tile_baseline.rs snapshot/reset field and ignored wrapper.
Parent currently owns production and must choose/implement or explicitly delegate
that seam. This worker has not changed either source or any golden.
