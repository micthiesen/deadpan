# OLD complete flattened-query producer

Test-only unit complete in Main and isolated Scope, source-frozen for parent build/capture. Ordinary constructors are unchanged. No Cargo, builds, native execution, Git, or producer runs were performed by this child.

## Files and exact pins

Both variants have identical contents for all four changed files:

- crates/deadpan-plan/src/audio_owners/legacy_snapshot_v1/flattened_query_baseline.rs: new producer/observers, 15,046 bytes, SHA256 7ab32e08df53ae069a863ad48955b0e830c36211df38321df8c3c11dc2f2e134.
- crates/deadpan-plan/src/audio_owners/legacy_snapshot_v1.rs: only the new test submodule declaration.
- crates/deadpan-plan/src/audio_allocated.rs: only cfg(test) query_storage_tests module visibility becomes pub(crate).
- crates/deadpan-plan/src/audio_allocated/query_storage_tests.rs: only fixture() test-helper visibility becomes pub(crate).

The per-variant patch files flattened-producer-main.patch and flattened-producer-scoped.patch are identical: 16,578 bytes, SHA256 6b27303f60e641b2316fb8a8f270d5c6778b256fd2933180802eb7a0a175b333.

before/ and after/ preserve exact source bytes. flattened-producer-before-pins.json records the original source and 13 immutable oracle JSON files per variant. flattened-producer-pins.json records before/after/patch hashes and confirms all 13 existing oracle JSON files remain byte-identical in both variants. No existing oracle JSON was written.

Parent must append the new source path and the three changed test-source hashes to its relevant guard manifests before building. This child did not modify manifests.

## Parent-owned capture invocation

Exact ignored test filter:

plan::audio_owners::tests::legacy_snapshot_v1::flattened_query_baseline::capture_old_flattened_query_baseline_v1

Pinned deadpan-plan test executable arguments:

--exact plan::audio_owners::tests::legacy_snapshot_v1::flattened_query_baseline::capture_old_flattened_query_baseline_v1 --ignored --nocapture

Required environment:

- DEADPAN_FLATTENED_QUERY_OUTPUT: a new absolute output under canonical /tmp.
- DEADPAN_FLATTENED_QUERY_VARIANT: main-inherited or scoped-published.
- DEADPAN_FLATTENED_QUERY_SOURCE_SHA256: 64 hex digits for that exact OLD runtime-source manifest.

Use distinct data-output and runner-receipt names, for example:

- main-flat-query-old-v1.json and main-flat-query-old-v1-runner.json
- scoped-flat-query-old-v1.json and scoped-flat-query-old-v1-runner.json

The output is opened create_new and synced. The path's parent must already exist. A failed capture can leave its newly created output incomplete; use a new output name for another attempt and retain the failed artifact. No output data bytes or runtime pass are claimed until parent executes the pinned binaries.

Compare the complete parsed Main/Scope bodies after removing only top-level variant and source_sha256. No query fields, work, lookup, error labels, request ranges or setup identities should be normalized.

## Matrix and future test APIs

Module: crate::plan::audio_owners::tests::legacy_snapshot_v1::flattened_query_baseline.

pub(in crate::plan) APIs:

- matrix() -> serde_json::Value: ordinary logical matrix with six parent records.
- visit_cases(impl FnMut(wide_baseline::Parent<'_, '_>, &Value)): borrows the actual reconstructed parent and its descriptor, for future admitted differential consumers.
- query_snapshot(&AudioQuery) -> Value: complete logical output, including explicit canonical work and all three lookup counters.

The six actual parents are:

1. source_repeat_nested_preserve_root, from the existing storage-test fixture().
2. repeat_root_all_five_spans, through the checked immutable wide visitor.
3. repeat_actual_default_gap_domain_full, through the same checked visitor.
4. fractional_actual_physical_capture_domain, through the same checked visitor.
5. cropped_group_domain_with_inherited_edit_retime, through policy_binding_baseline::visit_additional.
6. hidden_signed_partition_group_with_unrelated_binding, through visit_additional, with physical range -3..13.

Root identity, complete physical Domain seed/setup identity and the reused validated documents are retained where available. The storage fixture is identified by its pinned constructor source and actual plan header/root, without duplicating its constructor or manufacturing a Domain.

Every parent has default full/clipped/empty, exact canonical work, one-short positive canonical work, invalid zero work, invalid zero spans, outside-before and outside-after observations. Every multi-span full query additionally receives an insufficient positive span limit. There are 54 fixed observations plus one such span-limit observation per qualifying parent; runtime output determines that extra count.

Complete AudioQuery, AudioSpan, AudioBoundaries, AudioBoundaryOrigin and LookupStats are destructured exhaustively. The serializer includes every span field, explicit false placement_support, grid rounding parity via the existing logical helper, owning source content and full ordered nested values. It does not depend on AudioQuery Serialize, which skips work.

Failed constructors retain their exact typed PlanError observation and partial_work = "not exposed by the ordinary constructor error". No partial-work number, budget guess, refund or fabricated zero is recorded. Separate setup owner queries are not included in measured ordinary query work.

## Validation and limits

Targeted rustfmt with skip_children=true parsed/formatted only the new producer. Static guards verified the exact three permitted anchor replacements against saved originals; all four changed files match across variants; all 13 existing oracle JSON files match their before hashes. Parent owns semantic compilation and execution.

This is a logical/canonical-work/error oracle. Serializer allocations, document reconstruction and setup captures make it unsuitable as allocator or construction-peak evidence. Once captured, preserve the OLD output and producer authority; do not regenerate expected values from an admitted or factored constructor.
