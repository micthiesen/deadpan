# Host flattened-admission lifecycle test candidate

Scratch-only, 2026-10-29. Nine tests in two new files. No actual repository writes, Cargo, native execution, Git, or production changes were performed. Rustfmt parsed/formatted both scratch files with edition 2024 and skip_children=true. Parent owns compilation and execution.

## Apply and wire

Apply `host-tests-main.patch` or `host-tests-scoped.patch`. These patches add only the two new files and intentionally do not edit any existing worker-owned file. Candidate files are under `host-tests-candidate/{main,scoped}/crates/deadpan-audio/src/`.

The parent or owning worker appends `host-tests-original-request-module.rs` to `src/original_request/tests.rs`:

```rust
#[path = "flattened_admission_tests.rs"]
mod flattened_admission;
```

This nests the test file under original_request::tests so it can reuse the existing private real-WAV fixture, Provider, and work_control without changing visibility or duplicating fixtures.

Append `host-tests-shared-eq-module.rs` to `src/shared_eq/cached_prediction_baseline.rs`:

```rust
#[path = "flattened_original_admission_tests.rs"]
mod flattened_original_admission;
```

This nests its tests under the existing fixture producer, so they reuse its private real checked fixture, Graph constructor, WorkControl helper, exact bit/mask serializer, and actual phase trace. Both existing parents are already gated to tests on macOS/Linux. Neither declaration needs extra cfg or public visibility.

`host-tests-pins.json` pins both candidate files per variant and the relevant integrated source versions observed while authoring. Source pins are reference evidence, not overwrite authority over concurrent changes. Main/Scoped new files are identical.

## Test filters

Original-request filter:

`original_request::tests::flattened_admission::`

- `flattened_request_lease_is_live_during_real_source_io_and_dies_before_returned_pcm`
- `flattened_unused_and_failed_prepared_requests_release_live_real_ledger_charge`
- `flattened_foreign_readwork_is_refused_before_query_read_and_source_admission`
- `flattened_live_charge_reduces_actual_required_pcm_reservation_room`
- `flattened_later_processing_failure_drops_earlier_flattened_lease_without_refunding_work`

Shared-EQ filter:

`shared_eq::cached_prediction_baseline::flattened_original_admission::`

- `flattened_lease_remains_live_inside_actual_policy_population_then_releases_after_numeric_read`
- `flattened_prepared_late_cache_hit_drops_unused_query_lease_and_preserves_cached_arc`
- `flattened_prepared_late_hit_foreign_ledger_is_refused_before_cache_or_source_io`
- `flattened_early_warm_probe_skips_all_query_construction_and_retains_no_query_lease`

## Evidence each test demands

All ownership tests use the production sound_context_admission::Admission and real ReadWork. No replacement lease policy or synthetic memory ledger is present.

Root and Domain preparations retain positive sound_context_frames after the short mutable adapter is gone. A forwarding real-WAV provider asserts positive retained charge inside actual numerical source admission. Consuming the prepared request releases metadata before its returned PCM is dropped. Independent cases cover unused drop, cancellation, timeout, depth refusal, and source refusal; every return has zero metadata charge and preserves spent work.

Foreign ReadWork tests require the exact issuer mismatch before source/dependency preflight and prove that the old ledger is released independently of the foreign one. The direct read test bills exactly the new issuer comparison. The shared late-hit test warms a real cache first, then verifies foreign request refusal before source/cache access and without publishing another input.

The required-PCM test uses actual StageAudio::reserve(1,1), whose normal resident demand is three stereo frames. With a live query, a ceiling one frame below query-plus-PCM refuses the required reservation. Dropping the query makes the identical required reservation succeed. It observes existing conservative per-reservation frame rounding, not a byte/RSS estimate.

The later-constructor test measures the actual flattened receipt and the existing processing receipt, then supplies one unit below their sum. The flattened constructor completes; the actual later ordinary processing constructor fails internally. Its existing failed-call work receipt behavior remains intact while all earlier flattened ownership is released.

The actual policy-population test builds routes from the checked parent, passes request.queries() as OriginalPolicy::Queries, and observes the live flattened charge inside the real populate selection callback. It then runs the numerical read and independently checks prediction against observed masks before dropping returned PCM.

The late-hit test proves the prepared cold request has positive charge before the actual lookup returns the already cached Arc and zero afterwards. It also preserves mandatory source readmission and the published input identity.

The early warm test runs the real read_shared_program twice. Cold Queries work must be positive. Warm Queries work in both lanes and Queries scope calls must be exactly zero; OriginalRead work is zero; Probe work/calls are positive. Real source admission still occurs, publication identity stays fixed, exact PCM/masks are equal, and final live metadata is zero.

## Explicit limits

No test success is claimed until parent execution. The later-processing test deliberately asserts processing_work > 1 so that its refusal occurs inside the later constructor; do not remove that assertion if a fixture proves unsuitable. Use an existing more complex fixture/request instead.

There is no allocator/RSS peak claim, no replacement model of Graph ownership, and no test-only production hook. The early warm test observes exact absence of the production Queries scope/construction plus zero retained ledger charge; it does not assert the aggregate ledger is zero during every warm callback, because other legitimately admitted metadata can coexist. The positive policy observation is the actual Original-selection callback inside populate, with the request's borrowed Queries, rather than a new general callback inserted into production.

These tests cover real Root/Domain Original requests. They do not close unadmitted processing/policy/fade construction peaks or widen the accepted product claim.
