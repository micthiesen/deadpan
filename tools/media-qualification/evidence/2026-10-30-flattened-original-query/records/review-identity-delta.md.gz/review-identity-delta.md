# Review: flattened asset Layout delta and default fixture provenance

Static review, 2026-10-30. No actual repository writes, Cargo, native execution, or Git. Parent reported the targeted Scope test passed; this review does not add execution evidence.

## Verdict

No material correctness or default-fixture provenance issue found. The differential histogram assertion is stronger than an absolute count at a padded Layout size because unchanged allocations sharing that size cancel.

Reviewed identical Main/Scope files:

- crates/deadpan-plan/src/audio_allocated/query_storage_tests.rs, SHA256 8225f4d7a0661c197c03f4160f096f8f5813e85ed620319e372adb7fec6cc31d
- crates/deadpan-plan/src/audio_owners/flattened_query_admission_tests.rs, SHA256 7934fd55cd19eda744fe61a2ad1031a9020d0b019be305eabbdb51b70e408a69

The fixture diff was inspected against before/main/crates/deadpan-plan/src/audio_allocated/query_storage_tests.rs, not inferred from the new test's success.

## Default fixture

query_storage_tests.rs:55 fixture delegates to fixture_with_asset(source().asset). The helper reconstructs the same SourceAudio and replaces only its asset with the parameter. With the default parameter, asset text, source timestamps/time base, mapping, node graph, Repeat order, retime descriptors, project/revision, asset map and qualification remain the same as before.

The body changes replace repeated source() calls with one local SourceAudio used for the node audio, natural-rate mapping, asset-map key and asset audio span. Those old repeated calls were pure identical constructors. The refactor passes the same serialized node/asset values into the existing ProjectDocument JSON round trip and compilation. Any changed temporary Arc sharing before serialization cannot establish a new compiled logical fact or alter the query's per-owning-edge accounting.

The fixture's logical OLD observations therefore remain independently checkable against the frozen matrix. This refactor changes current source hashes; it must not replace the recorded pre-change source-manifest hashes or refresh OLD snapshots. The current test does neither.

## Layout delta

flattened_query_admission_tests.rs:548 flat_arc_str_layout independently expresses the Arc string storage layout using the two usize counters, str payload layout and tail padding. It matches the supported accounting convention while remaining independent of the production identity helper. It does not hard-code the host's padded size or assume source text bytes alone describe ownership.

The test at :557 builds structurally equal plans with asset IDs catalog-sound and a 107-character long-asset string. For each it obtains the actual ordinary full Root query, asserts exactly two spans, and asserts both are Source content with that exact asset. Thus the expected two independent owning source edges are established from actual query content.

It records the entire successful admitted reservation histogram by (size, alignment), then predicts the long-ID histogram by subtracting two old identity layouts and adding two new layouts. All unchanged allocations remain in the expected histogram. A collision with another identity or vector layout therefore cancels instead of inflating the expected edge count.

A missing reservation at either or both source edges, a short-ID layout incorrectly reused for the long ID, or extra asset-dependent reservations changes the observed delta and fails this assertion. An absent/insufficient short bucket also fails through unwrap/subtraction rather than silently accepting a malformed receipt. Both carriers are dropped and the production policy ledger is checked for zero live charge.

The test intentionally certifies requested Layout callbacks for these two source-owning edges. It is not an allocator/RSS measurement or a full separate long-ID query semantic oracle. The existing frozen-field tests supply the broader default-query equality check.

## Remaining verification

Parent's full Plan run is still the appropriate pending check. Preserve the literal OLD matrix and its original source provenance. No test or production adjustment is requested by this static review.
