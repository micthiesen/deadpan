# Native pressure tests: measured flattened metadata

Scratch-only changes in the two assigned native tests plus approved new
tests/stages/flattened_metadata.rs. Parent wires only the two-line declaration
in native-pressure-stage-module-fragment.rs into the current tests/stages.rs.
No whole stages.rs copy, production change, global cap change, actual source
write, Cargo/native/Git execution, golden write, or old oracle regeneration.

## Actual layout witness

The shared test helper executes RenderPlan::audio_admitted using a real public
AudioSoundContextAdmission policy. Every actual reserve callback independently
rounds Layout.size up to stereo f32 frames, exactly size.div_ceil(8), as the host
does. The live sum and peak include old/replacement vector buffers, partial
headers and all simultaneous constructor leases. Each returned lease owns only
its charge, merge disarms its source without releasing the combined amount,
and Drop subtracts that lease's remaining frames.

The helper checks forwarded work against the actual immutable query total,
canonical+additional decomposition, positive actual reservations, positive
retained metadata, peak >= retained, and zero live charge after query Drop.
Its ledger is a stack object with Cell counters and borrowed independent
leases, not a fabricated reservation or a post-measured production admission.
No metadata bytes are estimated from shallow structs or guessed weights.

## Exact gain boundary

The simple gain fixture's processing query is nonempty and every span is Leaf
Source, excluding recursive Original requests. The actual gain path reserves
3*256 PCM frames before invoking its single Root flat factory. Therefore the
measured flat construction peak is simultaneous with that complete 768-frame
PCM reservation. Other query constructors remain explicitly unadmitted in this
slice.

The old literal 767 and 768 limits both must refuse resident admission before
provider I/O. 767 preserves the original insufficient-PCM evidence; 768 now also
lacks the real flat metadata charge. The positive case receives exactly
3*256 + measured construction peak; its one-frame-short counterpart must refuse
before provider I/O. At the exact aggregate cap, the first and repeated authored
read must equal the entire ample-budget expected PCM. No fourth PCM conversion
allocation is granted, and no arbitrary slack is introduced. The existing test
name is retained; its exact three-frame statement refers to PCM, with the
separate actual flat metadata demand made explicit in the code.

## Fixed streaming bound

The four-minute fixture is proved to have one root Preserve stage. Querying its
actual full input signal yields multiple spans, all Leaf Source, with the exact
declared INPUT sample count. The source-read branch of read_signal_queries does
not call an Original factory. This excludes nested simultaneous flat carriers
for this fixture; there is exactly the outer Root query held through native
stage preparation.

The helper measures every actual Root request window: the late first 173-frame
request, cold terminal 73-frame request, and all sequential chunks through the
complete output. Both retained and construction maxima must be identical for
the finite short and four-minute plans. Thus the chosen added metadata amount
is a per-request bound for these two histories, not a sum proportional to their
output lengths.

The cap remains the old fixed two input windows + 2048-frame file buffer, plus
that measured flat construction peak. The outer query's retained charge
coexists with streaming PCM; using its larger construction peak is conservative.
This is a fixed sufficient bound, not a claimed minimum. It is asserted smaller
than both total INPUT and four-minute output.

The old PCM-only cap must still refuse before source I/O, with no cached stage.
Under the measured aggregate bound the entire existing canonical comparison,
every sequential output chunk, terminal cold-controller reconstruction, exact
disk size and zero cached resident frames remain unchanged. StageAudio still
retains no complete memory output. The oracle's expected Vec is test-only and
already existed before this change.

## Verification and gap

Targeted rustfmt parsed/formatted only the three candidate files in each
variant. The full diffs were inspected. native-pressure-scope-proof.json checks
that every byte outside the two assigned test functions is unchanged. Main and
Scope candidates/patches are byte-identical, and actual source hashes were still
equal to before copies at freeze.

Parent must compile and execute both native tests. In particular it must verify
the asserted short/long equality and exact gain aggregate boundary. No numeric
metadata peak or behavioral pass is claimed before that run. The fixed-memory
claim is bounded to these actual unbound fixtures; arbitrary Bound/nested
Original requests would require observing their simultaneous carrier stack and
cannot reuse this single-carrier bound. Processing/policy/fade query peaks
remain the separately named unadmitted work.
