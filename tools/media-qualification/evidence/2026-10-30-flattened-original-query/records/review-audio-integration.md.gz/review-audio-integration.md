# Audio integration review

Reviewed both exact patches and the current production originals named in scope: original_request.rs, shared_eq/original_inputs.rs, shared_eq/policy_prediction.rs, cached_prediction_trace.rs, and cached_prediction_baseline.rs. No material resource, issuer, error-release, work-accounting, cache-bypass, or semantic-drift finding identified.

The admitted query's issuer and lease both point to the same RefCell<ReadWork> selected by WorkControl. Admission's short mutable StageAudio borrow ends before the request is returned; its lease remains owned by AdmittedAudioQuery. The query is borrowed for prediction and read, and read_prepared_original drops the whole request immediately after read_queries_borrowed returns, including on error through normal drop paths. Preparation failures after flattened construction likewise drop the local flattened carrier. A late Original cache hit drops an unused prepared request on return; the early cached prediction hit avoids preparation and therefore avoids the new query lease. Constructor work is forwarded during admission and is not re-billed from flattened.work.

The test-only legacy path is confined to thread-local RAII scopes and restores nested prior state. cached_prediction_baseline's independent query oracle explicitly enters that path. The two patch files differ only in contextual line offsets in cached_prediction_baseline.rs.

One small cost is duplicated issuer validation on the cold prepared path: validate_original calls PreparedOriginalRequest::validate_issuer, then read_prepared_original validates the same request against the same copied WorkControl again. Both checks bill one plan-work unit. This is safe and is not a correctness finding; it adds two units per normal cold read and can affect a request exactly at the work cap.

Limits: static review only. No Cargo/typecheck, test, native execution, or concurrent runtime observation. The candidate remains scoped to flattened AudioQuery construction/admission; processing, policy, and fades remain unadmitted.
