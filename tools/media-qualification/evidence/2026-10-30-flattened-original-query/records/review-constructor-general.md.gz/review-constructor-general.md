# General constructor review

Reviewed the scratch-only candidate at constructor-candidate/{main,scoped} against its pinned before copies, with constructor-rationale.md and cold-query-admission-design.md as scope. No material correctness, heap-peak, error-lifetime, or carrier-closure finding identified.

The outer assembler keeps each span and the output buffer before their independent charges, reserves a full replacement while the prior buffer and current/prior span contents remain live, and moves the actual generic walk's guarded Leaf into the result without a detach/callback gap. Header identity helpers reserve before cloning and execute after spans, preserving the old constructor point/order. The completed carrier keeps the immutable query before its payload memory; ordinary constructors route through the unmetered backend.

The narrow flattened_leaf extraction combines the walk result and actual capture memory before matching, checks both issuers, accepts only Legacy(Leaf(_)), and returns errors with rejected values still guarded. The generic Build's declaration order also keeps optional header values and span contents ahead of both payload and capacity memory on failure.

Limits: this was a textual/static review. I did not run Cargo, typechecking, tests, native execution, allocator measurements, or compare candidate outputs against frozen captures. The candidate has no production integration yet. Root processing, Domain processing/policy, and fades remain outside this constructor's closure as the rationale states.
