# Flattened query constructor candidate

Scratch-only candidate, 2026-10-29. No Cargo, native execution, Git, or actual repository edits were performed by the constructor worker.

## Frozen API

- `AdmittedAudioQuery<I,L>` has private fields and no Clone, mutable query, lease accessor, public constructor, charge transfer, or public detach. `query()` borrows `&AudioQuery`; `work()`, `canonical_units()`, `additional_units()`, and `was_forwarded()` follow the admitted owner-query convention.
- `RenderPlan::audio_admitted<A: AudioSoundContextAdmission>(&self, Range<AudioSample>, AudioQueryLimits, &mut A) -> Result<AdmittedAudioQuery<A::Issuer,A::Lease>,A::Error>`.
- `AudioDomain::audio_admitted<A: AudioSoundContextAdmission>` has the same arguments/result.
- The only owned-query extraction is crate-internal and restricted to `AdmittedAudioQuery<(),()>`, matching existing compatibility carriers.
- Root library reexport is one standalone `pub use plan::AdmittedAudioQuery;`. `audio.rs` declares/reexports its child module. No `plan.rs` edit is needed.

## Construction and compatibility

Both old `audio()` entrypoints instantiate the existing owner-query `Unmetered` and invoke their actual admitted constructor. Root validation keeps limits, then root range/audio_duration checks in the original order. Domain keeps its existing `budget(&samples, limits)` validation. Both call one generic outer assembler.

The assembler calls the actual `audio_walk_inner_admitted` with both stop flags false and every optional capture absent. It uses the unchanged clipping expression and span order. `Budget::grow` runs only after each actual current span exists and before output push. Its metered backend reserves a full replacement before allocation, retaining the old buffer and prior/current contents; its false backend remains a no-op followed by the original `Vec::push` allocator behavior.

Header project/revision ownership is created via existing Budget helpers at the original end-of-query point, in original order. Partial headers, prior spans, payload memory, and replaceable buffer memory live together in a named value-before-memory Build struct on all fallible transitions. At completion, payload and capacity memories merge into `Owned<AudioQuery>`. Canonical plus additional units use checked addition and are reconciled against the local allowance actually consumed. The carrier's `work()` reads exactly the immutable query's total `work` field. Unmetered additional work stays zero.

## Narrow extraction

`WalkResult::flattened_leaf` delegates only to a specialization for `GuardedBound<AudioWalkSpan>`. The specialization first combines the entire result and actual Plan memory in a value-before-memory `Owned` guard and validates both issuers. It matches only the closed `Legacy(Leaf(span))` shape. Success moves that leaf without allocating or invoking callbacks, merges actual Plan memories, and checks the resulting owned guard. Any Stage or metered Core payload is rejected while the entire rejected value remains before both guards. No Core API, generic unchecked unwrap, callback escape, or metered `.unmetered()` was introduced.

The metered-Core rejection has the new explicit label `flattened audio retained a metered binding`; the existing Stage rejection remains `flattened audio retained a stage`. Stage/Core shapes are impossible for the selected walk flags, but are still fail-closed.

## Candidate files and verification

`constructor-before/{main,scoped}` contains the exact current originals of the six owned existing paths. `constructor-before-pins.json` pins these copies. `constructor-candidate/{main,scoped}` contains only the six existing production paths plus the new `audio_flattened_query.rs`.

`constructor-main.patch` and `constructor-scoped.patch` are exact unified patches; `constructor-candidate-pins.json` records original/candidate SHA-256 for each path. The script `build_constructor_candidate.py` records the initial transformation, but the final candidate files/patches are authoritative because review refinements followed that initial script.

Rustfmt parsed/formatted all changed Rust code in scratch with `--edition 2024 --config skip_children=true`. The narrow standalone lib reexport is intentionally preserved without whole-file reordering. No typecheck, behavioral test, native run, allocator observation, or old-versus-new qualification is claimed. Parent owns those checks after OLD captures and integration.

## Remaining scope

No open constructor design questions. Parent must typecheck the candidate, compare frozen ordinary observations, and test metered peaks/errors/issuer behavior. Full Original processing, policy, and fade constructor peaks remain open and are explicitly named as separate in the admission trait module documentation. There are no query caches, Graph packs, DSP changes, limits/weight changes, refunds, or retention APIs in this patch.
