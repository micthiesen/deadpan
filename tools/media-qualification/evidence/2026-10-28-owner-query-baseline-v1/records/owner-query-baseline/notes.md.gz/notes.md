# Frozen old-query SnapshotV1 harness, first compile candidate

Base source HEAD reported296f2b894ccc4c32c5c6abc09db0d0bba2263f20. This worker has
not changed main/scoped/index/kernel code, run Cargo/rustc, opened any media,
created native state or generated ANY expected golden. Candidate is5 test files,
3 new, under existing private Plan/Audio test trees. Production source untouched.

harness.patch applies cleanly to scratch copies of both main and scoped existing
test files. Their inherited Core/Plan product variants remain separate. Runtime
source authority manifests cover expected1441 main/1212 scoped inputs after
harness overlay, including all existing parent guard inputs. Twenty source paths
are copied/pinned per variant under harness/runtime-kernel-snapshots. Fixture
constructors and logical serializer are pinned separately.

## Output protocol

Plan ignored test suffix: capture_legacy_snapshot_v1.
Required environment:
- DEADPAN_OWNER_SNAPSHOT_OUTPUT: an explicit absolute /tmp JSON path, not existing.
- DEADPAN_OWNER_SNAPSHOT_VARIANT: main-inherited or scoped-published.
- DEADPAN_OWNER_SNAPSHOT_SOURCE_SHA256: SHA of matching runtime authority manifest.

Audio ignored test suffix: capture_legacy_query_workcontrol_receipts_v1.
Same variant/source environment, with DEADPAN_OWNER_WORK_OUTPUT for its separate
explicit output. Parent should build lib-only Plan+Audio, pin executable/source
inputs first, then invoke each ignored test once with one exact filter. These
tests are ignored in ordinary test runs.

Both producers use OpenOptions.create_new(true), refusing to overwrite any
previous JSON. They emit no pointer, Debug, raw bytes or allocation-capacity
identity. Ratio numerators/denominators are normalized base10 integer strings.
Only logical field names are serialized. The private grid parity scalar comes
from the existing Serialize contract, because no product getter is exposed.

Do NOT run this producer against future query wrappers to refresh expected
values. Parent must retain JSON+SHA and matching exact OLD executable/source/
fixture receipts before anyone edits query kernels. A compiled old binary
without this exact harness does not count. No oracle has been captured yet.

## Prepared logical matrix, not runtime-qualified yet

Plan SnapshotV1 records actual old ordered window query and separate one-sample
query; old observation selects member index first, then old owner_input;
pre-admission candidates/capture must reproduce that independently selected
member. It records every owner provenance/play/affine field and all private
captured Domain/seed fields, stable NodeIds replacing private node indices,
query/capture/Input/probe work and exact/one-short local error behavior.

Fixtures reuse audio_owners/tests.rs checked constructors:
- root Sequence/Tone and actual captured Tone Domain; seeded invalid range,
  reversed range and invalid limits; foreign Plan rejection;
- stable Repeat default gap, separate play/gap overrides, coarse-equal whole
  Repeat observations with distinct play records; wrong Repeat branch refuses;
- literal resumed binding counterexample from input_tests.rs: actual retained
  Root Domain at labels3..4 differs from live root and rejects substitution.
  It asserts a coarse identity collision but different provenance/affine.
- moved PointCeil fixture with nonunity Shift, fractional32k presentation grid
  and source timebase1/44100; source planning metadata only, no provider authority.
- actual public Source Split with RootRoundEven retained input and clipped
  query window, plus actual captured Domain. Main/scoped outputs are labeled,
  not presumed equivalent when inherited Core behavior differs.

Audio output separately records actual original_context WorkControl debits:
Root, actual Domain and accepted Retained, ample and exact/one-short total/Q/C
allowance, real typed error and before/after/prefix counters. Q/C/probe numbers
are measured independently before numerical helper invocation. Legacy Plan
errors themselves provide success-only receipts; Plan JSON labels prefix
billing accordingly, rather than inventing internal failure receipts.

Potential first-runtime fixture diagnostics may still require correction. No
minimum matrix completion or baseline qualification claim is made before parent
runs both actual executables. Any correction must be separately pinned before
single-use golden capture, never justified from a future query implementation.
