from pathlib import Path
r=Path('/tmp/deadpan-owner-query-baseline-2026-10-28')
repo=Path('/Users/michael/Code/deadpan')
scope=Path('/tmp/deadpan-query-groundwork-2026-10-26/scoped')
path=Path('crates/deadpan-audio/src/shared_eq/node_description_tests.rs')
for label,base in [('before',repo),('scoped-before',scope)]:
 p=r/label/path;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes((base/path).read_bytes())
p=r/'candidate'/path;p.parent.mkdir(parents=True,exist_ok=True)
p.write_text((repo/path).read_text()+'\n#[path = "legacy_query_receipts.rs"]\nmod legacy_query_receipts;\n')
