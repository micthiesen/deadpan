use std::collections::BTreeMap;

use deadpan_core::*;
use deadpan_plan::{
    AudioBoundaryRule, AudioContent, AudioQueryLimits, AudioReferencePlan, AudioSignalContent,
    PlanError, ReferenceAudioContent, ReferenceAudioSpan, ReferenceProcessingKind, ReferenceSample,
    RenderPlan, SignalSample, SilenceReason,
};

fn id(name: &str) -> NodeId {
    NodeId::new(name).unwrap()
}
fn duration(frames: i64) -> FrameDuration {
    FrameDuration::new(frames).unwrap()
}
fn ratio(n: i128, d: i128) -> ExactRatio {
    ExactRatio::new(n, d).unwrap()
}
fn samples(start: i64, end: i64) -> std::ops::Range<ReferenceSample> {
    ReferenceSample(start)..ReferenceSample(end)
}
fn instance(name: &str) -> InstancePath {
    InstancePath {
        node: id(name),
        repeats: Vec::new(),
    }
}

fn audio() -> SourceAudio {
    let time_base = SourceTimeBase::new(1, 48_000).unwrap();
    SourceAudio {
        asset: AssetId::new("original").unwrap(),
        span: SourceSpan::new(
            SourceTimestamp {
                ticks: 0,
                time_base,
            },
            SourceTimestamp {
                ticks: 48_000,
                time_base,
            },
        )
        .unwrap(),
    }
}

fn source(frames: i64) -> BeatNode {
    BeatNode {
        label: "Original".into(),
        framing: None,
        audio_treatments: Default::default(),
        audio_editorial_edges: Default::default(),
        audio_edges: Default::default(),
        kind: NodeKind::Source {
            source: SourceNode {
                edit_window: None,
                duration: duration(frames),
                video: SourceVideo::Blank,
                video_mapping: SourceVideoMapping::FitBeat,
                audio: Some(audio()),
                audio_mapping: SourceAudioMapping::FitBeat,
                audio_offset: AudioSample(0),
                link: LinkRelation::Independent,
            },
        },
        cutaways: Vec::new(),
        captions: Vec::new(),
    }
}

fn hold(frames: i64, audio: HoldAudio) -> BeatNode {
    BeatNode::hold(
        "Policy",
        HoldRecipe {
            duration: duration(frames),
            video: HoldVideo::Background,
            picture_context: None,
            audio,
        },
    )
}

fn retime(child: &str, frames: i64, start: i64, end: i64, pitch: PitchPolicy) -> BeatNode {
    BeatNode {
        label: "Retime".into(),
        framing: None,
        audio_treatments: Default::default(),
        audio_editorial_edges: Default::default(),
        audio_edges: Default::default(),
        kind: NodeKind::Retime {
            child: id(child),
            duration: duration(frames),
            mapping: FrameRange::new(ProjectFrame(start), ProjectFrame(end)).unwrap(),
            pitch,
            purpose: RetimePurpose::Edit,
        },
        cutaways: Vec::new(),
        captions: Vec::new(),
    }
}

fn document(rate: FrameRate, children: &[&str], nodes: Vec<(&str, BeatNode)>) -> ProjectDocument {
    try_document(rate, children, nodes).unwrap()
}

fn try_document(
    rate: FrameRate,
    children: &[&str],
    nodes: Vec<(&str, BeatNode)>,
) -> Result<ProjectDocument, DocumentError> {
    let empty = ProjectDocument::new(
        ProjectId::new("reference-project").unwrap(),
        RevisionId::new("initial").unwrap(),
        PresentationBasis {
            width: 640,
            height: 360,
            frame_rate: rate,
            color_policy: ColorPolicy::SdrRec709,
        },
        id("root"),
    )
    .unwrap();
    let mut nodes: BTreeMap<_, _> = nodes
        .into_iter()
        .map(|(name, node)| (id(name), node))
        .collect();
    nodes.insert(
        id("root"),
        BeatNode::sequence("Edit", children.iter().map(|name| id(name)).collect()),
    );
    let mut wire = serde_json::to_value(empty).unwrap();
    wire["nodes"] = serde_json::to_value(nodes).unwrap();
    wire["assets"] = serde_json::to_value(BTreeMap::from([(
        audio().asset,
        AssetRecord {
            label: "Original".into(),
            content_hash: "a".repeat(64),
            video: None,
            audio: Some(audio().span),
            still_image: true,
            frame_count: None,
            source_qualification: None,
        },
    )]))
    .unwrap();
    ProjectDocument::from_json(&wire.to_string())
}

fn compile(document: &ProjectDocument) -> AudioReferencePlan {
    AudioReferencePlan::compile(&FrozenAudioLayout::capture(document).unwrap()).unwrap()
}

fn exact_document(
    document: ProjectDocument,
    clocks: BTreeMap<NodeId, DerivedRetimeClock>,
) -> ProjectDocument {
    let mut wire = serde_json::to_value(document).unwrap();
    wire["derived_clocks"] = serde_json::to_value(clocks).unwrap();
    ProjectDocument::from_json(&wire.to_string()).unwrap()
}

fn exact_clock(extent: ExactRatio) -> DerivedRetimeClock {
    DerivedRetimeClock {
        extent,
        child_start: ExactRatio::ZERO,
        child_end: ratio(2, 1),
        preserve_input: None,
    }
}

#[test]
fn exact_frozen_follow_speed_matches_live_allocation_and_absolute_sample_phase() {
    for first in [ratio(1, 2), ratio(1, 3), ratio(17, 31), ratio(5, 4)] {
        let doc = document(
            FrameRate::new(30_000, 1001).unwrap(),
            &["first", "last"],
            vec![
                ("first", retime("a", 1, 0, 2, PitchPolicy::FollowSpeed)),
                ("last", retime("b", 1, 0, 2, PitchPolicy::FollowSpeed)),
                ("a", source(2)),
                ("b", hold(2, HoldAudio::Silence)),
            ],
        );
        let mut clock = exact_clock(first);
        clock.child_start = ratio(1, 4);
        clock.child_end = ratio(7, 4);
        let doc = exact_document(
            doc,
            BTreeMap::from([
                (id("first"), clock),
                (
                    id("last"),
                    exact_clock(ratio(3, 1).checked_sub(first).unwrap()),
                ),
            ]),
        );
        let frozen = FrozenAudioLayout::capture(&doc).unwrap();
        let frozen = FrozenAudioLayout::from_json(&frozen.to_json().unwrap()).unwrap();
        let reference = AudioReferencePlan::compile(&frozen).unwrap();
        let live = RenderPlan::compile(&doc).unwrap();
        let root = reference.root_clock();
        assert_eq!(root.sample_count().unwrap(), ReferenceSample(4805));
        let cut = root.grid().boundary(first).unwrap().0;
        for range in [
            samples(0, 4805),
            samples(cut - 1, cut + 1),
            samples(cut, 4805),
        ] {
            let expected = live
                .audio(
                    AudioSample(range.start.0)..AudioSample(range.end.0),
                    Default::default(),
                )
                .unwrap();
            let actual = root.query(range, Default::default()).unwrap();
            assert_eq!(expected.spans.len(), actual.spans.len());
            for (old, current) in actual.spans.iter().zip(&expected.spans) {
                assert_eq!(old.content, policy(&current.content));
                assert_eq!(
                    old.allocated_samples,
                    samples(
                        current.allocated_samples.start.0,
                        current.allocated_samples.end.0
                    )
                );
                assert_eq!(old.extent, current.project_extent);
                assert_eq!(old.instance, current.instance);
            }
        }
        let start = root
            .processing_domain_at(ReferenceSample(0), Default::default())
            .unwrap();
        assert_eq!(start.local_at(ReferenceSample(0)).unwrap(), ratio(1, 4));
        let end = root
            .processing_domain_at(ReferenceSample(cut), Default::default())
            .unwrap();
        assert_eq!(end.instance().node, id("b"));
    }
}

#[test]
fn exact_frozen_repeat_queries_remain_compact_at_a_billion_plays() {
    let mut repeated = BeatNode::sequence("Repeat", vec![]);
    repeated.kind = NodeKind::Repeat {
        child: id("first"),
        iterations: IterationOrder::new(RevisionId::new("exact-plays").unwrap(), 1_000_000_001)
            .unwrap(),
        gap: None,
        escalation: None,
    };
    let doc = document(
        FrameRate::new(30_000, 1001).unwrap(),
        &["repeat", "last"],
        vec![
            ("repeat", repeated),
            ("first", retime("a", 1, 0, 2, PitchPolicy::FollowSpeed)),
            ("last", retime("b", 1, 0, 2, PitchPolicy::FollowSpeed)),
            ("a", source(2)),
            ("b", hold(2, HoldAudio::Silence)),
        ],
    );
    let doc = exact_document(
        doc,
        BTreeMap::from([
            (id("first"), exact_clock(ratio(1, 2))),
            (id("last"), exact_clock(ratio(1, 2))),
        ]),
    );
    let reference = compile(&doc);
    let root = reference.root_clock();
    let cut = root.grid().boundary(ratio(1_000_000_001, 2)).unwrap().0;
    let before = root
        .processing_domain_at(ReferenceSample(cut - 1), Default::default())
        .unwrap();
    assert_eq!(
        before.instance().repeats[0].iteration.ordinal,
        1_000_000_000
    );
    assert!(before.lookup().visited_nodes < 10);
    let after = root
        .processing_domain_at(ReferenceSample(cut), Default::default())
        .unwrap();
    assert_eq!(after.instance().node, id("b"));
}

#[test]
fn exact_historical_layouts_cannot_enter_legacy_processing_paths() {
    let doc = document(
        FrameRate::new(30, 1).unwrap(),
        &["stage"],
        vec![
            ("stage", retime("a", 1, 0, 2, PitchPolicy::FollowSpeed)),
            ("a", source(2)),
        ],
    );
    let live = RenderPlan::compile(&doc).unwrap();
    let exact = exact_document(
        doc,
        BTreeMap::from([(id("stage"), exact_clock(ratio(3, 1)))]),
    );
    let frozen = FrozenAudioLayout::capture(&exact).unwrap();
    let assets = std::collections::BTreeSet::from([audio().asset]);
    assert!(
        RenderPlan::sound_processing_layout_work(&frozen, &assets)
            .unwrap_err()
            .to_string()
            .contains("owned output")
    );
    assert!(
        live.compile_sound_processing_layout(&frozen, &assets)
            .unwrap_err()
            .to_string()
            .contains("owned output")
    );
    let mut wire = serde_json::to_value(frozen).unwrap();
    wire["nodes"]["stage"]["kind"]["pitch"] = serde_json::json!("preserve");
    let frozen = FrozenAudioLayout::from_json(&wire.to_string()).unwrap();
    assert!(
        AudioReferencePlan::compile(&frozen)
            .unwrap_err()
            .to_string()
            .contains("owned output")
    );
}

fn policy(content: &AudioContent) -> ReferenceAudioContent {
    match content {
        AudioContent::Source { .. } => ReferenceAudioContent::Source,
        AudioContent::RoomTone { .. } => ReferenceAudioContent::RoomTone,
        AudioContent::Tail {
            maximum,
            effect,
            input,
            ..
        } => ReferenceAudioContent::Tail {
            input: *input,
            maximum: *maximum,
            effect: *effect,
        },
        AudioContent::Reverse { .. } => ReferenceAudioContent::Reverse,
        AudioContent::Tone {
            frequency_hz,
            level,
            ..
        } => ReferenceAudioContent::Tone {
            frequency_hz: *frequency_hz,
            level: *level,
        },
        AudioContent::Silence { reason } => ReferenceAudioContent::Silence { reason: *reason },
    }
}

fn at(spans: &[ReferenceAudioSpan], sample: i64) -> ReferenceAudioContent {
    spans
        .iter()
        .find(|span| span.samples.contains(&ReferenceSample(sample)))
        .unwrap()
        .content
}

#[test]
fn ntsc_old_root_and_preserve_output_keep_both_rounding_phases() {
    for silent_start in [4, 6] {
        let doc = document(
            FrameRate::new(30_000, 1001).unwrap(),
            &["preserve"],
            vec![
                (
                    "preserve",
                    retime("sequence", 6, 0, 12, PitchPolicy::Preserve),
                ),
                (
                    "sequence",
                    BeatNode::sequence("Context", vec![id("a"), id("quiet"), id("b")]),
                ),
                ("a", source(silent_start)),
                ("quiet", hold(2, HoldAudio::Silence)),
                ("b", source(10 - silent_start)),
            ],
        );
        let frozen = compile(&doc);
        let live = RenderPlan::compile(&doc).unwrap();
        let root = frozen.root_clock();
        let output = frozen.preserve_output_clock(&instance("preserve")).unwrap();
        assert_eq!(root.grid().boundary_rule(), AudioBoundaryRule::RoundEven);
        assert_eq!(output.grid().boundary_rule(), AudioBoundaryRule::PointCeil);
        let root_query = root.query(samples(3000, 6800), Default::default()).unwrap();
        let live_query = live
            .audio(AudioSample(3000)..AudioSample(6800), Default::default())
            .unwrap();
        for (old, current) in root_query.spans.iter().zip(&live_query.spans) {
            assert_eq!(old.content, policy(&current.content));
            assert_eq!(
                old.allocated_samples,
                samples(
                    current.allocated_samples.start.0,
                    current.allocated_samples.end.0
                )
            );
            assert_eq!(old.extent, current.project_extent);
            assert_eq!(old.instance, current.instance);
        }
        assert_eq!(root_query.spans.len(), live_query.spans.len());
        let point_query = output
            .query(samples(3000, 6800), Default::default())
            .unwrap();
        let boundary = if silent_start == 4 { 3203 } else { 6406 };
        let silent = ReferenceAudioContent::Silence {
            reason: SilenceReason::SilentHold,
        };
        if silent_start == 4 {
            assert_eq!(at(&root_query.spans, boundary), silent);
            assert_eq!(
                at(&point_query.spans, boundary),
                ReferenceAudioContent::Source
            );
        } else {
            assert_eq!(
                at(&root_query.spans, boundary),
                ReferenceAudioContent::Source
            );
            assert_eq!(at(&point_query.spans, boundary), silent);
        }
        // Query order and cropping cannot alter full old allocated boundaries.
        for range in [
            samples(6400, 6800),
            samples(3000, 3204),
            samples(3204, 6400),
        ] {
            for partial in root.query(range.clone(), Default::default()).unwrap().spans {
                let full = root_query
                    .spans
                    .iter()
                    .find(|full| full.allocated_samples == partial.allocated_samples)
                    .unwrap();
                assert_eq!(partial.content, full.content);
                assert_eq!(partial.extent, full.extent);
                assert_eq!(partial.instance, full.instance);
            }
        }
    }
}

#[test]
fn preserve_input_uses_selected_origin_and_flattens_nested_policies() {
    let doc = document(
        FrameRate::new(30_000, 1001).unwrap(),
        &["outer"],
        vec![
            ("outer", retime("inner", 6, 1, 13, PitchPolicy::Preserve)),
            ("inner", retime("sequence", 14, 0, 7, PitchPolicy::Preserve)),
            (
                "sequence",
                BeatNode::sequence("Context", vec![id("a"), id("quiet"), id("b")]),
            ),
            ("a", source(2)),
            ("quiet", hold(1, HoldAudio::Silence)),
            ("b", source(4)),
        ],
    );
    let frozen = compile(&doc);
    let live = RenderPlan::compile(&doc).unwrap();
    let clock = frozen.preserve_input_clock(&instance("outer")).unwrap();
    assert_eq!(clock.grid().frame_origin(), ExactRatio::ONE);
    assert_eq!(
        clock.grid().at(ReferenceSample(0)).unwrap(),
        ExactRatio::ONE
    );
    assert_eq!(clock.support(), ExactRatio::ONE..ExactRatio::integer(13));
    let query = clock
        .query(
            samples(0, clock.sample_count().unwrap().0),
            Default::default(),
        )
        .unwrap();
    let processing = live
        .audio_processing(AudioSample(0)..AudioSample(1), Default::default())
        .unwrap();
    let AudioSignalContent::Stage(stage) = &processing.spans[0].content else {
        panic!("outer Preserve")
    };
    let expected = stage
        .input_signal()
        .query_flattened(
            SignalSample(0)..SignalSample(clock.sample_count().unwrap().0),
            Default::default(),
        )
        .unwrap();
    assert_eq!(query.spans.len(), expected.spans.len());
    for (old, current) in query.spans.iter().zip(expected.spans) {
        let AudioSignalContent::Leaf(content) = current.content else {
            panic!("flattened policy")
        };
        assert_eq!(old.content, policy(&content));
        assert_eq!(
            old.allocated_samples,
            samples(
                current.allocated_samples.start.0,
                current.allocated_samples.end.0
            )
        );
        assert_eq!(old.extent, current.signal_extent);
    }
}

#[test]
fn tiny_zero_allocated_leaves_and_source_placement_remain_explicit() {
    let tiny = document(
        FrameRate::new(48_000, 1).unwrap(),
        &["preserve"],
        vec![
            (
                "preserve",
                retime("sequence", 1, 0, 3, PitchPolicy::Preserve),
            ),
            (
                "sequence",
                BeatNode::sequence("Tiny", vec![id("a"), id("quiet"), id("tone")]),
            ),
            ("a", source(1)),
            ("quiet", hold(1, HoldAudio::Silence)),
            ("tone", hold(1, HoldAudio::RoomTone { source: audio() })),
        ],
    );
    let frozen = compile(&tiny);
    let root = frozen
        .root_clock()
        .query(samples(0, 1), Default::default())
        .unwrap();
    assert_eq!(root.spans.len(), 1);
    assert_eq!(root.spans[0].instance.node, id("quiet"));
    assert_eq!(root.spans[0].extent, ratio(1, 3)..ratio(2, 3));
    let point = frozen
        .preserve_output_clock(&instance("preserve"))
        .unwrap()
        .query(samples(0, 1), Default::default())
        .unwrap();
    assert_eq!(point.spans[0].instance.node, id("a"));

    let mut placed = source(10);
    let NodeKind::Source { source } = &mut placed.kind else {
        unreachable!()
    };
    source.audio_mapping = SourceAudioMapping::Placement {
        start: ExactRatio::integer(2),
        frames: ExactRatio::integer(3),
    };
    let doc = document(
        FrameRate::new(48_000, 1).unwrap(),
        &["placed", "tail"],
        vec![
            ("placed", placed),
            (
                "tail",
                hold(
                    2,
                    HoldAudio::Tail {
                        input: Default::default(),
                        maximum: duration(2),
                        effect: Default::default(),
                    },
                ),
            ),
        ],
    );
    let plan = compile(&doc);
    let query = plan
        .root_clock()
        .query(samples(0, 12), Default::default())
        .unwrap();
    assert_eq!(
        query
            .spans
            .iter()
            .map(|span| (span.allocated_samples.clone(), span.content))
            .collect::<Vec<_>>(),
        vec![
            (
                samples(0, 2),
                ReferenceAudioContent::Silence {
                    reason: SilenceReason::OutsideSourcePlacement
                }
            ),
            (samples(2, 5), ReferenceAudioContent::Source),
            (
                samples(5, 10),
                ReferenceAudioContent::Silence {
                    reason: SilenceReason::OutsideSourcePlacement
                }
            ),
            (
                samples(10, 12),
                ReferenceAudioContent::Tail {
                    input: Default::default(),
                    maximum: duration(2),
                    effect: Default::default(),
                }
            ),
        ]
    );
    let before = plan
        .root_clock()
        .processing_domain_at(ReferenceSample(1), Default::default())
        .unwrap();
    let audible = plan
        .root_clock()
        .processing_domain_at(ReferenceSample(2), Default::default())
        .unwrap();
    let after = plan
        .root_clock()
        .processing_domain_at(ReferenceSample(5), Default::default())
        .unwrap();
    assert_eq!(before.instance(), audible.instance());
    assert_eq!(before.kind(), after.kind());
    assert_eq!(before.meaningful_samples(), samples(0, 2));
    assert_eq!(audible.meaningful_samples(), samples(2, 5));
    assert_eq!(after.meaningful_samples(), samples(5, 10));
    assert!(!before.same_domain(&audible));
    assert!(!before.same_domain(&after));
}

fn edit(doc: &ProjectDocument, revision: &str, command: Command) -> ProjectDocument {
    apply(
        doc,
        &CommandRequest {
            project_id: doc.project_id().clone(),
            expected_revision: doc.revision_id().clone(),
            new_revision: RevisionId::new(revision).unwrap(),
            command,
        },
    )
    .unwrap()
    .forward
    .apply(doc)
    .unwrap()
}

#[test]
fn ntsc_resume_keeps_later_domains_first_sample_and_composes_active_phase() {
    let rate = FrameRate::new(30_000, 1001).unwrap();
    let doc = document(rate, &["a", "b"], vec![("a", source(2)), ("b", source(2))]);
    let plan = compile(&doc);
    let clock = plan.root_clock();
    let a = clock
        .processing_domain_at(ReferenceSample(1602), Default::default())
        .unwrap();
    let b = clock
        .processing_domain_at(ReferenceSample(3203), Default::default())
        .unwrap();
    assert_eq!(a.instance(), &instance("a"));
    assert_eq!(a.meaningful_samples(), samples(0, 3203));
    assert_eq!(b.instance(), &instance("b"));
    assert_eq!(b.meaningful_samples(), samples(3203, 6406));
    assert!(!a.same_domain(&b));

    // Insert one frame at frame one. Round absolute endpoints once: the cut
    // moves 1602 -> 3203, but the next genuine domain moves 3203 -> 4805.
    let resumed_a = a
        .place_root(AudioSample(0))
        .unwrap()
        .resume(AudioSample(1602), AudioSample(3203))
        .unwrap();
    let placed_b = b.place_root(AudioSample(4805)).unwrap();
    assert_eq!(
        resumed_a.reference_position(AudioSample(3203)).unwrap(),
        ratio(1602, 1)
    );
    assert_eq!(
        placed_b.reference_position(AudioSample(4805)).unwrap(),
        ratio(3203, 1)
    );
    // A blanket shift would lose B's first sample. A's continued map is
    // intentionally unclamped, so the discrepancy is observable here.
    assert_eq!(
        resumed_a.reference_position(AudioSample(4805)).unwrap(),
        ratio(3204, 1)
    );
    assert!(resumed_a.domain().same_domain(&a));
    assert!(placed_b.domain().same_domain(&b));

    let long = document(rate, &["a"], vec![("a", source(8))]);
    let long_plan = compile(&long);
    let long_a = long_plan
        .root_clock()
        .processing_domain_at(ReferenceSample(1602), Default::default())
        .unwrap();
    let first = long_a
        .place_root(AudioSample(0))
        .unwrap()
        .resume(AudioSample(1602), AudioSample(3203))
        .unwrap();
    let second = first.resume(AudioSample(4805), AudioSample(6406)).unwrap();
    assert_eq!(second.output_anchor(), AudioSample(6406));
    assert_eq!(second.reference_at_anchor(), ratio(3204, 1));
    for (current, old) in [(6405, 3203), (6406, 3204), (7000, 3798)] {
        assert_eq!(
            second.reference_position(AudioSample(current)).unwrap(),
            ratio(old, 1)
        );
    }
    // Resuming the current mapping must not recompute phase from frame two.
    assert_ne!(second.reference_at_anchor(), ratio(3203, 1));
}

#[test]
fn processing_domains_keep_preserve_opaque_and_preparation_clocks_distinct() {
    let doc = document(
        FrameRate::new(30_000, 1001).unwrap(),
        &["preserve"],
        vec![
            (
                "preserve",
                retime("sequence", 6, 0, 12, PitchPolicy::Preserve),
            ),
            (
                "sequence",
                BeatNode::sequence("Context", vec![id("a"), id("quiet"), id("tone"), id("b")]),
            ),
            ("a", source(4)),
            ("quiet", hold(2, HoldAudio::Silence)),
            ("tone", hold(2, HoldAudio::RoomTone { source: audio() })),
            ("b", source(4)),
        ],
    );
    let plan = compile(&doc);
    let root = plan.root_clock();
    let first = root
        .processing_domain_at(
            ReferenceSample(0),
            AudioQueryLimits {
                maximum_spans: 1,
                maximum_work: 3,
            },
        )
        .unwrap();
    assert_eq!(first.lookup().visited_nodes, 2);
    assert_eq!(first.instance(), &instance("preserve"));
    assert_eq!(
        first.kind(),
        &ReferenceProcessingKind::Preserve {
            pitch: PitchPolicy::Preserve,
            selection: ratio(0, 1)..ratio(12, 1),
            duration: duration(6),
            rate: ratio(2, 1),
        }
    );
    assert_eq!(first.meaningful_samples(), samples(0, 9610));
    for sample in [3203, 4805, 6406, 9609] {
        let domain = root
            .processing_domain_at(ReferenceSample(sample), Default::default())
            .unwrap();
        assert!(first.same_domain(&domain));
        assert_eq!(domain.allocated_samples(), samples(0, 9610));
    }
    let policy = root.query(samples(3203, 3204), Default::default()).unwrap();
    assert_eq!(
        policy.spans[0].content,
        ReferenceAudioContent::Silence {
            reason: SilenceReason::SilentHold
        }
    );

    let input = plan
        .preserve_input_clock(&instance("preserve"))
        .unwrap()
        .processing_domain_at(ReferenceSample(6407), Default::default())
        .unwrap();
    assert_eq!(input.instance(), &instance("quiet"));
    assert_eq!(
        input.kind(),
        &ReferenceProcessingKind::Leaf {
            content: ReferenceAudioContent::Silence {
                reason: SilenceReason::SilentHold
            },
        }
    );
    let output = plan
        .preserve_output_clock(&instance("preserve"))
        .unwrap()
        .processing_domain_at(ReferenceSample(0), Default::default())
        .unwrap();
    assert_eq!(output.instance(), first.instance());
    assert!(!output.same_domain(&first));
    assert!(!input.same_domain(&output));
    for domain in [&input, &output] {
        assert!(matches!(
            domain.place_root(AudioSample(0)),
            Err(PlanError::InvalidPlan(_))
        ));
    }

    // Even equal serialized layouts compiled twice have separate ownership.
    let foreign = compile(&doc);
    let foreign_domain = foreign
        .root_clock()
        .processing_domain_at(ReferenceSample(0), Default::default())
        .unwrap();
    assert_eq!(foreign_domain.kind(), first.kind());
    assert_eq!(
        foreign_domain.meaningful_samples(),
        first.meaningful_samples()
    );
    assert!(!foreign_domain.same_domain(&first));
}

#[test]
fn partition_allocation_keeps_full_context_but_edit_crops_are_meaningful() {
    for purpose in [RetimePurpose::Partition, RetimePurpose::Edit] {
        let mut selection = retime("a", 2, 2, 4, PitchPolicy::Preserve);
        let NodeKind::Retime {
            purpose: selected_purpose,
            ..
        } = &mut selection.kind
        else {
            unreachable!()
        };
        *selected_purpose = purpose;
        let doc = document(
            FrameRate::new(48_000, 1).unwrap(),
            &["selection"],
            vec![("selection", selection), ("a", source(6))],
        );
        let plan = compile(&doc);
        let domain = plan
            .root_clock()
            .processing_domain_at(ReferenceSample(1), Default::default())
            .unwrap();
        assert_eq!(domain.instance(), &instance("a"));
        assert_eq!(domain.extent(), ratio(0, 1)..ratio(2, 1));
        assert_eq!(domain.allocated_samples(), samples(0, 2));
        assert_eq!(domain.local_at(ReferenceSample(1)).unwrap(), ratio(3, 1));
        assert_eq!(domain.local_at(ReferenceSample(-3)).unwrap(), ratio(-1, 1));
        let meaningful = if purpose == RetimePurpose::Partition {
            samples(-2, 4)
        } else {
            samples(0, 2)
        };
        assert_eq!(domain.meaningful_samples(), meaningful);
        assert_eq!(
            domain.meaningful_extent(),
            ratio(meaningful.start.0.into(), 1)..ratio(meaningful.end.0.into(), 1)
        );
        let placed = domain.place_root(AudioSample(10)).unwrap();
        assert_eq!(
            placed.reference_position(AudioSample(10)).unwrap(),
            ratio(meaningful.start.0.into(), 1)
        );
    }

    let doc = document(
        FrameRate::new(48_000, 1).unwrap(),
        &["a"],
        vec![("a", source(6))],
    );
    let split = edit(
        &doc,
        "split",
        Command::Split {
            node: id("a"),
            at: duration(2),
            identities: SplitIdentities {
                nodes: (0..8).map(|n| id(&format!("split-{n}"))).collect(),
            },
        },
    );
    let plan = compile(&split);
    let left = plan
        .root_clock()
        .processing_domain_at(ReferenceSample(1), Default::default())
        .unwrap();
    let right = plan
        .root_clock()
        .processing_domain_at(ReferenceSample(2), Default::default())
        .unwrap();
    assert_eq!(left.allocated_samples(), samples(0, 2));
    assert_eq!(right.allocated_samples(), samples(2, 6));
    assert_eq!(left.meaningful_samples(), samples(0, 6));
    assert_eq!(right.meaningful_samples(), samples(0, 6));
    assert_eq!(
        left.local_at(ReferenceSample(2)).unwrap(),
        right.local_at(ReferenceSample(2)).unwrap()
    );
    // Explicit authored lineage relates the copies without erasing their
    // distinct physical identity or admitting media/PCM.
    assert_ne!(left.instance(), right.instance());
    assert!(!left.same_domain(&right));
    assert!(left.shares_copy_lineage(&right));
}

#[test]
fn retained_root_maps_keep_wide_exhausted_coordinates_and_fractional_phase() {
    let doc = document(
        FrameRate::new(48_000, 1).unwrap(),
        &["a"],
        vec![("a", source(2))],
    );
    let plan = compile(&doc);
    let domain = plan
        .root_clock()
        .processing_domain_at(ReferenceSample(0), Default::default())
        .unwrap();
    let map = domain.place_root(AudioSample(i64::MIN)).unwrap();
    let width = i128::from(i64::MAX) - i128::from(i64::MIN);
    assert_eq!(
        map.reference_position(AudioSample(i64::MAX)).unwrap(),
        ratio(width, 1)
    );
    let resumed = map
        .resume(AudioSample(i64::MAX), AudioSample(i64::MIN))
        .unwrap();
    assert_eq!(
        resumed.reference_position(AudioSample(i64::MAX)).unwrap(),
        ratio(width * 2, 1)
    );
    assert_eq!(
        domain.local_at(ReferenceSample(i64::MIN)).unwrap(),
        ratio(i128::from(i64::MIN), 1)
    );
    let normal = domain.place_root(AudioSample(7)).unwrap();
    assert_eq!(
        normal.reference_position_at(ratio(15, 2)).unwrap(),
        ratio(1, 2)
    );
    assert_eq!(
        normal.reference_position_at(ratio(13, 2)).unwrap(),
        ratio(-1, 2)
    );
}

#[test]
fn copy_lineage_survives_root_split_refinement_but_rejects_detached_or_moved_audio() {
    let doc = document(
        FrameRate::new(48_000, 1).unwrap(),
        &["a"],
        vec![("a", source(8))],
    );
    let split = edit(
        &doc,
        "root-split",
        Command::Split {
            node: id("root"),
            at: duration(2),
            identities: SplitIdentities {
                nodes: (0..12).map(|i| id(&format!("s-{i}"))).collect(),
            },
        },
    );
    let right = split.children(split.root()).nth(1).unwrap().clone();
    let refined = edit(
        &split,
        "refine",
        Command::Split {
            node: right,
            at: duration(2),
            identities: SplitIdentities {
                nodes: (0..12).map(|i| id(&format!("r-{i}"))).collect(),
            },
        },
    );
    let plan = compile(&refined);
    let domains = [1, 3, 5].map(|sample| {
        plan.root_clock()
            .processing_domain_at(ReferenceSample(sample), Default::default())
            .unwrap()
    });
    for pair in domains.windows(2) {
        assert!(!pair[0].same_domain(&pair[1]));
        assert!(pair[0].shares_copy_lineage(&pair[1]));
        assert!(pair[1].shares_copy_lineage(&pair[0]));
    }
    let foreign = compile(&refined);
    let foreign_domain = foreign
        .root_clock()
        .processing_domain_at(ReferenceSample(1), Default::default())
        .unwrap();
    assert!(!domains[0].shares_copy_lineage(&foreign_domain));
    let mut legacy = serde_json::to_value(FrozenAudioLayout::capture(&refined).unwrap()).unwrap();
    legacy.as_object_mut().unwrap().remove("audio_lineage");
    let legacy =
        AudioReferencePlan::compile(&FrozenAudioLayout::from_json(&legacy.to_string()).unwrap())
            .unwrap();
    let left = legacy
        .root_clock()
        .processing_domain_at(ReferenceSample(1), Default::default())
        .unwrap();
    let right = legacy
        .root_clock()
        .processing_domain_at(ReferenceSample(5), Default::default())
        .unwrap();
    assert!(!left.shares_copy_lineage(&right));
    let changed = edit(
        &refined,
        "changed-audio",
        Command::SetSourceAudioMapping {
            node: domains[2].instance().node.clone(),
            mapping: SourceAudioMapping::FitBeat,
            offset: AudioSample(1),
        },
    );
    let changed = compile(&changed);
    let left = changed
        .root_clock()
        .processing_domain_at(ReferenceSample(1), Default::default())
        .unwrap();
    let right = changed
        .root_clock()
        .processing_domain_at(ReferenceSample(5), Default::default())
        .unwrap();
    assert!(!left.shares_copy_lineage(&right));
    let moved = edit(
        &refined,
        "move",
        Command::Move {
            node: refined.children(refined.root()).nth(2).unwrap().clone(),
            parent: id("root"),
            index: 0,
        },
    );
    let moved = compile(&moved);
    let moved_right = moved
        .root_clock()
        .processing_domain_at(ReferenceSample(1), Default::default())
        .unwrap();
    let moved_left = moved
        .root_clock()
        .processing_domain_at(ReferenceSample(5), Default::default())
        .unwrap();
    assert!(!moved_right.shares_copy_lineage(&moved_left));
}

#[test]
fn copy_lineage_keeps_compact_repeat_paths_and_gap_identity_explicit() {
    let iterations = IterationOrder::new(RevisionId::new("plays").unwrap(), 1_000_000_000).unwrap();
    let doc = document(
        FrameRate::new(48_000, 1).unwrap(),
        &["repeat"],
        vec![
            (
                "repeat",
                BeatNode {
                    label: "Compact".into(),
                    framing: None,
                    audio_treatments: Default::default(),
                    audio_editorial_edges: Default::default(),
                    audio_edges: Default::default(),
                    kind: NodeKind::Repeat {
                        child: id("a"),
                        iterations: iterations.clone(),
                        gap: Some(HoldRecipe {
                            duration: duration(4),
                            video: HoldVideo::Background,
                            picture_context: None,
                            audio: HoldAudio::RoomTone { source: audio() },
                        }),
                        escalation: None,
                    },
                    cutaways: Vec::new(),
                    captions: Vec::new(),
                },
            ),
            ("a", source(6)),
        ],
    );
    for (cut, before, after) in [(3, 2, 3), (8, 7, 8)] {
        let split = edit(
            &doc,
            "split",
            Command::Split {
                node: id("repeat"),
                at: duration(cut),
                identities: SplitIdentities {
                    nodes: (0..12).map(|i| id(&format!("s-{i}"))).collect(),
                },
            },
        );
        let plan = compile(&split);
        assert!(plan.layout().to_json().unwrap().len() < 6000);
        let clock = plan.root_clock();
        let domains = [before, after, after + 10].map(|sample| {
            clock
                .processing_domain_at(
                    ReferenceSample(sample),
                    AudioQueryLimits {
                        maximum_spans: 1,
                        maximum_work: 30,
                    },
                )
                .unwrap()
        });
        assert!(!domains[0].same_domain(&domains[1]));
        assert!(domains[0].shares_copy_lineage(&domains[1]));
        assert!(!domains[1].shares_copy_lineage(&domains[2]));
        for domain in &domains {
            assert!(domain.lookup().visited_nodes < 8);
        }
        if cut == 8 {
            assert_eq!(domains[0].gap_after(), iterations.at(0).as_ref());
        }
    }
}

#[test]
fn nested_occurrence_split_retains_copy_lineage_without_expanding_repeats() {
    let outer = IterationOrder::new(RevisionId::new("outer-plays").unwrap(), 2).unwrap();
    let inner =
        IterationOrder::new(RevisionId::new("inner-plays").unwrap(), 1_000_000_000).unwrap();
    let doc = document(
        FrameRate::new(48_000, 1).unwrap(),
        &["outer"],
        vec![
            (
                "outer",
                BeatNode {
                    label: "Outer".into(),
                    framing: None,
                    audio_treatments: Default::default(),
                    audio_editorial_edges: Default::default(),
                    audio_edges: Default::default(),
                    kind: NodeKind::Repeat {
                        child: id("inner"),
                        iterations: outer.clone(),
                        gap: None,
                        escalation: None,
                    },
                    cutaways: Vec::new(),
                    captions: Vec::new(),
                },
            ),
            (
                "inner",
                BeatNode {
                    label: "Inner".into(),
                    framing: None,
                    audio_treatments: Default::default(),
                    audio_editorial_edges: Default::default(),
                    audio_edges: Default::default(),
                    kind: NodeKind::Repeat {
                        child: id("a"),
                        iterations: inner.clone(),
                        gap: None,
                        escalation: None,
                    },
                    cutaways: Vec::new(),
                    captions: Vec::new(),
                },
            ),
            ("a", source(6)),
        ],
    );
    let split = edit(
        &doc,
        "nested-split",
        Command::EditOccurrence {
            instance: InstancePath {
                node: id("a"),
                repeats: vec![
                    RepeatInstance {
                        node: id("outer"),
                        iteration: outer.at(1).unwrap(),
                    },
                    RepeatInstance {
                        node: id("inner"),
                        iteration: inner.at(1).unwrap(),
                    },
                ],
            },
            edit: OccurrenceEdit::Split {
                at: duration(2),
                identities: SplitIdentities {
                    nodes: (0..12).map(|i| id(&format!("s-{i}"))).collect(),
                },
            },
            identities: OccurrenceIdentities {
                nodes: (0..12).map(|i| id(&format!("isolate-{i}"))).collect(),
                marks: vec![],
            },
        },
    );
    let plan = compile(&split);
    assert!(plan.layout().to_json().unwrap().len() < 8000);
    let clock = plan.root_clock();
    let domains = [6_000_000_007, 6_000_000_008].map(|sample| {
        clock
            .processing_domain_at(
                ReferenceSample(sample),
                AudioQueryLimits {
                    maximum_spans: 1,
                    maximum_work: 40,
                },
            )
            .unwrap()
    });
    assert_eq!(domains[0].instance().repeats.len(), 2);
    assert_eq!(
        domains[0].instance().repeats[1].iteration,
        inner.at(1).unwrap()
    );
    assert!(!domains[0].same_domain(&domains[1]));
    assert!(domains[0].shares_copy_lineage(&domains[1]));
}

#[test]
fn copied_preserve_lineage_does_not_merge_distinct_preparation_clocks() {
    let doc = document(
        FrameRate::new(48_000, 1).unwrap(),
        &["preserve"],
        vec![
            ("preserve", retime("a", 8, 0, 4, PitchPolicy::Preserve)),
            ("a", source(4)),
        ],
    );
    let split = edit(
        &doc,
        "split",
        Command::Split {
            node: id("preserve"),
            at: duration(3),
            identities: SplitIdentities {
                nodes: (0..12).map(|i| id(&format!("s-{i}"))).collect(),
            },
        },
    );
    let plan = compile(&split);
    let domains = [1, 4].map(|sample| {
        plan.root_clock()
            .processing_domain_at(ReferenceSample(sample), Default::default())
            .unwrap()
    });
    assert!(matches!(
        domains[0].kind(),
        ReferenceProcessingKind::Preserve { .. }
    ));
    assert!(!domains[0].same_domain(&domains[1]));
    assert!(domains[0].shares_copy_lineage(&domains[1]));
    let prepared = domains
        .iter()
        .map(|domain| {
            plan.preserve_input_clock(domain.instance())
                .unwrap()
                .processing_domain_at(ReferenceSample(1), Default::default())
                .unwrap()
        })
        .collect::<Vec<_>>();
    assert_eq!(
        prepared[0].meaningful_extent(),
        prepared[1].meaningful_extent()
    );
    assert_eq!(prepared[0].kind(), prepared[1].kind());
    assert_eq!(
        plan.layout()
            .audio_lineage()
            .get(&prepared[0].instance().node),
        plan.layout()
            .audio_lineage()
            .get(&prepared[1].instance().node)
    );
    assert!(!prepared[0].shares_copy_lineage(&prepared[1]));
    assert!(!prepared[0].same_domain(&prepared[1]));
}

#[test]
fn a_tail_hold_or_gap_under_a_speed_change_is_an_invalid_document() {
    let tail = HoldAudio::Tail {
        input: Default::default(),
        maximum: duration(2),
        effect: Default::default(),
    };
    for gap in [false, true] {
        let (frames, nodes) = if gap {
            (
                12,
                vec![
                    (
                        "context",
                        BeatNode {
                            label: "Tail gap".into(),
                            framing: None,
                            audio_treatments: Default::default(),
                            audio_editorial_edges: Default::default(),
                            audio_edges: Default::default(),
                            kind: NodeKind::Repeat {
                                child: id("a"),
                                iterations: IterationOrder::new(
                                    RevisionId::new("plays").unwrap(),
                                    2,
                                )
                                .unwrap(),
                                gap: Some(HoldRecipe {
                                    duration: duration(8),
                                    video: HoldVideo::Background,
                                    picture_context: None,
                                    audio: tail.clone(),
                                }),
                                escalation: None,
                            },
                            cutaways: Vec::new(),
                            captions: Vec::new(),
                        },
                    ),
                    ("a", source(2)),
                ],
            )
        } else {
            (8, vec![("context", hold(8, tail.clone()))])
        };
        let mut nodes = nodes;
        nodes.push((
            "preserve",
            retime("context", frames / 2, 0, frames, PitchPolicy::Preserve),
        ));
        // A live tail is fed on the edit clock; under a nonunity Retime it
        // would be stretched, so the document is refused before compiling.
        let error = try_document(FrameRate::new(24, 1).unwrap(), &["preserve"], nodes).unwrap_err();
        assert!(error.message.contains("speed change"), "{error:?}");
    }
}

#[test]
fn billion_play_reference_keeps_old_order_gap_identity_after_current_edits() {
    let iterations = IterationOrder::new(RevisionId::new("plays").unwrap(), 1_000_000_000).unwrap();
    let doc = document(
        FrameRate::new(48_000, 1).unwrap(),
        &["repeat"],
        vec![
            (
                "repeat",
                BeatNode {
                    label: "Compact".into(),
                    framing: None,
                    audio_treatments: Default::default(),
                    audio_editorial_edges: Default::default(),
                    audio_edges: Default::default(),
                    kind: NodeKind::Repeat {
                        child: id("a"),
                        iterations: iterations.clone(),
                        gap: Some(HoldRecipe {
                            duration: duration(1),
                            video: HoldVideo::Background,
                            picture_context: None,
                            audio: HoldAudio::RoomTone { source: audio() },
                        }),
                        escalation: None,
                    },
                    cutaways: Vec::new(),
                    captions: Vec::new(),
                },
            ),
            ("a", source(1)),
        ],
    );
    let old = compile(&doc);
    let clock = old.root_clock();
    let expected = clock
        .query(
            samples(1_999_999_994, 1_999_999_999),
            AudioQueryLimits {
                maximum_spans: 5,
                maximum_work: 100,
            },
        )
        .unwrap();
    assert_eq!(expected.spans.len(), 5);
    assert!(expected.lookup.visited_nodes < 20);
    assert!(expected.lookup.iteration_run_comparisons <= 5);
    assert_eq!(expected.spans[1].content, ReferenceAudioContent::RoomTone);
    assert_eq!(expected.spans[1].gap_after, iterations.at(999_999_997));
    let domains = [1_999_999_994, 1_999_999_995, 1_999_999_996].map(|sample| {
        clock
            .processing_domain_at(
                ReferenceSample(sample),
                AudioQueryLimits {
                    maximum_spans: 1,
                    maximum_work: 20,
                },
            )
            .unwrap()
    });
    assert_eq!(
        domains[0].instance().repeats[0].iteration,
        iterations.at(999_999_997).unwrap()
    );
    assert_eq!(domains[1].gap_after(), iterations.at(999_999_997).as_ref());
    assert_eq!(domains[1].instance(), &instance("repeat"));
    assert_eq!(
        domains[1].kind(),
        &ReferenceProcessingKind::Leaf {
            content: ReferenceAudioContent::RoomTone
        }
    );
    assert_eq!(
        domains[1].meaningful_samples(),
        samples(1_999_999_995, 1_999_999_996)
    );
    assert!(!domains[0].same_domain(&domains[2]));
    for domain in &domains {
        assert!(domain.lookup().visited_nodes <= 3);
        assert!(domain.lookup().iteration_run_comparisons <= 1);
    }
    let split = edit(
        &doc,
        "split",
        Command::Split {
            node: id("repeat"),
            at: duration(5),
            identities: SplitIdentities {
                nodes: (0..16).map(|n| id(&format!("split-{n}"))).collect(),
            },
        },
    );
    assert!(split.nodes().len() > doc.nodes().len());
    assert_eq!(
        clock
            .query(samples(1_999_999_994, 1_999_999_999), Default::default())
            .unwrap()
            .spans,
        expected.spans
    );
    let moved = edit(
        &doc,
        "move",
        Command::MovePlays {
            node: id("repeat"),
            start: 999_999_999,
            end: 1_000_000_000,
            destination: 0,
        },
    );
    let moved_plan = compile(&moved);
    let moved_first = moved_plan
        .root_clock()
        .processing_domain_at(ReferenceSample(0), Default::default())
        .unwrap();
    assert_eq!(
        moved_first.instance().repeats[0].iteration,
        iterations.at(999_999_999).unwrap()
    );
    let old_last = clock
        .processing_domain_at(ReferenceSample(1_999_999_998), Default::default())
        .unwrap();
    assert_eq!(old_last.instance().repeats, moved_first.instance().repeats);
    assert_eq!(
        old_last.meaningful_samples(),
        samples(1_999_999_998, 1_999_999_999)
    );
    assert!(!old_last.same_domain(&moved_first));
    let shrunk = edit(
        &moved,
        "shrink",
        Command::SetRepeat {
            node: id("repeat"),
            plays: 2,
            gap: None,
        },
    );
    let removed = edit(&shrunk, "delete", Command::Delete { node: id("repeat") });
    assert_eq!(removed.duration().unwrap(), FrameDuration::ZERO);
    assert_eq!(
        clock
            .query(samples(1_999_999_994, 1_999_999_999), Default::default())
            .unwrap()
            .spans,
        expected.spans
    );
}

#[test]
fn sparse_override_clock_validates_its_effective_play_and_retains_partition_allocation() {
    let doc = document(
        FrameRate::new(24, 1).unwrap(),
        &["repeat"],
        vec![
            (
                "repeat",
                BeatNode {
                    label: "Repeated".into(),
                    framing: None,
                    audio_treatments: Default::default(),
                    audio_editorial_edges: Default::default(),
                    audio_edges: Default::default(),
                    kind: NodeKind::Repeat {
                        child: id("default"),
                        iterations: IterationOrder::new(RevisionId::new("plays").unwrap(), 3)
                            .unwrap(),
                        gap: None,
                        escalation: None,
                    },
                    cutaways: Vec::new(),
                    captions: Vec::new(),
                },
            ),
            ("default", retime("a", 2, 0, 4, PitchPolicy::Preserve)),
            ("a", source(4)),
        ],
    );
    let iteration = IterationId {
        allocation: RevisionId::new("plays").unwrap(),
        ordinal: 1,
    };
    let overridden = edit(
        &doc,
        "override",
        Command::SetPlayOverride {
            node: id("repeat"),
            iteration: iteration.clone(),
            subtree: Subtree {
                root: id("override"),
                nodes: BTreeMap::from([
                    (
                        id("override"),
                        retime("quiet", 3, 0, 4, PitchPolicy::Preserve),
                    ),
                    (id("quiet"), hold(4, HoldAudio::Silence)),
                ]),
                overrides: BTreeMap::new(),
                gap_overrides: BTreeMap::new(),
            },
        },
    );
    let frozen = compile(&overridden);
    let path = InstancePath {
        node: id("override"),
        repeats: vec![RepeatInstance {
            node: id("repeat"),
            iteration: iteration.clone(),
        }],
    };
    let clock = frozen.preserve_input_clock(&path).unwrap();
    assert_eq!(clock.sample_count().unwrap(), ReferenceSample(8000));
    let query = clock.query(samples(0, 1), Default::default()).unwrap();
    assert_eq!(query.spans[0].instance.node, id("quiet"));
    assert_eq!(query.spans[0].instance.repeats, path.repeats);
    let root = frozen.root_clock();
    let overridden_domain = root
        .processing_domain_at(ReferenceSample(4000), Default::default())
        .unwrap();
    assert_eq!(overridden_domain.instance(), &path);
    assert_eq!(overridden_domain.meaningful_samples(), samples(4000, 10000));
    assert!(matches!(
        overridden_domain.kind(),
        ReferenceProcessingKind::Preserve { .. }
    ));
    assert_eq!(
        overridden_domain.local_at(ReferenceSample(4000)).unwrap(),
        ExactRatio::ZERO
    );
    let first_default = root
        .processing_domain_at(ReferenceSample(0), Default::default())
        .unwrap();
    let last_default = root
        .processing_domain_at(ReferenceSample(10000), Default::default())
        .unwrap();
    assert_eq!(first_default.instance().node, last_default.instance().node);
    assert_ne!(
        first_default.instance().repeats,
        last_default.instance().repeats
    );
    assert!(!first_default.same_domain(&last_default));
    assert!(!first_default.same_domain(&overridden_domain));
    let wrong = InstancePath {
        node: id("default"),
        ..path
    };
    assert!(frozen.preserve_output_clock(&wrong).is_err());
    let split = edit(
        &overridden,
        "split",
        Command::Split {
            node: id("repeat"),
            at: duration(3),
            identities: SplitIdentities {
                nodes: (0..20).map(|n| id(&format!("split-{n}"))).collect(),
            },
        },
    );
    let split_reference = compile(&split);
    let live = RenderPlan::compile(&split).unwrap();
    let actual = split_reference
        .root_clock()
        .query(samples(0, 14000), Default::default())
        .unwrap();
    let expected = live
        .audio(AudioSample(0)..AudioSample(14000), Default::default())
        .unwrap();
    assert_eq!(actual.spans.len(), expected.spans.len());
    for (actual, expected) in actual.spans.iter().zip(expected.spans) {
        assert_eq!(actual.content, policy(&expected.content));
        assert_eq!(
            actual.allocated_samples,
            samples(
                expected.allocated_samples.start.0,
                expected.allocated_samples.end.0
            )
        );
        assert_eq!(actual.instance, expected.instance);
    }
}

#[test]
fn invalid_owner_paths_ranges_and_budgets_fail_before_results() {
    let doc = document(
        FrameRate::new(24, 1).unwrap(),
        &["repeat"],
        vec![
            (
                "repeat",
                BeatNode {
                    label: "Repeated".into(),
                    framing: None,
                    audio_treatments: Default::default(),
                    audio_editorial_edges: Default::default(),
                    audio_edges: Default::default(),
                    kind: NodeKind::Repeat {
                        child: id("preserve"),
                        iterations: IterationOrder::new(RevisionId::new("plays").unwrap(), 2)
                            .unwrap(),
                        gap: None,
                        escalation: None,
                    },
                    cutaways: Vec::new(),
                    captions: Vec::new(),
                },
            ),
            ("preserve", retime("a", 2, 0, 4, PitchPolicy::Preserve)),
            ("a", source(4)),
        ],
    );
    let plan = compile(&doc);
    assert!(plan.preserve_input_clock(&instance("a")).is_err());
    assert!(plan.preserve_input_clock(&instance("preserve")).is_err());
    assert!(plan.preserve_output_clock(&instance("missing")).is_err());
    let mut selected = instance("preserve");
    selected.repeats.push(RepeatInstance {
        node: id("repeat"),
        iteration: IterationId {
            allocation: RevisionId::new("plays").unwrap(),
            ordinal: 1,
        },
    });
    assert!(plan.preserve_input_clock(&selected).is_ok());
    selected.repeats[0].iteration.ordinal = 2;
    assert!(plan.preserve_input_clock(&selected).is_err());
    let root = plan.root_clock();
    for sample in [-1, 8000, i64::MAX] {
        assert!(matches!(
            root.processing_domain_at(ReferenceSample(sample), Default::default()),
            Err(PlanError::AudioRangeOutOfRange)
        ));
    }
    assert!(matches!(
        root.processing_domain_at(
            ReferenceSample(0),
            AudioQueryLimits {
                maximum_spans: 1,
                maximum_work: 1
            }
        ),
        Err(PlanError::AudioQueryLimit("structural work"))
    ));
    for range in [samples(-1, 0), samples(2, 1), samples(0, 8001)] {
        assert!(matches!(
            root.query(range, Default::default()),
            Err(PlanError::AudioRangeOutOfRange)
        ));
    }
    assert!(
        root.query(samples(0, 0), Default::default())
            .unwrap()
            .spans
            .is_empty()
    );
    assert!(matches!(
        root.query(
            samples(0, 1),
            AudioQueryLimits {
                maximum_spans: 1,
                maximum_work: 1
            }
        ),
        Err(PlanError::AudioQueryLimit(_))
    ));
    assert!(matches!(
        root.query(
            samples(0, 8000),
            AudioQueryLimits {
                maximum_spans: 1,
                maximum_work: 100
            }
        ),
        Err(PlanError::AudioQueryLimit("span count"))
    ));
    for limits in [
        AudioQueryLimits {
            maximum_spans: 0,
            maximum_work: 100,
        },
        AudioQueryLimits {
            maximum_spans: 1,
            maximum_work: 65_537,
        },
    ] {
        assert!(matches!(
            root.processing_domain_at(ReferenceSample(0), limits),
            Err(PlanError::InvalidAudioLimits)
        ));
        assert!(matches!(
            root.query(samples(0, 1), limits),
            Err(PlanError::InvalidAudioLimits)
        ));
    }
}

fn dormant_source(point: ExactRatio) -> BeatNode {
    let mut node = source(32);
    let NodeKind::Source { source } = &mut node.kind else {
        panic!()
    };
    source.audio_mapping = SourceAudioMapping::SelectedPlacement {
        start: ExactRatio::integer(-10),
        frames: ExactRatio::integer(60),
        selection: ExactFrameRange {
            start: point,
            end: point,
        },
    };
    node
}

#[test]
fn dormant_source_is_one_silent_allocation_in_live_point_and_frozen_queries() {
    for point in [
        ExactRatio::integer(-10),
        ratio(13, 7),
        ExactRatio::integer(50),
    ] {
        let doc = document(
            FrameRate::new(48000, 1).unwrap(),
            &["source"],
            vec![("source", dormant_source(point))],
        );
        let plan = RenderPlan::compile(&doc).unwrap();
        let spans = plan
            .audio(AudioSample(0)..AudioSample(32), Default::default())
            .unwrap()
            .spans;
        assert_eq!(spans.len(), 1);
        assert_eq!(spans[0].samples, AudioSample(0)..AudioSample(32));
        assert!(matches!(
            spans[0].content,
            AudioContent::Silence {
                reason: SilenceReason::OutsideSourceSelection
            }
        ));
        let processing = plan
            .audio_processing(AudioSample(0)..AudioSample(32), Default::default())
            .unwrap();
        assert!(matches!(
            processing.spans[0].content,
            AudioSignalContent::Leaf(AudioContent::Silence {
                reason: SilenceReason::OutsideSourceSelection
            })
        ));
        let signal = plan
            .audio_signal()
            .query(SignalSample(0)..SignalSample(32), Default::default())
            .unwrap();
        assert_eq!(signal.spans.len(), 1);
        assert!(matches!(
            signal.spans[0].content,
            AudioSignalContent::Leaf(AudioContent::Silence {
                reason: SilenceReason::OutsideSourceSelection
            })
        ));
        plan.audio_owners(AudioSample(0)..AudioSample(32), Default::default())
            .unwrap();
        plan.audio_gain_owners(AudioSample(0)..AudioSample(32), Default::default())
            .unwrap();
        let frozen = compile(&doc);
        let spans = frozen
            .root_clock()
            .query(samples(0, 32), Default::default())
            .unwrap()
            .spans;
        assert_eq!(spans.len(), 1);
        assert_eq!(spans[0].samples, samples(0, 32));
        assert!(matches!(
            spans[0].content,
            ReferenceAudioContent::Silence {
                reason: SilenceReason::OutsideSourceSelection
            }
        ));
    }
}

#[test]
fn dormant_bound_recipe_retains_its_lattice_and_can_reveal_existing_phase() {
    let doc = document(
        FrameRate::new(48000, 1).unwrap(),
        &["source"],
        vec![("source", dormant_source(ratio(13, 7)))],
    );
    let state = capture_unbound_audio_bindings(
        &doc,
        AudioTimingId {
            allocation: RevisionId::new("captured").unwrap(),
            ordinal: 0,
        },
    )
    .unwrap();
    let mut wire = serde_json::to_value(&doc).unwrap();
    wire["audio_bindings"] = serde_json::to_value(&state).unwrap();
    let bound = ProjectDocument::from_json(&wire.to_string()).unwrap();
    let plan = RenderPlan::compile(&bound).unwrap();
    let query = plan
        .audio_processing(AudioSample(0)..AudioSample(32), Default::default())
        .unwrap();
    assert_eq!(query.spans.len(), 1);
    assert!(matches!(
        query.spans[0].content,
        AudioSignalContent::Leaf(AudioContent::Silence {
            reason: SilenceReason::OutsideSourceSelection
        })
    ));
    plan.audio_owners(AudioSample(0)..AudioSample(32), Default::default())
        .unwrap();
    plan.audio_gain_owners(AudioSample(0)..AudioSample(32), Default::default())
        .unwrap();
    assert_eq!(bound.audio_bindings(), &state);
    let tx = apply(
        &bound,
        &CommandRequest {
            project_id: bound.project_id().clone(),
            expected_revision: bound.revision_id().clone(),
            new_revision: RevisionId::new("audible").unwrap(),
            command: Command::SetSourceAudioMapping {
                node: id("source"),
                offset: AudioSample(0),
                mapping: SourceAudioMapping::SelectedPlacement {
                    start: ExactRatio::integer(-10),
                    frames: ExactRatio::integer(60),
                    selection: ExactFrameRange {
                        start: ratio(13, 7),
                        end: ExactRatio::integer(20),
                    },
                },
            },
        },
    )
    .unwrap();
    let audible = tx.forward.apply(&bound).unwrap();
    assert_eq!(audible.audio_bindings(), &state);
    let plan = RenderPlan::compile(&audible).unwrap();
    let query = plan
        .audio_processing(AudioSample(10)..AudioSample(11), Default::default())
        .unwrap();
    let AudioSignalContent::Bound(binding) = &query.spans[0].content else {
        panic!("retained lattice was discarded")
    };
    assert_eq!(
        binding.reference_at_offset(10).unwrap(),
        ExactRatio::integer(10)
    );
    assert_eq!(tx.inverse.apply(&audible).unwrap(), bound);
}

fn local_origin_document(prefix: i64) -> ProjectDocument {
    let mut leaf = source(32 + prefix);
    let NodeKind::Source { source } = &mut leaf.kind else {
        panic!()
    };
    source.audio_mapping = SourceAudioMapping::SelectedPlacement {
        start: ExactRatio::integer(prefix),
        frames: ExactRatio::integer(32),
        selection: ExactFrameRange {
            start: ExactRatio::integer(prefix),
            end: ExactRatio::integer(prefix + 32),
        },
    };
    let mut crop = retime("source", 32, prefix, prefix + 32, PitchPolicy::FollowSpeed);
    let NodeKind::Retime { purpose, .. } = &mut crop.kind else {
        panic!()
    };
    *purpose = RetimePurpose::Partition;
    document(
        FrameRate::new(30000, 1001).unwrap(),
        &["lead", "crop"],
        vec![
            ("lead", hold(1, HoldAudio::Silence)),
            ("crop", crop),
            ("source", leaf),
        ],
    )
}

fn with_origin_bindings(document: &ProjectDocument, state: &AudioBindingState) -> ProjectDocument {
    let mut wire = serde_json::to_value(document).unwrap();
    wire["audio_bindings"] = serde_json::to_value(state).unwrap();
    ProjectDocument::from_json(&wire.to_string()).unwrap()
}

fn translated_origin_bindings(state: &AudioBindingState, prefix: ExactRatio) -> AudioBindingState {
    AudioBindingState::new(
        state
            .timings()
            .iter()
            .map(|(id, layout)| AudioTimingRecord {
                id: id.clone(),
                layout: layout.clone(),
            })
            .collect(),
        state
            .bindings()
            .iter()
            .map(|(owner, binding)| {
                (
                    owner.clone(),
                    if *owner == id("source") {
                        binding.rebase_local(prefix).unwrap()
                    } else {
                        binding.clone()
                    },
                )
            })
            .collect(),
    )
    .unwrap()
}

#[test]
fn source_prefix_behind_partition_keeps_unbound_and_retained_source_phase() {
    let original = local_origin_document(0);
    let captured = capture_unbound_audio_bindings(
        &original,
        AudioTimingId {
            allocation: RevisionId::new("origin-capture").unwrap(),
            ordinal: 0,
        },
    )
    .unwrap();
    let plain = RenderPlan::compile(&original).unwrap();
    let expected = plain
        .audio(AudioSample(1602)..AudioSample(1603), Default::default())
        .unwrap();
    // Independent arithmetic: sample 1602 is 2/5 of a mix sample after frame 1.
    // A 48000-tick source mapped over 32 frames therefore starts at 375/1001.
    assert_eq!(
        expected.spans[0]
            .source_point(AudioSample(1602))
            .unwrap()
            .ticks,
        ratio(375, 1001)
    );
    for prefix in [1, 2, 7] {
        let rebased = local_origin_document(prefix);
        let moved_plain = RenderPlan::compile(&rebased).unwrap();
        for sample in [1602, 5000, 12000, 40000] {
            let range = AudioSample(sample)..AudioSample(sample + 1);
            let old = plain.audio(range.clone(), Default::default()).unwrap();
            let new = moved_plain.audio(range, Default::default()).unwrap();
            assert_eq!(
                old.spans[0].source_point(AudioSample(sample)).unwrap(),
                new.spans[0].source_point(AudioSample(sample)).unwrap()
            );
            assert_eq!(
                old.spans[0].allocated_samples,
                new.spans[0].allocated_samples
            );
            assert_eq!(old.spans[0].envelope_samples, new.spans[0].envelope_samples);
        }
        for resumed in [false, true] {
            let mut bindings = captured.bindings().clone();
            if resumed {
                let binding = bindings.get_mut(&id("source")).unwrap();
                binding.resume = Some(AudioResume {
                    local_boundary: ExactRatio::ONE,
                    phase: AudioLocalPhase {
                        constant: ExactRatio::ZERO,
                        terms: vec![AudioPhaseTerm {
                            placement: binding.lattice.clone(),
                            from_local: ExactRatio::ZERO,
                            to_local: ExactRatio::ONE,
                        }],
                    },
                });
                binding.reanchors.push(AudioReanchorStep {
                    anchor: Default::default(),
                    placement: binding.lattice.clone(),
                    window: Some(
                        ExactFrameRange::new(ExactRatio::integer(3), ExactRatio::integer(33))
                            .unwrap(),
                    ),
                });
            }
            let state = AudioBindingState::new(
                captured
                    .timings()
                    .iter()
                    .map(|(id, layout)| AudioTimingRecord {
                        id: id.clone(),
                        layout: layout.clone(),
                    })
                    .collect(),
                bindings,
            )
            .unwrap();
            let before = with_origin_bindings(&original, &state);
            let translated = translated_origin_bindings(&state, ExactRatio::integer(prefix));
            let after = with_origin_bindings(&rebased, &translated);
            assert_eq!(translated.timings(), state.timings());
            let old_plan = RenderPlan::compile(&before).unwrap();
            let new_plan = RenderPlan::compile(&after).unwrap();
            for sample in [5000, 12000, 40000] {
                let range = AudioSample(sample)..AudioSample(sample + 1);
                let old_query = old_plan
                    .audio_processing(range.clone(), Default::default())
                    .unwrap();
                let new_query = new_plan
                    .audio_processing(range.clone(), Default::default())
                    .unwrap();
                let AudioSignalContent::Bound(old) = &old_query.spans[0].content else {
                    panic!("retained source")
                };
                let AudioSignalContent::Bound(new) = &new_query.spans[0].content else {
                    panic!("retained source")
                };
                let old_at = old
                    .reference_at_offset(sample - old_query.spans[0].allocated_samples.start.0)
                    .unwrap();
                let new_at = new
                    .reference_at_offset(sample - new_query.spans[0].allocated_samples.start.0)
                    .unwrap();
                assert_eq!(old_at, new_at);
                assert_eq!(
                    old.reference_samples_per_output_sample(),
                    new.reference_samples_per_output_sample()
                );
                let deadpan_plan::AudioBoundDomain::Root(old_domain) = old.raw_domain().unwrap()
                else {
                    panic!("root clock")
                };
                let deadpan_plan::AudioBoundDomain::Root(new_domain) = new.raw_domain().unwrap()
                else {
                    panic!("root clock")
                };
                assert_eq!(old_domain.root_samples(), new_domain.root_samples());
                let index = i64::try_from(old_at.floor()).unwrap();
                let range = AudioSample(index)..AudioSample(index + 1);
                let old_raw = old_domain.audio(range.clone(), Default::default()).unwrap();
                let new_raw = new_domain.audio(range, Default::default()).unwrap();
                assert_eq!(
                    old_raw.spans[0].source_point(AudioSample(index)).unwrap(),
                    new_raw.spans[0].source_point(AudioSample(index)).unwrap()
                );
                new_plan
                    .audio_owners(
                        AudioSample(sample)..AudioSample(sample + 1),
                        Default::default(),
                    )
                    .unwrap();
            }
            let patch = DocumentPatch {
                project_id: before.project_id().clone(),
                from_revision: before.revision_id().clone(),
                to_revision: RevisionId::new("rebased-origin").unwrap(),
                presentation: None,
                nodes: [id("source"), id("crop")]
                    .into_iter()
                    .map(|id| {
                        (
                            id.clone(),
                            ValueChange {
                                before: Some(before.nodes()[&id].clone()),
                                after: Some(after.nodes()[&id].clone()),
                            },
                        )
                    })
                    .collect(),
                assets: BTreeMap::new(),
                source_interpretations: BTreeMap::new(),
                marks: BTreeMap::new(),
                sounds: BTreeMap::new(),
                beat_sounds: BTreeMap::new(),
                sound_routes: BTreeMap::new(),
                sound_allowances: BTreeMap::new(),
                targets: BTreeMap::new(),
                overrides: BTreeMap::new(),
                gap_overrides: BTreeMap::new(),
                audio_lineage: BTreeMap::new(),
                derived_clocks: BTreeMap::new(),
                audio_bindings: AudioBindingPatch::between(&state, &translated),
            };
            let applied = patch.apply(&before).unwrap();
            assert_eq!(applied.nodes(), after.nodes());
            assert_eq!(applied.audio_bindings(), after.audio_bindings());
            assert_eq!(patch.inverse().apply(&applied).unwrap(), before);
        }
    }
}
