from pathlib import Path
import hashlib,json,difflib
r=Path('/tmp/deadpan-owner-query-baseline-2026-10-28')
g=r/'harness/fixture-correction/gen2a'
repo=Path('/Users/michael/Code/deadpan');scope=Path('/tmp/deadpan-query-groundwork-2026-10-26/scoped')
sha=lambda b:hashlib.sha256(b).hexdigest()
path=Path('crates/deadpan-plan/src/audio_owners/legacy_snapshot_v1/fixtures.rs')
old=(g/'before'/path).read_bytes();new=(g/'candidate'/path).read_bytes()
assert (repo/path).read_bytes()==old and (scope/path).read_bytes()==old
(g/'fixture-correction.patch').write_text(''.join(difflib.unified_diff(old.decode().splitlines(True),new.decode().splitlines(True),fromfile='a/'+str(path),tofile='b/'+str(path))))
pins=json.loads((r/'harness/fixture-pins.json').read_text())
for item in pins:
 if item['path']==str(path):item['candidate_sha256']=sha(new);item['previous_generation_sha256']=sha(old)
(g/'fixture-pins-gen2.json').write_text(json.dumps(pins,indent=2)+'\n')
for label,base,listname in [('main-inherited',repo,'source-files.json'),('scoped-published',scope,'scoped-source-files.json')]:
 names=sorted(set(json.loads((r/listname).read_text())))
 assert str(path) in names
 entries=[]
 for name in names:
  data=new if name==str(path) else (base/name).read_bytes()
  entries.append({'path':name,'sha256':sha(data),'bytes':len(data)})
 authority={'schema':'LegacyRuntimeSourceAuthorityV1','producer_generation':2,'variant':label,
  'base_head':'296f2b894ccc4c32c5c6abc09db0d0bba2263f20','old_query_kernels':True,
  'source_count':len(entries),'harness_pins_sha256':sha((g/'fixture-pins-gen2.json').read_bytes()),'sources':entries}
 output=g/('runtime-source-authority-'+label+'-gen2.json')
 output.write_text(json.dumps(authority,indent=2)+'\n')
 print(output.name,sha(output.read_bytes()),len(entries))
basis=[]
for name in ['crates/deadpan-plan/tests/audio_reference.rs','crates/deadpan-plan/src/audio_owners/input_tests.rs','crates/deadpan-core/src/audio_binding_lifecycle.rs']:
 for label,base in [('main',repo),('scoped',scope)]:
  data=(base/name).read_bytes();out=g/'fixture-basis'/label/name;out.parent.mkdir(parents=True,exist_ok=True);out.write_bytes(data)
  basis.append({'variant':label,'path':name,'sha256':sha(data)})
(g/'fixture-basis-pins.json').write_text(json.dumps(basis,indent=2)+'\n')
for name in ['fixture-correction.patch','fixture-pins-gen2.json','fixture-basis-pins.json']:
 print(name,sha((g/name).read_bytes()))
