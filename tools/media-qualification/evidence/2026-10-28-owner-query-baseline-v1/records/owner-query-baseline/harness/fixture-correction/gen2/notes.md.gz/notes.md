# Generation2 Split fixture correction

All initial harness/candidate/pins/patch/manifests and the already captured
main-work-v1.json are untouched. This delta changes ONE test fixture file only.
No query/Core/Plan product kernel, main/scoped source, index, Cargo/rustc or media
operation was changed/run by this worker. Scoped rustfmt parsed the new file.

The first-generation fixture reused a public Source Split reference-plan test
but assumed its last observed RenderPlan owner had a retained Bound. It did not.
This is a fixture assumption failure, not a product bug or source-admission issue.

Exact existing basis:
- deadpan-plan/tests/audio_reference.rs:149 compiles FrozenAudioLayout into
  AudioReferencePlan, not RenderPlan. Its Source Split test around858 establishes
  retained reference-domain support, not AudioOwnerInput.retained_at(Some).
- audio_reference.rs:1931 source_prefix_behind_partition_keeps_unbound_and_retained_source_phase
  explicitly calls capture_unbound_audio_bindings, installs its state in the
  document, validates, then compiles RenderPlan.
- deadpan-core/src/audio_binding_lifecycle.rs:14 documents that public capture
  freezes each unbound physical recipe's actual current lattice; caller must
  install it. Split is a different operation and promises no implicit capture.
- audio_owners/input_tests.rs:151/439 independently establish actual persisted
  RootRoundEven/PointCeil input behavior through retained_probe_at.

Generation2 therefore explicitly captures/installs the Source lattice BEFORE
the same actual public Split command. It retains the unbound-before, bound-before
and post-Split documents separately. No synthetic private Domain is constructed.
The fixture walks the actual OLD ordered observed owners, invokes each actual
old input/probe, and selects an observed member proven Some(Root). Its resulting
member index is frozen before new wrappers exist. It does not assume root,
last owner, owner-ID equality or matches_clock_at. Full old owner/input/seed/probe
rows are also retained in the resulting fixture witness.

## Bounded diagnostic before golden capture

New ignored test suffix: diagnose_old_split_owner_inputs_v1.
Required DEADPAN_OWNER_SPLIT_DIAGNOSTIC_OUTPUT absolute fresh /tmp path,
DEADPAN_OWNER_SNAPSHOT_VARIANT and matching gen2 source-authority SHA.
It writes named logical old rows for BOTH plain-Split and explicit-pre-lattice
Split at labels3..4. It contains no Debug/raw pointer/capacity fields and uses
create_new. Parent owns its one-time execution; no diagnostic was run by worker.
No golden is created by this diagnostic.

After inspecting those actual diagnostic rows, parent can run the existing Plan
capture_legacy_snapshot_v1 producer against the gen2 old-source binary to a NEW
golden path. Do not overwrite initial output or regenerate the successful old
Audio main-work-v1.json. The original Audio golden remains tied to original
source manifest c25a... and its original pinned executable/receipt. Gen2 Plan
goldens must cite the new source-authority manifest and gen2 executable pins.

No runtime success/completeness claim until actual diagnostic and producer pass.
