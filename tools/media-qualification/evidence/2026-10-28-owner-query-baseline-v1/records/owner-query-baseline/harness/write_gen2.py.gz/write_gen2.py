from pathlib import Path
import hashlib,json,difflib
r=Path('/tmp/deadpan-owner-query-baseline-2026-10-28')
g=r/'harness/fixture-correction/gen2'
repo=Path('/Users/michael/Code/deadpan')
scoped=Path('/tmp/deadpan-query-groundwork-2026-10-26/scoped')
path=Path('crates/deadpan-plan/src/audio_owners/legacy_snapshot_v1/fixtures.rs')
for name in ['before','candidate']:
 p=g/name/path;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes((repo/path).read_bytes())
s=(repo/path).read_text()
start=s.index('fn split_root() -> Value {');end=s.index('pub(super) fn matrix()',start)
s=s[:start]+'''// audio_reference::source_prefix_behind_partition_keeps_unbound_and_retained_source_phase
// explicitly captures/installs a lattice; its bare Source-Split reference-plan
// test does NOT promise a RenderPlan Bound input. Keep these variants distinct.
fn split_documents(install_lattice: bool) -> (ProjectDocument, ProjectDocument, ProjectDocument) {
    let (voice, asset) = source(48_000, 6);
    let original = source_document(
        FrameRate::new(48_000, 1).unwrap(),
        &["voice"],
        vec![("voice", voice)],
        asset,
    );
    let before = if install_lattice {
        let state = capture_unbound_audio_bindings(
            &original,
            AudioTimingId { allocation: revision("baseline-pre-split-lattice"), ordinal: 0 },
        ).unwrap();
        let mut wire = serde_json::to_value(&original).unwrap();
        wire["audio_bindings"] = serde_json::to_value(state).unwrap();
        ProjectDocument::from_json(&wire.to_string()).unwrap()
    } else {
        original.clone()
    };
    let result = apply(
        &before,
        &CommandRequest {
            project_id: before.project_id().clone(),
            expected_revision: before.revision_id().clone(),
            new_revision: revision("baseline-split"),
            command: Command::Split {
                node: id("voice"),
                at: frames(2),
                identities: SplitIdentities {
                    nodes: (0..12).map(|n| id(&format!("baseline-cut-{n}"))).collect(),
                },
            },
        },
    ).unwrap();
    let split = result.forward.apply(&before).unwrap();
    (original, before, split)
}
fn split_owner_rows(plan: &RenderPlan, at: AudioSample) -> Vec<Value> {
    let observed = plan.audio_gain_owners(at..AudioSample(at.0 + 1), Default::default()).unwrap();
    observed.spans()[0].owners().iter().enumerate().map(|(index, member)| {
        let captured = plan.audio_owner_input(member, at, Default::default()).unwrap();
        json!({
            "member_index":index,
            "observed_owner":clock(member, plan, |v|v.0),
            "captured_input":input(&captured),
            "actual_retained_probe":retained_probe(&captured)
        })
    }).collect()
}
fn split_root() -> Value {
    let (original, before, doc) = split_documents(true);
    let plan = RenderPlan::compile(&doc).unwrap();
    let at = AudioSample(3);
    let observed = plan.audio_gain_owners(at..AudioSample(4), Default::default()).unwrap();
    // Select from ACTUAL old observations/probes, not a root/last/key assumption.
    // The resulting member index is frozen in SnapshotV1 before any new API.
    let mut selected = None;
    for (index, member) in observed.spans()[0].owners().iter().enumerate() {
        let captured = plan.audio_owner_input(member, at, Default::default()).unwrap();
        let probe = captured.retained_probe_at(at, Default::default()).unwrap();
        if probe.input().is_some_and(|value| matches!(value.domain(), AudioBoundDomain::Root(_))) {
            selected = Some((index, captured));
            break;
        }
    }
    let (selected_index, captured) = selected.expect("installed pre-Split lattice must expose a checked retained Root input");
    let member = &observed.spans()[0].owners()[selected_index];
    let alias = member.instance.node.as_str();
    let rows = split_owner_rows(&plan, at);
    fixture_json(
        "actual_source_split_with_preexisting_lattice_retained_root_round_even_clipped_window",
        &doc,
        vec![
            case(
                "split_verified_retained_owner_clipped",
                Parent::Root(&plan),
                AudioSample(2)..AudioSample(5),
                at,
                alias,
                member.kind,
            ),
            case(
                "split_verified_retained_owner_actual_domain",
                Parent::Domain(captured.context()),
                captured.context().visible_samples(),
                at,
                alias,
                member.kind,
            ),
        ],
        json!({
            "unbound_pre_split_document":serde_json::to_value(original).unwrap(),
            "bound_pre_split_document":serde_json::to_value(before).unwrap(),
            "public_source_split_command":true,
            "explicit_pre_split_lattice_capture":true,
            "selected_verified_old_member_index":selected_index,
            "actual_old_owner_rows":rows,
            "retained_domain_grid":"RootRoundEven",
            "current_variant_label_required":true
        }),
    )
}

#[test]
#[ignore = "bounded legacy fixture diagnosis only; no expected golden"]
fn diagnose_old_split_owner_inputs_v1() {
    let output = std::path::PathBuf::from(
        std::env::var_os("DEADPAN_OWNER_SPLIT_DIAGNOSTIC_OUTPUT").expect("explicit /tmp diagnostic path required")
    );
    assert!(output.is_absolute() && (output.starts_with("/tmp") || output.starts_with("/private/tmp")));
    let variant = std::env::var("DEADPAN_OWNER_SNAPSHOT_VARIANT").expect("variant required");
    assert!(matches!(variant.as_str(), "main-inherited" | "scoped-published"));
    let source = std::env::var("DEADPAN_OWNER_SNAPSHOT_SOURCE_SHA256").expect("source authority required");
    assert!(source.len() == 64 && source.bytes().all(|v|v.is_ascii_hexdigit()));
    let rows = [false, true].map(|bound| {
        let (_, before, doc) = split_documents(bound);
        let plan = RenderPlan::compile(&doc).unwrap();
        json!({"explicit_pre_split_lattice":bound,
            "before_document":serde_json::to_value(before).unwrap(),
            "split_document":serde_json::to_value(doc).unwrap(),
            "observed_window":{"start":3,"end":4},
            "old_owner_rows":split_owner_rows(&plan, AudioSample(3))})
    });
    let result = json!({"schema":"LegacySplitOwnerDiagnosticV1","variant":variant,
        "runtime_source_manifest_sha256":source,"variants":rows});
    let mut file = std::fs::OpenOptions::new().write(true).create_new(true).open(output).unwrap();
    serde_json::to_writer_pretty(&mut file,&result).unwrap();
    use std::io::Write;
    file.write_all(b"\\\\n").unwrap();
    file.sync_all().unwrap();
}
''' +s[end:]
(g/'candidate'/path).write_text(s)
