from pathlib import Path
import json,hashlib
r=Path('/tmp/deadpan-owner-query-baseline-2026-10-28')
repo=Path('/Users/michael/Code/deadpan')
scoped=Path('/tmp/deadpan-query-groundwork-2026-10-26/scoped')
path=Path('crates/deadpan-plan/src/audio_owners/tests.rs')
for label,base in [('before',repo),('scoped-before',scoped)]:
 p=r/label/path;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes((base/path).read_bytes())
p=r/'candidate'/path;p.parent.mkdir(parents=True,exist_ok=True)
p.write_text((repo/path).read_text()+'\n#[path = "legacy_snapshot_v1.rs"]\nmod legacy_snapshot_v1;\n')
