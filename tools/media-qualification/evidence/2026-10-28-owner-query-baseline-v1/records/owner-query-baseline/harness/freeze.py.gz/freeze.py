from pathlib import Path
import json,hashlib,difflib,shutil,datetime
r=Path('/tmp/deadpan-owner-query-baseline-2026-10-28')
repo=Path('/Users/michael/Code/deadpan');scoped=Path('/tmp/deadpan-query-groundwork-2026-10-26/scoped')
sha=lambda b:hashlib.sha256(b).hexdigest()
pins=[];parts=[]
for p in sorted((r/'candidate').rglob('*.rs')):
 path=p.relative_to(r/'candidate');before=r/'before'/path
 old=before.read_bytes() if before.exists() else b'';current=p.read_bytes()
 if before.exists():
  assert (repo/path).read_bytes()==old, f'main drift {path}'
  assert (scoped/path).read_bytes()==(r/'scoped-before'/path).read_bytes(),f'scoped drift {path}'
 else: assert not(repo/path).exists() and not(scoped/path).exists()
 pins.append({'path':str(path),'new':not before.exists(),'before_sha256':sha(old) if before.exists() else None,'candidate_sha256':sha(current)})
 parts.extend(difflib.unified_diff(old.decode().splitlines(True),current.decode().splitlines(True),fromfile='a/'+str(path) if before.exists() else '/dev/null',tofile='b/'+str(path)))
 for label,base in [('main-apply',repo),('scoped-apply',scoped)]:
  if (base/path).exists():
   target=r/label/path;target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(base/path,target)
(r/'harness.patch').write_text(''.join(parts))
(r/'harness/fixture-pins.json').write_text(json.dumps(pins,indent=2)+'\n')
# Snapshot enough actual old kernel and fixture dependencies to pin the interpretation.
kernel_paths=[
'crates/deadpan-plan/src/audio_owners.rs','crates/deadpan-plan/src/audio_owner_input.rs',
'crates/deadpan-plan/src/audio_owner_input/candidates.rs','crates/deadpan-plan/src/audio_domain.rs',
'crates/deadpan-plan/src/audio.rs','crates/deadpan-plan/src/audio_bound.rs',
'crates/deadpan-plan/src/audio_sampling.rs','crates/deadpan-plan/src/audio_definition.rs',
'crates/deadpan-plan/src/audio_point_domain.rs','crates/deadpan-plan/src/audio_owners/input_tests.rs',
'crates/deadpan-plan/src/audio_owners/tests.rs','crates/deadpan-core/src/audio_binding.rs',
'crates/deadpan-core/src/audio_reference.rs','crates/deadpan-core/src/split.rs',
'crates/deadpan-core/src/command.rs','crates/deadpan-audio/src/authored_eq.rs',
'crates/deadpan-audio/src/shared_eq/node_description.rs','crates/deadpan-audio/src/shared_eq/node_description_tests.rs',
'crates/deadpan-audio/src/stages.rs','crates/deadpan-audio/src/eq_admission/fixture.rs']
kernel=[]
for path in kernel_paths:
 for label,base in [('main',repo),('scoped',scoped)]:
  data=(base/path).read_bytes();target=r/'harness/runtime-kernel-snapshots'/label/path
  target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(data)
  kernel.append({'variant':label,'path':path,'sha256':sha(data),'bytes':len(data)})
(r/'harness/kernel-source-pins.json').write_text(json.dumps(kernel,indent=2)+'\n')
overlay={item['path']:(r/'candidate'/item['path']).read_bytes() for item in pins}
for label,base,listfile in [('main-inherited',repo,'source-files.json'),('scoped-published',scoped,'scoped-source-files.json')]:
 paths=sorted(set(json.loads((r/listfile).read_text()))|set(overlay))
 entries=[]
 for path in paths:
  data=overlay[path] if path in overlay else (base/path).read_bytes()
  entries.append({'path':path,'sha256':sha(data),'bytes':len(data)})
 payload={'schema':'LegacyRuntimeSourceAuthorityV1','variant':label,'base_head':'296f2b894ccc4c32c5c6abc09db0d0bba2263f20',
  'old_query_kernels':True,'source_count':len(entries),'harness_pins_sha256':sha((r/'harness/fixture-pins.json').read_bytes()),'sources':entries}
 path=r/'harness'/('runtime-source-authority-'+label+'.json')
 path.write_text(json.dumps(payload,indent=2)+'\n')
 print(path.name,sha(path.read_bytes()),len(entries))
for name in ['harness.patch','harness/fixture-pins.json','harness/kernel-source-pins.json']:
 print(name,sha((r/name).read_bytes()))
