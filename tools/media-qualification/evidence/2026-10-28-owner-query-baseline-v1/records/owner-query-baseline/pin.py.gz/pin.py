from pathlib import Path
import json,sys,shutil,hashlib
s=Path(__file__).resolve().parent
label=sys.argv[1]
receipt=json.loads((s/(label+'.json')).read_text())
assert receipt['exit_code']==0 and receipt['sources_unchanged']
artifacts=[]
for line in (s/(label+'.stdout')).read_text().splitlines():
 try:a=json.loads(line)
 except ValueError:continue
 if a.get('reason')!='compiler-artifact' or not a.get('executable') or not a.get('profile',{}).get('test'):continue
 package='audio' if 'deadpan-audio#' in a['package_id'] else 'plan' if 'deadpan-plan#' in a['package_id'] else None
 if package and a['target']['name'] in ['deadpan_audio','deadpan_plan']:
  artifacts.append((package,a))
assert sorted(p for p,a in artifacts)==['audio','plan']
pins=[]
for package,a in artifacts:
 dest=s/(label+'-'+package)
 assert not dest.exists()
 shutil.copyfile(a['executable'],dest);shutil.copymode(a['executable'],dest)
 b=dest.read_bytes()
 pins.append({'package':package,'path':str(dest),'sha256':hashlib.sha256(b).hexdigest(),'bytes':len(b),'artifact':a})
(s/(label+'-pins.json')).write_text(json.dumps(pins,indent=2)+'\n')
print(json.dumps({'binaries':len(pins),'pins':str(s/(label+'-pins.json'))}))
