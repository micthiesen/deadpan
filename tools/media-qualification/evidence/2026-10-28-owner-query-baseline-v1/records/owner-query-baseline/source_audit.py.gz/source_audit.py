from pathlib import Path
import json,hashlib
s=Path(__file__).resolve().parent
rows=json.loads((s/'harness/kernel-source-pins.json').read_text())
roots={'main':Path('/Users/michael/Code/deadpan'),'scoped':Path('/tmp/deadpan-query-groundwork-2026-10-26/scoped')}
hooks={
 'crates/deadpan-plan/src/audio_owners/tests.rs':'\n#[path = "legacy_snapshot_v1.rs"]\nmod legacy_snapshot_v1;\n',
 'crates/deadpan-audio/src/shared_eq/node_description_tests.rs':'\n#[path = "legacy_query_receipts.rs"]\nmod legacy_query_receipts;\n'
}
record=[]
for row in rows:
 p=roots[row['variant']]/row['path']
 b=p.read_bytes()
 if row['path'] in hooks:
  t=b.decode();hook=hooks[row['path']]
  assert t.count(hook)==1 and t.endswith(hook),row
  original=t[:-len(hook)].encode()
  assert len(original)==row['bytes'] and hashlib.sha256(original).hexdigest()==row['sha256'],row
  kind='existing_test_host_plus_exact_module_declaration'
 else:
  assert len(b)==row['bytes'] and hashlib.sha256(b).hexdigest()==row['sha256'],row
  kind='unchanged_product_kernel_or_reference'
 record.append({'variant':row['variant'],'path':row['path'],'classification':kind,'current_sha256':hashlib.sha256(b).hexdigest()})
for before,after in [('baseline-build','baseline-build2'),('baseline-scoped-build','baseline-scoped-build2')]:
 old=next(x for x in json.loads((s/(before+'-pins.json')).read_text()) if x['package']=='plan')
 new=next(x for x in json.loads((s/(after+'-pins.json')).read_text()) if x['package']=='plan')
 assert old['sha256']!=new['sha256']
(s/'source-audit.json').write_text(json.dumps({'product_kernel_edits':False,'variant_rows':record,'changed_fixture_positive_plan_binary_differs_from_known_negative':True,'initial_audit_correction':'Initial exact comparison also included two test host files pervariant; their only changes are the pinned module declarations above.'},indent=2)+'\n')
print('36 source rows unchanged; four test-host rows differ only by exact producer declarations. Positive Plan binaries differ from known-negative fixture binaries.')
