from pathlib import Path
import gzip
import hashlib
import json

scratch = Path(__file__).resolve().parent
repo = Path('/Users/michael/Code/deadpan')
destination = repo / 'tools/media-qualification/evidence/2026-10-28-owner-query-baseline-v1'
assert not destination.exists(), 'Archive only after all listed receipts are terminal'
prior = repo / 'tools/media-qualification/evidence/2026-10-28-original-sharing-budget/inventory.json'
prior_sha256 = 'cee946dcaf542bcd1216a077ce7f987f96f2a01c04fd0f3cf26c9c94e950fd7a'
assert hashlib.sha256(prior.read_bytes()).hexdigest() == prior_sha256
allowed = {'.rs', '.json', '.py', '.md', '.patch', '.stdout', '.stderr', '.txt'}
excluded_names = {'qualification-draft.md'}

# These are the exact 17 terminal runner receipts. Two first-generation Plan
# snapshot runs are expected fixture failures (101); the corrected generation-2
# captures and all other listed runs must pass.
terminal_codes = {
    'baseline-build.json': 0,
    'baseline-build2.json': 0,
    'baseline-scoped-build.json': 0,
    'baseline-scoped-build2.json': 0,
    'baseline-main-snapshot.json': 101,
    'baseline-scoped-snapshot.json': 101,
    'baseline-main-snapshot2.json': 0,
    'baseline-scoped-snapshot2.json': 0,
    'baseline-main-split-diagnostic2.json': 0,
    'baseline-scoped-split-diagnostic2.json': 0,
    'baseline-main-work.json': 0,
    'baseline-scoped-work.json': 0,
    'baseline-main-library-audio.json': 0,
    'baseline-main-library-plan.json': 0,
    'baseline-scoped-library-audio.json': 0,
    'baseline-scoped-library-plan.json': 0,
    'baseline-strict.json': 0,
}
for name, expected in terminal_codes.items():
    receipt = json.loads((scratch / name).read_text())
    assert receipt.get('exit_code') == expected, (name, receipt.get('exit_code'))
    assert receipt.get('finished_at') and receipt.get('sources_unchanged') is True
    assert receipt.get('binaries_unchanged') is True
    if expected == 101:
        stdout = (scratch / name.replace('.json', '.stdout')).read_text()
        stderr = (scratch / name.replace('.json', '.stderr')).read_text()
        assert 'fixture' in (stdout + stderr).lower(), name

# Assert generation-2 source authorities and six immutable output pins.
for variant in ['main-inherited', 'scoped-published']:
    source = json.loads((scratch / 'harness' / f'runtime-source-authority-{variant}.json').read_text())
    assert source['old_query_kernels'] is True
for name in ['main-snapshot-v1-gen2.json', 'scoped-snapshot-v1-gen2.json',
             'main-split-diagnostic-gen2.json', 'scoped-split-diagnostic-gen2.json',
             'main-work-v1.json', 'scoped-work-v1.json']:
    data = (scratch / name).read_bytes()
    digest = hashlib.sha256(data).hexdigest()
    assert any(row['path'] == name and row['sha256'] == digest
               for row in json.loads((scratch / 'golden-pins-gen2.json').read_text())['files']), name
for variant, expected in [
    ('main-inherited', '2ba58d9f8272d67f5851ab6c183cb8b5bd3e3a362c747330938232da8a4412d9'),
    ('scoped-published', '551e2eb1c627445e1456e7d9d9c24a7d4e6975e9a77f15da7c9cdc91376295a3'),
]:
    path = scratch / 'harness/fixture-correction/gen2a' / ('runtime-source-authority-' + variant + '-gen2.json')
    assert hashlib.sha256(path.read_bytes()).hexdigest() == expected
contract = Path('/tmp/deadpan-original-query-admission-2026-10-28/interface-contract.md')
assert hashlib.sha256(contract.read_bytes()).hexdigest() == '34e027354671ae37ecf16132e0c586d47ecf94317a1d8cd510401b21a511b5a6'
audit = json.loads((scratch / 'source-audit.json').read_text())
assert audit['product_kernel_edits'] is False
rows = audit['variant_rows']
assert len(rows) == 40
assert sum(row['classification'] == 'unchanged_product_kernel_or_reference' for row in rows) == 36
assert sum(row['classification'] == 'existing_test_host_plus_exact_module_declaration' for row in rows) == 4
assert audit['changed_fixture_positive_plan_binary_differs_from_known_negative'] is True
assert all(row['classification'] in {'unchanged_product_kernel_or_reference', 'existing_test_host_plus_exact_module_declaration'} for row in rows)

pins = json.loads((scratch / 'published-golden-pins.json').read_text())
for row in pins:
    published = repo / row['published_path']
    data = published.read_bytes()
    assert len(data) == row['bytes'] and hashlib.sha256(data).hexdigest() == row['sha256']
assert json.loads((scratch / 'golden-pins-gen2.json').read_text())['fixture_arrays_equal'] is True
assert json.loads((scratch / 'golden-pins-gen2.json').read_text())['plan_work_receipts_equal'] is True
assert json.loads((scratch / 'golden-pins-gen2.json').read_text())['split_selection_indices_verified'] is True

entries = []
def store(group: str, path: Path, relative: Path) -> None:
    data = path.read_bytes()
    record = destination / 'records' / group / relative
    record = record.with_name(record.name + '.gz')
    record.parent.mkdir(parents=True, exist_ok=True)
    compressed = gzip.compress(data, mtime=0)
    record.write_bytes(compressed)
    entries.append({
        'path': str(record.relative_to(destination)),
        'bytes': len(compressed),
        'sha256': hashlib.sha256(compressed).hexdigest(),
        'expanded_bytes': len(data),
        'expanded_sha256': hashlib.sha256(data).hexdigest(),
    })

# Include allowed source/design/test/receipt material only; compiled binaries are excluded by suffix.
for path in sorted(scratch.rglob('*')):
    if not path.is_file() or path.suffix not in allowed or path.name in excluded_names:
        continue
    store('owner-query-baseline', path, path.relative_to(scratch))

# Archive the closely related query-design contract and source pins/snapshots.
related = Path('/tmp/deadpan-original-query-admission-2026-10-28')
for path in sorted(related.rglob('*')):
    if not path.is_file() or path.suffix not in allowed:
        continue
    store('query-design', path, path.relative_to(related))

manifest = {
    'schema_version': 1,
    'base_revision': (scratch / 'base-revision.txt').read_text().strip(),
    'scope': (
        'Frozen old-query SnapshotV1 and old WorkControl baseline harness, '
        'generation-2 Source Split fixture, exact main/scoped golden receipts, '
        'and bounded query-design source contract. No query kernel implementation or change.'
    ),
    'prior_original_sharing_inventory': {
        'inventory_sha256': prior_sha256,
        'path': '../2026-10-28-original-sharing-budget/inventory.json',
        'note': 'Reference by hash only; do not duplicate the prior inventory.'
    },
    'expected_terminal_receipts': terminal_codes,
    'expected_first_generation_fixture_failures': [
        'baseline-main-snapshot.json', 'baseline-scoped-snapshot.json'
    ],
    'files': entries,
}
manifest_path = destination / 'inventory.json'
manifest_path.write_text(json.dumps(manifest, indent=2) + '\n')

# Compression and checksum verification occurs when the parent runs this script.

stored = expanded = 0
for row in entries:
    packed = (destination / row['path']).read_bytes()
    plain = gzip.decompress(packed)
    assert len(packed) == row['bytes'] and hashlib.sha256(packed).hexdigest() == row['sha256']
    assert len(plain) == row['expanded_bytes'] and hashlib.sha256(plain).hexdigest() == row['expanded_sha256']
    stored += len(packed); expanded += len(plain)
print(json.dumps({'files': len(entries), 'stored_bytes': stored, 'expanded_bytes': expanded,
                  'inventory_sha256': hashlib.sha256(manifest_path.read_bytes()).hexdigest()}))
