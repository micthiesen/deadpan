# Independent review: frozen old-query SnapshotV1 harness

Reviewed `harness.patch`, generated candidate files, fixture/runtime pins, and `notes.md`. No Cargo, rustc, or Git command was run. No golden output has been captured by this review.

## Findings

No concrete oracle defect found in the reviewed harness design/code.

## Coverage checked

- Snapshot serializers use named logical fields for ordered windows, owner clocks/provenance/play/affine labels, query lookup/work, Domain and seed state, retained Root/Point/Empty references, captured input, and normalized exact-ratio strings. Private node indices are converted back to stable node IDs; no pointers, Debug dumps, raw bytes, or capacities are serialized. The private parity bit is read through the public Serialize representation.
- `case` records the actual old single-sample query, selects the member by its explicit alias/kind before calling the old `owner_input`, then compares candidate capture on that member and index. The separate wide query is also frozen in order. This gives later code a usable anti-substitution oracle.
- The resumed hidden-domain fixture proves a literal Root-vs-seeded Domain query difference on the same sample window, while deliberately showing a coarse identity collision and rejecting use of the live-root member against the retained plan. Repeat fixtures distinguish equal coarse Repeat owners with different play records and exercise default/overridden gaps and wrong-branch refusal. PointCeil/Shift and the actual Source Split cases are built from plan metadata without opening media or claiming provider authority.
- The old WorkControl receipt producer runs the actual `original_context` helper. It independently measures Q, C, retained-probe, and optional retained-owner-query work, then records ample, exact-total, one-short-total, one-short-query, and one-short-capture outcomes with typed error variants and ledger counters. It explicitly refuses unknown errors instead of using Debug formatting. The Plan snapshot labels legacy receipts as success-only where failure paths cannot expose internal receipts.
- Output producers require explicit absolute `/tmp` paths and use `create_new`, with variant and source-manifest SHA recorded. This prevents accidental overwrite and keeps main-inherited versus scoped-published captures distinct.

## Qualification boundary

The ignored producers are not evidence until each is run exactly once against the pinned old executable and matching source/fixture manifests, and the resulting JSON and SHA are retained. The first lib-only compile was still running when assigned; I did not treat compile or fixture coverage as a captured baseline. Future query wrappers must not regenerate these goldens.

## Generation 2a Source Split fixture correction

Reviewed `harness/fixture-correction/gen2a/fixture-correction.patch` and its pins/notes. No production or query-kernel change is present. The correction is supported by the identified distinction: the bare public Source Split reference-plan test does not guarantee a retained `AudioOwnerInput`; the new fixture explicitly captures and installs the unbound lattice before applying the same public Split command, matching the existing `RenderPlan` lifecycle test. It keeps the unbound, bound-before-Split, and post-Split documents distinct, then scans actual ordered old owner observations and accepts only a member whose actual retained probe yields `Some(Root)`. It records all rows and uses a separately named create-new diagnostic for bare versus installed-lattice variants. This avoids fabricating a private Domain or assuming the last member is retained.

The earlier successful Audio work receipts and their original source authority remain untouched; the Plan snapshot producer must run against the corrected generation-2 source manifest and a new output path. Parent reports that this diagnostic and corrected Plan producer have not yet been run, so neither golden qualification nor full matrix success is established here.

One concrete runtime assertion to check during the planned diagnostic: the stored `selected_verified_old_member_index` should equal the `selected_member_index` returned by both generated `case` rows for the selected alias/kind. The correction's discovery loop chooses the first owner whose probe is `Some(Root)`, while `case` reselects by alias and kind; checking those indexes makes the oracle prove that the same observed member is used end-to-end.

## Runtime qualification follow-up

Parent reports both generation-2 diagnostics and Plan SnapshotV1 producers passed for main/scoped; the five fixture families produced 14 cases, full fixture arrays and Plan work-receipt arrays compare equal, and both Split discovery indexes are 0 and match each case's `selected_member_index`. Parent also reports both old WorkControl producers passed with Root/Domain/Retained totals 22/22/60 in each variant, main/scoped arrays equal, existing main/scoped library suites passed, and strict lint passed. These are parent-run results; I did not rerun tests or produce/copy the JSON. The six golden outputs and published fixture copies are described as immutable and must remain untouched. This baseline captures old query behavior only; no query kernel was changed or implied.
