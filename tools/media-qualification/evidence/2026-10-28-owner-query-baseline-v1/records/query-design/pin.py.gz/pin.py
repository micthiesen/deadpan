from pathlib import Path
import hashlib,json
base=Path('/Users/michael/Code/deadpan')
scratch=Path('/tmp/deadpan-original-query-admission-2026-10-28')
paths=[
'crates/deadpan-plan/src/audio_owner_input/candidates.rs','crates/deadpan-plan/src/audio_owner_input.rs',
'crates/deadpan-plan/src/audio_owners.rs','crates/deadpan-plan/src/audio.rs',
'crates/deadpan-plan/src/audio_boundary.rs','crates/deadpan-plan/src/audio_bound.rs',
'crates/deadpan-plan/src/audio_domain.rs','crates/deadpan-plan/src/audio_definition.rs',
'crates/deadpan-plan/src/audio_signal.rs','crates/deadpan-plan/src/audio_point_domain.rs',
'crates/deadpan-plan/src/audio_sound_admission.rs','crates/deadpan-plan/src/audio_allocated.rs',
'crates/deadpan-core/src/audio_binding.rs','crates/deadpan-core/src/audio_reference.rs',
'crates/deadpan-core/src/repeat_layout.rs','crates/deadpan-core/src/occurrence.rs',
'crates/deadpan-core/src/document.rs',
'crates/deadpan-audio/src/authored_eq.rs','crates/deadpan-audio/src/shared_eq/node_description.rs',
'crates/deadpan-audio/src/shared_eq/node_description_tests.rs',
'crates/deadpan-audio/src/sound_context_admission.rs','crates/deadpan-audio/src/stages.rs',
'crates/deadpan-audio/src/shared_eq/original_inputs.rs',
]
data={'root':str(base),'files':{}}
for p in paths:
 b=(base/p).read_bytes()
 data['files'][p]={'sha256':hashlib.sha256(b).hexdigest(),'bytes':len(b)}
 (scratch/'source-snapshot'/p).parent.mkdir(parents=True,exist_ok=True)
 (scratch/'source-snapshot'/p).write_bytes(b)
(scratch/'source-pins.json').write_text(json.dumps(data,indent=2)+'\n')
print('Pinned',len(paths),'sources')
