# Actual shared kernels to instrument

Audio shared_eq/node_description::original_context
  Root / actual borrowed Domain
  -> sealed AudioOwnerInputCandidates
     -> audio_owners::query_mapped
        -> Walk clone + audio_owners::walk
           -> audio_bound::bound_at
              -> Core resolve_owner/resolve_binding
                 -> template validate_with / resolve_with
                    -> scoped_repeats / project_scoped_inner
           -> bound.envelope_domain -> actual Domain -> recursive walk
        -> fallible RawOwner map + result span
     -> capture(self, checked actual index)
        -> audio_owner_input::capture_observed
           -> audio::audio_walk_owner_input
              -> audio_walk_inner
                 -> actual owner/processor capture
                 -> complete walk + bound/Core/Preserve/boundary construction
              -> drop actual returned Leaf/Stage
           -> owner.clone + move captured Domain
        -> drop candidates query
  -> authored_eq::finish_paid_owner_input
     -> retained_probe_at
        -> audio_walk_inner with EditorialCapture
        -> bound.raw_domain: Root / Point / Empty
     -> retained.owners -> envelope_domain -> query_mapped
     -> final-sharing worker's actual admitted Context Arc
