# Primary implementation decisions

Keep the legacy semantic validation and branch order in the shared kernels.
Do not move later scalar/range/depth checks ahead of an existing allocation
just to simplify resource admission. With adequate resources, valid results
and invalid-input errors must retain their original order and exact values.

New cancellation, deadline, work or residency refusal occurs immediately at
its actual metered inspection/allocation site. It may therefore precede an
existing later semantic error. This is the intended new failure precedence;
do not allocate first, defer the failure, retry legacy, or convert it into
absence. Test both the ample-budget legacy error and resource refusal at the
earlier allocation site, including Domain seed construction before the
existing query limits validation.

The first coherent delivery is the complete actual candidate query closure,
including reached Core binding/projection temporaries. The same candidate
query stays owned and charged during the actual capture call. Earlier/shared
final-sharing work must be preserved. A query-only delivery explicitly leaves
capture/discarded-span and retained-probe/owner construction uncovered and
cannot activate cold recursion/batching.

Classify every primitive work debit versus local parent account_child call
before implementation. The actual remaining read budget can decrease during
cache eviction inside admission; never rely on initial query allowance to
defer real work charging.
