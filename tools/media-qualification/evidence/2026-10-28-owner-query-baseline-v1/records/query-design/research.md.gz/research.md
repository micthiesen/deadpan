# Admission through the real Original owner query and capture

Read-only implementation design, 2026-10-28. source-pins.json and source-snapshot/
pin23 actual files. No live source, Git state, Cargo/rustc, provider or native
execution changed. Existing final-sharing work belongs to the other worker;
this proposal complements it and must not overwrite that work.

## Recommendation

Instrument the existing shared owner-query and audio-capture kernels with a
bounded construction policy. Return an admitted candidates carrier which owns
the SAME query, then consumes the SAME member index and SAME borrowed parent
for the SAME capture. Keep temporary leases with the actual intermediate
values through the nested Core binding/projection path.

This requires a coherent Core+Plan patch, not just a new candidates signature.
The smallest complete first implementation unit is the real candidate QUERY
closure through its reachable binding helpers. Capture and retained probing
then reuse the same admitted helpers but require the independent audio walker
and its discarded result to be covered. Do not activate a "full Original
admitted" consumer until all reached phases are covered. A partial numerical
integration may describe its exact covered allocations but cannot authorize
additional cold histories or batching.

Use ordinary actual input lengths and incremental buffer capacities. No
whole-plan node-count allowance, bytes-per-work estimate, second discovery
walk, provider/native planner, prefix/query cache or limit increase is needed.

## Exact call graph and immutable authorities

node_description.rs:125 original_context:
- Root -> RenderPlan::audio_owner_input_candidates_at, candidates.rs:168.
- Domain -> AudioDomain::owner_input_candidates_at, candidates.rs:184.
  Parent holds the exact borrowed Domain, including its hidden seed. No
  reconstructed Domain, Arc<RenderPlan>, OwnerKey certificate or new owner
  selection enters the query.
- Audio pays Q and validates all observed treatment layers, then selects the
  FIRST actual member whose OwnerKey equals the requested key.
- candidates.capture(self, actual_index, fresh_limits), :82, holds the query
  owner alive while capture_observed receives that exact borrowed member and
  Root/Domain seed. The query drops before capture returns its Input.
- without_selection consumes the same query, records Q and makes no fresh
  limits request. Preserve that absence behavior.

Query kernel:
  audio_gain_owners (:343) / Domain::gain_owners (:408)
  -> Walk::root / Walk::from_seed (:577/:603)
  -> query -> query_mapped (:669)
  -> walk (:762), including Sequence binary search, Repeat compact-run lookup,
     nominal Retime/Preserve clock traversal and inactive retained support
  -> bound_at (audio_bound.rs:135) when a node/gap actually has a binding
  -> AudioBindingState::resolve_in / resolve_gap_in (Core audio_binding:1692)
  -> resolve_owner -> resolve_binding (:1790)
  -> AudioPlacementTemplate::resolve_with (:866)
  -> validate_with (:715), scoped_repeats, ClockScope::project
  -> FrozenAudioLayout::project_scoped_inner (:2358), then resolved lattice
  -> AudioBound::envelope_domain (:351)
  -> Walk::from_seed of that Domain, recursively walk the exact transferred
     reference position with AudioOwnerClockOrigin::Retained
  -> fallible RawOwner-to-Clock map, then one AudioOwnerSpan into result.

Capture kernel:
  capture_observed (audio_owner_input.rs:322)
  -> audio_walk_owner_input (audio.rs:467)
  -> audio_walk_inner (:486), stop_at_preserve=true, stop_at_bindings=true
  -> same bound_at/Core resolver when reached
  -> capture actual AudioDomainSeed at owner or stopping processor
  -> finish the SAME walk through scalar validation AND return Leaf/Stage
  -> discard that real AudioWalkSpan at audio_walk_owner_input's semicolon
  -> clone selected observed Clock, move captured seed into AudioOwnerInput.

The capture's first successful seed assignment DOES NOT end execution. It can
still build a Bound box or Preserve descriptor, constraints and exact boundary
origins; perform fallible arithmetic/eligibility checks; and fail afterward.
No early return is valid merely because the caller ignores the final span.

Retained continuation, a separate necessary closure:
  finish_paid_owner_input
  -> retained_probe_at (:80), same audio_walk_inner with EditorialCapture
  -> bound.raw_domain for a real Bound result
  -> Root AudioDomain OR Point AudioPointDomain/AudioSignal, or Empty
  -> retained.owners (:484 in audio_owners) -> envelope_domain -> query_mapped,
     mapping actual consumer positions to the retained reference grid
  -> existing boundary match -> final-sharing worker's admitted Arc choice.

No Frozen layout validate/build_index runs in these query calls. Current
projection/scoped_repeats/branch_below use the immutable prebuilt index. Do
not reserve a new all-layout BTreeMap or claim removal of an index rebuild.
Compact Repeat lookup visits compact segments, not expanded individual plays.

## Allocation inventory and overlapping ownership

| Actual site | Newly owned storage / lifetime |
| --- | --- |
| Domain gain_owners -> Walk::from_seed, audio_owners:603 | Repeat vector and owning definition/gap IDs. This happens BEFORE query_mapped's own limits.validate. Keep existing scalar/range/error order with adequate admission; no preflight clone. |
| query_mapped:701 seed.clone | A separate walk Repeat vector/IDs for this span. Original seed remains live. One-sample input still currently executes this clone. |
| walk:857 instance construction | Per-reached-node Repeat vector clone and NodeId; gap-after ID. Some are temporary when the node resolves a binding; others move to RawOwner. |
| walk:942 RawOwner push | Grow result RawOwner buffer before push; definition and full origin (including retained instance/path) owning copies. Preserve play and inactive fields. |
| walk:1049/1062 Repeat descent | Grow current state's Repeat buffer, plus compact selected-play IDs. No expanded iteration array. |
| walk:867-939 bound path | Instance + optional definition-exclusion vector; Core resolved placement; mapped constraint vector in AudioBound; envelope Domain construction with initial constraint and copies of bound evaluation paths/constraints; retained origin copies; recursive walk. Outer state, bound and Domain remain in scope during the recursive call. |
| query_mapped:725-744 collect | Raw buffer/iterator and mapped AudioOwnerClock buffer can coexist, plus their moved inner paths. AudioSampleMap::new stays at the current postwalk map point. Do not move its failure into per-node descent. |
| query_mapped:745 spans.push | Result span vector. One nonempty integer-sample request admits at most one progressing span, but still use the common query loop and its invariant checks. |
| audio_walk_inner:534-547 seeded entry | Copies constraints/editorial/repeats/retimes and gap. Entry Domain stays borrowed/alive. |
| audio_walk_inner:567/675/695 etc | Growing constraints/editorial/repeats/retimes buffers. Some constraint elements own gap IterationIds. |
| audio_walk_inner:647 and :972 capture assignments | Copied inherited prefix constraint/editorial vectors, repeated path/retimes vectors, definition and instance. Copied seed remains live while the original walk continues. No free borrowing view is returned. |
| audio_walk_inner:610/740/885 | Box<AudioBound> or AudioStageDescriptor with owning plan IDs/selector/instance/child. These may be discarded, but must be admitted BEFORE allocation. |
| audio_boundary:50 capture, :105/:126 pushes | Per-edge InstancePath clone and result origin buffer; potentially many exactly coincident origins. Clearing an edge drops elements but retains vector capacity. |
| audio_walk_inner:1045-1081 return | Leaf/Stage owns moved paths/retimes/content/boundaries. Temporary returned value drops before capture_observed clones selected Clock. |
| capture_observed:351 owner.clone | Exact observed Clock shape includes definition, instance, gap-after, and full retained origin. Query remains alive through this last clone. Move captured Domain; do not clone it again here. |
| retained_probe_at:92-111 | EditorialCapture copies plus retained processing span, then raw_domain; these can coexist with still-live source Input. Root and Point forms are distinct. |
| bound.raw_domain / Point constructor | Root initial constraint plus definition/gap paths, or PointDomain+Signal metadata. Point does not mean a metadata-free scalar view. |

IDs use shared Arc payloads. Follow the existing conservative owning-edge
accounting consistently; no new strings are needed. Copying an existing Arc
does not allocate its payload again physically. Borrowed immutable RenderPlan
and FrozenAudioLayout/index storage is excluded from new construction storage;
the already responsible plan owner must keep it alive as before.

The successful query result stays alive through capture. The source Input
then stays alive through retained probing and final sharing. The final-sharing
worker's copy overlaps Input, but the candidates query has already dropped.
Current-sound metadata and existing native/PCM/cache charges coexist with all
these phases. Leases must follow actual lifetime, not the last lexical read.

## A bounded generic policy seam that preserves one algorithm

Keep public legacy APIs as unmetered wrappers around the SAME kernels.
Add metered variants only when the actual numerical consumer is in the same
patch. Use a trusted allocation policy with stable issuer and independent
RAII Lease, checked Layout arithmetic and typed policy error. Do not export
an authority type constructible from caller-supplied rows/IDs.

Conceptual carrier, adapting final-sharing worker names rather than inventing
parallel token families:
- AdmittedCandidates<'context,'plan,I,L> owns current sealed candidates/query
  BEFORE its query lease. Parent/at/limits stay sealed as now.
- capture consumes it; observed is borrowed from its own actual query;
  returned AdmittedInput owns actual Input BEFORE its retained capture lease.
- without_selection drops query before lease and preserves its actual Q
  receipt, including a successful absent query with no fresh budget.
- local Tracked<T,L> guards pair actual values with each temporary lease.
  No allocating side registry or one heap token per allocation is necessary.
- associated Error must propagate actual StageAudio cancellation, timeout,
  memory refusal and canonical work errors without mapping them to invalid
  plan or permission absence. Core cannot depend on Plan/Audio: use a Core
  generic policy seam plus an explicit CoreError{Document,Policy(E)} adapter,
  mapping Document through PlanError at the Plan boundary. No new blanket
  StageAudioError:From<DocumentError> is required.

Thread the policy into query_mapped/walk and audio_walk_inner, not into a
parallel one-sample walker. Borrowed plan authorities/ranges and all arithmetic
and branch decisions stay in the existing functions. Private allocation
helpers perform explicit field copies, vector growth and Box construction.

### Buffers and real realloc peak

For known copied slices use exact requested length capacity, after checked
Layout::array<T>(len) reservation. For push buffers use an explicit checked
capacity policy based on current capacity, not maximum_spans or plan nodes.
Before growth admit the full NEW buffer IN ADDITION to the still-live old
buffer; create new buffer, move elements, drop old allocation before releasing
its buffer lease. Keep element-owned descendant charges separate from buffer
capacity so moving elements does not release them.

An admitted owning iterator must retain the RawOwner buffer lease until that
buffer actually drops. Explicitly allocate a mapped owner buffer before the
fallible conversion if necessary to remove hidden collect capacity behavior.
The current standard library collect may reuse an in-place buffer; a new
explicit implementation can change peak even if values/work match. Measure
actual layouts/capacities and test that change, do not claim identical heap.
One-sample result span capacity1 is justified by integer progress; no need to
reserve4096 spans. Do not silently turn multi-window APIs into single-span.

Merge surviving child charges when values move into a result, not every
temporary allocation into a query-wide monotonic sum. Core resume phase terms,
reanchor projections, validation vectors and discarded spans must release
their own guards at the real drop points. Otherwise a long sequential valid
query could be refused from a sum of dead workspaces even with a tiny peak.
No lease release happens merely when a value is temporarily taken for use.

## Core binding boundary and the BTreeSet issue

Reachable transient sets are specifically:
1. AudioBindingEnvironment::validate :404 'seen': repeats then excluded outer
   Repeat IDs. Input repeat depth is checked first; outside_repeats length is
   checked later at its current point.
2. AudioPlacementTemplate::validate_with :774 'live': live argument IDs.
3. Same function :782 'clauses': birth clause IDs.
They hold borrowed IDs, not cloned documents; each logical input is depth
bounded (MAX_DOCUMENT_DEPTH256, environment can see two such slices).

Preferred portable path: replace only these three validation scratch sets
with a fallible bounded sorted-Vec set, while retaining the SAME validation
loop and sorted iteration semantics. Allocate from real input lengths at the
current actual entry/first-insert point, not MAX_DOCUMENT_NODES. For 'seen',
the initial repeats capacity is known; extend only after the EXISTING outside
depth guard. Keep both old/new buffer charges during growth. 'live' capacity
can use actual arguments.len, 'clauses' births.len (both<=256), preferably
lazily on first insert so empty sets allocate nothing. Capacity bounds must
not run the outside guard earlier or skip duplicates/foreign-branch checks.

Use checked binary search with explicit work/check before each reached key
comparison, and bill new element shifts at actual insertion. Preserve sorted
iteration (later for-repeat validation currently iterates BTreeSet order).
Read-only key string comparison is bounded by the existing identity limits;
do not invent per-byte billing. These are actual algorithm/storage changes,
so new comparisons/shift charges are additional work, not a weight tweak.
Existing error text/branch order and all successful coordinates stay exact.
Work-limit changes must be reported and qualified, never hidden by caps.

Alternative: retain BTreeSet and reserve a proven per-insert upper bound for
actual leaf/internal nodes, splits and new root, releasing with each set.
That requires a pinned Rust node layout/allocation/split proof, including
temporary coexistence. No such proof was established here; installed Rust
source/docs at the checked1.97.1 paths were absent. Neither
size_of::<BTreeSet<_>>() nor a guessed bytes-per-entry covers node allocations.
Do not use a global allocator hook, project unsafe or an all-graph set bound.

Core other needed actual sites:
- scoped_repeats result Vec and scoped projection output instance/path clones.
- validate_with's temporary projected captured-argument instance/vec.
- resolve_with's required Repeat vector, output Repeat path and clock/gap IDs.
- sequential resume/reanchor resolved placements, including projections.
Current Frozen index is borrowed and needs no construction reservation.
Standard BTreeMap reads and Repeat compact-run lookup allocate no new tree.

## Work/control contract: avoid nested double billing

New admission can evict real cache entries. Current make_room_for calls
evict_original_input, whose probes/removal spend real controlled work. Thus
remaining read allowance CAN change inside allocation admission. Do not assume
the initial query limit guarantees a later aggregate spend will fit.

Preferred metered contract follows current sound construction:
- each authoritative primitive existing work debit checks its original local
  budget first, then forwards the SAME debit once to WorkControl;
- extra allocation/identity/set inspection work is similarly real and billed;
- nested Core/project calls keep their local budget/receipt, but parents use
  explicit account_child(receipt) to debit local totals/lookup bookkeeping
  without forwarding that ALREADY forwarded work again;
- unmetered wrappers retain the original successful reported work and no new
  resource inspection work, except explicitly shared scratch-set algorithm
  changes whose actual costs must be qualified for both entry modes;
- Audio's admitted query/capture branch must not then call
  spend_plan_work(query.work()/capture_work()) again. Typed carrier distinguishes
  already forwarded receipt from the legacy unpaid return; no arbitrary
  subtraction or refund of work that ran.

This distinction is needed at Plan bound_at -> resolved.work; Core template
-> scoped_repeats/project.work; and caller -> Q/C. Keep all leaf actual
budget.spend and aggregate parent sites classified in review. Returning Some
or None has actual work; query/capture errors poison/consume the carrier.
Streaming actual partial charges on failure can differ from the old
success-only aggregate API; document this truthful new accounting, preserve
the typed failure, and never reset work or retry legacy after refusal.

Capture retains min(stored_allowance-Q, fresh_capture_allowance), including
actual newly metered query work. Internal zero still reaches the existing
structural limit, not InvalidAudioLimits. Shared read max remains16*1024*1024
WORK UNITS; each AudioQueryLimits maximum_work stays65,536. These are not
byte limits. Local child caps and depth checks stay unchanged.

## Why a specialized single-sample shortcut is insufficient

One sample justifies a one-span result capacity. It does not prove:
no retained binding, nominal clock equals raw grid, no inactive support,
no Preserve input clock, no old-domain constraints, or no hidden allocations.
Calling a separate simplified traversal for Root and then capture for Domain
would duplicate the authority algorithm and risk lost default gaps, stable
Repeat plays, fractional overlap, exact source selection or postcapture errors.

A shared kernel parameter choosing result capacity is safe. Moving scalar
checks/creating AudioSampleMap while descending instead of its current final
map, using OwnerKey as a parent, skipping discarded boundaries, or exiting
after capture is not this mechanical admission patch.

## Implementation responsibilities and acceptance contract

1. Core owner: narrow construction-policy/error/guard primitives; the three
   sorted scratch sets; actual binding resolve/template/projection/scoped
   Repeat allocation sites in audio_binding.rs/audio_reference.rs. Legacy
   entrypoints use the same algorithm. No binding lifecycle or layout rebuild.
2. Plan owner-query owner: audio_owners.rs and candidates.rs, admitted
   Walk/RawOwner/query mapping, Core adapter and candidates/Input receipts.
   Preserve sealed exact parent, FIRST selection and one actual membership.
3. Plan capture owner: audio.rs/audio_boundary.rs/audio_signal.rs for the
   complete real capture/discarded span, plus admitted bound/domain/definition/
   Point construction needed by retained_probe. Reuse Core and leaf-copy
   helpers. This overlaps final-sharing helper types; agree those interfaces
   before parallel edits, not an independent replacement.
4. Audio integrator: use admitted variants at node_description/authored_eq
   while respecting final-sharing worker's carriers/handoff. Common ledger
   reserve sees active sound/native/PCM/cache headroom. No source/provider
   calls and no speculative ancestor/raw-context activation.

Tests required before claiming this actual closure:
- Independent legacy Root and seeded Domain query/capture oracle: complete
  ordered owner fields, kind/play/origin, sampling, inactive flags, support,
  captured Domain fields and downstream query results. Retain one-query Q
  savings witness; do not compare only two wrappers over the new helper.
- Actual retained Split bound, WholeRepeat selected play/default gap, nested
  Repeat/override, foreign branch/plan, hidden Domain binding, fractional
 44.1kHz/grid boundary and Preserve/Shift: exact original failures and grids.
- Every actual reservation boundary with preceding live values: exact cap
  succeeds, one-short refuses before the reached allocation, buffers/objects
  drop BEFORE leases. Include reallocation old+new, RawOwner conversion,
  recursive bound+Domain overlap, captured seed plus discarded span, and
  sequential Core phase terms whose dead allocations release promptly.
- Preserve postcapture fallible validation: arrange capture succeeds before a
  later walker failure; no Input or partial token is published.
- No-selection Q using last budget succeeds as absence without new capture
  limits. Exact/one-short Q/C bounds; zero internal C; issuer mismatch;
  cancellation/deadline during each phase; real cache eviction consumes work
  without resetting local/read limits. All successful work reconciles once,
  including Core aggregate children and None retained probe.
- All three scratch-set semantics against literal duplicate/outside/ordered
  birth fixtures; exact comparison/shift charges and realistic tiny lengths.
- Both retained RootRoundEven and PointCeil raw domains; empty/dormant binding
  branches; allocation-free standard map lookup is not treated as a new tree.
- Actual numerical node-description and read PCM/source/dependency/depth
  tests, alongside library/stage/real-WAV matrix main already owns.

Remaining honest boundaries after the first query-only unit: capture;
retained probe and its owners; final shared Context lease; OwnerKey/boundary/
other caller containers; general prepared Original raw query forms. Complete
all before advertising full recursive cold resource closure. Nothing here
authorizes batching or claims remaining Split work-limit failures are fixed.
