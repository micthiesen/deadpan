# First actual candidates-query closure: interface contract

Proposed concrete contract, not source changes or compiled Rust. Against current
final-sharing bytes captured in interface-source-pins.json. The earlier
source-pins.json/snapshots and research evidence remain untouched.

This delivery admits the actual candidates QUERY, including reached Core
bindings/projections, and keeps its query charged through the actual legacy
capture call. Capture/discarded-span and retained-probe construction remain
explicitly unadmitted. Final-sharing remains the existing separate carrier.
No cold activation or query replay.


## 0. Capture an independent legacy oracle BEFORE implementation

This is a dependency of the worker fanout, not a final test invented afterward.
The26 pinned current files and interface-source-snapshot preserve pre-query-change
bytes (including final-sharing), but no new query fixture snapshot has yet
been built/run here. Parent owns that bounded baseline execution.

Before Core/Plan source changes:
1. Freeze fixture constructors and a test-only logical SnapshotV1 serializer
   in a copied baseline runtime. Prefer a child test module in
   audio_owners.rs / the Plan subtree so it can read private Clock/seed fields
   without adding a public product inspection API. Parent may build this small
   harness against the pinned baseline source or a matching existing binary
   which ALREADY includes the exact fixture/harness. An old binary without the
   new fixture cannot be assumed to have recorded it.
2. Read actual legacy audio_gain_owners / actualDomain.gain_owners and actual
   audio_owner_input / Domain.owner_input using the same independently selected
   baseline member. Record BOTH query window and index, never select again by
   the new implementation. For candidates parity, run current actual candidates
   and capture too; this is the already qualified pre-admission query algorithm.
3. Freeze resulting JSON+SHA plus the exact baseline source/executable/fixture
   pins. New tests read these immutable expected values; do not regenerate them
   from either new wrapper. Existing broad old executables remain supporting
   evidence, not a substitute for a missing logical result fixture.
4. Use manually named structural fields and stable scalar encodings, not raw
   pointers, Debug text, raw struct bytes or allocator capacity as correctness.
   SnapshotV1 contains:
   - ordered spans: exact sample range, support/silent flags, ordered owners;
   - each owner: selector tag+ID, instance NodeId and ordered stable Repeat
     allocation/ordinal IDs, kind, gap-after, play, current/retained origin
     (including its own selector/path/kind/gap), affine anchor/local/slope;
   - captured Input: observed sample, scope, same logical owner, total work;
     captured Domain root/visible ranges, placement, instance; seed selector,
     bypass Node/Gap index brand mapped to stable NodeId, transform, grid
     origin/ratio/rule, extent/envelope, constraints, editorial edges/probes,
     suppression bits, repeats, retimes, gap;
   - all ExactRatio values as normalized integer numerator/denominator; grid
     rule as explicit RootRoundEven/PointCeil labels; IDs as validated strings.
     Borrowed Plan identity is checked as belongs_to(expected_plan)==true,
     with independent foreign-plan rejection tests, not a golden pointer.
   - baseline Q, C=Input.work-Q, retained Some/None probe work when applicable.
     Runtime receipts additionally pin old WorkControl billed amounts. A future
     expected increase must equal separately measured new real operations;
     no arbitrary old/new total substitution.
5. For errors record typed PlanError variant, nested DocumentError code/message
   or TimeError variant and prefix billed work, at ample budget and actual
   exact/one-short local allowance. Include invalid range and limits on a
   seeded Domain where seed copying happens before limits validation.
   New metered refusal at an earlier allocation is separately expected by
   implementation-decisions.md, not a reason to rewrite the old error golden.

Minimum bounded fixture matrix (reuse existing checked fixtures):
- unbound root Sequence/Tone and its real captured Domain;
- a Repeat with distinct stable selected plays/default gap and override;
- a hidden resumed binding where actualDomain.gain_owners differs from
  root.audio_gain_owners at the same numerical window;
- nonunity Preserve/Shift + retained PointCeil with fractional grid/source44.1kHz;
- real Split retained RootRoundEven with scope/window clipping;
- foreign plan and wrong Repeat branch, including an equal OwnerKey whose
  provenance/sampling differs.

A meaningful counterexample must assert that the hidden seeded Domain
snapshot is DIFFERENT from the root query snapshot at the same labels, and
that capturing its actual member preserves the seeded grid/hidden support.
A fake key-only/root-substitution path must fail that literal oracle. Whole
Repeat current plays likewise share coarse identity yet have different play/
affine records. This prevents a test which only passes because new metered
and unmetered wrappers share the same mistaken resolver.

No test claims are made by writing this plan. Parent must capture and pin
these baseline results before the implementation owners change the kernels.

## 1. Core policy and typed failure

New narrowly scoped Core module: audio_binding/admission.rs, used only by the
real binding/projection constructors. Existing Core has no Plan dependency.

Illustrative signatures, names fixed here for coordination:

    pub enum AudioBindingBuildError<E> {
        Document(DocumentError),
        Policy(E),
    }

    pub trait AudioBindingAdmission {
        const METERED: bool = true;
        type Error;
        type Issuer: Copy + Eq;
        type Lease;

        fn issuer(&self) -> Self::Issuer;
        fn issuer_mismatch(&self) -> Self::Error;
        fn spend(&mut self, units: usize) -> Result<(), Self::Error>;
        fn reserve(&mut self, layout: Layout) -> Result<Self::Lease, Self::Error>;
        fn merge(&mut self, into: &mut Self::Lease, from: &mut Self::Lease);
    }

No Error:From<DocumentError> constraint: semantic errors stay in Document,
callback errors remain the original E. issuer_mismatch only constructs the
typed failure; it must not reserve/spend/allocate. Every entry/transition and
callback checks the stable issuer before and after. Mismatch is Policy(E).
Do not turn cancellation/timeouts/admission limits into DocumentError or None.

Lease Drop is independent of the mutable policy, allocation-free, and releases
only that issuer's charge. merge is trusted infallible/non-unwinding/no-allocation
and disarms source WITHOUT releasing. The existing Plan policy has the same
contract. Unmetered Core compatibility uses issuer=(), lease=(),
Error=DocumentError, no-op callbacks; flatten either error arm to its contained
DocumentError. No fake media authority is involved.

New actual entrypoints, legacy wrappers delegate to the same implementation:

    impl AudioBindingState {
        pub fn resolve_in_admitted<P: AudioBindingAdmission>(
            &self, owner: &NodeId, environment: AudioBindingEnvironment<'_>,
            maximum_work: usize, admission: &mut P,
        ) -> Result<AdmittedAudioBinding<P::Issuer, P::Lease>,
                    AudioBindingBuildError<P::Error>>;

        pub fn resolve_gap_in_admitted<P: AudioBindingAdmission>(
            &self, owner: &NodeId, environment: AudioBindingEnvironment<'_>,
            maximum_work: usize, admission: &mut P,
        ) -> Result<AdmittedAudioBinding<P::Issuer, P::Lease>,
                    AudioBindingBuildError<P::Error>>;
    }

Only these actual resolve APIs and their necessary policy/carrier types cross
the crate boundary. Scoped projection/repeat admitted helpers can be Core-private
or pub(crate), because only Core binding calls them in this delivery. No new
generic public frozen-layout observation API.

## 2. Paired owned value and work receipt

A small audio-binding storage bridge is needed because Core cannot name the
Plan AudioBound that will own ResolvedAudioBinding. Use ONE sealed generic
value guard, not naked (Resolved, lease) parts:

    pub struct AudioBindingValue<T, I, L> {
        value: Option<T>,             // drops FIRST
        issuer: I,
        lease: Option<L>,             // drops AFTER value
        work: Option<AudioBindingForwardedWork<I>>,
        metered: bool,               // sealed, set only from constructor P::METERED
    }
    pub type AdmittedAudioBinding<I, L> =
        AudioBindingValue<ResolvedAudioBinding, I, L>;

    pub struct AudioBindingForwardedWork<I> {
        issuer: I,
        canonical_units: usize,
        additional_units: usize,
        controller_debited: bool,    // sealed, exactly constructor P::METERED
    } // private fields, NOT Clone or Copy

Minimum methods:
- value(&self) -> &T; issuer(&self) -> I.
- take_work(&mut self, policy:&P) -> Result<ForwardedWork<I>,BuildError<P::Error>>.
  Validate issuer; take at most once. An attempted second take is an internal
  protocol/Document error. It is not a fresh work debit.
- ForwardedWork::units(&self)->usize (checked canonical+additional),
  canonical_units()->usize, additional_units()->usize, issuer()->I and
  was_forwarded()->bool;
  only Core creates it. The historical name claims controller forwarding ONLY
  when was_forwarded()==true. Both modes carry actual local provenance units.
- map_value<U,P>(self, policy:&P, map:impl FnOnce(T)->U)
    -> Result<AudioBindingValue<U,I,L>,BuildError<P::Error>>
  Validate all issuer/protocol checks BEFORE taking T. The map is a trusted
  infallible, non-unwinding, allocation-free move-only constructor. It gets no
  policy callback. Value storage stays owned until this check succeeds. It
  transfers the SAME lease/work option into the returned guard, without release.
  Store U in that returned guard before a final stable-issuer check; if an
  unstable policy is then detected, U drops before its transferred lease.

This generic is only an ownership bridge for the real Core result -> actual
Plan AudioBound move. It is not a public planner/callback framework or an
ancestry certificate. There is no generic constructor from arbitrary value,
no generic into_inner/into_parts, and no standalone hook left unused in delivery.

Core-private Tracked<T,I,L> can use the same field order without public work
methods for temporary projections, expected/required Repeat vectors, and
scratch sets. They do not need a heap side table or boxed lease. Return and
merge only surviving lattice-owned allocations. Each temporary retains its own
guard until its actual lexical/value drop.

## 3. Primitive work versus parent aggregate accounting

Keep original local limits/check order. A metered budget operation is:

    primitive(units):
        local.spend(units)?;        // existing semantic query cap first
        if P::METERED { policy.spend(units)?; } // forward actual debit ONCE
        validate stable issuer

Additional actual copy/metadata/set inspections use primitive as well.
Host reserve can evict cache entries and spend controlled canonical work;
the shared read budget is checked by every forwarded primitive, not inferred
from the starting local cap.

    account_child(receipt):
        validate same issuer AND receipt.was_forwarded()==P::METERED
        local.spend(receipt.units)? // aggregate bookkeeping ONLY in BOTH modes
        consume receipt            // NEVER policy.spend again

account_child is a private budget operation, not a public authority API. The
receipt is linear so the same returned work cannot be forwarded/tallied twice.
LookupStats merging stays at the existing sites; memory accounting does not
invent node visits.

METERED=false MUST still create a linear local work receipt. Its
was_forwarded()==false, because no controller debit occurred, but its units
are still needed by the parent local account_child and returned successful
.work() provenance. Parent bookkeeping must consume these unpaid units
locally once; it must NOT skip them just because the controller was unused.
Legacy public wrappers flatten errors and return the ordinary successful
unpaid work receipt exactly as their callers expect.

The private carrier/receipt modes come from the actual constructor policy
constant, never caller-supplied data. Transition/child accounting checks the
mode as well as issuer, including when the issuer is () in compatibility
tests. map_value preserves it after work has been taken.

The actual Audio node-description caller MUST use compile-time A::METERED:
    if !A::METERED { control.spend_plan_work(candidates.work())?; }
    validate_all_owner_treatment_layers(candidates.query())?;
Under true, Q has already been forwarded; under false, Q is still owed.
An admitted-looking carrier TYPE is not sufficient to suppress Audio Q.
The query-only capture still reports unpaid C in EITHER mode, so Audio bills
C once as now. A later capture-admission patch may change that only with its
own explicit mode/receipt contract. Test both modes, not just true.

Physical allocation instrumentation and its additional inspections are absent
under false. The storage decision below supersedes a common sorted backend: unmetered
compatibility keeps the legacy BTreeSet, while metered validation uses the
admitted sorted Vec. Hence additional sorted comparisons/shifts occur only
in metered work, while both modes execute the SAME validation loop.


Exact classification for this first closure:

| Current operation | Classification |
| --- | --- |
| audio_owners::walk Budget.spend(1+state.repeats.len()) | primitive |
| Sequence binary-search budget.spend(1) | primitive |
| Plan RepeatLayout.locate_bounded -> budget.spend(location.comparisons) | primitive; that existing Repeat helper is NOT itself forwarding |
| Plan owner append/definition/path costs, new explicit copy/set costs | primitive |
| Plan bound_at budget.spend(repeats.len()+1), exclusions loop, mapped constraints costs | primitive |
| Core resolve_binding Work.spend(environment path len+1) | primitive |
| Core validate_with Work.spend(entry_count), arguments/birth/environment inspections | primitive |
| Core scoped_repeats / project_scoped_inner own spend loops | primitive inside child |
| Core validate_with/resolve_with consume scoped_repeats used | account_child |
| ClockScope::project consumes projection.work | account_child |
| resolve_with called with the SAME &mut Core Work in resolve_binding | no second account; its local before/after 'work' result is provenance only |
| Plan bound_at consumes resolved.work | take/consume Core ForwardedWork via account_child |
| Audio consumes query Q with A::METERED=true | already forwarded, do NOT spend Q again |
| Audio consumes query Q with A::METERED=false | unpaid successful receipt, bill Q once as before |
| Audio capture C in query-only delivery | legacy unpaid receipt, bill ONCE as now |

Keep successful .work() provenance = actual local primitive+child work total,
including genuine added scratch-set operations. .work() alone does not say
whether the caller still owes a controller debit; the admitted type does.
Do not subtract guessed costs, refund work, or reset allowances.

When Core fails after some primitive work, those actual units were already
forwarded; the caller returns the same typed error and consumes/drops partial
guards. An unmetered legacy call retains its existing success-only receipt
behavior. Newly visible partial metered charges are intentional, not an error
to mask. No retry through the unmetered path.

## 4. Plan adapter and the actual AudioBound ownership handoff

Current private Plan kernel audio_metadata_admission.rs is already shared by
sound and final Original sharing. Keep it and audio_context_sharing.rs intact.
Use its layouts/issuer/reserve mechanics where appropriate. Do not rename its
trait/module or replace the other worker's guard definitions.

New Plan-private adapter:

    struct CoreAdmission<'a,A:AudioSoundContextAdmission> { outer:&'a mut A }
    impl AudioBindingAdmission for CoreAdmission<'_,A> {
        type Error=A::Error; type Issuer=A::Issuer; type Lease=A::Lease;
        // same issuer, spend/reserve/merge delegated exactly once
        // issuer_mismatch = PlanError::AudioMetadataIssuerMismatch.into()
    }

At every Core call return, map Document(e) to
A::Error::from(PlanError::from(e)); Policy(e) passes through unchanged.
No blanket StageAudio From<DocumentError> or lossy conversion is needed.

Do NOT genericize the existing public AudioBound<'plan> over a lease lifetime.
Use a query-local wrapper:

    struct QueryBound<'plan,I,L> {
        core: AudioBindingValue<AudioBound<'plan>,I,L>, // value+Core charge
        plan_charge: Option<L>,                       // drops after value
    }

Construction sequence in the same actual bound_at kernel:
1. Plan BoundBuild owns instance, optional exclusions, projected constraints,
   definition/gap copies and their Plan leases. Values precede leases.
2. Obtain AdmittedAudioBinding from actual Core resolution. Immediately
   consume its ForwardedWork into the original Plan local budget location,
   before the existing lattice/reference arithmetic.
3. Run all remaining actual Plan checks/arithmetic in their inherited order.
   Keep the actual Core guard live beside Plan BoundBuild. If anything fails,
   each owned temporary drops before its own lease.
4. Prevalidate the relevant issuers. core.map_value constructs the REAL
   AudioBound by moving its Resolved and already built Plan fields. The closure
   does not clone, allocate, reserve or perform fallible arithmetic.
5. Infallibly return QueryBound containing that mapped Core guard and the
   remaining Plan charge. There is NO fallible gap or policy call between
   moving Plan fields into AudioBound and moving the Plan charge alongside it.

The numerical query uses QueryBound.value() -> &AudioBound for envelope_domain,
reference transfer etc. Its recursive return keeps bound/domain/outer walk
state charged until their current actual scopes finish. Do not return a naked
AudioBound and drop Core lease merely because Resolved was already measured.

bound.envelope_domain also needs a query-local admitted Domain guard; it must
cover the constructor's1-element constraint buffer and evaluation path/constraint
copies, then give Walk::from_seed its SAME actual Domain. The Domain itself is
not pinned with a new Arc or plan clone.

First-query scope does not move QueryBound into an AudioSignalContent Box:
that is in the later capture walker delivery. The type/ownership bridge is
compatible with that later admission, but do not add an unused public boxing API.

## 5. Sequential Core placements must release, not accumulate

resolve_binding retains its lattice guard until final result construction.
Each resume phase term creates an actual temporary resolved placement guard;
compute existing sample boundaries/scalar delta, then drop that placement and
its lease at the existing iteration scope. Only scalar delta survives.
Reanchor placement/projection guards similarly drop after each step; resume
stores scalar values only. Validation expected-path, captured projection,
live/clauses/seen sets drop at their existing validation scopes.

Do not merge all these leases into the final lattice or a monotonic query
allocation sum. That would charge dead sequential workspace, and can reject
ordinary long-journal reads with small actual peak. Existing lattice-owned
clock/path/gap identity charges survive into AdmittedAudioBinding; only those
surviving values' charges merge.

## 6. Plan candidates API and first numerical consumer

Add admitted entrypoints with the SAME actual sealed parent:
    RenderPlan::audio_owner_input_candidates_at_admitted(at,limits,&mut A)
    AudioDomain::owner_input_candidates_at_admitted(at,limits,&mut A)
      -> Result<AdmittedAudioOwnerInputCandidates<'context,'plan,A::Issuer,A::Lease>,
                A::Error>

The carrier owns the actual existing candidates value/query before issuer and
its query lease. No A borrow is retained after construction, so the Audio
caller can validate layers/select and request fresh capture limits normally.
No new Arc<RenderPlan>, path/seed replay or fake query is retained.

query()->&AudioOwnerQuery; work()->usize; actual capture takes self, checked
member index, existing capture_limits and &mut A for same-issuer validation.
For QUERY-ONLY delivery its capture body calls the SAME legacy capture kernel:
- consume the candidates value while the outer carrier still retains its query
  lease; the actual query drops during that capture before lease release;
- no new membership query; keep min(stored_allowance-Q,fresh_allowance);
- returned legacy AudioOwnerInputCapture still owes only C to Audio;
- do not claim Input/capture heap is admitted because Q stayed charged.
without_selection drops query before charge, reports Q with its sealed actual
metered/unmetered accounting mode, and makes no capture limits call.

Numerical node_description::original_context_admitted must use these actual
entrypoints in this delivery. Factor current Context::admit_owner_query into
an unchanged legacy billing wrapper plus common layer validation, so metered
Q skips only the already forwarded duplicate Q charge and STILL runs every
layer validation before FIRST OwnerKey selection. The unmetered path bills Q
as now. Capture C, None retained probe and optional owners billing are unchanged
until their own admitted implementation. Existing final-sharing code remains
in the same final branch and carries its own lease/handoff.

## 7. Narrow ownership split and compile order

Interface/integration owner (parent):
- Core lib.rs minimal export wiring.
- Plan lib.rs/plan barrel minimal wiring.
- Current private audio_metadata_admission.rs only agreed additive helpers.
- Audio authored_eq.rs layer-validation factoring and
  shared_eq/node_description.rs actual query consumer.
- Preserve final-sharing worker's production/test hunks.

Core worker:
- NEW audio_binding/admission.rs + focused tests.
- audio_binding.rs actual generic resolver and one scratch-set facade:
  legacy BTreeSet under false, admitted sorted Vec under true (section9).
- audio_reference.rs only reached scoped Repeat/projection constructors.
  Do not touch Frozen build_index, layout lifecycle or unrelated sound routing.
- NEW focused Core binding-admission tests if a child module is clearer.

Plan query worker:
- audio_owners.rs actual query/walk allocation sites.
- audio_bound.rs actual bound/envelope constructors through private helper
  modules as useful; do not change public AudioBound representation.
- audio_definition.rs only root_domain_on_grid construction reached by envelope
  conversion (share its real kernel).
- audio_owner_input/candidates.rs admitted carrier plus unchanged capture bridge.
- NEW private owner-query admission/guard and focused tests.
- No audio.rs/audio_boundary.rs/audio_signal.rs capture rewrite in this first
  QUERY closure. Those are the explicitly later implementation scope.

Build/dependency order:
1. Agree these policy/error/linear-receipt/ownership signatures first.
2. Core worker implements the actual resolve/projection constructors and tests;
   Plan worker can code adapter/query types against the agreed interface in a
   disjoint scratch candidate. No implementation requires a second walk.
3. Parent compiles Core then Plan+Audio combined, fixes compiler-guided lifetime
   details while sources are frozen. Do not publish a detached unused policy.
4. Integrate actual numerical query caller, final-sharing overlay intact, and
   run focused plus broad parent-owned qualification.
5. Only then begin independent full capture/discarded-span admission. No cold
   resource claim/batching is enabled at either boundary.

No worker owns the same barrel or current final-sharing file concurrently.

## 8. Interface-specific verification

- Same Plan outer issuer through Core nested calls; distinct and unstable
  issuers refuse before the next spend/reserve/allocation; existing leases
  release to the ORIGINAL request, never the rejecting one.
- Inject policy error E with distinct cancellation/work/memory labels in real
  Core resolve; exact E survives Plan adapter, not Document/None.
- Both-mode primitive/child receipt test: metered nested real projection work forwards once,
  caller local total includes it once, second receipt take refuses, and
  resolved.work stays consistent. Unmetered has the SAME local child accounting
  with was_forwarded=false and zero controller calls; its Audio Q is then paid
  once by the compatibility caller. Include actual eviction consuming host work.
- Move real Resolved into a real Plan AudioBound and fail after Core success but
  before map; observe value-before-lease drops. Successful envelope/recursive
  query keeps Core and Plan leases through actual use.
- Many sequential real phase/reanchor terms: peak stabilizes at lattice plus
  one live term/projection, not sum of all dead terms.
- Actual Domain seed: ample budget retains legacy InvalidAudioLimits after
  the existing seed construction; earlier policy refusal preempts it at that
  actual allocation. Range check still precedes seed allocation.
- Q one-sample result oracle, actual FIRST member selection/capture, query
  lease alive across capture, no-selection with exhausted remainder requires
  no new query_limits. None probe9/final-sharing tests remain intact.
- New sorted set exact known capacities/old+new growth and duplicate semantics;
  billed comparisons/shifts reconcile as real extra work. No guessed BTree
  per-entry formula and no widened limits.

These are implementation obligations, not executed tests. The final first
query delivery still excludes capture, retained-probe/owners, caller keys/
boundaries and general prepared raw Original queries from its closure claim.


## 9. FINAL decision: canonical/additional work and storage backend

This section supersedes earlier suggestions to replace BTreeSet in both modes.
Choose option(b). Do NOT thread new provenance through the otherwise unchanged
legacy capture/probe merely to accommodate a shared sorted backend.

### Shared validation loop, two private storage backends

The three set sites use one small private scratch-set facade in Core:
    enum ScratchSet<'a,I,L> {
        Legacy(BTreeSet<&'a NodeId>),
        Admitted(/* sorted borrowed IDs + paired capacity lease + issuer */),
    }

Constructor selects solely from trusted P::METERED:
false=Legacy; true=Admitted. No caller flag, no second validation traversal.
The SAME environment/template loops invoke insert/contains/iteration through
this facade. Legacy invokes the old BTree operations, with the same work and
error order. Admitted uses checked binary search and sorted insertion and bills
each actually reached new comparison/shift as ADDITIONAL units. Retain original
canonical entry_count/path/debit calls at their current points in BOTH modes.

The admitted set capacity comes from the real current input slice lengths and
existing guard order, with old+new allocation coexistence charged during growth.
No MAX_DOCUMENT_NODES reservation. Empty sets allocate nothing. Keep sorted
iteration and duplicate semantics. The only alternative branches are storage
operations, not separate resolvers, query walkers or semantic validation loops.

Core legacy resolve_in/resolve_gap_in use P::METERED=false. Therefore the first
QUERY-only delivery's legacy capture and retained probe still execute BTree
storage and retain frozen old C/probe work, even though the query metered path
uses sorted storage. A later full capture admission will explicitly switch its
same real Core calls to metered and then carry that phase's added work.

### Two counters in the existing private budget and linear receipt

Private budget state tracks:
    canonical_used: usize,
    additional_used: usize,
    remaining: usize, // unchanged cap, decremented by BOTH categories
    lookup: LookupStats

Use two private entry methods:
    canonical(n): // existing algorithm debit at its inherited site
    additional(n): // genuinely added inspected/layout/identity/set operation

Both first check/decrement the original local allowance, increment their own
checked counter, and, for P::METERED=true, forward n ONCE via policy.spend(n).
No controller refund, subtraction, synthetic credit, reset or changed weight.
For false, ownership instrumentation is not executed and additional=0; all old
canonical work remains in the unpaid successful result. Standard allocator's
internal legacy BTree work stays under the old accounting contract.

The sealed existing linear receipt carries canonical_units, additional_units,
issuer and controller_debited. units() is their checked sum. account_child
consumes it, adds BOTH categories to matching private counters and decrements
the local allowance by their sum, WITHOUT another host spend. Ordinary public
.work() remains total provenance; do not add fields to every legacy public
Resolved type or invent a general public accounting framework.

Core's existing returned ResolvedAudioBinding.work is total local provenance
for that actual invocation. Legacy false has old canonical total; admitted
true has canonical+additional. The extra getters belong only to the already
required sealed cross-crate receipt, because Plan must preserve the split
when consuming Core work. Plan's candidate construction keeps the same two
private counters and preserves them across every Core account_child.

Admitted candidates expose their sealed construction-work breakdown only as
needed by the real Plan/Audio accounting bridge and scoped tests (one receipt
getter or existing carrier getters). Do not add an unrelated public measurement
API. Their underlying query.work() reports total Q, including new operations.

### Prepaid copy handling

Do not move, remove, weaken or reclassify an existing canonical budget.spend.
In particular audio_owners::walk's canonical(1+state.repeats.len()) already
prepays the node's repeat-path copying. A shared copy helper at that exact site
must take an explicit PRIVATE copy_paid mode, analogous to current sound
copy_paid; when paid it MUST NOT charge repeats.len() canonical again.

For each helper call, implementation review records which actual old canonical
debit paid its copying, or that the old operation was uncharged. This is not
a transferable allowance/token and never a controller credit. The helper may
copy fields in the same order while adding only new actual ownership/layout/
identity inspection as additional units. An old uncharged clone does not
magically acquire a second canonical charge merely because its Vec is now
admitted; its genuinely new inspection work belongs in additional.

Examples:
- Walk node's first instance.repeats clone: original1+len stays canonical;
  no second len debit. Layout check/reserve handling and explicit owning-ID
  inspection steps are additional.
- Domain Walk::from_seed initial clone: retain exactly its legacy canonical
  context (including no new canonical debit where none existed); newly added
  per-field/layout/identity probes are additional.
- Plan bound_at original canonical(repeats.len()+1), constraint mapping debit
  and Core original entry_count remain at their current sites. Admitted copy
  helpers do not debit those counts again.
- A new sorted insert's binary-search comparisons and shifts are additional,
  not an alteration of Core's existing canonical validation entry_count.
- Core aggregate receipts carry both counts; accounting a child never reruns
  the helper or calls policy.spend for either count again.

No need to charge both a whole extra vector-length scan and its per-element
inspections if the implementation performs only the latter. Conversely every
new loop actually executed must be accounted, even if a no-op callback exists
for legacy mode. Document actual code operations, not a guessed per-byte cost.

### Baseline and conservation assertions

The parent has now captured the BEFORE-change golden oracle:
    /tmp/deadpan-owner-query-baseline-2026-10-28/golden-pins-gen2.json
Five fixture families,14 cases, actual Root/seeded Domain ordered logical
arrays, grids, captured inputs, errors and work were qualified main/scoped.
Hidden Root-versus-Domain counterexample passes. Actual saved pre-Split lattice
was needed; plain Source Split did not exercise retained Some. Existing old
Control outputs22/22/60 match both variants. Preserve those expectations.

For each query fixture assert independently:
    admitted.canonical_units == frozen_old_Q
    admitted.total_units == frozen_old_Q + admitted.additional_units
    host_forwarded_query_delta == admitted.total_units
and reconcile additional_units with actual added operation counters from the
metered kernel/linear receipt, not a difference guessed from the new total.
An inspection-category trace in test policy/private counters may break that
additional count into field/layout/identity/set comparison/shift totals; their
sum must match the receipt. No new product tracing API is necessary.

For this first QUERY-only caller:
    new_complete_billed == old_qualified_complete_billed + query_additional
provided the fixture invokes the same phases/eviction schedule; if new real
eviction occurs, include its separately observed real work, never hide it.
Legacy capture C and probe/owner work equal frozen old C/probe/owners because
their unmetered Core storage backend remains BTreeSet. Query Q being larger
can reduce the same min(stored_allowance-Q,fresh_allowance) headroom honestly;
do not renew the cap to recover the old C boundary.

Unmetered candidate compatibility must still bill old Q once at Audio and
report additional=0. Its .work() equals the frozen old golden Q, not the
metered total. Type appearance alone never grants an already-paid credit.
Tests assert no duplicate controller debit under either mode and preserve
all old golden files, including error/headroom characterization.

These are counters describing actual executed work, not refunds or weights.
No implementation or execution is claimed by this contract amendment.
