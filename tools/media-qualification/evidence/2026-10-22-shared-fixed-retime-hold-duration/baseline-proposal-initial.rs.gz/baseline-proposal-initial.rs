//! Proposed old-code regression witness for All-Default Hold duration under
//! a fixed unclocked Edit Retime inside an outer Repeat.
//!
//! Install as preview/scoped/model/tests/shared_fixed_retime_duration.rs and
//! register `mod shared_fixed_retime_duration;` in tests.rs. Uses silent
//! structural Holds only; this proves native duration admission and exact
//! geometry, not media or audio qualification.

use super::*;
use deadpan_core::{
    Anchor, AnchorIndex, AnchorTarget, BoundaryAnchor, ExactRatio, InsertionBias, InstancePath,
    RepeatInstance,
};

fn fixed_repeated_retime_fixture() -> ProjectDocument {
    let mut stage = retime("fixed-stage", "fixed-body", 0, 8, 6).1;
    if let NodeKind::Retime { pitch, .. } = &mut stage.kind {
        *pitch = PitchPolicy::FollowSpeed;
    }
    let mut outer = BeatNode::sequence("Outer Repeat", Vec::new());
    outer.kind = NodeKind::Repeat {
        child: node("fixed-stage"),
        iterations: IterationOrder::new(revision("outer-plays"), 3).unwrap(),
        gap: None,
        escalation: None,
    };
    let (timeline, mut root) = sequence("timeline", &[]);
    if let NodeKind::Sequence { children } = &mut root.kind {
        children.extend([node("lead"), node("outer"), node("tail")]);
    }
    let mut document = ProjectDocument::new(
        ProjectId::new("fixed-repeat-retime-duration").unwrap(),
        revision("fixed-repeat-retime-seed"),
        PresentationBasis {
            width: 16,
            height: 16,
            frame_rate: FrameRate::new(30, 1).unwrap(),
            color_policy: ColorPolicy::SdrRec709,
        },
        timeline.clone(),
    )
    .unwrap();
    document.nodes.insert(timeline, root);
    document.nodes.extend([
        (node("lead"), hold("lead", 3).1),
        (node("outer"), outer),
        (node("fixed-stage"), stage),
        (
            node("fixed-body"),
            sequence("fixed-body", &["before", "held", "speech"]).1,
        ),
        (node("before"), hold("before", 2).1),
        (node("held"), hold("held", 2).1),
        (node("speech"), hold("speech", 6).1),
        (node("tail"), hold("tail", 3).1),
    ]);
    document.validate().unwrap();
    document
}

fn outer_iteration(document: &ProjectDocument, zero_based: u32) -> deadpan_core::IterationId {
    let NodeKind::Repeat { iterations, .. } = &document.nodes()[&node("outer")].kind else {
        panic!("expected outer Repeat");
    };
    iterations.at(zero_based).expect("fixture Repeat iteration")
}

fn exact_occurrence_boundary(
    document: &ProjectDocument,
    owner: &str,
    iteration: deadpan_core::IterationId,
    position: i64,
) -> ExactRatio {
    AnchorIndex::new(document)
        .unwrap()
        .resolve_target(&AnchorTarget {
            boundary: BoundaryAnchor {
                coordinate: Anchor::Occurrence {
                    instance: InstancePath {
                        node: node(owner),
                        repeats: vec![RepeatInstance {
                            node: node("outer"),
                            iteration,
                        }],
                    },
                    position: ExactRatio::integer(i128::from(position)),
                },
                bias: InsertionBias::Right,
            },
            occurrence: None,
        })
        .unwrap()
        .exact_frame
}

fn selected_second_play(document: ProjectDocument) -> State {
    // Outer is a direct child of the root Sequence. Its child is the fixed
    // Retime; the Retime child is the ordinary Before/Held/Speech Sequence.
    let mut state = state(document, "outer", 10);
    state.switch_play_in(2).unwrap();
    assert!(state.enter_in().unwrap());
    assert!(state.enter_in().unwrap());
    state.select_in(1).unwrap();
    assert_eq!(state.selected.node, node("held"));
    state
}

#[test]
fn old_code_all_default_hold_duration_inside_fixed_retime_under_repeat_is_refused() {
    let before = fixed_repeated_retime_fixture();
    before.validate().unwrap();
    assert_eq!(before.duration().unwrap().frames(), 24);
    let NodeKind::Retime {
        duration,
        mapping,
        pitch,
        purpose,
        ..
    } = &before.nodes()[&node("fixed-stage")].kind
    else {
        panic!("expected fixed Edit Retime");
    };
    assert_eq!(*duration, frames(6));
    assert_eq!(*mapping, FrameRange::new(ProjectFrame(0), ProjectFrame(8)).unwrap());
    assert_eq!(*pitch, PitchPolicy::FollowSpeed);
    assert_eq!(*purpose, RetimePurpose::Edit);
    assert!(before.overrides().is_empty());
    assert!(before.gap_overrides().is_empty());

    // Confirm the second stable Repeat play is the representative and the
    // selected Hold's sampled envelope begins at output frame 10.
    let before_state = selected_second_play(before.clone());
    assert_eq!(before_state.cursor, ProjectFrame(10));
    assert_eq!(presentation(&before_state).frames, 10..12);

    let request = CommandRequest {
        project_id: before.project_id().clone(),
        expected_revision: before.revision_id().clone(),
        new_revision: revision("fixed-retime-held-growth-control"),
        command: Command::SetHoldDuration {
            node: node("held"),
            duration: frames(4),
        },
    };
    let transaction = apply(&before, &request).unwrap();
    assert_eq!(transaction.duration_delta, 0);
    let after = transaction.forward.apply(&before).unwrap();

    // The raw public reducer accepts 2->4 and changes only the Hold duration.
    // Retime output/mapping, Repeat, exterior beats, identities and branch
    // tables stay fixed, so no time escapes the fixed stage or Repeat.
    assert_eq!(after.duration().unwrap().frames(), 24);
    assert_eq!(after.nodes().len(), before.nodes().len());
    assert_eq!(after.nodes()[&node("fixed-stage")], before.nodes()[&node("fixed-stage")]);
    assert_eq!(after.nodes()[&node("outer")], before.nodes()[&node("outer")]);
    assert_eq!(after.nodes()[&node("lead")], before.nodes()[&node("lead")]);
    assert_eq!(after.nodes()[&node("tail")], before.nodes()[&node("tail")]);
    assert_eq!(after.overrides(), before.overrides());
    assert_eq!(after.gap_overrides(), before.gap_overrides());
    assert!(matches!(
        &after.nodes()[&node("held")].kind,
        NodeKind::Hold { recipe } if recipe.duration == frames(4)
    ));

    let second = outer_iteration(&before, 1);
    assert_eq!(
        exact_occurrence_boundary(&before, "fixed-stage", second.clone(), 0),
        ExactRatio::integer(9)
    );
    assert_eq!(
        exact_occurrence_boundary(&after, "fixed-stage", second.clone(), 0),
        ExactRatio::integer(9)
    );
    assert_eq!(
        exact_occurrence_boundary(&before, "held", second.clone(), 0),
        ExactRatio::new(21, 2).unwrap()
    );
    assert_eq!(
        exact_occurrence_boundary(&before, "held", second.clone(), 2),
        ExactRatio::integer(12)
    );
    assert_eq!(
        exact_occurrence_boundary(&after, "held", second.clone(), 4),
        ExactRatio::new(27, 2).unwrap()
    );
    assert_eq!(
        exact_occurrence_boundary(&before, "speech", second.clone(), 0),
        ExactRatio::integer(12)
    );
    assert_eq!(
        exact_occurrence_boundary(&after, "speech", second, 0),
        ExactRatio::new(27, 2).unwrap()
    );

    // The projected sampled envelope grows from [10,12) to [10,13), while the
    // retained cursor stays at 10. Exact start/end are checked above.
    let after_state = selected_second_play(after.clone());
    assert_eq!(after_state.cursor, ProjectFrame(10));
    assert_eq!(presentation(&after_state).frames, 10..13);

    // Check exact Undo before the sole public availability expectation. This
    // isolates the old scoped guard: duration mutation is valid, but the
    // All-Default scoped inspector still refuses Change duration.
    assert_eq!(transaction.inverse.apply(&after).unwrap(), before);
    let old_guard_state = selected_second_play(after);
    assert!(!old_guard_state.hold_duration_available());
    assert_eq!(old_guard_state.hold_parameter_in(), None);
}
