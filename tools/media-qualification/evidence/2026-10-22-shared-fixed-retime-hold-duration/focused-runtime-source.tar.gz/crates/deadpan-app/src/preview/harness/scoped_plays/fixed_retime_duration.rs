//! Native All-Default duration authoring through a fixed Edit Retime.

use super::*;
use deadpan_core::{HoldVideo, ProjectFrame};
use std::path::Path;

pub(in crate::preview::harness) fn run(d: &mut Driver<'_>) -> Result<(), String> {
    let workspace = d
        .app()
        .workspace
        .as_ref()
        .ok_or("No fixed-Retime duration workspace")?;
    let previous = workspace.path.clone();
    let baseline = workspace.document.clone();
    let original = d.app().source_cursor;
    let picture = workspace
        .plan
        .picture(ProjectFrame(0))
        .map_err(|error| error.to_string())?;
    let (asset, _) = picture
        .picture
        .follow_point()
        .ok_or("No actual Original picture")?;
    let index = workspace
        .sources
        .get(asset)
        .and_then(|source| source.video_index.as_ref())
        .ok_or("No measured Original index")?;
    let measured = picture
        .picture
        .select_source_frame(index)
        .map_err(|error| error.to_string())?;
    let expected_picture = measured.identity;
    let freeze = HoldVideo::Freeze {
        asset: asset.clone(),
        timestamp: deadpan_core::SourceTimestamp {
            ticks: measured.pts,
            time_base: index.time_base(),
        },
    };
    let scratch = tempfile::tempdir().map_err(|error| error.to_string())?;
    let live = scratch.path().join("shared-fixed-retime.deadpan");
    super::shared_hold_duration::fixture::create_fixed_retime(&previous, &live, freeze)?;
    let result = (|| {
        super::shared_hold_duration::open(d, &live, original)?;
        d.check(
            "The shared-duration fixture adds a fixed unclocked Edit Retime below the inspected Repeat",
            d.app().workspace.as_ref().is_some_and(|workspace| {
                workspace.document.nodes().contains_key(
                    &super::shared_hold_duration::fixture::id("fixed-stage").unwrap(),
                ) && workspace.document.duration().is_ok_and(|duration| duration.frames() == 45)
            }),
            json!({"Retime":"fixed Edit stage","duration_frames":45}),
            d.snapshot(),
        )?;
        fixed_controls(d, expected_picture)?;
        reopen_check(d, &live, original)?;
        Ok(())
    })();
    d.app_mut().feedback.hold_project_updates = false;
    let cleanup = (|| {
        d.app().service.submit(ProjectRequest::Close)?;
        d.wait_for("Close the private fixed-Retime writer", |app| {
            app.workspace.is_none() && !app.service.is_busy()
        })?;
        super::shared_hold_duration::open(d, &previous, original)?;
        resize(d, 1280.0, 820.0)?;
        d.check(
            "Fixed-Retime duration replay restores the original project and cursor",
            super::shared_hold_duration::equivalent(document(d)?, &baseline)
                && d.app().source_cursor == original
                && d.app().scoped.is_none(),
            json!({"project":"restored","Original":original,"inspector":"closed"}),
            d.snapshot(),
        )
    })();
    if cleanup.is_err() {
        let _ = scratch.keep();
    }
    match (result, cleanup) {
        (Err(error), Err(cleanup)) => Err(format!("{error}; fixed-Retime cleanup: {cleanup}")),
        (Err(error), _) | (_, Err(error)) => Err(error),
        _ => Ok(()),
    }
}

fn fixed_controls(d: &mut Driver<'_>, expected_picture: SourceFrameId) -> Result<(), String> {
    resize(d, 960.0, 640.0)?;
    super::shared_hold_duration::choose(d)?;
    let baseline = document(d)?.clone();
    let prior = super::shared_hold_duration::target(d)?;
    let retime = super::shared_hold_duration::fixture::id("fixed-stage")?;
    let held = super::shared_hold_duration::fixture::id("selected")?;
    d.check(
        "The duration editor captures both literal All-Default Repeat ancestors through the fixed Retime",
        prior.target.repeats.len() == 2
            && prior.target.repeats.iter().all(|step| step.branch == deadpan_core::RepeatEditBranch::Default)
            && prior.also.is_empty()
            && prior.presentation.is_some()
            && matches!(baseline.nodes()[&retime].kind, deadpan_core::NodeKind::Retime {
                purpose: deadpan_core::RetimePurpose::Edit, ..
            })
            && d.app().sequence_length() == 45,
        json!({"scope":"All plays at both Repeat levels","Retime":"fixed Edit","output_frames":45}),
        d.snapshot(),
    )?;
    let fixed = baseline.nodes()[&retime].clone();
    let revision = d.revision();
    d.key(Key::Enter)?;
    d.check(
        "Enter prefills the actual shared Hold duration without a write",
        d.app().command_open && d.app().command == "hold-duration 2f" && d.revision() == revision,
        json!({"prefill":"hold-duration 2f","history":"unchanged"}),
        d.snapshot(),
    )?;
    d.capture("Fixed-Retime All plays duration prefill")?;
    super::shared_hold_duration::submit(d, "hold-duration 4f")?;
    d.changed(&revision)?;
    super::shared_hold_duration::settled(d)?;
    let grown = document(d)?.clone();
    d.check(
        "Growing the shared Hold preserves the fixed-stage clock and All-Default authority",
        grown.duration().is_ok_and(|duration| duration.frames() == 45)
            && grown.nodes()[&retime] == fixed
            && matches!(grown.nodes()[&held].kind, deadpan_core::NodeKind::Hold { ref recipe }
                if recipe.duration.frames() == 4)
            && grown.overrides() == baseline.overrides()
            && super::shared_hold_duration::target(d)?.target == prior.target
            && d.app().presentation.displayed_source_frame() == Some(expected_picture),
        json!({"hold_frames":4,"fixed_output_frames":45,"overrides":"unchanged","picture":expected_picture}),
        d.snapshot(),
    )?;
    let revision = d.revision();
    d.command("hold-duration 4f")?;
    super::shared_hold_duration::settled(d)?;
    d.check(
        "Repeating the same duration is a no-op with no history entry",
        document(d)? == &grown && d.revision() == revision,
        json!({"history":"unchanged","duration":4}),
        d.snapshot(),
    )?;
    d.key(Key::U)?;
    d.changed(&revision)?;
    super::shared_hold_duration::settled(d)?;
    d.check(
        "Undo restores the baseline shared duration without changing the fixed Retime",
        document(d)? == &baseline && document(d)?.nodes()[&retime] == fixed,
        json!({"hold_frames":2,"output_frames":45}),
        d.snapshot(),
    )?;
    let revision = d.revision();
    d.key_modified(Key::R, egui::Modifiers::CTRL)?;
    d.changed(&revision)?;
    super::shared_hold_duration::settled(d)?;
    d.check(
        "Redo restores the shared duration and retains its fixed output clock",
        document(d)? == &grown && document(d)?.nodes()[&retime] == fixed,
        json!({"hold_frames":4,"output_frames":45}),
        d.snapshot(),
    )?;
    super::shared_hold_duration::choose(d)?;
    scroll_top(d)?;
    d.click("Change duration…  Enter")?;
    let revision = d.revision();
    super::shared_hold_duration::submit(d, "hold-duration 3f")?;
    d.changed(&revision)?;
    super::shared_hold_duration::settled(d)?;
    let shortened = document(d)?.clone();
    d.check(
        "Shortening the Hold also leaves the fixed output unchanged",
        shortened
            .duration()
            .is_ok_and(|duration| duration.frames() == 45)
            && shortened.nodes()[&retime] == fixed
            && matches!(shortened.nodes()[&held].kind, deadpan_core::NodeKind::Hold { ref recipe }
                if recipe.duration.frames() == 3),
        json!({"hold_frames":3,"output_frames":45}),
        d.snapshot(),
    )?;
    d.key(Key::U)?;
    d.changed(&revision)?;
    super::shared_hold_duration::settled(d)?;
    let after_undo = document(d)?.clone();
    d.key(Key::Period)?;
    super::shared_hold_duration::settled(d)?;
    d.check(
        "Dot repeats the prior duration edit against the retained shared target",
        document(d)? == &shortened && document(d)?.nodes()[&retime] == fixed,
        json!({"dot":"hold-duration 3f","output_frames":45}),
        d.snapshot(),
    )?;
    let revision = d.revision();
    d.key(Key::U)?;
    d.changed(&revision)?;
    super::shared_hold_duration::settled(d)?;
    d.check(
        "Undo after dot restores the immediately preceding four-frame state",
        document(d)? == &after_undo,
        json!({"hold_frames":4,"output_frames":45}),
        d.snapshot(),
    )?;
    d.capture("Shared duration history under fixed Edit Retime")?;
    Ok(())
}

fn reopen_check(d: &mut Driver<'_>, path: &Path, original: u64) -> Result<(), String> {
    d.app().service.submit(ProjectRequest::Close)?;
    d.wait_for("Close the fixed-Retime writer before reopening", |app| {
        app.workspace.is_none() && !app.service.is_busy()
    })?;
    super::shared_hold_duration::open(d, path, original)?;
    resize(d, 960.0, 640.0)?;
    super::shared_hold_duration::choose(d)?;
    let target = super::shared_hold_duration::target(d)?;
    let held = super::shared_hold_duration::fixture::id("selected")?;
    d.check(
        "Reopening preserves the committed shared duration and captured All-Default path",
        d.app().sequence_length() == 45
            && target.target.repeats.len() == 2
            && target.target.repeats.iter().all(|step| step.branch == deadpan_core::RepeatEditBranch::Default)
            && matches!(document(d)?.nodes()[&held].kind, deadpan_core::NodeKind::Hold { ref recipe }
                if recipe.duration.frames() == 4),
        json!({"hold_frames":4,"output_frames":45,"reopened":true}),
        d.snapshot(),
    )
}

fn scroll_top(d: &mut Driver<'_>) -> Result<(), String> {
    let point = d.rect("Nested beat inspector pane")?.center() + egui::vec2(0.0, 120.0);
    d.events(
        "Restore fixed-Retime inspector controls",
        vec![
            egui::Event::PointerMoved(point),
            egui::Event::MouseWheel {
                unit: egui::MouseWheelUnit::Point,
                delta: egui::vec2(0.0, 10_000.0),
                phase: egui::TouchPhase::Move,
                modifiers: egui::Modifiers::NONE,
            },
        ],
    )?;
    for _ in 0..8 {
        d.step("Fixed-Retime inspector scroll settles", false)?;
    }
    Ok(())
}
