from pathlib import Path
import json,hashlib
s=Path(__file__).resolve().parent
failures={'query-core-build':101,'query-build':101,'query-build2':101,'query-plan':1,'query-scoped-plan':1,'query-strict':1,'query-strict2':1,'query-split':101}
rows=[]
for p in sorted(s.glob('*.json')):
 x=json.loads(p.read_text())
 if not isinstance(x,dict) or 'command' not in x or 'started_at' not in x:continue
 assert 'exit_code' in x,p
 assert x['sources_unchanged'] and x['binaries_unchanged'],p
 assert x['exit_code']==failures.get(p.stem,0),(p,x['exit_code'])
 rows.append({'label':p.stem,'exit_code':x['exit_code'],'seconds':x['seconds'],'source_inputs':len(x['source_before']),'receipt_sha256':hashlib.sha256(p.read_bytes()).hexdigest()})
required=['query-final-build','query-scoped-final-build','query-final-core-build','query-final-core','query-final-audio','query-final-plan','query-scoped-final-audio','query-scoped-final-plan','query-final-stages','query-definition','query-scoped-stages','query-scoped-birth','query-split','query-strict3','query-strict4']
assert set(required)<=set(r['label'] for r in rows)
for label in ['query-final-build','query-scoped-final-build','query-final-core-build']:
 x=json.loads((s/(label+'.json')).read_text())
 for p,pin in x['source_after'].items():
  b=Path(p).read_bytes()
  assert len(b)==pin['bytes'] and hashlib.sha256(b).hexdigest()==pin['sha256'],p
for build,total in [('query-final-build',569),('query-scoped-final-build',556)]:
 data=json.loads((s/'plan-results'/build/'results.json').read_text())
 assert len(data)==29 and all(r['exit_code']==0 for r in data)
 assert sum(int(t[1]) for r in data for t in r['test_results'])==total
 assert sum(int(t[2]) for r in data for t in r['test_results'])==0
core=json.loads((s/'core-results/query-final-core-build/results.json').read_text())
assert len(core)==9 and all(r['exit_code']==0 for r in core)
assert next(r for r in core if r['target']=='deadpan_core')['test_results'][0][1]=='807'
assert all(int(t[2])==0 and int(t[3])==0 for r in core for t in r['test_results'])
equality=json.loads((s/'index-source-equality.json').read_text())
assert len(equality)==22 and all(r['equals_isolated_final_build'] for r in equality)
blob_data=(s/'index-blobs.bin').read_bytes();offset=0
for r in equality:
 end=blob_data.index(b'\n',offset);header=blob_data[offset:end].decode().split()
 assert len(header)==3 and header[0]==r['blob'] and header[1]=='blob'
 size=int(header[2]);body=blob_data[end+1:end+1+size]
 assert hashlib.sha256(body).hexdigest()==r['sha256']
 assert blob_data[end+1+size:end+2+size]==b'\n'
 offset=end+2+size
 p=Path('/tmp/deadpan-query-groundwork-2026-10-26/scoped')/r['path']
 assert hashlib.sha256(p.read_bytes()).hexdigest()==r['sha256'],p
assert offset==len(blob_data)
(s/'final-audit.json').write_text(json.dumps({'all_terminal':True,'final_source_and_index_verified':True,'source_files':{'main':1451,'isolated':1222},'index_source_files':22,'also_main':19,'receipts':rows,'core_total_passed':sum(int(t[1]) for r in core for t in r['test_results'])},indent=2)+'\n')
print(json.dumps({'terminal_receipts':len(rows),'core_total_passed':sum(int(t[1]) for r in core for t in r['test_results']),'all_final_sources_match':True,'index_matches_isolated':22}))
