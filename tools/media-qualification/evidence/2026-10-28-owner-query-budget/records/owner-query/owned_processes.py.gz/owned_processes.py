import sys,json
rows=[]
for line in sys.stdin:
 parts=line.split(None,5)
 if len(parts)==6:
  pid,ppid,cpu,rss,elapsed,name=parts
  rows.append({'pid':int(pid),'parent':int(ppid),'cpu_percent':float(cpu),'rss_kib':int(rss),'elapsed':elapsed,'executable':name.strip()})
pids={int(sys.argv[1])}
while True:
 nextpids=pids|{r['pid'] for r in rows if r['parent'] in pids}
 if nextpids==pids:break
 pids=nextpids
print(json.dumps([r for r in rows if r['pid'] in pids],indent=2))
