# Independent review: Root/Domain query-admission integration

Reviewed the integration candidate against `integration/main-before` and the associated Plan candidate APIs read in the same scratch task. This is a read-only review; no Cargo, rustc, Git, or source edits were performed.

## Findings

No concrete correctness finding in the reviewed integration.

## Checked behavior

- `original_context_admitted` routes Root and actual Domain contexts to their corresponding admitted candidate factories. It checks the wrapper's `was_forwarded()` mode against `A::METERED` before consuming it. Metered query Q is already streamed by the Plan/Core walker, so it runs the shared treatment-layer validation without `Context::admit_owner_query` spending Q a second time. Unmetered candidates take the prior `admit_owner_query` path, preserving Q billing and validation order.
- Selection remains the first member whose complete `OwnerKey` matches, from the actual first span of the query result. Selected capture uses that same member index and actual legacy capture implementation; it charges `capture_work()` once after success. The query lease remains live during capture, and fields/drop order release the query value before its lease. The absent-selection branch calls `without_selection(admission)` without requesting new limits or spending synthetic work.
- The incoming Retained branch is unchanged: it performs its retained owners query, first matching clock selection, and old `owner_context` result. It does not enter the new Root/Domain query-admission path.
- `validate_owner_query_layers` is factored from `admit_owner_query`; the metered path avoids duplicate Q spend while preserving validation. The unmetered adapter in `describe` has `METERED = false`, and the legacy receipt equality test calls `original_context`, which wraps `original_context_admitted` with that adapter. Thus its fixture receipts exercise the new unmetered integration rather than only the pre-integration helper.
- The sentinel test compares the first-reservation failure from the actual numerical Root path with a standalone admitted Root query, including forwarded units and `plan_work`, then confirms the prefix is below the frozen complete 22-unit case and leaves sound metadata at zero. This verifies that production reaches query admission before capture/probe. It does not directly exercise the numerical Domain branch; the candidate's branch is a symmetric direct call to `domain.owner_input_candidates_at_admitted`.
- Export/barrel changes expose the admitted candidate type and existing query-input types. Core candidate is unchanged/no-op per task scope.

## Verification boundary

Compile and combined API verification were pending. This review does not claim the candidate builds. The Root sentinel is the one actual numerical-path sentinel covered here; consider adding the analogous actual Domain sentinel if the combined test gate shows the Plan factory unit tests do not already cover Domain routing through the consumer.
