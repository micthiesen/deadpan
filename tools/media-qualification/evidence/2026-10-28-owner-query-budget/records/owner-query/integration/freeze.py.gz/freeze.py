from pathlib import Path
import json,hashlib,difflib
s=Path(__file__).resolve().parent
rows=[];patch=[]
for p in sorted((s/'candidate').rglob('*.rs')):
 name=str(p.relative_to(s/'candidate'));before=s/'main-before'/name
 data=p.read_bytes();old=before.read_bytes() if before.exists() else b''
 if data==old:continue
 rows.append({'path':name,'new':not before.exists(),'before_sha256':hashlib.sha256(old).hexdigest() if before.exists() else None,'candidate_sha256':hashlib.sha256(data).hexdigest()})
 patch.extend(difflib.unified_diff(old.decode().splitlines(True),data.decode().splitlines(True),fromfile='a/'+name if before.exists() else '/dev/null',tofile='b/'+name))
(s/'integration.patch').write_text(''.join(patch))
(s/'candidate-pins.json').write_text(json.dumps(rows,indent=2)+'\n')
print(json.dumps({'changed_files':len(rows),'patch_sha256':hashlib.sha256((s/'integration.patch').read_bytes()).hexdigest()}))
