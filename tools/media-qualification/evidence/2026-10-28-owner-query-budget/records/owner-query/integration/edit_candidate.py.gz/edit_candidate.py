from pathlib import Path
s=Path(__file__).resolve().parent
p=s/'candidate/crates/deadpan-audio/src/authored_eq.rs'
t=p.read_text()
old='''        control.spend_plan_work(query.work())?;
        for span in query.spans() {'''
new='''        control.spend_plan_work(query.work())?;
        Self::validate_owner_query_layers(query)
    }

    /// Shared validation runs for both legacy unpaid and admitted prepaid Q.
    pub(super) fn validate_owner_query_layers(
        query: &AudioOwnerQuery<'plan>,
    ) -> Result<(), StageAudioError> {
        for span in query.spans() {'''
assert t.count(old)==1
p.write_text(t.replace(old,new))
p=s/'candidate/crates/deadpan-audio/src/shared_eq/node_description.rs'
t=p.read_text()
old='''        Context::Root => plan.audio_owner_input_candidates_at(at, control.query_limits()?)?,
        Context::Domain(domain) => domain.owner_input_candidates_at(at, control.query_limits()?)?,'''
new='''        Context::Root => plan.audio_owner_input_candidates_at_admitted(
            at,
            control.query_limits()?,
            admission,
        )?,
        Context::Domain(domain) => domain.owner_input_candidates_at_admitted(
            at,
            control.query_limits()?,
            admission,
        )?,'''
assert t.count(old)==1;t=t.replace(old,new)
old='''    Context::admit_owner_query(candidates.query(), control)?;
    let selected'''
new='''    if candidates.was_forwarded() != A::METERED {
        return Err(PlanError::InvalidPlan("owner query accounting mode differs").into());
    }
    if A::METERED {
        // Q was streamed by the actual Plan/Core kernel, including inspections.
        Context::validate_owner_query_layers(candidates.query())?;
    } else {
        Context::admit_owner_query(candidates.query(), control)?;
    }
    let selected'''
assert t.count(old)==1;t=t.replace(old,new)
old='''        let capture = candidates.capture(index, control.query_limits()?)?;'''
new='''        // The actual query stays charged while the same legacy capture runs.
        // Capture C is not forwarded by the query-only admission slice.
        let capture = candidates.capture(index, control.query_limits()?, admission)?;'''
assert t.count(old)==1;t=t.replace(old,new)
old='''        candidates.without_selection()
    };'''
new='''        candidates.without_selection(admission)?
    };'''
assert t.count(old)==1;t=t.replace(old,new)
p.write_text(t)
for name,old,new in [
 ('crates/deadpan-plan/src/lib.rs',
  '    AudioOwnerInput, AudioOwnerInputCandidates, AudioOwnerInputCapture, AudioOwnerInputScope,',
  '    AdmittedAudioOwnerInputCandidates, AudioOwnerInput, AudioOwnerInputCandidates,\\n    AudioOwnerInputCapture, AudioOwnerInputScope,'),
 ('crates/deadpan-plan/src/plan.rs',
  '    AudioOwnerInput, AudioOwnerInputCandidates, AudioOwnerInputCapture, AudioOwnerInputScope,',
  '    AdmittedAudioOwnerInputCandidates, AudioOwnerInput, AudioOwnerInputCandidates,\\n    AudioOwnerInputCapture, AudioOwnerInputScope,')
]:
 p=s/'candidate'/name;t=p.read_text();assert t.count(old)==1
 p.write_text(t.replace(old,new.replace(chr(92) + "n", chr(10))))
print('Prepared actual Audio query integration and Plan exports in scratch only.')
