from pathlib import Path
r=Path('/tmp/deadpan-owner-query-budget-2026-10-28/plan/candidate/crates/deadpan-plan/src')
p=r/'audio_owners.rs';s=p.read_text()
# Module visibility needed only by real Plan allocation-site constructors.
s=s.replace('use crate::{AudioBoundaryRule, AudioSampleGrid, AudioSampleMap, PlanError};','''use crate::{AudioBoundaryRule, AudioSampleGrid, AudioSampleMap, PlanError};

#[path="audio_owner_query_admission.rs"]
pub(super) mod admission;
#[path="audio_owner_query.rs"]
mod query_admission;''')
# Move common actual walk body to generic tracked kernel; test wrapper retains old
# transferred() private fixture call, while all normal queries use that same body.
start=s.index('fn walk(\n');end=s.index('\nfn restrict_end(',start)
old=s[start:end]
body=old[old.index('    if depth >'):]
body=body[:body.rfind('\n}')]
body=body.replace('budget.spend(', 'budget.canonical(')
body=body.replace('''        let instance = InstancePath {
            node: node.inspection.id.clone(),
            repeats: state.repeats.clone(),
        };
        let gap_after = state.gap.as_ref().and_then(|gap| gap.after.clone());''','''        // The inherited canonical(1 + repeats.len()) above pays this path
        // copy. Helpers add only actual new ownership/layout inspections.
        let mut instance_memory=budget.memory();
        let mut instance_capacity=budget.memory();
        let instance=InstancePath {
            node:budget.node(&mut instance_memory,&node.inspection.id)?,
            repeats:budget.repeats(&mut instance_memory,&mut instance_capacity,&state.repeats)?,
        };
        budget.check_memory(&instance_memory)?;budget.check_memory(&instance_capacity)?;
        budget.merge_checked(&mut instance_memory,&mut instance_capacity);
        let gap_after=state.gap.as_ref().and_then(|gap|gap.after.as_ref())
            .map(|v|budget.iteration(&mut instance_memory,v)).transpose()?;''')
body=body.replace('plan.bound_at(', 'plan.bound_at_query(').replace('bound.envelope_domain(budget)?','bound.envelope_domain_query(budget)?')
body=body.replace('''                let mut retained = Walk::from_seed(&domain.seed);
                retained.allow_inactive = state.allow_inactive;
                return walk(
                    plan,
                    retained,
                    reference,
                    output,
                    AudioOwnerClockOrigin::Retained {
                        definition: state.definition,
                        instance,
                        kind,
                        gap_after,
                    },
                    budget,
                    depth + 1,
                );''','''                let mut retained=State::from_seed(&domain.seed,budget)?;
                retained.value.allow_inactive=state.allow_inactive;
                // These moved values are still covered by the enclosing state
                // and instance scopes until the actual recursive call returns.
                let next_origin=AudioOwnerClockOrigin::Retained {
                    definition:state.value.definition.take(),instance,kind,gap_after
                };
                return walk_query(plan,retained,reference,output,&next_origin,budget,depth+1);''')
old='''        output.owners.push(RawOwner {
            definition: state.definition.clone(),
            instance,
            kind,
            gap_after,
            play: None,
            position: local,
            origin: origin.clone(),
        });'''
new='''        budget.grow(&mut output.value.owners,&mut output.capacity,output.value.owners.len()+1)?;
        let definition=budget.definition(&mut instance_memory,&state.definition)?;
        let copied_origin=budget.origin(&mut instance_memory,origin)?;
        budget.check_memory(&output.memory)?;budget.check_memory(&instance_memory)?;
        output.value.owners.push(RawOwner {
            definition,instance,kind,gap_after,play:None,position:local,origin:copied_origin
        });
        budget.merge_checked(&mut output.memory,&mut instance_memory);'''
assert old in body;body=body.replace(old,new)
body=body.replace('''                let repeat = node.inspection.id.clone();''','''                let mut repeat_memory=budget.memory();
                let repeat=budget.node(&mut repeat_memory,&node.inspection.id)?;''')
body=body.replace('''                        state.repeats.push(RepeatInstance {
                            node: repeat,
                            iteration: location.play.iteration,
                        });''','''                        state.push_repeat(RepeatInstance{node:repeat,iteration:location.play.iteration},&mut repeat_memory,budget)?;''')
body=body.replace('''                    state.repeats.push(RepeatInstance {
                        node: repeat,
                        iteration: location.play.iteration,
                    });''','''                    state.push_repeat(RepeatInstance{node:repeat,iteration:location.play.iteration},&mut repeat_memory,budget)?;''')
body=body.replace('''                        state.gap = Some(DomainGap {
                            after: Some(location.play.iteration),
                            duration: *gap_duration,
                        });''','''                        // location.play owns its actual iteration; its identity
                        // edge is newly retained when moved into this state.
                        budget.own_iteration(&mut state.memory,&location.play.iteration)?;
                        state.value.gap=Some(DomainGap{after:Some(location.play.iteration),duration:*gap_duration});''')
# Direct semantic errors now use the internal typed error channel.
body=body.replace('return Err(PlanError::AudioQueryLimit("owner binding depth"));','return Err(PlanError::AudioQueryLimit("owner binding depth").into());')
body=body.replace('''return Err(PlanError::InvalidPlan(
                "owner coordinate is outside its allocated interval",
            ));''','''return Err(PlanError::InvalidPlan(
                "owner coordinate is outside its allocated interval",
            ).into());''')
body=body.replace('''return Err(PlanError::InvalidPlan(
                        "owner binding has empty meaningful support",
                    ));''','''return Err(PlanError::InvalidPlan(
                        "owner binding has empty meaningful support",
                    ).into());''')
generic='''fn walk_query<A:crate::AudioSoundContextAdmission>(
    plan:&RenderPlan,mut state:State<A::Issuer,A::Lease>,position:Position,
    output:&mut Output<A::Issuer,A::Lease>,origin:&AudioOwnerClockOrigin,
    budget:&mut admission::Budget<'_,A>,depth:usize
)->admission::Result<(),A>{
'''+body+'''
}
'''
# query_mapped common body replaced by a no-op-policy wrapper.
qs=s.index('fn query_mapped<');qe=s.index('\nfn walk(',qs)
sig=s[qs:s.index('    limits.validate()?;',qs)]
replacement=sig+'''    let mut local=Budget {remaining:limits.maximum_work,lookup:LookupStats::default()};
    let mut policy=admission::Unmetered;
    let mut budget=admission::Budget::new(&mut local,&mut policy);
    let seed=State::plain(seed,budget.issuer);
    admission::outer::<_,_>(query_tracked(plan,samples,limits,seed,label,retained,&mut budget))
        .map(|value|value.query.unmetered())
}
'''
s=s[:qs]+replacement+s[qe:]
start=s.index('fn walk(\n');end=s.index('\nfn restrict_end(',start)
wrapper='''#[cfg(test)]
fn walk(plan:&RenderPlan,state:Walk,position:Position,output:&mut WalkOutput,
    origin:AudioOwnerClockOrigin,budget:&mut Budget,depth:usize)->Result<(),PlanError>{
    let mut policy=admission::Unmetered;
    let mut query_budget=admission::Budget::new(budget,&mut policy);
    let old=std::mem::replace(output,WalkOutput{start:0,end:0,owners:Vec::new(),support:AudioOwnerSupport::Active,
        through_processor:false,original_is_silent:false});
    let mut tracked=Output::plain(old,());
    let result=admission::outer::<_,_>(walk_query(plan,State::plain(state,()),position,&mut tracked,&origin,&mut query_budget,depth));
    *output=tracked.value;
    result
}
'''
s=s[:start]+wrapper+s[end:]
s=s.replace('mod query_admission;','mod query_admission;\nuse query_admission::{State,Output,query_tracked,walk_query};')
p.write_text(s)
newmodule='''//! Actual owner query loop with allocation-site guards.
use super::*;
use admission::{Memory,Owned,Result};
use crate::AudioSoundContextAdmission;
use crate::audio_allocated::admission::array;

pub(super) struct State<I,L>{pub(super) value:Walk,pub(super) memory:Memory<I,L>,capacity:Memory<I,L>}
impl<I,L> std::ops::Deref for State<I,L>{type Target=Walk;fn deref(&self)->&Walk{&self.value}}
impl<I,L> std::ops::DerefMut for State<I,L>{fn deref_mut(&mut self)->&mut Walk{&mut self.value}}
impl<I:Copy+Eq,L> State<I,L>{
 pub(super) fn plain(value:Walk,issuer:I)->Self{Self{value,memory:Memory::empty(issuer),capacity:Memory::empty(issuer)}}
 pub(super) fn from_seed<A:AudioSoundContextAdmission<Issuer=I,Lease=L>>(seed:&AudioWalkSeed,budget:&mut admission::Budget<'_,A>)->Result<Self,A>{
   let placement=Placement{origin:seed.transform.project_origin,scale:seed.transform.project_frames_per_local_frame};
   let value=Walk{node:seed.node,definition:None,repeats:Vec::new(),gap:None,bypass:seed.bypass_binding,
      grid:seed.grid,placement,binding:BindingClock{grid:seed.grid,placement},
      extent:seed.extent.clone(),support:seed.envelope.clone(),allow_inactive:false};
   let mut result=Self::plain(value,budget.issuer);
   result.value.definition=budget.definition(&mut result.memory,&seed.definition)?;
   result.value.repeats=budget.repeats(&mut result.memory,&mut result.capacity,&seed.repeats)?;
   result.value.gap=budget.gap(&mut result.memory,&seed.gap)?;
   Ok(result)
 }
 fn copy<A:AudioSoundContextAdmission<Issuer=I,Lease=L>>(&self,budget:&mut admission::Budget<'_,A>)->Result<Self,A>{
   let Walk{node,definition,repeats,gap,bypass,grid,placement,binding,extent,support,allow_inactive}=&self.value;
   let value=Walk{node:*node,definition:None,repeats:Vec::new(),gap:None,bypass:*bypass,grid:*grid,
      placement:*placement,binding:*binding,extent:extent.clone(),support:support.clone(),allow_inactive:*allow_inactive};
   let mut result=Self::plain(value,budget.issuer);
   result.value.definition=budget.definition(&mut result.memory,definition)?;
   result.value.repeats=budget.repeats(&mut result.memory,&mut result.capacity,repeats)?;
   result.value.gap=budget.gap(&mut result.memory,gap)?;
   Ok(result)
 }
 fn push_repeat<A:AudioSoundContextAdmission<Issuer=I,Lease=L>>(&mut self,value:RepeatInstance,source:&mut Memory<I,L>,budget:&mut admission::Budget<'_,A>)->Result<(),A>{
   budget.own_iteration(source,&value.iteration)?;
   let needed=self.value.repeats.len()+1;
   budget.grow(&mut self.value.repeats,&mut self.capacity,needed)?;
   budget.check_memory(&self.memory)?;budget.check_memory(source)?;
   self.value.repeats.push(value);
   budget.merge_checked(&mut self.memory,source);Ok(())
 }
}
pub(super) struct Output<I,L>{pub(super) value:WalkOutput,memory:Memory<I,L>,capacity:Memory<I,L>}
impl<I,L> std::ops::Deref for Output<I,L>{type Target=WalkOutput;fn deref(&self)->&WalkOutput{&self.value}}
impl<I,L> std::ops::DerefMut for Output<I,L>{fn deref_mut(&mut self)->&mut WalkOutput{&mut self.value}}
impl<I:Copy,L> Output<I,L>{
 pub(super) fn plain(value:WalkOutput,issuer:I)->Self{Self{value,memory:Memory::empty(issuer),capacity:Memory::empty(issuer)}}
}
pub(in crate::plan) struct Product<'plan,S,I,L>{
 pub(in crate::plan) query:Owned<AudioOwnerQuery<'plan,S>,I,L>,
 pub(in crate::plan) canonical:usize,pub(in crate::plan) additional:usize,
}
pub(super) fn query_tracked<'plan,S:Copy,A:AudioSoundContextAdmission>(
 plan:&'plan RenderPlan,samples:Range<i64>,limits:AudioQueryLimits,seed:State<A::Issuer,A::Lease>,
 label:impl Fn(i64)->S,retained:Option<&AudioOwnerRetainedInput<'plan>>,budget:&mut admission::Budget<'_,A>
)->Result<Product<'plan,S,A::Issuer,A::Lease>,A>{
 limits.validate()?;
 if samples.end<samples.start{return Err(PlanError::AudioRangeOutOfRange.into());}
 let mut payload=budget.memory();
 let mut capacity=budget.memory();
 let mut spans=Vec::new();
 let mut cursor=samples.start;
 while cursor<samples.end{
   if spans.len()==limits.maximum_spans{return Err(PlanError::AudioQueryLimit("owner span count").into());}
   let mut output=Output::plain(WalkOutput{start:cursor,end:samples.end,owners:Vec::new(),support:AudioOwnerSupport::Active,
      through_processor:false,original_is_silent:false},budget.issuer);
   let origin=retained.map_or(AudioOwnerClockOrigin::Current,AudioOwnerRetainedInput::clock_origin);
   walk_query(plan,seed.copy(budget)?,match retained{
      Some(input)=>Position{at:input.reference_at(AudioSample(cursor))?,step:input.reference_samples_per_output_sample()},
      None=>Position{at:ExactRatio::integer(cursor),step:ExactRatio::ONE}
   },&mut output,&origin,budget,0)?;
   if output.end<=cursor||(output.owners.is_empty()&&output.support==AudioOwnerSupport::Active){
      return Err(PlanError::InvalidPlan("owner interval did not advance").into());
   }
   let mut owners_capacity=budget.memory();
   budget.reserve(&mut owners_capacity,array::<AudioOwnerClock<'plan,S>>(output.owners.len())?)?;
   let mut owners=Vec::with_capacity(output.owners.len());
   if A::METERED{assert_eq!(owners.capacity(),output.owners.len());}
   for owner in std::mem::take(&mut output.value.owners){
      owners.push(AudioOwnerClock{plan,definition:owner.definition,instance:owner.instance,kind:owner.kind,
         gap_after:owner.gap_after,play:owner.play,origin:owner.origin,
         sampling:AudioSampleMap::new(label(cursor),owner.position.at,owner.position.step)?});
   }
   let needed=spans.len()+1;
   budget.grow(&mut spans,&mut capacity,needed)?;
   budget.check_memory(&payload)?;budget.check_memory(&output.memory)?;budget.check_memory(&owners_capacity)?;
   spans.push(AudioOwnerSpan{samples:label(cursor)..label(output.end),owners,
      support:output.support,original_is_silent:output.original_is_silent});
   budget.merge_checked(&mut payload,&mut output.memory);
   budget.merge_checked(&mut payload,&mut owners_capacity);
   cursor=output.end;
 }
 budget.check_memory(&payload)?;budget.check_memory(&capacity)?;
 budget.merge_checked(&mut payload,&mut capacity);
 let canonical=budget.canonical_used;let additional=budget.additional_used;
 let work=canonical.checked_add(additional).ok_or(TimeError::Overflow)?;
 Ok(Product{query:Owned{value:AudioOwnerQuery{plan,samples:label(samples.start)..label(samples.end),spans,lookup:budget.lookup,work},memory:payload},canonical,additional})
}
'''+generic
(r/'audio_owner_query.rs').write_text(newmodule)
