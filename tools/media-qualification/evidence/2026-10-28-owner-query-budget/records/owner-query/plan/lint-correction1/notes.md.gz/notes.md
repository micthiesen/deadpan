# Lint correction1

Two current-live source snapshots, scratch-only patch/candidates. Private
BoundResult and EnvelopeResult aliases name the existing identical generic
return types. The known Unmetered query_mapped wrapper supplies literal () as its
issuer, rather than passing its unit-valued field. No callback or side effect is
removed: budget.issuer is an already stored unit field.

No allows, boxes, allocations, accounting, caps, numerical/body ordering or API
changes. Scoped rustfmt parsed both. Initial candidate/pins/patch remain
unchanged; no Cargo/rustc/live/scoped/index writes.
