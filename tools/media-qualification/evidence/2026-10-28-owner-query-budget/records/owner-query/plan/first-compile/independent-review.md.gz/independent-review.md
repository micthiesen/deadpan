# Independent first Plan-candidate review

Reviewed `plan.patch` SHA `ac563a68abbe75c25c257accf938d1829facf7af26379785319b7d4704560e15`, the 11 pinned candidate files, and `notes.md`. No Cargo/rustc/Git or live-source writes.

## Findings

No supported correctness finding in this Plan candidate.

The candidate shares the existing query walk and bound/domain construction between the compatibility and admitted modes. Root and Domain entry paths preserve their distinct seed behavior; the admitted Domain path copies the exact captured seed before the existing limits validation point. The legacy `METERED = false` adapters retain the old copy/collect storage behavior and do not call the host policy. In admitted mode the Core query receives remaining local work, returns a typed receipt, and the Plan wrapper accounts it locally once without forwarding it a second time. The actual capture still consumes the same sealed query and parent; the query lease remains in the admitted wrapper through capture and releases when the consumed query has dropped. No-selection consumes the query, reports its work, and does not ask for fresh capture limits.

Inspected allocation paths cover the constructed owner state/Repeat copies, growing `Walk`/owner/span/exclusion vectors with old/new buffers coexisting, mapped output storage, bound-owned identity/constraint fields, and the actual temporary envelope Domain. Value fields are declared before their independent leases, and the inspected growth/replacement paths drop old vectors before replacing their leases. The query output and capture work are separately accounted; capture work remains the legacy unpaid C path, while admitted Q is forwarded once. Tests wire the actual root/domain constructors and compare complete logical query/input fields and work against the frozen 14-case fixture, with separate exact/one-short/failure cleanup and mode/issuer checks.

The envelope Domain deliberately retains the construction-allocation charge after replacing some temporary identity/constraint fields. This is a conservative bound and can overcharge the recursive phase relative to current live bytes. It is explicitly documented as construction-peak accounting, rather than asserted as the minimum post-replacement live footprint; within that stated conservative policy, I did not find a safety undercount or an unbounded accumulator. No BTree-size estimate or cache/replay path is introduced.

## Limits / verification still owed

This is source review only. Candidate tests and compiler/clippy checks had not yet been reported complete at review time. No conclusion here covers full native peak calibration, future Root/Domain/Core allocation sites outside this bounded query/capture slice, recursive graph admission, or batching. The work preserves the legacy capture path, so its C remains outside this patch's additional-allocation instrumentation as described in the task.
