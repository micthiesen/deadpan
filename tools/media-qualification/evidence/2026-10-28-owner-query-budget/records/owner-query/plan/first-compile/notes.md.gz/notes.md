# First Plan query compiler snapshot

Scratch-only11-file candidate,5 new private modules/tests. All6 existing before
bytes exactly match current main AND scoped; no inherited normalization needed
inside these owned files. Parent's barrels/Audio integration and Core candidate
are separate. No live/scoped/index edits or Cargo/rustc by worker.

Public entrypoints and methods match final34e027 contract. Minimal
audio_owner_input.rs reexport included as parent requested. Parent must add
AdmittedAudioOwnerInputCandidates through its owned Plan/lib barrels.

The actual owner walk and query loop are shared between compatibility and
admitted paths. Same actual bound scalar/decision body and root_domain_on_grid
constructor are reused. Legacy bound resolution selects legacy Core storage;
admitted selects Core's owned guard and linear canonical/additional receipt.
Core work is accounted locally once without forwarding it again. Bounds map
Core value directly into AudioBound while Plan fields/charges stay alongside.

Allocation-site guards cover initial/copied Walk metadata, repeat buffers and
growth with old/new coexistence, RawOwner buffers/IDs, mapped Clock buffers,
Span buffers, Core-bound Plan fields/exclusions/constraints, and the reached
temporary envelope Domain constructor/evaluation copies. No aggregate post-hoc
visitor, provider/native probe, cache or replay. False mode bypasses ownership
layout/ID instrumentation and keeps legacy push/collect/Core storage backends.
Original prepaid repeat-path canonical debit stays at its original site.

Query value precedes its lease and remains owned/charged throughout the exact
legacy capture call, which still returns unpaid C and uses the sealed stored
parent/query/member. No-selection validates issuer/mode, consumes same query and
requests no fresh limits. Admitted query total/canonical/additional/mode getters
match parent's planned consumer. Incoming Retained query/capture stays legacy.

Four initial tests use the independent frozen14-case SnapshotV1; no golden
regeneration. Full ordered legacy window/one-sample semantics and captured
private seed fields compare to OLD output, with canonical Q separately equal
to old Q, total Q=old+actual-added and host debit reconciled. Both modes;
exact-byte/one-short construction, partial cleanup, foreign issuer before
capture semantics, absence and seeded invalid-limit/early-admission order.

This is a first coherent compiler snapshot, not a successful-check claim.
Parent owns actual builds/tests/strict review. Additional drop/peak review:
temporary envelope Domain conservatively keeps its construction-peak charge
through recursive use, including initial identity edges replaced by evaluation
fields. This is an upper bound from real exact allocations/copies, not a lower
native estimate; it is not claimed to be a minimum post-replacement live bound.
Actual Core sequential temporaries retain their separate guards, not a merged
monotonic query allocation sum. Query result retains only its own output memory.

The original frozen producer/serializer file has ONLY an appended private test
child hook; existing producer bytes/immutable JSON remain intact.
