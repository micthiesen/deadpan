from pathlib import Path
import hashlib,json,difflib,shutil
r=Path('/tmp/deadpan-owner-query-budget-2026-10-28/plan')
repo=Path('/Users/michael/Code/deadpan');scope=Path('/tmp/deadpan-query-groundwork-2026-10-26/scoped')
f=r/'first-compile';f.mkdir(exist_ok=True)
sha=lambda b:hashlib.sha256(b).hexdigest()
manifest=[];parts=[]
for p in sorted((r/'candidate').rglob('*.rs')):
 name=p.relative_to(r/'candidate');old=r/'before'/name;new=p.read_bytes()
 if old.exists():
  before=old.read_bytes();assert(repo/name).read_bytes()==before,str(name)
  assert(scope/name).read_bytes()==before,('scope differs',str(name))
 else:before=b'';assert not(repo/name).exists() and not(scope/name).exists()
 out=f/'candidate'/name;out.parent.mkdir(parents=True,exist_ok=True);out.write_bytes(new)
 if old.exists():
  out=f/'before'/name;out.parent.mkdir(parents=True,exist_ok=True);out.write_bytes(before)
 manifest.append({'path':str(name),'new':not old.exists(),'before_sha256':sha(before) if old.exists() else None,'candidate_sha256':sha(new),'bytes':len(new)})
 parts.extend(difflib.unified_diff(before.decode().splitlines(True),new.decode().splitlines(True),fromfile='a/'+str(name) if old.exists() else '/dev/null',tofile='b/'+str(name)))
(f/'plan.patch').write_text(''.join(parts));(f/'pins.json').write_text(json.dumps(manifest,indent=2)+'\n')
for name in ['plan.patch','pins.json']:print(name,sha((f/name).read_bytes()))
print('files',len(manifest),'new',sum(v['new'] for v in manifest))
