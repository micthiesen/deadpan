# Compiler correction1

Three actual legacy wrappers and the same private cfg(test) compatibility walk
wrapper now name admission::Unmetered explicitly. Rust cannot infer a policy type
backwards from its associated Error. No budget, lease, query, allocation, semantic
ordering or public API change.

Output/walk_query imports are cfg(test), matching their only parent use.
Plan unused-import warning corrected. The separate Core dead_code warning for
project_scoped_supported belongs to Core worker; no Core edit in this delta.

Before snapshots are current live combined-build bytes; candidates/patch are
scratch only. Scoped rustfmt parsed all three. Initial first-compile files/pins/
patch remain unchanged. No Cargo/rustc/live/scoped/index writes.
