from pathlib import Path
r=Path('/tmp/deadpan-owner-query-budget-2026-10-28/plan/candidate/crates/deadpan-plan/src')
p=r/'audio_bound.rs';s=p.read_text()
start=s.index('    fn definition_exclusions(');bs=s.index('    pub(super) fn bound_at(',start);end=s.index('\n}\n\nimpl<\'plan> AudioBound',bs)
original=s[bs:end]
# Keep the actual scalar/decision body once, now in the generic query child.
body=original[original.index('        let BoundPlacement {'):]
body=body[:body.rfind('\n    }')]
body=body.replace('return Ok(None);','return Ok(None);')
body=body.replace('budget.spend(', 'budget.canonical(')
body=body.replace('''        let instance = InstancePath {
            node: id.clone(),
            repeats: repeats.to_vec(),
        };''','''        let mut memory = budget.memory();
        let mut instance_capacity = budget.memory();
        let instance = InstancePath {
            node: budget.node(&mut memory,id)?,
            repeats: budget.repeats(&mut memory,&mut instance_capacity,repeats)?,
        };
        budget.check_memory(&memory)?;budget.check_memory(&instance_capacity)?;
        budget.merge_checked(&mut memory,&mut instance_capacity);''')
body=body.replace('''        let excluded = definition
            .map(|selector| self.definition_exclusions(selector, budget))
            .transpose()?;''','''        let mut excluded_memory = budget.memory();
        let excluded = definition
            .map(|selector| self.definition_exclusions_query(selector, budget, &mut excluded_memory))
            .transpose()?;''')
startresolve=body.index('        let resolved = if gap.is_some() {');endresolve=body.index('        let lattice = &resolved.lattice;',startresolve)
body=body[:startresolve]+'''        let mut resolved = if A::METERED {
            let mut adapter=CoreAdmission {outer:budget.admission};
            Resolved::Metered(core::<_,A>(if gap.is_some() {
                self.audio_bindings.resolve_gap_in_admitted(id,environment,budget.remaining,&mut adapter)
            } else {
                self.audio_bindings.resolve_in_admitted(id,environment,budget.remaining,&mut adapter)
            })?)
        } else {
            Resolved::Legacy(if gap.is_some() {
                self.audio_bindings.resolve_gap_in(id,environment,budget.remaining)?
            } else {
                self.audio_bindings.resolve_in(id,environment,budget.remaining)?
            })
        };
        match &mut resolved {
            Resolved::Legacy(value)=>budget.canonical(value.work)?,
            Resolved::Metered(value)=>{
                let work={let adapter=CoreAdmission{outer:budget.admission};core::<_,A>(value.take_work(&adapter))?};
                budget.account_core(work)?;
            }
        }
        let resolved_value=resolved.value();
''' +body[endresolve:]
body=body.replace('let lattice = &resolved.lattice;', 'let lattice = &resolved_value.lattice;').replace('let local_anchor = resolved\n','let local_anchor = resolved_value\n').replace('let phase = resolved\n','let phase = resolved_value\n')
old='''        let constraints = constraints
            .iter()
            .map(|constraint| {
                Ok(EnvelopeConstraint {
                    range: project(constraint.range.start)?..project(constraint.range.end)?,
                    ..constraint.clone()
                })
            })
            .collect::<Result<Vec<_>, PlanError>>()?;'''
new='''        let mut constraint_capacity=budget.memory();
        budget.reserve(&mut constraint_capacity,array::<EnvelopeConstraint>(constraints.len())?)?;
        let mut copied_constraints=Vec::with_capacity(constraints.len());
        if A::METERED {assert_eq!(copied_constraints.capacity(),constraints.len());}
        for constraint in constraints {
            let range=project(constraint.range.start)?..project(constraint.range.end)?;
            let mut value=budget.constraint(&mut memory,constraint)?;
            value.range=range;
            copied_constraints.push(value);
        }
        budget.check_memory(&memory)?;budget.check_memory(&constraint_capacity)?;
        budget.merge_checked(&mut memory,&mut constraint_capacity);
        let constraints=copied_constraints;'''
assert old in body;body=body.replace(old,new)
old='''        Ok(Some(AudioBound {
            plan: self,
            node,
            definition: definition.cloned(),
            instance,
            gap: gap.cloned(),
            resolved,
            reference_at_anchor: reference.checked_add(offset.checked_mul(reference_step)?)?,
            reference_step,
            support,
            envelope_scale,
            constraints,
        }))'''
new='''        let definition=budget.definition(&mut memory,&definition.cloned())?;
        let gap=budget.gap(&mut memory,&gap.cloned())?;
        let reference_at_anchor=reference.checked_add(offset.checked_mul(reference_step)?)?;
        budget.check_memory(&memory)?;
        let make=|resolved|AudioBound {plan:self,node,definition,instance,gap,resolved,
            reference_at_anchor,reference_step,support,envelope_scale,constraints};
        let value=match resolved {
            Resolved::Legacy(value)=>BoundValue::Legacy(make(value)),
            Resolved::Metered(value)=>{
                let adapter=CoreAdmission{outer:budget.admission};
                BoundValue::Metered(core::<_,A>(value.map_value(&adapter,make))?)
            }
        };
        Ok(Some(QueryBound {value, memory}))'''
assert old in body;body=body.replace(old,new)
# Avoid unadmitted preliminary option clones at final copy site.
body=body.replace('budget.definition(&mut memory,&definition.cloned())?', 'budget.definition_ref(&mut memory,definition)?')
body=body.replace('budget.gap(&mut memory,&gap.cloned())?', 'budget.gap_ref(&mut memory,gap)?')
body=body.replace('return Err(PlanError::AudioQueryLimit("binding resolution"));','return Err(PlanError::AudioQueryLimit("binding resolution").into());')
newmodule='''//! Shared actual binding/envelope constructors for legacy and admitted queries.
use super::*;
use crate::plan::audio_owners::admission::{self,Budget as QueryBudget,Memory,Owned,CoreAdmission,Result,core};
use crate::{AudioSoundContextAdmission,AudioQueryLimits};
use crate::audio_allocated::admission::array;
use deadpan_core::{AdmittedAudioBinding,AudioBindingValue};

enum Resolved<I,L>{Legacy(ResolvedAudioBinding),Metered(AdmittedAudioBinding<I,L>)}
impl<I:Copy+Eq,L> Resolved<I,L>{
 fn value(&self)->&ResolvedAudioBinding {match self{Self::Legacy(v)=>v,Self::Metered(v)=>v.value()}}
}
enum BoundValue<'plan,I,L>{Legacy(AudioBound<'plan>),Metered(AudioBindingValue<AudioBound<'plan>,I,L>)}
pub(in crate::plan) struct QueryBound<'plan,I,L>{value:BoundValue<'plan,I,L>,memory:Memory<I,L>}
impl<'plan,I:Copy+Eq,L> std::ops::Deref for QueryBound<'plan,I,L>{
 type Target=AudioBound<'plan>;
 fn deref(&self)->&Self::Target{match &self.value{BoundValue::Legacy(v)=>v,BoundValue::Metered(v)=>v.value()}}
}
impl<'plan> QueryBound<'plan,(),()> {
 pub(in crate::plan) fn unmetered(self)->AudioBound<'plan>{match self.value{BoundValue::Legacy(v)=>v,BoundValue::Metered(_)=>unreachable!("legacy binding backend")}}
}
impl RenderPlan {
 fn definition_exclusions_query<A:AudioSoundContextAdmission>(
   &self,selector:&AudioDefinitionSelector,budget:&mut QueryBudget<'_,A>,memory:&mut Memory<A::Issuer,A::Lease>
 )->Result<(NodeId,Vec<NodeId>),A>{
   let mut temporary=budget.memory();
   let copied=budget.definition_ref(&mut temporary,Some(selector))?.expect("selector");
   let definition=self.audio_definition(copied)?;
   let mut current=self.parents[definition.root];
   let mut capacity=budget.memory();
   let mut excluded=Vec::new();
   while let Some(index)=current{
     budget.canonical(1)?;
     if matches!(self.nodes[index].kind,CompiledKind::Repeat{..}){
       budget.grow(&mut excluded,&mut capacity,excluded.len()+1)?;
       excluded.push(budget.node(memory,&self.nodes[index].inspection.id)?);
     }
     current=self.parents[index];
   }
   excluded.reverse();
   let root=budget.node(memory,definition.root())?;
   budget.check_memory(memory)?;budget.check_memory(&capacity)?;
   budget.merge_checked(memory,&mut capacity);
   Ok((root,excluded))
 }
 pub(in crate::plan) fn bound_at_query<A:AudioSoundContextAdmission>(
   &self,node:usize,repeats:&[RepeatInstance],definition:Option<&AudioDefinitionSelector>,
   placement:BoundPlacement<'_>,budget:&mut QueryBudget<'_,A>
 )->Result<Option<QueryBound<'_,A::Issuer,A::Lease>>,A>{
'''+body+'''
 }
}
impl<'plan> AudioBound<'plan>{
 pub(in crate::plan) fn envelope_domain_query<A:AudioSoundContextAdmission>(
   &self,budget:&mut QueryBudget<'_,A>
 )->Result<Option<Owned<AudioDomain<'plan>,A::Issuer,A::Lease>>,A>{
   budget.canonical(self.constraints.len()+self.instance.repeats.len()+1)?;
   if !self.support.end.checked_sub(self.support.start)?.compare_integer(0).is_gt(){return Ok(None);}
   let mut temporary=budget.memory();
   let gap=budget.gap(&mut temporary,&self.gap)?;
   let selector=if self.gap.is_some(){
     AudioDefinitionSelector::RepeatGap{repeat:budget.node(&mut temporary,&self.instance.node)?}
   }else{AudioDefinitionSelector::Node{node:budget.node(&mut temporary,&self.instance.node)?}};
   let definition=AudioDefinition{plan:self.plan,root:self.node,gap,selector};
   let lattice=&self.resolved.lattice;
   let placement=AudioRootPlacement::new(lattice.origin,lattice.frames_per_local_frame,self.support.clone())?;
   let mut domain=definition.root_domain_on_grid_query(placement,lattice.grid_origin,
      match lattice.grid_rule{AudioBindingGridRule::RootRoundEven=>crate::AudioBoundaryRule::RoundEven,AudioBindingGridRule::PointCeil=>crate::AudioBoundaryRule::PointCeil},budget)?;
   // Construction peak stays charged during this temporary Domain's use.
   domain.value.seed.definition=budget.definition(&mut domain.memory,&self.definition)?;
   domain.value.seed.bypass_binding=Some(self.binding_target());
   let mut capacity=budget.memory();
   domain.value.seed.repeats=budget.repeats(&mut domain.memory,&mut capacity,&self.instance.repeats)?;
   budget.check_memory(&domain.memory)?;budget.check_memory(&capacity)?;
   budget.merge_checked(&mut domain.memory,&mut capacity);
   let count=domain.value.seed.constraints.len()+self.constraints.len();
   // Original one-element buffer and replacement coexist until the old drops.
   let mut next_capacity=budget.memory();
   budget.reserve(&mut next_capacity,array::<EnvelopeConstraint>(count)?)?;
   let mut next=Vec::with_capacity(count);
   if A::METERED{assert_eq!(next.capacity(),count);}
   next.append(&mut domain.value.seed.constraints);
   for value in &self.constraints{next.push(budget.constraint(&mut domain.memory,value)?);}
   domain.value.seed.constraints=next;
   budget.check_memory(&domain.memory)?;budget.check_memory(&next_capacity)?;
   budget.merge_checked(&mut domain.memory,&mut next_capacity);
   let mut cap=budget.memory();
   domain.value.instance=budget.instance(&mut domain.memory,&mut cap,&self.instance)?;
   budget.check_memory(&domain.memory)?;budget.check_memory(&cap)?;
   budget.merge_checked(&mut domain.memory,&mut cap);
   Ok(Some(domain))
 }
}
'''
(r/'audio_bound_query.rs').write_text(newmodule)
s=s[:start]+'''    pub(super) fn bound_at(
        &self,node:usize,repeats:&[RepeatInstance],definition:Option<&AudioDefinitionSelector>,
        placement:BoundPlacement<'_>,budget:&mut Budget,
    )->Result<Option<AudioBound<'_>>,PlanError>{
        let mut policy=crate::plan::audio_owners::admission::Unmetered;
        let mut query=crate::plan::audio_owners::admission::Budget::new(budget,&mut policy);
        crate::plan::audio_owners::admission::outer::<_,_>(
            self.bound_at_query(node,repeats,definition,placement,&mut query)
        ).map(|value|value.map(QueryBound::unmetered))
    }
'''+s[end:]
s=s.replace('use crate::{AudioSampleGrid, PlanError};','use crate::{AudioSampleGrid, PlanError};\n\n#[path="audio_bound_query.rs"]\nmod query;\nuse query::QueryBound;')
p.write_text(s)
# Definition constructor shared actual implementation.
p=r/'audio_definition.rs';s=p.read_text()
start=s.index('    pub(super) fn root_domain_on_grid(');bodyStart=s.index('        let support = placement.local_support();',start);end=s.index('\n    pub fn belongs_to(',bodyStart)
oldbody=s[bodyStart:end];oldbody=oldbody[:oldbody.rfind('\n    }')]
body=oldbody.replace('''        Ok(AudioDomain {''','''        let mut memory=budget.memory();
        let definition=budget.definition_ref(&mut memory,Some(&self.selector))?;
        let mut capacity=budget.memory();
        budget.reserve(&mut capacity,crate::audio_allocated::admission::array::<EnvelopeConstraint>(1)?)?;
        let constraints=vec![EnvelopeConstraint {
            placement_support:true,range:extent.clone(),node:self.root,repeat_count:0,gap_after:None,
            kinds:(AudioBoundaryKind::NodeStart,AudioBoundaryKind::NodeEnd)
        }];
        budget.check_memory(&memory)?;budget.check_memory(&capacity)?;
        budget.merge_checked(&mut memory,&mut capacity);
        let gap=budget.gap(&mut memory,&self.gap)?;
        let node=budget.node(&mut memory,self.root())?;
        let value=AudioDomain {''')
body=body.replace('definition: Some(self.selector.clone()),','definition,')
cs=body.index('                constraints: vec![');ce=body.index('                editorial:',cs)
body=body[:cs]+'                constraints,\n'+body[ce:]
body=body.replace('gap: self.gap.clone(),','gap,').replace('node: self.root().clone(),','node,')
body=body.replace('''        })
''','''        };
        Ok(Owned{value,memory})
''')
helper='''//! Actual root-domain constructor reused by admitted owner-envelope conversion.
use super::*;
use crate::plan::audio_owners::admission::{Budget as QueryBudget,Owned,Result};
use crate::AudioSoundContextAdmission;
impl<'plan> AudioDefinition<'plan>{
 pub(in crate::plan) fn root_domain_on_grid_query<A:AudioSoundContextAdmission>(
    &self,placement:AudioRootPlacement,grid_origin:ExactRatio,rule:AudioBoundaryRule,budget:&mut QueryBudget<'_,A>
 )->Result<Owned<AudioDomain<'plan>,A::Issuer,A::Lease>,A>{
'''+body+'''
 }
}
'''
(r/'audio_definition_query.rs').write_text(helper)
s=s[:start]+'''    pub(super) fn root_domain_on_grid(
        &self,placement:AudioRootPlacement,grid_origin:ExactRatio,rule:AudioBoundaryRule,
    )->Result<AudioDomain<'plan>,PlanError>{
        let mut local=super::audio::Budget{remaining:65_536,lookup:super::LookupStats::default()};
        let mut policy=crate::plan::audio_owners::admission::Unmetered;
        let mut budget=crate::plan::audio_owners::admission::Budget::new(&mut local,&mut policy);
        crate::plan::audio_owners::admission::outer::<_,_>(
            self.root_domain_on_grid_query(placement,grid_origin,rule,&mut budget)
        ).map(crate::plan::audio_owners::admission::Owned::unmetered)
    }
'''+s[end:]
s=s.replace('use crate::{AudioBoundaryRule, AudioSampleGrid, PlanError};','use crate::{AudioBoundaryRule, AudioSampleGrid, PlanError};\n\n#[path="audio_definition_query.rs"]\nmod query;')
p.write_text(s)
