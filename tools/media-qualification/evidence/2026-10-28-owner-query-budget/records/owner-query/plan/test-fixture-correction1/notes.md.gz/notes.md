# Owning seeded-Domain fixture correction

Test-only current-live delta. No product guards, capacity policy, query ordering,
allocation or cap change. Initial failed receipt and snapshots remain unchanged.

The standalone Hold fixture produces a captured Domain whose Walk seed has
definition=None, repeats=[], gap=None. State::from_seed copies only those owning
fields. Copying this seed performs no nonzero layout reservation before the
inherited query limits validation, so ample.calls>0 was a false fixture
assumption. It does not show missing allocation admission.

Use the existing validated Repeat constructor (audio_owners/tests.rs) and the
checked Repeat-child input pattern already exercised by
input_tests::repeat_play_gap_and_whole_repeat_have_distinct_contexts. The actual
captured seed contains a nonempty Repeat path, asserted directly before the
test. Its actual array/identity copy requires reservation before the same
later invalid-limits check.

All original meaningful assertions remain: ample resources yield the legacy
InvalidAudioLimits after actual seed allocation; zero-byte allowance refuses
at the earlier real allocation; cancellation propagates; every failed path
releases all charges. No forced allocation or moved semantic guard.

Scratch snapshots/pins/patch only. Scoped rustfmt parsed the file; no Cargo,
rustc, live/scoped/index writes or golden changes.
