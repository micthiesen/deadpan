from pathlib import Path
import hashlib,json,difflib
r=Path('/tmp/deadpan-owner-query-budget-2026-10-28/plan/compiler-correction1')
repo=Path('/Users/michael/Code/deadpan')
paths=['crates/deadpan-plan/src/audio_definition.rs','crates/deadpan-plan/src/audio_bound.rs','crates/deadpan-plan/src/audio_owners.rs']
for name in paths:
 data=(repo/name).read_bytes()
 for folder in ['before','candidate']:
  p=r/folder/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data)
 p=r/'candidate'/name;s=p.read_text()
 if name.endswith('audio_owners.rs'):
  assert s.count('admission::outer::<_, _>')==2
  s=s.replace('admission::outer::<_, _>','admission::outer::<_, admission::Unmetered>')
  assert 'use query_admission::{Output, State, query_tracked, walk_query};' in s
  s=s.replace('use query_admission::{Output, State, query_tracked, walk_query};','use query_admission::{State, query_tracked};\n#[cfg(test)]\nuse query_admission::{Output, walk_query};')
 else:
  assert s.count('admission::outer::<_, _>')==1
  s=s.replace('admission::outer::<_, _>','admission::outer::<_, crate::plan::audio_owners::admission::Unmetered>')
 p.write_text(s)
