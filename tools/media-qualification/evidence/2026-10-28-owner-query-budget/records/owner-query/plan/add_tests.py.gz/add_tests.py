from pathlib import Path
r=Path('/tmp/deadpan-owner-query-budget-2026-10-28/plan');repo=Path('/Users/michael/Code/deadpan')
name='crates/deadpan-plan/src/audio_owners/legacy_snapshot_v1.rs'
for label in ['before','candidate']:
 p=r/label/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes((repo/name).read_bytes())
p=r/'candidate'/name;p.write_text(p.read_text()+'\n#[path = "owner_query_admission_tests.rs"]\nmod admitted;\n')
