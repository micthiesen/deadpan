from pathlib import Path
import hashlib,json
r=Path('/tmp/deadpan-owner-query-budget-2026-10-28/plan');repo=Path('/Users/michael/Code/deadpan')
paths=['crates/deadpan-plan/src/audio_owners.rs','crates/deadpan-plan/src/audio_bound.rs','crates/deadpan-plan/src/audio_definition.rs','crates/deadpan-plan/src/audio_owner_input/candidates.rs']
pins=[]
for name in paths:
 data=(repo/name).read_bytes()
 for where in ['before','candidate']:
  p=r/where/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data)
 pins.append({'path':name,'sha256':hashlib.sha256(data).hexdigest(),'bytes':len(data)})
(r/'before-pins.json').write_text(json.dumps(pins,indent=2)+'\n')
