from pathlib import Path
import difflib,hashlib,json
r=Path('/tmp/deadpan-owner-query-budget-2026-10-28/plan/test-fixture-correction1')
repo=Path('/Users/michael/Code/deadpan')
name=Path('crates/deadpan-plan/src/audio_owners/owner_query_admission_tests.rs')
data=(repo/name).read_bytes()
for folder in ['before','candidate']:
 p=r/folder/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data)
p=r/'candidate'/name;s=p.read_text()
anchor='fn seeded_invalid_limits_keep_semantic_order_but_earlier_admission_can_refuse() {'
start=s.index(anchor);head=s[:start];body=s[start:]
old='    let doc = document(48_000, &["voice"], vec![("voice", hold(4))]);'
assert body.count(old)==1
body=body.replace(old,'''    // The seed must own a real Repeat path. A standalone Hold's seed
    // has no owning metadata allocation before the inherited validation.
    let doc = document(
        48_000,
        &["repeat"],
        vec![("voice", hold(4)), ("repeat", repeat("voice", 2, 1))],
    );''')
old='    let domain = input.context();'
assert body.count(old)==1
body=body.replace(old,'''    let domain = input.context();
    assert!(
        !domain.seed.repeats.is_empty(),
        "checked Repeat-child capture provides a genuinely owning seed path"
    );''')
p.write_text(head+body)
