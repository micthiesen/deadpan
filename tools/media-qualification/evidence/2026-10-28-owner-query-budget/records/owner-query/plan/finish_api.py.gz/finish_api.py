from pathlib import Path
r=Path('/tmp/deadpan-owner-query-budget-2026-10-28/plan');src=r/'candidate/crates/deadpan-plan/src'
# Minimal extra file ownership requested by parent.
name='crates/deadpan-plan/src/audio_owner_input.rs';repo=Path('/Users/michael/Code/deadpan')
for label in ['before','candidate']:
 p=r/label/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes((repo/name).read_bytes())
p=src/'audio_owner_input.rs';s=p.read_text().replace('pub use candidates::{AudioOwnerInputCandidates, AudioOwnerInputCapture};','pub use candidates::{AdmittedAudioOwnerInputCandidates, AudioOwnerInputCandidates, AudioOwnerInputCapture};');p.write_text(s)
p=src/'audio_owner_query_admission.rs';s=p.read_text()
s=s.replace('''        self.additional(1)?;self.reserve(m,identity(id.as_str())?)?;Ok(id.clone())''','''        if !A::METERED{return Ok(id.clone());}
        self.additional(1)?;self.reserve(m,identity(id.as_str())?)?;Ok(id.clone())''')
anchor='''    pub(in crate::plan) fn definition(&mut self'''
pos=s.index(anchor)
s=s[:pos]+'''    pub(in crate::plan) fn own_iteration(&mut self,m:&mut Memory<A::Issuer,A::Lease>,v:&IterationId)->Result<(),A>{
        if !A::METERED{return Ok(());}
        self.additional(1)?;self.reserve(m,identity(v.allocation.as_str())?)
    }
    pub(in crate::plan) fn definition_ref(&mut self,m:&mut Memory<A::Issuer,A::Lease>,v:Option<&AudioDefinitionSelector>)->Result<Option<AudioDefinitionSelector>,A>{
        if !A::METERED{return Ok(v.cloned());}self.additional(1)?;
        v.map(|v|Ok(match v{
          AudioDefinitionSelector::Node{node}=>AudioDefinitionSelector::Node{node:self.node(m,node)?},
          AudioDefinitionSelector::RepeatDefault{repeat}=>AudioDefinitionSelector::RepeatDefault{repeat:self.node(m,repeat)?},
          AudioDefinitionSelector::RepeatGap{repeat}=>AudioDefinitionSelector::RepeatGap{repeat:self.node(m,repeat)?}
        })).transpose()
    }
    pub(in crate::plan) fn gap_ref(&mut self,m:&mut Memory<A::Issuer,A::Lease>,v:Option<&DomainGap>)->Result<Option<DomainGap>,A>{
        if !A::METERED{return Ok(v.cloned());}self.additional(1)?;
        v.map(|v|Ok(DomainGap{after:v.after.as_ref().map(|i|self.iteration(m,i)).transpose()?,duration:v.duration})).transpose()
    }
'''+s[pos:]
p.write_text(s)
p=src/'audio_definition_query.rs';s=p.read_text();assert s.endswith('        })\n }\n}\n');s=s[:-len('        })\n }\n}\n')]+'        };\n        Ok(Owned{value,memory})\n }\n}\n';p.write_text(s)
p=src/'audio_owner_query.rs';s=p.read_text().replace('fn walk_query<A:', 'pub(super) fn walk_query<A:')
s=s.replace('state.extent', 'state.value.extent').replace('state.support','state.value.support')
# Avoid overlapping borrows of a Vec and its len during growth.
s=s.replace('budget.grow(&mut output.value.owners,&mut output.capacity,output.value.owners.len()+1)?;','let needed=output.value.owners.len()+1;\n        budget.grow(&mut output.value.owners,&mut output.capacity,needed)?;')
# Shared function's direct Err conversion.
s=s.replace('return Err(PlanError::AudioQueryLimit("owner binding depth"));','return Err(PlanError::AudioQueryLimit("owner binding depth").into());')
# Actual public entrypoint initial seed timing remains inherited.
s+='''

pub(in crate::plan) fn root_candidates_query<'plan,A:AudioSoundContextAdmission>(
 plan:&'plan RenderPlan,at:AudioSample,limits:AudioQueryLimits,admission:&mut A
)->std::result::Result<Product<'plan,AudioSample,A::Issuer,A::Lease>,A::Error>{
 admission::outer::<_,A>((||{
   let end=AudioSample(at.0.checked_add(1).ok_or(TimeError::Overflow)?);
   if at.0<0||end>plan.audio_duration()?{return Err(PlanError::AudioRangeOutOfRange.into());}
   let mut local=super::Budget{remaining:limits.maximum_work,lookup:LookupStats::default()};
   let mut budget=admission::Budget::new(&mut local,admission);
   let mut seed=State::plain(Walk::root(plan)?,budget.issuer);
   seed.value.allow_inactive=true;
   query_tracked(plan,at.0..end.0,limits,seed,AudioSample,None,&mut budget)
 })())
}
pub(in crate::plan) fn domain_candidates_query<'plan,A:AudioSoundContextAdmission>(
 domain:&AudioDomain<'plan>,at:AudioSample,limits:AudioQueryLimits,admission:&mut A
)->std::result::Result<Product<'plan,AudioSample,A::Issuer,A::Lease>,A::Error>{
 admission::outer::<_,A>((||{
   let end=AudioSample(at.0.checked_add(1).ok_or(TimeError::Overflow)?);
   if at<domain.samples.start||end>domain.samples.end{return Err(PlanError::AudioRangeOutOfRange.into());}
   let mut local=super::Budget{remaining:limits.maximum_work,lookup:LookupStats::default()};
   let mut budget=admission::Budget::new(&mut local,admission);
   // Same seed copy BEFORE the inherited query limits validation.
   let mut seed=State::from_seed(&domain.seed,&mut budget)?;
   seed.value.allow_inactive=true;
   query_tracked(domain.plan,at.0..end.0,limits,seed,AudioSample,None,&mut budget)
 })())
}
'''
p.write_text(s)
# Make only exact root/domain query entrypoints visible to the sealed parent.
p=src/'audio_owners.rs';s=p.read_text().replace('mod query_admission;','pub(super) mod query_admission;');p.write_text(s)
p=src/'audio_bound_query.rs';s=p.read_text().replace('budget.grow(&mut excluded,&mut capacity,excluded.len()+1)?;','let needed=excluded.len()+1;\n       budget.grow(&mut excluded,&mut capacity,needed)?;')
# Borrow budget.remaining before its mutable admission adapter.
s=s.replace('''            let mut adapter=CoreAdmission {outer:budget.admission};
            Resolved::Metered''','''            let remaining=budget.remaining;
            let mut adapter=CoreAdmission {outer:budget.admission};
            Resolved::Metered''').replace('id,environment,budget.remaining,&mut adapter','id,environment,remaining,&mut adapter')
p.write_text(s)
p=src/'audio_owner_input/candidates.rs';s=p.read_text();s+='''
// Query-only guard. Actual parent/query value drops before its independent lease.
pub struct AdmittedAudioOwnerInputCandidates<'context,'plan,I,L>{
    value:Option<AudioOwnerInputCandidates<'context,'plan>>,
    canonical:usize,
    additional:usize,
    forwarded:bool,
    memory:crate::plan::audio_owners::admission::Memory<I,L>,
}
impl<'context,'plan,I:Copy+Eq,L> AdmittedAudioOwnerInputCandidates<'context,'plan,I,L>{
    pub fn query(&self)->&AudioOwnerQuery<'plan>{self.value.as_ref().expect("unconsumed query").query()}
    pub fn work(&self)->usize{self.query().work()}
    pub fn canonical_units(&self)->usize{self.canonical}
    pub fn additional_units(&self)->usize{self.additional}
    pub fn was_forwarded(&self)->bool{self.forwarded}
    fn validate<A:crate::AudioSoundContextAdmission<Issuer=I,Lease=L>>(&self,admission:&A)->Result<(),A::Error>{
        if self.memory.issuer!=admission.issuer(){return Err(PlanError::AudioMetadataIssuerMismatch.into());}
        if self.forwarded!=A::METERED{return Err(PlanError::InvalidPlan("candidate accounting mode mismatch").into());}
        Ok(())
    }
    pub fn capture<A:crate::AudioSoundContextAdmission<Issuer=I,Lease=L>>(
        mut self,member:usize,limits:AudioQueryLimits,admission:&mut A
    )->Result<AudioOwnerInputCapture<'plan>,A::Error>{
        self.validate(admission)?;
        // Keep self.memory live throughout the SAME actual legacy call.
        // Its query is consumed/dropped inside capture before lease release.
        self.value.take().expect("unconsumed query").capture(member,limits).map_err(A::Error::from)
    }
    pub fn without_selection<A:crate::AudioSoundContextAdmission<Issuer=I,Lease=L>>(
        mut self,admission:&mut A
    )->Result<AudioOwnerInputCapture<'plan>,A::Error>{
        self.validate(admission)?;
        Ok(self.value.take().expect("unconsumed query").without_selection())
    }
}
impl RenderPlan{
    pub fn audio_owner_input_candidates_at_admitted<A:crate::AudioSoundContextAdmission>(
        &self,at:AudioSample,limits:AudioQueryLimits,admission:&mut A
    )->Result<AdmittedAudioOwnerInputCandidates<'_,'_,A::Issuer,A::Lease>,A::Error>{
        let product=crate::plan::audio_owners::query_admission::root_candidates_query(self,at,limits,admission)?;
        let value=AudioOwnerInputCandidates::checked(Parent::Root(self),at,product.query.value,limits)?;
        if product.query.memory.issuer!=admission.issuer(){return Err(PlanError::AudioMetadataIssuerMismatch.into());}
        Ok(AdmittedAudioOwnerInputCandidates{value:Some(value),canonical:product.canonical,
            additional:product.additional,forwarded:A::METERED,memory:product.query.memory})
    }
}
impl<'plan> AudioDomain<'plan>{
    pub fn owner_input_candidates_at_admitted<A:crate::AudioSoundContextAdmission>(
        &self,at:AudioSample,limits:AudioQueryLimits,admission:&mut A
    )->Result<AdmittedAudioOwnerInputCandidates<'_,'plan,A::Issuer,A::Lease>,A::Error>{
        let product=crate::plan::audio_owners::query_admission::domain_candidates_query(self,at,limits,admission)?;
        let value=AudioOwnerInputCandidates::checked(Parent::Domain(self),at,product.query.value,limits)?;
        if product.query.memory.issuer!=admission.issuer(){return Err(PlanError::AudioMetadataIssuerMismatch.into());}
        Ok(AdmittedAudioOwnerInputCandidates{value:Some(value),canonical:product.canonical,
            additional:product.additional,forwarded:A::METERED,memory:product.query.memory})
    }
}
'''
p.write_text(s)
