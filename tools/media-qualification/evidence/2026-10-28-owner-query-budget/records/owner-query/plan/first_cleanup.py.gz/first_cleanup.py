from pathlib import Path
sroot=Path('/tmp/deadpan-owner-query-budget-2026-10-28/plan/candidate/crates/deadpan-plan/src')
p=sroot/'audio_owner_query_admission.rs';s=p.read_text().replace('pub(in crate::plan) enum Error<E>', '#[derive(Debug)]\npub(in crate::plan) enum Error<E>')
# Canonical false does not execute physical metadata layout instrumentation.
for marker in ['node','revision','iteration','definition_ref','gap_ref','definition','gap','repeat','repeats','instance','origin','constraint']:
 start=s.index(' fn '+marker+'(') if ' fn '+marker+'(' in s else -1
 if start<0:continue
 brace=s.index('{',start)
 s=s[:brace+1]+'\n        self.check_memory(m)?;'+s[brace+1:]
p.write_text(s)
p=sroot/'audio_bound_query.rs';s=p.read_text()
s=s.replace('memory: Memory<I, L>,','_memory: Memory<I, L>,')
s=s.replace('Ok(Some(QueryBound { value, memory }))','Ok(Some(QueryBound { value, _memory:memory }))')
# No layout probe under the false compatibility policy.
s=s.replace('''        budget.reserve(
            &mut constraint_capacity,
            array::<EnvelopeConstraint>(constraints.len())?,
        )?;''','''        if A::METERED {
            budget.reserve(&mut constraint_capacity,array::<EnvelopeConstraint>(constraints.len())?)?;
        }''')
# The original setter remains exact on unmetered C/probe calls.
needle='''        // Construction peak stays charged during this temporary Domain's use.'''
s=s.replace(needle,'''        if !A::METERED {
            self.set_domain_evaluation(&mut domain.value);
            return Ok(Some(domain));
        }
'''+needle)
p.write_text(s)
p=sroot/'audio_definition_query.rs';s=p.read_text()
s=s.replace('''        budget.reserve(
            &mut capacity,
            crate::audio_allocated::admission::array::<EnvelopeConstraint>(1)?,
        )?;''','''        if A::METERED {
            budget.reserve(&mut capacity,crate::audio_allocated::admission::array::<EnvelopeConstraint>(1)?)?;
        }''')
p.write_text(s)
p=sroot/'audio_owner_query.rs';s=p.read_text()
s=s.replace('''        budget.reserve(
            &mut owners_capacity,
            array::<AudioOwnerClock<'plan, S>>(output.owners.len())?,
        )?;''','''        if A::METERED {
            budget.reserve(&mut owners_capacity,array::<AudioOwnerClock<'plan,S>>(output.owners.len())?)?;
        }''')
# pub(super) protects real Plan entrypoints, while parent test wrapper needs access.
s=s.replace('fn walk_query<A:', 'pub(super) fn walk_query<A:').replace('pub(super) pub(super)','pub(super)')
p.write_text(s)
p=sroot/'audio_owner_input/candidates.rs';s=p.read_text()
old='''        self.value
            .take()
            .expect("unconsumed query")
            .capture(member, limits)
            .map_err(A::Error::from)'''
new='''        let result=self.value.take().expect("unconsumed query").capture(member,limits).map_err(A::Error::from)?;
        self.validate(admission)?;
        Ok(result)'''
assert old in s;s=s.replace(old,new)
old='''        Ok(self
            .value
            .take()
            .expect("unconsumed query")
            .without_selection())'''
new='''        let result=self.value.take().expect("unconsumed query").without_selection();
        self.validate(admission)?;
        Ok(result)'''
assert old in s;s=s.replace(old,new)
p.write_text(s)
