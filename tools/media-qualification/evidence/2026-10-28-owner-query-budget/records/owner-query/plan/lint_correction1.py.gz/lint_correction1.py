from pathlib import Path
r=Path('/tmp/deadpan-owner-query-budget-2026-10-28/plan/lint-correction1');repo=Path('/Users/michael/Code/deadpan')
names=['crates/deadpan-plan/src/audio_bound_query.rs','crates/deadpan-plan/src/audio_owners.rs']
for name in names:
 data=(repo/name).read_bytes()
 for folder in ['before','candidate']:
  p=r/folder/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data)
 p=r/'candidate'/name;s=p.read_text()
 if name.endswith('audio_bound_query.rs'):
  anchor='use deadpan_core::{AdmittedAudioBinding, AudioBindingValue};'
  assert s.count(anchor)==1
  s=s.replace(anchor,anchor+'''

type BoundResult<'plan,A> = Result<
    Option<QueryBound<'plan,<A as AudioSoundContextAdmission>::Issuer,<A as AudioSoundContextAdmission>::Lease>>,
    A,
>;
type EnvelopeResult<'plan,A> = Result<
    Option<Owned<AudioDomain<'plan>,<A as AudioSoundContextAdmission>::Issuer,<A as AudioSoundContextAdmission>::Lease>>,
    A,
>;
''')
  old=") -> Result<Option<QueryBound<'_, A::Issuer, A::Lease>>, A> {"
  assert s.count(old)==1;s=s.replace(old,") -> BoundResult<'_,A> {")
  old=") -> Result<Option<Owned<AudioDomain<'plan>, A::Issuer, A::Lease>>, A> {"
  assert s.count(old)==1;s=s.replace(old,") -> EnvelopeResult<'plan,A> {")
 else:
  old='let seed = State::plain(seed, budget.issuer);'
  assert s.count(old)==1;s=s.replace(old,'let seed = State::plain(seed, ());')
 p.write_text(s)
