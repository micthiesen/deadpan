from pathlib import Path
import json,sys,subprocess,hashlib,re
s=Path(__file__).resolve().parent
label=sys.argv[1]
pins=[p for p in json.loads((s/(label+'-pins.json')).read_text()) if p['package']=='core']
assert pins
out=s/'core-results'/label
out.mkdir(parents=True,exist_ok=False)
rows=[]
for p in pins:
 path=Path(p['path'])
 assert hashlib.sha256(path.read_bytes()).hexdigest()==p['sha256']
 command=[str(path),'--test-threads=4']
 r=subprocess.run(command,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
 (out/(p['name']+'.stdout')).write_bytes(r.stdout)
 (out/(p['name']+'.stderr')).write_bytes(r.stderr)
 matches=re.findall(r'test result: ([^.]+)\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out',r.stdout.decode())
 row={'target':p['name'],'command':command,'exit_code':r.returncode,'test_results':matches,'binary_sha256':p['sha256']}
 rows.append(row)
 (out/'results.json').write_text(json.dumps(rows,indent=2)+'\n')
 print(json.dumps(row),flush=True)
assert all(hashlib.sha256(Path(p['path']).read_bytes()).hexdigest()==p['sha256'] for p in pins)
raise SystemExit(0 if all(r['exit_code']==0 for r in rows) else 1)
