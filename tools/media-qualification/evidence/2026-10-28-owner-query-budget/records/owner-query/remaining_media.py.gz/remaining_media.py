from pathlib import Path
import json,subprocess
s=Path(__file__).resolve().parent
steps=[
 ('main','query-split','query-final-build-audio-stages',['general_split_sound','--test-threads=1','--nocapture'],101),
 ('main','query-definition','query-final-build-audio-audio-definition',['--test-threads=4'],0),
 ('scoped','query-scoped-stages','query-scoped-final-build-audio-stages',['--test-threads=4'],0),
 ('scoped','query-scoped-birth','query-scoped-final-build-audio-audio-definition',['new_group_birth::','--test-threads=1','--nocapture'],0),
]
rows=[]
for kind,label,binary,args,expected in steps:
 runner=s/('run.py' if kind=='main' else 'run_scoped.py')
 exe=s/binary
 assert exe.exists()
 command=['python',str(runner),'--binary',str(exe),'--binary',str(Path(__file__).resolve()),label,'--',str(exe),*args]
 code=subprocess.run(command).returncode
 r=json.loads((s/(label+'.json')).read_text())
 assert r['exit_code']==code and r['sources_unchanged'] and r['binaries_unchanged']
 rows.append({'label':label,'exit_code':code,'expected_exit':expected})
 print(json.dumps(rows[-1]),flush=True)
 (s/'media-sequence.json').write_text(json.dumps({'all_terminal':len(rows)==len(steps),'results':rows},indent=2)+'\n')
raise SystemExit(0 if all(r['exit_code']==r['expected_exit'] for r in rows) else 1)
