# Retained correction/application outcomes

The initial whole-file equality preflight refused Core correction2 because the
isolated audio_reference.rs intentionally omits inherited main WIP. No source was
changed by that preflight. An unchanged query-build2 then ran and failed with the
same Plan type inference errors; retain its receipt, not as positive evidence.
The corrected application used exact patch contexts in both variants and
reconstructed the deleted wrapper to verify the original file hashes.

The first Plan runtime failure was a false fixture assumption: a standalone
Hold's captured seed owned no metadata needing a pre-validation reservation.
The corrected test uses a real captured Repeat path and asserts it is nonempty;
it neither forces allocation nor moves semantic validation. Both initial failures
and final passing runs remain in this inventory.

Strict1 rejected six Core style issues. Strict2 rejected three Plan style issues.
Private type aliases and a private projection request struct retain the same
underlying values and operation order; saturating multiplication equals the old
checked-multiply-or-MAX expression. The known Unmetered wrapper passes literal
unit. No allows, new boxing, caps, weights, refunds or caches were introduced.
