# Compiler correction1

One-file private bridge, against current live applied Core bytes. The original
core.patch/after-pins and first-build evidence are unchanged.

The old private resolve_with(&mut Work) now delegates to resolve_with_build
using Build::new on the SAME caller Work. It creates only zero additional
instrumentation counters and the unmetered policy. It neither initializes a
new Work nor resets used/maximum. The already admitted resolver calls the
generic body directly. Both routes use the same validation/resolution body.

Public admitted signatures and policy/value/receipt interfaces are unchanged.
repeat_rates.rs needs no edit: its accumulated Work and DocumentError result
are restored. Parent should rerun Core build and existing repeat-rates tests.
No build or tests were run here.
