# Compiler correction2

The exact wrapper name occurs ONLY at its declaration across all crates'
Rust source. There is no remaining test seam to preserve. Adding cfg(test)
would retain a dead wrapper in test builds, so remove only this private,
unused8-line forwarding wrapper. Public project_scoped_with_support stays
unchanged, as do the shared actual kernel and all constructors/work.

One-file scratch patch against current live post-correction1 bytes. Existing
core.patch/correction1 and evidence remain immutable. No build/test claims.
