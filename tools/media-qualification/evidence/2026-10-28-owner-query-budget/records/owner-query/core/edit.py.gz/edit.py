from pathlib import Path
base=Path('/tmp/deadpan-owner-query-budget-2026-10-28/core/candidate/crates/deadpan-core/src')
def section(text,start):
 a=text.index(start);b=text.index('{',a);depth=1;c=b+1
 while depth:
  if text[c]=='{':depth+=1
  elif text[c]=='}':depth-=1
  c+=1
 return a,c,text[a:c]
def errs(s):
 # Exact semantic Err operands in these narrow methods.
 import re
 s=re.sub(r'Err\((invalid|limit)\((.*?)\)\)',r'Err(\1(\2).into())',s,flags=re.S)
 return s
p=base/'audio_reference.rs';text=p.read_text()
text=text.replace('use std::sync::Arc;','use std::sync::Arc;\nuse crate::audio_binding::admission::{AudioBindingAdmission, AudioBindingValue, Build, BuildResult, Unmetered, legacy, Growing};\nuse crate::audio_binding::Work;')
a,c,old=section(text,'    fn project_scoped_inner(')
new=old.replace('fn project_scoped_inner(','pub(crate) fn project_scoped_inner_admitted<P: AudioBindingAdmission>(')
new=new.replace('        mode: ProjectionMode,\n','        mode: ProjectionMode,\n        admission: &mut P,\n')
new=new.replace('Result<(FrozenAudioProjection, std::ops::Range<ExactRatio>), DocumentError>','BuildResult<AudioBindingValue<(FrozenAudioProjection, std::ops::Range<ExactRatio>),P::Issuer,P::Lease>,P::Error>')
new=new.replace('        let mut work = 0usize;','        let mut raw = Work { used: 0, maximum: maximum_work };\n        let mut extra = 0;\n        let mut work = Build::new(&mut raw, &mut extra, admission);')
new=new.replace('spend(&mut work, layout.segment_count(), maximum_work)?','work.spend(layout.segment_count())?').replace('spend(&mut work, 1, maximum_work)?','work.spend(1)?')
new=new.replace('        Ok((\n            FrozenAudioProjection {','        let result = (\n            FrozenAudioProjection {')
new=new.replace('instance: instance.clone(),','instance: work.instance(instance)?,').replace('gap_after: gap_after.cloned(),','gap_after: gap_after.map(|v|work.iteration(v)).transpose()?,')
new=new.replace('                work,\n','                work: work.used(),\n')
assert new.endswith('        ))\n    }');new=new[:-len('        ))\n    }')]+'        );\n        Ok(work.finish(result))\n    }'
new=errs(new)
wrapper=old[:old.index('{')+1]+'''
        let value = legacy(self.project_scoped_inner_admitted(root,instance,local,gap_after,maximum_work,mode,&mut Unmetered))?;
        Ok(value.into_legacy())
    }'''
text=text[:a]+wrapper+'\n\n'+new+text[c:]
a,c,old=section(text,'    pub(crate) fn scoped_repeats(')
new=old.replace('fn scoped_repeats(','fn scoped_repeats_admitted<P:AudioBindingAdmission>(')
new=new.replace('        maximum_work: usize,\n','        maximum_work: usize,\n        admission: &mut P,\n')
new=new.replace('Result<(Vec<NodeId>, usize), DocumentError>','BuildResult<AudioBindingValue<Vec<NodeId>,P::Issuer,P::Lease>,P::Error>')
new=new.replace('        let mut repeats = Vec::new();\n        let mut work = 0;','        let mut raw=Work{used:0,maximum:maximum_work};\n        let mut extra=0;\n        let mut work=Build::new(&mut raw,&mut extra,admission);\n        let mut repeats=Growing::new();')
new=new.replace('spend(&mut work, 1, maximum_work)?','work.spend(1)?')
new=new.replace('repeats.push(parent.clone());','let value=work.node(parent)?;\n                repeats.push(value,&mut work)?;')
new=new.replace('        repeats.reverse();\n        Ok((repeats, work))','        repeats.values.reverse();\n        let values=repeats.finish(&mut work)?;\n        Ok(work.finish(values))')
new=errs(new)
wrapper=old[:old.index('{')+1]+'''
        let mut value=legacy(self.scoped_repeats_admitted(root,target,maximum_work,&mut Unmetered))?;
        let work=legacy(value.take_work(&Unmetered))?.units();
        Ok((value.into_legacy(),work))
    }'''
text=text[:a]+wrapper+'\n\n'+new+text[c:]
# branch_below contains only owning NodeId output and no buffer.
a,c,old=section(text,'    pub(crate) fn branch_below(')
new=old.replace('fn branch_below(','fn branch_below_admitted<P:AudioBindingAdmission>(').replace('        maximum_work: usize,\n','        maximum_work: usize,\n        admission: &mut P,\n')
new=new.replace('Result<(NodeId, usize), DocumentError>','BuildResult<AudioBindingValue<NodeId,P::Issuer,P::Lease>,P::Error>')
new=new.replace('        let mut work = 0;','        let mut raw=Work{used:0,maximum:maximum_work};\n        let mut extra=0;\n        let mut work=Build::new(&mut raw,&mut extra,admission);')
new=new.replace('spend(&mut work, 1, maximum_work)?','work.spend(1)?')
new=new.replace('return Ok((node.clone(), work));','let node=work.node(node)?;\n                return Ok(work.finish(node));')
new=errs(new)
wrapper=old[:old.index('{')+1]+'''
        let mut value=legacy(self.branch_below_admitted(ancestor,target,maximum_work,&mut Unmetered))?;
        let work=legacy(value.take_work(&Unmetered))?.units();
        Ok((value.into_legacy(),work))
    }'''
text=text[:a]+wrapper+'\n\n'+new+text[c:]
text=text.replace('enum ProjectionMode {','pub(crate) enum ProjectionMode {')
p.write_text(text)
