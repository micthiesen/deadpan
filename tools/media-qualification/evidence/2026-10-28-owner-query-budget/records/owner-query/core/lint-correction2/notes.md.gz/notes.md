# Core lint correction2

Three files against current live AFTER lint1, which is retained unchanged.
Private AdmittedResult/ProjectedSupport/ProjectedAllocation type aliases remove
all4 reported complex return types. Private ScopedProjectionRequest groups
the existing root/instance/local/gap/maximum/mode arguments; all3 actual call
sites construct the same fields, destructured at the actual kernel entry.
No allocation, semantic validation, budget or arithmetic order changes.

No Core tests call the crate-private project_scoped_inner_admitted directly:
the exact symbol occurs only in the declaration and3 updated call sites.
Existing public projection wrappers and admitted binding public APIs stay the
same. The private branch result also uses the alias consistently.

Manual saturation was already fixed by parent-applied lint1; this delta does
not revert/combine that frozen patch. No broad formatter/build/test was run.
