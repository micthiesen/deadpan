# Independent Core admission review

Reviewed frozen candidate patch SHA `3c2d5b0ad8b5bcf3515a264a42c0904a3d0a1474fd6da09da88f2567e0eac0e5`, four scoped Core files, against the supplied before snapshots and `notes.md`. No Cargo/rustc/Git or live-source writes.

## Findings

No supported correctness finding in the reviewed Core candidate.

The legacy `METERED = false` path retains the `BTreeSet` implementation, original canonical-work calls, and no host admission calls. In metered mode the three replaced sets keep sorted order, admit their maximum input-derived capacity on first insertion, meter binary comparisons and shifts, and preserve the existing outside-depth guard before extending capacity. The admitted path does not introduce BTree estimates.

Child projection/scope/branch calls use their own bounded `Work`, return a typed, issuer-bound linear receipt, and the parent accounts that receipt locally once. The parent and child share the admission controller, so child `additional` visits are controller-debited there and are not forwarded again. Local scratch `fork()` calls share the parent work ledger and are not passed through `account_child`; their receipt is disabled. This distinction is important and appears consistent at the inspected call sites.

The temporary set/vector growth path reserves the replacement layout while the old buffer and lease remain live, moves contents, drops the old allocation, and only then drops the old lease. Final value fields precede lease fields in `AudioBindingValue`, giving the asserted value-before-release order. Scoped Repeat IDs are moved into the final result, and the separately tracked vector buffer lease follows that allocation's lifetime. The actual admission tests include exact/one-short peak, injected failures at each reached reservation, sequential temporary peaks, issuer/work failures, legacy mode, value parity, and value-before-lease drop checks.

## Limits / verification still owed

This is a source review, not a build or runtime result. At the time of review, the seven new Core tests and compiler/clippy checks were not reported complete; the parent owns those checks. The tests exercise a real captured-Hold/Repeat binding fixture and complement the frozen external Plan oracle, but they do not independently cover every recipe/alias/error branch. No conclusion here covers Plan integration, full retained-query behavior, recursive allocation proof, cold batching, or any larger resource-admission claim.
