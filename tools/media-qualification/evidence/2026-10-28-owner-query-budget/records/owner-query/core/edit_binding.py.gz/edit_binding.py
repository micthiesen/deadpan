exec((__import__('pathlib').Path('/tmp/deadpan-owner-query-budget-2026-10-28/core/edit.py')).read_text().split("p=base/'audio_reference.rs'")[0])
p=base/'audio_binding.rs';text=p.read_text()
text=text.replace('mod repeat_rates;','pub(crate) mod admission;\npub use admission::{AudioBindingAdmission, AudioBindingBuildError, AudioBindingForwardedWork, AudioBindingValue, AdmittedAudioBinding};\nuse admission::{Build, BuildResult, ScratchSet, Unmetered, legacy};\nmod repeat_rates;')
text=text.replace('struct Work {\n    used: usize,\n    maximum: usize,','pub(crate) struct Work {\n    pub(crate) used: usize,\n    pub(crate) maximum: usize,')
a,c,old=section(text,'    fn validate(&self) -> Result<(), DocumentError> {')
new=old.replace('fn validate(&self) -> Result<(), DocumentError>',"fn validate_build<P:AudioBindingAdmission>(&self,work:&mut Build<'_,P>) -> BuildResult<(),P::Error>")
new=new.replace('let mut seen = BTreeSet::new();','let mut seen = ScratchSet::new(work,self.instance().repeats.len());')
new=new.replace('!seen.insert(&repeat.node)','!seen.insert(&repeat.node,work)?').replace('!seen.insert(repeat)','!seen.insert(repeat,work)?')
new=new.replace('            for repeat in *outside_repeats {','            seen.extend_capacity(self.instance().repeats.len()+outside_repeats.len());\n            for repeat in *outside_repeats {')
new=errs(new)
wrapper='''    fn validate(&self) -> Result<(), DocumentError> {
        let mut raw=Work{used:0,maximum:MAX_DOCUMENT_NODES};let mut extra=0;
        legacy(self.validate_build(&mut Build::new(&mut raw,&mut extra,&mut Unmetered)))
    }'''
text=text[:a]+wrapper+'\n'+new+text[c:]
a,c,old=section(text,'    fn project(')
new='''    fn project<P:AudioBindingAdmission>(
        &self, layout:&FrozenAudioLayout, instance:&InstancePath,
        gap_after:Option<&IterationId>, allocation:bool, work:&mut Build<'_,P>,
    )->BuildResult<AudioBindingValue<(crate::FrozenAudioProjection,Option<std::ops::Range<ExactRatio>>),P::Issuer,P::Lease>,P::Error>{
        if let AudioDefinitionScope::RepeatGap(repeat)=self.root {
            if repeat!=&instance.node || !instance.repeats.is_empty() || gap_after.is_some(){
                return Err(invalid("gap definition has occurrence arguments").into());
            }
            let mut storage=work.fork();storage.spend(1)?;
            let duration=gap_duration(layout,repeat)?;
            let result=(crate::FrozenAudioProjection{
                origin:ExactRatio::ZERO,frames_per_local_frame:ExactRatio::ONE,point:ExactRatio::ZERO,
                local_duration:duration,local_extent:ExactRatio::integer(duration.frames()),
                instance:storage.instance(instance)?,gap_after:None,work:0,
            },Some(ExactRatio::ZERO..ExactRatio::integer(duration.frames())));
            return Ok(storage.finish(result));
        }
        let mode=if allocation{crate::audio_reference::ProjectionMode::VisibleAllocation}else{crate::audio_reference::ProjectionMode::MeaningfulSupport};
        let maximum=work.remaining()?;
        let mut value=layout.project_scoped_inner_admitted(self.root.node(),instance,ExactRatio::ZERO,gap_after,maximum,mode,work.policy())?;
        let receipt=value.take_work(work.policy())?;work.account_child(receipt)?;
        value.map_value(work.policy(),|(projection,support)|{
            let support=if allocation{(support.start!=support.end).then_some(support)}else{Some(support)};
            (projection,support)
        })
    }'''
text=text[:a]+new+text[c:]
a,c,old=section(text,'    fn validate_with(')
new=old.replace('fn validate_with(','fn validate_build<P:AudioBindingAdmission>(').replace('work: &mut Work',"work: &mut Build<'_,P>").replace('Result<(), DocumentError>','BuildResult<(),P::Error>')
new=new.replace('let mut live = BTreeSet::new();','let mut live = ScratchSet::new(work,self.arguments.len());').replace('let mut clauses = BTreeSet::new();','let mut clauses = ScratchSet::new(work,self.births.len());')
new=new.replace('!live.insert(repeat)','!live.insert(repeat,work)?').replace('!clauses.insert(&clause.repeat)','!clauses.insert(&clause.repeat,work)?')
new=new.replace('live.contains(&clause.repeat)','live.contains(&clause.repeat,work)?').replace('for repeat in live {','for repeat in live.values() {').replace('!clauses.contains(repeat)','!clauses.contains(repeat,work)?')
new=new.replace('let (expected, used) = layout.scoped_repeats(','let mut expected = layout.scoped_repeats_admitted(')
new=new.replace('let (_, used) =\n                layout.scoped_repeats(','let mut checked =\n                layout.scoped_repeats_admitted(').replace('let (_, used) = layout.scoped_repeats(','let mut checked = layout.scoped_repeats_admitted(')
import re
new=re.sub(r'(layout\.scoped_repeats_admitted\(.*?work\.remaining\(\)\?,)(\s*\)\?;)',r'\1\n            work.policy(),\2',new,flags=re.S)
new=new.replace('work.spend(used)?;','let receipt=expected.take_work(work.policy())?;work.account_child(receipt)?;',1)
new=new.replace('work.spend(used)?;','let receipt=checked.take_work(work.policy())?;work.account_child(receipt)?;',2)
new=new.replace('if !expected.iter().eq(','if !expected.value().iter().eq(')
new=new.replace('let (child, used) = layout.branch_below(','let mut child = layout.branch_below_admitted(')
new=re.sub(r'(layout\.branch_below_admitted\(.*?work\.remaining\(\)\?,)(\s*\)\?;)',r'\1\n                    work.policy(),\2',new,flags=re.S)
new=new.replace('work.spend(used)?;','let receipt=child.take_work(work.policy())?;work.account_child(receipt)?;')
new=new.replace('node: child,','node: work.node(child.value())?,')
new=new.replace('let projected = layout.project_scoped(','let mut projected = project_affine_build(layout,')
new=new.replace('work.spend(projected.work)?;','let receipt=projected.take_work(work.policy())?;work.account_child(receipt)?;')
new=re.sub(r'(project_affine_build\(.*?work\.remaining\(\)\?,)(\s*\)\?;)',r'\1\n                        work,\2',new,flags=re.S)
new=errs(new)
wrapper='''    fn validate_with(&self,layout:&FrozenAudioLayout,work:&mut Work)->Result<(),DocumentError>{
        let mut extra=0;legacy(self.validate_build(layout,&mut Build::new(work,&mut extra,&mut Unmetered)))
    }'''
text=text[:a]+wrapper+'\n'+new+text[c:]
a,c,old=section(text,'    fn resolve_with(')
new=old.replace('fn resolve_with(','fn resolve_with<P:AudioBindingAdmission>(').replace('work: &mut Work',"work: &mut Build<'_,P>").replace('Result<ResolvedAudioPlacement, DocumentError>','BuildResult<ResolvedAudioPlacement,P::Error>')
new=new.replace('let before = work.used;','let before = work.used();').replace('self.validate_with(layout, work)?;','self.validate_build(layout, work)?;')
new=new.replace('Some(iteration.clone())','Some(work.iteration(iteration)?)').replace('survives.then(|| iteration.clone())','if survives {Some(work.iteration(iteration)?)} else {None}')
new=new.replace('repeat: self.reference.physical.clone(),','repeat: work.node(&self.reference.physical)?,')
oldclock='''birth.map_or_else(
                || self.reference.root.clone(),
                |index| AudioClockRoot::DefinitionPointCeil {
                    root: self.births[index].definition_root.clone(),
                },
            )'''
newclock='''match birth {
                None=>work.clock(&self.reference.root)?,
                Some(index)=>AudioClockRoot::DefinitionPointCeil{root:work.node(&self.births[index].definition_root)?},
            }'''
assert oldclock in new;new=new.replace(oldclock,newclock)
new=new.replace('let (required, used) = layout.scoped_repeats(','let mut required = layout.scoped_repeats_admitted(')
new=re.sub(r'(layout\.scoped_repeats_admitted\(.*?work\.remaining\(\)\?,)(\s*\)\?;)',r'\1\n            work.policy(),\2',new,flags=re.S)
new=new.replace('work.spend(used)?;','let receipt=required.take_work(work.policy())?; work.account_child(receipt)?;')
new=new.replace('let mut repeats = Vec::with_capacity(required.len());','work.array::<RepeatInstance>(required.value().len())?;\n        let mut repeats = Vec::with_capacity(required.value().len());')
new=new.replace('for reference_repeat in required {','for reference_repeat in required.value() {').replace('argument.reference_repeat == reference_repeat','&argument.reference_repeat == reference_repeat')
new=new.replace('node: reference_repeat,','node: work.node(reference_repeat)?,').replace('iteration: iteration.clone(),','iteration: work.iteration(iteration)?,')
new=new.replace('node: self.reference.physical.clone(),','node: work.node(&self.reference.physical)?,')
new=new.replace('''let (projection, local_support) =
            scope.project(layout, &instance, gap_after.as_ref(), false, work)?;''','''let projected = scope.project(layout, &instance, gap_after.as_ref(), false, work)?;
        let (projection,local_support)=projected.value();''')
new=new.replace('let mut local_support = local_support.expect(','let mut local_support = local_support.clone().expect(').replace('work: work.used - before,','work: work.used() - before,')
new=errs(new);text=text[:a]+new+text[c:]
a,c,old=section(text,'    fn allocation_entry(')
new=old.replace('fn allocation_entry(','fn allocation_entry<P:AudioBindingAdmission>(').replace('work: &mut Work',"work: &mut Build<'_,P>").replace('Result<Option<ExactRatio>, DocumentError>','BuildResult<Option<ExactRatio>,P::Error>')
new=new.replace('let (projection, mut allocation) = scope.project(','let projected = scope.project(').replace('        let captured = clock_scope','        let (projection,allocation)=projected.value();\n        let mut allocation=allocation.clone();\n        let captured = clock_scope')
new=new.replace('            .transpose()','            .transpose().map_err(Into::into)')
new=errs(new);text=text[:a]+new+text[c:]
a,c,old=section(text,'    fn resolve_binding(')
new=old.replace('fn resolve_binding(','fn resolve_binding_build<P:AudioBindingAdmission>(').replace('maximum_work: usize,',"work: &mut Build<'_,P>,").replace('Result<ResolvedAudioBinding, DocumentError>','BuildResult<ResolvedAudioBinding,P::Error>')
new=new.replace('        let mut work = Work::new(maximum_work)?;\n','')
new=new.replace('let resolve = |template: &AudioPlacementTemplate, work: &mut Work| {',"let resolve = |template: &AudioPlacementTemplate, work: &mut Build<'_,P>| {")
new=new.replace('            template.resolve_with(layout, environment, work)','            let mut storage=work.fork();\n            let result=template.resolve_with(layout, environment, &mut storage)?;\n            Ok::<_,AudioBindingBuildError<P::Error>>(storage.finish(result))')
new=new.replace('resolve(&binding.lattice, &mut work)?','resolve(&binding.lattice, work)?').replace('let lattice = resolve','let mut lattice = resolve',1)
new=new.replace('resolve(&term.placement, &mut work)?','resolve(&term.placement, work)?').replace('resolve(&step.placement, &mut work)?','resolve(&step.placement, work)?')
new=new.replace('placement.sample_boundary','placement.value().sample_boundary').replace('placement.local_frames_per_sample','placement.value().local_frames_per_sample')
new=new.replace('Ok::<_, DocumentError>(ResolvedAudioResume','Ok::<_, AudioBindingBuildError<P::Error>>(ResolvedAudioResume')
new=new.replace('step.allocation_entry(layout, &placement, &mut work)?','step.allocation_entry(layout, placement.value(), work)?').replace('lattice.local_support.start','lattice.value().local_support.start')
new=new.replace('        Ok(ResolvedAudioBinding {\n            lattice,','        work.merge_value(&mut lattice)?;\n        Ok(ResolvedAudioBinding {\n            lattice:lattice.value.take().expect("binding lattice"),').replace('work: work.used,','work: work.used(),')
new=errs(new)
wrapper='''    fn resolve_binding(&self,binding:&OwnedAudioBinding,environment:AudioBindingEnvironment<'_>,maximum_work:usize)->Result<ResolvedAudioBinding,DocumentError>{
        let mut raw=Work::new(maximum_work)?;let mut extra=0;let mut policy=Unmetered;
        let mut work=Build::new(&mut raw,&mut extra,&mut policy);
        let value=legacy(self.resolve_binding_build(binding,environment,&mut work))?;
        Ok(work.finish(value).into_legacy())
    }'''
text=text[:a]+wrapper+'\n'+new+text[c:]
pos=text.index('    /// Whether appending ')
entries='''    pub fn resolve_in_admitted<P:AudioBindingAdmission>(&self,owner:&NodeId,environment:AudioBindingEnvironment<'_>,maximum_work:usize,admission:&mut P)->BuildResult<AdmittedAudioBinding<P::Issuer,P::Lease>,P::Error>{
        self.resolve_owner_admitted(owner,environment,maximum_work,AudioRecipeKind::Node,admission)
    }
    pub fn resolve_gap_in_admitted<P:AudioBindingAdmission>(&self,owner:&NodeId,environment:AudioBindingEnvironment<'_>,maximum_work:usize,admission:&mut P)->BuildResult<AdmittedAudioBinding<P::Issuer,P::Lease>,P::Error>{
        self.resolve_owner_admitted(owner,environment,maximum_work,AudioRecipeKind::RepeatGap,admission)
    }
    fn resolve_owner_admitted<P:AudioBindingAdmission>(&self,owner:&NodeId,environment:AudioBindingEnvironment<'_>,maximum_work:usize,kind:AudioRecipeKind,admission:&mut P)->BuildResult<AdmittedAudioBinding<P::Issuer,P::Lease>,P::Error>{
        let mut raw=Work{used:0,maximum:maximum_work};let mut extra=0;
        let mut work=Build::new(&mut raw,&mut extra,admission);
        environment.validate_build(&mut work)?;
        if (kind==AudioRecipeKind::RepeatGap)!=matches!(environment,AudioBindingEnvironment::GapOccurrence{..}|AudioBindingEnvironment::GapDefinition{..}){
            return Err(invalid("audio binding environment has another recipe kind").into());
        }
        if &environment.instance().node!=owner{return Err(invalid("audio binding occurrence names another owner").into());}
        let bindings=match kind{AudioRecipeKind::Node=>&self.bindings,AudioRecipeKind::RepeatGap=>&self.gap_bindings};
        let binding=bindings.get(owner).ok_or_else(||invalid("audio binding owner is missing"))?;
        Work::new(maximum_work)?;
        let result=self.resolve_binding_build(binding,environment,&mut work)?;
        Ok(work.finish(result))
    }

'''
text=text[:pos]+entries+text[pos:]
pos=text.index('fn physical(')
text=text[:pos]+'''fn project_affine_build<P:AudioBindingAdmission>(layout:&FrozenAudioLayout,root:&NodeId,instance:&InstancePath,local:ExactRatio,gap:Option<&IterationId>,maximum:usize,work:&mut Build<'_,P>)->BuildResult<AudioBindingValue<(crate::FrozenAudioProjection,std::ops::Range<ExactRatio>),P::Issuer,P::Lease>,P::Error>{
    layout.project_scoped_inner_admitted(root,instance,local,gap,maximum,crate::audio_reference::ProjectionMode::Affine,work.policy())
}

'''+text[pos:]
p.write_text(text)
