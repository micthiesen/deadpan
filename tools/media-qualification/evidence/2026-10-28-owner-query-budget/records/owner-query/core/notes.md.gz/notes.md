# Core actual owner-query admission: first frozen candidate

Frozen for parent compiler/review, NOT compiled or tested here. Scoped rustfmt
parsed the four Rust files. No Cargo/rustc, live source/index, commits, worktrees,
provider/native or cache operations ran. before-pins.json matches both actual
live Core production sources at freeze; after-pins.json and core.patch pin output.

## Files/API

- audio_binding.rs: shared legacy/admitted environment/template/resolve kernels;
  three scratch-set sites use one facade; same branch/scalar order.
- audio_reference.rs: actual scoped projection/scoped Repeat/branch kernels;
  legacy wrappers use the same functions. Frozen index remains borrowed.
- NEW audio_binding/admission.rs: binding-specific trusted policy, typed failure,
  paired value/lease bridge, linear canonical/additional receipts, independent
  temporary storage forks and bounded scratch/growing buffers.
- NEW audio_binding/admission/tests.rs:7 actual focused tests below.

Public exports are reexported inside audio_binding.rs, so existing Core
'pub use audio_binding::*' barrel requires no source change:
AudioBindingAdmission, AudioBindingBuildError, AudioBindingForwardedWork,
AudioBindingValue, AdmittedAudioBinding. Actual resolve_in_admitted and
resolve_gap_in_admitted methods are used by the Plan integration candidate.
No public arbitrary-value constructor or naked into_parts exists.

Core error semantic payload stays Document; caller E stays Policy(E).
Lease Drop is independent; actual value fields precede resource leases.
map_value validates before and after its trusted allocation-free move,
storing U before the postcheck so failures retain drop order.

## Actual ownership/work choices

Canonical debit remains at each existing accounting site. Newly executed
metadata/set/identity/buffer inspections are additional; both categories
decrement the same unchanged local cap. True forwards every primitive once.
Parents account_child linear receipts locally and never forward them twice.
False keeps old BTreeSet backend and canonical receipts, so legacy capture and
probe code's Core calls retain the old unpaid work. The metered environment
validation runs before the old work-limit-validation site, preserving semantic
order; its new policy refusal may preempt later old errors as approved.

The resolved lattice owns only its surviving IDs/path and allocation lease.
Each phase term and reanchor placement is a separate temporary storage guard;
validation expected/scoped/projected values likewise drop at their actual
scope. No query-wide monotonic sum of dead journal workspaces.

Growing vectors reserve new buffer before allocation with the old buffer+lease
still live, then move/drop old buffer before releasing old lease. Scoped Repeat
results keep buffer and descendant owning-ID leases separate: the required
path's IDs MOVE into final RepeatInstances as before, while its consumed
iterator/buffer drops and its buffer lease releases. No extra ID clone for that
move. Legacy Vec growth stays the original Vec::push behavior.

The three metered scratch sets store borrowed IDs in sorted Vecs. Capacity
uses actual input slice lengths, lazily allocated on first insertion. Environment
outside-depth guard remains before capacity extension. New comparisons, shifts,
and explicit reallocation moves are billed as additional work. No BTree node
estimate, global allocator, dependency or unsafe code is used.

Root/Point transforms, exact ratios, Repeat compact-run selection, original
clocks and physical mapping arithmetic are unchanged. Returned projection/
placement .work reflects total provenance in true mode, old canonical under
false; numerical comparison must compare logical fields and reconcile work
through the separate receipt, not expect metered .work to equal old work.

## Authored tests (NOT executed)

- actual_binding_values_and_both_mode_work_are_exact:
  real captured Repeat Hold, phase+reanchor binding, logical lattice and resume
  parity, literal instance/support, canonical equals legacy, additional>0,
  forwarded totals reconcile; second receipt take refuses; false unpaid work.
- exact_peak_one_short_and_every_reservation_failure_release:
  measure actual successful reservation peak, exact/one-short cap, then inject
  policy failure at every reached reservation; all live charges release.
- sequential_journal_temporaries_do_not_accumulate:
  same actual binding with1 versus8 phase/reanchor terms must have equal peak
  and retained live resource amounts.
- issuer_and_work_policy_errors_preserve_original_type:
  real result issuer change refuses before more reserves; exact/one-short host
  work budget retains typed policy error and releases all resources.
- semantic_error_order_and_earlier_policy_refusal_both_hold:
  duplicate actual Repeat input produces old semantic error with headroom;
  zero-byte cap refuses earlier at actual scratch storage, typed Policy.
- unmetered_backend_keeps_old_unpaid_work_and_never_calls_policy:
  actual false policy panics if spend/reserve/merge called; same legacy result
  and canonical work, zero additional/controller calls.
- actual_resolved_move_preserves_value_before_lease_drop:
  real Resolved moved through public map into an owning drop-observed wrapper;
  final resource release checks the owned value has dropped.

No test hooks were added to product constructors. These tests are an initial
uncompiled contract; compiler errors, fixture legality, clippy or failed
assertions must be resolved by parent-guided follow-up, not treated as passes.
Independent frozen Plan/Audio old oracle remains the decisive algorithm
regression witness; direct legacy parity in Core tests is complementary.

## Main/scoped integration

Core production delta is the same on main/scoped if before source hashes match.
No Core test fixture references Audio Graph/WIP or source provider state.
Parent owns apply/compile/test/barrel actions and all Plan/Audio integration.
Do not copy older Plan or final-sharing files from this scratch. If an isolated
Core base differs, apply scoped hunks against its actual text and pin the port.

No query-only delivery can certify capture/discarded-span or retained-probe
metadata. Those existing walks continue unchanged in the first Plan bridge,
with the newly admitted query retained/charged until capture completes.
No cold recursion/batching or raised work/resident limits is enabled.

## First compiler pass

All four owned files are frozen. I have not invoked Cargo or rustc. Parent may
compile Core first against the candidate, then Plan/Audio integration. I will
make no edits until a diagnostic/unfreeze request. Private guards' generic
borrows, test fixture construction and public type reachability are unverified
by a compiler so far.
