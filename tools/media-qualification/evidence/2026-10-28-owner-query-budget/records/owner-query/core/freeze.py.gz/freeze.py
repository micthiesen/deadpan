from pathlib import Path
import hashlib,json,difflib
s=Path('/tmp/deadpan-owner-query-budget-2026-10-28/core');root=Path('/Users/michael/Code/deadpan')
paths=['crates/deadpan-core/src/audio_binding.rs','crates/deadpan-core/src/audio_reference.rs','crates/deadpan-core/src/audio_binding/admission.rs','crates/deadpan-core/src/audio_binding/admission/tests.rs']
patch=[];pins={}
for path in paths:
 new=(s/'candidate'/path).read_bytes()
 old=(s/'before'/path).read_bytes() if (s/'before'/path).exists() else b''
 patch.extend(difflib.unified_diff(old.decode().splitlines(True),new.decode().splitlines(True),fromfile='a/'+path if old else '/dev/null',tofile='b/'+path))
 pins[path]={'sha256':hashlib.sha256(new).hexdigest(),'bytes':len(new)}
(s/'core.patch').write_text(''.join(patch))
(s/'after-pins.json').write_text(json.dumps(pins,indent=2)+'\n')
before=json.loads((s/'before-pins.json').read_text())
audit={'before_matches_live':{p:hashlib.sha256((root/p).read_bytes()).hexdigest()==v['sha256'] for p,v in before.items()},'patch_sha256':hashlib.sha256((s/'core.patch').read_bytes()).hexdigest(),'after_pins_sha256':hashlib.sha256((s/'after-pins.json').read_bytes()).hexdigest(),'verification':'Scoped rustfmt parse only; no Cargo/rustc or runtime tests run by this agent.'}
(s/'audit.json').write_text(json.dumps(audit,indent=2)+'\n')
print(json.dumps(audit,indent=2))
print('Patch lines',len(patch))
