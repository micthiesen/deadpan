from pathlib import Path
import json,hashlib,difflib
root=Path('/Users/michael/Code/deadpan');s=Path('/tmp/deadpan-owner-query-budget-2026-10-28/core/lint-correction2')
paths=['crates/deadpan-core/src/audio_binding.rs','crates/deadpan-core/src/audio_reference.rs','crates/deadpan-core/src/audio_binding/admission.rs']
values={}
for p in paths:
 text=(root/p).read_text();values[p]=text
 q=s/'before'/p;q.parent.mkdir(parents=True,exist_ok=True);q.write_text(text)
p=paths[2];text=values[p]
marker='pub(crate) type BuildResult<T, E> = Result<T, AudioBindingBuildError<E>>;'
assert text.count(marker)==1
text=text.replace(marker,marker+'''
pub(crate) type AdmittedResult<T, P> = BuildResult<
    AudioBindingValue<T, <P as AudioBindingAdmission>::Issuer, <P as AudioBindingAdmission>::Lease>,
    <P as AudioBindingAdmission>::Error,
>;
pub(crate) type ProjectedSupport = (crate::FrozenAudioProjection, std::ops::Range<ExactRatio>);
pub(crate) type ProjectedAllocation = (crate::FrozenAudioProjection, Option<std::ops::Range<ExactRatio>>);
''');values[p]=text
p=paths[0];text=values[p]
text=text.replace('use admission::{Build, BuildResult, ScratchSet, Unmetered, legacy};','use admission::{AdmittedResult, Build, BuildResult, ProjectedAllocation, ProjectedSupport, ScratchSet, Unmetered, legacy};')
old='''    ) -> BuildResult<
        AudioBindingValue<
            (
                crate::FrozenAudioProjection,
                Option<std::ops::Range<ExactRatio>>,
            ),
            P::Issuer,
            P::Lease,
        >,
        P::Error,
    > {'''
assert text.count(old)==1
text=text.replace(old,') -> AdmittedResult<ProjectedAllocation, P> {')
old=''' ) -> BuildResult<'''
oldret=''' ) -> BuildResult<
    AudioBindingValue<
        (crate::FrozenAudioProjection, std::ops::Range<ExactRatio>),
        P::Issuer,
        P::Lease,
    >,
    P::Error,
> {'''
# fn has ')' beginning no leading space in formatted source.
oldret=oldret[1:]
assert text.count(oldret)==1
text=text.replace(oldret,') -> AdmittedResult<ProjectedSupport, P> {')
old='''        let mut value = layout.project_scoped_inner_admitted(
            self.root.node(),
            instance,
            ExactRatio::ZERO,
            gap_after,
            maximum,
            mode,
            work.policy(),
        )?;'''
new='''        let mut value = layout.project_scoped_inner_admitted(
            crate::audio_reference::ScopedProjectionRequest {
                root: self.root.node(), instance, local: ExactRatio::ZERO,
                gap_after, maximum_work: maximum, mode,
            },
            work.policy(),
        )?;'''
assert text.count(old)==1;text=text.replace(old,new)
old='''    layout.project_scoped_inner_admitted(
        root,
        instance,
        local,
        gap,
        maximum,
        crate::audio_reference::ProjectionMode::Affine,
        work.policy(),
    )'''
new='''    layout.project_scoped_inner_admitted(
        crate::audio_reference::ScopedProjectionRequest {
            root, instance, local, gap_after: gap, maximum_work: maximum,
            mode: crate::audio_reference::ProjectionMode::Affine,
        },
        work.policy(),
    )'''
assert text.count(old)==1;text=text.replace(old,new);values[p]=text
p=paths[1];text=values[p]
# Actual rustfmt import spelling verified after insertion.
text=text.replace('AudioBindingAdmission, AudioBindingValue, Build, BuildResult, Growing, Unmetered, legacy,','AdmittedResult, AudioBindingAdmission, Build, Growing, ProjectedSupport, Unmetered, legacy,')
# It may already have different multiline spacing; demand exactly names present.
assert 'AudioBindingValue' in text
old='''    ) -> BuildResult<
        AudioBindingValue<
            (FrozenAudioProjection, std::ops::Range<ExactRatio>),
            P::Issuer,
            P::Lease,
        >,
        P::Error,
    > {'''
assert text.count(old)==1
text=text.replace(old,') -> AdmittedResult<ProjectedSupport, P> {')
old='''    ) -> BuildResult<AudioBindingValue<Vec<NodeId>, P::Issuer, P::Lease>, P::Error> {'''
assert text.count(old)==1;text=text.replace(old,') -> AdmittedResult<Vec<NodeId>, P> {')
old='''    ) -> BuildResult<AudioBindingValue<NodeId, P::Issuer, P::Lease>, P::Error> {'''
assert text.count(old)==1;text=text.replace(old,') -> AdmittedResult<NodeId, P> {')
old='''        let value = legacy(self.project_scoped_inner_admitted(
            root,
            instance,
            local,
            gap_after,
            maximum_work,
            mode,
            &mut Unmetered,
        ))?;'''
new='''        let value = legacy(self.project_scoped_inner_admitted(
            ScopedProjectionRequest { root, instance, local, gap_after, maximum_work, mode },
            &mut Unmetered,
        ))?;'''
assert text.count(old)==1;text=text.replace(old,new)
old='''    pub(crate) fn project_scoped_inner_admitted<P: AudioBindingAdmission>(
        &self,
        root: &NodeId,
        instance: &InstancePath,
        local: ExactRatio,
        gap_after: Option<&IterationId>,
        maximum_work: usize,
        mode: ProjectionMode,
        admission: &mut P,
) -> AdmittedResult<ProjectedSupport, P> {
        if maximum_work'''
new='''    pub(crate) fn project_scoped_inner_admitted<P: AudioBindingAdmission>(
        &self,
        request: ScopedProjectionRequest<'_>,
        admission: &mut P,
) -> AdmittedResult<ProjectedSupport, P> {
        let ScopedProjectionRequest { root, instance, local, gap_after, maximum_work, mode } = request;
        if maximum_work'''
assert text.count(old)==1;text=text.replace(old,new)
pos=text.index('pub(crate) enum ProjectionMode {')
# Request may precede enum derive; choose insert before its preceding derive.
pos=text.rfind('#[derive',0,pos)
text=text[:pos]+'''pub(crate) struct ScopedProjectionRequest<'a> {
    pub(crate) root: &'a NodeId,
    pub(crate) instance: &'a InstancePath,
    pub(crate) local: ExactRatio,
    pub(crate) gap_after: Option<&'a IterationId>,
    pub(crate) maximum_work: usize,
    pub(crate) mode: ProjectionMode,
}

'''+text[pos:]
# Remove no-longer-used generic carrier/result imports, add aliases.
text=text.replace('AudioBindingAdmission, AudioBindingValue, Build, BuildResult, Growing, Unmetered, legacy,','AdmittedResult, AudioBindingAdmission, Build, Growing, ProjectedSupport, Unmetered, legacy,')
assert 'AudioBindingValue' not in text
assert 'BuildResult' not in text
values[p]=text
for p,text in values.items():
 q=s/'candidate'/p;q.parent.mkdir(parents=True,exist_ok=True);q.write_text(text)
(s/'before-pins.json').write_text(json.dumps({p:hashlib.sha256((s/'before'/p).read_bytes()).hexdigest() for p in paths},indent=2)+'\n')
