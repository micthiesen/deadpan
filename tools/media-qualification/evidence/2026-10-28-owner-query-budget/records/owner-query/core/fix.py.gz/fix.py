from pathlib import Path
b=Path('/tmp/deadpan-owner-query-budget-2026-10-28/core/candidate/crates/deadpan-core/src')
p=b/'audio_binding/admission.rs';s=p.read_text()
s=s.replace('pub(crate) lease: Option<L>,','pub(crate) lease: Option<L>,\n    pub(crate) buffer: Option<L>,',1)
s=s.replace('lease: self.lease.take(),','lease: self.lease.take(),\n            buffer:self.buffer.take(),',1)
# Finish regular guards have no independent buffer.
pos=s.index('    pub(crate) fn finish<T>')
tail=s[pos:].replace('lease: self.charge.take(),','lease: self.charge.take(),\n            buffer:None,',1);s=s[:pos]+tail
pos=s.index('    pub(crate) fn merge_value')
s=s[:pos]+'''    pub(crate) fn finish_buffer<T>(self,value:Vec<T>,buffer:Option<P::Lease>)->AudioBindingValue<Vec<T>,P::Issuer,P::Lease>{
        let mut result=self.finish(value);result.buffer=buffer;result
    }
'''+s[pos:]
# Growing result is a private actual buffer/lease ownership transfer, not a public naked Core resolved API.
a=s.index('    pub(crate) fn finish<P:',s.index('pub(crate) struct Growing'))
s=s[:a]+'''    pub(crate) fn finish<P:AudioBindingAdmission<Issuer=I,Lease=L>>(mut self,build:&mut Build<'_,P>)->BuildResult<(Vec<T>,Option<L>),P::Error>{
        build.validate()?;
        if self.issuer.is_some_and(|v|v!=build.issuer){return Err(AudioBindingBuildError::Policy(build.policy.issuer_mismatch()));}
        Ok((std::mem::take(&mut self.values),self.buffer.take()))
    }
}
''';p.write_text(s)
p=b/'audio_reference.rs';s=p.read_text().replace('let values = repeats.finish(&mut work)?;\n        Ok(work.finish(values))','let (values,buffer) = repeats.finish(&mut work)?;\n        Ok(work.finish_buffer(values,buffer))');p.write_text(s)
p=b/'audio_binding.rs';s=p.read_text()
s=s.replace('''                &clause.definition_root,
                work.remaining()?,
            )?;''','''                &clause.definition_root,
                work.remaining()?,
                work.policy(),
            )?;''')
# Keep old move count and release only consumed required path buffer after iterator drops.
s=s.replace('for reference_repeat in required.value() {','let required_values=required.value.take().expect("required Repeat path");\n        for reference_repeat in required_values {')
s=s.replace('&argument.reference_repeat == reference_repeat','argument.reference_repeat == reference_repeat')
s=s.replace('node: work.node(reference_repeat)?,','node: reference_repeat,')
s=s.replace('''        let instance = InstancePath {
            node: work.node(&self.reference.physical)?,''','''        drop(required.buffer.take());
        work.merge_value(&mut required)?;
        let instance = InstancePath {
            node: work.node(&self.reference.physical)?,''')
# Affine projection caller instances must be admitted before actual construction.
old='''                    let mut projected = project_affine_build(
                        layout,
                        &self.reference.physical,
                        &InstancePath {
                            node: self.reference.physical.clone(),
                            repeats: Vec::new(),
                        },'''
new='''                    let mut input=work.fork();
                    let instance=InstancePath{node:input.node(&self.reference.physical)?,repeats:Vec::new()};
                    let input=input.finish(instance);
                    let mut projected = project_affine_build(
                        layout,
                        &self.reference.physical,
                        input.value(),'''
assert old in s;s=s.replace(old,new)
old='''                let mut projected = project_affine_build(
                    layout,
                    &argument.reference_repeat,
                    &InstancePath {
                        node: work.node(child.value())?,
                        repeats: vec![RepeatInstance {
                            node: argument.reference_repeat.clone(),
                            iteration: iteration.clone(),
                        }],
                    },'''
new='''                let mut input=work.fork();
                input.array::<RepeatInstance>(1)?;
                let repeats=vec![RepeatInstance{node:input.node(&argument.reference_repeat)?,iteration:input.iteration(iteration)?}];
                let input=input.finish(repeats);
                let instance=child.map_value(work.policy(),|node|InstancePath{node,repeats:input.value().clone()})?;
                let mut projected = project_affine_build(
                    layout,
                    &argument.reference_repeat,
                    instance.value(),'''
assert old in s;s=s.replace(old,new)
# Avoid clone of the temporary repeat Vec: move actual admitted value, retaining its charge.
s=s.replace('let input = input.finish(repeats);','let mut input = input.finish(repeats);') if False else s
s=s.replace('let input=input.finish(repeats);\n                let instance=child.map_value(work.policy(),|node|InstancePath{node,repeats:input.value().clone()})?;','let mut input=input.finish(repeats);\n                let instance=child.map_value(work.policy(),|node|InstancePath{node,repeats:input.value.take().expect("captured Repeat path")})?;')
# input charge must outlive instance: declared before instance, therefore drops after instance.
p.write_text(s)
