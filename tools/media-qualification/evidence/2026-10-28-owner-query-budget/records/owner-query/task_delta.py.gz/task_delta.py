from pathlib import Path
import json,difflib,hashlib
s=Path(__file__).resolve().parent
root=Path('/Users/michael/Code/deadpan')
paths={}
for p in json.loads((s/'core/after-pins.json').read_text()):
 paths[p]=s/'core/before'/p
for row in json.loads((s/'plan/first-compile/pins.json').read_text()):
 paths[row['path']]=s/'plan/first-compile/before'/row['path']
for row in json.loads((s/'integration/candidate-pins.json').read_text()):
 p=row['path'];assert p not in paths,p
 paths[p]=s/'integration/main-before'/p
patch=[];rows=[]
for p,before in sorted(paths.items()):
 assert (root/p).exists(),p
 old=before.read_bytes() if before.exists() else b''
 current=(root/p).read_bytes()
 if old==current:continue
 rows.append({'path':p,'new':not before.exists(),'before_sha256':hashlib.sha256(old).hexdigest() if before.exists() else None,'current_sha256':hashlib.sha256(current).hexdigest()})
 patch.extend(difflib.unified_diff(old.decode().splitlines(True),current.decode().splitlines(True),fromfile='a/'+p if before.exists() else '/dev/null',tofile='b/'+p))
(s/'task.patch').write_text(''.join(patch))
(s/'task-source-pins.json').write_text(json.dumps(rows,indent=2)+'\n')
print(json.dumps({'files':len(rows),'patch_sha256':hashlib.sha256((s/'task.patch').read_bytes()).hexdigest()}))
