from pathlib import Path
import gzip,hashlib,json
s=Path(__file__).resolve().parent
repo=Path('/Users/michael/Code/deadpan')
dest=repo/'tools/media-qualification/evidence/2026-10-28-owner-query-budget'
assert not dest.exists()
prior=repo/'tools/media-qualification/evidence/2026-10-28-owner-query-baseline-v1/inventory.json'
prior_hash='e7cb86ccaf27fea0abd4c784c2f82e31c2f94b9593e756fb3979add4bbf16e2a'
assert hashlib.sha256(prior.read_bytes()).hexdigest()==prior_hash
audit=json.loads((s/'final-audit.json').read_text())
assert audit['all_terminal'] and audit['final_source_and_index_verified']
allowed={'.rs','.json','.py','.md','.patch','.stdout','.stderr','.txt'}
exclude={'qualification-draft.md','next-capture-core.md','next-capture-plan.md'}
entries=[]
for p in sorted(s.rglob('*')):
 if not p.is_file() or p.suffix not in allowed or p.name in exclude or p.name.startswith('next-capture-'):continue
 data=p.read_bytes()
 if p.suffix=='.json':
  obj=json.loads(data)
  if isinstance(obj,dict) and 'command' in obj and 'started_at' in obj:
   assert 'exit_code' in obj and obj['sources_unchanged'] and obj['binaries_unchanged'],str(p)
 record=dest/'records/owner-query'/p.relative_to(s)
 record=record.with_name(record.name+'.gz')
 record.parent.mkdir(parents=True,exist_ok=True)
 packed=gzip.compress(data,mtime=0);record.write_bytes(packed)
 entries.append({'path':str(record.relative_to(dest)),'bytes':len(packed),'sha256':hashlib.sha256(packed).hexdigest(),'expanded_bytes':len(data),'expanded_sha256':hashlib.sha256(data).hexdigest()})
manifest={'schema_version':1,'base_revision':(s/'base-revision.txt').read_text().strip(),'scope':'Actual Root/Domain candidate-query admission through reached Core binding/projection, sealed membership and one-time canonical/additional work. Legacy capture remains unpaid C and its allocations, returned capture/probe graph, caller keys/containers and cold activation remain outside this closure. Includes retained compiler/lint/fixture failures and their corrections.','prior_legacy_query_baseline':{'path':'../2026-10-28-owner-query-baseline-v1/inventory.json','inventory_sha256':prior_hash},'files':entries}
p=dest/'inventory.json';p.write_text(json.dumps(manifest,indent=2)+'\n')
stored=expanded=0
for row in entries:
 packed=(dest/row['path']).read_bytes();plain=gzip.decompress(packed)
 assert len(packed)==row['bytes'] and hashlib.sha256(packed).hexdigest()==row['sha256']
 assert len(plain)==row['expanded_bytes'] and hashlib.sha256(plain).hexdigest()==row['expanded_sha256']
 stored+=len(packed);expanded+=len(plain)
print(json.dumps({'files':len(entries),'stored_bytes':stored,'expanded_bytes':expanded,'inventory_sha256':hashlib.sha256(p.read_bytes()).hexdigest()}))
