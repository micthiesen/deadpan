from pathlib import Path
import sys,json,subprocess
s=Path(__file__).resolve().parent
label=sys.argv[1];receipt=sys.argv[2];kind=sys.argv[3]
pins=json.loads((s/(label+'-pins.json')).read_text())
command=['python',str(s/('run.py' if kind=='main' else 'run_scoped.py'))]
for pin in pins:
 if pin['package']=='plan':command+=['--binary',pin['path']]
command+=['--binary',str(s/'plan_suites.py'),receipt,'--','python',str(s/'plan_suites.py'),label]
raise SystemExit(subprocess.run(command).returncode)
