# Pre-G projected baseline candidate review

CHANGES REQUIRED before integration. The source-ready hook is sound, but the original capture candidate has concrete compile and reachability blockers. No build/native execution/root edit/Git was performed.

Pinned candidate: patch 8e5a556da32cce57186add9c6ac8c52c8b0c6736f83cbd44796ea12cab94672b; observer 5c329596ff9318a4ffb264b4daed8e5e4e555211b3d4e5205f8051ebb2318be7; test f50241a08db507c4dbb65062d8b1303cde7e904473cce28fd653503984472bef. All nine declared base pins match Scope. The patch reconstructs all three new files exactly. The reviewed original is retained under candidate-observed so later revisions cannot erase these findings.

## Blocking findings

1. The public read_routed_signal requests 512/768 frames. routed_end at routed.rs:513 rejects frames>MAX_OUTPUT_FRAMES 256 before any projected helper. All intended reads therefore return Range with no source-ready row; the positive branch assertion cannot pass. Use actual windows of at most 256 frames. The existing Source a spans 512 frames, followed by the new 128-frame silent Hold; input extent 640 and Preserve duration 768 are consistent. Source-only 0..256 and positive 512..768 are plausible choices, with actual policy/range assertions and runtime confirmation still required.

2. The helper module is stages::controlled_reads, not stages::tests (stages.rs:3357). Provider and fixture_document_at_rate paths must reference that actual sibling module. Their pub(super) visibility permits descendants of stages to use them. Candidate also omits required deadpan_core imports for NodeId, BeatNode, HoldRecipe/HoldVideo/HoldAudio, NodeKind, ProjectFrame/FrameRange, PitchPolicy, RetimePurpose, ProjectDocument and SoundRoute. These are not imported by stages' root use list. TIMEOUT has no definition in the candidate or ancestors. Use explicit imports and a local real timeout.

3. Before claiming intended positive/empty output coverage, require actual Ok results and identified source-ready rows in both cases. The empty case currently can record Err/no-row while its separate ordinary preasserted policy is empty. Positive checks only a separate nonempty policy and some reached row. Assert the actual source Vec's length/ranges and final identity-route result, including nonempty actual positive source and empty actual negative source. This prevents a separate query from substituting for actual reader reachability.

## Hook and construction review

The record call is strictly after the unchanged suppress_signal succeeds. It observes the actual Vec while alive, and prepared is still an Arc used afterward. Disabled mode returns before borrowing ReadWork or collecting ranges. Enabled mode borrows only local observation state and ReadWork; no query/provider callback, native debit, admission/lease, source mutation or production owner is introduced. Source pointer is a private integer excluded by serde; it is never dereferenced after drop. The capacity flag describes the actual allocation, not a charge. Cumulative work is correctly labeled as cumulative, not an isolated query fee.

The graph/tape construction is statically plausible: a 512 + silent Hold 128 gives 640 intrinsic input frames; Retime maps 640 to 768, so the descriptor rate is 5/6 and the public AudioStageProjection validator expects 0..640 input and 0..768 output. Both tapes retain the same-plan stage input and identity route. This is public-factory reasoning, not proof that validation/native preparation succeeds.

## Proof limits and requested clarification in the capture

Repeating calls on one StageAudio does not demonstrate persistent projected-memo reuse. prepare_projected stores that memo in ReadWork.projected, and every public call creates a fresh PreparationBudget. The ordinary Stage cache may be reused. Label the observations as repeated same-renderer reads unless an actual cache-hit receipt establishes more. Within one successful routed read the pre-loop preparation and helper's second preparation can use the same request-local memo.

Current result capture has a SHA of decimal-JSON PCM and selected fields only. Prefer complete f32-bit samples, sample capacity, schema/stage/project/revision/allocation/start, and literal result mask metadata before freezing the new corpus. Otherwise explicitly call this a limited source-ready baseline, not complete public-output parity. No dependency/fingerprint/depth/fractional/negative case is proved here.

The separate policy preassert is a legitimate fixture sanity check outside the measured request; it is not the actual helper receipt and cannot supply its work/lookup/inventory. Keep that distinction and preserve any rejected factory/read results. The observer is scoped to these bounded fixture invocations; it has no generic truncation/unfinished protocol, so do not extend its claim to arbitrary long request observation without adding a bounded truthful protocol.

Parent and author received the concrete blockers immediately. Await a pinned correction and actual parent execution before freezing any 35th corpus.
