# Pre-G v3/v4 and parent compile-fix review

GO for the narrow source-ready baseline candidate after the actual test compile fixes. No production admission or numerical path changes are included. This is a static verdict; parent build 2/native success is still owed.

The v3 delta adds exact f32-bit PCM samples plus SHA256 over little-endian channel words; every public RoutedSignalBlock field, sample/mask length and capacity; exactly one actual SourceReady receipt with matching start/frame; and an assertion that successful pre-G output remains Plain. The Mac/Linux test gate matches the existing real helper. The observer is unchanged from v2. These changes address v2's output-proof limits without inventing destination ownership.

V4 only corrects shared-renderer labels to first empty/second positive and corresponding local names. It does not claim a cache hit or persistent projected memo across fresh public budgets. Scope's three integrated files exactly matched v4 before the parent compiler fixes.

The actual first v4 build failed in both roots: E0034 ambiguous AudioSoundRoute::new and E0277 LowerHex unsupported for the sha2 digest output. My prior static review missed these concrete API issues; it did not establish compilation. Parent changes only the test: explicit AudioSoundRoute::<SignalSample>::new, std::fmt::Write imported anonymously alongside io::Write, and two-digit lowercase hex formatting of each finalized digest byte. The resulting source is 8fe2760d8bbf5ab3d0d2060f18dc114ed4b5c269d1589d8adc586e645eb904a9. This preserves the same 32-byte digest and 64-character lowercase representation without relying on the digest container's formatting trait.

Public fixture reasoning remains unchanged: 512 Source +128 silent Hold gives 640 intrinsic input,768 Preserve output,rate 5/6. Windows 0..256 and 512..768 fit the actual 256-frame routed limit and identity-route integral bounds. The input/output tape supports match the public projection validator. Each intended result must actually succeed with the corresponding observed source policy before a baseline is frozen. This is plausible reachable source code, not execution evidence.

The hook remains immediately after old suppress_signal succeeds, with the true Vec/prepared Arc live, default-off, no query/provider call, no admission/ticket, no work mutation and no serialized pointer. Bounded observation rejects truncation, take disables it, and output uses create_new. Source-ready/cumulative-counter claims are accurate. Negative/fractional/override/quota/ownership lifetime claims remain explicitly outside this before capture.

Exact snapshots of v3, v4 and the parent fixed test delta/pins are retained in this directory. No roots/builds/native/Git were changed or executed by this reviewer.
