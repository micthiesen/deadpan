# Projected destination seam and before-corpus review

GO for the minimal native destination-copy seam, with the explicitly limited claim below. This is source/design review only. No implementation, root edits, builds, native executions, Git, or capture generation were performed.

## Concrete production boundary

In routed.rs::read_projected_signal_controlled, retain the existing prepare_projected, stage_recipe and sample_prepared sequence. Let the existing suppress_signal call finish unchanged. Then consume SignalSuppressionMask::plain(actual_vec).into_admitted(&mut self.masks(control)) and put that returned owner directly into SignalBlock. Keep the prepared Arc used afterward for dependency cloning and relative depth, as now. No helper-wide replacement is warranted.

The actual helper in stages.rs constructs ordinary PreserveTape policy, spends its literal policy.work once, preflights actual contents, checks control, validates every interval before any zeroing, zeroes PCM, and performs the legacy merge. That entire sequence precedes destination admission. Neither ordinary child queries/inventory nor the final legacy source Vec becomes admitted retroactively.

The copy retains its real source owner through reservation, all borrowed pushes, Box construction and final control check. into_admitted explicitly drops self only after a completed destination exists. begin_ranges reserves the exact vector Layout for source.len() plus future owning Storage Box before allocation. The account shell is lazily admitted through real make_room, with existing projected_resident_frames/sound_context/active/cache/owned residency counted. PreparedBlock's request-local cache retains its PCM Arc as well; it is not a suppression-mask cache. No source bytes may be subtracted or converted into a fake lease.

An empty source uses the existing empty path: check control, return default, drop the actual ordinary source allocation, no new account/vector/Box from this seam. Record a nonzero old source capacity even if its length is zero. A pre-existing shell may remain; do not assert the whole controller has no account.

The short mutable self.masks borrow is feasible after suppress_signal returns. prepared is an owned Arc, not a borrow into self or a held ReadWork Ref. No provider/query callback is added between destination reserve and finish. Existing unique Box/Vec-before-charge drop behavior covers every new refusal/cancellation path. Additional resource errors can occur after the old work/zeroing succeeds; discard the local output and preserve accepted work.

## Downstream effects that must be measured

Only one actual production caller reaches this helper: read_routed_signal's Projected span branch. Its public request is checked by routed_end to 1..=MAX_OUTPUT_FRAMES with checked end and allocation containment. This bound is not permission to replace general mask storage or assume general ReadBlock bounds.

The caller appends PCM, then extend_try_map shifts real SignalSample ranges through checked shift_label. A positive Owned child selects the existing Owned branch. It can fund a replacement while both current aggregate and child remain live, or append within funded capacity; it does not detach the child. Final Owned merge uses existing billed in-place heap sort/compaction and retains capacity. Later gap pushes can grow capacity. Observe these additional fees/overlaps/refusals and literal capacities separately from the one local copy. Do not force all old/new capacities equal or call downstream work canonical Tape policy work. With sufficient resources, preserve PCM bits, range endpoints/clocks, provider/dependency observations and existing semantic errors.

The caller's PCM/gap buffers, route spans, dependency clones, ordinary Tape construction/query/merge and stage_projection build/saved-stage suppress_signal temporaries remain outside this unit. Do not route PreserveTape through PointCeil admitted policy: stored tape grids/endpoints/provider kinds and overrides remain ordinary and semantically distinct.

## Truthful 35th before corpus

Freeze one immutable manifest, not one selected full F body. Its anchor is published F59874646dba6974da77e2cad08e9bc4822fd5afe. The sketch records all six actual 38,529,544-byte F canonical payloads and full hashes. They already exist in immutable F evidence; parent may use committed compressed archive-member locators, retaining raw bytes/proofs/source provenance. No F recapture, rewritten metadata, or normalized canonical replacement is required.

The exact current classic section is 35,593,959 bytes, SHA256 a0551013c190119e61a17e09db82a64c8807abedefab02336c01887ae126af45. Separating that section for comparison is not replacing the full raw capture. Keep all 744 outputs (264 Ok/480 Error),42 result fields, classic account data and structure exact. Independently validate all four F producer cases in each capture: actual driver/reachability, bounded inline words, bit-derived ranges/count, funded capacity/custody/overlap, held disposal/cleanup, real Zero4 and first/last Mark1 with unchanged cache lane. Completed inclusive claims reconcile independently; keep the claimless partial and its five-unit residual literal.

F's six bodies differ only at 95 reviewed integer absolute plan-work paths in TWO wet-positive cases. Store that exact path specification and all actual values/deltas as observations, not numeric goldens. A fresh capture need not equal any of the six whole hashes. Require exact comparison outside the reviewed fields plus independent local-debit/ownership checks in each new capture. Unexpected new paths, altered structure/output/capacity/account/error/local debit must fail automated comparison and receive explicit independent evidence review. Never edit old F payloads or silently enlarge their variance specification to turn a failure green.

F6 alone do not observe the new projected destination. Before any G production integration, also freeze actual checked G-specific before cases into the corpus: genuine positive silent-Hold output policy, genuine empty Source policy, and whichever nested/negative/fractional/cold-warm/preflight/fingerprint cases public factories actually support. Keep construction failures as errors; do not manufacture a positive case. Record the actual source Vec values/len/cap and current Plain result, exact PCM/ranges/clocks/provider/dependency/errors and resource metadata. The manifest sketch deliberately leaves g_before_cases null until those exist; it is not itself a frozen oracle.

A G-only literal replay must keep Components/Point/Root/SharedMix active as published F while bypassing only this new destination admission. Older five complete-body replay modes keep their original compositions. No global legacy switch, fee waiver, altered old JSON header, or unused production fallback is needed.

## Meaningful proof for G

Observe the real local source Vec after suppress_signal succeeds, before consuming it. For positive length, show source/destination pointers differ while both allocations live, exact target Layout/capacity, source retained through Box publication/final check, and account payload release after request/provider/controller disposal. Distinguish the local copy from later label-map/aggregate owners. If actual query stats are needed, observe the actual policy receipt at its existing construction site under an identified test scope; no second query or whole-read residual establishes them.

Quota thresholds are isolated only after real source preparation/policy/zeroing succeeds. Keep projected PCM residency and existing retained owners in the actual cap expression. Such a test proves destination overlap, not whole-request admission or source policy closure. Work-prefix/cancellation/deadline failures must prove their actual reached boundary, pending cleanup and retained source custody; do not repeat F's assumption that a measured prefix is stable across independent pointer-sensitive graphs.

The decisive limitations remain the ordinary source/inventory gap and newly activated downstream work/capacity. Both are reviewable; neither blocks this accurately named destination-only prerequisite. No DP or Gate acceptance changes follow.
