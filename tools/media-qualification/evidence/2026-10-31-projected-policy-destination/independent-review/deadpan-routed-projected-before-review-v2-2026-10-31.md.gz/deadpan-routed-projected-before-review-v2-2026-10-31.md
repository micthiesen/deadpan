# Pre-G baseline v2 static review

GO for parent build/run as a limited source-ready baseline. No remaining concrete compile/API/reachability blocker was found by static review. This is not execution or freeze approval. V1's failed source assumptions remain retained.

Candidate patch 18510f9980990288f5e76a505f2bb2f5cf006afbc4093aff9e33c962272470e3, observer 4bdb423032d1d127c84c6e2a52a5e559514f48d2428394c00b043af5214a6573, tests 233bfa69606f2d67f5403f25b8e28d35a9adb0499b321db2957403ceb07e9619. All nine base pins match and all three patch outputs reconstruct exactly. Snapshot/pins are retained beside this report.

V2 fixes the concrete blockers: real controlled_reads helper/Provider paths, explicit core/Plan imports and local timeout; public reads 0..256 and 512..768 fit routed_end's 256-frame bound and 0..768 allocation. The 512 Source +128 Hold input 640 and Preserve duration 768 match the descriptor rate 5/6, input/output tape extents and public projection/route validators. No forced private domain or fabricated mask is used. Actual constructor/native success is still owed.

Both intended cases now require actual Ok and SourceReady reachability. Empty requires the actual source length 0. Positive requires the actual source ranges equal the independently preasserted nonempty policy, with the same checks on repeated-renderer reads. The separate prequery remains fixture evidence, not the helper's actual work receipt.

The observer stays cfgtest/default-off and returns before reading WorkControl.work when disabled. Enabled observation is bounded 128 rows/512 ranges, records truncation, and the capture rejects it. Actual source pointer is private/serde-skipped; source Vec and prepared Arc remain alive at the hook, with no native fee, ownership/lease or runtime admission change. take disables observation before assertions/serialization. Fresh output uses create_new.

Metadata correctly labels cumulative work and separates source readiness from destination ownership. Reusing StageAudio across public calls still does not prove projected memo reuse or a concrete cache hit; each public read has fresh PreparationBudget/ReadWork. Treat its cache fields as observations only. Source-ready rows, capacities and the stored PCM JSON hash are a limited baseline; v3's promised exact PCM bits/public metadata will strengthen immutable output parity. No negative/fractional/override/quota proof is established here.

Only narrow read-only source/patch inspection was performed. Parent owns compile/native validation and before-corpus freezing; roots remain untouched by this reviewer.
