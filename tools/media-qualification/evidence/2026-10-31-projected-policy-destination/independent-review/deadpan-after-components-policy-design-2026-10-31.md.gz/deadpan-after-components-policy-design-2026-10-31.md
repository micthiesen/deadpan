# After Components: projected PreserveTape mask ownership

Read-only contract against current Scope source, with F integrated but unpublished. Published base: E 69698b678fd8a75dd644993d7d2a9846986d6911. Source authority is /tmp/deadpan-query-groundwork-2026-10-26/scoped. Exact source hashes and navigation are in /tmp/deadpan-after-components-policy-design-2026-10-31/source-pins.json and navigation.md. No roots, builds, native runs, Git, captures or oracles were changed. This is not F qualification or Gate credit.

## Decision

The smallest safe next ownership unit is the returned native mask of routed.rs::read_projected_signal_controlled. Reuse the real native SignalSuppressionMask::into_admitted with the existing StageAudio mask context, after the complete existing suppress_signal call succeeds. Leave that helper and all ordinary Plan queries literal. Keep the already prepared PCM Arc alive through this new allocation and result construction.

This is deliberately a destination-only copy prerequisite, not closure of the PreserveTape policy producer. It leaves the ordinary tape-policy child queries, range aggregates, inventory and legacy native merge allocation outside admission. If the next milestone requires source-construction closure, do not count this prerequisite as satisfying it. A fully admitted tape producer is a separate Plan unit described below; C is insufficient.

The minimal production change is local to the one routed method: wrap the actual returned Vec as Plain, consume it with into_admitted(&mut self.masks(control)), then put the resulting sealed mask directly into SignalBlock. Do not use a fabricated Plan lease, adopt heap after construction, generalize public handoff tokens, or add an ordinary fallback under an “admitted tape” name. A test-only literal replay flag and focused tests are separate hooks. No ordinary multi-output changes are needed.

## Current actual path and lifetime

1. read_routed_signal validates cancellation/domain/timeout/allocation, builds and bills its route query, and converts every route lookup to an exact retained integral range before media work. It preflights and prepares the complete projected source even for an all-gap route.
2. Each actual Projected span invokes read_projected_signal_controlled with its old retained SignalSample start and span length. That method calls prepare_projected again, obtains the presentation frame rate, builds the existing resample recipe, then calls sample_prepared. Its use of AudioSample(start.0) inside the resampler is the existing numeric boundary; this proposal does not relabel/remap it.
3. suppress_signal computes the checked end, requests ordinary PreserveTape policy using the current query limits, bills policy.work once, preflights every policy content, checks cancellation/deadline, validates all ranges before any zeroing, zeroes PCM, then creates the ordinary merged Vec.
4. Today that Vec becomes Plain in SignalBlock. The caller translates actual ranges with checked shift_label through extend_try_map, appends PCM, checks control and merges the RoutedSignalBlock mask. Giving the projected child an Owned mask activates these existing Owned branches downstream. Their additional work, overlap, quota refusals and final capacity must be observed, not attributed solely to the new copy.
5. SignalBlock dependencies are cloned from PreparedBlock after mask creation; relative_depth remains 1 + prepared.relative_depth. Caller PCM/dependency containers are outside this unit.

The query’s ordinary contents and source child temporaries have already dropped when suppress_signal returns. The exact source for the proposed native copy is its real final Vec, with its real len/capacity/pointer. into_admitted retains that source wrapper through reservation, every borrowed copy, destination Box publication and final check, then drops it. This is different from retaining the whole Plan query and its guards. Neither a borrowed tape nor an OwnedHeap measurement proves a query reservation.

## Preserve the exact semantic and failure boundary

Keep prepare_projected, recipe construction, sample_prepared, ordinary tape policy, its single manual debit, all content preflights, control check, whole-list interval validation/zeroing and legacy merged_suppression in their current order. The new destination allocation begins only after all those succeed. The simple local seam intentionally retains the legacy intermediate Vec. Eliminating it is another optimization requiring a stronger producer contract.

No extra query invocation, validation sweep, content callback or provider callback belongs before the old query/debit/preflight boundaries. Do not replace malformed-range errors with a prior new quota error. The ordinary query does not forward successful partial work on Plan failure; preserve that receipt behavior in this narrow unit. Successful policy.work and lookup remain literal, including nested work fields. New host allocation/copy work uses existing native phases and actual WorkControl lanes, never canonical policy repricing.

For nonempty source length n, into_admitted uses begin_ranges with exactly n. Its real reserve_mask_storage covers destination vector Layout plus owning Storage Box before allocation, initializes the account shell lazily through make_room, bills existing AllocateVector/Map/AllocateStorage phases, checks control, and physically retains source and destination allocations through publication. No source bytes are credited to that account. Empty Plain returns default after a check and requests no new shell/vector/Box; a controller that already has a shell may keep it. Positive source capacity with len0 must be recorded as an existing ordinary allocation, not invented as an owned output.

Failure discards the local output PCM/result. Existing native RAII frees pending Box/vector before Charge. Accepted work is retained; there are no refunds. Shell initialization followed by later refusal can leave the real shell until controller teardown. A retained output may outlive PreparationBudget/ReadWork, the projected cache, source provider and StageAudio. Existing atomic Account ownership, not a request-local ledger, must remain its custodian.

## Tape policy is a separate ordinary source producer

AudioSignalTape owns actual PlacedRun signals, optional projection Arcs and boxed recursive policy_override tapes. Public construction initially uses PointCeil, checks a positive exactly contiguous partition, and accepts up to 4096 supplied runs. Materialized remap expansion has its distinct 65,536-run build allowance. Remapping carries the supplied boundary rule; policy reads the actual stored grid. Do not infer a new rule from the SignalSample type.

policy_inner validates limits, computes sample_count and route_end, then checks sample_start/end/order/route/count before allocating its aggregate vectors. For each nonempty covered segment it performs:
- the actual binary run_for comparisons, each charged against tape work;
- uncovered/nonadvancing validation;
- one run charge, subtraction and zero-remaining rejection;
- one child query with unchanged maximum_spans and the remaining work allowance;
- checked folding of child.work and lookup, then actual suppressed/contents extension.

An override always calls the nested tape’s policy_after_preserve. Otherwise the real run.signal.policy_on_grid uses this tape’s boundary and !after_preserve. After the loop it sorts, skips empty/reversed ranges, merges overlap/adjacency, and returns the complete content inventory. Aggregate work is shared; maximum_spans remains a per-provider query cap, not an aggregate inventory cap. Empty requests still perform the initial validation but no run query. Preserve output removes physical Source endpoint masks while retaining explicit silent Holds; nested binding/retime semantics stay with the ordinary policy engine.

C’s public AudioPointDomain::policy_admitted hardcodes PointCeil and endpoints=true. Its admitted signal_policy invokes structural_child_query, which rejects non-Structural providers. Ordinary signal_policy additionally handles source_voice_hold_carrier; its admitted counterpart does not. Public tape construction accepts a same-plan AudioSignal and projection scope checks definition/ancestry/repeats, not Structural provider kind. Therefore public projected tapes cannot truthfully be funneled through C merely because current simple fixtures are structural. There is no current tape policy_admitted API.

For a future true source unit, implement an actual AudioSignalTape::policy_after_preserve_admitted producer with an unmetered literal branch and one real issuer/query budget across actual run lookup, child construction, override recursion, contents and aggregate ranges. Reuse QueryBudget, exact Memory/Layout guards, GuardedBound inventory and the final typed Signal-policy carrier only after all supported provider paths have admitted parity. Preserve per-child caps, canonical old work and checked lookup folding. Additional storage/sort/copy work is separate and may refuse under unchanged limits. Do not re-debit a child already forwarded through the shared budget. Reusing finish_signal requires an explicit carrier-construction refactor and tape semantics tests, not calling Point policy then adjusting returned work.

Once that producer exists, existing AdmittedSignalPolicyQuery::into_suppression and the native same-issuer/exact-final-lease handoff can move the actual final Vec without a copy. All inventory guards must survive prepare/commit. Box-only destination overlap, exact source capacity lease, final exclusive preflight, no callback between prepare/commit, atomic native credit and source ledger disarm remain C’s real requirements. No ticket can be synthesized for an ordinary tape Vec. This larger unit still would not admit construction of the input tape/projection graph itself.

## Caches, reservations and callbacks

prepare_projected caches request-local PreparedBlock PCM/dependencies/depth, not suppression masks. Its cold path performs complete intrinsic preflight before reserve_stream/build_stage; active-recursion tracking and reservation release precede result publication. Projected PCM residency/disk bytes are admitted at publication. Hits recheck depth and freshly resolve/observe each dependency fingerprint. None of this reservation is evidence for ordinary policy Vec bytes.

stage_projection preflight independently queries ordinary input policy and processing, plus output PreserveTape policy in bounded chunks, and bills/preflights each in the existing order. build_stage and saved_stage also call suppress_signal for PCM zeroing and cache-mask hashing and discard its returned mask. They are out of the proposed local seam. Do not globally replace suppress_signal or imply those metadata temporaries are fixed. Retaining the existing cache key hash, provider revocation checks, complete-input preflight and hidden-history errors is mandatory.

Native destination reserve uses actual make_room: persistent cache/Original evictions and host-residency work may occur while the prepared Arc is pinned. WorkControl’s plan/cache scope and single deadline continue unchanged. Existing owned capacity propagation prevents ordinary-capacity double billing; no new reservation may manually add the same mask capacity again. PCM, route spans, dependencies, projected graph storage and policy inventories remain explicitly outside this destination-account claim.

## Before/failure/lifetime proof required before implementation credit

Freeze fresh actual pre-change bodies only after F is qualified/published by the parent. Preserve all earlier oracles. A small additive observer should distinguish policy/legacy-native-source storage from the separately admitted destination and record actual reachability, not infer masks from zero PCM.

Use checked public projections and real WAVs: one Source-only empty output policy, one explicit silent Hold with positive mask, one intrinsic nested override, and a fractional/negative retained-coordinate case that public validation actually accepts. Include cold/warm projection reuse and a fingerprint/depth/preflight failure. Existing stage_projection/tests.rs offers checked source/owned projection fixtures; routed tests supply real providers, but neither is dynamic proof of a nonempty projected policy mask. Keep rejected candidate constructions as errors.

At the native source-copy seam record actual source pointer/len/cap/values, destination pointer/len/cap/values, requested Layouts and real account snapshots before reserve/publication/drop. Positive source/destination pointers must differ; this is copy, not C transfer. Show source still live through destination completion and physical cleanup thereafter. Record source policy work/lookup/contents separately from accepted native phases/evictions and downstream translated-mask work.

Measure isolated destination quota/work thresholds only after an actual receipt proves policy/zeroing completed; distinguish them from the public whole-read minimum. Check exact minimum and one below with unchanged limits, every small accepted-work prefix, cancellation/deadline at reached allocation/copy boundaries, cleanup after a pending destination failure, and held output through request/provider/controller teardown. Do not invent total memory closure from an isolated destination cap. Empty success must not be padded with a fictional charge.

Compare complete successful routed outputs, PCM bits, typed ranges/clocks, provider/cache/dependency results and literal query receipts. New resource failures must be classified at their real boundary; no success/cap/weight normalization or residual attribution. The native account overlap, lazy shell retention, downstream Owned callbacks and complete query/source gaps are separate observations.
