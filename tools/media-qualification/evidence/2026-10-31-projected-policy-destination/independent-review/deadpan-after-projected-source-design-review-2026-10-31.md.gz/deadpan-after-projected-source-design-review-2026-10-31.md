# Provider-aware child kernel design review

GO for the bounded private child-kernel prerequisite. No design blocker found. Reviewed design 876cad9458ae9633483eb2d1f09cfa5e0e5629f144a6355a9510b6c05ad146ab; all 17 declared Scope pins match. Two additional implementation-feasibility sources are pinned here. This is design/source review only; no implementation, builds/native runs, Git or Gate acceptance is claimed.

## Actual gap and feasibility

The gap is real. AudioPointDomain::policy_admitted fixes PointCeil/endpoints=true. Its admitted signal_policy currently calls structural_child_query, which validates the grid then rejects every non-Structural provider. Ordinary signal_policy calls the provider-aware query_inner and separately applies output SourceVoice Hold carrier rules. Source input_signal and output_signal differ by apply_holds=false/true. Tape scope validation does not guarantee Structural providers.

A private explicit-grid provider-aware child assembler returning existing guarded SignalValue is the correct smallest boundary. Keep the Structural delegate and public Point behavior unchanged; add real guarded Source/Silence/Projected result construction instead of wrapping a completed ordinary query. All result-owned strings, definitions, repeat paths, content/headers/span arrays and constructed nested fields need genuine pre-admission. Preexisting borrowed provider/projection graphs remain an explicit input-construction gap.

Borrowed current-Hold selection is feasible: structural_query_admitted and span_admitted traverse the signal's actual structural fields without reading its provider selector. A sealed Source-output-only bridge can invoke that assembler with the same original signal fields and false/false stops, avoiding structural_hold_carrier's allocating self.clone. Keep this bridge private and restricted to Source{apply_holds:true}; do not relax the existing Point/Structural entry or substitute a root signal.

## Required order details for implementation

1. Match query_inner: Structural delegates first; other providers validate limits, reject RequiresOwnedInput, compute the requested rule's grid/boundaries and validate range before provider construction. Source/Silence check per-query span cap before each iteration and spend canonical 1 before actual span construction. Their empty query has canonical query work 0, but still constructs its real header. Projected reports canonical query work 1 even empty; preserve construction/validation before policy's non-Leaf rejection. Crucially, an empty Projected query has no non-Leaf span and must not be categorically rejected by policy. Test this separately from nonempty rejection.

2. Complete current query and current inventory handling before the Source-output carrier branch. Evaluate whether the carrier exists before requesting another child work limit. An unconditional child_limits call for Source input (apply_holds=false) can incorrectly reject an otherwise completed exact-budget policy. Only actual output carrier handling obtains that limit and queries. Source output still evaluates its carrier even for an empty policy request, as ordinary code does.

3. Preserve the complete carrier query before emitted-Hold fees/ranges. Filter only explicit silent-Hold spans; carrier Original, source endpoints, retained bindings and issuer identities must not enter independent voice inventory. A direct policy-only extraction can avoid an unused Hold-rule Vec/issuer allocation, but it must retain complete query validation and current canonical order. Otherwise build and guard the actual intermediate rules. Never call ordinary carrier clone/query and charge it retroactively.

4. Keep canonical counts and accepted additional work distinct. Nested admitted queries forward once through the same issuer/budget; no observe/redebit of already forwarded work. Preserve ordinary error strings/order with sufficient resources and retain actual admitted failure prefixes without claiming they equal ordinary unreturned work. Projected's literal work 1 needs an explicit completion/forwarding witness; do not silently turn its empty case into work 0 or its late policy error into early provider rejection.

## Tape/native follow-on remains separate

Tape uses its stored grid, direct child endpoints=!after_preserve, and override.policy_after_preserve regardless of the outer endpoint mode. Actual run_for comparison fees, per-run fee, coverage/nonadvance checks, remaining-work check, child work folding and checked lookup addition precede collection extension. maximum_spans is per logical provider query. Signal recursion restarts depth 0 per provider query; override traversal has no current independent depth cap/fee to invent.

Existing finish_signal already sorts, discards empty/reversed ranges, merges adjacency and creates a separately leased exact final Signal Vec. Its current provenance strings/inventory messages are Point-specific. Reuse through a private truthful Tape constructor, not a public lease extractor or Point factory, only after child/provider parity is established. Inventory/work buffers/source guards must survive future validation, zeroing and exclusive handoff; the native copy in G is not proof of this source factory.

## Bounded next-step contract

Qualify the private provider dispatcher plus Source-output Hold branch first. Preserve all 35 before payloads and leave Tape public APIs, native SignalInput/routed integration and G files unchanged. Freeze ordinary evidence from actual checked public SourceVoice input/output, silence/padding and accepted Projected/RequiresOwnedInput paths before changing construction. Test full/crop/empty/outside/reversed requests, both endpoint modes and grid rules, exact-limit branch selection, complete headers/content/lookup/error parity, real guard lifetime/cleanup and partial work. Keep failed setups and inaccessible native coverage explicit.

Plan recording-backend tests are protocol/construction evidence, not native allocator ownership proof. The existing G Structural Source/Hold fixture alone cannot establish SourceVoice or arbitrary projection semantics. The later Tape aggregate/final-Vec/native custody unit needs its own actual before/source-overlap/issuer/cancellation/cap proof. No whole-preparation or product Gate conclusion follows.
