# Projected-policy destination corpus draft, v3

This remains an unfrozen draft. It preserves v1 and v2 at sibling directories and records two distinct six-capture F sets in chronological order:
- final13 F qualification captures ran on the qualified working code before F was published; these are retained in the `published_f` section;
- the separate publication-time F captures ran after F publication, with embedded-before checkpoint 69698b678fd8a75dd644993d7d2a9846986d6911. Their recorded published source revision identifies the F release being observed, not necessarily the checkout HEAD at process execution.

Each publication-time capture pins its raw run receipt, full body, canonical output, proof, source manifest, stdout, stderr, source/binary guards, exact test command, runner script digest, Cargo artifact pins, and executable digest. The validator checks these links and compares the complete source-before map to the hashed source manifest. It also validates both F sets and the later G-before receipts. The run receipt and source manifest identify the source actually used; the published revision field alone does not prove the checkout HEAD.

The immutable oracle remains a separate 34-entry pin set. The classic F comparison retains 744 native requests, ten internal cases, four transfer entries, exact output field counts, interval totals, five historical-body checks, and the classic projection that excludes only the additive top-level components_producer_cases section. That section has its own six-capture F analysis. Neither six-capture F set is rewritten into one canonical body.

All observed work counters and raw hashes remain literal. Independent capture work can vary due pointer-sensitive lookups; the manifest preserves values and artifacts without normalization or replacing them with a historical numeric golden. F-specific observed work differences are not a blanket G exception.

G native3 is the selected source-ready baseline, with native2 retained as historical evidence. Main and Scope native3 bodies match at 58,670 bytes and canonical outputs match at 23,896 bytes. Source-only empty returns an unowned Plain mask with capacity zero. Explicit silent Hold returns the actual [615,768) policy range in a Plain mask with capacity one; its source Vec has capacity one. All four cases record projected residency of 768 frames and zero projected disk bytes. The shared-renderer pair still records zero StageAudio cache entries before and after, so no warm cache reuse is claimed. These before captures do not establish destination ownership or quota closure.

## Proposed portable repository corpus

At final freeze, prefer a portable fixture such as crates/deadpan-audio/tests/fixtures/projected-policy-destination-baseline-v1/corpus.json. Store the compact manifest, the literal selected G native3 body, and the unchanged 34 oracle pins. Represent F captures by stable logical archive paths plus byte counts and SHA-256 values: map the final13 six to their existing F archive inventory entries and the postpublication six to published-f-before logical entries. Keep the complete F work observations and exact hashes available through those archive references. Absolute /tmp paths can remain in the audit draft, but must not be the sole durable corpus authority.

## Validator

Run python3 validate_draft.py --main-root MAIN_CHECKOUT --scoped-root SCOPED_CHECKOUT. It checks all 34 oracle pins in both roots, every pinned F/G artifact, source and binary guard equality, command and runner linkage, and proof-to-body/canonical/source-manifest digests. It does not compare post-G output, make a final acceptance decision, or freeze the corpus.
