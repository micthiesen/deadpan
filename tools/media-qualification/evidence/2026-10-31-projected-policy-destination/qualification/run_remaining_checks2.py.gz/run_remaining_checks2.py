from pathlib import Path
import subprocess,json
s=Path(__file__).resolve().parent
jobs=[
("main","projected-strict2-main",["cargo","xtask","check","--no-test"]),
("scoped","projected-clippy2-scoped",["cargo","clippy","-p","deadpan-audio","--all-targets","--","-D","warnings"]),
("main","projected-fmt2-main",["cargo","fmt","--all","--","--check"]),
("scoped","projected-fmt2-scoped",["cargo","fmt","--all","--","--check"]),
("main","projected-doc2-main",["cargo","test","-p","deadpan-audio","--doc"]),
("scoped","projected-doc2-scoped",["cargo","test","-p","deadpan-audio","--doc"]),
("main","projected-hygiene2-main",["cargo","xtask","hygiene"]),
("scoped","projected-hygiene2-scoped",["cargo","xtask","hygiene"]),
]
results=[]
for variant,label,command in jobs:
    runner=s/("run_active_qualified.py" if variant=="main" else "run_scoped_active_qualified.py")
    result=subprocess.run(["python",str(runner),label,"--",*command])
    results.append({"variant":variant,"label":label,"exit_code":result.returncode})
with (s/"remaining-checks2-summary.json").open("x") as file:json.dump(results,file,indent=2);file.write(chr(10))
assert all(row["exit_code"]==0 for row in results),results
