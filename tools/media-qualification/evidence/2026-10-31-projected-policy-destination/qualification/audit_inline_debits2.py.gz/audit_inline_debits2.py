from pathlib import Path
import hashlib
import json

s = Path(__file__).resolve().parent
sources = sorted(s.glob('projected-final2-active*-canonical.json'))
assert len(sources) == 6
out = []
for path in sources:
    raw = path.read_bytes()
    body = json.loads(raw)
    cases = []
    for case in body['components_producer_cases']['cases']:
        rows = case['components_trace']['rows']
        accepted_marks = 0
        for row in rows:
            before = row['source_plan_work_before']
            initialized = row['source_init']
            assert initialized['success'] is True
            assert initialized['plan_work_after'] - before == 4
            assert initialized['cache_work_after'] == row['source_cache_work_before']
            assert row['inline_words_initial'] == [0, 0, 0, 0]
            marks = row['marks']
            if marks['written_count']:
                for attempt, accepted in (('first_attempt', 'first_accepted_work_after'), ('last_attempt', 'last_accepted_work_after')):
                    assert marks[accepted]['plan_work'] - marks[attempt]['plan_work_before'] == 1
                    assert marks[accepted]['cache_plan_work'] == marks[attempt]['cache_plan_work_before']
                accepted_marks += marks['written_count']
            assert sum(word.bit_count() for word in row['inline_words_latest']) == marks['written_count']
        cases.append({'name': case['name'], 'rows': len(rows), 'actual_zero_units_per_row': 4, 'accepted_marks': accepted_marks, 'first_and_last_actual_mark_units': 1 if accepted_marks else None})
    out.append({'path': path.name, 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest(), 'cases': cases})
output = s / 'inline-local-debits2.json'
with output.open('x') as file:
    json.dump(out, file, indent=2)
    file.write('\n')
print(json.dumps({'captures': len(out), 'rows_checked': sum(case['rows'] for capture in out for case in capture['cases']), 'output_sha256': hashlib.sha256(output.read_bytes()).hexdigest()}))
