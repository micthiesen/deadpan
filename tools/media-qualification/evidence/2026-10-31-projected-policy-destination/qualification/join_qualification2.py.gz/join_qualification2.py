from pathlib import Path
import hashlib
import json

s = Path(__file__).resolve().parent

def pin(path):
    raw = path.read_bytes()
    return {'path': path.relative_to(s).as_posix(), 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}

records = []
builds = {}
matrices = {}
for variant in ('main', 'scoped'):
    build_label = 'projected-active-build2-' + variant
    build = json.loads((s / (build_label + '.json')).read_text())
    assert build['exit_code'] == 0 and build['sources_unchanged']
    source = build['source_after']
    assert build['source_before'] == source
    binaries = json.loads((s / (build_label + '-pins.json')).read_text())
    assert len(binaries) == len({row['name'] for row in binaries}) == 21
    for binary in binaries:
        artifact = binary['artifact']
        assert artifact['profile']['opt_level'] == '2'
        assert artifact['profile']['overflow_checks'] and artifact['profile']['debug_assertions']
        assert hashlib.sha256(Path(binary['path']).read_bytes()).hexdigest() == binary['sha256']
    builds[variant] = {'receipt': pin(s / (build_label + '.json')), 'pins': pin(s / (build_label + '-pins.json')), 'source_inputs': len(source)}
    matrix_path = s / ('projected-matrix2-' + variant + '-matrix.json')
    matrix = json.loads(matrix_path.read_text())
    assert len(matrix) == 21 and {row['target'] for row in matrix} == {row['name'] for row in binaries}
    labels = [row['run'] for row in matrix]
    labels += ['projected-final2-before-' + mode + '-' + variant for mode in ('old', 'intervals', 'policy', 'root', 'shared', 'components')]
    labels += ['projected-final2-' + mode + '-' + variant for mode in ('active', 'active2', 'active3')]
    labels += ['projected-final2-source-before-' + variant]
    labels += ([
        'projected-strict2-main', 'projected-fmt2-main', 'projected-doc2-main', 'projected-hygiene2-main'
    ] if variant == 'main' else [
        'projected-clippy2-scoped', 'projected-fmt2-scoped', 'projected-doc2-scoped', 'projected-hygiene2-scoped'
    ])
    for label in labels:
        path = s / (label + '.json')
        run = json.loads(path.read_text())
        assert run['exit_code'] == 0 and run['sources_unchanged'] and run['binaries_unchanged'], label
        assert run['source_before'] == run['source_after'] == source, label
        assert run['binary_before'] == run['binary_after'], label
        for absolute, expected in run['streams'].items():
            stream = Path(absolute)
            raw = stream.read_bytes()
            assert expected == {'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}, label
        records.append({'variant': variant, 'label': label, 'receipt': pin(path), 'command': run['command'], 'environment': run['environment'], 'seconds': run['seconds']})
    matrices[variant] = pin(matrix_path)

roots = {'main': Path('/Users/michael/Code/deadpan'), 'scoped': Path('/tmp/deadpan-query-groundwork-2026-10-26/scoped')}
owned = set(json.loads((s / 'owned-code-paths.json').read_text()))
unowned = {}
for variant, root in roots.items():
    original = json.loads((s / (variant + '-initial-authority.json')).read_text())
    checked = 0
    for name, expected in original.items():
        if name in owned:
            continue
        raw = (root / name).read_bytes()
        assert expected == {'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}, name
        checked += 1
    unowned[variant] = checked
    oracle = json.loads((s / 'immutable-oracle-pins35.json').read_text())
    assert len(oracle) == 35
    for row in oracle:
        assert hashlib.sha256((root / row['path']).read_bytes()).hexdigest() == row['sha256']

for name in owned:
    assert (roots['main'] / name).read_bytes() == (roots['scoped'] / name).read_bytes(), name

value = {
    'schema': 'deadpan.projected-policy-destination.qualification-join.v1',
    'base_revision': (s / 'base-revision.txt').read_text().strip(),
    'builds': builds, 'matrices': matrices,
    'matrix_summary': json.loads((s / 'audio-matrix2-summary.json').read_text()),
    'runs': records, 'immutable_payloads': 35,
    'all_owned_paths_equal': len(owned), 'unowned_initial_inputs_exact': unowned,
    'capture_analysis': 'pending independent exhaustive analysis; this join grants no capture-semantic or publication acceptance',
    'source_scope': 'Projected Signal destination copy only; ordinary policy sources, exhausted vectors and whole preparation remain outside this claim.',
}
output = s / 'projected-final2-qualification-join.json'
with output.open('x') as file:
    json.dump(value, file, indent=2)
    file.write('\n')
print(json.dumps({'runs': len(records), 'owned': len(owned), 'unowned': unowned, 'output': pin(output)}))
