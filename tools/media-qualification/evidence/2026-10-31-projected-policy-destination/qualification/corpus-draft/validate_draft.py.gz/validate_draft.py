#!/usr/bin/env python3
"""Integrity and shape checker for the projected-policy corpus draft.

This is not a freeze tool and does not compare post-G output.
"""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
import sys

MANIFEST = Path(__file__).with_name("corpus-manifest-draft.json")


def check_record(record: dict, label: str) -> None:
    path = Path(record["path"])
    raw = path.read_bytes()
    actual = hashlib.sha256(raw).hexdigest()
    if len(raw) != record["bytes"] or actual != record["sha256"]:
        raise ValueError(f"{label}: size/hash mismatch: {path}")


def check_oracle(manifest: dict, root: Path) -> None:
    for pin in manifest["immutable_oracle"]["entries"]:
        path = root / pin["path"]
        actual = hashlib.sha256(path.read_bytes()).hexdigest()
        if actual != pin["sha256"]:
            raise ValueError(f"oracle digest mismatch: {path}")


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--main-root", type=Path)
    parser.add_argument("--scoped-root", type=Path)
    args = parser.parse_args()
    manifest = json.loads(MANIFEST.read_text())
    if manifest["state"] != "draft_pending_review":
        raise ValueError("draft state changed; this script cannot freeze a corpus")

    check_record(manifest["immutable_oracle"]["pins_file"], "oracle pin list")
    check_record(manifest["published_f"]["publication_proof"], "F publication proof")
    for root in (args.main_root, args.scoped_root):
        if root is not None:
            check_oracle(manifest, root)

    f_captures = manifest["published_f"]["six_fresh_captures"]
    expected_f = {(mode, variant) for mode in ("active", "active2", "active3")
                  for variant in ("main", "scoped")}
    if len(f_captures) != 6 or {(x["mode"], x["variant"]) for x in f_captures} != expected_f:
        raise ValueError("F set must be exactly six mode/variant captures")
    for capture in f_captures:
        for name, record in capture["artifacts"].items():
            check_record(record, f'F {capture["mode"]}/{capture["variant"]} {name}')
        proof = json.loads(Path(capture["artifacts"]["-proof"]["path"]).read_text())
        canonical = capture["artifacts"]["-canonical"]
        if (proof["sha256"], proof["bytes"]) != (canonical["sha256"], canonical["bytes"]):
            raise ValueError("F proof does not bind canonical capture")
        if proof["binary_sha256"] != capture["binary_sha256"]:
            raise ValueError("F binary digest mismatch")
        if proof["source_manifest_sha256"] != capture["proof_source_manifest_sha256"]:
            raise ValueError("F source-manifest digest mismatch")
        if proof["base_revision"] != manifest["published_f"]["embedded_before_checkpoint"]:
            raise ValueError("F source revision mismatch")

    g_captures = manifest["g_before_pending"]["captures"]
    if {x["variant"] for x in g_captures} != {"main", "scoped"} or len(g_captures) != 2:
        raise ValueError("G before set must contain one capture per root")
    for capture in g_captures:
        for name, record in capture["artifacts"].items():
            check_record(record, f'G {capture["variant"]} {name}')
        run = json.loads(Path(capture["artifacts"][".json"]["path"]).read_text())
        if run["exit_code"] != 0 or not run["sources_unchanged"] or not run["binaries_unchanged"]:
            raise ValueError(f'G run proof failed: {capture["variant"]}')
        canonical = json.loads(Path(capture["artifacts"]["-canonical.json"]["path"]).read_text())
        for case_name in ("source_only_empty", "explicit_silent_hold_positive",
                          "shared_renderer_first_empty", "shared_renderer_second_positive"):
            if canonical[case_name]["result"] != "Ok":
                raise ValueError(f'G case not successful: {capture["variant"]}/{case_name}')

    for record in manifest["published_f"]["analysis_authorities"].values():
        check_record(record, "F analysis")
    print("Pinned F and G-before artifacts passed integrity checks.")
    print("Immutable oracle roots checked:", sum(root is not None for root in (args.main_root, args.scoped_root)))
    print("State:", manifest["state"], "(review required; this script did not freeze)")
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except (KeyError, OSError, ValueError, json.JSONDecodeError) as exc:
        print(f"validation failed: {exc}", file=sys.stderr)
        raise SystemExit(1)
