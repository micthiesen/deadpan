# Projected-policy destination corpus draft

This is still a draft. The actual G-before capture is now present for both roots, but the corpus has not been frozen; parent review and a completed oracle join remain necessary.

## Inputs and comparison contract

- corpus-manifest-draft.json carries the 34 immutable oracle pins from the parent qualification directory.
- It separately pins six fresh F captures: active, active2, and active3 for Main and Scope. For each it records the canonical serialized capture, full body, proof, source manifest, run JSON, stdout, and stderr by path, byte count, and SHA-256.
- F proof records bind each canonical capture to the binary digest, source-manifest digest, source revision, and source input count. The classic analyses carry the 744 native requests, ten internal cases, four transfer entries, exact output field counts, interval totals, five historical-body checks, and the all-six classic projection digest. That projection omits only the additive top-level components_producer_cases field, which the F analysis validates separately.
- The six full F body hashes are retained literally. They are not required to match each other because observed pointer-sensitive plan-work counters can vary between independent captures. The manifest keeps the work-counter contract explicit: retain values, do not erase or normalize counters, and do not carry F-specific path exceptions forward as a G whitelist.
- G-before has four actual checked public routed cases in each root. Main and Scope bodies are byte-identical at 58,362 bytes; canonical files are byte-identical at 23,668 bytes. Both captures retain source-only empty output and a real explicit silent-Hold positive range [615,768), with exact f32 bit arrays, public block fields, capacities, source-ready rows, command/run receipts, guarded-build pin files, and executable digests. The source Vec has capacity one in the positive case; the public pre-G mask is still Plain with capacity one. Empty has zero mask capacity. Renderer cache counts remain zero in the shared-renderer pair, so no cache reuse is claimed.
- G-before remains source-ready baseline evidence. It does not establish destination ownership, final routed-mask residency, quota closure, nested overrides, or negative/fractional retained-coordinate behavior.

The F analysis and G-before proofs are linked from the manifest; no large capture bodies were copied into this draft directory.

## Validator skeleton

Run python3 validate_draft.py --main-root MAIN_CHECKOUT --scoped-root SCOPED_CHECKOUT to verify the 34 immutable files in both trees and every pinned F/G artifact. Omitting a root skips only that root's oracle-file checks. The script checks artifact integrity, command outcomes, and proof linkage. It does not compare post-G behavior, certify ownership, or freeze the draft.
