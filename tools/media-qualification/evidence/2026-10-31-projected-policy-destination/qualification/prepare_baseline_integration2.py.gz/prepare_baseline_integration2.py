from pathlib import Path
import json,hashlib,difflib,sys
s=Path(__file__).resolve().parent
candidate=Path(sys.argv[1])
roots={"main":Path("/Users/michael/Code/deadpan"),"scoped":Path("/tmp/deadpan-query-groundwork-2026-10-26/scoped")}
paths=["crates/deadpan-audio/src/routed.rs","crates/deadpan-audio/src/projected_mask_before_trace.rs","crates/deadpan-audio/src/routed_projected_mask_tests.rs"]
pins=json.loads((candidate/"source-pins.json").read_text())["files"]
patches=[]
for variant,root in roots.items():
    initial=json.loads((s/f"{variant}-initial-authority.json").read_text())
    for name,entry in initial.items():
        assert hashlib.sha256((root/name).read_bytes()).hexdigest()==entry["sha256"],name
    for name in paths:
        before=(root/name).read_text() if (root/name).exists() else None
        after=(candidate/"new"/name).read_text()
        if before is not None:
            assert hashlib.sha256(before.encode()).hexdigest()==pins[name],name
            dest=s/"baseline-before"/variant/name
            dest.parent.mkdir(parents=True,exist_ok=True)
            if dest.exists(): assert dest.read_text()==before
            else:
                with dest.open("x") as f:f.write(before)
            diff=list(difflib.unified_diff(before.splitlines(keepends=True),after.splitlines(keepends=True)))
            patch="*** Begin Patch\n*** Update File: "+str(root/name)+"\n"
            for line in diff[2:]:
                patch+=("@@\n" if line.startswith("@@") else line)
            patch+="*** End Patch\n"
        else:
            patch="*** Begin Patch\n*** Add File: "+str(root/name)+"\n"
            patch+="".join("+"+line+"\n" for line in after.splitlines())
            patch+="*** End Patch\n"
        patches.append({"variant":variant,"path":name,"patch":patch,"after_sha256":hashlib.sha256(after.encode()).hexdigest()})
out=s/"baseline-integration-plan2.json"
with out.open("x") as f:json.dump(patches,f,indent=2);f.write("\n")
print(json.dumps(patches))
