from pathlib import Path
import subprocess,sys
s=Path(__file__).resolve().parent
for variant in ("main","scoped"):
    build="projected-active-build2-"+variant
    for mode in ("old","intervals","policy","root","shared","components"):
        label="projected-final2-before-"+mode+"-"+variant
        subprocess.run(["python",str(s/"capture_historical_after_g.py"),variant,build,mode,label],check=True)
for repeat in ("active","active2","active3"):
    for variant in ("main","scoped"):
        build="projected-active-build2-"+variant
        label="projected-final2-"+repeat+"-"+variant
        subprocess.run(["python",str(s/"capture_after_g.py"),variant,build,"projected",label],check=True)
