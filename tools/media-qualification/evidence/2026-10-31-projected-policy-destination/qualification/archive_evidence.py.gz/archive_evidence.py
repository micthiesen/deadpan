from pathlib import Path
import gzip
import hashlib
import json

s = Path(__file__).resolve().parent
root = Path('/Users/michael/Code/deadpan')
scope = Path('/tmp/deadpan-query-groundwork-2026-10-26/scoped')
out = root / 'tools/media-qualification/evidence/2026-10-31-projected-policy-destination'
assert not out.exists()
allowed = {'.json', '.md', '.txt', '.py', '.patch', '.diff', '.rs', '.stdout', '.stderr'}
excluded = {
    'archive-proof.json', 'qualification-draft.md', 'publication-proof.json',
    'index-publication-audit.json', 'publication-inputs.json', 'publication-sources.txt',
    'publication-index-info.txt', 'publication-blobs.txt', 'baseline-integration-plan.json',
    'baseline-integration-plan2.json',
}
files = {}
for path in sorted(s.rglob('*')):
    if not path.is_file() or path.suffix not in allowed or '__pycache__' in path.parts:
        continue
    relative = path.relative_to(s)
    if relative.parts[:2] in (('baseline-before', 'main'), ('production-before', 'main')):
        continue
    if path.name in excluded:
        continue
    files['qualification/' + relative.as_posix()] = path

reports = [
    'deadpan-after-components-policy-design-2026-10-31.md',
    'deadpan-projected-mask-design-review-2026-10-31.md',
    'deadpan-routed-projected-before-review-2026-10-31.md',
    'deadpan-routed-projected-before-review-v2-2026-10-31.md',
    'deadpan-routed-projected-before-review-v4-2026-10-31.md',
    'deadpan-routed-projected-before-capture-review-2026-10-31.md',
    'deadpan-projected-before-corpus-review-2026-10-31.md',
    'deadpan-projected-copy-lifetime-review-2026-10-31.md',
    'deadpan-projected-destination-final-source-review-2026-10-31.md',
    'deadpan-projected-final-capture-review-2026-10-31.md',
    'deadpan-after-projected-destination-source-design-2026-10-31.md',
    'deadpan-after-projected-source-design-review-2026-10-31.md',
]
for name in reports:
    path = Path('/tmp') / name
    assert path.is_file(), path
    files['independent-review/' + name] = path
    adjacent = path.with_suffix('.pins.json')
    if adjacent.is_file():
        files['independent-review/' + adjacent.name] = adjacent

directories = [
    'deadpan-projected-mask-design-review-2026-10-31',
    'deadpan-projected-signal-mask-copy-candidate-2026-10-31',
    'deadpan-routed-projected-mask-test-contract-2026-10-31',
    'deadpan-routed-projected-mask-before-candidate-2026-10-31',
    'deadpan-routed-projected-mask-before-candidate-v2-2026-10-31',
    'deadpan-routed-projected-mask-before-candidate-v3-2026-10-31',
    'deadpan-routed-projected-mask-before-candidate-v4-2026-10-31',
    'deadpan-projected-copy-lifetime-candidate-2026-10-31',
    'deadpan-projected-active-capture-candidate-2026-10-31',
    'deadpan-projected-active-capture-candidate-2026-10-31-v2',
    'deadpan-projected-final-capture-review-2026-10-31',
    'deadpan-projected-destination-final-source-review-2026-10-31',
    'deadpan-projected-copy-lifetime-review-2026-10-31',
    'deadpan-projected-before-corpus-review-2026-10-31',
    'deadpan-routed-projected-before-capture-review-2026-10-31',
    'deadpan-after-projected-source-design-review-2026-10-31',
]
for name in directories:
    directory = Path('/tmp') / name
    assert directory.is_dir(), directory
    for path in sorted(directory.rglob('*')):
        if not path.is_file() or path.suffix not in allowed or '__pycache__' in path.parts:
            continue
        relative = path.relative_to(directory)
        if relative.parts[:2] in (('before', 'main'), ('source', 'main')):
            continue
        files['proposal-and-audit/' + name + '/' + relative.as_posix()] = path

for name in json.loads((s / 'owned-code-paths.json').read_text()):
    files['shipping-source/' + name] = scope / name
for name in json.loads((s / 'owned-doc-paths.json').read_text()):
    files['documentation/' + name] = scope / name

rows = []
for key, source in sorted(files.items()):
    data = source.read_bytes()
    compressed = gzip.compress(data, compresslevel=6, mtime=0)
    destination = out / (key + '.gz')
    destination.parent.mkdir(parents=True, exist_ok=True)
    with destination.open('xb') as file:
        file.write(compressed)
    assert gzip.decompress(destination.read_bytes()) == data
    rows.append({'path': key, 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest(),
                 'stored_path': key + '.gz', 'stored_bytes': len(compressed),
                 'stored_sha256': hashlib.sha256(compressed).hexdigest()})
    if len(rows) % 100 == 0:
        print(json.dumps({'archived': len(rows), 'total': len(files)}), flush=True)

body = {
    'schema': 'deadpan-qualified-gzip-evidence-v1',
    'scope': 'Projected PreserveTape Signal destination copy after ordinary suppression; exact isolated native boundaries, four public before/after cases, unchanged 744+42 compatibility outputs and literal 80-path work variance. Ordinary policy sources and whole preparation remain outside this claim.',
    'base_revision': (s / 'base-revision.txt').read_text().strip(),
    'records': rows, 'expanded_bytes': sum(row['bytes'] for row in rows),
    'stored_bytes': sum(row['stored_bytes'] for row in rows),
    'excluded': 'Pinned executables, raw Main source snapshots and raw Main patch plans; shipping source is Scope only. An initial failed analyzer source was unavailable and its provenance explicitly records that limitation.',
}
data = (json.dumps(body, indent=2) + '\n').encode()
with (out / 'inventory.json').open('xb') as file:
    file.write(data)
proof = {'inventory_path': (out / 'inventory.json').relative_to(root).as_posix(),
         'inventory_sha256': hashlib.sha256(data).hexdigest(), 'records': len(rows),
         'expanded_bytes': body['expanded_bytes'], 'stored_bytes': body['stored_bytes']}
with (s / 'archive-proof.json').open('x') as file:
    json.dump(proof, file, indent=2)
    file.write('\n')
print(json.dumps(proof))
