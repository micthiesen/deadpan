from pathlib import Path
import hashlib
import json

s = Path(__file__).resolve().parent
f_archive = Path('/Users/michael/Code/deadpan/tools/media-qualification/evidence/2026-10-31-components-mask-ownership')
f_inventory = json.loads((f_archive / 'inventory.json').read_text())
f_records = {row['path']: row for row in f_inventory['records']}
draft_path = s / 'corpus-draft-v3/corpus-manifest-draft.json'
draft = json.loads(draft_path.read_text())
g_archive = 'tools/media-qualification/evidence/2026-10-31-projected-policy-destination'

def record(pin, namespace):
    path = Path(pin['path']).resolve()
    if namespace == 'f':
        logical = 'qualification/' + path.name
        archived = f_records[logical]
        assert archived['sha256'] == pin['sha256'] and archived['bytes'] == pin['bytes']
        inventory = 'tools/media-qualification/evidence/2026-10-31-components-mask-ownership/inventory.json'
    else:
        logical = 'qualification/' + path.relative_to(s).as_posix()
        inventory = g_archive + '/inventory.json'
    return {'inventory': inventory, 'record': logical, 'bytes': pin['bytes'], 'sha256': pin['sha256']}

final_f = []
for capture in draft['published_f']['six_fresh_captures']:
    final_f.append({
        'variant': capture['variant'], 'mode': capture['mode'],
        'binary_sha256': capture['binary_sha256'],
        'source_manifest_sha256': capture['proof_source_manifest_sha256'],
        'artifacts': {key: record(value, 'f') for key, value in capture['artifacts'].items()},
    })
publication_f = []
for capture in draft['publication_time_f']['six_captures']:
    publication_f.append({
        'variant': capture['variant'], 'repeat': capture['repeat'],
        'binary_sha256': capture['binary_sha256'],
        'source_manifest_sha256': capture['source_manifest_sha256'],
        'artifacts': {value['role']: record(value, 'g') for value in capture['artifacts']},
    })

before = json.loads((s / 'projected-before-native3-main-body.json').read_text())
assert before == json.loads((s / 'projected-before-native3-scoped-body.json').read_text())
g_captures = []
for variant in ('main', 'scoped'):
    label = 'projected-before-native3-' + variant
    receipt = json.loads((s / (label + '.json')).read_text())
    binary, = receipt['binary_before'].values()
    artifacts = {}
    for suffix in ('.json', '.stdout', '.stderr', '-body.json', '-canonical.json', '-proof.json'):
        path = s / (label + suffix)
        raw = path.read_bytes()
        artifacts[suffix] = record({'path': str(path), 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}, 'g')
    g_captures.append({'variant': variant, 'binary_sha256': binary['sha256'], 'artifacts': artifacts})

variable_work = dict(draft['published_f']['variable_work_contract'])
variable_work['known_observation_refs'] = {key: record(pin, 'f') for key, pin in variable_work['known_observation_refs'].items()}

value = {
    'schema': 'deadpan.projected-policy-destination-before-corpus.v1',
    'published_before_source': '59874646dba6974da77e2cad08e9bc4822fd5afe',
    'claim': 'Immutable source-ready and numerical baseline before projected PreserveTape destination admission.',
    'immutable_predecessors': draft['immutable_oracle']['entries'],
    'components_final13': final_f,
    'components_after_publication': publication_f,
    'components_comparison': {
        'classic_invariants': draft['published_f']['classic_invariants'],
        'variable_work_contract': variable_work,
        'rule': 'All twelve literal captures remain evidence. Neither full-body equality nor membership in these hashes is a future oracle. Preserve outputs, errors, capacities, ownership and local debit invariants; retain and explain every changed work value. F-specific reviewed paths do not authorize G differences.',
    },
    'source_ready_before': before,
    'source_ready_captures': g_captures,
    'audit_authority': {
        'inventory': g_archive + '/inventory.json',
        'record': 'qualification/corpus-draft-v3/corpus-manifest-draft.json',
        'sha256': hashlib.sha256(draft_path.read_bytes()).hexdigest(),
    },
    'limitations': [
        'Ordinary PreserveTape policy source queries and their returned Vec are unadmitted.',
        'Source-ready receipts do not establish destination ownership or final routed-mask residency.',
        'The observed projected PCM is request-local; persistent StageAudio cache counts are zero.',
        'The baseline does not establish nested overrides, negative or fractional retained coordinates, or whole preparation.',
    ],
}
raw = (json.dumps(value, indent=2) + '\n').encode()
output = s / 'portable-corpus-candidate2.json'
assert '/tmp/' not in raw.decode(), 'portable baseline must not depend solely on host scratch paths'
with output.open('xb') as file:
    file.write(raw)
print(json.dumps({'path': str(output), 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}))
