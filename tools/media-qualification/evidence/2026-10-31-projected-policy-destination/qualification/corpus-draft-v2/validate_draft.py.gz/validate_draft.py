#!/usr/bin/env python3
"""Integrity and shape checker for the projected-policy corpus draft.

This is not a freeze tool and does not compare post-G output.
"""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
import sys

MANIFEST = Path(__file__).with_name("corpus-manifest-draft.json")


def check_record(record: dict, label: str) -> None:
    path = Path(record["path"])
    raw = path.read_bytes()
    actual = hashlib.sha256(raw).hexdigest()
    if len(raw) != record["bytes"] or actual != record["sha256"]:
        raise ValueError(f"{label}: size/hash mismatch: {path}")


def check_oracle(manifest: dict, root: Path) -> None:
    for pin in manifest["immutable_oracle"]["entries"]:
        path = root / pin["path"]
        actual = hashlib.sha256(path.read_bytes()).hexdigest()
        if actual != pin["sha256"]:
            raise ValueError(f"oracle digest mismatch: {path}")


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--main-root", type=Path)
    parser.add_argument("--scoped-root", type=Path)
    args = parser.parse_args()
    manifest = json.loads(MANIFEST.read_text())
    if manifest["state"] != "draft_pending_review_v2":
        raise ValueError("draft state changed; this script cannot freeze a corpus")

    check_record(manifest["immutable_oracle"]["pins_file"], "oracle pin list")
    check_record(manifest["published_f"]["publication_proof"], "F publication proof")
    for root in (args.main_root, args.scoped_root):
        if root is not None:
            check_oracle(manifest, root)

    f_captures = manifest["published_f"]["six_fresh_captures"]
    expected_f = {(mode, variant) for mode in ("active", "active2", "active3")
                  for variant in ("main", "scoped")}
    if len(f_captures) != 6 or {(x["mode"], x["variant"]) for x in f_captures} != expected_f:
        raise ValueError("F set must be exactly six mode/variant captures")
    for capture in f_captures:
        for name, record in capture["artifacts"].items():
            check_record(record, f'F {capture["mode"]}/{capture["variant"]} {name}')
        proof = json.loads(Path(capture["artifacts"]["-proof"]["path"]).read_text())
        canonical = capture["artifacts"]["-canonical"]
        if (proof["sha256"], proof["bytes"]) != (canonical["sha256"], canonical["bytes"]):
            raise ValueError("F proof does not bind canonical capture")
        if proof["binary_sha256"] != capture["binary_sha256"]:
            raise ValueError("F binary digest mismatch")
        if proof["source_manifest_sha256"] != capture["proof_source_manifest_sha256"]:
            raise ValueError("F source-manifest digest mismatch")
        if proof["base_revision"] != manifest["published_f"]["embedded_before_checkpoint"]:
            raise ValueError("F source revision mismatch")
        for item in capture["build_artifacts"].values():
            check_record(item, f'F build artifact {capture["variant"]}')
        run = json.loads(Path(capture["artifacts"]["run_json"]["path"]).read_text())
        if run["exit_code"] != 0 or not run["sources_unchanged"] or not run["binaries_unchanged"]:
            raise ValueError(f'F run/source/binary guard failed: {capture["mode"]}/{capture["variant"]}')
        if run["runner_sha256"] != capture["build_artifacts"]["runner"]["sha256"]:
            raise ValueError(f'F runner mismatch: {capture["mode"]}/{capture["variant"]}')
        if proof["binary_sha256"] != capture["build_artifacts"]["binary"]["sha256"]:
            raise ValueError(f'F binary artifact mismatch: {capture["mode"]}/{capture["variant"]}')
        if Path(run["command"][0]).resolve() != Path(capture["build_artifacts"]["binary"]["path"]).resolve():
            raise ValueError(f'F command binary mismatch: {capture["mode"]}/{capture["variant"]}')
        if "capture_active_components_mask_after_v1" not in " ".join(run["command"]):
            raise ValueError(f'F command test mismatch: {capture["mode"]}/{capture["variant"]}')
        if run["source_before"] != run["source_after"] or run["binary_before"] != run["binary_after"]:
            raise ValueError(f'F source/binary changed during run: {capture["mode"]}/{capture["variant"]}')
        source_manifest = json.loads(Path(capture["artifacts"]["-source-manifest"]["path"]).read_text())
        source_root = Path(run["cwd"]).resolve()
        observed = {
            Path(name).resolve().relative_to(source_root).as_posix(): metadata
            for name, metadata in run["source_before"].items()
        }
        if observed != source_manifest:
            raise ValueError(f'F source manifest linkage mismatch: {capture["mode"]}/{capture["variant"]}')

    publication = manifest["publication_time_f"]
    check_record(publication["proof_file"], "publication-time F index")
    if len(publication["six_captures"]) != 6:
        raise ValueError("publication-time F set must contain six captures")
    publication_index = json.loads(Path(publication["proof_file"]["path"]).read_text())
    index_by_key = {(row["variant"], row["repeat"]): row for row in publication_index}
    if len(index_by_key) != 6:
        raise ValueError("publication-time F index must contain six unique entries")
    for capture in publication["six_captures"]:
        index_row = index_by_key[(capture["variant"], capture["repeat"])]
        if (index_row["capture"] != capture["capture"]
                or index_row["published_source_revision"] != capture["published_source_revision"]
                or index_row["embedded_before_checkpoint"] != capture["embedded_before_checkpoint"]):
            raise ValueError(f'publication-time F index metadata mismatch: {capture["capture"]}')
        for indexed_file in index_row["files"]:
            actual_path = Path(publication["proof_file"]["path"]).parent / indexed_file["path"]
            if not any(Path(row["path"]).resolve() == actual_path.resolve()
                       and row["bytes"] == indexed_file["bytes"]
                       and row["sha256"] == indexed_file["sha256"]
                       for row in capture["artifacts"]):
                raise ValueError(f'publication-time F index file mismatch: {capture["capture"]}/{indexed_file["path"]}')
        artifacts = {row["role"]: row for row in capture["artifacts"]}
        required = {"run_receipt", "stdout", "stderr", "body", "canonical", "proof", "source_manifest"}
        if set(artifacts) != required:
            raise ValueError(f'publication F artifact roles invalid: {capture["capture"]}')
        for row in artifacts.values():
            check_record(row, f'publication F {capture["capture"]} {row["role"]}')
        for row in capture["build_artifacts"].values():
            check_record(row, f'publication F build {capture["capture"]}')
        run = json.loads(Path(artifacts["run_receipt"]["path"]).read_text())
        proof = json.loads(Path(artifacts["proof"]["path"]).read_text())
        if run["exit_code"] != capture["exit_code"] or run["exit_code"] != 0:
            raise ValueError(f'publication F run failed: {capture["capture"]}')
        if not run["sources_unchanged"] or not run["binaries_unchanged"]:
            raise ValueError(f'publication F source/binary guard failed: {capture["capture"]}')
        if run["runner_sha256"] != capture["runner_sha256"]:
            raise ValueError(f'publication F runner pin mismatch: {capture["capture"]}')
        if run["runner_sha256"] != capture["build_artifacts"]["runner"]["sha256"]:
            raise ValueError(f'publication F runner file mismatch: {capture["capture"]}')
        command = run["command"]
        if len(command) < 4 or "capture_active_components_mask_after_v1" not in " ".join(command):
            raise ValueError(f'publication F command mismatch: {capture["capture"]}')
        if Path(command[0]).resolve() != Path(capture["build_artifacts"]["binary"]["path"]).resolve():
            raise ValueError(f'publication F command binary mismatch: {capture["capture"]}')
        if proof["binary_sha256"] != capture["binary_sha256"]:
            raise ValueError(f'publication F executable digest mismatch: {capture["capture"]}')
        if proof["binary_sha256"] != capture["build_artifacts"]["binary"]["sha256"]:
            raise ValueError(f'publication F built executable mismatch: {capture["capture"]}')
        if proof["source_manifest_sha256"] != artifacts["source_manifest"]["sha256"]:
            raise ValueError(f'publication F source manifest mismatch: {capture["capture"]}')
        if proof["source_inputs"] != capture["source_inputs"]:
            raise ValueError(f'publication F source input count mismatch: {capture["capture"]}')
        if proof["sha256"] != artifacts["canonical"]["sha256"] or proof["bytes"] != artifacts["canonical"]["bytes"]:
            raise ValueError(f'publication F canonical digest mismatch: {capture["capture"]}')
        if proof["base_revision"] != capture["embedded_before_checkpoint"]:
            raise ValueError(f'publication F checkpoint mismatch: {capture["capture"]}')
        if run["source_before"] != run["source_after"] or run["binary_before"] != run["binary_after"]:
            raise ValueError(f'publication F observed source or binary drift: {capture["capture"]}')
        source_manifest = json.loads(Path(artifacts["source_manifest"]["path"]).read_text())
        root = Path(run["cwd"]).resolve()
        observed = {}
        for absolute, metadata in run["source_before"].items():
            relative = Path(absolute).resolve().relative_to(root).as_posix()
            observed[relative] = metadata
        if observed != source_manifest:
            raise ValueError(f'publication F source map is not bound to its manifest: {capture["capture"]}')

    if manifest["g_before"]["selected_capture_set"] != "native3":
        raise ValueError("G native3 must remain selected")
    g_sets = [("selected-native3", manifest["g_before"]["captures"])]
    g_sets.extend((item["label"], item["captures"]) for item in manifest["g_before"]["historical_capture_sets"])
    for set_label, g_captures in g_sets:
        if {x["variant"] for x in g_captures} != {"main", "scoped"} or len(g_captures) != 2:
            raise ValueError(f"G capture set must contain one capture per root: {set_label}")
        pair_proofs = []
        for capture in g_captures:
            for name, record in capture["artifacts"].items():
                check_record(record, f'G {set_label} {capture["variant"]} {name}')
            if "build_artifacts" in capture:
                for name, record in capture["build_artifacts"].items():
                    check_record(record, f'G {set_label} build {capture["variant"]} {name}')
                run_record = capture["artifacts"]["run"]
                canonical_record = capture["artifacts"]["canonical"]
                proof_record = capture["artifacts"]["proof"]
                binary_record = capture["build_artifacts"]["binary"]
                runner_record = capture["build_artifacts"]["runner"]
            else:
                run_record = capture["artifacts"][".json"]
                canonical_record = capture["artifacts"]["-canonical.json"]
                proof_record = capture["artifacts"]["-proof.json"]
                binary_record = capture["artifacts"]["-audio-deadpan-audio"]
                runner_record = capture["artifacts"]["runner"]
                check_record(capture["artifacts"]["-pins.json"], f'G {set_label} Cargo pins {capture["variant"]}')
            run = json.loads(Path(run_record["path"]).read_text())
            proof = json.loads(Path(proof_record["path"]).read_text())
            canonical = json.loads(Path(canonical_record["path"]).read_text())
            if run["exit_code"] != 0 or not run["sources_unchanged"] or not run["binaries_unchanged"]:
                raise ValueError(f'G run/source/binary guard failed: {set_label}/{capture["variant"]}')
            if run["source_before"] != run["source_after"] or run["binary_before"] != run["binary_after"]:
                raise ValueError(f'G source or binary changed during run: {set_label}/{capture["variant"]}')
            if run["runner_sha256"] != runner_record["sha256"]:
                raise ValueError(f'G runner mismatch: {set_label}/{capture["variant"]}')
            if Path(run["command"][0]).resolve() != Path(binary_record["path"]).resolve():
                raise ValueError(f'G command binary mismatch: {set_label}/{capture["variant"]}')
            if "capture_routed_projected_mask_before_g" not in " ".join(run["command"]):
                raise ValueError(f'G test command mismatch: {set_label}/{capture["variant"]}')
            if proof["canonical"]["sha256"] != canonical_record["sha256"] or proof["canonical"]["bytes"] != canonical_record["bytes"]:
                raise ValueError(f'G proof/canonical mismatch: {set_label}/{capture["variant"]}')
            expected_body_sha = capture["artifacts"].get("body", {}).get("sha256")
            if expected_body_sha is None:
                expected_body_sha = capture["artifacts"]["-body.json"]["sha256"]
            if proof["body"]["sha256"] != expected_body_sha:
                raise ValueError(f'G proof/body mismatch: {set_label}/{capture["variant"]}')
            binary_rows = list(run["binary_before"].values())
            if not any(row["sha256"] == binary_record["sha256"] for row in binary_rows):
                raise ValueError(f'G guarded binary digest mismatch: {set_label}/{capture["variant"]}')
            pair_proofs.append((proof["body"]["sha256"], proof["canonical"]["sha256"]))
            for case_name in ("source_only_empty", "explicit_silent_hold_positive",
                              "shared_renderer_first_empty", "shared_renderer_second_positive"):
                case = canonical[case_name]
                if case["result"] != "Ok" or not case["branch_reached"] or case["trace_dropped"] != 0:
                    raise ValueError(f'G source-ready case invalid: {set_label}/{capture["variant"]}/{case_name}')
                row = case["source_rows"][0]
                expected_start = 0 if case_name.endswith("empty") else 512
                if row["source_ranges_truncated"] or row["start"] != expected_start or row["frames"] != 256:
                    raise ValueError(f'G source receipt invalid: {set_label}/{capture["variant"]}/{case_name}')
                is_positive = case_name in ("explicit_silent_hold_positive", "shared_renderer_second_positive")
                if is_positive:
                    if case["public_block"]["suppressed_ranges"] != [[615, 768]] or case["public_block"]["suppressed_capacity"] != 1:
                        raise ValueError(f'G positive mask observation changed: {set_label}/{capture["variant"]}')
                elif case["public_block"]["suppressed_ranges"] or case["public_block"]["suppressed_capacity"] != 0:
                    raise ValueError(f'G empty mask observation changed: {set_label}/{capture["variant"]}')
            if "observed_cases" in capture:
                for case_name, observed in capture["observed_cases"].items():
                    if "projected_resident_frames" in observed:
                        if observed["projected_resident_frames"] != 768 or observed["projected_disk_bytes"] != 0:
                            raise ValueError(f'G projected residency observation changed: {set_label}/{capture["variant"]}/{case_name}')
        if pair_proofs[0] != pair_proofs[1]:
            raise ValueError(f'G root captures differ: {set_label}')

    for record in manifest["published_f"]["analysis_authorities"].values():
        check_record(record, "F analysis")
    print("Pinned F and G-before artifacts passed integrity checks.")
    print("Immutable oracle roots checked:", sum(root is not None for root in (args.main_root, args.scoped_root)))
    print("State:", manifest["state"], "(review required; this script did not freeze)")
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except (KeyError, OSError, ValueError, json.JSONDecodeError) as exc:
        print(f"validation failed: {exc}", file=sys.stderr)
        raise SystemExit(1)
