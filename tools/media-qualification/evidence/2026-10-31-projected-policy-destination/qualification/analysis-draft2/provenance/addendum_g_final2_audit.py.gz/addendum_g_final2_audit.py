#!/usr/bin/env python3
"""Supplemental literal G/F work and G/G repeat audit; does not rewrite captures."""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path

G = Path("/tmp/deadpan-projected-policy-destination-qualification-2026-10-31")
F = Path("/tmp/deadpan-components-mask-qualification-2026-10-31")
MODES = ("active", "active2", "active3")
VARIANTS = ("main", "scoped")
EXPECTED_NODES = {
    "marks/first_accepted_work_after/plan_work",
    "marks/first_attempt/plan_work_before",
    "marks/last_accepted_work_after/plan_work",
    "marks/last_attempt/plan_work_before",
    "result/plan_work_after",
    "source_init/plan_work_after",
    "source_plan_work_before",
}
EXPECTED_CASE_NAMES = {
    0: "constant_block_positive",
    1: "dynamic_positive",
    2: "constant_zero_emission",
    3: "measured_mark_work_refusal",
}


def sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def read(path: Path):
    return json.loads(path.read_text())


def differences(a, b, path=""):
    if type(a) is not type(b):
        yield path or "/", a, b
    elif isinstance(a, dict):
        for key in sorted(set(a) | set(b)):
            child = path + "/" + str(key).replace("~", "~0").replace("/", "~1")
            if key not in a:
                yield child, None, b[key]
            elif key not in b:
                yield child, a[key], None
            else:
                yield from differences(a[key], b[key], child)
    elif isinstance(a, list):
        if len(a) != len(b):
            yield path + "/length", len(a), len(b)
        for i, (left, right) in enumerate(zip(a, b)):
            yield from differences(left, right, path + "/" + str(i))
    elif a != b:
        yield path or "/", a, b


def check_rows(body: dict, label: str) -> dict:
    case_receipts = []
    all_rows = 0
    for case in body["components_producer_cases"]["cases"]:
        name = case["name"]
        rows = case["components_trace"]["rows"]
        for row in rows:
            all_rows += 1
            source_before = row["source_plan_work_before"]
            source_init = row["source_init"]
            assert source_init["success"] is True, (label, name, row["row_id"])
            assert source_init["plan_work_after"] - source_before == 4, (
                label, name, row["row_id"], source_before, source_init["plan_work_after"])
            assert source_init["cache_work_after"] == row["source_cache_work_before"], (
                label, name, row["row_id"])
        case_receipts.append({"case": name, "rows": len(rows),
                              "source_init_plan_debit_per_row": 4,
                              "source_init_cache_debit_per_row": 0})
    return {"cases": case_receipts, "rows_checked": all_rows}


def validate_work_difference(path: str, left, right, a: dict, b: dict, context: str) -> dict:
    parts = path.split("/")
    assert len(parts) >= 6 and parts[1:3] == ["components_producer_cases", "cases"], (context, path)
    case_index = int(parts[3])
    assert case_index == 1 and EXPECTED_CASE_NAMES[case_index] == "dynamic_positive", (context, path)
    if parts[4:] == ["work", "plan_work"]:
        pass
    else:
        assert len(parts) >= 8 and parts[4:6] == ["components_trace", "rows"], (context, path)
        row_index = int(parts[6])
        assert 0 <= row_index < len(a["components_producer_cases"]["cases"][1]["components_trace"]["rows"])
        assert 0 <= row_index < len(b["components_producer_cases"]["cases"][1]["components_trace"]["rows"])
        node = "/".join(parts[7:])
        assert node in EXPECTED_NODES, (context, path)
    assert type(left) is int and type(right) is int, (context, path, left, right)
    return {"path": path, "before": left, "after": right, "delta": right - left,
            "case_name": "dynamic_positive", "case_index": 1, "comparison": context}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", type=Path, default=G / "analysis-draft2" / "projected-final2-work-audit.json")
    args = parser.parse_args()
    captures = {}
    row_checks = {}
    for mode in MODES:
        for variant in VARIANTS:
            key = f"{mode}/{variant}"
            path = G / f"projected-final2-{mode}-{variant}-canonical.json"
            raw = path.read_bytes()
            captures[key] = json.loads(raw)
            row_checks[key] = check_rows(captures[key], key)
    f_active = {v: read(F / f"components-final13-active-{v}-canonical.json") for v in VARIANTS}

    g_vs_f = {}
    work_path_inventory = set()
    for mode in MODES:
        for variant in VARIANTS:
            key = f"{mode}/{variant}"
            diffs = []
            for path, old, new in differences(f_active[variant], captures[key]):
                if path.startswith("/components_producer_cases/"):
                    receipt = validate_work_difference(path, old, new, captures[key], f_active[variant], key + " vs F active/" + variant)
                    diffs.append(receipt)
                    work_path_inventory.add(path)
                elif path in {
                    "/schema", "/scope", "/projected_policy_checkpoint", "/projected_policy_before",
                    "/projected_policy_cases", "/native_requests/scope",
                } or (path.startswith("/internal_and_transfer_paths/cases/") and path.endswith("/scope/internal_masks")):
                    continue
                else:
                    raise AssertionError((key, "unclassified G/F difference", path, old, new))
            g_vs_f[key] = diffs

    g_pairwise = []
    for left_key in captures:
        for right_key in captures:
            if left_key >= right_key:
                continue
            diffs = []
            for path, left, right in differences(captures[left_key], captures[right_key]):
                receipt = validate_work_difference(path, left, right, captures[left_key], captures[right_key],
                                                   left_key + " vs " + right_key)
                diffs.append(receipt)
            g_pairwise.append({"left": left_key, "right": right_key,
                               "difference_count": len(diffs), "differences": diffs})

    all_work = [row for rows in g_vs_f.values() for row in rows]
    all_pair_diffs = [row for pair in g_pairwise for row in pair["differences"]]
    summary = {
        "schema": "projected-policy-final2-work-audit-v1",
        "source_analysis": {
            "path": str(G / "analysis-draft2/projected-final2-analysis.json"),
            "sha256": sha((G / "analysis-draft2/projected-final2-analysis.json").read_bytes()),
        },
        "capture_sha256": {
            key: sha((G / f"projected-final2-{key.replace('/', '-')}-canonical.json").read_bytes())
            for key in captures
        },
        "source_init_rows": row_checks,
        "g_vs_f": {key: {"difference_count": len(value), "differences": value}
                   for key, value in g_vs_f.items()},
        "g_vs_f_work_summary": {
            "difference_count": len(all_work),
            "distinct_path_count": len(work_path_inventory),
            "path_inventory": sorted(work_path_inventory),
            "leaf_counts": {leaf: sum(row["path"].endswith("/" + leaf) for row in all_work)
                            for leaf in sorted({row["path"].split("/")[-1] for row in all_work})},
            "max_absolute_delta": max((abs(row["delta"]) for row in all_work), default=0),
        },
        "g_pairwise": g_pairwise,
        "g_pairwise_summary": {
            "pair_count": len(g_pairwise),
            "difference_count": len(all_pair_diffs),
            "distinct_path_count": len({row["path"] for row in all_pair_diffs}),
            "path_inventory": sorted({row["path"] for row in all_pair_diffs}),
            "max_absolute_delta": max((abs(row["delta"]) for row in all_pair_diffs), default=0),
        },
        "limits": "All work changes are recorded with exact values and paths. Comparisons classify only the closed Components dynamic_positive work nodes; any other difference fails. This is repeat/counter provenance, not a work-value golden.",
    }
    args.output.write_text(json.dumps(summary, indent=2))

    print(json.dumps({"g_vs_f_differences": len(all_work),
                      "g_vs_f_distinct_paths": len(work_path_inventory),
                      "g_pair_count": len(g_pairwise),
                      "g_pairwise_differences": len(all_pair_diffs),
                      "output": str(args.output)}))


if __name__ == "__main__":
    main()
