#!/usr/bin/env python3
"""Review six post-G projected-policy captures without rewriting inputs.

The report keeps each capture hash and all observed work/interval receipts. It
asserts only the product outputs, source-ready before/after parity, historical
F qualification artifacts, immutable oracle pins, and stated G metadata.
"""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path

G_DIR = Path(__file__).resolve().parent.parent
DEFAULT_MANIFEST = G_DIR / "corpus-draft-v3" / "corpus-manifest-draft.json"
DEFAULT_CORPUS = G_DIR / "portable-corpus-candidate2.json"
DEFAULT_ORACLES = G_DIR / "immutable-oracle-pins35.json"
DEFAULT_F_DIR = Path("/tmp/deadpan-components-mask-qualification-2026-10-31")
F_PREFIX = "components-final13"
G_PREFIX_DEFAULT = "projected-final2"
F_CHECKPOINT = "59874646dba6974da77e2cad08e9bc4822fd5afe"
BASELINE_CORPUS_SHA256 = "93912d8a589912b7ef41f0bd523db8da2a6cdec0d2ea5db1b6ba6f9941dffa51"
HISTORICAL_HASHES = {
    "before-shared": "9d6f3c67d9d611f46e75360006845a1b9419b30168a983db1ca9e4cf79c8be0a",
    "before-root": "596d738a53f6ef4cbf7870d74b3025504f6289f735ea91f4a38ed45c6661f44a",
    "before-policy": "afa6038a02c959c7192c09c08a89266c7d52151a5e59a4f69828fbdf67e7414e",
    "before-off": "af7a292718365c34fa03692e2cbe58a2cfb3c6d444b5ae29d52647e1fdbbff14",
    "before-interval": "f64d3a00a10967cc3822083d21705bd454f2d33ff2198da30e25671092ab5a53",
}
G_SCOPE = (
    "Projected PreserveTape Signal destinations copy the actual completed ordinary policy Vec "
    "into native owned storage while prepared PCM remains live. Public route mapping admits its "
    "separate destination. Ordinary policy queries and their source Vec, exhausted vectors and "
    "whole preparation remain outside this claim."
)
G_NATIVE_SCOPE = (
    "744 actual active native requests with Point, Root, SharedMix, Components and projected "
    "Signal destination admission. Query claims and native work remain separate."
)
G_INTERNAL_SCOPE = (
    "Native destinations, Point Signal policy custody and projected PreserveTape destination "
    "copies are admitted. Ordinary projected policy source queries and exhausted vectors remain "
    "outside this claim."
)
EXPECTED_COMPONENT_CASES = {
    "constant_block_positive": (0, "constant", "positive"),
    "dynamic_positive": (8128, "dynamic", "positive"),
    "constant_zero_emission": (0, "constant", "zero"),
    "measured_mark_work_refusal": (0, "dynamic", "mark_refusal"),
}
PROJECTED_CASES = (
    ("source_only_empty", False),
    ("explicit_silent_hold_positive", True),
    ("shared_renderer_first_empty", False),
    ("shared_renderer_second_positive", True),
)


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def read_json(path: Path):
    return json.loads(path.read_text())


def verify_record(record: dict, label: str) -> None:
    path = Path(record["path"])
    data = path.read_bytes()
    actual = {"bytes": len(data), "sha256": sha256_bytes(data)}
    expected = {key: record[key] for key in actual}
    assert actual == expected, f"{label}: digest mismatch at {path}"


def verify_immutable(manifest: dict, oracle_file: Path, roots: dict[str, Path]) -> dict:
    oracle_bytes = oracle_file.read_bytes()
    pins = read_json(oracle_file)
    assert len(pins) == 35
    base_record = manifest["immutable_oracle"]["pins_file"]
    base_path = Path(base_record["path"])
    base_bytes = base_path.read_bytes()
    assert len(base_bytes) == base_record["bytes"]
    assert sha256_bytes(base_bytes) == base_record["sha256"]
    base_pins = json.loads(base_bytes)
    assert len(base_pins) == 34 and pins[:34] == base_pins
    assert len(pins[34:]) == 1
    for label, root in roots.items():
        for pin in pins:
            actual = sha256_bytes((root / pin["path"]).read_bytes())
            assert actual == pin["sha256"], (label, pin["path"], actual, pin["sha256"])
    return {"count": len(pins), "base_count": len(base_pins),
            "roots": {name: str(path) for name, path in roots.items()},
            "pin_file_sha256": sha256_bytes(oracle_bytes),
            "base_pin_file_sha256": sha256_bytes(base_bytes)}


def verify_f_history(manifest: dict, before_corpus: dict, f_dir: Path) -> dict:
    final13 = manifest["published_f"]["six_fresh_captures"]
    expected_keys = {(mode, variant) for mode in ("active", "active2", "active3")
                     for variant in ("main", "scoped")}
    assert len(final13) == 6 and {(x["mode"], x["variant"]) for x in final13} == expected_keys
    for capture in final13:
        for name, record in capture["artifacts"].items():
            verify_record(record, f"F final13 {capture['mode']}/{capture['variant']} {name}")
        for name, record in capture["build_artifacts"].items():
            verify_record(record, f"F final13 build {capture['variant']} {name}")

    postpub = manifest["publication_time_f"]["six_captures"]
    assert len(postpub) == 6 and len({(row["variant"], row["repeat"]) for row in postpub}) == 6
    for capture in postpub:
        for record in capture["artifacts"]:
            verify_record(record, f"F postpublication {capture['capture']} {record['role']}")
        for name, record in capture["build_artifacts"].items():
            verify_record(record, f"F postpublication build {capture['capture']} {name}")
        assert capture["published_source_revision"] == manifest["publication_time_f"]["published_source_revision"]
        assert capture["embedded_before_checkpoint"] == manifest["publication_time_f"]["embedded_before_checkpoint"]

    authorities = manifest["published_f"]["analysis_authorities"]
    analysis_records = {}
    for name, record in authorities.items():
        verify_record(record, f"F analysis authority {name}")
        analysis_records[name] = read_json(Path(record["path"]))
    inline = analysis_records["components-final13-inline-final-qualification13.json"]
    assert inline["capture_prefix"] == F_PREFIX
    assert inline["classic_cross_root_exact"] is True
    assert inline["classic_projection"]["excluded_top_level_keys"] == ["components_producer_cases"]
    capture_analysis = inline["capture_analysis"]
    assert len(capture_analysis["full_capture_hashes"]) == 6
    assert inline["full_raw_bodies_exact"] is False
    assert set(capture_analysis["components_cases_by_capture"]) == {
        f"{variant}/{mode}" for variant in ("main", "scoped")
        for mode in ("active", "active2", "active3")
    }
    for counts in capture_analysis["components_cases_by_capture"].values():
        assert counts == {"positive": 2, "zero": 1, "mark_refusal": 1}
    f_component_checks = []
    for capture in final13:
        canonical = Path(capture["artifacts"]["-canonical"]["path"])
        verify_record(capture["artifacts"]["-canonical"], f"F producer body {capture['mode']}/{capture['variant']}")
        checked = check_f_component_cases(read_json(canonical), f"F {capture['mode']}/{capture['variant']}")
        f_component_checks.append({"mode": capture["mode"], "variant": capture["variant"], **checked})
    for variant in ("main", "scoped"):
        classic = analysis_records[f"components-final13-classic13-{variant}.json"]
        assert classic["classic_cross_root_exact"] is True
        assert classic["five_historical_bodies_exact_in_both_variants"] is True
        counts = classic["counts"]
        assert counts["native_requests"] == 744
        assert counts["exact_Ok"] == 264 and counts["exact_Error"] == 480
        assert counts["internal_exact_output_fields"] + counts["transfer_exact_output_fields"] == 42
        assert counts["completed_intervals"] == 477 and counts["partial_intervals"] == 1
        assert counts["interval_rows"] == 478
        for mode, digest in HISTORICAL_HASHES.items():
            for root in ("main", "scoped"):
                path = f"{F_PREFIX}-{mode}-{root}-canonical.json"
                assert sha256_bytes((f_dir / path).read_bytes()) == digest
    return {
        "final13_capture_keys": sorted([f"{mode}/{variant}" for mode, variant in expected_keys]),
        "postpublication_capture_count": 6,
        "analysis_authorities": {
            name: {"path": record["path"], "bytes": record["bytes"], "sha256": record["sha256"]}
            for name, record in authorities.items()
        },
        "F_components_variable_work": {
            "full_capture_hashes": capture_analysis["full_capture_hashes"],
            "four_case_local_checks": f_component_checks,
            "work_differences_are_retained": inline["full_raw_bodies_exact"] is False,
            "work_difference_observations": capture_analysis["allowed_counter_differences"],
            "qualification_note": "F captures are pinned independently; variable work observations remain literal and are not reused as a G whitelist.",
        },
        "historic_body_sha256": HISTORICAL_HASHES,
    }


def check_f_component_cases(body: dict, label: str) -> dict:
    cases = body["components_producer_cases"]["cases"]
    assert {case["name"] for case in cases} == set(EXPECTED_COMPONENT_CASES), label
    checks = []
    for case in cases:
        name = case["name"]
        start, driver, kind = EXPECTED_COMPONENT_CASES[name]
        trace = case["components_trace"]
        assert trace["schema"] == "components-inline-marks-v2"
        assert not trace["unfinished"] and not trace["truncated_rows"]
        assert trace["attempted_rows"] == len(trace["rows"])
        assert trace["dropped_rows"] == 0
        row_checks = validate_component_rows(trace["rows"], label, name)
        rows = [row for row in trace["rows"] if row["program_depth"] == 0 and row["start"] == start]
        assert len(rows) == 1, (label, name, len(rows))
        root = rows[0]
        marks = root["marks"]
        assert driver in root["driver_kinds"]
        assert root["inline_source_scope_closed"] is True
        assert root["inline_word_count"] == 4 and root["inline_bytes"] == 32
        if kind == "positive":
            assert root["result"]["success"] is True and root["result"]["owned"] is True
            assert root["raw_mark_count"] == marks["written_count"] > 0
            assert root["result"]["mask_capacity"] == case["destination_capacity"]
            assert case["exact_output_match"] is True and case["active"] == case["legacy"]
        elif kind == "zero":
            assert root["result"]["success"] is True and root["result"]["owned"] is False
            assert root["raw_mark_count"] == marks["written_count"] == 0
            assert root["destination_reservation"] is None and root["destination_storage"] is None
            assert case["destination_reservation"] is None
            assert case["exact_output_match"] is True and case["active"] == case["legacy"]
        else:
            assert root["result"]["success"] is False
            assert marks["attempt_count"] == 1 and marks["written_count"] == 0
            assert any(event["kind"] == "mark_refused" for event in root["events"])
            assert root["destination_reservation"] is None and root["destination_storage"] is None
            assert case["active"]["status"] == case["legacy_at_same_work_seed"]["status"] == "Error"
            assert case["active"]["error"] == case["legacy_at_same_work_seed"]["error"]
        checks.append({"case": name, "driver": driver, "kind": kind,
                       "raw_mark_count": root["raw_mark_count"],
                       "mark_attempt_count": marks["attempt_count"],
                       "mark_written_count": marks["written_count"],
                       "result": root["result"], **row_checks})
    return {"case_count": len(cases), "cases": checks}


def validate_component_rows(rows: list[dict], label: str, case_name: str) -> dict:
    accepted = refused = empty = mark_rows = 0
    for row in rows:
        marks = row["marks"]
        result = row["result"]
        assert row["inline_source_scope_closed"] is True
        assert row["inline_word_count"] == 4 and row["inline_bytes"] == 32
        assert row["source_storage"] == "inline_bitset"
        assert row["source_heap_allocation"] is False and row["source_heap_charge_frames"] == 0
        words_initial = row["inline_words_initial"]
        words_latest = row["inline_words_latest"]
        assert len(words_initial) == len(words_latest) == 4
        assert all(word == 0 for word in words_initial), (label, case_name, row["row_id"])
        popcount = sum(word.bit_count() for word in words_latest)
        assert popcount == marks["written_count"], (label, case_name, row["row_id"])
        if result["success"]:
            accepted += 1
            raw_count = row["raw_mark_count"]
            assert raw_count == marks["written_count"]
            if marks["written_count"]:
                mark_rows += 1
                assert result["owned"] is True
                assert row["destination_reservation"]["accepted"] is True
                assert row["destination_storage"]["capacity"] == result["mask_capacity"]
                for attempt_name, accepted_name in (
                    ("first_attempt", "first_accepted_work_after"),
                    ("last_attempt", "last_accepted_work_after"),
                ):
                    attempt = marks[attempt_name]
                    after = marks[accepted_name]
                    assert after["plan_work"] - attempt["plan_work_before"] == 1
                    assert after["cache_plan_work"] == attempt["cache_plan_work_before"]
            else:
                empty += 1
                assert result["owned"] is False
                assert row["destination_reservation"] is None and row["destination_storage"] is None
        else:
            refused += 1
            assert marks["attempt_count"] == 1 and marks["written_count"] == 0
            assert row["raw_mark_count"] is None
            assert row["destination_reservation"] is None and row["destination_storage"] is None
            assert any(event["kind"] == "mark_refused" for event in row["events"])
    return {"rows_checked": len(rows), "successful_rows": accepted,
            "zero_mark_rows": empty, "positive_mark_rows": mark_rows,
            "reached_mark_refusal_rows": refused}


def native_outputs(body: dict) -> list[dict]:
    section = body["native_requests"]
    assert section["operations"] == 744
    results = []
    for case_index, case in enumerate(section["cases"]):
        for operation_index, operation in enumerate(case["operations"]):
            paired = operation["paired"]
            result = paired["new"]["read"]["output"]
            results.append({"case_index": case_index, "fixture": case["fixture"],
                            "operation_index": operation_index,
                            "old_operation_index": operation["old_operation_index"],
                            "output": result})
    assert len(results) == 744
    return results


def result_fields(body: dict) -> list[dict]:
    section = body["internal_and_transfer_paths"]
    results = []
    for group, rows in (("internal", section["cases"]),
                        ("transfer", section["public_transfers"]["cases"])):
        for row in rows:
            fields = {key: value for key, value in row.items() if key.startswith("result_")}
            results.extend({"group": group, "case": row["name"], "field": key, "value": value}
                           for key, value in sorted(fields.items()))
    assert len(results) == 42
    return results


def json_differences(before, after, path="") -> list[dict]:
    if type(before) is not type(after):
        return [{"path": path or "/", "before": before, "after": after}]
    if isinstance(before, dict):
        output = []
        for key in sorted(set(before) | set(after)):
            child_path = path + "/" + str(key).replace("~", "~0").replace("/", "~1")
            if key not in before:
                output.append({"path": child_path, "before": None, "after": after[key], "presence": "added"})
            elif key not in after:
                output.append({"path": child_path, "before": before[key], "after": None, "presence": "removed"})
            else:
                output.extend(json_differences(before[key], after[key], child_path))
        return output
    if isinstance(before, list):
        output = []
        if len(before) != len(after):
            output.append({"path": path + "/length", "before": len(before), "after": len(after)})
        for index, (old, new) in enumerate(zip(before, after)):
            output.extend(json_differences(old, new, path + "/" + str(index)))
        return output
    if before != after:
        return [{"path": path or "/", "before": before, "after": after}]
    return []


def classify_g_vs_f_differences(before: dict, after: dict, label: str) -> dict:
    differences = json_differences(before, after)
    metadata_paths = {
        "/schema", "/scope", "/projected_policy_checkpoint", "/projected_policy_before",
        "/projected_policy_cases", "/native_requests/scope",
    }
    expected_scopes = {f"/internal_and_transfer_paths/cases/{index}/scope/internal_masks"
                       for index in range(10)}
    work_fields = {"plan_work", "plan_work_before", "plan_work_after", "source_plan_work_before"}
    variable_work = []
    metadata = []
    unexpected = []
    for diff in differences:
        path = diff["path"]
        if path in metadata_paths or path in expected_scopes:
            metadata.append(diff)
            continue
        parts = path.split("/")
        if len(parts) >= 5 and parts[1:3] == ["components_producer_cases", "cases"]:
            try:
                case_index = int(parts[3])
            except ValueError:
                case_index = -1
            leaf = parts[-1]
            old, new = diff.get("before"), diff.get("after")
            if (case_index in (0, 1) and leaf in work_fields and
                    type(old) is int and type(new) is int):
                variable_work.append({**diff, "delta": new - old,
                                      "case_index": case_index,
                                      "case_name": after["components_producer_cases"]["cases"][case_index]["name"],
                                      "capture": label})
                continue
        unexpected.append(diff)
    assert not unexpected, (label, "unexpected G-vs-F changes", unexpected[:8])
    return {"metadata_differences": metadata, "literal_variable_work_differences": variable_work,
            "metadata_difference_count": len(metadata),
            "variable_work_difference_count": len(variable_work),
            "unexpected_difference_count": len(unexpected)}


def intervals(body: dict, label: str) -> dict:
    snapshots: list[tuple[str, dict]] = []
    def walk(value, path=""):
        if isinstance(value, dict):
            if value.get("schema") == "native-mask-query-intervals-v1":
                snapshots.append((path or "/", value))
            else:
                for key, child in value.items():
                    walk(child, path + "/" + str(key).replace("~", "~0").replace("/", "~1"))
        elif isinstance(value, list):
            for index, child in enumerate(value):
                walk(child, path + "/" + str(index))
    walk(body)
    completed = partial = rows_seen = 0
    partials = []
    completed_rows = []
    for path, snapshot in snapshots:
        assert snapshot["active_intervals"] == snapshot["dropped_intervals"] == 0, (label, path)
        assert not snapshot["misnested"] and not snapshot["overflow"], (label, path)
        for row_index, row in enumerate(snapshot["rows"]):
            rows_seen += 1
            assert row["attributable"] and not row["foreign_work_overlap"], (label, path, row_index)
            for lane_kind in ("native", "host"):
                before = row[lane_kind + "_before"]
                after = row[lane_kind + "_after"]
                assert before["reset_epoch"] is not None and before["reset_epoch"] == after["reset_epoch"]
                assert not before["overflow"] and not after["overflow"]
            claim = row["claim"]
            if claim is None:
                partial += 1
                partials.append({"snapshot_path": path, "row_index": row_index, "row": row})
                continue
            completed += 1
            assert claim["total"] == claim["canonical"] + claim["additional"]
            lane_observations = []
            for lane in range(2):
                before_phase = row["native_before"]["lanes"][lane]
                after_phase = row["native_after"]["lanes"][lane]
                assert len(before_phase) == len(after_phase)
                phase = [after - before for before, after in zip(before_phase, after_phase)]
                host = row["host_after"]["units"][lane] - row["host_before"]["units"][lane]
                observed = row["work_after"][lane] - row["work_before"][lane]
                assert min(phase) >= 0 and host >= 0 and observed >= 0
                expected = (claim["expected_debit"] if lane == row["selected_lane"] else 0) + sum(phase) + host
                assert observed == expected, (label, path, row_index, lane)
                lane_observations.append({
                    "lane": lane,
                    "selected_lane": row["selected_lane"],
                    "work_before": row["work_before"][lane],
                    "work_after": row["work_after"][lane],
                    "work_delta": observed,
                    "native_phase_delta": phase,
                    "host_units_delta": host,
                    "expected_debit": claim["expected_debit"] if lane == row["selected_lane"] else 0,
                    "equation_rhs": expected,
                    "reset_epoch": row["native_before"]["reset_epoch"],
                })
            completed_rows.append({"snapshot_path": path, "row_index": row_index,
                                   "row_id": row.get("row_id"),
                                   "selected_lane": row["selected_lane"],
                                   "claim": claim, "lanes": lane_observations})
    assert completed == 477 and partial == 1 and rows_seen == 478, (label, completed, partial, rows_seen)
    return {"snapshot_count": len(snapshots), "rows": rows_seen, "completed": completed,
            "claimless_partial": partial, "partial_rows": partials,
            "completed_work_deltas": completed_rows}


def component_producers(body: dict, label: str) -> dict:
    section = body["components_producer_cases"]
    cases = section["cases"]
    assert {case["name"] for case in cases} == set(EXPECTED_COMPONENT_CASES)
    observations = []
    for case in cases:
        name = case["name"]
        start, driver, kind = EXPECTED_COMPONENT_CASES[name]
        trace = case["components_trace"]
        assert trace["schema"] == "components-inline-marks-v2"
        assert not trace["unfinished"] and not trace["truncated_rows"]
        assert trace["attempted_rows"] == len(trace["rows"])
        assert trace["dropped_rows"] == 0
        assert all(row.get("events_truncated") is not True for row in trace["rows"])
        row_checks = validate_component_rows(trace["rows"], label, name)
        roots = [row for row in trace["rows"] if row["program_depth"] == 0 and row["start"] == start]
        assert len(roots) == 1, (label, name, len(roots))
        root = roots[0]
        assert root["parent_row_id"] is None
        assert driver in root["driver_kinds"] and case["actual_driver_reached"] is True
        assert root["inline_source_scope_closed"] is True
        assert root["inline_word_count"] == 4 and root["inline_bytes"] == 32
        assert len(root["inline_words_initial"]) == len(root["inline_words_latest"]) == 4
        assert all(word == 0 for word in root["inline_words_initial"])
        words = root["inline_words_latest"]
        popcount = sum(word.bit_count() for word in words)
        writes = root["marks"]["written_count"]
        assert popcount == writes
        if kind == "positive":
            assert popcount > 0 and root["raw_mark_count"] == popcount
            assert root["result"]["success"] is True and root["result"]["owned"] is True
            assert case["provider_was_used"] is True and case["root_positive_marks"] is True
            assert case["target_reserved_while_existing_source_live"] is True
            assert case["destination_capacity"] == popcount
            assert case["exact_output_match"] is True and case["active"] == case["legacy"]
        elif kind == "zero":
            assert popcount == writes == 0 and root["raw_mark_count"] == 0
            assert root["result"]["success"] is True and root["result"]["owned"] is False
            assert root["destination_reservation"] is None and root["destination_storage"] is None
            assert case["zero_emission_has_no_target"] is True
            assert case["exact_output_match"] is True and case["active"] == case["legacy"]
        else:
            assert case["actual_mark_refusal_reached"] is True
            assert case["expected_driver"] == "dynamic" and case["root_callback_count"] == 0
            assert root["result"]["success"] is False
            assert root["marks"]["attempt_count"] > 0
            assert any(event["kind"] == "mark_refused" for event in root["events"])
            assert root["destination_reservation"] is None and root["destination_storage"] is None
            assert case["active_frames_after_request"] == case["sound_context_frames_after_request"] == 0
        observations.append({
            "case": name, "root_start": start, "driver": driver,
            "kind": kind, "popcount": popcount, "mark_writes": writes,
            "literal_work": case.get("work"),
            "root_plan_work_before": root.get("source_plan_work_before"),
            "root_plan_work_after": root.get("result", {}).get("plan_work_after"),
            "marks": root["marks"],
            "inline_words_latest": words,
            **row_checks,
        })
    return {"case_count": len(cases), "cases": observations,
            "work_contract": "Every capture's work observations are kept literal. No cross-capture numeric golden or F-derived work-path whitelist is applied."}


def check_case_parity(before: dict, after: dict, label: str) -> None:
    before_case = before["source_ready_before"]
    active_cases = after["projected_policy_cases"]
    expected_case_names = {name for name, _ in PROJECTED_CASES}
    assert expected_case_names.issubset(active_cases), label
    assert set(active_cases) - expected_case_names == {"schema", "capture_mode", "provider_calls", "limitations"}, label
    assert active_cases["schema"] == "deadpan.routed_projected_mask.active.v1"
    assert active_cases["capture_mode"] == "G active destination ownership"
    assert active_cases["provider_calls"] == before_case["provider_calls"]
    for name, expected_owned in PROJECTED_CASES:
        old = before_case[name]
        current = active_cases[name]
        assert current["result"] == "Ok" and old["result"] == "Ok"
        assert current["source_rows"] == old["source_rows"], (label, name, "source-ready receipt changed")
        assert current["result_samples_f32_bits"] == old["result_samples_f32_bits"], (label, name, "PCM bits changed")
        assert current["result_samples_f32_bits_sha256_le"] == old["result_samples_f32_bits_sha256_le"]
        old_case = dict(old)
        current_case = dict(current)
        old_public = old_case.pop("public_block")
        current_public = current_case.pop("public_block")
        assert current_case == old_case, (label, name, "case metadata changed")
        assert set(current_public) == set(old_public), (label, name, "public field keys changed")
        assert current_public["suppressed_owned"] is expected_owned, (label, name, "ownership flag")
        assert {key: value for key, value in current_public.items() if key != "suppressed_owned"} == {
            key: value for key, value in old_public.items() if key != "suppressed_owned"
        }, (label, name, "public output changed")
        if expected_owned:
            assert current_public["suppressed_ranges"] == [[615, 768]]
            assert current_public["suppressed_capacity"] == 1
        else:
            assert current_public["suppressed_ranges"] == []
            assert current_public["suppressed_capacity"] == 0


def verify_g_metadata(body: dict, label: str) -> None:
    assert body["schema"] == "active-projected-policy-destination-after-v1", label
    assert body["projected_policy_checkpoint"] == F_CHECKPOINT, label
    assert body["projected_policy_before"] == {
        "path": "tests/fixtures/projected-policy-destination-baseline-v1/corpus.json",
        "sha256": BASELINE_CORPUS_SHA256,
    }, label
    assert body["scope"] == G_SCOPE, label
    assert body["native_requests"]["scope"] == G_NATIVE_SCOPE, label
    internal = body["internal_and_transfer_paths"]["cases"]
    assert len(internal) == 10
    assert all(row["scope"]["internal_masks"] == G_INTERNAL_SCOPE for row in internal)


def verify_g_capture_artifacts(capture_dir: Path, stem: str, variant: str) -> dict:
    run_path = capture_dir / f"{stem}.json"
    proof_path = capture_dir / f"{stem}-proof.json"
    source_path = capture_dir / f"{stem}-source-manifest.json"
    body_path = capture_dir / f"{stem}-body.json"
    canonical_path = capture_dir / f"{stem}-canonical.json"
    run, proof = read_json(run_path), read_json(proof_path)
    source_bytes = source_path.read_bytes()
    source_manifest = json.loads(source_bytes)
    source_digest = sha256_bytes(source_bytes)
    assert run["exit_code"] == 0 and run["sources_unchanged"] and run["binaries_unchanged"]
    assert run["source_before"] == run["source_after"]
    assert run["binary_before"] == run["binary_after"]
    assert proof["mode"] == "projected" and proof["base_revision"] == F_CHECKPOINT
    assert proof["variant"] == variant and proof["source_manifest_sha256"] == source_digest
    assert proof["source_inputs"] == len(source_manifest)
    expected_variant = "main-inherited" if variant == "main" else "scoped-published"
    environment = run["environment"]
    for key, expected in {
        "DEADPAN_PROJECTED_MASK_AFTER_VARIANT": expected_variant,
        "DEADPAN_PROJECTED_MASK_AFTER_SOURCE_SHA256": source_digest,
        "DEADPAN_PROJECTED_MASK_AFTER_PUBLISHED_CHECKPOINT": F_CHECKPOINT,
    }.items():
        assert environment[key] == expected, (stem, key)
    assert Path(environment["DEADPAN_PROJECTED_MASK_AFTER_OUTPUT"]).resolve() == body_path.resolve()
    test_name = "stages::bound_reads::retained_host_baseline::pairs::native_mask_after::capture_active_projected_mask_after_v1"
    assert test_name in " ".join(run["command"])
    assert run["cwd"] == ("/Users/michael/Code/deadpan" if variant == "main" else "/tmp/deadpan-query-groundwork-2026-10-26/scoped")
    root = Path(run["cwd"]).resolve()
    observed = {Path(path).resolve().relative_to(root).as_posix(): value
                for path, value in run["source_before"].items()}
    assert observed == source_manifest, stem
    assert proof["binary_sha256"] in {value["sha256"] for value in run["binary_before"].values()}
    body = read_json(body_path)
    assert body.pop("variant") == expected_variant
    assert body.pop("source_sha256") == source_digest
    native = body["native_requests"]
    assert native.pop("variant") == expected_variant
    assert native.pop("source_sha256") == source_digest
    canonical = (json.dumps(body, sort_keys=True, separators=(",", ":")) + "\n").encode()
    assert canonical == canonical_path.read_bytes()
    assert proof["sha256"] == sha256_bytes(canonical) and proof["bytes"] == len(canonical)
    return {"run_receipt_sha256": sha256_bytes(run_path.read_bytes()),
            "proof_sha256": sha256_bytes(proof_path.read_bytes()),
            "source_manifest_sha256": source_digest,
            "binary_sha256": proof["binary_sha256"],
            "test": test_name}


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--capture-directory", type=Path, default=G_DIR)
    parser.add_argument("--prefix", default=G_PREFIX_DEFAULT)
    parser.add_argument("--f-directory", type=Path, default=DEFAULT_F_DIR)
    parser.add_argument("--manifest", type=Path, default=DEFAULT_MANIFEST)
    parser.add_argument("--corpus", type=Path, default=DEFAULT_CORPUS)
    parser.add_argument("--oracle-pins", type=Path, default=DEFAULT_ORACLES)
    parser.add_argument("--main-root", type=Path, default=Path("/Users/michael/Code/deadpan"))
    parser.add_argument("--scoped-root", type=Path, default=Path("/tmp/deadpan-query-groundwork-2026-10-26/scoped"))
    parser.add_argument("--output", type=Path, default=G_DIR / "analysis-draft2" / "projected-final2-analysis.json")
    args = parser.parse_args()
    manifest = read_json(args.manifest)
    before_corpus_bytes = args.corpus.read_bytes()
    assert sha256_bytes(before_corpus_bytes) == BASELINE_CORPUS_SHA256
    before_corpus = json.loads(before_corpus_bytes)
    immutable = verify_immutable(manifest, args.oracle_pins,
                                 {"main": args.main_root, "scoped": args.scoped_root})
    f_history = verify_f_history(manifest, before_corpus, args.f_directory)

    f_references = {}
    for variant in ("main", "scoped"):
        path = args.f_directory / f"{F_PREFIX}-active-{variant}-canonical.json"
        record = next(c["artifacts"]["-canonical"] for c in manifest["published_f"]["six_fresh_captures"]
                      if c["mode"] == "active" and c["variant"] == variant)
        verify_record(record, f"F canonical {variant}")
        assert Path(record["path"]).resolve() == path.resolve()
        f_references[variant] = read_json(path)

    capture_hashes = []
    output_receipts = []
    interval_receipts = []
    component_receipts = []
    projected_receipts = []
    change_receipts = []
    capture_guard_receipts = []
    for variant in ("main", "scoped"):
        for mode in ("active", "active2", "active3"):
            stem = f"{args.prefix}-{mode}-{variant}"
            path = args.capture_directory / f"{stem}-canonical.json"
            capture_guard_receipts.append({"mode": mode, "variant": variant,
                                           **verify_g_capture_artifacts(args.capture_directory, stem, variant)})
            raw = path.read_bytes()
            digest = sha256_bytes(raw)
            body = json.loads(raw)
            label = f"{mode}/{variant}"
            verify_g_metadata(body, label)
            check_case_parity(before_corpus, body, label)
            reference = f_references[variant]

            change_receipts.append({"mode": mode, "variant": variant,
                                    **classify_g_vs_f_differences(reference, body, label)})

            native = native_outputs(body)
            f_native = native_outputs(reference)
            assert native == f_native, (label, "744 native output records differ from F")
            classic_results = result_fields(body)
            f_results = result_fields(reference)
            assert classic_results == f_results, (label, "42 internal/transfer result fields differ from F")
            assert body["internal_and_transfer_paths"]["cases"] and len(body["internal_and_transfer_paths"]["cases"]) == 10
            assert len(body["internal_and_transfer_paths"]["public_transfers"]["cases"]) == 4

            interval_receipt = intervals(body, label)
            producer_receipt = component_producers(body, label)
            projected_receipt = {
                "source_only_empty": body["projected_policy_cases"]["source_only_empty"]["public_block"],
                "explicit_silent_hold_positive": body["projected_policy_cases"]["explicit_silent_hold_positive"]["public_block"],
                "shared_renderer_first_empty": body["projected_policy_cases"]["shared_renderer_first_empty"]["public_block"],
                "shared_renderer_second_positive": body["projected_policy_cases"]["shared_renderer_second_positive"]["public_block"],
            }
            capture_hashes.append({"mode": mode, "variant": variant,
                                   "path": str(path.resolve()), "bytes": len(raw), "sha256": digest})
            output_receipts.append({"mode": mode, "variant": variant, "native_outputs": 744,
                                    "exact_ok": 264, "exact_error": 480,
                                    "internal_transfer_output_fields": 42})
            interval_receipts.append({"mode": mode, "variant": variant, **interval_receipt})
            component_receipts.append({"mode": mode, "variant": variant, **producer_receipt})
            projected_receipts.append({"mode": mode, "variant": variant, "cases": projected_receipt})

    output = {
        "schema": "projected-policy-destination-final2-analysis-draft-v1",
        "status": "analysis draft; no freeze decision",
        "selected_source_ready_before": {"path": str(args.corpus.resolve()),
                                         "bytes": len(before_corpus_bytes),
                                         "sha256": BASELINE_CORPUS_SHA256},
        "immutable_oracles": immutable,
        "F_history": f_history,
        "G_capture_hashes": capture_hashes,
        "G_capture_guard_receipts": capture_guard_receipts,
        "output_parity_vs_F": output_receipts,
        "query_intervals": interval_receipts,
        "F_components_replay": component_receipts,
        "projected_policy_cases": projected_receipts,
        "G_vs_F_literal_differences": change_receipts,
        "intentional_G_metadata_paths": [
            "/schema", "/scope", "/projected_policy_checkpoint", "/projected_policy_before",
            "/projected_policy_cases", "/native_requests/scope",
            *[f"/internal_and_transfer_paths/cases/{index}/scope/internal_masks" for index in range(10)],
        ],
        "scope_limit": (
            "G validates the routed projected PreserveTape Signal destination through four checked "
            "public cases. The ordinary projected policy source query and its source Vec remain "
            "outside this claim. The 744 native requests are preserved compatibility observations, "
            "not evidence that all 744 exercise this G destination."
        ),
        "work_policy": (
            "All six full canonical bodies remain individually hashed. Interval rows and inline "
            "producer work values are retained literally in their source captures and summarized "
            "here per capture; no F work-value whitelist is applied to G. Any unexpected output or "
            "metadata change fails the explicit parity assertions instead of being normalized."
        ),
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(output, indent=2) + "\n")
    print(json.dumps({"captures": len(capture_hashes), "oracle_count": immutable["count"],
                      "native_outputs_each": 744, "internal_transfer_fields_each": 42,
                      "completed_intervals_each": 477, "partial_intervals_each": 1,
                      "output": str(args.output)}))


if __name__ == "__main__":
    main()
