# G final2 capture analysis draft

This folder contains a read-only validator for the six canonical active G captures:
projected-final2-{active,active2,active3}-{main,scoped}-canonical.json.

The script verifies the 35 immutable oracle pins in both roots, the five historical
body hashes and F qualification artifacts, all six literal G body hashes, 744
native output records and 42 internal/transfer result fields against F, the full
interval receipt equations (477 complete and one claimless partial), four F
Components producer cases per capture, and four actual routed projected-policy
cases per G capture. It permits only the specifically scoped G schema/scope
metadata and the expected positive-mask suppressed_owned flag. It keeps all
work observations and hashes literal. It records all interval lane work deltas
with source path, row, claim, phase deltas, host units, and reset epoch; it also
records every G-vs-F Components work leaf with exact before/after/delta and case
context. No generic counter normalization or F-derived work whitelist is used.

Run only after the parent capture pipeline has completed all six G captures and
each corresponding proof/source-manifest exists:

    python3 /tmp/deadpan-projected-policy-destination-qualification-2026-10-31/analysis-draft2/analyze_g_final2.py --capture-directory /tmp/deadpan-projected-policy-destination-qualification-2026-10-31 --output /tmp/deadpan-projected-policy-destination-qualification-2026-10-31/analysis-draft2/projected-final2-analysis.json

This is a draft analyzer, not a freeze decision. It does not generate captures,
change source, or certify that all 744 native requests exercise the G destination.
