from pathlib import Path
import hashlib,json,os,subprocess,sys
s=Path(__file__).resolve().parent
variant=sys.argv[1]
build=f"projected-active-build1-{variant}"
pins=json.loads((s/(build+"-pins.json")).read_text())
binary=next(row["path"] for row in pins if row["package"]=="audio" and row["name"]=="deadpan_audio")
runner=s/("run_qualified.py" if variant=="main" else "run_scoped_qualified.py")
label=f"projected-active-before-replay1-{variant}"
body=s/(label+"-body.json")
assert not body.exists()
env=dict(os.environ,DEADPAN_ROUTED_PROJECTED_MASK_BEFORE_OUTPUT=str(body))
cmd=["python",str(runner),"--binary",binary,label,"--",binary,"--ignored","--exact","stages::routed::routed_projected_mask_tests::capture_routed_projected_mask_before_g","--test-threads=1","--nocapture"]
code=subprocess.run(cmd,env=env).returncode
if code:raise SystemExit(code)
receipt=json.loads((s/(label+".json")).read_text())
assert receipt["sources_unchanged"] and receipt["binaries_unchanged"]
v=json.loads(body.read_text())
canonical=json.dumps(v,sort_keys=True,separators=(",",":")).encode()
with (s/(label+"-canonical.json")).open("xb") as f:f.write(canonical)
proof={"variant":variant,"build":build,"native_receipt":label+".json","body":{"path":body.name,"bytes":body.stat().st_size,"sha256":hashlib.sha256(body.read_bytes()).hexdigest()},"canonical":{"bytes":len(canonical),"sha256":hashlib.sha256(canonical).hexdigest()}}
with (s/(label+"-proof.json")).open("x") as f:json.dump(proof,f,indent=2);f.write(chr(10))
print(json.dumps(proof))
