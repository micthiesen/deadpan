from pathlib import Path
import subprocess,json,hashlib,shutil
s=Path(__file__).resolve().parent
f=Path('/tmp/deadpan-components-mask-qualification-2026-10-31')
rows=[]
for repeat in range(1,4):
 for variant in ['main','scoped']:
  label=f'projected-before-f-{variant}-{repeat}'
  subprocess.run(['python',str(f/'capture_after.py'),variant,'components-build13-'+variant,'components',label],check=True)
  copied=[]
  for suffix in ['.json','.stdout','.stderr','-body.json','-canonical.json','-proof.json','-source-manifest.json']:
   p=f/(label+suffix);q=s/'published-f-before'/(label+suffix);assert not q.exists();q.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,q)
   b=q.read_bytes();copied.append({'path':str(q.relative_to(s)),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()})
  rows.append({'variant':variant,'repeat':repeat,'capture':label,'published_source_revision':(s/'base-revision.txt').read_text().strip(),'embedded_before_checkpoint':'69698b678fd8a75dd644993d7d2a9846986d6911','files':copied})
(s/'published-f-before-proof.json').write_text(json.dumps(rows,indent=2)+'\n')
print(json.dumps({'captures':len(rows),'source_revision':(s/'base-revision.txt').read_text().strip()}))
