# G projected-copy warm request-memo boundary tests

Final scratch-only candidate. No Root edits, Cargo/builds, native execution, Git, new tracer or corpus changes. Parent owns integration after corpus35 freeze/review.

candidate.patch adds three private child tests beneath the actual current routed_projected_mask_tests.rs plus two narrow cfg(test) helpers:
- Row::allocation_is_distinct_from borrows the actual returned SignalSuppressionMask and compares its pointer to the existing private source pointer. No pointer is serialized or dereferenced after source disposal; no source Clone/detach API is added.
- point_suppression::signal_payload_frames calls the existing actual generic Layout calculation for SignalSample. This avoids guessing a Reference/Audio ABI fee. No storage, ticket or counter is fabricated.

Tests use the current checked public projection fixture and verified WAV provider. They prepopulate the real request-local projected memo with prepare_projected on the same actual WorkControl/ReadWork, retaining its genuine Arc. The qualified existing residency is768 frames, disk0, controller cache0/account0. Only then do they lower the private test controller ceiling. These are warm request-memo copy boundaries, not cold preparation minima or whole-process memory claims.

Three tests:
1. warm_projected_copy_exact_payload_limit_is_owned_before_routed_map_and_outlives_work:
   Actual private read_projected_signal_controlled reads512..768, requires the actual source-ready Vec len/cap1 and range615..768, succeeds at existing residency + actual shell + actual Signal payload Layout, and returns Owned directly before public routed translation. It checks distinct source/destination allocation, actual destination reservation/map counters, matching real prepared dependencies/depth and a still-live prepared Arc. The result remains readable/charged after ReadWork/provider/controller drop; dropping it returns to the actual shell while only the observer remains.
2. warm_projected_copy_one_frame_below_payload_limit_refuses_after_policy_and_cleans_up:
   Same real memo/source and one lower ceiling. The existing source-ready row proves old policy/zeroing completed. The new admission must fail with resident PCM or stage cache before vector/map/storage work, with no accepted payload reservation. A real initialized shell can remain; prepared residency/Arc and source ledgers stay truthful. This test fails against pre-G production because that code returns a Plain result without the new reservation.
3. warm_empty_projected_mask_needs_no_destination_above_existing_prepared_residency:
   Source-only0..256 succeeds with only the768 already retained frames available, source len/cap0, no destination ownership/account and zero native mask phase counters.

The positive test also fails before G because its private SignalBlock mask is Plain. Neither test relies on a public mapped output to infer ownership. Parent will add exact public PCM/capacity baseline parity against the35th fixture separately.

## Proof limits

The source policy query, inventory and intermediate merge Vec remain ordinary/unadmitted. Source-ready observations describe the actual real Vec, not a quota lease. The source is passed by value into the existing Plain.into_admitted; its lexical owner survives reservation/copy/finish/finalcheck and the method explicitly drops self before successful return. Error paths retain ordinary Rust RAII. This candidate relies on that inherited source/drop proof. It does not instrument the allocator, observe a physical deallocator event, or assert a source charge was released.

The prepared Arc runtime checks establish the actual memo/test-held preparation remains live; the producer's named prepared local is also used in the result header after the copy. No source/reference is cloned just to serialize it. Source snapshot JSON and test observer handles are harness storage outside measured native mask ownership.

No new whole-read initial-work seed claim is made. The tests do not edit plan_work, fabricate late work, widen a seed search, or insert a budget-exhaustion hook. A concrete after-policy work/cancellation/finalcheck test can follow using actual stable measured setup and existing generic context coverage, but it must be labelled separately and preserve real accepted prefixes. Work-limit, cancellation, deadline, foreign/depth/provider-priority paths are not newly claimed as executed by these three tests.

For a later small priority test, a cancelled/expired actual WorkControl or depth/foreign/provider failure before source-ready must produce no G-copy observation/reservation; retain the real prior error. Late cancellation should use a real cancel signal at an existing phase if a precise test hook is needed, never rewrite work/clock state or claim a fabricated prefix. This is deliberately deferred to avoid broad tracer/refactor scope.

All test source assumptions are asserted: fresh controller cache/account0, projected disk0/resident768, exact real source len/cap/ranges and direct owned result. If the fixture or preparation mode changes, these tests must fail rather than silently redefine the cap or source geometry.

## Integration

Apply candidate.patch after the minimal G runtime/replay patch and current before hooks, preserving Main WIP. The child module path is routed::routed_projected_mask_tests::copy_lifetime. The new test file is routed_projected_mask_lifetime_tests.rs. Source dependencies and all before/new hashes are in source-pins.json.

The source_pointer allow(dead_code) attribute becomes unnecessary once its comparison helper is integrated; parent may remove only that attribute mechanically. This candidate leaves the existing attribute intact to preserve the exact reviewed patch.

No compilation or runtime result is claimed.
