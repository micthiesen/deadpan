from pathlib import Path
from collections import Counter
import argparse,json,hashlib
p=argparse.ArgumentParser();p.add_argument('--prefix',default='projected-final2');p.add_argument('--current',default='active-scoped');p.add_argument('--output',default='data-audit.json');args=p.parse_args()
R=Path('/tmp/deadpan-projected-policy-destination-qualification-2026-10-31');O=Path(__file__).resolve().parent
def load(name):
 proof=R/f'{args.prefix}-{name}-proof.json'
 if not proof.exists():raise SystemExit('proof missing: '+proof.name)
 json.loads(proof.read_text())
 return json.loads((R/f'{args.prefix}-{name}-canonical.json').read_text())
old=load('before-shared-scoped');new=load(args.current)
counts=Counter();account_changes=[];partial=[];equations=[];scope_findings=[]
if 'separately funds flags before numerical finish' in new['scope']:scope_findings.append('stale heap-flags admission caption')
assert len(old['native_requests']['cases'])==len(new['native_requests']['cases'])==5
for a,b in zip(old['native_requests']['cases'],new['native_requests']['cases']):
 assert {k:v for k,v in a.items()if k!='operations'}=={k:v for k,v in b.items()if k!='operations'}
 assert len(a['operations'])==len(b['operations'])
 for x,y in zip(a['operations'],b['operations']):
  assert {k:v for k,v in x.items()if k!='paired'}=={k:v for k,v in y.items()if k!='paired'}
  before=x['paired']['new']['read']['output'];after=y['paired']['new']['read']['output']
  assert before==after
  counts['native_requests']+=1;counts[before['status']]+=1
for group,a,b in [
 ('internal',old['internal_and_transfer_paths']['cases'],new['internal_and_transfer_paths']['cases']),
 ('transfer',old['internal_and_transfer_paths']['public_transfers']['cases'],new['internal_and_transfer_paths']['public_transfers']['cases'])]:
 assert len(a)==len(b)==(10 if group=='internal'else 4)
 for i,(x,y)in enumerate(zip(a,b)):
  for key,value in x.items():
   if key.startswith('result_'):assert value==y[key];counts[group+'_output_fields']+=1
   if key.startswith('account_')and value!=y[key]:account_changes.append({'group':group,'case':i,'field':key,'before':value,'after':y[key]})
def walk(value,path=''):
 if isinstance(value,dict):
  if value.get('schema')=='native-mask-query-intervals-v1':
   assert value['active_intervals']==value['dropped_intervals']==0
   assert not value['misnested']and not value['overflow']
   counts['interval_snapshots']+=1
   for row in value['rows']:
    assert row['attributable']and not row['foreign_work_overlap']
    counts['interval_rows']+=1
    claim=row['claim']
    if claim is not None:
     assert claim['total']==claim['canonical']+claim['additional'];counts['completed_intervals']+=1
    else:counts['partial_intervals']+=1
    deltas=[]
    for lane in range(2):
     for label in ['native','host']:
      before=row[label+'_before'];after=row[label+'_after']
      assert before['reset_epoch']is not None and before['reset_epoch']==after['reset_epoch']
      assert not before['overflow']and not after['overflow']
     native=[b-a for a,b in zip(row['native_before']['lanes'][lane],row['native_after']['lanes'][lane])]
     host=row['host_after']['units'][lane]-row['host_before']['units'][lane]
     observed=row['work_after'][lane]-row['work_before'][lane]
     assert min(native)>=0 and host>=0 and observed>=0
     query=claim['expected_debit']if claim is not None and row['selected_lane']==lane else 0
     expected=query+sum(native)+host
     deltas.append({'lane':lane,'query':query,'native':sum(native),'host':host,'observed':observed,'expected':expected})
     if claim is not None:assert observed==expected,(path,claim,lane,deltas)
     else:
      deltas[-1]['query']=None;deltas[-1]['expected']=None
      deltas[-1]['known_native_host_subtotal']=sum(native)+host
      deltas[-1]['unclaimed_residual']=observed-sum(native)-host
    if claim is None:partial.append({'path':path,'row':row,'deltas':deltas})
    else:equations.extend(deltas)
  else:
   for key,child in value.items():walk(child,path+'/'+key)
 elif isinstance(value,list):
  for i,child in enumerate(value):walk(child,path+'/'+str(i))
walk(new)
def runs(words,start,frames):
 positions=[]
 for i,word in enumerate(words):
  assert isinstance(word,int)and 0<=word<1<<64
  for bit in range(64):
   if word&(1<<bit):
    at=i*64+bit;assert at<frames;positions.append(at+start)
 out=[]
 for at in positions:
  if out and out[-1][1]==at:out[-1][1]=at+1
  else:out.append([at,at+1])
 return out
cases=new['components_producer_cases']['cases']
assert len(cases)==4 and {x['name']for x in cases}=={'constant_block_positive','dynamic_positive','constant_zero_emission','measured_mark_work_refusal'}
case_summaries=[]
for case in cases:
 name=case['name'];trace=case['components_trace'];rows=trace['rows']
 assert trace['schema']=='components-inline-marks-v2'
 assert not trace['unfinished']and not trace['truncated_rows']and trace['active_row']is None
 assert trace['attempted_rows']==len(rows)and trace['dropped_rows']==0
 roots=[]
 for row in rows:
  assert not row.get('events_truncated',False)
  assert row['source_storage']=='inline_bitset'and row['source_heap_allocation']is False and row['source_heap_charge_frames']==0
  n=row['requested_frames'];assert 0<n<=256 and row['source_frames']==n
  assert row['source_init']['success']is True and row['inline_source_scope_closed']is True
  assert row['source_init']['plan_work_after']==row['source_plan_work_before']+4
  assert row['source_init']['cache_work_after']==row['source_cache_work_before']
  initial=row['inline_words_initial'];words=row['inline_words_latest']
  assert len(initial)==len(words)==row['inline_word_count']==4 and initial==[0]*4 and row['inline_bytes']==32
  wanted=runs(words,row['start'],n);m=sum(word.bit_count()for word in words)
  assert m==row['marks']['written_count']
  assert row['marks']['attempt_count']>=m
  if m:
   for edge in ['first','last']:
    attempt=row['marks'][edge+'_attempt'];accepted=row['marks'][edge+'_accepted_work_after']
    assert accepted['plan_work']==attempt['plan_work_before']+1
    assert accepted['cache_plan_work']==attempt['cache_plan_work_before']
    assert row['marks'][edge+'_written']==[attempt['index'],attempt['sample']]
  result=row['result'];assert isinstance(result,dict)
  if result['success']:
   assert row['raw_mark_count']==m
   assert result['mask_len']==len(wanted)and result['mask_capacity']==m
   if m:
    assert result['owned']and result['destination_identity_preserved']
    reserve=row['destination_reservation'];storage=row['destination_storage']
    assert reserve['accepted']and reserve['active_frames']>=row['source_reservation_frames']>0
    assert reserve['frames']==2*m+5 and storage['capacity']==m
   else:
    assert not result['owned']and row['destination_reservation']is None and row['destination_storage']is None
  else:
   assert name=='measured_mark_work_refusal'
   assert row['raw_mark_count']is None and m==0 and row['marks']['attempt_count']>0
   assert 'mask_capacity'not in result
   assert row['destination_reservation']is None and row['destination_storage']is None
   assert result['error']=='Limit("plan work per read")'
  if row['program_depth']==0:
   assert row['parent_row_id']is None
   roots.append((row,wanted))
 assert roots
 if name!='measured_mark_work_refusal':
  assert case['legacy']==case['active']and case['exact_output_match']
  assert case['active']['status']=='Ok'and case['provider_calls']>0
  all_ranges=[]
  for row,wanted in sorted(roots,key=lambda p:p[0]['start']):all_ranges.extend(wanted)
  merged=[]
  for a,b in all_ranges:
   if merged and a<=merged[-1][1]:merged[-1][1]=max(merged[-1][1],b)
   else:merged.append([a,b])
  assert merged==case['active']['suppressed']
  assert case['active_frames_after_request']==case['sound_context_frames_after_request']==0
  assert case['held_after_controller_drop']==case['held_while_output_live']
  assert case['held_while_output_live']-case['live_after_output_drop']==case['output_payload_frames']
 else:
  assert case['active']=={'status':'Error','error':'Limit("plan work per read")'}
  assert case['actual_mark_refusal_reached']and case['legacy_at_same_work_seed']is not None
  assert case['failure_fixture']=='checked_gain_aggregate'and case['expected_driver']=='dynamic'
  assert case['actual_driver_reached']is True and case['root_callback_count']==0
  failed_root=[row for row,_ in roots if row['start']==0];assert len(failed_root)==1
  assert case['root_first_attempt_plan_work_before']==failed_root[0]['marks']['first_attempt']['plan_work_before']==16*1024*1024
  measured=case['measured_first_attempt'];failed_attempt=failed_root[0]['marks']['first_attempt']
  assert measured['plan_work_before']+case['seed_from_actual_first_mark']==failed_attempt['plan_work_before']
  assert (measured['index'],measured['sample'])==(failed_attempt['index'],failed_attempt['sample'])
  assert case['active_frames_after_request']==case['sound_context_frames_after_request']==0
 root=[row for row,_ in roots if row['start']==(8128 if name=='dynamic_positive'else 0)]
 assert len(root)==1;root=root[0]
 driver='dynamic'if name in ['dynamic_positive','measured_mark_work_refusal']else'constant'
 assert driver in root['driver_kinds']
 if name=='dynamic_positive':assert root['callback_count']>0
 if name in ['constant_block_positive','dynamic_positive']:
  assert root['marks']['written_count']>0
  a=root['marks']['first_attempt'];b=root['marks']['first_accepted_work_after']
  assert b['plan_work']==a['plan_work_before']+1 and b['cache_plan_work']==a['cache_plan_work_before']
 case_summaries.append({'name':name,'rows':len(rows),'root_raw_count':root['raw_mark_count'],'root_writes':root['marks']['written_count'],'root_callbacks':root['callback_count'],'root_destination_capacity':root.get('destination_storage'),'active':case['active']if name=='measured_mark_work_refusal'else{'status':case['active']['status'],'mask_capacity':case['active']['mask_capacity'],'suppressed':case['active']['suppressed']},'legacy_seed_status':case.get('legacy_at_same_work_seed',{}).get('status'),'held':case.get('held_while_output_live'),'after_drop':case.get('live_after_output_drop'),'payload_frames':case.get('output_payload_frames')})
assert counts['native_requests']==744 and counts['Ok']==264 and counts['Error']==480
assert counts['interval_snapshots']==758 and counts['interval_rows']==478 and counts['completed_intervals']==477 and counts['partial_intervals']==1
assert counts['internal_output_fields']+counts['transfer_output_fields']==42
result={'prefix':args.prefix,'capture':args.current,'counts':dict(counts),'classic_account_changes':account_changes,'components_cases':case_summaries,'partial_interval':partial,'completed_lane_equations':len(equations),'scope_findings':scope_findings}
O.joinpath(args.output).write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items()if k not in ['partial_interval','components_cases']}))
