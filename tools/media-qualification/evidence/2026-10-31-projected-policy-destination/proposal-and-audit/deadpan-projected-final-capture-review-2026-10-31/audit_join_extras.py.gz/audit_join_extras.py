from pathlib import Path
import hashlib,json,re
G=Path('/tmp/deadpan-projected-policy-destination-qualification-2026-10-31');O=Path(__file__).resolve().parent
roots={'main':Path('/Users/michael/Code/deadpan'),'scoped':Path('/tmp/deadpan-query-groundwork-2026-10-26/scoped')}
def load(p):return json.loads(p.read_text())
def pin(p):
 h=hashlib.sha256()
 with p.open('rb')as f:
  while b:=f.read(1024*1024):h.update(b)
 return {'bytes':p.stat().st_size,'sha256':h.hexdigest()}
def pinned(r):
 p=G/r['path'];assert pin(p)=={k:r[k]for k in ['bytes','sha256']};return p
def streams(r):
 for p,want in r['streams'].items():assert pin(Path(p))==want,p
join=load(G/'projected-final2-qualification-join.json');assert len(join['runs'])==70
seen=set();sources={}
for v in roots:
 build=load(pinned(join['builds'][v]['receipt']));pinned(join['builds'][v]['pins'])
 sources[v]=build['source_after'];pinned(join['matrices'][v])
for row in join['runs']:
 assert row['label']not in seen;seen.add(row['label'])
 r=load(pinned(row['receipt']));v=row['variant']
 assert r['exit_code']==0 and r['sources_unchanged']and r['binaries_unchanged']
 assert r['source_before']==r['source_after']==sources[v]
 assert r['binary_before']==r['binary_after']
 for path,p in r['binary_before'].items():assert pin(Path(path))==p
 for key in ['command','environment','seconds']:assert row[key]==r[key]
 assert Path(r['cwd']).resolve()==roots[v].resolve()
 streams(r)
owned=load(G/'owned-code-paths.json');assert len(owned)==len(set(owned))==10
source_records={};unowned={}
for v,root in roots.items():
 original=load(G/f'{v}-initial-authority.json')
 for name,want in original.items():
  if name not in owned:assert pin(root/name)==want,(v,name)
 unowned[v]=sum(x not in owned for x in original)
 source_records[v]={name:pin(root/name)for name in owned}
 oracles=load(G/'immutable-oracle-pins35.json');assert len(oracles)==35
 for row in oracles:assert pin(root/row['path'])['sha256']==row['sha256']
assert source_records['main']==source_records['scoped']
assert unowned==join['unowned_initial_inputs_exact']=={'main':2932,'scoped':2604}
before=[]
for v in roots:
 stem=f'projected-final2-source-before-{v}'
 p=load(G/f'{stem}-proof.json');r=load(G/f'{stem}.json')
 binaries=load(G/f'projected-active-build2-{v}-pins.json');binary=next(b for b in binaries if b['name']=='deadpan_audio')
 assert Path(r['command'][0]).resolve()==Path(binary['path']).resolve()
 assert r['command'][1:]==['--ignored','--exact','stages::routed::routed_projected_mask_tests::capture_routed_projected_mask_before_g','--test-threads=1','--nocapture']
 bp=G/f'{stem}-body.json';cp=G/f'{stem}-canonical.json';body=load(bp)
 assert pin(bp)=={k:p['body'][k]for k in ['bytes','sha256']}=={'bytes':58670,'sha256':'9e2349a6948302c51872cb4669637f256c8521e182e607b0885bd02e3d9767ad'}
 assert pin(cp)==p['canonical']=={'bytes':23896,'sha256':'d77865693996e74e6d1bee6a33510fde658a70e1f8919fc4cff67aea243b5ee9'}
 assert cp.read_bytes()==json.dumps(body,sort_keys=True,separators=(',',':')).encode()
 assert Path(r['environment']['DEADPAN_ROUTED_PROJECTED_MASK_BEFORE_OUTPUT']).resolve()==bp.resolve()
 before.append({'variant':v,'raw':pin(bp),'canonical':pin(cp),'command':r['command']})
checks=load(G/'remaining-checks2-summary.json');assert len(checks)==8
checks_out=[]
for x in checks:
 r=load(G/(x['label']+'.json'));text=(G/(x['label']+'.stdout')).read_text()
 assert x['exit_code']==r['exit_code']==0
 if '-doc' in x['label']:assert 'test result: ok. 0 passed; 0 failed;'in text
 checks_out.append({'label':x['label'],'command':r['command'],'stdout':pin(G/(x['label']+'.stdout')),'stderr':pin(G/(x['label']+'.stderr'))})
expected=set()
for v in roots:
 expected|={x['run']for x in load(G/f'projected-matrix2-{v}-matrix.json')}
 expected|={f'projected-final2-{m}-{v}'for m in ['active','active2','active3','before-old','before-intervals','before-policy','before-root','before-shared','before-components','source-before']}
expected|={r['label']for r in checks}
assert seen==expected
out={'status':'all 70 actual receipts joined, streams/source/binary guards checked','runs':len(seen),'checks':checks_out,'source_before':before,'owned':source_records['scoped'],'unowned_initial_exact':unowned,'immutable_oracles':35,'join':pin(G/'projected-final2-qualification-join.json')}
(O/'join-extra-audit.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({k:out[k]for k in ['status','runs','unowned_initial_exact','immutable_oracles','join']}))
