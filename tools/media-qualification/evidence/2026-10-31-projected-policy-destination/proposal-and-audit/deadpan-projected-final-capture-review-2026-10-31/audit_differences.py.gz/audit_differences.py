from pathlib import Path
from itertools import combinations
import json,hashlib,struct
G=Path('/tmp/deadpan-projected-policy-destination-qualification-2026-10-31')
F=Path('/tmp/deadpan-components-mask-qualification-2026-10-31')
O=Path(__file__).resolve().parent
def load(p):return json.loads(p.read_text())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def diff(a,b,p=''):
 if type(a)is not type(b):yield {'path':p,'before':a,'after':b};return
 if isinstance(a,dict):
  for k in sorted(a.keys()|b.keys()):
   q=p+'/'+k.replace('~','~0').replace('/','~1')
   if k not in a or k not in b:yield {'path':q,'before':a.get(k),'after':b.get(k),'presence':'added'if k not in a else'removed'}
   else:yield from diff(a[k],b[k],q)
 elif isinstance(a,list):
  if len(a)!=len(b):yield {'path':p+'/length','before':len(a),'after':len(b)}
  for i,(x,y)in enumerate(zip(a,b)):yield from diff(x,y,p+'/'+str(i))
 elif a!=b:yield {'path':p,'before':a,'after':b}
base='/components_producer_cases/cases/1/'
# Closed path set reviewed from actual affected rows and typed work observer fields.
# No old F whitelist, arbitrary row or leaf-suffix acceptance.
nodes3=['result/plan_work_after','source_init/plan_work_after','source_plan_work_before']
marknodes=['marks/first_accepted_work_after/plan_work','marks/first_attempt/plan_work_before','marks/last_accepted_work_after/plan_work','marks/last_attempt/plan_work_before']
allowed={base+'work/plan_work'}
allowed|={base+'components_trace/rows/0/'+x for x in ['result/plan_work_after']+marknodes}
allowed|={base+f'components_trace/rows/{i}/'+x for i in range(7,13)for x in nodes3}
allowed|={base+f'components_trace/rows/{i}/'+x for i in range(13,21)for x in nodes3+marknodes}
assert len(allowed)==80
meta={'/schema','/scope','/projected_policy_checkpoint','/projected_policy_before','/projected_policy_cases','/native_requests/scope'}
meta|={f'/internal_and_transfer_paths/cases/{i}/scope/internal_masks'for i in range(10)}
bodies={f'{m}/{v}':load(G/f'projected-final2-{m}-{v}-canonical.json')for m in ['active','active2','active3']for v in ['main','scoped']}
fref={v:load(F/f'components-final13-active-{v}-canonical.json')for v in ['main','scoped']}
before=load(G/'projected-final2-source-before-main-body.json')
corpus=load(G/'portable-corpus-candidate2.json')
assert before==corpus['source_ready_before']
scope='Projected PreserveTape Signal destinations copy the actual completed ordinary policy Vec into native owned storage while prepared PCM remains live. Public route mapping admits its separate destination. Ordinary policy queries and their source Vec, exhausted vectors and whole preparation remain outside this claim.'
native_scope='744 actual active native requests with Point, Root, SharedMix, Components and projected Signal destination admission. Query claims and native work remain separate.'
internal_scope='Native destinations, Point Signal policy custody and projected PreserveTape destination copies are admitted. Ordinary projected policy source queries and exhausted vectors remain outside this claim.'
contexts={}
for key,b in bodies.items():
 assert b['schema']=='active-projected-policy-destination-after-v1'
 assert b['scope']==scope and b['native_requests']['scope']==native_scope
 assert b['projected_policy_checkpoint']=='59874646dba6974da77e2cad08e9bc4822fd5afe'
 assert b['projected_policy_before']=={'path':'tests/fixtures/projected-policy-destination-baseline-v1/corpus.json','sha256':'93912d8a589912b7ef41f0bd523db8da2a6cdec0d2ea5db1b6ba6f9941dffa51'}
 assert all(x['scope']['internal_masks']==internal_scope for x in b['internal_and_transfer_paths']['cases'])
 p=b['projected_policy_cases']
 assert set(p)==set(before)and p['schema']=='deadpan.routed_projected_mask.active.v1'and p['capture_mode']=='G active destination ownership'
 assert p['provider_calls']==before['provider_calls']==12
 assert p['limitations']==[
  'Raw source-ready receipts must match literally across modes; destination admission occurs after those receipts.',
  'Each public read gets a fresh request-local projected memo; repeated calls only reuse StageAudio-owned caches if measured.',
  'No public negative/fractional retained-coordinate case is asserted.']
 for name,positive in [('source_only_empty',False),('explicit_silent_hold_positive',True),('shared_renderer_first_empty',False),('shared_renderer_second_positive',True)]:
  a=before[name];z=p[name]
  want=json.loads(json.dumps(a));want['public_block']['suppressed_owned']=positive
  assert z==want,(key,name)
  assert z['result']=='Ok'and len(z['source_rows'])==1
  assert len(z['result_samples_f32_bits'])==256
  flat=[bit for frame in z['result_samples_f32_bits']for bit in frame]
  raw=b''.join(struct.pack('<I',x)for x in flat)
  assert hashlib.sha256(raw).hexdigest()==z['result_samples_f32_bits_sha256_le']
  assert z['public_block']['suppressed_ranges']==([[615,768]]if positive else[])
  assert z['public_block']['suppressed_capacity']==(1 if positive else 0)
 c=b['components_producer_cases']['cases'][1]
 assert c['name']=='dynamic_positive'and len(c['components_trace']['rows'])==21
 ctx=[]
 for i in [0,*range(7,21)]:
  r=c['components_trace']['rows'][i]
  assert r['row_id']==i
  if i==0:assert(r['start'],r['requested_frames'],r['program_depth'],r['parent_row_id'],r['driver_kinds'],r['callback_count'])==(8128,128,0,None,['dynamic'],64)
  else:assert(r['start'],r['requested_frames'],r['program_depth'],r['parent_row_id'],r['driver_kinds'],r['callback_count'])==(4864+256*i,256,1,0,['constant'],0)
  ctx.append({k:r[k]for k in ['row_id','parent_row_id','start','requested_frames','program_depth','driver_kinds','callback_count','source_reservation_frames']})
 contexts[key]=ctx
def workrecords(diffs):
 for d in diffs:
  assert d['path']in allowed,d['path']
  assert type(d['before'])is int and type(d['after'])is int,d
  assert d['before']>=0 and d['after']>=0
  d['delta']=d['after']-d['before']
 return diffs
vf={};pp={}
for key,b in bodies.items():
 all_d=list(diff(fref[key.split('/')[1]],b))
 md=[d for d in all_d if d['path']in meta]
 assert {d['path']for d in md}==meta
 vf[key]={'metadata':md,'work':workrecords([d for d in all_d if d['path']not in meta])}
for (ka,a),(kb,b)in combinations(bodies.items(),2):pp[ka+' vs '+kb]=workrecords(list(diff(a,b)))
def summary(records):
 return {'records':sum(map(len,records)),'paths':sorted({d['path']for r in records for d in r}),'max_abs_delta':max(abs(d['delta'])for r in records for d in r)}
sv=summary([x['work']for x in vf.values()]);sp=summary(list(pp.values()))
assert sv['records']==304 and sp['records']==855 and set(sv['paths'])==set(sp['paths'])==allowed
assert sv['max_abs_delta']==3 and sp['max_abs_delta']==5
parent=load(G/'analysis-draft2/projected-final2-work-audit.json')
assert parent['g_vs_f_work_summary']['path_inventory']==sv['paths']
for k,v in vf.items():
 ours=v['work'];theirs=parent['g_vs_f'][k]['differences']
 assert [{a:d[a]for a in ['path','before','after','delta']}for d in ours]==[{a:d[a]for a in ['path','before','after','delta']}for d in theirs]
out={'status':'independent complete recursive differences qualified','vs_F_summary':sv,'pairwise_G_summary':sp,'G_vs_F':vf,'G_pairwise':pp,'typed_contexts':contexts,'scope':'These are literal observations for six captures, not a golden/normalizer or permission for future paths.'}
(O/'literal-differences.json').write_text(json.dumps(out,indent=2)+'\n')
(O/'closed-work-paths.json').write_text(json.dumps(sorted(allowed),indent=2)+'\n')
print(json.dumps({'status':out['status'],'vs_F':{k:v for k,v in sv.items()if k!='paths'},'pairwise_G':{k:v for k,v in sp.items()if k!='paths'},'paths':len(allowed),'projected_cases':24}))
