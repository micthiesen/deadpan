# G final capture and qualification review

GO for this destination-copy checkpoint. No material source, output, custody, receipt, or capture-classification blocker found. This is a read-only audit of actual parent executions, not an execution claim by this reviewer. Final portable archive reference resolution remains required after the G archive is created.

The separate source review is /tmp/deadpan-projected-destination-final-source-review-2026-10-31.md. Scope is shipping authority. Product scope and Gates remain unchanged.

## Independent qualification

audit_sources.py verifies actual compiler-artifact records for 21 unique Audio targets per optimized build2, executable bytes/profiles, all 42 matrix commands/counts, all 18 overall capture commands, environment/checkpoint bindings, source manifests, raw-to-canonical serialization, proofs and stream hashes. audit_join_extras.py checks the complete 70-run join, eight other checks, two source-before replays, all 35 immutable payloads, ten owned paths and initial unowned files.

Actual totals are Main 1140 passed, 27 ignored and seven known Split tests filtered; Scope 1134 passed, 27 ignored and none filtered. Libraries are 559/553. Main strict check, Scope all-target Audio Clippy, both format checks, both Audio doctests and both hygiene checks pass. Doctests have zero examples. Both builds have 21 actual Audio test artifacts at opt2, with overflow checks and debug assertions. Guarded Rust inputs number 2942 Main / 2614 Scope. Initial unowned files remain exact: 2932 Main / 2604 Scope. All ten owned files match across roots.

The actual join is 87661 bytes, SHA256 472786e87e8609f64ba62d7ef30475ca3270ef0b2865d9e34ef9b24711e91163. Its own text correctly leaves semantic acceptance to an independent audit.

Each of six current bodies, and separately both F compatibility replays, was checked by audit_data.py:

- All 744 complete native outputs remain exact: 264 Ok and 480 Error.
- All 42 internal/public-transfer result fields remain exact; no new account-field change appears against that check's old comparison.
- 758 interval snapshots contain 478 rows: 477 completed and one claimless partial. Both lanes of every completed row reconcile, giving 954 equations per capture. Inclusive nested intervals are not summed.
- The literal partial remains observed plan work 6, known native subtotal 1, host 0 and unclaimed residual 5. It does not prove an invented query claim or zero residual.
- All 1558 Components rows per capture, 9348 across six current bodies, are complete and untruncated. Real source-init debit is plan 4 / cache 0. Accepted first/last Mark debit is plan 1 / cache 0; written positions match attempts and popcount matches writes.
- Inline scratch is four words / 32 bytes with no heap source allocation/charge. Nonzero destinations retain funded capacity/custody; zero emission has no destination. Actual checked same-root driver/callback/mark evidence, cleanup and held-output account equations pass.
- The measured failure is the actual gain-only dynamic first-Mark refusal at the maximum plan-work counter, without an accepted bit or destination.

The four direct projected cases per current body, 24 observations, separately match the frozen source-ready body. Every source receipt, PCM f32 bit and recomputed little-endian SHA256, public metadata, exhaustion, mask range/capacity, dependencies, provider calls and remaining case field is exact. Only the two positive cases change the expected public owned flag to true. Positive output is [615,768), capacity 1; empty remains len/capacity 0. Source-ready observations remain ordinary pre-copy observations.

Both final source-before replays match native3 literally: raw 58670 bytes / 9e2349a6948302c51872cb4669637f256c8521e182e607b0885bd02e3d9767ad; canonical 23896 bytes / d77865693996e74e6d1bee6a33510fde658a70e1f8919fc4cff67aea243b5ee9. This direct source canonical encoding has no final LF; overall captures have one. Neither was rewritten.

## Literal work variance

audit_differences.py independently traverses entire trees. It uses no old F whitelist or normalization. The closed 80-path set is reviewed against actual typed source/Mark/result nodes and row identity:

- Dynamic positive case 1 only.
- Row 0: first/last Mark attempt and accepted plan counters, plus result plan counter.
- Rows 7–12: source-before, source-init-after and result plan counters.
- Rows 13–20: those three plus four Mark counters.
- The case's final plan-work counter.

Row 0 is the dynamic root at 8128, 128 frames, depth 0, 64 callbacks. Affected child rows have identical identities, depth 1, parent 0, constant driver, zero callbacks and 256-frame starts 6656 through 9984. Differences are nonnegative typed integers at these exact nodes. All other structures, outputs, errors, capacities, cache counters, source/destination observations and local debits remain exact.

Against each variant's actual F active reference, six G captures contain 304 differing leaves at exactly those 80 paths, max absolute delta 3. All fifteen pairwise G comparisons contain 855 differing leaves at the same paths, max absolute delta 5. Full values remain in literal-differences.json and exact paths in closed-work-paths.json. This records these observations; it does not authorize future differences.

Sixteen additional G metadata nodes are explicit: schema, scope, checkpoint, before-corpus descriptor, new projected case section, native scope and ten internal-mask scope strings. Their literal G values are checked. Active projected schema/caption/limitations are checked separately, not blindly equated to before-mode captions.

## Six immutable current observations

Every current canonical body is 38554371 bytes. They are individually pinned, not a byte-identical golden.

| Capture | SHA256 |
| --- | --- |
| active Main | cef172ebf9b8dbb1aaed27b2874109aad65e7081c6939680d3dcaaa88dac3b60 |
| active Scope | ef140d066ce656acc84ad435006a999c9c32a62c7c1b497ad35048c870f10849 |
| active2 Main | 76cb20e891da99876bd42a344d6604293226d9439f113a305ef685dc46d0b79f |
| active2 Scope | e14218c00bafcd25cbb0c2c5569dc87f68c4e95660eea408647c7b5769f7e3cc |
| active3 Main | e4da5e869e34d60cf75a1920402eee8e988c587aa9df0f03ea38f225871e8d56 |
| active3 Scope | 5f2d334a350df29b27b411510f76b21b410eb2c4b1029b66cdf35feb398ab4e1 |

Five older replay modes remain exact to their own immutable bodies in both roots. F replay is assessed through literal observations/local invariants, not falsely asserted globally byte-identical.

## Limits and failures

G funds only the copied completed projected Signal destination and downstream separately admitted mapping destinations. The ordinary policy source Vec, query/inventory and legacy merge remain a gap. Source residency is not retroactively invented. The prepared PCM owner and real memo residency remain alive through copy admission. The three destination boundary/lifetime tests establish isolated warmed destination overlap, not whole preparation. No new negative/fractional retained-coordinate, cancellation or deadline coverage is claimed.

Historical actual test compilation failures (ambiguous constructor, digest formatting) and observer Clippy argument-count failure remain historical; later successful artifacts are bound here. Surface's first analysis failed a 34-vs-35 pin-file check. Its stdout/stderr survive, but the overwritten failed script's source hash is unrecoverable and explicitly recorded. The successful ffb3919f… script/output are pinned. Its broader suffix classifier is not this review's acceptance rule: the independent exact 80-path check and every-row local-debit audit provide the narrower proof.

This review's first difference-audit draft wrongly required active limitations to equal before-mode text. That assertion failed. The rejected draft remains audit_differences_initial_rejected.py. The final audit verifies deliberate literal active limitations against source without changing capture data.

No root changes, Cargo/build/native execution, Git or publication were performed by this reviewer. The next admitted provider-aware Signal child-kernel design is separately reviewed and is not G implementation evidence.
