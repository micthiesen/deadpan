# Projected-mask active capture candidate

Scratch-only additive test/capture proposal. No repository source, build, or native executable was changed or run.

## Source pins

Current Main and Scope have identical source-ready fixture inputs:

- `crates/deadpan-audio/src/routed_projected_mask_tests.rs`: SHA-256 `4fc1386457fa7917c7e6fe4cbc0c420b5682df11292d159e6394c6339f874ef3`
- `crates/deadpan-audio/src/routed.rs`: SHA-256 `4d69e36d86973816c6dae24435f33a8de8f8e2dc29bf498f6d2d49cceb9e504f`
- `crates/deadpan-audio/tests/fixtures/projected-policy-destination-baseline-v1/corpus.json`: SHA-256 `93912d8a589912b7ef41f0bd523db8da2a6cdec0d2ea5db1b6ba6f9941dffa51`

The same hashes were observed in Main (`/Users/michael/Code/deadpan`) and Scope (`/tmp/deadpan-query-groundwork-2026-10-26/scoped`).

## Proposed files

- `new/routed_projected_mask_tests.rs` plus `routed_projected_mask_tests.patch`: parameterizes the existing expected-ownership assertion without changing the old before-capture schema, adds an active-mode capture function, adds an ordinary regression test against the frozen `source_ready_before`, and adds an ignored `create_new` capture using `DEADPAN_PROJECTED_POLICY_AFTER_OUTPUT`.
- `new/routed.rs` plus `routed_wrapper.patch`: exposes the active capture function to `crate::stages` under the same macOS/Linux test cfg as the existing fixture module.

The ordinary test compares all 256 PCM f32 bit pairs, digest, exact source-ready receipt rows, provider totals, every public block field except the intentionally changed `suppressed_owned` value, and then checks expected ownership separately. The empty cases stay unowned; positive cases require owned masks. The old ignored before capture remains under its original schema and legacy wrapper.

The active capture does not assert a warmed StageAudio cache: the existing fixture records zero cache entries, and each public read has a fresh request-local projected memo. Runtime execution and integration are parent-owned; this candidate has only been rustfmt-formatted with `skip_children=true`, not compiled or run.
