from pathlib import Path
import hashlib
import json
import math
import re
import struct

directory = Path('/tmp/deadpan-projected-policy-destination-qualification-2026-10-31')
output = Path(__file__).resolve().parent
roots = {'main': Path('/Users/michael/Code/deadpan'), 'scoped': Path('/tmp/deadpan-query-groundwork-2026-10-26/scoped')}
cache = {}


def pin(path):
    path = Path(path)
    key = str(path.resolve())
    if key not in cache:
        digest = hashlib.sha256()
        with path.open('rb') as stream:
            while chunk := stream.read(1048576):
                digest.update(chunk)
        cache[key] = {'bytes': path.stat().st_size, 'sha256': digest.hexdigest()}
    return cache[key]


def load(path):
    return json.loads(Path(path).read_text())


def streams(receipt):
    for path, expected in receipt['streams'].items():
        assert pin(path) == expected, path


results = []
documents = []
for variant, root in roots.items():
    build_name = f'projected-before-build2-{variant}'
    name = f'projected-before-native2-{variant}'
    proof = load(directory / f'{name}-proof.json')
    build = load(directory / f'{build_name}.json')
    native = load(directory / f'{name}.json')
    assert build['exit_code'] == native['exit_code'] == 0
    assert build['sources_unchanged'] and native['sources_unchanged'] and native['binaries_unchanged']
    assert build['source_before'] == build['source_after'] == native['source_before'] == native['source_after']
    assert Path(build['cwd']).resolve() == Path(native['cwd']).resolve() == root.resolve()
    for path, expected in build['source_after'].items():
        assert pin(path) == expected, path
    for receipt in [build, native]:
        streams(receipt)
        assert receipt['environment']['CARGO_INCREMENTAL'] == '0'
        assert receipt['environment']['CARGO_PROFILE_DEV_OPT_LEVEL'] == '2'
        assert 'ffmpeg-8.0.3' in receipt['environment']['DEADPAN_FFMPEG_PREFIX']
        assert 'onnxruntime-1.31.0' in receipt['environment']['DEADPAN_ORT_PREFIX']
    artifacts = []
    for line in (directory / f'{build_name}.stdout').open():
        try:
            value = json.loads(line)
        except ValueError:
            continue
        if value.get('reason') == 'compiler-artifact' and value.get('executable') and value.get('target', {}).get('name') == 'deadpan_audio':
            assert Path(value['manifest_path']).resolve() == (root / 'crates/deadpan-audio/Cargo.toml').resolve()
            artifacts.append(value)
    assert len(artifacts) == 1
    pins = load(directory / f'{build_name}-pins.json')
    assert len(pins) == 1 and pins[0]['artifact'] == artifacts[0]
    binary = pins[0]
    assert pin(binary['path']) == {'bytes': binary['bytes'], 'sha256': binary['sha256']}
    profile = artifacts[0]['profile']
    assert profile['test'] and profile['opt_level'] == '2' and profile['overflow_checks'] and profile['debug_assertions']
    expected_binary = {str(Path(binary['path']).resolve()): pin(binary['path'])}
    for field in ['binary_before', 'binary_after']:
        assert {str(Path(path).resolve()): value for path, value in native[field].items()} == expected_binary
    assert Path(native['command'][0]).resolve() == Path(binary['path']).resolve()
    assert native['command'][1:] == ['--ignored', '--exact', 'stages::routed::routed_projected_mask_tests::capture_routed_projected_mask_before_g', '--test-threads=1', '--nocapture']
    assert re.search(r'test result: ok\. 1 passed; 0 failed;', (directory / f'{name}.stdout').read_text())
    body_path = directory / f'{name}-body.json'
    assert Path(native['environment']['DEADPAN_ROUTED_PROJECTED_MASK_BEFORE_OUTPUT']).resolve() == body_path.resolve()
    assert proof['variant'] == variant and proof['build'] == build_name and proof['native_receipt'] == f'{name}.json'
    assert pin(body_path) == {key: proof['body'][key] for key in ['bytes', 'sha256']}
    assert pin(body_path) == {'bytes': 58362, 'sha256': '7599fcd2f145417704e767afedf8dfc05afddd9c0620a4f22cf045bca97870dc'}
    document = load(body_path)
    canonical = (json.dumps(document, sort_keys=True, separators=(',', ':')) + '\n').encode()
    assert (directory / f'{name}-canonical.json').read_bytes() == canonical
    assert pin(directory / f'{name}-canonical.json') == proof['canonical'] == {'bytes': 23668, 'sha256': '60fd3f91f8b319b4e500ba3a99cf374035571094ae81c48db620d7cd49989cbe'}
    assert document['schema'] == 'deadpan.routed_projected_mask.before.v2'
    assert document['capture_mode'] == 'pre-G source-ready only'
    case_results = []
    previous_calls = 0
    for key, start, expected_ranges, expected_work in [
        ('source_only_empty', 0, [], 189),
        ('explicit_silent_hold_positive', 512, [[615, 768]], 194),
        ('shared_renderer_first_empty', 0, [], 189),
        ('shared_renderer_second_positive', 512, [[615, 768]], 194),
    ]:
        case = document[key]
        assert case['case'] == key and case['result'] == 'Ok' and case['branch_reached']
        assert case['trace_attempted'] == 1 and case['trace_dropped'] == 0 and len(case['source_rows']) == 1
        row = case['source_rows'][0]
        assert row['start'] == start and row['frames'] == 256
        assert row['source_len'] == row['source_capacity'] == row['source_range_count'] == len(expected_ranges)
        assert row['source_ranges'] == case['preasserted_policy_ranges'] == expected_ranges
        assert not row['source_ranges_truncated'] and row['source_allocation_nonempty'] == bool(expected_ranges)
        assert row['prepared_dependencies'] == 1 and row['prepared_relative_depth'] == 0
        assert row['cached_stages'] == row['cached_resident_frames'] == row['active_frames'] == row['account_live_frames'] == 0
        assert row['plan_work_after_suppression'] == expected_work and row['cache_plan_work_after_suppression'] == 0
        assert case['before_cached_stages'] == case['after_cached_stages'] == 0
        assert case['provider_calls_before'] == previous_calls and case['provider_calls_after'] == previous_calls + 3
        previous_calls += 3
        public = case['public_block']
        assert set(public) == {'allocation', 'project_id', 'revision_id', 'sample_capacity', 'sample_len', 'schema_version', 'stage', 'start', 'suppressed_capacity', 'suppressed_len', 'suppressed_owned', 'suppressed_ranges'}
        assert public['allocation'] == [0, 768] and public['start'] == start
        assert public['project_id'] == 'controlled-read' and public['revision_id'] == 'revision'
        assert public['schema_version'] == 1 and public['stage'] == 'routed_signal_pcm_before_effects_and_current_gates'
        assert public['sample_len'] == public['sample_capacity'] == 256
        assert public['suppressed_ranges'] == expected_ranges and not public['suppressed_owned']
        assert public['suppressed_len'] == public['suppressed_capacity'] == len(expected_ranges)
        bits = case['result_samples_f32_bits']
        assert len(bits) == 256
        raw = bytearray()
        for pair in bits:
            assert len(pair) == 2 and all(type(word) is int and 0 <= word < 1 << 32 for word in pair)
            raw.extend(struct.pack('<II', *pair))
            assert all(math.isfinite(value) for value in struct.unpack('<ff', struct.pack('<II', *pair)))
        assert hashlib.sha256(raw).hexdigest() == case['result_samples_f32_bits_sha256_le']
        for left, right in expected_ranges:
            assert all(pair == [0, 0] for pair in bits[left-start:right-start])
        case_results.append({'case': key, 'source_ranges': expected_ranges, 'source_len_capacity': len(expected_ranges), 'pcm_bits_sha256_le': hashlib.sha256(raw).hexdigest(), 'cumulative_plan_work': expected_work, 'provider_calls': 3})
    assert previous_calls == document['provider_calls'] == 12
    assert document['source_only_empty']['result_samples_f32_bits'] == document['shared_renderer_first_empty']['result_samples_f32_bits']
    assert document['explicit_silent_hold_positive']['result_samples_f32_bits'] == document['shared_renderer_second_positive']['result_samples_f32_bits']
    documents.append(document)
    results.append({'variant': variant, 'build': build_name, 'binary': pin(binary['path']), 'source_inputs': len(build['source_after']), 'raw': pin(body_path), 'canonical': proof['canonical'], 'cases': case_results})
assert documents[0] == documents[1]
output.mkdir(exist_ok=True)
(output / 'audit-results.json').write_text(json.dumps({'status': 'actual_source_ready_baseline_freeze_go', 'variants': results, 'limits': ['no destination ownership/admission proof', 'no StageAudio cache reuse observed', 'request-local projected residency not included in these cached/active counters', 'no isolated query fee claim']}, indent=2) + '\n')
print(json.dumps({'status': 'actual_source_ready_baseline_freeze_go', 'variants': len(results), 'cases_per_variant': 4, 'canonical': results[0]['canonical']}))
