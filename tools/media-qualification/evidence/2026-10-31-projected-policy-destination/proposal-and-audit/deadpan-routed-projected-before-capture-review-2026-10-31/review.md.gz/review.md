# Actual pre-G projected baseline freeze review

GO to freeze baseline 3 as the bounded source-ready/numerical before corpus. No G production admission has been implemented or qualified by these captures. This reviewer performed source reads, hashes and Python evidence analysis only; parent owns the builds/native executions.

## Actual evidence

Both optimized library builds and serial ignored captures pass. I independently joined each exact compiler-artifact, optimized/debug/overflow profile, pinned executable bytes, executed command, environment, source-before/after maps, binary-before/after maps and stdout/stderr hashes. Current guarded inputs are 2939 Main/2611 Scope. The source-ready hook is test-only; projected suppression still becomes Plain. Scope Clippy 2 passes with exact streams/source guards.

Main and Scope raw bodies are identical 58,670 bytes:
9e2349a6948302c51872cb4669637f256c8521e182e607b0885bd02e3d9767ad.

Compact sorted JSON with no trailing LF is identical 23,896 bytes:
d77865693996e74e6d1bee6a33510fde658a70e1f8919fc4cff67aea243b5ee9.

The audit reconstructs that canonical form directly from each raw body without deleting fields. My first audit incorrectly appended a trailing LF, inherited from the F capture convention; correcting the auditor to this actual convention resolved that audit-only mismatch. No capture bytes were changed.

All four actual public reads succeed with exactly one SourceReady row, no dropped/truncated observations, real provider calls and actual Plain result:
- source_only_empty and shared_renderer_first_empty read 0..256. Source and returned mask length/capacity are 0; ranges are empty.
- explicit_silent_hold_positive and shared_renderer_second_positive read 512..768. Actual source, independently preasserted policy and returned mask all equal [615,768), length/capacity 1, Plain.
- Every public block records all metadata, 256 stereo samples as exact f32 bit pairs, sample capacity 256 and actual mask metadata. The audit checks every word's range, PCM finiteness, stored hash and zeroed masked samples. Empty PCM hash is c70165e2a11557ce9b0cba5d5a49206b1292dc448f885c8de1bb1ae60b81cb01; positive PCM hash is caa35b459becfe4bea03b5f4bc154d940af8ac55137be8dc9b615a38ed4b4463. Hashes are over little-endian channel words. Each same-renderer result's full bit vector matches its separate-renderer counterpart.
- Actual source-ready cumulative plan work is 189 empty/194 positive, cache work 0, prepared dependency count 1 and prepared relative depth 0. These are observations, not isolated policy fees.
- Controller cache counts/resident frames, active frames and owned-mask account frames are 0. Separately observed existing request-local projected PCM residency is 768 frames and projected disk bytes 0 in every row. Do not collapse these into a false zero-source-residency statement.
- Provider calls advance by 3 per actual read, 12 total. Same-renderer observations show no StageAudio cache reuse. Request-local projected memoization is not a cross-call cache claim.

## Source corrections and retained evidence

V1's frame-limit/helper/import/TIMEOUT issues were static findings. V4 actually failed compilation in both roots on ambiguous AudioSoundRoute::new and unsupported digest-container LowerHex; my earlier static GO missed those API problems. Parent's test-only explicit SignalSample constructor and byte-wise hash formatting are the versions built successfully.

Clippy 1 then failed the observer's eight-argument signature. Parent reduced it to six by borrowing the actual Vec and reading capacity/pointer inside the enabled observer. This adds no detached copy, admission, lease or work debit. The same observer now reads actual ReadWork.projected_resident_frames/disk fields. Disabled observation still returns before reading WorkControl.work. Current root/observer/test hashes are pinned; test source remains 8fe2760d8bbf5ab3d0d2060f18dc114ed4b5c269d1589d8adc586e645eb904a9.

Baseline 2 remains a historically valid narrower capture with unrecorded projected-residency counters. I checked that baseline 3 adds only those two source-row counters and preserves every other baseline 2 body value. Neither raw baseline was rewritten. audit-baseline2-prepared-not-executed.py is explicitly an unused preparation artifact, not claimed as a completed baseline 2 source-guard audit.

## Scope of freeze

This proves genuine checked public Preserve(Source+silent Hold) projection/identity-route reachability, exact before outputs, source Vec metadata and cumulative observations. It does not prove destination ownership, source policy/inventory admission, native mask quota closure, disposal after destination publication, nested overrides, negative/fractional retained domains, cache-hit behavior or complete preparation.

The 35th corpus can bind these exact projected before bodies/proofs alongside all six freshly retained published-F captures and their explicit variable-counter contract. Keep the earlier F payloads immutable; fresh before observations are separate evidence, not replacements. No absolute work normalization, fake source ticket, cap/fee change or new DP/Gate credit follows.
