//! Test-only source-ready receipts for the pre-G routed projected-mask seam.
use super::*;
use serde::Serialize;
use std::cell::RefCell;

thread_local! {
    static ROWS: RefCell<Option<Vec<Row>>> = const { RefCell::new(None) };
}

#[derive(Serialize)]
pub(super) struct Row {
    pub start: i64,
    pub frames: usize,
    pub source_len: usize,
    pub source_capacity: usize,
    pub source_ranges: Vec<[i64; 2]>,
    pub source_allocation_nonempty: bool,
    pub prepared_relative_depth: usize,
    pub prepared_dependencies: usize,
    pub cached_stages: usize,
    pub cached_resident_frames: u64,
    pub active_frames: u64,
    pub account_live_frames: u64,
    pub plan_work_after_suppression: usize,
    pub cache_plan_work_after_suppression: usize,
    // Kept private for in-process comparison; never included in the capture.
    #[allow(dead_code)]
    #[serde(skip)]
    source_pointer: usize,
}

pub(super) fn begin() {
    ROWS.with(|rows| *rows.borrow_mut() = Some(Vec::new()));
}

pub(super) fn take() -> Vec<Row> {
    ROWS.with(|rows| rows.borrow_mut().take().unwrap_or_default())
}

pub(super) fn record(
    renderer: &StageAudio,
    control: WorkControl<'_>,
    start: SignalSample,
    frames: u32,
    prepared: &PreparedBlock,
    source: &[Range<SignalSample>],
    source_capacity: usize,
    source_pointer: usize,
) {
    ROWS.with(|rows| {
        let mut rows = rows.borrow_mut();
        let Some(rows) = rows.as_mut() else {
            return;
        };
        let work = control.work.borrow();
        rows.push(Row {
            start: start.0,
            frames: frames as usize,
            source_len: source.len(),
            source_capacity,
            source_ranges: source
                .iter()
                .map(|range| [range.start.0, range.end.0])
                .collect(),
            source_allocation_nonempty: source_capacity > 0,
            prepared_relative_depth: prepared.relative_depth,
            prepared_dependencies: prepared.dependencies.len(),
            cached_stages: renderer.cache.len(),
            cached_resident_frames: renderer.cached_resident_frames(),
            active_frames: renderer.active_frames,
            account_live_frames: renderer.owned_suppression.live_frames(),
            plan_work_after_suppression: work.plan_work,
            cache_plan_work_after_suppression: work.cache_plan_work,
            source_pointer,
        });
    });
}
