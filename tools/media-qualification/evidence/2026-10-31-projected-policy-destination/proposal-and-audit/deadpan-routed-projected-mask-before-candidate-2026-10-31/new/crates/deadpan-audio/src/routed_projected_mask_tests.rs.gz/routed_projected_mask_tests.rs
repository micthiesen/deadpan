//! Ignored pre-G capture for the actual routed projected-mask return seam.
use super::*;
use deadpan_plan::{
    AudioBoundaryRule, AudioQueryLimits, AudioRoutedSignal, AudioSampleGrid, AudioSignalContent,
    AudioSignalTape, AudioSignalTapeRun, AudioSoundRoute, AudioStageProjection,
};
use serde_json::{Value, json};
use sha2::{Digest, Sha256};
use std::fs;

fn id(value: &str) -> NodeId {
    NodeId::new(value).unwrap()
}

fn ratio(numerator: i128, denominator: i128) -> ExactRatio {
    ExactRatio::new(numerator, denominator).unwrap()
}

fn checked_plan_with_silent_hold() -> (Arc<RenderPlan>, super::super::tests::Provider) {
    let rate = FrameRate::new(48_000, 1).unwrap();
    let (document, provider) = super::super::tests::fixture_document_at_rate(rate);
    let mut wire = serde_json::to_value(document).unwrap();
    let duration = |frames| FrameDuration::new(frames).unwrap();
    wire["nodes"]["root"] =
        serde_json::to_value(BeatNode::sequence("Root", vec![id("stage")])).unwrap();
    wire["nodes"]["room"] = serde_json::to_value(BeatNode::hold(
        "Silent hold",
        HoldRecipe {
            picture_context: None,
            duration: duration(128),
            video: HoldVideo::Background,
            audio: HoldAudio::Silence,
        },
    ))
    .unwrap();
    wire["nodes"]["b"] = serde_json::to_value(BeatNode::sequence(
        "Preserve input",
        vec![id("a"), id("room")],
    ))
    .unwrap();
    wire["nodes"]["stage"] = serde_json::to_value(BeatNode {
        framing: None,
        label: "Preserve".into(),
        audio_treatments: Default::default(),
        audio_editorial_edges: Default::default(),
        audio_edges: Default::default(),
        kind: NodeKind::Retime {
            child: id("b"),
            duration: duration(768),
            mapping: FrameRange::new(ProjectFrame(0), ProjectFrame(640)).unwrap(),
            pitch: PitchPolicy::Preserve,
            purpose: RetimePurpose::Edit,
        },
        cutaways: Vec::new(),
        captions: Vec::new(),
    })
    .unwrap();
    let document = ProjectDocument::from_json(&wire.to_string()).unwrap();
    (Arc::new(RenderPlan::compile(&document).unwrap()), provider)
}

fn projected<'plan>(plan: &'plan RenderPlan) -> Arc<AudioStageProjection<'plan>> {
    let query = plan
        .audio_signal()
        .query(
            SignalSample(0)..SignalSample(1),
            AudioQueryLimits::default(),
        )
        .unwrap();
    let AudioSignalContent::Stage(stage) = query.spans.into_iter().next().unwrap().content else {
        panic!("the checked root must contain the Preserve stage");
    };
    let signal = stage.input_signal();
    let input = AudioSignalTape::new(
        plan,
        ExactRatio::ZERO..ratio(640, 1),
        vec![AudioSignalTapeRun::new(
            ExactRatio::ZERO..ratio(640, 1),
            ExactRatio::ZERO..ratio(640, 1),
            signal.clone(),
        )],
    )
    .unwrap();
    let output_policy = AudioSignalTape::new(
        plan,
        ExactRatio::ZERO..ratio(768, 1),
        vec![AudioSignalTapeRun::new(
            ExactRatio::ZERO..ratio(768, 1),
            ExactRatio::ZERO..ratio(640, 1),
            signal,
        )],
    )
    .unwrap();
    AudioStageProjection::new(
        stage,
        input,
        output_policy,
        FrameDuration::new(768).unwrap(),
    )
    .unwrap()
}

fn routed<'plan>(projection: Arc<AudioStageProjection<'plan>>) -> AudioRoutedSignal<'plan> {
    let route = SoundRoute::identity(ratio(768, 1)).unwrap();
    let grid = AudioSampleGrid::new(
        ExactRatio::ZERO,
        ExactRatio::ONE,
        AudioBoundaryRule::PointCeil,
    )
    .unwrap();
    let grid_count = route.nodes().len();
    let signal_route = AudioSoundRoute::new(route, vec![grid; grid_count]).unwrap();
    AudioRoutedSignal::projected(projection, signal_route).unwrap()
}

fn one_case(
    case: &str,
    renderer: &mut StageAudio,
    provider: &mut super::super::tests::Provider,
    domain: &AudioRoutedSignal<'_>,
    start: i64,
    frames: u32,
) -> Value {
    let policy = match domain.input() {
        deadpan_plan::AudioRoutedSignalInput::Projected(projection) => {
            projection
                .output_policy()
                .policy_after_preserve(
                    SignalSample(start)..SignalSample(start + i64::from(frames)),
                    AudioQueryLimits::default(),
                )
                .unwrap()
                .suppressed
        }
        _ => unreachable!("capture fixture uses a projected provider"),
    };
    super::projected_mask_before_trace::begin();
    let before_cache = renderer.cached_stage_count();
    let provider_calls_before = provider.calls;
    let result = renderer.read_routed_signal(
        provider,
        domain,
        SignalSample(start),
        frames,
        TIMEOUT,
        &AtomicBool::new(false),
    );
    let source_rows = super::projected_mask_before_trace::take();
    match result {
        Ok(block) => json!({
            "case": case,
            "preasserted_policy_ranges": policy.iter().map(|r| [r.start.0,r.end.0]).collect::<Vec<_>>(),
            "branch_reached": !source_rows.is_empty(),
            "source_rows": source_rows,
            "before_cached_stages": before_cache,
            "after_cached_stages": renderer.cached_stage_count(),
            "provider_calls_before": provider_calls_before,
            "provider_calls_after": provider.calls,
            "result": "Ok",
            "result_ranges": block.suppressed.as_slice().iter().map(|r| [r.start.0,r.end.0]).collect::<Vec<_>>(),
            "result_capacity": block.suppressed.capacity(),
            "result_len": block.suppressed.len(),
            "samples_sha256": format!("{:x}", Sha256::digest(serde_json::to_vec(&block.samples).unwrap())),
            "owned": block.suppressed.is_owned(),
        }),
        Err(error) => json!({
            "case": case,
            "preasserted_policy_ranges": policy.iter().map(|r| [r.start.0,r.end.0]).collect::<Vec<_>>(),
            "branch_reached": !source_rows.is_empty(),
            "source_rows": source_rows,
            "before_cached_stages": before_cache,
            "after_cached_stages": renderer.cached_stage_count(),
            "provider_calls_before": provider_calls_before,
            "provider_calls_after": provider.calls,
            "result": "Err",
            "error": format!("{error:?}"),
        }),
    }
}

fn capture_cases() -> Value {
    let (plan, mut provider) = checked_plan_with_silent_hold();
    let projection = projected(&plan);
    let domain = routed(Arc::clone(&projection));

    let mut empty_renderer = StageAudio::new(Arc::clone(&plan));
    let empty = one_case(
        "source_only_empty",
        &mut empty_renderer,
        &mut provider,
        &domain,
        0,
        512,
    );

    assert!(
        empty["preasserted_policy_ranges"]
            .as_array()
            .unwrap()
            .is_empty()
    );

    let mut positive_renderer = StageAudio::new(Arc::clone(&plan));
    let positive = one_case(
        "explicit_silent_hold_positive",
        &mut positive_renderer,
        &mut provider,
        &domain,
        0,
        768,
    );

    assert!(
        !positive["preasserted_policy_ranges"]
            .as_array()
            .unwrap()
            .is_empty()
    );
    assert!(positive["branch_reached"].as_bool().unwrap());

    let mut warm_renderer = StageAudio::new(Arc::clone(&plan));
    let warm_empty = one_case(
        "warm_empty_before_positive",
        &mut warm_renderer,
        &mut provider,
        &domain,
        0,
        512,
    );
    let warm_positive = one_case(
        "warm_positive_after_empty",
        &mut warm_renderer,
        &mut provider,
        &domain,
        0,
        768,
    );
    json!({
        "schema": "deadpan.routed_projected_mask.before.v1",
        "capture_mode": "pre-G source-ready only",
        "source_only_empty": empty,
        "explicit_silent_hold_positive": positive,
        "warm_empty": warm_empty,
        "warm_positive": warm_positive,
        "provider_calls": provider.calls,
        "limitations": [
            "Source-ready receipts are not destination ownership receipts.",
            "Plan work values are cumulative at the suppression return seam, not an isolated query fee.",
            "No public negative/fractional retained-coordinate case is asserted.",
        ],
    })
}

#[test]
#[ignore = "manual immutable pre-G routed projected-mask baseline capture"]
fn capture_routed_projected_mask_before_g() {
    let path = std::env::var_os("DEADPAN_ROUTED_PROJECTED_MASK_BEFORE_OUTPUT")
        .expect("set output path to a fresh capture file");
    let body = capture_cases();
    fs::write(path, serde_json::to_vec_pretty(&body).unwrap()).unwrap();
}
