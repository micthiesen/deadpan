# Routed projected mask pre-G capture candidate

Scope source authority: `/tmp/deadpan-query-groundwork-2026-10-26/scoped`. This candidate is scratch only. It adds a default-off test-thread receipt after the existing `suppress_signal` returns and an ignored unit test that writes a fresh pre-G body when `DEADPAN_ROUTED_PROJECTED_MASK_BEFORE_OUTPUT` is set.

The fixture starts from the existing real WAV provider helper in `stages::tests::fixture_document_at_rate`, modifies only the checked project graph to make a Preserve stage over `Source + silent Hold`, and builds a checked `AudioStageProjection`/identity `AudioRoutedSignal` using public Plan constructors. It requests the source-only 0..512 interval and the full 0..768 interval, and repeats both on a warm renderer. Each capture preasserts the actual checked output policy before read. The receipt is emitted only after real suppression has completed at `read_projected_signal_controlled`; a no-row failure is not called a producer success.

The source Vec's address is retained only as a private test field and never serialized. Rows record actual source length/capacity/ranges and cumulative work/cache/account state at the seam. This before candidate deliberately does not claim destination ownership, native mask admission, isolated query work, or full-request residency. Those are post-G evidence. No route-gap fixture is used to claim the producer was reached.

No tests/builds/native runs were executed. The candidate needs source integration/review before use; in particular verify that the checked graph mutation and `AudioStageProjection::new` accept the tape extents under the current public validators.
