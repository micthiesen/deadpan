# 35th before-corpus freeze review

GO for portable-corpus-candidate2.json, 115,803 bytes SHA256 93912d8a589912b7ef41f0bd523db8da2a6cdec0d2ea5db1b6ba6f9941dffa51. This freezes before evidence only, not G implementation/ownership acceptance.

The portable JSON contains no /tmp path. Its literal selected source_ready_before object is exactly both independently audited native3 bodies. All 34 immutable predecessor pins remain unchanged. It keeps six final13 F qualification captures and six separate post-publication F captures; neither is reduced to a whole-body numeric golden. Source-ready native2 remains historical in the audit authority. V3 corrects v2's reversed chronology and explains published revision identifiers versus actual run source maps without changing artifact hashes.

I ran the draft v2 read-only validator successfully against both roots: all pinned F/G artifacts, oracle hashes and source/binary/command/runner links pass its integrity checks. My independent native3 audit additionally verifies actual compiler artifacts/executable bytes/env/commands, PCM bits and hashes, full public metadata, actual source/returned ranges and capacities, and the real 768-frame projected residency.

The portable references independently match 44 existing published F inventory records. Its 54 G logical records and v3 audit-authority hash match the actual retained qualification bytes. Their inventory publication is still pending; the planned logical paths must be fulfilled and checked against the resulting G inventory before final publication. This packaging obligation is not a reason to postpone freezing the literal before fixture.

I also independently checked all six fresh post-publication F captures, beyond the existing final13 qualification: each preserves 744 outputs (264 Ok/480 Error), 42 internal/transfer fields/classic accounts; 758 snapshots and 477 completed inclusive claims/954 lane equations, plus the literal partial residual 5; and all four genuine F producer cases with actual bit-derived masks, source/destination/custody/cleanup, Zero4 and accepted Mark1 invariants. Their actual work values remain literal. The existing F final13 reviewed variance is not a blanket G waiver.

No root edits, Cargo/native execution, Git, source admission, normalized body, cap/fee changes, new DP/Gate credit or whole-preparation claim was introduced by this review. Exact artifacts/pins and independent post-publication results are retained in this review directory.

Approved draft authority: corpus-draft-v3/corpus-manifest-draft.json SHA256 d27df01bee43ae1d883e9efb3c258121afdba36e5cee74fbf4e88242ad0cc84b. Earlier v2 chronology finding remains retained.
