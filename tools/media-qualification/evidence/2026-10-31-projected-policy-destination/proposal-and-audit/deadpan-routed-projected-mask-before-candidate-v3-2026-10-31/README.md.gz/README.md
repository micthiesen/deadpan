# Routed projected-mask pre-G capture candidate, v3

This scratch candidate supersedes neither v1 nor v2; both remain preserved. Source authority is /tmp/deadpan-query-groundwork-2026-10-26/scoped, recorded in source-pins.json.

The patch adds a bounded, default-off cfg(test) receipt immediately after the existing suppress_signal call in routed.rs, plus a platform-gated ignored test that writes only to a fresh output path with create_new. The fixture starts from stages::controlled_reads::fixture_document_at_rate, which provides a checked project and real verified WAV provider. It changes the checked graph to a Preserve stage over Source followed by an explicit silent Hold, then constructs checked tapes, projection, projected routed signal, and an identity PointCeil route using public constructors.

Each read is 256 frames, within MAX_OUTPUT_FRAMES: source-only 0..256 and Hold-overlapping 512..768, first on fresh renderers and then repeated on one renderer. Each successful public read requires exactly one matching receipt at the real source-ready seam. Actual returned source ranges must match the separately preasserted output policy; the empty case also requires source Vec length zero. Repeated calls are described as same-renderer repeats; request-local projected memoization is recreated per public read.

Successful results store every stereo sample as the exact pair of f32::to_bits() values and SHA-256 over those words in little-endian byte order. They also record all public RoutedSignalBlock metadata and literal sample/mask lengths, capacities, ranges, and ownership status. This makes the capture suitable for literal before/after comparison without float formatting or normalization.

The observer caps snapshots at 128 rows and copied source ranges at 512 per row. It records attempted/dropped/truncated counts; the capture rejects any truncation. It does no work or WorkControl borrow while disabled. Source pointers are held only in a private serde-skipped field and are never serialized. Work counters are cumulative at the suppression seam, not isolated query fees.

This is a pre-G source-ready baseline only. It does not prove destination ownership, final routed-mask residency, quota closure, nested overrides, or negative/fractional retained-coordinate behavior. No build or test execution was performed for this candidate.
