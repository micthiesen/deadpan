# Projected-mask active capture candidate v2

Scratch-only additive test/capture proposal. No repository source, build, or native executable was changed or run.

## Source pins

Current Main and Scope have identical inputs:

- `crates/deadpan-audio/src/routed_projected_mask_tests.rs`: SHA-256 `4fc1386457fa7917c7e6fe4cbc0c420b5682df11292d159e6394c6339f874ef3`
- `crates/deadpan-audio/tests/fixtures/projected-policy-destination-baseline-v1/corpus.json`: SHA-256 `93912d8a589912b7ef41f0bd523db8da2a6cdec0d2ea5db1b6ba6f9941dffa51`

The source file hash was rechecked in both Main (`/Users/michael/Code/deadpan`) and Scope (`/tmp/deadpan-query-groundwork-2026-10-26/scoped`).

## Candidate

Apply `routed_projected_mask_tests.patch` against the pinned test source. It unifies the four existing fixture executions in `capture_cases_with_mode(owned_mode)`: false retains the before schema, capture mode, limitations, case names, and all captured fields; true writes a distinct active schema/mode while using the same checked graph and requests. Empty masks remain Plain; each actual positive mask must be owned.

The active capture function is `pub(in crate::stages)` so the parent stage test harness can call it after making the existing routed test module visible. The ignored writer uses `DEADPAN_PROJECTED_POLICY_AFTER_OUTPUT` and `create_new` so it cannot overwrite a capture.

The ordinary test verifies the embedded corpus bytes against the pinned SHA before parsing. For each case, it compares every case field and every public block field literally, except `public_block.suppressed_owned`, which is checked against the expected active ownership state. This includes exact source-ready rows, PCM bit arrays and digest, provider call totals, result metadata, ranges, lengths, and capacities. It also checks key counts so added or removed fields fail visibly.

Formatting used `rustfmt --edition 2024 --config skip_children=true` because sibling modules are not copied into scratch. The candidate is not compiled or executed.
