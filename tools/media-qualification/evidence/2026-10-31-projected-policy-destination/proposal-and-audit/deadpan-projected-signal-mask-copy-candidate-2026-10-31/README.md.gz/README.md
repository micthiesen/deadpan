# G: routed projected Signal mask destination copy

Scratch-only production/replay proposal against published F 59874646dba6974da77e2cad08e9bc4822fd5afe. Authority is Scope /tmp/deadpan-query-groundwork-2026-10-26/scoped. Main WIP was never read/copied for implementation. No Root edits, Cargo/builds, native execution, Git, corpus freeze, oracle generation or runtime claim. Parent must freeze the new corpus before integration.

## Runtime change

production.patch changes only routed.rs::read_projected_signal_controlled. After the complete unchanged suppress_signal call succeeds, it wraps the actual returned Vec as SignalSuppressionMask::plain and invokes its existing into_admitted with the real self.masks(control). SignalBlock receives that sealed result directly.

The prepared Arc remains named and is referenced again for dependencies/depth in the returned SignalBlock after the copy; it is retained throughout admission/copy/publication and result construction. No source Arc/Vec clone or temporary Plan query is introduced. Into_admitted performs the existing bounded destination reservation/copy and returns the same values under native ownership. It creates a distinct destination allocation, not C's same-Vec lease transfer.

The old prepare_projected/provider checks, recipe/clock construction, sample_prepared, ordinary PreserveTape policy, its one manual work debit, content preflight, control check, complete range validation/PCM zeroing and legacy merged_suppression all stay literal and in the same order. Admission starts after that helper succeeds. Generic suppress_signal and its stage preparation/saved-key consumers are untouched.

## Exact source/type contract

- Runtime input is the real ordinary Vec<Range<SignalSample>> returned by suppress_signal. Its policy/query contents and child temporaries have already dropped inside that helper. It has no Plan Memory lease.
- Plain.into_admitted checks control and returns default for empty input. Positive input uses actual input len as builder capacity, reserves destination vector+Storage Box through StageAudio, copies while the entire source wrapper remains alive, finishes the Box, checks control, then drops the ordinary source Vec.
- Actual source bytes remain outside the new account. The native destination owns its real ticket, with physical Box/Vec drop before Charge. An account shell initialized before later refusal can remain until controller teardown.
- Existing mask context forwards real WorkControl check/spend and StageAudio reserve_mask_storage/make_room. Source policy work/lookup/nested values are never replaced or redebited. There are no new public API, weight, quota, timeout or cap changes.
- Empty input requests no destination vector/Box/account from this copy, but still performs the actual into_admitted control check. Preexisting owners/shells remain literal.
- This closes only the returned projected Signal mask destination. Source tape/projection graph construction, ordinary policy inventories/aggregates, generic suppress_signal metadata in other consumers, PCM/dependencies and whole preparation remain outside the claim. No ordinary object is relabeled as admitted source metadata and C's Point policy API is not used.

Decision baseline: /tmp/deadpan-after-components-policy-design-2026-10-31.md, pinned in source-pins.json.

## Replay hooks

replay-hooks.patch is a separately reviewable cfg(test) proposal:
- New stages::projected_signal_mask_request::{legacy,with_legacy_projected_signal_masks}.
- Default legacy=false. Thread-local RAII preserves nesting/panic restoration; no tracer or broad admission-test mode.
- stages.rs gets one cfg(test) module declaration.
- components_mask_request::with_legacy_components_masks chains into Glegacy. E and older replay lanes already chain through Flegacy, so they remain prior behavior. A standalone Glegacy call bypasses only this new copy and leaves F active.

The routed cfg(test) branch returns the exact Plain helper result when Glegacy=true. Non-test production always invokes into_admitted.

Important F-current distinction: capture-glue-proposal.patch separately wraps the ENTIRE existing capture_active_components_mask_after_v1 capture_after call in Glegacy, while its assertions keep F/nonseparate SharedMix active. Chaining only Flegacy would not protect this F-current capture. New G-current capture must be separate and default-active, not a relabeled Destination::Components body.

Apply production + replay hooks atomically in the parent's guarded integration before compiling tests. The capture glue is separate because parent owns corpus/capture integration. It is an exact proposal from current Scope text; no root application occurred here.

## New G capture/header contract, deliberately not implemented yet

Parent owns the distinct G-current Destination/header/ignored capture and additive fixtures. It should:
- Use a separate ignored capture, env family and schema identifying projected Signal destination-copy-only, with published base F59874646... .
- Preserve the existing F-current body under explicit Glegacy, and make G-current default active; do not allow old F mode to silently execute G.
- Keep Root/SharedMix/Components checkpoint fields and cases literal, then add G authority/scope and its separate actual fixture evidence. Projection tracing should follow the existing enabled lanes; do not broaden query traces or invent query receipts.
- Freeze corpus35 as all six actual F raw canonical captures plus the classic/invariant comparison contract. Absolute dynamic work counters can legitimately vary. Record literal raw hash manifest and separate classic identity; do not fabricate a single full-body byte-equality authority or write a placeholder expected SHA.
- Keep actual old/new capacities, work, account/provider/cache state and errors. Additive native tests/observer data must be recorded from execution, not synthesized here.

No G-current capture implementation with an unknown before authority is included. The one existing-F wrapper patch is ready for parent review alongside its actual corpus freeze.

## Downstream consequences and required evidence

read_routed_signal receives this SignalBlock and translates child masks through the existing extend_try_map, then merges the aggregate. A positive Owned child can promote/copy a Plain route-gap target or use an existing owned target; these existing owned branches introduce real additional work, source/destination overlap and later resource refusals. They may retain a different real capacity than the old Plain Vec growth. Do not normalize capacity/work or add a gratuitous shrink allocation to mimic old metadata.

No manual resident sum should add the same already-owned payload again. Existing cache residency uses unaccounted_capacity for ordinary mask storage, while account live frames cover owned masks. Verify actual consumers rather than inferring source admission from the controller's PCM/cache reservation.

New make_room may evict eligible cache/Original entries while the actual prepared Arc stays pinned. Source revocation, dependency fingerprints, complete projected preparation, numeric validation and unsupported policy errors retain their old pre-copy priority. Failure during the copy discards the local result/PCM and releases the pending destination through existing RAII; accepted work is retained, without refunds. Returned native masks can outlive local WorkControl/ReadWork and controller.

Parent qualification should include actual public checked projected routes with empty and positive policy, cold/warm preparation, exact typed range/PCM/dependency semantics, distinct source/destination pointer+capacity receipts at the real copy, source-live overlap and actual account cleanup, work/quota/cancel/deadline at a reached copy boundary, and lifetime past controller. Also observe downstream translated-mask capacity/work changes separately. The current proposal supplies no tracer, fixtures or runtime proof.

## Artifacts and pins

before/ and new/ contain exact current Scope source and candidate files. Per-file patches are under patches/. source-pins.json records before/new and real dependency hashes. capture-glue-new/ holds only the separate native_mask_after.rs proposal. production.patch is the sole runtime change; replay-hooks.patch/capture-glue-proposal.patch are test-only integration proposals. navigation is the pinned ripwire output beside this candidate.

No compile or native result is claimed.
