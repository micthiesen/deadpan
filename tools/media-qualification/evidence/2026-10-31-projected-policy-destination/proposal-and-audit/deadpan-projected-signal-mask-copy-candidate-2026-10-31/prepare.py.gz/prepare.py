from pathlib import Path
import hashlib,json,difflib
root=Path('/tmp/deadpan-query-groundwork-2026-10-26/scoped')
out=Path('/tmp/deadpan-projected-signal-mask-copy-candidate-2026-10-31')
paths=['crates/deadpan-audio/src/routed.rs','crates/deadpan-audio/src/stages.rs','crates/deadpan-audio/src/components_mask_request.rs']
before={path:(root/path).read_text() for path in paths}
after=dict(before)
p=paths[0]
start=after[p].index('    fn read_projected_signal_controlled(')
end=after[p].index('\n}\n',start)
body=after[p][start:end]
old='''        )?;
        Ok(SignalBlock {
            samples,
            dependencies: prepared.dependencies.clone(),
            suppressed: SignalSuppressionMask::plain(suppressed),
            relative_depth: 1 + prepared.relative_depth,
        })
'''
new='''        )?;
        let suppressed = SignalSuppressionMask::plain(suppressed);
        #[cfg(test)]
        let suppressed = if super::projected_signal_mask_request::legacy() {
            suppressed
        } else {
            suppressed.into_admitted(&mut self.masks(control))?
        };
        #[cfg(not(test))]
        let suppressed = suppressed.into_admitted(&mut self.masks(control))?;
        Ok(SignalBlock {
            samples,
            dependencies: prepared.dependencies.clone(),
            suppressed,
            relative_depth: 1 + prepared.relative_depth,
        })
'''
assert body.count(old)==1
after[p]=after[p][:start]+body.replace(old,new)+after[p][end:]
p=paths[1]
anchor='''#[cfg(test)]
#[path = "components_mask_request.rs"]
mod components_mask_request;
'''
assert after[p].count(anchor)==1
after[p]=after[p].replace(anchor,anchor+'''
#[cfg(test)]
#[path = "projected_signal_mask_request.rs"]
mod projected_signal_mask_request;
''')
p=paths[2]
assert after[p].count('    action()\n')==1
after[p]=after[p].replace('    action()\n','    super::projected_signal_mask_request::with_legacy_projected_signal_masks(action)\n')
newpath='crates/deadpan-audio/src/projected_signal_mask_request.rs'
after[newpath]='''//! Literal routed projected-signal output before native destination copying.
thread_local! {
    static LEGACY: std::cell::Cell<bool> = const { std::cell::Cell::new(false) };
}
pub(super) fn legacy() -> bool {
    LEGACY.with(std::cell::Cell::get)
}
pub(super) fn with_legacy_projected_signal_masks<T>(action: impl FnOnce() -> T) -> T {
    struct Restore(bool);
    impl Drop for Restore {
        fn drop(&mut self) {
            LEGACY.with(|legacy| legacy.set(self.0));
        }
    }
    let _restore = Restore(LEGACY.with(|legacy| legacy.replace(true)));
    action()
}
'''
production=[];replay=[]
files=[]
for rel,text in after.items():
 for directory,data in [('before',before.get(rel,'')),('new',text)]:
  p=out/directory/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(data)
 patch=''.join(difflib.unified_diff(before.get(rel,'').splitlines(True),text.splitlines(True),fromfile='a/'+rel if rel in before else '/dev/null',tofile='b/'+rel))
 p=out/'patches'/(Path(rel).stem+'.patch');p.parent.mkdir(parents=True,exist_ok=True);p.write_text(patch)
 (production if rel==paths[0] else replay).append(patch)
 files.append({'path':rel,'before_exists':rel in before,'before_bytes':len(before[rel].encode()) if rel in before else None,'before_sha256':hashlib.sha256(before[rel].encode()).hexdigest() if rel in before else None,'new_bytes':len(text.encode()),'new_sha256':hashlib.sha256(text.encode()).hexdigest()})
(out/'production.patch').write_text(''.join(production));(out/'replay-hooks.patch').write_text(''.join(replay))
pins={'schema':'projected-signal-mask-copy-candidate-v1','source_authority':str(root),'published_base':'59874646dba6974da77e2cad08e9bc4822fd5afe','scope':'routed projected Signal output destination-copy prerequisite only','files':files}
deps=[
'crates/deadpan-audio/src/mask_context.rs',
'crates/deadpan-audio/src/point_suppression.rs',
'crates/deadpan-audio/src/point_suppression/ops.rs',
'crates/deadpan-audio/src/point_suppression/mutations.rs',
'crates/deadpan-audio/src/point_suppression/projections.rs',
'crates/deadpan-audio/src/signal_input.rs',
'crates/deadpan-audio/src/stage_projection.rs',
'crates/deadpan-audio/src/stage_cache.rs',
'crates/deadpan-audio/src/shared_eq/original_inputs.rs',
'crates/deadpan-plan/src/audio_tape.rs',
'crates/deadpan-plan/src/audio_policy.rs',
'crates/deadpan-plan/src/audio_point_policy_query.rs',
]
pins['dependencies']=[{'path':rel,'bytes':(root/rel).stat().st_size,'sha256':hashlib.sha256((root/rel).read_bytes()).hexdigest()} for rel in deps]
pins['design']={'path':'/tmp/deadpan-after-components-policy-design-2026-10-31.md','sha256':hashlib.sha256(Path('/tmp/deadpan-after-components-policy-design-2026-10-31.md').read_bytes()).hexdigest()}
(out/'source-pins.json').write_text(json.dumps(pins,indent=2)+'\n')
print(json.dumps(files,indent=2))
