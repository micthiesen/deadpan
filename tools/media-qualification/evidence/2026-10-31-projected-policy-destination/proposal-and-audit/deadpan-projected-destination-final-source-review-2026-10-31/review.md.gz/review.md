# Final G source review

GO for the current ten owned paths. No correctness blocker found. Scope is the source authority; exact current hashes and scoped before/current diffs are retained here. Main WIP was neither edited nor copied. Full build 2 matrix execution/qualification remains with parent; this is source review, not a claim that the current new assertions have run.

## Runtime and custody

The only new production behavior is local to read_projected_signal_controlled: after the unchanged suppress_signal succeeds, its actual final Vec becomes a Plain SignalSuppressionMask and is consumed by the existing into_admitted through real self.masks(control). Production unconditionally uses the admitted path; the replay fallback is cfg(test) only.

Prepare/resample/policy query, literal query.work debit, content preflights, whole-range validation, PCM zeroing and legacy merge keep their order. No extra query/provider call, grid conversion, detached clone, source lease, refund, cap or canonical-weight change is introduced. The actual ordinary Vec remains owned by into_admitted through reserve/copy/Box/final check. Prepared PCM Arc is retained through the copy and subsequently used for dependencies/depth. make_room counts its existing request-local projected residency alongside other live residency. The copied destination funds exact typed range capacity plus its actual owning Box, and inherits the proven Vec/Box-before-charge cleanup/account lifetime.

Empty input checks control and returns default without a new account/allocation. Positive copy keeps source and destination physically separate and returns an owner independent of local ReadWork. Downstream public label mapping activates existing funded Owned branches; it retains source custody during replacement, with independent Map/merge/storage work and possible resource refusals. This unit does not pretend those operations are canonical Tape query work.

## Replay and capture

The G-only TLS switch defaults active and restores nested/panic state through RAII. Existing Components legacy replay composes G legacy, while active F Components capture explicitly bypasses only G. Earlier literal replay chains remain intact; there is no production fallback.

Destination::Projected preserves the existing actual 744 framework and earlier sections, adds the frozen 93912d8a corpus/checkpoint metadata, and appends four real projected cases. Modified mode/header/scope text is isolated to this new destination. These four cases are the direct G public-path evidence; the old 744 cases are compatibility coverage, not 744 independently reached projected copies. Cumulative source-ready counters are sampled before destination copying, so they are not isolated G-copy fee totals.

The new normal test hashes the entire frozen corpus and compares every per-case field and full public block/PCM bits literally. Only the expected positive suppressed_owned bit changes; empty remains unowned. Literal source rows, capacities, provider observations and sample hashes cannot be silently normalized. Metadata-only active schema/limitations are separate from those compared case bodies.

The source observer remains bounded/default-off, borrows no work when disabled, and records the actual Vec capacity/pointer only inside the enabled hook. Pointer comparison stays private and serde-skipped. Actual projected resident/disk counters remain distinct from controller cache/active/account counters.

## Actual tests and limits

Three direct controlled-return tests use the genuine warm request memo with 768 existing projected frames and actual Signal Layout/shell costs. Exact destination cap/onebelow, actual source-ready positive mask, private copy pointer, empty no-account/no-native-fee, and owned payload retention are meaningfully asserted. The improved positive test now requires vector/Map/storage units 1 and drops its extra prepared Arc before Work/provider/controller, then checks the held mask and shell-only residue. The failure case retains its diagnostic prepared Arc until its own end; it makes no whole-preparation disposal claim.

No source-query/inventory/intermediate Vec admission is established. Ordinary PreserveTape source construction, projected Root policy paths, exhausted/PCM/dependency buffers, nested override and negative/fractional/provider-priority/work-limit/cancellation/deadline cases, public routed-cap overlap and whole preparation remain outside this test set. A public successful Owned result does not replace the direct isolated-copy cap/lifetime proof, and that isolated proof is not a cold whole-read memory minimum.

The portable 35th corpus remains byte-identical 93912d8a, with all older payloads intact and variable F counters retained as observations. Planned G archive references still need fulfillment at final publication. No DP or Gate credit follows from this source verdict.

No roots/builds/native/Git were modified or executed by this reviewer.
