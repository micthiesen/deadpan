from pathlib import Path
import json,hashlib,collections
P=Path('/tmp/deadpan-root-mask-emission-qualification-2026-10-31')
D=Path('/tmp/deadpan-root-mask-first-capture-review-2026-10-31')
cache={};pins={}
def pin(path):
 p=Path(path).resolve()
 if str(p) in cache:return cache[str(p)]
 h=hashlib.sha256();size=0
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1024*1024),b''):h.update(b);size+=len(b)
 r={'bytes':size,'sha256':h.hexdigest()};cache[str(p)]=r;return r
def evidence(path):
 pins[str(path)]=pin(path)
def load(n):return json.loads((P/n).read_text())
def guard(r):
 assert r['exit_code']==0 and r['sources_unchanged'] and r['binaries_unchanged']
 assert r['source_before']==r['source_after']
 assert r['binary_before']==r['binary_after']
 assert r['removed_paths_absent_before']==r['removed_paths_absent_after']
 for p,h in {**r['binary_after'],**r['streams']}.items():
  assert pin(p)==h,p;evidence(p)
 assert all(not (Path(r['cwd'])/n).exists() for n in r['removed_paths_absent_after'])
out={'captures':[],'first_source_to_current':{},'preservation':{}}
active='596d738a53f6ef4cbf7870d74b3025504f6289f735ea91f4a38ed45c6661f44a'
modes=[
 ('','root','DEADPAN_ROOT_MASK_AFTER','44068bd971dee62e2ed8cbaffbb2f18922283f83','capture_active_root_mask_after_v1',active),
 ('-before-policy','policy','DEADPAN_POINT_POLICY_AFTER','eedbc58272bdd009a65239b7104ddb786a2554fc','capture_active_point_policy_after_v1','afa6038a02c959c7192c09c08a89266c7d52151a5e59a4f69828fbdf67e7414e'),
 ('-before-interval','intervals','DEADPAN_QUERY_INTERVAL_AFTER','ab211a2f132379a246157c3596d95fc42121541c','capture_active_query_intervals_v1','f64d3a00a10967cc3822083d21705bd454f2d33ff2198da30e25671092ab5a53')]
owned=set(load('owned-code-paths.json'))
for variant,root in [('main',Path('/Users/michael/Code/deadpan')),('scoped',Path('/tmp/deadpan-query-groundwork-2026-10-26/scoped'))]:
 runner=P/('run_qualified.py' if variant=='main' else 'run_scoped_qualified.py')
 for suf,mode,pre,checkpoint,test,sha in modes:
  label=f'root-mask-first{suf}-{variant}'
  r=load(label+'.json');proof=load(label+'-proof.json')
  m=load(label+'-source-manifest.json');guard(r)
  assert r['runner_sha256']==pin(runner)['sha256']
  assert {str(Path(p).relative_to(root)):h for p,h in r['source_before'].items()}==m
  assert len(m)==proof['source_inputs']
  assert pin(P/(label+'-source-manifest.json'))['sha256']==proof['source_manifest_sha256']
  assert proof['base_revision']==checkpoint and proof['mode']==mode and proof['variant']==variant
  bp=next(iter(r['binary_before']));assert len(r['binary_before'])==1
  assert pin(bp)['sha256']==proof['binary_sha256']
  assert r['command']==[bp,'--ignored','--exact','stages::bound_reads::retained_host_baseline::pairs::native_mask_after::'+test,'--nocapture','--test-threads=1']
  e=r['environment'];var='main-inherited' if variant=='main' else 'scoped-published'
  assert e[pre+'_VARIANT']==var and e[pre+'_PUBLISHED_CHECKPOINT']==checkpoint
  assert e[pre+'_SOURCE_SHA256']==proof['source_manifest_sha256']
  assert Path(e[pre+'_OUTPUT']).resolve()==(P/(label+'-body.json')).resolve()
  assert e['CARGO_PROFILE_DEV_OPT_LEVEL']=='2' and e['CARGO_INCREMENTAL']=='0' and e['DEADPAN_REQUIRE_PHYSICAL_MAC']=='1'
  body=load(label+'-body.json')
  assert body.pop('variant')==var and body.pop('source_sha256')==proof['source_manifest_sha256']
  assert body['native_requests'].pop('variant')==var and body['native_requests'].pop('source_sha256')==proof['source_manifest_sha256']
  canonical=(json.dumps(body,sort_keys=True,separators=(',',':'))+'\n').encode()
  assert canonical==(P/(label+'-canonical.json')).read_bytes()
  assert len(canonical)==proof['bytes'] and hashlib.sha256(canonical).hexdigest()==proof['sha256']==sha
  for end in ['.json','-proof.json','-source-manifest.json','-body.json','-canonical.json']:evidence(P/(label+end))
  out['captures'].append({'label':label,**proof})
 first=load(f'root-mask-first-{variant}-source-manifest.json')
 out['first_source_to_current'][variant]=[p for p,h in first.items() if pin(root/p)!=h]
 assert set(out['first_source_to_current'][variant])<=owned
 now=set(load('source-files.json' if variant=='main' else 'scoped-source-files.json'))
 out['first_source_to_current'][variant]={'changed_existing':out['first_source_to_current'][variant],'added_named_inputs':sorted(now-set(first))}
 assert set(now-set(first))<=owned
 initial=load(variant+'-initial-authority.json')
 untouched={p:h for p,h in initial.items() if p not in owned}
 for p,h in untouched.items():assert pin(root/p)==h,p
 assert all(p in owned or p in initial for p in now)
 for n in ['owned-code-paths.json',variant+'-initial-authority.json','source-files.json' if variant=='main' else 'scoped-source-files.json']:evidence(P/n)
 out['preservation'][variant]={'initial_inputs':len(initial),'unowned_exact':len(untouched),'added_named_inputs':sorted(now-set(initial))}
 for f in load('immutable-oracle-pins.json'):
  assert pin(root/f['path'])['sha256']==f['sha256'];evidence(root/f['path'])
 for rel in ['crates/deadpan-audio/src/raw_policy.rs','crates/deadpan-audio/src/stages.rs']:
  old=P/'before'/variant/rel;current=root/rel
  evidence(old);evidence(current)
 def fn(path,name):
  s=path.read_text();start=s.index(name);return s[start:s.index('\n}\n',start)+3]
 oldraw=P/'before'/variant/'crates/deadpan-audio/src/raw_policy.rs'
 curraw=root/'crates/deadpan-audio/src/raw_policy.rs'
 for name in ['pub(super) fn apply(','pub(super) fn visit<','fn span_offsets(']:
  assert fn(oldraw,name)==fn(curraw,name),(variant,name)
 oldstage=P/'before'/variant/'crates/deadpan-audio/src/stages.rs'
 curstage=root/'crates/deadpan-audio/src/stages.rs'
 assert fn(oldstage,'fn merged_suppression<')==fn(curstage,'fn merged_suppression<')
 assert fn(oldstage,'fn is_silent_hold(')==fn(curstage,'fn is_silent_hold(')
 out['preservation'][variant]['literal_old_apply_visit_offsets_merge_and_tag']=True
 for rel in ['crates/deadpan-audio/src/original_request.rs','crates/deadpan-audio/src/point_suppression.rs','crates/deadpan-audio/src/point_suppression/ops.rs','crates/deadpan-audio/src/point_suppression/mutations.rs','crates/deadpan-audio/src/bound_reads/native_mask_after.rs','crates/deadpan-audio/src/root_mask_request.rs','crates/deadpan-audio/src/point_policy_request.rs']:
  evidence(root/rel)
a=load('root-mask-first-before-policy-scoped-canonical.json')
b=load('root-mask-first-scoped-canonical.json')
assert (P/'root-mask-first-main-canonical.json').read_bytes()==(P/'root-mask-first-scoped-canonical.json').read_bytes()
counts=collections.Counter();ac=[]
assert len(a['native_requests']['cases'])==len(b['native_requests']['cases'])
for x,y in zip(a['native_requests']['cases'],b['native_requests']['cases']):
 assert x['fixture']==y['fixture'] and len(x['operations'])==len(y['operations'])
 for u,v in zip(x['operations'],y['operations']):
  assert {k:z for k,z in u.items() if k!='paired'}=={k:z for k,z in v.items() if k!='paired'}
  u=u['paired']['new']['read']['output'];v=v['paired']['new']['read']['output']
  assert u==v;counts[u['status']]+=1
assert counts=={'Ok':264,'Error':480}
out['complete_outputs']=dict(counts)
resultfields=0
for group,x,y in [('internal',a['internal_and_transfer_paths']['cases'],b['internal_and_transfer_paths']['cases']),('transfer',a['internal_and_transfer_paths']['public_transfers']['cases'],b['internal_and_transfer_paths']['public_transfers']['cases'])]:
 assert len(x)==len(y)==(10 if group=='internal' else 4)
 for i,(u,v) in enumerate(zip(x,y)):
  assert u['name']==v['name']
  for k in u:
   if k.startswith('result_'):assert u[k]==v[k],(group,i,k);resultfields+=1
   if k.startswith('account_') and u[k]!=v[k]:ac.append({'group':group,'index':i,'name':u['name'],'field':k,'before':u[k],'after':v[k]})
assert resultfields==42 and len(ac)==8
assert {(x['group'],x['index']) for x in ac}=={('internal',4),('internal',5)}
for x in ac:
 assert x['before']=={'live_frames':None,'status':'None'} and x['after']=={'live_frames':3,'status':'Some'}
out['account_changes']=ac;out['exact_result_fields']=resultfields
for i in [4,5]:
 c=b['internal_and_transfer_paths']['cases'][i];n=c['native_mask_work_whole_case']
 assert not n['overflow']
 assert n['plan']['accepted_payload_reservations']==3 and n['plan']['accepted_payload_frames']==1043
 assert n['plan']['accepted_vector_units']==n['plan']['accepted_storage_units']==3
 assert n['plan']['initialized_account_frames']==3 and n['plan']['initialized_account_shells']==1
 assert all(v==0 for v in n['cache'].values())
out['aggregate_native_reservations']={'cases':2,'reservations_each':3,'accepted_payload_frames_each':1043,'shell_frames_each':3}
intervals=collections.Counter();partial=[]
def visit(v,path=''):
 if isinstance(v,dict):
  if v.get('schema')=='native-mask-query-intervals-v1':
   intervals['snapshots']+=1
   assert v['active_intervals']==v['dropped_intervals']==0 and not v['misnested'] and not v['overflow']
   for r in v['rows']:
    intervals['rows']+=1
    assert r['attributable'] and not r['foreign_work_overlap']
    for pre in ['native','host']:
     x=r[pre+'_before'];y=r[pre+'_after']
     assert x['reset_epoch'] is not None and x['reset_epoch']==y['reset_epoch'] and not x['overflow'] and not y['overflow']
    assert r['native_before']['enabled'] and r['native_after']['enabled']
    if r['claim'] is None:
     intervals['partial']+=1;partial.append({'path':path,'row':r});continue
    c=r['claim'];intervals['complete']+=1
    assert c['canonical']+c['additional']==c['total']==c['expected_debit'] and c['forwarded'] and not c['ordinary']
    for lane in [0,1]:
     x=r['native_before']['lanes'][lane];y=r['native_after']['lanes'][lane];assert len(x)==len(y)==8
     d=[v-u for u,v in zip(x,y)];assert min(d)>=0
     host=r['host_after']['units'][lane]-r['host_before']['units'][lane]
     actual=r['work_after'][lane]-r['work_before'][lane];assert host>=0 and actual>=0
     assert actual==(c['total'] if lane==r['selected_lane'] else 0)+sum(d)+host
  else:
   for k,z in v.items():visit(z,path+'/'+k)
 elif isinstance(v,list):
  for i,z in enumerate(v):visit(z,path+'/'+str(i))
visit(b)
assert intervals=={'snapshots':758,'rows':478,'complete':477,'partial':1}
assert partial[0]['row']['claim'] is None and partial[0]['row']['work_after']==[6,0]
out['intervals']=dict(intervals);out['partial']=partial
for n in ['first-capture-analysis.json','first-output-analysis.json','before-freeze-proof.json','immutable-oracle-pins.json','capture_after.py','run_qualified.py','run_scoped_qualified.py','audit_sources.py']:evidence(P/n)
out['compiler_artifacts']={}
for variant in ['main','scoped']:
 label=f'root-mask-build-{variant}'
 receipt=load(label+'.json');guard(receipt)
 compiled=load(label+'-pins.json');assert len(compiled)==1
 record=compiled[0];artifact=record['artifact']
 assert record['name']==artifact['target']['name']=='deadpan_audio'
 assert artifact['profile']['opt_level']=='2' and artifact['profile']['test']
 assert artifact['profile']['debug_assertions'] and artifact['profile']['overflow_checks']
 records=[]
 for line in (P/(label+'.stdout')).read_text().splitlines():
  try:records.append(json.loads(line))
  except json.JSONDecodeError:pass
 assert artifact in records
 assert pin(record['path'])=={'bytes':record['bytes'],'sha256':record['sha256']}
 first=load(f'root-mask-first-{variant}.json')
 assert first['source_before']==receipt['source_after']
 assert first['command'][0]==record['path']
 out['compiler_artifacts'][variant]={'retained_binary':record['sha256'],'opt_level':'2','test':True,'artifact_literal_in_stdout':True}
 for end in ['.json','-pins.json','.stdout','.stderr']:evidence(P/(label+end))
 root=Path('/Users/michael/Code/deadpan') if variant=='main' else Path('/tmp/deadpan-query-groundwork-2026-10-26/scoped')
 fixture=root/'crates/deadpan-audio/tests/fixtures/root-mask-emission-baseline-v1/snapshot.json'
 assert pin(fixture)=={'bytes':35440148,'sha256':'afa6038a02c959c7192c09c08a89266c7d52151a5e59a4f69828fbdf67e7414e'}
 evidence(fixture)
 old=(P/'before'/variant/'crates/deadpan-audio/src/stages.rs').read_text()
 new=(root/'crates/deadpan-audio/src/stages.rs').read_text()
 def limits(text):
  start=text.index('impl Default for StageLimits {')
  return text[start:text.index('\n}\n',start)+3]
 assert limits(old)==limits(new)
 out['preservation'][variant]['default_limits_literal']=True
(D/'audit-results.json').write_text(json.dumps(out,indent=2,sort_keys=True)+'\n')
(D/'evidence-pins.json').write_text(json.dumps(pins,indent=2,sort_keys=True)+'\n')
print(json.dumps({k:v for k,v in out.items() if k not in ['account_changes','partial']},indent=2))
