# sound_events integration boundary correction

Frozen scratch-only candidate. No root source edits, builds, native executables, Git or oracle modifications. Parent owns integration and actual verification. Only sound_events.rs changes; rustfmt --edition 2024 --config skip_children=true passed.

## Observed cause and test intent

First Main sound_events run: 3 pass / 3 fail. Two provider-reuse tests reach resident Limit where their 128-frame request should have reached the sentinel; the in-flight cancellation test likewise fails before its provider callback can set cancellation. The existing resident_limit helper only combines an assumed PCM allowance with flattened_metadata::root's measured Plan metadata peak. It does not admit or measure D's additional native Root mask destination/account. Adding a guessed Box/shell constant or increasing a production cap is inappropriate.

The affected tests use raw prepare_edge_faded with held_sound or gap_masked_sound. They require raw256 to refuse before provider resolution, raw128 to reach the deliberate sentinel, repeated failure cleanup, and initial/in-flight cancellation/reuse. The separate nonlinear test already passes and specifically requires authored128 refusal, authored64 sentinel and raw128 sentinel. It is untouched, including its existing resident_limit call and all assertions.

## Minimal candidate

A new raw-only reusable_raw_resident_limit(plan, frames) helper measures the public admission boundary for those exact raw128 requests, without native ABI assumptions or internal cfg(test) access. No generic request modes or production visibility changes are added.

Each search attempt creates a fresh StageAudio with a cap within the existing public default, a fresh provider and fresh cancellation state. It performs exactly two raw requests on that one renderer so retained one-time account shell residency is included in reusable admission. Each admitted attempt must return the exact SourceUnavailable sentinel, add exactly one effect callback and leave no cached stages. Only the exact resident PCM/stage-cache Limit means the candidate cap is insufficient; it must occur without a new provider call for that failed request. Every other error or an unexpected successful render fails the test.

The search keeps observed lower-refusal and upper-success witnesses, bounded by 1 and StageLimits::default().maximum_resident_frames. The loop strictly halves that finite interval. It independently repeats the adjacent selected boundary and one-below witnesses at the end. This is an actual fresh public two-request boundary for the fixed fixture and request, not an algebraic proof of native layout or a universal minimum for unrelated plans.

The selected cap must then pass a separate behavioral check without any enlargement or research: a fresh renderer at that same cap must refuse raw256 before any provider call, then reach the sentinel on exactly three raw128 requests on that SAME renderer. This plateau witness is deliberately beyond the two requests used to choose the cap; it prevents the helper from merely baking a growing per-failure leak into its calibration. It also retains the important failure-then-reuse sequence.

Only the three failing test sites switch from their old numeric allowance to this measured helper with frames128. Their existing raw256 rejection, provider asset/count, cached-stage, cancellation and same-renderer reuse assertions remain literal. The cancellation test gains an explicit raw256 exclusion from its helper as requested. No original assertion or oracle is removed or normalized.

## Limits and execution owed

No native success or measured numeric cap is claimed by this candidate. Parent must compile and run sound_events for Main and Scope, then preserve the actual selected-boundary result through its qualification receipts. If raw128 cannot reach its sentinel within the current default, if any non-resident error occurs during the bounded probes, or if raw256 admits at the selected boundary, the test fails rather than changing the cap.

The sentinel deliberately exits at provider resolution; these tests do not decode PCM or prove full successful playback. They prove pre-provider resource gating, provider/cancellation ordering and reservation cleanup through repeated failures. Production caps, canonical weights, independent frozen oracles and the actual default D lane are unchanged.
