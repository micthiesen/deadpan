# Root suppression emission native custody tests

Scratch-only test proposal against the integrated D Root collector. No repository changes, compiler/build/native execution or Git operations were made. Parent owns integration and execution.

## Integration hook

Install root_mask_emission_tests.rs as:

crates/deadpan-audio/src/shared_eq/original_inputs_root_mask_tests.rs

Add this child in crates/deadpan-audio/src/shared_eq/original_inputs_owned_masks_tests.rs:

    #[path = "original_inputs_root_mask_tests.rs"]
    mod root_mask_emission;

This child can reuse the existing checked setup, graph, control, WAV Provider, cache, and Point helpers from original_inputs_owned_masks_tests.rs. The standalone Root/physical-Domain fixture rewrites the checked document into one 64-frame SilentHold and compiles it normally. The setup still opens the qualified real WAV fixture; no native descriptor, synthetic lease or mask is injected.

## Proposed coverage

- Public StageAudio::read and read_domain each emit a nonempty owned AudioSample mask from the checked SilentHold. Each path compares PCM, mask values and capacity to the D-only legacy Root replay, then holds the active output after dropping Provider and StageAudio and observes the account until output drop.
- A held public Root output constrains a later actual Root request at a measured whole-request resident minimum. A bounded binary search uses fresh renderer, fixture provider, and actual held Root output at every attempt, with the original StageLimits default as the ceiling. It checks one below versus exact minimum and verifies retry after release. This boundary includes checked Plan query/source guards and construction peak; it is not attributed to the mask alone.
- A held Root output from the appended checked SilentHold constrains warm Original prediction over the real WAV-backed source at root 0..64. The ceiling is cached resident frames + the renderer baseline after subtracting this held mask payload + 37 requested additional frames, matching the existing Point prediction test. Since the held mask remains in the account, the actual reservation exceeds that ceiling; prediction is denied without provider calls or Original-cache key changes. After output drop, the same cached Arc is admitted.
- The D legacy Root switch is exercised around a public Root read while a checked public Point read still returns an owned Point mask. This checks that Root replay leaves C Point policy enabled.
- The controlled Root read work-prefix test uses real ReadWork debits and actual read_controlled. It measures a successful full debit, attempts each smaller remaining allowance, records accepted Plan work and native phase units, and checks errors do not retain partial native payload. Entry cancellation and an expired deadline are also asserted with zero source callbacks/work.

The standalone all-Hold Root fixture removes provider I/O while retaining the real checked Root query and its metadata/admission work. Each whole-request boundary attempt starts fresh, constructs a real owned Root mask, then performs a second full Root read under the candidate ceiling. The Original warm-prediction case uses the existing checked project plus its appended SilentHold, so the cached Original remains a real WAV-backed Source at 0..64.

## Deliberate coverage limits

This proposal does not claim a provider callback after a Root policy event, because root source preparation precedes raw-policy emission. Entry cancellation/deadline and actual Plan work-prefix cleanup are deterministic with existing interfaces. No safe deterministic trigger was found for failure after D has emitted its pending mask but during fade application: creative-fade structure is validated before preparation and the fade applier has no injected failure/control seam. Adding a test-only failure hook solely for this case would widen instrumentation; parent can decide whether the Rust drop-order proof plus other real failure tests is sufficient.

The resident boundary is deliberately reported as whole-request pressure. It includes the source query and temporary construction peak, so it does not prove an isolated destination-mask charge. Parent separately owns a direct admitted-query overlap test. This candidate does not claim source-guard pointer provenance or per-guard runtime telemetry. Existing original_optional_publication_counts_the_public_mask_without_double_billing_cache covers publication accounting for Point masks; the warm prediction extension here specifically exercises a Root emission owner.

No capture/oracle schema or snapshot is modified. The tests compare active outputs directly against the immediately preceding C Root collector, with the D-only switch so C Point remains active.

## Pins and execution

Source hashes are in source-pins.json. Candidate Rust is rustfmt-formatted only. Compilation and execution are not claimed.
