from pathlib import Path
import difflib,hashlib,json
d=Path('/tmp/deadpan-root-mask-library-failure-fixes-candidate-2026-10-31')
roots={'main':Path('/Users/michael/Code/deadpan'),'scoped':Path('/tmp/deadpan-query-groundwork-2026-10-26/scoped')}
base='crates/deadpan-audio/src/'
files=['original_request/tests.rs','original_request/fade_admission_tests.rs','original_request/processing_admission_tests.rs','shared_eq/cached_prediction_tests.rs','shared_eq/cached_policy_tests.rs']
pins={}
for name in files:
 rel=base+name
 main=(roots['main']/rel).read_text()
 assert (roots['scoped']/rel).read_text()==main,name
 for variant,root in roots.items():
  b=(root/rel).read_bytes()
  pins[str(root/rel)]={'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
 before=d/'before'/rel;after=d/'new'/rel
 before.parent.mkdir(parents=True,exist_ok=True);after.parent.mkdir(parents=True,exist_ok=True)
 before.write_text(main)
 s=main
 if name=='original_request/tests.rs':
  old='''    with_legacy_fade_queries(
        prepared_source_read_needs_only_its_exact_issuer_work_allowance_legacy_fade,
    );'''
  new='''    // Keep the exact issuer-fee witness independent of native Root collection.
    crate::stages::root_mask_request::with_legacy_root_masks(|| {
        with_legacy_fade_queries(
            prepared_source_read_needs_only_its_exact_issuer_work_allowance_legacy_fade,
        );
    });'''
 elif name=='original_request/processing_admission_tests.rs':
  old='''    with_legacy_fade_queries(processing_only_carrier_bills_once_and_lives_through_wav_io_unused_drop_and_error_legacy_fade);'''
  new='''    // Isolate processing admission from the separately billed Root collector.
    crate::stages::root_mask_request::with_legacy_root_masks(|| {
        with_legacy_fade_queries(processing_only_carrier_bills_once_and_lives_through_wav_io_unused_drop_and_error_legacy_fade);
    });'''
 elif name=='original_request/fade_admission_tests.rs':
  old='''fn four_product_consumption_has_an_exact_four_unit_boundary_before_source_io() {
    for domain_read'''
  new='''fn four_product_consumption_has_an_exact_four_unit_boundary_before_source_io() {
    // Preserve the four issuer comparisons as an exact historical boundary.
    crate::stages::root_mask_request::with_legacy_root_masks(
        four_product_consumption_has_an_exact_four_unit_boundary_before_source_io_legacy_root,
    );
}

fn four_product_consumption_has_an_exact_four_unit_boundary_before_source_io_legacy_root() {
    for domain_read'''
 elif name=='shared_eq/cached_prediction_tests.rs':
  old='''fn observations() -> Value {
    let old: Value'''
  new='''fn observations() -> Value {
    // This compares an immutable pre-fast-path witness, including residency.
    // Both prediction modes must retain its historical Root Vec representation.
    crate::stages::root_mask_request::with_legacy_root_masks(observations_legacy_root)
}

fn observations_legacy_root() -> Value {
    let old: Value'''
 else:
  old = """    let mut suppressed = raw.suppressed.into_legacy_vector();
    suppressed.clear();
    raw.suppressed = AudioSuppressionMask::plain(suppressed);"""
  new = """    assert!(raw.suppressed.is_owned());
    // Drop the real admitted owner; this private corruption needs an empty mask.
    raw.suppressed = AudioSuppressionMask::default();"""

 assert s.count(old)==1,(name,s.count(old))
 s=s.replace(old,new)
 after.write_text(s)
(d/'source-pins.json').write_text(json.dumps(pins,indent=2)+'\n')
