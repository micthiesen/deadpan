# D first-library failure analysis and candidate fixes

Scratch only. No roots, Cargo/build/native executions, Git, production code, budgets or immutable oracles changed. Five per-file patches and their combined candidate.patch are supplied against exact identical Main/Scope test bytes, with before/new copies and source-pins.json.

Verification: rustfmt --edition 2024 --config skip_children=true passed on the five candidate files. The initial rustfmt invocation tried resolving absent sibling test modules in the isolated copy; rerunning with skip_children=true corrected that formatting-only limitation. No compilation or test execution is claimed.

## 1. Three historical constructor/issuer fee tests

The failing tests are:

- original_request/tests.rs: prepared_source_read_needs_only_its_exact_issuer_work_allowance. The test prepares actual metadata, leaves exactly 3 units for issuer comparisons and expects a successful Source read. It also checks the complete wrapper allowance, 2-unit failure before source I/O, real source checking and cleanup.
- original_request/fade_admission_tests.rs: four_product_consumption_has_an_exact_four_unit_boundary_before_source_io. It similarly preserves an exact 4-unit success / 3-unit pre-source failure boundary, including per-product issuer receipts.
- original_request/processing_admission_tests.rs: processing_only_carrier_bills_once_and_lives_through_wav_io_unused_drop_and_error. It isolates an admitted processing carrier under explicit old other-query modes and asserts spent + 1 after consumption, alongside real source callbacks, unused-drop/error cleanup and processing receipts.

D runs suppression_capacity after actual PCM preparation even on a Source read with no suppression output. A Source flattened tag adds one actual native Scan. The exact issuer-only success budgets therefore run out at the new post-source Scan, and the processing test measures 45 instead of its historical 44. This is a new native fee, not a repeated processing constructor debit.

Each candidate adds only the D-specific with_legacy_root_masks wrapper around that historical test. Existing query modes, exact work/cap values, assertions, providers and before-I/O failures remain unchanged. C Point policy remains independent and active as before. No global legacy mode, fee subtraction, cap relaxation or additional allowance is introduced. Default D fee/resource-prefix behavior belongs to the separate new producer tests and actual native receipts.

## 2. cached_prediction frozen optimization witness

shared_eq/cached_prediction_tests.rs::observations first loads independent immutable cached-original-prediction-baseline-v1 and zero-supplement bodies. It requires exact complete legacy observations and then compares current warm query optimization against the historical lane, including PCM/policy/independent query witness, cache residency, every non-work field and scoped phase-work reconciliation.

The legacy prediction wrapper already reaches historical Root collection through its older compound wrappers. The warm lane currently uses D. At the first positive SilentHold crossing, the frozen/legacy cached residency is 340 and new warm residency is 336. This is consistent with the actual frozen independent witness containing one SilentHold event and one explicit Suppressed event over [512,560). The old final merged Vec retains event-count capacity 2, or 4 eight-byte frames. D's Owned unaccounted_capacity0 excludes those same payload bytes from Original cache residency because native ownership accounts for them separately. Those four frames must not be normalized away to pass a frozen accounting assertion.

The candidate wraps the entire historical observations function in D-only legacy and moves its unchanged body into observations_legacy_root. Both prediction modes then use the historical Root storage representation. All frozen-body equality checks, independent_query_oracle comparisons, non-work field checks, phase equations and warm-query improvement assertions remain literal. The ignored historical observation writer selects the same declared historical scope.

This preserves the old optimization regression rather than claiming default D storage is identical. Separate D-active native cache tests must cover new owned account/residency and warm predictions; these patches do not award that coverage or suppress new D observations. No frozen JSON is rewritten and compare/without_work are unchanged.

## 3. cached_policy intentional mask corruption

shared_eq/cached_policy_tests.rs::cached_original_policy_keeps_selection_and_actual_owner_support_separate obtains a genuine selected-placement/bound read, then deliberately removes cached exclusions so only independently supplied current owner support can reject inactive spans. Its private corruption is expressly not an authenticated-cache publication.

D now returns a positive Owned mask for this checked read. The old into_legacy_vector call correctly panics because the native mask cannot detach its allocation/charge. Adding a detach API or disabling D for all cached-policy tests would be the wrong fix.

The candidate keeps the producing read D-active, asserts its actual positive mask is Owned, and assigns AudioSuppressionMask::default to destroy that owner and install the intentionally empty private fixture mask. It then clears exhausted exactly as before. All active/inactive support, independent allowed-bit and output assertions remain unchanged. No owning iterator, clone, new temporary Vec or production accounting exemption is added.

The old local Vec capacity after clear was not asserted and had no semantic role in this corruption test. This change tests the new ownership honestly while retaining the original owner-support witness.

## Actual aggregate lifetime note from the same D run

The two captured aggregate514 shared-EQ/shared-input paths show a real new account shell surviving after intermediate payloads are gone. In root-mask-first-main-body.json each whole-case plan receipt records initialized_account_shells=1 and initialized_account_frames=3, accepted_payload_reservations=3 and accepted_payload_frames=1043, accepted_vector_units=3 and accepted_storage_units=3. Account before_internal is 0 and account while_result_alive is 3. Final suppression still has 257 values/capacity257 on these separate general-aggregate products.

These actual positive reservations/Vec/Box operations explain that an account was truly created and its payloads later released. MaskContext::spend delegates only to spend_work; Scan alone does not initialize an account. Whole-case counters do not independently identify every intermediate read or each capacity, so this note does not claim that missing per-read attribution. Preserve the actual Some3 cleanup observation in D-active captures/tests. The historical wrappers above do not change those captures.

## Integration and execution owed

Apply each per-file patch against fresh anchors; the five files were identical in Main and Scope when pinned. Parent owns integration, compilation, focused tests and both full library reruns. All five failure names are unchanged. No native run or passing result is claimed here.

Source proof: first-library stdout records 526 passed / 5 failed / 22 ignored, exact error locations and cached-residency mismatch. The selected old cached prediction fixture and relevant production source hashes are recorded in analysis-pins.json. The candidate adds test-scope isolation or an honest owner drop; it never changes the old assertion constants, data oracle or production path.
