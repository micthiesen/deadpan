from pathlib import Path
import hashlib,json,difflib
D=Path('/tmp/deadpan-root-mask-emission-candidate-2026-10-31')
R=Path('/tmp/deadpan-query-groundwork-2026-10-26/scoped')
paths=['crates/deadpan-audio/src/raw_policy.rs','crates/deadpan-audio/src/stages.rs','crates/deadpan-audio/src/point_policy_request.rs']
before={p:(R/p).read_text() for p in paths}
for p,s in before.items():
 t=D/'before'/p;t.parent.mkdir(parents=True,exist_ok=True);t.write_text(s)
raw=before[paths[0]]
anchor='use deadpan_plan::AudioSpan;\n'
assert raw.count(anchor)==1
raw=raw.replace(anchor,anchor+'use point_suppression::ops::{MaskContext, MaskWorkPhase, RangeBuilder, begin_ranges};\n')
old='''/// The real final policy consumer. PCM remains at its original operation
/// boundaries; only the decisions above are shared with metadata consumers.
pub(super) struct Applied {'''
new='''/// Literal pre-owned consumer retained for exact compatibility observations.
#[cfg(test)]
pub(super) struct Applied {'''
assert raw.count(old)==1;raw=raw.replace(old,new)
anchor='pub(super) fn apply(\n'
assert raw.count(anchor)==1;raw=raw.replace(anchor,'#[cfg(test)]\n'+anchor)
anchor='#[cfg(test)]\n#[path = "raw_policy/tests.rs"]\nmod tests;\n'
assert raw.count(anchor)==1
addition='''pub(super) struct PendingApplied {
    pub(super) suppressed: PendingSuppression,
    pub(super) exhausted: Vec<Range<AudioSample>>,
}

pub(super) enum PendingSuppression {
    #[cfg(test)]
    Legacy(Vec<Range<AudioSample>>),
    Owned(Option<RangeBuilder<AudioSample>>),
}

impl PendingSuppression {
    pub(super) fn finish<C: MaskContext>(
        self,
        context: &C,
    ) -> Result<AudioSuppressionMask, StageAudioError> {
        match self {
            #[cfg(test)]
            Self::Legacy(ranges) => Ok(AudioSuppressionMask::plain(merged_suppression(ranges))),
            Self::Owned(None) => Ok(AudioSuppressionMask::default()),
            Self::Owned(Some(builder)) => builder.finish(context)?.merge(context),
        }
    }
}

// Count emissions of a successful visit, including empty SilentHold spans and
// duplicates. Do not move range/envelope validation ahead of its actual event.
fn suppression_capacity<C: MaskContext>(
    queries: RootReadQueriesRef<'_, '_>,
    context: &C,
) -> Result<usize, StageAudioError> {
    let mut capacity = queries.policy.suppressed.len();
    for span in &queries.flattened.spans {
        context.check()?;
        context.spend(MaskWorkPhase::Scan, 1)?;
        if is_silent_hold(&span.content) {
            capacity = capacity.checked_add(1).ok_or(StageAudioError::Range)?;
        }
    }
    Ok(capacity)
}

pub(super) fn apply_owned<C: MaskContext>(
    queries: RootReadQueriesRef<'_, '_>,
    start: AudioSample,
    samples: &mut [[f32; 2]],
    control: WorkControl<'_>,
    context: &mut C,
) -> Result<PendingApplied, StageAudioError> {
    #[cfg(test)]
    if super::root_mask_request::legacy() {
        let Applied {
            suppressed,
            exhausted,
        } = apply(queries, start, samples, control)?;
        return Ok(PendingApplied {
            suppressed: PendingSuppression::Legacy(suppressed),
            exhausted,
        });
    }
    let capacity = suppression_capacity(queries, context)?;
    let mut suppressed = None;
    let mut exhausted = Vec::new();
    visit(
        queries,
        start,
        samples.len(),
        control,
        || Ok(()),
        |event| {
            match event {
                Event::SilentHold { range, offsets }
                | Event::Suppressed { range, offsets } => {
                    samples[offsets].fill([0.0; 2]);
                    if suppressed.is_none() {
                        suppressed = Some(begin_ranges::<AudioSample, C>(context, capacity)?);
                    }
                    suppressed
                        .as_mut()
                        .expect("suppression event has funded destination")
                        .push(range, context)?;
                }
                Event::RetainedEnvelope { span, offsets } => {
                    crate::edges::apply_retained_envelope(span, &mut samples[offsets], false)?;
                }
                Event::Exhausted(range) => exhausted.push(range),
            }
            Ok(())
        },
    )?;
    Ok(PendingApplied {
        suppressed: PendingSuppression::Owned(suppressed),
        exhausted,
    })
}

'''
raw=raw.replace(anchor,addition+anchor)
stages=before[paths[1]]
anchor='''#[cfg(test)]
#[path = "point_policy_request.rs"]
mod point_policy_request;
'''
assert stages.count(anchor)==1
testhook='''
#[cfg(test)]
#[path = "root_mask_request.rs"]
mod root_mask_request;
'''
stages=stages.replace(anchor,anchor+testhook)
old='''        let raw_policy::Applied {
            suppressed,
            exhausted,
        } = raw_policy::apply(queries, start, &mut samples, control)?;
'''
new='''        let raw_policy::PendingApplied {
            suppressed,
            exhausted,
        } = raw_policy::apply_owned(
            queries,
            start,
            &mut samples,
            control,
            &mut self.masks(control),
        )?;
'''
assert stages.count(old)==1;stages=stages.replace(old,new)
anchor='''        control.check()?;
        Ok(ReadBlock {
            start,
            samples,
            dependencies,
            relative_depth,
            suppressed: AudioSuppressionMask::plain(merged_suppression(suppressed)),
            exhausted,
        })
'''
replacement='''        control.check()?;
        let suppressed = suppressed.finish(&self.masks(control))?;
        Ok(ReadBlock {
            start,
            samples,
            dependencies,
            relative_depth,
            suppressed,
            exhausted,
        })
'''
assert stages.count(anchor)==1;stages=stages.replace(anchor,replacement)
point=before[paths[2]]
assert point.count('    action()\n')==1
point=point.replace('    action()\n','    super::root_mask_request::with_legacy_root_masks(action)\n')
switch='''//! Exact final Root mask collector before native destination admission.
thread_local! {
    static LEGACY: std::cell::Cell<bool> = const { std::cell::Cell::new(false) };
}
pub(super) fn legacy() -> bool {
    LEGACY.with(std::cell::Cell::get)
}
pub(super) fn with_legacy_root_masks<T>(action: impl FnOnce() -> T) -> T {
    struct Restore(bool);
    impl Drop for Restore {
        fn drop(&mut self) {
            LEGACY.with(|legacy| legacy.set(self.0));
        }
    }
    let _restore = Restore(LEGACY.with(|legacy| legacy.replace(true)));
    action()
}
'''
newfiles={paths[0]:raw,paths[1]:stages,paths[2]:point,'crates/deadpan-audio/src/root_mask_request.rs':switch}
for p,s in newfiles.items():
 t=D/'new'/p;t.parent.mkdir(parents=True,exist_ok=True);t.write_text(s)
patch=[]
for p,s in newfiles.items():
 patch.extend(difflib.unified_diff(before.get(p,'').splitlines(keepends=True),s.splitlines(keepends=True),fromfile='a/'+p if p in before else '/dev/null',tofile='b/'+p))
(D/'candidate.patch').write_text(''.join(patch))
deps=[
 *paths,
 'crates/deadpan-audio/src/point_suppression.rs',
 'crates/deadpan-audio/src/point_suppression/ops.rs',
 'crates/deadpan-audio/src/point_suppression/mutations.rs',
 'crates/deadpan-audio/src/point_suppression/ops_trace.rs',
 'crates/deadpan-audio/src/mask_context.rs',
 'crates/deadpan-audio/src/policy_ranges.rs',
 'crates/deadpan-audio/src/raw_policy/tests.rs',
 'crates/deadpan-audio/src/internal_mask_request.rs',
 'crates/deadpan-audio/src/original_request.rs',
 'crates/deadpan-audio/src/shared_eq/original_inputs.rs',
]
pins={}
for root in [R,Path('/Users/michael/Code/deadpan')]:
 for p in deps:
  path=root/p;b=path.read_bytes();pins[str(path)]={'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
(D/'source-pins.json').write_text(json.dumps(pins,indent=2,sort_keys=True)+'\n')
for p in paths[:2]:assert before[p]==(R/p).read_text(),p
assert raw[raw.index('pub(super) fn apply(\n'):raw.index('pub(super) struct PendingApplied')].rstrip()==before[paths[0]][before[paths[0]].index('pub(super) fn apply(\n'):before[paths[0]].index('#[cfg(test)]\n#[path = "raw_policy/tests.rs"]')].rstrip()
print(json.dumps({'files':list(newfiles),'patch_bytes':(D/'candidate.patch').stat().st_size,'legacy_apply_body_literal':True,'sourcepins':len(pins)}))
