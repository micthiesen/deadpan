# D: admitted native Root suppression emission candidate

Scratch proposal only. No shared source edits, builds, native executions, Rust compiler runs or Git operations. Parent owns C publication, before capture, integration and verification. Product requirements and Gates are unchanged.

## Files and integration

candidate.patch contains two production-file edits:

- raw_policy.rs adds apply_owned, a successful-visit emission-count prepass and a pending destination that owns the real RangeBuilder<AudioSample>.
- stages.rs changes only the Root read_queries_borrowed collector/final-mask tail in production. A short masks(control) borrow is used for apply_owned, dropped before creative fades, and a new short borrow finishes the pending mask at the existing post-fade merge boundary.

The other edits are test-only compatibility hooks: a cfg(test) root_mask_request module declaration/file and chaining point_policy_request::with_legacy_policy through with_legacy_root_masks. The original Applied/apply implementation remains literal under cfg(test); a textual assertion in prepare.py checks the full old apply function body. The existing merged_suppression body is untouched.

The new D-only switch is stages::root_mask_request::with_legacy_root_masks. It changes only final Root collection. It deliberately leaves C Point policy active, so the immediate pre-D C body can be replayed without disabling C. Older Point policy and compound legacy wrappers also select Root legacy through the separate chain hunk, preserving their old complete bodies. Nested overrides restore their previous value on normal exit or unwinding.

The before/new trees hold exact files. Both roots had identical raw_policy.rs, stages.rs and point_policy_request.rs bytes at preparation time. Apply the reviewed hunks against fresh roots; do not use a whole-file replacement to overwrite later parent changes. source-pins.json records 26 exact dependencies across Main and Scope.

## Physical destination and order

The count is policy.suppressed.len() plus one for each flattened span matching existing is_silent_hold. The prepass checks the actual WorkControl and accepts one native Scan before inspecting each flattened tag. It counts empty SilentHold ranges and duplicates. It does not inspect explicit policy entries, validate ranges, run an envelope, invoke a provider, replay the visitor, reprice a Plan query or change a cap.

The count is exact for a fully successful visit. On a later error, it is a funded full-success upper bound rather than the number of events emitted before failure. The requested capacity and accepted event prefix must be reported separately.

No destination is allocated before the first actual suppression event. At that event's old push position, PCM zeroing still happens first. begin_ranges reserves the actual destination Vec and its future unique Box using the existing real controller account, then allocates the exact-capacity Vec. push accepts its existing native Map/check before the actual vector write and cannot grow the vector. Retained-envelope evaluation, exhausted emission, whole-list policy validation and explicit-policy zeroing retain their one original visitor order.

PendingSuppression::Owned contains Option<RangeBuilder<AudioSample>>, retaining no context or renderer borrow. A failed visitor drops its pending Vec before Charge through existing Storage field order. A creative-fade error likewise drops the pending Vec without constructing the final Box. The caller's existing post-fade control.check remains before finish. The builder then spends actual storage work and constructs its funded Box; the existing owned merge sorts/compacts that same Vec in place. No second merge Vec or ordinary intermediate mask is introduced.

Successful no-emission collection returns the existing allocation-free default. A successfully emitted empty range still creates a one-element owned destination and remains a range after merge, matching the old behavior.

Prepared Root/Domain metadata remains borrowed through the entire call, including finish and merge. The new context does not take or release the source lease. Ordinary occurrence/beat query setup remains ordinary and explicitly outside this destination claim. The existing owned mask account and cache unaccounted_capacity0 behavior apply without changing their APIs.

The exhausted Vec and existing numeric PCM/envelope loops are unchanged and remain outside this bounded storage/work closure.

## Empty-range and merge check

Both merges sort on range.start and use the identical predicate next.start <= previous.end, followed by max(end). Neither filters empty or reversed ranges. Therefore a standalone 4..4 remains present; empty ranges at or inside an existing interval join just as before. Duplicate and adjacent events compact identically while preserving the full original event-count capacity. Actual raw span_offsets rejects reversed spans before emission, but no new merge normalization was introduced.

The count prepass adds resource-error boundaries ahead of old validation. Thus under exhausted work or cancellation it can fail before an old malformed span/envelope error. Allocation or Map refusal can follow an event's original PCM zeroing. Under sufficient resources the non-resource visitor/PCM/fade validation order remains unchanged. Capture the new resource prefixes honestly.

## Focused test proposal

raw_policy_owned_tests.rs is an optional child of the existing raw_policy/tests.rs, installed as raw_policy/owned_tests.rs with a path module declaration in that existing test file. It reuses the existing raw adapter fixtures. These are lower-level adapter tests with a real StageAudio reserve/account path, not checked provider/Root factory coverage and not a replacement for parent native cases.

Its four proposed tests cover:

- A standalone empty SilentHold tag and mixed empty/duplicate events, exact old output union/capacity/PCM bits, actual builder len/capacity, real account retention after controller/ReadWork disposal, and no second Vec across owned merge.
- A truly empty event collector with no account, allocation work or PCM change.
- A later invalid explicit-policy range after a real prior SilentHold event: old zeroing order, pending payload disposal to actual shell residency and zero final-Box allocation work.
- D-only override independence from C and restoration of nested overrides.

The proposal does not expose a new production pointer/Vec extraction API. It can assert the finalized Vec pointer remains unchanged through owned merge. A runtime assertion of the pending pre-Box pointer still needs an existing test-only builder observer or an ops-descendant test; safe Rust moves of the unchanged Storage/Vec already provide the static move argument. The source Plan policy pointer versus destination pointer and all admitted source/destination overlap must be checked on actual parent native fixtures, not inferred from these adapter tests.

Still owed to the parent: actual checked Root and physical-Domain providers, fixed warmed exact-cap/one-below cases, every accepted construction/merge prefix, cancellation/deadline boundaries, fade/envelope failures, real Original cache publish/hit/pin/evict, complete immediate-C and older replay, full numerical outputs and native intervals with literal invalid flags. No execution is claimed here.

## Safety boundaries

There is no generic GuardedBound extraction, Plan API change, relabeling, refund, cap increase, canonical-weight change, mask clone or detach. The actual AudioSample event type is preserved directly, without recomputing RoundEven geometry through PointCeil. New bounded native work uses only existing phases.

No borrow or sizing obstacle was found in the current source. The two temporary context borrows end at their calls; the pending destination owns its charge and allocations. Allocation/capacity qualification continues to use the existing requested-Layout admission and actual capacity assertion, not an unsupported allocator guarantee.
