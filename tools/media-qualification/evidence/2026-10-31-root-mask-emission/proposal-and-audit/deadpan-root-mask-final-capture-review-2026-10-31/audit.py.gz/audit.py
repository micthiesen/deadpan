from pathlib import Path
import hashlib,json,collections,re
P=Path('/tmp/deadpan-root-mask-emission-qualification-2026-10-31')
D=Path('/tmp/deadpan-root-mask-final-capture-review-2026-10-31')
memo={};pins={}
def pin(path):
 p=Path(path).resolve()
 if str(p) in memo:return memo[str(p)]
 h=hashlib.sha256();size=0
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1024*1024),b''):h.update(b);size+=len(b)
 r={'bytes':size,'sha256':h.hexdigest()};memo[str(p)]=r;return r
def evidence(path):pins[str(path)]=pin(path)
def load(n):return json.loads((P/n).read_text())
def guard(r,code=0):
 assert r['exit_code']==code and r['sources_unchanged'] and r['binaries_unchanged']
 assert r['source_before']==r['source_after'] and r['binary_before']==r['binary_after']
 assert r['removed_paths_absent_before']==r['removed_paths_absent_after']
 assert all(not(Path(r['cwd'])/n).exists() for n in r['removed_paths_absent_after'])
 for p,h in {**r['binary_after'],**r['streams']}.items():assert pin(p)==h,p;evidence(p)
def test_summary(name):
 r=load(name+'.json');guard(r);evidence(P/(name+'.json'))
 matches=re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored; \d+ measured; (\d+) filtered out;', (P/(name+'.stdout')).read_text())
 assert len(matches)==1,(name,matches)
 values=dict(zip(['passed','failed','ignored','filtered'],map(int,matches[0])))
 assert values['failed']==0
 return r,values
result={'build_join':{},'captures':[],'runtime':{},'source_preservation':{}}
roots={'main':Path('/Users/michael/Code/deadpan'),'scoped':Path('/tmp/deadpan-query-groundwork-2026-10-26/scoped')}
builds={};compiled={}
for v,root in roots.items():
 for version in [6,7]:
  label=f'root-mask-build{version}-{v}'
  r=load(label+'.json');guard(r);evidence(P/(label+'.json'));evidence(P/(label+'-pins.json'))
  array=load(label+'-pins.json');assert len(array)==21
  records=[]
  with (P/(label+'.stdout')).open() as f:
   for line in f:
    try:records.append(json.loads(line))
    except json.JSONDecodeError:pass
  byname={}
  for row in array:
   assert row['name'] not in byname;byname[row['name']]=row
   assert pin(row['path'])=={'bytes':row['bytes'],'sha256':row['sha256']}
   evidence(row['path'])
   a=row['artifact'];assert a in records
   assert a['reason']=='compiler-artifact' and a['target']['name']==row['name']
   assert a['profile']['opt_level']=='2' and a['profile']['test'] and a['profile']['debug_assertions'] and a['profile']['overflow_checks']
   assert Path(a['target']['src_path']).resolve().is_relative_to(root.resolve())
   assert a['executable'] in a['filenames']
  builds[v,version]=r;compiled[v,version]=byname
 old=builds[v,6]['source_after'];new=builds[v,7]['source_after']
 assert set(old)==set(new)
 delta=[p for p in old if old[p]!=new[p]]
 expected=str(root/'crates/deadpan-audio/tests/sound_events.rs')
 assert delta==[expected]
 before=compiled[v,6];after=compiled[v,7];assert set(before)==set(after)
 different=[n for n in before if before[n]['sha256']!=after[n]['sha256']]
 assert different==['sound_events']
 joined=load(f'root-mask-final-{v}-matrix.json');original=load(f'root-mask-matrix-{v}-matrix.json')
 assert len(joined)==len(original)==21
 counts=collections.Counter()
 for row in joined:
  target=row['target'];assert row['sha256']==after[target]['sha256']
  run,summary=test_summary(row['run'])
  assert run['command'][0]==after[target]['path'] if target=='sound_events' else run['command'][0]==before[target]['path']
  assert next(iter(run['binary_before'].values()))['sha256']==row['sha256']
  if target=='sound_events':
   assert row['run']==f'root-mask-sound-fixed-{v}'
   assert run['source_before']==new
  else:
   assert row['retained_exact_binary']
   oldrow=next(a for a in original if a['target']==target)
   assert row['run']==oldrow['run'] and row['sha256']==oldrow['sha256']
   assert run['source_before']==old
  counts.update(summary)
 assert dict(counts)=={'passed':1120 if v=='main' else 1114,'failed':0,'ignored':22,'filtered':7 if v=='main' else 0}
 librow=next(a for a in joined if a['target']=='deadpan_audio')
 lib=load(librow['run']+'.json')
 libtext=(P/(librow['run']+'.stdout')).read_text()
 _,libcounts=test_summary(librow['run'])
 assert libcounts=={'passed':539 if v=='main' else 533,'failed':0,'ignored':22,'filtered':0}
 prefixes=[
  'stages::raw_policy::tests::guarded_query::',
  'stages::shared_eq::original_inputs::tests::owned_masks::root_mask_emission::']
 checked={}
 for prefix,number in zip(prefixes,[3,5]):
  rows=[line for line in libtext.splitlines() if line.startswith('test '+prefix)]
  assert len(rows)==number and all(line.endswith(' ... ok') for line in rows)
  checked[prefix]=[line.split(' ... ')[0][5:] for line in rows]
 failed=load(f'root-mask-matrix-{v}-sound-events.json')
 assert failed['exit_code']!=0
 guard(failed,failed['exit_code']);evidence(P/f'root-mask-matrix-{v}-sound-events.json')
 assert failed['source_before']==old
 assert next(iter(failed['binary_before'].values()))['sha256']==before['sound_events']['sha256']
 result['build_join'][v]={'only_source_delta':delta,'before':old[expected],'after':new[expected],'identical_executables':20,'changed_executable':'sound_events','literal_artifacts_checked':42}
 result['runtime'][v]={'all21':dict(counts),'library6_and_identical7':libcounts,'checked_eight_tests':checked,'replaced_sound6_failed_exit':failed['exit_code']}
 for n in [f'root-mask-final-{v}-matrix.json',f'root-mask-matrix-{v}-matrix.json']:evidence(P/n)
 for n in ([f'root-mask-strict3-{v}'] if v=='main' else [f'root-mask-clippy3-{v}']):
  r=load(n+'.json');guard(r);evidence(P/(n+'.json'))
  assert r['source_before']==new
  result['runtime'][v]['strict_command']=r['command']
 doc,doccounts=test_summary(f'root-mask-doc-{v}')
 assert doc['source_before']==new and doccounts=={'passed':0,'failed':0,'ignored':0,'filtered':0}
 assert doc['command']==['cargo','test','-p','deadpan-audio','--doc']
 result['runtime'][v]['doctests']=doccounts
active_sha='596d738a53f6ef4cbf7870d74b3025504f6289f735ea91f4a38ed45c6661f44a'
modes=[
 ('active','root','DEADPAN_ROOT_MASK_AFTER','44068bd971dee62e2ed8cbaffbb2f18922283f83','capture_active_root_mask_after_v1',active_sha),
 ('active2','root','DEADPAN_ROOT_MASK_AFTER','44068bd971dee62e2ed8cbaffbb2f18922283f83','capture_active_root_mask_after_v1',active_sha),
 ('active3','root','DEADPAN_ROOT_MASK_AFTER','44068bd971dee62e2ed8cbaffbb2f18922283f83','capture_active_root_mask_after_v1',active_sha),
 ('before-policy','policy','DEADPAN_POINT_POLICY_AFTER','eedbc58272bdd009a65239b7104ddb786a2554fc','capture_active_point_policy_after_v1','afa6038a02c959c7192c09c08a89266c7d52151a5e59a4f69828fbdf67e7414e'),
 ('before-interval','intervals','DEADPAN_QUERY_INTERVAL_AFTER','ab211a2f132379a246157c3596d95fc42121541c','capture_active_query_intervals_v1','f64d3a00a10967cc3822083d21705bd454f2d33ff2198da30e25671092ab5a53'),
 ('before-off','old','DEADPAN_INTERNAL_MASK_AFTER','e8fcdb3cb02f9682bef53f6ba2709e8a5ad692d0','capture_active_internal_mask_after_v1','af7a292718365c34fa03692e2cbe58a2cfb3c6d444b5ae29d52647e1fdbbff14')]
for variant,root in roots.items():
 runner=P/('run_qualified.py' if variant=='main' else 'run_scoped_qualified.py')
 evidence(runner)
 for mode,kind,prefix,checkpoint,test,sha in modes:
  label=f'root-mask-final7-{mode}-{variant}'
  r=load(label+'.json');guard(r)
  proof=load(label+'-proof.json');manifest=load(label+'-source-manifest.json')
  assert r['runner_sha256']==pin(runner)['sha256']
  assert r['source_before']==builds[variant,7]['source_after']
  assert {str(Path(p).relative_to(root)):h for p,h in r['source_before'].items()}==manifest
  assert len(manifest)==proof['source_inputs']==(2927 if variant=='main' else 2599)
  assert pin(P/(label+'-source-manifest.json'))['sha256']==proof['source_manifest_sha256']
  assert proof['base_revision']==checkpoint and proof['mode']==kind and proof['variant']==variant
  exe=compiled[variant,7]['deadpan_audio']
  assert r['command']==[exe['path'],'--ignored','--exact','stages::bound_reads::retained_host_baseline::pairs::native_mask_after::'+test,'--nocapture','--test-threads=1']
  assert proof['binary_sha256']==exe['sha256']
  e=r['environment'];v='main-inherited' if variant=='main' else 'scoped-published'
  assert e[prefix+'_VARIANT']==v and e[prefix+'_SOURCE_SHA256']==proof['source_manifest_sha256']
  assert e[prefix+'_PUBLISHED_CHECKPOINT']==checkpoint
  assert Path(e[prefix+'_OUTPUT']).resolve()==(P/(label+'-body.json')).resolve()
  assert e['CARGO_PROFILE_DEV_OPT_LEVEL']=='2' and e['CARGO_INCREMENTAL']=='0' and e['DEADPAN_REQUIRE_PHYSICAL_MAC']=='1'
  body=load(label+'-body.json')
  assert body.pop('variant')==v and body.pop('source_sha256')==proof['source_manifest_sha256']
  assert body['native_requests'].pop('variant')==v and body['native_requests'].pop('source_sha256')==proof['source_manifest_sha256']
  canonical=(json.dumps(body,sort_keys=True,separators=(',',':'))+'\n').encode()
  assert canonical==(P/(label+'-canonical.json')).read_bytes()
  assert hashlib.sha256(canonical).hexdigest()==proof['sha256']==sha and len(canonical)==proof['bytes']
  for ending in ['.json','-proof.json','-source-manifest.json','-body.json','-canonical.json']:evidence(P/(label+ending))
  result['captures'].append({'label':label,**proof})
 # final named source preservation, without copying a broad Main path map
 current=builds[variant,7]['source_after']
 for p,h in current.items():assert pin(p)==h,p
 owned=set(load('owned-code-paths.json'));assert len(owned)==19
 initial=load(variant+'-initial-authority.json')
 unowned={p:h for p,h in initial.items() if p not in owned}
 for p,h in unowned.items():assert pin(root/p)==h,p
 digest=hashlib.sha256((json.dumps(unowned,sort_keys=True,separators=(',',':'))+'\n').encode()).hexdigest()
 assert len(unowned)==(2908 if variant=='main' else 2580)
 result['source_preservation'][variant]={'initial_inputs':len(initial),'unowned_exact':len(unowned),'unowned_manifest_sha256':digest,'current_inputs_exact':len(current)}
 for p in owned:
  assert (roots['main']/p).read_bytes()==(roots['scoped']/p).read_bytes()
  evidence(root/p)
  old=P/'before'/variant/p
  if old.exists():
   evidence(old)
   if p in initial:assert pin(old)==initial[p]
 assert all(str(Path(p).relative_to(root)) in initial or str(Path(p).relative_to(root)) in owned for p in current)
 for name in [variant+'-initial-authority.json','owned-code-paths.json','immutable-oracle-pins.json']:evidence(P/name)
 immutable=load('immutable-oracle-pins.json');assert len(immutable)==32
 for x in immutable:assert pin(root/x['path'])['sha256']==x['sha256'],x['path']
 def function(text,start):
  a=text.index(start);return text[a:text.index('\n}\n',a)+3]
 oldraw=(P/'before'/variant/'crates/deadpan-audio/src/raw_policy.rs').read_text()
 raw=(root/'crates/deadpan-audio/src/raw_policy.rs').read_text()
 for start in ['pub(super) fn apply(','pub(super) fn visit<','fn span_offsets(']:assert function(oldraw,start)==function(raw,start)
 before=(P/'before'/variant/'crates/deadpan-audio/src/stages.rs').read_text()
 now=(root/'crates/deadpan-audio/src/stages.rs').read_text()
 for start in ['fn merged_suppression<','fn is_silent_hold(','impl Default for StageLimits {']:assert function(before,start)==function(now,start)
 result['source_preservation'][variant]['immutable_oracles_exact']=32
 result['source_preservation'][variant]['legacy_functions_and_default_limits_literal']=True
a=load('root-mask-final7-before-policy-scoped-canonical.json')
b=load('root-mask-final7-active-scoped-canonical.json')
c=collections.Counter()
assert len(a['native_requests']['cases'])==len(b['native_requests']['cases'])
for u,v in zip(a['native_requests']['cases'],b['native_requests']['cases']):
 assert u['fixture']==v['fixture'] and len(u['operations'])==len(v['operations'])
 for x,y in zip(u['operations'],v['operations']):
  assert {k:z for k,z in x.items() if k!='paired'}=={k:z for k,z in y.items() if k!='paired'}
  x=x['paired']['new']['read']['output'];y=y['paired']['new']['read']['output']
  assert x==y;c[x['status']]+=1
assert c=={'Ok':264,'Error':480};result['complete_outputs']=dict(c)
account=[];fields=0
for group,x,y in [('internal',a['internal_and_transfer_paths']['cases'],b['internal_and_transfer_paths']['cases']),('transfer',a['internal_and_transfer_paths']['public_transfers']['cases'],b['internal_and_transfer_paths']['public_transfers']['cases'])]:
 assert len(x)==len(y)==(10 if group=='internal' else 4)
 for i,(u,v) in enumerate(zip(x,y)):
  assert u['name']==v['name']
  for k in u:
   if k.startswith('result_'):assert u[k]==v[k];fields+=1
   if k.startswith('account_') and u[k]!=v[k]:account.append({'group':group,'index':i,'name':u['name'],'field':k,'before':u[k],'after':v[k]})
assert fields==42 and len(account)==8
assert {(a['group'],a['index']) for a in account}=={('internal',4),('internal',5)}
for x in account:assert x['before']=={'live_frames':None,'status':'None'} and x['after']=={'live_frames':3,'status':'Some'}
result['account_changes']=account;result['exact_result_fields']=fields
for i in [4,5]:
 p=b['internal_and_transfer_paths']['cases'][i]['native_mask_work_whole_case']
 assert not p['overflow'] and p['plan']['accepted_payload_reservations']==3 and p['plan']['accepted_payload_frames']==1043
 assert p['plan']['initialized_account_frames']==3 and p['plan']['initialized_account_shells']==1
intervals=collections.Counter();partial=[]
def visit(v,path=''):
 if isinstance(v,dict):
  if v.get('schema')=='native-mask-query-intervals-v1':
   intervals['snapshots']+=1
   assert v['active_intervals']==v['dropped_intervals']==0 and not v['misnested'] and not v['overflow']
   for r in v['rows']:
    intervals['rows']+=1
    assert r['attributable'] and not r['foreign_work_overlap']
    for p in ['host','native']:
     x=r[p+'_before'];y=r[p+'_after'];assert x['reset_epoch'] is not None and x['reset_epoch']==y['reset_epoch'] and not x['overflow'] and not y['overflow']
    assert r['native_before']['enabled'] and r['native_after']['enabled']
    if r['claim'] is None:intervals['partial']+=1;partial.append({'path':path,'row':r});continue
    claim=r['claim'];intervals['complete']+=1
    assert claim['canonical']+claim['additional']==claim['total']==claim['expected_debit'] and claim['forwarded'] and not claim['ordinary']
    for lane in [0,1]:
     x=r['native_before']['lanes'][lane];y=r['native_after']['lanes'][lane];assert len(x)==len(y)==8
     delta=[v-u for u,v in zip(x,y)];assert min(delta)>=0
     host=r['host_after']['units'][lane]-r['host_before']['units'][lane]
     observed=r['work_after'][lane]-r['work_before'][lane]
     assert host>=0 and observed>=0 and observed==(claim['total'] if lane==r['selected_lane'] else 0)+sum(delta)+host
  else:
   for k,z in v.items():visit(z,path+'/'+k)
 elif isinstance(v,list):
  for i,z in enumerate(v):visit(z,path+'/'+str(i))
visit(b)
assert intervals=={'snapshots':758,'rows':478,'complete':477,'partial':1}
result['intervals']=dict(intervals);result['partial']=partial
for n in ['final-qualification-join.json','final-source-audit.json','audio-matrix-summary.json','final7-capture-analysis.json','before-freeze-proof.json','capture_after.py','run_qualified.py','run_scoped_qualified.py','final_join.py','audit_sources.py']:evidence(P/n)
(D/'audit-results.json').write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
(D/'evidence-pins.json').write_text(json.dumps(pins,indent=2,sort_keys=True)+'\n')
print(json.dumps({k:v for k,v in result.items() if k not in ['captures','account_changes','partial']},indent=2))
