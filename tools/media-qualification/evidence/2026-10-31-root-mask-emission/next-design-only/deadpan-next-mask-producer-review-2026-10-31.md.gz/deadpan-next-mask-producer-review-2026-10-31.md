# Review: next mask producer after D

Verdict: GO WITH CHANGES for the non-separate SharedMix producer. The recommendation is sound, but the proposed ownership carrier and reservation boundary must be explicit before implementation. No implementation, build, native execution or Git operation was performed. D is not treated as passed or published.

Reviewed proposal: /tmp/deadpan-next-mask-producer-design-2026-10-31.md, SHA3ecf7c1ed8707cb5ad21a579a8a0d2c9c91978f8aeb153076e917dd8cd141d4e. All eight declared Scope source pins match current files. Exact additional sources are pinned in /tmp/deadpan-next-mask-producer-review-2026-10-31/source-pins.json. Scope is the authority; Main shared_eq.rs differs and was not used as implementation authority.

## 1. Preserve the real source reservation through projection

Moving self.permissions out of SharedMix does not itself remove its existing funding. In current Scope:

- read_shared_program computes frames*12 + mix.resident_frames() at shared_eq.rs:585-588, admits it at645-647, and adds it to self.active_frames before allocation.
- Non-separate resident_frames includes every sum/bus PCM and permission buffer, at shared_mix.rs:417-425. Permissions is a fixed64-word bitset, not a boolean.
- Non-separate verify_prediction returns zero at shared_mix.rs:489-497. Thus the adjustment at shared_eq.rs:887-896 retires no non-separate source-grid reservation.
- The reservation remains active through mix.finish at897, the nested-depth check at917 and the rest of the closure. The tail subtracts it only at930.

Therefore a moved permission Vec remains funded after the SharedMix value is consumed if, and only if, its complete use and physical disposal stay inside that existing read_shared_program closure, before the tail release. There is no need to invent a second source ticket or retroactively admit the grid.

Concrete required contract:

    mix.finish returns final PCM plus an inline pending permission carrier
    existing equalizer callback has ended
    existing nested-depth check succeeds
    count empty entries while the moved grid remains live
    admit/allocate the exact AudioSample destination with source reservation still active
    emit, finish the actual Box, merge the owned destination
    physically drop the moved grid
    construct WideBlock containing only PCM and the final owned mask
    exit closure; only then subtract the original reservation

Failure must follow the same lifetime order. Locals inside the closure, including moved grid and pending/final native destination, are destroyed before the outer scalar reservation is retired. Keep the existing whole reservation unchanged until this point, even when the consumed SharedMix has already freed its other buffers.

Reject this variant: return a pending grid from read_shared_program, run its reservation-release tail, then reserve a destination in read_shared_input. The physical grid would remain alive after its source charge disappeared. Re-admitting it later would not repair that gap. A Plain wrapper or a comment saying it was formerly resident would not repair it either.

## 2. The current final receiver is Plain, so the carrier must change

The proposal incorrectly says current read_shared_input already extends into an account-owned final mask. Current Scope initializes the result with default Plain, then wraps each WideBlock Vec with AudioSuppressionMask::plain at shared_eq.rs:361-364. SuppressionMask::extend takes the literal uncharged Vec path when both sides are Plain, at mutations.rs:142-148; merge likewise takes its Plain allocation path. The current aggregate mask remains ordinary.

The minimal coherent ownership change needs:

- shared_mix.rs: MixedBlock carries either a literal ordinary mask for the deferred Components/legacy path or an allocation-free pending final permission grid with its actual AudioSample start. An inline enum is sufficient; moving a Vec header allocates no new policy-source buffer.
- shared_components.rs: its existing finish algorithm stays literal and wraps its existing Vec in the ordinary enum case. This is a type adaptation, not ownership coverage for Components.
- shared_eq.rs: consume the pending grid inside the live read_shared_program reservation as above. Change private shared_eq::WideBlock.suppressed to AudioSuppressionMask. At read_shared_input, pass block.suppressed directly to extend, with no Plain conversion or extraction.
- shared_eq.rs and event_returns.rs: adapt existing empty constructors of this same private WideBlock to the empty mask default. event_returns.rs uses this type at98,406,440,514; shared_eq_tile constructs its empty cached instance at1278. Do not confuse it with the separate authored_eq::WideBlock type.

The existing extend then makes a Plain default destination genuinely owned when the first owned chunk arrives; later replacements admit their complete destination while both sources remain live. Its final owned merge allocates no second Vec. Do not change the chunking, but the carrier/argument type must change. Never recover a Vec from an owned chunk to preserve an old signature.

This is wider than two implementation files, even though only one numerical producer is selected. These mechanical receiver changes should be named in the contract. Check the actual pinned layout of the private cached WideBlock when replacing its Vec-sized field, so old metadata/cache residency evidence is preserved.

## Numerical and error-order constraints

The non-separate branch is an actual independent producer, not a copy of a Plan policy. It emits one absolute AudioSample interval per empty final permission entry. Count every empty entry, not coalesced runs, to preserve the old final capacity from merged_suppression(raw.len()). Retain the old self.start + index and at +1 clock. read_shared_program has already checked start+frames and frames<=MAX_OUTPUT_FRAMES; the grid has exactly frames entries. This also covers negative starts in temporal history without relabeling through a Point or Signal clock.

Do not infer permissions from PCM, reuse a source Root mask or clip to nominal Root support. Allowed zero-valued PCM must remain permitted. Keep the equalizer/transfer loop and callback failure order literal. The old final permission projection itself introduces no reachable non-resource error under the validated shape; moving new count/admission work after the existing nested-depth check retains that error's priority. New budget/cancellation/admission failures are new resource prefixes and must be recorded honestly.

Native Scan/checks must bound both count and emission scans. Define the unit honestly: each current Permissions::is_empty inspects at most64 words with short-circuit behavior. Do not claim a per-word trace from a per-entry counter. No new canonical Plan weights, cap increases, buffer-count reduction or early reservation refund is justified.

All-permitted projection returns the existing allocation-free empty mask. A nonempty destination retains the complete capacity charge even after in-place merge compacts its length.

## Alternative comparison, limited to two choices

Preferred: the corrected non-separate SharedMix contract above. It has an already resident concrete permission source and a real reservation whose lifetime can cover the new target. Its absolute AudioSample clock is already fixed. It does require the complete carrier propagation listed above.

Deferred alternative: routed.rs:464-503 is a real ordinary projected output lane. It calls suppress_signal with PreserveTape(projection.output_policy()), then wraps the returned Vec Plain. SignalInput::PreserveTape specifically calls AudioSignalTape::policy_after_preserve; audio_tape.rs:408-480 performs run lookup, policy-override recursion, policy_on_grid with the tape boundary rule and endpoints disabled after Preserve, then aggregation/merge. C's direct PointCeil admitted query does not cover this path.

Closing only its final native copy could be bounded, but the tape's ordinary Plan allocations would remain ordinary and must be named as such. Closing the actual policy producer requires a separate admitted tape/run/override contract preserving the tape grid and after-Preserve endpoint semantics. Also, suppress_signal has two other production callers, stages.rs:2704 and stage_cache.rs:133, so a generic helper rewrite silently broadens the unit. This is a genuine next candidate, but it is not a simpler full producer closure than corrected SharedMix.

The proposal's statement that stage_projection::prepare_projected caches PCM/dependencies rather than a final suppression Vec is correct. That does not make routed projected policy already covered.

## Required proof and before authority

Use a newly pinned final D before body only after D qualifies and publishes. The historical84f971e... body is pre-D/B. The current first D body is accessible at /tmp/deadpan-root-mask-emission-qualification-2026-10-31/root-mask-first-scoped-canonical.json and has SHA596d738a53f6ef4cbf7870d74b3025504f6289f735ea91f4a38ed45c6661f44a. It is preliminary, not a final post-D authority. Correct the design's stale statement that these paths were unavailable.

The aggregate-514 path is a good positive witness. Record actual non-separate producer entry/exit for each 256/256/2 chunk, its source-grid pointer/len/capacity and active reservation, destination capacity/charge and pointer through merge, plus complete final mask/PCM/dependencies/depth. Show source funding is unchanged through destination admission and grid disposal, including an actual refusal while the source grid still exists. Account observations after the read alone cannot prove that overlap.

The zero-emission control must prove that this non-separate producer was reached. A final empty mask or an existing general retained/EQ test alone is insufficient. Earlier D producers can initialize a shell or allocate temporary masks during the same real graph read, so assert zero new payload/reservation at this producer's boundary rather than assuming the whole invocation's account remains uninitialized.

Likewise, a work/cap failure must demonstrably reach this producer. An earlier ordinary query, D Root collector or native EQ failure does not exercise new pending-grid cleanup. Keep the actual source reservation and account baseline visible through the refusal. Check cleanup to prior native payload plus any retained shell, active/source ledgers restored, and no returned WideBlock.

Freeze complete output/error/capacity parity and independent legacy replay for the entire deferred Components branch and current D bodies. Preserve old invalid flags and whole-invocation counters literally. No global residual attribution locates nested SharedMix invocations.

No implementation should begin from this review until the parent completes D qualification. Components mask construction, projected Plan policy, exhausted storage, PCM/dependencies and whole preparation remain outside the selected ownership claim.
