# Review: next raw Root suppression producer

Verdict: GO with the implementation constraints below. No blocking correctness flaw found in the proposed two-production-file seam. This is a review of the design against current pinned sources, not an implementation approval, runtime result, Gate award, or assertion that C is qualified/published. No roots, builds, native executables, Git, or immutable bodies were changed.

## What is correct

The chosen seam is the actual ordinary final native producer. raw_policy::apply appends one AudioSample range for each SilentHold event and each explicit Suppressed event. read_queries_borrowed subsequently allocates the final merged Vec with capacity equal to that appended Vec's length and wraps it Plain. A new admitted destination fixes that collector without pretending the Plan policy allocation itself was transferred or its source became free.

The successful-visit count is exactly:

    number of flattened spans matching existing is_silent_hold + policy.suppressed.len()

No envelope evaluation, offset conversion, inferred PCM silence, interval union, support clipping, or visitor replay belongs in this count. Duplicates count separately. The existing SilentHold offset helper permits a zero-length range and still emits it, whereas explicit policy ranges reject zero length. Therefore the count must include each actual matching SilentHold tag even when its range is empty. Do not replace it with a count of positive-width or merged intervals.

The existing final merged_suppression allocates with_capacity(raw_ranges.len()), including duplicate and adjacent inputs. An exact-capacity admitted destination followed by owned in-place merge preserves that final capacity and resulting union while removing the two ordinary suppression allocations from the active path. The earlier raw apply Vec's geometric temporary capacity is not an output contract; the design correctly retains its literal behavior only in the legacy path.

Lazy begin_ranges at the old first push position is appropriate. Earlier span-offset/envelope errors occur without destination admission if no suppression event was reached. A successful no-emission visit never needs account, Vec or Box storage. The funded builder owns its pending native Vec and its future Box charge without borrowing the controller/context, so it can remain live across creative fades. Physical Box construction and owned merge can stay at the existing final-mask boundary after fades and the caller's existing control.check.

The proposal retains the actual visitor once. Its current order is per-span check and offsets, SilentHold PCM zeroing or retained-envelope numeric work, exhaustion, validation of the entire explicit policy list, then explicit policy zeroing. Reusing those exact events and PCM operations preserves ordinary numerical bits and non-resource errors when native admission succeeds. Exhaustion remains a separate ordinary Vec and is truthfully outside the scope.

Root policy is AudioSample and its admitted Root policy constructor uses RoundEven. The proposed collector consumes already typed AudioSample event ranges directly; it has no reason to reconstruct grid geometry or convert through SignalSample/PointCeil. C's Point final-mask handoff must not be reused for this producer.

PreparedOriginalRequest remains live across read_queries_borrowed and is explicitly dropped only afterward. Its Plan policy, flattened/processing metadata and inventory guards therefore overlap the actual destination Vec/future-Box charge and final Box. Ordinary occurrence/beat inputs have no such admitted-source guarantee, but the proposed destination is still real native-owned storage and the design correctly calls out the ordinary source setup. No lease extraction, unmerge or refund is needed.

The real StageAudio mask context supplies WorkControl checks/spends and reserve_mask_storage. That reservation goes through the actual make_room policy and includes source sound_context_frames plus the atomic native account. Existing Owned unaccounted_capacity0 avoids counting this payload again in Original cache metadata. The new account can outlive the request/controller, and eviction can physically drop a cached owner through existing ownership paths.

## Implementation constraints and wording corrections

1. Describe the count as exact for a completed successful visitor. If a later envelope or policy validation fails, a first-event admission may already have funded that full-success count; it is not the number of events actually emitted before failure. Keep actual event/work prefixes separate from requested/funded capacity. This is honest preallocation, not over-claiming a partial result.

2. The tag prepass must check cancellation/deadline and bill one native Scan before inspecting each flattened tag. It must not validate ranges, evaluate envelopes, call providers, walk policy entries merely to recount their length, or bill canonical Plan work again. Checked addition of the actual two counts suffices. No hard-coded 256/1024/4096 destination guess and no added cap may replace that count.

3. Preserve old zeroing-before-push order. The builder allocation/Map refusal consequently can follow PCM zeroing for that event; the failed read discards its local PCM. Conversely, the newly billed prepass may refuse before an old earlier malformed span/envelope would have been validated. Resource-error prefixes are intentionally new and must be captured as such. Do not claim all error precedence is byte-for-byte unchanged. With adequate native resources, retain the exact existing non-resource validation/PCM/fade order.

4. Keep the source owners alive until finish and merge complete, including failed merge cleanup. Limit each mutable controller/context borrow to its operation; do not store Context in AppliedPending or release PreparedOriginalRequest early to lower the peak. begin_ranges already reserves both Vec and future Box; do not reserve the Box a second time at finish or reduce the charge before physical disposal.

5. Active pending storage must never be converted into a Plain Vec or copied through an ordinary temporary. finish the existing builder and call the existing Owned merge. Empty pending state returns the native default without allocating. An owned positive-capacity result may compact to fewer ranges, but capacity/charge remain funded. No shrink/refund or post-hoc provenance flag.

6. Keep both literal legacy operations: raw apply's Vec pushes and merged_suppression's sort/with_capacity/consuming merge. A new Root-only override must be independently selectable for immediate pre-unit C replay. Older compound legacy wrappers may chain it for their older bodies, but the new immediate baseline must leave C Point handoff active. Test-only hook files can exceed the two production files; do not silently broaden production scope to close the other deferred producers.

These are concrete implementation/proof constraints. They do not require a wider Plan API, additional public exposure, modified canonical weights, increased caps, or changes to existing account/lease ownership.

## Required evidence

Before production edits, preserve an actual fresh C-qualified baseline and current legacy outputs through parent-owned captures. Existing raw visitor tests are useful lower-level order tests, but their manually assembled spans are not substitutes for checked native producer cases.

Use bounded checked Root and physical-Domain cases covering SilentHold, explicit suppression, duplicate/adjacent SilentHold plus policy emissions, no emission, SelectedPlacement, retained envelope exhaustion, and fractional/negative/half-way geometry where RoundEven differs from PointCeil. Record actual output PCM bits, mask values/length/capacity, exhausted ranges, typed errors, accepted native work, account liveness and source ledger. Do not infer a mask from zero PCM.

A malformed policy list must still validate the entire list before the first explicit zeroing/push under sufficient resources. A failing retained envelope must still occur before later policy validation. Creative-fade failure must dispose a still-pending funded Vec without allocating the final Box. New preparation/merge resource refusals must retain their actual accepted prefixes and typed resource errors.

Pointer evidence has two separate purposes. For positive inputs, keep the source Plan policy Vec alive and show that the newly funded destination pointer is distinct. Then show the pending destination Vec pointer/length/capacity passes through builder finish and owned merge unchanged except for compacted length. This proves native destination ownership and no second merge Vec, not a zero-copy source handoff. Use pointer-equality assertions in tests rather than unstable address normalization in cross-root bodies.

A successful real Original path must show all admitted source metadata plus the new native destination charged at once. Use a fixed warmed cache state for exact-ceiling/one-below tests; do not search for the first success through mutating warmups. Exercise actual cache publish, hit/pin, and eviction/drop so Owned0 unaccounted-capacity behavior is checked on the new producer rather than on a fabricated ReadBlock.

Sweep every accepted prefix only for a small actual construction/merge case. Exercise cancellation/deadline before first emission, during construction, after fades/before finalization, and during merge. Verify no allocation/account on actual empty collection, pending/final payload cleanup on refusal, final query-ledger cleanup, and returned mask survival after request, controller and ReadWork drop.

New Scan/Map/AllocateVector/AllocateStorage/merge work remains native work. Existing query receipt totals and invalid flags stay literal, with current interval evidence used only at its real scope. No global residual attribution or canonical repricing is justified.

## Review limits

No implementation, compile, or runtime proof was performed. The proposal's allocation/order claims are supported by the source paths below. Callback-free Rust ownership and the existing builder destructor/account rules support the lifetime argument; exact native peaks, error prefixes and pointer assertions are still execution owed to the parent.

ProjectedRoot, Shared EQ bus, owner EQ, exhausted storage, PCM/dependency storage and whole preparation are deliberately outside this unit. This review does not award them policy ownership coverage.

## Pins

Every source entry in the author's source-pins.json was rehashed against its current file; all matched at review. The selected production dependencies also match between Main and Scope. The author's declared shared_eq.rs and beat_sounds.rs variant differences are outside the selected production seam.

| Review input | Bytes | SHA-256 |
| --- | ---: | --- |
| /tmp/deadpan-next-policy-producer-design-2026-10-31/design.md | 10975 | 5470d114c8b57ebe30de430211a030c8dfd3e8a6df56be3dad271606d668c050 |
| /tmp/deadpan-next-policy-producer-design-2026-10-31/source-pins.json | 13572 | eba4c9bd79f26748dd7acc6891001a4a5a41d111b6501c8b8471cad6cf330d78 |
| /tmp/deadpan-next-policy-producer-design-2026-10-31/ripwire.txt | 2752 | 9ed88e2670c20423b4d079e55ed5ab6c4182b0dad62615145809ff6996433f57 |

| Selected Scope source | Bytes | SHA-256 |
| --- | ---: | --- |
| /tmp/deadpan-query-groundwork-2026-10-26/scoped/crates/deadpan-audio/src/raw_policy.rs | 5341 | 39a19edbd0d79b78485057e3e22d6100146be786bf6b67c93214e2d92a2ae95f |
| /tmp/deadpan-query-groundwork-2026-10-26/scoped/crates/deadpan-audio/src/policy_ranges.rs | 1908 | 1612ad56d6497737ac61dbdcb5b607ea07975ca391ae19161f1ffc0fd3502b44 |
| /tmp/deadpan-query-groundwork-2026-10-26/scoped/crates/deadpan-audio/src/stages.rs | 167139 | 9908347a9191010843dac61a458452fc35adac2d657fa49e92cd31f6f73af9ef |
| /tmp/deadpan-query-groundwork-2026-10-26/scoped/crates/deadpan-audio/src/original_request.rs | 25134 | c3594d28d529175851c1101ed108d42091e76c963b57f6ca5544f2306263daef |
| /tmp/deadpan-query-groundwork-2026-10-26/scoped/crates/deadpan-audio/src/point_suppression.rs | 23733 | 050d5e7430d7b9cd9fcd21c29d84f5b08079b160e2c9a9c957271c97ed007958 |
| /tmp/deadpan-query-groundwork-2026-10-26/scoped/crates/deadpan-audio/src/point_suppression/ops.rs | 4820 | a26d85f167ecca23b53dd2d60e290fc9f2602ee045dcb9a83c25a8ded1385d70 |
| /tmp/deadpan-query-groundwork-2026-10-26/scoped/crates/deadpan-audio/src/point_suppression/mutations.rs | 13981 | ab2f3680984d319e5c35400d815bbbd8061710e4e0f8b957617641cfc5d4975b |
| /tmp/deadpan-query-groundwork-2026-10-26/scoped/crates/deadpan-audio/src/mask_context.rs | 2415 | ca66d52bd1489702745f1b26719846456ad51c8133d8d3090f76e490897b00b1 |
| /tmp/deadpan-query-groundwork-2026-10-26/scoped/crates/deadpan-audio/src/shared_eq/original_inputs.rs | 24272 | dc0caf01de2dd7d869a71e03319f59d1c39a622dbc5db64174016477a1cd77eb |
| /tmp/deadpan-query-groundwork-2026-10-26/scoped/crates/deadpan-plan/src/audio_policy_query.rs | 29864 | ae9363b8043665a45336c2e577b60d1d963c92a2ef2cd297f6adced3109a5d06 |
| /tmp/deadpan-query-groundwork-2026-10-26/scoped/crates/deadpan-plan/src/audio_domain.rs | 23720 | 16bfede5f9b3747da9200362ea95ef74df2719c322a061ed79461e1d5ad1c242 |
