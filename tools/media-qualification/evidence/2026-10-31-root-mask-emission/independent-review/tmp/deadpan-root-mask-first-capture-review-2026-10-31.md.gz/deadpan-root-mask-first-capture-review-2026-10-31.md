# First D capture/source audit

No material production or capture finding in this bounded first audit. This checks retained first captures and current source bytes only. Parent builds are active; this is not a claim that the final D library, matrix, guarded-query tests, cache tests, strict checks or publication have passed. No shared sources, immutable payloads, builds, native executables or Git were changed by this audit.

Evidence root: /tmp/deadpan-root-mask-emission-qualification-2026-10-31.

Independent audit code/results/pins: /tmp/deadpan-root-mask-first-capture-review-2026-10-31/{audit.py,audit-results.json,evidence-pins.json,audit.stdout}. Hashes were read in 1 MiB chunks. The audit independently asserts lengths, full values, source/binary/environment joins and interval equations rather than accepting first-capture-analysis.json as proof.

## Captures and guards

Main and Scope active captures independently reconstruct exactly 35,440,251 canonical bytes, SHA-256 596d738a53f6ef4cbf7870d74b3025504f6289f735ea91f4a38ed45c6661f44a.

Main has 2,925 named source inputs, manifest SHA 37f5f8cb76c871c8a43b9dc396a08399a5630dcbc890bd88dfa7072dcbcffbfe, retained binary SHA 1beccef1fb9fe774010cd4561ae8d3460524037934523006158d6139d9e3d8e0.

Scope has 2,597 named source inputs, manifest SHA 58dbf30a129d94af0e4f1111d635784fc17bfeabb96c9704c95d41468b440509, retained binary SHA d2bbdcdf17d570bfae6aafdfff3a139cfc199ab8e6402c7349370bd445ab064b.

All six active/before-policy/before-interval receipts have exit zero, unchanged before/after source and binary maps, matching stdout/stderr byte counts and hashes, the correct runner digest, exact ignored test invocation and single-thread options, correct output path/variant/source digest/checkpoint, and eight absent removed paths. Their retained executable bytes match the guards and compiler-artifact pins. The literal compiler-artifact records appear in the guarded build stdout and specify opt-level2, test mode, debug assertions and overflow checks.

Both before-policy canonical bodies reproduce the complete C authority: 35,440,148 bytes, SHA afa6038a02c959c7192c09c08a89266c7d52151a5e59a4f69828fbdf67e7414e. Both before-interval bodies reproduce 35,439,545 bytes, SHA f64d3a00a10967cc3822083d21705bd454f2d33ff2198da30e25671092ab5a53. The physical new Root baseline fixture in both roots is the literal C authority bytes. Canonical reconstruction removes only the four separately checked provenance fields: top-level variant/source_sha256 and the same two fields in native_requests. No output, capacity, error, account, receipt or invalid flag is normalized.

## Exact outputs and literal account changes

Case/operation cardinalities, fixture identities and operation metadata outside paired are checked independently. All 744 complete paired.new.read.output values match the C before-policy body: 264 Ok, 480 Error.

All ten internal and four public transfer case names/cardinalities match. All 42 complete result_* fields match, including the recorded post-work/provider/controller disposal values.

There are exactly eight changed account_* fields. They are four fields each in internal cases4/5, aggregate-514-shared-equalizers and aggregate-514-shared-input:

- account_after_controller_drop_internal_result_alive.
- account_after_internal_result_drop.
- account_after_local_work_drop.
- account_after_public_held_result_drop.

Each changes literally from unavailable None to Some with live_frames3. Every other account field remains equal. Neither unavailable readings nor the new shell readings were converted to a fabricated zero.

For each of these two aggregate cases, the actual whole-case native receipt records one initialized shell with three frames, three payload reservations totaling 1,043 accepted payload frames, three vector allocation units and three storage allocation units. Cache-lane counters remain zero and overflow is false. The 1,043 is cumulative accepted reservation frames across three allocations, not a measured simultaneous peak. The eventual three-frame reading is the remaining live shell; these observations do not claim that the final independently derived aggregate mask became owned.

## Interval reconciliation

Independent traversal finds 758 interval snapshots, 478 rows, 477 completed and one partial. Active/dropped intervals are zero and every snapshot has no misnesting/overflow. Every row is attributable without foreign work overlap; native recording is enabled, reset epochs match and boundary overflow is false.

Every completed claim has canonical + additional = total = expected_debit, forwarded true and ordinary false. For each lane independently:

observed ReadWork delta = selected-lane claim debit + sum of eight native phase deltas + host-eviction delta.

Every delta is nonnegative and each equation is exact. The sole lower-quota Point-content partial retains claim:null, delta [6,0] and its literal accepted residency prefix. No completed query debit is inferred from its remainder. No inclusive rows or whole-case receipts were summed into a synthetic Root-query fee. These particular rows have depth1 and add no nested-interval runtime coverage.

## Source and production checks

All 2,909 Main and 2,581 Scope unowned initial named inputs are still byte exact. Every named addition or changed initial input belongs to the declared owned paths. The before copies of existing owned files match across Main/Scope, and current owned files also match across Main/Scope; there is no owned-file inherited variant difference to overwrite. All immutable oracle pins remain exact.

The first capture manifests predate later test work. Each current root now has eight changed existing test/helper files and two newly named test files relative to its first-capture manifest. They are recorded in audit-results.json and all belong to the declared owned set. The added files are guarded_query_tests.rs and original_inputs_root_mask_tests.rs. raw_policy.rs and stages.rs remain byte exact to the first capture manifest. The first binaries therefore do not qualify the newly integrated test/helper changes; the parent must use the later builds and final capture/source joins for that.

The earlier producer review's missing-old-raw-policy limitation is now resolved: the exact pre-D file exists at before/scoped/crates/deadpan-audio/src/raw_policy.rs, 5,341 bytes, SHA39a19edbd0d79b78485057e3e22d6100146be786bf6b67c93214e2d92a2ae95f. Its complete literal apply, visit and span_offsets function text matches the retained compatibility/shared functions in current source in both roots. The old merged_suppression and is_silent_hold bodies also match. Default StageLimits are literal, with no cap raise.

The active producer counts every SilentHold tag plus explicit-policy length, including empty and duplicate emissions. It bills Scan before inspecting each tag and does no policy-range or envelope validation in that pass. At the original event push position, unchanged PCM zeroing precedes lazy begin_ranges and its funded Map push. The pending builder owns the real Vec/future-Box reservation without retaining a context borrow.

read_queries_borrowed retains its one visitor, creative fades and existing final check, then finishes the actual Box and uses owned in-place merge. Existing source metadata remains borrowed through that tail. read_prepared_original explicitly drops its owning request only after read_queries_borrowed returns, so the admitted source guard is not retired to reduce the destination overlap. The later guarded-query tests are intended to measure this directly, but their success is not asserted here.

The existing owned merge sorts by start and uses the old join/max-end rule without filtering empty ranges. A valid empty SilentHold emission therefore retains the same old semantics and funded event-count capacity. Reversed raw spans are rejected before emission. The existing funded builder cap check prevents growth; no detach, mask clone, second owned merge Vec, lease extraction, refund, relabeling or Plan canonical-weight change is introduced.

The prepass adds real resource-error boundaries before old validation, and allocation/Map refusal can follow an event's original zeroing. Under sufficient resources, the literal shared visitor preserves its old non-resource order. The first output comparisons support the exercised cases; they do not justify a blanket claim that every new resource prefix is unchanged.

## Scope

The new active-root-mask-after-v1 schema names Root checkpoint44068bd971dee62e2ed8cbaffbb2f18922283f83 and separately names the exact C before authority. C Point policy stays active. The before-policy capture selects only the D Root override, leaving C active; the earlier compatibility chain still reproduces the literal T body.

Root output suppression Vec/future/final Box/owned merge is the D claim. Projected-provider policy, independently derived bus/equalizer masks, exhausted vectors, PCM/dependencies and whole preparation remain outside it. Whole-case native work and constructor intervals are distinct evidence.

Final tests, source guards, repeated final captures, hygiene, documentation and publication remain parent-owned and are not certified by this first audit. No product requirement, Gate acceptance or whole-preparation credit changes.
