# D producer runtime review

Scope: current /Users/michael/Code/deadpan production stages.rs, raw_policy.rs, point_suppression.rs, and point_suppression/ops.rs; compared the pre-D read_queries_borrowed tail in /tmp/deadpan-internal-suppression-runtime-2026-10-31/before/scoped/.../stages.rs. Read only; no build/runtime/Git.

Pins:
- current stages.rs: 059eff2e7ca29c2ae9e4894c4a6e1eb21086ffa9c0151fb06325f0a85d571e4b
- current raw_policy.rs: 9988e24cfc0ee472c568610e7b334555a4f31c503ae3230d22ec6357286fe590
- current point_suppression.rs: 050d5e7430d7b9cd9fcd21c29d84f5b08079b160e2c9a9c957271c97ed007958
- current point_suppression/ops.rs: 69ae0914fdb9e3fa814c346b5bae63568f2802677cf5f48ac65da99d326ce440
- pre-D stages.rs: a7e0a3425282392062b4ff3e00c76314df158a422f441cae70687d97af435bf6

## Findings

No actionable production correctness/resource-accounting issue found in the requested paths.

- The new sizing pass in raw_policy::suppression_capacity adds exactly one Scan Plan-work debit for every flattened span, including spans that do not emit suppression. It checks cancellation/deadline per span, and uses checked addition for every SilentHold emission. This is an explicit extra O(flattened spans) debit before the final visitor (raw_policy.rs:183-197); it can reject a near-budget request earlier than the old single-visitor path. The debit corresponds to the new exact-capacity count and is recorded, not hidden. Existing output boundary tests should treat the whole request as the budgeted operation.
- Capacity is policy.suppressed.len() plus one slot per SilentHold, not the count of unique/merged ranges (raw_policy.rs:189-196). The visitor pushes one range per emitted event, including duplicates; builder enforces len < capacity (raw_policy.rs:229-237, ops.rs:110-125). Merge happens afterward in-place on the owned allocation (PendingSuppression::finish, raw_policy.rs:169-180; mutations.rs:320-355). Thus duplicates are not underfunded. Empty explicit policy intervals fail the existing strict offset validation (policy_ranges.rs:18-31); empty SilentHold events are permitted by span_offsets (raw_policy.rs:89-109) and are included in the capacity count.
- Account creation is lazy: sizing only checks/spends; suppressed remains None until the first suppression event, and begin_ranges is then the first reservation (raw_policy.rs:218-237). begin_ranges returns an uncharged empty builder for capacity zero (ops.rs:147-154). A no-event request can spend scan work but does not initialize the mask account or reserve a mask payload.
- Event order remains flattened spans first, then complete explicit-policy range validation/emission. Retained envelope application precedes exhaustion emission; all explicit intervals are validated before the first explicit Suppressed event (raw_policy.rs:49-85, comments at 28-40). This matches the old tail's call position after PCM assembly and its sequence of raw policy application, fade application, final control check, and block construction (before/scoped/stages.rs:2112-2127). D retains that sequence at stages.rs:2035-2057; fade failure, final cancellation/deadline, or merge work failure drops local samples/pending ownership before any ReadBlock is returned.
- The account-backed reservation uses make_room_for, which includes existing cached/active/projected/sound-context frames plus current account residency and requested frames before accepting (stages.rs:2529-2587). This is the actual request-level admission condition; the boundary candidate correctly labels its measured cap as whole-request pressure, not isolated Root-mask cost.

## Comparison limitation

The pre-D archive contains stages.rs but not the referenced sibling raw_policy.rs (mod raw_policy appears at before/scoped/stages.rs:40-41). Therefore the old final-mask visitor implementation itself was not source-pinned in this comparison; the old caller ordering and ownership return shape were available. The current D review is source-pinned, but claims about the literal old visitor's internal empty/duplicate semantics rely on the already completed D review and current shared policy_ranges/merge helpers, not on a recoverable archived visitor body.
