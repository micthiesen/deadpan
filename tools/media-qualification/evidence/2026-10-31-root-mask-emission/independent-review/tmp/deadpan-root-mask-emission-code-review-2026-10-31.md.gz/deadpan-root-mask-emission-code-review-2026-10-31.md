# D raw Root mask emission candidate: static review

Verdict: GO for parent integration and qualification. No material correctness finding in the reviewed candidate. This is a static review only. No roots, builds, native executables, Rust compiler, Git, fixtures or capture bodies were changed. C publication/qualification remains parent-owned.

Reviewed candidate.patch, optional-tests.patch, README.md, before/new source trees, source-pins.json and candidate-pins.json against the current native context/builder/merge code. All 26 source pins and all 12 candidate pins matched their actual bytes. The three before production/hook files also match current Scope. The complete original apply function text compares unchanged.

## Concrete production assessment

The prepass suppression_capacity reads the actual policy list length and checks/debits Scan before inspecting each actual flattened content tag. It increments only for the same existing is_silent_hold predicate used by visit. It neither validates policy entries nor evaluates span geometry, envelopes, exhaustion, fades or providers. It counts matching empty SilentHold spans and duplicates. This is the exact destination capacity for a completed successful visit; after an error it is a full-success capacity bound, not an asserted emitted prefix.

The old apply visitor emits exactly one range for each matching SilentHold and each explicit Suppressed event. The new match combines only those two event variants; each retains PCM fill before native admission/push. RetainedEnvelope and Exhausted retain their literal bodies. visit itself and policy_ranges::visit are unchanged, including the whole explicit-list validation before the first explicit-policy event. Later invalid policy therefore cannot newly zero an earlier explicit-policy region, while already visited SilentHold zeroing remains visible in the failed local PCM as before.

The first begin_ranges call occurs at the old first push position, after the corresponding zero fill. It reserves through the real StageAudio context and existing controller make_room/account before creating the destination Vec. It requests the actual computed capacity, and push cannot grow it. There is no ordinary suppression Vec, borrowed clone, second visitor, inferred-silence mask or source-lease extraction on the active path. The separate exhausted Vec is unchanged and remains ordinary.

PendingSuppression::Owned stores only Option<RangeBuilder<AudioSample>>. The builder stores actual pending Storage whose Vec precedes its Charge in drop order. Its type retains no controller or WorkControl borrow. The temporary context borrow in apply_owned ends at that call, so the pending Vec plus its full future-Box reservation remain alive across creative fades and the existing caller control.check. An error before finalization drops that pending Vec before its charge without constructing the Box.

At the original final-mask boundary, finish consumes the same builder, constructs its already-funded Box, and invokes the existing Owned in-place merge. That merge does not detach the Vec or allocate a replacement; it retains actual capacity while sorting/compacting length. A failed finish or merge disposes the owning payload with existing native accounting. No early source-query drop or charge refund was added. PreparedOriginalRequest still encloses the whole read and drops after read_queries_borrowed returns.

The legacy final mask capacity is raw event count because merged_suppression allocates with_capacity(ranges.len()), rather than using the raw temporary Vec's geometric capacity. Exact-capacity collection therefore preserves successful final output capacity, including duplicates. Both old and owned merge keep standalone empty ranges and use the same adjacency/overlap predicate and max-end update. No merge filtering/normalization was inserted.

All newly emitted values are actual AudioSample ranges, and the destination is RangeBuilder<AudioSample>. No PointCeil conversion, SignalSample reinterpretation or new arithmetic changes Root/Domain RoundEven geometry. No caps, canonical weights, Plan API or shared account representation changed.

The existing real reserve_mask_storage path includes live source sound_context_frames and the native account during make_room. The new Vec is separately funded while source metadata stays alive. Ordinary occurrence/beat source setup is still ordinary; the candidate does not claim otherwise. Existing cache unaccounted_capacity0 for Owned avoids charging this same payload again.

## Error and compatibility boundaries

The billed tag scan adds resource refusal points before old span/envelope validation. Allocation and Map refusal can occur after the corresponding PCM zero fill. The README correctly discloses both facts instead of promising identical resource-error precedence. Under adequate resources the non-resource visitor, PCM and fade operation order is preserved.

Owned(None).finish returns the allocation-free default. In the production caller it is preceded by the unchanged post-fade control.check. A genuinely no-emission collector avoids account/Vec/Box allocation; it may still pay Scan for non-silent flattened tags. The optional empty test has no tags and correctly expects zero work, but is not evidence that every no-emission query has zero work.

The old Applied/apply implementation is cfg(test), with its complete function body unchanged. Legacy PendingSuppression invokes the unchanged merged_suppression body. The D-only with_legacy_root_masks switch is independent of point_policy_request::legacy, so the immediately pre-D C body can retain C Point handoff. The older point-policy wrapper chains Root legacy, which is appropriate for older complete-body replay. Both flags use thread-local restoration guards, including unwind restoration. Existing internal/public compound wrappers continue reaching the older Point wrapper.

No production visibility or capability was widened merely to inspect a pointer.

## Optional tests and remaining evidence

The four optional tests use manually assembled raw adapter spans with a real StageAudio account/context. They do not claim checked Root factory, provider, admitted source-guard, cache, numerical resampler or RoundEven-geometry coverage. Their assertions match current interfaces and trace schema on static inspection.

They meaningfully cover empty/duplicate emitted tags, exact final legacy capacity/union/PCM parity, finalized-pointer stability across owned merge, lower-level output lifetime after controller/ReadWork, true empty collection, later invalid explicit-policy ordering and pending cleanup before Box allocation, and independent legacy switches.

The README correctly notes that these tests observe the finalized pointer before merge, not the pending pre-Box Vec pointer. The unchanged Vec inside moved Storage supports the static no-copy argument; a separate runtime observer or ops-descendant test is still owed if the qualification claims direct pending-to-final pointer evidence.

Other execution still owed to the parent:

- Compile both variants and run the four optional tests, existing tests and all immutable legacy replays.
- Freeze the fresh C-qualified pre-D bodies before production edits.
- Use actual checked Root and physical-Domain reads, including fractional/negative/tie geometry, SilentHold/policy duplicates, SelectedPlacement, envelope/exhaustion and creative-fade failures.
- Observe complete admitted source guards overlapping the real native destination. For positive input show destination distinct from the still-live policy Vec, then retain output beyond query/request/controller/ReadWork.
- Sweep accepted construction/merge prefixes only on a bounded small case, plus cancellation/deadline and fixed warmed exact-cap/one-below cases.
- Exercise real Original cache publish, hit/pin and eviction/drop. Do not infer cache admission from fabricated ReadBlock payloads or a first-success search through mutating warmups.
- Preserve actual query receipt fields/invalid flags and explain native work only from real scoped receipts, without residual attribution or canonical repricing.

No runtime success, measured peak or new before oracle is awarded by this review. Exhausted, PCM/dependency storage, ProjectedRoot and derived bus/owner EQ products remain outside this bounded producer.

## Pins and checks

Verification was read-only hashing/text comparison. No build or patch application was performed.

| Candidate input | Bytes | SHA-256 |
| --- | ---: | --- |
| /tmp/deadpan-root-mask-emission-candidate-2026-10-31/candidate.patch | 6514 | cfc8cfa0df3acb1f7eb0913514c418475a2ba5e94396cd4b194c9c3f48bddd80 |
| /tmp/deadpan-root-mask-emission-candidate-2026-10-31/optional-tests.patch | 8513 | 21ba60e416a4d59a2817ce5104c7dfebf756d7ae70e867b552cecfcd732b4adc |
| /tmp/deadpan-root-mask-emission-candidate-2026-10-31/README.md | 8061 | 82230e0b2b8621ae85d3c72d90aa32576ff2a1d8633291ffc7908d0c0b05e0e5 |
| /tmp/deadpan-root-mask-emission-candidate-2026-10-31/source-pins.json | 5129 | 17df12f7f184ca8564e2d51114bef01d0acc3c5a21f166ae5ebe283be60c96c2 |
| /tmp/deadpan-root-mask-emission-candidate-2026-10-31/candidate-pins.json | 1701 | 3875d91126ac50d05fd1dd069bdcb9e163752ea2180d8d8835e14a9d75cd9b3c |
| /tmp/deadpan-root-mask-emission-candidate-2026-10-31/new/crates/deadpan-audio/src/raw_policy.rs | 8534 | c208c5bbc26a9cda2ebd30596cd6d05d759ee165e23a74f868f2be3d03769fd1 |
| /tmp/deadpan-root-mask-emission-candidate-2026-10-31/new/crates/deadpan-audio/src/stages.rs | 167325 | 059eff2e7ca29c2ae9e4894c4a6e1eb21086ffa9c0151fb06325f0a85d571e4b |
| /tmp/deadpan-root-mask-emission-candidate-2026-10-31/new/crates/deadpan-audio/src/point_policy_request.rs | 608 | 7136a3722391d8472277fc3188bef70dea6b122abbaf69b99f26babb6b2648f9 |
| /tmp/deadpan-root-mask-emission-candidate-2026-10-31/new/crates/deadpan-audio/src/root_mask_request.rs | 561 | e34f11bf8d1c7e27853e26dbc3cf968c4a298c1cc3bdea59866bb4bb14b9c1f1 |
| /tmp/deadpan-root-mask-emission-candidate-2026-10-31/new/crates/deadpan-audio/src/raw_policy/owned_tests.rs | 7997 | 9212c8ecff0eea37531cf5806e63d257033d06e3b269c13fb74b7881e2b5fb9c |
