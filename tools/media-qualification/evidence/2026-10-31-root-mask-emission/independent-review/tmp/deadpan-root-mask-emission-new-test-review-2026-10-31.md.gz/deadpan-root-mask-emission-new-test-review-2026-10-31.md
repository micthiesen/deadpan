# D new test coverage review

Static review of integrated Main tests and the five failure-fix patches, with no edits, builds, native execution or Git. Parent owns runtime qualification and active builds. This note does not award passing runtime results.

Verdict: the new tests provide meaningful checked-path and real-account evidence. The initial assertion/coverage issues and the parent-owned follow-up corrections are described below. Runtime qualification remains pending. The five historical test fixes preserve their intended authority.

## Findings and status

### 1. Whole-read prefix sweep permits too narrow an error type

In shared_eq/original_inputs_root_mask_tests.rs, actual_root_work_prefixes_refuse_without_retaining_partial_mask_storage accepts only StageAudioError::Limit(_) for every insufficient whole-read allowance.

This sweep includes Plan metadata construction, not only native mask operations. WorkControl::query_limits reduces maximum_work to actual global remaining units. QueryBudget::canonical/additional calls local.spend before Admission::spend, so local exhaustion can legitimately return StageAudioError::Plan(PlanError::AudioQueryLimit(_)) before the host callback. Existing constructor-prefix tests accept that distinct error.

The test should preserve actual Plan-local versus native/global resource errors, allowing those exact two documented error families rather than changing budgets, weights or caps. Adding a real sound_context_frames==0 assertion on every failed whole-read prefix would also check source-carrier cleanup explicitly, alongside its existing native shell-only cleanup assertion.

Status: subsequently reproduced by parent runtime and corrected in source to accept the exact Plan-local and native/global families. Parent owns the failing/passing receipts. This is an assertion restriction, not a production admission defect.

### 2. Measured held-mask minimum recovery currently uses a non-discriminating ceiling

held_root_mask_changes_measured_whole_request_resident_minimum_and_recovers measures a genuine whole-request threshold using a fresh fixture/controller/default warmup for every attempt. It confirms held-state minimum success and one-below refusal. This avoids mutating-cache first-success probing.

Its final recovery read originally stayed at the measured minimum, where a read already succeeded while the first output remained held. It therefore demonstrated cleanup/successful reuse, but did not itself demonstrate that releasing the held payload lowers the threshold or recovers a refused request.

Parent agreed to keep the existing success checks, set the SAME controller to minimum-1 with the held output still live, require the real Limit refusal and unchanged account, then drop the held output and retry successfully at that SAME cap. Runtime verification is still owed. This adds a discriminating resource assertion without changing a production ceiling.

Scope must remain explicit: guarded-query tests prove an isolated destination threshold after source metadata admission; this test measures a complete public held-state request threshold. Neither is a universal minimum for all reads.

### 3. C-selection claim needs a specific witness

root_legacy_replay_leaves_c_point_policy_active currently checks that a public Point output remains Owned inside a Root-only override. That is genuine public output behavior, but pre-C/B public Point paths also produced owned masks. Ownership alone does not distinguish the C final-mask handoff lane.

A direct !point_policy_request::legacy() assertion inside the Root-only override, or C-specific handoff receipts, supplies the missing selection witness. Parent has now added the direct flag assertion. The optional raw owned_tests already asserts the two flags independently. Existing C custody tests supply the separate zero-copy handoff proof.

Status: nonblocking coverage clarification reported to parent. It does not indicate that the current Root switch actually disables C.

### Corrected compile issue

The first inspected public-prefix test used StageAudioError::Cancelled, which does not exist. Parent's build2 caught the same E0599 in both variants; parent replaced it with Err(error) if error.is_cancelled() and started build3. The corrected assertion matches the real nested cancellation representation. No source change was made by this reviewer.

## Guarded-query test assessment

The corrected raw_policy/guarded_query_tests.rs constructs a checked public Sequence root containing a 64-frame SilentHold child, recompiles a real RenderPlan and obtains an actual PreparedOriginalRequest. The first version incorrectly installed Hold directly as the project root and failed document validation; parent runtime exposed that fixture error and the parent corrected it to Sequence+quiet. It never fabricates a query lease or a private Point/Bound. Its policy slice is independently asserted to contain [0,64), and exactly one flattened SilentHold tag is asserted. Thus expected emission capacity 2 has concrete input witnesses rather than an arbitrary cap.

The helper calculates a post-source destination ceiling only after asserting cached/active/projected/native residency are zero and reading the actual admitted source ledger. Lowering the controller ceiling after source preparation intentionally isolates destination admission. The exact-cap success and one-below Limit refusal exercise real reserve_mask_storage/make_room and actual accepted reservations; they are not mere equality tests of an arithmetic helper. They make no claim that the same cap can construct the whole public request from cold state.

The positive test observes source policy pointer/capacity and whole-query ledger remaining live. The newly funded destination pointer is distinct while both nonempty buffers live, and builder pointer/capacity passes through physical Box finish and Owned merge unchanged. Exact mask values/compacted length and unchanged funded capacity are asserted. Actual native trace reservations/vector/storage counts and account frames support the overlap claim. Returning mask lifetime is checked after request, controller and ReadWork disposal, and dropping it leaves only the observer's shell.

These tests use manually initialized PCM for the final adapter, so they are checked metadata/native collector tests rather than full numerical source reads. Their leading comment correctly says so.

The pending cancellation/expiry test first creates a real funded destination, then refuses finish before storage work. It checks that pending payload disappears while the original source guard/pointer/ledger remain live, followed by source cleanup. This is real cancellation/deadline after pending construction and before finish. It does not exercise a native creative-fade error, interruption during fades, or a public read cancellation callback at that exact boundary. No such coverage should be claimed.

## Public read and cache test assessment

quiet_root reparses a public checked SilentHold document based on the qualified native fixture helper. The Root and physical-Domain tests invoke actual public APIs, compare ordinary C-lane versus D output ranges/capacity and samples, then retain the real Owned output after provider/controller disposal. The pure SilentHold path legitimately has no provider calls; it should not be described as decoding WAV.

The explicit samples equality checks use f32 PartialEq, so they do not alone discriminate signed-zero changes. The root_bits snapshot checks lifetime/content stability across owner destruction, not an independent old/new bit oracle. Complete D replay remains the bit-exact regression authority. If claiming these particular tests as direct bit parity, compare old/new f32::to_bits too. This is a limited test scope, not a discovered numerical difference.

The warm Original test does invoke the genuine WAV-backed cache path. It retains a real positive Root mask, warms an actual cached Original, captures the Arc identity and keys, then applies an explicit additional reservation. The held state refuses prediction before new source calls and preserves keys; after the owner drops, the same fixed ceiling admits the same Arc and performs fresh source checking. This is a discriminating real cache-residency/lifetime test, not a fabricated block or counter.

The prefix sweep creates actual checked reads and checks native payload cleanup for failed attempts. Its trace measures native work independently from total accepted work. The sweep must retain the distinction between early Plan constructor failures and later native failures as described above. Preloaded prior budget is existing test-state injection, not a production budget increase/refund.

## Five historical failure-fix patches

All five integrated files exactly matched the supplied candidate copies at review:

- The three constructor/issuer tests select only D Root legacy, retaining exact old success/one-short allowances and their original callbacks, receipts and cleanup assertions.
- cached_prediction wraps the entire immutable historical comparison in D Root legacy. Frozen equality, independent query witness, all non-work comparisons and phase reconciliation remain literal. This historical test no longer claims default D account/cache coverage; the new cache tests and complete active capture are its replacement authority for that representation.
- cached_policy keeps D active, asserts a real positive Owned mask and drops it by installing the default before its deliberate private corruption. It preserves actual owner support and allowed-bit assertions without adding a detach API or suppressing D.

No frozen oracle, comparison normalization, canonical fee, cap or production account was changed by those fixes.

## Pins

The following are Main bytes inspected after the parent's cancellation-variant correction and before any promised recovery adjustment. Hashes identify the precise reviewed revision; follow-up edits require a new comparison. No test run was performed.

| Source | Bytes | SHA-256 |
| --- | ---: | --- |
| /Users/michael/Code/deadpan/crates/deadpan-audio/src/raw_policy/guarded_query_tests.rs | 12988 | b9ec4b7b79aede137f45978130f50ef2d82f1850658a7118ec513adf843df7ba |
| /Users/michael/Code/deadpan/crates/deadpan-audio/src/shared_eq/original_inputs_root_mask_tests.rs | 17354 | a2617d5405edf5dc9b78124b462d3b551d9257c6e51767ffc9f18eb4a89526f1 |
| /Users/michael/Code/deadpan/crates/deadpan-audio/src/original_request/tests.rs | 31038 | cc42a3b03244db91113da086f9f5348501c0b3701cb337ac32e1111fca91d1c0 |
| /Users/michael/Code/deadpan/crates/deadpan-audio/src/original_request/fade_admission_tests.rs | 22428 | a4b71ef84d2553358254b2c70ae42cf68cf4d58a37575822d820dba2cbdda2ae |
| /Users/michael/Code/deadpan/crates/deadpan-audio/src/original_request/processing_admission_tests.rs | 16375 | b4a19b6540ab5428625056b79ec37c21932968cde448c717d9d468b6d6c97a2a |
| /Users/michael/Code/deadpan/crates/deadpan-audio/src/shared_eq/cached_prediction_tests.rs | 6524 | 12e5296960563800dc3fd149e75416904d317eb3f2f6da842aa1d9838ac13e37 |
| /Users/michael/Code/deadpan/crates/deadpan-audio/src/shared_eq/cached_policy_tests.rs | 14836 | 45bd08afda2a92e3a44ae2b98bf190bdae2abc58e3d236cfa20ad44764fa5e4d |
| /Users/michael/Code/deadpan/crates/deadpan-audio/src/stages.rs | 167325 | 059eff2e7ca29c2ae9e4894c4a6e1eb21086ffa9c0151fb06325f0a85d571e4b |
| /Users/michael/Code/deadpan/crates/deadpan-audio/src/raw_policy.rs | 8518 | 9988e24cfc0ee472c568610e7b334555a4f31c503ae3230d22ec6357286fe590 |
| /Users/michael/Code/deadpan/crates/deadpan-audio/src/mask_context.rs | 2415 | ca66d52bd1489702745f1b26719846456ad51c8133d8d3090f76e490897b00b1 |
| /Users/michael/Code/deadpan/crates/deadpan-audio/src/point_suppression/ops.rs | 4996 | 69ae0914fdb9e3fa814c346b5bae63568f2802677cf5f48ac65da99d326ce440 |
| /Users/michael/Code/deadpan/crates/deadpan-audio/src/shared_eq/original_inputs.rs | 24272 | dc0caf01de2dd7d869a71e03319f59d1c39a622dbc5db64174016477a1cd77eb |
| /Users/michael/Code/deadpan/crates/deadpan-plan/src/audio_owner_query_admission.rs | 22077 | 9f52395699a7cdd95b0c1329d0d7ee1b12459b2b2fd0c27a4fc53f952910c150 |

## Follow-up: parent runtime findings and resource-capacity interpretation

After the initial static note, parent runtime reproduced the early Plan-local prefix failure and the invalid Hold-root fixture. Parent corrected the fixture to a public Sequence root with quiet child, corrected prefix error matching, added the explicit C flag witness, and implemented the discriminating same-controller minimum-1 held refusal followed by released-owner success at that same ceiling. Those source changes were inspected read-only. Their actual passing execution remains parent-owned.

Parent's intermediate diagnostic formatting of result with Debug requires ReadBlock: Debug and caused E0277. Parent reported the intended diagnostic-only correction to format result.as_ref().err(). This note awards no compile pass and makes no production type change recommendation.

The public physical-Domain test also exposed a genuine final capacity difference: old Domain mask length1/capacity1, D mask length1/capacity2, with equal values/PCM. The Root path retains old capacity2/current2.

This is explained by the actual read_domain tail. It appends exhausted ranges, then calls merge again on the result returned by read_domain_controlled. Legacy Plain merge allocates a new Vec with capacity equal to its already compacted length1. D's Owned merge operates in place on its funded event-count allocation of capacity2. It preserves the existing unique owner and charge. No range or PCM semantic difference follows from that second merge.

That capacity is public/resource-observable, so a blanket capacity-parity claim is false beyond the selected Root collector boundary. It must be disclosed as a concrete new case, even though the existing complete 744 observations and 14 result payloads remain exact in the parent's capture. The corrected test explicitly asserts old capacity1 and current capacity2 and checks the full retained capacity2 native charge/lifetime. It does not normalize the difference or rewrite an old oracle.

No production shrink/copy is warranted merely to reproduce old capacity1. That would introduce a new allocation and source/destination overlap, undo the in-place retained-capacity contract, and require fresh admission/work instead of pretending the smaller capacity is free. Retaining charged capacity2 is the correct result under the agreed new ownership rules. The precise statement is that the Root collector keeps its old final event-count capacity; downstream public re-merges can retain that allocation where old Plain processing allocated a shorter one.

Current follow-up source pins below supersede the earlier table for the two edited test files only. Production files were not changed by this review or by those test corrections.

| Follow-up source | Bytes | SHA-256 |
| --- | ---: | --- |
| /Users/michael/Code/deadpan/crates/deadpan-audio/src/raw_policy/guarded_query_tests.rs | 12988 | b9ec4b7b79aede137f45978130f50ef2d82f1850658a7118ec513adf843df7ba |
| /Users/michael/Code/deadpan/crates/deadpan-audio/src/shared_eq/original_inputs_root_mask_tests.rs | 17386 | be726c0131f48f60015579ffe33ede46057bac0939f72bfe69153d70590072c1 |
