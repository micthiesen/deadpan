from pathlib import Path
import gzip,hashlib,json
s=Path(__file__).resolve().parent
root=Path('/Users/michael/Code/deadpan');scope=Path('/tmp/deadpan-query-groundwork-2026-10-26/scoped')
out=root/'tools/media-qualification/evidence/2026-10-31-root-mask-emission'
assert not out.exists()
allowed={'.json','.md','.txt','.py','.patch','.rs','.stdout','.stderr'}
excluded={'archive-proof.json','qualification-draft.md','publication-proof.json','index-publication-audit.json','publication-inputs.json','publication-sources.txt','publication-index-info.txt','publication-blobs.txt'}
files={}
for p in sorted(s.rglob('*')):
 if not p.is_file()or p.suffix not in allowed or '__pycache__'in p.parts:continue
 rel=p.relative_to(s)
 if rel.parts[:2]==('before','main')or p.name in excluded or 'ripwire'in p.name:continue
 files['qualification/'+str(rel)]=p.read_bytes()
for name in [
 '/tmp/deadpan-next-policy-producer-design-2026-10-31/design.md',
 '/tmp/deadpan-next-policy-producer-review-2026-10-31.md',
 '/tmp/deadpan-root-mask-emission-code-review-2026-10-31.md',
 '/tmp/deadpan-root-D-producer-review-2026-10-31.md',
 '/tmp/deadpan-root-mask-emission-new-test-review-2026-10-31.md',
 '/tmp/deadpan-root-mask-first-capture-review-2026-10-31.md',
 '/tmp/deadpan-root-mask-final-capture-review-2026-10-31.md']:
 p=Path(name);assert p.exists(),p
 files['independent-review/'+p.parent.name+'/'+p.name]=p.read_bytes()
for directory in [
 '/tmp/deadpan-root-mask-emission-candidate-2026-10-31',
 '/tmp/deadpan-root-mask-native-tests-candidate-2026-10-31',
 '/tmp/deadpan-root-mask-guarded-query-tests-candidate-2026-10-31',
 '/tmp/deadpan-root-mask-library-failure-fixes-candidate-2026-10-31',
 '/tmp/deadpan-root-mask-sound-events-fixes-candidate-2026-10-31',
 '/tmp/deadpan-root-mask-first-capture-review-2026-10-31',
 '/tmp/deadpan-root-mask-final-capture-review-2026-10-31']:
 d=Path(directory);assert d.exists(),d
 for p in sorted(d.rglob('*')):
  if p.is_file()and p.suffix in allowed and 'ripwire'not in p.name:
   rel=p.relative_to(d)
   if rel.parts[:2]==('before','main'):continue
   files['proposal-and-audit/'+d.name+'/'+str(rel)]=p.read_bytes()
for name in ['/tmp/deadpan-next-mask-producer-design-2026-10-31.md','/tmp/deadpan-next-mask-producer-review-2026-10-31.md']:
 p=Path(name);assert p.exists()
 files['next-design-only/'+p.name]=p.read_bytes()
for rel in json.loads((s/'owned-code-paths.json').read_text()):
 files['shipping-source/'+rel]=(scope/rel).read_bytes()
rows=[]
for key,data in sorted(files.items()):
 zipped=gzip.compress(data,compresslevel=9,mtime=0);dest=out/(key+'.gz')
 dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(zipped);assert gzip.decompress(dest.read_bytes())==data
 rows.append({'path':key,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest(),'stored_path':key+'.gz','stored_bytes':len(zipped),'stored_sha256':hashlib.sha256(zipped).hexdigest()})
body={'schema':'deadpan-qualified-gzip-evidence-v1','scope':'native Root/physical-Domain AudioSample suppression destination admission and retained capacity; 32 immutable before payloads, actual checked query overlap and native public/cache/failure tests, complete 744+10+4 captures; concrete extra Domain capacity1-to2 retention disclosed; no whole preparation or new product acceptance','base_revision':(s/'base-revision.txt').read_text().strip(),'records':rows,'expanded_bytes':sum(r['bytes']for r in rows),'stored_bytes':sum(r['stored_bytes']for r in rows),'excluded':'pinned executable copies; full Main before snapshots and broad Main ripwire maps containing possible inherited WIP.'}
data=(json.dumps(body,indent=2)+'\n').encode();(out/'inventory.json').write_bytes(data)
proof={'inventory_path':str((out/'inventory.json').relative_to(root)),'inventory_sha256':hashlib.sha256(data).hexdigest(),'records':len(rows),'expanded_bytes':body['expanded_bytes'],'stored_bytes':body['stored_bytes']}
(s/'archive-proof.json').write_text(json.dumps(proof,indent=2)+'\n');print(json.dumps(proof))
