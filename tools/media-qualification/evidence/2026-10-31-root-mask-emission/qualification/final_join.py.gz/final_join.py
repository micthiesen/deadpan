from pathlib import Path
import hashlib,json,re
s=Path(__file__).parent
summary={};proof={}
for variant in ['main','scoped']:
 old=json.loads((s/f'root-mask-build6-{variant}.json').read_text())
 new=json.loads((s/f'root-mask-build7-{variant}.json').read_text())
 assert old['exit_code']==new['exit_code']==0 and old['sources_unchanged']and new['sources_unchanged']
 delta=[p for p in old['source_after']if old['source_after'][p]!=new['source_after'][p]]
 assert len(delta)==1 and delta[0].endswith('/crates/deadpan-audio/tests/sound_events.rs')
 a={r['name']:r for r in json.loads((s/f'root-mask-build6-{variant}-pins.json').read_text())}
 b={r['name']:r for r in json.loads((s/f'root-mask-build7-{variant}-pins.json').read_text())}
 assert set(a)==set(b)and len(a)==21
 changed=[n for n in a if a[n]['sha256']!=b[n]['sha256']]
 assert changed==['sound_events'],changed
 matrix=json.loads((s/f'root-mask-matrix-{variant}-matrix.json').read_text())
 counts={'targets':21,'passed':0,'ignored':0,'filtered':0,'retained_exact_binaries':20}
 joined=[]
 for row in matrix:
  target=row['target']
  if target=='sound_events':
   name=f'root-mask-sound-fixed-{variant}'
   run=json.loads((s/(name+'.json')).read_text())
   assert run['exit_code']==0 and run['sources_unchanged']and run['binaries_unchanged']
   assert run['binary_before'][b[target]['path']]['sha256']==b[target]['sha256']
   entry={'target':target,'run':name,'sha256':b[target]['sha256'],'exit_code':0}
  else:
   assert row['exit_code']==0 and row['sha256']==b[target]['sha256']
   name=row['run'];entry={**row,'retained_exact_binary':True}
  run=json.loads((s/(name+'.json')).read_text())
  assert run['exit_code']==0 and run['sources_unchanged']and run['binaries_unchanged']
  text=(s/(name+'.stdout')).read_text()
  matches=re.findall(r'test result: ok\. (\d+) passed; 0 failed; (\d+) ignored; 0 measured; (\d+) filtered out;',text)
  assert len(matches)==1,(name,matches)
  for field,value in zip(['passed','ignored','filtered'],map(int,matches[0])):counts[field]+=value
  joined.append(entry)
 proof[variant]={'source_delta':delta,'before':old['source_after'][delta[0]],'after':new['source_after'][delta[0]],'changed_executables':changed,'unchanged_executables':20,'all_passed':True}
 summary[variant]=counts
 (s/f'root-mask-final-{variant}-matrix.json').write_text(json.dumps(joined,indent=2)+'\n')
(s/'final-qualification-join.json').write_text(json.dumps(proof,indent=2)+'\n')
(s/'audio-matrix-summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(summary))
