from pathlib import Path
import hashlib,json,os,subprocess,sys
s=Path(__file__).resolve().parent
variant,build,mode,label=sys.argv[1:];assert variant in ['main','scoped'] and mode in ['old','intervals','policy','root']
root=Path('/Users/michael/Code/deadpan') if variant=='main' else Path('/tmp/deadpan-query-groundwork-2026-10-26/scoped')
receipt=json.loads((s/(build+'.json')).read_text())
assert receipt['exit_code']==0 and receipt['sources_unchanged']
pin=next(p for p in json.loads((s/(build+'-pins.json')).read_text()) if p['name']=='deadpan_audio')
assert pin['artifact']['profile']['opt_level']=='2' and pin['artifact']['profile']['overflow_checks'] and pin['artifact']['profile']['debug_assertions']
assert hashlib.sha256(Path(pin['path']).read_bytes()).hexdigest()==pin['sha256']
manifest={}
for absolute,h in receipt['source_after'].items():
 b=Path(absolute).read_bytes();assert {'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}==h,absolute
 manifest[str(Path(absolute).relative_to(root))]=h
data=(json.dumps(manifest,sort_keys=True,separators=(',',':'))+'\n').encode()
digest=hashlib.sha256(data).hexdigest()
out=s/(label+'-body.json');assert not out.exists()
(s/(label+'-source-manifest.json')).write_bytes(data)
prefix={'root':'DEADPAN_ROOT_MASK_AFTER','policy':'DEADPAN_POINT_POLICY_AFTER','intervals':'DEADPAN_QUERY_INTERVAL_AFTER','old':'DEADPAN_INTERNAL_MASK_AFTER'}[mode]
checkpoint={'root':(s/'base-revision.txt').read_text().strip(),'policy':'eedbc58272bdd009a65239b7104ddb786a2554fc','intervals':'ab211a2f132379a246157c3596d95fc42121541c','old':'e8fcdb3cb02f9682bef53f6ba2709e8a5ad692d0'}[mode]
keys={prefix+'_OUTPUT':str(out),prefix+'_VARIANT':'main-inherited' if variant=='main' else 'scoped-published',prefix+'_SOURCE_SHA256':digest,prefix+'_PUBLISHED_CHECKPOINT':checkpoint}
env=os.environ.copy();env.update(keys)
runner=s/('run_qualified.py' if variant=='main' else 'run_scoped_qualified.py')
test='stages::bound_reads::retained_host_baseline::pairs::native_mask_after::'+{'root':'capture_active_root_mask_after_v1','policy':'capture_active_point_policy_after_v1','intervals':'capture_active_query_intervals_v1','old':'capture_active_internal_mask_after_v1'}[mode]
subprocess.run(['python',str(runner),'--binary',pin['path'],label,'--',pin['path'],'--ignored','--exact',test,'--nocapture','--test-threads=1'],env=env,check=True)
run=json.loads((s/(label+'.json')).read_text())
assert run['exit_code']==0 and run['sources_unchanged'] and run['binaries_unchanged']
for k,v in keys.items():assert run['environment'][k]==v
body=json.loads(out.read_text());assert body.pop('variant')==keys[prefix+'_VARIANT'] and body.pop('source_sha256')==digest
native=body['native_requests'];assert native.pop('variant')==keys[prefix+'_VARIANT'] and native.pop('source_sha256')==digest
data=(json.dumps(body,sort_keys=True,separators=(',',':'))+'\n').encode()
sha=hashlib.sha256(data).hexdigest()
(s/(label+'-canonical.json')).write_bytes(data)
proof={'base_revision':checkpoint,'mode':mode,'variant':variant,'source_inputs':len(manifest),'source_manifest_sha256':digest,'binary_sha256':pin['sha256'],'bytes':len(data),'sha256':sha}
(s/(label+'-proof.json')).write_text(json.dumps(proof,indent=2)+'\n')
print(json.dumps(proof))
