# Cached Original masks as policy-prediction input

Read-only semantic analysis, 2026-10-29. No source edits, Cargo/native/compiler execution, or Git. This concerns actual successful private Original PCM cached by shared_eq/original_inputs, not arbitrary ReadBlocks or serialized masks.

## Result

For the exact immutable **Root or Domain Context + requested range + depth**, the cached block's suppressed ∪ exhausted is exactly the exclusion predicate currently derived from RootReadQueries for Original policy prediction. No Stage, Bound, creative-fade or endpoint counterexample exists within that scope. Reuse can avoid the full query factory on an actual PCM hit without retaining query metadata.

It is predicate-equivalent, not event-trace/work/error-order equivalent. It also changes the independence of one verification input: warm Original prediction and numerical permission observation would consult the same cached mask. That tradeoff must remain explicit.

## Source-level proof

Let H be every SilentHold range emitted by raw_policy::visit, P every explicit policy.suppressed range, and E every retained-envelope Exhausted range.

1. policy_prediction::populate initializes each applicable current owner route with admitted(original) && owner_support==Active, then passes the actual prepared queries to raw_policy::visit. It ignores RetainedEnvelope numeric events. For each H/P/E event, exclude intersects that mask with each current owner span and assigns false.
2. read_queries_borrowed calls raw_policy::apply with exactly those same borrowed queries, start and output count. apply itself calls the same visitor. It collects H and P into suppressed and E into exhausted while doing the real zero/envelope operations.
3. That reader returns suppressed=merged_suppression(H∪P), exhausted=E. merged_suppression sorts and merges overlapping/adjacent intervals without changing the set of samples covered.
4. Subsequent creative-fade application changes PCM only. No post-apply code adds, removes or reinterprets masks.
5. Therefore for a sample s in owner span i, both paths use:
   admitted(original) && support_i==Active && s∉(cached.suppressed ∪ cached.exhausted),
   with current route presence/ignored-route semantics unchanged.

The boolean range writes are idempotent union-clears after all initial positive writes. shared_components/permissions::assign_range implements true as bitwise OR and false as bitwise AND-not. Thus reordering H/P/E exclusions, joining adjacent H/P ranges, or dropping duplicate clears preserves every predicted bit. Current owner queries/routes must still be built and admitted normally; a cached mask cannot replace owner support or selection.

Sources: raw_policy.rs:7-24,40-92,128-162; stages.rs:1831-1984,2860-2872; shared_eq/policy_prediction.rs:96-164; shared_components/permissions.rs:127-174; shared_eq.rs:570-612.

## Cases that are easy to get wrong

- **Preserve/Stage/ProjectedStage:** read_queries_borrowed consumes prepared child samples/dependencies/relative_depth. It does not union the child's suppressed/exhausted vectors into the outer block. Outer policy is applied once afterward from the flattened/policy queries. Stored OUTER masks therefore match prediction. Recursively collecting inner masks would be wrong.
- **Bound processing:** likewise, the Bound result contributes block.samples, dependencies and relative_depth; its own masks are discarded at this outer boundary (stages.rs:1930-1956). Flattened retained-envelope exhaustion and current explicit policy supply the final outer masks. Do not substitute a bound-child ReadBlock.
- **Creative edges, including exactly zero gain:** apply_creative_fades runs after raw_policy::apply and does not change suppression/exhaustion. Zero faded PCM is not forbidden policy. The existing raw_policy test creative_zero_gain_and_policy_contents_do_not_invent_mask_bits explicitly demonstrates this.
- **Retained source endpoints:** exhausted_range_slots derives prefix/suffix masks from AudioSpan.envelope progress and length, independently of creative Hard/Automatic choice. apply_retained_envelope enforces those endpoints with fades=false in this boundary. Cached exhausted preserves the exact masks; using only suppressed would lose this policy. Hard edges cannot extend retained support.
- **NoSourceAudio, numerical cancellation, underflow or naturally silent PCM:** these do not automatically emit SilentHold. is_silent_hold matches only SilenceReason::SilentHold. Do not scan samples for zero or inspect policy.contents to invent permission bits.
- **Domain signed history/crops:** stored mask coordinates are absolute AudioSample labels on exactly the same signed output range. Do not assume Root's nonnegative origin or rebase them via nominal owner clocks.
- **Context::Retained:** excluded from this result. It uses read_retained_controlled, not this root-query finalizer, and policy_prediction::available currently rejects it. Keep that guard.
- **Authored owner treatments/mix:** these remain outside the cached raw block. A later gain mute or treatment producing zero must not alter its raw permissions.

Sources: stages.rs:1855-1984,2980-2987; edges.rs:143-252; raw_policy/tests.rs:281-322; policy_prediction.rs:52-64.

## Warm-hit provenance and same-pin requirement

The proof depends on an actual successful cached read of immutable input. Preserve the existing full accelerator-key/context/range/depth/controller/plan validation and relative-depth check; live-resolve and observe every dependency before using the candidate as a warm source. Successful original publication already proves envelope and creative-fade numeric validation. Cached masks are private derived products, not a new externally supplied admission token.

Pin the actual admitted Arc<ReadBlock> once. Use its masks for prediction and exactly that same Arc for numerical consumption afterward; do not later redo an unpinned lookup and accidentally consume a replacement block. Release the local pin promptly after Original mixing, as the current caller already drops raw before sound-return preparation. This retains the existing evictable PCM's already charged masks and adds no variable metadata allocation.

Live source failure still aborts; mask equality cannot excuse a revoked/changed dependency. Current owner/query support and all root/beat sound predictions remain independent and unchanged.

Source: shared_eq/original_inputs.rs:351-430,493-529; shared_eq.rs:570-620.

## Event order and actual work

The cold visitor emits flattened spans in order: offset validation, then SilentHold OR RetainedEnvelope followed by up to two Exhausted events. It validates EVERY explicit policy interval before emitting the first Suppressed event. Numeric retained-envelope validation occurs during apply's RetainedEnvelope callback, before exhaustion computation. Existing tests assert these error/operation boundaries.

Stored masks intentionally lose event categories, multiplicity, overlap ordering and validation history. suppressed is union-merged; exhausted is retained as emitted. Replaying their union cannot reproduce the exact old trace, and must not pretend to bill it.

For F flattened spans, E emitted exhaustion ranges and P explicit suppressed ranges, cold prediction's visitor hook alone bills 2F+E+2P units. Each H/P/E event also calls exclude on every Some current route (one unit per call), followed by actual nonempty range bit-write work. A warm adapter should bill its actual mask validation/visit and current route/word updates. For example, reusing the bounded policy-range visitor for stored intervals gives validation+emission charges for each stored interval, then the same exclude and predict_range work. Duplicate/overlapping clears may now cost less, legitimately because fewer operations occur. No old query-construction fees, cold event counts, cached work scalars or refunds should be replayed.

Use current cancellation/deadline checks and the actual selected ReadWork lane. Warm acceptance/error timing can differ because skipped work is absent. Do not alter cold query construction or the cold raw_policy event order. The literal tests in raw_policy/tests.rs:119-278 remain the cold oracle.

## Early candidate and reservation caveat

An early nonpinning exact-key candidate is only a hint. The current make_room tries to evict unpinned Original PCM FIRST. Therefore candidate→mutating make_room→pin can turn into a miss. Falling through to query construction AFTER keeping that mix reservation changes today's cold order (currently queries precede mix reservation), potentially changing failure precedence and peak residency.

The narrowest clean fast-path eligibility is: an exact candidate exists AND the full current resident sum plus existing mix reservation already fits, so warm reservation requires no eviction. Then reserve and pin/revalidate the actual hit; no fallible eviction-producing operation should occur between the final successful test and pin. If it does not fit, keep the ordinary cold query-factory-before-reservation path. A wider optimization allowing eviction needs explicit fallback ordering and reservation rollback; a candidate alone is insufficient evidence that warm work can proceed.

This is an ordering constraint, not a requirement to design a new reservation system. The parent can compare coverage/net work before choosing a broader branch.

## Verification-independence caveat

Today query-derived prediction is compared with producer observations based on raw masks. Warm mask-based prediction would share the same old mask data with that observation. It would still detect wrong selection, support, route/offset, missing producer samples and positive/negative row-write bugs. It would no longer independently detect an internally corrupted/stale mask that both warm branches use consistently. The exact cache identity/provenance checks and immutable successful-read origin address intended runtime inputs, but this is a real reduction in fault-detection independence, not something verify_prediction can certify away.

A semantic regression oracle should independently compute query-based predicted rows and actual successful cached masks for the same fixture, then compare warm/cold output bits/PCM. Include overlapping/adjacent masks, retained prefix+suffix exhaustion, silent Holds/gaps, Preserve and Bound outer policy, creative-zero-with-permitted-bit, signed Domain history, changed source, exact identity/depth rejection and a candidate evicted during reservation. Keep a deliberate cached-mask-corruption test to document whether the intended contract requires detecting that class on warm reads.

No performance benefit has been measured for this alternative. The source proof supports exact warm permission reuse in the stated scope; it does not by itself establish acceptance of the changed verification independence or fallback order.
