# Warm Original policy-mask review

Scope reviewed: `warm-before/{main,scoped}` against `warm-candidate/{main,scoped}` for `shared_eq.rs`, `shared_eq/original_inputs.rs`, and `shared_eq/policy_prediction.rs`. The main and scoped candidate diffs are identical in these paths. Read `cached-policy-mask-research.md` and the relevant Deadpan AGENTS resource/cache and testing instructions. No files changed; no Cargo, native, or Git operations run.

## Findings

No actionable correctness, ownership, cache-coherence, resource-cap, or error-order finding in the assigned scope.

The candidate pins the cached `Arc<ReadBlock>` only after it finds the exact graph entry, confirms the cache payload exists, and proves the full current resident/disk totals plus the computed mix reservation fit. It then rechecks graph-entry identity, re-admits each source dependency and verifies its fingerprint, checks depth/cancellation, and passes that same Arc to policy prediction and subsequent numerical consumption. On a miss or failed fit it retains the cold query-factory-before-`make_room` order. The Original pin is dropped immediately after Original mixing, before later sound-return preparation. The shared helper refactor preserves the ordinary cache-hit validation path.

## Verification-independence caveat

Warm prediction and numeric `permitted(&raw, ...)` now consume the same cached masks. A coherently corrupted mask can therefore affect both sides and evade `verify_prediction`, whereas the cold query-derived prediction compared against read-derived masks had more independence. This is an explicit tradeoff of the requested same-Arc optimization; it is not a mismatch in the cache-mask equivalence proof. Keep the independent cold-vs-warm regression oracle and a deliberate corrupted-cache-mask case if the verification contract needs to retain that fault-detection property.
