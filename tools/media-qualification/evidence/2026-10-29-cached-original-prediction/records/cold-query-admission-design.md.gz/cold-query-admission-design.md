# Cold Original query construction admission

Research only, 2026-10-29. No production edits, Cargo, native execution, or Git.
Main: /Users/michael/Code/deadpan
Scope: /tmp/deadpan-query-groundwork-2026-10-26/scoped

## Decision

Full cold Original query admission requires Plan constructor changes. There is no sound host-only measure-then-reserve change: the final four products omit temporary query products, recursion state, replaced vector buffers, and the overlap between old and new buffers. Reserving their measured final bytes after construction leaves precisely that peak unadmitted. An estimate based only on maximum_spans/maximum_work is also insufficient without proving all allocation and identity-length bounds, and would not be actual storage admission.

The next bounded implementation unit should be **admitted flattened AudioQuery construction for Root and Domain, with its carrier kept by PreparedOriginalRequest through prediction and the numerical query read**. Reuse the existing actual generic capture walker; add admission to the outer collection/header construction and a sealed read-only carrier. This closes one concrete product, including its peak, and establishes the caller lifetime without pretending to close processing, policy, or fades. Keep the other three explicitly outside that claim until their constructors are admitted.

Do not retain any new pack in Graph. Required current-request leases belong to ReadWork and are released when their values die. The rejected optional Graph-pack retention design remains rejected.

## Current factory and actual lifetimes

Relevant host symbols:

| Location | Actual behavior |
| --- | --- |
| deadpan-audio/src/stages.rs:366 RootReadQueries | Owns AudioQuery flattened, AudioProcessingQuery processing, AudioPolicyQuery<AudioSample> policy, optional AudioFadeQuery fades. |
| stages.rs:374 RootReadQueriesRef and as_borrowed | Four references, copied as stack metadata. They do not clone a query or reserve storage. |
| original_request.rs:14 PreparedOriginalRequest | Owns the products plus borrowed Root/Domain identity and scalar range/fade seal. |
| original_request.rs:58 prepare_original_root | Builds flattened, processing, policy, then fades. Earlier returned products remain live while every later product is constructed. Each successful query's work is billed immediately after its constructor returns. |
| original_request.rs:115 prepare_original_domain | Builds flattened, the processing/policy pair, then fades with the same cumulative-live-product overlap. |
| original_request.rs:216 prepare_domain_policy | Processing product is held while finish_policy builds policy; its terminal witness may reuse the existing processing binding tape. The seal and witness add no separate heap allocation. Do not replace this with a second independent first walk. |
| shared_eq.rs:518 onward read_shared_program | On the cold prediction path PreparedOriginalRequest survives policy_prediction::populate, then is consumed by shared_original_input_prepared. |
| shared_eq/original_inputs.rs:511 shared_original_input_mode | A late cache hit can consume and drop the already prepared request without using its numerical queries. Otherwise it moves the request to read_prepared_original. |
| original_request.rs:170 read_prepared_original; stages.rs:1831 read_queries_borrowed | Actual numerical preflight and processing read borrow the four products. The request is destroyed after this read returns, before later numerical mixing needs only the resulting ReadBlock. |

The normal Root/Domain reads at stages.rs:1285 and :1763 also consume a PreparedOriginalRequest. The separate read_queries owning entry point at :1812 borrows its owned pack during the call. A closure claim limited to prepare_original_* must not silently include all renderer/signal query construction elsewhere.

At the last numerical query borrow, dropping both the products and their leases is correct. The later SharedMix copy uses ReadBlock PCM and masks, not those query products. Keeping the query charge until drop(raw) would unnecessarily extend the charge beyond query lifetime. The raw cached Arc still drops at shared_eq.rs:685 before later sound returns as the current warm implementation requires.

## Four owned products and construction-only overlap

This map relies on the already completed OwnedHeap closure, not a new audit of it. Every identifier owns an Arc text reference; charge conservatively at each owning edge, even when shared with the immutable plan. Borrowed RenderPlan and scalar range/grid/transform fields are excluded.

### 1. Flattened AudioQuery

Product: audio.rs:237 AudioSpan and :302 AudioQuery. Owns header project/revision identities; spans capacity; per-span definition identities, boundary start/end origin capacities with occurrence paths and gap identities, instance repeat capacities and identities, gap_after, retime capacity/node identities, and owning content identifiers.

Construction: RenderPlan::audio at audio.rs:396 and AudioDomain::audio at audio_domain.rs:393 both use Vec::new/push for the outer span vector and clone the header identities at return. Each span is built while previous spans remain retained.

The actual deep work is already audio_capture.rs:123 RenderPlan::audio_walk_inner_admitted. Its temporary constraints, editorial markers, repeats, retimes, copied seeds, boundary extent construction, Stage/Bound branches and nested identities have allocation-site guards. Existing ordinary callers at audio.rs:530 audio_walk_inner instantiate Unmetered, then extract unmetered values. This is the useful existing seam, not permission to wrap the final ordinary query after it returns.

### 2. AudioProcessingQuery

Product: audio_signal.rs:540 AudioProcessingSpan and :574 AudioProcessingQuery. Owns header identities; span capacity; definition, instance/repeats, gap, retimes; and AudioSignalContent at :454:

- Leaf owns its content identifiers.
- Stage owns descriptor/recipe/domain metadata.
- Bound owns its Box shell and the complete resolved-binding/domain metadata beneath it.
- ProjectedStage owns an Arc edge and nested projection metadata. Conservative measurement is per owning edge.

Root construction is not the same admitted capture path. RenderPlan::audio_processing at audio_signal.rs:718 first constructs AudioSignalQuery with AudioSignal::query_inner at :1007, then maps its spans into a fallible Result<Vec<AudioProcessingSpan>> collect. This is a real input span buffer plus output-buffer construction; do not assume allocator reuse or equal capacities without evidence. Values move rather than deep-clone during this conversion, but the vector storage and partial-conversion failure peak still need guards.

AudioSignal::span at :1124 owns temporary repeats/retimes/gap, clones Source identifiers, resolves a binding through ordinary bound_at and allocates its Box at :1211, and can construct opaque stages. query_inner also has Source/Silence and Projected branches that cannot be covered by guarding only its structural loop.

Domain construction is audio_domain.rs:450 processing_observing. It uses audio_walk_processing and into_processing, which reach the existing generic capture walker via an Unmetered wrapper. Its outer spans Vec and header identities remain separate admission sites. A future admitted processing_for_policy/finish_policy carrier must retain the first query's charge across both reuse and fallback branches.

### 3. AudioPolicyQuery<AudioSample>

Product: audio_policy.rs:15 owns suppressed range-vector capacity and contents capacity; each AudioContent may own source identifiers. Scalar sample labels require no nested heap. The constructor also instantiates policy on SignalSample internally.

Construction: PolicyWork at :24 owns the growing content inventory. signal_policy (:253), domain_policy_inner (:334), and bound_policy (:461) recursively allocate current flattened/signal queries, binding queries, raw Root/Point domains, per-recursion suppressed buffers, child return buffers, and inventories. Moving a child's content into the inventory avoids a content clone but does not remove the concurrent vector capacities.

PolicyWork::result at :81 sorts suppressed in place, creates a second merged Vec while consuming the first, then collects a labeled output Vec. Constructor admission must cover both merge and labeling conversion, not just the final suppressed vector. The processing-tape witness removes one eligible binding walk only; it does not remove the independent current flattened policy query or retained-bound recursion.

### 4. Optional AudioFadeQuery

Product: audio_fades.rs:21/:31/:38 owns spans capacity; each span's start/end edge capacities; each edge's origins capacity; each origin's occurrence paths/identities.

Construction: fade_query (:83) keeps prior output spans while building an actual walked Leaf/Stage plus EditorialCapture. For an opaque stage it performs an additional flattened walk while the first processing result is still live. retained_bound_fade (:193) creates an envelope Domain, grows its editorial seed, then walks that Domain with a further capture.

retained (:349) allocates the start/end edge vectors. add_editorial (:375) builds new origins, append_origins (:459) captures/deduplicates owning origins, and merge_edge (:498) clones retained old origins into the replacement before replacing the old edge. Both original and new origin buffers are live during that operation. A final AudioFadeQuery measurement cannot see any of those discarded walks, Domains, captures, or replaced edges.

## Existing admission infrastructure that can actually help

- audio_sound_admission.rs:11 AudioSoundContextAdmission: issuer, spend, reserve(Layout), merge. The trait is currently documented for the closed sound context, so expanding its use must update that scope explicitly. Its policy is trusted accounting, not media authority.
- audio_owner_query_admission.rs:94 Memory, :106 Owned, :145 Budget: allocation-free RAII lease carriers, issuer validation, canonical versus additional work. Values must precede their leases in destruction order.
- Budget::grow at :580 reserves the full replacement capacity before allocating, keeps the previous vector/capacity charge live while draining into the replacement, then drops the old buffer before replacing its charge. It handles the actual double-buffer peak; reserving just capacity delta would not.
- audio_capture_storage.rs:11 copy_vec/fixed: actual exact-capacity copy construction with each nested owning clone guarded. Reuse these finite copy helpers rather than Vec::clone after an after-the-fact inspection.
- audio_bound_query.rs GuardedBound, bound_at_query, envelope_domain_query: existing binding/domain allocation guards; CoreAdmission forwards actual Core work to the same policy. Processing/policy/fade expansion must preserve those guards rather than extracting unguarded values.
- audio_metadata_admission.rs: array/arc/identity layout helpers and validate/reserve. Identity layout includes Arc counters and padding. The final storage measurement is a separate observer, not a reserve capability.
- deadpan-audio/src/sound_context_admission.rs: Admission already reserves against StageAudio::make_room and increments ReadWork.sound_context_frames. Its Lease borrows only the read ledger and does not hold a mutable controller borrow. This permits a returned query carrier to outlive the short mutable Admission while numerical reading reborrows StageAudio.

Use a request-local lease, not Graph publication/JointTransfer. The existing required make_room accounting sees resident caches, active/projected allocations and live sound-context metadata, so an admitted query carrier can coexist honestly with subsequent required PCM reservation. Per-reservation frame rounding remains the existing conservative semantics; do not consolidate rounding later and refund a difference.

## Exact smallest next unit

Proposed names are design names, not existing API:

1. Add a sealed AdmittedAudioQuery<I,L> containing the actual AudioQuery before its issuer and charge. Provide query() -> &AudioQuery; no Clone, arbitrary detach, mutable query access, or caller-built admission certificate. Follow the existing admitted owner-query carrier convention.
2. Add RenderPlan::audio_admitted and AudioDomain::audio_admitted, factoring the existing loop into the actual generic implementation. Unmetered entry points retain their existing ordinary push allocator backend, failure labels/order, and canonical work. The admitted path calls audio_walk_inner_admitted, reserves outer Vec replacement peaks and header identities before ownership is created, and transfers a completed span's retained charge into the output carrier without releasing it first. Temporary walker charges drop with their actual temporary values.
3. Flattened queries always request stop_at_preserve=false and stop_at_bindings=false and must finish as Leaf. Exploit only that existing closed invariant. GuardedBound currently deliberately has no arbitrary generic into-unmetered extraction; any new allocation-free extraction must preserve/check the guard and reject impossible metered Core payloads, or retain a sealed guard in the returned carrier. Do not add a general lease-detach escape hatch to make compilation easy.
4. Change prepare_original_root/domain to take the short mutable admission borrow, then store the admitted flattened carrier in the owned request. RootReadQueriesRef still borrows &AudioQuery from its carrier. Thread the read-work lifetime through PreparedOriginalRequest and original_inputs prepared helpers as required; keep origin identity borrowed.
5. Keep that carrier live during policy prediction and numerical read, including all errors. The late Original cache-hit return naturally destroys the unused request and releases the lease. A warm Probe hit builds no query carrier, so it receives no query reservation, traversal, or lease. Cold miss source/cache behavior remains the existing path.

This unit is reviewable independently. It must be described as flattened-query admission only. Full cold Original admission subsequently needs the Root AudioSignal constructor/conversion plus Domain processing, recursive policy, and fade constructors under the same live ledger. There is no honest smaller host-only step that closes all four construction peaks.

## Work and failure semantics

AudioStorageMeasurement in audio_allocated.rs:108/:126 returns (Result<byte_count,PlanError>, actual successful traversal debits). HeapBudget::core_route (:76) now propagates the delegated SoundRoute observation's successful debits even on failure. Use it as an independent final-storage cross-check or for a bounded inspection whose work the host bills before propagating the byte result:

measurement -> (byte_result, inspected_work) -> spend_plan_work(inspected_work) -> byte_result?

It observes only storage still present. It cannot recover past constructor work and cannot establish preallocation admission.

Today prepare_original_* uses constructor()? before spend_plan_work(query.work). A failed constructor therefore exposes no partial canonical work to this host call. Earlier successful products have already been billed; the failed product's successful internal traversal is not. PolicyWork similarly observes nested work only after nested success. Do not relabel measurement work as constructor work or bill maximum_work on failure.

For the admitted unit, use the existing callback path while operations happen: Budget::canonical debits its local allowance then forwards successful debits; additional bills actual new inspections/reservations/copies, without changing canonical weights. CoreAdmission forwards work during Core construction, so a Core failure does not require a guessed final receipt or replay. Success still needs the existing take_work/account_core local receipt reconciliation, without billing twice. Errors must drop actual values and leases in order. Failed bulk precharges perform no traversal and must not consume/refund invented work.

Preserving legacy failed-call work behavior applies to compatibility entry points. A new admitted host path deliberately reports actual partial failure work through the callback and must have explicit tests for that difference. No changes to MAX_PLAN_WORK_PER_READ, canonical weights, refunds, or renderer budgets belong in this unit.

## Necessary tests

Reuse existing compiled Source/Repeat/retime/boundary and admitted-allocation fixtures, not a parallel test framework.

1. Root and Domain ordinary versus admitted flattened field equality and identical canonical work/lookup. Include signed physical Domain, repeated identifiers, transparent retimes, owned boundaries and gap identities.
2. Finite ledger exact construction peak fits; one frame short fails before the corresponding allocation/clone. Force outer Vec growth while previous spans and the old buffer remain live. Assert peak and final live charge separately; include empty query header identities.
3. Allocation/identity callback failure at each meaningful transition releases all partial values and charges. Include issuer changes, layout overflow, work exhaustion, and later walker failure after an earlier completed span.
4. Actual successful debit counts on exact/short/zero work limits, including failure work. No manufactured full-allowance debit. Old ordinary entry points keep their frozen observations.
5. Host cold prediction: live flattened lease during policy_prediction::populate and read_queries_borrowed, then zero after success/error. A later product failure releases the earlier flattened value/charge while retaining already spent work.
6. Late numerical cache hit drops the unused cold request charge; early warm Probe hit performs no query construction/admission. Warm PCM/masks/source/depth semantics and the current raw Arc drop boundary remain identical.
7. While a required query lease is live, a subsequent numerical reservation sees it and cannot exceed aggregate residency. No Graph query pack, no optional non-evictable retained charge, no new cache payload.
8. Independent final AudioStorageMeasurement is billed even on measurement error and its result is consistent with the retained carrier's conservative coverage. It is not substituted for the allocation callback/peak assertions.

Before claiming full four-product closure, add separate failed constructor tests for Root processing's intermediate-to-output vector conversion; Domain processing/policy reuse and fallback; nested raw-bound Root/Point policy; merge/label buffer overlap; and retained/editorial fade replacement with old/new origins both live. None is discharged by the existing final-storage observer tests.

## Evidence and limits

The source map and exact current source hashes for both variants are in cold-query-admission-source-pins.json beside this report. These are read-only textual findings. Parent owns builds and native qualification. No test results are inferred from this research.

Prior evidence: plan-storage-README.md, cached-policy-mask-research.md, query-retention-design-review.md, warm-production-rationale.md. Their successful warm-path results do not close cold construction storage.
