# Warm Original test-strength review

Scope: current `cached_prediction_tests.rs`, `cached_policy_tests.rs`, `cached_prediction_baseline.rs`, and `cached_prediction_trace.rs`, including their module wiring. Read only; no build or test execution.

## Findings

No material test gap or flaw found in the requested checks.

- The OLD producer freezes the pre-fast-path outputs; the current test regenerates OLD through the legacy query path and compares it to the immutable snapshot before comparing that OLD result to the warm path. The comparison checks full output/mask witnesses, the independently prepared query oracle, actual provider/cache counters, and cleanup. The zero-source supplement separately confirms the fixture is declared Source audio, verifies an all-zero signed-16 stereo WAV by decoding it, and proves every raw-policy sample is permitted despite zero PCM.
- Work reconciliation is valid for the measured intervals. Each phase guard is synchronous and non-nested, and `assert_phases` checks depth, overlap and overflow. The guards cover the changed query construction, probe, prediction, and Original-read work; the assertion that total work delta equals summed phase-delta changes also detects any changed unphased debit. Repeat intervals specifically require no query-construction or Original-read plan work and positive probe work, and require a net plan-work reduction. The separately performed cache-hit/independent-oracle work is outside both snapshots, as the producer documents.
- The adapter tests independently derive literal interval unions for overlapping, duplicate, and adjacent suppression masks plus exhaustion, verify output permissions, and test malformed/out-of-range masks. The owner-support case uses real owner spans and checks selected and unselected behavior across active and inactive support. The corruption case is useful: cached mask and numeric observation intentionally agree and pass, while preserved old queries disagree and reject the same well-formed mask, explicitly documenting the independence tradeoff.

The current oracle corpus is intentionally bounded: Root and exact Domain, Source, SilentHold crossing, Preserve Stage, plus zero Source; the changed-range, malformed-mask, exhaustion, support and corruption cases are covered by the adapter tests. The producer records unexercised Bound, retained-envelope exhaustion, signed history, revocation and reservation-eviction cases instead of implying coverage. I see no need to demand an unbounded matrix expansion for this focused change.
