# Warm Original cache resource review

## Result

No production resource or failure findings in the assigned scope: `shared_eq/original_inputs.rs`, the warm-before/current `shared_eq.rs` integration, and `cached_probe_tests.rs`.

The early probe's pre-pin reservation accounts for required prepared-stage resident frames and disk bytes, cached Original resident frames, active resident/disk work, projected resident/disk work, live sound-context metadata, and the full future mix reservation. This matches the subsequent `make_room` admission terms; on success the probe pins the existing Arc without duplicating PCM. The probe performs no eviction before the fit check. On resource decline it returns `None` before touching LRU state, pinning, or source admission. A successful candidate is still source-readmitted and depth-checked before use.

## Finite owner-lease fixture order

The finite-cap test must hold the actual `owners_admitted` lease before seeding its two Original cache payloads. Owner-query construction can legitimately evict optional cached Original payloads under a constrained ceiling. The test's measurement pass obtains cached residency and metadata from real constructors, then calculates `full = cached + metadata + ADDITIONAL`. In each fresh finite controller, acquiring/holding owners first and then seeding both 64-frame entries leaves the cache intact because `cached + metadata` remains below both `full` and `full - 1`. Probing at `full` should hit; at `full - 1`, it should decline without altering cache state, pins, required-stage residency, or source I/O. The current reordered setup reflects that boundary.

The required memory and temporary-file cases also measure actual prepared-stage outputs, admit an eligible reference probe, then tighten the corresponding private limit by one to establish a no-eviction decline. No production issue was found in those cases.
