# Query retention host design review

Read-only review of the concrete proposal, against current shared_eq/original_inputs/original_request/policy_prediction and sound_context_admission. No source edits, Cargo/native/compiler execution or Git. Base supplied by parent:8c81a8d0d. This does not repeat the earlier heap-closure inventory or approve acceptance without measurement.

## Verdict

The ownership and borrowing model is sound **if packs stay inside the request Graph's lifetime**: move successful query products into a separately owned pack, borrow its queries locally, and keep an actual lease until its last owning handle drops. No self-reference or deep query clone is needed. StageAudio can remain PCM-only.

There is one material pressure-eviction gap in the stated design: a retained pack's ordinary Lease increases ReadWork.sound_context_frames, but StageAudio::make_room_for has no access to Graph's query packs. It can evict optional PCM and required prepared stages, then fail while unpinned optional query packs are still retaining those frames. Admission that fits today does not establish room for the next required allocation. Resolve that before publishing retention; do not treat optional metadata as permanently required Graph storage.

## Minimal holder and APIs

An adequate private holder shape is:

    struct RetainedQueries<'plan, 'work> {
        plan: &'plan RenderPlan,
        context: Context<'plan>,
        scope: Arc<()>,
        samples: Range<AudioSample>,
        depth: usize,
        queries: RootReadQueries<'plan>,
        issuer: sound_context_admission::Issuer<'work>,
        _lease: sound_context_admission::Lease<'work>,
    }

    enum SharedPrepared<'context, 'plan, 'work> {
        Fresh(PreparedOriginalRequest<'context, 'plan>),
        Retained(Arc<RetainedQueries<'plan, 'work>>),
    }

Lease MUST be the last owning field, so query storage/context drop before its reservation is released. issuer can be omitted only if Lease exposes an equivalent checked ledger identity method. scope can be omitted only if every pre-prediction and numerical path proves the same controller identity from Cache.scope. Keeping it explicitly is a small and robust exact receipt; cloned scope/context Arcs do not allocate payloads.

Thread 'work through Entry<'plan,'work>, Cache<'plan,'work>, their Default/impls and test builders; Graph already has both lifetimes. Do not add a pack to StageAudio. Pack Arc clones must not escape read_shared_program/read_shared_input or survive release_shared_graph. Context payload charges were transferred into Graph.resident, not into this new query lease: retaining Context past Graph teardown would keep that heap alive after its existing charge was released. Entry eviction while Graph remains alive is safe.

Only small new methods are necessary:

- PreparedOriginalRequest::into_queries(self) -> RootReadQueries<'plan> (private consuming move).
- StageAudio::read_prepared_original_borrowed(..., &PreparedOriginalRequest<'_, '_>, control, depth) -> Result<ReadBlock,...>. Keep existing consumed read_prepared_original signature and delegate to the borrowed implementation, retaining its current Origin validation.
- SharedPrepared::queries(&self) -> RootReadQueriesRef<'_, 'plan>.
- One exact pre-prediction Cache lookup returning an independent owning Arc handle; it validates/touches the slot without requiring PCM presence.
- A shared-only validation/read entry point taking SharedPrepared by value, validating Fresh by existing validate_original and Retained by its pack receipt, then borrowing queries for a numerical miss.
- One optional retention-admission/publication operation. Measure borrowed products; reserve; then consume only the Fresh variant. The retained variant reattaches its existing Arc/lease to a replacement slot with no remeasurement, new allocation or second charge.

Arc<RetainedQueries> is !Send/!Sync because Lease contains &RefCell<ReadWork>. This is legal for these local synchronous functions, but the workspace enables clippy::all, so expect arc_with_non_send_sync to require attention at the constructor. A local Rc would express the true local ownership; if preserving the proposed Arc, document and narrowly justify the existing request-local restriction rather than accidentally promising cross-thread safety.

## Exact ordering

1. At the old prepared_original construction point (shared_eq.rs:497 onward), run common preflight BEFORE a cache lookup can bypass construction: cancellation/deadline; Graph plan pointer == controller plan; controller scope; Context belongs_to(plan); depth; nonzero/MAX_OUTPUT_FRAMES and range arithmetic. Determine predict/owners/admitted exactly as today. Do not enable Retained-context prediction, which available currently rejects.
2. Lookup actual Context allocation + range + depth. Check full context after the accelerator match. Check pack.plan, pack.scope and exact issuer == issuer(control). Lifetimes alone do not distinguish two ReadWork objects with equally long Rust lifetimes. Reject a foreign ledger before prediction can read its products.
3. Clone the pack handle, ending the Cache/Graph borrow. Or construct the existing Fresh request. Never retain a reference into Cache across a &mut Graph call.
4. Prediction borrows queries from the local enum. End those borrows before moving the enum into the shared numerical read. Prediction remains metadata-only and does not admit media.
5. Numerical read repeats exact receipt validation, depth and normal read preflight as appropriate. A PCM hit still resolves every dependency, observes its current provenance and enforces relative depth/cancellation. A query-pack hit is not source admission. A PCM miss can use the independent local pack even if the stale Entry is removed.
6. On successful numerical read, optional publication may retain freshly built products. Do not extract/drop the Fresh request before the borrowed read succeeds. Any failure drops products and temporary leases in ordinary scope cleanup; previous work stays billed.
7. Prefer attaching the products after **any successful exact read with a Fresh request**, including an existing PCM hit. Limiting publication literally to a PCM miss can leave a PCM-only entry rebuilding prediction products forever (for example an entry first populated by the nonprediction path or an earlier retention refusal).
8. Keep the local pack pin only through prediction/numerical use. Drop it before later sound-return allocations and before final Graph cleanup. Cache.clear drops its entries while Graph context accounting still exists.

Source anchors: original_request.rs:13-50,151-190; policy_prediction.rs:29-64; shared_eq.rs:497-589,612-620; original_inputs.rs:351-430; sound_context_admission.rs:14-30,138-192.

## Admission and eviction refinements that matter

**Do not blindly reuse Admission::reserve for optional retention.** It calls generic make_room, which may evict required stages before returning an error. Either provide a narrow optional backend, or prove the full existing sum plus the exact new charge fits immediately before calling that backend, with no intervening fallible mutation that changes residency. Byte failure must preserve the already successful PCM/fresh return.

Measure complete query-owned heap plus the correctly aligned Arc<RetainedQueries> allocation (including inline query handles, Context/range/depth/issuer/lease), with checked arithmetic. The fixed Cache reservation covers its new optional-Arc pointer slots, not the pack allocation. Existing token-shell accounting remains valid. Measurement observes work before visits and reports exact accepted partial work on failure, including nested Core traversal; no post-success-only charge. Use the actual current canonical/cache lane. No work refund when optional retention is refused.

Treat PCM and query metadata as independent resources. Generic PCM eviction may leave a query-bearing slot. Stale-key removal must not invalidate a previously cloned pack or free its lease prematurely. When replacing a stale slot, transfer/clone the already admitted pack into the new slot, not a new measured copy. Clearing one slot does not release a pack still pinned by an active read. Consider replacing an existing optional query pack without adding another slot; actual slot capacity remains64.

**Pressure blocker, concrete failure case:** fill multiple exact entries with successful, unpinned query packs until sound_context_frames=Q. Then require a new stage/mix allocation R where R plus live required state fits without Q. Current make_room evicts controller Original PCM, which does not release the Graph entries' packs. It next evicts required stages and/or fails even though dropping the unpinned optional packs would make room. Fixing only the retention publication predicate cannot prevent this later failure.

A narrow resolution is an explicit query-pack eviction phase, reachable before every required allocation phase that may encounter this Graph's retained metadata, ordered before unrelated stage eviction. The implementation must prove it also covers nested read/preparation make_room calls, not just the top-level mix reservation. If that reachability cannot be established with the existing signatures, the proposed host design is not yet complete. A conservative interim policy can release all unpinned packs before entering allocation phases, but must specify how the currently used pack is pinned and charged and whether the measured reuse benefit survives. No new callback registry or broad refactor is recommended here.

No RefCell<ReadWork> borrow guard may remain live while dropping a pack: Lease::drop uses borrow_mut. Cache removal should first unlink/take the entry, end ledger guards, then drop its owning handles. Similarly finish any bytes/work observation guard before reservation, eviction or Arc publication.

## Failure/verification cases

- Same Context contents but different allocation; different plan/controller/depth/range/fade mode; same lifetimes but different ReadWork issuer.
- Metadata hit + PCM hit; metadata hit + stale PCM; Fresh query + PCM-only hit; miss that succeeds but cannot afford optional metadata.
- Last Entry reference evicted while a local pack pin remains: metadata lease stays live until that pin drops, PCM admission remains fresh.
- Every stale/remove/clear/error path releases exactly one pack charge on last-owner drop; no graph teardown or ledger borrow panic.
- Pressure needing only unpinned query eviction; required-stage cache should remain untouched when optional metadata can be freed.
- Exact partial work conservation on failed Plan and nested Core measurement; cancellation/deadline and global-lane exhaustion preserve their actual errors. Optional local storage/byte refusal may skip retention, but must not disguise a real global work/deadline error.
- End-to-end unchanged PCM/masks/source provenance/relative depth and Scope's existing family logic. No GeneralSplit enablement.

Acceptance still requires measured construction saved minus actual lookup, heap-measurement/admission and pressure-eviction work on the original witness. With those quantities unmeasured this is an implementable ownership design with a pressure-management blocker, not an established optimization.
