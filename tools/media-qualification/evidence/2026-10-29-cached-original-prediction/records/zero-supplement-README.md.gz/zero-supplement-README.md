# Separate zero Source OLD supplement

Only appended to Main/Scope cached_prediction_baseline.rs. The complete preexisting producer prefix is byte-for-byte unchanged: Main 18,835 bytes; Scope 18,746 bytes. Existing matrix(), its six cases, helpers and golden output code are unchanged. No existing golden or guard manifests were written.

New public-to-sibling helper: zero_matrix().
Exact ignored filter:
stages::shared_eq::cached_prediction_baseline::produce_old_cached_prediction_zero_matrix
Distinct create-new output env: DEADPAN_CACHED_PREDICTION_ZERO_BASELINE.
The ignored producer wraps zero_matrix in with_legacy, matching the existing OLD trace safety. Ordinary zero_matrix records the actual default path for the parent's future warm-versus-legacy test. Parent owns module wiring and serial native capture; this worker ran no native/Cargo/Git command and produced no OLD result.

The supplement reuses the validated existing document and nonconstant shared prediction treatment, changes no declaration to Silence, and proves the requested plan window still consists of AudioContent::Source. It copies the real RIFF WAV into memory, asserts signed PCM format1, stereo,16bit, zeros only data chunks, hashes those exact bytes, reopens them through AudioSession::open_verified and creates a real PreparedSource with the original matrix layout. No WAV fixture on disk is changed. Derived WAV bytes: 32832; SHA-256: 4a20771a21250d4ab90ae09c586f4e0ce31c9e072713176a2179718fdc8acf64. This pin is a byte-construction observation, not a native decode result.

Root and exact Domain each run fresh/repeat read_shared_program on the same admitted Graph/range. The actual cached raw block must be all numerical zero, have dependencies, and have empty suppressed/exhausted vectors. An independent query visitor must mark every requested sample permitted, and all16 zero samples must occur in the zero-with-permitted-policy list. Returned f64 PCM is all zero while shared suppression remains empty. First publication, unchanged warm publication counter, live source admission, same Arc identity, phase depth/overflow guards, literal PCM equality and full cleanup remain asserted.

Existing six-case artifacts are intentionally separate. Source pins, append-only prefix proof and full patch: zero-supplement-{before,after}-pins.json, zero-supplement.patch, zero-supplement-{before,after}/. Main and Scope appended bytes are identical. Source guard manifests remain parent-owned and need no new source path: only the existing producer path's hash changed.

Targeted rustfmt with skip_children=true completed. Complete appended source reviewed and exact original-prefix preservation verified. No production source, Core/Plan, fixtures/goldens or parent guard manifests were modified.
