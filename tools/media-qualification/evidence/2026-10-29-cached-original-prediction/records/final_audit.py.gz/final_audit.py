from pathlib import Path
from datetime import datetime
import hashlib,json,re,sys

s=Path(__file__).resolve().parent
main=Path('/Users/michael/Code/deadpan')
scope=Path('/tmp/deadpan-query-groundwork-2026-10-26/scoped')
sha=lambda value:hashlib.sha256(value).hexdigest()
split_passed,split_failed=map(int,sys.argv[1:])
assert split_passed+split_failed==7
negative={'final-scoped-lib':101,'published-warm-main':101,'published-warm-scoped':101}
if split_failed:negative['fresh-split']=101
receipts=[]
audio_intervals=[]
for path in sorted(s.glob('*.json')):
    row=json.loads(path.read_text())
    if not isinstance(row,dict)or 'command'not in row or 'started_at'not in row:continue
    assert row.get('exit_code')==negative.get(path.stem,0),(path.stem,row.get('exit_code'))
    assert row['sources_unchanged']and row['binaries_unchanged'],path.stem
    for name,pin in row['streams'].items():
        data=Path(name).read_bytes();assert len(data)==pin['bytes']and sha(data)==pin['sha256'],name
    receipts.append({'label':path.stem,'exit_code':row['exit_code'],'seconds':row['seconds'],
        'source_inputs':len(row['source_before']),'sha256':sha(path.read_bytes())})
    if row['binary_before']and '-audio-'in row['command'][0]:
        audio_intervals.append((datetime.fromisoformat(row['started_at']),datetime.fromisoformat(row['finished_at']),path.stem))
for a,b in zip(sorted(audio_intervals),sorted(audio_intervals)[1:]):
    assert a[1]<=b[0],('native Audio overlap',a[2],b[2])

paths=json.loads((s/'published-source-paths.json').read_text())
index=json.loads((s/'index-source-equality.json').read_text())
assert len(paths)==len(index)==15 and all(row['scoped_index_equal']for row in index)
assert sum(row['main_equal']for row in index)==12
for variant,root in [('main',main),('scoped',scope)]:
    for name,pin in json.loads((s/(variant+'-published-source-pins.json')).read_text()).items():
        data=(root/name).read_bytes();assert len(data)==pin['bytes']and sha(data)==pin['sha256'],(variant,name)
    initial=json.loads((s/(variant+'-initial-authority.json')).read_text())
    for name,pin in initial.items():
        if name not in paths:assert sha((root/name).read_bytes())==pin['sha256'],(variant,name)
for row in json.loads((s/'scoped-baseline-head-equality.json').read_text()):
    assert row['scoped_initial_matches_HEAD']
goldens=json.loads((s/'immutable-oracle-pins.json').read_text());assert len(goldens)==13
for row in goldens:
    for root in [main,scope]:assert sha((root/row['path']).read_bytes())==row['sha256'],row['path']
assert (s/'old-cached-policy-main.json').read_bytes()==(s/'old-cached-policy-scoped.json').read_bytes()
assert (s/'old-zero-main.json').read_bytes()==(s/'old-zero-scoped.json').read_bytes()
assert (s/'published-current-main.json').read_bytes()==(s/'published-current-scoped.json').read_bytes()==(s/'current-warm-main.json').read_bytes()

tests={}
expected={'storage-main-core':(816,0),'storage-main-plan':(199,9),
    'storage-scoped-core':(791,0),'storage-scoped-plan':(186,9),
    'published-main-lib':(389,6),'published-scoped-lib':(383,6),
    'final-main-stages':(203,0),'warm-scoped-stages':(203,0),
    'final-main-definition':(171,0),'final-scoped-definition':(171,0)}
for label,pair in expected.items():
    rows=re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;', (s/(label+'.stdout')).read_text())
    assert len(rows)==1 and (int(rows[0][0]),int(rows[0][2]))==pair and int(rows[0][1])==0,(label,rows)
    tests[label]={'passed':pair[0],'ignored':pair[1],'seconds':json.loads((s/(label+'.json')).read_text())['seconds']}
rows=re.findall(r'^test (general_split_sound::[\w:]+) \.\.\. (ok|FAILED)',(s/'fresh-split.stdout').read_text(),re.M)
assert len(rows)==7 and sum(state=='ok'for _,state in rows)==split_passed and sum(state=='FAILED'for _,state in rows)==split_failed,rows
observed=json.loads((s/'published-current-main.json').read_text())
counts=[]
for row in observed['reconciliation']+observed['zero_reconciliation']:
    counts.append({'context':row['context'],'name':row['name'],'intervals':row['intervals']})
for label in ['published-warm-main','published-warm-scoped']:
    assert 'AlreadyExists'in(s/(label+'.stdout')).read_text()
result={'all_terminal':True,'receipts':receipts,'expected_negative_results':negative,
    'source_paths':15,'all_scoped_index_equal':True,'main_also_equal':12,
    'immutable_oracles_unchanged':13,'baseline_existing_files_equal_HEAD':8,
    'initial_source_preservation':json.loads((s/'source-preservation-audit.json').read_text()),
    'tests':tests,'native_audio_suites_serial':True,'native_audio_intervals':len(audio_intervals),
    'post_suite_format_only':json.loads((s/'post-suite-format-source-proof.json').read_text()),
    'split':{'passed':split_passed,'failed':split_failed,'cases':rows,'seconds':json.loads((s/'fresh-split.json').read_text())['seconds']},
    'actual_work_reconciliation':counts,'published_source_patch_sha256':sha((s/'published-source.patch').read_bytes()),
    'current_observation_sha256':sha((s/'published-current-main.json').read_bytes()),
    'reviews':['review-storage-general.md','review-storage-failure.md','review-warm-general.md','review-warm-tests.md','review-warm-resources.md']}
for name in result['reviews']:assert (s/name).is_file(),name
(s/'final-audit.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({key:result[key]for key in ['all_terminal','source_paths','all_scoped_index_equal','tests','split','published_source_patch_sha256']}))
