from pathlib import Path

s=Path(__file__).resolve().parent
files=['crates/deadpan-audio/src/shared_eq.rs','crates/deadpan-audio/src/shared_eq/original_inputs.rs','crates/deadpan-audio/src/shared_eq/policy_prediction.rs']

def once(text, old, new):
    assert text.count(old)==1, (old[:100],text.count(old))
    return text.replace(old,new)

def cache(text):
    start=text.index('        control.check()?;',text.index('    fn shared_original_input_mode'))
    end=text.index('        if let Some(request) = &prepared {',start)
    validation=text[start:end].replace('count(&samples)?','count(samples)?')
    text=text[:start]+'''        let frames = self.validate_original_input_request(graph, context, &samples, control, depth)?;
'''+text[end:]
    start=text.index('        if let Some(slot) = graph.original_inputs.find(lookup, control)? {',text.index('    fn shared_original_input_mode'))
    end=text.index('        // Every context has one fixed private read mode.',start)
    text=text[:start]+'''        if let Some(slot) = graph.original_inputs.find(lookup, control)? {
            let key = cached_original_key(graph, slot, (context, &samples, depth))?;
            if let Some(cached) = self.original_inputs.get(&key) {
                return self
                    .admit_cached_original(provider, &cached.block, control, depth)
                    .map(Read::Cached);
            }
            graph.original_inputs.remove(slot, control)?;
        }
'''+text[end:]
    key_helper='''type CachedIdentity<'request, 'plan> = (
    &'request Context<'plan>,
    &'request Range<AudioSample>,
    usize,
);

fn cached_original_key<'plan>(
    graph: &mut Graph<'plan, '_>,
    slot: usize,
    (context, samples, depth): CachedIdentity<'_, 'plan>,
) -> Result<u64, StageAudioError> {
    let entry = graph.original_inputs.entries[slot]
        .as_ref()
        .expect("occupied cache slot");
    if entry.depth != depth
        || entry.samples != *samples
        || !same_context(&entry.context, context)
    {
        return Err(StageAudioError::ForeignDomain);
    }
    let key = entry.key;
    graph.original_inputs.touch(slot);
    Ok(key)
}

'''
    text=once(text,'fn resident(block: &ReadBlock) -> Option<u64> {',key_helper+'fn resident(block: &ReadBlock) -> Option<u64> {')
    methods='''    fn validate_original_input_request(
        &self,
        graph: &Graph<'_, '_>,
        context: &Context<'_>,
        samples: &Range<AudioSample>,
        control: WorkControl<'_>,
        depth: usize,
    ) -> Result<u32, StageAudioError> {
'''+validation+'''        Ok(frames)
    }

    fn admit_cached_original(
        &self,
        provider: &mut impl AudioSourceProvider,
        cached: &Arc<ReadBlock>,
        control: WorkControl<'_>,
        depth: usize,
    ) -> Result<Arc<ReadBlock>, StageAudioError> {
        let block = Arc::clone(cached);
        if depth
            .checked_add(block.relative_depth)
            .is_none_or(|depth| depth > self.limits.maximum_depth)
        {
            return Err(StageAudioError::Limit("nested stage depth"));
        }
        for (asset, fingerprint) in &block.dependencies {
            control.spend_plan_work(1)?;
            let source = resolve_source(provider, &self.plan, asset, control.cancelled)?;
            if control.observe(asset, source)? != *fingerprint {
                return Err(PreparationError::IndexMismatch.into());
            }
        }
        control.check()?;
        Ok(block)
    }

    fn original_prediction_reservation_fits(
        &self,
        additional: u64,
        control: WorkControl<'_>,
    ) -> Result<bool, StageAudioError> {
        let mut resident = 0_u64;
        let mut disk = 0_u64;
        for entry in &self.cache {
            // Inspect the required stage's two retained resource metrics.
            control.spend_plan_work(2)?;
            let Some(next_resident) = resident.checked_add(entry.block.samples.resident_frames()) else {
                return Ok(false);
            };
            let Some(next_disk) = disk.checked_add(entry.block.samples.disk_bytes()) else {
                return Ok(false);
            };
            resident = next_resident;
            disk = next_disk;
        }
        for cached in self.original_inputs.values() {
            control.spend_plan_work(1)?;
            let Some(next) = resident.checked_add(cached.resident) else {
                return Ok(false);
            };
            resident = next;
        }
        // Four resident additions and two disk additions, before pinning.
        control.spend_plan_work(6)?;
        let work = control.work.borrow();
        let resident = resident
            .checked_add(self.active_frames)
            .and_then(|frames| frames.checked_add(work.projected_resident_frames))
            .and_then(|frames| frames.checked_add(work.sound_context_frames))
            .and_then(|frames| frames.checked_add(additional));
        let disk = disk
            .checked_add(self.active_disk_bytes)
            .and_then(|bytes| bytes.checked_add(work.projected_disk_bytes));
        Ok(resident.is_some_and(|frames| frames <= u64::from(self.limits.maximum_resident_frames))
            && disk.is_some_and(|bytes| bytes <= self.limits.maximum_disk_bytes))
    }

    pub(super) fn try_cached_original_for_prediction<'plan, 'work>(
        &self,
        provider: &mut impl AudioSourceProvider,
        graph: &mut Graph<'plan, 'work>,
        context: &Context<'plan>,
        (samples, additional): (Range<AudioSample>, u64),
        control: WorkControl<'work>,
        depth: usize,
    ) -> Result<Option<Arc<ReadBlock>>, StageAudioError> {
        self.validate_original_input_request(graph, context, &samples, control, depth)?;
        if matches!(context, Context::Retained(_)) {
            return Ok(None);
        }
        let lookup = LookupKey::new(context, &samples, depth);
        let Some(slot) = graph.original_inputs.find(lookup, control)? else {
            return Ok(None);
        };
        let key = graph.original_inputs.entries[slot]
            .as_ref()
            .expect("occupied cache slot")
            .key;
        let Some(cached) = self.original_inputs.get(&key) else {
            // Preserve the late cold path's stale-key touch/removal boundary.
            return Ok(None);
        };
        if !self.original_prediction_reservation_fits(additional, control)? {
            return Ok(None);
        }
        // The complete no-eviction test precedes either pinning or media I/O.
        // Neither this validation/touch nor source admission changes residency.
        cached_original_key(graph, slot, (context, &samples, depth))?;
        self.admit_cached_original(provider, &cached.block, control, depth)
            .map(Some)
    }

'''
    return once(text,'impl StageAudio {\n    fn remove_original_input', 'impl StageAudio {\n'+methods+'    fn remove_original_input')

def shared(text):
    start=text.index('        let mut prepared_original = if predict && owners.is_some() && admitted(original_id) {')
    end=text.index('        self.make_room(reservation, false, control)?;',start)
    old=text[start:end]
    factory_start=old.index('            #[cfg(test)]')
    factory_end=old.index('        } else {\n            None\n        };')
    factory=old[factory_start:factory_end]
    # Add one nesting level without changing the cold query body.
    factory=''.join('    '+line if line.strip() else line for line in factory.splitlines(True))
    replacement='''        if predict {
            // Routes have not allocated policy or PCM. This only installs an
            // empty prediction carrier; the fallible query factories do not
            // inspect SharedMix. Its complete payload is still admitted below.
            mix.begin_prediction()?;
        }
        let reservation = u64::from(frames)
            .checked_mul(12)
            .and_then(|n| n.checked_add(mix.resident_frames().ok()?))
            .ok_or(StageAudioError::Limit("shared EQ mix PCM"));
        let mut cached_original = None;
        let mut prepared_original = if predict && owners.is_some() && admitted(original_id) {
            let count = count(&original_range)?;
            #[cfg(test)]
            let enabled = !cached_prediction_trace::legacy();
            #[cfg(not(test))]
            let enabled = true;
            if enabled && let Ok(additional) = &reservation {
                #[cfg(test)]
                let _probe_phase = cached_prediction_trace::ScopeGuard::new(
                    cached_prediction_trace::Phase::Probe,
                    control,
                );
                cached_original = self.try_cached_original_for_prediction(
                    provider,
                    graph,
                    &program.context.original,
                    (original_range.clone(), *additional),
                    control,
                    program.depth,
                )?;
            }
            if cached_original.is_none() {
'''+factory+'''            } else {
                None
            }
        } else {
            None
        };
        // Preserve the ordinary cold query-failure priority over admission.
        let mut reservation = reservation?;
'''
    text=text[:start]+replacement+text[end:]
    old='''                let original = match (&owners, &prepared_original) {
                    (Some(owners), Some(request)) => Some(policy_prediction::Original {
                        queries: request.queries(),
                        owners: owners.query(),
                        routes: &original_routes,
                        id: original_id,
                    }),
                    (None, _) => None,
                    (Some(_), None) if !admitted(original_id) => None,
'''
    new='''                let original = match (&owners, &prepared_original, &cached_original) {
                    (Some(owners), _, Some(block)) => Some(policy_prediction::Original {
                        policy: policy_prediction::OriginalPolicy::Cached(block),
                        owners: owners.query(),
                        routes: &original_routes,
                        id: original_id,
                    }),
                    (Some(owners), Some(request), None) => Some(policy_prediction::Original {
                        policy: policy_prediction::OriginalPolicy::Queries(request.queries()),
                        owners: owners.query(),
                        routes: &original_routes,
                        id: original_id,
                    }),
                    (None, _, _) => None,
                    (Some(_), None, None) if !admitted(original_id) => None,
'''
    text=once(text,old,new)
    text=once(text,'''                let raw = if let Some(request) = prepared_original.take() {
''','''                let raw = if let Some(block) = cached_original.take() {
                    original_inputs::Read::Cached(block)
                } else if let Some(request) = prepared_original.take() {
''')
    return text

def policy(text):
    text=once(text,'''pub(in crate::stages) struct Original<'a, 'plan> {
    pub(super) queries: RootReadQueriesRef<'a, 'plan>,
''','''pub(in crate::stages) enum OriginalPolicy<'a, 'plan> {
    Queries(RootReadQueriesRef<'a, 'plan>),
    Cached(&'a ReadBlock),
}

pub(in crate::stages) struct Original<'a, 'plan> {
    pub(super) policy: OriginalPolicy<'a, 'plan>,
''')
    start=text.index('        let samples = &original.queries.processing.samples;')
    end=text.index('    }\n    if inputs.roots.len()',start)
    cold=text[start:end]
    cold=cold.replace('let samples = &original.queries.processing.samples;', 'let samples = &queries.processing.samples;').replace('            original.queries,','            *queries,')
    cold=''.join('        '+line if line.strip()else line for line in cold.splitlines(True))
    warm='''            OriginalPolicy::Cached(block) => {
                control.spend_plan_work(1)?;
                let samples = original.owners.samples();
                let frames = count(&samples)? as usize;
                if block.start != samples.start || block.samples.len() != frames {
                    return Err(PlanError::InvalidPlan("cached Original prediction range differs").into());
                }
                // These are the exact successful outer read's policy masks,
                // not zero PCM or recursively inherited child suppression.
                for ranges in [&block.suppressed, &block.exhausted] {
                    policy_ranges::visit(
                        block.start,
                        frames,
                        ranges,
                        |sample| sample.0,
                        || control.spend_plan_work(1),
                        |mask, _| {
                            for (span, route) in original.owners.spans().iter().zip(original.routes) {
                                if let Some(route) = route {
                                    exclude(mix, route, &span.samples(), mask, control)?;
                                }
                            }
                            Ok(())
                        },
                    )?;
                }
            }
'''
    text=text[:start]+'''        match &original.policy {
            OriginalPolicy::Queries(queries) => {
'''+cold+'''            }
'''+warm+'''        }
'''+text[end:]
    return text

for variant in ['main','scoped']:
    for rel,transform in zip(files,[shared,cache,policy]):
        before=s/'warm-before'/variant/rel
        target=s/'warm-candidate'/variant/rel
        target.write_text(transform(before.read_text()))
print('scratch candidate transformations complete')
