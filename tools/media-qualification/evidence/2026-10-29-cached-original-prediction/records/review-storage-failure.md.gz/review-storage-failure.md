# Storage failure and closure review

Scope: `crates/deadpan-core/src/sound_route.rs`, `crates/deadpan-plan/src/lib.rs`, `crates/deadpan-plan/src/audio_allocated.rs`, `crates/deadpan-plan/src/audio_allocated/query_storage.rs`, and `crates/deadpan-plan/src/audio_allocated/query_storage_tests.rs`, compared with `8c81a8d0dec1961348e6a0e88e87219602dd69b`.

No material findings for the assigned lens.

The new measurement wrappers preserve the legacy successful `(bytes, work)` results while making prior successful debits available after failure. `HeapBudget::core_route` spends the nested route's reported debit before mapping its error, so a nested refusal cannot erase already-debited traversal work. Nested route traversal similarly reports `maximum_work - remaining`; failed bulk debits do not consume allowance.

The retained-heap closure covers flat span boundaries and retimes, fade span/edge/origin vectors, scalar policy labels, processing `Bound` and `ProjectedStage` content, and the associated owning identity/path storage. The ignored boundary fields are inline (`placement_support: bool`, `AudioEdgePolicy`), so they add no heap closure.

Tests exercise nested route refusal prefixes, delegated Core route debit propagation, byte-overflow and depth failures, exact-budget success, spare capacity, projection storage, and legacy API equivalence. No tests or source changes were made during this review.
