# Scratch-only cached policy adapter tests

Intended integration: copy cached_policy_tests.rs to shared_eq/cached_policy_tests.rs in both Main/Scope, then declare it as a child of shared_eq/policy_prediction_tests.rs with #[path = "cached_policy_tests.rs"] mod cached_policy_tests. Parent owns integration/wiring and execution. This worker changed no repository source and ran no Cargo/native/Git command.

Requires candidate policy API:
Original { policy: OriginalPolicy::{Cached(&ReadBlock), Queries(RootReadQueriesRef)}, owners, routes, id }.
The adapter source consulted is warm-candidate/main/crates/deadpan-audio/src/shared_eq/policy_prediction.rs, whose Cached branch validates the exact owner-query range/sample length and visits both typed mask vectors through policy_ranges::visit.

Four focused tests:
1. Actual WAV-backed raw input and owner query, then narrowly altered start or sample count: expects exact cached-range InvalidPlan rejection. Each suppressed/exhausted vector independently receives a valid preceding interval plus negative-start, past-end, empty, reversed or extreme-overflow interval: expects typed Range rejection. Partial prediction rows are discarded on error; no rollback guarantee is invented.
2. Literal independent expected union for overlapping/adjacent/duplicate suppressed intervals, plus an independently clearing exhausted interval. Runs exhaustion-only too. Verifies real SharedMix predicted-versus-observed rows, exact f64 output and merged final suppression.
3. Uses actual selected-placement audio binding and a real owner query spanning Active/Inactive support. The test asserts both actual support kinds exist. It clears only raw exclusions in this private fixture so ignoring current support cannot accidentally pass because cached exhaustion duplicates the same exclusion. Selection=false and selection=true observations derive independently from current owner support. This mutated block is not claimed admissible through the production cache/source boundary.
4. Demonstrates the exact shared-mask verification limit: a well-formed but wrong private mask plus matching numeric observations passes the warm adapter's comparison. The independently prepared original queries reject those identical corrupted observations with contribution-permission mismatch. This is an explicit bounded limitation, not a promise to detect authenticated-mask corruption in the warm path.

All owner clocks, routes and SharedMix allocations use actual existing APIs and the real WAV provider; required mix storage is admitted via actual resident_frames/make_room. No synthetic ledger assignments, dummy reservations, global allocator infrastructure or fabricated source admission.

The numerical-zero/permitted-policy case is already covered separately by the frozen zero Source supplement; it is not duplicated here. These are adapter unit perturbations, not new claims that arbitrary ReadBlocks are runtime cache candidates.

Targeted rustfmt completed and entire scratch module reviewed. Native assertions, including selected-placement Active/Inactive coverage, remain unexecuted until parent integration. Source pin: cached_policy_tests-pins.json.
