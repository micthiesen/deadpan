# Plan query storage measurement implementation

Edits are terminal/frozen in Main and Scope. Three owned paths only: audio_allocated.rs, audio_allocated/query_storage.rs and audio_allocated/query_storage_tests.rs. Both variants are byte-identical. Exact patches, copies and source pins are plan-storage-{main,scoped}.patch, plan-storage-after/ and plan-storage-source-pins.json.

AudioStorageMeasurement has private result/work fields, work() and into_parts() -> (Result<usize, PlanError>, usize). measure_allocated_storage(maximum_work) is available on AudioQuery, AudioProcessingQuery, AudioFadeQuery and policy queries with exactly AudioSample or SignalSample labels. Parent owns the root lib.rs reexport.

New exhaustive OwnedHeap closures cover flattened span boundaries/origins, complete repeat paths and optional gap IDs, retimes and owned content; complete fade span/edge/origin vectors; both scalar policy-label buffers and owned content. Existing processing Bound/Projected/Box/Arc closures are reused. Real capacities and owning identity allocations are charged; shared Arcs are conservatively charged per owning edge. Inline query handles, borrowed RenderPlan storage, allocator-private rounding and construction transient peak are excluded.

The shared observation helper retains HeapBudget.remaining even when a visitor fails. Failed bulk precharge leaves that debit unapplied, exactly as before; successful debits before overflow/depth/child failure are retained. Legacy measure/allocated_bytes_bound delegates to the observed helper and returns the same success tuple or prior Plan error.

The only delegated heap-inspection seam found was HeapBudget::core_route. It now calls the parent's confirmed Core SoundRoute::measure_allocated_storage and debits the returned successful Core work before propagating a failure mapped to the previous retained-sound-route error label. No unused allowance is charged. Parent must supply the confirmed Core seam before compilation; no Core source was edited by this worker.

Six tests cover actual compiled flattened/processing/policy/fade products and immutability; every nested vector capacity class and unused-capacity work stability; repeated shared identity edges and both policy labels; nested independent Preserve projections against legacy successful bounds and all short work limits; actual Core route partial failure debits; and byte/depth failures after successful debits.

Tests:
- actual_root_query_products_measure_all_owned_storage_without_mutating_fields
- flattened_boundaries_retimes_and_fade_origins_charge_actual_spare_capacity
- policy_sample_labels_have_complete_scalar_storage_and_shared_identity_bounds
- projected_processing_observation_keeps_legacy_bounds_and_every_failure_debit
- failed_core_route_inspection_keeps_its_actual_partial_debits
- byte_and_depth_refusals_report_actual_successful_debits

Targeted rustfmt --edition 2024 --config skip_children=true ran on all three Main paths; identical formatted copies were written to Scope. Entire owned production diff and test source were reviewed. No Cargo, compiler/native test execution, Git, or external write ran. Parent owns execution and publication. No further source writes are planned without parent follow-up.
