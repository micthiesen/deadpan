from pathlib import Path
import gzip,hashlib,json

s=Path(__file__).resolve().parent
repo=Path('/Users/michael/Code/deadpan')
dest=repo/'tools/media-qualification/evidence/2026-10-29-cached-original-prediction'
assert not dest.exists()
audit=json.loads((s/'final-audit.json').read_text());assert audit['all_terminal']
prior=repo/'tools/media-qualification/evidence/2026-10-29-original-input-cache/inventory.json'
prior_sha='d7346f8f1dcc8a5af850f133624276ac7362959e7a7a28adc719d1cd16b193a5'
assert hashlib.sha256(prior.read_bytes()).hexdigest()==prior_sha
rows=[]
allowed={'.rs','.json','.py','.md','.patch','.stdout','.stderr','.txt','.sha256','.toml'}
for p in sorted(s.rglob('*')):
    if not p.is_file()or p.suffix not in allowed:continue
    rel=p.relative_to(s)
    if rel.name in {'qualification-draft.md','published-evidence.json'}:continue
    data=p.read_bytes()
    if p.suffix=='.json':
        obj=json.loads(data)
        if isinstance(obj,dict)and 'command'in obj and 'started_at'in obj:
            assert 'exit_code'in obj and obj['sources_unchanged']and obj['binaries_unchanged'],str(p)
    target=(dest/'records'/rel).with_name(rel.name+'.gz');target.parent.mkdir(parents=True,exist_ok=True)
    packed=gzip.compress(data,mtime=0);target.write_bytes(packed)
    rows.append({'path':str(target.relative_to(dest)),'bytes':len(packed),'sha256':hashlib.sha256(packed).hexdigest(),
        'expanded_bytes':len(data),'expanded_sha256':hashlib.sha256(data).hexdigest()})
manifest={'schema_version':1,'base_revision':(s/'base-revision.txt').read_text().strip(),
    'scope':'Warm exact Root/Domain Original policy prediction from already admitted successful private PCM masks, same Arc for numeric read, full no-eviction future-reservation precheck and fresh source/depth/cancel admission. Actual old/current native witnesses and work reconciliation. Separate Core/Plan final-storage measurement observers retain failed inspection debits without claiming construction admission. General Split stays disabled; no requirement or gate closes.',
    'prior_cache_inventory':{'path':'../2026-10-29-original-input-cache/inventory.json','sha256':prior_sha},
    'exclusions':'Executables and entire filesystem copies excluded; exact assigned before/after sources, published/index source, patch, source/executable/stream hashes, raw failed/passing receipts and independent review reports retained. Ordinary native suites precede a cfg(test)-only module reorder; final units, strict checks, actual current captures and fresh Split use final formatted source. See post-suite-format-source-proof.json.',
    'files':rows}
p=dest/'inventory.json';p.write_text(json.dumps(manifest,indent=2)+'\n')
for row in rows:
    packed=(dest/row['path']).read_bytes();plain=gzip.decompress(packed)
    assert len(packed)==row['bytes']and hashlib.sha256(packed).hexdigest()==row['sha256']
    assert len(plain)==row['expanded_bytes']and hashlib.sha256(plain).hexdigest()==row['expanded_sha256']
result={'files':len(rows),'stored_bytes':sum(row['bytes']for row in rows),'expanded_bytes':sum(row['expanded_bytes']for row in rows),
    'inventory_sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
(s/'published-evidence.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result))
