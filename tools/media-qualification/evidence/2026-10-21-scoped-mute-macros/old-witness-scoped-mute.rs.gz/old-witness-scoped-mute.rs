//! An explicit whole-owner mute state follows the invocation's chosen Play.
use super::*;

fn mute(muted: bool) -> SemanticInstruction {
    SemanticInstruction::SetAudio {
        change: AudioChange::Mute { muted },
    }
}

fn muted(document: &ProjectDocument, context: &SemanticContext) -> bool {
    document.nodes()[&context.scoped.as_ref().unwrap().target.node]
        .audio_treatments
        .clip_gain()
        .is_some_and(|clip| clip.muted())
}

fn seeded(muted: bool) -> ProjectDocument {
    let mut document = fixture();
    let local = crate::GainRange::new(ExactRatio::ZERO, ExactRatio::integer(4)).unwrap();
    let envelope = crate::GainEnvelope::new(
        crate::GainClock::OwnerOutput,
        local,
        crate::GainDb::new(-3000).unwrap(),
        vec![
            crate::GainSegment::new(
                local.end(),
                crate::GainDb::new(3000).unwrap(),
                crate::GainCurve::Linear,
            )
            .unwrap(),
        ],
    )
    .unwrap();
    let clip = crate::ClipGain::new(
        crate::GainDb::new(6000).unwrap(),
        muted,
        vec![envelope],
        vec![crate::GainRange::new(ExactRatio::ONE, ExactRatio::integer(2)).unwrap()],
    )
    .unwrap();
    document.nodes.get_mut(&node("a")).unwrap().audio_treatments =
        crate::AudioTreatments::default()
            .with_clip_gain(clip)
            .unwrap()
            .with_saturation(Some(
                crate::Saturation::new(crate::GainDb::new(9000).unwrap()).unwrap(),
            ))
            .unwrap();
    document.validate().unwrap();
    document
}

#[test]
fn scoped_mute_true_isolates_one_nested_play_and_preserves_gain_curves_order_with_exact_pools() {
    let before = seeded(false);
    let context = entry();
    let target = &context.scoped.as_ref().unwrap().target;
    let expected = AudioChange::Mute { muted: true }
        .apply(&before.nodes()[&target.node].audio_treatments)
        .unwrap();
    let needs = before
        .scoped_edit_requirements(
            target,
            &crate::ScopedNodeEdit::SetAudioTreatments {
                treatments: expected.clone(),
            },
        )
        .unwrap();
    assert_eq!((needs.nodes, needs.marks), (10, 2));
    assert!(!muted(&before, &context));
    let snapshot = before.to_json().unwrap();
    let mut allocations = Vec::new();
    let changed = resolve(
        &before,
        &context,
        vec![mute(true)],
        &BTreeMap::new(),
        |request| {
            allocations.push(request.clone());
            allocator("mute", request)
        },
    )
    .expect("one explicit nested Play must admit whole-owner mute intent");
    assert_eq!(
        allocations,
        vec![SemanticAllocationRequest::Isolation {
            step_index: 0,
            nodes: needs.nodes,
            marks: needs.marks,
        }]
    );
    assert_context(&context, &changed.context);
    let mapped = changed.context.scoped.as_ref().unwrap();
    assert!(
        mapped
            .target
            .matches_instance(&changed.document, &mapped.presentation)
            .unwrap()
    );
    assert_eq!(
        changed.document.nodes()[&mapped.target.node].audio_treatments,
        expected
    );
    for (owner, authored) in changed.document.nodes() {
        assert_eq!(
            authored
                .audio_treatments
                .clip_gain()
                .is_some_and(|clip| clip.muted()),
            owner == &mapped.target.node
        );
    }
    assert_eq!(
        changed.document.nodes()[&node("a")],
        before.nodes()[&node("a")]
    );
    assert_eq!(
        changed.document.duration().unwrap(),
        before.duration().unwrap()
    );
    assert_eq!(before.to_json().unwrap(), snapshot);
    assert_reversible(&before, &changed);
}
