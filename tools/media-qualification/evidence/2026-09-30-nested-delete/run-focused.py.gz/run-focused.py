import os
from pathlib import Path
import subprocess
import sys

scratch = Path('/tmp/deadpan-nested-delete-20260930')
runner = 'tools/media-qualification/evidence/2026-09-29-generated-pictures/run-native.py'
environment = dict(os.environ, DEADPAN_CHECK_OUTPUT=str(scratch))
checks = [
    ('core-delete-final', ['-p', 'deadpan-core', '--test', 'insert_time', 'delete_range']),
    ('plan-delete-final', ['-p', 'deadpan-plan', '--test', 'edited_slice', 'delete_range']),
    ('audio-delete-final', ['-p', 'deadpan-audio', '--test', 'composite_insert', 'delete_range::nested_partition']),
]
for label, args in checks:
    result = subprocess.run([sys.executable, runner, label, 'rustup', 'run', '1.97.1', 'cargo', 'test', '--locked', *args], env=environment)
    if result.returncode:
        sys.exit(result.returncode)
