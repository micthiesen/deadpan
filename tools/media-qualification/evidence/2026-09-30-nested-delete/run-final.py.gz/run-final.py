import os
from pathlib import Path
import subprocess
import sys

scratch = Path('/tmp/deadpan-nested-delete-20260930')
runner = 'tools/media-qualification/evidence/2026-09-29-generated-pictures/run-native.py'
environment = dict(os.environ, DEADPAN_CHECK_OUTPUT=str(scratch))
checks = [
    ('fmt-final', ['fmt', '--all', '--', '--check']),
    ('clippy-final', ['clippy', '--workspace', '--all-targets', '--features', 'deadpan-app/ui-harness', '--locked', '--', '-D', 'warnings']),
    ('workspace-final', ['test', '--workspace', '--locked', '--no-fail-fast']),
]
for label, args in checks:
    result = subprocess.run([sys.executable, runner, label, 'rustup', 'run', '1.97.1', 'cargo', *args], env=environment)
    if result.returncode:
        sys.exit(result.returncode)
