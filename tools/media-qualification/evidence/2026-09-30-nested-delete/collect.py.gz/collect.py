import gzip
import hashlib
import json
from pathlib import Path
import re
import shutil
import subprocess

scratch = Path('/tmp/deadpan-nested-delete-20260930')
target = Path('tools/media-qualification/evidence/2026-09-30-nested-delete')
target.mkdir(parents=True, exist_ok=True)
labels = [
    'core-delete-initial', 'app-delete-initial', 'core-delete-final',
    'plan-delete-final', 'audio-delete-final', 'old-admission-witness',
    'audio-delete-corrected', 'plan-delete-unframed',
    'fmt-final', 'clippy-final', 'workspace-final',
]
checks = {}
manifests = set()
for label in labels:
    metadata = json.loads((scratch / (label + '.json')).read_text())
    expected = 101 if label in ('core-delete-initial', 'audio-delete-final', 'old-admission-witness') else 0
    assert metadata['exit_code'] == expected, (label, metadata)
    log = (scratch / (label + '.log')).read_bytes()
    counts = re.findall(r'test result: \w+\. (\d+) passed; (\d+) failed; (\d+) ignored;', log.decode())
    metadata['test_totals'] = {
        name: sum(int(row[index]) for row in counts)
        for index, name in enumerate(('passed', 'failed', 'ignored'))
    }
    checks[label] = metadata
    manifests.add(metadata['source_manifest_sha256'])
    shutil.copy2(scratch / (label + '.json'), target / (label + '.json'))
    (target / (label + '.log.gz')).write_bytes(gzip.compress(log, mtime=0))
for manifest in sorted(manifests):
    name = 'source-' + manifest + '.json'
    wire = (scratch / name).read_bytes()
    assert hashlib.sha256(wire).hexdigest() == manifest
    (target / (name + '.gz')).write_bytes(gzip.compress(wire, mtime=0))
final_source = checks['workspace-final']['source_manifest_sha256']
for label in ('fmt-final', 'clippy-final', 'audio-delete-corrected', 'plan-delete-unframed'):
    assert checks[label]['source_manifest_sha256'] == final_source, label
inputs = json.loads((scratch / ('source-' + final_source + '.json')).read_text())
for name, checksum in inputs.items():
    assert Path(name).is_file(), name
    assert hashlib.sha256(Path(name).read_bytes()).hexdigest() == checksum, name
paths = subprocess.check_output(['git', 'ls-files', '--cached', '--others', '--exclude-standard', '-z']).decode().split('\0')
current_names = {name for name in paths if name and Path(name).is_file() and
                 (Path(name).suffix in ('.rs', '.toml', '.lock', '.cpp', '.h', '.hpp', '.c', '.m', '.py') or name.startswith(('.cargo/', 'crates/', 'native/')))}
assert current_names == set(inputs), sorted(current_names.symmetric_difference(inputs))
assert checks['workspace-final']['test_totals']['failed'] == 0
assert checks['workspace-final']['test_totals']['ignored'] == 0
for name in ('core-report.md', 'media-report.md', 'review.md', 'baseline-input.json', 'environment.json'):
    shutil.copy2(scratch / name, target / name)
for name in ('prepare-baseline.py', 'run-focused.py', 'run-final.py', 'collect.py'):
    (target / (name + '.gz')).write_bytes(gzip.compress((scratch / name).read_bytes(), mtime=0))
runner = Path('tools/media-qualification/evidence/2026-09-29-generated-pictures/run-native.py')
(target / 'run-native.py.gz').write_bytes(gzip.compress(runner.read_bytes(), mtime=0))
baseline = scratch / 'baseline'
baseline_input = json.loads((scratch / 'baseline-input.json').read_text())
for name, checksum in baseline_input['old_production_sha256'].items():
    assert hashlib.sha256((baseline / name).read_bytes()).hexdigest() == checksum, name
baseline_test = 'crates/deadpan-core/tests/insert_time/delete_range/nested_partitions.rs'
assert hashlib.sha256((baseline / baseline_test).read_bytes()).hexdigest() == baseline_input['new_regression_sha256']
snapshot_names = (
    'crates/deadpan-core/src/insert_time/delete_range.rs',
    'crates/deadpan-core/src/insert_time/sequence_range.rs',
    'crates/deadpan-core/tests/insert_time/delete_range.rs',
    'crates/deadpan-core/tests/insert_time/delete_range/nested_partitions.rs',
)
for name in snapshot_names:
    output = target / 'baseline' / (name + '.gz')
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_bytes(gzip.compress((baseline / name).read_bytes(), mtime=0))
summary = {
    'checks': checks,
    'final_source_manifest_sha256': final_source,
    'final_source_inputs_rechecked': len(inputs),
    'baseline': 'old-admission-witness intentionally fails using isolated HEAD production with the new untreated-chain regression; baseline-input.json and baseline/ retain exact inputs.',
    'early_runs': 'core-delete-initial and audio-delete-final failed new test fixtures/oracles; corrected runs pass. plan-delete-final predates final unframed variants; plan-delete-unframed and workspace-final cover them. app-delete-initial predates only subsequent test changes in other crates.',
    'review': 'Independent static review: no findings; root reviewed media oracles and complete diff.',
    'native_app': 'Agent-owned dev.thiesen.deadpan.cursor-qa quit through native UI; native app inventory returned no Deadpan apps. No new native UI/paint/device qualification.',
}
(target / 'summary.json').write_text(json.dumps(summary, indent=2) + '\n')
manifest = {str(path.relative_to(target)): hashlib.sha256(path.read_bytes()).hexdigest()
            for path in sorted(target.rglob('*')) if path.is_file() and path.name != 'SHA256SUMS.json'}
(target / 'SHA256SUMS.json').write_text(json.dumps(manifest, indent=2) + '\n')
print(json.dumps({'checks': {key: value['test_totals'] for key, value in checks.items()},
                  'source': final_source, 'rechecked': len(inputs), 'files': len(manifest)}, indent=2))
