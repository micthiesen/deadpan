import hashlib
import json
from pathlib import Path
import shutil
import subprocess

repo = Path.cwd()
scratch = Path('/tmp/deadpan-nested-delete-20260930')
target = scratch / 'baseline'
target.mkdir(exist_ok=False)
for directory in ('crates', 'native', '.cargo'):
    shutil.copytree(repo / directory, target / directory)
for name in ('Cargo.toml', 'Cargo.lock', 'rust-toolchain.toml'):
    shutil.copy2(repo / name, target / name)
reverted = {}
for name in (
    'crates/deadpan-core/src/insert_time/delete_range.rs',
    'crates/deadpan-core/src/insert_time/sequence_range.rs',
):
    content = subprocess.check_output(['git', 'show', 'HEAD:' + name])
    (target / name).write_bytes(content)
    reverted[name] = hashlib.sha256(content).hexdigest()
test = 'crates/deadpan-core/tests/insert_time/delete_range/nested_partitions.rs'
report = {
    'base_commit': subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip(),
    'workspace': str(target),
    'old_production_sha256': reverted,
    'new_regression_sha256': hashlib.sha256((target / test).read_bytes()).hexdigest(),
    'selection': 'delete_range::nested_partitions::two_and_three_windows_split_one_child_with_exact_pools_and_full_context',
    'expected': 'Failure in range_deletion preflight before mutation; shared checkout untouched.',
}
(scratch / 'baseline-input.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps(report))
