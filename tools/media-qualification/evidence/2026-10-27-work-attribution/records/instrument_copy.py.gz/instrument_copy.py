from pathlib import Path
import json,hashlib,difflib
S=Path('/tmp/deadpan-placement-profile-2026-10-27');SOURCE=S/'source';relative='crates/deadpan-audio/src/stages.rs';p=SOURCE/relative
base=json.loads((S/'base-input-pins.json').read_text())
def pin(p):
 b=p.read_bytes();return {'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
assert pin(p)==base[relative], 'refuse to instrument different source'
original=p.read_text();(S/'stages.before.rs').write_bytes(p.read_bytes())
old='''#[derive(Default)]
struct ReadWork {
    prepared_stages: u32,'''
new='''#[derive(Default)]
struct ReadWork {
    work_trace: PlanWorkTrace,
    prepared_stages: u32,'''
assert original.count(old)==1
updated=original.replace(old,new)
anchor='''const MAX_PLAN_WORK_PER_READ: usize = 16 * 1024 * 1024;'''
assert updated.count(anchor)==1
updated=updated.replace(anchor,(S/'trace-types.rs').read_text()+'\n'+anchor)
old='''    fn spend_plan_work(self, amount: usize) -> Result<(), StageAudioError> {
        self.check()?;
        let mut work = self.work.borrow_mut();
        let cache = work.cache_key_scopes > 0;
        let spent = if cache {
            &mut work.cache_plan_work
        } else {
            &mut work.plan_work
        };
        *spent = spent
            .checked_add(amount)
            .filter(|total| *total <= MAX_PLAN_WORK_PER_READ)
            .ok_or(StageAudioError::Limit(if cache {
                CACHE_KEY_WORK_LIMIT
            } else {
                "plan work per read"
            }))?;
        Ok(())
    }
'''
new='''    #[track_caller]
    fn spend_plan_work(self, amount: usize) -> Result<(), StageAudioError> {
        self.check()?;
        let mut work = self.work.borrow_mut();
        let cache = work.cache_key_scopes > 0;
        let before = if cache { work.cache_plan_work } else { work.plan_work };
        let next = before
            .checked_add(amount)
            .filter(|total| *total <= MAX_PLAN_WORK_PER_READ);
        let canonical = work.plan_work;
        let optional = work.cache_plan_work;
        work.work_trace.record(
            std::panic::Location::caller(), cache, amount, next, canonical, optional,
        );
        if !cache && next.is_none() {
            work.work_trace.dump("canonical-spend-limit");
        }
        let spent = if cache {
            &mut work.cache_plan_work
        } else {
            &mut work.plan_work
        };
        *spent = next.ok_or(StageAudioError::Limit(if cache {
            CACHE_KEY_WORK_LIMIT
        } else {
            "plan work per read"
        }))?;
        Ok(())
    }
'''
assert updated.count(old)==1,'spend anchor mismatch'
updated=updated.replace(old,new)
p.write_text(updated)
(S/'diagnostic-unformatted.patch').write_text(''.join(difflib.unified_diff(original.splitlines(True),updated.splitlines(True),fromfile='a/'+relative,tofile='b/'+relative)))
print('instrumented copied stages.rs only')
