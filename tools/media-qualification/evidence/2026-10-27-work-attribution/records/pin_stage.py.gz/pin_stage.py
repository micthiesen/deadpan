"""Select one executed integration target from Cargo JSON, then freeze bytes."""
from pathlib import Path
import hashlib
import json
import shutil

s = Path(__file__).resolve().parent
receipt = json.loads((s / 'build.json').read_text())
assert receipt['exit_code'] == 0 and receipt['sources_unchanged']
artifacts = []
for line in (s / 'build.stdout').read_text().splitlines():
    try:
        row = json.loads(line)
    except json.JSONDecodeError:
        continue
    if (row.get('reason') == 'compiler-artifact'
            and row.get('target', {}).get('name') == 'stages'
            and row.get('target', {}).get('kind') == ['test']
            and row.get('executable')):
        artifacts.append(row)
assert len(artifacts) == 1, len(artifacts)
row = artifacts[0]
assert 'deadpan-audio' in row['package_id']
original = Path(row['executable'])
out = s / 'profile-stages'
assert not out.exists()
shutil.copy2(original, out)
source_bytes = original.read_bytes()
assert source_bytes == out.read_bytes()
pin = {'path': str(out), 'bytes': len(source_bytes),
       'sha256': hashlib.sha256(source_bytes).hexdigest(),
       'cargo_artifact': row}
(s / 'profile-stage-pin.json').write_text(json.dumps(pin, indent=2) + '\n')
print(json.dumps({k: pin[k] for k in ('path', 'bytes', 'sha256')}))
