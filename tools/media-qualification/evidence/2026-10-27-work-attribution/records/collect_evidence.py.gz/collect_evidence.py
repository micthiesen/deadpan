from pathlib import Path
import gzip, hashlib, json
s=Path(__file__).resolve().parent
dest=Path('/Users/michael/Code/deadpan/tools/media-qualification/evidence/2026-10-27-work-attribution')
assert not dest.exists(), 'refuse evidence overwrite'
dest.mkdir(parents=True)
files=[]
for p in sorted(s.iterdir()):
 if not p.is_file() or p.suffix not in {'.json','.py','.md','.patch','.rs','.stdout','.stderr'}:continue
 data=p.read_bytes();compressed=gzip.compress(data,mtime=0)
 out=dest/'records'/(p.name+'.gz');out.parent.mkdir(parents=True,exist_ok=True);out.write_bytes(compressed)
 files.append(dict(path=str(out.relative_to(dest)),bytes=len(compressed),sha256=hashlib.sha256(compressed).hexdigest(),expanded_bytes=len(data),expanded_sha256=hashlib.sha256(data).hexdigest()))
inventory=dict(schema_version=1,base_revision='cf796605',scope='Copied-runtime diagnostic attribution of three unchanged general-Split failures after checked placement-history reuse. One copied stages.rs overlay; canonical and optional charges separate, no caps or PCM semantics changed. Timings and diagnostic heap are not product acceptance.',runtime_baseline_evidence=dict(path='../2026-10-27-placement-history/inventory.json',inventory_sha256='eca10101cd2e52057a24268f725d5700877dce9ece008d1407a35131279930ac',note='Full prior candidate reconstruction plus placement overlay and all guarded runtime pins; full tracked workspace is cf796605. Copy additionally pins 5,279 workspace/config/fixture inputs. No repeated source tree or executable archive.'),files=files)
out=dest/'inventory.json';out.write_text(json.dumps(inventory,indent=2)+'\n')
for row in files:
 data=(dest/row['path']).read_bytes();expanded=gzip.decompress(data)
 assert len(data)==row['bytes'] and hashlib.sha256(data).hexdigest()==row['sha256']
 assert len(expanded)==row['expanded_bytes'] and hashlib.sha256(expanded).hexdigest()==row['expanded_sha256']
print(json.dumps(dict(payloads=len(files),stored_bytes=sum(r['bytes'] for r in files),expanded_bytes=sum(r['expanded_bytes'] for r in files),inventory_sha256=hashlib.sha256(out.read_bytes()).hexdigest()),indent=2))
