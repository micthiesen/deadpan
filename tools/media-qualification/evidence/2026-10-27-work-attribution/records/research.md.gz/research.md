# Bounded charge attribution after placement reuse

Read-only research, 2026-10-27. No main source changes, copied-runtime patch, compiler or test execution by this agent. The current placement milestone's final matrix was still running when this note was written. Parent reports three terminal failures: all-owner `cut-three`, limited `0+511`, canonical plan-work Limit; selected `prefix-two`, limited `0+4096`, same Limit; nested `prefix-two`, limited `0+4096`, child Plan `AudioQueryLimit("sound plan binding work")`. These are parent-reported current results, not new measurements here.

## Exact source facts

- `crates/deadpan-audio/src/stages.rs:448-470`: `ReadWork` owns canonical `plan_work`, independent optional `cache_plan_work`, and `cache_key_scopes`. New/default requests start both ledgers at zero. Production writes to these counters are confined to `spend_plan_work`; the other direct assignments found by rg are tests.
- `stages.rs:472`: canonical and optional per-read ceilings are each `16 * 1024 * 1024` **work units** (16,777,216). They are not bytes or a 1M allowance.
- `stages.rs:542-559`: `spend_plan_work` first checks the existing cancellation/deadline, chooses the optional ledger iff `cache_key_scopes > 0`, and accepts `before.checked_add(amount)` only if <= the existing ceiling. Failure leaves the old counter unchanged and returns either `Limit("plan work per read")` or `Limit("saved audio key work per read")`.
- `stages.rs:562-586`: `query_limits` checks the same cancellation/deadline first and limits the next query to the remaining canonical allowance. AudioQueryLimits default/max is 65,536. Optional key work instead refuses before shrinking its ordinary query allowance (`remaining < 65,536`). This deliberately classifies optional exhaustion separately.
- A child Core/Plan query may refuse a diminished canonical allowance before returning its `work`; then no spend occurs at that site. A profiler triggered only by failed `spend_plan_work` cannot report that nested failure. Its successful charge histogram also cannot claim to include internal visits in that failed child query.
- `PreparationBudget` (`stages.rs:483-519`) owns one ReadWork/one deadline across bus halos and cache checks. Other public preparation entrypoints also create local `RefCell<ReadWork>`. Per-ReadWork state therefore supplies the actual request boundary without thread-local pointer/deadline heuristics or retained request maps.
- There are 123 textual `spend_plan_work(` lines under Audio src at inspection, including its definition and test uses. 256 diagnostic bins are ample for the current static sites, but overflow must still be explicit rather than silently dropped.
- New placement cursor charges converge at `sound_clocks.rs:200`, so that exact site contains several cursor query phases. A call-site histogram is not an internal Plan phase profiler. Historical construction remains `sound_clocks.rs:242`; current full batch construction is `:267`; planning-only support discovery is `:300`; afterbirth validation is billed at `beat_sounds.rs:193`. Constant transfer/block checks remain real source sites in `shared_components.rs` and `shared_components/block.rs`.

## Preferred diagnostic patch, copied runtime only

Make a new source copy at `/tmp/deadpan-placement-profile-2026-10-27/source` and separate target at `/tmp/deadpan-placement-profile-2026-10-27/target`. Do not modify or restore main checkout files. Copy the actual frozen working files, including untracked modules; a Git archive of HEAD is insufficient. Copy workspace manifests/member trees, native sources/build inputs and `.cargo/config.toml`, Cargo.lock and rust-toolchain.toml so Cargo resolves every workspace member. Exclude `.git`, target, prior evidence executables and agent state. Do not rewrite workspace membership/dependencies merely to shrink the copy.

Only copied `crates/deadpan-audio/src/stages.rs` needs a diagnostic source change:

1. Add private `PlanWorkTrace` to ReadWork. Prefer one lazily allocated **fixed** boxed 256-bin open-address table, keyed by `(cache, caller.file(), caller.line(), caller.column())`, with static borrowed source labels, accepted call count/units and two explicit overflow buckets (canonical/optional). Hash line/column plus cache and compare exact static file strings; no per-call strings, stack backtraces, dynamic maps, eviction or sorting. A single bin array is shared by the two ledger categories. Initialize on the first spend, not at every ReadWork construction, to avoid allocation on unused reads. Document the measured diagnostic allocation/struct size; this is bounded diagnostic overhead, not production residency. A fixed inline table is also bounded but adds its entire stack footprint to every ReadWork; do not call that free.
2. Mark `spend_plan_work` `#[track_caller]`. Keep `self.check()` in exactly its original position and preserve the exact original checked_add/filter/ledger assignment and error strings. Compute the same `next` once if needed to record only **accepted** units. Attribute accepted work to the selected category. If `next` is None, record the refused caller/amount separately; do not include refused amount in accepted totals or write it to the budget. Use saturating diagnostic call counters with explicit overflow flag; accepted units cannot overflow usize because each real ledger is capped.
3. Dump on a **canonical** failed spend only, then mark dumped. Do not dump merely because optional-key allowance refuses, and never merge optional units into canonical totals. Include optional accepted totals/refusal counts as a separately labelled diagnostic field. The renderer must still return its original failure even if diagnostic output fails; avoid profiling asserts that replace the observed error.
4. Also implement a narrow diagnostic ReadWork Drop fallback: if not already dumped and `plan_work >= MAX_PLAN_WORK_PER_READ - AudioQueryLimits::default().maximum_work` (16,711,680), dump a `near_limit_final_summary`. This captures a nested child-query refusal when it receives the last <65,536 units, and the exact-cap `query_limits` refusal that has no failed spend. Drop has the full final ledgers and does not insert another deadline/cancellation check. This label **does not claim an error or exhaustion**: a successful near-limit read also qualifies. Correlate with the fixture panic/terminal result. If the nested failure occurs with full 65,536 intrinsic cap and a lower canonical ledger, this trigger correctly prints nothing; then an explicit outer-result error hook would be a separate follow-up, not grounds to claim no work happened.
5. Write one bounded header and all occupied bins directly to stderr only at those triggers. Avoid per-call environment lookup/output and million-unit progress dumps. Deterministic tab-separated lines with static source labels are enough; sort in the external analyzer. No vector/sort/large formatted strings need exist on the renderer path. Include `kind`, canonical/optional accepted counters, remaining allowance, attempted/failing site when known, overflow/counter-overflow flags, and accepted site sums.
6. Analyzer must verify `canonical accepted site units + canonical overflow units == ReadWork.plan_work`, and similarly for optional. `overflow != 0` means incomplete exact site attribution even if total reconciliation succeeds. A profile with any reconciliation/counter error is invalid evidence, while the real renderer result remains unchanged. Neither diagnostic memory nor timing is product acceptance evidence.

The trace lives inside each ReadWork and dies with it. There is no retained TLS registry, generation map, plan/query retention, PCM cache or proof token. A scalar run-local ID allocated when the trace is first used may help correlate output, but no object address is an identity guarantee. No limits, source admission, real charges, test PCM, timeout or cancellation behavior should be changed. The fixture timeout is currently 60 seconds; profiler overhead can cause Timeout earlier, in which case that run is unusable for the intended work-limit attribution. Do not increase it to manufacture a matching result; first reduce the instrumentation overhead or report the diagnostic failure.

## Build and exact test targets, parent execution only

Build only the integration executable needed:

`cargo test --locked -p deadpan-audio --test stages --no-run --message-format=json`

Run from copied `source`, with copied target dir above, existing qualified FFmpeg and ORT prefixes, `DEADPAN_REQUIRE_PHYSICAL_MAC=1`, `CARGO_PROFILE_DEV_OPT_LEVEL=2`, `CARGO_INCREMENTAL=0`, and copied `.cargo/config.toml` (`MACOSX_DEPLOYMENT_TARGET=15.0`). Capture actual compiler/toolchain identity. Extract the stages executable from compiler-artifact JSON, then copy it to a named scratch executable before running; never guess a deps hash or execute a mutable target path.

First narrow filter:

`<pinned-stages> --exact general_split_sound::one_explicit_play_split_keeps_both_selected_and_other_plays_in_the_shared_sound_bus --nocapture --test-threads=1`

The test at `tests/stages/general_split_sound.rs:489` creates the post-edit fixture, then `assert_preserved` first records the **before** prefix-two document with `[4096]` reads. `record_case` (`:271-346`) prepares authored, then faded, then limited for each block. The reported first failure is limited `0+4096`, before the after-document comparisons. Keep the whole exact test and its existing setup/order; do not make a smaller synthetic operation and call it the same failure.

Separate nested probe to capture the child-query class:

`<pinned-stages> --exact general_split_sound::nested_selected_play_split_keeps_root_and_child_sounds_on_their_exact_clocks --nocapture --test-threads=1`

Nested (`:557`) tests root_sound=false first, with prefix-two history, and true second. The reported failure is in the former branch's first limited read. A near-limit Drop record, not a failed-spend record, may be the only applicable trace. Preserve this distinction in conclusions.

All-owner alternative:

`<pinned-stages> --exact general_split_sound::all_owner_kinds_keep_full_sound_pcm_after_split_and_refinement_with_prior_clocks --nocapture --test-threads=1`

It begins Source/Sequence; first-Split checks are unmastered, refinement enables master processing for the Sequence parent, and the current reported failure is cut-three limited `0+511`. No need to repeat the full seven-test matrix just to collect these charged-site summaries. Parent decides whether all three probes are worthwhile after the first histogram.

## Existing evidence/harnesses and source/executable identity

The normative source for the prior measurements is `docs/qualification/sound-preparation-resume-2026-10-26.md` under Measured remaining work. Old files:

- `/tmp/deadpan-audio-work-read-2026-10-26/build_patch.py`: old generated trace design, **not** a patch to run against current source (it hardcodes an old stages hash and modifies main checkout). It used an unbounded per-generation TLS map and per-call env lookup; do not reuse these parts.
- `/tmp/deadpan-split-resume-2026-10-26/work-trace-snippet.txt`: later bounded-ish TLS tracing, pointer/deadline reset heuristics, output at 12M/13M/... as well as failure; do not reuse those output triggers.
- `current-work-selected-trace-second.{json,stdout,stderr}`, `trace-restoration.json`, and final pinned `stages-final` receipts in that directory show prior run/restoration/executable evidence. They are historical, not measurements of the new cursor candidate.
- Current candidate's `/tmp/deadpan-placement-token-2026-10-27/run.py`, `source-files.json`, `exact-build.json`, `exact-pins.json`, `run_final_matrix.py` supply the newer guard and executable scheme. At inspection the source manifest contained 1,395 paths and includes both new placement-history files. It covers Core, Plan, Audio, Media, Store, native DSP/Source plus root build/lock/toolchain files. It is not by itself every workspace dependency input; the profiler receipt should additionally hash the actual copied dependency build inputs (e.g. Diagnostics) and `.cargo/config.toml`.

Latest inspected stage pin from `exact-pins.json`:

- path `/private/tmp/deadpan-placement-token-2026-10-27/deadpan-audio-stages-exact`
- SHA-256 `193aaf70fd2394ea5faf6a322550f84dd4e72bb5961c573bf00f990cb2ff1bc6`

Parent must re-read that receipt when implementing; do not bake a stale pin into a new run. Final matrix receipt remained nonterminal during this audit. The main source and executable are frozen by the parent; no new acceptance claim is made.

Required relationships:

1. Hash main/candidate input files before copying and after copying; require they stayed unchanged during copy. Compare every candidate relative path in copied baseline byte-for-byte with the final accepted-build source_before. Include current untracked files. Record absence of rejected prototype modules from removed-files manifest.
2. Save copied stages.before.rs plus SHA-256 before instrumentation. Reconstruct the diagnostic overlay and assert **only** copied stages.rs differs from copied baseline, with all other source/input hashes equal. Save the exact patch, builder/analyzer/runner bytes, and baseline/profile manifests. Build inputs such as generated native config must be captured, not silently excluded.
3. Do not run the existing run.py unchanged: it hardcodes main ROOT and the shared old CARGO_TARGET_DIR. A profile runner must use the copied root and isolated target, guard those input files before/after, and pin the executed scratch executable before/after. Its environment receipt must include all qualified prefixes, target, optimization/debug/Rust/C++ flags and worker overrides.
4. Run the already pinned baseline executable with the same exact filter (or use the matching current terminal matrix's exact panic/first-failure evidence) and guard its bytes. Then run the separate pinned profile executable with same environment/filter. Baseline/profile executable SHA-256 are distinct identities, not expected to match. Source-root/debug-path differences can also change a newly rebuilt clean binary's hash; do not assert unsupported bit-for-bit reproducibility across build roots.
5. The Audio build script hashes engine-source bytes (`crates/deadpan-audio/build.rs`) into DEADPAN_PCM_ENGINE_PIN, so stages tracing necessarily changes the diagnostic pin. The Split test constructs StageAudio::new, whose persistent_cache starts None (`stages.rs:689-701`), so this probe does not change an existing configured persistent disk-cache hit into a miss. Preserve all ordinary in-memory caches and fixture sequence. A new binary hash alone is not a media-semantic difference.
6. Each run receipt contains command/cwd, environment, actual source+binary before/after hashes, start/end/exit, raw stdout/stderr hashes and fixture error text. Verify same canonical failure class/read boundary, valid histogram reconciliation and no dropped bins before making charged-work conclusions. If it instead times out or fails setup, preserve that setup error and avoid interpreting it as the original preparation bottleneck.

This is a measurement proposal only. It identifies no new measured hotspot percentages and recommends no optimization until the parent runs the guarded copy.
