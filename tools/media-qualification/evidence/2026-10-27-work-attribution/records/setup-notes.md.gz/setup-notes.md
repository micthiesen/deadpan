# Copied-runtime diagnostic setup, frozen

No Cargo, compiler or test was run by the setup agent. Parent owns `runner.py`, `analyze.py`, `pin_stage.py`, builds and executed evidence. The source copy, final input manifest and diagnostic patch are frozen for that work.

## Copy and identity

`copy_runtime.py` copied `/Users/michael/Code/deadpan/` with rsync into this directory's `source/`. It excludes anchored `/.git/`, `/target/`, `/fuzz/target/`, `/.claude/`, `/fuzz/Cargo.lock`, plus evidence, node_modules and .venv directories. Workspace manifests, `.cargo/config.toml`, all member source trees, native build inputs, source audio/video/DSP fixtures, assets and small model manifests remain. Qualification evidence is not a runtime build input; the project resume note explicitly excludes the foreign fuzz lock and agent state from sound-runtime evidence.

The first setup attempt used unanchored `target/`; the 1,395-file check caught its exclusion of legitimate `crates/deadpan-core/src/target/geometry.rs`. The failed attempt is recorded in `copy-first-failure.json`. The recipe was corrected to anchored build-output directories and resumed before any instrumentation. No actual repo file was changed.

`copy-receipt.json` proves all 1,395 guarded files exactly matched `/tmp/deadpan-placement-token-2026-10-27/exact-build.json` source_before, main was unchanged across the copy, and copied guarded bytes equalled main. The wider copied manifest has 5,279 files, 181,726,217 baseline bytes, including dependencies/configuration outside the older runtime-only guard. The removed-file manifest was checked and copied.

- `guarded-baseline.json`: the 1,395 exact runtime baseline pins.
- `base-input-pins.json`: all 5,279 copied baseline files.
- `profile-input-pins.json`: all 5,279 frozen profile files. Only `crates/deadpan-audio/src/stages.rs` differs from base.
- `stages.before.rs`: exact pre-instrumentation source bytes.
- `diagnostic.patch`: final formatted stages-only diagnostic patch.
- `stages-line-map.json`: equal-line mappings from baseline stages.rs to copied instrumented stages.rs; other source files retain their original line positions.
- `audit.json`: final audit assertions and SHA-256 identities.

Baseline stages.rs: 166,297 bytes, SHA-256 `e3ccaf9aa088df4c7c63dd053c32176efb870f1be523768ab1e195bf712bf85b`.

Profile stages.rs: 175,508 bytes, SHA-256 `96535371609ed875299872be8b863dc973f64121db1d57a917a5944f1fc9b55e`.

Patch: 10,891 bytes, SHA-256 `a468b13848c2b870fffb346005aed84f6655d1ce6d87a9f07fd6c4791121d2e1`.

## What instrumentation does

Only copied stages.rs changed. A private `PlanWorkTrace` field in each ReadWork lazily allocates one fixed boxed 256-site table on the first accepted spend. Labels borrow static caller strings; lookup uses bounded open addressing. Site identity is exact `(file,line,column,cache-category)`. There is no per-call string allocation, output, environment lookup, backtrace, sort, TLS map or retained cross-request registry. A monotonic scalar ID only identifies output groups; trace state itself belongs to its request.

`spend_plan_work` uses `#[track_caller]`. Its first operation remains the original `self.check()?`, followed by the original budget borrow/category decision and single `before.checked_add(amount).filter(total <= MAX_PLAN_WORK_PER_READ)`. The original selected counter is assigned exactly the accepted next value, or left unchanged with the same error on refusal. Actual limits and error strings are unchanged. Diagnostic mirrors describe the pending assignment; they do not replace or write real ledgers. Accepted units and call counts are aggregated by site and category. Refused amounts are separate and never enter accepted sums. Full-table units go to explicit category overflow buckets and invalidate exact attribution. Counter overflow also explicitly invalidates the profile.

A canonical failed spend dumps `kind=canonical-spend-limit`, once. Optional-key refusal does not itself dump. A private **trace-field** Drop dumps `kind=near-limit-final-summary` if the final mirrored canonical ledger is at least `16,777,216 - 65,536 = 16,711,680`, and has not already dumped. Using field Drop avoids making existing ReadWork struct-update fixtures illegal. Production real ledger writes exist only in spend_plan_work; thus the two mirrors describe those final counters even when a child query returns an error before its next spend. The near-limit summary may also describe a successful read, so its outcome must be supplied by the enclosing test result. Neither trigger changes deadline, cancellation, source admission, query limits, PCM or test read boundaries.

Output is a bounded BEGIN, occupied SITE rows, two CATEGORY rows, up to two last REFUSAL rows, and END, with accepted sums/reconciliation/overflow flags. All output is at the trigger, uses direct stderr writes, and ignores output failures rather than replacing the renderer's failure. Output includes actual diagnostic site/trace/heap size measurements; no memory or timing benefit is claimed. A table allocation is bounded overhead, not production residency. No runtime source/cache/permission objects are retained by the trace.

`audit_copy.py` verifies that removing only the diagnostic insertions recovers the exact baseline bytes, the entire query_limits function remains byte-identical, self.check is still first, one original checked_add/filter remains, all other copied file bytes are unchanged, and main's 1,395 baseline files remain unchanged. It writes only scratch audit/manifest files. Do not rerun it during a guarded build, since it rewrites these scratch receipts even though source bytes would stay the same.

## Parent build recommendation

One integration executable is sufficient:

`cargo test --locked -p deadpan-audio --test stages --no-run --message-format=json`

Use the parent's runner from copied `source/` and isolated `CARGO_TARGET_DIR=/tmp/deadpan-placement-profile-2026-10-27/target`, qualified FFmpeg/ORT prefixes, physical Mac flag, opt-level2 and incremental0 as recorded in the research/runner. Pin/copy the compiler-reported executable before running the exact selected-play filter, then nested if needed. Full exact filters and limitations are in `research.md`. Do not reuse or mutate main's Cargo target.

If the profiler causes timeout, fails to produce a complete profile, or the analyzer cannot reconcile accepted sums to actual ledgers, preserve the failed diagnostic receipt and do not interpret it as charged-work attribution. No current tests or build outcomes are claimed by this setup.
