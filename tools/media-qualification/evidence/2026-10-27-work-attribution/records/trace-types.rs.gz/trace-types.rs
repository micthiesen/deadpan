// Diagnostic-only copied-runtime instrumentation. Fixed capacity, request-owned;
// it neither grants preparation work nor changes the renderer's real counters.
const PLAN_WORK_TRACE_SITES: usize = 256;

#[derive(Clone, Copy)]
struct PlanWorkTraceSite {
    file: &'static str,
    line: u32,
    column: u32,
    cache: bool,
    calls: usize,
    units: usize,
}

impl PlanWorkTraceSite {
    const EMPTY: Self = Self {
        file: "",
        line: 0,
        column: 0,
        cache: false,
        calls: 0,
        units: 0,
    };
}

#[derive(Clone, Copy)]
struct PlanWorkTraceRefusal {
    file: &'static str,
    line: u32,
    column: u32,
    before: usize,
    amount: usize,
}

#[derive(Clone, Copy, Default)]
struct PlanWorkTraceOverflow {
    calls: usize,
    units: usize,
}

#[derive(Default)]
struct PlanWorkTrace {
    // This field's destructor, rather than ReadWork::drop, preserves existing
    // ReadWork { ..Default::default() } struct updates in unit fixtures.
    sites: Option<Box<[PlanWorkTraceSite; PLAN_WORK_TRACE_SITES]>>,
    id: u64,
    canonical: usize,
    optional: usize,
    overflow: [PlanWorkTraceOverflow; 2],
    refused_calls: [usize; 2],
    refused_units: [u128; 2],
    last_refused: [Option<PlanWorkTraceRefusal>; 2],
    counter_overflow: bool,
    dumped: bool,
}

impl PlanWorkTrace {
    fn record(
        &mut self,
        caller: &'static std::panic::Location<'static>,
        cache: bool,
        amount: usize,
        next: Option<usize>,
        canonical: usize,
        optional: usize,
    ) {
        if self.id == 0 {
            static NEXT: std::sync::atomic::AtomicU64 = std::sync::atomic::AtomicU64::new(1);
            self.id = NEXT.fetch_add(1, std::sync::atomic::Ordering::Relaxed);
            self.counter_overflow |= self.id == 0;
        }
        // These mirrors describe the real counters after the original pending
        // assignment. Production changes them only at spend_plan_work. A refused
        // charge must leave the selected mirror and actual counter unchanged.
        self.canonical = canonical;
        self.optional = optional;
        let category = usize::from(cache);
        let Some(next) = next else {
            let calls = self.refused_calls[category].checked_add(1);
            let units = self.refused_units[category].checked_add(amount as u128);
            self.counter_overflow |= calls.is_none() || units.is_none();
            self.refused_calls[category] = calls.unwrap_or(usize::MAX);
            self.refused_units[category] = units.unwrap_or(u128::MAX);
            self.last_refused[category] = Some(PlanWorkTraceRefusal {
                file: caller.file(),
                line: caller.line(),
                column: caller.column(),
                before: if cache { optional } else { canonical },
                amount,
            });
            return;
        };
        if cache {
            self.optional = next;
        } else {
            self.canonical = next;
        }
        let sites = self
            .sites
            .get_or_insert_with(|| Box::new([PlanWorkTraceSite::EMPTY; PLAN_WORK_TRACE_SITES]));
        let start = (caller.line() as usize)
            .wrapping_mul(37)
            .wrapping_add((caller.column() as usize).wrapping_mul(7))
            .wrapping_add(category.wrapping_mul(127))
            % PLAN_WORK_TRACE_SITES;
        for offset in 0..PLAN_WORK_TRACE_SITES {
            let slot = &mut sites[(start + offset) % PLAN_WORK_TRACE_SITES];
            if slot.file.is_empty() {
                *slot = PlanWorkTraceSite {
                    file: caller.file(),
                    line: caller.line(),
                    column: caller.column(),
                    cache,
                    calls: 1,
                    units: amount,
                };
                return;
            }
            if slot.file == caller.file()
                && slot.line == caller.line()
                && slot.column == caller.column()
                && slot.cache == cache
            {
                let calls = slot.calls.checked_add(1);
                let units = slot.units.checked_add(amount);
                self.counter_overflow |= calls.is_none() || units.is_none();
                slot.calls = calls.unwrap_or(usize::MAX);
                slot.units = units.unwrap_or(usize::MAX);
                return;
            }
        }
        // A full table never silently loses units. Separate overflow buckets
        // retain exact category totals while making site attribution incomplete.
        let overflow = &mut self.overflow[category];
        let calls = overflow.calls.checked_add(1);
        let units = overflow.units.checked_add(amount);
        self.counter_overflow |= calls.is_none() || units.is_none();
        overflow.calls = calls.unwrap_or(usize::MAX);
        overflow.units = units.unwrap_or(usize::MAX);
    }

    fn dump(&mut self, kind: &'static str) {
        if self.dumped {
            return;
        }
        self.dumped = true;
        let mut sums = [0u128; 2];
        if let Some(sites) = &self.sites {
            for site in sites.iter().filter(|site| !site.file.is_empty()) {
                sums[usize::from(site.cache)] += site.units as u128;
            }
        }
        for (sum, overflow) in sums.iter_mut().zip(&self.overflow) {
            *sum += overflow.units as u128;
        }
        let reconciled = sums == [self.canonical as u128, self.optional as u128];
        let exact_sites = self.overflow.iter().all(|entry| entry.calls == 0);
        // Output errors are diagnostic failures, never renderer errors. No
        // assertion, environment lookup, sort, per-call log or backtrace runs.
        use std::io::Write as _;
        let stderr = std::io::stderr();
        let mut output = stderr.lock();
        let _ = writeln!(
            output,
            "AUDIO_WORK_PROFILE_BEGIN version=1 id={} kind={kind} canonical={} optional={} remaining={} reconciled={reconciled} exact_sites={exact_sites} counter_overflow={} bins={} site_bytes={} trace_bytes={} diagnostic_heap_bytes={}",
            self.id,
            self.canonical,
            self.optional,
            MAX_PLAN_WORK_PER_READ.saturating_sub(self.canonical),
            self.counter_overflow,
            PLAN_WORK_TRACE_SITES,
            std::mem::size_of::<PlanWorkTraceSite>(),
            std::mem::size_of::<Self>(),
            if self.sites.is_some() { std::mem::size_of::<[PlanWorkTraceSite; PLAN_WORK_TRACE_SITES]>() } else { 0 },
        );
        if let Some(sites) = &self.sites {
            for site in sites.iter().filter(|site| !site.file.is_empty()) {
                let _ = writeln!(
                    output,
                    "AUDIO_WORK_PROFILE_SITE id={} cache={} file={} line={} column={} calls={} units={}",
                    self.id, site.cache, site.file, site.line, site.column, site.calls, site.units,
                );
            }
        }
        for category in 0..2 {
            let cache = category == 1;
            let overflow = &self.overflow[category];
            let _ = writeln!(
                output,
                "AUDIO_WORK_PROFILE_CATEGORY id={} cache={cache} overflow_calls={} overflow_units={} refused_calls={} refused_units={}",
                self.id, overflow.calls, overflow.units, self.refused_calls[category], self.refused_units[category],
            );
            if let Some(refused) = self.last_refused[category] {
                let _ = writeln!(
                    output,
                    "AUDIO_WORK_PROFILE_REFUSAL id={} cache={cache} file={} line={} column={} before={} amount={}",
                    self.id, refused.file, refused.line, refused.column, refused.before, refused.amount,
                );
            }
        }
        let _ = writeln!(
            output,
            "AUDIO_WORK_PROFILE_END id={} canonical_sum={} optional_sum={}",
            self.id, sums[0], sums[1],
        );
    }
}

impl Drop for PlanWorkTrace {
    fn drop(&mut self) {
        if !self.dumped
            && self.canonical
                >= MAX_PLAN_WORK_PER_READ - AudioQueryLimits::default().maximum_work
        {
            // May describe a child-query refusal or a successful near-limit
            // read. Only the enclosing fixture result establishes its outcome.
            self.dump("near-limit-final-summary");
        }
    }
}
