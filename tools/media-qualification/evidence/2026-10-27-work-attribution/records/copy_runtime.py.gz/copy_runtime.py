from pathlib import Path
import hashlib,json,subprocess,time
from datetime import datetime,timezone
ROOT=Path('/Users/michael/Code/deadpan')
SCRATCH=Path('/tmp/deadpan-placement-profile-2026-10-27')
SOURCE=SCRATCH/'source'
ACCEPTED=Path('/tmp/deadpan-placement-token-2026-10-27/exact-build.json')
MANIFEST=Path('/tmp/deadpan-placement-token-2026-10-27/source-files.json')
# Resume only this agent's incomplete, uninstrumented first copy.
if SOURCE.exists():
 assert not (SCRATCH/'copy-receipt.json').exists(), 'refuse to overwrite a completed copy'
 assert not (SCRATCH/'diagnostic.patch').exists(), 'refuse to overwrite instrumented source'
paths=json.loads(MANIFEST.read_text());assert len(paths)==1395
expected=json.loads(ACCEPTED.read_text())['source_before']
def pin(p):
 b=p.read_bytes();return {'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def pins(root):return {name:pin(root/name) for name in paths}
before=pins(ROOT)
for name,row in before.items():assert row==expected[str(ROOT/name)], (name,'main differs from accepted-build source_before')
(SCRATCH/'guarded-baseline.json').write_text(json.dumps(before,indent=2)+'\n')
exclude=['/.git/','/target/','/fuzz/target/','/.claude/','/fuzz/Cargo.lock','**/evidence/','**/node_modules/','**/.venv/']
command=['rsync','-a',*[f'--exclude={s}' for s in exclude],str(ROOT)+'/',str(SOURCE)+'/']
record={'started_at':datetime.now(timezone.utc).isoformat(),'command':command,'baseline_receipt':str(ACCEPTED),'baseline_receipt_pin':pin(ACCEPTED),'guarded_manifest':str(MANIFEST),'guarded_manifest_pin':pin(MANIFEST),'guarded_count':len(paths),'main_before':before}
start=time.monotonic();subprocess.run(command,check=True)
after=pins(ROOT);copied=pins(SOURCE)
assert before==after,'main source changed during copy'
assert before==copied,'copied guarded files differ'
assert not (SOURCE/'.git').exists();assert not (SOURCE/'.claude').exists();assert not (SOURCE/'target').exists();assert not (SOURCE/'fuzz/Cargo.lock').exists()
# Include every copied input, not just the narrower historical runtime manifest.
allpins={str(p.relative_to(SOURCE)):pin(p) for p in sorted(SOURCE.rglob('*')) if p.is_file()}
(SCRATCH/'base-input-pins.json').write_text(json.dumps(allpins,indent=2)+'\n')
removed=json.loads(Path('/tmp/deadpan-placement-token-2026-10-27/removed-files.json').read_text())
assert all(not (SOURCE/name).exists() for name in removed)
(SCRATCH/'removed-files.json').write_text(json.dumps(removed,indent=2)+'\n')
record.update({'finished_at':datetime.now(timezone.utc).isoformat(),'seconds':time.monotonic()-start,'main_after':after,'copied_guarded':copied,'main_unchanged':before==after,'guarded_bytes_match':before==copied,'all_copied_files':len(allpins),'all_copied_bytes':sum(r['bytes'] for r in allpins.values()),'removed_paths_absent':removed})
(SCRATCH/'copy-receipt.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps({k:record[k] for k in ['guarded_count','main_unchanged','guarded_bytes_match','all_copied_files','all_copied_bytes','seconds']}))
