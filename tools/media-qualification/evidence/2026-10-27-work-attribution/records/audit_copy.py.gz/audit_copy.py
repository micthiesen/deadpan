from pathlib import Path
import hashlib,json,difflib
from datetime import datetime,timezone
S=Path('/tmp/deadpan-placement-profile-2026-10-27');SOURCE=S/'source';MAIN=Path('/Users/michael/Code/deadpan');REL='crates/deadpan-audio/src/stages.rs'
def pin(p):
 b=p.read_bytes();return {'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
base=json.loads((S/'base-input-pins.json').read_text())
profile={str(p.relative_to(SOURCE)):pin(p) for p in sorted(SOURCE.rglob('*')) if p.is_file()}
assert set(profile)==set(base),'copied input set changed'
changed=[p for p in base if base[p]!=profile[p]];assert changed==[REL],changed
old=(S/'stages.before.rs').read_text();new=(SOURCE/REL).read_text()
assert pin(S/'stages.before.rs')==base[REL]
assert new.count('    work_trace: PlanWorkTrace,')==1
assert new.count('impl Drop for PlanWorkTrace {')==1
assert 'impl Drop for ReadWork' not in new
assert 'thread_local!' not in new[new.index('// Diagnostic-only copied-runtime instrumentation.'):new.index('const MAX_PLAN_WORK_PER_READ:')]
# Reconstruct baseline bytes by removing only the owned diagnostic insertions.
a=new.index('// Diagnostic-only copied-runtime instrumentation.');b=new.index('const MAX_PLAN_WORK_PER_READ:',a)
stripped=new[:a]+new[b:]
stripped=stripped.replace('    work_trace: PlanWorkTrace,\n','',1)
a=stripped.index('    #[track_caller]\n    fn spend_plan_work(');b=stripped.index('    fn query_limits(',a)
old_a=old.index('    fn spend_plan_work(');old_b=old.index('    fn query_limits(',old_a)
stripped=stripped[:a]+old[old_a:old_b]+stripped[b:]
assert stripped==old,'non-diagnostic bytes changed'
(S/'stages.reconstructed-baseline.rs').write_text(stripped)
# The canonical query-limit function and all remaining code are unchanged.
a=old.index('    fn query_limits(');b=old.index('    fn admit_dependency(',a)
x=new.index('    fn query_limits(');y=new.index('    fn admit_dependency(',x)
assert old[a:b]==new[x:y]
spend=new[new.index('    fn spend_plan_work('):x]
assert spend.count('        self.check()?;')==1
assert spend.splitlines()[1]=='        self.check()?;'
assert spend.count('.checked_add(amount)')==1
assert spend.count('.filter(|total| *total <= MAX_PLAN_WORK_PER_READ)')==1
assert spend.count('*spent = next.ok_or(')==1
assert new.count('const MAX_PLAN_WORK_PER_READ: usize = 16 * 1024 * 1024;')==1
assert 'const PLAN_WORK_TRACE_SITES: usize = 256;' in new
assert 'self.dump("near-limit-final-summary")' in new
assert 'work.work_trace.dump("canonical-spend-limit")' in new
(S/'diagnostic.patch').write_text(''.join(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile='a/'+REL,tofile='b/'+REL)))
(S/'profile-input-pins.json').write_text(json.dumps(profile,indent=2)+'\n')
guarded=json.loads((S/'guarded-baseline.json').read_text())
main={name:pin(MAIN/name) for name in guarded};assert main==guarded,'main guarded input changed during instrumentation'
assert all(profile[p]==row for p,row in guarded.items() if p!=REL)
assert (SOURCE/'crates/deadpan-core/src/target/geometry.rs').is_file()
assert not (SOURCE/'fuzz/Cargo.lock').exists()
assert not any((SOURCE/path).exists() for path in ['.git','.claude','target','fuzz/target'])
removed=json.loads((S/'removed-files.json').read_text());assert all(not (SOURCE/p).exists() for p in removed)
# Equal-line map lets exact copied stages call sites be read against the baseline.
mapping=[]
for block in difflib.SequenceMatcher(a=old.splitlines(),b=new.splitlines(),autojunk=False).get_matching_blocks():
 if block.size:mapping.append({'baseline_first':block.a+1,'profile_first':block.b+1,'lines':block.size})
(S/'stages-line-map.json').write_text(json.dumps(mapping,indent=2)+'\n')
record={'at':datetime.now(timezone.utc).isoformat(),'baseline_input_count':len(base),'profile_input_count':len(profile),'guarded_baseline_count':len(guarded),'changed_copied_inputs':changed,'main_guarded_unchanged':main==guarded,'stripped_instrumentation_recovers_exact_baseline':True,'query_limits_bytes_unchanged':True,'first_spend_operation_is_original_check':True,'single_original_checked_add_filter':True,'fixed_bins':256,'trace_drop_not_readwork_drop':True,'main_edited':False,'cargo_run':False,'profile_source_pin':profile[REL],'baseline_source_pin':base[REL],'diagnostic_patch_pin':pin(S/'diagnostic.patch'),'reconstructed_baseline_pin':pin(S/'stages.reconstructed-baseline.rs'),'profile_manifest_pin':pin(S/'profile-input-pins.json'),'base_manifest_pin':pin(S/'base-input-pins.json')}
(S/'audit.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps(record,indent=2))
