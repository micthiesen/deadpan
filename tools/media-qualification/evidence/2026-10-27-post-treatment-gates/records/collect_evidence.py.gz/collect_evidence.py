from pathlib import Path
import gzip,json,hashlib,shutil
s=Path(__file__).resolve().parent
extensions={'.json','.stdout','.stderr','.py','.patch','.rs','.txt','.tar','.md','.diff'}
for source,label in [(Path('/tmp/deadpan-unused-gates-2026-10-27'),'unused-gates'),(Path('/tmp/deadpan-coincident-edge-probe-2026-10-27'),'coincidence-probe')]:
 for p in source.iterdir():
  if p.is_file() and p.suffix in extensions:
   out=s/'related'/label/p.name
   out.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,out)
dest=Path('/Users/michael/Code/deadpan/tools/media-qualification/evidence/2026-10-27-post-treatment-gates')
assert not dest.exists()
dest.mkdir(parents=True)
files=[]
for p in sorted(s.rglob('*')):
 if not p.is_file() or p.suffix not in extensions:continue
 rel=p.relative_to(s);data=p.read_bytes();compressed=gzip.compress(data,mtime=0)
 out=dest/'records'/Path(str(rel)+'.gz')
 out.parent.mkdir(parents=True,exist_ok=True);out.write_bytes(compressed)
 files.append(dict(path=str(out.relative_to(dest)),bytes=len(compressed),sha256=hashlib.sha256(compressed).hexdigest(),expanded_bytes=len(data),expanded_sha256=hashlib.sha256(data).hexdigest()))
inventory=dict(schema_version=1,base_revision='ea1083d3',scope='Independent nine-file unused post-gate query optimization and processed root input-edge fix. Original doublefade and rejected Option-neutral coincidence regression retained. Final exact patch, candidate reconstruction, main/isolated tests, bounded work/source guards, source/binary identities and corrected independent review retained. Split work-limit failures remain incomplete; no acceptance credit. Executables local only.',files=files)
out=dest/'inventory.json';out.write_text(json.dumps(inventory,indent=2)+'\n')
for row in files:
 data=(dest/row['path']).read_bytes();expanded=gzip.decompress(data)
 assert len(data)==row['bytes'] and hashlib.sha256(data).hexdigest()==row['sha256']
 assert len(expanded)==row['expanded_bytes'] and hashlib.sha256(expanded).hexdigest()==row['expanded_sha256']
print(json.dumps(dict(payloads=len(files),stored_bytes=sum(r['bytes'] for r in files),expanded_bytes=sum(r['expanded_bytes'] for r in files),inventory_sha256=hashlib.sha256(out.read_bytes()).hexdigest()),indent=2))
