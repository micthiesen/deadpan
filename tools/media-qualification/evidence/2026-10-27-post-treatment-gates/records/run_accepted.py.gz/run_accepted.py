from pathlib import Path
import json,sys,shutil,subprocess,hashlib
s=Path(__file__).resolve().parent
bins=[]
for line in (s/'accepted-build.stdout').read_text().splitlines():
 try:r=json.loads(line)
 except ValueError:continue
 if r.get('reason')=='compiler-artifact' and r.get('executable') and r.get('profile',{}).get('test'):
  pkg=r['package_id'].split('/crates/')[1].split('#')[0]
  name=r['target']['name']
  p=s/(pkg+'-'+name.replace('_','-')+'-accepted')
  shutil.copy2(r['executable'],p)
  bins.append(dict(package=pkg,name=name,path=str(p),sha256=hashlib.sha256(p.read_bytes()).hexdigest()))
(s/'accepted-pins.json').write_text(json.dumps(bins,indent=2)+'\n')
jobs=[(r,'accepted-plan-'+r['name'].replace('_','-'),['--nocapture']) for r in bins if r['package']=='deadpan-plan']
r=next(r for r in bins if r['package']=='deadpan-audio' and r['name']=='deadpan_audio')
jobs.append((r,'accepted-audio-library',['--nocapture','--test-threads=1']))
r=next(r for r in bins if r['package']=='deadpan-audio' and r['name']=='audio_definition')
jobs.append((r,'accepted-root-waveform',['edit_waveform::root_routes_and_silent_hold_permissions_change_actual_window_peaks','--exact','--nocapture','--test-threads=1']))
r=next(r for r in bins if r['package']=='deadpan-audio' and r['name']=='stages')
jobs.append((r,'accepted-event-returns',['event_returns::','--nocapture','--test-threads=1']))
jobs.append((r,'accepted-split-matrix',['general_split_sound::','--nocapture','--test-threads=1']))
results=[]
for r,label,args in jobs:
 binary=r['path']
 code=subprocess.call([sys.executable,str(s/'run.py'),'--binary',binary,label,'--',binary,*args])
 results.append(dict(label=label,exit_code=code))
 (s/'accepted-results.json').write_text(json.dumps(results,indent=2)+'\n')
raise SystemExit(any(r['exit_code'] for r in results))
