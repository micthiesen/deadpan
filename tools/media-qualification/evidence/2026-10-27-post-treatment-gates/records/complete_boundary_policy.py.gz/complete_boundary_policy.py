from pathlib import Path
import re,hashlib
path=Path('/Users/michael/Code/deadpan/crates/deadpan-plan/src/audio_sound_event.rs')
text=path.read_text()
before=text
edits=[]
for match in re.finditer(r'\b(?:RoutedBoundary|Boundary)\s*\{',text):
 line=text[text.rfind('\n',0,match.start())+1:match.start()]
 if 'struct ' in line or '-> ' in line: continue
 pos=match.end();depth=1
 while depth:
  if text[pos]=='{':depth+=1
  elif text[pos]=='}':depth-=1
  pos+=1
 body=text[match.end():pos-1]
 policy=re.search(r'\bpolicy:\s*',body)
 if policy:
  start=match.end()+policy.end()
  end=start;stack=[]
  while end<len(text):
   ch=text[end]
   if ch in '([{':stack.append(ch)
   elif ch in ')]}':
    if not stack:break
    stack.pop()
   elif ch==',' and not stack:break
   end+=1
  value=text[start:end].rstrip()
  if value.startswith(('boundary.policy','a.policy.coincident')):continue
  authored=value.startswith(('self.start_edge','self.end_edge','start_edge','end_edge','if inherited_hard_edges'))
  constructor='authored' if authored else 'current'
  edits.append((start,start+len(value),f'BoundaryPolicy::{constructor}({value})'))
 else:
  short=re.search(r'\bpolicy,',body)
  if short:
   start=match.end()+short.start()
   edits.append((start,start+len('policy'),'policy: BoundaryPolicy::current(policy)'))
for start,end,value in reversed(edits):text=text[:start]+value+text[end:]
anchor='''        start_edge,
        end_edge,
    }
    .query(samples, limits, |_, _, _| Ok(false))'''
assert text.count(anchor)==1
text=text.replace(anchor,anchor.replace('        end_edge,\n','        end_edge,\n        phase: GatePhase::Complete,\n'))
anchor='''        &gates,
        limits,
        &mut work,'''
assert text.count(anchor)==1
text=text.replace(anchor,anchor.replace('        limits,','        GatePhase::Complete,\n        limits,'))
for fn,phase in [('    fn append_envelope(','self.phase'),('fn append_routed_envelope(','phase')]:
 start=text.index(fn);push=text.index('    '+('    ' if phase=='self.phase' else '')+'push_span(\n',start)
 indent='        ' if phase=='self.phase' else '    '
 # Both policies are projected together at emission, after all provenance merges.
 text=text[:push]+f'{indent}if matches!({phase}, GatePhase::PostTreatment) {{\n{indent}    charge(work, limits.maximum_work)?;\n{indent}}}\n'+text[push:]
path.write_text(text)
print('Wrapped',len(edits),'boundary constructors; completed both phase projections')
print('Before',hashlib.sha256(before.encode()).hexdigest(),'after',hashlib.sha256(text.encode()).hexdigest())
