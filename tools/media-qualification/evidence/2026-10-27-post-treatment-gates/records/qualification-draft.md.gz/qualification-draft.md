# Post-treatment sound gates, 2026-10-27

Preparation now omits an unused second gate query for events whose canonical
event-return predicate is false. The first full gate query, source admission,
retained-input preflight and every required query remain. A decision costs one
work unit; a required query costs its full reported work. No cache, dependency,
permission or limit changes. Normal owner processing and Tail Sends do not
turn an unprocessed event into a processed return.

The investigation also exposed an existing root-sound PCM bug. The direct
post-treatment gate used Hard input endpoints, but routed root gates reused
compiled Automatic island tags. An input fade already applied before event
processing was therefore multiplied into the processed dry output again.
The actual PCM regression fails at sample37:
-0.000013255305 instead of -0.0025450184.

The corrected plan carries complete and post-treatment edge policies through
each immutable boundary, retaining exact semantic coordinates and physical
sample labels. Authored endpoints need no additional post fade; new cut/Hold
boundaries keep their real policies. Exact coincidence combines both phases
separately so the same input endpoint is not faded again. It projects the post
policy only at final span emission and charges that projection. No second
island vector, extra layout traversal or persisted format is introduced.

An initial Option-neutral design was rejected before commit. Its focused route
regression passed, but adding a SilentHold wholly before an offset37 event
reintroduced the same192x fade. The new full48000-sample invariance probe fails
that candidate and passes the corrected paired-policy version. The test keeps
Original audio absent, event timing fixed and project duration unchanged.

Plan regressions cover inserted/deleted cuts, current Holds, both real Hard
choices, exact endpoint coincidence and odd RoundEven label transport at32kfps.
New gate preparation tests inspect actual root/current/routed prepared results,
compare required spans and work with an explicit second query, prove unused
queries stay lazy, and retain exact/one-short/zero budget refusal. An initial
test requested576 frames through the256-frame routed-reader guard; the fixture
was corrected to request256 without changing that production guard.

The first candidate passes533 Plan,198 Audio library,171 Audio definition and
202 existing stage tests. Its unchanged Split matrix remains4pass/3work-limit
failures. These are intermediate results, not acceptance of the rejected
coincidence rule. Final paired-policy verification is recorded separately.
