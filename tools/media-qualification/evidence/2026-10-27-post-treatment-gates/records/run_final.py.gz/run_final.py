from pathlib import Path
import json,sys,shutil,subprocess,hashlib
s=Path(__file__).resolve().parent
bins=[]
for line in (s/'final-build.stdout').read_text().splitlines():
 try:r=json.loads(line)
 except ValueError:continue
 if r.get('reason')=='compiler-artifact' and r.get('executable') and r.get('profile',{}).get('test'):
  pkg=r['package_id'].split('/crates/')[1].split('#')[0]
  name=r['target']['name']
  p=s/(pkg+'-'+name.replace('_','-')+'-final')
  shutil.copy2(r['executable'],p)
  bins.append(dict(package=pkg,name=name,path=str(p),sha256=hashlib.sha256(p.read_bytes()).hexdigest()))
(s/'final-pins.json').write_text(json.dumps(bins,indent=2)+'\n')
jobs=[(r,'final-plan-'+r['name'].replace('_','-'),['--nocapture']) for r in bins if r['package']=='deadpan-plan']
for name in ['deadpan_audio','audio_definition']:
 r=next(r for r in bins if r['package']=='deadpan-audio' and r['name']==name)
 jobs.append((r,'final-'+name.replace('_','-'),['--nocapture','--test-threads=1']))
r=next(r for r in bins if r['package']=='deadpan-audio' and r['name']=='stages')
jobs.append((r,'final-existing-stages',['--skip','general_split_sound::','--nocapture','--test-threads=1']))
jobs.append((r,'final-split-matrix',['general_split_sound::','--nocapture','--test-threads=1']))
results=[]
for r,label,args in jobs:
 binary=r['path']
 code=subprocess.call([sys.executable,str(s/'run.py'),'--binary',binary,label,'--',binary,*args])
 results.append(dict(label=label,exit_code=code))
 (s/'final-results.json').write_text(json.dumps(results,indent=2)+'\n')
raise SystemExit(any(r['exit_code'] for r in results))
