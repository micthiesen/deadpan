# Unused post-treatment gate queries

Read-only source audit, 2026-10-27. No Cargo or repository edits. This is a
bounded next candidate, not a claim that the remaining real-WAV failures pass.

## Proposed change

Construct post-treatment gates only when the event's existing canonical
event_returns::needs_processing(&event.treatments) predicate is true. Keep the
normal event gate query, static query/preflight and source admission unchanged.
Do not use selected output, permissions, zero PCM, owner treatments, source
availability or tail-send selection as additional conditions.

Actual repeated calls today:
- beat_sounds.rs:229/232: transported/history normal edges, then Hard/Hard.
- beat_sounds.rs:262/274: current occurrence normal edges, then Hard/Hard.
- sound_events.rs:143/146: root normal gates, then post_treatment_gates.
- Root post_treatment_gates additionally clones AudioRootSound before its
  second gate query (audio_sound_event.rs:328).

Each second query can repeat current.audio/domain.audio with a 192-sample halo,
route transition arithmetic, Hold extraction, envelope projection and allocation.
Skipping it removes this execution and its returned-span storage. It adds no
retained query, PCM, cache key, historical plan owner or transient peak.

## Exhaustive consumer check

post_fades occurs only in the prepared structures, their constructors, and:
- shared_eq.rs:538/611 passes the vectors to add_sound.
- add_sound validates post_fades only if returned.is_some() (:920), and indexes
  them only inside the same branch (:938).
- read_shared_program chooses returned=Some exactly when needs_processing is
  true for that root (:503) or beat (:552). read_event_returns always returns
  EventOutput; cached tiles never change this predicate.
- sound_events::render_root_sounds explicitly discards post_fades (:204).
- beat_sounds::render_beat_sounds never reads post_fades.
- Tail sends have no other consumer. They tap the normally faded contribution.
  Event wet sends are included in needs_processing; allocated tail_sends alone
  are not. Owner EQ/wet processing does not imply event returns.

The canonical predicate (event_returns.rs:45) includes wet sends, nonunity EQ,
any saturation, noncenter balance, and ClipGain whole mute/envelopes/mute ranges.
Default, trim-only, unity EQ, center balance and tail_sends-only recipes are
false. Keep that one predicate; do not reproduce its flags in another helper.

## No distinct validation is removed

For a current occurrence, CurrentEnvelope::query (audio_sound_event.rs:667)
uses event edges only in Boundary.policy. Coordinate comparisons and selection,
halo audio query, Hold/allowance extraction, lengths, progress and all fallible
arithmetic are independent of that tag. earlier/later/coincident carry or combine
tags after choosing the same coordinates. append_envelope writes tags to output.

For transported/history occurrences, routed_occurrence_envelope (:462) likewise
only carries policy through RoutedBoundary. move_boundary, routed_earlier/later,
routed_coincident and append_routed_envelope (:1178 onward) perform identical
coordinate/label calculations. clip_current_hold_samples (:1119) ignores tags.
Both edge choices generate the same span geometry and execute the same route,
grid, range, shape and halo validation.

The first normal gate query still executes these validations. A second query
can differ in work-budget failure because it is additional actual work; removing
its traversal legitimately removes that charge. No cap changes or refunds.
Source resolution/observation stays at existing render and retained-input paths,
including empty prepared event carriers.

## Helper visibility and ownership

Preferred one helper in shared_eq.rs:

    pub(super) fn prepare_post_gates(
        treatments: &deadpan_core::AudioTreatments,
        control: WorkControl<'_>,
        build: impl FnOnce(AudioQueryLimits)
            -> Result<deadpan_plan::AudioSoundGateQuery, StageAudioError>,
    ) -> Result<Vec<deadpan_plan::AudioSoundGateSpan>, StageAudioError>

It charges one structural predicate operation, calls the existing private
event_returns::needs_processing, and returns Vec::new immediately when false.
When true, it obtains current query limits, calls build once, charges returned
query.work, and returns query.spans. Other query/dependency work stays charged.
Builders are lazy, so false cannot allocate, obtain limits for a nonexistent
query, clone a root voice, or execute Plan work.

Placement matters: event_returns is a private child of shared_eq, and its
needs_processing is pub(super), visible only to shared_eq. A pub(super) helper
on shared_eq is visible to the StageAudio sibling files beat_sounds and
sound_events without exposing event_returns or copying its predicate. Update
the three producer sites; leave both returned=Some consumer decisions unchanged.

One implementation owner can own shared_eq.rs helper/wiring, beat_sounds.rs,
sound_events.rs and new private shared_eq/post_gate_tests.rs. Public PCM test
additions belong in tests/stages/event_returns.rs or event_treatments.rs.
No Plan gate implementation or visibility changes are necessary.

## Verification proposal

- Private helper test: false recipes never invoke a builder that deliberately
  errors; true recipes invoke once and propagate that error.
- Actual-work witness with a real multi-span Hold gate query: first query
  unchanged; skipped helper costs one predicate operation; an explicitly
  executed reference post query reports its full positive work and expected
  identical support. A near-exhausted controller passes the skipped branch
  while the real second traversal fails. No synthetic refunds or constants.
- Required branch: EQ/saturation/balance/envelope/mute/wet recipes keep the
  full Hard/Hard query and exact spans/work; tail_sends-only stays false.
- Root and beat PCM for default and trim-only events under owner EQ/wet, with
  Automatic event edges and Hard/Automatic current Hold boundaries.
- Current and transported/history variants, NTSC offsets, cold/warm reads;
  compare exact PCM/dependencies/suppression.
- Source revocation and invalid/preflight-limit tests still reject, including
  saved_beat_sound_with_no_current_occurrence_still_admits_source.
- Existing PCM oracles:
  event_fade_precedes_saturation_once_and_balance_keeps_other_channel;
  automatic_event_edges_feed_the_effect_and_fade_the_bounded_return;
  processed_event_history_and_envelope_progress_survive_insert_and_cut;
  current_hold_blocks_event_return_until_that_sound_is_explicitly_allowed.
- Main owns seven-case real-WAV matrix; no acceptance inferred from an error tag.

## Separate projected-root edge concern

Treat as a suspected existing defect requiring a separate regression, not
established intended saved-clock semantics and not an issue to fix here.

post_treatment_gates sets cloned root start/end edges to Hard, but projected
root dispatches to routed_gate_fades (:959), which reads CompiledRootSound.islands
and never reads those fields. compile_islands (:1367) embeds original event tags
and later saved cut tags. Normal and post queries are literally identical there.

Saved cut provenance is intentional, but docs/qualification/
event-treatments-2026-10-12.md explicitly says processed dry uses a separate
output envelope so its original input edge is not applied twice.
event_returns.rs:541-550 applies original event edges before processing;
shared_eq::add_sound then applies the post gate to dry. A routed root event
with Automatic onset and nonzero saturation/balance, followed by a saved
mid-event insertion, appears capable of fading that original onset twice.

The nonrouted automatic-edge/saturation oracle covers once-only input edges;
routed insert/cut oracles use Hard edges and miss this intersection. Independent
witness: take automatic-edge saturation, add saved root insertion far from onset,
and require unchanged onset prefix to equal pre-insertion PCM. No run claimed.

Fixing that issue would require distinguishing original event edges from saved
cut/hold boundaries. Blindly changing all projected tags to Hard would erase
intentional cut fades. The unused-query optimization does neither: when returns
are needed, leave the existing post query untouched.
