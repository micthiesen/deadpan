from pathlib import Path
import json,difflib
s=Path(__file__).resolve().parent
opt=Path('/tmp/deadpan-unused-gates-2026-10-27')
root=Path('/Users/michael/Code/deadpan')
pairs={
'crates/deadpan-audio/src/beat_sounds.rs':opt/'beat_sounds.before.rs',
'crates/deadpan-audio/src/sound_events.rs':opt/'sound_events.before.rs',
'crates/deadpan-audio/src/shared_eq.rs':opt/'shared_eq.before.rs',
'crates/deadpan-audio/src/stages.rs':opt/'stages.before.rs',
'crates/deadpan-plan/src/audio_sound_event.rs':s/'audio_sound_event.before.rs',
'crates/deadpan-plan/tests/root_sound_routes.rs':s/'root_sound_routes.before.rs',
'crates/deadpan-audio/tests/stages/event_returns.rs':s/'event_returns.head.rs',
'crates/deadpan-audio/src/post_gate_tests.rs':None,
'crates/deadpan-plan/tests/root_sound_routes/post_treatment.rs':None,
}
assert (s/'event_returns.before.rs').read_bytes()==(s/'event_returns.head.rs').read_bytes()
patch=''
for rel,src in pairs.items():
 before=src.read_text() if src else ''
 after=(root/rel).read_text()
 patch+=''.join(difflib.unified_diff(before.splitlines(True),after.splitlines(True),fromfile='a/'+rel if src else '/dev/null',tofile='b/'+rel))
(s/'scoped.patch').write_text(patch)
(s/'scoped-files.json').write_text(json.dumps(list(pairs),indent=2)+'\n')
print('Prepared9file independent patch',len(patch),'bytes')
