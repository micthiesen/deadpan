# Capture-baseline branding correction review

Reviewed the branding correction and `branding-tests1` delta read-only against the frozen candidate. No build or source changes performed.

The earlier branding finding is fixed. `content(expected_plan, Bound)` now passes the caller's actual RenderPlan into `AudioBound::capture_baseline_snapshot`, which asserts `belongs_to(expected_plan)` before indexing node/constraint data. The retained-input snapshot and probe-result hook likewise receive the actual context Plan and assert both `belongs_to` and pointer identity before serializing processing/editorial/domain data. This closes the self-derived-plan assertion hole without adding pointer values to the logical baseline.

The regression uses two independently compiled plans from the same frozen document, so their logical metadata is identical while Plan identity differs. It obtains a real bound retained input from the actual owner/probe path, accepts the actual Plan, then verifies the existing processing/content serializer and retained-input serializer panic on the foreign Plan. This reaches the Bound arm through the production-shaped serializer and tests the exact false-positive case; it does not create a replacement Bound or replay the walk. The new assertions preserve the baseline's successful serialized boolean (`true`) and do not alter logical output fields.

The explicitly documented PointCeil private `AudioSignal` provider omission remains a retained-probe-only coverage limit. The new expected-Plan check still covers the owning Point domain's plan brand via `bound_domain`; the omitted provider does not affect capture-only input/span closure. Extend this baseline before changing retained-probe/provider construction.

No further supported findings. Parent reports the branding regression passed in both variants and their common logical baseline remained identical; I did not independently execute those checks.
