from pathlib import Path
import gzip,json,hashlib
s=Path(__file__).resolve().parent;repo=Path('/Users/michael/Code/deadpan')
dest=repo/'tools/media-qualification/evidence/2026-10-29-owner-capture-baseline-v1'
assert not dest.exists()
audit=json.loads((s/'final-audit.json').read_text());assert audit['all9_terminal']
prior=repo/'tools/media-qualification/evidence/2026-10-28-owner-query-budget/inventory.json'
prior_sha='166da971f5ce76d8905714c3b03de3f37011e8409adbcdcc0d390a11195708ac'
assert hashlib.sha256(prior.read_bytes()).hexdigest()==prior_sha
allowed={'.rs','.json','.py','.md','.patch','.stdout','.stderr','.txt'};rows=[]
for p in sorted(s.rglob('*')):
 if not p.is_file() or p.suffix not in allowed:continue
 data=p.read_bytes()
 if p.suffix=='.json':
  obj=json.loads(data)
  if isinstance(obj,dict) and 'command' in obj and 'started_at' in obj:assert obj['exit_code']==0 and obj['sources_unchanged'] and obj['binaries_unchanged']
 target=dest/'records/capture-baseline'/p.relative_to(s)
 target=target.with_name(target.name+'.gz');target.parent.mkdir(parents=True,exist_ok=True)
 packed=gzip.compress(data,mtime=0);target.write_bytes(packed)
 rows.append({'path':str(target.relative_to(dest)),'bytes':len(packed),'sha256':hashlib.sha256(packed).hexdigest(),'expanded_bytes':len(data),'expanded_sha256':hashlib.sha256(data).hexdigest()})
manifest={'schema_version':1,'base_revision':(s/'base-revision.txt').read_text().strip(),'scope':'Test-only actual legacy capture/discard/probe logical and work observations, before capture admission. Two actual old producers with identical14+2case/128event observations. No heap/native/provider qualification, no capture/probe admission, no cold activation. PointCeil private AudioSignal provider remains outside the probe oracle. Includes corrected expected-Plan branding and its real foreign-Plan regression.','prior_query_admission_inventory':{'path':'../2026-10-28-owner-query-budget/inventory.json','sha256':prior_sha},'published_goldens':json.loads((s/'published-golden-pins.json').read_text()),'files':rows}
p=dest/'inventory.json';p.write_text(json.dumps(manifest,indent=2)+'\n')
for r in rows:
 packed=(dest/r['path']).read_bytes();plain=gzip.decompress(packed)
 assert len(packed)==r['bytes'] and hashlib.sha256(packed).hexdigest()==r['sha256']
 assert len(plain)==r['expanded_bytes'] and hashlib.sha256(plain).hexdigest()==r['expanded_sha256']
print(json.dumps({'files':len(rows),'stored_bytes':sum(r['bytes'] for r in rows),'expanded_bytes':sum(r['expanded_bytes'] for r in rows),'inventory_sha256':hashlib.sha256(p.read_bytes()).hexdigest()}))
