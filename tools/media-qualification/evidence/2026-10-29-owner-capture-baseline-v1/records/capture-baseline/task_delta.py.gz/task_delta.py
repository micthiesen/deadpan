from pathlib import Path
import difflib,json,hashlib
s=Path(__file__).resolve().parent;repo=Path('/Users/michael/Code/deadpan')
names=json.loads((s/'plan/candidate-pins.json').read_text())
rows=[];patch=[]
for name in sorted(names):
 before=s/'plan/before'/name
 old=before.read_bytes() if before.exists() else b'';new=(repo/name).read_bytes()
 assert old!=new,name
 patch.extend(difflib.unified_diff(old.decode().splitlines(True),new.decode().splitlines(True),fromfile='a/'+name if before.exists() else '/dev/null',tofile='b/'+name))
 rows.append({'path':name,'before_sha256':hashlib.sha256(old).hexdigest() if before.exists() else None,'sha256':hashlib.sha256(new).hexdigest()})
(s/'task.patch').write_text(''.join(patch));(s/'task-source-pins.json').write_text(json.dumps(rows,indent=2)+'\n')
(s/'index-queries.txt').write_text(''.join(':'+r['path']+'\n' for r in rows))
print('Seven-file final source delta frozen')
