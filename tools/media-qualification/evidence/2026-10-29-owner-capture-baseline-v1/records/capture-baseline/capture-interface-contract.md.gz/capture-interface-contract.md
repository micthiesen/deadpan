# Actual owner capture admission contract

Status: proposed implementation boundary, frozen after source-pin verification.
Query checkpoint: cb6a81d6ef2d233f07f72922103673548ddf31c8.
The 17 initial source pins are in capture-interface-pins.json; final source
verification and the two parent-applied observer-only branding changes are in
capture-interface-audit.json. Initial pins remain immutable. Current audio.rs
also contains the parent-applied TEST-ONLY old capture observer; no production
capture kernel has been admitted by this document.

This delivery admits the ONE actual capture reached by the sealed admitted
Root/Domain candidates, including the complete span it currently discards.
It does not admit retained_probe_at, retained.owners, raw_domain construction,
or the inner retained graph later moved into an Arc. It adds no cold activation,
cache, query replay, source/media operation, cap, work weight or controller refund.

## 1. Public surface: change the actual admitted result only

Keep AudioOwnerInputCandidates and its plain AudioOwnerInputCapture unchanged
as public compatibility APIs. Their capture and without_selection still return
plain values, with old unmetered allocation/work/error behavior.

Change the ALREADY USED admitted candidates methods to these signatures:

~~~rust
impl<'context, 'plan, I: Copy + Eq, L>
    AdmittedAudioOwnerInputCandidates<'context, 'plan, I, L>
{
    pub fn capture<A: AudioSoundContextAdmission<Issuer = I, Lease = L>>(
        self,
        member: usize,
        limits: AudioQueryLimits,
        admission: &mut A,
    ) -> Result<AdmittedAudioOwnerInputCapture<'plan, I, L>, A::Error>;

    pub fn without_selection<
        A: AudioSoundContextAdmission<Issuer = I, Lease = L>,
    >(
        self,
        admission: &mut A,
    ) -> Result<AdmittedAudioOwnerInputCapture<'plan, I, L>, A::Error>;
}

pub struct AdmittedAudioOwnerInputCapture<'plan, I, L> {
    // PRIVATE: actual value must precede its independent charge.
    value: AudioOwnerInputCapture<'plan>,
    query_canonical: usize,
    query_additional: usize,
    capture_canonical: usize,
    capture_additional: usize,
    forwarded: bool,
    memory: /* existing private Memory<I, L> */,
}
~~~

Export the result through the existing Plan barrels with the admitted candidates.
No Clone, constructor from external Input, naked into_input, into_parts,
independent lease take, or generic commit API is exposed on this result.

Read-only methods:

~~~rust
pub fn input(&self) -> Option<&AudioOwnerInput<'plan>>;
pub fn query_work(&self) -> usize;
pub fn capture_work(&self) -> usize;
pub fn work(&self) -> usize;
pub fn query_canonical_units(&self) -> usize;
pub fn query_additional_units(&self) -> usize;
pub fn capture_canonical_units(&self) -> usize;
pub fn capture_additional_units(&self) -> usize;
pub fn was_forwarded(&self) -> bool;
~~~

was_forwarded states whether C's actual debits have ALREADY reached the trusted
controller. Its value equals A::METERED, checked against the candidates' Q mode
before capture and again on the guarded result before return. False is NOT a
forwarding claim. All sums are bounded/checked provenance, not new debits.

The result borrows only the original RenderPlan lifetime. It retains neither
the candidates' shorter Domain-handle borrow nor an admission/controller borrow.
The actual captured seed owns its finite fields, and its cloned owner borrows
only plan data. This matches the lifetime of the current plain capture result.

without_selection returns the same guarded result with input=None and C=0.
It consumes/drops the already-owned query before releasing its query charge.
It does not validate new capture limits, request fresh controller headroom,
walk, allocate a placeholder Input, or call spend(0).

## 2. One semantic kernel, separate actual ownership lanes

Extend the existing audio_walk_inner semantic body using the current private
Plan admission Budget/Memory/Owned helpers. Legacy audio_walk,
audio_walk_editorial and audio_walk_owner_input remain unmetered wrappers over
that SAME body. No second resolver, counting traversal, one-sample shortcut or
early return after seed capture is allowed.

Minimum private types, with exact names left to the implementation:

~~~rust
type CaptureSlot<I, L> = Owned<Option<AudioDomainSeed>, I, L>;

enum WalkValue<'plan, I, L> {
    Plain(AudioWalkSpan<'plan>),
    Bound(AudioBindingValue<AudioWalkSpan<'plan>, I, L>),
}
struct WalkResult<'plan, I, L> {
    value: WalkValue<'plan, I, L>, // actual Leaf/Stage, FIRST
    memory: Memory<I, L>,       // Plan-owned result fields/Box shell
}
~~~

A non-Bound metered span uses Plain plus metered Plan memory; Plain also stores
unmetered spans. The branch is not a forwarding assertion. These are PRIVATE
guarded representations, not new public policy abstractions.

The generic walk receives a caller-owned guarded capture slot, so a seed captured
before a later failure stays charged while the caller still owns it. Construction
uses a temporary guarded seed and replaces the slot only at the old assignment
point after all its fields succeed. An error must never leave a seed alive with
its charge already released. Old wrappers restore the caller's actual optional
slot on BOTH success and error if their compatibility adapter moves it into a
guard. No cloning is needed for that adapter.

The working constraints/editorial/repeats/retimes/content, optional captured seed,
and returned span have independent ownership lanes. The captured seed may outlive
working storage; the discarded span must not be retained inside its Input charge.
The existing optional editorial-output lane remains absent for candidate capture.
Legacy probe callers keep their old output/order through the false wrapper.

Preserve the complete actual sequence:

1. Hold the SAME candidates' actual query and query charge. Borrow the selected
   clock from its actual first one-sample span, after the old limit validation
   and member-index check. No caller-supplied clock, free OwnerKey or root lookup.
2. Execute all real walking, capture-prefix copying, bound/Preserve constructors,
   envelope/grid/range checks, boundary construction and final Leaf/Stage.
3. At audio_walk_owner_input's CURRENT fallible discard statement, drop the
   entire successful WalkResult before its span/Box/Core leases. A failed result
   also drops all live temporary values before their leases; the captured slot
   remains guarded until its caller handles that error.
4. Only after that successful discard, take the captured seed, classify Owner
   versus EnclosingProcessor, then perform the old observed owner clone.
5. Move that seed into the actual AudioDomain/Input. Its finite-field charges
   and new observed-owner-copy charge move into the public capture carrier.
6. Validate issuer/mode AFTER the Input is already guarded. On late mismatch
   the Input drops before its charge; the query value also drops before Q charge.
   On success, return the guarded capture result, then release the consumed Q.

The exact first/fallback capture predicates, inherited prefix slices, bindings,
bypass_binding, gap/Repeat stable paths, incident editorial filtering, boundary
order and fractional grids are unchanged. Existing errors under ample policy
headroom remain old errors in old order. A genuine NEW policy refusal immediately
before its actual allocation/inspection may precede a later old semantic error.

## 3. Core Bound move and Box shell: no new public Core API

Use actual bound_at_query with the existing Plan budget/CoreAdmission. Core's
real resolved value remains paired inside QueryBound; take its linear child
work once and account it locally without forwarding those units again.

At each CURRENT Box::new(bound) site:

1. Reserve the exact checked layout for AudioBound through the current policy.
2. Safely preallocate Box::<AudioBound>::new_uninit(). Hold the uninitialized box
   before its independent shell lease, with the real bound/Core guard alive.
3. Use the existing trusted allocation-free map_value callback to initialize
   that existing shell with safe Box::write(shell, bound), then move the box
   into the actual content/span with no new allocation or semantic checks.
4. Keep the mapped Core value and Plan shell/result charges paired until the
   complete actual span drops at the existing discard point.

The already-guarded shell must survive any pre-map/post-map issuer failure and
drop before its lease. Do not allocate Box::new inside map_value, take a naked
resolved graph, clone it to escape its guard, use unsafe assume_init, or add
Core boxing/into_parts APIs. Pinned Rust1.97.1 compilation must qualify the exact
safe Box calls. Core source changes are not expected for this delivery.

CaptureSlot contains finite seed metadata, not a Core resolved binding. Thus
capture-only may release the discarded Bound/Core allocations before cloning
the observed owner while still returning a charged Input. This statement does
not apply to a later retained-probe Some result.

## 4. Work and limits: Q and C remain distinct

Keep the candidates' actual Q receipt and all its categories. The selected
capture uses the existing bound:
  C_limit = min(stored_maximum_work - Q_total, fresh_capture_maximum_work).
Q_total includes Q's truthful metered additions. A zero INTERNAL C remainder
goes to the existing walker budget and structural-work failure, never caller
InvalidAudioLimits. Do not request new headroom on absent selection.

The C kernel uses the existing private QueryBudget, with its own counters over
the same bounded remaining C budget. For successful capture:

- Q_total = Q_canonical + Q_additional.
- C_total = C_canonical + C_additional.
- capture.query_work() = Q_total; capture.capture_work() = C_total.
- capture.work() = input.work() = Q_total + C_total.
- With METERED=false, additions are0 and Q/C canonical equal the frozen old
  oracle. Core uses legacy BTree storage. No new traversal charge is fabricated.
- With METERED=true, canonical Q/C still equal their frozen old counterparts.
  Added work records actual new layout/identity/field inspections, and actual
  reached sorted-set comparisons/shifts in admitted Core. Preserve the old
  canonical copy/visit sites, not a reweighted estimate.

Already-paid aggregate copies use the existing private copy_paid convention:
seeded vector lengths, per-node/Sequence/Repeat visits, inherited seed capture
lengths, incident-editorial retain scan, Preserve repeats.len()+1, editorial
output aggregate and BoundaryOwner::capture repeats.len()+1. Do not charge
another canonical len when a helper admits those same copies. Unpaid old clones
keep canonical0 and gain only truthful additional inspections in true mode.

Every actual Plan primitive forwards once in true mode. A Core child forwards
its own primitives, then hands Plan a linear category receipt: account it in the
local C allowance/counters once, WITHOUT a second controller spend. Canonical/
additional counters are provenance, not a transferable right to suppress other
work. On failure there is no success receipt; accepted controller debits remain
spent. Lease drop releases memory only, never work.

The Audio selected branch becomes:

~~~rust
let capture = candidates.capture(index, control.query_limits()?, admission)?;
if capture.was_forwarded() != A::METERED {
    return Err(/* existing typed accounting-mode failure */);
}
if !capture.was_forwarded() {
    control.spend_plan_work(capture.capture_work())?;
}
if let Some(input) = capture.input() {
    let shared = Context::finish_paid_owner_input_admitted(
        input, input.owner(), at, control, admission,
    )?;
    // Existing actual Context/Description creation using shared.
}
// capture's source Input drops before its source charge, after the borrow.
~~~

Q is already admitted/billed before FIRST-key selection and treatment-layer
checks at the existing node_description point. Do not bill Q again using
Input.work. The false branch still pays successful C once at the old location.
The true branch MUST remove only that duplicated C spend, since C's real kernel
already streamed it. Existing probe and retained-owner-query spends remain.

## 5. Consumer borrow through probe and final share

The source Input carrier remains live and charged throughout the EXISTING
finish_paid_owner_input_admitted call. That function still executes exactly one
retained_probe_at, bills its positive work even None, and executes the same
retained.owners/boundary decision and final share operation.

When the helper returns:
- Domain fallback owns an independently admitted clone and Arc, so it does not
  borrow source Input metadata.
- Accepted Retained owns newly constructed legacy probe metadata plus its
  already-admitted final Arc shell. Those inner probe allocations are explicitly
  OUTSIDE this capture-only admission, as they were before this slice.

Therefore source Input charge may end after the helper and Context construction.
No captured Input lease is committed to Graph. Existing final-sharing carrier
and joint Graph publication remain unchanged. Do not merge source Input charges
into that carrier simply to retain freed construction storage. Conversely, do
not claim that dropping the source carrier admits the probe's new metadata.

This slice implements NO probe/Arc ownership bridge. Future admitted probe
would need its actual processing/Core/raw-domain charges paired through owners,
boundary decision and Arc publication. That unresolved lifetime cannot be
silently solved with Arc::new inside Core map_value or an unchecked lease split.

## 6. Allocation and failure verification contract

Baseline first: parent must execute/pin the OLD test-only capture/discard/probe
producer in both actual runtime variants before the new kernel changes. The
observer is neither admission implementation nor a peak-memory oracle. Preserve
its immutable ordered logical fields, old errors and Q/C/probe canonical work.
The existing query14cases and supplemental unbound Leaf/Preserve cases cover
both complete walked values and late error after a populated capture slot.

Implementation tests must additionally establish:

- Real Root and hidden seeded Domain, WholeRepeat/default/override gaps,
  preserved fractional44.1kHz/grid/reanchor behavior. Compare actual captured
  Input AND full discarded Leaf/Stage to frozen old logical values.
- Same successful canonical C; separately measured new added C; real numerical
  consumer performs no extra membership query or capture and no duplicate spend.
- Exact measured live allocation peak and one-byte-short refusal; Q query,
  working state, early captured seed, late span/boundary/Box may overlap.
- Full-new plus old buffer overlap on growth, actual reached capacity,
  owning-ID edges, cleared boundary-vector capacity, empty buffers and all
  failure exits. No guessed BTree per-entry byte charge or whole-depth reserve.
- Early slot capture followed by a refused later boundary/Box/stage construction
  fails with no partial Input publication; ample resources preserve the old
  later semantic failure. Observe real guarded drop events, no provider/fake PCM.
- Unstable/foreign issuer before/after callbacks; cancellation/deadline/work/
  memory errors retain their typed cause, accepted work and complete cleanup.
- No-selection without fresh limits, internal C0, exact/one-short local work,
  and METERED=false legacy Q/C/probe work/order against frozen outputs.
- Capture carrier borrowing remains valid through actual existing Some/None
  probe and final sharing; no source lease leak after success/error/Graph cleanup.

Parent owns all compilation, baseline/qualification execution, PCM/source/
dependency/depth regression and resource receipts. This document claims no
execution result, total cold-resource closure, native memory bound or batching.

## 7. Small ownership split and integration order

Plan worker owns the actual shared walker/capture/result and narrowly reached
boundary/stage constructors; may add private capture-builder modules to keep
audio.rs focused. Reuse audio_owner_query_admission helpers, extending actual
finite field copies only where needed, and audio_bound_query's private move
adapter for the existing Box site. Parent owns barrels and the Audio C-mode/
borrow integration plus tests. Core public policy/value interfaces stay unchanged.

Compile dependency: Plan generic walker and admitted result, then parent Plan
reexports and actual Audio borrow/mode consumer in the SAME candidate; no
published unused admitted capture API or query-only caller mismatch. Legacy
probe and all other false wrappers must continue to compile/use the same kernel.
Actual old baseline evidence and contract source pins remain immutable.
