from pathlib import Path
p=Path('/tmp/deadpan-owner-capture-baseline-2026-10-29/plan/candidate/crates/deadpan-plan/src/audio_owners/legacy_snapshot_v1/capture_baseline.rs')
s=p.read_text()
old='''    let actual = super::fixtures::matrix();
    let events = session.finish();'''
assert old in s
s=s.replace(old,'''    let actual = super::fixtures::matrix();''')
anchor='''    assert_eq!(names.len(), 14);
    for name in &names {'''
new='''    assert_eq!(names.len(), 14);
    // Derive two ordinary validated documents from the SAME frozen fixture.
    // This is actual legacy compilation/capture, never a fabricated Domain.
    let point = actual.iter().find(|f|
        f["fixture"] == "nonunity_shift_fractional_point_ceil_source44100").unwrap();
    let historical = ProjectDocument::from_json(
        &point["witnesses"]["historical_document"].to_string()).unwrap();
    let stage_plan = RenderPlan::compile(&historical).unwrap();
    let stage = super::case(
        "supplemental_unbound_shift_stage", Parent::Root(&stage_plan),
        AudioSample(0)..stage_plan.audio_duration().unwrap(), AudioSample(4),
        "stage", AudioOwnerKind::Node,
    );
    let mut unbound_source_wire = point["document"].clone();
    unbound_source_wire.as_object_mut().unwrap().remove("audio_bindings");
    let source_doc = ProjectDocument::from_json(&unbound_source_wire.to_string()).unwrap();
    let source_plan = RenderPlan::compile(&source_doc).unwrap();
    let source = super::case(
        "supplemental_unbound_source44100", Parent::Root(&source_plan),
        AudioSample(0)..source_plan.audio_duration().unwrap(), AudioSample(0),
        "voice", AudioOwnerKind::Node,
    );
    let supplemental = vec![
        json!({"document":historical,"case":stage}),
        json!({"document":source_doc,"case":source}),
    ];
    let events = session.finish();
    let supplemental_names = supplemental.iter().map(|v|
        v["case"]["name"].as_str().unwrap()).collect::<Vec<_>>();
    for name in names.iter().chain(&supplemental_names) {'''
assert anchor in s
s=s.replace(anchor,new)
s=s.replace('''"fixtures":actual,"events":events,''','''"fixtures":actual,"supplemental":supplemental,"events":events,''')
# Cross-check supplemental cases actually exercise the intended paths.
anchor='''    let body = json!({'''
new='''    assert!(events.iter().any(|v|
        v["case"] == "supplemental_unbound_shift_stage"
        && v["observation"]["walk"]["discarded_span"]["value"]["content"]["tag"] == "Stage"),
        "supplement must reach the actual AudioStage descriptor");
    assert!(events.iter().any(|v|
        v["case"] == "supplemental_unbound_source44100"
        && v["observation"]["walk"]["discarded_span"]["value"]["content"]["type"] == "source"),
        "supplement must reach an actual unbound Source leaf");
    let body = json!({'''
assert s.count(anchor)==1
s=s.replace(anchor,new)
p.write_text(s)
