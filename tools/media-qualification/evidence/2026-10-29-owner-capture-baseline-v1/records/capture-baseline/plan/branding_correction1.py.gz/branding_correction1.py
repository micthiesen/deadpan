from pathlib import Path
import json,hashlib,difflib
root=Path('/Users/michael/Code/deadpan')
s=Path('/tmp/deadpan-owner-capture-baseline-2026-10-29/plan/branding-correction1')
paths=['crates/deadpan-plan/src/audio_bound.rs','crates/deadpan-plan/src/audio_owner_input.rs','crates/deadpan-plan/src/audio_owners/legacy_snapshot_v1/capture_baseline.rs']
for p in paths:
 for part in ['before','candidate']:
  dst=s/part/p;dst.parent.mkdir(parents=True,exist_ok=True);dst.write_bytes((root/p).read_bytes())
def edit(p,a,b):
 f=s/'candidate'/p;t=f.read_text();assert t.count(a)==1,(p,t.count(a),a);f.write_text(t.replace(a,b))
bound,input,producer=paths
sig='''pub(in crate::plan) fn capture_baseline_snapshot(&self) -> serde_json::Value {'''
newsig='''pub(in crate::plan) fn capture_baseline_snapshot(
        &self,
        expected_plan: &RenderPlan,
    ) -> serde_json::Value {'''
edit(bound,sig,newsig)
edit(bound,'''        use super::audio_owners::tests::legacy_snapshot_v1::capture_baseline as snapshot;
        let Self {
            plan,
            node,''','''        use super::audio_owners::tests::legacy_snapshot_v1::capture_baseline as snapshot;
        assert!(self.belongs_to(expected_plan));
        let Self {
            plan: _,
            node,''')
edit(bound,'''            "belongs_to_expected_plan":self.belongs_to(plan),
            "node":plan.nodes[*node].inspection.id.as_str(),''','''            "belongs_to_expected_plan":true,
            "node":expected_plan.nodes[*node].inspection.id.as_str(),''')
edit(bound,'''snapshot::constraint(plan,v)''','''snapshot::constraint(expected_plan,v)''')
edit(input,sig,newsig)
edit(input,'''        use super::audio_owners::tests::legacy_snapshot_v1::capture_baseline as snapshot;
        let Self {
            plan,
            processing,''','''        use super::audio_owners::tests::legacy_snapshot_v1::capture_baseline as snapshot;
        assert!(self.belongs_to(expected_plan));
        assert!(std::ptr::eq(self.plan, expected_plan));
        let Self {
            plan: _,
            processing,''')
edit(input,'''            "belongs_to_expected_plan":self.belongs_to(plan),
            "processing":snapshot::processing(plan, processing),
            "editorial":snapshot::editorial(plan, editorial),
            "raw_domain":snapshot::bound_domain(plan, domain),''','''            "belongs_to_expected_plan":true,
            "processing":snapshot::processing(expected_plan, processing),
            "editorial":snapshot::editorial(expected_plan, editorial),
            "raw_domain":snapshot::bound_domain(expected_plan, domain),''')
edit(input,'''capture_baseline::probe_result(
            input.as_ref(),''','''capture_baseline::probe_result(
            self.context.plan,
            input.as_ref(),''')
edit(producer,'''Bound(value) => json!({"tag":"Bound","value":value.capture_baseline_snapshot()}),''','''Bound(value) => json!({"tag":"Bound","value":value.capture_baseline_snapshot(plan)}),''')
edit(producer,'''pub(in crate::plan) fn probe_result(
    value:''','''pub(in crate::plan) fn probe_result(
    expected_plan: &RenderPlan,
    value:''')
edit(producer,'''value.map(|v|v.capture_baseline_snapshot())''','''value.map(|v|v.capture_baseline_snapshot(expected_plan))''')
(s/'owned-files.txt').write_text('\n'.join(paths)+'\n')
(s/'before-pins.json').write_text(json.dumps({p:hashlib.sha256((s/'before'/p).read_bytes()).hexdigest() for p in paths},indent=2)+'\n')
print(s)
