# Owner capture baseline, first compile snapshot

Scratch-only producer against current query-only checkpoint cb6a81d6ef2d233f07f72922103673548ddf31c8.
No live/scoped/index edits, Cargo, rustc, provider, native or media operation was run.
Parent owns both builds, execution, runtime authority and immutable output pins.

## Actual path

The only walker change names its existing Result, observes it under cfg(test),
then applies the same question-mark/discard statement. The actual
audio_walk_inner runs once, including the late span/envelope/boundary body.
The observer borrows that returned span and the caller's actual capture slot.
It neither reconstructs a Domain nor makes an oracle query/walk. Errors record
the actual still-populated slot if early capture succeeded before a late refusal.

retained_probe_at similarly observes its actual audio_walk_editorial Result
and EditorialCapture before the existing Some/None match. Its second hook
borrows the actually constructed optional retained input after raw_domain.
No traversal is added. A raw_domain failure would retain the walk observation
but have no success/result observation. This producer's existing fixtures
expect successful probes and retain their old error/work receipts separately.

The old frozen case function supplies scope and phase labels to all six of its
existing direct/candidate ample/exact/one-short captures. The existing probe
call is unchanged. Matrix setup outside each case is intentionally unrecorded.
This instrumentation does not turn an extra replay into the oracle: it records
the independent preexisting calls already present in the frozen case builder.

All observer state is thread_local RefCell<Option<Recording>>. Inactive hooks
only inspect that None or absent case and return before building JSON, cloning,
or growing a buffer. Case labels allocate only with an active Session. Session
and CaseScope guards clear recording state on unwind. Other tests running in
parallel cannot share it. There is no unsafe/global allocator or product API.

## Schema and coverage

OwnerCaptureBaselineV1 contains the same five fixture documents and 14 complete
case objects as frozen SnapshotV1. The producer asserts literal equality of
that entire fixture array against the immutable repository JSON before output.
The query expectations and frozen fixture builders are not regenerated/edited.

An ordered events array adds phase-labelled actual observations:
- selected clock and all captured private seed fields, including inherited
  prefix constraints/editorial, gap, retimes, suppression and instance;
- actual complete discarded Leaf/Stage span, exact scalar maps/grid, envelope,
  ordered start/end boundary origins and full content;
- actual Bound fields, including its skipped node and constraints, plan-brand
  assertion, resolved binding, support, envelope scale and reference affine;
- actual probe walked span/editorial and final processing/editorial/raw domain.

Leaf and processing span serializers exhaustively destructure their structs;
private Bound and retained input serializers exhaustively destructure those
structs. Their existing logical serde fields use ExactRatio's normalized decimal
string wire. Stable node IDs replace internal indices. Boundary vectors stay
in original order. AudioStage uses its logical descriptor plus a plan-brand
assertion. No Debug string, pointer, raw object bytes, capacity, wall time,
allocation counter or media-open claim enters the semantic output.

RootRoundEven raw domains use the complete existing private-seed serializer.
PointCeil records the complete public definition/root/placement/reference
grid/samples/affine map. It explicitly does NOT inspect its private AudioSignal
provider; this is a declared coverage limit, not a claim of private-signal
closure. ProjectedStage has a published logical serializer but is not exercised
by the 14 frozen cases. No projection is fabricated to broaden support.

Two supplemental cases use ordinary validated documents from the same frozen
44.1 kHz fixture:
1. Its actual historical unbound Shift document at sample 4, selecting stage,
   must produce a real AudioStage descriptor.
2. Its current Source document with audio_bindings removed and normal
   ProjectDocument validation/RenderPlan compilation must produce an actual
   unbound Source leaf at sample 0.
Their complete document/case objects are stored separately as supplemental.
They do not replace or mutate the original 14 expectations. All 16 cases assert
six actual capture events, a probe walk/result, Leaf/Stage coverage, and a late
error with a populated capture slot. Parent runtime must qualify these fixture
assumptions before freezing a golden.

## Run and pin contract

The ignored test is:
plan::audio_owners::tests::legacy_snapshot_v1::capture_baseline::capture_legacy_owner_capture_baseline_v1
Use the actual test binary's list to confirm its full path before execution.

Required environment:
- DEADPAN_OWNER_CAPTURE_OUTPUT: new absolute /tmp or /private/tmp JSON path.
- DEADPAN_OWNER_CAPTURE_VARIANT: main-inherited or scoped-published.
- DEADPAN_OWNER_CAPTURE_SOURCE_SHA256: SHA256 of parent-pinned runtime authority.

The output uses create_new and sync_all. No existing golden can be overwritten.
Capture once under each actual old capture kernel, then compare fixtures,
supplemental and events arrays across variants. Variant/source-authority strings
are expected to differ. Parent pins executable and complete runtime sources,
including any inherited Core differences. Existing query JSON remains immutable.

source-authority-before.json pins every Core/Plan Rust source, manifests,
workspace lock/toolchain and old query JSON (330 paths) from the current main
text. source-authority-candidate.json overlays the seven candidate files,
including the new producer. The same 330-path before manifest is not a claim
that main and scoped authorities are byte-identical. Parent must derive the
scoped manifest from its actual sources. Exact changed before snapshots and
candidate hashes accompany the patch.

## Verification status

Scoped rustfmt parsing completed for owned files only. No compiler/test result
is claimed. This observer deliberately adds serializer allocations while the
observed metadata is alive, so these runs are logical/work/error baselines,
NOT evidence for admission peak bytes or native/resource closure. The next
admitted capture/probe implementation must compare to these frozen old outputs;
its own heap/issuer/drop tests remain separate.
