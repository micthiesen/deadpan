from pathlib import Path
import hashlib,json
root=Path('/Users/michael/Code/deadpan')
scratch=Path('/tmp/deadpan-owner-capture-baseline-2026-10-29/plan')
existing=[
'crates/deadpan-plan/src/audio.rs',
'crates/deadpan-plan/src/audio_bound.rs',
'crates/deadpan-plan/src/audio_owner_input.rs',
'crates/deadpan-plan/src/audio_owners.rs',
'crates/deadpan-plan/src/audio_owners/tests.rs',
'crates/deadpan-plan/src/audio_owners/legacy_snapshot_v1.rs',
]
for rel in existing:
    data=(root/rel).read_bytes()
    for prefix in ['before','candidate']:
        path=scratch/prefix/rel
        path.parent.mkdir(parents=True,exist_ok=True)
        path.write_bytes(data)
(scratch/'before-pins.json').write_text(json.dumps({p:hashlib.sha256((root/p).read_bytes()).hexdigest() for p in existing},indent=2)+'\n')
def edit(rel,old,new):
    path=scratch/'candidate'/rel
    text=path.read_text()
    assert text.count(old)==1,(rel,text.count(old),old[:80])
    path.write_text(text.replace(old,new))
prefix='crates/deadpan-plan/src/'
edit(prefix+'audio_owners.rs','#[path = "audio_owners/tests.rs"]\nmod tests;','#[path = "audio_owners/tests.rs"]\npub(in crate::plan) mod tests;')
edit(prefix+'audio_owners/tests.rs','#[path = "legacy_snapshot_v1.rs"]\nmod legacy_snapshot_v1;','#[path = "legacy_snapshot_v1.rs"]\npub(in crate::plan) mod legacy_snapshot_v1;')
edit(prefix+'audio_owners/legacy_snapshot_v1.rs','mod fixtures;','mod fixtures;\n\n#[path = "legacy_snapshot_v1/capture_baseline.rs"]\npub(in crate::plan) mod capture_baseline;')
edit(prefix+'audio_owners/legacy_snapshot_v1.rs',') -> Value {\n    let plan = parent.plan();\n    let one = at..AudioSample(at.0 + 1);',') -> Value {\n    let _capture_scope = capture_baseline::case_scope(name);\n    let plan = parent.plan();\n    let one = at..AudioSample(at.0 + 1);')
# Phase labels refer to actual preexisting calls; they do not invoke queries.
for old,new in [
('    let legacy = parent.input(owner, at, Default::default()).unwrap();','    capture_baseline::phase("legacy_input_ample");\n    let legacy = parent.input(owner, at, Default::default()).unwrap();'),
('    let captured = candidates.capture(member, Default::default()).unwrap();','    capture_baseline::phase("candidate_capture_ample");\n    let captured = candidates.capture(member, Default::default()).unwrap();'),
('    let i_exact = parent.input(owner, at, q_limits(legacy.work()));','    capture_baseline::phase("legacy_input_exact");\n    let i_exact = parent.input(owner, at, q_limits(legacy.work()));'),
('    let i_short = parent.input(owner, at, q_limits(legacy.work() - 1));','    capture_baseline::phase("legacy_input_one_short");\n    let i_short = parent.input(owner, at, q_limits(legacy.work() - 1));'),
('    let c_exact = parent','    capture_baseline::phase("candidate_capture_exact");\n    let c_exact = parent'),
('    let c_short = parent','    capture_baseline::phase("candidate_capture_one_short");\n    let c_short = parent'),
('    json!({"name":name,"parent_kind":match parent','    capture_baseline::phase("retained_probe_ample");\n    json!({"name":name,"parent_kind":match parent'),
]:
    edit(prefix+'audio_owners/legacy_snapshot_v1.rs',old,new)
old='''        self.audio_walk_inner(
            sample,
            budget,
            seed,
            true,
            true,
            (Some(capture), None, Some(owner)),
        )?;
        Ok(())'''
new='''        #[cfg(test)]
        let before = budget.remaining;
        let walked = self.audio_walk_inner(
            sample,
            budget,
            seed,
            true,
            true,
            (Some(capture), None, Some(owner)),
        );
        #[cfg(test)]
        super::audio_owners::tests::legacy_snapshot_v1::capture_baseline::capture(
            self, sample, owner, capture.as_ref(), &walked, (before, budget.remaining),
        );
        // Preserve the actual complete walk and its original discard point.
        walked?;
        Ok(())'''
edit(prefix+'audio.rs',old,new)
old='''        let walked = self.context.plan.audio_walk_editorial(
            at,
            &mut budget,
            Some(&self.context.seed),
            (true, true),
            &mut editorial,
        )?;
        let input = match walked {'''
new='''        let walked = self.context.plan.audio_walk_editorial(
            at,
            &mut budget,
            Some(&self.context.seed),
            (true, true),
            &mut editorial,
        );
        #[cfg(test)]
        super::audio_owners::tests::legacy_snapshot_v1::capture_baseline::probe_walk(
            self.context.plan, at, &walked, &editorial,
            (limits.maximum_work, budget.remaining),
        );
        let walked = walked?;
        let input = match walked {'''
edit(prefix+'audio_owner_input.rs',old,new)
edit(prefix+'audio_owner_input.rs','''        Ok(AudioOwnerRetainedProbe {
            input,
            work: limits.maximum_work - budget.remaining,
        })''','''        #[cfg(test)]
        super::audio_owners::tests::legacy_snapshot_v1::capture_baseline::probe_result(
            input.as_ref(), limits.maximum_work - budget.remaining,
        );
        Ok(AudioOwnerRetainedProbe {
            input,
            work: limits.maximum_work - budget.remaining,
        })''')
# Inspect actual owned fields without cloning or querying the private values.
edit(prefix+'audio_owner_input.rs',"""impl<'plan> AudioOwnerRetainedInput<'plan> {
    pub(super) fn clock_origin""","""impl<'plan> AudioOwnerRetainedInput<'plan> {
    #[cfg(test)]
    pub(in crate::plan) fn capture_baseline_snapshot(&self) -> serde_json::Value {
        use super::audio_owners::tests::legacy_snapshot_v1::capture_baseline as snapshot;
        let Self { plan, processing, editorial, domain, work } = self;
        serde_json::json!({
            "belongs_to_expected_plan":self.belongs_to(plan),
            "processing":snapshot::processing(plan, processing),
            "editorial":snapshot::editorial(plan, editorial),
            "raw_domain":snapshot::bound_domain(plan, domain),
            "work":work,
        })
    }

    pub(super) fn clock_origin""")
edit(prefix+'audio_bound.rs',"""impl crate::audio_allocated::OwnedHeap for AudioBound<'_> {""","""#[cfg(test)]
impl AudioBound<'_> {
    pub(in crate::plan) fn capture_baseline_snapshot(&self) -> serde_json::Value {
        use super::audio_owners::tests::legacy_snapshot_v1::capture_baseline as snapshot;
        let Self {
            plan, node, definition, instance, gap, resolved, reference_at_anchor,
            reference_step, support, envelope_scale, constraints,
        } = self;
        serde_json::json!({
            "belongs_to_expected_plan":self.belongs_to(plan),
            "node":plan.nodes[*node].inspection.id.as_str(),
            "definition":definition,"instance":instance,"gap":gap,"resolved":resolved,
            "reference_at_anchor":reference_at_anchor,"reference_step":reference_step,
            "support":support,"envelope_scale":envelope_scale,
            "constraints":constraints.iter().map(|v|snapshot::constraint(plan,v)).collect::<Vec<_>>(),
        })
    }
}

impl crate::audio_allocated::OwnedHeap for AudioBound<'_> {""")
print('captured and prepared six existing test-only hook files')
