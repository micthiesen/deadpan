from pathlib import Path
import hashlib,json,difflib
repo=Path('/Users/michael/Code/deadpan')
s=Path('/tmp/deadpan-owner-capture-baseline-2026-10-29/plan')
sha=lambda b:hashlib.sha256(b).hexdigest()
# Reached-kernel source authority: all Core + Plan Rust, both manifests, pinned
# compiler/workspace files, and the immutable logical query fixture JSON.
paths=[]
for crate in ['deadpan-core','deadpan-plan']:
    paths += [str(p.relative_to(repo)) for p in sorted((repo/'crates'/crate/'src').rglob('*.rs'))]
    paths += ['crates/'+crate+'/Cargo.toml']
paths += ['Cargo.toml','Cargo.lock','rust-toolchain.toml',
    'crates/deadpan-plan/tests/fixtures/owner-query-baseline-v1/snapshot.json']
before={p:sha((repo/p).read_bytes()) for p in sorted(paths)}
(s/'source-authority-before.json').write_text(json.dumps(before,indent=2)+'\n')
owned=[str(p.relative_to(s/'candidate')) for p in sorted((s/'candidate').rglob('*.rs'))]
patch=[]
current={}
for p in owned:
    a=s/'before'/p
    b=s/'candidate'/p
    old=a.read_text() if a.exists() else ''
    new=b.read_text()
    patch += difflib.unified_diff(old.splitlines(True),new.splitlines(True),
       fromfile='a/'+p if a.exists() else '/dev/null',tofile='b/'+p)
    current[p]=sha(b.read_bytes())
    if a.exists():
        assert sha(a.read_bytes())==before[p]
        assert (repo/p).read_bytes()==a.read_bytes(),f'live drift: {p}'
(s/'capture-baseline.patch').write_text(''.join(patch))
(s/'candidate-pins.json').write_text(json.dumps(current,indent=2)+'\n')
candidate_authority=dict(before)
candidate_authority.update(current)
(s/'source-authority-candidate.json').write_text(json.dumps(candidate_authority,indent=2)+'\n')
(s/'owned-files.txt').write_text('\n'.join(owned)+'\n')
print(json.dumps({
    'patch_sha256':sha((s/'capture-baseline.patch').read_bytes()),
    'candidate_pins_sha256':sha((s/'candidate-pins.json').read_bytes()),
    'before_authority_sha256':sha((s/'source-authority-before.json').read_bytes()),
    'candidate_authority_sha256':sha((s/'source-authority-candidate.json').read_bytes()),
    'source_paths':len(before),'owned_files':len(owned),
},indent=2))
