# Capture-only admission design review

Scope: read-only review of `next-capture-core.md` and `next-capture-plan.md` against the current query-only Core and Plan source. No build or source changes performed.

## Result

No blocking design flaw found in the proposed capture-only slice. The notes correctly keep the actual `audio_walk_inner` execution and its full discarded `AudioWalkSpan`; an early return after capturing the requested seed would skip real allocations, work, and late failures. The inventory covers the visible Plan-owned growth/copies, captured seed, Bound shell, Preserve stage, boundary origins, final discarded span, and post-walk observed clock clone. Existing prepaid work is distinguished from new allocation/inspection charges, and the capture lease is explicitly required to outlive the captured `Input` while the discarded span's lease ends at the existing drop point.

## Required implementation constraints

- Keep capture-slot ownership and its charge together across the entire walk, including when the slot becomes `Some` and a later walk step fails. Drop the seed value before its lease on both success and failure; do not let a callee-local charge end while the caller's slot retains the seed.
- Keep the returned span and each independently charged Plan/Core allocation in value-before-lease guards. At the existing discarded-span statement, drop the complete span before releasing those charges. The returned capture input has a separate longer-lived charge.
- The Box bridge is viable under the stated constraints: reserve the exact `AudioBound` layout, safely allocate `Box<MaybeUninit<AudioBound>>`, and initialize it with `Box::write` inside Core's existing allocation-free move callback. Do not use `Box::new` in `map_value`, `assume_init`, or a generic naked value/lease extraction. The shell guard must own the uninitialized box before its lease and transfer the initialized `Box<AudioBound>` without an intervening allocation.
- Preserve `capture_observed`'s clone-after-success ordering and all old canonical debits exactly once. The metered walk may add truthful inspection/reservation work; it must not silently add canonical charges for copies already prepaid by the listed aggregate debits.
- Keep the new input/lease paired in the admitted capture result through the existing consumer. The legacy public result may keep an explicit unit-lease conversion; the metered path must not return a bare `AudioOwnerInput` while releasing its memory lease.

The notes appropriately defer retained-probe allocation and Arc publication, and make no cold recursion or whole-graph claim. Required pinned-toolchain compilation, peak/one-byte-short checks, late-failure cleanup, and the listed semantic regressions remain implementation verification, not evidence established by this design review.
