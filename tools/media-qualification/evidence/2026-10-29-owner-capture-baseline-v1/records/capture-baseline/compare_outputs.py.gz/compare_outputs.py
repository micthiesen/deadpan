from pathlib import Path
import hashlib,json,collections
s=Path(__file__).resolve().parent
a=json.loads((s/'main-output-v1.json').read_text());b=json.loads((s/'scoped-output-v1.json').read_text())
variable={'variant','runtime_source_manifest_sha256'}
assert a.keys()==b.keys()
assert {k:v for k,v in a.items() if k not in variable}=={k:v for k,v in b.items() if k not in variable}
assert a['variant']=='main-inherited' and b['variant']=='scoped-published'
kinds=collections.Counter(e['observation']['kind'] for e in a['events'])
assert kinds=={'actual_audio_walk_owner_input':96,'actual_retained_probe_walk':16,'actual_retained_probe_result':16}
late=sum(e['observation'].get('walk',{}).get('result')=='Error' and e['observation'].get('capture_slot') is not None for e in a['events'])
assert late>0
for kind in ['main','scoped']:
 p=s/(kind+'-output-v1.json');x=json.loads(p.read_text())
 authority=s/(kind+'-authority-v1.json')
 assert hashlib.sha256(authority.read_bytes()).hexdigest()==x['runtime_source_manifest_sha256']
 r=json.loads((s/('capture-'+kind+'-v1.json')).read_text())
 assert r['exit_code']==0 and r['sources_unchanged'] and r['binaries_unchanged']
 assert '1 passed; 0 failed; 0 ignored' in (s/('capture-'+kind+'-v1.stdout')).read_text()
logical={k:v for k,v in a.items() if k not in variable}
rows={n:{'bytes':(s/n).stat().st_size,'sha256':hashlib.sha256((s/n).read_bytes()).hexdigest()} for n in ['main-output-v1.json','scoped-output-v1.json','main-authority-v1.json','scoped-authority-v1.json']}
result={'both_actual_producers_pass':True,'common_logical_fields_equal':True,'five_families':len(a['fixtures']),'frozen_cases':sum(len(f['cases']) for f in a['fixtures']),'supplemental_cases':len(a['supplemental']),'event_counts':dict(kinds),'late_errors_with_actual_captured_slot':late,'logical_sha256':hashlib.sha256(json.dumps(logical,sort_keys=True,separators=(',',':')).encode()).hexdigest(),'pins':rows,'coverage_limit':'PointCeil private AudioSignal provider is outside this capture-only oracle; extend before retained-probe admission.'}
(s/'comparison.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result))
