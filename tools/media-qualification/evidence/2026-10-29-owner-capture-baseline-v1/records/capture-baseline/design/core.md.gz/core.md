# Next actual capture admission after the query-only delivery

Read-only next-step contract against the current integrated query source.
next-capture-pins.json records exact bytes. No live source, Cargo/rustc, Git,
provider or native execution was changed/run for this research.

## Preferred next delivery

Admit the SAME capture that AdmittedAudioOwnerInputCandidates::capture currently
calls, including its complete discarded AudioWalkSpan. Reuse the integrated
query Budget/Memory/Owned helpers and actual bound_at_query/Core policy bridge.
No new Core resolver or ancestry API is required. No cold activation.

Keep retained_probe_at/raw_domain/retained.owners explicitly outside this
capture-only closure until the follow-up below is implemented. The source Input
then remains alive and charged while that legacy probe runs; this does not
make the probe's NEW allocations admitted.

## Current exact entry and authority

audio_owner_input/candidates.rs:208 admitted capture:
- validates SAME issuer and metered mode;
- takes the actual sealed AudioOwnerInputCandidates, retaining its query Memory;
- calls its existing capture(member, limits), then validates issuer again.
- the inner method checks limits/member from the actual first one-sample span;
  computes min(stored_allowance-Q, fresh_capture_allowance), and calls
  capture_observed with Root or the SAME actual Domain seed.
- the actual query stays owned/charged until that inner call finishes. It is
  dropped before the admitted wrapper's query memory releases.

audio_owner_input.rs:324 capture_observed:
- audio_walk_owner_input(..., observed, captured_slot, actual_seed);
- classifies the captured scope from captured instance/gap against observed;
- clones the observed checked clock AFTER the walk succeeds;
- moves seed fields into AudioDomain, then Input, with total work Q+C.

audio.rs:467 audio_walk_owner_input:
- calls audio_walk_inner(sample,budget,seed,true,true,
  (Some(capture),None,Some(owner)))?;
- discards the complete returned AudioWalkSpan at the semicolon;
- only then returns to capture_observed for observed.clone().

audio_walk_inner:486 is the real shared kernel. It also backs ordinary
audio_walk and audio_walk_editorial; do not create another capture-only
descent algorithm. Existing wrappers can choose unmetered policy and move
their unit-charge results back into the ordinary return types.

## Exact allocations still reached by capture

1. Initial actual seeded entry copies constraints/editorial/repeats/retimes and
   gap after its inherited canonical aggregate spend. Root entry starts empty.
2. Loop growth of constraints/editorial/repeats/retimes; Source/RoomTone/Reverse
   SourceAudio metadata owning IDs; repeat/gap IDs; incident editorial filtering.
3. First actual owner capture at audio.rs:647 copies inherited constraint/
   editorial prefixes, Repeat/retime vectors, definition and owner instance.
   This seed stays live while the original working vectors continue.
4. The fallback stopping-processor capture around :972 makes the SAME bounded
   seed shape after Preserve/binding stopping semantics. It must not be treated
   as an ordinary requested-owner input.
5. Bound branches around :610/:740 call actual bound_at. That wrapper is now
   backed by bound_at_query with Unmetered, so a metered capture should call the
   shared kernel using its existing metered Budget instead. All actual Core
   resolver/projection/scratch construction is already instrumentable.
6. The Bound is placed in Box<AudioBound> at that original site.
7. Nonunity Preserve creates AudioStage::for_node(:149 audio_signal.rs):
   project/revision/definition/instance/child IDs + Repeat vector. Its scalar
   recipe/owned-input/derived-extent checks stay in order. Do not replace an
   existing owned-Preserve refusal with a fabricated projected stage.
8. After the loop, allocation/range/envelope validation and capture fallback
   still run. Each exact coincident boundary origin owns a cloned InstancePath
   and optional gap ID; start/end origin vectors grow and can clear.
9. The final Leaf or Stage owns content, instance/retimes/boundaries. This
   allocation is REAL even though audio_walk_owner_input discards the result.
10. After that result drops, capture_observed clones the selected clock,
    including its full retained origin/definition/path/gap when present.

Borrowed RenderPlan/Frozen indexes remain borrowed. No decoder, provider,
source admission, processing/native execution or Repeat expansion occurs here.
Arc identity owning-edge accounting follows the current convention, not an
RSS claim or a new per-byte work weight.

## Minimal implementation shape

Use the existing private audio_owner_query_admission::Budget<'_,A>, Memory and
Owned value-first guards, without renaming the public sound policy just for
this extension. Factor audio_walk_inner into one generic actual kernel with
an unmetered compatibility wrapper; all semantic loops/branches remain there.

A small private capture builder needs separate owned lanes:
- working vectors/content and their capacities/owning edges;
- captured AudioDomainSeed and its independent Memory;
- optional editorial capture and its independent Memory (needed for the later
  probe, not for candidate capture's None editorial receiver);
- returned actual Leaf/Stage value, with its own result/Core-bound charge.

These are actual owned values/slots, not replayed metadata or a side heap
registry. Do not merge every charge into one Input-wide monotonic sum. Working
and discarded span allocations must drop/release while the captured seed
survives. Capacity/element guards may keep a bounded per-container conservative
owning-edge amount until that container drops, matching the current helpers;
do not claim per-element exact release without implementing it.

Reuse the actual query copy helpers for instance/origin/definition/gap/
constraints, adding finite EditorialConstraint and AudioRetimeStage copies at
their actual sites. Add a metered AudioStage::for_node shared kernel to preserve
all its fallible checks and field construction order. Reuse grow's real old+new
capacity admission; do not reserve maximum-depth vectors up front.

The actual capture result must now own its Input and Memory, not return a naked
Input while its lease drops. Preferred cross-crate shape:
  AdmittedAudioOwnerInputCapture<'plan,I,L>
    private Option<AudioOwnerInput<'plan>> FIRST, then capture Memory;
    query/capture canonical+additional receipt and trusted forwarded mode;
    input()->Option<&AudioOwnerInput>; no generic bare into_input.
The actual Audio consumer borrows this Input through existing final sharing,
then drops it before its Memory. Unmetered compatibility may expose an explicit
unit-lease conversion as current helpers do. This is an API change only in the
actual admitted capture branch, wired in the same delivery; no unused stub.

The admitted query carrier must keep its query Memory throughout that same
capture. If late issuer validation fails, the newly built Input must already
sit in its value-first guard so it drops before its capture charge and before
the outer query charge. No partial token is returned after errors.

## Safe Bound boxing without changing Core map_value

The current Core map_value callback is intentionally allocation-free. Calling
Box::new inside it would violate that contract, even with an earlier estimate.

A safe Plan-only seam (also independently identified by the Plan worker):
1. At the OLD Box::new(bound) site, reserve Layout::new::<AudioBound>() in a
   separate Plan shell guard. The actual Core-mapped bound still owns T and
   its Core lease; no field is taken early.
2. Safely allocate Box::<AudioBound>::new_uninit(), stored in that value-first
   shell guard. MaybeUninit<T> has T's exact layout.
3. Existing Core map_value's trusted move-only closure uses
   Box::write(shell,bound), which initializes the existing shell without a
   second allocation or project unsafe. Then move that Box into the actual
   Content/Stage/Span through further allocation-free constructors.
4. Core-mapped value owns the actual returned span/Box. Keep the Plan shell
   lease and other Plan metadata leases beside it until that value drops.

This needs pinned-toolchain safe Box::new_uninit/Box::write compilation
verification by parent, not an unsafe assume_init or a new generic boxing API.
It preserves old clone count and allocation position, with the new policy
refusal permitted immediately before its actual shell allocation.

For capture-only, the returned Bound span is discarded. Therefore its Core/
Box/result leases can all release before observed clock cloning. The captured
seed contains only finite Domain metadata, not ResolvedAudioBinding or a Core
lease. This makes capture a tractable next slice without solving retained Arc
publication yet.

## Canonical work already paid: retain it once

Existing canonical sites to preserve exactly:
- seeded copy aggregate:
  constraints.len + editorial.len + repeats.len + retimes.len;
- per descent loop spend1 and Sequence/Repeat bounded lookup comparisons;
- retain_incident_editorial spend(editorial.len) before its existing retain_mut;
- owner/stopping seed capture:
  inherited_constraints + inherited_editorial + repeats.len + retimes.len +1;
- Preserve descriptor spend(repeats.len+1) before for_node;
- editorial receiver aggregate editorial.len+constraints.len+repeats.len;
- each BoundaryOwner::capture spend(repeats.len+1);
- existing actual bound_at/Core canonical work, locally account_core after
  already-forwarded child primitive debits.

Those aggregate debits already prepay the corresponding copies/traversals.
Copy helpers must use the explicit private copy_paid convention, not charge
another canonical len for every cloned vector/path. Some old clones
(observed.clone after successful walk, some ID copies) had no explicit debit;
keep canonical0 there and bill only actual NEW field/layout/identity inspection
as additional. No synthetic refund or new canonical weight.

Capture metered true now reaches Core's admitted sorted backend, so C gains
additional Core inspection/comparison/shift work. Its canonical C must equal
the frozen old C; Ctotal=Cold+Cadditional. Q retains its independently tracked
query canonical/additional. Probe remains legacy false/BTree and old probe
work until its own phase is admitted. Controller forwards Q/C primitive units
once; actual Audio removes only duplicate already-forwarded C billing when
the typed admitted result says true. False still owes old successful C.

Input.work remains total Q+C provenance. Capture's local cap still uses
min(stored_allowance-Qtotal,fresh_capture_allowance); new work/real eviction can
truthfully reduce headroom. Internal zero stays structural exhaustion; no
InvalidAudioLimits relabel, cap renewal, budget reset or legacy retry.

## Retained/probe ownership: explicit next boundary, not closed by capture

retained_probe_at currently:
- validates limits, checks at inside Input.context;
- audio_walk_editorial into actual processing span + EditorialCapture;
- for a Bound span calls bound.raw_domain, creating Root / Point / Empty;
- returns retained {processing, editorial, raw domain} or successful None,
  with actual work even None.

An admitted probe must keep Input alive/charged across all of this, and guard
the discarded non-Bound result and editorial buffers even on None. It cannot
extract a bare retained object and drop its processing/Core/raw-domain charges.
A Some result's Box<Bound> and Core lease live with the actual retained value,
including through retained.owners and its binding boundary check.

Raw Root conversion can reuse actual root_domain_on_grid_query and admitted
evaluation copies. Raw Point needs finite construction admission through
AudioPointDomain::new and AudioSignal::for_placed_definition/set_evaluation;
an owned signal/selector/path is not a scalar view. Empty still pays performed
work and frees actual discarded temporaries. No second probe or root substitute.

If Some is accepted, those INNER retained charges must transfer with the
final-sharing worker's retained Arc shell into Graph, not release when a
probe.into_input happens. Its current final-sharing guard covers only the new
shell; this later typed handoff must add the inner construction charge under
the same issuer/joint publication. If boundary rejects Some and falls through,
drop retained value before its charges, then perform the existing Domain copy.

That eventual Arc ownership bridge deserves an explicit safe design. Do not
silently put Arc::new inside Core's allocation-free map_value or clone the
retained processing graph to escape the lease. The safe preallocated Box seam
is sufficient for CAPTURE, not proof that generic Arc initialization is solved.
Keep the probe/Arc handoff out of the next capture-only closure claim.

## Meaningful regression/verification contract

- Extend the frozen legacy SnapshotV1 oracle with admitted capture fields;
  canonical C equals frozen C, and total equals C+separately counted added
  operations. Reuse the actual saved pre-Split lattice fixture (plain Source
  Split previously failed to exercise retained Some).
- Real Root and hidden seeded Domain, WholeRepeat selected/default/override
  plays, nonunity Preserve/Shift, fractional PointCeil/RoundEven and44.1kHz
  source support. No detached key or fabricated current owner.
- Direct private shared-kernel test returns an ACTUAL Bound Stage before its
  discard; the same public capture drops that span before cloning selected
  clock. Observe leases with trusted policy, not product hooks or fake PCM.
- Valid root owner captured before later descent: force canonical work or
  actual allocation refusal AFTER seed assignment and assert no Input/partial
  proof published; every earlier copied value drops before its lease. Preserve
  any existing later semantic failure under adequate resource headroom.
- Exact/one-short successful peak, every reached allocation failure, realloc
  old+new, overlapping query+working vectors+captured seed+discarded span,
  and each postcapture error. Do not test only retained final byte size.
- Preserve exact coincident boundary order/policy and retained incident-marker
  filtering; clearing origins retains buffer capacity. No skipping boundary
  construction because the top caller discards the span.
- Typed cancellation/deadline/work/memory refusal at actual sites, unstable/
  foreign issuer before further allocation, value-before-lease drop, Q held
  through C, no-selection with no fresh C budget, zero internal C budget.
- Actual renderer PCM/source/dependency/depth tests remain parent-owned.
  Successful None probe still reports/bills its existing positive work once;
  until probe admission, do not claim its temporary residency is covered.

## Suggested owned file slice

Plan capture owner: audio.rs shared actual walker; audio_boundary.rs capture/
clip helpers; audio_signal.rs only actual for_node constructor; a new private
capture builder/test module; audio_owner_input.rs/candidates.rs actual guarded
capture/result. Reuse audio_owner_query_admission.rs rather than a second
policy family. audio_bound_query.rs only private move-to-content/Box shell
handoff, preserving current actual binding algorithm.

Parent integrates actual Audio typed Input borrow/C billing and exports.
Core: no changes expected for capture if safe Box::write seam compiles. Current
policy/value bridge should be reused. Core changes for the later retained Arc
handoff require a separate agreed ownership contract.

No code, test execution or full cold resource guarantee is claimed by this note.
