# Next boundary: actual capture, then retained-probe construction

Read-only proposal against the frozen query-only candidate. No code, source,
index, Cargo/rustc, provider or native operation was changed/run for this note.
This does not qualify either next boundary or activate cold recursion.

## Actual path and lifetime

There is no capture_selected symbol in the inspected Plan source. The chain is:

AdmittedAudioOwnerInputCandidates::capture (candidates.rs:208)
-> SAME legacy AudioOwnerInputCandidates::capture (:76)
-> capture_observed (audio_owner_input.rs:324)
-> audio_walk_owner_input (audio.rs:467)
-> audio_walk_inner (:486).

The stored query and its selected clock stay live throughout, under the query
lease. Limits validate before member lookup; available = stored maximum_work -
total Q; C limit = min(available, fresh). Zero internal remainder reaches the
actual capture walk and its structural-work error. Preserve this order.

audio_walk_owner_input does NOT stop after capturing the requested seed. It
builds the complete AudioWalkSpan, discards it at the fallible-call statement,
then returns (). The caller's captured Option<AudioDomainSeed> is separate.
Skipping the discarded span skips existing work, allocations, bounds and late
failures, changing the qualified algorithm.

| Actual site | Ownership requiring admission |
| --- | --- |
| audio.rs:531-545 initial seed copy | constraints/editorial/repeats/retimes Vec buffers, nested IDs/gap; selector remains borrowed here |
| :552 onward walk | growing constraints/editorial/repeats/retimes and identity edges; old/new buffer overlap during growth |
| :648 early owner capture | prefix constraint/editorial buffers, repeat/retime copies, selector, separate owner InstancePath; seed survives while walk CONTINUES |
| :608/:728 binding stops | reached bound/Core construction, then actual Box<AudioBound> shell |
| :868 Preserve stop | AudioStage::for_node descriptor (audio_signal.rs:149): project/revision/definition/path/child IDs and repeat buffer |
| Source/Hold leaves | SourceAudio/asset identity copies for Source, RoomTone, Reverse; scalar Tone/Tail/Silence |
| :971 fallback capture | captured seed plus independent instance path when Preserve/binding/default-gap stopped before descendant |
| :995 editorial output | EditorialCapture moves editorial but CLONES constraints/repeats; used by probe |
| :1005 boundary loop | boundary Vecs and AudioBoundaryOrigin path/ID/gap copies, including clear/push |
| :1035-1077 returned span | Stage moves repeats/retimes/content; Leaf additionally owns boundaries; definition/instance IDs copied |
| capture_observed result | observed owner clone, then seed move into Input; scope, observation and provenance work retained |

BoundaryOwner::capture (audio_boundary.rs:51) already charges repeats.len()+1
before cloning. clip_start/clip_end (:85/:104) may clear origins while retaining
Vec capacity. Boundary storage can be quadratic in ancestor path lengths; use
actual arrays and owning edges, not a guessed per-node constant. For Stage,
computed AudioExtent boundary values are temporary: AudioProcessingSpan has no
boundaries field, so those values drop before returning that span.

On error after early capture, the caller's slot can already be Some. A lease
owned only by the walker callee releases too early. The slot itself must pair
its actual optional seed with its charge and issuer across the call/error.
Values must drop before independent leases.

## Minimal capture extension

Extend the SAME audio_walk_inner body with its existing stop/capture semantics,
using the current private Plan budget/guards. Compatibility keeps unmetered
storage and old receipts. Do not duplicate the semantic loop, count first,
replay the query or add an early return after finding the owner.

Use a private guarded capture sink at the existing assignment sites and a
guarded walk result covering the actual Leaf/Stage/discarded value. Extend
existing buffer/ID helpers narrowly for editorial, stage, asset and boundary
fields at their actual construction sites. Admit checked capacities and old/new
growth coexistence.

The admitted entrypoint should return an opaque capture/Input carrier: actual
Input first, remaining charge afterward, borrow access for the existing final
context decision, and sealed C canonical/additional/mode receipts. Keep the old
public AudioOwnerInputCapture API intact. The actual Audio caller skips C only
when that admitted C was forwarded. The current query-only caller still owes
legacy C until this next delivery is wired.

Query drops before its query lease. The new Input charge survives probe/final
sharing until its source Input drops. Do not retain discarded-span workspace in
the Input charge; release its complete guard at the old discard statement.

### Box bridge

Current Core map_value is trusted allocation-free. Do not call Box::new inside
it or extract naked value/lease parts. Reserve the actual Box<AudioBound> layout,
safely preallocate Box::<AudioBound>::new_uninit in a value-before-shell-lease
guard, then use allocation-free Box::write(shell, bound) within map_value.
Map that same guard into actual content/span; keep Plan shell charge beside the
Core guard. Core owner agrees no new Core public API is needed. The exact safe
Box call must be compiler-qualified under the pinned toolchain.

## Semantic constraints

The early match is the current kind/definition/node/repeat-path comparison on
an observation selected from the exact sealed query. Capture precedes descent;
inherited constraint/editorial slices exclude the newly encountered owner's own
entries. Do not substitute whole vectors for those prefixes.

An earlier Preserve or binding stops first. Fallback captures the complete
processor output and scope becomes EnclosingProcessor, even if it contains other
descendants. A direct descendant seed or scope=Owner substitute moves effects
into different DSP input.

Preserve bypass_binding, inherited envelope, suppression bits, transforms,
retimes, gap-after, stable Repeat IDs, signed labels and fractional phase.
RootRoundEven and PointCeil stay distinct. No nominal-clock inverse, numerical
window/root substitution, owner-ID proof or matches_clock_at shortcut is valid.
The frozen hidden-Domain counterexample is mandatory.

Keep existing refusals: audio.rs rejects preserve_input routes requiring splice
placement; for_node rejects wrong kind/unity policy/derived extent. Do not invent
a projection or descend through an opaque stage. Gap occurrences/definitions
retain their actual binding environments.

## Probe is the second boundary

retained_probe_at (audio_owner_input.rs:82) validates limits, then Input support,
creates Budget/EditorialCapture and calls the SAME audio_walk_editorial with
seed and stops=(true,true). It already returns positive actual work for None.
Only Stage(Bound) is accepted; other fully built values drop and produce None.
Do not lose None work or turn resource failure into absence.

For Some, span and EditorialCapture survive while bound.raw_domain() constructs
another owned domain. All three move into AudioOwnerRetainedInput (:152). Current
work derives from the walker budget; raw_domain has no work/admission parameter.

Extend this actual raw_domain constructor:
- RootRoundEven uses the existing definition/placement constructor followed by
  set_domain_evaluation (audio_bound.rs:231-299). Reuse root_domain_on_grid with
  the SAME caller budget/guards.
- PointCeil uses AudioPointDomain::new (audio_point_domain.rs:58), including its
  independent selector and embedded for_placed_definition (audio_signal.rs:699).
  Both own selector/gap edges. Preserve reference grid, signed samples and
  rebased storage transform. The evaluation setter moves separately copied
  definition/repeats/bypass into its signal.
- Empty support returns Empty at the existing scalar check. No invented buffer
  or physical provider.

Old raw-domain copies had no separate canonical debit. Keep that history; bill
new inspections/reservations as additional. Some owns processing/editorial/domain
before leases. None drops all discarded values before charges and retains only
its work receipt. Both use the same issuer and account their real prefix work.

A later handoff decision remains explicit: Some's processing span owns a Core
bound guard and final sharing moves that retained object into Arc. Allocation-free
map_value cannot simply invoke Arc::new. Unlike Box, do not assume a safe Arc
initialization bridge. Before implementation, review a narrowly pre-admitted
move-constructor contract permitting the ONE actual Arc allocation, or another
proven safe typed bridge. This note justifies no unsafe or general into_parts.

The retained-owner query that follows in finish_paid_owner_input_with
(authored_eq.rs:193) is ALSO currently legacy construction. Probe admission alone
does not close it. Preserve its query/boundary decision once; complete numerical
node closure still requires that query and final handoff.

## Work sites and required regressions

Keep canonical sites: seed lengths (:531), node visits (:552), capture-prefix
copies (:639/:961), editorial (:675/:996), Sequence comparisons (:837), stage
path copy (:868), Repeat comparisons (:909), incident-editorial scans (:1091),
and boundary path (:51). Existing prepaid copies must not acquire another
canonical len debit. Core child receipts account locally without forwarding twice.

New metered canonical C must equal frozen old C; total C = old C + separately
counted additions. Probe follows the same rule, including None. Total Q still
reduces stored capture headroom. Host eviction work stays separately observed.
No resets, refunds, retries or weight changes.

BEFORE editing these kernels, extend the independent OLD serializer to record
the currently discarded full Leaf/Stage span, boundary order, stage/bound fields
and probe processing/editorial/raw-domain values. SnapshotV1 already records
Input seeds/C/Some/None/grids, but not every discarded Span/private bound field.
Do not derive new expected fields from the admitted walker.

Required bounded regressions:
1. All14 frozen cases and both modes: full Input/seed, canonical C/probe, old
   compatibility WorkControl receipts and one-time numerical forwarding.
2. Query + parent + captured seed + discarded span coexistence: exact measured
   peak, one byte short, cancellation/error after the slot becomes Some, and
   value-before-lease drop order.
3. A real cap permitting seed capture but refusing later discarded Leaf boundary
   or Stage/Box allocation must fail, proving no early-return shortcut.
4. Bound Root/Point and no-Bound None; repeats/default and overridden gaps;
   Preserve/Shift; transported editorial; hidden support; foreign issuer.
   Plain Source Split is None; the saved pre-Split lattice exercises Root Some.
5. Source/RoomTone/Reverse identities and late errors retain old ample-resource
   order; genuine earlier admission failure remains typed.
6. Actual numerical PCM bits, suppression, dependencies, depth and source checks
   remain identical under the same schedule.

Neither constructor slice alone establishes cold-resource, batching, raw-reader,
fade-query or full graph closure.

## Inspected source pins

Frozen candidate bytes, SHA-256:

- crates/deadpan-plan/src/audio_owner_input/candidates.rs: 19d1b87146dca6e3e17a9a2cc9521c62bd1f1418ac654a267bb1e0a6a4b219c4
- crates/deadpan-plan/src/audio_owner_input.rs: f2eff5bee7991f98a1a54ab1aa55fd2c2e132f69bbf00407a6cf339ceb52c271
- crates/deadpan-plan/src/audio.rs: ec8043289754b22b8c06cc29dd7388d9a74353686328bfec93663ff7e948eeac
- crates/deadpan-plan/src/audio_boundary.rs: 4763f365219fd82f8a7be1a4a8b5900a5878987eb89e44932d0bf1955635aecd
- crates/deadpan-plan/src/audio_signal.rs: 6377d133f1c3cd7f094ca37a7b34e013d498b9e75f5b02d9f661170c35c88d3f
- crates/deadpan-plan/src/audio_bound.rs: ddea6653d17f182c83eed81b1fd1a01e0ed3c4fed0cd2340af12c31f422c4b2b
- crates/deadpan-plan/src/audio_definition.rs: 416f8c1493fb85714a7cf4625b243336a8597e0dca9e93f78a87a9d18959f3c9
- crates/deadpan-plan/src/audio_point_domain.rs: ce5233aad9a57d116410bf73f49abb1fe00376acbe5541e69b2489805dd46dce
- crates/deadpan-plan/src/audio_owner_query_admission.rs: 30e048a11cfcb7d3c8950f716375de6c53cb01955d7dcab88f49802a0d407ec9
- crates/deadpan-core/src/audio_binding/admission.rs: fad6c72f3a0c6c0879a9f54d6648ab79a77b50d1e9116605637be3f14a74c867
- crates/deadpan-audio/src/authored_eq.rs: 96b71f0f0dc3cc711e8827ecebe917e5f9cd9d7b877113962bb294d01004fa63
