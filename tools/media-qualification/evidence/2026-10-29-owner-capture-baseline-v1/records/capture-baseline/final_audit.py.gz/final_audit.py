from pathlib import Path
import hashlib,json
s=Path(__file__).resolve().parent;repo=Path('/Users/michael/Code/deadpan');scoped=Path('/tmp/deadpan-query-groundwork-2026-10-26/scoped')
rows=json.loads((s/'task-source-pins.json').read_text());data=(s/'index-blobs.bin').read_bytes();off=0;equal=[]
for row in rows:
 end=data.index(b'\n',off);head=data[off:end].decode().split();assert head[1]=='blob'
 size=int(head[2]);body=data[end+1:end+1+size];off=end+2+size
 assert hashlib.sha256(body).hexdigest()==row['sha256']
 assert body==(repo/row['path']).read_bytes()==(scoped/row['path']).read_bytes(),row['path']
 equal.append({'path':row['path'],'blob':head[0],'sha256':row['sha256'],'all_three_equal':True})
assert off==len(data) and len(equal)==7
(s/'index-source-equality.json').write_text(json.dumps(equal,indent=2)+'\n')
labels=['capture-build','capture-build2','capture-build3','capture-main-v1','capture-main-library','capture-scoped-build','capture-scoped-v1','capture-scoped-library','capture-strict']
receipts=[]
for label in labels:
 x=json.loads((s/(label+'.json')).read_text())
 assert x['exit_code']==0 and x['sources_unchanged'] and x['binaries_unchanged'],label
 receipts.append({'label':label,'exit_code':0,'seconds':x['seconds'],'source_inputs':len(x['source_before']),'sha256':hashlib.sha256((s/(label+'.json')).read_bytes()).hexdigest()})
for label in ['capture-build3','capture-scoped-build']:
 x=json.loads((s/(label+'.json')).read_text())
 for p,pin in x['source_after'].items():
  b=Path(p).read_bytes();assert len(b)==pin['bytes'] and hashlib.sha256(b).hexdigest()==pin['sha256'],p
old=(s/'plan/before/crates/deadpan-plan/src/audio.rs').read_text()
new=(repo/'crates/deadpan-plan/src/audio.rs').read_text()
start="    fn audio_walk_inner<'plan>(";end='\nfn retain_incident_editorial('
old_body=old[old.index(start):old.index(end)]
new_body=new[new.index(start):new.index(end)]
assert old_body==new_body
assert old[old.index(end):]==new[new.index(end):]
authority=json.loads((s/'plan/source-authority-before.json').read_text())
owned={r['path'] for r in rows};unchanged=0
for name,sha in authority.items():
 if name in owned:continue
 assert hashlib.sha256((repo/name).read_bytes()).hexdigest()==sha,name
 unchanged+=1
for p,pin in json.loads((s/'published-golden-pins.json').read_text()).items():
 assert hashlib.sha256((repo/p).read_bytes()).hexdigest()==pin['sha256']
comparison=json.loads((s/'comparison.json').read_text());assert comparison['common_logical_fields_equal']
result={'all9_terminal':True,'all_final_runtime_sources_match':True,'seven_source_files_equal_main_isolated_index':True,'other_original_authority_inputs_unchanged':unchanged,'audio_walk_inner_unchanged_sha256':hashlib.sha256(old_body.encode()).hexdigest(),'remaining_audio_rs_tail_unchanged':True,'published_json_separately_pinned_not_a_producer_input':True,'receipts':receipts}
(s/'final-audit.json').write_text(json.dumps(result,indent=2)+'\n')
print('9 terminal positive receipts; 7 source files equal main/isolated/index; actual walker body unchanged.')
