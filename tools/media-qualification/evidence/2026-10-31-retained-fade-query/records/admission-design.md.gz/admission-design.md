# Retained creative fade admission

This is a read-only implementation contract. Navigation began with ripwire for AudioOwnerRetainedInput::fades_admitted, audio_owner_input.rs, retained_bound_fade, audio_fades_query.rs and read_retained_controlled, followed by exact source reads. No repository edits, builds, test execution, native execution, captures or expected-body generation were performed.

The preferred unit adds the actual retained fade constructor to the existing AdmittedAudioFadeQuery and holds that carrier through the synchronous retained read. It does not reconstruct the retained input, resolve its binding again, truncate history to current delivery, or admit the separate recursive signal/raw-domain products.

## Authority and coverage boundary

The parent reports the independently captured, equal and reviewed retained v1 corpus is frozen as the 18th oracle. Canonical body: 2,206,347 bytes, SHA-256 44aecc27d5be86e880af03ac43d8a83e5861628638d857a5501da6b1abdc4f16. It contains 11 fixtures, 44 actual modes: 23 Some, 20 None, one RejectedSome; 1,882 ordinary fade calls: 1,142 Ok and 740 Error. Preserve v1 and all 17 prior oracles unchanged.

The corpus distinguishes the real input origins. For example:

| Actual input | Ordinary/false bound.work | Actual true probe/shared bound.work |
| --- | ---: | ---: |
| Root retained descendant, NTSC source/silence, retained treatments | 8 | 13 |
| Point retained labels and fractional source | 8 | 14 |
| Opaque bound stage plus silence | 11 | 16 |

These are values already stored inside the immutable input. They remain part of the OLD retained fade canonical prepayment. They are not a delta to normalize away, a second Core resolution receipt, or grounds to refund a previous callback. The cloned resolved.work and resolved.lattice.work must both stay literal. In this unit a completed true fade query changes only its own top work to canonical plus additional; its canonical is the OLD fade work for the exact same input provenance.

Read-only inspection of the canonical body found 15 RootRoundEven retained Some modes and eight PointCeil modes, 12 with a resolved resume. All 23 have bound/outer constraints, at most three. All have empty processing.retimes, processing/bound/lattice instance.repeats, editorial.editorial and editorial.repeats. No retained processing/bound definition or gap identity is present. Output policies are Automatic; origins cover NodeStart/End and SourcePlacementStart/End, with up to six origins per edge. These are genuine limits of v1, not proof that the missing lanes are unreachable.

Before new production changes, add a separate supplement capture/test fixture for real missing lanes, as specified below. Do not extend or regenerate v1.

## Public API and private seams

Add this method, reusing the existing fixed-AudioSample carrier and its immutable query/work/canonical_units/additional_units/was_forwarded API:

    impl AudioOwnerRetainedInput<'_> {
        pub fn fades_admitted<A: AudioSoundContextAdmission>(
            &self,
            samples: Range<AudioSample>,
            limits: AudioQueryLimits,
            admission: &mut A,
        ) -> Result<AdmittedAudioFadeQuery<A::Issuer, A::Lease>, A::Error>;
    }

The output has no new plan lifetime because AudioFadeQuery owns its edges and origins. It has no Clone, mutable query, public detach or generic unmetered extraction. The existing ordinary fades method remains literal. The false admitted branch calls that exact ordinary method first, then wraps it with an empty same-issuer guard, additional=0, forwarded=false, without spend/reserve/merge callbacks. A private helper must still reject A::METERED=true if used to wrap ordinary output.

Put the retained implementation in a child of audio_owner_input, for example audio_owner_input/retained_fade_query.rs. It can read the actual private processing and editorial fields. Keep those fields private.

Three narrow within-Plan seams suffice:

1. In audio_bound_query.rs, AudioBound::copy_for_retained_fade_query(&self, &mut QueryBudget<A>) -> QueryResult<Owned<AudioBound<'plan>, I, L>, A>. This is an explicit finite copy of this immutable Plan Bound, not a generic Core carrier clone or charge transfer.
2. In audio_fades_query.rs, factor bound_fade's current-allocation clipping from its existing admitted body. Root/Domain bound_fade computes end.min(processing.allocated_samples.end) and calls the common body. A retained-only pub(in crate::plan) retained_bound_span_admitted receives an already guarded actual Stage(Bound), untrimmed end and owned editorial capture, calls the same body, finishes its SpanWork and returns GuardedBound<AudioFadeSpan,I,L>. No other provider or content variant is admitted through this seam.
3. A narrow pub(in crate::plan) finish_query consumes collection::Collected<AudioFadeSpan,A>, the original maximum_work and the same QueryBudget. It performs the existing checked canonical+additional/remainder reconciliation, builds FadeBuffer and seals AdmittedAudioFadeQuery. Share the existing checked seal, rather than expose carrier fields. The false ordinary wrapping helper also needs only within-Plan visibility.

The clone implementation must not call bound_at_query, Core resolve, AudioBindingValue::map/detach on a borrowed input, raw_domain or an alternative nominal clock. The original input remains borrowed under its caller's real carrier for the whole copy. Newly copied finite payload owns independent Plan leases; it does not mint another Core work receipt or transfer the input's guards. A raw borrowed input carries no policy issuer to transfer. A second admission can legitimately own an independent copy while the original carrier stays alive. Foreign-plan rejection remains the host's actual input.belongs_to(plan) boundary. The new synchronous local host construction does not require a new public prepared split.

## Exact loop, work and error order

The true factory follows audio_owner_input.rs::AudioOwnerRetainedInput::fades:

1. limits.validate() first. Then reject only samples.end < samples.start as AudioRangeOutOfRange. Negative samples, samples before/after current delivery, and history outside cached raw-domain support remain valid requests. Do not add a root duration or meaningful-support bounds check.
2. Create one fresh LocalBudget with remaining=limits.maximum_work and default lookup, then one QueryBudget. A valid empty request returns empty spans, default lookup and zero work, with no payload/buffer reservations.
3. Before each span enforce the original equality spans.len()==limits.maximum_spans with exact label retained fade span count.
4. Forward the original aggregate as ONE canonical debit before copying any fields:

       1 + self.bound().work()
         + self.processing.retimes.len()
         + self.processing.instance.repeats.len()
         + self.editorial.editorial.len()
         + self.editorial.constraints.len()
         + self.editorial.repeats.len()

   Preserve this literal weight and order. Use checked arithmetic only if an actual helper requires it without inventing another canonical debit. Existing checked constructors bound these inventories; do not change caps or old weights.
5. Copy the actual processing span, including its Bound Box, first. Copy the actual editorial capture second. Each result is value-before-memory and remains live through subsequent allocation/callback/scalar failures. Do not replace either clone with a borrowed view and call the old copy admitted.
6. Call the untrimmed common Bound fade body with cursor and the original samples.end. Existing q, positive step, envelope-domain construction, positive scale, outer editorial transform and suppression, support-before/after behavior, floor probe, second flattened geometry walk and editorial merge order stay literal.
7. Check span.samples.start==cursor, end>cursor and end<=samples.end, in that order and with retained fade interval did not advance. Root's current weaker final check is not substituted.
8. Move the completed guarded span into the actual shared growing outer collector. Retain old buffer, all previous spans, current span and full replacement capacity during reservation and moves. New move fees are additional, outside infallible GuardedBound maps.
9. Reconcile canonical+additional with maximum_work-remaining, preserve accumulated lookup exactly once, then seal. A successful true query forwards exactly once; do not bill the final query again. Every successfully accepted earlier callback remains spent if a later operation refuses. A failed callback contributes only if the policy itself accepted it; no refund or invented unused fee.

Reused canonical sites in the common body remain:

- envelope_domain_query: constraints.len()+instance.repeats.len()+1, then the same root-domain canonical construction.
- outer.editorial.len(), then matching-entry suppression's repeat_count, before transported marker growth and geometry.
- the actual flattened geometry walk with stop_at_preserve=false and stop_at_bindings=false, including existing lookup/canonical traversal.
- captured.editorial.len()+captured.constraints.len() before projecting their ranges.
- add_editorial per-marker 1; append_origins per-constraint 1, current output length and existing BoundaryOwner::capture work; merge_edge side.len()+1 and new.origins.len()+old_origin.repeats.len()+1 per old origin.

The new clone adds actual inspection/copy/reservation fees through the established QueryBudget helpers only. It does not invent an old debit for the deep Bound/Box copy. The previous aggregate is not re-split or reinterpreted. Additional work can cause a true call to exhaust an old tight work limit earlier; false calls must still reproduce every old limit result literally. True exact/one-short tests use the observed NEW total and the same actual input.

## Concrete finite ownership copy

AudioBound's fields are private to Plan but accessible from its audio_bound_query child. All owning fields of Core ResolvedAudioBinding and ResolvedAudioPlacement are public. No new Core API is needed.

Implement exact destructuring without '..' so a future field addition requires review. The copied bound contains the same borrowed plan pointer and node index; scalar ratios/ranges/support/work copy unchanged. Do not clone the input's cached raw domain because the old per-span processing clone never cloned it.

| Actual copy lane | Owning storage/identity | Existing helper |
| --- | --- | --- |
| processing.definition | optional selector's NodeId edge | budget.definition |
| processing.instance | own node edge, repeat Vec, each repeat NodeId and allocation RevisionId | budget.instance_fixed or instance + separate capacity |
| processing.gap_after | optional independent allocation RevisionId | budget.iteration |
| processing.retimes | Vec<AudioRetimeStage>; each stage.node edge | storage::fixed with storage::retime |
| content Bound | actual Box<AudioBound<'plan>> shell | existing GuardedBound<AudioBound>::boxed |
| bound.definition | independent optional selector edge | budget.definition |
| bound.instance | independent node/repeat inventory | budget.instance_fixed |
| bound.gap | optional DomainGap and optional after allocation edge | budget.gap |
| resolved.lattice.clock | owning NodeId for PreserveInputPointCeil.stage, DefinitionPointCeil.root or GapDefinitionPointCeil.repeat; ProjectRootRoundEven is scalar | explicit exhaustive match plus budget.node |
| resolved.lattice.instance | independent node/repeat inventory, even if equal to bound.instance | budget.instance_fixed |
| resolved.lattice.gap_after | independent optional allocation edge | budget.iteration |
| resolved.resume | two ExactRatio fields only; no Vec/term history in the resolved type | explicit scalar copy |
| bound.constraints | Vec<EnvelopeConstraint>; each optional gap allocation | storage::fixed with budget.constraint |
| outer.editorial | Vec<EditorialConstraint>; each boundary optional gap allocation; incident/edge flags scalar | storage::fixed with storage::editorial |
| outer.constraints | Vec<EnvelopeConstraint>; each optional gap allocation | storage::fixed with budget.constraint |
| outer.repeats | own Vec and independent per-element node/allocation edges | budget.repeats or storage::fixed with budget.repeat |

The public Core placement clock has four variants. Do not miss the DefinitionPointCeil and GapDefinitionPointCeil identity edges simply because v1 contains only Root and Preserve Point. The original template histories, arguments and births were resolved before this query; copying the finite resolved representation must preserve the public lattice birth/gap_birth and both work scalars without resolving the template again. There is no private Core-owned vector hidden behind ResolvedAudioBinding, so a general Core cloning/escape seam would add unnecessary authority.

Identifiers are Arc<str> in deadpan-core/src/document.rs. Cloning them increments the Arc count and does not allocate a new string. The established budget.node/revision/definition helpers reserve identity(text), namely padded Arc header plus text layout, for each actual owning edge. Preserve that existing logical ownership accounting independently per edge. Do not report duplicate Arc ownership charges as distinct heap allocations or RSS. No new Arc shell is created by this retained query: the caller's optional shared retained handle remains borrowed. The actual new shell here is Box<AudioBound>.

Build the complete copied Bound under Owned first, turn it into a same-issuer plain GuardedBound and adopt its Plan memory, then use the existing boxed helper. That helper pre-admits and allocates the actual Box<MaybeUninit<AudioBound>> shell while the copied value stays guarded, writes it inside an infallible map, and merges its shell lane with checked issuer validation. Do not replace it with clone-then-visit_heap accounting. Construct the remaining processing fields under a named value-first state, and map the boxed guarded content to the complete AudioWalkSpan::Stage after all other copies complete. Any fallible merge/adoption uses existing checked helpers.

This uses a plain internal guard for a newly copied finite Plan value even in true mode. It is not unmetered extraction: all its actual copied payload and shell lanes were admitted before allocation/clone and remain attached. The original input Core guard is never detached or moved.

## Reused envelope, edge and replacement ownership

Keep the common admitted implementation's actual nested states:

- Primary copied processing guard and copied outer editorial remain live while envelope_domain_query creates its own temporary definition, gap/selector identity, placed domain, seed and independent instance/constraint/repeat copies.
- EnvelopeValue owns domain, incoming editorial IntoIter, unused outer constraints/repeats and current pending marker before EnvelopeWork's memory lanes. Retain old domain seed editorial capacity plus incoming marker and all outstanding outer values while growing replacement storage.
- Support-before/after and missing-envelope branches drop the real temporary values under their own guards. They must not skip the original processing/editorial copies or canonical debits.
- The second admitted geometry walk produces its actual flattened Leaf and captures editorial under separate guards. Preserve its origin paths and boundary ownership. Keep the copied primary alive through every scalar projection and edge construction.
- retained_span reserves and allocates the actual initial start-side Vec before opposite-side distance arithmetic and end-side reservation. Initial origins already have their own payload guards.
- add_editorial, append_origins, copy_origin, grow_side and merge_edge retain independent origin identities, old edge, incoming edge, previous side buffer and replacement through every callback. Current guards zip only allocation-free moves; all fallible grow/copy fees remain outside maps.
- collection::push handles the completed outer Vec with old contents/current span/replacement overlap. It is not a single final-sized pre-reservation.

The current span.keep(primary) conservatively carries primary construction leases into the result even after the copied primary payload is consumed/discarded by the mapping. Reusing that behavior is acceptable if documented: final logical live charges can exceed final query-owned heap because construction lanes are conservatively retained. It is not a claim that discarded values still occupy heap. Independent peak tests should use real phase brackets and requested Layouts; final OwnedHeap measurement is a separate lower-bound/crosscheck, not a substitute for construction peak.

Every direct merge, reserve, adoption, map, zip, Box finish and final seal must preserve the centrally checked pre/post issuer contract. QueryBudget.merge_checked now returns Result and must be propagated. Keep values declared before their own Memory fields in named nested states. During partial copies, earlier copied values are declared after the Memory local and drop before it on failure. Do not hold a naked value outside its guards in a callback or add a generic mutable Core output escape.

## Host integration and exact existing debits

stages.rs::read_retained_controlled is the actual synchronous boundary. Preserve order:

control.check -> input.belongs_to(self.plan) -> depth -> frames -> checked end -> existing control.spend_plan_work(input.work()) -> fresh query_limits -> retained fade construction -> creative validation -> optional owner query/treatment validation -> required PCM make_room -> active_frames reservation -> read_bound_at -> creative application -> optional authored gain -> final control.check -> active_frames release -> metadata drop before returned PCM.

Replace only the fade construction/bill with a short Admission::new(self,control) borrow calling input.fades_admitted. End that borrow immediately, retain the carrier in a named local and use its immutable query through validation, later owner construction, make_room, source/nested DSP I/O and apply_creative_fades. Do not second-bill its successful canonical/additional receipt. Preserve the pre-existing input.work debit even for a true-probe/shared-created input; changing it is a separate witnessed accounting decision.

The carrier must drop on later owner refusal, PCM admission failure, source/read error, DSP invalid samples, timeout/cancellation and successful return. Explicitly drop it before returning the ReadBlock if that makes the release boundary reviewable. It is request-local; do not cache it or publish it in Graph. Current higher-level cache hits that bypass read_retained_controlled continue to bypass its constructor.

Optional separately named follow-through: use existing input.owners_admitted in authored=true, ending another short Admission borrow and holding that independent carrier through treatment validation and authored gain. Do not merge its canonical work into the fade receipt or silently reclassify its additional fees. Otherwise report that retained authored owner metadata remains ordinary. The preferred implementation can include this existing product reuse without changing its algorithm.

ReadWork has separate plan/cache lanes and Admission::reserve can make_room and evict real entries. Reuse the existing explicit host_eviction_work receipt when tracing a retained fade constructor; do not infer fade additional from gross ReadWork delta. Accepted constructor fees, host eviction fees, input.work and optional owner-query fees remain separate. No PCM cap increase, cache change or fictitious allocation is justified by larger metadata.

No foreign-controller consuming API is introduced here. If implementation creates a prepared local helper that can actually be consumed with another WorkControl, bind it to the real ReadWork issuer and validate before source/query I/O, using the established comparison fee convention only at that actual boundary. Do not add an otherwise unused public split merely to create such a test.

Existing call paths that need host lifetime proof: public read_retained_owner_input and read_retained_owner_treatments, owner_equalizer::equalize_owner_tile retained halos, authored_eq Context::Retained and shared_eq/original_inputs retained cache misses. Shared graph handles remain caller-owned while the local query is built.

## Required additive OLD supplement before implementation

Keep v1 completely unchanged. A separate retained-fade-owning-lanes-v1 supplement should reuse the same complete retained serializer and four actual handle modes, plus full actual document/setup descriptors. It can use v1's private one/observation helpers through a tiny cfgtest child seam or a narrow visitor; do not copy a different serializer or broaden production visibility.

Smallest proposed checked sources/observations:

| Source already checked | Actual setup to capture | Missing lane and proof strength |
| --- | --- | --- |
| fade_query_cases.rs::signed, descriptor fade/signed/retained_negative_origin | Same exact bound document; actual gain owner voice at AudioSample(2), audio_owner_input then retained probe | Non-Partition FollowSpeed Edit is pushed into retimes before the voice binding; source walk shows the path. Actual Some and nonempty retimes must be asserted in supplemental capture. |
| fade_query_cases.rs::editorials, fade/editorial/entry_after | Same marked bound document; voice at2 | Outer crop marker inherited by captured input, then copied into retained editorial. Capture actual inventory; do not infer marker existence only from final Root fade. |
| fade_query_cases.rs::gap_cases::visit, fade/gap_bound/root | Same checked moved gap document; child at8008, and repeat DefaultGap at4805 | Child occurrence exercises processing/bound/lattice repeat paths. Gap observation exercises processing.gap_after, Bound DomainGap.after and constraint identities. Use kind+instance/iteration selection, not merely node name, to distinguish whole Repeat from gap. |
| Same gap document plus real SetEditorialEdges on child | Apply the checked command pattern from repeat_editorial (start/end true), describe before/command/after exactly; child at8008 | Combines inherited nonempty editorial with nonempty repeats, including editorial.repeats and old/new owning origins. This is a new checked command composition requiring actual validation/capture, not a claim already observed by v1. |
| tests/gap_bindings.rs::one_play_gap_definition_uses_its_own_point_clock_and_current_duration | Exact captured(1), SetRepeat gap duration3, RepeatGap definition and exact signed in_root_clock placement; Domain gain owner/owner_input at placed.root_samples.start | Existing test proves placed processing is Bound and direct raw domain is Point with that definition. New retained probe presence/inventories still need actual capture. Targets definition selector/DomainGap and GapDefinitionPointCeil clock identity. |
| fade_query_cases.rs::point_and_preserve, fade/point/definition_birth | Exact root document, actual voice owner/input at0 | Targets DefinitionPointCeil clock identity. The existing Root fade is already checked; retained factory availability must be recorded and then required if it is to close this lane. |

Use the fewest fixtures that actually demonstrate all nonempty lanes after capture; the gap document serves several observations. No need to recapture all 80 Root/Domain fade parents. Existing fade visitor is already a cfgtest child; expose only the necessary checked factory/visitor or read its complete frozen fixture_source.document and reconstruct with ProjectDocument::from_json, explicitly recording that provenance. A definition placement must use its actual public factory, not a fabricated Domain seed.

Do not use fade/repeat_fragment/marked as a retained Some proof: its checked document has no binding. A retained probe stops at the opaque Preserve and returns None rather than descending to invent a Bound. Likewise an ordinary physical Domain fade proving a marker says nothing by itself about which marker survives owner-input capture.

Distinguish public branch availability: current v1 has no Empty raw-domain retained Some. synthetic_empty_support_for_test is private diagnostic coverage, not a public document witness. Definition/Gap clocks are real public enums with existing checked bound/definition constructors; the proposed retained observation is not yet executed. If an attempted public setup returns None/error, preserve it and mark the lane open; never construct a synthetic retained/span to pretend closure.

## Acceptance tests

1. False mode: all 1,882 v1 calls and the additive supplement compare complete fields/typed errors/lookup/work literally to their own frozen OLD bodies, with zero fade admission callbacks. Keep actual ordinary/admitted false/admitted true/shared input provenance separate and keep each actual input carrier alive. V1 availability/23 Some and rejection remain literal.
2. True mode: full/crop/empty/history/seam/source endpoint cases on every real retained Some, plus all supplemental owning lanes. Compare entire output except the top work field, which is checked as canonical==OLD exact-provenance work and total==canonical+actualadditional==accepted constructor spend. Input snapshot, both nested work scalars and bound.work stay unchanged before/after. Do not recursively remove work.
3. Use the same actual borrowed input for ordinary and admitted query comparisons. Never rebuild an ordinary equivalent to compare a true-created retained handle. New-query reservation failure must not disturb the caller's already-live input/probe/shared/selection leases. Keep separate initial ledger baselines for the caller and for the copied query.
4. Exact/one-short NEW total work and exact/one-byte-short requested-layout peak on Root, Point, repeated/gap, definition and editorial cases. Sweep meaningful spend/reserve/merge refusals and cancellation/issuer rotations, retaining both old/new policy states. After query failure, caller baseline remains; after caller drop both states become zero. Accepted failed-prefix work is never refunded.
5. Independent layout assertions: real Box shell bracket with copied Bound payload live; added retime/repeat/editorial Vec length deltas from equal-structure checked documents; independent identity-edge delta including Point/Definition clock NodeId; initial start/end arrays; origin replacement/old-new side and outer-buffer overlap while prior spans/current span live. Verify additional fees at actual sites. Callback totals alone and final storage traversal are insufficient construction proof.
6. Reuse scalar synchronous phase hooks around actual initial clone/Box/editorial and the existing fade geometry/side/origin phases. No callback/debit/allocation semantic change in production. Include real supplemental cases to reach nonempty lanes; zero-sized vectors do not prove reservation refusal for them.
7. WAV host tests hold positive retained fade metadata at source/nested DSP callbacks and through authored owner construction/gain. Aggregate caller metadata, fade and optional admitted owner leases reduce later required PCM room. Check success, source failure, owner failure, exact refusal/partial work, cancellation and cache-hit bypass cleanup. Source/foreign-plan/depth/frames priorities remain exact before fade I/O. Fresh-source admission occurs before numerical reads. Pair OLD values/masks/dependencies/depth using exact same retained provenance and explicit legacy wrappers; keep host eviction differences separate.

Legal Layout overflow remains unproven reachable under checked public inventories. No general speculative Core escape or artificial huge fixture is required to claim this unit.

## Explicit work still open

This unit does not admit read_bound_at's actual bound.raw_domain() on each read, raw Domain/Point preparation, SignalInput query/policy for structural/source/silence/projected/tape providers, complete output-policy paging in build_stage/suppress_signal, projected intrinsic preflight, Mix queries or per-voice closure, retained_sound_input Source/Projected/Occurrence metadata, general Graph containers or native workspace. Do not substitute the cached input.domain() for the currently reconstructed raw domain or remove required complete-history preflight to make metadata cheaper.

No general Split change, cap increase, altered DSP, budget refund, old-weight change, retained-query cache or public generalized provider is part of the proposed unit.

## Exact Main read pins

These are read-state SHA-256 values, not build or capture evidence. No Scope equality is inferred from Main reads.

| Path | SHA-256 |
| --- | --- |
| crates/deadpan-plan/src/audio_owner_input.rs | 3e05de22bd25de72882d942c11221043a06c53a2d9536ca502814088b2c665c2 |
| crates/deadpan-plan/src/audio_owner_probe.rs | 2d51a72c6a54452eacd4d8d305821dab45ac98ac4307998895f1b7036e3bd97f |
| crates/deadpan-plan/src/audio_bound.rs | ac25028a624378198c3fe4276ccaec42cf898fc80f12a88d5266b32d6fbb306f |
| crates/deadpan-plan/src/audio_bound_query.rs | d57c9d91afc4c1542860fb575dddd37f464ea1aec6cc6a4def6249aa4a566c4b |
| crates/deadpan-plan/src/audio_capture.rs | 13755b2b9d63def76982f13aa4a42ff6a9b4dd4ed10cec1ba63afa445386dba7 |
| crates/deadpan-plan/src/audio_capture_storage.rs | 393d120f8950fb9009582f7922b486213570ff91db1c4de1f0e4f987f019dbd9 |
| crates/deadpan-plan/src/audio_fades.rs | b9ea79fbe311e790861fc9a65118616be26947357235c7242edfc84d00e74af2 |
| crates/deadpan-plan/src/audio_fades_query.rs | b69db756a935582720c131b9ce30c63b78ba630b0b3967780fe723123f2ee051 |
| crates/deadpan-plan/src/audio_owner_query_admission.rs | 9f52395699a7cdd95b0c1329d0d7ee1b12459b2b2fd0c27a4fc53f952910c150 |
| crates/deadpan-plan/src/audio_processing_query.rs | 0e07e0d251f140ad53efb891cba8cc2654f0d8d4f3da061f4e60c7ed0b65c793 |
| crates/deadpan-core/src/audio_binding.rs | cc69f19a1efb0bf8667080eb4433f76bd841aa4495f44d8237fb16f932263564 |
| crates/deadpan-core/src/document.rs | 2763bb86bbaba1afe9f11ade4e0077c154ffc12c9452bc2836fc9b0105865d10 |
| crates/deadpan-core/src/occurrence.rs | 8850cca1bfab8b663c179f8ef5b1054c08a6aaeb57f3d95e7d76e1c7781d8330 |
| crates/deadpan-plan/src/audio_owners/legacy_snapshot_v1/fade_query_cases.rs | 8bb4687267066f722fbcd08bdc99fd99bf9a5a7704b41fbfab5dd8e973f99e15 |
| crates/deadpan-plan/tests/gap_bindings.rs | 95d6dde1b80dd76cb20e383ac8595ac48fcba3c2d3eabfa1b90f8858fda47c32 |
| crates/deadpan-audio/src/stages.rs | 7fa81e333bf6cbfb777d807f3e52f498f415169775f0db0f7d2e552482509e77 |
| crates/deadpan-audio/src/sound_context_admission.rs | f15f6bba0ab8b4382f46dcf1ef369688a231b23f7f78855f7c14573f6df6884d |
| crates/deadpan-audio/src/original_request/flattened_work_trace.rs | d505bc6db82fb275624702df0f11b2a243f8031aef3c85e039852e8136b476f4 |
