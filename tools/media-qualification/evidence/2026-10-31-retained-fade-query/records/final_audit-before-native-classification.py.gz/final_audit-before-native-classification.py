from pathlib import Path
from datetime import datetime
import hashlib,json,re
s=Path(__file__).resolve().parent
sha=lambda b:hashlib.sha256(b).hexdigest()
negative={
'retained-admission-scoped-plan2':101,'retained-admission-main-audio':101,
'retained-admission-scoped-plan4':101,'retained-strict-main-initial':1,
'retained-overlap-scoped-diagnostic6':101,'retained-admission-scoped-plan5':101,
'retained-host-old-main-build':101,'retained-admission-main-plan2':101,
'retained-strict-main-second':1,'retained-strict-scoped-initial':1,
'retained-supplement-scoped-coverage':101,'retained-host-old-scoped-build':101,
'retained-admission-main-plan4':101,'retained-admission-scoped-audio':101,
'retained-admission-main-plan5':101}
receipts=[];native=[]
for p in sorted(s.glob('*.json')):
 r=json.loads(p.read_text())
 if not isinstance(r,dict)or'command'not in r or'started_at'not in r:continue
 assert 'exit_code'in r,p.name
 if p.stem=='retained-final-fresh-split':assert r['exit_code']in [0,101]
 else:assert r['exit_code']==negative.get(p.stem,0),(p.stem,r['exit_code'])
 assert r['sources_unchanged']and r['binaries_unchanged'],p.name
 for path,pin in r['streams'].items():
  b=Path(path).read_bytes();assert len(b)==pin['bytes']and sha(b)==pin['sha256'],path
 receipts.append({'label':p.stem,'exit_code':r['exit_code'],'seconds':r['seconds'],'receipt_sha256':sha(p.read_bytes()),'acceptance_credit':r['exit_code']==0})
 if r['binary_before']and any('-audio-'in x for x in r['binary_before']):
  assert r['environment']['CARGO_PROFILE_DEV_OPT_LEVEL']=='2'
  native.append((datetime.fromisoformat(r['started_at']),datetime.fromisoformat(r['finished_at']),p.stem))
for a,b in zip(sorted(native),sorted(native)[1:]):assert a[1]<=b[0],('native overlap',a[2],b[2])
tests={}
def result(label):
 r=json.loads((s/(label+'.json')).read_text());assert r['exit_code']==0
 m=re.findall(r'test result: ok\. (\d+) passed; 0 failed; (\d+) ignored;',(s/(label+'.stdout')).read_text())
 assert len(m)==1,label
 passed,ignored=map(int,m[0]);tests[label]={'passed':passed,'ignored':ignored,'seconds':r['seconds']}
 return passed,ignored
for v,lib in [('main',273),('scoped',260)]:
 labels=[r['label']for r in receipts if r['label'].startswith(f'retained-final-{v}-plan-')]
 assert len(labels)==29
 integrations=0
 for label in labels:
  p,i=result(label)
  if label.endswith('deadpan-plan'):assert(p,i)==(lib,22)
  else:assert i==0;integrations+=p
 assert integrations==450
reused=json.loads((s/'native-final2-reused-identical.json').read_text());assert len(reused)==14
for v,lib in [('main',429),('scoped',423)]:
 build=json.loads((s/f'retained-all2-{v}-audio-build.json').read_text())
 assert build['exit_code']==0 and build['environment']['CARGO_PROFILE_DEV_OPT_LEVEL']=='2'
 pins=json.loads((s/f'retained-all2-{v}-audio-build-pins.json').read_text());assert len(pins)==21
 small=0
 for pin in pins:
  target=pin['name']
  prefix='retained-final'if pin.get('reused_identical_pinned_executable')else'retained-final2'
  label=f'{prefix}-{v}-audio-'+target.replace('_','-')
  r=json.loads((s/(label+'.json')).read_text())
  data=Path(pin['path']).read_bytes();digest=sha(data)
  assert digest==pin['sha256']
  assert any(x['sha256']==digest for x in r['binary_before'].values()),label
  p,i=result(label)
  if target=='deadpan_audio':assert(p,i)==(lib,9)
  elif target=='stages':assert(p,i)==(203,0)
  elif target=='audio_definition':assert(p,i)==(171,0)
  else:assert i==0;small+=p
 assert small==207
for label in ['retained-strict-main-receipts','retained-strict-scoped-receipts','retained-format-scoped']:
 r=json.loads((s/(label+'.json')).read_text());assert r['exit_code']==0
body=json.loads((s/'native-pairs5-full-audit.json').read_text())
assert body['all_744_cleanup_and_receipts_checked']and body['changed_reads_before_source']==58 and body['changed_reads_after_same_source_events']==12
split_text=(s/'retained-final-fresh-split.stdout').read_text()
m=re.search(r'test result: (?:FAILED|ok)\. (\d+) passed; (\d+) failed;',split_text);assert m
split={'passed':int(m[1]),'failed':int(m[2]),'seconds':json.loads((s/'retained-final-fresh-split.json').read_text())['seconds']}
assert split['passed']+split['failed']==7
source=json.loads((s/'preserved-source-and-oracle-final-audit.json').read_text())
assert source=={'preserved_unowned':{'main':2792,'scoped':2464},'immutable_oracles':21,'owned_paths':45,'index_scoped_equal':45,'index_main_equal':44}
out={'all_terminal':True,'receipts':receipts,'tests':tests,'native_audio_runs_serial':True,'native_runs':len(native),'reused_identical_native_passes':14,'source_audit':source,'native_pair_audit':body,'split':split,'source_tree':(s/'index-source-tree.txt').read_text().strip(),'shipping_source_patch_sha256':sha((s/'shipping-source.patch').read_bytes())}
(s/'final-audit.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({k:v for k,v in out.items()if k not in ['receipts','tests','native_pair_audit']},indent=2))
