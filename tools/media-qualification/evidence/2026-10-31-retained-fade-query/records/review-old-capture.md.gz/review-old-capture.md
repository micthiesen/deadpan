# OLD retained-fade capture review

## Findings

None. The retained OLD capture and its provenance checks are internally consistent in the inspected artifacts.

## Evidence checked

- capture_old.py selects a fixed Main or Scope checkout root, requires a successful build receipt with matching cwd and unchanged source guard, verifies the captured executable against the build pin, recomputes and checks every source_after file, and hashes a canonical source manifest. It requires one exact named capture test from the recorded --list output, checks the published checkpoint against the verified publication receipt, supplies the emitted variant/source/checkpoint values, then verifies the test run receipt, output metadata, environment and all source/binary pins.
- Build pins point to the captured executable copies. The exact binary hashes agree with the build artifacts' executable hashes. The capture run receipts report the expected roots, exit code 0, and unchanged complete source and binary sets. Both retained capture stdout files report exactly one passed named test.
- The two emitted raw bodies are 7,532,676 and 7,532,678 bytes. Removing only variant, source_sha256 and published_fade_checkpoint makes the complete JSON values equal. The canonical body is 2,206,347 bytes with SHA-256 44aecc27d5be86e880af03ac43d8a83e5861628638d857a5501da6b1abdc4f16.
- The canonical-body comparison was exercised against both OLD binaries by the exact named external regression test; both receipts show exit code 0, unchanged source and binary pins, and one passed test.
- The summary records 11 fixtures, 44 actual handle trials (23 Some, 20 None, one RejectedSome), and 1,882 actual fade calls (1,142 Ok, 740 Error). The raw body, not only the summary, was parsed to check whole-body equality.
- Each initial source authority has exactly two additions and no removals in either checkout. The changed existing files are the baseline test declaration and legacy_snapshot_v1.rs visibility declarations needed by the capture; no behavioral baseline body changes were found. All 17 immutable oracle pins match in both roots (34 checks); oracle bodies were not opened.
- The earlier capture-provenance concern is resolved: wrapper and test output agree on checkout identity, source-manifest digest and published checkpoint, and the run receipts bind the invocation to the pinned executable.

## Limits

This verifies the retained OLD capture and its canonical equality/regression receipts only. It does not establish correctness of the new admission implementation or report the separately running native verification outcome. The large frozen fade oracle was hash-checked but not read.
