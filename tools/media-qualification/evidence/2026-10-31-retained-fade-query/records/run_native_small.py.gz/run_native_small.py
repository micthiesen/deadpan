from pathlib import Path
import subprocess,json
s=Path(__file__).resolve().parent
for v in ['scoped','main']:
 build=f'retained-all-{v}-audio-build'
 pins=json.loads((s/(build+'-pins.json')).read_text())
 for pin in sorted(pins,key=lambda p:p['name']):
  if pin['name']in ['deadpan_audio','stages','audio_definition']:continue
  label=f'retained-final-{v}-audio-'+pin['name'].replace('_','-')
  subprocess.run(['python3',str(s/'run_target.py'),build,v,'audio',pin['name'],label,'--test-threads=1'],check=True)
