from pathlib import Path
import json,subprocess,sys
s=Path(__file__).resolve().parent;v=sys.argv[1];assert v in ['main','scoped']
build=f'retained-all-{v}-plan-build'
pins=json.loads((s/(build+'-pins.json')).read_text())
failures=[]
for pin in sorted(pins,key=lambda p:(p['name']!='deadpan_plan',p['name'])):
 label=f'retained-final-{v}-plan-'+pin['name'].replace('_','-')
 r=subprocess.run(['python3',str(s/'run_logic_target.py'),build,v,'plan',pin['name'],label,'--test-threads=1'])
 if r.returncode:failures.append({'label':label,'code':r.returncode})
(s/f'retained-final-{v}-plan-summary.json').write_text(json.dumps({'executables':len(pins),'failures':failures},indent=2)+'\n')
raise SystemExit(bool(failures))
