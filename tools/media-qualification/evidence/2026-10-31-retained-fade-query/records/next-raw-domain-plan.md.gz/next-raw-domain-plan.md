# Next unit: guarded fresh raw-domain reconstruction at native Bound reads

Read-only planning in Main and the isolated published copy. Navigation began with
ripwire in BOTH roots for AudioOwnerRetainedInput::raw_domain, AudioBound::raw_domain,
audio_owner_input.rs, stages.rs and read_bound_at, then bounded source reads and
exact caller searches. No source/fixture edits, builds, native runs, Git operations
or network access were performed. Hashes below describe inspected source, not
build or execution evidence.

## Preferred bounded unit

Admit the fresh AudioBound raw-domain product used by
StageAudio::read_bound_at and retain its independent carrier through that
Root/Point numerical branch. Reuse the existing internal admitted constructor;
do not write a second reconstruction algorithm or replace reconstruction with
the cached operand in AudioOwnerRetainedInput.

There is no AudioOwnerRetainedInput::raw_domain method in this tree. That type
stores a cached domain and exposes domain() by reference. The actual fresh call
is input.bound().raw_domain(), reached through read_bound_at. The same native
boundary also handles Bound spans from ordinary Root/Domain processing and
structural Signal queries, so an AudioBound product is the useful unit rather
than a retained-input-only facade.

The internal reconstruction is ALREADY admitted when called by the true retained
probe and true Bound policy. The missing pieces are a sealed public result for
the cross-crate native call, actual host lifetime integration, and sufficiently
specific preimplementation evidence. This is a follow-through over an existing
finite constructor, not the recursive Signal/Tape/Mix preparation family.

## Exact current ordinary algorithm

AudioBound::raw_domain at audio_bound.rs:291 creates a local Budget with
remaining=65,536 and default lookup, creates Unmetered plus QueryBudget, invokes
the internal raw_domain_admitted, translates its error through outer and consumes
Owned::unmetered. That method exposes only a Result<AudioBoundDomain,PlanError>;
it has no public accepted-work receipt or caller-selected query limits.

The actual shared body is audio_bound_probe.rs:37. Its order is:

1. Borrow the already resolved lattice and clone the scalar support range.
   Subtract support endpoints and require positive exact extent. Nonpositive
   extent returns Empty with empty memory; it performs no physical placement,
   selector/repeat copy or constructor callbacks.
2. Construct a temporary AudioDefinition under Owned. Copy the optional DomainGap
   FIRST, then the owning instance node edge used by Node or RepeatGap selector.
   This temporary definition remains owned while the output constructor runs.
3. Build AudioRootPlacement from the existing lattice origin, existing
   frames_per_local_frame and literal support. Validate the actual physical
   definition kind and support before entering either output constructor.
4. RootRoundEven: call root_domain_on_grid_query with grid origin ZERO and
   RoundEven, then replace evaluation metadata. This is deliberately different
   from envelope_domain_query, which uses lattice.grid_origin and can make an
   envelope Domain on a Point grid. Do not substitute that envelope constructor.
5. PointCeil: call AudioPointDomain::new_admitted using lattice.grid_origin, then
   copy BOTH the new optional evaluation selector and repeat vector before
   replacing either embedded Signal field. Merge the owned memory before the
   infallible owning move and set the exact binding bypass target.
6. Return Root/Point under its own Owned memory. The temporary definition drops
   before the returned domain's charge. The original Bound remains borrowed.

The helper explicitly states canonical work is ZERO. Its metered inspections,
copies and reserves add additional work on the existing parent remainder. Under
Unmetered, additional and reservations are no-ops, while the literal allocations
and false replacement path still happen. Do not introduce a canonical bound.work
debit, refund an earlier caller debit, or re-resolve the serialized binding to
mint another Core receipt. Neither resolved.work nor lattice.work is a license
to normalize an input from another provenance.

Physical validation accepts Source, Hold, Repeat gap, or a Retime whose pitch
processes its scale. It rejects other structural definitions and support beyond
the definition's exact output. AudioRootPlacement validates its own exact shape;
Point construction separately checks grid/sample arithmetic. Their actual
typed errors and priority should be captured, not replaced with guessed caps.

## Finite owning payloads and nested constructors

The Bound itself is borrowed. Its resolved lattice, support, map, envelope scale,
node index and work scalars are not reconstructed or copied into a second Bound.
No new Core resolve/map/detach API is needed.

| Constructor phase | Real owning storage and overlap |
| --- | --- |
| Temporary definition | Optional DomainGap.after allocation identity, plus Node/RepeatGap selector node identity. Values precede their Memory. |
| Root initial domain | Optional physical definition selector, one-element placement-support EnvelopeConstraint Vec, optional gap identity, independent instance node identity. AudioRootPlacement, grids/maps/ranges/transforms are scalar. |
| Root evaluation replacement | New optional bound definition; copied seed repeat Vec and its node/allocation edges; full replacement constraints Vec for old placement constraint plus Bound constraints and each optional gap identity; independent replacement instance node/repeat Vec. Old values/capacities remain charged during their replacement. |
| Point initial structural Signal | Independent optional definition selector and optional gap identity in AudioSignal. Provider is Structural, with scalar support, sampling_support, placed transform and bypass state. This is construction of a signal handle, not a Signal query. |
| Point object selector | A second independent top-level physical selector edge, copied after Signal construction. It remains distinct from the embedded Signal definition. |
| Point evaluation replacement | Optional bound definition and copied repeats are both completed while the old Signal fields remain live. They replace the embedded Signal definition/repeats and set bypass_binding; the Point's top selector is retained. |

Root set_root_evaluation_admitted preserves conservative logical ownership for
cleared edges until the result drops. The old selector/instance allocation edges
can therefore remain charged even after the replaced value itself dies. This
is not a claim those discarded heap values still exist. Each new owning Arc<str>
identity edge follows the existing logical identity Layout accounting; it is not
a distinct physical string allocation or RSS measurement.

DomainGap contains only optional after identity and scalar duration. Each
EnvelopeConstraint has scalar geometry/node index/repeat count/kinds plus its
optional gap identity. RepeatInstance has its own node and iteration allocation
edges. Root seed editorial/retimes start empty here. Point has no copied Bound
constraints field: its literal old Signal evaluation replacement changes only
definition, repeats and bypass. Do not add a Root-style constraints copy to Point
as an unrequested semantic correction.

The nested guarded helpers already exist:

- AudioDefinition::root_domain_on_grid_query, audio_definition_query.rs:6.
- AudioPointDomain::new_admitted, audio_point_domain.rs:118.
- AudioSignal::for_placed_definition_admitted, audio_signal.rs:752.
- The actual raw helper's repeats and set_root_evaluation_admitted.

They use the existing checked issuer, additional, reserve and merge mechanics.
They do not walk the whole definition or build projected/source/tape providers.
Raw Point's current provider is specifically Structural. Treat an unexpected
provider as an explicit fixture/implementation mismatch, rather than serializing
only a provider label and omitting its payload.

## Current true/false caller paths

| Actual caller | Current path and accounting |
| --- | --- |
| Public AudioBound::raw_domain | Unmetered wrapper of the same internal helper, fixed local 65,536. No work receipt returned. |
| Ordinary AudioOwnerInput::retained_probe_at | Constructs the actual walked Bound, invokes public ordinary raw_domain and stores that cached result. Its probe work remains the enclosing ordinary walk's actual work. |
| retained_probe_at_admitted | Calls internal raw_domain_admitted on the SAME outer QueryBudget, then moves the real returned domain into the retained value and merges its memory with walk/editorial/Core guards. Its additional work can augment the stored retained work. |
| True Bound policy, audio_policy_query.rs:683 | Calls internal raw_domain_admitted under the actual policy query budget and keeps the returned raw domain while evaluating that policy branch. |
| Ordinary Bound policy, audio_policy.rs:474 | Calls public ordinary raw_domain; its surrounding PolicyWork remains the established separate caller accounting. |
| Native read_bound_at, stages.rs:1614 | ALWAYS calls public ordinary raw_domain after early checks and silent-Hold bypass. Existing admitted fade/owner policies do not admit this fresh allocation. |

Cached input.domain() already owns a raw domain from probe construction. That
does not admit a SECOND fresh reconstruction at native read time. Reusing the
cached value would remove an actual allocation/copy/lifetime boundary and change
the algorithm being witnessed. Keep that as a separate possible optimization,
not an admission shortcut.

## Native reachability and priority

The exact read_bound_at order is control.check -> depth -> foreign Bound ->
frames -> silent-Hold early return -> scalar step/output -> fresh raw_domain ->
Root/Point/Empty branch. This differs from read_retained_controlled's own
foreign-before-depth order. Do not unify them accidentally.

read_bound is another entry: it rejects negative relative offset before mapping
reference_at_wide_offset, then calls read_bound_at. Preserve those preexisting
relative-versus-signed-history boundaries and scalar error priorities.

Live callers are:

- read_retained_controlled: directly maps input.reference_at(start) and calls
  read_bound_at. Public retained raw/treatment reads, retained owner equalizer
  halos, authored EQ retained operands and retained Original cache misses reach
  this path. Their fade/optional owner carriers stay live during raw construction.
- read_root_queries, Bound arm at stages.rs:1957: relative offset from the
  actual processing span, depth+1, then read_bound.
- read_signal_queries, Bound arm at stages.rs:2837: same exact span-relative
  transfer, depth+1, then read_bound. This includes structural Signal preparation
  and nested paths reached through Point, stage, tape or projected inputs.

Root raw output with no allocated integer samples returns an empty block before
transfer/I/O. Point separately computes its allocated reference-sample length
and returns empty on zero points. A nonempty exact Point support with zero grid
points is NOT AudioBoundDomain::Empty and must keep its exact frame support/map.
Actual Empty also returns an empty block. Silent Hold bypasses reconstruction
entirely. Preserve masks/dependencies/depth and these no-I/O paths exactly.

Original cache hits in shared_original_input_mode return before the retained cold
reader and therefore before raw reconstruction. The separate prediction fast
path intentionally excludes Retained contexts. A new raw-domain unit must not
change that availability or add Graph retention/cache identities.

## Small host ownership seam that needs design attention

A sealed AdmittedAudioBoundDomain<'plan,I,L> with immutable domain and receipt
access is sufficient for Plan. It should expose no Clone, mutable payload,
unmetered detach, generic map or Graph-publication facility. Keep the internal
QueryBudget API private. A public admitted method can rename the current private
helper to raw_domain_query; that is a small caller rename, not a second algorithm.
Preserve the existing fixed 65,536 standalone allowance and aggregate host
ReadWork admission; no cap increase or new span limit is justified for one object.
False mode should use the literal ordinary constructor and an empty same-issuer
guard with canonical/additional/total all zero and no policy callbacks.

Root needs a PRIVATE borrowed transfer seam. DomainSignalTransfer::new currently
consumes AudioDomain. Moving a sealed raw carrier's domain out would detach its
metadata ownership; cloning would add another unadmitted copy. Prefer factoring
the existing controlled transfer body into a private helper taking a borrowed
domain plus the same scalar RootSignalTransfer/descriptor geometry. The current
public owning transfer can delegate to that helper, while read_bound_at passes
the admitted carrier's borrowed Root domain. Keep the exact existing checked
length, integer rebasing, origin/step and label-restoration algorithm.

Point already passes &domain into read_point_domain_controlled. Hold the new raw
carrier through support/transfer construction, every transfer render closure,
query/preflight/source/nested DSP callback, final control.check and cleanup, then
drop it before returning SignalBlock. Empty/zero-point/error paths release it
without numerical I/O. A short Admission borrow around construction should end
before the numerical mutable controller borrow. No public foreign-controller
prepared API or new issuer-switch debit is needed for this synchronous boundary.

Keep its receipt separate from input.work, fade, optional owner, later queries
and real host cache-eviction work. A completed true constructor is not billed
again. Reuse the explicit existing accepted eviction receipt when tracing it;
gross ReadWork delta is not the constructor's additional work. Add a separate
test-only trace slot/module instead of changing a frozen Root four-slot shape.

## Work explicitly outside this unit

read_point_domain_controlled currently calls domain.signal(), which clones the
embedded Structural signal before read_signal. An internal point_signal_clone_admitted
already exists, but this cross-crate native call is still ordinary. Admission
of the raw Point's ORIGINAL Signal fields does not admit that subsequent copy.
Leave it explicitly open unless a separately witnessed clone product is chosen.
Do not silently replace the old clone with a borrowed internal accessor and call
the removed allocation admitted.

Also open: SignalInput query/policy, structural/source/silence/projected provider
families, tape/mix voice closure, complete build_stage/suppress_signal policy
paging, intrinsic preflight, retained_sound_input products, Graph containers,
native decoder/DSP workspace and other independent output-metadata copies.
Root raw reconstruction can be closed while these remain open. No full recursive
preparation or allocator/RSS claim follows.

## Existing witness strengths and concrete gaps

The current raw helper has three unit tests in audio_bound_probe_tests.rs:
ordinary/false/true logical equality with canonical zero, actual aggregate peak
exact/one-short cleanup, and reservation refusal across Root and fractional
Point source fixtures. They use real checked inputs, but only TWO ordinary
retained origins. Expected ordinary raw values are generated in the SAME test
run, not frozen as a separate standalone old reconstruction body. Their policy
does not refuse spend, cancel or rotate issuers; accepted work is checked only
as positive/upper-level totals. They are useful mechanics tests, not the complete
next-unit evidence.

Existing retained fade/probe snapshots capture the cached raw domain. Their Root
domain serializer is exhaustive, but capture_baseline::bound_domain explicitly
states its Point view excludes the private AudioSignal provider. The old Point
supplement captures eleven private Structural signal fields for ONE actual
returned Point after evaluation replacement and explicitly leaves Empty open.
That does not cover all repeated/gap/definition Point payloads or a separate
native reconstruction's result/lifetime.

The immutable retained host body freezes real PCM, masks, dependencies, depth,
full ReadWork and callbacks, but its historical producer now deliberately selects
retained legacy fade/owner mode to preserve that old unit. It does not freeze the
next unit's CURRENT ordinary raw call under today's admitted retained fades and
owners. Reuse its serializers/helpers, not its old expected body or legacy mode
as if it represented today's default caller.

## Required preimplementation capture

First finish and verify publication of the retained-fade checkpoint. Then pin
that actual published source/binary in BOTH roots and capture BEFORE changing
raw reconstruction, its public wrapper or native transfer lifetime.

Create a separate immutable raw-domain witness, not an extension/regeneration of
any existing oracle:

1. Reuse the actual complete retained handle-owning scopes from retained v1,
   owning-lane supplement and new checked coincident case. Keep ordinary,
   actual admitted-false, admitted-true and shared origins distinct and live.
   Also reuse real Bound processing spans from Root/Signal paths that need no
   retained-input facade. Record full source documents, selections and genuine
   Some/None/errors; do not manufacture a domain from a nominal owner clock.
2. For each real Bound call the actual public ordinary raw_domain afresh. Record
   exact Bound snapshot, all literal nested work, full typed result and complete
   returned Root/Point private value. For Point use the borrowed exhaustive
   probe_baseline_snapshot, including all eleven Structural fields AFTER actual
   set_evaluation. Do not call signal() merely to serialize an equivalent clone.
3. In a separate lane, freeze the existing internal true helper's actual
   canonical=0/additional/accepted work and requested Layout/issuer event sequence
   while the actual input carrier stays live. Preserve independent caller and
   result ledgers. This already-existing helper evidence can guard against drift
   while adding the public carrier. It is not an ordinary error partial receipt.
4. Include Root, fractional Point/44100, repeated/gap, explicit definition and
   GapDefinition clocks, old/new selector/repeat replacement, nonempty constraints,
   signed origin/support, nonempty support with zero allocated points, and actual
   physical Source/Hold/opaque Preserve/gap recipes that existing checked public
   fixtures genuinely expose. Record unrepresented lanes honestly. Use private
   empty-support mutation only as a labelled diagnostic branch test, never as a
   public Empty oracle. Do not invent huge invalid inventories to force Layout
   overflow.
5. Add a NEW native before-body using current default admitted fades/owners and
   the still-ordinary raw call. Reuse current host scenarios on actual four
   origins, with direct raw Bound paths plus real WAV Root/Point reads. Serialize
   complete blocks as bits, masks/dependencies/depth; literal before/after
   ReadWork/controller state; fresh-source arguments/provenance; accepted failures,
   cancellation, signed/overflow/zero-support boundaries and cleanup. Do not renew
   deadlines or add a public split. Native executables remain serial and guarded.

Freeze matching Main/Scope bodies after stripping only declared source/variant
envelope identities. Include a new exact ignored external full-body regression,
fresh /tmp create_new output and actual source/checkpoint/binary/fixture hashes.
Do not generate expected bodies after the algorithm/lifetime change. The existing
twenty plus additive coincident witness remain byte-for-byte immutable.

## Acceptance after implementation

- False public wrapper reproduces the fresh ordinary raw output/errors exactly,
  with zero callbacks/reservations and no added validation-priority changes.
- True returns the same exact Root/Point data, canonical zero and
  total=additional=accepted constructor spend. Input, caller ledger, Bound work,
  resolved work and lattice work remain unchanged.
- Sweep each actual spend/reserve/merge refusal and issuer rotation with exact
  accepted callback prefix, typed error, no later callback and both issuer states
  released. Use explicit callback ordinals for all-callback cancellation (zero
  work calls can share a total); retain separately meaningful real work-total
  cancellation boundaries. Never refund accepted earlier work.
- Independently assert Layouts and real phase overlaps for temporary definition,
  Root initial/replacement selectors/repeats/constraints/instance, Point initial
  Signal versus top selector, and old/new Signal evaluation replacement. Keep
  original input ownership live throughout; final heap traversal alone is not
  a construction-peak proof.
- Source/native callbacks must see positive raw metadata IN ADDITION to caller
  fade/owner/query charges. Test real metadata-driven cache eviction and separate
  its existing scan fee; later PCM reservation refusal; source error/cancel and
  zero-support early returns; actual original cache-hit bypass. Drop metadata
  before returned PCM and preserve the frozen numerical output.
- Add an independent explicit raw legacy scope for old full-body observations.
  Chain it into the appropriate whole-Original and whole-retained compatibility
  helpers, without making narrow Root fade legacy implicitly disable new raw
  admission. Do not refresh old bodies to hide altered costs.

## Main/Scope read pins

Every listed file had the SAME hash in Main and Scope at inspection. These are
not a claim that a later concurrent edit or a native binary still has this state.

| Path | SHA-256 in both roots |
| --- | --- |
| crates/deadpan-plan/src/audio_owner_input.rs | 9444f9efb24de3e6c710e8acc2f4070284bdec47bb7b8197ec6f4baf7ffc9ab6 |
| crates/deadpan-plan/src/audio_bound.rs | ac25028a624378198c3fe4276ccaec42cf898fc80f12a88d5266b32d6fbb306f |
| crates/deadpan-plan/src/audio_bound_probe.rs | ff221f1cdef36f0e3b385ab28fb0086c3f80e52601325fa08e07494cd2c5e7e5 |
| crates/deadpan-plan/src/audio_bound_probe_tests.rs | 10b80b2d27c453ea35c6f434510de1df9def31bf90353247a0733efea88d8f74 |
| crates/deadpan-plan/src/audio_definition_query.rs | 194f427ac760dc443db98b69003c9c4f2d3dde0be82a4fa1518f8bd3ad4f0c95 |
| crates/deadpan-plan/src/audio_point_domain.rs | 6d2964c84d2d816a346ff766cecfb3adb53a931263581a083e3f22cc30c4e7f8 |
| crates/deadpan-plan/src/audio_signal.rs | 115e8a3162122f16127aabac15e0283a35262f20541af16f2be64044931df76f |
| crates/deadpan-plan/src/audio_policy.rs | 8195ffc909c9ddfed0ea04132244750d10e9b9668461a7e7493b59f666f56e80 |
| crates/deadpan-plan/src/audio_policy_query.rs | 4b09dd0ac140db1e7e5a58e9092a5e2ecaa29d45d4bc303a56b4e815985a28a9 |
| crates/deadpan-audio/src/stages.rs | 8033598161459c6e7107e852c3ec7138ba79ff8994aa3fdc1acc3676bdf0f7c1 |
| crates/deadpan-audio/src/domain_transfer.rs | 93559b42437a3dd85e04241d567c37d5dbb6162bdcf6927d80ccbe8bc563e243 |
| crates/deadpan-audio/src/retained_request.rs | 2f54f7cfbc6d524d85e7adc54fcbebe0b357d53d72ca7aada4e9109b3875db0b |
| crates/deadpan-audio/src/signal_input.rs | e1b9782f8730a19ce2fc46e393033f642d666d6109466b045146d747b8a08085 |
