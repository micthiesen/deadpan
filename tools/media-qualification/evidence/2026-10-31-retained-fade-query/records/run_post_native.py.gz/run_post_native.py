from pathlib import Path
import subprocess,time,json
s=Path(__file__).resolve().parent
started=time.monotonic()
while not(s/'native-final2-reused-identical.json').exists():
 assert time.monotonic()-started<1800,'native completion marker not received'
 for label in ['retained-final2-main-audio-stages','retained-final2-main-audio-timing-representation']:
  p=s/(label+'.json')
  if p.exists():
   r=json.loads(p.read_text())
   assert r.get('exit_code',0)==0,(label,r.get('exit_code'))
 time.sleep(2)
code=subprocess.run(['python3',str(s/'run_target.py'),'retained-all2-main-audio-build','main','audio','stages','retained-final-fresh-split','general_split_sound::','--nocapture','--test-threads=1']).returncode
assert code in [0,101],code
subprocess.run(['python3',str(s/'run_qualified.py'),'retained-final-hygiene','--','cargo','xtask','hygiene'],check=True)
subprocess.run(['python3',str(s/'audit_staged_source.py')],check=True)
subprocess.run(['python3',str(s/'final_audit.py')],check=True)
