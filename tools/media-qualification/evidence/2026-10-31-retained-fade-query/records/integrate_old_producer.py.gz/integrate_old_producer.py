from pathlib import Path
import hashlib,json
from datetime import datetime,timezone
s=Path(__file__).resolve().parent;c=s/'old-producer-candidate';pins=json.loads((c/'pins.json').read_text())
roots={'main':Path('/Users/michael/Code/deadpan'),'scoped':Path('/tmp/deadpan-query-groundwork-2026-10-26/scoped')}
previous=Path('/tmp/deadpan-fade-query-admission-2026-10-30')
sha=lambda b:hashlib.sha256(b).hexdigest()
# Publication was independently confirmed by git ls-remote before this integration.
checkpoint='ee9742711868fde9a78bcb945adfd36e67f504d6'
(s/'published-fade-checkpoint.txt').write_text(checkpoint+'\n')
rows={}
for variant,root in roots.items():
 for name,pin in pins['variants'][variant]['read_sources'].items():
  b=(root/name).read_bytes();assert len(b)==pin['bytes']and sha(b)==pin['sha256'],(variant,name)
 for name,pin in pins['new_sources'].items():
  assert not(root/name).exists(),(variant,name)
  b=(c/name).read_bytes();assert len(b)==pin['bytes']and sha(b)==pin['sha256'],name
 initial={}
 for name in json.loads((previous/('source-files.json'if variant=='main'else'scoped-source-files.json')).read_text()):
  b=(root/name).read_bytes();initial[name]={'bytes':len(b),'sha256':sha(b)}
 (s/(variant+'-initial-authority.json')).write_text(json.dumps(initial,indent=2)+'\n')
 for name,pin in pins['variants'][variant]['read_sources'].items():
  if 'suggested_after_sha256'not in pin:continue
  before=(root/name).read_bytes();after=(c/'after'/variant/name).read_bytes()
  assert sha(after)==pin['suggested_after_sha256'],name
  target=s/'integration-before'/variant/name;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(before)
  (root/name).write_bytes(after)
 for name in pins['new_sources']:
  (root/name).write_bytes((c/name).read_bytes())
 rows[variant]={'existing_inputs':len(initial),'changed_test_files':[n for n,p in pins['variants'][variant]['read_sources'].items()if'suggested_after_sha256'in p],'new_test_sources':list(pins['new_sources'])}
(s/'old-producer-integration.json').write_text(json.dumps({'published_checkpoint':checkpoint,'at':datetime.now(timezone.utc).isoformat(),'variants':rows},indent=2)+'\n')
print(rows)
