# Genuine retained coincident-origin diagnostic: scratch candidate

No actual repository edits, builds, native executions, captures or oracle writes
were performed. Rustfmt parsing/checking and read-only patch application checks
are the only local verification. Parent owns source-guarded Plan execution.

## Corrected real construction

The first proposed SetEditorialEdges(loop) was invalid: command.rs:2930 permits
that command only on RetimePurpose::Partition, while loop is Repeat. That proposal
was withheld from integration. Its source is preserved only as
withheld-invalid-repeat-command.rs and is NOT in either patch.

The active candidate uses two genuine public commands on the unchanged frozen
retained_supplement/captured_marked_repeat_fragment document:

1. Split(loop, at=4), strictly inside its eight-frame duration. The deterministic
   five-ID pool creates coinc-left/coinc-right Partitions followed by the copied
   right subtree coinc-loop/coinc-fragment/coinc-voice. Root is an ordinary
   Sequence parent, so no synthetic container or private context is constructed.
2. SetEditorialEdges(coinc-right, start=false, end=true). Split's actual partition
   factory creates purpose=Partition, satisfying the real command guard.

The resulting right Partition and its already marked inner copied fragment share
their exact end at frame 8 / sample 12800. Their retained second-play voice's
underlying extent was frame 2..10 in the checked source. The diagnostic selects
the actual coinc-voice owner at sample 6400 through audio_gain_owners and obtains
its actual AudioOwnerInput. It never fabricates a retained handle, span or seed.
Genuine Some and phase reachability are still runtime obligations.

The full before document, Split request, intermediate document, mark request and
after document are stored in the case descriptor, together with the original
frozen source descriptor. The existing one helper supplies full retained snapshots,
literal work and the actual four handle origins and their caller ledgers.

## Source files and invocation

New child file:
crates/deadpan-plan/src/audio_owners/retained_fade_coincident_diagnostic.rs.
Only two narrow additions to retained_fade_overlap_tests.rs are proposed: the
child declaration and a default-off scalar diagnostic recorder at common_phase.
The existing stronger overlap assertions and all twenty oracle files are unchanged.
Exact before/after files and per-variant patches are under variants; pins.json
hashes the current anchors and new source.

First run the exact nonignored leaf:
checked_split_partition_end_reaches_both_nonempty_retained_origin_merge
under retained_fade_baseline::overlap_tests::diagnostic.
It enables the existing retained overlap observer on the new case, preserving
full ordinary-versus-admitted comparisons for the SAME actual borrowed input.
It logs bounded Before/Ready/After old/new length counts and requires four real
Some origins and at least one actual OriginMergeReady with BOTH lengths positive.
The parent's already integrated combined copied-payload+array lower bounds remain
active for those callbacks. No new expected query output is invented.

Optional ignored bounded leaf:
existing_retained_corpora_report_actual_origin_merge_shapes.
It runs the existing fifty Some scopes/594 windows, compares both immutable bodies
literally, and logs the actual merge phase/old/new count map without weakening the
original combined resource test's positive-coverage requirement.

## Why current checked windows missed the phase

Source/frozen-state inspection finds only two existing Some families with nonempty
outer editorial, four origins each: fractional crop entry and captured marked
repeat fragment. Their sole transported marker is geometrically distinct from the
underlying full voice endpoints (crop 1..4 versus whole voice; fragment 4..8 versus
retained voice 2..10). Multiple final origins can be assembled into ONE new marker
by append_origins before merge_edge; that final origin count alone does not prove
two nonempty edge arrays coexist. The bounded existing-corpus diagnostic can
establish the actual Before/Ready/After event distribution. No impossibility or
unreachability claim is made from the current zero counter.

## Independent additive ordinary witness

The ignored leaf capture_current_literal_ordinary_retained_coincidence_v1 writes
a fresh file only when explicitly invoked by the parent. It requires:

- DEADPAN_RETAINED_COINCIDENT_OUTPUT: fresh absolute path beneath an existing /tmp
  directory; canonical parent validation and create_new prevent overwrite.
- DEADPAN_RETAINED_COINCIDENT_VARIANT: main-inherited or scoped-published.
- DEADPAN_RETAINED_COINCIDENT_SOURCE_SHA256: actual parent complete-source manifest.
- DEADPAN_RETAINED_COINCIDENT_ORDINARY_SOURCE_SHA256: parent's ordinary-algorithm
  pin-manifest identity.
- DEADPAN_RETAINED_COINCIDENT_PUBLISHED_CHECKPOINT:
  ee9742711868fde9a78bcb945adfd36e67f504d6.

Admission observers are disabled for this capture. Its body is generated by the
still-literal ordinary retained fades method on actual ordinary/admitted-false/
admitted-true/shared inputs, retaining each origin's literal stored Bound work.
It is labelled truthfully as a CURRENT-TREE unchanged-ordinary-algorithm witness,
not a pre-implementation native build. Existing twenty witnesses are not refreshed.

Read-only published-source comparison was actually performed: the exact current
AudioOwnerRetainedInput::fades method bytes in BOTH roots match published ee at
SHA-256 b900bf94dc7cbbfb7f3f2f591641aef8b771ee9f0599d011b6bedd007c78f187.
The entire ordinary audio_fades.rs also matches ee in BOTH roots at
b9ea79fbe311e790861fc9a65118616be26947357235c7242edfc84d00e74af2.
See ordinary-algorithm-pins.json and saved published source. Parent must pin the
actual candidate binary/full source and recheck these identities before capture.

The manual producer creates its file before computing the body. An early panic
may leave an empty partial output; preserve the failure and use a fresh path on
retry. No expected body or native result exists in this candidate.
