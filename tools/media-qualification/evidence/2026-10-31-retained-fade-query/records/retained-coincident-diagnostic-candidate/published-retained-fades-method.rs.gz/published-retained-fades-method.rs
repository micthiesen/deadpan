    pub fn fades(
        &self,
        samples: std::ops::Range<AudioSample>,
        limits: AudioQueryLimits,
    ) -> Result<AudioFadeQuery, PlanError> {
        limits.validate()?;
        if samples.end < samples.start {
            return Err(PlanError::AudioRangeOutOfRange);
        }
        let mut budget = Budget {
            remaining: limits.maximum_work,
            lookup: LookupStats::default(),
        };
        let mut spans = Vec::new();
        let mut cursor = samples.start;
        while cursor < samples.end {
            if spans.len() == limits.maximum_spans {
                return Err(PlanError::AudioQueryLimit("retained fade span count"));
            }
            budget.spend(
                1 + self.bound().work()
                    + self.processing.retimes.len()
                    + self.processing.instance.repeats.len()
                    + self.editorial.editorial.len()
                    + self.editorial.constraints.len()
                    + self.editorial.repeats.len(),
            )?;
            let span = super::audio_fades::retained_bound_fade(
                self.processing.clone(),
                cursor,
                samples.end,
                self.editorial.clone(),
                &mut budget,
            )?;
            if span.samples.start != cursor
                || span.samples.end <= cursor
                || span.samples.end > samples.end
            {
                return Err(PlanError::InvalidPlan(
                    "retained fade interval did not advance",
                ));
            }
            cursor = span.samples.end;
            spans.push(span);
        }
        Ok(AudioFadeQuery {
            spans,
            lookup: budget.lookup,
            work: limits.maximum_work - budget.remaining,
        })
    }