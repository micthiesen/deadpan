from pathlib import Path
import json,hashlib,difflib,subprocess
r=Path("/tmp/deadpan-retained-fade-query-admission-2026-10-30/retained-coincident-diagnostic-candidate")
target="crates/deadpan-plan/src/audio_owners/retained_fade_overlap_tests.rs"
new="crates/deadpan-plan/src/audio_owners/retained_fade_coincident_diagnostic.rs"
def d(b):return hashlib.sha256(b).hexdigest()
pins={"schema":"scratch-retained-coincidence-diagnostic-v1","new_file":{"path":new,"sha256":d((r/new).read_bytes())},"variants":{},"typechecked":False,"executed":False}
for variant,repo in [("main-inherited",Path("/Users/michael/Code/deadpan")),("scoped-published",Path("/tmp/deadpan-query-groundwork-2026-10-26/scoped"))]:
 before=(repo/target).read_text()
 needle="fn common_phase(event: Event) {\n"
 assert before.count(needle)==1
 after=before.replace(needle,needle+"    diagnostic::record(event);\n")
 after+='\n#[path = "retained_fade_coincident_diagnostic.rs"]\nmod diagnostic;\n'
 folder=r/"variants"/variant
 for state,text in [("before",before),("after",after)]:
  path=folder/state/target;path.parent.mkdir(parents=True,exist_ok=True);path.write_text(text)
 subprocess.run(["rustfmt","--edition","2024","--config","skip_children=true",str(folder/"after"/target)],check=True)
 after=(folder/"after"/target).read_text()
 patch="".join(difflib.unified_diff(before.splitlines(True),after.splitlines(True),fromfile="a/"+target,tofile="b/"+target))
 patch+="".join(difflib.unified_diff([],(r/new).read_text().splitlines(True),fromfile="/dev/null",tofile="b/"+new))
 (folder/"candidate.patch").write_text(patch)
 pins["variants"][variant]={"target":target,"before_sha256":d(before.encode()),"after_sha256":d(after.encode()),"patch_sha256":d(patch.encode())}
(r/"pins.json").write_text(json.dumps(pins,indent=2)+"\n")
print(json.dumps({"new_file":pins["new_file"],"patches":{k:v["patch_sha256"] for k,v in pins["variants"].items()}},indent=2))
