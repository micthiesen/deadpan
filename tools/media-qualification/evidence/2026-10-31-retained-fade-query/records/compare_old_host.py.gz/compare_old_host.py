from pathlib import Path
import json,hashlib
s=Path(__file__).resolve().parent
a=json.loads((s/'retained-host-old-main-body.json').read_text());b=json.loads((s/'retained-host-old-scoped-body.json').read_text())
for d in[a,b]:
 for name in['variant','source_sha256','published_fade_checkpoint']:d.pop(name)
def first_difference(a,b,path='$'):
 if type(a)!=type(b):return(path,type(a).__name__,type(b).__name__)
 if isinstance(a,dict):
  if a.keys()!=b.keys():return(path+'.keys',list(a),list(b))
  for key in a:
   d=first_difference(a[key],b[key],path+'.'+key)
   if d:return d
 elif isinstance(a,list):
  if len(a)!=len(b):return(path+'.length',len(a),len(b))
  for i,(x,y)in enumerate(zip(a,b)):
   d=first_difference(x,y,path+f'[{i}]')
   if d:return d
 elif a!=b:return(path,a,b)
 return None
if a!=b:
 diff=first_difference(a,b);(s/'old-host-first-difference.json').write_text(json.dumps(diff,indent=2)+'\n')
 raise SystemExit(str(diff))
canonical=(json.dumps(a,sort_keys=True,separators=(',',':'))+'\n').encode()
p=s/'retained-host-old-canonical-body.json';assert not p.exists();p.write_bytes(canonical)
out={'complete_main_scoped_equal':True,'removed_fields':['variant','source_sha256','published_fade_checkpoint'],'canonical_bytes':len(canonical),'canonical_sha256':hashlib.sha256(canonical).hexdigest(),'keys':list(a)}
(s/'old-host-equality.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out))
