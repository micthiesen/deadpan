# Retained fade admission production review

Scope: integrated Main source in /Users/michael/Code/deadpan; reviewed audio_bound_fade_copy.rs, audio_retained_fades_query.rs, shared audio_fades_query.rs / audio_bound_query.rs, and retained_request.rs / stages.rs against admission-design.md and the candidate-before sources. Scope-only Plan has the inherited isolated plan.rs change; the fade implementation is otherwise the same.

## Findings

None.

## Evidence and limits

- The retained API charges the original constructor's literal per-span formula before copying, then charges new copied fields and real capacity reservations separately. The inner bounded-envelope implementation keeps the original full-history geometry, repeats and constraints, and uses the same untrimmed fade path and edge/origin merge operations as the existing query.
- The metered Bound copy explicitly destructures every field. It independently copies the Bound instance, lattice instance, gap IDs, clock identities and all constraints; preserves both stored work values, resume, lattice geometry and birth fields; retains borrowed plan/node identity; and clones only stack-sized range/ratio values outside the charged heap-copy path.
- Processing and editorial copies allocate through storage::fixed. Their Owned values put copied vectors before their memory carriers. Bound boxing reserves the actual Box<AudioBound> shell before constructing it and merges its carrier with issuer checks. Query finish keeps span values before the aggregate capacity carrier.
- Host read spends retained-input work before constructing fades, holds the admitted fade carrier across owner preparation, room-making, provider reads and DSP, then explicitly drops owners and fades on both success and ordinary error returns. It does not separately spend query.work, so the admission callbacks are not double-billed.
- I found no unpropagated checked merge, fallback to an ordinary constructor in metered mode, early truncation of history, or path that turns factory None/error into synthetic success in these production paths.
- Static review only. Parent compilation/native runs were in flight; this report does not claim they passed or prove runtime behavior.
