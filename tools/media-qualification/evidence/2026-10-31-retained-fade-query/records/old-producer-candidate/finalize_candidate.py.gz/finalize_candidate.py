from pathlib import Path
import hashlib,difflib,json,shutil
base=Path('/tmp/deadpan-retained-fade-query-admission-2026-10-30/old-producer-candidate')
roots={'main':Path('/Users/michael/Code/deadpan'),'scoped':Path('/tmp/deadpan-query-groundwork-2026-10-26/scoped')}
paths=['crates/deadpan-plan/src/audio_owners/wide_gain_query_admission_tests.rs','crates/deadpan-plan/src/audio_owners/legacy_snapshot_v1.rs']
sources=paths+[
'crates/deadpan-plan/src/audio_owners/tests.rs',
'crates/deadpan-plan/src/audio_owners/input_tests.rs',
'crates/deadpan-plan/src/audio_owners/legacy_snapshot_v1/policy_binding_baseline.rs',
'crates/deadpan-plan/src/audio_owners/legacy_snapshot_v1/fade_query_baseline.rs',
'crates/deadpan-plan/src/audio_owners/legacy_snapshot_v1/capture_baseline.rs',
'crates/deadpan-plan/src/audio_owners/legacy_snapshot_v1/wide_baseline.rs',
'crates/deadpan-plan/src/audio_owner_input.rs',
'crates/deadpan-plan/src/audio_owner_probe.rs',
'crates/deadpan-plan/src/audio_context_sharing.rs',
'crates/deadpan-plan/src/audio_retained_owner_query.rs',
'crates/deadpan-plan/src/audio_fades.rs',
'crates/deadpan-plan/src/audio.rs',
'crates/deadpan-plan/tests/fixtures/fade-query-baseline-v1/snapshot.json',
'crates/deadpan-audio/src/bound_reads.rs',
'crates/deadpan-audio/src/bound_reads/owner_input.rs',
'crates/deadpan-audio/src/stages.rs',
]
sha=lambda b:hashlib.sha256(b).hexdigest()
manifest={'status':'prepare-only; no build, execution, capture, expected body generation, or actual source mutation','variants':{}}
for variant,root in roots.items():
    pins={p:{'sha256':sha((root/p).read_bytes()),'bytes':(root/p).stat().st_size} for p in sources}
    patches=[]
    for p in paths:
        old=(root/p).read_text()
        before=base/'before'/variant/p;before.parent.mkdir(parents=True,exist_ok=True);before.write_text(old)
        if p.endswith('wide_gain_query_admission_tests.rs'):
            assert 'mod retained_fade_baseline;' not in old
            new=old+'\n#[path = "retained_fade_baseline.rs"]\nmod retained_fade_baseline;\n'
        else:
            anchors=["fn input(value: &AudioOwnerInput<'_>) -> Value {","fn error_json(value: &PlanError) -> Value {"]
            new=old
            for anchor in anchors:
                assert new.count(anchor)==1
                new=new.replace(anchor,'pub(in crate::plan) '+anchor,1)
            # Only visibility words change, bodies stay byte-identical.
            assert new.replace('pub(in crate::plan) fn input(', 'fn input(').replace('pub(in crate::plan) fn error_json(', 'fn error_json(')==old
        after=base/'after'/variant/p;after.parent.mkdir(parents=True,exist_ok=True);after.write_text(new)
        patches.extend(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile='a/'+p,tofile='b/'+p))
        pins[p]['suggested_after_sha256']=sha(new.encode())
    patch=base/f'declarations-{variant}.patch';patch.write_text(''.join(patches))
    manifest['variants'][variant]={'read_sources':pins,'declaration_patch_sha256':sha(patch.read_bytes())}
newpaths=['crates/deadpan-plan/src/audio_owners/retained_fade_baseline.rs','crates/deadpan-plan/src/audio_owners/retained_fade_cases.rs']
patch=[]
manifest['new_sources']={}
for p in newpaths:
    content=(base/p).read_text()
    manifest['new_sources'][p]={'sha256':sha(content.encode()),'bytes':len(content.encode())}
    patch.extend(difflib.unified_diff([],content.splitlines(True),fromfile='/dev/null',tofile='b/'+p))
(base/'new-files.patch').write_text(''.join(patch))
manifest['new_files_patch_sha256']=sha((base/'new-files.patch').read_bytes())
(base/'pins.json').write_text(json.dumps(manifest,indent=2)+'\n')
