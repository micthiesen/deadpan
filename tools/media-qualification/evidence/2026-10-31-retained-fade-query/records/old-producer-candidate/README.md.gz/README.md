# Preparatory retained-fade OLD witness

Status: scratch candidate only. No actual source integration, compilation, test execution, capture, expected body, or freeze was performed. The current fade checkpoint must be published before the parent integrates or captures this next unit. The explicit checkpoint environment variable records provenance; it cannot prove publication itself.

## Files and exact wiring

Copy these new files into the matching paths only after that publication gate:

- crates/deadpan-plan/src/audio_owners/retained_fade_baseline.rs
- crates/deadpan-plan/src/audio_owners/retained_fade_cases.rs

Apply only the matching declarations-main.patch or declarations-scoped.patch. Each appends a child of the existing cfg(test) wide_gain_query_admission_tests module. This placement reuses its actual private Policy<M>, PolicyState, and Lease ledger without a duplicate accounting framework. The other file changes only the visibility of legacy_snapshot_v1::input and error_json to pub(in crate::plan). Their bodies remain byte-identical; there is no production API or algorithm change.

before/{variant}/ and after/{variant}/ contain the complete exact existing-file bytes used to build each declaration patch, preserving current Main/Scope differences. pins.json records source hashes, proposed after hashes, candidate hashes, and patch hashes. new-files.patch is the normalized new-source patch. Parent should recheck before hashes immediately before integration and adapt only declaration context if concurrent source changed.

## Actual handle provenance

Every checked setup constructs a real RenderPlan, obtains an actual gain owner, and obtains its actual AudioOwnerInput. Existing visit_additional setups keep their existing checked input. The complete document and selector/input snapshots accompany each case.

Each input is evaluated independently in these modes:

1. Ordinary retained_probe_at. Actual Some, None, or typed failure is serialized.
2. Actual retained_probe_at_admitted with METERED=false.
3. Actual retained_probe_at_admitted with METERED=true, keeping the actual probe and all its guards alive while borrowing its retained value for ordinary fades.
4. Actual METERED=true probe, followed by actual retained.owners_admitted on the observed sample and the existing treatment-owner membership predicate. On a selected Some, the SAME probe is consumed by into_shared_admitted while the owner-query guard remains alive. Its actual resulting shared retained handle remains alive for every fade call. Rejection, absent probe, selection failure, and sharing failure are serialized literally.

Mode 4 exercises the actual public Plan construction/sharing sequence. It does not claim a complete StageAudio decision replay, conditional host fallback Domain setup, boundary-owner alternatives, or global ReadWork accounting.

No ordinary equivalent is reconstructed from admitted metadata. The complete private retained snapshot records processing, editorial capture, raw Root/Point domain, immutable bound payloads and work. literal_bound_work_prepaid_per_span is the actual retained.bound().work(), not a derived offset. Returned fade work stays literal even when admitted-created bound work differs. Empty raw support is not manufactured.

The Policy ledger records retained probe, owner selection, and sharing construction only. It is sampled while the actual carriers live, required to remain unchanged across ordinary fade calls, and required to return to zero live bytes after handle drop. These observations are not admitted-fade allocation/peak evidence and make no RSS claim. No issuer address or pointer is serialized.

## Checked fixture coverage

The producer reuses all six actual policy_binding_baseline::visit_additional setups, preserving factory absence as well as presence. It adds five checked ports:

- Plan retained_binding_is_not_reconstructed_from_its_nominal_descendant_clock: signed Root retained history and moved enclosing Preserve.
- Plan moved_preserve_input_keeps_its_point_ceil_reference_labels: actual Point reference labels and historical samples.
- Audio retained_ntsc_binding_and_silence_keep_the_current_output_policy: Root 30000/1001 source plus silence.
- Audio retained_point_input_fades_keep_fractional_source_phase_before_delivery: moved fractional-source Point plus explicit reference document.
- Audio retained_treatments_keep_reference_gain_mute_and_order_without_exterior_owners: actual reference saturation/gain/balance order, gain envelope and mute region, excluded exterior treatment.

Plan helper bodies and audio metadata/helper ports retain the checked constructors. Audio cases reproduce the final ProjectDocument metadata from bound_reads::document and controlled_reads::fixture_document_at_rate. The provider, WAV opening, and numerical reader assertions remain in the existing Audio tests. Complete old/current/reference documents make this metadata-only port reviewable. This producer does not claim native playback evidence.

For every actual retained Some it queries delivery, observation, empty, crop, adjacent pages, seams, signed support, mapped reference support, surrounding history, and fixture windows. Reference inversion computes request labels from actual raw domain endpoints, reference_at, and step; all outputs still come from ordinary retained.fades.

Every successful default window is rerun at its literal returned work and one-short work (if positive). Literal zero remains an invalid-limit observation, not an invented positive exact cap. Span probes use literal output count when nonempty; one-short positive count only exists when output count exceeds one. Empty output uses the minimum legal positive span cap. These probes do not assume the public output count is the only internal span budget.

Malformed/tiny-positive cases preserve actual validation priority: reversed range, zero/above-hard-cap work or spans, invalid limits plus reversed range, empty plus invalid limits, minimum-positive work/spans, and actual extreme signed requests. No expected outcome or global cap is invented. Some historical windows may expose a real typed failure, which is retained in the body.

## Parent-owned integration and capture commands

First typecheck the integrated cfg(test) producer. Then obtain the actual test path with the parent's test executable --list. The intended exact paths, derived from the current parent declaration, are:

plan::audio_owners::wide_gain_query_admission_tests::retained_fade_baseline::capture_old_retained_fade_query_baseline_v1

plan::audio_owners::wide_gain_query_admission_tests::retained_fade_baseline::ordinary_retained_fades_match_explicit_external_old_v1

These paths have not been confirmed by --list. Do not count zero-test commands as coverage.

The manual producer is ignored. The parent invokes the listed exact test with --ignored --exact after assigning:

- DEADPAN_RETAINED_FADE_OUTPUT: a new absolute path whose existing parent resolves under /tmp. create_new refuses overwrite.
- DEADPAN_RETAINED_FADE_VARIANT: main-inherited or scoped-published.
- DEADPAN_RETAINED_FADE_SOURCE_SHA256: SHA-256 of the parent's complete actual OLD source manifest.
- DEADPAN_RETAINED_FADE_PUBLISHED_CHECKPOINT: the actual published fade checkpoint identity.

The external ordinary regression scaffold is also ignored and requires DEADPAN_RETAINED_FADE_EXPECTED pointing at an independent complete capture. It removes only variant, source_sha256, and published_fade_checkpoint and compares the entire actual matrix. It supplies no expected body and performs no normalization.

Run both real variants from their pinned OLD binaries before retained-fade production changes. Verify all bodies and actual availability/coverage, compare after only those three provenance fields, independently review, and freeze only after agreement. Any permanent repository fixture/regression wiring is parent-owned after capture.

## Owed verification and bounded gaps

Only rustfmt parsing/checking and scratch patch dry runs are performed here. Borrow/type correctness, runtime factory availability, success/error counts, exact test paths, Main/Scope equality, and capture duration remain unverified. Existing Some/None counts are not assumed for the new producer. The sharing sequence intentionally exercises the real membership result and may serialize rejection.

The producer does not cover malformed private retained values, synthetic Empty support, synthetic raw Stage/Span values, policy callback refusal/rotation, foreign issuers, admitted retained-fade allocation, host lifetime, or numerical playback. Refusal/rotation and independent Layout proofs belong to the later admitted implementation tests. Exact legal Layout overflow has no demonstrated reachable fixture here.

The selected checked fixtures cover Root and Point provenance, signed historical support and multiple treatments. They do not establish exhaustive retained binding reanchor/birth/argument histories, every creative edge kind/merge collision, or every owner-selection alternative. Complete private snapshots preserve any real history present. Add only real checked document factories if the actual captured coverage report exposes a needed missing branch; do not force factory Some or fabricate a retained query.

The generated Python helpers are preparation utilities only; final reviewed Rust files and exact patches are authoritative. Do not rerun a generator against changed actual sources without regenerating/reviewing pins and patches.
