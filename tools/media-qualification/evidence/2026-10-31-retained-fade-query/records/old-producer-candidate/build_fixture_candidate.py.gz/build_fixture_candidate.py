from pathlib import Path
root=Path('/Users/michael/Code/deadpan')
out=Path('/tmp/deadpan-retained-fade-query-admission-2026-10-30/old-producer-candidate/crates/deadpan-plan/src/audio_owners')
plan=(root/'crates/deadpan-plan/src/audio_owners/tests.rs').read_text()
audio=(root/'crates/deadpan-audio/src/bound_reads.rs').read_text()
owner=(root/'crates/deadpan-audio/src/bound_reads/owner_input.rs').read_text()
def between(s,a,b): return s[s.index(a):s.index(b,s.index(a))]
# Exact literal checked helper bodies; provider removal is explicit in metadata_document below.
plan_helpers=between(plan,'fn id(', '#[test]')
audio_helpers=between(audio,'fn id(', 'fn document(')+between(audio,'fn lattice(', 'fn render(')
head='''//! Exact checked fixture ports for the preparatory retained-fade OLD witness.
//! Audio ports reconstruct the checked metadata only; no media file/provider is opened.
use super::*;
use deadpan_core::*;
use std::collections::BTreeMap;

fn observe(
    visit: &mut impl FnMut(&Value, &AudioOwnerInput<'_>, &[(&str, i64, i64)]),
    descriptor: Value, document: &ProjectDocument, name: &str, at: i64,
    windows: &[(&str, i64, i64)],
) {
    let plan = RenderPlan::compile(document).unwrap();
    let selected = plan.audio_gain_owners(AudioSample(at)..AudioSample(at + 1), Default::default())
        .unwrap().spans()[0].owners().iter()
        .find(|owner| owner.instance().node == NodeId::new(name).unwrap()).unwrap().clone();
    let input = plan.audio_owner_input(&selected, AudioSample(at), Default::default()).unwrap();
    let mut descriptor = descriptor;
    descriptor["document"] = serde_json::to_value(document).unwrap();
    descriptor["selector"] = json!({"node":name,"observed_at":at,"factory":"audio_gain_owners then actual audio_owner_input"});
    visit(&descriptor, &input, windows);
}

pub(in crate::plan) fn visit_cases(
    mut visit: impl FnMut(&Value, &AudioOwnerInput<'_>, &[(&str, i64, i64)]),
) {
    plan_ports::visit(&mut visit);
    audio_ports::visit(&mut visit);
}
mod plan_ports {
use super::*;
'''
# remove unused repeat helper; document_at retained by document.
plan_helpers=plan_helpers[:plan_helpers.index('fn repeat(')]+plan_helpers[plan_helpers.index('fn document('):]
plan_vis='''pub(super) fn visit(visit: &mut impl FnMut(&Value,&AudioOwnerInput<'_>,&[(&str,i64,i64)])) {
    let nodes = || vec![
        ("a",hold(2)),("b",hold(2)),("group",sequence(&["a","b"])),
        ("stage",retime("group",8,0..4,PitchPolicy::Preserve,RetimePurpose::Edit)),
    ];
    let old=document(48_000,&["stage"],nodes());
    let mut moved=nodes(); moved.push(("prefix",hold(1)));
    let current=document(48_000,&["prefix","stage"],moved);
    let bound=bind(&current,&old,"stage",AudioClockRoot::ProjectRootRoundEven,Some(ratio(3,1)));
    observe(visit,json!({"name":"plan/root_retained_descendant",
        "source":{"path":"crates/deadpan-plan/src/audio_owners/input_tests.rs","symbol":"retained_binding_is_not_reconstructed_from_its_nominal_descendant_clock"},
        "old_document":old,"current_document":current}),&bound,"group",1,
        &[("signed_complete",-3,7),("root_reference_seam",1,3),("before_delivery",-2,0)]);
    let old=document(32_000,&["stage"],vec![
        ("prefix",hold(1)),("voice",hold(2)),("group",sequence(&["prefix","voice"])),
        ("stage",retime("group",6,0..3,PitchPolicy::Preserve,RetimePurpose::Edit)),
    ]);
    let current=document(32_000,&["voice"],vec![("voice",hold(2))]);
    let bound=bind(&current,&old,"voice",AudioClockRoot::PreserveInputPointCeil{stage:id("stage")},None);
    observe(visit,json!({"name":"plan/point_retained_labels",
        "source":{"path":"crates/deadpan-plan/src/audio_owners/input_tests.rs","symbol":"moved_preserve_input_keeps_its_point_ceil_reference_labels"},
        "old_document":old,"current_document":current}),&bound,"voice",0,
        &[("point_reference_support",-2,6),("first",0,1),("later",2,3)]);
}
}
mod audio_ports {
use super::*;
'''
meta='''fn metadata_document(rate: FrameRate, children: &[&str], nodes: Vec<(&str,BeatNode)>) -> ProjectDocument {
    // Exact final metadata from bound_reads::document + controlled_reads::fixture_document_at_rate.
    let base=ProjectDocument::new(ProjectId::new("controlled-read").unwrap(),revision("revision"),
        PresentationBasis{width:16,height:16,frame_rate:rate,color_policy:ColorPolicy::SdrRec709},id("root")).unwrap();
    let mut wire=serde_json::to_value(base).unwrap();
    let mut nodes:BTreeMap<_,_>=nodes.into_iter().map(|(name,node)|(id(name),node)).collect();
    nodes.insert(id("root"),BeatNode::sequence("Root",children.iter().map(|name|id(name)).collect()));
    wire["nodes"]=serde_json::to_value(nodes).unwrap();
    let audio=SourceSpan::new(
        SourceTimestamp{ticks:0,time_base:SourceTimeBase::new(1,48_000).unwrap()},
        SourceTimestamp{ticks:8197,time_base:SourceTimeBase::new(1,48_000).unwrap()}).unwrap();
    wire["assets"]=serde_json::to_value(BTreeMap::from([(AssetId::new("media").unwrap(),AssetRecord{
        label:"PCM fixture".into(),content_hash:"a".repeat(64),video:None,audio:Some(audio),
        still_image:true,frame_count:None,source_qualification:None})])).unwrap();
    ProjectDocument::from_json(&wire.to_string()).unwrap()
}
'''
# Real constructor portions copied with provider-free metadata adapter only. Assertions/numeric readers remain in source tests.
ntsc=between(owner,'    let rate = FrameRate::new(30_000, 1001).unwrap();','    let plan = Arc::new(RenderPlan::compile(&bound).unwrap());')
ntsc=ntsc.replace('("group", group())','("group", BeatNode::sequence("Group", vec![id("a"),id("b")]))')
ntsc=ntsc.replace('let (old, mut provider) = document(', 'let old = metadata_document(').replace('let (current, _) = document(','let current = metadata_document(')
point=between(owner,'    let rate = FrameRate::new(32_000, 1).unwrap();\n    let (old, mut provider) = document(','    let plan = Arc::new(RenderPlan::compile(&moved).unwrap());')
point=point.replace('let (old, mut provider) = document(', 'let old = metadata_document(').replace('let (base, _) = document(', 'let base = metadata_document(').replace('let (moved, _) = document(', 'let moved = metadata_document(')
treat=between(owner,'    let rate = FrameRate::new(48_000, 1).unwrap();\n    let mut voice = source(', '    let plan = Arc::new(RenderPlan::compile(&bound).unwrap());')
treat=treat.replace('let (old, mut provider) = document(', 'let old = metadata_document(').replace('let (current, _) = document(', 'let current = metadata_document(')
end='''pub(super) fn visit(visit: &mut impl FnMut(&Value,&AudioOwnerInput<'_>,&[(&str,i64,i64)])) {
{
'''+ntsc+'''
    observe(visit,json!({"name":"audio/root_ntsc_retained_source_and_silence",
        "source":{"path":"crates/deadpan-audio/src/bound_reads/owner_input.rs","symbol":"retained_ntsc_binding_and_silence_keep_the_current_output_policy",
            "metadata_port":"bound_reads::document plus controlled_reads::fixture_document_at_rate; provider/media excluded"},
        "old_document":old,"current_document":current}),&bound,"group",1602,
        &[("source",1602,1730),("near_source_end",7900,8028),("silence",8100,8228),("late_silence",12000,12128)]);
}
{
'''+point+'''
    observe(visit,json!({"name":"audio/point_retained_fractional_source",
        "source":{"path":"crates/deadpan-audio/src/bound_reads/owner_input.rs","symbol":"retained_point_input_fades_keep_fractional_source_phase_before_delivery",
            "metadata_port":"bound_reads::document plus controlled_reads::fixture_document_at_rate; provider/media excluded"},
        "old_document":old,"base_document":base,"reference_document":reference}),&moved,"a",8,
        &[("source_start",5,69),("early",69,133),("middle",261,325),("near_end",477,541),("after_end",541,605)]);
}
{
'''+treat+'''
    observe(visit,json!({"name":"audio/root_retained_reference_treatments",
        "source":{"path":"crates/deadpan-audio/src/bound_reads/owner_input.rs","symbol":"retained_treatments_keep_reference_gain_mute_and_order_without_exterior_owners",
            "metadata_port":"bound_reads::document plus controlled_reads::fixture_document_at_rate; provider/media excluded"},
        "old_document":old,"current_document":current}),&bound,"a",512,
        &[("signed_start",-1536,-1440),("early",-1504,-1408),("before_mute",448,544),
            ("mute_start",504,600),("mute_end",524,620),("envelope_end",2560,2656),("source_end",6560,6656)]);
}
}
}
'''
(out/'retained_fade_cases.rs').write_text(head+plan_helpers+plan_vis+audio_helpers+meta+end)
producer=out/'retained_fade_baseline.rs'
producer.write_text(producer.read_text().replace('snapshot::{capture_baseline, fade_query_baseline, policy_binding_baseline}', 'snapshot::{fade_query_baseline, policy_binding_baseline}'))
