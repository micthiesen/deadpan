from pathlib import Path
import json,difflib,hashlib
s=Path(__file__).resolve().parent;out=[]
roots={'main':Path('/Users/michael/Code/deadpan'),'scoped':Path('/tmp/deadpan-query-groundwork-2026-10-26/scoped')}
for variant,root in roots.items():
 name='crates/deadpan-plan/src/audio_owners/retained_fade_baseline.rs'
 p=root/name;before=p.read_text();after=before
 old='''fn retained_body(
    input: &AudioOwnerInput<'_>,
    retained: &AudioOwnerRetainedInput<'_>,
    extra: &[(&str, i64, i64)],
) -> Value {'''
 new=old.replace('\n) -> Value {','\n    caller: Option<&Rc<RefCell<PolicyState>>>,\n) -> Value {')
 assert after.count(old)==1;after=after.replace(old,new)
 old='.map(|retained| retained_body(input, retained, extra));'
 assert after.count(old)==2
 after=after.replace(old,'.map(|retained| retained_body(input, retained, extra, None));',1)
 after=after.replace(old,'.map(|retained| retained_body(input, retained, extra, Some(&policy.0)));',1)
 old='let body = retained_body(input, retained, extra);';assert after.count(old)==1
 after=after.replace(old,'let body = retained_body(input, retained, extra, Some(&policy.0));')
 old='admission_tests::observe(input, retained, &observations);';assert after.count(old)==1
 after=after.replace(old,'admission_tests::observe(input, retained, &observations, caller);\n    copy_tests::observe(input, retained, &observations);')
 after+='''\n#[path = "retained_fade_copy_tests.rs"]
mod copy_tests;
'''
 out.append((p,before,after))
 name='crates/deadpan-plan/src/audio_owners/retained_fade_admission_tests.rs';p=root/name;before=p.read_text();after=before
 old='''    rows: &[Value],
) {'''
 assert after.count(old)==1
 after=after.replace(old,'''    rows: &[Value],
    caller: Option<&Rc<RefCell<PolicyState>>>,
) {''')
 old='    let before = retained.capture_baseline_snapshot(input.context().plan);';assert after.count(old)==1
 after=after.replace(old,old+'\n    let caller_before = caller_snapshot(caller);')
 start=after.index('                for (is_reserve, count)')
 end=after.index('\n            }\n        }\n    }\n    assert_eq!',start)
 after=after[:start]+'''                let attempts = failure_audit::check(retained, row, caller);
                COUNTS.with(|counts| counts.borrow_mut().1 += attempts);'''+after[end:]
 # Every completed query, including failed limit attempts, keeps the caller ledger.
 after=after.replace('                COUNTS.with(|counts| counts.borrow_mut().1 += 1);','                assert_eq!(caller_snapshot(caller), caller_before);\n                COUNTS.with(|counts| counts.borrow_mut().1 += 1);')
 after=after.replace('                drop(value);','                assert_eq!(caller_snapshot(caller), caller_before);\n                drop(value);')
 after=after.replace('    assert_eq!(\n        retained.capture_baseline_snapshot','    assert_eq!(caller_snapshot(caller), caller_before);\n    assert_eq!(\n        retained.capture_baseline_snapshot')
 after+='''\nfn caller_snapshot(caller: Option<&Rc<RefCell<PolicyState>>>) -> Option<[usize; 6]> {
    caller.map(|state| {
        let state = state.borrow();
        if state.forwarded > 0 {
            assert!(state.live > 0, "actual metered caller retains its leases");
        }
        [state.live, state.peak, state.cap, state.reservations, state.forwarded, state.work_calls]
    })
}
#[path = "retained_fade_failure_audit.rs"]
mod failure_audit;
'''
 out.append((p,before,after))
 audit=(s/'retained_fade_failure_audit.rs').read_text()
 audit=audit.replace('struct Recording {','''#[derive(Clone)]
struct Caller {
    state: Rc<RefCell<PolicyState>>,
    before: Option<[usize; 6]>,
}
impl Caller {
    fn check(&self) {
        assert_eq!(caller_snapshot(Some(&self.state)), self.before);
    }
}
struct Recording {
    caller: Option<Caller>,''')
 audit=audit.replace('fn new() -> Self {','fn new(caller: Option<&Rc<RefCell<PolicyState>>>) -> Self {')
 audit=audit.replace('''        Self {
            states:''','''        Self {
            caller: caller.map(|state| Caller { state: Rc::clone(state), before: caller_snapshot(Some(state)) }),
            states:''')
 audit=audit.replace('''    fn remember(&mut self) {''','''    fn check_caller(&self) {
        if let Some(caller) = &self.caller { caller.check(); }
    }
    fn remember(&mut self) {
        self.check_caller();''')
 audit=audit.replace('''    fn assert_released(&self) {''','''    fn assert_released(&self) {
        self.check_caller();''')
 audit=audit.replace('''        let result = self.policy.''','''        self.check_caller();
        let result = self.policy.''')
 audit=audit.replace('''        self.policy.merge(target, source);''','''        self.check_caller();
        self.policy.merge(target, source);''')
 audit=audit.replace("row: &Value) -> usize", "row: &Value, caller: Option<&Rc<RefCell<PolicyState>>>) -> usize")
 audit=audit.replace('Recording::new()', 'Recording::new(caller)')
 new=[
 ('crates/deadpan-plan/src/audio_owners/retained_fade_failure_audit.rs',audit),
 ('crates/deadpan-plan/src/audio_owners/retained_fade_copy_tests.rs',(s/'plan-admission-candidate/tests/crates/deadpan-plan/src/audio_owners/retained_fade_copy_tests.rs').read_text())]
 for name,body in new:
  p=root/name;assert not p.exists();out.append((p,None,body))
patches=[]
for p,before,after in out:
 if before is None:
  patch='*** Begin Patch\n*** Add File: '+str(p)+'\n'+''.join('+'+l+'\n'for l in after.splitlines())+'*** End Patch'
 else:
  target=s/'stronger-tests-before'/str(p).lstrip('/');target.parent.mkdir(parents=True,exist_ok=True);target.write_text(before)
  lines=list(difflib.unified_diff(before.splitlines(keepends=True),after.splitlines(keepends=True)))[2:]
  patch='*** Begin Patch\n*** Update File: '+str(p)+'\n'+''.join('@@\n'if l.startswith('@@')else l for l in lines)+'*** End Patch'
 patches.append({'path':str(p),'patch':patch})
(s/'stronger-tests-integration-patches.json').write_text(json.dumps(patches))
print(json.dumps(patches))
