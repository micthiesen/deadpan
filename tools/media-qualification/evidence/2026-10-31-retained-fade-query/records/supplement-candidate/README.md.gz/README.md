# Additive retained-fade OLD owning-lane supplement

Prepare-only candidate. No actual repo edits, compilation, execution, capture, expected body generation or freeze were performed. The original retained v1 matrix, 18th frozen oracle and regression remain unchanged.

## Integration

new-file.patch adds only crates/deadpan-plan/src/audio_owners/retained_fade_supplement.rs. Use the matching declarations-main.patch or declarations-scoped.patch, never both in one root:

- Append a cfgtest child named supplement to existing retained_fade_baseline.rs. Its existing matrix, serializer, modes and regression bodies remain byte-identical.
- Change only fade_query_baseline::cases::visit_cases visibility from pub(super) to pub(in crate::plan). Its body and all checked factories remain byte-identical.

The child calls the same private parent one(), actual four handle modes, exhaustive serializers and provenance-body comparison. It does not build a parallel ledger or change parent v1 cases. before/{variant}, after/{variant} and pins.json identify exact source and proposed after bytes. Both roots currently produce identical declaration patches, but retain their separate authorities. Recheck target hashes before integrating if concurrent source changes.

## Selected real observations

The existing checked fade visitor runs its factories, while the child selects only four exact Root descriptor names. It does not recapture the 80-parent Root/Domain matrix. It adds three further selector/checked-setup observations, for seven setups in total:

1. fade/signed/retained_negative_origin: real voice owner at2. Targets inherited Edit FollowSpeed retime.
2. fade/editorial/entry_after: real voice owner at2. Targets inherited crop editorial.
3. fade/point/definition_birth: real voice owner at0. Targets DefinitionPointCeil identity.
4. fade/gap_bound/root: real child owner at8008, targeting nonempty occurrence and resolved paths.
5. Same exact checked gap document: repeat DefaultGap owner at4805, targeting independent gap identities. Select kind plus node, not whole Repeat node alone.
6. Same checked gap document plus actual SetEditorialEdges(child,start=true,end=true), using the checked command pattern in repeat_editorial. Full before/command/after documents are recorded. Targets nonempty editorial and repeat inventories together.
7. Exact metadata/command/placement port from tests/gap_bindings.rs::one_play_gap_definition_uses_its_own_point_clock_and_current_duration: captured(1), SetRepeat gap3, RepeatGap definition and exact in_root_clock placement. Select the real Domain gap owner at the actual domain start. Targets definition and GapDefinitionPointCeil identity.

Real owner-query error, owner absence, input error, probe None, rejected selection or sharing failure is recorded literally. The candidate does not force a Some. Each valid setup reuses all four parent provenance modes and its complete actual input/retained/query snapshots. All ordinary work remains literal.

A per-Some owning_lanes object counts actual processing/Bound/lattice repeat paths, retimes, editorial/repeats, definitions, gaps, constraint identities and the actual clock/raw-domain tags, preserving resolved and lattice work. Coverage aggregates only these actual Some fields. every_required_lane_reached may be false. That is a proof gap to investigate through a real checked constructor, not permission to edit expected fields or fabricate retained values.

The public definition test already proves actual placed processing is Bound and its direct raw domain is Point. It does not prove this newly attempted retained factory returns Some. The supplement must establish that runtime fact.

## Manual capture and regression

Parent must typecheck first and obtain the actual test names from the resulting executable --list. Intended paths from current declarations, not yet confirmed:

plan::audio_owners::wide_gain_query_admission_tests::retained_fade_baseline::supplement::capture_old_retained_fade_supplement_v1

plan::audio_owners::wide_gain_query_admission_tests::retained_fade_baseline::supplement::ordinary_retained_fade_supplement_matches_external_old_v1

plan::audio_owners::wide_gain_query_admission_tests::retained_fade_baseline::supplement::actual_retained_supplement_reaches_owning_lanes

All three tests are ignored/manual. Use exact listed names and --ignored --exact. Zero-test output is not evidence.

Capture requires:

- DEADPAN_RETAINED_FADE_SUPPLEMENT_OUTPUT: a new absolute output whose existing parent resolves below /tmp; create_new refuses overwrite.
- DEADPAN_RETAINED_FADE_VARIANT: main-inherited or scoped-published.
- DEADPAN_RETAINED_FADE_SOURCE_SHA256: complete actual OLD source manifest SHA-256.
- DEADPAN_RETAINED_FADE_PUBLISHED_CHECKPOINT: actual published fade checkpoint identity.

The capture emits the complete body including coverage gaps and all actual availability results, without requiring coverage to be true. The separate coverage diagnostic asserts all declared lanes were actually reached and will fail otherwise, exposing the exact counts. This lets a failed proof remain inspectable in the independent capture.

The external regression requires DEADPAN_RETAINED_FADE_SUPPLEMENT_EXPECTED pointing at an independently captured complete supplement. It removes only variant, source_sha256 and published_fade_checkpoint, exactly as parent body(), and compares the entire matrix. No expected body or include_str fixture is provided. A later permanent supplement fixture and unignored regression are parent-owned after independent dual-root capture, equality review, coverage review and freeze. Never replace retained v1.

## Checks performed and owed

Performed: rustfmt parse/check of the new child; declaration patches dry-run against scratch before copies; new-file patch dry-run against an empty scratch directory. No Cargo/rustc/native execution.

Owed: actual type/borrow checking, --list confirmation, actual owner/input/probe availability, nonempty lane predicates, independent capture/equality and ordinary regression. The new checked command composition can fail validation or produce different metadata than anticipated; record and repair only through real public constructors. Do not weaken coverage to make it pass.

DefinitionPointCeil/GapDefinitionPointCeil, inherited editorial, independent gap allocation and per-repeat inventory are proposed reachable observations from checked source paths, not executed claims. Synthetic private Empty support stays excluded. The checked WrapRepeat fragment has no binding and is deliberately excluded as a retained Some witness.

All captures must occur before the retained fade production algorithm changes. This candidate changes only cfgtest declaration visibility and adds a cfgtest child; it introduces no product hook, fee, allocation or canonical operation.
