from pathlib import Path
import hashlib,difflib,json
base=Path('/tmp/deadpan-retained-fade-query-admission-2026-10-30/supplement-candidate')
roots={'main':Path('/Users/michael/Code/deadpan'),'scoped':Path('/tmp/deadpan-query-groundwork-2026-10-26/scoped')}
paths=['crates/deadpan-plan/src/audio_owners/retained_fade_baseline.rs','crates/deadpan-plan/src/audio_owners/legacy_snapshot_v1/fade_query_cases.rs']
sources=paths+[
'crates/deadpan-plan/src/audio_owners/retained_fade_cases.rs',
'crates/deadpan-plan/src/audio_owners/legacy_snapshot_v1/fade_query_baseline.rs',
'crates/deadpan-plan/src/audio_owners/legacy_snapshot_v1/wide_baseline.rs',
'crates/deadpan-plan/src/audio_owners/legacy_snapshot_v1.rs',
'crates/deadpan-plan/src/audio_owners/wide_gain_query_admission_tests.rs',
'crates/deadpan-plan/tests/gap_bindings.rs',
'crates/deadpan-plan/src/audio_capture.rs',
'crates/deadpan-plan/src/audio_owner_input.rs',
'crates/deadpan-plan/src/audio_owner_probe.rs',
'crates/deadpan-plan/tests/fixtures/retained-fade-query-baseline-v1/snapshot.json',
]
sha=lambda b:hashlib.sha256(b).hexdigest()
m={'status':'prepare-only; no actual source/build/test/capture','variants':{}}
for variant,root in roots.items():
    pins={p:{'sha256':sha((root/p).read_bytes()),'bytes':(root/p).stat().st_size} for p in sources if (root/p).exists()}
    patch=[]
    for p in paths:
        old=(root/p).read_text()
        b=base/'before'/variant/p;b.parent.mkdir(parents=True,exist_ok=True);b.write_text(old)
        if p.endswith('retained_fade_baseline.rs'):
            assert 'mod supplement;' not in old
            new=old+'\n#[path = "retained_fade_supplement.rs"]\npub(in crate::plan) mod supplement;\n'
        else:
            a="pub(super) fn visit_cases(mut visit: impl FnMut(Parent<'_, '_>, &Value)) {"
            assert old.count(a)==1
            new=old.replace(a,a.replace('pub(super)','pub(in crate::plan)'),1)
            assert new.replace(a.replace('pub(super)','pub(in crate::plan)'),a)==old
        a=base/'after'/variant/p;a.parent.mkdir(parents=True,exist_ok=True);a.write_text(new)
        patch.extend(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile='a/'+p,tofile='b/'+p))
        pins[p]['suggested_after_sha256']=sha(new.encode())
    file=base/f'declarations-{variant}.patch';file.write_text(''.join(patch))
    m['variants'][variant]={'source_pins':pins,'declaration_patch_sha256':sha(file.read_bytes())}
p='crates/deadpan-plan/src/audio_owners/retained_fade_supplement.rs'
text=(base/p).read_text()
patch=''.join(difflib.unified_diff([],text.splitlines(True),fromfile='/dev/null',tofile='b/'+p))
(base/'new-file.patch').write_text(patch)
m['new_source']={'path':p,'bytes':len(text.encode()),'sha256':sha(text.encode())}
m['new_file_patch_sha256']=sha(patch.encode())
(base/'pins.json').write_text(json.dumps(m,indent=2)+'\n')
print(json.dumps({'new_source':m['new_source'],'new_file_patch_sha256':m['new_file_patch_sha256'],'declarations':{v:d['declaration_patch_sha256'] for v,d in m['variants'].items()}},indent=2))
