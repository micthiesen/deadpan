from pathlib import Path
import hashlib,json,os,subprocess,sys
s=Path(__file__).resolve().parent
v=sys.argv[1];assert v in ['main','scoped']
root=Path('/Users/michael/Code/deadpan')if v=='main'else Path('/tmp/deadpan-query-groundwork-2026-10-26/scoped')
build=f'retained-coincident-{v}-build8';label=f'coincident-ordinary-{v}'
r=json.loads((s/(build+'.json')).read_text());assert r['cwd']==str(root)and r['exit_code']==0 and r['sources_unchanged']
pin=json.loads((s/(build+'-pins.json')).read_text())[0]
assert pin['package']=='plan'and pin['artifact']['profile']['opt_level']=='0'
assert hashlib.sha256(Path(pin['path']).read_bytes()).hexdigest()==pin['sha256']
manifest={}
for absolute,value in r['source_after'].items():
 p=Path(absolute);b=p.read_bytes();actual={'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
 assert actual==value,absolute;manifest[str(p.relative_to(root))]=actual
b=(json.dumps(manifest,sort_keys=True,separators=(',',':'))+'\n').encode();source_sha=hashlib.sha256(b).hexdigest()
manifest_path=s/(label+'-source-manifest.json');assert not manifest_path.exists();manifest_path.write_bytes(b)
c=s/'retained-coincident-diagnostic-candidate'
algorithm=json.loads((c/'ordinary-algorithm-pins.json').read_text())
method=(c/'published-retained-fades-method.rs').read_bytes()
assert hashlib.sha256(method).hexdigest()==algorithm['ordinary_method_sha256']
assert (root/'crates/deadpan-plan/src/audio_owner_input.rs').read_bytes().count(method)==1
assert (c/'published-audio_owner_input.rs').read_bytes().count(method)==1
fades=(root/'crates/deadpan-plan/src/audio_fades.rs').read_bytes()
assert fades==(c/'published-audio_fades.rs').read_bytes()
assert hashlib.sha256(fades).hexdigest()==algorithm['published_audio_fades_sha256']
ordinary_sha=hashlib.sha256((c/'ordinary-algorithm-pins.json').read_bytes()).hexdigest()
listed=(s/(build+'-list.stdout')).read_text()
names=[l.removesuffix(': test')for l in listed.splitlines()if l.endswith('overlap_tests::diagnostic::capture_current_literal_ordinary_retained_coincidence_v1: test')]
assert len(names)==1,names
out=s/(label+'-body.json');assert not out.exists()
tag='main-inherited'if v=='main'else'scoped-published'
checkpoint=(s/'published-fade-checkpoint.txt').read_text().strip();assert checkpoint==algorithm['published_checkpoint']
publication=json.loads((s/'fade-publication-receipt.json').read_text());assert publication['remote_verified']and publication['commit']==checkpoint
env=os.environ.copy();env.update({'DEADPAN_RETAINED_COINCIDENT_OUTPUT':str(out),'DEADPAN_RETAINED_COINCIDENT_VARIANT':tag,'DEADPAN_RETAINED_COINCIDENT_SOURCE_SHA256':source_sha,'DEADPAN_RETAINED_COINCIDENT_ORDINARY_SOURCE_SHA256':ordinary_sha,'DEADPAN_RETAINED_COINCIDENT_PUBLISHED_CHECKPOINT':checkpoint})
subprocess.run(['python3',str(s/'run_logic_target.py'),build,v,'plan','deadpan_plan',label,'--ignored','--exact',names[0],'--nocapture','--test-threads=1'],env=env,check=True)
run=json.loads((s/(label+'.json')).read_text());assert run['exit_code']==0 and run['sources_unchanged']and run['binaries_unchanged']
for key,value in env.items():
 if key.startswith('DEADPAN_RETAINED_COINCIDENT_'):assert run['environment'][key]==value
body=json.loads(out.read_text())
assert body['variant']==tag and body['source_sha256']==source_sha and body['ordinary_source_sha256']==ordinary_sha and body['published_checkpoint']==checkpoint
for absolute,value in run['source_after'].items():assert manifest[str(Path(absolute).relative_to(root))]==value
proof={'variant':v,'build_receipt':build+'.json','run_receipt':label+'.json','source_inputs':len(manifest),'source_manifest_sha256':source_sha,'binary_sha256':pin['sha256'],'body_bytes':out.stat().st_size,'body_sha256':hashlib.sha256(out.read_bytes()).hexdigest(),'ordinary_algorithm_pin_manifest_sha256':ordinary_sha,'ordinary_method_and_entire_fades_file_match_published':True,'current_tree_post_implementation_capture':True,'not_preimplementation_tree':True,'source_and_binary_guards':True}
(s/(label+'-capture-proof.json')).write_text(json.dumps(proof,indent=2)+'\n')
print(json.dumps(proof))
