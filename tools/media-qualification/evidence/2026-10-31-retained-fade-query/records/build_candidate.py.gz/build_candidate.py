from pathlib import Path
import subprocess,sys
s=Path(__file__).resolve().parent;v=sys.argv[1];assert v in ['main','scoped']
for package,version,runner in [('plan','5','run_main_logic.py'if v=='main'else'run_scoped_logic.py'),('audio','3','run_qualified.py'if v=='main'else'run_scoped_qualified.py')]:
 label=f'retained-admission-{v}-{package}-build{version}'
 subprocess.run(['python3',str(s/runner),label,'--','cargo','test','-p',f'deadpan-{package}','--lib','--no-run','--message-format=json'],check=True)
 subprocess.run(['python3',str(s/'pin.py'),label],check=True)
 target='deadpan_'+package
 target_runner='run_logic_target.py'if package=='plan'else'run_target.py'
 subprocess.run(['python3',str(s/target_runner),label,v,package,target,label+'-list','--list'],check=True)
