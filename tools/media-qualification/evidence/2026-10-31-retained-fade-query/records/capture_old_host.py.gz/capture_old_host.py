from pathlib import Path
import hashlib,json,os,subprocess,sys
s=Path(__file__).resolve().parent
variant=sys.argv[1];assert variant in['main','scoped']
root=Path('/Users/michael/Code/deadpan')if variant=='main'else Path('/tmp/deadpan-query-groundwork-2026-10-26/scoped')
build='retained-host-old-'+variant+'-build3';receipt=json.loads((s/(build+'.json')).read_text())
assert receipt['cwd']==str(root)and receipt['exit_code']==0 and receipt['sources_unchanged']
pins=json.loads((s/(build+'-pins.json')).read_text());assert len(pins)==1
binary=Path(pins[0]['path']);assert hashlib.sha256(binary.read_bytes()).hexdigest()==pins[0]['sha256']
manifest={}
for absolute,pin in receipt['source_after'].items():
 p=Path(absolute);name=str(p.relative_to(root));data=p.read_bytes()
 actual={'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}
 assert actual==pin,name
 manifest[name]=actual
manifest_bytes=(json.dumps(manifest,sort_keys=True,separators=(',',':'))+'\n').encode()
manifest_sha=hashlib.sha256(manifest_bytes).hexdigest()
manifest_path=s/('retained-host-old-'+variant+'-source-manifest.json');assert not manifest_path.exists();manifest_path.write_bytes(manifest_bytes)
listed=s/('retained-host-old-'+variant+'-list3.stdout')
names=[line.removesuffix(': test')for line in listed.read_text().splitlines()if line.endswith('retained_host_baseline::capture_old_retained_host_read_baseline_v1: test')]
assert len(names)==1,names
checkpoint=(s/'published-fade-checkpoint.txt').read_text().strip()
publication=json.loads((s/'fade-publication-receipt.json').read_text());assert publication['remote_verified']and publication['commit']==checkpoint
tag='main-inherited'if variant=='main'else'scoped-published'
label='retained-host-old-'+variant;output=s/(label+'-body.json');assert not output.exists()
env=os.environ.copy();env.update({'DEADPAN_RETAINED_HOST_OUTPUT':str(output),'DEADPAN_RETAINED_HOST_VARIANT':tag,'DEADPAN_RETAINED_HOST_SOURCE_SHA256':manifest_sha,'DEADPAN_RETAINED_HOST_PUBLISHED_CHECKPOINT':checkpoint})
code=subprocess.run(['python3',str(s/'run_target.py'),build,variant,'audio','deadpan_audio',label,'--ignored','--exact',names[0],'--nocapture','--test-threads=1'],env=env).returncode
if code:raise SystemExit(code)
run=json.loads((s/(label+'.json')).read_text());assert run['exit_code']==0 and run['sources_unchanged']and run['binaries_unchanged']
assert 'test result: ok. 1 passed;'in(s/(label+'.stdout')).read_text()
for key,value in env.items():
 if key.startswith('DEADPAN_RETAINED_HOST_'):assert run['environment'][key]==value,key
body=json.loads(output.read_text())
assert body['variant']==tag and body['source_sha256']==manifest_sha and body['published_fade_checkpoint']==checkpoint
for absolute,pin in run['source_after'].items():assert manifest[str(Path(absolute).relative_to(root))]==pin
proof={'variant':variant,'root':str(root),'build_receipt':build+'.json','run_receipt':label+'.json','source_inputs':len(manifest),'source_manifest_sha256':manifest_sha,'binary_sha256':pins[0]['sha256'],'body_bytes':output.stat().st_size,'body_sha256':hashlib.sha256(output.read_bytes()).hexdigest(),'published_fade_checkpoint':checkpoint,'exact_named_test':names[0],'complete_source_and_binary_guards':True,'emitted_provenance_matches_wrapper':True}
(s/(label+'-capture-proof.json')).write_text(json.dumps(proof,indent=2)+'\n')
print(json.dumps(proof))
