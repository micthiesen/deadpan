# Current-tree ordinary coincidence capture audit

## Findings

None in the assigned lens.

## Evidence checked

- Independently normalized the complete Main and Scope bodies by removing only the two declared provenance fields, variant and source_sha256. The remaining objects compare equal. The published equality record gives canonical SHA-256 e5702798bd4ccfe98b54637d0b9dffb102d4c3c22b36b4fe7214068112b399a8.
- Both capture proofs bind successful build and run receipts, complete source manifests, binary hashes, output body hashes, and matching method/file pins. The wrapper verifies every listed source before/after, binary bytes, env values, fresh output path, exact diagnostic test selection, and emitted provenance. It checks the exact ordinary retained-fades method bytes against the published copy and hash, checks the whole audio_fades.rs file against the published copy and hash, and pins the published checkpoint/remote verification receipt.
- The capture explicitly identifies itself as current-tree, post-implementation, with preimplementation_tree_claim false. This matches the wrapper and test: it runs against the current Main and Scope sources while pinning the unchanged ordinary algorithm, so it does not represent a historical preimplementation binary.
- The test’s capture asserts ENABLED is false and calls ordinary_case without the trace wrapper. The diagnostic path itself uses a separate ignored/regular diagnostic test that wraps ordinary_case with tracing. The ordinary capture therefore does not turn on overlap instrumentation.
- ordinary_case loads the unchanged frozen captured_marked_repeat_fragment, applies a real Split(loop, 4), then marks the resulting coinc-right Partition end. The diagnostic assertion requires all four real handle origins to be Some and a real OriginMergeReady event with old_len and new_len both positive.
- Both emitted bodies contain four Some handles and 284 observation calls, with 180 Ok and 104 Error results. The observed calls include ordinary probe, unmetered admitted probe, metered admitted probe, and admitted selected/shared origins. The source pins and body equality preserve the complete results, including errors and query payloads.

## Limits

This is an ordinary-path characterization on the post-implementation tree, not evidence of a preimplementation run or of metered production admission. I did not run builds/tests/captures.
