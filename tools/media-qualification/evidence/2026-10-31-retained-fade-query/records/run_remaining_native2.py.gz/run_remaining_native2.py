from pathlib import Path
import subprocess,json,hashlib
s=Path(__file__).resolve().parent
reused=[]
for v in ['scoped','main']:
 build=f'retained-all2-{v}-audio-build'
 pins=json.loads((s/(build+'-pins.json')).read_text())
 for pin in sorted(pins,key=lambda p:p['name']):
  if pin['name']=='deadpan_audio':continue
  if pin.get('reused_identical_pinned_executable'):
   label=f"retained-final-{v}-audio-"+pin['name'].replace('_','-')
   record=json.loads((s/(label+'.json')).read_text())
   assert record['exit_code']==0 and record['sources_unchanged'] and record['binaries_unchanged']
   digest=hashlib.sha256(Path(pin['path']).read_bytes()).hexdigest()
   assert any(x['sha256']==digest for x in record['binary_before'].values())
   reused.append({'variant':v,'name':pin['name'],'sha256':digest,'receipt':label+'.json','prior_build':pin['prior_build']})
   continue
  label=f"retained-final2-{v}-audio-"+pin['name'].replace('_','-')
  subprocess.run(['python3',str(s/'run_target.py'),build,v,'audio',pin['name'],label,'--test-threads=1'],check=True)
(s/'native-final2-reused-identical.json').write_text(json.dumps(reused,indent=2)+'\n')
