from pathlib import Path
import json,hashlib
s=Path(__file__).resolve().parent
roots={'main':Path('/Users/michael/Code/deadpan'),'scoped':Path('/tmp/deadpan-query-groundwork-2026-10-26/scoped')}
rows=[]
for v,root in roots.items():
 b=json.loads((s/f'retained-all-{v}-plan-build.json').read_text())
 assert b['exit_code']==0 and b['sources_unchanged']and b['binaries_unchanged']
 pins=b['source_after']
 selected={p:pin for p,pin in pins.items()if any(x in Path(p).parts for x in ['deadpan-plan','deadpan-core'])}
 for p,pin in selected.items():
  data=Path(p).read_bytes();assert len(data)==pin['bytes']and hashlib.sha256(data).hexdigest()==pin['sha256'],p
 rows.append({'variant':v,'build_receipt':f'retained-all-{v}-plan-build.json','current_plan_core_inputs_unchanged':len(selected),'audio_only_test_instrumentation_after_plan_build':True})
(s/'final-plan-core-source-identity.json').write_text(json.dumps(rows,indent=2)+'\n')
print(rows)
