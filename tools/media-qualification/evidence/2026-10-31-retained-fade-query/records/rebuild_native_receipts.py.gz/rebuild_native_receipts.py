from pathlib import Path
import json,subprocess,hashlib,shutil,sys
s=Path(__file__).resolve().parent;v=sys.argv[1];assert v in ['main','scoped']
runner='run_qualified.py'if v=='main'else'run_scoped_qualified.py'
if v=='main':
 subprocess.run(['python3',str(s/runner),'retained-strict-main-receipts','--','cargo','xtask','check','--no-test'],check=True)
else:
 subprocess.run(['python3',str(s/runner),'retained-strict-scoped-receipts','--','cargo','clippy','-p','deadpan-plan','-p','deadpan-audio','--all-targets','--locked','--','-D','warnings'],check=True)
label=f'retained-all2-{v}-audio-build'
subprocess.run(['python3',str(s/runner),label,'--','cargo','test','-p','deadpan-audio','--no-run','--message-format=json'],check=True)
receipt=json.loads((s/(label+'.json')).read_text());assert receipt['exit_code']==0 and receipt['sources_unchanged']
old={r['name']:r for r in json.loads((s/f'retained-all-{v}-audio-build-pins.json').read_text())}
pins=[]
for line in(s/(label+'.stdout')).read_text().splitlines():
 try:a=json.loads(line)
 except ValueError:continue
 if a.get('reason')!='compiler-artifact'or not a.get('executable')or not a.get('profile',{}).get('test')or 'deadpan-audio#'not in a.get('package_id',''):continue
 name=a['target']['name'];b=Path(a['executable']).read_bytes();sha=hashlib.sha256(b).hexdigest()
 assert a['profile']['opt_level']=='2'and a['profile']['debug_assertions']and a['profile']['overflow_checks']
 prior=old[name]
 reused=sha==prior['sha256']
 if reused:
  dest=Path(prior['path']);assert hashlib.sha256(dest.read_bytes()).hexdigest()==sha
 else:
  dest=s/(label+'-audio-'+name.replace('_','-'));assert not dest.exists();shutil.copyfile(a['executable'],dest);shutil.copymode(a['executable'],dest)
 pins.append({'package':'audio','name':name,'path':str(dest),'sha256':sha,'bytes':len(b),'artifact':a,'reused_identical_pinned_executable':reused,'prior_build':f'retained-all-{v}-audio-build'})
assert len(pins)==21
(s/(label+'-pins.json')).write_text(json.dumps(pins,indent=2)+'\n')
print(json.dumps({'build':label,'reused':sum(p['reused_identical_pinned_executable']for p in pins),'changed':[p['name']for p in pins if not p['reused_identical_pinned_executable']]}))
