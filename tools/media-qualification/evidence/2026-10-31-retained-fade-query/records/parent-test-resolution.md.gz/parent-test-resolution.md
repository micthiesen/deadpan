# Retained admission test adjudication

The first supplemental external regression wrapper looked for the wrong module
suffix and launched no test. The corrected exact listed name passed on both
pinned binaries. The original orchestration output remains preserved.

The initial freeze script assumed every older oracle pin had a byte-count field.
The 17 older records carry hashes without byte counts. The script stopped after
writing the two exact new fixture directories, before changing the oracle list.
The corrected retry verified those existing bytes and every older hash, then
appended the supplement pin. It did not overwrite or regenerate any witness.

The first stronger callback audit expected InvalidPlan on issuer rotation.
The production boundary returns the dedicated AudioMetadataIssuerMismatch.
Both independent Layout/rotation tests passed; the callback-prefix assertion was
corrected to that exact typed error. Both exact failed-test retries then passed.
No production code changed for this test correction.

The initial admitted Audio library runs each failed exactly two authored tile
work comparisons. Four new retained native tests and the frozen twentieth
legacy witness passed. The older comparison observes the four Root query
receipts but omits new retained fade/owner receipts. An additive test-only
receipt reconciliation is being reviewed; no old body, canonical weight,
runtime cap or production algorithm has been changed to satisfy this comparison.

The first full744 audit tried to attribute each changed read's entire accepted
work to input.work plus its retained constructors. Row17 disproved that:
18 input +178 completed fade versus276 total, before any source callback.
Existing downstream Original/domain queries also accept work before their own
budget refusal. The capture now records the existing four-product Original
trace as a separate object; the initial complete captures remain immutable.
No production path or existing four-slot trace shape changed.

The extended full744 audit initially assumed all changed-budget rows stopped
before source access. Twelve actually reach the same OLD provider events,
then fail later: eight plan-work limits and four recursive-policy work limits.
Accepted downstream work of539/1614/1674 units lies outside the constructor
receipts and remains separately recorded. The final auditor does not invent
fees to cover it. Independent review found two assertion gaps:40 unchanged
cache-scope faults and70 changed-budget cleanup states. Dedicated assertions
now cover both. All744 pass actual receipt/context cleanup checks,584 normal
pairs pass full non-budget state comparisons, and40 cache-scope faults pass
separate before/after/event assertions. Earlier weaker auditors stay archived.

The main ordinary stage runner excludes the inherited general_split_sound
research module explicitly, as the prior checkpoint did. The dispatcher was
corrected before that native target launched; actual command receipts retain
the filter. A separate fresh seven-case research audit is still required.

The final audit's first native-run classifier searched for "-audio-" in a
binary path and accidentally selected pure Plan audio-* integration targets.
Their normal optimization-zero receipts correctly omit the native profile
variable. The corrected classifier uses the build pin manifest's explicit
package="audio" membership. All91 actual native invocations are optimized and
serial; Plan's optimization-zero results remain independently qualified.
The first failed audit source is preserved. Final audit passes without a
production or test change.
