from pathlib import Path
import hashlib,json,subprocess
s=Path(__file__).resolve().parent
roots={'main':Path('/Users/michael/Code/deadpan'),'scoped':Path('/tmp/deadpan-query-groundwork-2026-10-26/scoped')}
owned=json.loads((s/'owned-paths.json').read_text())
sha=lambda b:hashlib.sha256(b).hexdigest()
entries={}
for line in (s/'index-source-entries.txt').read_text().splitlines():
 meta,path=line.split('\t',1);mode,oid,stage=meta.split()
 assert stage=='0'
 entries[path]=(mode,oid)
rows=[]
for name in owned:
 mode,oid=entries[name]
 data=subprocess.check_output(['git','cat-file','blob',oid],cwd=roots['main'])
 assert mode=='100644'and data==(roots['scoped']/name).read_bytes(),name
 rows.append({'path':name,'mode':mode,'git_blob':oid,'bytes':len(data),'sha256':sha(data),'scoped_index_equal':True,'main_equal':data==(roots['main']/name).read_bytes()})
assert [r['path']for r in rows if not r['main_equal']]==['crates/deadpan-audio/src/shared_eq/original_inputs_tests.rs']
(s/'index-source-equality.json').write_text(json.dumps(rows,indent=2)+'\n')
preserved={}
for v,root in roots.items():
 initial=json.loads((s/(v+'-initial-authority.json')).read_text())
 others={p:pin for p,pin in initial.items()if p not in owned}
 for p,pin in others.items():
  data=(root/p).read_bytes();assert sha(data)==pin['sha256']and len(data)==pin['bytes'],(v,p)
 preserved[v]=len(others)
assert preserved=={'main':2792,'scoped':2464}
pins=json.loads((s/'immutable-oracle-pins.json').read_text());assert len(pins)==21
for p in pins:
 for root in roots.values():assert sha((root/p['path']).read_bytes())==p['sha256']
for v,root in roots.items():
 saved=json.loads((s/(v+'-final-source-pins.json')).read_text())
 for p,pin in saved.items():
  data=(root/p).read_bytes();assert sha(data)==pin['sha256']and len(data)==pin['bytes'],(v,p)
(s/'preserved-source-and-oracle-final-audit.json').write_text(json.dumps({'preserved_unowned':preserved,'immutable_oracles':21,'owned_paths':45,'index_scoped_equal':45,'index_main_equal':44},indent=2)+'\n')
print('45 scoped index blobs verified; 21 immutable oracles exact; 2792/2464 unowned inputs preserved')
