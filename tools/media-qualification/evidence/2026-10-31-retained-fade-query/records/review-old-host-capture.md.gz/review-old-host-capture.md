# OLD retained-host capture review

## Findings

None. The Main and Scope captures have matching full bodies after removing only the three expected provenance fields; the capture provenance and per-operation resource records are consistent.

## Evidence

- Independently parsed both 93 MB capture bodies, removed only variant, source_sha256 and published_fade_checkpoint, and compared the complete resulting JSON values. The saved canonical body reproduces at 25,746,494 bytes and SHA-256 838a7165fe4fd9142450568158359b00b05d6cd867aceaef77bfbd49e2c52f75.
- Both roots captured the exact ignored host test with one pass. Build and run receipts have the expected Main/Scope cwd, success status and unchanged source/binary pins. The copied executable hashes also match the compiler artifact files. Source manifests contain 2,815 Main and 2,487 Scope inputs; both include and match the two fixture WAV digests emitted in the body. The emitted source-manifest digest and published checkpoint match each run environment and capture proof. The checkpoint is the remotely verified published fade commit.
- The five fixture records refer to checked host-source cases and contain full current/reference documents, the selected owner and its observation, windows, and WAV identity. They contain 744 operations in total across the four modes and two authored states; all 744 setups yielded Some. Each mode contributes 186 operations, split evenly between authored false and true. The observed owner origin is Retained in each operation; the retained raw-domain data records the Root or Point form.
- The full-body counts reproduce 306 successful reads and 438 read errors. There are 1,046 provider calls and 1,046 recorded provider events: 966 PreparedSource, 40 SourceUnavailable and 40 Cancelled. For each operation, event count equals provider_calls. Events include request project/revision/asset, cancellation state, a complete work snapshot before the provider result, provider outcome and prepared-source provenance/index/layout.
- The work snapshot covers every current ReadWork field, including projected/active/preflight inventories and capacities, cache scope/work, source/preparation counters, resident/context frames and projected disk bytes. StageAudio snapshots include active/cache totals, retained keys/blocks and original-input tracking. Projection keys use their full Debug payload plus within-snapshot equality relations, without pointer-address claims. Sound-context frame accounting is zero after handle drop and after renderer drop for all 744 operations. The selected-sharing helper reports the same request issuer for all 186 operations.
- Fixture preparation reads the pinned repository WAV bytes, hashes them into SourceContentIdentity, opens them through AudioSession::open_verified, and constructs PreparedSource with the declared channel layout. The emitted per-WAV SHA and byte length match the source manifest in both variants.

## Limits

This verifies the actual OLD host capture and its cross-root equality; it does not validate the later admission implementation. The host body explicitly leaves private processing/editorial/Bound detail to the separate Plan witness, so those private fields are not repeated in this host capture. No separate external host-read regression against a third expected body was present or run as part of this audit.
