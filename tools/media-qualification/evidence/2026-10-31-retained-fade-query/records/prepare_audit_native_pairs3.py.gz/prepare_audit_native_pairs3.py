from pathlib import Path
s=Path(__file__).resolve().parent
text=(s/'audit_native_pairs2.py').read_text()
text=text.replace("stable=0;changes=[]","stable=0;changes=[];early=0;late=0")
a=text.index("   assert value['read']['output']['status']=='Error' and value['provider_calls']==0")
b=text.index("  if fault not in",a)
text=text[:a]+'''   assert value['read']['output']['status']=='Error'
   expected=value['read']['output']['error']['debug']
   reached=value['provider_calls']>0
   if reached:
    assert fault=='injected_prior_plan_work'
    assert case['fixture']in ['root-reference-treatments-and-masks','root-ntsc-enclosing-and-silence']
    assert value['provider_calls']==prior['provider_calls']in [1,13]
    assert expected in ['Limit("plan work per read")','Plan(AudioQueryLimit("recursive policy work"))']
    for event,former in zip(value['provider_events'],prior['provider_events']):
     same_fields(event,former,{'work_before_provider_result'})
     same_fields(event['work_before_provider_result'],former['work_before_provider_result'],{'plan_work','cache_plan_work','sound_context_frames'})
     assert event['work_before_provider_result']['sound_context_frames']>former['work_before_provider_result']['sound_context_frames']
    late+=1
   else:
    assert expected==('Plan(AudioQueryLimit("structural work"))'if fault=='injected_prior_plan_work'else'Limit("resident PCM or stage cache")')
    early+=1
   lane_records=[]
   for lane,counter in [('plan','plan_work'),('cache','cache_plan_work')]:
    delta=value['read']['after_return_drop'][counter]-value['read']['before'][counter]
    input_work=value['retained']['retained_work']if lane=='plan'else 0
    traced=input_work+units(receipt,lane,'accepted_work')+original_units(receipt,lane)
    remainder=delta-traced
    if reached and lane=='plan':
     expected_remainder=539 if case['fixture']=='root-reference-treatments-and-masks'else(1614 if row['authored']else 1674)
     assert remainder==expected_remainder,(case['fixture'],i,remainder,expected_remainder)
    else:assert remainder==0,(case['fixture'],i,lane,delta,traced)
    assert units(receipt,lane,'host_eviction_work')==0
    lane_records.append({'lane':lane,'accepted_read_work':delta,'input_work':input_work,'retained_accepted_work':units(receipt,lane,'accepted_work'),'original_accepted_work':original_units(receipt,lane),'accepted_work_outside_captured_constructor_receipts':remainder})
   faults[(kind,fault)]+=1
   changes.append({'fixture':case['fixture'],'operation_index':i,'mode':row['mode'],'authored':row['authored'],'fault':fault,'classification':kind,'new_error':expected,'provider_calls':value['provider_calls'],'same_provider_events_except_work_and_metadata_residency':reached,'work':lane_records})
''' + text[b:]
text=text.replace("'all_changed_reads_stop_before_source_io':True,'accepted_failed_work_exactly_input_plus_retained_and_original_receipts':True", "'changed_reads_before_source':early,'changed_reads_after_same_source_events':late,'early_failed_work_exactly_input_plus_retained_and_original_receipts':True,'late_work_outside_captured_constructor_receipts':'539/1614/1674 accepted legacy downstream units retained separately; these receipts do not establish whole-read allocation/work admission'")
text=text.replace("(s/'native-pairs2-full-audit.json')","(s/'native-pairs3-full-audit.json')")
text=text.replace("out={'canonical_bytes'","assert early==58 and late==12\nout={'canonical_bytes'")
(s/'audit_native_pairs3.py').write_text(text)
