from pathlib import Path
import json,hashlib
s=Path(__file__).resolve().parent
data=(s/'coincident-ordinary-canonical-body.json').read_bytes();sha='e5702798bd4ccfe98b54637d0b9dffb102d4c3c22b36b4fe7214068112b399a8'
assert len(data)==501603 and hashlib.sha256(data).hexdigest()==sha
assert(s/'review-coincident-ordinary-capture.md').exists()
roots={'main':Path('/Users/michael/Code/deadpan'),'scoped':Path('/tmp/deadpan-query-groundwork-2026-10-26/scoped')}
rel='crates/deadpan-plan/tests/fixtures/retained-fade-coincident-v1'
readme='''# Immutable unchanged-ordinary coincident-edge witness

This is a CURRENT-TREE, POST-IMPLEMENTATION ordinary-algorithm capture.
It is not a pre-implementation build. The exact ordinary retained fades method
and entire ordinary audio_fades.rs match published checkpoint
ee9742711868fde9a78bcb945adfd36e67f504d6 byte for byte; their pin manifest is
retained in the unit evidence. Admission observers were disabled during capture.

Independently captured Main and isolated published-copy bodies agree completely
after removing only variant and source_sha256. The remaining provenance,
including ordinary-algorithm pin-manifest identity, is literal. Both exact external
case regressions and independent capture audit pass. The earlier twenty oracles
remain unchanged.

The fixture starts from the frozen marked-repeat document, performs a checked
Split(loop,4) and marks the resulting right Partition through SetEditorialEdges.
It records full before/request/intermediate/request/after documents, the actual
selected voice and four actual retained-handle construction origins. All four
are Some. Their 284 ordinary fade calls yield 180 Ok and104 typed errors.

Separate metered resource diagnostics on the same handles reach36 actual
OriginMergeReady events with old/new origin lengths both4, while independently
summed copied processing/editorial payload and old/new origin array layouts are
live. That metered result is separate from this ordinary body.

Do not regenerate this body from a changed algorithm to make a test pass.
'''
pins=json.loads((s/'immutable-oracle-pins.json').read_text());assert len(pins)==20
for v,root in roots.items():
 r=json.loads((s/f'coincident-ordinary-{v}-external-regression.json').read_text())
 assert r['exit_code']==0 and r['sources_unchanged']and r['binaries_unchanged']
 for pin in pins:assert hashlib.sha256((root/pin['path']).read_bytes()).hexdigest()==pin['sha256']
 target=root/rel;assert not target.exists();target.mkdir(parents=True)
 (target/'snapshot.json').write_bytes(data);(target/'snapshot.sha256').write_text(sha+'  snapshot.json\n');(target/'README.md').write_text(readme)
pins.append({'path':rel+'/snapshot.json','bytes':len(data),'sha256':sha})
(s/'immutable-oracle-pins.json').write_text(json.dumps(pins,indent=2)+'\n')
new=[rel+'/'+n for n in ['snapshot.json','snapshot.sha256','README.md']]
source='crates/deadpan-plan/src/audio_owners/retained_fade_coincident_diagnostic.rs'
for name in ['source-files.json','main-logic-source-files.json','scoped-source-files.json','scoped-logic-source-files.json','owned-paths.json','owned-baseline-paths.json']:
 p=s/name;v=json.loads(p.read_text());p.write_text(json.dumps(sorted(set(v)|set(new)|{source}),indent=2)+'\n')
print({'immutable_oracles':21,'bytes':len(data),'sha256':sha})
