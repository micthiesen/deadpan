# Retained fade Plan admission candidate

Scratch-only initial candidate. No actual repo edits, Cargo/rustc/native execution, captures, expected-body changes or Git operations were performed. The parent owns integration, compilation, testing and host integration.

Apply only production-main.patch or production-scoped.patch, plus new-files.patch. The production patches currently match, but exact before/after trees retain both root authorities. pins.json records every before/after/new-file SHA-256. Baseline/supplement sources, fixture bodies and their declarations are excluded.

Initial frozen patch identities:

- production-main.patch / production-scoped.patch: af73186303b8677c6c632494b63835ac894ce7dba9ad4e9f9f099eebb52de902
- new-files.patch: 8cc5058e2680000c5dae492c56dbb28dec616f5a10eeb573734ca31f00472034

## Actual API and construction

AudioOwnerRetainedInput::fades_admitted<A:AudioSoundContextAdmission> returns the existing fixed-sample AdmittedAudioFadeQuery<A::Issuer,A::Lease>. Its implementation is the new within-Plan child audio_owner_input::retained_fades. The existing ordinary fades method is unchanged.

False mode invokes that literal ordinary constructor and existing false-only wrapper. It introduces no spend/reserve/merge callback and keeps additional=0 and forwarded=false. The private wrapper retains its runtime accounting-mode rejection for A::METERED=true.

True mode keeps the original limits-before-reversed-range validation, accepts unrestricted signed retained history, creates one fresh QueryBudget, preserves empty zero work and the exact retained fade span count/advance labels, and forwards the literal original per-span aggregate before copies:

1 + actual bound.work + processing retimes/repeats + editorial markers/constraints/repeats.

Each actual processing copy precedes the actual editorial copy. The copy preserves both nested resolved/lattice work scalars and all immutable finite fields. No Core resolution, raw-domain reconstruction, nominal clock inversion, Core guard detachment, new public provider, cap/weight/refund change or generic unmetered escape was added.

The shared Bound helper now has a clipped Root/Domain wrapper and an untrimmed retained wrapper over the same body. Root/Domain preserve their allocated-end clip. Retained passes the original requested end. The completed guard uses the existing SpanWork finish, collection::push overlap implementation, and the factored existing checked carrier seal.

## Files and narrow seams

New:
- audio_bound_fade_copy.rs, a private child of audio_bound::query, copies only this finite Plan Bound shape. Public Core ResolvedAudioBinding/Placement/Resume fields suffice. All four owning clock variants are explicit; no Core change.
- audio_retained_fades_query.rs, child of audio_owner_input, owns the copied processing/editorial states and actual loop.
- audio_retained_fades_query_trace.rs, cfgtest scalar synchronous phases only.

Existing:
- audio_bound_query.rs: declare private finite-copy child.
- audio_capture_storage.rs: widen only fixed/editorial/retime visibility from pub(super) to pub(in crate::plan); bodies unchanged.
- audio_fades_query.rs: expose the private false wrapper within Plan, share the existing checked seal, and split allocated clipping from the common Bound body.
- audio_owner_input.rs: declare within-Plan retained child; ordinary method unchanged.
- audio_sound_admission.rs: accurately update module scope documentation.

The existing public carrier/export needs no new public type or lib.rs export.

## Ownership and fees

Partial copied fields live in named Owned value-before-memory states. Definition, instance/repeat inventory, gaps, retimes, constraints, outer editorial and all independent NodeId/RevisionId Arc-backed edges use the existing budget helpers before cloning. The Bound copy explicitly destructures every finite field without '..'. Clock NodeIds, independent outer/lattice instance paths and gap identities are copied independently. Resume/range/grid/map/work fields copy literally.

The actual Box shell uses existing GuardedBound::boxed: pre-admit and allocate the Box<MaybeUninit<AudioBound>> while the copied value remains guarded, then write inside its infallible map and merge checked shell memory. Processing fields remain in a value-first pending state through the Box map and guard adoption. No owning output moves outside its guard during a fallible callback.

Three new finite owning-record copy inspections add one additional unit each: processing copy, Bound copy and editorial capture copy. Existing per-element, identity-copy and actual reservation helpers add their established additional units. All old canonical aggregate and nested helper weights remain unchanged. Successful carrier work is reconciled as canonical+additional==initial remaining-final remaining; failed accepted prefix callbacks are not refunded.

The common fade constructor retains actual envelope-domain, second geometry/captured-editorial, origin and edge buffers with the already reviewed guarded composition. All new merge/adopt/seal paths use centrally checked pre/post issuer methods. No direct new admission.merge callback was introduced.

The existing span.keep(primary) conservatively carries construction charge into the final carrier after the copied primary payload is discarded by the mapping. This is established logical requested-Layout accounting, not an RSS or distinct Arc allocation claim. New query allocation is independent of, and never detaches, the caller's original retained/probe/shared guard.

## Test hooks and separate tests

The scalar phases are ProcessingCopyBefore/After, BoundBoxBefore/After and EditorialCopyBefore/After. Their synchronous observer changes no production callbacks, work, allocation or geometry.

The separate tests/ subtree owns only new audio_owners/retained_fade_copy_tests.rs and wiring fragments for the parent. It reuses the original Policy/Lease framework via a retained_fade_baseline child. No production baseline/declaration edits were made here.

See tests/WIRING.md. The tests independently calculate complete finite-copy payload Layouts and exact Box deltas from actual immutable snapshots for all 50 Some handles, sweep every measured work/reservation/merge issuer rotation, retain old/current ledger states, and check cancellation before/after the actual original prepay. Parent owns the broader 3,764 false observations, 2,309 true successes and exact/refusal tests.

## Checks and unresolved integration work

Performed: rustfmt parsing of all new sources and changed fade source, formatting checks, normalized patch generation and dry runs against scratch exact before copies. No compiler/runtime claim.

Owed: parent compiler/borrow/lint validation, literal false/true frozen corpus tests, independent phase/Layout test execution, every refusal/rotation/cancellation result, host lifetime/WAV qualification, and full existing oracle regressions. Trace with_observer is intended to be used by the separate child test; integrating production without those tests may leave a cfgtest dead-code warning.

Host work is explicitly another owner's task. The new Plan carrier must stay live through creative validation, optional owner preparation, PCM make_room, read_bound_at and creative/gain application; the successful fade receipt must not be billed twice. Existing input.work and real host eviction costs remain separately witnessed. Wider raw-domain/signal/tape/mix/projected preparation remains open.

Initial candidate source/patch bytes are held stable after handoff. Parent compiler corrections are not silently folded back into these initial before/after pins.
