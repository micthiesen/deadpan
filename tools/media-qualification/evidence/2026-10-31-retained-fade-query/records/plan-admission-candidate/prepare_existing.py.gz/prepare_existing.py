from pathlib import Path
import textwrap
base=Path('/tmp/deadpan-retained-fade-query-admission-2026-10-30/plan-admission-candidate')
roots={'main':Path('/Users/michael/Code/deadpan'),'scoped':Path('/tmp/deadpan-query-groundwork-2026-10-26/scoped')}
paths=['crates/deadpan-plan/src/audio_owner_input.rs','crates/deadpan-plan/src/audio_bound_query.rs',
'crates/deadpan-plan/src/audio_fades_query.rs','crates/deadpan-plan/src/audio_capture_storage.rs','crates/deadpan-plan/src/audio_sound_admission.rs']
for variant,root in roots.items():
 for p in paths:
  old=(root/p).read_text()
  target=base/'before'/variant/p;target.parent.mkdir(parents=True,exist_ok=True);target.write_text(old)
  new=old
  if p.endswith('audio_owner_input.rs'):
   a='#[path = "audio_owner_input/candidates.rs"]'
   assert new.count(a)==1
   new=new.replace(a,'#[path = "audio_retained_fades_query.rs"]\npub(in crate::plan) mod retained_fades;\n\n'+a,1)
  elif p.endswith('audio_bound_query.rs'):
   a='use deadpan_core::{AdmittedAudioBinding, AudioBindingValue};'
   assert new.count(a)==1
   new=new.replace(a,a+'\n\n#[path = "audio_bound_fade_copy.rs"]\nmod fade_copy;',1)
  elif p.endswith('audio_capture_storage.rs'):
   for name in ['fixed','editorial','retime']:
    a='pub(super) fn '+name
    assert new.count(a)==1
    new=new.replace(a,'pub(in crate::plan) fn '+name,1)
  elif p.endswith('audio_sound_admission.rs'):
   a='//! Standalone retained-input fade construction remains separate.'
   assert new.count(a)==1
   new=new.replace(a,'//! Standalone retained creative fades share this admission; recursive signal and\n//! raw-domain preparation remain separate.',1)
  else:
   a='fn ordinary<A: AudioSoundContextAdmission>('
   assert new.count(a)==1
   new=new.replace(a,'pub(in crate::plan) '+a,1)
   start=new.index('        let canonical = budget.canonical_used;')
   end=new.index('\n    })())\n}',start)
   seal=new[start:end]
   new=new[:start]+'        finish_query(spans, limits.maximum_work, &mut budget)'+new[end:]
   seal=textwrap.dedent(seal).replace('limits.maximum_work','maximum_work').replace('spans.map(&mut budget,','spans.map(budget,')
   method='''pub(in crate::plan) fn finish_query<A: AudioSoundContextAdmission>(
    spans: collection::Collected<AudioFadeSpan, A>,
    maximum_work: usize,
    budget: &mut QueryBudget<'_, A>,
) -> QueryResult<AdmittedAudioFadeQuery<A::Issuer, A::Lease>, A> {
    budget.check()?;
'''+textwrap.indent(seal,'    ')+'\n}\n\n'
   anchor='struct Retained {'
   assert new.count(anchor)==1
   new=new.replace(anchor,method+anchor,1)
   anchor='fn bound_fade<A: AudioSoundContextAdmission>('
   assert new.count(anchor)==1
   new=new.replace(anchor,'fn bound_fade_untrimmed<A: AudioSoundContextAdmission>(',1)
   a='    let end = end.min(processing.allocated_samples.end);'
   assert new.count(a)==1
   new=new.replace(a,'',1)
   wrappers='''fn bound_fade<A: AudioSoundContextAdmission>(
    primary: Guard<AudioWalkSpan<'_>, A>,
    start: AudioSample,
    end: AudioSample,
    outer: Kept<EditorialCapture, A>,
    budget: &mut QueryBudget<'_, A>,
) -> QueryResult<SpanWork<A::Issuer, A::Lease>, A> {
    let AudioWalkSpan::Stage(processing) = &*primary else {
        return Err(PlanError::InvalidPlan("fade has no bound output").into());
    };
    let end = end.min(processing.allocated_samples.end);
    bound_fade_untrimmed(primary, start, end, outer, budget)
}

pub(in crate::plan) fn retained_bound_span_admitted<A: AudioSoundContextAdmission>(
    primary: Guard<AudioWalkSpan<'_>, A>,
    start: AudioSample,
    end: AudioSample,
    outer: Kept<EditorialCapture, A>,
    budget: &mut QueryBudget<'_, A>,
) -> QueryResult<Guard<AudioFadeSpan, A>, A> {
    bound_fade_untrimmed(primary, start, end, outer, budget)?.finish(budget)
}

'''
   new=new.replace('fn bound_fade_untrimmed<A: AudioSoundContextAdmission>(',wrappers+'fn bound_fade_untrimmed<A: AudioSoundContextAdmission>(',1)
  target=base/'after'/variant/p;target.parent.mkdir(parents=True,exist_ok=True);target.write_text(new)
