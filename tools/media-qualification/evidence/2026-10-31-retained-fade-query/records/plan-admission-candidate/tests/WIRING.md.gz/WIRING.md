# Parent-owned test wiring

New file: crates/deadpan-plan/src/audio_owners/retained_fade_copy_tests.rs.

Append only this child declaration to retained_fade_baseline.rs, alongside admission_tests:

    #[path = "retained_fade_copy_tests.rs"]
    mod copy_tests;

In retained_body, after complete observations are collected, alongside admission_tests::observe(input, retained, &observations), invoke:

    copy_tests::observe(input, retained, &observations);

The hook is test-only and Off except when these two tests call the actual unchanged matrices. It does not alter or append serialized observations or input values.

Intended filters, requiring parent --list confirmation:

plan::audio_owners::wide_gain_query_admission_tests::retained_fade_baseline::copy_tests::independent_copied_payload_and_box_layouts_at_actual_allocation_phases

plan::audio_owners::wide_gain_query_admission_tests::retained_fade_baseline::copy_tests::every_spend_reserve_merge_rotation_and_prepaid_cancellation_preserve_caller

The child reuses the existing Policy/PolicyState/Lease through super::* and introduces only a forwarding MergeRotation wrapper around that Policy. It does not implement a second ledger.

Layout assertions independently sum the copied immutable metadata's concrete Vec element layouts, finite per-edge Arc<str> header/text ownership layouts, and the actual Box<AudioBound> shell. The complete snapshots retain actual ordinary/admitted/shared provenance and work. Scalar production phase brackets prove:
- complete processing copy increases live bytes by the independently summed full copied payload and Box;
- BoxBefore/After isolates exactly Layout::new::<AudioBound>();
- complete editorial copy increases live bytes by its independent finite inventory sum.

These are requested-Layout/live-ledger assertions, not RSS or an assertion of distinct Arc allocation per shared identity. The identity computation matches the established logical owning-edge convention independently of production identity() calls.

The rotation test measures each actual delivery query's callback counts, then rotates at every accepted work, reservation and actual merge callback. It retains old Rc ledger state and checks both old/current states return to zero. It also cancels before first debit and immediately after the literal original per-span prepay, asserting accepted work is exactly 0 or the original aggregate and is never refunded.

All 50 actual borrowed Some handles from both frozen matrices are replayed while their original caller/probe/share guard remains alive. Snapshot equality before/after ensures the input and both nested work scalars stay literal. Existing parent matrix ledger assertions additionally verify caller cleanup.

No execution claimed. Only rustfmt parsing/checking was performed. Parent owns source hook integration, compile, runtime phase/cardinality/coverage checks and any resulting compiler/lint repairs.
