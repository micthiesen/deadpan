from pathlib import Path
import hashlib,json,difflib,subprocess
b=Path('/tmp/deadpan-retained-fade-query-admission-2026-10-30/plan-admission-candidate')
sha=lambda v:hashlib.sha256(v).hexdigest()
m={'status':'scratch-only initial production candidate; no compile/test/capture','variants':{},'new_files':{}}
for variant in ['main','scoped']:
 patches=[];pins={}
 for p in sorted((b/'before'/variant).rglob('*.rs')):
  rel=p.relative_to(b/'before'/variant);a=b/'after'/variant/rel
  subprocess.run(['rustfmt','--edition','2024','--config','skip_children=true',str(a)],check=True)
  before=p.read_text();after=a.read_text()
  pins[str(rel)]={'before_sha256':sha(before.encode()),'after_sha256':sha(after.encode())}
  patches.extend(difflib.unified_diff(before.splitlines(True),after.splitlines(True),fromfile='a/'+str(rel),tofile='b/'+str(rel)))
 patch=''.join(patches);(b/f'production-{variant}.patch').write_text(patch)
 m['variants'][variant]={'files':pins,'patch_sha256':sha(patch.encode())}
patches=[]
for p in sorted((b/'new').rglob('*.rs')):
 subprocess.run(['rustfmt','--edition','2024',str(p)],check=True)
 rel=p.relative_to(b/'new');text=p.read_text()
 m['new_files'][str(rel)]={'sha256':sha(text.encode()),'bytes':len(text.encode())}
 patches.extend(difflib.unified_diff([],text.splitlines(True),fromfile='/dev/null',tofile='b/'+str(rel)))
patch=''.join(patches);(b/'new-files.patch').write_text(patch)
m['new_files_patch_sha256']=sha(patch.encode())
(b/'pins.json').write_text(json.dumps(m,indent=2)+'\n')
print(json.dumps({'production_patches':{v:d['patch_sha256'] for v,d in m['variants'].items()},'new_files_patch_sha256':m['new_files_patch_sha256'],'new_files':m['new_files']},indent=2))
