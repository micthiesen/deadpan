from pathlib import Path
import json,os,subprocess,sys
s=Path(__file__).resolve().parent;variant=sys.argv[1]
assert variant in['main','scoped']
listed=(s/('retained-old-'+variant+'-list.stdout')).read_text()
names=[l.removesuffix(': test')for l in listed.splitlines()if l.endswith('retained_fade_baseline::ordinary_retained_fades_match_explicit_external_old_v1: test')]
assert len(names)==1
env=os.environ.copy();env['DEADPAN_RETAINED_FADE_EXPECTED']=str(s/'retained-old-canonical-body.json')
label='retained-old-'+variant+'-external-regression'
code=subprocess.run(['python3',str(s/'run_logic_target.py'),'retained-old-'+variant+'-build',variant,'plan','deadpan_plan',label,'--ignored','--exact',names[0],'--nocapture','--test-threads=1'],env=env).returncode
if code:raise SystemExit(code)
assert'test result: ok. 1 passed;'in(s/(label+'.stdout')).read_text()
