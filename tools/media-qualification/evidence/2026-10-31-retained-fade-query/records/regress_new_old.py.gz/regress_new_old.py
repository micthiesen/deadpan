from pathlib import Path
import json,os,subprocess,sys
s=Path(__file__).resolve().parent
kind,variant=sys.argv[1:]
assert kind in ['host','supplement','retained'] and variant in ['main','scoped']
if kind=='host':
 build=f'retained-host-old-{variant}-build3'
 listing=f'retained-host-old-{variant}-list3.stdout'
 suffix='retained_host_baseline::retained_host_reads_match_external_old_v1'
 key='DEADPAN_RETAINED_HOST_EXPECTED';expected='retained-host-old-canonical-body.json'
 runner='run_target.py';package='audio';target='deadpan_audio'
elif kind=='supplement':
 build=f'retained-supplement-{variant}-build2'
 listing=f'retained-supplement-{variant}-list2.stdout'
 suffix='retained_fade_baseline::supplement::ordinary_retained_fade_supplement_matches_external_old_v1'
 key='DEADPAN_RETAINED_FADE_SUPPLEMENT_EXPECTED';expected='retained-supplement-old-canonical-body.json'
 runner='run_logic_target.py';package='plan';target='deadpan_plan'
else:
 build=f'retained-supplement-{variant}-build2'
 listing=f'retained-supplement-{variant}-list2.stdout'
 suffix='retained_fade_baseline::ordinary_retained_fades_match_frozen_old_v1'
 key=None;expected=None
 runner='run_logic_target.py';package='plan';target='deadpan_plan'
names=[l.removesuffix(': test')for l in(s/listing).read_text().splitlines()if l.endswith(suffix+': test')]
assert len(names)==1,names
env=os.environ.copy()
if key:env[key]=str(s/expected)
label=f'retained-{kind}-old-{variant}-external-regression'
args=['python3',str(s/runner),build,variant,package,target,label]
if kind!='retained':args+=['--ignored']
args+=['--exact',names[0],'--nocapture','--test-threads=1']
code=subprocess.run(args,env=env).returncode
if code:raise SystemExit(code)
receipt=json.loads((s/(label+'.json')).read_text())
assert receipt['exit_code']==0 and receipt['sources_unchanged']and receipt['binaries_unchanged']
assert 'test result: ok. 1 passed;'in(s/(label+'.stdout')).read_text()
print(label,'PASS',flush=True)
