from pathlib import Path
import subprocess,sys
s=Path(__file__).resolve().parent
v=sys.argv[1];assert v in ['main','scoped']
for package,runner in [('plan','run_main_logic.py' if v=='main' else 'run_scoped_logic.py'),('audio','run_qualified.py' if v=='main'else'run_scoped_qualified.py')]:
 label=f'retained-frozen-{v}-{package}-build'
 subprocess.run(['python3',str(s/runner),label,'--','cargo','test','-p',f'deadpan-{package}','--lib','--no-run','--message-format=json'],check=True)
 subprocess.run(['python3',str(s/'pin.py'),label],check=True)
