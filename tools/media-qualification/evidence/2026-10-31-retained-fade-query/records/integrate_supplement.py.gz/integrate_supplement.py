from pathlib import Path
import json,hashlib
s=Path(__file__).resolve().parent;c=s/'supplement-candidate';pins=json.loads((c/'pins.json').read_text())
roots={'main':Path('/Users/michael/Code/deadpan'),'scoped':Path('/tmp/deadpan-query-groundwork-2026-10-26/scoped')}
sha=lambda b:hashlib.sha256(b).hexdigest()
for variant,root in roots.items():
 for name,pin in pins['variants'][variant]['source_pins'].items():
  b=(root/name).read_bytes();assert len(b)==pin['bytes']and sha(b)==pin['sha256'],(variant,name)
 new=pins['new_source'];assert not(root/new['path']).exists()
 assert sha((c/new['path']).read_bytes())==new['sha256']
for variant,root in roots.items():
 for name,pin in pins['variants'][variant]['source_pins'].items():
  if'suggested_after_sha256'not in pin:continue
  p=root/name;b=p.read_bytes();after=(c/'after'/variant/name).read_bytes();assert sha(after)==pin['suggested_after_sha256']
  saved=s/'supplement-integration-before'/variant/name;saved.parent.mkdir(parents=True,exist_ok=True);saved.write_bytes(b);p.write_bytes(after)
 (root/new['path']).write_bytes((c/new['path']).read_bytes())
for filename in['source-files.json','main-logic-source-files.json','scoped-source-files.json','scoped-logic-source-files.json']:
 p=s/filename;paths=json.loads(p.read_text());p.write_text(json.dumps(sorted(set(paths)|{new['path']}),indent=2)+'\n')
owned=set(json.loads((s/'owned-baseline-paths.json').read_text()))
owned|={new['path'],'crates/deadpan-plan/src/audio_owners/legacy_snapshot_v1/fade_query_cases.rs'}
(s/'owned-baseline-paths.json').write_text(json.dumps(sorted(owned),indent=2)+'\n')
print('Added test-only supplement; V1 matrix/frozen body unchanged.')
