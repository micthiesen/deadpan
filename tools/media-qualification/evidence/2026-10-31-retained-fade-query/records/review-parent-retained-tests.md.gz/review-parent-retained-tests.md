# Retained fade admission test candidate review

## Findings

1. **Major — caller lease preservation is not observed.** At lines 128–166 each failing query gets a fresh Policy, and lines 84/173 snapshot only the retained input's value state. Those assertions prove the query's own leases drop and the input's serialized value is unchanged, but cannot prove the still-live original admitted probe/shared carrier's policy ledger survives a refusal. Pass a caller-ledger snapshot/callback into observe from the actual handle-owning scope, and compare it before and after each refusal while that original carrier is still live.

2. **Major — failure sweeps do not prove accepted-prefix accounting or issuer checks.** Lines 157–166 assert only is_err, zero remaining query lease, and forwarded <= work. Refunding all previously accepted fees, accepting too many fees, or returning an unrelated error can pass; reservation refusals also need to retain exactly the prior accepted work. The tests never use Policy's supported rotate_work_call or rotate_reservation controls, so they do not exercise stale-issuer rejection at merges after a policy rotation. Record expected accepted work and callback/reservation prefix state, assert the precise refusal result and no later callback, and sweep rotations around actual checked merge sites.

3. **Minor — the peak check only asserts aggregate live-byte capacity.** Lines 131–153 compare the observed PolicyState.peak with peak - 1; the candidate records no requested Layout sequence or phase bracket. This demonstrates a whole-query capacity threshold, but not the design's separate Box shell, old/new Vec overlap, origin-side and outer-buffer replacement peaks. Keep this as a useful aggregate check, and add named layout/phase observations for the construction sites the design calls out.

## Verified strengths

- The TLS gate is thread-local, defaults Off, and resets on unwind. The retained_body seam described by the parent can run synchronously inside the real handle's borrow without changing frozen output in ordinary tests.
- run checks both full frozen bodies before returning counts. The False path replays each observation, checks literal output/errors, and requires zero query callbacks/reservations. The True path compares all old successful query fields except top-level work, checks literal canonical and nested work, actual total/accepted work, and query lease cleanup.
- The reported counts align with the captured corpora: 50 actual Some handles (23 v1 plus 27 supplement), 3,764 false observations, 2,309 old successes, and 150 work/peak boundary attempts. The exact and one-short work/cap cases are derived from a successful actual input, not synthetic retained data.

## Scope

This reviews the parent test candidate only. I did not run builds/tests or edit either repository.
