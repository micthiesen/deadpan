# Review: retained overlap tests candidate

Read-only review after the owner confirmed candidate stability. No edits, compilation, test/native execution or capture were performed.

Reviewed new source SHA-256 17ee7dcac0443b7861727bbd9314b8e546c638dea9f0132d8d4aeef7c1ce1066; both variant patch SHA-256 98d4ae5b38a58343d16fbe5392f432f0ba79e78f4fea06be74701e8477d8f671. These match the owner's stable pins. This report initially covers those exact bytes.

## Finding

P2: combine the copied-payload floor with the origin/side buffer floor.

In retained_fade_overlap_tests.rs:69-72, common_phase checks:

    live >= (completed_spans+1)*processing_bytes + editorial_bytes

At lines244-257, the OriginMergeReady audit separately checks:

    ready_live >= old_origin_array_layout + new_origin_array_layout

Those two inequalities prove only the maximum of the two floors, not their sum. The README claims simultaneous overlap of the independently sized copied processing/editorial payload and both origin arrays. A dropped copied-payload charge masked by other construction storage could pass these separate assertions. This is a gap in the requested proof, not a discovered production lifetime bug.

At the actual OriginMergeReady callback, assert one combined lower bound:

    live >= (completed_spans+1)*processing_bytes + editorial_bytes
              + Layout<AudioBoundaryOrigin>(event.old_len)
              + Layout<AudioBoundaryOrigin>(event.new_len)

Lengths provide a valid lower bound for those two actual origin arrays; both vectors still live at that phase. Their storage is distinct from the processing Bound/Box and editorial inventories in the independent copy-size calculator, so this does not double-count a copied field.

For OriginGrowthBefore and SideGrowthBefore, similarly include the real old array Layout in the independently sized copied-payload floor. The existing exactly one replacement reservation, before/after delta and peak checks then extend that combined floor by the complete new array while the old one is still charged. Growth-before old_len equals old capacity here because the actual guard is len+1>capacity.

The owner and parent were notified with this concrete correction. Until the combined assertion is included, do not claim the test closes the full combined origin/side overlap proof.

## Other checks

No additional concrete error found in the inspected candidate.

- OuterPushBefore already sums exact old AudioFadeSpan capacity plus every prior and current copied processing payload. Its bracket permits exactly one complete replacement Layout, checks the actual reservation's before total, and checks exact after=before+new-old plus peak>=before+new. Spare-capacity pushes require no reservation and unchanged live bytes. This is substantially stronger than an aggregate-only final peak.
- Omitting current editorial from the outer-push floor is correct. The common Bound helper may release its temporary EnvelopeWork/outer editorial lane before returning the finished span. The copied primary construction lane is conservatively retained by span.keep(primary).
- Initial start/end assertions locate actual one-element AudioFadeEdge allocations. The second side's arithmetic and reservation follow the completed first side without a lease release in the current implementation. The exact event order and unchanged live total between those two allocation brackets are supported by the source.
- Origin/side growth events report old length before growth and actual capacity afterward. At those guarded growth points old length equals capacity. The asserted replacement Layout and after=before+new-old agree with the actual grow implementation, which drops the old value buffer before replacing its capacity lease.
- The common-phase pairing uses the first following matching after phase. In the current synchronous, non-reentrant callbacks these particular construction brackets do not nest another bracket of the same kind, so that pairing is valid. The observer itself logs only scalar context/ledger totals and does not call a query.
- The new outer hooks wrap the actual collection::push in cfg(test), with only scalar length/capacity data. The generic collector, production callbacks, work, allocation and geometry are unchanged.
- Existing copy_tests gets only an exhaustive no-op arm for the new phases and sibling visibility for its independent pure expected-size calculator.
- The default-off baseline observer does not modify serialized values, matrix cases or frozen outputs. It reuses the real Policy and Lease through a forwarding reservation recorder.
- Complete successful query fields other than explicitly reconciled top work remain literal; canonical, additional and forwarded accepted work are checked. The retained input snapshot and both corpus bodies remain exact.
- Root/Domain PrimaryLeaf/PrimaryStage/PrimaryBound phase absence is correctly documented. The standalone retained factory begins with a copied Bound and does not fabricate the Root initial walk.

## Independent frozen-body coverage check

Read-only JSON analysis of the two actual frozen Plan fixtures confirmed:

- 50 actual Some handle scopes.
- 594 unique successful nonempty default sample ranges when deduplicated within each actual handle as the test does.
- Maximum four output spans in a selected request.
- 100 selected output sides with more than one edge.
- 976 selected edges with more than one origin.
- Four handle scopes with both nonempty processing repeat path and nonempty editorial marker inventory.

These counts establish that the selected public corpus contains the relevant output shapes. They do not establish that every asserted callback phase executes in the new constructor; that remains a runtime obligation. The test's explicit origins/sides/coincident/outer-prior-growth/spare-push coverage assertions are appropriate for that obligation.

## Runtime adjudication and limits

Parent execution must still establish type correctness, all594 admitted requests, exact reservation brackets/alignments, callback phase reachability, conservative primary-charge retention, and zero final query live charge in both variants. A compiler pass or independent old output shape count is not a substitute.

The resource model is logical requested Layouts and conservative construction leases. It does not prove allocator/RSS peaks, physical continued residency of discarded values, or separate physical allocation for each Arc identity clone. The candidate correctly states those limits.

The aggregate floor cannot identify a particular Lease by itself. Its value here is the combination of independent immutable copy sizing, the separate exact copy phase tests, real callback allocation brackets, and a source ownership audit. The requested combined sum correction is necessary to avoid weakening that combination to independent lower bounds.
