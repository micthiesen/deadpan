# Additive OLD supplement capture review

## Findings

No capture-integrity or lane-counter defect found in the corrected Main and Scope bodies. One verification limitation remains: the saved Scope coverage-test receipt is from the pre-fix binary and still fails with WrongNodeKind; I found a passing corrected coverage-test receipt for Main, but not a corrected Scope diagnostic receipt.

## Evidence

- Both capture proofs match their run roots, exact ignored test name, successful build/run receipts, binary hashes, source-manifest hashes, body hashes and the same published checkpoint. The capture wrapper recomputes every file in source_after, verifies the manifest digest and emitted provenance, checks the pinned executable, and verifies source and binary stability across the capture. The recorded environment also binds the actual FFMPEG and ONNX runtime prefix paths.
- Re-parsing both raw capture bodies and removing exactly variant, source_sha256 and published_fade_checkpoint yields equal complete JSON. Independently canonicalizing that object reproduces the saved 2,129,320-byte body at SHA-256 28ca861120d0733f6835b6edd3117c5a0fbd9fd95cc69a4cca8ede2e2a39fe8b.
- Independently counting raw Some/RejectedSome input metadata reproduces the mode totals: 7 Some ordinary, 7 Some admitted unmetered, 7 Some admitted metered, 6 Some plus 1 RejectedSome selected/shared. There are 1,882 fade calls: 1,167 Ok and 715 Error. All seven selector setups are Ok.
- Recomputing every declared coverage predicate from retained input values gives positive actual Some metadata counts: processing retimes 4; processing/bound/lattice repeats 8 each; editorial and editorial repeats 8 each; processing/bound definitions 3 each; processing gap_after 4; bound gap 7; lattice gap_after 4; nonzero constraint-gap identities 4; definition-point-ceil clock 4; gap-definition-point-ceil clock 3. This matches the raw coverage object and does not rely on a hard-coded “covered” field.
- The corrected marked-repeat fixture stores the exact checked source document and returned bindings. Its captured bindings are installed by checked ProjectDocument::from_json, the installed document is compiled, then the actual voice owner is selected at sample 6400. The returned Some input records the repeat instance ordinal 1 and editorial boundary. It is a concrete post-capture source, not a fabricated retained input.
- The pre-fix Scope coverage receipt is explicitly a failure at the removed invalid SetEditorialEdges setup, with WrongNodeKind. The fix source removes that invalid setup and adds the checked marked-fragment constructor. Corrected Main's exact coverage diagnostic passes. The corrected Scope capture itself passes and its raw computed lane counters are positive, but no corrected Scope coverage-diagnostic receipt was present in the inspected scratch.
- The prior retained v1 canonical body remains 2,206,347 bytes with SHA-256 44aecc27d5be86e880af03ac43d8a83e5861628638d857a5501da6b1abdc4f16. This audit did not read the 2.3 MB frozen oracle.

## Limits

This checks the additive OLD source capture, raw equality and lane metadata. It does not establish correctness of the new admission implementation. It also does not treat the stale pre-fix Scope diagnostic as a corrected pass; rerun that exact diagnostic from the post-fix Scope binary if a separate proof of that test is required.

## Parent resolution

The corrected Scope diagnostic subsequently passed on the pinned build2 executable. Receipt retained-supplement-scoped-coverage2.json records exit 0 with unchanged sources and binary; stdout records one passing exact named coverage test. The original failing receipt remains unchanged. Both external full-body regressions also pass. The suffix used by the first supplemental regression wrapper did not match the actual module path and launched no test; the corrected wrapper selected the listed exact name and both runs passed.
