from pathlib import Path
import json,hashlib,collections
s=Path(__file__).resolve().parent
a=json.loads((s/'retained-old-main-body.json').read_text());b=json.loads((s/'retained-old-scoped-body.json').read_text())
for d in[a,b]:
 for name in['variant','source_sha256','published_fade_checkpoint']:d.pop(name)
assert a==b
canonical=(json.dumps(a,sort_keys=True,separators=(',',':'))+'\n').encode()
p=s/'retained-old-canonical-body.json';assert not p.exists();p.write_bytes(canonical)
results=collections.Counter();modes={};calls=collections.Counter();work=[];provenance=[]
for case in a['cases']:
 counts={}
 for h in case['handles']:
  mode=h['mode'];modes.setdefault(mode,collections.Counter())[h['result']]+=1;results[h['result']]+=1
  if h['result']!='Some':continue
  inp=h['input'];observations=inp['observations']
  counts[mode]={'retained_input_work':inp['retained_input_work'],'bound_work':inp['literal_bound_work_prepaid_per_span'],'actual_fade_calls':len(observations)}
  for row in observations:
   calls[row['output']['result']]+=1
   if row['name']=='current_delivery/default':
    work.append({'fixture':case['fixture']['name'],'mode':mode,'result':row['output']['result'],'work':row['output'].get('query',{}).get('work')})
 provenance.append({'fixture':case['fixture']['name'],'modes':counts})
result={'fixtures':len(a['cases']),'actual_handle_trials':sum(results.values()),'handle_results':dict(results),'by_mode':{m:dict(c)for m,c in modes.items()},'actual_fade_calls':sum(calls.values()),'fade_results':dict(calls),'default_delivery':work,'actual_work_provenance':provenance,'canonical_bytes':len(canonical),'canonical_sha256':hashlib.sha256(canonical).hexdigest(),'removed_fields':['variant','source_sha256','published_fade_checkpoint'],'full_main_scoped_equality':True}
(s/'old-equality-and-coverage.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items()if k not in['default_delivery','actual_work_provenance']},indent=2))
