# Native retained host pairs audit

## Findings

None in the assigned lens.

## Evidence checked

- The before_read hook receives the exact AudioOwnerRetainedInput borrowed by the subsequent read_retained_controlled call. It obtains ordinary standalone fade/owner metadata using the same requested sample range, records its witness, then resets only admission trace counters before the measured read. The witness is explicitly labelled outside ReadWork; it validates canonical work but is not counted as production admission.
- Each paired NEW scenario is reconstructed from the frozen OLD fixture, request coordinates, mode, authored flag, and fault. fixture_matches checks current/reference documents and WAV descriptor. The frozen OLD JSON SHA is pinned. Where enabled, the legacy comparison asserts the complete OLD body before comparing.
- Canonical comparison checks successful product canonical units against ordinary constructor work on the same input. Successful pair assertions compare complete PCM bits, masks/suppression, dependencies, and relative depth via the full output object, plus provider event ordering and all non-admission fields. Error comparisons retain kind, Debug, Display, and cancellation status; the paired failure test requires the complete typed error to match.
- Successful fee reconciliation uses paired NEW-minus-OLD ReadWork deltas against only independently measured additional_units. It requires zero partial work and zero eviction work in those success cases and separately verifies the global host-eviction receipt is zero. Thus the ordinary canonical witness is not added a second time and host evictions are not folded into that delta.
- The manual capture loops over all 744 literal frozen OLD operations and stores each paired NEW result, request, mode, authored flag, and comparison. The frozen OLD coverage summary reports all 744 setups as Some and 306 Ok / 438 Error; it includes four retained-probe/selected modes, authored and unauthored operations, five fixture families, and provider/error/budget/residency cases.
- The before-read hook is confined to the cfg(test) baseline module and is inert unless this test module's thread-local ACTIVE flag is set. RAII cleanup clears the flag and witness on unwind. The ordinary witness runs before the production reader but has no ReadWork accounting; this is a test-only observability seam, not production admission behavior.

## Limits

The 744-operation NEW capture is a manual ignored capture test; regular paired assertions directly cover 40 default-success operations and 64 early/source-failure operations. Full 744-result classification/equality depends on the separately recorded native capture comparison, not on this unit test alone. I inspected frozen OLD coverage and equality metadata, but did not run or regenerate native tests/captures.
