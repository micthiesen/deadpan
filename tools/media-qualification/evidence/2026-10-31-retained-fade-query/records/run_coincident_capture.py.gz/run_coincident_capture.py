from pathlib import Path
import subprocess,sys
s=Path(__file__).resolve().parent;v=sys.argv[1]
label=f'retained-coincident-{v}-build8'
subprocess.run(['python3',str(s/'pin.py'),label],check=True)
subprocess.run(['python3',str(s/'run_logic_target.py'),label,v,'plan','deadpan_plan',label+'-list','--list'],check=True)
subprocess.run(['python3',str(s/'capture_coincident_ordinary.py'),v],check=True)
