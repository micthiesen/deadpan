from pathlib import Path
import json,hashlib,sys
s=Path(__file__).resolve().parent
kind=sys.argv[1];assert kind in ['supplement','host']
roots={'main':Path('/Users/michael/Code/deadpan'),'scoped':Path('/tmp/deadpan-query-groundwork-2026-10-26/scoped')}
if kind=='supplement':
 body='retained-supplement-old-canonical-body.json';length=2129320;sha='28ca861120d0733f6835b6edd3117c5a0fbd9fd95cc69a4cca8ede2e2a39fe8b'
 rel='crates/deadpan-plan/tests/fixtures/retained-fade-query-supplement-v1'
 report='review-old-supplement-capture.md'
 text='''# Immutable additive retained-fade owning-lane witness

Captured independently from Main and the isolated published copy before changing
retained fade production algorithms, following published checkpoint
ee9742711868fde9a78bcb945adfd36e67f504d6.

Complete parsed bodies agree after removing only variant, source_sha256 and
published_fade_checkpoint. Compact JSON changes whitespace only. Both exact
external full-body regressions and corrected owning-lane diagnostics pass.

Seven checked setups produce 28 actual provenance trials: 27 Some and one
RejectedSome. Their 1,882 fade calls record 1,167 successes and 715 typed errors.
Actual Some inputs cover retimes, repeats, editorial markers, definitions,
gap identities and DefinitionPointCeil/GapDefinitionPointCeil clock ownership.
These are observations of real checked constructors, not synthetic retained
handles. The separate retained-fade-query-baseline-v1 body is unchanged.

Raw bodies, source/binary/media provenance, independent review, failed initial
setup and corrected reruns remain unit evidence. This logical OLD witness makes
no claim about the new admission implementation or native allocation residency.

Do not regenerate this body from a changed algorithm to make a test pass.
'''
else:
 body='retained-host-old-canonical-body.json';length=25746494;sha='838a7165fe4fd9142450568158359b00b05d6cd867aceaef77bfbd49e2c52f75'
 rel='crates/deadpan-audio/tests/fixtures/retained-host-read-baseline-v1'
 report='review-old-host-capture.md'
 text='''# Immutable native retained-reader witness

Captured independently on this physical Mac from Main and the isolated published
copy before changing read_retained_controlled or retained fade algorithms,
following published checkpoint ee9742711868fde9a78bcb945adfd36e67f504d6.
Qualified FFmpeg and ONNX Runtime identities, source manifests, executable hashes,
media hashes and complete invocation receipts accompany the raw unit evidence.
Native executions were serialized.

Complete parsed bodies agree after removing only variant, source_sha256 and
published_fade_checkpoint. Compact JSON changes whitespace only. Both exact
external full-body regressions pass.

Five real WAV scenarios exercise Root and Point retained history, resumed/signed
phase, reference treatments/masks, NTSC enclosing/silence and a 44.1 kHz fractional
Root path. Four actual input-provenance modes and authored false/true yield 744
Some setups and actual reads: 306 successes and 438 typed failures.
The complete body retains PCM bits, masks, dependencies, depth, work counters,
cache identities/aliases, source callback observations and cleanup state.
Work and resource observations are literal; no accounting fields are removed.
Private Plan fields are covered by the separate retained-fade logical witnesses.

These observations establish the OLD reader's behavior, not allocator/RSS
measurement or correctness of the later admitted implementation.

Do not regenerate this body from a changed algorithm to make a test pass.
'''
data=(s/body).read_bytes();assert len(data)==length and hashlib.sha256(data).hexdigest()==sha
assert (s/report).exists()
for variant,root in roots.items():
 label=f'retained-{kind}-old-{variant}-external-regression'
 r=json.loads((s/(label+'.json')).read_text())
 assert r['exit_code']==0 and r['sources_unchanged'] and r['binaries_unchanged']
 target=root/rel
 if target.exists():
  assert (target/'snapshot.json').read_bytes()==data
  assert (target/'snapshot.sha256').read_text()==sha+'  snapshot.json\n'
  assert (target/'README.md').read_text()==text
 else:
  target.mkdir(parents=True)
  (target/'snapshot.json').write_bytes(data)
  (target/'snapshot.sha256').write_text(sha+'  snapshot.json\n')
  (target/'README.md').write_text(text)
pins=json.loads((s/'immutable-oracle-pins.json').read_text())
assert len(pins)==(18 if kind=='supplement'else 19)
for pin in pins:
 for root in roots.values():
  b=(root/pin['path']).read_bytes();assert hashlib.sha256(b).hexdigest()==pin['sha256'],pin['path']
  if 'bytes'in pin:assert len(b)==pin['bytes'],pin['path']
pins.append({'path':rel+'/snapshot.json','bytes':length,'sha256':sha})
(s/'immutable-oracle-pins.json').write_text(json.dumps(pins,indent=2)+'\n')
files=[rel+'/'+f for f in ['snapshot.json','snapshot.sha256','README.md']]
for filename in ['source-files.json','main-logic-source-files.json','scoped-source-files.json','scoped-logic-source-files.json']:
 paths=json.loads((s/filename).read_text())
 (s/filename).write_text(json.dumps(sorted(set(paths)|set(files)),indent=2)+'\n')
ownedfile='owned-baseline-paths.json'if kind=='supplement'else'owned-host-baseline-paths.json'
owned=json.loads((s/ownedfile).read_text())
(s/ownedfile).write_text(json.dumps(sorted(set(owned)|set(files)),indent=2)+'\n')
print({'kind':kind,'frozen_bytes':length,'sha256':sha,'immutable_oracles':len(pins)})
