# Review and integration follow-up

The original pinned candidate source/patch bytes remain unchanged.

Flat_constructor found that OriginMergeReady's original checks separately bounded
copied processing/editorial payload and old/new origin arrays. That established
only their maximum, not the combined live sum claimed. The parent accepted the
finding and changed its actual integration to require, at the real Ready event:

    live >= (completed_spans + 1) * processing_bytes + editorial_bytes
            + Layout<Origin>(old_len) + Layout<Origin>(new_len)

The actual integration also adds combined copied-payload-plus-old-array bounds at
origin/side growth and the initial end-side bracket. The original outer-push sum
and exact replacement reservation/delta proof was already sound.

Parent-supplied diagnostic6 evidence reports all those stronger sum assertions
passed over 594 current retained windows. Its only failed assertion was missing
both-nonempty coincident-origin coverage: initial=1084, origins=172, sides=100,
coincident=0, outer_growth=853, prior_growth=259, spare_push=8,
repeat_editorial_handles=4. That is a real corpus coverage gap, not proof the
shared merge phase is impossible. This reviewer did not run diagnostic6.

The subsequent retained-coincident-diagnostic-candidate preserves the existing
twenty oracle bodies and proposes a genuine checked Split plus marked Partition
composition for independent ordinary/admitted diagnosis. Its runtime remains
parent-owned and unverified here. The original positive overlap coverage
requirement has not been weakened in these scratch patches.
