from pathlib import Path
import subprocess,json,hashlib,difflib
r=Path("/tmp/deadpan-retained-fade-query-admission-2026-10-30/retained-overlap-tests-candidate")
new="crates/deadpan-plan/src/audio_owners/retained_fade_overlap_tests.rs"
paths=[
"crates/deadpan-plan/src/audio_retained_fades_query.rs",
"crates/deadpan-plan/src/audio_retained_fades_query_trace.rs",
"crates/deadpan-plan/src/audio_owners/retained_fade_copy_tests.rs",
"crates/deadpan-plan/src/audio_owners/retained_fade_baseline.rs",
]
def d(b):return hashlib.sha256(b).hexdigest()
pins={"schema":"scratch-retained-overlap-tests-v1","new_files":{new:d((r/new).read_bytes())},"variants":{},"typechecked":False,"executed":False}
for variant,repo in [("main-inherited",Path("/Users/michael/Code/deadpan")),("scoped-published",Path("/tmp/deadpan-query-groundwork-2026-10-26/scoped"))]:
 folder=r/"variants"/variant
 changed={}
 for name in paths:
  before=(repo/name).read_text()
  after=before
  if name.endswith("/audio_retained_fades_query.rs"):
   needle="                spans = collection::push(spans, span, &mut budget)?;"
   assert after.count(needle)==1
   after=after.replace(needle,'''                #[cfg(test)]
                trace::observe(trace::Phase::OuterPushBefore {
                    old_len: spans.spans.len(),
                    old_capacity: spans.spans.capacity(),
                });
                spans = collection::push(spans, span, &mut budget)?;
                #[cfg(test)]
                trace::observe(trace::Phase::OuterPushAfter {
                    new_len: spans.spans.len(),
                    new_capacity: spans.spans.capacity(),
                });''')
  elif name.endswith("/audio_retained_fades_query_trace.rs"):
   needle="    EditorialCopyAfter,\n"
   assert after.count(needle)==1
   after=after.replace(needle,needle+'''    OuterPushBefore { old_len: usize, old_capacity: usize },
    OuterPushAfter { new_len: usize, new_capacity: usize },
''')
  elif name.endswith("/retained_fade_copy_tests.rs"):
   needle="fn expected(snapshot: &Value) -> (usize, usize)"
   assert after.count(needle)==1
   after=after.replace(needle,"pub(super) fn expected(snapshot: &Value) -> (usize, usize)")
   needle="                state.completed[2] += 1;\n            }\n"
   assert after.count(needle)==1
   after=after.replace(needle,needle+"            Phase::OuterPushBefore { .. } | Phase::OuterPushAfter { .. } => {}\n")
  else:
   needle="    copy_tests::observe(input, retained, &observations);\n"
   assert after.count(needle)==1
   after=after.replace(needle,needle+"    overlap_tests::observe(input, retained, &observations);\n")
   after+='\\n#[path = "retained_fade_overlap_tests.rs"]\\nmod overlap_tests;\\n'.replace("\\n","\n")
  for state,value in [("before",before),("after",after)]:
   p=folder/state/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(value)
  p=folder/"after"/name
  subprocess.run(["rustfmt","--edition","2024","--config","skip_children=true",str(p)],check=True)
  changed[name]={"before_sha256":d(before.encode()),"after_sha256":d(p.read_bytes())}
 patch=""
 for name in paths:
  before=(folder/"before"/name).read_text();after=(folder/"after"/name).read_text()
  patch+="".join(difflib.unified_diff(before.splitlines(True),after.splitlines(True),fromfile="a/"+name,tofile="b/"+name))
 patch+="".join(difflib.unified_diff([],(r/new).read_text().splitlines(True),fromfile="/dev/null",tofile="b/"+new))
 (folder/"candidate.patch").write_text(patch)
 pins["variants"][variant]={"changed_files":changed,"patch_sha256":d(patch.encode())}
(r/"pins.json").write_text(json.dumps(pins,indent=2)+"\n")
print(json.dumps({"new_files":pins["new_files"],"patches":{k:v["patch_sha256"] for k,v in pins["variants"].items()}},indent=2))
