# Retained combined overlap tests: scratch candidate

No actual repository files were changed. No builds, type checks, tests, native
runs, captures or oracle regeneration were performed. Rustfmt parsing/checking
and read-only git apply --check passed against both current roots.

Each variant includes exact before/after source files, a candidate.patch and
pins in the top-level pins.json. The new file is
crates/deadpan-plan/src/audio_owners/retained_fade_overlap_tests.rs.

Narrow cfgtest changes only:

- Extend retained-fade Phase with scalar OuterPushBefore {old_len, old_capacity}
  and OuterPushAfter {new_len, new_capacity}.
- Emit them immediately around the actual collection::push in the retained true
  factory. Generic collector code and runtime semantics are unchanged. Production
  has no new observer callbacks, debits or allocations.
- Let existing copy_tests ignore the new phase variants and expose its pure
  independent expected-size calculator to its sibling with pub(super).
- Add one baseline child declaration and observe hook alongside its existing
  admission/copy test observers. Default-off observers preserve frozen output.

The new test traverses the actual 50 Some handle-owning scopes in both unchanged
frozen corpora. It replays 594 distinct successful nonempty default windows on
the actual borrowed handle. It registers both the existing common edge/origin
phase observer and the new retained outer observer. A forwarding wrapper around
the existing actual Policy records each requested Layout size/alignment and
before/after live byte totals; no second accounting policy is introduced.

Exact assertions:

- Through common retained geometry and edge phases, all prior completed copied
  processing payloads, the current copied processing payload and the current
  copied editorial payload remain logically charged. The floor is derived by
  the existing independent snapshot-based copy-size calculator, not callback
  totals or final heap traversal.
- Actual initial start/end side arrays each request exactly one correctly aligned
  AudioFadeEdge Layout at the observed live total. The end allocation follows the
  completed start side with that first side still live.
- Actual origin/side growth requests exactly the full correctly aligned new
  capacity while old capacity and the independent copied-payload floor remain
  live. The after phase equals before+new-old, and peak covers before+new.
- Coincident-origin merge retains both old and new origin arrays through the
  ready/after phases while retained copied payload stays live.
- At each real outer push, live charges include exact old AudioFadeSpan capacity
  plus the independent processing-copy floor for ALL prior spans and current
  guarded span. Editorial construction leases can legitimately be released by
  the common helper before the push, so they are not falsely included here.
- On outer growth the only reservation inside the bracket is the full new
  AudioFadeSpan capacity with its correct alignment and unchanged observed
  before total. After equals before+new-old. Peak covers old/new capacity overlap
  with prior/current copied payloads. Spare-capacity pushes allocate nothing and
  preserve the observed live total.
- Every query keeps every frozen output field except top work literal, with
  canonical==OLD work and total==canonical+additional==accepted policy work;
  dropping the query releases its own ledger. Complete retained snapshots and
  both frozen bodies remain identical.

Coverage assertions require all 50 Some scopes and exactly 594 distinct requests,
real initial/origin-growth/side-growth/coincident phases, real outer growth with
prior spans, a spare-capacity push and at least one real handle with BOTH nonempty
repeat and editorial inventories. A read-only frozen-body inspection already
shows 100 output sides with multiple edges, 976 edges with multiple origins and
real four-span windows. Runtime phase reachability remains an unexecuted test
obligation; these are not reported passes.

Structurally unavailable phases: the common PrimaryLeaf/PrimaryStage/PrimaryBound
events belong to the Root/Domain factory's initial walk and are not emitted by
the standalone retained factory, which enters the shared Bound geometry with an
already copied primary. This test does not fabricate that walk. It observes the
actual retained geometry, side/origin and collector phases instead.

Parent must integrate the matching patch and run the new exact test in both
roots under its guarded build/native policy. This closes the specifically named
logical requested-Layout overlap proof if it passes; it is not a claim about RSS,
allocator implementation peaks or separate physical allocation per cloned Arc
identity edge. The unchanged twenty immutable oracles still need their normal
gate checks after integration.
