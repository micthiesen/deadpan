from pathlib import Path
import json,hashlib,re
s=Path(__file__).resolve().parent
roots={'main':Path('/Users/michael/Code/deadpan'),'scoped':Path('/tmp/deadpan-query-groundwork-2026-10-26/scoped')}
data=(s/'retained-old-canonical-body.json').read_bytes()
digest='44aecc27d5be86e880af03ac43d8a83e5861628638d857a5501da6b1abdc4f16'
assert len(data)==2206347 and hashlib.sha256(data).hexdigest()==digest
assert(s/'review-old-capture.md').exists()
rel='crates/deadpan-plan/tests/fixtures/retained-fade-query-baseline-v1'
source='crates/deadpan-plan/src/audio_owners/retained_fade_baseline.rs'
test='''
#[test]
fn ordinary_retained_fades_match_frozen_old_v1() {
    let expected: Value = serde_json::from_str(include_str!(
        "../../tests/fixtures/retained-fade-query-baseline-v1/snapshot.json"
    ))
    .unwrap();
    assert_eq!(matrix(), expected);
}
'''
readme='''# Immutable ordinary retained-fade witness

Captured independently from Main and an isolated published copy after fade
checkpoint ee9742711868fde9a78bcb945adfd36e67f504d6 was pushed and remotely verified.
No retained-fade production algorithm changed before capture.

Complete parsed bodies agree after removing only variant, source_sha256 and
published_fade_checkpoint. This compact body removes whitespace only.

11 checked fixtures, four actual handle-provenance modes each: 44 trials,
23 Some, 20 None and one explicit sharing rejection. The 23 actual retained
handles contribute 1,882 fade calls: 1,142 successes and 740 typed errors.
Ordinary, admitted-false, admitted-true and actual selected/shared provenance
remain separate. Actual stored bound.work and complete retained metadata are
literal, including augmented work on admitted-created handles.

Exact returned-work and positive one-short trials record actual outcomes;
they do not invent a zero-work legal cap or assume returned span count is the
only internal budget. Unavailable factories and sharing rejection remain
explicit. Ordinary error APIs expose no accepted partial-work receipt.

Before freeze, both complete captures, source/binary/checkpoint provenance and
two external full-body regressions passed independent audit. Full Plan libraries
also pass with the producer integrated. Raw pretty bodies, wrappers, receipts
and reviews are retained as unit evidence. No native or admitted-fade resource
claim is supplied by this witness.

Do not regenerate this body from a changed algorithm to make a test pass.
'''
for variant,root in roots.items():
 label='retained-old-'+variant+'-plan'
 receipt=json.loads((s/(label+'.json')).read_text())
 assert receipt['exit_code']==0 and receipt['sources_unchanged']
 summary=re.findall(r'test result: ok\. (\d+) passed; 0 failed; (\d+) ignored;', (s/(label+'.stdout')).read_text())
 assert summary==[(str(262 if variant=='main'else 249),'16')],summary
 target=root/rel;assert not target.exists();target.mkdir(parents=True)
 (target/'snapshot.json').write_bytes(data)
 (target/'snapshot.sha256').write_text(digest+'  snapshot.json\n')
 (target/'README.md').write_text(readme)
 p=root/source;before=p.read_text();assert'fn ordinary_retained_fades_match_frozen_old_v1'not in before
 saved=s/'freeze-before'/variant/source;saved.parent.mkdir(parents=True,exist_ok=True);saved.write_text(before)
 p.write_text(before+test)
pins=json.loads((s/'immutable-oracle-pins.json').read_text());assert len(pins)==17
pins.append({'path':rel+'/snapshot.json','bytes':len(data),'sha256':digest})
(s/'immutable-oracle-pins.json').write_text(json.dumps(pins,indent=2)+'\n')
owned=list(json.loads((s/'old-producer-candidate/pins.json').read_text())['new_sources'])+['crates/deadpan-plan/src/audio_owners/wide_gain_query_admission_tests.rs','crates/deadpan-plan/src/audio_owners/legacy_snapshot_v1.rs',rel+'/snapshot.json',rel+'/snapshot.sha256',rel+'/README.md']
(s/'owned-baseline-paths.json').write_text(json.dumps(sorted(owned),indent=2)+'\n')
for variant,filename in [('main','source-files.json'),('main','main-logic-source-files.json'),('scoped','scoped-source-files.json'),('scoped','scoped-logic-source-files.json')]:
 paths=json.loads((s/filename).read_text());paths=sorted(set(paths)|{rel+'/snapshot.json',rel+'/snapshot.sha256',rel+'/README.md'})
 (s/filename).write_text(json.dumps(paths,indent=2)+'\n')
print({'frozen_body_bytes':len(data),'sha256':digest,'immutable_oracles':18,'owned_baseline_paths':len(owned)})
