# Integrated retained Plan tests: read-only review

Reviewed current Main and Scope source. No repository edits, build, test run,
native execution, capture or expected-body generation was performed. The parent
reports the initial stronger tests passed after correcting rotation's expected
error to the actual AudioMetadataIssuerMismatch; the latest cancellation repair
is in the parent's builds4 and was not executed by this reviewer.

## Result

The earlier caller-preservation and failure-prefix gaps are closed in the current
source. Exact processing/Box/editorial copy-size brackets cover all 50 actual
Some handles. All twenty immutable oracle files match the recorded SHA-256 pins
byte-for-byte in BOTH roots. One construction-peak coverage boundary remains
against admission-design.md acceptance item 5; it is described below rather than
reported as a production defect.

## Failure prefix, error and caller ownership

retained_fade_failure_audit.rs records the actual successful baseline callback
sequence, then targets each real spend and reservation ordinal. Each refusal must
return its exact typed AudioQueryLimit label, preserve the complete prior Event
prefix, terminate at exactly index+1, and have the exact rejected operation and
units. Thus accepting a later callback, an unrelated error or an accepted failed
fee cannot satisfy the test.

The rotation sweep covers every baseline spend, reserve and merge callback. It
requires AudioMetadataIssuerMismatch, the exact accepted baseline prefix through
the rotation callback, no later callback, and two retained issuer states. All
recorded states must release live bytes. Their accepted forwarded-work sum must
equal the accepted spend Events, so failed-prefix fees remain spent rather than
being refunded. The infallible merge rotates only after the actual merge; the
following checked issuer boundary must reject it.

The real caller policy is supplied from the admitted probe/shared handle's owning
scope through retained_body -> admission_tests::observe -> Recording. Caller live,
peak, cap, reservation count, forwarded work and work-call count are compared at
every callback, immediately after policy callbacks/rotations, and after query
failure/drop. This preserves the original guard while its actual retained value
is borrowed. After leaving the handle-owning scope, the existing producer checks
caller live bytes are zero. Ordinary handles correctly have no caller ledger;
false admitted handles keep their zero-callback caller state separately.

### Cancellation finding and parent resolution

The reviewed initial loop at former lines 206-224 accepted any early prefix
ending in a rejected spend. It did not require the selected threshold's actual
baseline callback index, so cancellation at the first spend for every threshold
could pass that loop. This was reported to the parent.

The parent first repaired both roots by asserting the indexed baseline prefix.
That stricter runtime check then exposed zero-unit spend callbacks: several
callbacks can share one accepted-work total, so a work-total threshold can cancel
before the intended callback (the parent observed index 68 versus 70). This was a
test targeting mismatch, not a production defect.

The current source now uses an explicit spend callback ordinal in the forwarding
Recording wrapper for the all-callback cancellation sweep. It requires
events.len()==index+1, the exact rejected Event operation/units, the full preceding
baseline prefix, precise cancellation label and caller/accepted-work cleanup.
The existing copy_tests separately retain real Policy work-total cancellation
before zero and immediately after the literal canonical prepay. Callback-ordinal
fault coverage and those actual work-total boundaries are distinct claims. The
finding is resolved in source; runtime verification remains the parent's work.

## Actual coverage and copy brackets

Independent read-only traversal of the frozen corpora confirms:

- Baseline: 23 Some handles, 1,882 rows, 1,142 successful rows.
- Supplement: 27 Some handles, 1,882 rows, 1,167 successful rows.
- Combined: 50 Some, 3,764 false replay rows, 2,309 successful true comparisons.
- Resolved clocks: 35 RootRoundEven, 8 PreserveInputPointCeil, 4
  DefinitionPointCeil, 3 GapDefinitionPointCeil.
- Nonempty retimes occur in 4 handles; processing/bound/lattice repeat vectors
  each occur in 8; outer editorial and editorial repeat vectors each occur in 8.
  Processing/bound definitions occur in 3; processing/lattice gap identities in 4;
  a Bound gap in 7.

retained_fade_copy_tests independently derives the copy-size sum from exhaustive
retained snapshots: the processing selector, independent instance/repeat/retime
storage and identity edges, the Bound shell and its independent owning fields,
all four resolved clock variants, and the editorial marker/constraint/repeat
storage and identities. It does not obtain the expected totals from the copy
implementation or final OwnedHeap traversal.

The synchronous phase hooks are at the real production processing_copy call,
real GuardedBound::boxed call and actual editorial_copy call. For every output
span they assert exact live-byte deltas; the Box bracket requires the actual
AudioBound shell size while prior copied payload remains live. The phase state
requires a positive completed count, equal completed counts for all three
brackets and no unmatched before event. The test asserts exactly 50 observed
handles. The full frozen matrices still compare equal when observers are active.

These are independent requested-size sums and real phase brackets. They do not
by themselves prove every allocation's alignment, exact allocator RSS or final
heap identity. Logical repeated Arc identity ownership remains distinct from
separate physical heap allocations, as the design requires.

## Remaining bounded coverage boundary

Acceptance item 5 also asks for initial side/origin replacement and
AudioFadeSpan outer-buffer overlap while retained copied payload, prior spans
and current span are live. The new retained copy test registers only the six
processing/Box/editorial Phase events. It does not attach the existing common
fade side/origin observer during these 50 retained calls, nor independently
bracket this retained query's growing AudioFadeSpan collector.

Existing fade_query_resource_tests do verify the COMMON initial-side,
origin/side replacement and coincident-origin implementation using 80 frozen
Root/Domain parents, including Bound geometry on both reference grids. Existing
processing_query_admission_tests verify outer growth for AudioSignalSpan /
AudioProcessingSpan. Those are useful reused-helper evidence, but the latter
has different element layouts and neither is the retained-specific combined
peak assertion described in item 5. Do not claim that combined retained
construction peak is independently proved by the current copy-size test alone.

Concrete closure: run the common fade phase observer on an actual nonempty
retained supplemental request and bracket AudioFadeSpan collector growth while
previous spans/current guarded span remain live, using the actual requested
Layouts and independent retained payload totals. If this is deliberately deferred,
document it as that specific proof boundary rather than a closed peak claim.

## Frozen data and source identity

All 20 paths in immutable-oracle-pins.json matched in Main and Scope. In
particular retained v1 remains 2,206,347 bytes / SHA-256
44aecc27d5be86e880af03ac43d8a83e5861628638d857a5501da6b1abdc4f16,
and the owning-lane supplement remains 2,129,320 bytes / SHA-256
28ca861120d0733f6835b6edd3117c5a0fbd9fd95cc69a4cca8ede2e2a39fe8b.

Reviewed sources have identical hashes in both roots:

- retained_fade_admission_tests.rs:
  363709eb83a1a175b648884d06202f912c8ee67b2b334870314faac1d15a46df
- retained_fade_failure_audit.rs after callback-ordinal cancellation repair:
  f4be5ab699afa65525cb5dffd5ad28555bd39c758ea59463c989c50c2acac56a
- retained_fade_copy_tests.rs:
  b5a95ce03c476c70b42fe1312e6516c9ec862f4d9dc4bc8fcfd2f7ded78bf280
- retained_fade_baseline.rs observer/caller seam:
  179836b09f6f87489788e89a923ce44f2237442a9c148b900c7732c7fa0d565f
- audio_retained_fades_query.rs:
  bdcd5fe32536a9e120904d4ee0fc72591f40b6607c2fcb51d2938b874990032c
- audio_retained_fades_query_trace.rs:
  85de1d180b1af303e0dcb2b96fa96377b6f749c9cf4013322ff529d732aacbe8
