# Retained host gap tests: scratch extension

Prepared only in this scratch directory. No actual repository edits, builds,
type checks, native runs, captures, oracle regeneration, commits or pushes.
Rustfmt parsing/checking and read-only git apply --check passed for both variants.

Each variant has an exact current before/after original_inputs_tests.rs and an
additive candidate.patch. Only a child test declaration is added to that file;
the new shared_eq/retained_host_gap_tests.rs holds all test logic. The Main and
Scope declaration files differ, so use the matching variant patch. pins.json
records both exact anchors and the new file hash. Existing host admission and
Plan changes are untouched.

The child uses the existing original_inputs_tests Graph, Provider and control
helpers. It loads the complete real retained document from the unchanged frozen
twentieth oracle rather than copying another fixture builder. That source file's
actual SHA-256 is 838a7165fe4fd9142450568158359b00b05d6cd867aceaef77bfbd49e2c52f75
in both roots. No new production visibility, hook or mutable test receipt is added.

Three tests cover the requested paths:

1. foreign_retained_plan_wins_over_depth_and_range_before_constructor_or_source_io
   compiles the identical actual document into a distinct immutable plan, keeps
   the original retained operand, and combines foreign identity with invalid
   depth/range arguments. It requires ForeignDomain before either constructor,
   source I/O or any accepted work. Initial control checks remain unchanged.

2. real_cached_wav_payloads_are_evicted_by_retained_fade_admission_with_separate_receipts
   obtains the actual admitted shared retained carrier through the production
   owner-selection helper. It measures the same fade factory on a real separate
   ledger, then populates sixteen genuine unpinned WAV cache payloads through
   shared_original_input with Root context. The local test limit is LOWERED to
   observed cached residency plus live caller residency. It invokes the actual
   prepare_retained_fades helper in each plan/cache lane, requiring real cache
   removal during metadata construction and no source callback. Accepted work
   must equal the completed canonical/additional receipt plus the existing
   explicit host-eviction count. Dropping the query restores caller residency;
   clearing the real Graph cache and dropping the caller releases everything.

3. real_retained_original_cache_hit_rechecks_source_and_bypasses_retained_construction
   uses an actual admitted shared retained context. A real cold
   shared_original_input call populates its cache through read_retained_controlled.
   A second identical request must return the exact same PCM Arc, re-admit source
   provenance, publish no new entry, and execute neither retained constructor.
   Cleanup clears the actual Graph/controller payloads and caller metadata.

The authentic bypass is shared_original_input_mode's existing exact cache lookup
before its Context::Retained cold path. The separate policy-prediction fast path
try_cached_original_for_prediction explicitly returns None for Retained contexts;
the tests do not alter that boundary or claim that prediction supports them.

Runtime remains unverified. Parent must compile both variants and run the three
new tests serially with other native executables. The real pressure test assumes
the measured one-span constructor can fit after sufficient real entries are
evicted and that sixteen observed cache payloads exceed its retained metadata.
Those are explicit unexecuted assertions, not reported runtime evidence. If an
actual run disproves either, preserve the failure and adjust the real bounded
setup; do not fabricate cache entries, work receipts or expected eviction totals.
No production cap is increased and no allocator/independent-peak proof is claimed.
