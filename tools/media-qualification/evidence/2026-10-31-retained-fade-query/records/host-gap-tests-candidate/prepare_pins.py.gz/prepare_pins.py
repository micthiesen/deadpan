from pathlib import Path
import json,hashlib,difflib
r=Path("/tmp/deadpan-retained-fade-query-admission-2026-10-30/host-gap-tests-candidate")
new="crates/deadpan-audio/src/shared_eq/retained_host_gap_tests.rs"
target="crates/deadpan-audio/src/shared_eq/original_inputs_tests.rs"
fixture="crates/deadpan-audio/tests/fixtures/retained-host-read-baseline-v1/snapshot.json"
def d(b):return hashlib.sha256(b).hexdigest()
pins={"schema":"prepare-only-retained-host-gap-tests-v1","new_file":{"path":new,"sha256":d((r/new).read_bytes())},"variants":{},"typechecked":False,"executed":False}
for variant,repo in [("main-inherited",Path("/Users/michael/Code/deadpan")),("scoped-published",Path("/tmp/deadpan-query-groundwork-2026-10-26/scoped"))]:
    before=(repo/target).read_bytes()
    assert b"mod retained_host_gap_tests;" not in before
    after=before+b'\n#[path = "retained_host_gap_tests.rs"]\nmod retained_host_gap_tests;\n'
    folder=r/"variants"/variant
    for state,value in [("before",before),("after",after)]:
        path=folder/state/target
        path.parent.mkdir(parents=True,exist_ok=True)
        path.write_bytes(value)
    patch="".join(difflib.unified_diff(before.decode().splitlines(True),after.decode().splitlines(True),fromfile="a/"+target,tofile="b/"+target))
    patch+="".join(difflib.unified_diff([],(r/new).read_text().splitlines(True),fromfile="/dev/null",tofile="b/"+new))
    (folder/"candidate.patch").write_text(patch)
    pins["variants"][variant]={"target":target,"before_sha256":d(before),"after_sha256":d(after),"patch_sha256":d(patch.encode()),"frozen_document_source":{"path":fixture,"sha256":d((repo/fixture).read_bytes())}}
(r/"pins.json").write_text(json.dumps(pins,indent=2)+"\n")
print(json.dumps(pins,indent=2))
