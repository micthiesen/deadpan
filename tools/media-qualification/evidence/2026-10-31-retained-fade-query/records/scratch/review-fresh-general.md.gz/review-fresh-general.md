# Fresh general review

Scope: source-only review-subject.patch against ee9742711868fde9a78bcb945adfd36e67f504d6, evaluated with the supplied scoped shipping sources. Focused on retained fade admission, finite guarded copies, canonical/additional work accounting, and read_retained_controlled carrier lifetimes. No builds, tests, native execution, or source edits.

## Findings

None.

The retained metered constructor preserves the existing range/limit validation and canonical charge formula, while admitting additional per-copy allocations and inspections through the existing QueryBudget/Memory helpers. The bound copy retains the existing clock, placement, constraints, resume and support fields; processing/editorial copies are bounded and their leases are adopted into the returned fade query. read_retained_controlled holds the fade and optional owner query until the synchronous source read and effects finish, then drops them on both success and returned errors. The specified combined phase lower-bound follow-up is excluded as requested.
