from pathlib import Path
import subprocess
s=Path(__file__).resolve().parent
for v in ['scoped','main']:
 build=f'retained-all2-{v}-audio-build'
 subprocess.run(['python3',str(s/'run_target.py'),build,v,'audio','deadpan_audio',f'retained-final2-{v}-audio-deadpan-audio','--test-threads=1'],check=True)
 subprocess.run(['python3',str(s/'run_target.py'),build,v,'audio','deadpan_audio',build+'-list','--list'],check=True)
 subprocess.run(['python3',str(s/'capture_new_pairs.py'),v,build,f'retained-native-pairs2-{v}'],check=True)
