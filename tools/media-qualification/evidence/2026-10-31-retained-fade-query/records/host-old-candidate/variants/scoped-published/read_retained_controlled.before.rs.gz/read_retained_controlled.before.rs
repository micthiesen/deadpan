    fn read_retained_controlled(
        &mut self,
        provider: &mut impl AudioSourceProvider,
        input: &deadpan_plan::AudioOwnerRetainedInput<'_>,
        start: AudioSample,
        frames: u32,
        control: WorkControl<'_>,
        (depth, authored): (usize, bool),
    ) -> Result<ReadBlock, StageAudioError> {
        control.check()?;
        if !input.belongs_to(&self.plan) {
            return Err(StageAudioError::ForeignDomain);
        }
        if depth > self.limits.maximum_depth {
            return Err(StageAudioError::Limit("nested stage depth"));
        }
        if frames == 0 || frames > MAX_OUTPUT_FRAMES {
            return Err(StageAudioError::Range);
        }
        let end = AudioSample(
            start
                .0
                .checked_add(i64::from(frames))
                .ok_or(StageAudioError::Range)?,
        );
        control.spend_plan_work(input.work())?;
        let fades = input.fades(start..end, control.query_limits()?)?;
        control.spend_plan_work(fades.work)?;
        crate::edges::validate_creative_fades(start, frames as usize, &fades.spans)?;
        let owners = if authored {
            let query = input.owners(start..end, control.query_limits()?)?;
            control.spend_plan_work(query.work())?;
            for span in query.spans() {
                deadpan_core::validate_audio_treatment_layers(
                    span.owners().iter().filter_map(|owner| owner.treatments()),
                )?;
            }
            Some(query)
        } else {
            None
        };
        let reservation = if authored { u64::from(frames) * 2 } else { 0 };
        self.make_room(reservation, false, control)?;
        self.active_frames += reservation;
        let result = (|| {
            let raw = self.read_bound_at(
                input.bound(),
                provider,
                input.reference_at(start)?,
                (frames, depth),
                control,
            )?;
            let suppressed = raw
                .suppressed
                .into_iter()
                .map(|range| {
                    Ok(AudioSample(
                        start
                            .0
                            .checked_add(range.start.0)
                            .ok_or(TimeError::Overflow)?,
                    )
                        ..AudioSample(
                            start
                                .0
                                .checked_add(range.end.0)
                                .ok_or(TimeError::Overflow)?,
                        ))
                })
                .collect::<Result<Vec<_>, TimeError>>()?;
            let mut block = ReadBlock {
                start,
                samples: raw.samples,
                dependencies: raw.dependencies,
                relative_depth: raw.relative_depth,
                suppressed,
                exhausted: Vec::new(),
            };
            crate::edges::apply_creative_fades(start, &mut block.samples, &fades.spans)?;
            if let Some(owners) = &owners {
                let gained =
                    authored_gain::original_samples_with_owners(&block, owners, control, &[])?;
                authored_gain::write_finite_samples(&mut block.samples, gained)?;
            }
            control.check()?;
            Ok(block)
        })();
        self.active_frames -= reservation;
        result
    }
