from pathlib import Path
import hashlib, json, difflib
root = Path("/tmp/deadpan-retained-fade-query-admission-2026-10-30/host-old-candidate")
variants = {
    "main-inherited": Path("/Users/michael/Code/deadpan"),
    "scoped-published": Path("/tmp/deadpan-query-groundwork-2026-10-26/scoped"),
}
target = "crates/deadpan-audio/src/bound_reads.rs"
declaration = '\n#[path = "bound_reads/retained_host_baseline.rs"]\nmod retained_host_baseline;\n'
payloads = [
    "crates/deadpan-audio/src/bound_reads/retained_host_baseline.rs",
    "crates/deadpan-audio/src/bound_reads/retained_host_cases.rs",
]
audit = [
    target, "crates/deadpan-audio/src/stages.rs", "crates/deadpan-audio/src/authored_eq.rs",
    "crates/deadpan-audio/src/sound_context_admission.rs", "crates/deadpan-audio/src/stage_projection.rs",
    "crates/deadpan-audio/src/prepared_pcm.rs", "crates/deadpan-audio/src/bound_reads/owner_input.rs",
    "crates/deadpan-audio/src/routed/tests.rs", "crates/deadpan-plan/src/audio_owner_input.rs",
    "crates/deadpan-plan/src/audio_owner_probe.rs", "crates/deadpan-plan/src/audio_context_sharing.rs",
    "native/deadpan-source/tests/audio-fixtures/pcm-stereo-48000.wav",
    "native/deadpan-source/tests/audio-fixtures/pcm-mono-44100.wav",
]
def digest(b): return hashlib.sha256(b).hexdigest()
pins = {
    "schema": "prepare-only-old-retained-host-candidate-v1",
    "published_checkpoint": "ee9742711868fde9a78bcb945adfd36e67f504d6",
    "no_production_function_body_changes": True, "visibility_changes": [], "variants": {},
    "new_files": {p: {"sha256": digest((root / p).read_bytes()), "bytes": (root / p).stat().st_size} for p in payloads},
}
for name, repo in variants.items():
    before = (repo / target).read_bytes()
    assert b"mod retained_host_baseline;" not in before
    after = before + declaration.encode()
    folder = root / "variants" / name
    for state, data in [("before", before), ("after", after)]:
        output = folder / state / target
        output.parent.mkdir(parents=True, exist_ok=True)
        output.write_bytes(data)
    patch = "".join(difflib.unified_diff(before.decode().splitlines(True), after.decode().splitlines(True),
        fromfile="a/" + target, tofile="b/" + target))
    for p in payloads:
        patch += "".join(difflib.unified_diff([], (root / p).read_text().splitlines(True),
            fromfile="/dev/null", tofile="b/" + p))
    (folder / "candidate.patch").write_text(patch)
    evidence = {p: {"sha256": digest((repo / p).read_bytes()), "bytes": (repo / p).stat().st_size} for p in audit}
    stages = (repo / "crates/deadpan-audio/src/stages.rs").read_text()
    begin = stages.index("    fn read_retained_controlled(")
    end = stages.index("\n    /// Transfer hidden", begin)
    witness = stages[begin:end].encode()
    (folder / "read_retained_controlled.before.rs").write_bytes(witness)
    pins["variants"][name] = {
        "repository": str(repo), "before_declaration_sha256": digest(before),
        "after_declaration_sha256": digest(after), "patch_sha256": digest(patch.encode()),
        "read_retained_controlled_sha256": digest(witness), "read_source_pins": evidence,
    }
(root / "pins.json").write_text(json.dumps(pins, indent=2) + "\n")
print(json.dumps({"new_files": pins["new_files"], "variants": {
    k: {f: x[f] for f in ("before_declaration_sha256","after_declaration_sha256","patch_sha256","read_retained_controlled_sha256")}
    for k, x in pins["variants"].items()}}, indent=2))
