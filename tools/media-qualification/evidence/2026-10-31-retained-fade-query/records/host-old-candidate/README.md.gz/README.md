# OLD retained native host witness: prepare-only candidate

Scratch only. No repository files were written. No build, type check, native
execution, capture, expected body, commit or push was performed. Rustfmt parsing
and checking passed. This candidate is not a captured OLD witness yet.

## Files

- `crates/deadpan-audio/src/bound_reads/retained_host_baseline.rs`: actual OLD
  reader producer, exhaustive ReadWork serializer and separate ignored external
  full-body regression test.
- `crates/deadpan-audio/src/bound_reads/retained_host_cases.rs`: five complete
  document/reference setups and actual verified WAV provider construction.
- `variants/{main-inherited,scoped-published}/candidate.patch`: exact declaration
  addition plus both new files for each variant.
- Each variant has exact declaration files before/after and the unchanged
  `read_retained_controlled.before.rs` body.
- `pins.json`: SHA-256 identities for patches, new files, declarations, reviewed
  source and real WAV files in both variants.
- `prepare_manifest.py`: scratch-only patch/manifest generator. Re-running it
  updates pins to then-current source. It applies nothing.

No visibility changes are required. The new child sits under the existing
test-only `bound_reads` Stage module and can access the actual private reader,
ReadWork and controller through its ancestors. Production bodies stay unchanged.
The inherited declaration is already limited to tests on macOS/Linux.

Parent must validate pins, apply only the matching variant patch, typecheck and
fix actual compiler errors before invoking either test. Parent owns binding the
actual binary, complete source manifest and published checkpoint in its wrapper.
Never execute native binaries concurrently.

## Invocation contract

Ignored producer leaf: `capture_old_retained_host_read_baseline_v1`, under
`stages::bound_reads::retained_host_baseline`. Explicit environment fields:

- `DEADPAN_RETAINED_HOST_OUTPUT`: absolute fresh file in an existing `/tmp`
  directory. Its parent is canonicalized; output uses `create_new`.
- `DEADPAN_RETAINED_HOST_VARIANT`: `main-inherited` or `scoped-published`.
- `DEADPAN_RETAINED_HOST_SOURCE_SHA256`: actual parent source-manifest hash,
  64 hex digits.
- `DEADPAN_RETAINED_HOST_PUBLISHED_CHECKPOINT`: parent-verified published
  `ee9742711868fde9a78bcb945adfd36e67f504d6`.

The output is created before capture. A panic can leave an empty partial file;
preserve the failure observation separately and use a new output path after a
repair. No body was generated here.

Separate ignored regression leaf: `retained_host_reads_match_external_old_v1`.
It requires `DEADPAN_RETAINED_HOST_EXPECTED` pointing at an independently
captured OLD file and compares the complete body. Only `variant`,
`source_sha256` and `published_fade_checkpoint` are removed. Work, nested work,
PCM, dependencies, masks and errors are never normalized. Intentional accounting
differences after admission must be adjudicated explicitly by the parent; the
equality scaffold is not an equivalence claim.

## Observation scope

Each fresh scenario obtains one actual carrier: ordinary public retained probe;
actual admitted probe under METERED=false; actual admitted probe under production
Admission; or the actual production owner-selection/sharing helper
`Context::finish_paid_owner_input_admitted`. That helper's input.work precondition
is paid once. No reconstructed ordinary handle stands in for an admitted/shared
handle. Original probe/share guards remain live through the read on the SAME
ReadWork. Owner/input lookup is outside measured ReadWork.

All carriers are exercised with authored=false and authored=true, calling actual
`StageAudio::read_retained_controlled`. Every private ReadBlock field is recorded:
sample bits, dependencies, relative depth, start and complete masks. Complete
documents and public input/raw-domain provenance retain literal input.work and
bound.work. Complete private Plan retained snapshots belong to the separately
frozen Plan witness; no production serialization API was added.

ReadWork serialization exhaustively destructures every field. It retains all
scalar budgets, dependency sets, projection/preflight entries, cached PCM bits,
descriptors, depth and actual Vec capacities. Projection-key payload Debug and
within-snapshot equality are retained without raw pointer addresses. No
cross-snapshot opaque identity claim is made. Controller snapshots include
limits, active/cache amounts, complete prepared blocks/keys, original-input
IDs, processing-plan IDs and state flags. Private Graph original-input cache
payloads are not serialized; these fresh direct-reader scenarios do not enter
that cache.

Actual provider callbacks record arguments, source-call count, full ReadWork
before returning, exact prepared provenance/index/layout and cancellation. The
provider uses the existing AudioSession/PreparedSource adapter with checked real
WAV bytes. WAV SHA-256 and byte count are independent of the document's declared
asset content/qualification IDs; those IDs are not replaced with WAV hashes.

Trials cover small default reads, initial cancellation, expired deadlines,
provider failure/cancellation, depth rejection, invalid/overflow ranges, actual
cache-key lane and local one-frame residency. Residency is lowered after setup,
preserving the actual admitted handle. Provider errors occur only if the actual
reader reaches a source callback. Setup None/errors remain literal.

A successful default read's observed work delta seeds fresh prior-spent-work
trials at that allowance and one less when positive, on the same start/frame
request. Counters are raised only; accepted work is never refunded. Outcomes are
recorded, not assumed. No expected cap is invented. No allocator interception,
peak-allocation proof, scheduler-driven mid-DSP cancellation, partial native
decoder failure or public preparation split is claimed.

Observer snapshots are outside measured calls. Their own allocations and cached
PCM file reads are not admission observations. Unexpected oversized/unreadable
prepared blocks fail capture rather than substituting hashes for full PCM.

## Bounded gaps and remaining proof

Four fixtures copy checked host setups/windows: resumed Root signed history,
fractional Point before delivery, reference gain/mute/order with exterior owner,
and NTSC enclosing processor/silence. The fifth combines checked 44100 mono
source/provider setup from `routed/tests.rs` with the checked Root move/binding
pattern. Genuine Some, fixture validity and PCM remain unverified until parent
execution. The fifth is a combined trial, not a previously passing retained
44100 test. No Point+44100 cross-product is claimed.

Remaining: typecheck both variants; execute serial native OLD captures before
host implementation; adjudicate literal setup outcomes, source-call coverage,
failure boundaries and cleanup; freeze captured bodies and actual binary/source
identities. This OLD witness does not prove allocator admission.
