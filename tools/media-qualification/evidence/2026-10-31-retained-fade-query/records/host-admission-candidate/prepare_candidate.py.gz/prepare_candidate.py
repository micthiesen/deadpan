from pathlib import Path
import json, hashlib, difflib
root=Path("/tmp/deadpan-retained-fade-query-admission-2026-10-30/host-admission-candidate")
main=Path("/Users/michael/Code/deadpan")
source=(main/"crates/deadpan-audio/src/original_request/flattened_work_trace.rs").read_text()
# Keep the proven receipt reconciliation; use separate retained TLS slots.
source=source.replace('    issuer_checks: u64,\n    issuer_work: usize,\n','')
source=source.replace('    Flattened,\n    Processing,\n    Policy,\n    Fade,','    Fade,\n    Owners,')
source=source.replace('            Self::Flattened => 0,\n            Self::Processing => 1,\n            Self::Policy => 2,\n            Self::Fade => 3,','            Self::Fade => 0,\n            Self::Owners => 1,')
start=source.index('#[derive(Clone, Copy, Default)]\nstruct HostEvictions')
end=source.index('pub(in crate::stages) fn reset()',start)
source=source[:start]+'''thread_local! {
    static TRACE: Cell<[Snapshot; 2]> = Cell::new([Snapshot::default(); 2]);
}

fn host_evictions() -> ([usize; 2], bool) {
    super::super::original_request::flattened_work_trace::host_eviction_units()
}

'''+source[end:]
source=source.replace('''        for product in [
            Product::Flattened,
            Product::Processing,
            Product::Policy,
            Product::Fade,
        ] {''','''        for product in [Product::Fade, Product::Owners] {''')
source=source.replace('[Snapshot::default(); 4]','[Snapshot::default(); 2]')
source=source.replace('    HOST_EVICTIONS.with(|counter| counter.set(HostEvictions::default()));\n','')
start=source.index('pub(in crate::stages) fn snapshot()')
end=source.index('fn snapshot_product(',start)
source=source[:start]+'''pub(in crate::stages) fn fade_snapshot() -> Snapshot {
    snapshot_product(Product::Fade)
}

pub(in crate::stages) fn owners_snapshot() -> Snapshot {
    snapshot_product(Product::Owners)
}

'''+source[end:]
source=source.replace('let host = HOST_EVICTIONS.with(Cell::get);','let (host_units, host_overflow) = host_evictions();')
source=source.replace('host.units','host_units').replace('host.overflow','host_overflow')
start=source.index('pub(super) fn issuer_spent(')
end=source.index('pub(super) struct ScopeGuard',start)
source=source[:start]+source[end:]
start=source.index("    pub(super) fn new(control:")
end=source.index('    fn new_product(',start)
source=source[:start]+'''    pub(super) fn new_fade(control: WorkControl<'work>) -> Self {
        Self::new_product(Product::Fade, control)
    }

    pub(super) fn new_owners(control: WorkControl<'work>) -> Self {
        Self::new_product(Product::Owners, control)
    }

'''+source[end:]
source=source.replace('HOST_EVICTIONS.with(|counter| counter.get().units)','host_evictions().0')
(root/"crates/deadpan-audio/src/retained_request/trace.rs").write_text(source)
files=[
"crates/deadpan-audio/src/stages.rs",
"crates/deadpan-audio/src/original_request.rs",
"crates/deadpan-audio/src/original_request/flattened_work_trace.rs",
"crates/deadpan-audio/src/bound_reads/retained_host_baseline.rs",
]
for variant,repo in [("main-inherited",main),("scoped-published",Path("/tmp/deadpan-query-groundwork-2026-10-26/scoped"))]:
    folder=root/"variants"/variant
    for name in files:
        before=(repo/name).read_text()
        after=before
        if name.endswith("/stages.rs"):
            needle='#[path = "original_request.rs"]\nmod original_request;'
            assert after.count(needle)==1
            after=after.replace(needle,needle+'\n\n#[path = "retained_request.rs"]\nmod retained_request;')
            needle='''        let fades = input.fades(start..end, control.query_limits()?)?;
        control.spend_plan_work(fades.work)?;
        crate::edges::validate_creative_fades(start, frames as usize, &fades.spans)?;
        let owners = if authored {
            let query = input.owners(start..end, control.query_limits()?)?;
            control.spend_plan_work(query.work())?;
            for span in query.spans() {'''
            replacement='''        let fades = self.prepare_retained_fades(input, start..end, control)?;
        crate::edges::validate_creative_fades(start, frames as usize, &fades.query().spans)?;
        let owners = if authored {
            let query = self.prepare_retained_owners(input, start..end, control)?;
            for span in query.query().spans() {'''
            assert after.count(needle)==1
            after=after.replace(needle,replacement)
            # Restrict changes to the retained reader body.
            start=after.index('    fn read_retained_controlled(')
            end=after.index('\n    /// Transfer hidden',start)
            body=after[start:end]
            body=body.replace('&fades.spans','&fades.query().spans')
            body=body.replace('authored_gain::original_samples_with_owners(&block, owners, control, &[])?;',
                              'authored_gain::original_samples_with_owners(&block, owners.query(), control, &[])?;')
            assert body.count('        self.active_frames -= reservation;\n        result')==1
            body=body.replace('        self.active_frames -= reservation;\n        result',
                              '        self.active_frames -= reservation;\n        drop(owners);\n        drop(fades);\n        result')
            after=after[:start]+body+after[end:]
        elif name.endswith("/original_request.rs"):
            needle='''    with_legacy_fade_queries(|| {
        with_legacy_policy_queries(|| {
            with_legacy_processing_queries(|| with_legacy_flattened_queries(action))
        })
    })'''
            assert after.count(needle)==1
            after=after.replace(needle,'''    super::retained_request::with_legacy_retained_queries(|| {
        with_legacy_fade_queries(|| {
            with_legacy_policy_queries(|| {
                with_legacy_processing_queries(|| with_legacy_flattened_queries(action))
            })
        })
    })''')
            after=after.replace('Select the literal OLD constructors for all four products in one Original preparation.',
                                'Select the literal OLD Original and nested retained constructors.')
        elif name.endswith("/flattened_work_trace.rs"):
            needle='pub(in crate::stages) fn reset()'
            assert after.count(needle)==1
            after=after.replace(needle,'''// The retained trace reads this same accepted-eviction receipt without new slots.
pub(in crate::stages) fn host_eviction_units() -> ([usize; 2], bool) {
    let host = HOST_EVICTIONS.with(Cell::get);
    (host.units, host.overflow)
}

'''+needle)
        else:
            needle='    assert_eq!(matrix(), body(expected));'
            assert after.count(needle)==1
            after=after.replace(needle,'''    let actual = retained_request::with_legacy_retained_queries(matrix);
    assert_eq!(actual, body(expected));''')
            after=after.replace("    assert_eq!(matrix(), expected);",
                "    assert_eq!(retained_request::with_legacy_retained_queries(matrix), expected);")
            after=after.replace("    let mut value = matrix();",
                "    let mut value = retained_request::with_legacy_retained_queries(matrix);")
            after += '\n#[path = "retained_host_admission.rs"]\nmod admission_tests;\n'
        for state,text in [("before",before),("after",after)]:
            target=folder/state/name
            target.parent.mkdir(parents=True,exist_ok=True)
            target.write_text(text)
