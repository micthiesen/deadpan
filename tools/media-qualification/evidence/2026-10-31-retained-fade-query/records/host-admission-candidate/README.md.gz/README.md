# Retained host admission: scratch candidate

No actual repository files were written. No build, type check, native execution,
capture, expected-body generation, commit or push was performed. Parent owns
integration and serial native execution. The initial OLD candidate/pins remain
unchanged in the sibling host-old-candidate directory.

The parent reports independently equal OLD native bodies: 25,746,494 bytes,
SHA-256 838a7165fe4fd9142450568158359b00b05d6cd867aceaef77bfbd49e2c52f75.
That is external evidence supplied by the parent, not a capture made here.

## Application and pins

Each variants/main-inherited and variants/scoped-published directory has exact
current before/after files and candidate.patch. pins.json hashes every changed
before/after file, each new file and both patches. The variants currently have
identical patches. Validate before hashes against current shared files before
applying; do not overwrite concurrent changes or reapply old fixture versions.

New files:

- crates/deadpan-audio/src/retained_request.rs
- crates/deadpan-audio/src/retained_request/trace.rs
- crates/deadpan-audio/src/bound_reads/retained_host_admission.rs

Changed files:

- stages.rs: private child declaration and retained reader integration only.
- original_request.rs: whole Original legacy helper also selects retained legacy.
- original_request/flattened_work_trace.rs: tiny cfgtest accessor for the existing
  accepted host-eviction receipt. The frozen four-product TLS shape is unchanged.
- bound_reads/retained_host_baseline.rs: explicit retained legacy wrappers for
  OLD producer, ignored external regression and frozen twentieth oracle; child
  test declaration. The actual fixtures, serializers and expected body stay intact.

Rustfmt parsing/checking and read-only patch application checks are the only
verification performed here. No compile or test success is claimed. The future
Plan fades_admitted API is supplied by another worker; the host candidate assumes
the admission-design.md signature and existing carrier API.

## Lifetime and accounting

The retained reader preserves actual order: cancellation/deadline, foreign-plan,
depth, frames, checked end, then the exact pre-existing input.work debit. Each
constructor obtains fresh query_limits immediately before construction.

A short Admission borrow creates the real admitted retained fade carrier. That
borrow ends before validation and later owner construction. Authored reads create
an independent admitted owner-query carrier under another short Admission borrow.
Neither successful receipt is billed again. The original input.work debit is
never stripped, normalized or refunded, including admitted/shared input origins.

Both named carriers survive creative validation, owner-treatment validation,
required PCM room, bound/raw-domain construction, source/nested I/O, creative
application, authored gain and the final control check. active_frames is released
as before, then owners and fades are explicitly dropped before returning the
ReadBlock. Earlier failures unwind the same named carriers. No local request is
cached or placed in Graph. There is no new public prepared/foreign-controller API,
issuer-switch fee, cap change, cache change or recursive-product admission claim.

The new private Fade/Owners enums exist to keep the explicit cfgtest legacy
branch literal while production owns the admitted values. The same synchronous
controller/control construct and consume them; no detached issuer token is needed.

## Separate receipt trace and legacy scopes

The retained cfgtest trace has its own two TLS slots: fades and owners. It retains
plan/cache lanes, completed canonical/additional receipts, accepted partial work,
nesting/invariant flags and host eviction work. It reads the EXISTING host eviction
counter through the narrow accessor, subtracting actual accepted eviction fees
from constructor deltas. No duplicate eviction counter or runtime hook is added.
The existing Root/Domain four-slot trace and its serialized shape stay unchanged.

with_legacy_retained_queries selects both literal OLD retained fade and owner
constructors, restoring the previous mode on return or unwind. Narrow
with_legacy_fade_queries continues to control Root/Domain fades independently.
with_legacy_original_queries now chains retained legacy so existing full Original
OLD observations also preserve nested retained reads. The OLD host producer and
both OLD full-body regression entry points explicitly use retained legacy.

## Test scaffold and remaining proof

The new child reuses the actual frozen host fixture, scenario and provider helpers,
including the parent's corrected SHA loop/resume i64 fixture. It creates no oracle.
Four bounded tests cover:

- Real Root and Point WAV callbacks with ordinary/shared carriers, authored false
  and true, source success, provider failure and provider-triggered cancellation.
  They require local metadata above caller setup residency during callbacks and
  cleanup before returned PCM escapes.
- Existing cancellation/deadline/depth/range/residency/work/cache-lane boundaries,
  actual receipts and final cleanup.
- Separately observed NEW fade/owner totals to choose genuine constructor
  one-short trials. Later owner refusal must preserve the completed fade receipt,
  reach no source callback and release the earlier carrier without refunding work.
- Retained legacy isolation, whole Original legacy chaining and mode restoration.

Parent still owes compilation on both variants, these real native tests, the
unchanged twentieth OLD oracle under the explicit legacy scope, and all required
project gates/prior frozen oracles. Test assumptions about exact source reachability
and one-short boundaries are unexecuted and must be adjudicated on actual results.

Specific coverage still needed beyond this scaffold: direct foreign-plan priority;
real original-input eviction during retained constructor admission; an existing
Graph/original cache hit bypassing the retained constructor; independent peaks and
exact allocation refusal phases (owned by the Plan proof). Existing core/raw-domain,
Point signal, Signal/Tape/Mix, native workspace and Graph containers remain outside
this admission claim. No actual allocator or peak-memory proof follows from the
receipt trace alone.
