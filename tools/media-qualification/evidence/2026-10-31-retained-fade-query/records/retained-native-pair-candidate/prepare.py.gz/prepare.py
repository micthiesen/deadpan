from pathlib import Path
import hashlib,difflib,json
b=Path('/tmp/deadpan-retained-fade-query-admission-2026-10-30/retained-native-pair-candidate')
roots={'main':Path('/Users/michael/Code/deadpan'),'scoped':Path('/tmp/deadpan-query-groundwork-2026-10-26/scoped')}
p='crates/deadpan-audio/src/bound_reads/retained_host_baseline.rs'
sha=lambda v:hashlib.sha256(v).hexdigest()
m={'status':'prepare-only; no source mutations/build/native/test/capture','variants':{}}
for variant,root in roots.items():
 old=(root/p).read_text()
 target=b/'before'/variant/p;target.parent.mkdir(parents=True,exist_ok=True);target.write_text(old)
 anchor='    let before_calls = provider.calls;\n    let result = renderer.read_retained_controlled('
 assert old.count(anchor)==1
 new=old.replace(anchor,'    let before_calls = provider.calls;\n    pairs::before_read(retained, request_start, request_frames, authored, fault);\n    let result = renderer.read_retained_controlled(',1)
 assert 'mod pairs;' not in old
 new+='\n#[path = "retained_host_pairs.rs"]\nmod pairs;\n'
 target=b/'after'/variant/p;target.parent.mkdir(parents=True,exist_ok=True);target.write_text(new)
 patch=''.join(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile='a/'+p,tofile='b/'+p))
 (b/f'helper-{variant}.patch').write_text(patch)
 m['variants'][variant]={'before_sha256':sha(old.encode()),'after_sha256':sha(new.encode()),'patch_sha256':sha(patch.encode()),
  'read_pins':{p:sha((root/p).read_bytes()) for p in [
   'crates/deadpan-audio/src/bound_reads/retained_host_admission.rs',
   'crates/deadpan-audio/src/bound_reads/retained_host_cases.rs',
   'crates/deadpan-audio/src/retained_request.rs',
   'crates/deadpan-audio/src/retained_request/trace.rs',
   'crates/deadpan-audio/src/original_request/flattened_work_trace.rs',
   'crates/deadpan-audio/src/stages.rs',
   'crates/deadpan-audio/tests/fixtures/retained-host-read-baseline-v1/snapshot.json',
  ]}}
p='crates/deadpan-audio/src/bound_reads/retained_host_pairs.rs'
text=(b/'new'/p).read_text()
patch=''.join(difflib.unified_diff([],text.splitlines(True),fromfile='/dev/null',tofile='b/'+p))
(b/'new-file.patch').write_text(patch)
m['new_source']={'path':p,'sha256':sha(text.encode()),'bytes':len(text.encode())}
m['new_file_patch_sha256']=sha(patch.encode())
(b/'pins.json').write_text(json.dumps(m,indent=2)+'\n')
print(json.dumps({'helper_patches':{v:d['patch_sha256'] for v,d in m['variants'].items()},'new_source':m['new_source'],'new_file_patch_sha256':m['new_file_patch_sha256']},indent=2))
