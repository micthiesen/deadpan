# Retained native NEW/OLD pairs candidate

Scratch-only. No actual repository edits, Cargo/rustc/native execution, captures, expected-body generation or Git operations were performed. Parent owns integration and serial native verification.

Initial source/patch bytes are held stable after compiler handoff.

## Integration and immutable authority

new-file.patch adds crates/deadpan-audio/src/bound_reads/retained_host_pairs.rs as a child of retained_host_baseline. Apply only matching helper-main.patch or helper-scoped.patch. The existing test helper gains one TLS-Off before_read call and the child declaration. Existing matrix, scenario, snapshots, fault handling, native reader body, legacy wrapper, frozen regression and expected fixture remain unchanged.

Exact before/after copies and Main/Scope source pins are in before/, after/ and pins.json.

- Helper patches: f05127814c3cad5dd43a307225a0d040c74596cc85afe75c878c65032a70e081
- New-file patch: 390824a413c3c58e427296c6ce05658085cc30f76df1cb778cbc26621f042fd9
- New source: 9c0f1e04569829030a87a95c6030a2b698687824d9db1d32cec4c991423b065a

The candidate checks the immutable frozen host fixture SHA-256 before parsing it: 838a7165fe4fd9142450568158359b00b05d6cd867aceaef77bfbd49e2c52f75. No expected data is generated.

The fixed OLD set has 744 real operations, all with Some setup: 224 default successes, 40 cache-lane successes, eight sets of 40 early/source/shape errors, 40 one-resident-frame cases (38 Error, two Ok), 40 cache-minimum-allowance failures, and 80 exact/one-short prior-work requests. The producer decodes each literal frozen request, mode and old derived allowance. It does not recompute tight boundaries from NEW total or raise any cap.

## Exact actual provenance

Each NEW scenario runs the existing real setup in its recorded mode: ordinary retained probe, actual admitted false/true probe, or the production selected/shared helper. Its own real guard stays alive through the reader.

Bounded paired tests additionally rerun the actual legacy scenario under with_legacy_retained_queries and require its COMPLETE result JSON to equal the frozen operation, including every input, work counter, controller snapshot, source event and PCM bit. OLD and NEW scenarios are independent cold executions in the same recorded input mode, not the same pointer or a reconstruction from serialized retained metadata.

NEW input, retained bound/input work, setup receipt, before_setup, before_injection, before_read/controller and injected prior counter must equal the exact frozen OLD fields. No nested work scalar or input provenance is stripped. The separate Plan oracles remain authority for the full private retained payload.

## Independent constructor witness and receipts

The optional before_read helper is Off during ordinary frozen regression. When paired mode is active, it inspects the exact borrowed retained operand immediately before the measured host reader:

- ordinary retained.fades over the actual requested samples with default limits, recording literal work and full public fade query;
- ordinary retained.owners for authored=true, recording literal work and span count;
- actual retained.work and bound.work.

These are pure Plan calls, outside the measured ReadWork delta. No media/source callback is made. Early cancellation/deadline/depth/shape/overflow requests are not inspected because the real host must reject before constructors.

The helper resets only test trace counters immediately before the real read. It does not reset, reduce or mutate ReadWork, live leases, caps, source admission or caches.

For every completed NEW local fade/owner product, its canonical receipt must equal that actual ordinary constructor's work on the exact borrowed handle. Successful canonical/additional, failed accepted partial_work, and actual host_eviction_work remain separate. Every product/lane checks:

accepted_work == canonical_units + additional_units + partial_work + host_eviction_work.

A failed product has no final carrier receipt. The candidate records its actual accepted prefix and does not invent a canonical/additional split or recursively normalize work. The full new ReadWork snapshots and old/new plan/cache deltas stay visible.

Bounded default pairs use actual old and new eviction trace receipts and require zero because these fresh scenarios have no preexisting evictable entries. Their complete NEW-minus-OLD debit must equal independent successful additional receipts exactly. The other worker owns actual eviction/hit/foreign-plan fixtures; this candidate does not duplicate or weaken those tests.

## Normal tests

new_native_success_matches_full_old_pcm_masks_dependencies_depth_and_explicit_fees selects one legal recorded window (index1) in every five real WAV fixtures, all four input modes and both authored settings: 40 NEW/OLD pairs.

It requires:

- complete output JSON equality, covering every f32 bit, start/frame count, suppressed/exhausted masks, dependencies and relative depth;
- exact source event data and count/provenance/index/layout;
- exact controller/cache state after return/drop;
- all non-debit ReadWork fields after return/drop unchanged, including caller live metadata;
- explicit NEW-minus-OLD plan/cache fee reconciliation, not a normalized snapshot;
- positive additional metadata at actual provider callbacks;
- local lease release before return, caller release after handle drop, zero active frames/disk after result drop.

actual_early_and_source_failures_preserve_old_priority_with_separate_partial_receipts selects two fixtures, ordinary/shared origins, authored false/true, and eight existing error scenarios: 64 NEW/OLD pairs.

It requires exact complete typed-error parity and provider-call priority for initial cancel, deadline, depth, zero/above-limit frames, signed overflow, provider failure and provider cancellation. Early calls have zero constructor receipts and no source I/O; actual source failures occur after completed fade admission. No new resource-error alternative is accepted by these normal tests.

All caps and defaults are the existing real values. Runtime success/count assertions are owed to parent execution, not claimed here.

## Ignored NEW capture

capture_new_retained_host_pairs_v1 replays the exact 744 OLD requests through NEW reader execution, and emits full NEW operation data, independent ordinary metadata witnesses, receipts, old operation index/request/mode, accounting and comparison classification.

It references the immutable OLD body by exact SHA/index rather than duplicating or regenerating it. OLD tight work or residency scenarios can legitimately refuse earlier after actual admission. The capture preserves full errors and fees and classifies such differences as new_refusal/different_typed_error. It does not declare every classification acceptable. Successful payload differences or new successes are explicitly labelled for review. The parent must review every classification and retain legitimate resource differences; capture success alone is not complete semantic qualification.

This capture does not rerun all744 OLD operations: the separate frozen OLD regression and bounded exact legacy pairs provide that authority. Its old eviction receipt is explicitly null/not rerun outside bounded pairs; no old zero is invented.

Environment:

- DEADPAN_RETAINED_HOST_PAIRS_OUTPUT: new absolute file whose existing parent resolves below /tmp; create_new refuses overwrite.
- DEADPAN_RETAINED_HOST_VARIANT: main-inherited or scoped-published.
- DEADPAN_RETAINED_HOST_SOURCE_SHA256: actual complete NEW source manifest SHA-256.

There is no NEW expected-body fixture or normalization workflow.

## Test paths and owed checks

Parent must use its actual executable --list before counting execution. Intended paths from current module declarations:

stages::bound_reads::retained_host_baseline::pairs::new_native_success_matches_full_old_pcm_masks_dependencies_depth_and_explicit_fees

stages::bound_reads::retained_host_baseline::pairs::actual_early_and_source_failures_preserve_old_priority_with_separate_partial_receipts

stages::bound_reads::retained_host_baseline::pairs::capture_new_retained_host_pairs_v1

Only the capture is ignored. Use --ignored --exact for that manual capture. Zero-test output is not evidence.

Performed: rustfmt parse/check of the new source and scratch-only dry runs of all patches. No compilation/runtime claim.

Owed: parent type/borrow/lint checking, actual native test counts/outputs, continued exact frozen OLD regression, NEW capture and review of every changed tight-resource outcome, independent dual-root NEW equality where appropriate, real eviction/cache/foreign tests from their owner and authored-tile receipt qualification from its owner.

The normal pair fixture set is cold and bounded; it does not claim warm cache-hit construction absence, real cache pressure, foreign-plan rejection, or arbitrary native preparation admission. No recursive raw/signal query scope or DSP behavior was changed.
