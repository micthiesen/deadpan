from pathlib import Path
import gzip,hashlib,json
s=Path(__file__).resolve().parent
repo=Path('/Users/michael/Code/deadpan')
dest=repo/'tools/media-qualification/evidence/2026-10-31-retained-fade-query'
assert not(dest/'inventory.json').exists()
audit=json.loads((s/'final-audit.json').read_text());assert audit['all_terminal']
prior=repo/'tools/media-qualification/evidence/2026-10-30-fade-original-query/inventory.json'
prior_sha='ad18fd9f8d47a7dcb948e86e997b7200608438aad2772c08c5881f4d936a02fc'
assert hashlib.sha256(prior.read_bytes()).hexdigest()==prior_sha
allowed={'.rs','.json','.py','.md','.patch','.stdout','.stderr','.txt','.sha256','.toml','.sh'}
rows=[]
for p in sorted(s.rglob('*')):
 if not p.is_file()or p.suffix not in allowed:continue
 rel=p.relative_to(s)
 if rel.name in {'qualification-draft.md','published-evidence.json','index-source-entries.txt'}:continue
 data=p.read_bytes()
 if p.suffix=='.json':
  obj=json.loads(data)
  if isinstance(obj,dict)and'command'in obj and'started_at'in obj:
   assert'exit_code'in obj and obj['sources_unchanged']and obj['binaries_unchanged'],str(p)
 target=(dest/'records'/rel).with_name(rel.name+'.gz')
 target.parent.mkdir(parents=True,exist_ok=True)
 assert not target.exists()
 packed=gzip.compress(data,mtime=0);target.write_bytes(packed)
 rows.append({'path':str(target.relative_to(dest)),'bytes':len(packed),'sha256':hashlib.sha256(packed).hexdigest(),'expanded_bytes':len(data),'expanded_sha256':hashlib.sha256(data).hexdigest()})
manifest={'schema_version':1,'base_revision':(s/'base-revision.txt').read_text().strip(),
'scope':'Standalone retained-fade admission with literal stored work, finite Bound/processing/editorial copies and overlapping shared geometry; native retained fade/owner carrier lifetime and exact accepted receipts. No caps, prior weights, refunds, persisted formats, DSP or requirement/gate statuses change. Raw-domain reconstruction, later Point signal cloning, recursive products and whole preparation stay open. General sound-bearing Split remains disabled.',
'prior_original_fade_inventory':{'path':'../2026-10-30-fade-original-query/inventory.json','sha256':prior_sha},
'exclusions':'Native executables and nontext files excluded. The whole repository index entry list is excluded; exact 45-file shipping patch, selected staged-blob equality and source tree are retained. Owned baseline/current/candidate source, complete immutable OLD captures, initial/current NEW captures, source/binary/media/stream pins, commands/environment/timing, failed attempts and reviews are retained. The coincident-edge ordinary supplement is truthfully post-implementation, with the unchanged ordinary algorithm pinned to the prior publication. Nonzero attempts receive no acceptance credit. Native pass reuse requires identical final executable bytes.',
'files':rows}
p=dest/'inventory.json'
assert {str(x.relative_to(dest))for x in dest.rglob('*')if x.is_file()}=={r['path']for r in rows}
p.write_text(json.dumps(manifest,indent=2)+'\n')
for row in rows:
 packed=(dest/row['path']).read_bytes();plain=gzip.decompress(packed)
 assert len(packed)==row['bytes']and hashlib.sha256(packed).hexdigest()==row['sha256']
 assert len(plain)==row['expanded_bytes']and hashlib.sha256(plain).hexdigest()==row['expanded_sha256']
result={'files':len(rows),'stored_bytes':sum(r['bytes']for r in rows),'expanded_bytes':sum(r['expanded_bytes']for r in rows),'inventory_sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
(s/'published-evidence.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result))
