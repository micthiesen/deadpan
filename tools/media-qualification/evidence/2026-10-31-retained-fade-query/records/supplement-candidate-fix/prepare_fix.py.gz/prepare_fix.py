from pathlib import Path
import difflib,hashlib,json
base=Path('/tmp/deadpan-retained-fade-query-admission-2026-10-30/supplement-candidate-fix')
roots={'main':Path('/Users/michael/Code/deadpan'),'scoped':Path('/tmp/deadpan-query-groundwork-2026-10-26/scoped')}
path='crates/deadpan-plan/src/audio_owners/retained_fade_supplement.rs'
insert='''        if name == "fade/repeat_fragment/marked" {
            output.push(captured_marked_fragment(descriptor));
            return;
        }
'''
helper='''fn captured_marked_fragment(descriptor: &Value) -> Value {
    let before = ProjectDocument::from_json(
        &descriptor["fixture_source"]["document"].to_string(),
    ).unwrap();
    let timing = AudioTimingId {
        allocation: RevisionId::new("retained-supplement-capture").unwrap(),
        ordinal: 0,
    };
    let mut source = json!({
        "name":"retained_supplement/captured_marked_repeat_fragment",
        "source":"exact checked fade/repeat_fragment/marked plus public capture_unbound_audio_bindings and checked installation",
        "parent":descriptor,
        "before_document":before,
        "capture_timing":timing,
        "selection":{"node":"voice","kind":"Node","observed_at":6400}
    });
    let bindings = match capture_unbound_audio_bindings(&before, timing) {
        Ok(value) => value,
        Err(error) => {
            source["setup_result"] = json!("CaptureError");
            source["error"] = snapshot::error_json(&PlanError::from(error));
            return source;
        }
    };
    let mut wire = serde_json::to_value(&before).unwrap();
    wire["audio_bindings"] = serde_json::to_value(&bindings).unwrap();
    source["captured_bindings"] = serde_json::to_value(&bindings).unwrap();
    let captured = match ProjectDocument::from_json(&wire.to_string()) {
        Ok(value) => value,
        Err(error) => {
            source["setup_result"] = json!("CheckedInstallationError");
            source["error"] = snapshot::error_json(&PlanError::from(error));
            return source;
        }
    };
    source["document"] = serde_json::to_value(&captured).unwrap();
    let plan = match RenderPlan::compile(&captured) {
        Ok(value) => value,
        Err(error) => {
            source["setup_result"] = json!("CompileError");
            source["error"] = snapshot::error_json(&error);
            return source;
        }
    };
    selected(
        FadeParent::Root(&plan), source, "voice", crate::AudioOwnerKind::Node, 6400,
        &[("second_marked_play",6400,12800),("repeat_seam",6399,6401)],
    )
}

'''
m={'status':'prepare-only fix after actual WrongNodeKind receipt; no source/build/test/capture','variants':{}}
for v,r in roots.items():
 old=(r/path).read_text()
 b=base/'before'/v/path;b.parent.mkdir(parents=True,exist_ok=True);b.write_text(old)
 anchor='''        let Some((node, kind, at, windows)) = (match name {'''
 assert old.count(anchor)==1
 new=old.replace(anchor,insert+anchor,1)
 start=new.index('            let before =',new.index('if name == "fade/gap_bound/root"'))
 end=new.index('\n        }\n    });',start)
 invalid=new[start:end]
 assert 'Command::SetEditorialEdges' in invalid and 'marked_bound_repeat_child' in invalid
 new=new[:start]+new[end:]
 anchor='fn cases() -> Vec<Value> {'
 assert new.count(anchor)==1
 new=new.replace(anchor,helper+anchor,1)
 a=base/'after'/v/path;a.parent.mkdir(parents=True,exist_ok=True);a.write_text(new)
 m['variants'][v]={'before_sha256':hashlib.sha256(old.encode()).hexdigest()}
(base/'pins.json').write_text(json.dumps(m,indent=2)+'\n')
