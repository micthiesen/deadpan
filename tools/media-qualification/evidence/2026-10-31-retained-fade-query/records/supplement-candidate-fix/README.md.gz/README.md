# Additive retained OLD supplement constructor fix

Prepare-only. No actual repository source mutation, build, test execution, capture, golden generation or oracle change was performed. The parent owns integration after active source guards end.

Use only the matching fix-main.patch or fix-scoped.patch. Both patches currently have SHA-256 150a0140793cf9428415c738dd0f0873b7f2d120f4d663a3fac531a7553157ae. The complete actual before file is 0d916693710f79bd5e76ac820364516fb3fb408cb79a32e8f006fb7395d7ae1b; the complete suggested after file is 9f937e630c526b6b2358bb3dd9d11c0543aeda8e6cf214951b41cd5f3befd6ce. Separate exact before/after trees and pins.json preserve each authority. Recheck current source before application if another owner changes it.

## Actual failure and fix

The first supplement diagnostic stopped at the invalid SetEditorialEdges command on the ordinary Hold child. The public command requires a NodeKind::Retime with RetimePurpose::Partition. That preserved WrongNodeKind receipt remains valid; it did not evaluate the remaining lane predicates.

This fix removes that invalid command/setup. It adds the already checked fade/repeat_fragment/marked fixture from fade_query_cases::repeat_editorial, which was built by the real WrapRepeat and SetEditorialEdges commands. It parses that visitor's complete document, calls the public capture_unbound_audio_bindings with an explicit fresh timing identity, installs the returned actual AudioBindingState through checked ProjectDocument::from_json, compiles it and selects the actual voice owner at AudioSample(6400), the second play.

All complete before/document/timing/returned bindings/selection descriptors accompany the case. Capture, checked-installation or compile errors are serialized literally, followed by the existing selection/input/probe Some/None/rejection handling. The factory does not force Some or manufacture a retained value. The same four parent provenance modes and literal work serializers remain in use.

There are still seven proposed selector setups. No required coverage predicate was removed or weakened. The separate coverage diagnostic must still demonstrate every declared owning lane from actual Some metadata.

## Corrected static reasoning

The earlier design/README statement that this exact marked fragment necessarily stops at an opaque Preserve was incorrect. Its mapping is 2..6 and duration is4, so Preserve is unity and pitch.processes(mapping.duration()==duration) is false.

The actual public capture implementation:
- captures Source/Hold recipes and nontransparent processing Retime recipes;
- traverses this unity fragment without making it opaque;
- captures its Hold voice under the real repeat arguments/births;
- leaves the fragment's existing editorial marker and repeated occurrence path in the checked document.

The actual capture walker can then descend through the unity Partition to the voice binding. This is a concrete public route for a retained Some carrying editorial and repeat data. Runtime factory availability and exact lane contents remain owed until the parent executes the diagnostic/capture. This correction does not claim that every Preserve is transparent, or that the unbound marked fixture alone supplies a retained operand.

No genuinely unreachable owning lane has been demonstrated yet. Other proposed lanes have not completed their diagnostic because the earlier invalid setup panicked first. If a real attempted public constructor later returns None/error or a zero lane, preserve that result and investigate the exact factory path. Private finite-clone unit coverage may use an explicitly synthetic finite value separately, but cannot substitute for an OLD/provider retained oracle.

## Verification and integration

Performed:
- rustfmt parse of both complete after files.
- Both minimal patches dry-run against their exact scratch before copies.
- Static reads of public capture traversal, command validation and the checked marked-fragment factory.

Owed:
- Actual compile/typecheck and exact ignored coverage diagnostic.
- Actual Some/None and nonempty editorial/repeat predicates.
- Independent Main/Scope additive capture, equality/regression review and later supplement freeze.

Existing test names/declarations are unchanged. The intended diagnostic remains:

plan::audio_owners::wide_gain_query_admission_tests::retained_fade_baseline::supplement::actual_retained_supplement_reaches_owning_lanes

Use the parent's actual --list path and --ignored --exact. The original frozen retained v1 matrix, v1 body, v1 regression and all 18 existing oracles are unchanged.
