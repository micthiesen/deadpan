use super::*;

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
struct Event {
    operation: &'static str,
    units: usize,
    accepted: bool,
}
struct Recording {
    policy: Policy<true>,
    events: Vec<Event>,
    states: Vec<Rc<RefCell<PolicyState>>>,
    merges: usize,
    rotate_merge: Option<usize>,
}
impl Recording {
    fn new() -> Self {
        let policy = Policy::new(usize::MAX);
        Self {
            states: vec![Rc::clone(&policy.0)],
            policy,
            events: Vec::new(),
            merges: 0,
            rotate_merge: None,
        }
    }
    fn remember(&mut self) {
        if !Rc::ptr_eq(self.states.last().unwrap(), &self.policy.0) {
            self.states.push(Rc::clone(&self.policy.0));
        }
    }
    fn assert_released(&self) {
        for state in &self.states {
            assert_eq!(state.borrow().live, 0);
        }
        assert_eq!(
            self.states.iter().map(|state| state.borrow().forwarded).sum::<usize>(),
            self.events.iter().filter(|event| event.accepted && event.operation == "spend")
                .map(|event| event.units).sum::<usize>(),
            "accepted failed-prefix work is retained on its actual issuer"
        );
    }
}
impl AudioSoundContextAdmission for Recording {
    const METERED: bool = true;
    type Error = PlanError;
    type Issuer = usize;
    type Lease = Lease;
    fn issuer(&self) -> usize {
        self.policy.issuer()
    }
    fn spend(&mut self, units: usize) -> Result<(), PlanError> {
        let result = self.policy.spend(units);
        self.events.push(Event { operation: "spend", units, accepted: result.is_ok() });
        self.remember();
        result
    }
    fn reserve(&mut self, layout: Layout) -> Result<Lease, PlanError> {
        let result = self.policy.reserve(layout);
        self.events.push(Event { operation: "reserve", units: layout.size(), accepted: result.is_ok() });
        self.remember();
        result
    }
    fn merge(&mut self, target: &mut Lease, source: &mut Lease) {
        self.policy.merge(target, source);
        self.merges += 1;
        self.events.push(Event { operation: "merge", units: 0, accepted: true });
        if self.rotate_merge == Some(self.merges) {
            self.policy.rotate(usize::MAX);
        }
        self.remember();
    }
}
pub(super) fn check(retained: &AudioOwnerRetainedInput<'_>, row: &Value) -> usize {
    let requested = range(row);
    let mut baseline = Recording::new();
    let query = retained.fades_admitted(requested.clone(), Default::default(), &mut baseline).unwrap();
    assert_true(&query, &row["output"]["query"], &baseline.policy);
    drop(query);
    baseline.assert_released();
    let expected = baseline.events;
    let mut attempts = 0;
    for operation in ["spend", "reserve"] {
        let mut ordinal = 0;
        for (index, event) in expected.iter().enumerate().filter(|(_, event)| event.operation == operation) {
            ordinal += 1;
            let mut recorder = Recording::new();
            if operation == "spend" {
                recorder.policy.0.borrow_mut().refuse_work_call = Some(ordinal);
            } else {
                recorder.policy.0.borrow_mut().refuse_reservation = Some(ordinal);
            }
            let result = retained.fades_admitted(requested.clone(), Default::default(), &mut recorder);
            let expected_error = if operation == "spend" { "test wide work refusal" } else { "test wide reservation refusal" };
            assert!(matches!(&result, Err(PlanError::AudioQueryLimit(label)) if *label == expected_error));
            drop(result);
            assert_eq!(&recorder.events[..index], &expected[..index]);
            assert_eq!(recorder.events.len(), index + 1, "no later callback after refusal");
            assert_eq!(recorder.events[index], Event { accepted: false, ..*event });
            recorder.assert_released();
            attempts += 1;
        }
    }
    for operation in ["spend", "reserve", "merge"] {
        let mut ordinal = 0;
        for (index, _) in expected.iter().enumerate().filter(|(_, event)| event.operation == operation) {
            ordinal += 1;
            let mut recorder = Recording::new();
            match operation {
                "spend" => recorder.policy.0.borrow_mut().rotate_work_call = Some(ordinal),
                "reserve" => recorder.policy.0.borrow_mut().rotate_reservation = Some(ordinal),
                "merge" => recorder.rotate_merge = Some(ordinal),
                _ => unreachable!(),
            }
            let result = retained.fades_admitted(requested.clone(), Default::default(), &mut recorder);
            assert!(matches!(&result, Err(PlanError::InvalidPlan(_))), "{operation} {ordinal}");
            drop(result);
            assert_eq!(recorder.events, expected[..=index], "accepted rotation callback is the last");
            assert_eq!(recorder.states.len(), 2);
            recorder.assert_released();
            attempts += 1;
        }
    }
    let mut accepted = 0;
    for event in expected.iter().filter(|event| event.operation == "spend") {
        let mut recorder = Recording::new();
        recorder.policy.0.borrow_mut().cancel_after = Some(accepted);
        let result = retained.fades_admitted(requested.clone(), Default::default(), &mut recorder);
        assert!(matches!(&result, Err(PlanError::AudioQueryLimit("test wide cancellation"))));
        drop(result);
        let failed = recorder.events.last().unwrap();
        assert_eq!((failed.operation, failed.accepted), ("spend", false));
        assert_eq!(&recorder.events[..recorder.events.len()-1], &expected[..recorder.events.len()-1]);
        recorder.assert_released();
        attempts += 1;
        accepted += event.units;
    }
    attempts
}
