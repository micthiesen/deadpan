from pathlib import Path
import json,hashlib
s=Path(__file__).resolve().parent;c=s/'host-old-candidate';pins=json.loads((c/'pins.json').read_text())
roots={'main-inherited':Path('/Users/michael/Code/deadpan'),'scoped-published':Path('/tmp/deadpan-query-groundwork-2026-10-26/scoped')}
sha=lambda b:hashlib.sha256(b).hexdigest();decl='crates/deadpan-audio/src/bound_reads.rs'
for variant,root in roots.items():
 for name,pin in pins['variants'][variant]['read_source_pins'].items():
  data=(root/name).read_bytes();assert len(data)==pin['bytes']and sha(data)==pin['sha256'],(variant,name)
 for name,pin in pins['new_files'].items():
  assert not(root/name).exists();data=(c/name).read_bytes();assert sha(data)==pin['sha256']and len(data)==pin['bytes'],name
for variant,root in roots.items():
 before=(root/decl).read_bytes();after=(c/'variants'/variant/'after'/decl).read_bytes()
 assert sha(before)==pins['variants'][variant]['before_declaration_sha256']
 assert sha(after)==pins['variants'][variant]['after_declaration_sha256']
 saved=s/'host-old-integration-before'/variant/decl;saved.parent.mkdir(parents=True,exist_ok=True);saved.write_bytes(before)
 (root/decl).write_bytes(after)
 for name in pins['new_files']:(root/name).write_bytes((c/name).read_bytes())
for filename in['source-files.json','main-logic-source-files.json','scoped-source-files.json','scoped-logic-source-files.json']:
 p=s/filename;paths=json.loads(p.read_text());p.write_text(json.dumps(sorted(set(paths)|set(pins['new_files'])),indent=2)+'\n')
(s/'owned-host-baseline-paths.json').write_text(json.dumps([decl,*pins['new_files']],indent=2)+'\n')
old=Path('/tmp/deadpan-fade-query-admission-2026-10-30')
for name in['run_qualified.py','run_scoped_qualified.py','run_target.py']:
 t=(old/name).read_text()
 if name!='run_target.py':
  anchor="        'DEADPAN_FFMPEG_PREFIX', 'CARGO_TARGET_DIR', 'DEADPAN_REQUIRE_PHYSICAL_MAC',";assert t.count(anchor)==1
  t=t.replace(anchor,"        'DEADPAN_RETAINED_HOST_OUTPUT', 'DEADPAN_RETAINED_HOST_VARIANT',\n        'DEADPAN_RETAINED_HOST_SOURCE_SHA256', 'DEADPAN_RETAINED_HOST_PUBLISHED_CHECKPOINT',\n        'DEADPAN_RETAINED_HOST_EXPECTED',\n"+anchor)
 (s/name).write_text(t)
print('Integrated test-only OLD host producer; all reader production source pins unchanged.')
