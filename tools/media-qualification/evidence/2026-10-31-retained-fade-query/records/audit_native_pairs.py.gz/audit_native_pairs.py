from pathlib import Path
import collections,hashlib,json
s=Path(__file__).resolve().parent
new=json.loads((s/'retained-native-pairs-canonical-body.json').read_text())
old=json.loads((s/'retained-host-old-canonical-body.json').read_text())
counts=collections.Counter();faults=collections.Counter();stable=0;changes=[]
def n(value): assert isinstance(value,int);return value
def same_fields(actual,expected,ignored):
 assert set(actual)==set(expected)
 for k,v in expected.items():
  if k not in ignored:assert actual[k]==v,k
def units(receipts,lane,field):return sum(n(receipts[p][lane][field])for p in ['fade','owners'])
for case in new['cases']:
 original=next(c for c in old['cases']if c['name']==case['fixture'])
 assert len(case['operations'])==len(original['operations'])
 for i,row in enumerate(case['operations']):
  assert row['old_operation_index']==i
  prior=original['operations'][i];p=row['paired'];value=p['new'];receipt=p['receipts']
  assert row['old_request']==prior['read']['request']==value['read']['request']
  assert row['mode']==prior['mode']==value['mode'] and row['authored']==prior['authored']==value['authored']
  for k in ['before_setup','input','retained','setup']:assert value[k]==prior[k],k
  for k in ['before_injection','before','controller_before','injected_prior_work']:assert value['read'][k]==prior['read'][k],k
  assert value['after_handle_drop']['sound_context_frames']==value['after_renderer_drop']['sound_context_frames']==0
  assert value['read']['after_return_drop']['sound_context_frames']==value['read']['before']['sound_context_frames']
  for product in ['fade','owners']:
   q=receipt[product]
   assert not q['invalid'] and not q['overflow'] and not q['nested'] and q['active_depth']==0
   assert q['max_active_depth']<=1
   for lane in ['plan','cache']:
    v=q[lane];assert v['constructor_calls']==v['completed_queries']+v['failed_queries']
    assert v['accepted_work']==sum(v[k]for k in ['canonical_units','additional_units','partial_work','host_eviction_work'])
   completed=sum(q[l]['completed_queries']for l in ['plan','cache'])
   if completed:
    assert completed==1
    assert p['independent_ordinary_metadata'][product]['status']=='Ok'
    assert sum(q[l]['canonical_units']for l in ['plan','cache'])==p['independent_ordinary_metadata'][product]['work']
  assert value['provider_calls']==len(value['provider_events'])
  kind=p['comparison'];fault=row['old_request']['fault'];counts[kind]+=1
  if kind in ['same_complete_pcm_and_metadata','same_complete_typed_error']:
   assert value['read']['output']==prior['read']['output']
  else:
   assert kind in ['new_refusal','different_typed_error'],kind
   assert fault in ['injected_prior_plan_work','one_resident_frame'],fault
   assert value['read']['output']['status']=='Error' and value['provider_calls']==0
   expected='Plan(AudioQueryLimit("structural work"))'if fault=='injected_prior_plan_work'else'Limit("resident PCM or stage cache")'
   assert value['read']['output']['error']['debug']==expected
   for lane,counter in [('plan','plan_work'),('cache','cache_plan_work')]:
    delta=value['read']['after_return_drop'][counter]-value['read']['before'][counter]
    input_work=value['retained']['retained_work']if lane=='plan'else 0
    assert delta==input_work+units(receipt,lane,'accepted_work'),(case['fixture'],i,lane,delta)
    assert units(receipt,lane,'host_eviction_work')==0
   faults[(kind,fault)]+=1
   changes.append({'fixture':case['fixture'],'operation_index':i,'mode':row['mode'],'authored':row['authored'],'fault':fault,'classification':kind,'new_error':expected,'exact_accepted_input_plus_constructor_prefix':True})
  if fault not in ['injected_prior_plan_work','one_resident_frame','cache_scope_at_query_allowance']:
   assert kind in ['same_complete_pcm_and_metadata','same_complete_typed_error']
   for k in ['controller_after_handle_drop','cancelled_at_end','provider_calls']:assert value[k]==prior[k],k
   assert value['read']['controller_after_return_drop']==prior['read']['controller_after_return_drop']
   for key in ['after_return_drop','after_scope_drop']:
    same_fields(value['read'][key],prior['read'][key],{'plan_work','cache_plan_work'})
   for key in ['after_handle_drop','after_renderer_drop']:
    same_fields(value[key],prior[key],{'plan_work','cache_plan_work'})
   for lane,counter in [('plan','plan_work'),('cache','cache_plan_work')]:
    assert units(receipt,lane,'partial_work')==units(receipt,lane,'host_eviction_work')==0
    new_delta=value['read']['after_return_drop'][counter]-value['read']['before'][counter]
    old_delta=prior['read']['after_return_drop'][counter]-prior['read']['before'][counter]
    assert new_delta-old_delta==units(receipt,lane,'additional_units'),(case['fixture'],i,lane,new_delta,old_delta)
   assert len(value['provider_events'])==len(prior['provider_events'])
   for event,former in zip(value['provider_events'],prior['provider_events']):
    same_fields(event,former,{'work_before_provider_result'})
    same_fields(event['work_before_provider_result'],former['work_before_provider_result'],{'plan_work','cache_plan_work','sound_context_frames'})
    assert event['work_before_provider_result']['sound_context_frames']>former['work_before_provider_result']['sound_context_frames']
   stable+=1
assert sum(counts.values())==744 and counts=={'same_complete_pcm_and_metadata':264,'same_complete_typed_error':410,'new_refusal':42,'different_typed_error':28}
out={'canonical_bytes':(s/'retained-native-pairs-canonical-body.json').stat().st_size,'canonical_sha256':hashlib.sha256((s/'retained-native-pairs-canonical-body.json').read_bytes()).hexdigest(),'counts':dict(counts),'stable_full_counter_and_provider_pairs':stable,'changed_faults':[{'classification':k[0],'fault':k[1],'count':v}for k,v in sorted(faults.items())],'changed':changes,'all_changes_only_literal_tight_budgets':True,'all_changed_reads_stop_before_source_io':True,'accepted_failed_work_exactly_input_plus_measured_constructor_prefix':True,'all_744_cleanup_and_receipts_checked':True}
(s/'native-pairs-full-audit.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({k:v for k,v in out.items()if k!='changed'}))
