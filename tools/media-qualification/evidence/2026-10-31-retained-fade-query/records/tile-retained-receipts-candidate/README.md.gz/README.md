# Tile retained-receipt comparison candidate

Scratch-only proposal. No repository file was changed and no compile/test/native run was made.

## Scope

Two authored_eq test files only:
- legacy_tile_baseline.rs adds cumulative retained-fade and retained-owner receipts to each actual counter snapshot and resets their trace per scenario.
- tile_admission_tests.rs validates actual receipt arithmetic, pairs the retained receipts across the new and ordinary Original-query runs, and adds measured retained query work and its separately reported host-eviction work when reconciling against the immutable OLD fixture.

The full OLD matrix remains the comparison target. The normalization does not rewrite the OLD work baseline or remove any OLD observation field; it removes only the two new instrumentation fields after verifying their measured work. Existing OLD fixture/canonical bytes are not touched.

## Accounting rule

For each retained product and controller lane, the receipt checks:
accepted_work = canonical_units + additional_units + partial_work + host_eviction_work.

The paired comparison checks the fully admitted run against its ordinary Original-query / retained-query reference. It adds the existing Original query fee and host-eviction delta, accepted new tile-index work (except imposed refusal), and actual retained-query forwarded work plus separately measured retained host-eviction work. The ordinary retained receipts must show no retained constructors or accepted work. It then strips only the new receipts and compares the complete normalized matrix to the immutable OLD fixture.

## Source pins

SHA-256 of current source copied into before/:
- legacy_tile_baseline.rs: ed85aeb081cda4aff798e3b7b9e04f213e5b4285bfd3407c8590285ce67825ac
- tile_admission_tests.rs: 5e306b1437ab17ac8cc7d27abb0cd492fad128f8acbe3d0a546617bf17d5cfc4

Candidate after/ hashes:
- legacy_tile_baseline.rs: f9acbc821bc4c062ba8e2bdb5a3d28758f24ae15f66d00ed7a70ea794bf58495
- tile_admission_tests.rs: 44290d7a0dd9c5f469f6abf0d1d4afd09cd0a3b37146f6d81df01f2139376de3
