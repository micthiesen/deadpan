# NEW 744-row retained host budget audit

## Result

The changed outcomes are tied to measured near-limit cases. I found no unexplained output or provider-event change. The 12 source-reaching failures still contain downstream accepted plan work that these constructor receipts do not allocate. The exact typed-error split differs from the parent's blanket “Limit” summary: 8 rows end in `Limit("plan work per read")`; 4 authored rows end in `Plan(AudioQueryLimit("recursive policy work"))`.

## Pairing and outcomes

- Canonical NEW body: 744 operations, 26,575,199 bytes, SHA-256 `2f57d0404dad1cb2d33054958d0578f67dd9e2ecc154a1d17fd2824d65700745`. The Main/Scope equality result is complete JSON equality after removing exactly `variant` and `source_sha256`.
- Counts: 264 complete PCM/metadata matches, 410 complete typed-error matches, 40 injected-work new refusals, 28 injected-work error changes, and 2 one-resident-frame refusals.
- All 28 changed-error rows stop before provider access. OLD reports `Limit("plan work per read")` in 20 cases or `Plan(AudioQueryLimit("recursive policy work"))` in 8; NEW reports `Plan(AudioQueryLimit("structural work"))`.
- Of 40 injected-work refusals, 28 stop before a NEW source call and 12 reach the same source-call counts as OLD: four rows make 1 call and eight make 13. The 1-call rows end with `Limit("plan work per read")`. For the 13-call rows, unauthored cases end in `Limit("plan work per read")`; authored cases end in `Plan(AudioQueryLimit("recursive policy work"))`.
- Every source-reaching NEW row preserves event order and all event fields except `work_before_provider_result`; within that work snapshot only plan/cache counters and resident sound-context frames differ, and the latter is higher in NEW. The captured output then errors after the matching OLD source prefix.
- The two one-resident-frame refusals are unauthored fractional-phase requests. OLD succeeds after one provider call. NEW fails retained fade admission before provider access with a 15-unit partial fade prefix; the resident reservation is rejected by the configured one-frame cap.

## Accounting

For the 58 changed rows ending before source access, the new ReadWork delta exactly equals input work plus accepted retained fade/owner receipts plus the four original-query receipts and issuer work. All receipt equations pass. Host-eviction work is zero in these receipts, avoiding duplicate eviction billing.

For the 12 source-reaching rows, work remaining beyond those measured scopes is 539 units in four rows, 1,614 in four, and 1,674 in four. This is accepted downstream plan work, not identified by the captured constructor receipts. The captures do not split those units by downstream function, so they do not show complete allocation/admission of the whole read.

## Audit-script coverage note

`audit_native_pairs3.py` excludes the 40 `cache_scope_at_query_allowance` rows from its stable-case cleanup/counter/provider assertions. I separately compared these 40 to OLD: deltas, provider-call counts, post-return and post-scope state, post-handle controller state, and renderer-drop cleanup all match (with only plan/cache work fields filtered where expected). No mismatch was found, but the script's `all_744_cleanup_and_receipts_checked` result is stronger than its own assertions support unless those 40 dedicated comparisons are added.

## Limits

Read-only stored-capture and code-path review. No builds, tests, or captures were run by this audit. Provider-prefix equivalence is not success equivalence, and the 12 late differences do not establish whole-read work attribution.

## Follow-up: pairs4 audit

`audit_native_pairs4.py` adds a dedicated branch for the previously omitted 40 `cache_scope_at_query_allowance` operations. It requires unchanged output classification, compares provider-call/event pairs, verifies post-return/post-scope and handle/renderer cleanup state (ignoring only plan/cache work counters), and checks read-delta growth against captured additional constructor fees. Its emitted summary reports 584 regular pairs + 40 cache-fault pairs + 70 changed-budget pairs = all 744 operations. The 40-row coverage gap noted above is resolved.

One remaining scope qualification: the 70 changed-budget rows still bypass the ordinary unchanged-case cleanup comparisons. The global checks verify receipt equations/depth and sound-context frame behavior; I also inspected the recorded active/cache/projected reservation fields for those rows and saw them empty after handle/renderer/return/scope drops. The script does not assert those full cleanup invariants for the changed rows, so `all_744_cleanup_and_receipts_checked` is broader than its per-row cleanup assertions unless a changed-error cleanup check is added.

## Parent resolution: pairs5 audit

The parent added explicit changed-error cleanup checks in audit_native_pairs5.py.
All 70 changed rows have controller_after_return_drop and
controller_after_handle_drop exactly equal to their own controller_before.
Active/cache frames and disk bytes are zero, the cache is empty, feeding_tail
is false, and post-scope metadata residency equals pre-read residency.
The script passes all 744 operations. The independently observed empty states
are now asserted. This does not attribute the remaining downstream work or
claim whole-read preparation admission.

## Follow-up: pairs5 changed-error cleanup assertions

`audit_native_pairs5.py` adds explicit error-path cleanup assertions for the remaining 70 changed-budget cases: after return, the controller equals its pre-read state; after handle drop, controller state also equals that baseline; active and cached resource counts are zero, the cache is empty, and no tail is feeding. It also checks post-scope sound-context frames return to the pre-read count. This closes the changed-row cleanup assertion gap from pairs4. The pairs5 summary retains the 744-row classifications and constructor receipt checks, while late downstream work remains explicitly unallocated rather than claimed as admitted.
