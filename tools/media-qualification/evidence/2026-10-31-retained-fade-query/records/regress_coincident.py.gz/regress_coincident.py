from pathlib import Path
import json,subprocess,os,sys,hashlib
s=Path(__file__).resolve().parent;v=sys.argv[1];assert v in ['main','scoped']
build=f'retained-coincident-{v}-build9'
subprocess.run(['python3',str(s/'pin.py'),build],check=True)
subprocess.run(['python3',str(s/'run_logic_target.py'),build,v,'plan','deadpan_plan',build+'-list','--list'],check=True)
names=[l.removesuffix(': test')for l in(s/(build+'-list.stdout')).read_text().splitlines()if l.endswith('diagnostic::literal_ordinary_retained_coincidence_matches_external_v1: test')]
assert len(names)==1
path=s/'coincident-ordinary-canonical-body.json'
sha='e5702798bd4ccfe98b54637d0b9dffb102d4c3c22b36b4fe7214068112b399a8'
assert hashlib.sha256(path.read_bytes()).hexdigest()==sha
label=f'coincident-ordinary-{v}-external-regression'
env=os.environ.copy();env['DEADPAN_RETAINED_COINCIDENT_EXPECTED']=str(path)
subprocess.run(['python3',str(s/'run_logic_target.py'),build,v,'plan','deadpan_plan',label,'--ignored','--exact',names[0],'--nocapture','--test-threads=1'],check=True,env=env)
assert hashlib.sha256(path.read_bytes()).hexdigest()==sha
r=json.loads((s/(label+'.json')).read_text());assert r['sources_unchanged']and r['binaries_unchanged']and r['exit_code']==0
