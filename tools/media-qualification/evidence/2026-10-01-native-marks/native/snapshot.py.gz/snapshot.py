import json
import sqlite3
import sys
from pathlib import Path

root = Path(__file__).parent
label = sys.argv[1]
project = root / 'Marks QA.deadpan' / 'project.sqlite'
destination = root / (label + '.sqlite')
if destination.exists():
    raise SystemExit('Snapshot already exists')
with sqlite3.connect('file:' + str(project) + '?mode=ro', uri=True) as source:
    with sqlite3.connect(destination) as backup:
        source.backup(backup)
with sqlite3.connect(destination) as database:
    document = json.loads(database.execute('SELECT r.document FROM revisions r JOIN state s ON r.id=s.head_revision').fetchone()[0])
    (root / (label + '-document.json')).write_text(json.dumps(document, indent=2) + '\n')
    print(json.dumps({'label': label, 'revisions': database.execute('SELECT count(*) FROM revisions').fetchone()[0], 'history': database.execute('SELECT count(*) FROM history').fetchone()[0], 'marks': document['marks']}, indent=2))
