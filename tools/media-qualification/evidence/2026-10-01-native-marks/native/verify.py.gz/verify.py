import json
import sqlite3
from pathlib import Path

root = Path(__file__).parent
labels = ['before', 'edit-mark', 'original-mark', 'navigated-cancelled', 'removed', 'undo', 'reopened']
documents = {label: json.loads((root / (label + '-document.json')).read_bytes()) for label in labels}

def tables(label):
    with sqlite3.connect(root / (label + '.sqlite')) as database:
        names = [row[0] for row in database.execute("SELECT name FROM sqlite_master WHERE type='table' ORDER BY name")]
        return {name: database.execute('SELECT * FROM "' + name.replace('"', '""') + '" ORDER BY rowid').fetchall() for name in names}

states = {label: tables(label) for label in labels}
assert len(states['before']) == 20
assert states['original-mark'] == states['navigated-cancelled']
assert states['undo'] == states['reopened']
counts = {}
for label, expected in zip(labels, [(13,10),(14,11),(15,12),(15,12),(16,13),(17,13),(17,13)]):
    counts[label] = (len(states[label]['revisions']), len(states[label]['history']))
    assert counts[label] == expected, (label, counts[label], expected)
    assert {k:v for k,v in documents[label].items() if k not in {'revision_id','marks'}} == {k:v for k,v in documents['before'].items() if k not in {'revision_id','marks'}}
    for name in states['before'].keys() - {'revisions','history','state','redo'}:
        assert states[label][name] == states['before'][name], (label,name)

q = documents['edit-mark']['marks']['native-mark-q']
assert q['boundary']['coordinate']['space'] == 'occurrence'
assert q['boundary']['coordinate']['position'] == {'numerator':'20','denominator':'1'}
assert documents['edit-mark']['marks'] == documents['before']['marks'] | {'native-mark-q':q}
upper = documents['original-mark']['marks']['native-mark-Q']
assert upper['boundary']['coordinate']['moment']['timestamp'] == {'ticks':5005,'time_base':{'numerator':1,'denominator':30000}}
assert documents['original-mark']['marks'] == documents['edit-mark']['marks'] | {'native-mark-Q':upper}
assert documents['removed']['marks'] == {k:v for k,v in documents['original-mark']['marks'].items() if k != 'native-mark-q'}
assert documents['undo']['marks'] == documents['original-mark']['marks']
assert len({documents[label]['revision_id'] for label in ['before','edit-mark','original-mark','removed','undo']}) == 5

report = {'passed':True, 'counts':counts, 'database_tables':20, 'unchanged_nonhistory_tables':16, 'navigation_and_cancel_changed_no_tables':True, 'reopen_and_jump_changed_no_tables':True, 'all_nonmark_authored_fields_unchanged':True, 'undo_restores_all_mark_fields':True, 'revision_ids_never_reused':True, 'original_q_pts':5005, 'original_q_time_base':[1,30000], 'edit_q_exact_frame':[20,1]}
(root / 'verification.json').write_text(json.dumps(report,indent=2) + '\n')
print(json.dumps(report))
