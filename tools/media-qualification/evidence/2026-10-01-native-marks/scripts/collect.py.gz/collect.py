import gzip
import hashlib
import json
import shutil
import subprocess
from pathlib import Path

scratch = Path(__file__).parent
repo = Path.cwd()
output = repo / 'tools/media-qualification/evidence/2026-10-01-native-marks'
output.mkdir(exist_ok=True)

def save(relative, data):
    path = output / relative
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(data)

def packed(relative, data):
    save(relative + '.gz', gzip.compress(data, mtime=0))

for source in sorted((scratch / 'checks').iterdir()):
    if source.suffix not in {'.json', '.log'}:
        continue
    if source.suffix == '.log' or source.name.startswith('source-'):
        packed('checks/' + source.name, source.read_bytes())
    else:
        report = json.loads(source.read_bytes())
        if 'exit_code' not in report:
            raise SystemExit('Unfinished check: ' + source.name)
        save('checks/' + source.name, source.read_bytes())

replays = {}
for directory in sorted(scratch.glob('visual-marks-*')):
    report = json.loads((directory / 'report.json').read_bytes())
    packed('replays/' + directory.name + '.json', (directory / 'report.json').read_bytes())
    replays[directory.name] = {
        'failed': report['failed'],
        'scenarios': [{'name': s['name'], 'checks': len(s['checks']), 'failed': s['failed'], 'findings': s['findings']} for s in report['scenarios']]
    }
    if report['failed']:
        for scenario in report['scenarios']:
            images = [step['screenshot'] for step in scenario['steps'] if step.get('screenshot')]
            if scenario['failed'] and images:
                image = directory / images[-1]
                save('images/' + directory.name + '-failure.png', image.read_bytes())

passing = scratch / 'visual-marks-fifth'
report = json.loads((passing / 'report.json').read_bytes())
labels = {
    'Visible pending mark prefix and captured Edit boundary': 'pending-prefix',
    'Saved Original and Edit marks with keyboard controls': 'marks-list',
    'Last mark row revealed by keyboard at minimum size': 'last-mark-row',
}
image_index = []
for scenario in report['scenarios']:
    for step in scenario['steps']:
        if step['input'] in labels and step.get('screenshot'):
            width = int(step['semantic']['viewport_points'][0])
            name = f"images/{labels[step['input']]}-{width}.png"
            save(name, (passing / step['screenshot']).read_bytes())
            image_index.append({'path': name, 'caption': step['input'], 'semantic': step['semantic']})
packed('images/index.json', (json.dumps(image_index, indent=2) + '\n').encode())

performance = scratch / 'performance-final/report.json'
if not performance.exists():
    raise SystemExit('Full performance report is missing')
report = json.loads(performance.read_bytes())
packed('replays/performance-final.json', performance.read_bytes())
performance_summary = {
    'failed': report['failed'],
    'metadata': report['metadata'],
    'scenarios': [{'name': s['name'], 'checks': len(s['checks']), 'failed': s['failed'], 'findings': s['findings'], 'skipped': s['skipped'], 'timings': [{'name': t['name'], 'summary': t['summary']} for t in s['timings']]} for s in report['scenarios']],
}
packed('performance-summary.json', (json.dumps(performance_summary, indent=2) + '\n').encode())

for source in sorted((scratch / 'native').iterdir()):
    if not source.is_file():
        continue
    if source.suffix in {'.sqlite', '.py', '.log'}:
        packed('native/' + source.name, source.read_bytes())
    elif source.suffix in {'.md', '.json'}:
        save('native/' + source.name, source.read_bytes())
packed('scripts/collect.py', Path(__file__).read_bytes())

current_hash = '9f81d48542fa16934f3aabafe0af4f2d5b1a3511d47b343c704936442c786ea8'
unit_hash = '58728a6de59f5bd27cac771e0cba00c34cc5fb220625bdc3056bc359e50cfbe2'
current = json.loads((scratch / 'checks' / ('source-' + current_hash + '.json')).read_bytes())
unit = json.loads((scratch / 'checks' / ('source-' + unit_hash + '.json')).read_bytes())
changed_since_unit = [name for name in sorted(current.keys() | unit.keys()) if current.get(name) != unit.get(name)]
drift = [name for name, digest in current.items() if not (repo / name).is_file() or hashlib.sha256((repo / name).read_bytes()).hexdigest() != digest]
if drift:
    raise SystemExit('Current source drift: ' + repr(drift))
old_path = repo / 'tools/media-qualification/evidence/2026-10-01-structural-capture/checks/source-2ff5fa645251de51887575a0bafa8d71b59df3747a9b982e6617e2e844e68e1b.json.gz'
old = json.loads(gzip.decompress(old_path.read_bytes()))
backend_drift = [name for name in sorted(current.keys() | old.keys()) if name.startswith(('crates/', 'native/')) and not name.startswith('crates/deadpan-app/') and current.get(name) != old.get(name)]
environment = {
    'base': '291853145eb434864cdf84dcbbab92c81881ff73',
    'source_manifest_sha256': current_hash,
    'source_files_rechecked': len(current),
    'ui_unit_source_manifest_sha256': unit_hash,
    'changed_since_ui_unit_tests': changed_since_unit,
    'backend_changes_since_previous_workspace_gate': backend_drift,
    'os': subprocess.check_output(['sw_vers'], text=True).strip(),
    'chip': subprocess.check_output(['sysctl', '-n', 'machdep.cpu.brand_string'], text=True).strip(),
    'memory_bytes': int(subprocess.check_output(['sysctl', '-n', 'hw.memsize'], text=True)),
    'compiler': subprocess.check_output(['rustup', 'run', '1.97.1', 'rustc', '-Vv'], text=True).strip(),
    'visual_replays': replays,
}
save('environment.json', (json.dumps(environment, indent=2) + '\n').encode())
inventory = {str(path.relative_to(output)): hashlib.sha256(path.read_bytes()).hexdigest() for path in sorted(output.rglob('*')) if path.is_file() and path.name != 'SHA256SUMS.json'}
save('SHA256SUMS.json', (json.dumps(inventory, indent=2) + '\n').encode())
print(json.dumps({'files': len(inventory), 'bytes': sum(path.stat().st_size for path in output.rglob('*') if path.is_file()), 'source_files': len(current), 'backend_drift': backend_drift}))
