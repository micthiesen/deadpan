from pathlib import Path
import hashlib,json,gzip
s=Path(__file__).resolve().parent
repo=Path('/Users/michael/Code/deadpan')
dest=repo/'tools/media-qualification/evidence/2026-10-28-retained-probe-work'
assert not dest.exists(),'Archive only once all receipts are terminal'
allowed={'.rs','.json','.py','.md','.patch','.stdout','.stderr','.txt'}
entries=[]
sources=[('probe',p,p.relative_to(s)) for p in sorted(s.rglob('*')) if p.is_file() and p.suffix in allowed and p.name!='qualification-draft.md']
for group,p,relative in sources:
 data=p.read_bytes()
 if p.suffix=='.json':
  value=json.loads(data)
  if isinstance(value,dict) and 'command' in value and 'started_at' in value:
   assert 'exit_code' in value and value['sources_unchanged'] and value['binaries_unchanged'],str(p)
 out=dest/'records'/group/relative
 out=out.with_name(out.name+'.gz');out.parent.mkdir(parents=True,exist_ok=True)
 compressed=gzip.compress(data,mtime=0);out.write_bytes(compressed)
 entries.append({'path':str(out.relative_to(dest)),'bytes':len(compressed),'sha256':hashlib.sha256(compressed).hexdigest(),'expanded_bytes':len(data),'expanded_sha256':hashlib.sha256(data).hexdigest()})
manifest={'schema_version':1,'base_revision':(s/'base-revision.txt').read_text().strip(),'scope':'Seven-file retained-input probe work receipt for both Some and None. Same validated single walk, legacy wrapper, both real Audio consumers charge once. Negative old-consumer variant with same new API and legal fixture fails constructor13vs22 and metadata19vs28 assertions before PCM; patched real Tone oracle passes. Test-only PCM fixture and InvalidAudioLimits correction retained. Package-qualified32-binary Cargo JSON pins avoid Plan/Audio target-name collision. No caps/weights/refunds/cache/retry or cold-batching changes.','prior_runtime_evidence':{'path':'../2026-10-28-node-description/inventory.json','inventory_sha256':'b413d128cf2b00ad5e87d1a1fafd04a2bd624b13da322d019134fb39314c5c82'},'files':entries}

file=dest/'inventory.json';file.write_text(json.dumps(manifest,indent=2)+'\n')
stored=expanded=0
for row in entries:
 data=(dest/row['path']).read_bytes();plain=gzip.decompress(data)
 assert len(data)==row['bytes'] and hashlib.sha256(data).hexdigest()==row['sha256']
 assert len(plain)==row['expanded_bytes'] and hashlib.sha256(plain).hexdigest()==row['expanded_sha256']
 stored+=len(data);expanded+=len(plain)
print(json.dumps({'files':len(entries),'stored_bytes':stored,'expanded_bytes':expanded,'inventory_sha256':hashlib.sha256(file.read_bytes()).hexdigest()}))
