# Bill successful retained-input probes, including None

Scratch-only bugfix candidate, 2026-10-28. Source/test files FROZEN.
No live source edits, compiler, Cargo, tests, Git or worktrees.
Parent owns integration, all verification and full work-limit consequences.

## API and production consumers

AudioOwnerInput::retained_probe_at(at, limits) returns the strong
AudioOwnerRetainedProbe<'plan>:
- private input: Option<AudioOwnerRetainedInput>;
- private work: usize;
- input() borrows the optional input;
- work() reports the successful lookup's actual walk work;
- into_input() moves the optional input without a clone.

The type is Debug, not Clone, and exported through the existing Plan/Lib
barrels. It adds stack fields only; the Some input is the SAME owned value and
graph payload as before. No extra graph clone or heap allocation is introduced.

The existing retained_at API remains a compatibility wrapper over that single
lookup, moving its input. It does not issue a second walk. Actual controlled
preparation uses the work-bearing API.

Context::owner_context:
1. Resolves and bills input.work as before.
2. Calls retained_probe_at with the same at/control.query_limits.
3. Bills probe.work ONCE, regardless of Some/None.
4. Moves the optional retained input and keeps the original retained-owner
   query/work/provenance decision. The former Some-only retained.work spend
   is removed, not duplicated.
Incoming Context::Retained still returns its exact Arc clone immediately.

PreparedOwnerEqualizer::new:
- Keeps cancellation and treatment-boundary validation first.
- Same observed_at/default query limits, same one retained lookup.
- Adds probe.work once to its stored construction work, including None.
- Some adds only its owners query work afterward; no second retained.work add.
- Native Equalizer construction, owner membership/selection and PCM are untouched.
The stored total is spent at the existing read_owner_equalized_controlled entry,
after its original plan/depth/range guards and before media. No new public
construction-work getter is added just for the test.

## Structural audit

audit.json proves the Plan validation/walk prefix is byte-identical to the
old retained_at body; the work-bearing method contains exactly ONE
audio_walk_editorial call; the Some Retained payload is byte-identical.
No guard, query limit, reference map, lattice, clock, editorial capture,
provider/native action, retry or resource limit is altered.

Both work values in a Some result originate from the same budget after that
walk: retained.work remains the old compatibility value; probe.work matches it.
None now exposes work which previously disappeared with the successful None.

A FAILED query still returns the same typed Plan error before a probe result
exists. This patch does not change failed-query work reporting. In the known
one-short fixture the completed prefix is still 19, then the probe fails with
AudioQueryLimit("structural work"). It is not refunded or retried.

## Tests authored, not executed

Plan existing input tests:
- retained_probe_reports_positive_none_work_and_preserves_guards:
  real checked owner; absent retained input has positive actual work; exact
  reported probe allowance succeeds, one less refuses; compatibility wrapper
  still returns None; invalid limits precede the original out-of-range guard.
- moved_preserve_input_keeps_its_point_ceil_reference_labels:
  extends the existing Some witness to check probe work equals retained.work,
  exact/one-short limits and move semantics while retaining all original
  PointCeil reference-grid assertions.

Audio:
- owner_equalizer::tests::constructor_counts_none_probe_and_preserves_actual_tone_pcm:
  stored constructor work equals input.work+positive None probe.work (old
  accounting omitted the latter). Executes actual native owner EQ and compares
  f32 PCM bits/suppression against the existing authored-EQ reader using the
  real tone fixture. No source provider calls; both renderer ledgers clean up.
  The test does not alter a work counter to fabricate a PCM oracle.
- shared_eq::node_description::tests::captured_retained_context_bills_the_probe_once_before_owner_query:
  real bound Tone input; expected input.work+probe.work+retained-owner-query.work,
  exact Retained context result. Demonstrates Some is not counted twice.
- metadata_query_work_bills_the_final_nonretained_probe:
  updates the measured literal characterization. At headroom 28, successful
  metadata now bills 28 and leaves 0. At 27, the unchanged probe refuses with
  typed structural-work error after 19 completed billed units, leaving 8.

The latter is a genuine accounting regression assertion: only that updated
test against the mechanical predecessor's production code fails 28 vs 19.
The new Plan API tests do not compile against an old API and are not advertised
as old-failing runtime evidence. Existing media/native and full suites remain
required; none was run by this child.

## Scope and risk

Seven existing files only, listed in before/after/audit manifests. Reexport
edits preserve captured inherited Plan work; no new repository files.
All captured main sources still matched at final audit. Original mechanical
extraction and its diagnostic/literal evidence remain untouched.

Successful None lookups intentionally consume more canonical work. If a normal
case now reaches the existing work ceiling, that is honest newly reported work,
not permission to lower weights, raise caps, refund operations, hide failures,
retry, use optional-cache budget or revert the charge. Actual algorithmic work
must be removed if it prevents acceptance. Full-Split completion is not claimed.
