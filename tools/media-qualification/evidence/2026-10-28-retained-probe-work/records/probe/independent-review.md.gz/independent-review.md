# Independent review: retained-probe work accounting

Scope: frozen `retained-probe-work.patch` against its audit snapshots. Read-only; no live source edits or Cargo/rustc/Git runs.

## Findings

None supported in the assigned lens.

## Evidence and limits

`retained_probe_at` is the old validated walk with the same limit validation, root-range check, editorial traversal arguments, match classification, and `raw_domain` conversion. It now returns the existing walk's consumed-budget delta whether the result contains an input or is `None`; the `Some` input still carries the same work value. `retained_at` is a compatibility wrapper that moves out the optional input without cloning. The public barrel exports the probe type; the input payload remains private and inspectable by borrow or moved out.

Both controlled consumers charge probe work exactly once. `Context::owner_context` now bills a successful absent probe; for `Some`, probe work equals the prior retained input's work, so no duplicate charge. `PreparedOwnerEqualizer::new` and the worker-side owner-context constructor use the same substitution and retain their subsequent owner-query work. No native, context-selection, grid, or cache logic changed in the diff.

Tests cover positive `Some` work and existing PointCeil domain behavior, exact and one-short query limits, `None` work and legacy wrapper result, range/limit guard order, the observed `19 billed / 28 required / 27 structural refusal` case, controlled context billing for retained `Some`, and PreparedOwnerEqualizer work plus tone PCM equality with zero media-provider calls. The new tests exercise behavioral assertions that distinguish the former None underbilling, but they are not an old-binary runtime comparison; most directly call the new API. The patch and tests remain uncompiled in this review.

## Test-only follow-up addendum

Reviewed both fixture/limit corrections. No supported issue.

The PreparedOwnerEqualizer test now constructs a raw tone plan with no authored treatment at the standalone processor boundary, extracts the recipe from a separate authored-tone oracle plan, and passes only that recipe to the raw plan's checked input. This avoids asking the standalone suffix reader to process an already-authored EQ, which it correctly rejects. The `None` probe/work assertion remains before the reads; the comparison still runs actual tone generation and the actual native EQ paths, checks sample bits and suppression, verifies zero provider calls, and checks renderer cleanup. The prior negative old-consumer run is accounting evidence (13-vs-22 and 19-vs-28 assertions), not a claim that the earlier invalid fixture demonstrated an old PCM failure.

The Plan guard test now expects `InvalidAudioLimits` for `maximum_work == 0`, matching `AudioQueryLimits::validate` running before range validation. This narrows the assertion to the existing documented/implemented guard order; production is untouched. Parent reports the corrected positive run is underway; I did not run Cargo.
