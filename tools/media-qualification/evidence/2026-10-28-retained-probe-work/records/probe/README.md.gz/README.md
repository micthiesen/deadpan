# Retained probe work qualification

Main owns integration/Cargo. Worker candidate and independent review remain in scratch; children never ran compiler/native code or edited live source.

The new work-bearing Plan result retains Some and None from the same validated walk. Both actual Audio consumers use its work once. Existing Some payload/reference mappings and retained_at compatibility wrapper remain. Partial query errors retain existing failure-prefix behavior; this is not a new error-work receipt, metadata heap bound or cold resource system.

Main and isolated final builds each pin exactly32 package-qualified Cargo JSON executables:3 Audio +29 Plan. Initial unqualified pinning collided on audio_definition between the packages; partial copies are retained and never selected by glob. An immediate missing-Audio-binary launch failed before invocation. pin-orchestration.md describes these setup failures.

Two initial new tests had incorrect fixtures/expectations: the prepared-EQ PCM test supplied a temporally authored input rejected by its real API; the Plan zero-work guard expected AudioQueryLimit rather than the existing InvalidAudioLimits. Test-only corrections are retained. Neither weakens production guards. The legal PCM fixture uses raw Tone + explicit recipe and a separate authored-EQ oracle.

The isolated negative variant restores only the two production consumer charge bodies while keeping the work-bearing Plan API and final legal Audio test fixture. Its Audio library produces263pass/2fail at the intended accounting assertions: Prepared13vs22; node metadata19vs28, before PCM comparison. Its unused Plan unit test still contains the initial zero-work expectation; it was not executed or counted as Plan qualification. The isolated source is restored to positive production and corrected tests after that run.

Final source snapshots, all7published-index equalities and1428/1199 input guards are retained. Main Plan plan.rs has an inherited overlay outside the task's re-export hunk; no unrelated WIP is staged.

The seven-case unfinished Split matrix is rerun because honest work charges change budgets. Exact outputs are authoritative. The definition suite started5.104342seconds before the last Split witness finished due to a yielded wait being mistaken for completion; media-overlap.json retains exact times. No performance claim derives from these verification durations.
