from pathlib import Path
import sys,json,shutil,hashlib
s=Path(__file__).resolve().parent
label=sys.argv[1]
receipt=json.loads((s/(label+'.json')).read_text())
assert receipt['exit_code']==0 and receipt['sources_unchanged']
pins=[]
for line in (s/(label+'.stdout')).read_text().splitlines():
 try:a=json.loads(line)
 except ValueError:continue
 if a.get('reason')=='compiler-artifact' and a.get('executable') and a.get('profile',{}).get('test') and (('deadpan-audio#' in a['package_id'] and a['target']['name'] in ['deadpan_audio','audio_definition','stages']) or 'deadpan-plan#' in a['package_id']):
  dest=s/(label+'-'+a['target']['name'].replace('_','-'))
  assert not dest.exists();shutil.copy2(a['executable'],dest)
  pins.append(dict(name=a['target']['name'],path=str(dest),sha256=hashlib.sha256(dest.read_bytes()).hexdigest(),bytes=dest.stat().st_size,artifact=a))
assert len([p for p in pins if 'deadpan-audio#' in p['artifact']['package_id']])==3
assert len([p for p in pins if 'deadpan-plan#' in p['artifact']['package_id']])==29
(s/(label+'-pins.json')).write_text(json.dumps(pins,indent=2)+'\n')
print(json.dumps({'binaries':len(pins),'pins_file':str(s/(label+'-pins.json'))}))
