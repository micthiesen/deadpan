from pathlib import Path
import hashlib,json
root=Path('/Users/michael/Code/deadpan')
out=Path('/tmp/deadpan-retained-probe-work-2026-10-28')
paths=[
'crates/deadpan-plan/src/audio_owner_input.rs',
'crates/deadpan-plan/src/plan.rs',
'crates/deadpan-plan/src/lib.rs',
'crates/deadpan-plan/src/audio_owners/input_tests.rs',
'crates/deadpan-audio/src/authored_eq.rs',
'crates/deadpan-audio/src/owner_equalizer.rs',
'crates/deadpan-audio/src/shared_eq/node_description_tests.rs']
pins={}
for rel in paths:
    data=(root/rel).read_bytes()
    pins[rel]=hashlib.sha256(data).hexdigest()
    for folder in ['before','source']:
        dest=out/folder/rel; dest.parent.mkdir(parents=True,exist_ok=True); dest.write_bytes(data)
(out/'before.json').write_text(json.dumps(pins,indent=2)+'\n')
p=out/'source/crates/deadpan-plan/src/audio_owner_input.rs'
s=p.read_text()
a=s.index('    /// The first opaque retained input at this context sample')
b=s.index('        limits.validate()?;',a)
old=s[a:b]
assert 'pub fn retained_at(' in old
s=s[:a]+'''    /// Compatibility lookup for consumers that do not account preparation
    /// work. Controlled preparation should use retained_probe_at instead.
    pub fn retained_at(
        &self,
        at: AudioSample,
        limits: AudioQueryLimits,
    ) -> Result<Option<AudioOwnerRetainedInput<'plan>>, PlanError> {
        Ok(self.retained_probe_at(at, limits)?.into_input())
    }

    /// The first opaque retained input at this context sample and the work of
    /// the same lookup, including a successful lookup that finds no input.
    /// Do not descend through an enclosing Preserve to find one: that would
    /// move post-time/pitch effects into its input. No PCM is opened here.
    pub fn retained_probe_at(
        &self,
        at: AudioSample,
        limits: AudioQueryLimits,
    ) -> Result<AudioOwnerRetainedProbe<'plan>, PlanError> {
'''+s[b:]
a=s.index('        match walked {',s.index('    pub fn retained_probe_at'))
b=s.index('\n    }\n}',a)
old=s[a:b]
new=old.replace('        match walked {','        let input = match walked {',1)
new=new.replace('                Ok(Some(AudioOwnerRetainedInput {','                Some(AudioOwnerRetainedInput {',1)
new=new.replace('                }))','                })',1)
new=new.replace('            _ => Ok(None),','            _ => None,',1)
assert new.endswith('        }')
new=new[:-len('        }')]+'''        };
        Ok(AudioOwnerRetainedProbe {
            input,
            work: limits.maximum_work - budget.remaining,
        })'''
s=s[:a]+new+s[b:]
pos=s.index("/// A retained processor's full raw operand")
s=s[:pos]+'''/// Result of one checked retained-input lookup. An absent operand still has
/// actual traversal work. Owns the same optional input without cloning it.
#[derive(Debug)]
pub struct AudioOwnerRetainedProbe<'plan> {
    input: Option<AudioOwnerRetainedInput<'plan>>,
    work: usize,
}

impl<'plan> AudioOwnerRetainedProbe<'plan> {
    pub fn input(&self) -> Option<&AudioOwnerRetainedInput<'plan>> {
        self.input.as_ref()
    }

    pub fn work(&self) -> usize {
        self.work
    }

    pub fn into_input(self) -> Option<AudioOwnerRetainedInput<'plan>> {
        self.input
    }
}

'''+s[pos:]
p.write_text(s)
p=out/'source/crates/deadpan-plan/src/plan.rs'
s=p.read_text()
old='pub use audio_owner_input::{AudioOwnerInput, AudioOwnerInputScope, AudioOwnerRetainedInput};'
assert s.count(old)==1
p.write_text(s.replace(old,'''pub use audio_owner_input::{
    AudioOwnerInput, AudioOwnerInputScope, AudioOwnerRetainedInput, AudioOwnerRetainedProbe,
};'''))
p=out/'source/crates/deadpan-plan/src/lib.rs'
s=p.read_text()
old='    AudioOwnerOccurrences, AudioOwnerRetainedInput,'
assert s.count(old)==1
p.write_text(s.replace(old,'    AudioOwnerOccurrences, AudioOwnerRetainedInput, AudioOwnerRetainedProbe,'))
p=out/'source/crates/deadpan-audio/src/authored_eq.rs'
s=p.read_text()
old='''        if let Some(retained) = input.retained_at(at, control.query_limits()?)? {
            control.spend_plan_work(retained.work())?;'''
new='''        let probe = input.retained_probe_at(at, control.query_limits()?)?;
        control.spend_plan_work(probe.work())?;
        if let Some(retained) = probe.into_input() {'''
assert s.count(old)==1
p.write_text(s.replace(old,new))
p=out/'source/crates/deadpan-audio/src/owner_equalizer.rs'
s=p.read_text()
old='''        let retained = input.retained_at(at, AudioQueryLimits::default())?;
        let retained = if let Some(retained) = retained {'''
new='''        let probe = input.retained_probe_at(at, AudioQueryLimits::default())?;
        work += probe.work();
        let retained = if let Some(retained) = probe.into_input() {'''
assert s.count(old)==1
s=s.replace(old,new)
old='            work += retained.work() + query.work();'
assert s.count(old)==1
p.write_text(s.replace(old,'            work += query.work();'))
print(json.dumps(pins,indent=2))
