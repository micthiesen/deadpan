from pathlib import Path
r=Path('/tmp/deadpan-retained-probe-work-2026-10-28/source')
p=r/'crates/deadpan-plan/src/audio_owners/input_tests.rs'
s=p.read_text()
s+='''

#[test]
fn retained_probe_reports_positive_none_work_and_preserves_guards() {
    let doc = document(48_000, &["voice"], vec![("voice", hold(4))]);
    let plan = RenderPlan::compile(&doc).unwrap();
    let input = plan
        .audio_owner_input(&owner(&plan, "voice", 1), AudioSample(1), Default::default())
        .unwrap();
    let probe = input.retained_probe_at(AudioSample(1), Default::default()).unwrap();
    assert!(probe.input().is_none());
    let work = probe.work();
    assert!(work > 0, "an absent retained operand still required a walk");
    assert!(probe.into_input().is_none());
    let exact = AudioQueryLimits {
        maximum_work: work,
        ..Default::default()
    };
    let exact_probe = input.retained_probe_at(AudioSample(1), exact).unwrap();
    assert_eq!(exact_probe.work(), work);
    assert!(exact_probe.into_input().is_none());
    assert!(input.retained_at(AudioSample(1), exact).unwrap().is_none());
    assert!(matches!(
        input.retained_probe_at(
            AudioSample(1),
            AudioQueryLimits { maximum_work: work - 1, ..exact },
        ),
        Err(PlanError::AudioQueryLimit(_))
    ));
    for at in [AudioSample(-1), AudioSample(4)] {
        assert!(matches!(
            input.retained_probe_at(at, Default::default()),
            Err(PlanError::AudioRangeOutOfRange)
        ));
        assert!(matches!(
            input.retained_at(at, Default::default()),
            Err(PlanError::AudioRangeOutOfRange)
        ));
        // Limit validation remains before the existing range guard.
        assert!(matches!(
            input.retained_probe_at(
                at,
                AudioQueryLimits { maximum_work: 0, ..Default::default() },
            ),
            Err(PlanError::AudioQueryLimit(_))
        ));
    }
}
'''
# Extend the existing PointCeil retained witness, keeping all its mapping checks.
a=s.index('fn moved_preserve_input_keeps_its_point_ceil_reference_labels()')
old='''    let retained = input
        .retained_at(AudioSample(0), Default::default())
        .unwrap()
        .unwrap();'''
b=s.index(old,a)
new='''    let probe = input
        .retained_probe_at(AudioSample(0), Default::default())
        .unwrap();
    assert!(probe.work() > 0);
    assert_eq!(probe.work(), probe.input().unwrap().work());
    let work = probe.work();
    let exact = input
        .retained_probe_at(
            AudioSample(0),
            AudioQueryLimits { maximum_work: work, ..Default::default() },
        )
        .unwrap();
    assert_eq!(exact.work(), work);
    assert!(exact.input().is_some());
    assert!(matches!(
        input.retained_probe_at(
            AudioSample(0),
            AudioQueryLimits { maximum_work: work - 1, ..Default::default() },
        ),
        Err(PlanError::AudioQueryLimit(_))
    ));
    let retained = probe.into_input().unwrap();'''
s=s[:b]+s[b:].replace(old,new,1)
p.write_text(s)
p=r/'crates/deadpan-audio/src/shared_eq/node_description_tests.rs'
s=p.read_text()
s=s.replace('fn metadata_query_headroom_is_distinct_from_completed_billed_work()',
            'fn metadata_query_work_bills_the_final_nonretained_probe()')
old='''    // The completed metadata queries bill 19 units. The last retained_at(None)
    // walk additionally needs 9 units of headroom, but reports no work on None.
    // These measured fixture literals preserve that existing API distinction.'''
new='''    // All successful work is now reported: the old 19 completed units plus
    // the final 9-unit retained lookup that finds no operand. One less still
    // fails inside that same walk, before a work-bearing result can be returned.'''
assert s.count(old)==1
s=s.replace(old,new)
old='''        assert_eq!(work.borrow().plan_work - before, 19);
        if remaining == 28 {
            assert!(result.is_ok());
            assert_eq!(MAX_PLAN_WORK_PER_READ - work.borrow().plan_work, 9);'''
new='''        if remaining == 28 {
            assert!(result.is_ok());
            assert_eq!(work.borrow().plan_work - before, 28);
            assert_eq!(MAX_PLAN_WORK_PER_READ - work.borrow().plan_work, 0);'''
assert s.count(old)==1
s=s.replace(old,new)
old='''            assert_eq!(MAX_PLAN_WORK_PER_READ - work.borrow().plan_work, 8);'''
new='''            assert_eq!(work.borrow().plan_work - before, 19);
            assert_eq!(MAX_PLAN_WORK_PER_READ - work.borrow().plan_work, 8);'''
assert s.count(old)==1
s=s.replace(old,new)
# Same actual fixture demonstrates Some is counted once, not twice.
s+='''

#[test]
fn captured_retained_context_bills_the_probe_once_before_owner_query() {
    let plan = retained_plan();
    let owners = plan
        .audio_gain_owners(AudioSample(128)..AudioSample(129), Default::default())
        .unwrap();
    let owner = owners.spans()[0]
        .owners()
        .iter()
        .find(|clock| clock.instance().node.as_str() == "tone")
        .unwrap();
    let input = plan
        .audio_owner_input(owner, AudioSample(128), Default::default())
        .unwrap();
    let probe = input.retained_probe_at(AudioSample(128), Default::default()).unwrap();
    let retained = probe.input().unwrap();
    let retained_owners = retained
        .owners(AudioSample(128)..AudioSample(129), Default::default())
        .unwrap();
    let expected = input.work() + probe.work() + retained_owners.work();
    let cancelled = AtomicBool::new(false);
    let work = RefCell::new(ReadWork::default());
    let result = Context::Root
        .owner_context(
            &plan,
            owner,
            AudioSample(128),
            fixture::control(&cancelled, &work),
        )
        .unwrap();
    assert!(matches!(result, Context::Retained(_)));
    assert_eq!(work.borrow().plan_work, expected);
}
'''
p.write_text(s)
# Add the actual constructor accounting + numerical PCM oracle in its own scope.
p=r/'crates/deadpan-audio/src/owner_equalizer.rs'
s=p.read_text()
needle='''    #[test]
    fn controlled_eq_shares_work_deadline_depth_and_retains_all_halo_dependencies()'''
assert s.count(needle)==1
test='''    #[test]
    fn constructor_counts_none_probe_and_preserves_actual_tone_pcm() {
        use crate::stages::authored_eq::eq_admission_fixture as fixture;

        let plan = fixture::fixture();
        let owner = fixture::owner(&plan);
        let input = plan
            .audio_owner_input(&owner, AudioSample(128), Default::default())
            .unwrap();
        let probe = input
            .retained_probe_at(input.observed_at(), Default::default())
            .unwrap();
        assert!(probe.input().is_none());
        assert!(probe.work() > 0);
        let expected_work = input.work() + probe.work();
        let cancelled = AtomicBool::new(false);
        let mut equalizer = PreparedOwnerEqualizer::new(
            input,
            fixture::stage(&owner),
            owner.treatments().unwrap().equalizer().unwrap(),
            &cancelled,
        )
        .unwrap();
        assert_eq!(equalizer.work, expected_work);

        let mut provider = fixture::NoSources(0);
        let mut renderer = StageAudio::new(Arc::clone(&plan));
        let work = RefCell::new(ReadWork::default());
        let actual = renderer
            .read_owner_equalized_controlled(
                &mut provider,
                &mut equalizer,
                AudioSample(128),
                32,
                fixture::control(&cancelled, &work),
                0,
            )
            .unwrap();
        let mut oracle = StageAudio::new(Arc::clone(&plan));
        let oracle_work = RefCell::new(ReadWork::default());
        let expected = oracle
            .read_authored_equalizers(
                &mut provider,
                AudioSample(128),
                32,
                fixture::control(&cancelled, &oracle_work),
                0,
                &[],
            )
            .unwrap();
        assert_eq!(
            actual.samples.iter().map(|frame| frame.map(|value| (value as f32).to_bits())).collect::<Vec<_>>(),
            expected.samples.iter().map(|frame| frame.map(f32::to_bits)).collect::<Vec<_>>(),
        );
        assert_eq!(actual.suppressed, expected.suppressed);
        assert_eq!(provider.0, 0);
        assert_eq!(renderer.active_frames, 0);
        assert_eq!(oracle.active_frames, 0);
    }

'''
s=s.replace(needle,test+needle)
p.write_text(s)
