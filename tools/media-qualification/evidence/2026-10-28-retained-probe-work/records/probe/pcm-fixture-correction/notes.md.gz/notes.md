# Test-only legal PreparedOwnerEqualizer input

Captured the CURRENT live owner_equalizer.rs before editing the scratch copy.
Only constructor_counts_none_probe_and_preserves_actual_tone_pcm changes;
audit.json proves all surrounding tests and production bytes are unchanged.
Original candidate and prior diagnostic evidence remain untouched.

Cause of the reported failure:
PreparedOwnerEqualizer applies an explicitly supplied recipe at its checked
boundary. Its suffix uses authored_gain::GainSum::owner_boundary -> treatment.
An already authored nonunity EQ at that boundary remains in the suffix and
correctly refuses Unsupported("EQ requires temporal owner processing"). The
old test tried to process that authored EQ twice through the standalone API.
The constructor's work assertion passed before this unsupported read.

The corrected fixture builds a RAW root with the identical production Tone
recipe: 48,000 fps / 48 kHz sample rate, duration 512, 440Hz, -6000milli-dB, same root/tone IDs,
same project/revision and allocation. It asserts the raw owner's treatments
are empty, captures its actual checked input, and passes the separate oracle
plan's nonunity EqualizerRecipe EXPLICITLY to PreparedOwnerEqualizer at boundary 0.
No clock/context from the oracle plan is passed to the raw renderer.

The oracle remains the actual authored-EQ reader on its original separate plan
with the same Tone and recipe. Both paths use product Tone generation and native
EQ, compare actual f32 sample bits/suppression, assert zero source calls and clean
renderer ledgers. No mocked/fake PCM, guard relaxation or numerical production
change. The None probe/construction-work assertion remains before the reads.

Parent must compile/run the corrected test. The earlier old-charge negative
test failure at the work assertion is accounting evidence only, not evidence
of an old PCM failure. This correction makes the subsequent PCM comparison
legitimate; do not describe the unsupported original fixture as a production
regression. No compiler/test was run by this child.
