from pathlib import Path
import json,hashlib
s=Path('/tmp/deadpan-transcript-selectors-2026-10-22')
labels=['Transcript query needle with three separate highlights and exact ranges','Long raw transcript query keeps the compact picture and bounded status','Copied transcript union pasted in order at an explicit Edit seam']
rows=[]
for mode in ['debug-second-visual','release-visual']:
 report=json.loads((s/mode/'report.json').read_text())
 scenario=next(x for x in report['scenarios']if x['name']=='transcript-search-selectors')
 for label in labels:
  step=next(x for x in scenario['steps']if x['input']==label)
  p=s/mode/step['screenshot']
  rows.append({'mode':mode,'file':p.name,'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'checkpoint':label,'frame':step['frame']})
(s/'selected-captures.json').write_text(json.dumps(rows,indent=2)+'\n')
print(json.dumps(rows))
