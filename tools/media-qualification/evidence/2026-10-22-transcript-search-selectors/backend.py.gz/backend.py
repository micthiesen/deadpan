from pathlib import Path
import subprocess, os, json, time, hashlib, shutil, sys

s = Path('/tmp/deadpan-transcript-selectors-2026-10-22')
phase = sys.argv[1]
env = dict(os.environ, CARGO_PROFILE_DEV_OPT_LEVEL='2', DEADPAN_FFMPEG_PREFIX='/Users/michael/Library/Developer/Deadpan/ffmpeg-8.0.3-opus-1.6.1-dav1d-1.5.4-qualified-3/prefix', DEADPAN_REQUIRE_PHYSICAL_MAC='1', DEADPAN_REQUIRE_SYNTHETIC_WORKER='1')
names = subprocess.check_output(['rg', '--files', '-g', '*.rs'], text=True).splitlines()
names = [name for name in names if not name.startswith(('crates/deadpan-app/', 'xtask/'))]
rows = {}
for name in names:
    p = Path(name)
    target = s / (phase + '-source') / name
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(p, target)
    rows[name] = hashlib.sha256(p.read_bytes()).hexdigest()
(s / (phase + '-source-identities.json')).write_text(json.dumps(rows, indent=2) + '\n')
inputs = {name: hashlib.sha256(Path(name).read_bytes()).hexdigest() for name in ('Cargo.lock', 'Cargo.toml', 'rust-toolchain.toml', '.cargo/config.toml')}
(s / (phase + '-inputs.json')).write_text(json.dumps(inputs, indent=2) + '\n')

def guard():
    for name, digest in (rows | inputs).items():
        assert hashlib.sha256(Path(name).read_bytes()).hexdigest() == digest, name

args = ['cargo', 'nextest', 'archive', '--locked', '-p', 'deadpan-core', '-p', 'deadpan-analysis', '-p', 'deadpan-plan', '-p', 'deadpan-store', '-p', 'deadpan-cli', '--lib']
for target in ['transcript_search_counterfactual', 'transcript_search_provider', 'transcript_search_freshness_control', 'transcript_selection_guard', 'picture_plan', 'transcript_search']:
    args += ['--test', target]
args += ['--archive-file', str(s / (phase + '.tar.zst')), '--zstd-level=-1']
start = time.monotonic()
with (s / (phase + '-build.log')).open('w') as log:
    run = subprocess.run(args, env=env, stdout=log, stderr=subprocess.STDOUT)
(s / (phase + '-build-result.json')).write_text(json.dumps({'command': args, 'exit': run.returncode, 'seconds': time.monotonic() - start}, indent=2) + '\n')
guard()
if run.returncode:
    raise SystemExit(run.returncode)
expression = 'test(transcript_search) | test(transcript_selection) | test(same_key_proposals_and_correction) | test(provider_clock_coverage) | test(editing_search) | binary(transcript_selection_guard) | binary(transcript_search)'
run = subprocess.run(['python', str(s / 'run_archive.py'), phase, expression], env=env)
guard()
print('Backend frozen sources, inputs and archive run checked:', phase, flush=True)
raise SystemExit(run.returncode)
