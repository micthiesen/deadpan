from pathlib import Path
import subprocess, os, json, time, sys

s = Path('/tmp/deadpan-transcript-selectors-2026-10-22')
phase = sys.argv[1]
env = dict(os.environ, CARGO_PROFILE_DEV_OPT_LEVEL='2', DEADPAN_FFMPEG_PREFIX='/Users/michael/Library/Developer/Deadpan/ffmpeg-8.0.3-opus-1.6.1-dav1d-1.5.4-qualified-3/prefix', DEADPAN_REQUIRE_PHYSICAL_MAC='1', DEADPAN_REQUIRE_SYNTHETIC_WORKER='1')
subprocess.run(['python', str(s / 'freeze.py'), phase], env=env, check=True)
args = ['cargo', 'nextest', 'archive', '--locked']
for package in ['deadpan-core', 'deadpan-analysis', 'deadpan-plan', 'deadpan-store', 'deadpan-cli', 'deadpan-app']:
    args += ['-p', package]
args += ['--features', 'deadpan-app/ui-harness,deadpan-cli/synthetic-worker', '--lib', '--bin', 'deadpan-app']
for target in ['transcript_search_counterfactual', 'transcript_search_provider', 'transcript_search_freshness_control', 'transcript_selection_guard', 'picture_plan', 'transcript_search', 'preview_export']:
    args += ['--test', target]
args += ['--archive-file', str(s / (phase + '.tar.zst')), '--zstd-level=-1']
start = time.monotonic()
with (s / (phase + '-build.log')).open('w') as log:
    run = subprocess.run(args, env=env, stdout=log, stderr=subprocess.STDOUT)
(s / (phase + '-build-result.json')).write_text(json.dumps({'command': args, 'exit': run.returncode, 'seconds': time.monotonic() - start}, indent=2) + '\n')
subprocess.run(['python', str(s / 'guard.py'), phase], env=env, check=True)
if run.returncode:
    raise SystemExit(run.returncode)
expression = 'test(transcript_search) | test(transcript_selection) | test(provider_clock_coverage) | test(editing_search) | binary(transcript_selection_guard) | binary(transcript_search) | test(preview::edit_range::tests) | test(project::semantic::tests) | test(project::service::macros::tests) | test(project::tests::macros) | test(navigation::command::tests) | binary(=transcript_search_provider)'
run = subprocess.run(['python', str(s / 'run_archive.py'), phase, expression], env=env)
subprocess.run(['python', str(s / 'guard.py'), phase], env=env, check=True)
raise SystemExit(run.returncode)
