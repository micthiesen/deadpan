from pathlib import Path
import subprocess
s=Path('/tmp/deadpan-transcript-selectors-2026-10-22')
for script in ['strict_recheck.py','release.py','finish_media.py','select_captures.py']:
 subprocess.run(['python',str(s/script)],check=True)
