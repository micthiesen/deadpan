from pathlib import Path
import subprocess,os,json,time
s=Path('/tmp/deadpan-transcript-selectors-2026-10-22')
phase='provider-fixture'
env=dict(os.environ,CARGO_PROFILE_DEV_OPT_LEVEL='2')
subprocess.run(['python',str(s/'freeze.py'),phase],env=env,check=True)
args=['cargo','nextest','archive','--locked','-p','deadpan-core','--test','transcript_search_provider','--archive-file',str(s/(phase+'.tar.zst')),'--zstd-level=-1']
start=time.monotonic()
with(s/(phase+'-build.log')).open('w')as out:r=subprocess.run(args,env=env,stdout=out,stderr=subprocess.STDOUT)
(s/(phase+'-build-result.json')).write_text(json.dumps({'command':args,'exit':r.returncode,'seconds':time.monotonic()-start},indent=2)+'\n')
subprocess.run(['python',str(s/'guard.py'),phase],env=env,check=True)
if r.returncode:raise SystemExit(r.returncode)
r=subprocess.run(['python',str(s/'run_archive.py'),phase],env=env)
subprocess.run(['python',str(s/'guard.py'),phase],env=env,check=True)
raise SystemExit(r.returncode)
