# Public old-code controls

Owned additions only:

- `crates/deadpan-core/tests/transcript_search_counterfactual.rs`
- `crates/deadpan-store/tests/transcript_search_freshness_control.rs`

No production files, Cargo files, documentation, existing range controls or
fixtures changed. No Cargo commands, formatting commands, tests, Git writes,
model/network/media operations or private test hooks used.

## Core witness

Test:
`transcript_search_admission_follows_literal_ranges_cut_capture_and_paste_controls`

Reuses the unchanged public `tests/range_set/fixture.rs` synthetic 24-frame
Source. Tests literal separated windows `[2,6)`, `[10,14)`, `[18,22)`:

- Explicit range selection canonicalizes the out-of-order input and replaces
  the distracting existing Visual `[0,1)`.
- Three direct public captures retain 12 total selected frames; the hull
  `[2,22)` demonstrably contains 20 frames.
- A typed `SelectRanges` then Visual Cut program roundtrips through serde.
- Public `plan_semantic` produces one entry-revision EditedSet, named/unnamed
  aliases, a Compound with its Yank before three reverse-order ordinary
  `DeleteRange` leaves, and a 12-frame remainder.
- The set equals the public `CapturedEditSet::capture_ranges` result and the
  three independent captures, including their complete Source recipes.
- One public apply/inverse restores the exact original document.
- Three independent `SpliceSlice` operations establish exact Source windows
  through `check_oracle`. One `SpliceEditSet` has one outer group and the
  same 12-frame windows after public Ungroup. The fixture remains unchanged.
- Only the final assertion admits a serde `SemanticProgram` whose otherwise
  valid Yank selector is `{"type":"transcript_search","query":"hello world"}`.
  On old production this should fail solely with unknown variant
  `transcript_search`, after the preceding controls finish.

The existing wire discriminator is `type`, not `kind`. Root agreed to keep it.
The query is a raw JSON string. There are no references to future Rust enum
variants. This witness does not establish any transcript-query projection,
coverage semantics, phrase mapping, provider behavior or freshness guard.

## Store control

Test:
`same_key_proposals_and_correction_apply_undo_redo_leave_head_and_bank_unchanged`

Uses a deterministic temporary empty synthetic project and a populated public
Macro register bank. Reads and mutations use public Store/analysis APIs only:

- Explicitly observes absent proposal and absent corrections.
- Saves `hello world again`; exact-key replacement with `hullo world again`
  changes typed proposal/search results while retaining only that exact key.
- First Apply corrects `hullo` to `hello` at the same measured bounds and
  produces readable corrected words/version 1 without altering the proposal.
- Undo produces readable original replacement words/version 2 and explicitly
  retains a present empty correction row, distinct from initial absence.
- Redo restores identical corrected content with version 3.
- Every stage compares the full authored document, head revision and entire
  populated register bank. No authored Undo entry appears. Full validation,
  readonly reopen and rereads preserve the final state.

Expected to pass on old production. It shows why head/bank identity cannot
detect analysis changes, not that an unimplemented guard rejects publication.
No SQL corruption, SQL reads, private helpers, new dependencies or media needed.

## Execution ownership

Root owns all formatting, baseline source/input freeze, compilation and test
execution. These files have only been reviewed against current public APIs and
their complete diffs. No passing or failing test result is claimed by this
handoff. Preserve the failing old-code copy separately before adding positives.
