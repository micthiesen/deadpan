from pathlib import Path
import subprocess,json,os,time,shutil,hashlib
s=Path('/tmp/deadpan-transcript-selectors-2026-10-22')
env=dict(os.environ,DEADPAN_FFMPEG_PREFIX='/Users/michael/Library/Developer/Deadpan/ffmpeg-8.0.3-opus-1.6.1-dav1d-1.5.4-qualified-3/prefix',CARGO_PROFILE_DEV_OPT_LEVEL='2',DEADPAN_REQUIRE_PHYSICAL_MAC='1',DEADPAN_REQUIRE_SYNTHETIC_WORKER='1')
def guard(): subprocess.run(['python',str(s/'guard.py'),'lint-final'],env=env,check=True)
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def run(name,args):
 start=time.monotonic()
 with (s/(name+'.log')).open('w') as log: r=subprocess.run(args,env=env,stdout=log,stderr=subprocess.STDOUT)
 row={'command':args,'exit':r.returncode,'seconds':time.monotonic()-start}
 (s/(name+'-receipt.json')).write_text(json.dumps(row,indent=2)+'\n');print(name,json.dumps(row),flush=True)
 if r.returncode: raise SystemExit(r.returncode)
subprocess.run(['python',str(s/'freeze.py'),'lint-final'],env=env,check=True)
for name,args in [
 ('strict-passed-check',['cargo','xtask','check','--since','565cb1e8227976e7889bb5506c8b9bfa2f27604e','--no-test']),
 ('strict-passed-ui-clippy',['cargo','clippy','--locked','-p','deadpan-app','--features','ui-harness','--all-targets','--','-D','warnings']),
 ('strict-passed-format',['cargo','fmt','--all','--','--check'])]:
 run(name,args);guard()
