from pathlib import Path
import subprocess,os,json,time,hashlib,shutil
s=Path('/tmp/deadpan-transcript-selectors-2026-10-22')
env=dict(os.environ,DEADPAN_FFMPEG_PREFIX='/Users/michael/Library/Developer/Deadpan/ffmpeg-8.0.3-opus-1.6.1-dav1d-1.5.4-qualified-3/prefix',CARGO_PROFILE_DEV_OPT_LEVEL='2',DEADPAN_REQUIRE_PHYSICAL_MAC='1',DEADPAN_REQUIRE_SYNTHETIC_WORKER='1')
subprocess.run(['python',str(s/'freeze.py'),'broad-first'],env=env,check=True)
targets=['-p','deadpan-core','-p','deadpan-plan','-p','deadpan-audio','-p','deadpan-analysis','-p','deadpan-store','-p','deadpan-app','-p','deadpan-cli']
archive=s/'broad-first.tar.zst';target=s/'broad-first-extracted';target.mkdir(exist_ok=True)
with (s/'broad-first-build.log').open('w')as log:
 subprocess.run(['cargo','nextest','archive','--locked',*targets,'--archive-file',str(archive),'--zstd-level=-1'],stdout=log,stderr=subprocess.STDOUT,env=env,check=True)
reuse=['--archive-file',str(archive),'--extract-to',str(target),'--extract-overwrite','--workspace-remap',str(Path.cwd())]
expression='package(deadpan-core) | package(deadpan-plan) | package(deadpan-audio) | package(deadpan-analysis) | package(deadpan-store) | package(deadpan-app) | test(macros) | test(semantic) | test(mark) | test(project_commands) | test(selection) | test(nodes_cli) | test(ranges_cli) | test(transcript_search) | test(provider_clock_coverage) | binary(transcript_search) | binary(project_commands) | test(speech::)'
with(s/'broad-first-list.json').open('w')as out,(s/'broad-first-list.log').open('w')as err:
 subprocess.run(['cargo','nextest','list',*reuse,'-E',expression,'--message-format','json'],stdout=out,stderr=err,env=env,check=True)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
identities={}
for key,row in json.loads((s/'broad-first-list.json').read_text())['rust-suites'].items():
 tests=[n for n,c in row.get('testcases',{}).items()if c.get('filter-match',{}).get('status')=='matches']
 if not tests:continue
 p=Path(row['binary-path']);identities[key]={'path':str(p),'sha256':sha(p),'tests':tests}
helpers={}
for name in ['deadpan-app','deadpan-cli','deadpan-media-worker','deadpan-transcribe','deadpan-track']:
 source=Path('target/debug')/name;matches=list(target.rglob(name))
 if not matches:
  destination=target/'target/debug'/name;destination.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(source,destination);matches=[destination]
 assert len(matches)==1 and sha(matches[0])==sha(source),(name,matches)
 helpers[name]={'source':str(source),'path':str(matches[0]),'sha256':sha(source)}
(s/'broad-first-binaries.json').write_text(json.dumps({'test_binaries':identities,'helpers':helpers},indent=2)+'\n')
subprocess.run(['python',str(s/'guard.py'),'broad-first'],env=env,check=True)
start=time.monotonic()
with(s/'broad-first.log').open('w')as log:
 run=subprocess.run(['cargo','nextest','run',*reuse,'-E',expression,'--test-threads','8','--no-fail-fast'],stdout=log,stderr=subprocess.STDOUT,env=env)
subprocess.run(['python',str(s/'guard.py'),'broad-first'],env=env,check=True)
for row in [*identities.values(),*helpers.values()]:assert sha(Path(row['path']))==row['sha256']
result={'exit':run.returncode,'tests':sum(len(i['tests'])for i in identities.values()),'binaries':len(identities),'seconds':time.monotonic()-start,'sources_inputs_executable_hashes_unchanged':True,'test_threads':8}
(s/'broad-first-result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result),flush=True)
raise SystemExit(run.returncode)
