from pathlib import Path
import gzip,hashlib,io,json,tarfile,subprocess,os
s=Path('/tmp/deadpan-transcript-selectors-2026-10-22')
env=dict(os.environ,DEADPAN_FFMPEG_PREFIX='/Users/michael/Library/Developer/Deadpan/ffmpeg-8.0.3-opus-1.6.1-dav1d-1.5.4-qualified-3/prefix')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
assert json.loads((s/'release-final-post.json').read_text())['sources_inputs_native_and_media_binaries_unchanged']
result=json.loads((s/'release-media-fixture.json').read_text());package=Path(result['package']);movie=Path(result['movie']);root=package.parent.parent
report=json.loads((root/'transcript-search-verification.json').read_text());audio=report['audio']
assert report['passed'] and report['summary']['pictures_checked']==120 and report['summary']['pictures_failed']==0
assert [w['project_samples'] for w in audio]==[[0,192192]]
assert audio and all(not w['flags'] and w['offset_status']=='verified_zero' and w['measured_offset_samples']==0 and w['uncovered_samples']==0 and w['blocks']['low_snr_blocks']==0 for w in audio)
files=[{'path':str(p.relative_to(package)),'bytes':p.stat().st_size,'sha256':sha(p)}for p in sorted(package.rglob('*'))if p.is_file()]
assert all(not (package/row['path']).is_symlink() for row in files)
identity={'movie':str(movie),'movie_bytes':movie.stat().st_size,'movie_sha256':sha(movie),'package':str(package),'package_files':files,'summary':report['summary'],'windows':len(audio),'presented_samples':sum(w['project_samples'][1]-w['project_samples'][0]for w in audio),'qualification_limit':'Canonical preview versus encoded audio; no independent PCM oracle, listening or full mastering claim.'}
(s/'media-identities.json').write_text(json.dumps(identity,indent=2)+'\n')
buffer=io.BytesIO()
with tarfile.open(fileobj=buffer,mode='w') as archive:
 for row in files:
  p=package/row['path'];data=p.read_bytes();assert sha(p)==row['sha256']
  entry=tarfile.TarInfo(str(Path(package.name)/row['path']));entry.size=len(data);entry.mode=p.stat().st_mode&0o777;entry.mtime=0;archive.addfile(entry,io.BytesIO(data))
archive=s/'transcript-search.deadpan.tar.gz';archive.write_bytes(gzip.compress(buffer.getvalue(),mtime=0));destination=s/'owner-check';destination.mkdir()
with tarfile.open(fileobj=io.BytesIO(gzip.decompress(archive.read_bytes())),mode='r:') as tar:
 for member in tar.getmembers():assert member.isfile() and not Path(member.name).is_absolute() and '..' not in Path(member.name).parts
 tar.extractall(destination,filter='data')
extracted=destination/package.name
for row in files:
 p=extracted/row['path'];assert p.stat().st_size==row['bytes'] and sha(p)==row['sha256']
owner={'archive':archive.name,'bytes':archive.stat().st_size,'sha256':sha(archive),'package_name':package.name,'extracted':str(extracted),'files':files,'safely_extracted_and_rehashed':True}
(s/'owner-fixture-identity.json').write_text(json.dumps(owner,indent=2)+'\n')
binary=json.loads((s/'release-media-helpers.json').read_text())['deadpan-cli'];cli=Path(binary['path']);assert sha(cli)==binary['sha256']
checks={}
for name,args in [('validate',['project','validate',str(extracted)]),('doctor',['doctor','--project',str(extracted)])]:
 result=subprocess.run([str(cli),*args],env=env,capture_output=True,text=True)
 (s/('owner-'+name+'.stdout')).write_text(result.stdout);(s/('owner-'+name+'.stderr')).write_text(result.stderr)
 checks[name]={'exit':result.returncode};assert result.returncode==0,(name,result.stderr)
assert sha(cli)==binary['sha256']
after=[{'path':str(p.relative_to(extracted)),'bytes':p.stat().st_size,'sha256':sha(p)}for p in sorted(extracted.rglob('*'))if p.is_file()]
assert after==files, 'owner validation changed extracted package bytes or paths'
(s/'owner-fixture-validation.json').write_text(json.dumps({'checks':checks,'binary_sha256':binary['sha256'],'package_paths_and_bytes_unchanged_after_validation':True},indent=2)+'\n')
print(json.dumps({'pictures':120,'windows':len(audio),'samples':identity['presented_samples'],'min_block_snr_db':report['summary']['min_block_snr_db'],'owner_files':len(files),'owner_validation':checks}))
