from pathlib import Path
import hashlib,json,os,subprocess,time
s=Path('/tmp/deadpan-transcript-selectors-2026-10-22')
test='project::tests::consecutive_cached_insertions_report_distinct_committed_nodes'
rows=json.loads((s/'broad-second-binaries.json').read_text())['test_binaries']
matches=[r for r in rows.values() if test in r['tests']]
assert len(matches)==1
row=matches[0];p=Path(row['path'])
sha=lambda:hashlib.sha256(p.read_bytes()).hexdigest()
assert sha()==row['sha256']
env=dict(os.environ,DEADPAN_FFMPEG_PREFIX='/Users/michael/Library/Developer/Deadpan/ffmpeg-8.0.3-opus-1.6.1-dav1d-1.5.4-qualified-3/prefix',DEADPAN_REQUIRE_PHYSICAL_MAC='1',DEADPAN_REQUIRE_SYNTHETIC_WORKER='1')
start=time.monotonic()
r=subprocess.run([str(p),'--exact',test,'--nocapture'],env=env,capture_output=True,timeout=60)
(s/'broad-second-isolated-app.stdout').write_bytes(r.stdout)
(s/'broad-second-isolated-app.stderr').write_bytes(r.stderr)
assert sha()==row['sha256']
receipt={'binary':str(p),'binary_sha256':row['sha256'],'test':test,'exit':r.returncode,'seconds':time.monotonic()-start,'stdout_stderr_reached_eof':True,'source_candidate':'broad-second','reason':'Resolve passing nextest concurrent leaky-output warning using the same retained executable; no new source qualification'}
(s/'broad-second-isolated-app.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt));assert r.returncode==0
