# Group test failures: diagnosis and test-only fix

No production regression was identified in the two reported failures. Source inspection explains both failures without changing Group, Split, anchor resolution, or mark transforms.

## Owner clocks

`group_selection/tests.rs:318` matches all Preserve Retimes. `split.rs:204` builds new `RetimePurpose::Partition` nodes with Preserve pitch and the crop duration. The first processed frame therefore visits a two-frame Partition before the unchanged 27-frame authored Retime. Comparing both nodes to the authored owner is invalid.

The fixture processed owner occupies root [2,29), maps its local [0,27) to Repeat [0,36), and carries the framing recipe. Group [4,25) splits it into transparent local crops [0,2), [2,23), and [23,27). Every copy still retains the complete authored Retime duration, mapping, pitch and framing owner clock. This distinction is explicitly covered by the existing `anchors/location.rs:366` transparent Split test and the `RetimePurpose` contract in `document.rs:317`.

The patch compares complete ordered lists of authored (`purpose=Edit`) Retime clocks and recipes on both original and grouped paths. It asserts exactly one original owner for every frame in [2,29), zero outside, then equal lists. Missing/extra owners, changed pitch, mapping, duration, or local time fail. Existing full Source recipe, framing, exact audio sample boundary, grid rule and lattice rate assertions remain.

## Logical mark fragments

The original Local mark is at processed local 5, hence root 7. `split.rs:227` retains a Local binding on each copied full context. Both cuts produce three Bound physical bindings in deterministic order: left original, middle copy, right copy. Their coordinates remain local 5 and owner root. The left [0,2) and right [23,27) Partition crops correctly return OutsideMapping; only the middle [2,23) copy resolves, to root 7.

Bound means a valid retained authored address, not necessarily a currently visible address. `anchor.rs:366` named-mark resolution considers all bound fragments, ignores inaccessible crops and retains the exact matching binding ordinal. Existing `split.rs` integration tests already expect a Bound fragment hidden by a Partition to return OutsideMapping.

The patch requires exactly three Bound Local fragments with unchanged position/owner and exact result sequence [OutsideMapping, root7, OutsideMapping]. It also resolves the actual named mark before/after, requires exact and quantized root positions unchanged, and checks the sole matching ordinal changes from 0 to 1. Ungroup must retain the entire mark map and the complete resolved result. No catch-all ignored errors or merely nonempty success checks were added.

## Delivery

Only `crates/deadpan-core/src/group_selection/tests.rs` is changed in the scratch after tree. The shared checkout is unchanged. The scratch file was formatted with rustfmt. No build, test, Cargo, native app or Git command was run. Root must apply after the frozen gate and run the affected tests.
