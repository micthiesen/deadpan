# Core legacy adapter pruning

Scratch-only patch against the current count-setter source identified by the parent as `ee933f6c`. The manifest records exact file hashes and confirms every changed baseline matched the checkout when packaged. The checkout was not modified.

## Deliverables

- `core-prune.patch`: apply before the adapted Group patch.
- `manifest.json`: before/after SHA256 for all 73 changed paths.
- `removed-tests.json`: all 51 removed explicit tests, 232 removed macro-generated tests, and six retained/renamed mixed tests.
- `removed-items.json`: initial removal decisions and anchors. The exact patch and test inventory are authoritative; the follow-up cleanup also removes the three adapter-only contextual validators described below.
- `before/`, `after/`: exact complete core snapshots.
- `group-after-prune.patch`, `group-after-prune-manifest.json`: separate 14-file Group patch against the pruned tree, with complete baseline hashes in `group-after-prune/{before,after}`.

The original Group and audio equivalence artifacts under `/tmp/deadpan-group-20261003` remain unchanged.

## Removal boundary

Remove all 32 public `legacy_v1` through `legacy_v32` modules and files, their old document/request/history grammar tests, and eight private helpers that have no remaining runtime or test caller: `legacy_asset`, `legacy_framing_v37`, `legacy_hold_v18`, `legacy_mark`, `legacy_mark_v13`, `legacy_sound_routes`, `legacy_source_mapping`, and `legacy_video_mapping_v34`.

Remove `insert_time::{validate_v24_context, validate_v25_context, validate_legacy_context}`. These exist solely to constrain old full-document command replay. Keep the current insertion reducer and its `resolve_legacy_suffix`, `root_boundary`, and physical source resolution unchanged.

The current document schema remains 43. Current commands, serialization, request admission, authored temporal behavior, audio lineage, history patch application and exact-time arithmetic are unchanged. This patch does not simplify historical audio inputs embedded in the current format.

## Retained helper rationale

- `legacy_audio_mapping_v19`: `audio_context::LegacyInput` still deserializes, upgrades and projects this mapping.
- `legacy_audio_mapping_v35`: `audio_context::LegacyInputV4` still uses this mapping; `sound_events` still requires its `sound_mapping` admission helper.
- `legacy_audio_binding_v21::validate_v22_layout` and its `OldFrozenLayout` grammar: current `AudioContext::from_json` requires this preflight for retained schemas below 3. The runtime body is unchanged.
- `legacy_audio_binding_v35::supports_layout`: current `AudioContext::validate` checks retained schemas below 5 with this helper. The runtime body is unchanged.
- Independent codec tests in `legacy_audio_binding_v20` and `legacy_audio_binding_v36` remain. Their v20/v21/v22/v35 state projections and bounded decoders remain test-only, including the unchanged duplicate-key, recipe-kind, dormant-support and local-origin rejection checks. Only full-document adapter-generated exercises are removed.
- Adapter-only `is_empty` and `upgrade` methods on those test wrappers are removed. Their projection/change/Deserialize methods remain where tests use them.

No `legacy_*` glob was used to prune runtime source helpers. Eight helper deletions followed an exact module-reference inventory. Whole-file removal of dedicated legacy test suites followed inspection of their full adapter-bound purposes.

## Test preservation and static verification

Syntax-aware `ast-grep` function ranges removed standalone mixed-file adapter tests. Explicit exact section anchors removed adjacent adapter-only macro blocks and portions of mixed tests. Six mixed tests keep every current assertion, with names reflecting the remaining subject: audio edge omission, framing limits, closed source-trim resources, roll request round-trip, trim routes, and sound route admission. A before/after AST comparison confirms 743 surviving explicit test bodies are unchanged after whitespace normalization.

Completed without Cargo:

- Scoped rustfmt on modified Rust files, with child-module traversal disabled.
- AST syntax scan: no `ERROR` nodes.
- Exhaustive core `legacy_v1` through `legacy_v32` reference search: zero matches.
- Exact old-helper dependency inventory and static orphan/import review.
- Patch dry-run against each corresponding before-tree: both patches apply cleanly.
- All changed before-file hashes match the checkout.

Not run: Cargo check, tests, Clippy, native app, media or performance qualification. No measured build-speed claim is made. Root must apply the matching store pruning before workspace compilation because it removes the external callers of the deleted public adapters. Root also owns the remaining obsolete app migration test reference.

Recommended verification after integration: strict workspace lint, core and store test suites, then the existing affected current-format/history/media gates. Existing audio-context and sound-event tests are particularly important because those retain old codec vocabulary intentionally.

## Group adaptation

The adapted Group patch omits only four old `legacy_v29` through `legacy_v32` refusal-classifier hunks and inserts Group's module/export lines into the pruned `lib.rs`. All 13 non-`lib.rs` resulting Group files are byte-identical to the original frozen Group after-tree. Group semantics and tests are otherwise identical. The inherited Group validation and PCM qualification remain unrun.
