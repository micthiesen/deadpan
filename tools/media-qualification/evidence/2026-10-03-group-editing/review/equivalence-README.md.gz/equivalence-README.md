# Group/Ungroup audio and picture-plan equivalence tests

## Delivery and checks

- `group-equivalence.patch`: two-file patch, one new test module and its registration in `crates/deadpan-audio/tests/composite_insert.rs`.
- `manifest.json`: patch and per-file before/after SHA-256 hashes.
- `before/`, `after/`: exact baseline and proposed files.
- Requires the separate GroupSelection core patch in `/tmp/deadpan-group-20261003/core/core.patch`.
- Does not modify that frozen patch or the shared checkout.
- Scoped rustfmt, static source review, whitespace check and patch dry-run passed. Checkout baseline hashes matched at generation.
- No Cargo/compiler/test/native/media process or Git command was run.

## Tests

Run after integrating the core and host changes:

`cargo test --locked -p deadpan-audio --test composite_insert group_selection`

1. `partial_ntsc_source_group_keeps_offset_pcm_and_exact_picture_coordinates`
   - 8-frame NTSC Source, +17 mix-sample offset, live camera envelope and gain envelope.
   - Group exact range [1,5), then Ungroup the neutral wrapper.
   - Complete 12,813-sample raw and authored baseline; independent sample-phase witness at absolute sample 257 checks phase 240 against the existing qualified reconstruction kernel.
   - Compare every output f32 bit for Group and Ungroup, including prefix, group and suffix.
   - Compare every exact Source picture request and ordered authored framing pose/owner clock at every project frame.

2. `partial_repeat_preserve_group_and_ordinary_ungroup_keep_authored_pcm_and_routes`
   - 19-frame NTSC output with three Source plays, framed/treated Repeat and Sequence owners, partial crop of a full Preserve stage, negative Source sample offset, silent Hold and source suffix.
   - A preceding real InsertTime creates retained bindings/resume clocks and a nonidentity root sound route. A concrete sound permission produces real root-event PCM during a silent Hold.
   - Group [4,13) within ordinary scope [3,16), splitting inside Repeat at one endpoint and cropped Preserve at the other. Ungroup preserves the endpoint contexts.
   - Separately exercise existing ordinary Group/Ungroup across the three complete scoped children and assert literal node/binding restoration.
   - Complete 30,430-sample raw and authored baseline, nonzero Repeat/Preserve/suffix witnesses, raw silence versus actual permitted effect audio.
   - Compare every f32 bit and exact picture/framing plan for all four results. Sound recipes, nontrivial route journal and silent-Hold permission remain identical.

For every resulting document and each raw/authored mode, the test opens a fresh verified WAV session and fresh StageAudio. It first seeks cold to a selected tail window, revisits it after the head, then covers every sample with shuffled 193-sample chunks against a forward baseline produced in 251-sample chunks. Comparison uses f32::to_bits, including signed zero, and rejects nonfinite samples.

## Scope and limits

Actual audio uses the established composite_insert Provider: SHA-256-verified `native/deadpan-source/tests/audio-fixtures/pcm-mono-44100.wav`, measured AudioSession index and canonical source/stage audio pipeline. The fixture's project catalog/qualification identifiers are test data, not a durable ProjectStore media-admission receipt.

Video descriptors are synthetic explicit clocks paired with that test asset, following the existing trim fixture pattern. Pure RenderPlan checks compare complete Source picture requests, retained picture context, local provider position, gap identity and ordered nonidentity framing operations with exact owner clocks. They validate every resulting occurrence address. They do not decode video, exercise GPU intermediate clipping, display/export frames, device delivery or a limited/mastered bus.

Both tests are unrun. Passing rustfmt and patch dry-run establishes syntax formatting and patch applicability only. No PCM or picture equality result is claimed yet.
