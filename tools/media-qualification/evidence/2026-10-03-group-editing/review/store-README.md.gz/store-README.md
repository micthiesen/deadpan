# Store legacy pruning scratch handoff

Patch: `store-prune.patch`. The manifest includes exact before/after SHA-256 hashes and additions/deletions. All tracked bases matched the shared checkout at packaging time. No shared source was written. The separate Group host patch is unchanged.

## Admission and recovery boundary

- Database 55 and document 43 remain current. No schema bump.
- Database 52 remains the only explicit migration. The normal opener returns `MigrationRequired(52)` without writing. Migration acquires the existing writer lock, takes a consistent persistent SQLite backup, validates an isolated candidate, adds only Compound checkpoints and the register tables, rejects preexisting Compound requests, validates complete current history and operational state, then promotes through SQLite Backup atomically.
- Database 1 through 51, 53, 54, and all other noncurrent/non52 versions return existing `UnsupportedSchema` during the read-only application/version probe. No document parse, writer acquisition, writable database, WAL mode change, backup, directory repair or operational recovery is initiated for these packages. Refusal does not delete or recreate a package. Unsupported development packages must be recreated explicitly if needed.
- Current migration invokes current history replay directly. The specialized replay retains the same bounded SQL reads, revision chronology, unique allocations, request/forward/snapshot agreement, inverse agreement, ordinary and Compound provenance checks, qualified Hold source checks, cursor and redo reconstruction, and unreachable-history rejection.
- Checkpoint, generation attempt recovery, accepted generated-media reads, original/source qualification, render checkpoints, publication durability and reconciliation remain intact. In their large modules this patch removes only four unreachable migration-only helpers: generation schema8 columns, attempt schema8 tables, and pre42 render/publication intent grammar preflight. Current validators and current historical grammar remain unchanged.
- Migration promotion crash/disk-full/reader tests remain. The former schema1 reader/lock integration cases now exercise the supported schema52 upgrade. Generation, render, publication, source registration, register and Compound suites outside the migration harness are unchanged.

## Tests

`removed-test-inventory.json` lists every removed test name and every retained/new test name in changed files. These are names, not claims that every assertion was discarded.

Obsolete acceptance/vocabulary matrices are removed, including seven purely obsolete child modules. Archived old SQL fixtures remain available for refusal evidence and developer history. Existing schema39/40/41 refusal cases remain, now joined by all1..51 and53/54, malformed document cells, absent native directories, an already-held writer, exact main/WAL byte preservation and no new backup/lock files.

Mixed current-format assertions are retained:

- `framing`: current InsertTime, redo, framing, stale commit and reopen assertions, without a downgrade.
- `picture_context`, `source_selection`: captured geometry and exact selected source-audio setters, undo/redo, bindings and reopen.
- `audio_reanchors`, `audio_gap_bindings`: exact selected mappings, phase terms, reanchor chains, gap bindings, fresh revision checks and durable navigation.
- `insert_time`, `retime`: original current-only transactions, inverse checks, late/stale rejection and complete durable navigation.
- `sound_routes`: qualified source-receipt corruption rejection, forced history failure rollback, original sound recipes and successive route transforms across reopen.
- `gain`: exact gain, duration/lineage/binding preservation, stale request, Undo/Redo/reopen.
- `current_authoring`: direct audio/video Duration and Placement, occurrence audio Placement and edge-policy changes from old schema10..15 mixed tests, now against a current source/hold fixture with a real generation request and exact relevance preservation.
- Supported schema52 migration now has an authored edit, pending redo, complete prior-cell and backup equality, subsequent Undo/Redo. Current55 migrate stays read-only while a writer is held. Forged schema52 Compound is rejected with retained backup.

Six fixed document43 snapshot fixtures retain the exact previously used authored states. `fixture-provenance.json` records original SQL/head and the one-time version conversion. Two retain exact original-media and measured qualification rows plus the existing offset-bframes media bytes. Test setup seeds only a current initial snapshot, then generates its new history with current commands. No test calls a removed adapter or upgrades an obsolete package. These fixtures do not claim newly measured decoder evidence.

## Verification

Performed: scoped rustfmt, source/parser inspection, exhaustive adapter reference search in the scratch after-tree, exact baseline hash comparison and static whitespace validation.

Not run: Cargo, compilation, unit/integration tests, Clippy, native processes or replays. Root owns verification. Recommended first `deadpan-store --test migration`, then full core/store/CLI/app suite and strict Clippy. In particular exercise generation/checkpoint/publication/source registration/accepted-media suites because their boundaries must remain unchanged. The new current-format fixtures and generation-bearing authoring test need runtime validation.
