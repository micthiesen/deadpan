# Installed macOS Unicode fallback

Scratch patch, frozen for parent review and integration. The checkout is unchanged.

## Diagnosis and implementation

Deadpan enables eframe's built-in fonts and sets text sizes in
`preview/style.rs`, but never adds a CJK font. The installed epaint 0.36.2 default
faces have no glyphs for `答え`, so the command field, group label and breadcrumb
all use the replacement glyph.

The patch calls `fonts::install` once when constructing `DeadpanApp`. The native
replay uses this same constructor. It appends two locally installed fonts to both
default families, preserving every existing face and its priority:

| System font | TTC face | Measured bytes | SHA-256 |
| --- | --- | --- | --- |
| `/System/Library/Fonts/ヒラギノ角ゴシック W3.ttc` | 0, HiraginoSans-W3 | 7,863,660 | `833776a6fd68e2c71c0c52fd8041195bd3d0a336cdb278170b7ad71c7e1b3475` |
| `/System/Library/Fonts/Supplemental/Arial Unicode.ttf` | 0, ArialUnicodeMS | 23,278,008 | `876af2cd4854644e7f3e7feb2f688997fdb3343c6df6693611209c9dfb47ccec` |

Hiragino supplies Japanese glyphs; Arial Unicode additionally supplies the tested
Simplified Chinese, Traditional Chinese and Korean glyphs. No font bytes are
copied into the repository or these scratch artifacts. The metadata-only probe
is `../inspect-fonts.py`, with results in `../system-fonts.json`.

The loader opens two fixed paths nonblocking, checks regular-file metadata, and
caps actual reads and admitted font bytes at 32 MiB in aggregate. A process-wide
`OnceLock` retains the admitted bytes. Missing, oversized, malformed, wrong-index
or incomplete candidates are skipped independently. Failed admission preserves
the built-ins. This is bounded startup I/O, not a font directory scan.

The added direct `skrifa = =0.44.0` dependency is exactly the existing epaint
parser and locked version. Only the deadpan-app dependency list changes in
Cargo.lock. Its existing `std` feature is reused, without another package or
version. Parser and glyph-outline admission precede epaint, whose font
constructor otherwise panics on invalid faces.

## Replay evidence hook

After the first app frame, the Group replay can retain its existing state and
input assertions and additionally check the real egui lookup:

```rust
context.fonts_mut(|fonts| {
    assert!(fonts.has_glyphs(&egui::FontId::proportional(13.0), "答え"));
    assert!(fonts.has_glyphs(&egui::FontId::monospace(13.0), "答え"));
});
```

The installed-font report is available to descendants of `preview` through the
private module, with relative paths adjusted for the caller:

```rust
let report = context.data(|data| {
    data.get_temp::<fonts::Report>(egui::Id::new(fonts::REPORT_KEY))
});
```

`Report` is serializable and contains admitted path, face index, byte count and
SHA-256, plus skipped paths and reasons capped at 160 characters. It contains no
font bytes. The report comes from actual startup admission, not a second scan.

## Tests and qualification

Four CPU-only tests are included. They use the actual egui font API to reject
tofu, verify Japanese/Chinese/Korean glyph coverage in both families, and prove
ASCII widths and font priority are unchanged. They also cover missing files,
directories, oversized metadata and actual reads, invalid bytes, invalid TTC
indices, missing glyphs, aggregate limits and recovery through the second font.

Suggested parent verification:

1. `cargo test --locked -p deadpan-app preview::fonts`
2. Affected app checks and strict workspace lint.
3. Group visual replay with the glyph assertions and provenance above.
4. Inspect the captured command, name and breadcrumb containing `答え` at normal
   and compact sizes. Font support alone does not prove successful GPU painting.

Completed here: scoped rustfmt, AST syntax scan, whitespace scan, exact baseline
hash comparison, installed-font metadata inspection and clean patch dry-run.
No Cargo, compilation, tests, Clippy, app launch or GPU capture was run.

The installed-font tests intentionally require the measured macOS fonts. Other
macOS releases can fail qualification if those paths or coverage change, while
the production loader continues with its admitted fallbacks. This is not full
Unicode coverage, complex-script shaping qualification or universal macOS font
discovery. Startup timing and appearance remain unmeasured until parent testing.

## Artifacts

- `font-fallback.patch`: git-apply-compatible patch for five files.
- `manifest.json`: exact before/after hashes and verification inventory.
- `before/`, `after/`: exact source snapshots; new files exist only under after.

Patch SHA-256:
`b46cc6de54e3e180e48b00be46464a95327614dc711b241352121c18bba30945`

## Review correction

The first uncompiled patch used LowerHex on the pinned sha2 digest Array, which
does not implement that trait. The replacement follows the existing GPU helper:
format each digest byte as two hexadecimal digits and collect the String.
The superseded patch and its original manifest/README remain under
`superseded-sha2-lowerhex/`; its SHA-256 is
`a255118f33bd8fbb71ce211f363008446af8841113f10c046c24f5ed0a0eba19`.

The actual egui 0.36.2 source confirms `Context::fonts` supplies
`&FontsView`, `fonts_mut` supplies `&mut FontsView`, and
`FontsView::definitions(&self)` returns `&FontDefinitions`, which supports
PartialEq. Glyph checks/width queries require the mutable view. All tests call
`run_ui` before accessing fonts and use the matching APIs.
