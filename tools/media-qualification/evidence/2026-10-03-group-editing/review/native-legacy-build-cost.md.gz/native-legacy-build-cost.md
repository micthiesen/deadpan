# Frozen legacy schema surface and build cost

Read-only investigation on 2026-10-03 in `/Users/michael/Code/deadpan`.
No builds, tests, configuration changes or repository edits were performed.
Counts below describe source before the proposed legacy pruning, including the
Repeat count setter milestone and excluding frozen Group patches in scratch.

## Recommendation

Reject database schemas 1 through 38 before writes and remove the corresponding
32 frozen core document/history adapters. Keep schema 52's additive migration,
current core schema 43, current database schema 55 and all current recovery.
This is a material maintenance simplification. Its compilation benefit is
plausible but unmeasured; the observed slow gates do not establish causation.

## Exact source inventory

Lines count physical source lines, bytes count file bytes. Test target counts
refer to top-level Cargo integration targets, not source module count.

| Surface | Files | Lines | Bytes | Integration targets |
|---|---:|---:|---:|---:|
| Core `legacy_v1.rs` through `legacy_v32.rs` | 32 | 31,091 | 936,573 | Compiled into core |
| Other core `legacy_*.rs` helpers | 15 | 2,140 | 73,169 | Mixed current/legacy use |
| All core `src/**/*.rs` | 138 | 73,893 | 2,464,641 | Library and library tests |
| Core dedicated `tests/legacy_*.rs` | 9 | 1,801 | 88,915 | 9 |
| Store `src/migration.rs` | 1 | 408 | 19,060 | Library |
| Store `src/validation.rs` | 1 | 883 | 41,100 | Library |
| Store `tests/migration.rs` and child modules | 22 | 8,779 | 369,145 | 1 |

The 32 adapters are 42.1% of core source lines, 38.0% of its source bytes,
and contain 348 serde derive declarations out of 667 in core source. Their
modules are unconditional in `crates/deadpan-core/src/lib.rs:44` through 75.
The remaining legacy helpers contain 55 serde derive declarations.

Core has 53 top-level integration targets, store has 24, and the workspace has
163 top-level integration source files across `crates/*/tests` and
`native/*/tests`. There are 19 workspace members. Neither core nor store disables
Cargo's automatic integration test discovery or defines manual test targets.

Direct versioned-adapter references occur in 26 core integration source files
belonging to 25 targets, with 672 textual references. Those include mixed current
feature tests, so whole-target removal would lose current coverage. For example,
`crates/deadpan-core/tests/source_slip.rs:808` runs the frozen-command refusal
matrix across all 32 adapters.

| Adapter | Lines | Bytes |
|---|---:|---:|
| legacy_v1.rs | 525 | 16,342 |
| legacy_v2.rs | 409 | 12,517 |
| legacy_v3.rs | 484 | 15,148 |
| legacy_v4.rs | 912 | 26,517 |
| legacy_v5.rs | 1,030 | 33,531 |
| legacy_v6.rs | 1,081 | 35,515 |
| legacy_v7.rs | 1,158 | 38,579 |
| legacy_v8.rs | 1,152 | 38,387 |
| legacy_v9.rs | 698 | 19,915 |
| legacy_v10.rs | 977 | 31,217 |
| legacy_v11.rs | 772 | 22,243 |
| legacy_v12.rs | 873 | 25,537 |
| legacy_v13.rs | 873 | 25,546 |
| legacy_v14.rs | 907 | 26,322 |
| legacy_v15.rs | 917 | 26,712 |
| legacy_v16.rs | 914 | 26,919 |
| legacy_v17.rs | 935 | 27,430 |
| legacy_v18.rs | 955 | 28,205 |
| legacy_v19.rs | 967 | 28,363 |
| legacy_v20.rs | 967 | 28,382 |
| legacy_v21.rs | 967 | 28,393 |
| legacy_v22.rs | 967 | 28,365 |
| legacy_v23.rs | 1,054 | 31,020 |
| legacy_v24.rs | 1,054 | 31,014 |
| legacy_v25.rs | 1,054 | 31,003 |
| legacy_v26.rs | 1,051 | 30,860 |
| legacy_v27.rs | 1,073 | 31,292 |
| legacy_v28.rs | 1,123 | 32,452 |
| legacy_v29.rs | 1,270 | 38,420 |
| legacy_v30.rs | 1,311 | 39,707 |
| legacy_v31.rs | 1,327 | 40,264 |
| legacy_v32.rs | 1,334 | 40,456 |

## Existing gate evidence

Sources:

- `/tmp/deadpan-repeat-count-20261003/workspace-tests-2.json`
- `/tmp/deadpan-repeat-count-20261003/workspace-tests-2.log`
- `/tmp/deadpan-repeat-count-20261003/clippy.json`
- `/tmp/deadpan-repeat-count-20261003/clippy.log`

The test command was `cargo test --workspace --locked --no-fail-fast`, based on
commit `9870a4cbc706ad8cce8b59d4cb13ec5c2d3a9c33`. The recorder reported unchanged
source, exit 0 and 1,317.3063611253165 seconds. The source manifest SHA-256 was
`dd00cc7eda98233c93012ab17c1ffa051322aea775145d4eaecbd8b7c62304cc`.

The log reports compilation in 9m 54s, or 594 seconds. Across 201 result blocks
(unit, integration and documentation tests), 3,799 tests passed and reported
execution durations sum to 470.75 seconds. These summaries do not account for
all wall time; the remaining time cannot be attributed from this evidence.

| Dedicated legacy test target | Executed tests | Reported seconds |
|---|---:|---:|
| legacy_audio_editorial | 32 | 0.02 |
| legacy_audio_lineage | 2 | 0.00 |
| legacy_audio_selection | 21 | 0.13 |
| legacy_dormant_audio | 66 | 0.09 |
| legacy_framing_clock | 15 | 0.02 |
| legacy_marks | 5 | 1.73 |
| legacy_source_edit_window | 32 | 0.03 |
| legacy_split | 4 | 0.01 |
| legacy_video_selection | 32 | 0.03 |
| Store migration | 134 | 47.25 |
| Total | 343 | 49.31 |

The core-only legacy total is 209 tests and 2.06 seconds. Some store migration
tests cover current-schema refusal/no-op behavior and must remain. Thus 49.31
seconds is an observed target-duration sum, not a promised pruning speedup.

Root later reported strict default workspace Clippy completed cleanly in
1,082.9 seconds. No per-crate compiler timing or controlled comparison was
available. The adapters enlarge core parsing, derives, type checking and code
generation, but downstream tests load compiled dependency metadata rather than
each reparsing the complete adapter source. A compilation speedup is unmeasured.

## Bounded memory observation and sampling limitation

At 2026-10-03 12:47:03 UTC, a read-only process snapshot showed 17 Clippy drivers:

- Per-process CPU: 8.0% through 10.0%.
- RSS: 256,960 through 275,408 KiB; aggregate 4,527,616 KiB, about 4.32 GiB.
- VSZ: 435,751,824 through 435,800,496 KiB. This is virtual address space, not
  physical memory consumption.
- Physical RAM: 137,438,953,472 bytes, or 128 GiB.
- `memory_pressure -Q`: 96% system-wide memory free.
- `sysctl vm.swapusage`: total 0.00M, used 0.00M.

That snapshot does not support memory pressure as the bottleneck. Repository
`.cargo/config.toml` contained only the macOS deployment target and the doctor
alias, with no job-count setting. No user Cargo config existed at the inspected
default `~/.cargo/config` or `~/.cargo/config.toml` locations.

Two bounded attempts selected a Clippy driver only when its Cargo parent command
included both `--workspace` and `ui-harness`. No process matched. Root clarified
that UI Clippy instead used `cargo clippy --locked -p deadpan-app --all-targets
--features ui-harness -- -D warnings`. The selection predicate was therefore
inapplicable to that command. No process was sampled, no stack evidence was
obtained, and no absence of active compiler work can be inferred. No further
machine profiling was performed.

## Safe removal and retained recovery

1. In store `schema.rs:19` and `migration.rs:48`, reject schemas 1 through 38
   before writer acquisition, WAL, backups or document parsing. Keep schema 52
   as `MigrationRequired`, with its existing isolated backup/promotion path.
2. Remove core versioned adapters and the old-schema variants/dispatch in
   `validation.rs:171`. Preserve `validate_history` and the current replay
   algorithm at `validation.rs:467`.
3. Remove obsolete adapter assertions only. Expand the existing no-write refusal
   witness at `tests/migration/development_break.rs:90`; retain current-schema
   no-op, schema-52 migration, and forged-history refusal checks.

Preserve current forward/inverse replay, Undo/Redo, never-reused revision IDs,
register and compound validation. Current open calls `validate_history` at
`deadpan-store/src/lib.rs:415`; checkpoint paths call it at `lib.rs:481` and
`checkpoint.rs:260`. Current generation, accepted-media, publication and
checkpoint recovery do not depend on versioned document conversion.

Do not delete every legacy-named helper. Current frozen audio context admission
uses them at `deadpan-core/src/audio_context.rs:42`, 73, 253, 325 and 392.
Current sound deserialization uses `legacy_audio_mapping_v35::sound_mapping` at
`sound_events.rs:36`. Their embedded provenance semantics need preservation.
Current generic and multi-video project support is separate from old-format
admission and remains intact.

## Frozen Group patch overlap

The Group core patch changes `legacy_v29.rs`, `legacy_v30.rs`, `legacy_v31.rs`
and `legacy_v32.rs`, each adding a `Command::GroupSelection` refusal arm. These
hunks disappear if pruning is integrated first. `deadpan-core/src/lib.rs` also
gets a changed base hash, although its Group module/export additions are separate
from the versioned adapter declarations. The narrow removal needs no Group
native or host file edits. Regenerate affected patch hashes after rebasing.
