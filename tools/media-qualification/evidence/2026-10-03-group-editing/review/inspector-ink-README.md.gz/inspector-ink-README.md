# Inspector title glyph overhang

Scratch-only patch, based on the exact file hashes in `manifest.json`. The
checkout remains unchanged. This patch depends on the installed macOS font
fallback already integrated by the parent.

## Cause and fix

The failed Group replay `groups-visual-4/report.json`, scenario 1 check 41,
records the ordinary inspector title `l'été 答え "oui"` at y=120..139 while its
scroll clip begins at y=123. The other two copies of the title paint fully.

In egui 0.36.2, `widgets/label.rs:257-265` allocates `galley.size()` and places
the galley at that logical box. In epaint, `shapes/text_shape.rs:74-78` computes
paint bounds from the separate `galley.mesh_bounds`. Mixed fallback faces are
centered using their face metrics in `text/text_layout.rs:977-984`, so real glyph
ink can extend above or below the nominal row. The first title in the ScrollArea
has no room for that overhang.

`style::ink_padded_label` measures the exact galley once and adds only its
nonnegative vertical overhang, rounded up to whole logical points. It then uses
the standard `Label` with the same galley. Standard accessibility, text selection
and caller hover behavior remain available. Font scale and scroll clips stay
unchanged. Padding is allocated before the first paint and also moves subsequent
content below bottom overflow.

The ordinary inspector keeps its explicit 17-point size and truncation. The
scoped inspector keeps its Heading style and inherited wrapping. Both call sites
are top-down text columns. The helper is not intended for horizontal or grid
layout, and does not alter line spacing inside a wrapped title.

The patch also removes the redundant second `trim_start()` immediately before
`split_whitespace()` in the Group command hint, as requested by the parent after
Clippy. The first trim before stripping `:` remains.

## Tests and verification

Three macOS CPU tests use the real installed fallback fonts and egui paint
shapes. They cover:

- The old unpadded first row clipping at one or more of 1, 1.25 and 2 pixels per
  point, using the exact failing label.
- Actual paint bounds inside both the scroll clip and viewport for ASCII/CJK,
  ordinary/scoped title layouts, two sidebar widths and three scales; wrapping
  policy and space before following content remain explicit assertions.
- Identical ASCII title and following-row geometry when its glyph ink already
  fits the logical row.

The tests keep real glyph-availability assertions, so tofu cannot satisfy the
paint-bound checks. Suggested parent command:
`cargo test --locked -p deadpan-app preview::style::ink_tests`.

Completed: exact baseline comparison, scoped rustfmt, added-line whitespace
check, full patch review, pinned egui/epaint source inspection, clean patch
dry-run. No Cargo, unit tests, Clippy, native launch or GPU replay was run here.
The parent retains Group replay and capture inspection qualification.

Patch: `inspector-ink.patch`

SHA-256: `fd11fdb551d755cd0edb9ded9f196fe03e3ad46ba2bba625391026b41f71847f`
