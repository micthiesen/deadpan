from pathlib import Path
import difflib,json,hashlib
s=Path(__file__).resolve().parent
isolated=Path('/tmp/deadpan-query-groundwork-2026-10-26/scoped')
old=Path('/tmp/deadpan-occurrence-support-2026-10-27')
bases={
'crates/deadpan-plan/src/audio_signal.rs':old/'audio_signal.before.rs',
'crates/deadpan-plan/src/audio_sound_owner_context.rs':old/'audio_sound_owner_context.before.rs',
'crates/deadpan-plan/src/audio_source_occurrence.rs':old/'audio_source_occurrence.before.rs',
'crates/deadpan-plan/src/audio_source_occurrences.rs':old/'audio_source_occurrences.before.rs',
'crates/deadpan-plan/src/audio_source_voice.rs':old/'audio_source_voice.before.rs',
'crates/deadpan-plan/src/lib.rs':old/'lib.before.rs',
'crates/deadpan-plan/tests/audio_definition/source_occurrence.rs':old/'source_occurrence_tests.before.rs',
'crates/deadpan-plan/src/audio_source_occurrence_support.rs':None,
'crates/deadpan-plan/tests/audio_definition/support_discovery.rs':None,
'crates/deadpan-audio/src/sound_clocks.rs':s/'sound-clocks-head.rs',
'crates/deadpan-audio/src/sound_clocks/tests.rs':s/'sound-clocks-tests-head.rs',
}
patch=''
for rel,base in bases.items():
 before=base.read_text() if base else ''
 after=(isolated/rel).read_text()
 dest=s/'scope'/rel
 dest.write_text(after)
 patch+=''.join(difflib.unified_diff(before.splitlines(True),after.splitlines(True),fromfile='a/'+rel if before else '/dev/null',tofile='b/'+rel))
(s/'scoped.patch').write_text(patch)
(s/'scoped-pins.json').write_text(json.dumps({rel:hashlib.sha256((isolated/rel).read_bytes()).hexdigest() for rel in bases},indent=2)+'\n')
lines=[]
for name,binary in json.loads((s/'scoped-binaries.json').read_text()):
 import re
 label='scoped-'+name.replace('_','-')
 counts=re.findall(r'test result: (\w+)\. (\d+) passed; (\d+) failed; (\d+) ignored;', (s/(label+'.stdout')).read_text())
 assert len(counts)==1
 lines.append(dict(name=name,passed=int(counts[0][1]),failed=int(counts[0][2]),ignored=int(counts[0][3])))
report=dict(plan_passed=sum(x['passed'] for x in lines if x['name'] not in ['deadpan_audio','stages']),audio_library_passed=next(x['passed'] for x in lines if x['name']=='deadpan_audio'),stages_passed=next(x['passed'] for x in lines if x['name']=='stages'),failed=sum(x['failed'] for x in lines),ignored=sum(x['ignored'] for x in lines),targets=lines)
(s/'scoped-suite-summary.json').write_text(json.dumps(report,indent=2)+'\n')
print({k:v for k,v in report.items() if k!='targets'})
