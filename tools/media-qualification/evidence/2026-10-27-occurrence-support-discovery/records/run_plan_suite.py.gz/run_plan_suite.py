from pathlib import Path
import json,subprocess,sys,shutil,hashlib
scratch=Path(__file__).resolve().parent
binaries=[]
for line in (scratch/'focused-build.stdout').read_text().splitlines():
    try: row=json.loads(line)
    except ValueError: continue
    if row.get('reason')!='compiler-artifact' or not row.get('executable') or not row.get('profile',{}).get('test'):
        continue
    src=row['target']['src_path']
    if '/crates/deadpan-plan/' in src:
        binaries.append((row['target']['name'],row['executable']))
    if row['target']['name'] in ['stages','deadpan_audio','deadpan_plan']:
        target=scratch/(row['target']['name'].replace('_','-')+'-first')
        assert not target.exists()
        shutil.copy2(row['executable'],target)
(scratch/'plan-binaries.json').write_text(json.dumps(binaries,indent=2)+'\n')
for name,binary in binaries:
    label='plan-'+name.replace('_','-')
    code=subprocess.call([sys.executable,str(scratch/'run.py'),'--binary',binary,label,'--',binary,'--nocapture','--test-threads=1'])
    if code:
        raise SystemExit(code)
print('Complete Plan unit/integration executable set passed',flush=True)
