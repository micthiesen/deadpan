from pathlib import Path
import json,subprocess,sys
s=Path(__file__).resolve().parent
selected=[]
for line in (s/'scoped-build-first.stdout').read_text().splitlines():
    try: row=json.loads(line)
    except ValueError: continue
    if row.get('reason')!='compiler-artifact' or not row.get('executable') or not row.get('profile',{}).get('test'):
        continue
    src=row['target']['src_path']
    name=row['target']['name']
    if '/crates/deadpan-plan/' in src or name in ['deadpan_audio','stages']:
        selected.append((name,row['executable']))
(s/'scoped-binaries.json').write_text(json.dumps(selected,indent=2)+'\n')
for name,binary in selected:
    label='scoped-'+name.replace('_','-')
    args=['--nocapture','--test-threads=1']
    code=subprocess.call([sys.executable,str(s/'run_scoped.py'),'--binary',binary,label,'--',binary,*args])
    if code: raise SystemExit(code)
print('Independent scoped Plan suite, Audio library and all201 existing stages passed',flush=True)
