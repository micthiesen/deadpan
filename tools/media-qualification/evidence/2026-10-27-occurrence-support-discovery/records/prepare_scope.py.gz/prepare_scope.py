from pathlib import Path
import difflib,json,shutil,hashlib
s=Path(__file__).resolve().parent
root=Path('/Users/michael/Code/deadpan')
isolated=Path('/tmp/deadpan-query-groundwork-2026-10-26/scoped')
old=Path('/tmp/deadpan-occurrence-support-2026-10-27')
mapping={
'crates/deadpan-plan/src/audio_signal.rs':'audio_signal.before.rs',
'crates/deadpan-plan/src/audio_sound_owner_context.rs':'audio_sound_owner_context.before.rs',
'crates/deadpan-plan/src/audio_source_occurrence.rs':'audio_source_occurrence.before.rs',
'crates/deadpan-plan/src/audio_source_occurrences.rs':'audio_source_occurrences.before.rs',
'crates/deadpan-plan/src/audio_source_voice.rs':'audio_source_voice.before.rs',
'crates/deadpan-plan/src/lib.rs':'lib.before.rs',
'crates/deadpan-plan/tests/audio_definition/source_occurrence.rs':'source_occurrence_tests.before.rs',
'crates/deadpan-plan/src/audio_source_occurrence_support.rs':None,
'crates/deadpan-plan/tests/audio_definition/support_discovery.rs':None,
}
before={}
desired={}
for rel,base in mapping.items():
    before[rel]=(old/base).read_text() if base else ''
    desired[rel]=(root/rel).read_text()
rel='crates/deadpan-audio/src/sound_clocks.rs'
before[rel]=(s/'sound-clocks-head.rs').read_text()
prefix=before[rel].split("pub(super) fn current_occurrences<'plan>(",1)[0]
assert prefix.count('let batch = current_occurrences(')==1
assert prefix.count('for voice in batch.voices()')==1
prefix=prefix.replace('let batch = current_occurrences(', 'let batch = current_occurrence_supports(')
prefix=prefix.replace('for voice in batch.voices()', 'for voice in batch.supports()')
desired[rel]=prefix+"pub(super) fn current_occurrences<'plan>("+(root/rel).read_text().split("pub(super) fn current_occurrences<'plan>(",1)[1]
rel='crates/deadpan-audio/src/sound_clocks/tests.rs'
before[rel]=(s/'sound-clocks-tests-head.rs').read_text()
anchor='#[test]\nfn clock_discovery_keeps_exact_full_batch_paths_and_scoped_halos()'
current=(root/rel).read_text()
assert current.count(anchor)==1
desired[rel]=before[rel]+'\n'+anchor+current.split(anchor,1)[1]
for rel in desired:
    p=isolated/rel
    assert (p.read_text() if p.exists() else '')==before[rel],rel
for rel,text in desired.items():
    p=isolated/rel
    p.parent.mkdir(parents=True,exist_ok=True)
    p.write_text(text)
    dest=s/'scope'/rel
    dest.parent.mkdir(parents=True,exist_ok=True)
    dest.write_text(text)
patch=''
for rel in desired:
    patch+=''.join(difflib.unified_diff(before[rel].splitlines(True),desired[rel].splitlines(True),fromfile='a/'+rel if before[rel] else '/dev/null',tofile='b/'+rel))
(s/'scoped.patch').write_text(patch)
(s/'scoped-files.json').write_text(json.dumps(sorted(desired),indent=2)+'\n')
(s/'scoped-pins.json').write_text(json.dumps({rel:hashlib.sha256(text.encode()).hexdigest() for rel,text in desired.items()},indent=2)+'\n')
print('Installed exact independent11-file scope on prior verified HEAD-equivalent tree')
