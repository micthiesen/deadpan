from pathlib import Path
import json,hashlib,sys,re
s=Path('/tmp/deadpan-range-selectors-2026-10-22')
source=json.loads((s/'release-final-source-identities.json').read_text())
inputs=json.loads((s/'release-final-lock.json').read_text())
expected={**source,**inputs}
commit=(s/'code-commit.txt').read_text().strip()
assert re.fullmatch('[0-9a-f]{40}',commit)
names=sorted(expected)
if sys.argv[1]=='prepare':
 tracked=set((s/'tracked-rust.raw').read_bytes().decode().rstrip('\0').split('\0'))
 assert tracked==set(source),{'missing':sorted(set(source)-tracked),'extra':sorted(tracked-set(source))}
 (s/'git-blob-requests.raw').write_text(''.join(commit+':'+name+'\n' for name in names))
 print(json.dumps({'commit':commit,'rust_files':len(source),'inputs':len(inputs),'requests':len(names)}))
else:
 rows={}
 with (s/'git-blob-output.raw').open('rb') as stream:
  for name in names:
   fields=stream.readline().decode().strip().split()
   assert len(fields)==3 and fields[1]=='blob',(name,fields)
   data=stream.read(int(fields[2]));assert len(data)==int(fields[2]) and stream.read(1)==b'\n'
   digest=hashlib.sha256(data).hexdigest();assert digest==expected[name],name
   rows[name]={'blob':fields[0],'bytes':len(data),'sha256':digest}
  assert stream.read()==b''
 receipt={'commit':commit,'rust_files':len(source),'supplemental_inputs':len(inputs),'complete_rust_path_set_matches_git_index':True,'all_blobs_match_release_final_frozen_inputs':True,'files':rows}
 (s/'code-source-git-audit.json').write_text(json.dumps(receipt,indent=2)+'\n')
 print(json.dumps({k:v for k,v in receipt.items() if k!='files'}))
