import pathlib,json,gzip,hashlib,subprocess,tarfile
repo=pathlib.Path('/Users/michael/Code/deadpan')
ev=pathlib.Path('/Users/michael/Code/deadpan/tools/media-qualification/evidence/2026-10-22-range-selectors')
assert str(ev)=='/Users/michael/Code/deadpan/tools/media-qualification/evidence/2026-10-22-range-selectors'
assert ev.is_dir()
out=pathlib.Path('/tmp/deadpan-range-selectors-2026-10-22')
commit='32598481ba9e66a0a37c79df3967d5e3fd170ebe'
def sha(b): return hashlib.sha256(b).hexdigest()
def git(*args): return subprocess.check_output(['git',*args],cwd=repo)
def j(f): return json.loads((ev/f).read_text())
def gj(f): return json.loads(gzip.open(ev/f,'rt').read())
manifest=gj('release-final-source-identities.json.gz')
tree=git('ls-tree','-r','--name-only',commit).decode().splitlines()
committed=sorted(p for p in tree if p.endswith('.rs'))
manifest_paths=sorted(p for p in manifest if p.endswith('.rs'))
blob_hashes={p:sha(git('show',f'{commit}:{p}')) for p in manifest_paths}
lock=j('release-final-lock.json')
inputs={p:sha(git('show',f'{commit}:{p}')) for p in lock}
snap=j('source-snapshots.json')
tar_reports=[]
for key,s in snap.items():
 if 'release-final-source' not in key: continue
 ids=gj(s['manifest'])
 with tarfile.open(ev/s['archive'],'r:gz') as tf:
  archive={m.name.removeprefix('./'):sha(tf.extractfile(m).read()) for m in tf.getmembers() if m.isfile()}
 tar_reports.append({'snapshot':key,'archive':s['archive'],'manifest':s['manifest'],'declared_files':s['files'],'manifest_files':len(ids),'archive_files':len(archive),'archive_matches_manifest':archive==ids,'manifest_matches_release':ids==manifest,'content_sha256':s['content_sha256']})
def gt(f): return gzip.open(ev/f,'rt',errors='replace').read()
def logsummary(f):
 return [x.strip() for x in gt(f).splitlines() if 'Summary' in x][-1:]
native=j('release-native-summary.json')
native_summary={}
for kind,v in native.items():
 native_summary[kind]={'failed':v.get('failed'),'scenarios':[{'name':s.get('name'),'checks':s.get('checks'),'frames':s.get('frames'),'failed':s.get('failed'),'findings':s.get('findings',[])} for s in v.get('scenarios',[])]}
media=j('release-media-fixture.json')
owner=j('owner-fixture-identity.json')
with tarfile.open(ev/owner['archive'],'r:gz') as tf:
 members=tf.getmembers()
 safe=all(not pathlib.PurePosixPath(m.name).is_absolute() and '..' not in pathlib.PurePosixPath(m.name).parts and (m.isfile() or m.isdir()) for m in members)
 files={m.name.split('/',1)[-1]:sha(tf.extractfile(m).read()) for m in members if m.isfile()}
 expected={f['path']:f['sha256'] for f in owner['files']}
validation=j('owner-fixture-validation.json')
inventory=j('inventory.json')
bad=[]
for e in inventory:
 b=(ev/e['file']).read_bytes()
 if len(b)!=e['bytes'] or sha(b)!=e['sha256']: bad.append(e['file'])
result={
 'audited_directory':str(ev),'directory_assertion_passed':True,'target_commit':commit,
 'rust_binding':{'manifest_paths':len(manifest_paths),'commit_paths':len(committed),'exact_path_set':manifest_paths==committed,'blob_hashes_match':all(blob_hashes[p]==manifest[p] for p in manifest_paths),'missing_manifest_paths':sorted(set(committed)-set(manifest_paths)),'extra_manifest_paths':sorted(set(manifest_paths)-set(committed)),'mismatched_hash_count':sum(blob_hashes[p]!=manifest[p] for p in manifest_paths)},
 'six_input_binding':{'count':len(lock),'all_match':inputs==lock,'mismatches':{p:{'expected':lock[p],'actual':inputs[p]} for p in lock if inputs[p]!=lock[p]}},
 'release_source_archive':tar_reports,
 'broad_first':{'result':j('broad-first-result.json'),'summary':logsummary('broad-first.log.gz'),'case_inventory':{k:v for k,v in gj('broad-first-list.json.gz').items() if k=='test-count' or k=='rust-suites'}},
 'ui_complete_final':{'result':j('ui-complete-final-result.json'),'summary':logsummary('ui-complete-final.log.gz'),'case_inventory':{k:v for k,v in gj('ui-complete-final-list.json.gz').items() if k=='test-count' or k=='rust-suites'}},
 'native':native_summary,
 'media':{'fixture':media.get('fixture'),'passed':media.get('passed'),'pictures':media.get('pictures'),'frames':media.get('frames'),'audio_windows':media.get('audio_windows'),'offsets':media.get('offsets'),'signal_windows':media.get('signal_windows'),'failures':media.get('failures'),'verification':{'passed':j('media__range-sets-verification.json').get('passed'),'audio':[{k:a.get(k) for k in ['project_samples','window','measured_offset_samples','offset_status','flags','passed','uncovered_samples']} for a in j('media__range-sets-verification.json').get('audio',[])]},'notes':media.get('notes')},
 'owner_archive':{'archive':owner['archive'],'safe_paths':safe,'members':len(members),'file_count':len(files),'hashes_match_receipt':files==expected,'validation':validation},
 'inventory_rehash':{'entries':len(inventory),'total_bytes':sum(x['bytes'] for x in inventory),'all_entry_sizes_hashes_match':not bad,'bad_paths':bad,'inventory_json_sha256':sha((ev/'inventory.json').read_bytes())}
}
(out/'independent-source-audit.json').write_text(json.dumps(result,indent=2)+'\n')
md=[
'# Independent source audit','',
f'Audited directory: {ev}',
f'Target commit: {commit}.',
f'Rust binding: {len(manifest_paths)} retained manifest paths / {len(committed)} committed Rust paths; exact path set={manifest_paths==committed}; all manifest blob hashes match={all(blob_hashes[p]==manifest[p] for p in manifest_paths)}.',
f'Six input hashes all match={inputs==lock}; mismatch count={sum(inputs[p]!=lock[p] for p in lock)}.',
f'Release-final archive mapping: {json.dumps(tar_reports)}',
f'Broad first: {json.dumps(result["broad_first"])}',
f'UI complete final: {json.dumps(result["ui_complete_final"])}',
f'Native: {json.dumps(native_summary)}',
f'Media fixture: {json.dumps(result["media"])}',
f'Owner archive: {json.dumps(result["owner_archive"])}',
f'Inventory: {len(inventory)} entries, {sum(x["bytes"] for x in inventory)} bytes, all hashes/sizes match={not bad}, inventory SHA-256={sha((ev/"inventory.json").read_bytes())}.'
]
(out/'independent-source-audit.md').write_text('\n\n'.join(md)+'\n')
print(json.dumps(result,indent=2))
