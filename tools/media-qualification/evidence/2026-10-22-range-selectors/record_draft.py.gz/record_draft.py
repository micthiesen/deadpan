import hashlib
import json
from pathlib import Path

root = Path('/Users/michael/Code/deadpan')
out = Path('/tmp/deadpan-range-selectors-2026-10-22')
sources = [
    'crates/deadpan-core/src/edit_slice.rs',
    'crates/deadpan-core/src/edit_slice/set.rs',
    'crates/deadpan-core/src/edit_slice/rename.rs',
    'crates/deadpan-core/src/marks.rs',
    'crates/deadpan-core/src/semantic/program.rs',
    'crates/deadpan-core/tests/node_set_counterfactual.rs',
    'crates/deadpan-core/tests/node_set_shared_mark.rs',
    'crates/deadpan-core/tests/edit_set.rs',
]
controls = ['range_set_fixture.rs', 'range_set_counterfactual.rs', 'range_set_shared_mark.rs']


def row(path, label):
    data = path.read_bytes()
    return {'path': label, 'sha256': hashlib.sha256(data).hexdigest(), 'bytes': len(data)}


report = {
    'status': 'draft_only_not_compiled_or_executed',
    'source_observations': [row(root / path, path) for path in sources],
    'controls': [row(out / path, path) for path in controls],
}
(out / 'draft-identities.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps({'status': report['status'], 'controls': report['controls']}, indent=2))
