from pathlib import Path
import os,re,json,hashlib,subprocess,time
s=Path('/tmp/deadpan-range-selectors-2026-10-22')
text=(s/'registry-third.log').read_text()
m=re.search(r'Running unittests src/main.rs \(([^)]+)\)',text)
assert m
binary=Path(m.group(1))
digest=hashlib.sha256(binary.read_bytes()).hexdigest()
env=dict(os.environ,DEADPAN_UPDATE_ROUTING_BASELINE='1')
args=[str(binary),'--exact','navigation::registry::tests::routing_matches_the_pre_registry_baseline','--nocapture']
start=time.monotonic()
r=subprocess.run(args,env=env,capture_output=True,text=True)
(s/'registry-final-generation.stdout').write_text(r.stdout)
(s/'registry-final-generation.stderr').write_text(r.stderr)
assert r.returncode==101 and 'rewritten; review the diff' in r.stderr,r.stdout+r.stderr
receipt={'binary':str(binary),'sha256':digest,'command':args,'environment_override':'DEADPAN_UPDATE_ROUTING_BASELINE=1','exit':r.returncode,'expected_rewrite_refusal':True,'seconds':time.monotonic()-start,'note':'Third compiled candidate has updated usage rows; direct generator restores completion table after first generation read the old embedded usage. Final source checks run separately.'}
(s/'registry-final-generation.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt))
