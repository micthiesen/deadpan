from pathlib import Path
import os,subprocess,time,hashlib,json
s=Path('/tmp/deadpan-range-selectors-2026-10-22')
env=dict(os.environ,CARGO_PROFILE_DEV_OPT_LEVEL='2',DEADPAN_FFMPEG_PREFIX='/Users/michael/Library/Developer/Deadpan/ffmpeg-8.0.3-opus-1.6.1-dav1d-1.5.4-qualified-3/prefix')
def source():
 return {str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(Path('crates/deadpan-core').rglob('*.rs'))}
before=source()
(s/'core-first-identities.json').write_text(json.dumps(before,indent=2)+'\n')
args=['cargo','nextest','run','--locked','-p','deadpan-core','--test','range_sets','--test','range_set_counterfactual','--test','range_set_shared_mark','--test','edit_set','--test','node_set_counterfactual','--test','node_set_shared_mark','--test-threads','8','--status-level','fail','--final-status-level','fail']
start=time.monotonic()
with (s/'core-first.log').open('w') as log:
 r=subprocess.run(args,env=env,stdout=log,stderr=subprocess.STDOUT)
receipt={'command':args,'exit':r.returncode,'seconds':time.monotonic()-start,'core_sources_unchanged':source()==before,'scope':'Core Rust source only; other owners active in App/Store'}
(s/'core-first-result.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt),flush=True)
print('\n'.join((s/'core-first.log').read_text().splitlines()[-35:]))
raise SystemExit(r.returncode)
