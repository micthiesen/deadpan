from pathlib import Path
import subprocess,json,hashlib,os,shutil,time
s=Path('/tmp/deadpan-range-selectors-2026-10-22')
env=dict(os.environ,DEADPAN_FFMPEG_PREFIX='/Users/michael/Library/Developer/Deadpan/ffmpeg-8.0.3-opus-1.6.1-dav1d-1.5.4-qualified-3/prefix',CARGO_PROFILE_DEV_OPT_LEVEL='2',DEADPAN_REQUIRE_PHYSICAL_MAC='1',DEADPAN_REQUIRE_SYNTHETIC_WORKER='1',DEADPAN_RUN_IGNORED='1',DEADPAN_PREVIEW_EXPORT_KEEP='1',DEADPAN_PREVIEW_EXPORT_RESULTS=str(s/'media-preflight-fixture.json'))
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def guard():
 rows=json.loads((s/'media-preflight-source-identities.json').read_text())
 current=set(subprocess.check_output(['rg','--files','-g','*.rs'],text=True).splitlines())
 expected={n for n in rows if not n.startswith('crates/deadpan-app/')}
 assert {n for n in current if not n.startswith('crates/deadpan-app/')}==expected
 for name in expected: assert sha(Path(name))==rows[name],name
 for name,digest in json.loads((s/'media-preflight-lock.json').read_text()).items():assert sha(Path(name))==digest,name
def run(name,args):
 start=time.monotonic()
 with (s/(name+'.log')).open('w') as log:r=subprocess.run(args,env=env,stdout=log,stderr=subprocess.STDOUT)
 receipt={'command':args,'exit':r.returncode,'seconds':time.monotonic()-start}
 (s/(name+'-receipt.json')).write_text(json.dumps(receipt,indent=2)+'\n')
 print(name,json.dumps(receipt),flush=True)
 if r.returncode:raise SystemExit(r.returncode)
subprocess.run(['python',str(s/'freeze.py'),'media-preflight'],check=True)
name='media-preflight';archive=s/(name+'.tar.zst');target=s/(name+'-extracted');target.mkdir(exist_ok=True)
run(name+'-build',['cargo','nextest','archive','--locked','-p','deadpan-cli','--test','preview_export','--archive-file',str(archive),'--zstd-level=-1'])
expression='test(=range_sets_export_preserves_same_source_windows_and_complete_audio)'
with (s/(name+'-extract.log')).open('w') as log:
 subprocess.run(['cargo','nextest','list','--archive-file',str(archive),'--extract-to',str(target),'--extract-overwrite','--workspace-remap',str(Path.cwd()),'-E',expression],env=env,stdout=log,stderr=subprocess.STDOUT,check=True)
helpers={}
for helper in ['deadpan-cli','deadpan-media-worker','deadpan-transcribe','deadpan-track']:
 p=Path('target/debug')/helper;matches=list(target.rglob(helper))
 if not matches:
  t=target/'target/debug'/helper;t.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,t);matches=[t]
 assert len(matches)==1 and sha(matches[0])==sha(p),(helper,matches)
 helpers[helper]={'path':str(matches[0]),'sha256':sha(p)}
(s/(name+'-helpers.json')).write_text(json.dumps(helpers,indent=2)+'\n')
guard()
run(name+'-driver',['python',str(s/'run_archive.py'),name,expression])
guard()
for row in helpers.values():assert sha(Path(row['path']))==row['sha256']
result=json.loads((s/(name+'-result.json')).read_text());assert result['tests']==1 and result['exit']==0
(s/(name+'-scope.json')).write_text(json.dumps({'non_app_rust_and_six_inputs_and_helpers_unchanged':True,'app_rust_excluded_from_immutability_guard':'Concurrent app provenance fix; final release qualification will freeze the complete tree.'},indent=2)+'\n')
