from pathlib import Path
import subprocess,os,json,time,hashlib,shutil,sys
s=Path('/tmp/deadpan-range-selectors-2026-10-22')
phase=sys.argv[1]
env=dict(os.environ,CARGO_PROFILE_DEV_OPT_LEVEL='2',DEADPAN_FFMPEG_PREFIX='/Users/michael/Library/Developer/Deadpan/ffmpeg-8.0.3-opus-1.6.1-dav1d-1.5.4-qualified-3/prefix')
subprocess.run(['python',str(s/'freeze.py'),phase],env=env,check=True)
args=['cargo','nextest','list','--locked','-p','deadpan-core','--test','range_set_counterfactual','--test','range_set_shared_mark','--message-format','json']
started=time.monotonic()
with (s/(phase+'-list.json')).open('w') as out,(s/(phase+'-build.log')).open('w') as err:
 build=subprocess.run(args,stdout=out,stderr=err,env=env)
build_receipt={'command':args,'exit':build.returncode,'seconds':time.monotonic()-started}
(s/(phase+'-build-result.json')).write_text(json.dumps(build_receipt,indent=2)+'\n')
if build.returncode:raise SystemExit(build.returncode)
identities={}
for key,row in json.loads((s/(phase+'-list.json')).read_text())['rust-suites'].items():
 tests=[name for name,case in row.get('testcases',{}).items()if case.get('filter-match',{}).get('status')=='matches']
 if not tests:continue
 p=Path(row['binary-path']);dest=s/(phase+'-bin')/p.name;dest.parent.mkdir(exist_ok=True);shutil.copy2(p,dest)
 identities[key]={'source':str(p),'retained':str(dest),'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'tests':tests}
assert len(identities)==2 and all(len(row['tests'])==1 for row in identities.values())
(s/(phase+'-binaries.json')).write_text(json.dumps(identities,indent=2)+'\n')
subprocess.run(['python',str(s/'guard.py'),phase],env=env,check=True)
results=[]
for key,row in sorted(identities.items(),key=lambda pair:'shared_mark' not in pair[0]):
 started=time.monotonic();test=row['tests'][0]
 r=subprocess.run([row['retained'],'--exact',test,'--nocapture'],env=env,capture_output=True,text=True,timeout=60)
 stem=phase+'-'+key.split('::')[-1]
 (s/(stem+'.stdout')).write_text(r.stdout);(s/(stem+'.stderr')).write_text(r.stderr)
 expected_pass='shared_mark' in key
 expected=(r.returncode==0 and '1 passed; 0 failed' in r.stdout)if expected_pass else(r.returncode==101 and 'unknown variant '+chr(96)+'ranges'+chr(96) in r.stderr and '0 passed; 1 failed' in r.stdout)
 result={'suite':key,'test':test,'exit':r.returncode,'seconds':time.monotonic()-started,'expected_pass':expected_pass,'expected_outcome':expected,'binary_sha256':row['sha256']}
 results.append(result);(s/(phase+'-results.json')).write_text(json.dumps(results,indent=2)+'\n');print(json.dumps(result),flush=True)
 assert expected,r.stdout+r.stderr
subprocess.run(['python',str(s/'guard.py'),phase],env=env,check=True)
for row in identities.values():
 assert hashlib.sha256(Path(row['source']).read_bytes()).hexdigest()==row['sha256']
 assert hashlib.sha256(Path(row['retained']).read_bytes()).hexdigest()==row['sha256']
