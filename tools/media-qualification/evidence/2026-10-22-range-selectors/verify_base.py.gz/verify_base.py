from pathlib import Path
import json,hashlib
s=Path('/tmp/deadpan-range-selectors-2026-10-22')
source=json.loads((s/'base-source-identities.json').read_text())
inputs=json.loads((s/'base-lock.json').read_text())
expected={**source,**inputs}
rows={}
with (s/'base-git-output.raw').open('rb') as stream:
 for name in sorted(expected):
  fields=stream.readline().decode().strip().split()
  assert len(fields)==3 and fields[1]=='blob'
  data=stream.read(int(fields[2]));assert stream.read(1)==b'\n'
  digest=hashlib.sha256(data).hexdigest();assert digest==expected[name],name
  rows[name]={'blob':fields[0],'bytes':len(data),'sha256':digest}
 assert stream.read()==b''
frozen=json.loads((s/'baseline-first-source-identities.json').read_text())
controls=json.loads((s/'installed-control-identities.json').read_text())['files']
assert frozen=={**source,**controls}
receipt={'commit':(s/'base-commit.txt').read_text().strip(),'rust_files':len(source),'inputs':len(inputs),'all_blobs_match':True,'complete_path_set':True,'frozen_additions_only_public_controls':controls,'files':rows}
(s/'base-git-audit.json').write_text(json.dumps(receipt,indent=2)+'\n')
print({k:v for k,v in receipt.items() if k not in ['files','frozen_additions_only_public_controls']})
