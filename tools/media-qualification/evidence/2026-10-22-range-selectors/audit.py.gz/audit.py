import pathlib,json,gzip,hashlib,subprocess,tarfile,io,os
repo=pathlib.Path('/Users/michael/Code/deadpan')
ev=repo/'tools/media-qualification/evidence/2026-10-22-discontiguous-selectors'
out=pathlib.Path('/tmp/deadpan-range-selectors-2026-10-22')
commit='32598481ba9e66a0a37c79df3967d5e3fd170ebe'
def sha(b): return hashlib.sha256(b).hexdigest()
def git(*args): return subprocess.check_output(['git',*args],cwd=repo)
def loadj(name): return json.loads((ev/name).read_text())
def loadgz(name): return json.loads(gzip.open(ev/name,'rt').read())
manifest=loadgz('release-final-source-identities.json.gz')
paths=sorted(p for p in manifest if p.endswith('.rs'))
tree=git('ls-tree','-r','--name-only',commit,'--',*[]) if False else git('ls-tree','-r','--name-only',commit).decode().splitlines()
rust=sorted(p for p in tree if p.endswith('.rs'))
hashes={}
for p in paths:
 b=git('show',f'{commit}:{p}')
 hashes[p]=sha(b)
commit_match=set(paths)==set(rust) and hashes==manifest
lock=loadj('release-final-lock.json')
lock_now={p:sha(git('show',f'{commit}:{p}')) for p in lock}
# compare release lock hashes as saved in source tar snapshot (root)
snap=loadj('source-snapshots.json')
tarchecks={}
for key,s in snap.items():
 if key not in ('release-final-source',): continue
 arc=ev/s['archive']; ids=loadgz(s['manifest'])
 with tarfile.open(arc,'r:gz') as tf:
  bad=[]; actual={}
  for m in tf.getmembers():
   if not m.isfile(): continue
   f=tf.extractfile(m)
   actual[m.name.removeprefix('./')]=sha(f.read())
 tarchecks[key]={'mapping_count':len(ids),'archive_count':len(actual),'all_hashes_match':ids==actual,'matches_release_manifest':ids==manifest,'declared_count':s['files']}
# tar snapshot source may not map key; check final
inv=loadj('inventory.json')
invbad=[]
for e in inv:
 b=(ev/e['file']).read_bytes()
 if len(b)!=e['bytes'] or sha(b)!=e['sha256']: invbad.append(e['file'])
# audit logs
def gztext(f): return gzip.open(ev/f,'rt',errors='replace').read()
logchecks={}
for f in ['broad-final.log.gz','broad-fourth.log.gz','ui-final.log.gz','ui-complete-final-build.log.gz']:
 try:
  t=gztext(f); lines=[x for x in t.splitlines() if 'Summary' in x or 'tests run:' in x]
  logchecks[f]=lines[-1:] 
 except Exception as e: logchecks[f]=str(e)
native=loadj('release-native-summary.json')
def summarize_native(x):
 return {k:{'failed':v.get('failed'),'scenarios':[(s['name'],s.get('checks'),s.get('frames'),s.get('failed'),len(s.get('findings',[]))) for s in v.get('scenarios',[])]} for k,v in x.items()}
media=loadj('media__node-sets-verification.json')
ownerid=loadj('owner-fixture-identity.json')
# tar safety and contents
ar=ev/ownerid['archive']
with tarfile.open(ar,'r:gz') as tf:
 members=tf.getmembers()
 safe=all(not pathlib.PurePosixPath(m.name).is_absolute() and '..' not in pathlib.PurePosixPath(m.name).parts and (m.isfile() or m.isdir()) for m in members)
 files={m.name.split('/',1)[-1]:sha(tf.extractfile(m).read()) for m in members if m.isfile()}
 expected={f['path']:f['sha256'] for f in ownerid['files']}
 owner_match=files==expected
result={
 'requested_commit':commit,'actual_commit':git('rev-parse',commit).decode().strip(),
 'rust_paths':{'manifest_count':len(paths),'commit_count':len(rust),'path_set_matches':set(paths)==set(rust),'hashes_match':hashes==manifest,'mismatched_count':sum(hashes[p]!=manifest[p] for p in paths),'missing_from_release_manifest':sorted(set(rust)-set(paths)),'extra_in_release_manifest':sorted(set(paths)-set(rust))},
 'six_inputs_lock':{'count':len(lock),'hashes_match_commit':lock_now==lock,'details':{p:{'expected':v,'commit':lock_now[p]} for p,v in lock.items()}},
 'release_tar':tarchecks, 'release_manifest_commit_identity':{'source_manifest_head_commit':git('rev-parse','3259848^').decode().strip(),'source_commit_ee':git('rev-parse','eea765a96929be926fd3def97c2de6844df7827d').decode().strip()},
 'broad_ui_logs':logchecks,
 'native':summarize_native(native),
 'media':{'passed':media.get('passed'),'pictures':media.get('movie',{}).get('video_frames'),'project_range':media.get('audio',[{}])[0].get('project_samples'),'measured_offset_samples':media.get('audio',[{}])[0].get('measured_offset_samples'),'offset_status':media.get('audio',[{}])[0].get('offset_status'),'flags':media.get('audio',[{}])[0].get('flags'),'failures':media.get('failures')},
 'owner_archive':{'members':len(members),'safe_paths':safe,'file_count':len(files),'hashes_match_receipt':owner_match,'validate_doctor':loadj('owner-fixture-validation.json')},
 'inventory':{'entries':len(inv),'all_size_hashes_match':not invbad,'bad_files':invbad,'inventory_sha':sha((ev/'inventory.json').read_bytes())}
}
(out/'independent-source-audit.json').write_text(json.dumps(result,indent=2)+'\\n')
(out/'independent-source-audit.md').write_text('# Independent audit\\n\\n'+json.dumps(result,indent=2)+'\\n')
print(json.dumps(result,indent=2))
