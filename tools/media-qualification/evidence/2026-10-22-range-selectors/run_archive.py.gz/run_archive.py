from pathlib import Path
import subprocess,json,os,time,hashlib,sys
s=Path('/tmp/deadpan-range-selectors-2026-10-22')
name=sys.argv[1];archive=s/(name+'.tar.zst');target=s/(name+'-extracted');target.mkdir(exist_ok=True)
expression=sys.argv[2]if len(sys.argv)>2 else None
env=dict(os.environ,DEADPAN_FFMPEG_PREFIX='/Users/michael/Library/Developer/Deadpan/ffmpeg-8.0.3-opus-1.6.1-dav1d-1.5.4-qualified-3/prefix',CARGO_PROFILE_DEV_OPT_LEVEL='2',DEADPAN_REQUIRE_PHYSICAL_MAC='1',DEADPAN_REQUIRE_SYNTHETIC_WORKER='1')
reuse=['--archive-file',str(archive),'--extract-to',str(target),'--extract-overwrite','--workspace-remap',str(Path.cwd())];filters=['-E',expression]if expression else[]
if os.environ.get('DEADPAN_RUN_IGNORED')=='1':filters+=['--run-ignored','all']
with (s/(name+'-list.json')).open('w')as out,(s/(name+'-list.log')).open('w')as err:
 subprocess.run(['cargo','nextest','list',*reuse,*filters,'--message-format','json'],stdout=out,stderr=err,env=env,check=True)
identities={}
for key,row in json.loads((s/(name+'-list.json')).read_text())['rust-suites'].items():
 tests=[n for n,c in row.get('testcases',{}).items()if c.get('filter-match',{}).get('status')=='matches']
 if not tests:continue
 p=Path(row['binary-path']);identities[key]={'path':str(p),'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'tests':tests}
(s/(name+'-binaries.json')).write_text(json.dumps(identities,indent=2)+'\n')
start=time.monotonic()
with(s/(name+'.log')).open('w')as log:run=subprocess.run(['cargo','nextest','run',*reuse,*filters,'--test-threads','8','--no-fail-fast'],stdout=log,stderr=subprocess.STDOUT,env=env)
for row in identities.values():assert hashlib.sha256(Path(row['path']).read_bytes()).hexdigest()==row['sha256']
result={'exit':run.returncode,'tests':sum(len(i['tests'])for i in identities.values()),'seconds':time.monotonic()-start,'executable_hashes_unchanged':True}
(s/(name+'-result.json')).write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result),flush=True)
raise SystemExit(run.returncode)
