from pathlib import Path
import json,hashlib
s=Path('/tmp/deadpan-range-selectors-2026-10-22')
rows=[]
for mode in ['debug-fourth-visual','release-visual']:
 report=json.loads((s/mode/'report.json').read_text())
 scenario=next(x for x in report['scenarios'] if x['name']=='range-set-selectors')
 step=next(x for x in scenario['steps'] if x['input']=='Disjoint ranges show separate highlights and complete range inspector')
 p=s/mode/step['screenshot']
 rows.append({'mode':mode,'file':p.name,'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'checkpoint':step['input'],'frame':step['frame']})
(s/'selected-captures.json').write_text(json.dumps(rows,indent=2)+'\n')
print(json.dumps(rows))
