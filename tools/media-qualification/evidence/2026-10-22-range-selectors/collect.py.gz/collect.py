from pathlib import Path
import gzip,hashlib,io,json,tarfile
s=Path('/tmp/deadpan-range-selectors-2026-10-22')
out=Path('tools/media-qualification/evidence/2026-10-22-range-selectors')
out.mkdir(parents=True,exist_ok=True)
def sha(data):return hashlib.sha256(data).hexdigest()
def copy(source,name=None):
 name=name or source.name;data=source.read_bytes()
 if source.suffix in ['.log','.txt','.py','.stdout','.stderr','.patch','.sha256','.sh'] or (source.suffix=='.json' and len(data)>100000):
  name+='.gz';data=gzip.compress(data,mtime=0)
 (out/name).write_bytes(data)
 return name
retained={}
for source in sorted(s.iterdir()):
 if not source.is_file() or source.suffix not in ['.log','.json','.txt','.py','.stdout','.stderr','.patch','.sha256','.sh']:continue
 if any(word in source.name.lower() for word in ['artifact','progress','next-','collect-driver']):continue
 retained[source.name]=copy(source)
for suffix,manifest_suffix,label in [('-source','-source-identities.json','source'),('-inputs','-lock.json','input')]:
 snapshots={};unique={}
 for directory in sorted(p for p in s.iterdir() if p.is_dir() and p.name.endswith(suffix)):
  stage=directory.name[:-len(suffix)]
  rows={str(p.relative_to(directory)):sha(p.read_bytes())for p in sorted(directory.rglob('*'))if p.is_file()}
  manifest_name=stage+manifest_suffix
  assert rows==json.loads((s/manifest_name).read_text()),directory
  content_hash=sha(json.dumps(rows,sort_keys=True,separators=(',',':')).encode())
  archive_name=unique.get(content_hash)
  if archive_name is None:
   buffer=io.BytesIO()
   with tarfile.open(fileobj=buffer,mode='w') as archive:
    for name in rows:
     data=(directory/name).read_bytes();entry=tarfile.TarInfo(name)
     entry.size=len(data);entry.mode=0o644;entry.mtime=0;archive.addfile(entry,io.BytesIO(data))
   archive_name=directory.name+'.tar.gz';(out/archive_name).write_bytes(gzip.compress(buffer.getvalue(),mtime=0));unique[content_hash]=archive_name
  snapshots[directory.name]={'archive':archive_name,'manifest':retained[manifest_name],'files':len(rows),'content_sha256':content_hash}
  with tarfile.open(fileobj=io.BytesIO(gzip.decompress((out/archive_name).read_bytes())),mode='r:') as archive:
   assert sorted(m.name for m in archive.getmembers())==sorted(rows)
   for name,digest in rows.items():assert sha(archive.extractfile(name).read())==digest,name
 (out/(label+'-snapshots.json')).write_text(json.dumps(snapshots,indent=2)+'\n')
for mode in sorted(p.name for p in s.iterdir() if p.is_dir() and (p.name.startswith('debug-') or p.name in ['release-visual','release-performance'])):
 for source in sorted((s/mode).rglob('*.json')):copy(source,mode+'__'+str(source.relative_to(s/mode)).replace('/','__'))
for source in sorted((s/'concurrent-import-diagnostic').rglob('*')):
 if source.is_file():copy(source,'concurrent-import__'+str(source.relative_to(s/'concurrent-import-diagnostic')).replace('/','__'))
for source in sorted((s/'ui-sampled').rglob('*')):
 if source.is_file():copy(source,'ui-sampled__'+str(source.relative_to(s/'ui-sampled')).replace('/','__'))
for source in sorted((s/'import-location-diagnostic').rglob('*')):
 if source.is_file() and source.suffix in ['.json','.txt','.stdout','.stderr']:
  copy(source,'import-location__'+str(source.relative_to(s/'import-location-diagnostic')).replace('/','__'))
for row in json.loads((s/'selected-captures.json').read_text()):
 p=s/row['mode']/row['file'];assert sha(p.read_bytes())==row['sha256'];copy(p,row['mode']+'-'+row['file'])
media=json.loads((s/'media-identities.json').read_text())
movie=Path(media['movie']);assert sha(movie.read_bytes())==media['movie_sha256'];copy(movie,'range-sets.mp4')
package=Path(media['package']);media_root=package.parent.parent
for source in sorted(media_root.rglob('*.json')):
 if package not in source.parents:copy(source,'media__'+str(source.relative_to(media_root)).replace('/','__'))
owner=json.loads((s/'owner-fixture-identity.json').read_text())
p=s/owner['archive'];assert sha(p.read_bytes())==owner['sha256'];copy(p)
inventory=[{'file':p.name,'bytes':p.stat().st_size,'sha256':sha(p.read_bytes())}for p in sorted(out.iterdir())if p.name!='inventory.json']
(out/'inventory.json').write_text(json.dumps(inventory,indent=2)+'\n')
for row in inventory:
 data=(out/row['file']).read_bytes();assert len(data)==row['bytes'] and sha(data)==row['sha256']
print(json.dumps({'entries':len(inventory),'bytes':sum(r['bytes']for r in inventory),'inventory_verified':True}))
