# Consume the actual one-sample owner query for input capture

Read-only design, 2026-10-28. No source edits, compiler, Cargo, Git, rendering
or media. Current source includes the work-bearing retained probe fix.
This is a future actual-work optimization, not a cache or acceptance result.

## Recommended bounded patch

Add a sealed, non-Clone Plan candidate object that owns the actual one-sample
gain-owner query and borrows its actual Root/Domain parent. Audio performs the
existing FIRST key-equal member selection over that query, then consumes the
candidate object by the selected actual member index. Plan captures the raw
input from that exact observation and stored parent seed without a second
membership query.

Do not change key selection to exact-demand equality. The demanded first sound
clock may differ from the selected Original clock. This optimization authenticates
the SELECTED Original member and capture parent, not a demand/Original relation.
OwnerKey remains a selector, not ancestry proof.

Implement Plan and the real shared node-description consumer together. Do not
publish a public candidate API first without its numerical production caller.

## Source facts

- shared_eq/node_description.rs::describe creates Sounds first, clips Original
  support to at..at+1, calls Context::owners, chooses the first key-equal clock
  over spans/members, clones it, and calls Context::owner_context.
- Context::owners uses Root audio_gain_owners or actual Domain gain_owners, bills
  query.work, then validates treatment layers. It uses allow_inactive behavior;
  do not replace gain_owners with stricter inspection owners or filter support.
- Context::owner_context calls Root/Domain owner_input. Those each create ANOTHER
  gain-owner query over at..at+1, then Plan resolve_input checks same_at membership
  and calls audio_walk_owner_input with None / Some(&actual_domain.seed).
- resolve_input already owns the second query through capture, clones the
  selected observed clock into AudioOwnerInput, computes Owner versus
  EnclosingProcessor, and reports membership-query+capture construction work.
- The common conversion then bills retained_probe_at work for Some AND None,
  queries retained owners when present, and keeps exact Retained versus Domain
  choice. Incoming Context::Retained bypasses owner_input and clones its Arc.
- AudioOwnerQuery spans have integer sample labels and strict forward progress.
  A nonempty at..at+1 query has at most ONE span. A clipped nonempty integer
  support interval is still exactly at..at+1.

Therefore remove only that repeated Root/Domain membership query. Retained
already has no second membership query and should keep its current branch.

## Concrete Plan types and API

Conceptual signatures, to be implemented in the same actual-consumer patch:

    enum Parent<'context, 'plan> { // private
        Root(&'plan RenderPlan),
        Domain(&'context AudioDomain<'plan>),
    }

    pub struct AudioOwnerInputCandidates<'context, 'plan> {
        parent: Parent<'context, 'plan>,
        at: AudioSample,
        query: AudioOwnerQuery<'plan>,
        query_limits: AudioQueryLimits,
    }

    RenderPlan::audio_owner_input_candidates_at(at, limits)
    AudioDomain::owner_input_candidates_at(at, limits)

The constructors invoke the SAME respective gain-owner query once, storing
their actual parent/seed relationship by construction. Domain borrows the
real opaque handle; no cloned seed/Arc, hash, public-field reconstruction or
pointer-equality substitute. Root owns no additional plan Arc.

Methods:
- query() -> &AudioOwnerQuery: read-only for existing treatment validation and
  first-match selection; work() -> usize reports that actual initial query.
- capture(self, member_index, capture_limits) -> Result<AudioOwnerInputCapture>:
  consume once, bounds-check the actual first-span member, verify its span
  contains stored at, and capture with the stored parent. NO caller clock,
  plan, seed, new at or free OwnerKey is accepted.
- without_selection(self) -> AudioOwnerInputCapture: consume with no capture,
  report the query work and capture_work=0. No fresh query-limits request or
  limit validation should be forced for an absent selection.

    pub struct AudioOwnerInputCapture<'plan> { // private fields
        input: Option<AudioOwnerInput<'plan>>,
        query_work: usize,
        capture_work: usize,
    }

Expose query_work(), capture_work(), work() [their total], input(), into_input().
This is a work receipt, not a new graph. An absent selection still reports all
actual query work, preventing another successful-None reporting hole.

Existing AudioOwnerInput.work remains TOTAL membership+capture provenance.
For Some, it equals receipt.work. Audio, having already billed the candidate
query, bills ONLY receipt.capture_work. Do not subtract or refund work from
ReadWork, and do not bill input.work again in that already-paid path.

Selected member indices are not externally forged ancestry: every index is
checked against this privately constructed query, and every returned observation
comes from it. Reusing a scalar index from another query merely selects an
actual member of THIS query; it cannot supply a foreign clock or raw parent.
The actual Audio caller must still find the first key match on THIS view.

A separate borrow-token selection object is unnecessary and risks a self-borrow
that prevents consuming the candidate. One stored sample plus checked first-span
member index is sufficient. Keep it single-sample rather than introducing
multi-window selection rules without a real caller.

## Share the existing capture algorithm

Split resolve_input after its membership selection into ONE private
capture_observed helper. It receives actual observed clock, at, bounded capture
budget and actual optional seed, then performs the current audio_walk_owner_input,
captured-seed check, scope calculation and AudioDomain construction.

Both legacy resolve_input and new candidates call that same helper:
- legacy owner_input keeps its query+same_at check and existing total work;
- candidates select an actual member from their own query and skip only the
  duplicate membership query/check.

No second hand-written owner walk. No captured raw ancestry is reconstructed
from clock sampling, instance ID or treatment boundary. Keep opaque enclosing
Preserve/binding capture behavior.

## Work limits: query already paid, input total still bounded

Initial query uses its existing actual maximum_work, at most 65,536, and returns
Q. Audio bills Q at the old initial-query point, before treatment validation
and selection. On selection it obtains fresh WorkControl.query_limits at the
old owner_input point.

Capture budget should be:

    C_limit = min(stored_query_limit.maximum_work - Q,
                  fresh_capture_limit.maximum_work)

Validate limits and subtraction. Start a fresh budget with that capture-only
allowance; report C as its actual used amount. Input total Q+C stays within the
existing combined-query ceiling. Fresh capture allowance also respects the
global remaining read budget after Q has been billed.

In the usual full allowance case the capture maximum is still 65,536-Q, exactly
the old owner's membership+capture bound. When the global budget is nearly
exhausted, removing the second Q legitimately leaves more room for C; this is
removed work, not a raised cap. Name the method argument capture_limits so it
does not falsely mean an independently unspent TOTAL input budget.

Do not initialize capture budget with fresh_limit-Q AGAIN solely because Q
appears in Input.work: that query is already globally paid and was not repeated.
Conversely do not allow Q+C to exceed the stored combined query allowance.

Absent selection: initial Q is already billed, validate layers as before, then
without_selection returns total Q and capture 0. Do not call query_limits just
to finish absence: the old sound fallback can proceed after a successful query
even when no further input lookup is needed.

Failure: initial query errors behave as now; capture errors propagate as typed
Plan errors after the already billed Q, with no scalar retry/refund. Failed
capture partial work remains limited by the existing Plan error API; do not
pretend a failed receipt exists or add a broad InvalidPlan catch.

## Concrete Audio integration

1. Keep key creation, Sounds construction, checked at+1 and support clipping at
   their current positions. If support is empty, preserve current fallback
   without creating candidates.
2. Root/Domain nonempty case constructs exact candidates. Reuse a private
   admit_owner_query(query,control) extraction to bill Q and validate all
   treatment layers exactly as Context::owners currently does.
3. Read first-span owners in their original order; find FIRST key match. Keep
   the old per-candidate key comparison initially; a borrowed-key optimization
   is separate. Save only its index, not a cloned selected clock.
4. Selected: capture(index,control.query_limits()?), bill capture_work only,
   move its Input into a factored Context::finish_paid_owner_input helper.
5. That conversion runs the current retained_probe_at and bills its work for
   Some/None, then retained-owner query/work/provenance decision or Domain clone.
6. Ordinary owner_context still resolves its own input, bills input.work TOTAL,
   then calls the same conversion. PreparedOwnerEqualizer users therefore keep
   the existing total construction-work contract.
7. Retained initial context keeps its existing query/selection/Arc-clone branch;
   there is no duplicate query to remove there.
8. Sound fallback, boundary validation, native admission and node publication
   stay after the same completed metadata phases.

This removes the selected-clock .cloned() intermediary and the second query's
entire allocation/traversal. Input's required observed-clock clone remains.
Those are explicit allocation/lifetime changes, not altered media semantics.

## Lifetimes and heap implications

Root's plan borrow already lasts for 'plan. Domain candidates borrow the real
AudioDomain wrapper for 'context, while query clocks and final Input borrow the
external plan for 'plan. Existing Domain::owner_input already returns an owned
AudioDomain<'plan> independent of the wrapper's short borrow; the shared capture
helper keeps that property. Capture consumes/drops candidates before conversion
continues, so no self_cell or new plan pin is necessary.

The first query now survives selection through capture. Previously it was
dropped, then an identical second query from the same parent/one-sample window
survived capture. For successful calls those query shapes/capacities should be
identical: same gain-owner implementation, seed, sample, span cap and forward
walk. Treatment validation doesn't mutate the first query.

Prove that parity with actual capacity/heap tests; do not merely assert no peak
increase. No two owner-query graphs should coexist, and the removed selected
clock clone should not be recreated. Header/parent/receipt fields are bounded
stack state. New public query wrappers must not silently retain every candidate
across nodes or expose an arbitrary external-query constructor.

This does not admit a cold descriptor inventory's Domain/Retained/Sounds heap.
Its separate resource bound remains required. No existing order-vector or PCM
reservation can be repurposed as a blanket metadata allowance.

## Focused implementation tests

- Actual Root and captured Domain: candidates query equals the legacy gain-owner
  oracle; choose a real member, compare captured scope/owner observation, context
  support/processing, and retained probe/reference mapping against owner_input.
  Assert receipt.work=Q+C, Input.work=Q+C and Q/C separately; capture exact and
  one-short work, no second query through actual Audio accounting.
- No key match: finish absence, receipt Q and C 0, identical sound fallback;
  exact initial-query remaining budget must not fail merely because capture
  limits were unnecessarily requested.
- Domain seed: use a REAL RootRoundEven retained raw Domain from existing
  audio_owners/input_tests::retained_binding_is_not_reconstructed_from_its_nominal_descendant_clock,
  and a cropped group with hidden negative samples from
  cropped_group_input_keeps_hidden_siblings_and_signed_root_grid. Compare
  legacy Domain::owner_input and candidate capture at those actual labels.
  Replacing its parent by Root must fail or produce the wrong definition/
  context and be caught. Do not construct a fake seed in the new test.
- Whole Repeat: existing repeat_play_gap_and_whole_repeat_have_distinct_contexts.
  Capture at 6 must own the actual play 1 observation while preserving whole
  input 0..16; a play 0 key/boundary match must not replace its selected member.
  New sample 0 needs a new candidate object, not replay of the consumed one.
- Foreign plan: equal-content independent plans still produce inputs belonging
  only to their own actual parent. There is no API argument to splice query A
  into parent B. Legacy foreign-owner rejection remains unchanged.
- Actual Audio node-description old/new oracle: preserve chosen clock, context,
  stop, boundary and fallback; successful billed work decreases by EXACTLY the
  removed second gain-owner query's actual work, not a guessed multiplier.
  Existing new None probe work remains billed. A counterfactual retaining the
  duplicate numerical query must fail this accounting assertion.
- Preserve before/after native/provider counters and PCM/suppression oracles.
  Guard invalid index/window, empty/inactive owners, default gaps, canceled,
  deadline, query work failures and existing Retained branch without masking.

The current literal 28 metadata witness should change only by measured removed
query work; derive its new value from a focused run rather than guessing here.
No build/test/performance result is claimed by this note.
