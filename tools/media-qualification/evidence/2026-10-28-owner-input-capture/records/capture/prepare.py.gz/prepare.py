from pathlib import Path
import json,hashlib
root=Path('/Users/michael/Code/deadpan'); out=Path('/tmp/deadpan-owner-input-capture-2026-10-28')
paths=['crates/deadpan-plan/src/audio_owner_input.rs','crates/deadpan-plan/src/plan.rs','crates/deadpan-plan/src/lib.rs','crates/deadpan-plan/src/audio_owners/input_tests.rs','crates/deadpan-audio/src/authored_eq.rs','crates/deadpan-audio/src/shared_eq/node_description.rs','crates/deadpan-audio/src/shared_eq/node_description_tests.rs']
pins={}
for rel in paths:
    data=(root/rel).read_bytes(); pins[rel]=hashlib.sha256(data).hexdigest()
    for folder in ['before','source']:
        p=out/folder/rel; p.parent.mkdir(parents=True,exist_ok=True); p.write_bytes(data)
(out/'before.json').write_text(json.dumps(pins,indent=2)+'\n')
r=out/'source'
p=r/'crates/deadpan-plan/src/audio_owner_input.rs'; s=p.read_text()
needle='use crate::PlanError;\n'
assert s.count(needle)==1
s=s.replace(needle,needle+'''
#[path = "audio_owner_input/candidates.rs"]
mod candidates;
pub use candidates::{AudioOwnerInputCandidates, AudioOwnerInputCapture};
''',1)
a=s.index('    let mut captured = None;',s.index('fn resolve_input'))
old=s[a:]
# The existing resolve_input is the file's final function.
assert old.rstrip().endswith('}')
body=old[:old.rfind('}')].rstrip()
body=body.replace('plan.audio_walk_owner_input(at, &mut budget, observed, &mut captured, context)?;',
                  'plan.audio_walk_owner_input(at, budget, observed, &mut captured, context)?;',1)
body=body.replace('        work: limits.maximum_work - budget.remaining,',
                  '        work: query_work + (before - budget.remaining),',1)
s=s[:a]+'''    capture_observed(plan, observed, at, context, query.work(), &mut budget)
}

/// Capture one member of the actual checked owner query. Both the ordinary
/// membership API and sealed one-sample candidates use this exact walk.
fn capture_observed<'plan>(
    plan: &'plan RenderPlan,
    observed: &AudioOwnerClock<'plan>,
    at: AudioSample,
    context: Option<&super::audio_domain::AudioWalkSeed>,
    query_work: usize,
    budget: &mut Budget,
) -> Result<AudioOwnerInput<'plan>, PlanError> {
    let before = budget.remaining;
'''+body+'\n}\n'
p.write_text(s)
p=r/'crates/deadpan-plan/src/plan.rs'; s=p.read_text()
old='    AudioOwnerInput, AudioOwnerInputScope, AudioOwnerRetainedInput, AudioOwnerRetainedProbe,'
new='''    AudioOwnerInput, AudioOwnerInputCandidates, AudioOwnerInputCapture, AudioOwnerInputScope,
    AudioOwnerRetainedInput, AudioOwnerRetainedProbe,'''
assert s.count(old)==1; p.write_text(s.replace(old,new))
p=r/'crates/deadpan-plan/src/lib.rs'; s=p.read_text()
old='''    AudioOwnerInput, AudioOwnerInputScope, AudioOwnerOccurrence, AudioOwnerOccurrenceMap,
    AudioOwnerOccurrences, AudioOwnerRetainedInput, AudioOwnerRetainedProbe,'''
new='''    AudioOwnerInput, AudioOwnerInputCandidates, AudioOwnerInputCapture, AudioOwnerInputScope,
    AudioOwnerOccurrence, AudioOwnerOccurrenceMap, AudioOwnerOccurrences, AudioOwnerRetainedInput,
    AudioOwnerRetainedProbe,'''
assert s.count(old)==1; p.write_text(s.replace(old,new))
p=r/'crates/deadpan-audio/src/authored_eq.rs'; s=p.read_text()
# Share the existing query charge and layer checks; do not clone the query.
a=s.index('        control.spend_plan_work(query.work())?;',s.index('    pub(super) fn owners('))
b=s.index('        Ok(query)',a)
admission=s[a:b]
s=s[:a]+'''        Self::admit_owner_query(&query, control)?;
'''+s[b:]
pos=s.index('    pub(super) fn owner_context')
s=s[:pos]+'''    pub(super) fn admit_owner_query(
        query: &AudioOwnerQuery<'plan>,
        control: WorkControl<'_>,
    ) -> Result<(), StageAudioError> {
'''+admission+'''        Ok(())
    }

'''+s[pos:]
a=s.index('        let probe = input.retained_probe_at',s.index('    pub(super) fn owner_context'))
s=s[:a]+'''        Self::finish_paid_owner_input(&input, owner, at, control)
    }

    /// Input construction has already been billed, either in full by
    /// owner_context or as query plus capture by the candidate consumer.
    pub(super) fn finish_paid_owner_input(
        input: &deadpan_plan::AudioOwnerInput<'plan>,
        owner: &AudioOwnerClock<'plan>,
        at: AudioSample,
        control: WorkControl<'_>,
    ) -> Result<Self, StageAudioError> {
'''+s[a:]
p.write_text(s)
p=r/'crates/deadpan-audio/src/shared_eq/node_description.rs'; s=p.read_text()
a=s.index('    let observed = if range.start < range.end')
b=s.index('    let boundary = owner.treatment_boundary(stage)?;',a)
s=s[:a]+'''    let original = if let Some(original) =
        original_context(plan, &incoming.original, &key, range, at, control)?
    {
        original
    } else if let Sounds::Owner(context) = &sounds {
        Context::Domain(Arc::new(context.processing_domain().clone()))
    } else {
        return Err(PlanError::InvalidPlan("missing shared EQ Original context").into());
    };
'''+s[b:]
pos=s.index('#[cfg(test)]')
s=s[:pos]+'''/// Reuse the first actual Root/Domain membership query for capture. The
/// selected clock still follows the inherited first OwnerKey match.
fn original_context<'plan>(
    plan: &'plan RenderPlan,
    incoming: &Context<'plan>,
    key: &OwnerKey,
    range: Range<AudioSample>,
    at: AudioSample,
    control: WorkControl<'_>,
) -> Result<Option<Context<'plan>>, StageAudioError> {
    if range.start >= range.end {
        return Ok(None);
    }
    let candidates = match incoming {
        Context::Root => plan.audio_owner_input_candidates_at(at, control.query_limits()?)?,
        Context::Domain(domain) => domain.owner_input_candidates_at(at, control.query_limits()?)?,
        Context::Retained(_) => {
            // This branch already has no repeated membership query. Keep its
            // actual retained-grid query, clock clone and immediate Arc clone.
            let observed = {
                let query = incoming.owners(plan, range, control)?;
                query
                    .spans()
                    .iter()
                    .flat_map(|span| span.owners())
                    .find(|clock| OwnerKey::new(clock) == *key)
                    .cloned()
            };
            return if let Some(clock) = observed {
                Ok(Some(incoming.owner_context(plan, &clock, at, control)?))
            } else {
                Ok(None)
            };
        }
    };
    Context::admit_owner_query(candidates.query(), control)?;
    let selected = candidates
        .query()
        .spans()
        .first()
        .and_then(|span| {
            span.owners()
                .iter()
                .position(|clock| OwnerKey::new(clock) == *key)
        });
    let capture = if let Some(index) = selected {
        let capture = candidates.capture(index, control.query_limits()?)?;
        control.spend_plan_work(capture.capture_work())?;
        capture
    } else {
        // Absence has only the already-paid query, and must not request fresh
        // capture limits or spend a synthetic zero-work operation.
        candidates.without_selection()
    };
    if let Some(input) = capture.into_input() {
        Ok(Some(Context::finish_paid_owner_input(
            &input,
            input.owner(),
            at,
            control,
        )?))
    } else {
        Ok(None)
    }
}

'''+s[pos:]
p.write_text(s)
print(json.dumps(pins,indent=2))
