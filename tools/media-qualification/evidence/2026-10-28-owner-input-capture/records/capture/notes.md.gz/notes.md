# Consume checked owner candidates for one raw-input capture

Scratch candidate against the current cb3e9f39 source supplied by parent.
No live writes, compiler, Cargo, tests, Git or worktrees. Source/tests FROZEN.
Seven existing files plus one private companion module, all listed by manifests.
Every captured main input still hash-matched at the final audit.

## Actual production path

New public Plan types/methods and their numerical Audio consumer are in the
SAME patch. No unused future classification or measurement API is introduced.

AudioOwnerInputCandidates<'context,'plan>:
- owns the actual one-sample AudioOwnerQuery;
- privately borrows Parent::Root(&RenderPlan) or Parent::Domain(&AudioDomain);
- stores actual sample/limits, with no new plan Arc, cloned seed or hash;
- has no Clone, public constructor or external-query rebinding API.

RenderPlan::audio_owner_input_candidates_at and
AudioDomain::owner_input_candidates_at invoke their SAME gain-owner query once.
Their private checked constructor enforces the one-sample span invariant.
Query windows have integer labels and strict forward progress, hence at most
one span for at..at+1.

query()/work() allow admission and existing first-match selection.
capture(self,index,fresh_limits) consumes one actual first-span member, checks
the index and stored sample, then uses its private actual parent/seed.
There is no free clock, new at, OwnerKey, raw grid or reconstructed Domain input.

without_selection(self) produces an absent receipt without requesting fresh
capture limits. Its performed query work is not lost.

AudioOwnerInputCapture holds Option<Input>, query_work and capture_work.
work() is their total; Some Input.work is that same Q+C provenance. Getters
and into_input move the actual result without another graph clone.

## Work, caps and the shared walk

The old resolve_input retains its exact membership query/same_at check.
Both it and candidates call ONE private capture_observed helper containing the
existing audio_walk_owner_input, captured-seed requirement, scope calculation
and domain construction. The final Input owner clone remains there.

Legacy initial capture budget remains L-Q. New candidate capture budget is
min(stored L-Q, fresh capture allowance). No combined input exceeds its stored
maximum of 65,536; fresh global remaining work also limits actual C.
Internal zero goes straight into that existing walker and produces structural
work exhaustion. It is NOT wrapped in invalid AudioQueryLimits(maximum_work=0).

Input.work = Q + (capture-start remaining - final remaining), exactly the old
L-final formula for legacy calls. A capture receipt reports C directly, not a
subtraction/refund from the controller or an invented lower query weight.

## Audio factoring and behavior

Context::admit_owner_query shares the existing query spend and treatment-layer
validation with Context::owners. The latter retains all behavior.
Context::finish_paid_owner_input shares only conversion of an already-paid Input:
same retained_probe_at/work for Some AND None, retained-owner query/work,
boundary/provenance decision and Domain/Retained Arc construction.
Ordinary owner_context still pays full Input.work before this conversion;
PreparedOwnerEqualizer's total-work contract is unchanged.

node_description::describe keeps key/Sounds/support/fallback/boundary order.
Its Root/Domain branch:
1. constructs exact candidates;
2. bills Q and validates layers BEFORE selection;
3. chooses FIRST key-equal member in the actual query;
4. obtains fresh capture limits only when selected;
5. captures once and bills ONLY C;
6. converts that Input through finish_paid_owner_input, keeping the fixed
   successful None-probe work charge.

There is no key-based raw-context proof: index selects the actual observed
Original clock, which may differ from demanded sound clock. The callback's
boundary still comes from its original demanded clock, as before.

Incoming Retained uses the old owner query, selected-clock clone and immediate
owner_context Arc-clone branch; it has no second membership query to remove.
Empty support and no selection preserve current sound fallback/missing errors.
Tail, stage/native admission, source, permissions and output math are untouched.

Removed execution: the entire second Root/Domain membership query and the
intermediate selected-clock .cloned(). Input's actual observation clone stays.
The first query now survives through capture in place of the old identical
second query. No two owner-query graphs coexist in the production candidate path.

## Tests authored, not executed

Plan input tests:
- root_candidates_capture_the_actual_member_once_with_equal_query_heap:
  real legacy query/Input oracle, Q/C/total receipt contract, context/scope/work
  equality, exact query capacity and owned heap parity.
- candidates_report_absence_and_preserve_combined_and_capture_work_caps:
  actual measured Q/C; combined exact/one-short, capture-only exact, absent
  receipt at exhausted Q allowance, internal-zero structural refusal.
- domain_candidates_keep_hidden_negative_support_and_actual_seed:
  actual captured cropped group, signed support -3..13, capture at -2, same
  legacy Domain input and heap; Root lookup rejects the hidden label.
- candidate_capture_keeps_whole_repeat_observation_and_foreign_plan_separate:
  actual play at 6 and whole input 0..16; differing play 0 observation cannot replace
  it, equal-content foreign plan remains foreign, invalid member index rejects.
- existing retained_binding_is_not_reconstructed_from_its_nominal_descendant_clock
  now also uses its REAL RootRoundEven reference Domain at 3; seeded candidate
  capture equals legacy Domain capture while live Root lookup is rejected.

The test-only heap helper exhaustively destructures actual Query/Span fields,
counts Vec capacities, and uses the EXISTING field-aware clock OwnedHeap visitor.
It adds no public measurement API. Captured domains also compare existing heap
counts and all private seed values against the independent legacy capture
(Debug is only a test representation, never runtime identity).

Audio node-description tests:
- metadata_query_work_removes_one_actual_membership_query:
  independent legacy Root query measures removed Q; new billed+Q equals the
  qualified old total 28, while successful None probe remains 9. Exact new
  remainder is derived 28-Q, one less preserves prefix 19-Q before the unchanged
  typed structural probe error. No guessed new literal or diagnostic print.
- absent_member_keeps_query_work_without_requesting_capture_headroom:
  real Tone Domain excludes exterior root; requesting root's key has no match;
  Q uses the last canonical units, absence still completes without new limits.
- candidate_root_and_domain_contexts_match_legacy_and_save_only_query_work:
  actual old two-query oracle and new production helper contexts agree, and
  spent difference is EXACTLY the independently performed membership query.
Existing literal contexts, fallback, retained Arc and error-order tests remain.

A counterfactual keeping the duplicate numerical query must fail the new Audio
accounting assertions. New API-only tests cannot compile on the old API and are
not mislabeled as old-failing runtime evidence. Parent owns all execution.

## Guard/lifetime and heap limitations

A selected member belongs to this privately created query and parent. No caller
can splice query A into parent B. A scalar index from another query still only
selects an actual member of THIS batch; Audio's first-selector intent is unchanged.
Capture consumes/drops the query before conversion and retains only the actual
Input, as legacy owner_input already does. Final Input lifetime is the external
plan, not the temporary Domain borrow. No self-reference or new lifetime pin.

Query-capacity/heap tests check parity for real Root/Domain cases; they are not
a construction-peak allocator proof, nor prior admission for a cold inventory.
New parent/receipt headers are stack state. The candidate must not be retained
across nodes/reads or generalized into a query cache. Plan query limits and the
existing numerical allocation policy remain unchanged.

All successful Some/None probe work stays charged. Errors propagate without
broad catch, budget reset, retry or refund. If an honest limit still blocks
acceptance, more real execution must be removed. Full cold resource admission,
Retained/Projected recursive eligibility, descriptor inventory/cache-hit
continuations and batching remain OFF. No acceptance or performance claim.
