# Actual owner-query capture qualification

Main owns Cargo, live integration, scoped staging and pushes. Worker source and review were scratch-only.

Plan's sealed non-Clone one-sample candidates own the real gain-owner query and borrow its actual Root/Domain parent. Capture takes an actual checked member index, stores the actual sample/seed, and shares the existing capture walker with legacy owner_input. Work receipt separates prepaid query Q from additional capture C; Input.work stays Q+C. The actual Audio Root/Domain path consumes it. Retained and sound fallback remain unchanged, and retained_probe work still charges successful None.

A negative isolated variant restores the previous descriptor path while keeping the new Plan API and tests. Its Audio library has266pass/1expectedfailure: the actual metadata path cannot fit the reduced budget while it repeats the query. All other tests pass; no old-PCM failure is claimed. The new private helper remains for its direct absence tests in that negative build.

Restoring the positive scoped descriptor with copy2 preserved its older mtime. Cargo's first restored no-run build took0.16s and returned the exact known-negative Audio binary. It is rejected, pinned only as failure evidence, never used for positive qualification. The restored file is touched; capture-scoped-build2 recompiles it, produces a different binary hash, and passes267Audio tests. All future positive scoped results use build2. The repo Development guide records this source/binary provenance hazard.

The current patch has no compiler, strict-lint or positive runtime failure. A successful Cargo command alone is not accepted as source provenance: the old-counterexample test and binary hashes distinguish the stale artifact.

No clocks/domains are reconstructed from keys or sampling. No query/discovery/prefix cache, fake renderer, native probe, cap/weight/refund/retry change or cold activation is introduced. Same-query storage parity does not establish prior metadata construction admission. The separate sound-context admission work remains an uncompiled scratch task and is outside this delivery.
