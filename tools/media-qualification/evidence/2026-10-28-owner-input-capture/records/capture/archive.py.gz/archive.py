from pathlib import Path
import hashlib,json,gzip
s=Path(__file__).resolve().parent
repo=Path('/Users/michael/Code/deadpan')
dest=repo/'tools/media-qualification/evidence/2026-10-28-owner-input-capture'
assert not dest.exists(),'Archive only once all receipts are terminal'
allowed={'.rs','.json','.py','.md','.patch','.stdout','.stderr','.txt'}
entries=[]
sources=[('capture',p,p.relative_to(s)) for p in sorted(s.rglob('*')) if p.is_file() and p.suffix in allowed and p.name!='qualification-draft.md']
design=Path('/tmp/deadpan-owner-input-candidates-2026-10-28')
sources.extend(('query-design',p,p.relative_to(design)) for p in sorted(design.rglob('*')) if p.is_file() and p.suffix in allowed)
for group,p,relative in sources:
 data=p.read_bytes()
 if p.suffix=='.json':
  value=json.loads(data)
  if isinstance(value,dict) and 'command' in value and 'started_at' in value:
   assert 'exit_code' in value and value['sources_unchanged'] and value['binaries_unchanged'],str(p)
 out=dest/'records'/group/relative
 out=out.with_name(out.name+'.gz');out.parent.mkdir(parents=True,exist_ok=True)
 compressed=gzip.compress(data,mtime=0);out.write_bytes(compressed)
 entries.append({'path':str(out.relative_to(dest)),'bytes':len(compressed),'sha256':hashlib.sha256(compressed).hexdigest(),'expanded_bytes':len(data),'expanded_sha256':hashlib.sha256(data).hexdigest()})
manifest={'schema_version':1,'base_revision':(s/'base-revision.txt').read_text().strip(),'scope':'Eight-file one-sample actual owner-query/capture fusion. Sealed actual Root/Domain parent and selected member; shared capture walk; total Input.work contract plus prepaid query/capture-only receipt. Actual numerical caller removes duplicate query and intermediary clock clone; retained probe work stays charged. Old-descriptor variant fails tight-budget savings test. Known-negative Cargo artifact after old-mtime restoration is rejected by hash and freshly rebuilt; positive regression passes. No cache/weights/caps/refunds/retry or cold resource activation. Read-only design is not implementation evidence.','prior_runtime_evidence':{'path':'../2026-10-28-retained-probe-work/inventory.json','inventory_sha256':'b311089d45d4d637d33252d5a6d57cfae88a7096131370d21100add65228eac2'},'files':entries}

file=dest/'inventory.json';file.write_text(json.dumps(manifest,indent=2)+'\n')
stored=expanded=0
for row in entries:
 data=(dest/row['path']).read_bytes();plain=gzip.decompress(data)
 assert len(data)==row['bytes'] and hashlib.sha256(data).hexdigest()==row['sha256']
 assert len(plain)==row['expanded_bytes'] and hashlib.sha256(plain).hexdigest()==row['expanded_sha256']
 stored+=len(data);expanded+=len(plain)
print(json.dumps({'files':len(entries),'stored_bytes':stored,'expanded_bytes':expanded,'inventory_sha256':hashlib.sha256(file.read_bytes()).hexdigest()}))
