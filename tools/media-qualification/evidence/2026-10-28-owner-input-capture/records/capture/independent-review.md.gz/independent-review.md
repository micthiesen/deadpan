# Independent review: owner-input candidate capture

Reviewed `/tmp/deadpan-owner-input-capture-2026-10-28/owner-input-capture.patch` and its frozen `source/` snapshot against `before/`, with the assigned lens limited to query fusion, work accounting, actual clock/seed provenance, error semantics, and heap behavior. No repository files were changed and no Cargo/rustc commands were run.

## Findings

No supported correctness findings.

The candidate carrier is non-Clone and privately constructed from one checked one-sample Root or Domain query. `capture(member, ...)` resolves the indexed member from that owned query and uses its stored sample and borrowed parent. Domain capture passes the same domain seed to `capture_observed`; Root capture uses the same plan. The node-description path retains the existing OwnerKey-first-match selection and does not issue a second membership query. Retained inputs stay on the prior retained-grid path.

The accounting path is coherent: the constructor's query work is charged by `admit_owner_query` before selection. The capture budget is bounded by both the remaining original combined allowance (`stored maximum_work - query_work`) and the fresh capture allowance. Only measured successful capture work is then charged; `AudioOwnerInput.work()` remains Q+C, and a no-selection receipt preserves Q with zero capture work. A successful `None` retained probe still reaches the unchanged retained-probe charge in `finish_paid_owner_input`. Internally exhausted C=0 is passed to the existing walker without constructing invalid public limits. The ordinary single-input path uses the same `capture_observed` body and retains its original Q+C work total.

The focused tests compare captured input against ordinary Root/Domain captures, preserve actual negative hidden support and Repeat whole-observation behavior, check absence and the combined/capture caps, and compare the full owner-query heap shape. The patch snapshot's audit record reports no build or tests; integration/build verification remains outside this review and is owned by the parent.
