//! Relative whole-owner gain intent follows one isolated concrete occurrence.
use super::*;
use crate::AudioChange;

fn step(millidecibels: i32) -> SemanticInstruction {
    SemanticInstruction::SetAudio {
        change: AudioChange::Step { millidecibels },
    }
}

fn assert_context(before: &SemanticContext, after: &SemanticContext) {
    let mut expected = before.clone();
    expected.scoped = after.scoped.clone();
    assert_eq!(&expected, after);
}

fn assert_reversible(before: &ProjectDocument, plan: &SemanticPlan) {
    let replay =
        crate::replay_compound::<EditError>(before, plan.request.as_ref().unwrap(), |_| Ok(()))
            .unwrap();
    assert_eq!(replay.document, plan.document);
    assert_eq!(replay.edit.inverse.apply(&plan.document).unwrap(), *before);
    assert_eq!(
        ProjectDocument::from_json(&plan.document.to_json().unwrap()).unwrap(),
        plan.document
    );
}

#[test]
fn scoped_gain_step_isolates_one_nested_play_with_exact_pools_and_one_inverse() {
    let before = fixture();
    let context = entry();
    let target = &context.scoped.as_ref().unwrap().target;
    let treatments = AudioChange::Step {
        millidecibels: 3000,
    }
    .apply(&before.nodes()[&target.node].audio_treatments)
    .unwrap();
    let needs = before
        .scoped_edit_requirements(
            target,
            &crate::ScopedNodeEdit::SetAudioTreatments { treatments },
        )
        .unwrap();
    assert_eq!((needs.nodes, needs.marks), (10, 2));
    assert_eq!(
        before.nodes()[&node("a")]
            .audio_treatments
            .trim()
            .millidecibels(),
        0
    );
    let snapshot = before.to_json().unwrap();
    let mut allocations = Vec::new();
    let plan = resolve(
        &before,
        &context,
        vec![step(3000)],
        &BTreeMap::new(),
        |request| {
            allocations.push(request.clone());
            allocator("gain", request)
        },
    )
    .expect("one explicit nested Play must admit a relative whole-owner gain step");
    assert_eq!(before.to_json().unwrap(), snapshot);
    assert_eq!(
        allocations,
        vec![SemanticAllocationRequest::Isolation {
            step_index: 0,
            nodes: needs.nodes,
            marks: needs.marks,
        }]
    );
    assert_context(&context, &plan.context);
    let mapped = plan.context.scoped.as_ref().unwrap();
    assert!(
        mapped
            .target
            .matches_instance(&plan.document, &mapped.presentation)
            .unwrap()
    );
    assert_ne!(mapped.target.node, node("a"));
    for (owner, authored) in plan.document.nodes() {
        assert_eq!(
            authored.audio_treatments.trim().millidecibels(),
            if owner == &mapped.target.node {
                3000
            } else {
                0
            }
        );
    }
    assert_eq!(
        plan.document.nodes()[&node("a")],
        before.nodes()[&node("a")]
    );
    assert_eq!(
        plan.document.duration().unwrap(),
        before.duration().unwrap()
    );
    assert_reversible(&before, &plan);
}
