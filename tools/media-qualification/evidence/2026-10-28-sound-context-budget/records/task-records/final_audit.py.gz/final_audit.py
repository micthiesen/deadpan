from pathlib import Path
import json,hashlib
s=Path(__file__).resolve().parent
labels=['sound-build','sound-audio','sound-plan','sound-strict','sound-strict2','sound-final-build','sound-final-audio','sound-final-plan','sound-scoped-build','sound-scoped-audio','sound-scoped-plan','sound-stages','sound-split','sound-definition','sound-scoped-stages','sound-scoped-birth']
rows=[]
for label in labels:
 a=json.loads((s/(label+'.json')).read_text())
 assert a['sources_unchanged'] and a['binaries_unchanged']
 assert a['exit_code']==({'sound-strict':1,'sound-split':101}.get(label,0))
 rows.append({'label':label,'exit_code':a['exit_code'],'seconds':a['seconds'],'source_inputs':len(a['source_before']),'receipt_sha256':hashlib.sha256((s/(label+'.json')).read_bytes()).hexdigest()})
for label in ['sound-final-build','sound-scoped-build']:
 a=json.loads((s/(label+'.json')).read_text())
 for p,pin in a['source_after'].items():
  b=Path(p).read_bytes();assert len(b)==pin['bytes'] and hashlib.sha256(b).hexdigest()==pin['sha256'],p
for label,expected in [('sound-final-plan',564),('sound-scoped-plan',551)]:
 data=[json.loads(x) for x in (s/(label+'.stdout')).read_text().splitlines()]
 assert len(data)==29 and all(x['exit_code']==0 for x in data)
 results=[r for a in data for r in a['test_results']]
 assert sum(int(x[1]) for x in results)==expected
 assert all(all(int(x[i])==0 for i in [2,3,5]) for x in results)
(s/'final-audit.json').write_text(json.dumps({'all16_terminal':True,'final_sources_unchanged_now':True,'receipts':rows},indent=2)+'\n')
print('16 terminal receipts; final main/scoped source pins still match.')
