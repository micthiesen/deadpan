# Independent review: current sound-context admission

Reviewed the frozen `/tmp/deadpan-sound-context-budget-2026-10-28/sound-context.patch` and `audit.md`/`notes.md` against its stated bounded current-sound scope. Static review only; no repository edits, Cargo, rustc or Git commands.

## Findings

No supported correctness findings in the assigned admission, ownership, capacity, or accounting lens.

The revised carrier keeps owning `Values` before `Charges` in both `SoundBuild` and `AdmittedSoundContext`; `Description` likewise drops its owning context clones before the sound carrier. Failure transitions therefore retain values while RAII leases are released. The concrete lease is tied to the exact `RefCell<ReadWork>` pointer through `Issuer`, and checked before reusing the carrier or transferring it to the Graph. Reservations call the real `make_room` before increasing the pending ledger; publication moves the values into the pre-reserved Node slot, adds metadata to active/Graph residency, then commits the lease from pending residency. Graph cleanup clears cached originals and drops the Graph before subtracting its saved active residency.

Capacity reservations precede the bounded Vec and Arc allocations at the inspected sites. Chain and edge buffers are dropped before their temporary leases; retained path copies and domain/context Arc allocations remain under the merged retained lease. The checked copy path counts identity payloads conservatively. This is a logical payload accounting claim scoped to the listed current-sound metadata, not allocator overhead or whole-graph admission.

The seven Plan and six Audio tests are present and target exact/one-short admission, failure and cancellation cleanup, distinct issuer rejection, actual cache eviction, handoff and Graph lifetime. They have not been compiled or run in this snapshot. The public admission trait relies on its documented trusted-policy contract for lease Drop/merge behavior, as the design notes acknowledge; the production Audio adapter implements the checked request identity and RAII path.

## Final integration supplement

Reviewed the final `AudioSampleGrid::new` correction and the currently integrated task sources. The change removes only an identity `map_err(PlanError::from)` where the constructor already returns `PlanError`; the explicit ExactRatio conversion remains. I found no behavior or accounting change from this cleanup. The current call site still builds the sample grid with the same zero origin, computed step, and RoundEven boundary rule.

The integrated implementation remains scoped to current sound context construction, its shared wrappers, and the closed processing-Domain fallback. The main-owned strict/build/audio/plan results were reported passing (strict2, Audio 292, Plan 564); I did not rerun them. The prepared `archive.py` parses successfully and was not executed. Its terminal receipt assertions prevent archiving until the final build, Plan, Audio, strict, and stages receipts all exist with exit code zero and unchanged source/binary pins. It records the prior owner-input-capture inventory by its existing SHA-256 rather than copying that archive.
