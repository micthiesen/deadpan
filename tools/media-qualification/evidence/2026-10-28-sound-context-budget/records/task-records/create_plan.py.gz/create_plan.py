from pathlib import Path
r=Path('/tmp/deadpan-sound-context-budget-2026-10-28/candidate')
def f(p):return r/'crates/deadpan-plan/src'/p
s=f('audio_source_occurrence.rs').read_text()
s=s.replace('pub use owner_context::AudioSoundOwnerContext;','pub use owner_context::{AdmittedSoundContext, AudioSoundContextAdmission, AudioSoundOwnerContext};\nuse owner_context::admission::{SoundBuild, Unmetered};',1)
start=s.index('fn resolve_edges(\n');end=s.index('\nfn node_support(',start)
body=s[start:end]
body=body.replace('fn resolve_edges(\n','fn resolve_edges_admitted<A: AudioSoundContextAdmission>(\n',1)
body=body.replace("    budget: &mut BuildBudget,\n) -> Result<(Vec<Edge>, usize, bool), PlanError> {\n    let mut chain = vec![host];","    build: &mut SoundBuild<'_, '_, A>,\n) -> Result<(usize, bool), A::Error> {\n    let capacity = if host == plan.root { 1 } else { MAX_DOCUMENT_DEPTH + 1 };\n    build.reserve_chain(capacity)?;\n    build.values.chain.push(host);",1)
body=body.replace('budget.spend(', 'build.spend(').replace('chain.len()', 'build.values.chain.len()').replace('chain.push(', 'build.values.chain.push(').replace('chain.reverse()', 'build.values.chain.reverse()')
body=body.replace('build.values.build.values.chain.push(host);','build.values.chain.push(host);')
body=body.replace('    let mut edges = Vec::with_capacity(build.values.chain.len().saturating_sub(1));','    let chain_len = build.values.chain.len();\n    build.reserve_edges(chain_len.saturating_sub(1))?;',1)
body=body.replace('    for pair in chain.windows(2) {\n        build.spend(1)?;\n        let parent = pair[0];\n        let child = pair[1];','    for index in 0..chain_len.saturating_sub(1) {\n        build.spend(1)?;\n        let parent = build.values.chain[index];\n        let child = build.values.chain[index + 1];',1)
body=body.replace('        edges.push(Edge {','        build.values.edges.push(Edge {',1)
body=body.replace('    Ok((edges, build.values.chain.len(), has_processing))','    build.drop_chain();\n    Ok((chain_len, has_processing))',1)
body=body.replace('return Err(PlanError::AudioQueryLimit("source occurrence depth"));','return Err(PlanError::AudioQueryLimit("source occurrence depth").into());')
body=body.replace('                ));\n            }\n        };','                ).into());\n            }\n        };')
body=body.replace('        ));\n    }\n    build.drop_chain();','        ).into());\n    }\n    build.drop_chain();')
body=body.replace('.transpose()?', '.transpose().map_err(PlanError::from)?')
body=body.replace('play\n                    .branch_offset(&plan.nodes[child].inspection.id)?','play\n                    .branch_offset(&plan.nodes[child].inspection.id).map_err(PlanError::from)?')
body=body.replace('offset.checked_add(play.gap_after)?','offset.checked_add(play.gap_after).map_err(PlanError::from)?')
body=body.replace('ExactRatio::ONE.checked_div(*scale)?','ExactRatio::ONE.checked_div(*scale).map_err(PlanError::from)?')
body=body.replace('ExactRatio::ZERO.checked_sub(start.checked_mul(reciprocal)?)?','ExactRatio::ZERO.checked_sub(start.checked_mul(reciprocal).map_err(PlanError::from)?).map_err(PlanError::from)?')
wrapper='''fn resolve_edges(
    plan: &RenderPlan,
    host: usize,
    instance: &InstancePath,
    budget: &mut BuildBudget,
) -> Result<(Vec<Edge>, usize, bool), PlanError> {
    let mut admission = Unmetered;
    let mut build = SoundBuild::new(&mut admission, budget.remaining);
    let result = resolve_edges_admitted(plan, host, instance, &mut build);
    budget.remaining = build.remaining();
    let (length, processing) = result?;
    Ok((std::mem::take(&mut build.values.edges), length, processing))
}

'''
s=s[:start]+wrapper+body+s[end:];f('audio_source_occurrence.rs').write_text(s)
s=f('audio_sound_owner_context.rs').read_text()
s=s.replace('use crate::plan::audio_domain::AudioWalkSeed;','use crate::plan::audio_domain::AudioWalkSeed;\n\n#[path = "audio_sound_admission.rs"]\npub(super) mod admission;\npub use admission::{AdmittedSoundContext, AudioSoundContextAdmission};',1)
start=s.index('        limits.validate()?;',s.index('    pub fn audio_sound_instance_context('))
end=s.index('\n    }\n}',start)
s=s[:start]+'''        let mut admission = admission::Unmetered;
        Ok(self.audio_sound_instance_context_admitted(instance, limits, &mut admission)?
            .into_unmetered())
    }

    /// Construct the actual current sound context with allocation-site admission.
    /// The policy controls residency and reports every admitted inspection.
    pub fn audio_sound_instance_context_admitted<A: AudioSoundContextAdmission>(
        &self,
        instance: &InstancePath,
        limits: AudioQueryLimits,
        admission: &mut A,
    ) -> Result<AdmittedSoundContext<'_, A::Issuer, A::Lease>, A::Error> {
        limits.validate()?;
        if instance.repeats.len() > MAX_DOCUMENT_DEPTH {
            return Err(PlanError::AudioQueryLimit("sound context depth").into());
        }
        let node = *self.by_id.get(&instance.node).ok_or(
            PlanError::InvalidAudioSourceOccurrence("sound context owner is absent"))?;
        let mut build = admission::SoundBuild::new(admission, limits.maximum_work);
        resolve_edges_admitted(self, node, instance, &mut build)?;
        let mut map = Placement::IDENTITY;
        let mut processing = None;
        for index in 0..build.values.edges.len() {
            build.spend(1)?;
            let edge = &build.values.edges[index];
            if processing.is_none()
                && matches!(self.nodes[edge.parent].kind,
                    CompiledKind::Retime { pitch, scale, .. }
                        if pitch.processes(scale == ExactRatio::ONE))
            {
                processing = Some((edge.parent, map, edge.repeats));
            }
            map = map.compose(edge.map)?;
        }
        build.drop_edges();
        let (processing_node, processing_map, repeats) =
            processing.unwrap_or((node, map, instance.repeats.len()));
        let extent = processing_map.range(node_support(self, processing_node))?;
        let rate = self.metadata.presentation_basis.frame_rate;
        let step = ExactRatio::new(
            i128::from(rate.numerator()),
            i128::from(MIX_SAMPLE_RATE) * i128::from(rate.denominator()),
        ).map_err(PlanError::from)?;
        let grid = AudioSampleGrid::<AudioSample>::new(
            ExactRatio::ZERO, step, AudioBoundaryRule::RoundEven,
        ).map_err(PlanError::from)?;
        let samples = grid.boundary(extent.start).map_err(PlanError::from)?
            ..grid.boundary(extent.end).map_err(PlanError::from)?;
        build.spend(1 + repeats + instance.repeats.len())?;
        build.copy_initial_paths(
            instance, &self.nodes[processing_node].inspection.id, repeats)?;
        build.values.domain = Some(AudioDomain {
            plan: self,
            seed: AudioWalkSeed {
                definition: None, bypass_binding: None, node: processing_node,
                transform: AudioTransform {
                    project_origin: processing_map.origin,
                    project_frames_per_local_frame: processing_map.scale,
                    project_frames_per_sample: step,
                },
                grid, extent, envelope: None,
                constraints: Vec::new(), editorial: Vec::new(),
                suppress_entry_editorial: Default::default(),
                repeats: std::mem::take(&mut build.values.seed_repeats),
                retimes: Vec::new(), gap: None,
            },
            samples: samples.clone(), visible: samples,
            instance: build.values.policy_instance.take().expect("constructed path"),
            placement: None,
        });
        build.reserve_domain()?;
        build.values.policy = Some(Arc::new(
            build.values.domain.take().expect("constructed policy")));
        build.values.context = Some(AudioSoundOwnerContext {
            plan: self,
            owner: build.values.owner.take().expect("constructed owner"),
            owner_node: node,
            policy: build.values.policy.take().expect("constructed shared policy"),
            processing_node,
            processing_instance: build.values.processing.take().expect("constructed path"),
            work: build.used(),
        });
        Ok(build.finish())'''+s[end:]
f('audio_sound_owner_context.rs').write_text(s)
s=f('plan.rs').read_text()
needle='pub use audio_source_occurrence::'
i=s.find(needle)
print(s[i:i+450])
f('lib.rs').write_text(f('lib.rs').read_text().replace('    AudioSoundOwnerContext, AudioSoundPermissionFamily, AudioSoundPlacement,','    AdmittedSoundContext, AudioSoundContextAdmission, AudioSoundOwnerContext,\n    AudioSoundPermissionFamily, AudioSoundPlacement,',1).replace('pub enum PlanError {\n','pub enum PlanError {\n    #[error("audio metadata admission issuer differs")]\n    AudioMetadataIssuerMismatch,\n    #[error("current sound processing context changed shape")]\n    AudioSoundContextShapeChanged,\n',1))
