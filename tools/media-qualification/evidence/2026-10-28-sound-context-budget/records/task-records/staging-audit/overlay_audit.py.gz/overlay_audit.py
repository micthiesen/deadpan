from pathlib import Path
import hashlib,json,datetime
r=Path('/tmp/deadpan-sound-context-budget-2026-10-28');out=r/'staging-audit'
main=Path('/Users/michael/Code/deadpan');scoped=Path('/tmp/deadpan-query-groundwork-2026-10-26/scoped')
def digest(p): return hashlib.sha256(p.read_bytes()).hexdigest()
mset=set(json.loads((r/'source-files.json').read_text()));sset=set(json.loads((r/'scoped-source-files.json').read_text()))
common=sorted(mset&sset)
equal=[];different=[]
for rel in common:
 a=main/rel;b=scoped/rel
 entry={'path':rel,'main_sha256':digest(a),'scoped_sha256':digest(b),'main_bytes':a.stat().st_size,'scoped_bytes':b.stat().st_size}
 (equal if entry['main_sha256']==entry['scoped_sha256'] else different).append(entry)
task=json.loads((out/'task-files.json').read_text())
owned={e['path'] for e in task}
snapshot_changes=[]
for rel in owned:
 for label,live in [('main',main),('scoped',scoped)]:
  snap=out/(label+'-final')/rel
  if digest(snap)!=digest(live/rel):snapshot_changes.append({'tree':label,'path':rel})
applied_mismatches=[]
for rel in owned:
 if digest(out/'validation'/rel)!=digest(out/'index-candidate'/rel):applied_mismatches.append(rel)
report={'audited_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
 'main_root':str(main),'scoped_root':str(scoped),'main_source_inputs':len(mset),'scoped_source_inputs':len(sset),
 'common_inputs':len(common),'common_equal':len(equal),'common_differing':len(different),
 'main_only_inputs':sorted(mset-sset),'scoped_only_inputs':sorted(sset-mset),
 'common_differences':different,'task_files':task,
 'task_snapshot_drift':snapshot_changes,'scratch_apply_mismatches':applied_mismatches,
 'main_index_before':json.loads((out/'index-before.json').read_text()),
 'main_index_after':{'bytes':(main/'.git/index').stat().st_size,'sha256':digest(main/'.git/index')},
 'git_apply_check_exit':0,'git_apply_scratch_exit':0}
report['main_index_byte_unchanged']=report['main_index_before']==report['main_index_after']
assert not snapshot_changes
assert not applied_mismatches
assert report['main_index_byte_unchanged']
(out/'overlay-audit.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({k:report[k] for k in ['main_source_inputs','scoped_source_inputs','common_inputs','common_equal','common_differing','task_snapshot_drift','scratch_apply_mismatches','main_index_byte_unchanged']},indent=2))
print('ALL COMMON DIFFERENCES:')
print('\n'.join(x['path'] for x in different))
