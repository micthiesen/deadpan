--- main/crates/deadpan-audio/src/shared_eq/sound_admission_tests.rs
+++ scoped/crates/deadpan-audio/src/shared_eq/sound_admission_tests.rs
@@ -11,12 +11,9 @@
         event_filters: BTreeMap::new(),
         voices: BTreeMap::new(),
         permission_families: BTreeMap::new(),
-        selected_family_count: 0,
-        canonical_families: FamilyRegistry::default(),
         sends: None,
         skip: Vec::new(),
         original_only,
-        original_inputs: original_inputs::Cache::default(),
     }
 }
 fn node<'plan>(
