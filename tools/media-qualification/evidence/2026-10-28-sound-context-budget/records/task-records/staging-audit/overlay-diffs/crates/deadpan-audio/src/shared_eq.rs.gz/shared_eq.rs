--- main/crates/deadpan-audio/src/shared_eq.rs
+++ scoped/crates/deadpan-audio/src/shared_eq.rs
@@ -28,11 +28,6 @@
 #[path = "event_returns.rs"]
 mod event_returns;
 use event_returns::{EventKey, EventRead, EventSource};
-#[path = "shared_eq/original_inputs.rs"]
-pub(super) mod original_inputs;
-#[path = "shared_eq/permission_families.rs"]
-mod permission_families;
-use permission_families::{FamilyRegistry, FamilyToken};
 
 #[path = "shared_eq/policy_prediction.rs"]
 mod policy_prediction;
@@ -85,13 +80,11 @@
     event_nodes: std::collections::BTreeSet<EventKey>,
     event_filters: BTreeMap<EventKey, crate::Equalizer>,
     voices: BTreeMap<Voice, usize>,
-    permission_families: BTreeMap<InstancePath, BTreeMap<usize, Option<FamilyToken<'plan>>>>,
-    selected_family_count: usize,
-    canonical_families: FamilyRegistry<'plan>,
+    permission_families:
+        BTreeMap<(InstancePath, usize), Option<deadpan_plan::AudioSoundPermissionFamily<'plan>>>,
     sends: Option<deadpan_core::TailEffect>,
     skip: Vec<authored_gain::OwnerIdentity>,
     original_only: bool,
-    original_inputs: original_inputs::Cache<'plan>,
 }
 
 #[derive(Default)]
@@ -112,6 +105,76 @@
         let id = self.voices.len();
         self.voices.insert(voice, id);
         Ok(id)
+    }
+
+    /// The consuming voice may be absent from a later halo input block. Resolve
+    /// its identity in the complete owner context once, independently of that
+    /// block's active occurrences, then retain only bounded checked handles.
+    fn selected_split_families(
+        &mut self,
+        context: &AudioSoundOwnerContext<'plan>,
+        selected: Permissions,
+        control: WorkControl<'_>,
+    ) -> Result<Vec<(usize, deadpan_plan::AudioSoundPermissionFamily<'plan>)>, StageAudioError>
+    {
+        control.spend_plan_work(self.voices.len())?;
+        let mut selected_voices = Vec::new();
+        for (voice, id) in &self.voices {
+            if selected.contains(*id)
+                && let Voice::Beat(owner, sound, instance) = voice
+            {
+                control.spend_plan_work(3 + instance.repeats.len())?;
+                selected_voices.push((*id, owner.clone(), sound.clone(), instance.clone()));
+            }
+        }
+        let mut result = Vec::new();
+        for (id, owner, sound, instance) in selected_voices {
+            control.spend_plan_work(1 + context.owner().repeats.len())?;
+            let key = (context.owner().clone(), id);
+            if !self.permission_families.contains_key(&key) {
+                if self.permission_families.len() == shared_mix::MAX_VOICES {
+                    return Err(StageAudioError::Limit("shared Split family count"));
+                }
+                let scopes = self.plan.beat_sound_clock_scopes(
+                    &owner,
+                    &sound,
+                    control.query_limits()?.maximum_work,
+                )?;
+                for scope in &scopes {
+                    control.spend_plan_work(scope.proof_work())?;
+                }
+                let family = if scopes.iter().any(|scope| scope.has_split_alias()) {
+                    let event = self
+                        .plan
+                        .beat_sounds()
+                        .get(&owner)
+                        .and_then(|events| events.get(&sound))
+                        .ok_or(PlanError::InvalidPlan("selected Split event absent"))?;
+                    let voice = context.source_voice_occurrence(
+                        instance,
+                        deadpan_plan::AudioSourceVoiceRecipe {
+                            source: event.source.clone(),
+                            mapping: event.mapping,
+                            offset: event.offset,
+                        },
+                        control.query_limits()?,
+                    )?;
+                    control.spend_plan_work(voice.construction_work())?;
+                    let (family, used) =
+                        voice.split_permission_family(&scopes, context, control.query_limits()?)?;
+                    control.spend_plan_work(used)?;
+                    family
+                } else {
+                    None
+                };
+                self.permission_families.insert(key.clone(), family);
+            }
+            if let Some(family) = &self.permission_families[&key] {
+                control.spend_plan_work(family.comparison_work())?;
+                result.push((id, family.clone()));
+            }
+        }
+        Ok(result)
     }
 }
 #[derive(Clone, Copy)]
@@ -143,7 +206,7 @@
 /// input. Raw sample permissions and delivery supports are still checked by
 /// add_sound. Families cannot be inferred from a shared label or sound ID.
 fn split_family_aliases(
-    families: &[(usize, FamilyToken<'_>)],
+    families: &[(usize, deadpan_plan::AudioSoundPermissionFamily<'_>)],
     selected: Permissions,
     control: WorkControl<'_>,
 ) -> Result<Permissions, StageAudioError> {
@@ -156,8 +219,12 @@
             if !selected.contains(*candidate) {
                 continue;
             }
-            control.spend_plan_work(1)?;
-            if family.same(other) {
+            control.spend_plan_work(
+                family
+                    .comparison_work()
+                    .saturating_add(other.comparison_work()),
+            )?;
+            if family == other {
                 aliases.insert(*id)?;
                 break;
             }
@@ -193,16 +260,6 @@
             .0
             .checked_add(i64::from(frames))
             .ok_or(TimeError::Overflow)?;
-        let cache_reservation = original_inputs::Cache::resident_frames()?;
-        let reservation = u64::from(frames)
-            .checked_mul(3)
-            .and_then(|value| value.checked_add(cache_reservation))
-            .ok_or(StageAudioError::Range)?;
-        self.make_room(reservation, false, control)?;
-        self.active_frames = self
-            .active_frames
-            .checked_add(reservation)
-            .ok_or(StageAudioError::Range)?;
         let plan = Arc::clone(&self.plan);
         let mut graph = Graph {
             plan: &plan,
@@ -214,13 +271,13 @@
             event_filters: BTreeMap::new(),
             voices: BTreeMap::new(),
             permission_families: BTreeMap::new(),
-            selected_family_count: 0,
-            canonical_families: FamilyRegistry::default(),
             sends: selection.sends,
             skip: selection.skip.to_vec(),
             original_only: selection.original_only,
-            original_inputs: original_inputs::Cache::default(),
-        };
+        };
+        let reservation = u64::from(frames) * 3;
+        self.make_room(reservation, false, control)?;
+        self.active_frames += reservation;
         let result = (|| {
             let context = Contexts {
                 original: Context::Root,
@@ -275,9 +332,8 @@
         result
     }
 
-    fn release_shared_graph(&mut self, mut graph: Graph<'_>, reservation: u64) {
+    fn release_shared_graph(&mut self, graph: Graph<'_>, reservation: u64) {
         let graph_resident = graph.resident;
-        graph.original_inputs.clear(self);
         drop(graph);
         self.active_frames -= reservation + graph_resident;
     }
@@ -431,7 +487,8 @@
                     occurrence.voice.instance().clone(),
                 ))?;
                 if let Some(family) = &occurrence.permission_family {
-                    families.push((id, self.intern_permission_family(graph, family, control)?));
+                    control.spend_plan_work(family.comparison_work())?;
+                    families.push((id, family.clone()));
                 }
                 beat_routes.push((
                     id,
@@ -449,7 +506,7 @@
             if let Some(output) = program.output_voice {
                 selected.insert(output)?;
             }
-            families.extend(self.selected_split_families(graph, context, selected, control)?);
+            families.extend(graph.selected_split_families(context, selected, control)?);
         }
         let allowed_aliases = program
             .allowed
@@ -535,23 +592,42 @@
             let mut relative_depth = 0;
             if let Some(owners) = owners {
                 let raw = if let Some(request) = prepared_original.take() {
-                    self.shared_original_input_prepared(
-                        provider,
-                        graph,
+                    policy_prediction::validate_original(
+                        &request,
                         &program.context.original,
-                        (original_range.clone(), request),
+                        plan,
+                        original_range.start,
+                        count(&original_range)?,
                         control,
-                        program.depth,
-                    )?
+                    )?;
+                    self.read_prepared_original(provider, request, control, program.depth)?
                 } else {
-                    self.shared_original_input(
-                        provider,
-                        graph,
-                        &program.context.original,
-                        original_range.clone(),
-                        control,
-                        program.depth,
-                    )?
+                    match &program.context.original {
+                        Context::Root => self.read_controlled(
+                            provider,
+                            original_range.start,
+                            count(&original_range)?,
+                            control,
+                            true,
+                            program.depth,
+                        )?,
+                        Context::Domain(domain) => self.read_context_controlled(
+                            provider,
+                            domain,
+                            original_range.start,
+                            count(&original_range)?,
+                            control,
+                            (program.depth, true),
+                        )?,
+                        Context::Retained(input) => self.read_retained_controlled(
+                            provider,
+                            input,
+                            original_range.start,
+                            count(&original_range)?,
+                            control,
+                            (program.depth, false),
+                        )?,
+                    }
                 };
                 for (span, route) in owners.spans().iter().zip(original_routes) {
                     for sample in span.samples().start.0..span.samples().end.0 {
@@ -579,14 +655,7 @@
                     }
                 }
                 relative_depth = raw.relative_depth;
-                dependencies.extend(
-                    raw.dependencies
-                        .iter()
-                        .map(|(id, fingerprint)| (id.clone(), *fingerprint)),
-                );
-                // Later sound returns can need the same memory. The cache
-                // owns an evictable copy; do not pin it through those reads.
-                drop(raw);
+                dependencies.extend(raw.dependencies);
             }
             for ((root, id), route) in roots.into_iter().zip(root_ids).zip(root_routes) {
                 let event = root.voice.event();
