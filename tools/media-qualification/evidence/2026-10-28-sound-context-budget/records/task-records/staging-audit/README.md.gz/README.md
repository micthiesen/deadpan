# Task-only staging and overlay audit

Frozen staging proposal against HEAD 806e5a011ebe87ecd4fd6339daa6a2fa8dfef581.

- Patch: task-staging.patch
- SHA256: 67d8b8a628190a6d00893eca83f1876abd01466a93853a1cda9b1e42f25e898c
- 13 files, including five new files.
- Index-candidate bytes equal the actual scoped verification tree for all 13.
- git apply --check succeeded against standalone scratch copies of exact HEAD
  blobs. A scratch-only apply also succeeded; all output bytes equal the proposed
  index-candidate bytes.
- Main index SHA256/size are unchanged before/after preparation and validation.
  No main/scoped source was written. No Cargo/rustc ran during this audit.

The final parent lint correction is included in audio_sound_owner_context.rs:
AudioSampleGrid::new's identity map_err was removed, while ExactRatio::new's
needed TimeError-to-PlanError conversion remains. The actual original_context
function remains byte-identical to HEAD's fused capture implementation.

## The three index-candidate versus main differences

1. crates/deadpan-audio/src/shared_eq.rs retains HEAD's existing permission-family
   implementation and reservation/cache structure in the proposed index.
   Unrelated inherited FamilyRegistry/Original-input-cache WIP stays in main.
   New cleanup normalizes to drop Graph then release the saved total without
   the WIP-only original_inputs.clear(self) line or unnecessary mut Graph.
   The main variant correctly clears its actual Original cache before Graph drop.
2. crates/deadpan-audio/src/stages.rs retains HEAD's controller/cache fields and
   make_room eviction behavior in the proposed index. It adds only this task's
   sound-context module, request metadata counter and make_room lane.
3. crates/deadpan-audio/src/shared_eq/sound_admission_tests.rs omits only the
   three main-WIP initializer fields: selected_family_count, canonical_families,
   and original_inputs. Those fields remain in main's test initializer.

All other ten task files are byte-identical between proposed index, main and
scoped. Exact hashes appear in task-files.json. Complete text differences for
the three variants are retained in overlay-diffs/.

## Complete runner-input overlay accounting

The current runner lists name 1,434 main and 1,205 scoped inputs. Their sets
are not the same inventory: 1,092 paths overlap, 342 are main-list-only and
113 scoped-list-only. These are INPUT LIST differences, not an assertion that
a file is absent from a filesystem. Exact lists/hashes are in overlay-audit.json.

Among overlapping paths, 1,060 match and 32 differ. Three are the task variants
above. All 29 other common differences are inherited WIP: each scoped file was
verified byte-for-byte against its HEAD blob using a read-only Git archive.
None is included in this task patch. This includes existing sound clocks,
Core edits, other Audio fixtures and Plan permission-family/captured context
work. The archive and comparison hashes are retained as exact evidence.

## Evidence boundaries

This audit validates staging content and source identity, not new runtime
behavior. Parent reports final main Audio 292 / Plan 564, scoped Audio 273 /
Plan 551, enabled stages 203, and strict2 passed. Those outcomes belong to the
parent's retained receipts, not a run performed by this audit.

Parent also reports the current Split failure subphase as
Stage(Limit("plan work per read")) at Source/Sequence cut-three limited0+511.
Do not recast that failure as a memory pass for the full product or suppress
its exact changed subphase. All prior product/Split requirements remain open.

The real index is still parent-owned and was not modified here. The primary
can apply this patch to the index after its normal final review; do not copy
whole main files over the proposed task-only versions.
