from pathlib import Path
import difflib,json,hashlib,shutil,datetime
root=Path('/tmp/deadpan-sound-context-budget-2026-10-28');out=root/'staging-audit'
owned=[x['path'] for x in json.loads((root/'final-pins.json').read_text())['changed_files']]
main=out/'main-final';scoped=out/'scoped-final';head=out/'head';proposed=out/'index-candidate'
patch=[]
records=[]
for rel in owned:
 a=head/rel;b=scoped/rel;target=proposed/rel
 target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(b.read_bytes())
 old=a.read_text().splitlines(keepends=True) if a.exists() else []
 new=b.read_text().splitlines(keepends=True)
 patch.append(''.join(difflib.unified_diff(old,new,fromfile='a/'+rel if a.exists() else '/dev/null',tofile='b/'+rel)))
 records.append({'path':rel,'head_sha256':hashlib.sha256(a.read_bytes()).hexdigest() if a.exists() else None,
  'index_candidate_sha256':hashlib.sha256(b.read_bytes()).hexdigest(),
  'main_sha256':hashlib.sha256((main/rel).read_bytes()).hexdigest(),
  'differs_from_main':(main/rel).read_bytes()!=b.read_bytes(),
  'equals_scoped':True,'new':not a.exists()})
text=''.join(patch)
(out/'task-staging.patch').write_text(text)
# Apply verification uses a standalone scratch copy of exact HEAD blobs.
validation=out/'validation'
validation.mkdir(exist_ok=True)
for p in head.rglob('*.rs'):
 rel=p.relative_to(head);q=validation/rel;q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(p.read_bytes())
# Current final lint correction is included; unrelated ExactRatio conversion remains.
owner=(proposed/'crates/deadpan-plan/src/audio_sound_owner_context.rs').read_text()
ratio=owner[owner.index('        let step = ExactRatio::new('):owner.index('        let grid =')]
grid=owner[owner.index('        let grid ='):owner.index('        let samples =')]
assert '.map_err(PlanError::from)?' in ratio
assert '.map_err(PlanError::from)?' not in grid
# The fused Original capture helper is unchanged, even across admission integration.
rel='crates/deadpan-audio/src/shared_eq/node_description.rs'
def original(p):
 s=p.read_text();start=s.index("fn original_context<'plan>(");return s[start:s.index('\n#[cfg(test)]',start)]
assert original(proposed/rel)==original(head/rel)
(out/'task-files.json').write_text(json.dumps(records,indent=2)+'\n')
report={'prepared_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
 'head':'806e5a011ebe87ecd4fd6339daa6a2fa8dfef581','patch_sha256':hashlib.sha256(text.encode()).hexdigest(),
 'files':len(records),'new_files':sum(x['new'] for x in records),
 'differs_from_main':[x['path'] for x in records if x['differs_from_main']],
 'all_index_candidate_files_equal_scoped':True,
 'original_context_equals_HEAD':True,
 'grid_identity_map_err_removed':True,'exact_ratio_map_err_preserved':True}
(out/'staging-manifest.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
