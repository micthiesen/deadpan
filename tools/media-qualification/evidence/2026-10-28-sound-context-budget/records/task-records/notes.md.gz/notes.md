# Closed current-sound admission scratch candidate

This candidate is frozen for the primary agent's first compile. It has NOT
been built or run here: no Cargo/rustc, Git, live source edits, native/provider
probe or worktree operation. Scoped rustfmt parsing/checking is the only
executed source verification. Compilation and runtime results remain owed.

## Changes

Plan uses one actual admitted sound constructor/resolve_edges kernel. Legacy
entrypoints select the unmetered policy and preserve reported work. An opaque
carrier owns all intermediate Values before its charge. Exact typed capacity
requests cover chain, edges, Repeat buffers, policy/outer/fallback Arcs and
conservative actual-length owning identity Arc edges. Chain/edges drop before
their temporary reservations. The scalar/current-source grid/owner resolution
algorithm is unchanged; no ancestry dry run or native estimator is added.

The generic policy has associated Error: From<PlanError>, stable Copy+Eq issuer,
and independent RAII Lease. The concrete Audio issuer compares exact request
RefCell pointers. Every callback/transition and handoff validates issuer.
Partial buffers/Arcs live in paired guards across errors. Pure Plan arithmetic
explicitly converts through PlanError. Closed fallback clone exhaustively
matches every Domain/Seed field and checks closed shape in release builds.

Audio now admits this actual current-sound path through real make_room before
allocation. Live metadata has its own request lane in ReadWork/make_room.
Canonical performed work is forwarded once; returned receipts are not billed
twice. Native full preparation bounds, limits, weights, cache identities and
retry behavior are unchanged. Cache eviction is real and may remain after
a later error.

Numerical node_description preserves the captured fused original_context/
candidate/capture function exactly. Owning context clones precede the retained
carrier in Description. The callback handoff publishes values into a
pre-reserved Node slot, adds the same retained metadata units to active/Graph,
then disarms the request token. Node Vec growth remains explicitly outside this
admission claim. Both Graph cleanup exits now drop Graph before subtracting its
saved resident total; shared cleanup first clears its actual Original cache.

## Focused tests included

Seven Plan tests cover actual Root/Repeat/Preserve contexts, peak versus
one-short byte caps, final buffer/Arc-before-charge Drop observation, distinct
same-type issuer rejection with no further policy calls, post-shared failure/
cancellation, shape rejection before fallback reservation, legacy root receipt,
handoff mismatch, and an unstable policy issuer. Some behaviors share a test.

Six Audio tests cover real prepared-cache eviction/re-admission, real-WAV PCM
bits/dependencies/suppression/exhaustion/depth/source calls, exact request issuer
identity, nested native entry while metadata is outstanding, Graph publication/
filter take/cancelled tile cleanup, and prepublication budget/cancel refusal.

No runtime pass is claimed. In particular, this first compile may expose API,
borrow-check, lint or fixture issues. Main owns those checks.

## Exact scope and limitations

This does NOT admit Original Root/Domain/retained/Core binding transient
metadata, node containers, complete graph closure or recursive Cold histories.
No Cold or batching activation, fake provider planning, extra query cache or
budget reset/refund is introduced. Existing required rendered work may now
truthfully refuse if live current-sound metadata leaves insufficient headroom;
report that rather than lower bounds or raise caps.

Per-allocation ceil(bytes/8) can conservatively exceed ceil(total/8); merge
keeps the already admitted units and never refunds them. Owning identity Arcs
are deliberately counted at every retained edge, following the existing heap
visitor convention, although clones do not create new physical strings.

The exact Vec capacity policy relies on the pinned Rust 1.97.1 Global/RawVec
proof captured in the prior design scratch. No project unsafe or dependencies
are added.

## Main versus published validation copy

All candidate existing files originate from the captured current main text,
including inherited WIP. The final patch contains only this task's differences.
Do NOT restore older metadata/query bodies or stage any unrelated inherited
files. before-pins.json identifies the exact base bytes.

The captured main Graph has selected_family_count, canonical_families and
original_inputs, plus cache cleanup requiring mutable Self. A published
validation Graph without that inherited WIP needs published-adjustments.py
AFTER applying the main patch: it removes ONLY the new cleanup's cache line/
mutability and the three fields in the new test initializer. It does not
remove real fields from main or alter existing cache semantics.
The fused Root/Domain candidate APIs/current consumer are a prerequisite of the
captured node_description base; preserve the primary agent's qualified lineage.

## Required primary checks

Compile Plan/Audio tests and strict lint, run audio_sound_admission_tests,
sound_context_admission::tests and shared_eq::sound_admission_tests, existing
node-description/admission tests, then appropriate existing library/stage gates.
Actual allocation instrumentation is NOT newly added; issuer-before-policy
calls, exact enforced capacities, source-site reservation ordering and Drop
observers are the bounded tests here. Do not mistake logical payload bounds for
process RSS or allocator-internal overhead.
