from pathlib import Path
r=Path('/tmp/deadpan-sound-context-budget-2026-10-28/candidate/crates/deadpan-audio/src')
p=r/'stages.rs';s=p.read_text();s=s.replace('mod shared_eq;','mod shared_eq;\n#[path = "sound_context_admission.rs"]\nmod sound_context_admission;',1);s=s.replace('    projected_resident_frames: u64,','    projected_resident_frames: u64,\n    // Live current-sound metadata, including temporary constructor storage.\n    sound_context_frames: u64,',1);needle='                + control.work.borrow().projected_resident_frames\n                + additional';assert s.count(needle)==1;s=s.replace(needle,'                + control.work.borrow().projected_resident_frames\n                + control.work.borrow().sound_context_frames\n                + additional',1);p.write_text(s)
p=r/'shared_eq/node_description.rs';s=p.read_text()
i=s.index('pub(super) struct Description');e=s.index('/// No renderer',i)
s=s[:i]+'''pub(super) struct DescriptionValues<'plan> {
    pub(super) context: Contexts<'plan>,
    pub(super) boundary: AudioTreatmentBoundary<'plan>,
    pub(super) stop: Boundary,
    pub(super) kind: Temporal,
}

/// Owning context clones drop before the admitted carrier and its final lease.
pub(super) struct Description<'plan, I: Copy + Eq, L> {
    pub(super) values: Option<DescriptionValues<'plan>>,
    pub(super) sound: Option<deadpan_plan::AdmittedSoundContext<'plan, I, L>>,
}
impl<'plan, I: Copy + Eq, L> std::ops::Deref for Description<'plan, I, L> {
    type Target = DescriptionValues<'plan>;
    fn deref(&self) -> &Self::Target { self.values.as_ref().expect("unpublished description") }
}

#[cfg(test)]
pub(super) fn describe<'plan>(
    plan: &'plan RenderPlan, request: Request<'_, 'plan>, control: WorkControl<'_>,
) -> Result<Description<'plan, (), ()>, StageAudioError> {
    describe_admitted(plan, request, control, &mut sound_context_admission::Unmetered)
}

'''+s[e:]
s=s.replace('/// here. Query, spend, clone and error order is the inherited numerical body.','/// here. Root/Domain capture reuses its actual membership query; remaining\\n/// context-selection phases keep their checked numerical order.',1)
s=s.replace("pub(super) fn describe<'plan>(\n", "pub(super) fn describe_admitted<'plan, A>(\n",1 if False else 0) if False else s
# Only production function, not cfg(test) compatibility wrapper.
start=s.index('/// No renderer');tail=s[start:]
tail=tail.replace("pub(super) fn describe<'plan>(","pub(super) fn describe_admitted<'plan, A>(",1)
tail=tail.replace("    control: WorkControl<'_>,\n) -> Result<Description<'plan>, StageAudioError> {","    control: WorkControl<'_>,\n    admission: &mut A,\n) -> Result<Description<'plan, A::Issuer, A::Lease>, StageAudioError>\nwhere A: deadpan_plan::AudioSoundContextAdmission<Error = StageAudioError> {",1)
old='''    let sounds = if !original_only && owner.kind() == deadpan_plan::AudioOwnerKind::Node {
        let context =
            plan.audio_sound_instance_context(owner.instance(), control.query_limits()?)?;
        control.spend_plan_work(context.construction_work())?;
        Sounds::Owner(Arc::new(context))
    } else {
        Sounds::None
    };'''
new='''    let mut sound = None;
    let sounds = if !original_only && owner.kind() == deadpan_plan::AudioOwnerKind::Node {
        let context = plan.audio_sound_instance_context_admitted(
            owner.instance(), control.query_limits()?, admission)?;
        if !A::METERED {
            control.spend_plan_work(context.context().construction_work())?;
        }
        sound = Some(context.into_shared(admission)?);
        Sounds::Owner(Arc::clone(sound.as_ref().expect("created sound").shared()))
    } else {
        Sounds::None
    };'''
assert old in tail;tail=tail.replace(old,new,1)
old='''    } else if let Sounds::Owner(context) = &sounds {
        Context::Domain(Arc::new(context.processing_domain().clone()))
    } else {'''
new='''    } else if let Some(context) = sound.take() {
        sound = Some(context.with_processing_domain(admission)?);
        Context::Domain(Arc::clone(sound.as_ref().expect("created fallback")
            .processing_domain().expect("processing Domain")))
    } else {'''
assert old in tail;tail=tail.replace(old,new,1)
old='''    Ok(Description {
        context: Contexts { original, sounds },
        boundary,
        stop: Boundary {
            owner: key,
            before: stage,
        },
        kind,
    })'''
new='''    Ok(Description {
        values: Some(DescriptionValues {
            context: Contexts { original, sounds }, boundary,
            stop: Boundary { owner: key, before: stage }, kind,
        }),
        sound,
    })'''
assert old in tail;tail=tail.replace(old,new,1)
s=s[:start]+tail;p.write_text(s)
p=r/'shared_eq.rs';s=p.read_text()
old='''        graph.original_inputs.clear(self);
        self.active_frames -= reservation + graph.resident;'''
new='''        let graph_resident = graph.resident;
        graph.original_inputs.clear(self);
        drop(graph);
        self.active_frames -= reservation + graph_resident;'''
assert s.count(old)==1;s=s.replace(old,new,1)
start=s.index('        let node_description::Description {');e=s.index('        let resident = match kind {',start)
old=s[start:e]
request=old[old.index('            node_description::Request {'):old.index('            control,')]
new='''        let mut description = {
            let mut admission = sound_context_admission::Admission::new(self, control);
            node_description::describe_admitted(
                graph.plan,
'''+request+'''                control,
                &mut admission,
            )?
        };
        let metadata_frames = description.sound.as_ref()
            .and_then(|sound| sound.lease())
            .map_or(0, sound_context_admission::Lease::frames);
        let expected_issuer = sound_context_admission::issuer(control);
        if description.sound.as_ref().is_some_and(|sound| sound.issuer() != expected_issuer) {
            return Err(PlanError::AudioMetadataIssuerMismatch.into());
        }
'''
s=s[:start]+new+s[e:]
s=s.replace('''        let next_active = self
            .active_frames
            .checked_add(resident)''','''        let retained = resident.checked_add(metadata_frames).ok_or(StageAudioError::Range)?;
        let next_active = self
            .active_frames
            .checked_add(retained)''',1)
s=s.replace('''        let next_resident = graph
            .resident
            .checked_add(resident)''','''        let next_resident = graph
            .resident
            .checked_add(retained)''',1)
start=s.index('        graph.nodes.push(Node {',s.index('        let mut description ='))
e=s.index('        Ok(graph.nodes.len() - 1)',start)
new='''        // Reserve the existing Node Vec growth before the infallible handoff.
        // Its heap is outside this bounded current-sound admission slice.
        graph.nodes.reserve(1);
        let values = &mut description.values;
        let mut publish = |charge: Option<&mut sound_context_admission::Lease<'_>>| {
            let node_description::DescriptionValues { context, boundary, stop, kind } =
                values.take().expect("unpublished description");
            graph.nodes.push(Node {
                parent: program.parent, context, boundary, stop, filter, kind,
                tiles: BTreeMap::new(),
            });
            self.active_frames = next_active;
            graph.resident = next_resident;
            if let Some(charge) = charge { charge.commit(); }
        };
        if let Some(sound) = description.sound.as_mut() {
            sound.transfer_charge(expected_issuer, publish)?;
        } else {
            publish(None);
        }
'''
s=s[:start]+new+s[e:];p.write_text(s)
p=r/'authored_eq.rs';s=p.read_text();old='        self.active_frames -= reservation + graph.resident;';new='        let graph_resident = graph.resident;\n        drop(graph);\n        self.active_frames -= reservation + graph_resident;';assert s.count(old)==1;s=s.replace(old,new,1);p.write_text(s)
