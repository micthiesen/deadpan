from pathlib import Path
import gzip
import hashlib
import json

scratch = Path(__file__).resolve().parent
design = Path('/tmp/deadpan-sound-context-admission-2026-10-28')
repo = Path('/Users/michael/Code/deadpan')
dest = repo / 'tools/media-qualification/evidence/2026-10-28-sound-context-budget'
prior = repo / 'tools/media-qualification/evidence/2026-10-28-owner-input-capture/inventory.json'
prior_sha256 = '72edf14d01dfc710c10436f71c9b9a3dac52cd3fae8edcea563b20750fbbbcd4'
assert not dest.exists(), 'Archive only once all terminal receipts are present'
assert hashlib.sha256(prior.read_bytes()).hexdigest() == prior_sha256, 'Prior inventory reference changed'

# Archive only terminal, successful records from the final scoped verification.
terminal_receipts = [
    'sound-final-build.json',
    'sound-final-plan.json',
    'sound-final-audio.json',
    'sound-strict2.json',
    'sound-stages.json',
    'sound-scoped-build.json',
    'sound-scoped-audio.json',
    'sound-scoped-plan.json',
    'sound-definition.json',
    'sound-scoped-stages.json',
    'sound-scoped-birth.json',
]
for name in terminal_receipts:
    receipt = json.loads((scratch / name).read_text())
    assert 'exit_code' in receipt, f'{name} is not terminal'
    assert receipt['exit_code'] == 0, f'{name} did not pass'
    assert receipt.get('sources_unchanged') is True, f'{name} source pin changed'
    assert receipt.get('binaries_unchanged') is True, f'{name} binary pin changed'

split = json.loads((scratch / 'sound-split.json').read_text())
assert split['exit_code'] == 101 and split['sources_unchanged'] and split['binaries_unchanged']
assert '4 passed; 3 failed; 0 ignored' in (scratch / 'sound-split.stdout').read_text()

allowed = {'.rs', '.json', '.py', '.md', '.patch', '.stdout', '.stderr', '.txt'}
entries = []
sources = []
for path in sorted(scratch.rglob('*')):
    if path.is_file() and path.suffix in allowed and path.name != 'qualification-draft.md':
        sources.append(('task-records', path, path.relative_to(scratch)))

# Include only the task's declared source paths as copied from final pins.
final_pins = json.loads((scratch / 'final-pins.json').read_text())
for row in final_pins['changed_files']:
    path = repo / row['path']
    assert path.is_file(), str(path)
    sources.append(('current-source', path, Path(row['path'])))

# Preserve the bounded design and its pinned, verified Rust allocator references.
for path in sorted(design.rglob('*')):
    if path.is_file() and path.suffix in allowed:
        sources.append(('design-and-rust-references', path, path.relative_to(design)))

for group, path, relative in sources:
    data = path.read_bytes()
    if path.suffix == '.json':
        try:
            value = json.loads(data)
        except (json.JSONDecodeError, UnicodeDecodeError):
            value = None
        if isinstance(value, dict) and 'command' in value and 'started_at' in value:
            assert 'exit_code' in value, f'Nonterminal receipt: {path}'
            assert value.get('sources_unchanged') is True, f'Source pin mismatch: {path}'
            assert value.get('binaries_unchanged') is True, f'Binary pin mismatch: {path}'
    out = dest / 'records' / group / relative
    out = out.with_name(out.name + '.gz')
    out.parent.mkdir(parents=True, exist_ok=True)
    compressed = gzip.compress(data, mtime=0)
    out.write_bytes(compressed)
    entries.append({
        'path': str(out.relative_to(dest)),
        'bytes': len(compressed),
        'sha256': hashlib.sha256(compressed).hexdigest(),
        'expanded_bytes': len(data),
        'expanded_sha256': hashlib.sha256(data).hexdigest(),
    })

manifest = {
    'schema_version': 1,
    'base_revision': (scratch / 'base-revision.txt').read_text().strip(),
    'scope': 'Closed current-sound metadata admission only: actual AudioSoundOwnerContext construction, its two Arc wrappers, and its closed processing-Domain fallback. No Original/Core/retained input capture, node-container, complete Graph, recursive cold-history, or whole-graph admission claim. Current sound is reserved through real make_room, held by request-local RAII, and transferred to Graph active residency after checked handoff. Exact path/edge/repeat/context allocation sites and associated work are admitted. No caps, weights, cache identity, retries, refunds, or numerical output changes.',
    'final_correction': 'AudioSampleGrid::new uses its PlanError result directly; removed only the redundant identity map_err. ExactRatio errors still convert explicitly to PlanError.',
    'prior_owner_input_capture_inventory': {
        'path': '../2026-10-28-owner-input-capture/inventory.json',
        'inventory_sha256': prior_sha256,
    },
    'files': entries,
}
inventory = dest / 'inventory.json'
inventory.write_text(json.dumps(manifest, indent=2) + '\n')

stored = expanded = 0
for row in entries:
    packed = (dest / row['path']).read_bytes()
    plain = gzip.decompress(packed)
    assert len(packed) == row['bytes']
    assert hashlib.sha256(packed).hexdigest() == row['sha256']
    assert len(plain) == row['expanded_bytes']
    assert hashlib.sha256(plain).hexdigest() == row['expanded_sha256']
    stored += len(packed)
    expanded += len(plain)
print(json.dumps({
    'files': len(entries),
    'stored_bytes': stored,
    'expanded_bytes': expanded,
    'inventory_sha256': hashlib.sha256(inventory.read_bytes()).hexdigest(),
}))
