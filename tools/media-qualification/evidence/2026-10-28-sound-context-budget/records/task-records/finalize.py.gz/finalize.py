from pathlib import Path
import json,hashlib,difflib,subprocess,datetime
root=Path('/tmp/deadpan-sound-context-budget-2026-10-28')
base=root/'before';candidate=root/'candidate'
changed=[]
for path in sorted(candidate.rglob('*.rs')):
 rel=path.relative_to(candidate)
 old=base/rel
 if not old.exists() or old.read_bytes()!=path.read_bytes(): changed.append((rel,path,old))
subprocess.run(['rustfmt','--edition','2024','--config','skip_children=true','--check',*[str(p) for _,p,_ in changed]],check=True)
patches={'sound-context.patch':[],'production.patch':[],'tests.patch':[]}
files=[]
for rel,path,old in changed:
 data=path.read_bytes()
 text=data.decode().splitlines(keepends=True)
 prior=old.read_text().splitlines(keepends=True) if old.exists() else []
 patch=''.join(difflib.unified_diff(prior,text,fromfile='a/'+str(rel) if old.exists() else '/dev/null',tofile='b/'+str(rel)))
 patches['sound-context.patch'].append(patch)
 is_test='_tests.rs' in path.name
 patches['tests.patch' if is_test else 'production.patch'].append(patch)
 files.append({'path':str(rel),'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest(),'new':not old.exists()})
for name,parts in patches.items(): (root/name).write_text(''.join(parts))
rel=Path('crates/deadpan-audio/src/shared_eq/node_description.rs')
def original(path):
 text=path.read_text();start=text.index("fn original_context<'plan>(")
 return text[start:text.index('\n#[cfg(test)]',start)]
preserved=original(base/rel)==original(candidate/rel)
assert preserved
before=json.loads((root/'before-pins.json').read_text())
live=Path(before['repository'])
drift=[x['path'] for x in before['sources'] if hashlib.sha256((live/x['path']).read_bytes()).hexdigest()!=x['sha256']]
manifest={'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'frozen for primary first compile; rustfmt parse/check only',
 'changed_files':files,'patches':{n:hashlib.sha256((root/n).read_bytes()).hexdigest() for n in patches},
 'original_context_byte_preserved':preserved,'live_base_drift':drift,
 'notes_sha256':hashlib.sha256((root/'notes.md').read_bytes()).hexdigest(),
 'published_adjustments_sha256':hashlib.sha256((root/'published-adjustments.py').read_bytes()).hexdigest(),
 'tests_added':13,'builds_run_here':False}
(root/'final-pins.json').write_text(json.dumps(manifest,indent=2)+'\n')
(root/'candidate-sha256.txt').write_text(''.join(f"{f['sha256']}  {f['path']}\n" for f in files))
(root/'audit.md').write_text('''# Frozen audit\n\n- Scoped rustfmt parses/checks every changed/new Rust file.\n- The captured fused original_context function is byte-identical in the candidate.\n- Existing source snapshots and source hashes were not replaced.\n- All buffers/Arcs precede charge fields in the Build/carrier/Description guards.\n- No source-provider/native call exists in Plan admission.\n- Concrete reserve calls real make_room before counter/token/buffer publication.\n- Request issuer uses exact RefCell pointer equality; callbacks retain stable control.\n- Native bound and limits remain unchanged; metadata has a separate existing-limit lane.\n- Graph handoff follows all fallible steps; Node Vec capacity is reserved beforehand.\n- Graph drops before its saved active residency is released.\n- No budget/error-string fallback or Cold/batching activation.\n- No Cargo/rustc, Git, live writes, new dependencies, unsafe or worktree actions.\n\nThis is static audit evidence, not compilation or runtime verification. First compile,\nstrict lint and all 13 new tests plus inherited gates remain primary-owned. Candidate\nnotes list remaining coverage limitations and main/published adaptation explicitly.\n''')
print(json.dumps({'changed_files':len(files),'tests_added':13,'patch_sha256':manifest['patches']['sound-context.patch'],'original_context_byte_preserved':preserved,'live_base_drift':drift},indent=2))
