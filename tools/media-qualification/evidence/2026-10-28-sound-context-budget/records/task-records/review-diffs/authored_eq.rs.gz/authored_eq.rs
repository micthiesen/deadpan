--- a/crates/deadpan-audio/src/authored_eq.rs
+++ b/crates/deadpan-audio/src/authored_eq.rs
@@ -217,7 +217,9 @@
                 relative_depth,
             })
         })();
-        self.active_frames -= reservation + graph.resident;
+        let graph_resident = graph.resident;
+        drop(graph);
+        self.active_frames -= reservation + graph_resident;
         result
     }
 
