"""Apply ONLY after sound-context.patch to the published validation copy.
The captured main tree has three unrelated inherited Graph fields/cache lane.
"""
from pathlib import Path
import sys
root = Path(sys.argv[1])
p = root / 'crates/deadpan-audio/src/shared_eq.rs'
s = p.read_text()
old = "    fn release_shared_graph(&mut self, mut graph: Graph<'_>, reservation: u64) {"
new = "    fn release_shared_graph(&mut self, graph: Graph<'_>, reservation: u64) {"
assert s.count(old) == 1
s = s.replace(old, new, 1)
anchor = "        let graph_resident = graph.resident;\n        graph.original_inputs.clear(self);\n        drop(graph);"
assert s.count(anchor) == 1
s = s.replace(anchor, "        let graph_resident = graph.resident;\n        drop(graph);", 1)
p.write_text(s)
p = root / 'crates/deadpan-audio/src/shared_eq/sound_admission_tests.rs'
s = p.read_text()
for line in [
    "        selected_family_count: 0,\n",
    "        canonical_families: FamilyRegistry::default(),\n",
    "        original_inputs: original_inputs::Cache::default(),\n",
]:
    assert s.count(line) == 1, line
    s = s.replace(line, "", 1)
p.write_text(s)
