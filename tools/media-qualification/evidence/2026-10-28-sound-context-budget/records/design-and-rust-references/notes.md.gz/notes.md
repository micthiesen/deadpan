# Closed current-sound context admission

Design only, 2026-10-28. No live source changes, Cargo/rustc, Git, numerical
execution or native/provider probes. source-sha256.json pins nine relevant
repository files and four downloaded Rust 1.97.1 allocation sources.

## Preferred slice

Admit the actual current AudioSoundOwnerContext constructor, its two Arc
wrappers, and its specific processing-Domain fallback clone. Use one real
constructor parameterized by an admission policy, not a second counting walk.
Keep the shared node-description helper independent of StageAudio by passing
that policy to it. The Audio policy alone invokes real make_room and owns the
request resident ledger.

This closes only current-sound metadata. Original Root/Domain owner queries,
retained input capture/Core binding temporaries, other node metadata, and
recursive cold population remain separate. The ordinary numerical helper must
still support those forms. No complete graph/cold/history admission claim
follows from this slice.

## Concrete Plan boundary

Proposed names, with associated types doing real work:

    pub trait AudioSoundContextAdmission {
        type Error: From<PlanError>;
        type Issuer: Copy + Eq;
        type Lease;

        fn issuer(&self) -> Self::Issuer;
        fn spend(&mut self, work: usize) -> Result<(), Self::Error>;
        fn reserve(&mut self, layout: Layout)
            -> Result<Self::Lease, Self::Error>;
        fn merge(&mut self, first: &mut Self::Lease, second: &mut Self::Lease);
    }

    pub struct AdmittedSoundContext<'plan, I, L> {
        context: AudioSoundOwnerContext<'plan>,
        charge: IssuedCharge<I, L>,
    }

    RenderPlan::audio_sound_instance_context_admitted<A>(
        &self, instance: &InstancePath, limits: AudioQueryLimits,
        admission: &mut A,
    ) -> Result<
        AdmittedSoundContext<'_, A::Issuer, A::Lease>, A::Error
    >
    where A: AudioSoundContextAdmission;

Also expose context-specific consuming operations on this admitted carrier:

* into_shared(admission) first validates the carrier issuer, then reserves the
  outer Arc allocation before Arc::new. It returns another opaque paired
  carrier containing the actual Arc and its issued charge.
* clone_processing_domain_admitted(admission) borrows its specific closed
  policy Domain, validates issuer/shape, performs the two actual path copies,
  and reserves its Domain Arc. It returns an opaque paired Domain-Arc carrier.
  This is NOT a general arbitrary AudioDomain clone/bound API.

The value, charge and issuer stay private. No public into_parts or tuple
extraction exposes unrelated value/lease locals. Declare the owning value
before its charge so value destruction precedes counter release. The carrier
does not itself need another allocation.

That pairing applies THROUGH transition states, not just to the initial and
returned structs. Use a private fixed-size transition guard with all owning
values in its FIRST field and its issued charge slots in its LAST field.
It owns both old/new values while constructing the Arc or fallback. reserve,
shape/work checks, and merge all run while that guard owns every live value.
Merge charges through mutable references in their slots; do not consume lease
arguments into a callback whose unwind could drop them before the guard's
values. Only the final private synchronous Graph handoff may detach a value;
all checks are already complete and only infallible moves/ledger assignments
remain then. No fallible operation, allocation or user callback belongs after
that detachment.

The Lease contract must be documented: independently owned, allocation-free
Drop, releases exactly its reservation, and does not borrow the mutable
admission object. merge is infallible, non-unwinding and allocation-free for
validated same-issuer charges. It combines ownership in place, disarming the
source without decrementing any resident counter. It is not a budget refund.
No Vec of lease records is needed: use the fixed local chain/edge tokens and
one merged retained token.

Associated Lease/Issuer types cannot mechanically enforce honest third-party
Drop, identity or merge implementations. Document these public trait contracts;
the trusted concrete Audio adapter must satisfy them. Neither this generic
carrier nor an arbitrary user's admission policy is a source/security
certificate.

The existing bare Plan entrypoint remains a compatibility wrapper selecting
an internal unmetered policy. The same actual structural/copy kernel serves
both paths. Existing public AudioSoundOwnerContext remains usable by its
existing APIs. The bare wrapper is never accepted as an admission certificate.
The admitted API immediately has the real numerical callsite below; do not
land an uncalled public framework.

## Issuer identity is checked, not inferred from the Rust type

Every issued charge contains the captured issuer plus its lease. Its private
construction records admission.issuer() before reserve; the actual policy's
identity is stable for the policy lifetime. Check stability after callbacks
before publishing the returned carrier as well. The build/transition guard
captures its issuer once and validates it before each later admission call;
an equal lease type is never substituted for that check.

At the START of into_shared or clone_processing_domain_admitted, compare the
stored issuer with admission.issuer(). On mismatch return a NEW typed unit
PlanError::AudioMetadataIssuerMismatch, converted through A::Error. This
comparison occurs before work debits, shape/layout inspection, reservations,
allocations or merges. Equal associated types/lifetimes do not prove equality.

Before merging any two charges, check BOTH stored issuers against each other
and the current admission issuer. Before numerical handoff, check the
description issuer against the exact destination WorkControl ledger identity.
All these checks precede any ledger mutation; the handoff's issuer check
precedes native admission too. Do not match an error display string.

For Audio, Issuer is an opaque private Copy wrapper around the exact borrowed
WorkControl.work RefCell address. Implement Eq using std::ptr::eq on those
ledger addresses, NOT derived RefCell/content equality. The wrapper's field
and constructor remain private. SoundMetadataLease also records that identity
and borrows the actual ledger for its work lifetime. The adapter's control
cannot be replaced after construction, making its identity stable; copies of
that WorkControl name the same issuer. Different ledgers with identical
counters are different issuers. No unsafe dereference, content hash,
owner/Plan ID or cache key participates.

The borrowed ledger is stable while these references/leases exist. Identity
must not persist past that scope. The existing one-request private Graph
ownership rule remains required: its handoff uses the control captured by
that numerical read, not an arbitrary later control of the same type.

## Associated Error works, with explicit conversions

This permits the Audio implementation to set Error = StageAudioError; its
reserve can return the actual cache/residency/cancellation error unchanged.
Plan only requires From<PlanError> and never imports deadpan-audio.

It does NOT make question-mark transitive. ExactRatio/grid methods returning
TimeError must first map through PlanError::from. The resulting PlanError can
then convert to A::Error. Existing Placement::compose/range already return
PlanError. Layout overflow should become a specific PlanError variant/payload
at its typed site, then convert once. Do not add message-string matching,
convert every error into an eligibility result, or introduce a numerical retry.

The implementation needs a generic internal Build context owning the existing
BuildBudget plus the admission reference. Its spend method first enforces
the existing local maximum_work, then forwards admitted performed work before
the inspected operation. resolve_edges is shared with other Plan callers:
factor its ACTUAL body behind this small context, leaving the old resolve_edges
entrypoint as the unmetered compatibility adapter. Do not call it twice.

Legacy wrappers preserve their existing reported construction_work. Additional
resource inspections occur only on the admitted branch and are charged to its
same local query limit and canonical request budget. An unmetered wrapper
does not run an extra heap scan merely to throw the result away.

## Exact capacity policy, supported by the pinned implementation

Do not use implicit Vec growth, derived Vec::clone, slice.to_vec, or a generic
Clone implementation whose nested allocation is unknown in this admitted path.

1. Chain: allocate a Vec<usize> once with capacity C. Choose C = 1 when host
   is root, otherwise MAX_DOCUMENT_DEPTH + 1. Check Layout::array first and
   reserve before Vec::with_capacity(C). Existing depth validation still
   rejects before a push could exceed C. This trades at most the documented
   bounded chain capacity for avoiding every realloc and movement allowance.
2. Edges: once the actual chain exists, allocate exactly e = chain.len()-1
   Edge slots. Reserve Layout::array::<Edge>(e) first. The one actual edge
   loop pushes exactly e times and cannot grow. Edge owns no nested heap.
3. Repeat copies: a specialized exact path-copy helper reserves
   Layout::array::<RepeatInstance>(n), creates Vec::with_capacity(n), and
   clones exactly n known RepeatInstance values with checked non-growing
   pushes. RepeatInstance contains NodeId and IterationId; IterationId owns
   RevisionId plus ordinal. Their identity clones are Arc increments, not
   hidden new vectors or strings. Keep this helper specialized, not T: Clone.
4. Arc layouts: reuse the existing checked two-usize-counter + aligned payload
   + tail-padding calculation, also supported by pinned ArcInner. Reserve
   before Arc::new. Layout overflow returns through the typed Plan error.
5. All zero-length payloads use no allocation and a zero reservation; do not
   confuse Vec's zero-size-type conventions with these concrete non-ZST types.

Why exact capacity is credible here: this repository pins Rust 1.97.1.
The captured RawVec::try_allocate_in stores the requested capacity, and
captured Global::alloc_impl_runtime returns the requested byte length.
Global's own comment states that allocate/grow/shrink return no larger logical
allocation. Vec::with_capacity selects Global. Therefore these explicit
allocations have capacity n on this pin, even when a GlobalAlloc implementation
internally rounds its physical allocation. No project unsafe code or allocator
replacement is required. This is logical payload admission, consistent with
existing Vec-capacity/native bounds; it is not a bound on malloc bookkeeping
or process RSS.

Retain assertions/tests for capacity == n. They are regression sentinels,
not permission to allocate an unknown excess and admit it afterward.
The proof must be rechecked when changing toolchain/allocation representation.
The general public Vec docs permit excess capacity, so do not claim this as
a version-independent generic Vec guarantee.

Primary evidence: [Rust 1.97.1 RawVec](https://raw.githubusercontent.com/rust-lang/rust/1.97.1/library/alloc/src/raw_vec/mod.rs),
[Global](https://raw.githubusercontent.com/rust-lang/rust/1.97.1/library/alloc/src/alloc.rs),
[Vec](https://raw.githubusercontent.com/rust-lang/rust/1.97.1/library/alloc/src/vec/mod.rs),
and [Arc](https://raw.githubusercontent.com/rust-lang/rust/1.97.1/library/alloc/src/sync.rs).
Local captured bytes/hashes are the precise evidence for this proposal.

## Lifetime and exact phase recipe

Use the existing parent-resolution loop once. Construct edges while chain is
live, then explicitly drop chain BEFORE releasing its token. After the existing
edge-map loop has copied processing node/map/repeat-count scalars, explicitly
drop edges BEFORE releasing its token and before allocating retained copies.
No later operation borrows Edge or chain. These drops narrow the real live set;
they do not refund work or redo ancestry.

Let:

* U(C) = Layout::array::<usize>(C).size().
* E(e) = Layout::array::<Edge>(e).size().
* V(n) = Layout::array::<RepeatInstance>(n).size().
* AD = padded Arc allocation layout for AudioDomain.
* AS = padded Arc allocation layout for AudioSoundOwnerContext.
* R = input instance repeats; P = selected processing prefix repeats, P <= R.

The final SOUND allocation payload, including its actual outer Arc, is:

    S = V(R) + 3*V(P) + AD + AS

The three P copies are processing_instance.repeats, policy.seed.repeats,
and policy.instance.repeats. Owner contributes R. The policy's other vectors
are empty. The final Domain fallback adds:

    F = 2*V(P) + AD

Its two P copies are the policy seed path and Domain instance path.
Both the sound context and fallback Domain remain charged afterward.
Do not reuse an owner-ID-equal Domain or add a Domain cache.

The specialized fallback MUST validate its constructed closed shape before
reserving or cloning anything for the fallback: empty constraints/editorial/
retimes; no gap/definition/envelope/bypass-binding/placement; and the expected
processing-instance path in both the seed and Domain instance. Check remaining
scalar/context relationships as constructed, without treating them as a new
ancestry proof. Shape inspection is real billed work.

Use exhaustive field destructuring without a rest pattern in specialized
AudioDomain/AudioWalkSeed clone/accounting code. A new field must fail
compilation until its heap and clone behavior is explicitly handled. A later
populated field must either be fully admitted/copied or cause typed
PlanError::AudioSoundContextShapeChanged BEFORE fallback allocation.
Do not rely on debug assertions or silently call derived AudioDomain::clone.
This shape error is structural failure, not a cold eligibility shortcut.

With explicit early temporary drops, construction allocation peaks are:

    sound only:       max(U(C)+E(e), S)
    with fallback:    max(U(C)+E(e), S+F)

Without those explicit drops, retain the larger edges-plus-S overlap from
the old lexical scopes. These formulas are typed layouts of real allocated
storage, not guessed multipliers. AS is allocated only after the bare sound
constructor returns, so edges/chain are already gone.

### Existing identity allocations

Arc identity clones allocate no new text, but an admitted returned handle
must not rely on a caller continuing to own the input InstancePath.
For a self-contained conservative retained charge, include owning identity
Arc layouts just as the existing heap visitor does.

Let J(path) sum Arc layouts for the node and allocation identity strings in
each RepeatInstance, using ACTUAL string lengths; N(id) is the actual NodeId
text Arc layout. Then add to S:

    J(input repeats) + 3*J(processing prefix)
    + N(input owner node) + 2*N(processing node)

Add to F:

    2*J(processing prefix) + N(processing node)

Admit these owning edges in the SAME actual clone loop, before cloning the
corresponding Arc handles. Reading string length and constructing its Layout
are real inspections to bill; no second ancestry/counting traversal is needed.
Some physical identity allocations are shared with the pinned Plan and may
be counted repeatedly. That conservative upper bound matches existing
OwnedHeap policy and is explicit, rather than claiming cloned text is newly
allocated. If the project later chooses to credit independently pinned identity
storage, that needs a separate ownership proof and is not this slice.

When adding identity edges, the peak recipe uses the admitted retained edge
sum at the phase in which each clone is created. The simple S/F formulas above
plus their identity sums remain conservative peak bounds.

## Audio adapter and real cache eviction

An Audio-only adapter can have:

    struct SoundAdmission<'controller, 'work> {
        controller: &'controller mut StageAudio,
        control: WorkControl<'work>,
    }

    type Error = StageAudioError;
    type Issuer = SoundLedgerIdentity<'work>;
    type Lease = SoundMetadataLease<'work>;

Each reservation checks layout size and converts bytes upward to the existing
stereo-f32 frame units with checked arithmetic. Per-allocation upward rounding
is conservative; merge adds those already admitted units and releases none.
Before allocation, call controller.make_room(delta, false, control), allowing
it to evict its ACTUAL Original/PCM caches. Then increment a request-owned
metadata-resident counter which make_room also includes. Do not hold a
RefCell borrow across make_room or any Plan callback. Perform all checked sums
before publishing the new counter/lease.

The lease holds only the request ledger reference/issuer, amount and armed state.
It does not retain &mut StageAudio or the adapter. Thus the next reservation
can call make_room, and subsequent numerical work can borrow the controller.
The single request ledger already uses RefCell; no self-reference, unsafe,
Plan-to-Audio dependency, provider call or fake StageAudio is introduced.

Use a distinct metadata counter/field rather than changing the meaning of
projected_resident_frames. Include it in the EXISTING make_room sum. The
limit and eviction order remain unchanged. Cache eviction may remain visible
after later construction failure; no attempt to roll it back is required.

Drop buffers/owning values before dropping their leases. A separate Temporary
or Retained class is unnecessary for make_room: both are live reservations.
Scope ownership determines when each ends. The adapter's spend forwards the
actual canonical work and checks the same cancellation/deadline. It does not
use cache_key_scope or manufacture a separate work allowance.

## Shared numerical callsite and publication

Change the existing node_description::describe helper to be generic over this
admission parameter, with Error = StageAudioError at the Audio boundary. It
still receives actual Plan/request/control and owns no controller/Graph.
Its current-sound branch calls the admitted real constructor and into_shared.
Its existing sound fallback uses the admitted specific Domain clone.
Description keeps owning values first and the merged issued sound/fallback
charge last, including the issuer for transition and handoff validation.
Other context-selection semantics and errors are preserved.

The numerical caller creates SoundAdmission around its controller and passes
it into describe, then drops the adapter borrow. The returned lease keeps the
sound metadata charged while Original metadata, native EQ and later work run.
This prevents a required native reservation from ignoring metadata already live.
Every carrier transition validates its issuer as above. The numerical caller
validates against its captured control before native admission and again
before committing the charge.

For minimum disruption to current Graph lifetimes, transfer the retained lease
into existing active_frames + Graph.resident on SUCCESSFUL node publication:

1. Validate issuer and compute every prospective active/Graph addition with
   checked arithmetic, including native/sound metadata. Keep the paired
   description guard and request charge armed.
2. Complete native construction, cancellation check, and every fallible
   boundary step. Existing native admission sees the request metadata charge.
3. In the PRIVATE synchronous handoff only, move owning values into the Graph
   node first. Add the SAME retained sound units to active_frames/Graph.resident,
   subtract them from request metadata and disarm the request lease. No
   allocation, callback, fallible Result step or possible unwind belongs between
   value detachment/publication and ledger transfer. Generic merge work is
   already complete while the values remain paired in their guard.
4. Both normal and error exits use the stricter cleanup below. Private Graph
   contexts and their clones must not escape that cleanup lifetime.

### Graph cleanup drops owning values before releasing their total

Current numerical exits clear graph.original_inputs with Self, subtract
reservation + graph.resident from active_frames, and let Graph drop at return.
There the function holds exclusive &mut Self and performs no intervening
admission/allocation between subtraction and drop. That explains why another
renderer allocation cannot use the short gap in the present code. It still
fails the stronger lifetime statement for the new metadata charge and must
not be copied into the new contract.

Use this order at BOTH relevant Graph cleanup exits:

    let graph_resident = graph.resident;
    graph.original_inputs.clear(self);
    drop(graph);
    self.active_frames -= reservation + graph_resident;
    result

Save the same charged total once. Clear Original cache first because it needs
mutable Self and may update its separate cache accounting. Drop Graph next,
including nodes, context/domain Arcs, native filters and other graph-owned
values. ONLY THEN release its saved active total. No extra query, admission,
work debit/reset, callback or allocation is added between drop and subtraction.
This changes order, not the amount or number of releases. It is not a work
refund or a second cleanup.

Before publication, error cleanup drops the paired description/transition
values before its request charge, and Graph receives none of that charge.
After a completed handoff, the disarmed request token releases nothing, and
the ordered Graph cleanup releases once. Cancellation follows whichever side
of that publication boundary it reached.

A standalone cold descriptor instead keeps its lease; its lifetime is tied
to WorkControl's ledger by the associated Lease type. It cannot outlive that
request without moving to a separately owned accounted ledger. Do not promote
an admission token to a persistable certificate or detach its Arcs.

This handoff relies on the existing private no-escape Graph ownership rule.
If that rule cannot be demonstrated, keep the lease embedded with the owner
and add the necessary work lifetime to Graph instead. Do not release early
just to avoid a lifetime parameter.

Node Vec growth and Original metadata are NOT admitted by this sound slice.
Their existing behavior may remain in the numerical path, but Cold must still
decline closure. Successful sound admission alone is not authority to allocate
additional cold histories.

## Error and work contract

All failures propagate their actual typed A::Error. A denied reservation has
not yet allocated the denied buffer. Previously constructed values and their
independent tokens unwind in ordinary scope order. Admission errors must not
be converted by error message into Unsupported, retried, or used to reset
any preparation/query counter.

Admitted success bills the real existing parent/edge/map inspections once,
plus NEW resource inspections/copy loops which actually execute. The Plan
result's construction_work remains a receipt; Audio must NOT spend it again
after its admission policy already billed the same work incrementally.
Legacy compatibility callers continue their existing aggregate work behavior.
Tests must explicitly catch double billing and lost work on error.

Every error from pure arithmetic is mapped into PlanError then A::Error.
Source authority is unchanged: there is no provider in this construction path.
Allocator OOM/abort is outside the existing fallible budget contract, just as
for current Vec/Arc allocations; this design does not claim to catch process
OOM after successful budget admission.

## Small implementation contract and checks

Bounded implementation scope:

* Plan sound-owner-context constructor and its tiny admission/carrier types.
* Actual resolve_edges kernel plus compatibility adapter, exact non-growing
  chain/edge/path-copy helpers, and explicit temporary drops.
* Context-specific outer Arc/fallback Domain operations, not general Domains.
* Audio SoundAdmission/lease, one request metadata counter in make_room, generic
  node-description parameter, and publication handoff.

Meaningful required evidence:

1. Real pure-Plan legacy/admitted contexts have equal samples, owner, processing
   Domain behavior and construction semantics, for root, nested Repeat,
   Preserve, hidden support and malformed full paths. No fake constructor.
2. Reservation log follows actual phases and exact layouts. One-short failure
   at chain, edges, each Repeat copy, each Arc and fallback refuses BEFORE the
   allocating operation; all prior leases release. Exact required headroom
   succeeds with the same request. Verify all capacities and zero-size cases.
3. A real StageAudio cache-pressure test proves reserve calls evict existing
   cache entries before allocation. Also prove a genuinely exhausted cap
   returns the actual residency error without new buffers, retries or refunds.
4. Force arithmetic/work/cancel failures after earlier allocations. Counters
   stay spent; metadata returns to entry on error, and commits exactly once
   to Graph on success. A temporary filter take does not change retained
   metadata charge.
5. Numerical PCM/suppression/dependency/depth tests use the SAME shared helper.
   Normal source re-admission behavior remains unchanged. Record genuine new
   small-cap refusals without increasing caps or hiding them.
6. Create two admissions of the SAME Rust type backed by distinct RefCells
   containing equal counters. Build the real carrier under A, then call
   into_shared with B. Expect typed AudioMetadataIssuerMismatch BEFORE any
   reserve/allocation/merge/spend call on B. The consumed A carrier drops its
   real value before its charge and both metadata counters end at zero.
   Performed A work remains spent. For borrowed clone_processing_domain with
   B, require no fallback allocation and unchanged entry counters/work;
   explicitly dropping A afterward leaves both metadata counters zero.
   A copy of A's actual WorkControl must pass the same-issuer transition.
7. Exercise merge and handoff mismatch with two issued carriers. Neither ledger
   is mutated by a rejected merge/handoff. Their values stay paired through
   error unwinding and release only their own issuer's amounts. A test policy
   whose issuer changes is rejected at the next boundary, not silently merged.
8. Instrument the real transition guards/Graph publication boundary with a
   test lease observer and owning-value drop sentinels. Assert EVERY value
   drop precedes counter release on ordinary return, denied later reservation,
   structural/work error and cancellation. Include failure after the input
   value moves into the output Arc but before final return, so initial/final
   struct order alone cannot make a broken intermediate transition pass.
   For actual context Arcs, a weak payload observation can complement the
   sentinels; drop the test's Weak itself before releasing the counter it
   would otherwise keep allocated. Do not infer Vec release from counters alone.
9. Test the strict top-level sequence with a Graph owning a successfully handed
   off real context: Original-cache clearing, Graph/context/native drops, THEN
   the same saved active total subtraction. Cover successful read, read error,
   cancellation before publication and cancellation after a completed handoff.
   No double release, extra work charge, source retry or counter reset is allowed.
   A temporarily taken filter leaves the metadata charge unchanged.
10. Mutate each closed-shape condition in a Plan-private fixture. The fallback
    returns typed AudioSoundContextShapeChanged before any fallback reserve
    or allocation. Exhaustive no-rest destructuring is also reviewed so new
    Seed fields cannot silently bypass admission.

## Independent review response

This revision explicitly addresses independent-review.md:

* Required lifecycle correction: save Graph's total, clear its Original cache
  using Self, drop Graph, then subtract that same total. Both cleanup exits use
  the order. The previous exclusive-Self/no-intervening-admission nuance is
  documented above, not used to waive strict value-before-charge destruction.
* Issuer hole: stable Copy + Eq associated identity, opaque actual Audio
  RefCell pointer identity, issuer stored in each carrier/charge, and typed
  checks before later reserve/allocation/merge/native admission/handoff.
* Carrier invariant: opaque paired structs persist through fixed transition
  guards; mutable in-place merge does not move lease ownership into callbacks.
  Public tuple extraction is forbidden; only private synchronous publication
  can detach after all fallible work.
* Fallback invariant: explicit release-build shape checks and exhaustive field
  accounting, with a typed failure or full admission for later populated fields.
* Tests: same-type/different-ledger refusal before calls, both zero-on-drop
  counters, actual owning-value drop order, mismatch/cancel/error handoff and
  closed-shape mutation cases are now part of the implementation contract.

At revision verification, live node_description.rs had changed since the
original source snapshot: main's original_context helper reuses its checked
Root/Domain membership query for capture. The current-sound construction
branch and Domain fallback targeted here are unchanged. Preserve that live
Original work when implementing; do not restore the earlier captured body.
The original pins stay intact, and design-check.json records this one drift.

No checks above have been run. This contract is deliberately bounded and does
not complete Original/retained/Core transient proof, recursive native/history
admission, or product/Split acceptance.
