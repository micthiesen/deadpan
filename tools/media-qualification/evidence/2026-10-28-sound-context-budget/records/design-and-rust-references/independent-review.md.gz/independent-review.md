# Independent design review: current sound-context admission

Scope: design in `notes.md`, its nine source hashes, and the captured Rust 1.97.1 allocation evidence. No live changes or build/toolchain run.

## Verdict

The current-sound slice is implementable as a bounded numerical admission step. The allocation-site inventory and proposed split correctly stop short of claiming Root/Domain Original query, retained/Core temporary, node-vector, or recursive-cold admission. I found one concrete lifecycle correction to carry into implementation, plus two invariants that should be enforced explicitly.

## Required lifetime correction

At the current top-level numerical read exits, the code clears `graph.original_inputs`, subtracts `reservation + graph.resident` from `active_frames`, and only then lets the local `Graph` drop at function return. A future sound context/domain Arc retained by a Graph node would still be alive after the counter is released. Change both relevant cleanup paths to capture the resident total, drop the Graph and its owning contexts, then release the same active-frame total. Preserve `original_inputs.clear(self)` before dropping the Graph if it requires the mutable renderer. This closes the explicit counter-before-value-drop gap and makes the requested lease-drop order true at graph lifetime end.

## Invariants to hold in the implementation

1. Keep the admitted carrier opaque: its context value must not be extractable independently of its lease. Consuming methods should return a paired value-plus-lease carrier. For the numerical handoff, move the Graph-owned values first, add the same units to the Graph/active ledger, then disarm/subtract the request lease with no fallible work between those operations. The Plan trait’s associated `Lease` cannot mechanically guarantee third-party implementations obey independent/allocation-free Drop or merge provenance; document and constrain the public contract, and do not present the carrier as a security certificate.
2. The specialized fallback clone is safe only while the sound context’s `AudioDomain` keeps its constructed closed shape: `constraints`, `editorial`, `retimes`, and `gap` are empty, with only the two Repeat path vectors carrying heap payload. Assert that shape or extend the admitted clone to reserve/copy any later populated fields. Do not silently reuse derived `AudioDomain::clone`.

## Remaining review points resolved by the proposal

- Chain capacity `MAX_DOCUMENT_DEPTH + 1` matches the existing check-before-parent-push behavior; `chain.len()-1` is the exact edge count. Exact non-growing pushes keep both buffers within their reservations. Repeat payload counts R for the owner, three P prefix vectors for the sound context, and two P vectors for the fallback Domain.
- The pinned Rust 1.97.1 allocator evidence supports requested logical Vec capacity and the typed Arc layout calculation for this toolchain. This is not a version-independent Vec guarantee or process-RSS bound. Keep the capacity assertions and recheck the proof when upgrading.
- Identity-handle accounting is deliberately conservative even though Arc clones do not allocate new text. The separate string/Arc edges avoid claiming text copies; each path clone still needs its vector payload reservation.
- The local BuildBudget and `Audio` admission policy must both see each performed structural/copy inspection exactly once. Legacy wrappers should keep the existing work receipt and must not run the new layout/identity scan. The admitted Audio caller must not spend the returned receipt again. On refusal/error, retain work already spent, let values drop before their leases, and propagate the typed error.
- `reserve` must do checked layout-to-frame conversion, call real `make_room` with prior live metadata already included, and only then increment the metadata ledger. No RefCell borrow may span `make_room` or a Plan operation. Cancellation/deadline and native EQ admission must observe live sound metadata. Evicted caches may stay evicted after a later failure.
- Existing source/Original metadata and Graph-node-vector growth remain outside this slice. On failure, all admitted current-sound allocations unwind; on success, the lease transfers to the exact Graph node lifetime and is released once after that Graph drops.

No recursive/native proof, complete Root/Domain/Core proof, cold closure, or batching follows from this slice. The separate Root/Domain candidate remains independent.

## Additional ownership issue: lease issuer identity

The proposed carrier is `AdmittedSoundContext<'plan, L>` and its later `into_shared(admission)` / domain-clone operation accepts an admission again. `L` is only the associated type; equal Rust types and lifetimes do not prove that both reservations use the same `SoundAdmission` instance or `ReadWork` ledger. A second admission of the same type can point at a different `WorkControl` ledger. Then `merge` can combine unrelated lease amounts, a drop can decrement the wrong counter, and `make_room` only sees the current control's metadata total. This is a real admission-accounting hole in the public generic API, not malformed Plan input.

Before implementation, carry an issuer identity in the admitted carrier/leases and validate it on every subsequent reservation/merge/handoff, returning a typed mismatch error, or redesign the API so later operations cannot choose a second issuer. For the concrete Audio implementation, the identity can be the exact request ledger pointer/token. Do not rely on `A::Lease` having the same type or on a doc-only same-instance precondition. Keeping the actual StageAudio adapter borrow in the carrier would enforce identity but may block the later native/Original work; if so, split out an unforgeable ledger-scope token and have the adapter validate it without holding `&mut StageAudio` across the description lifetime.

Keep each owning value paired with its lease in a carrier through every intermediate method. Rust struct field order can make the value drop before its lease, but destructuring into unrelated locals weakens that guarantee; avoid a public `(value, lease)` extraction except at the private, synchronous Audio handoff where ownership and ledger transfer are controlled.
