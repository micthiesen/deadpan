from pathlib import Path
import gzip,json,hashlib
s=Path(__file__).resolve().parent
dest=Path('/Users/michael/Code/deadpan/tools/media-qualification/evidence/2026-10-27-sound-binding-reuse')
assert not dest.exists()
dest.mkdir(parents=True)
files=[]
extensions={'.json','.stdout','.stderr','.py','.patch','.rs','.txt','.tar'}
for p in sorted(s.rglob('*')):
 if not p.is_file() or p.suffix not in extensions:continue
 rel=p.relative_to(s)
 data=p.read_bytes()
 compressed=gzip.compress(data,mtime=0)
 out=dest/'records'/Path(str(rel)+'.gz')
 out.parent.mkdir(parents=True,exist_ok=True);out.write_bytes(compressed)
 files.append(dict(path=str(out.relative_to(dest)),bytes=len(compressed),sha256=hashlib.sha256(compressed).hexdigest(),expanded_bytes=len(data),expanded_sha256=hashlib.sha256(data).hexdigest()))
inventory=dict(schema_version=1,base_revision='233f6d23',scope='Independent five-file historical sound binding optimization: exact shared immutable layout admission and checked after-birth binding reuse. Current and isolated qualification, original two WIP test failures and baseline admission witness retained. General Split WIP stays uncommitted; no requirement or gate acceptance credit. Exact scoped patch, full candidate reconstruction, commands, source/binary hashes and independent review retained. Executables local only.',files=files)
out=dest/'inventory.json';out.write_text(json.dumps(inventory,indent=2)+'\n')
for row in files:
 data=(dest/row['path']).read_bytes();expanded=gzip.decompress(data)
 assert len(data)==row['bytes'] and hashlib.sha256(data).hexdigest()==row['sha256']
 assert len(expanded)==row['expanded_bytes'] and hashlib.sha256(expanded).hexdigest()==row['expanded_sha256']
print(json.dumps(dict(payloads=len(files),stored_bytes=sum(r['bytes'] for r in files),expanded_bytes=sum(r['expanded_bytes'] for r in files),inventory_sha256=hashlib.sha256(out.read_bytes()).hexdigest()),indent=2))
