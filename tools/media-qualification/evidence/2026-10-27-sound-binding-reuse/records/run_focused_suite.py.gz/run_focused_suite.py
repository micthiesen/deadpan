from pathlib import Path
import json,sys,shutil,subprocess,hashlib
s=Path(__file__).resolve().parent
bins={}
for line in (s/'focused-build.stdout').read_text().splitlines():
 try:r=json.loads(line)
 except ValueError:continue
 if r.get('reason')=='compiler-artifact' and r.get('executable') and r.get('profile',{}).get('test'):
  name=r['target']['name']
  p=s/(name.replace('_','-')+'-first')
  shutil.copy2(r['executable'],p)
  bins[name]=str(p)
(s/'binary-pins.json').write_text(json.dumps({name:dict(path=p,sha256=hashlib.sha256(Path(p).read_bytes()).hexdigest()) for name,p in bins.items()},indent=2)+'\n')
for name,label,args in [
 ('deadpan_audio','audio-library-first',['--nocapture']),
 ('audio_definition','audio-definition-first',['--nocapture','--test-threads=1']),
 ('stages','selected-play-first',['general_split_sound::one_explicit_play_split_keeps_both_selected_and_other_plays_in_the_shared_sound_bus','--exact','--nocapture','--test-threads=1']),
]:
 binary=bins[name]
 code=subprocess.call([sys.executable,str(s/'run.py'),'--binary',binary,label,'--',binary,*args])
 if code:raise SystemExit(code)
