from pathlib import Path
import shutil,json,difflib,hashlib
s=Path(__file__).resolve().parent
root=Path('/Users/michael/Code/deadpan')
isolated=Path('/tmp/deadpan-query-groundwork-2026-10-26/scoped')
files=['crates/deadpan-plan/src/audio_sound_processing_history.rs','crates/deadpan-audio/src/beat_sounds.rs','crates/deadpan-audio/tests/audio_definition/sound_clocks/new_group_birth_authority.rs']
before={}
desired={}
for rel in files:
 before[rel]=(isolated/rel).read_text()
 desired[rel]=(root/rel).read_text()
rel=files[1]
assert before[rel]==(s/'beat-sounds-head.rs').read_text()
anchor='''                                    .complete_processing_history_after_birth(
                                        &original,
                                        &alias,
'''
assert before[rel].count(anchor)==1
desired[rel]=before[rel].replace(anchor,anchor+'                                        binding,\n',1)
patch=''
for rel in files:
 out=s/'scope'/rel
 out.parent.mkdir(parents=True,exist_ok=True)
 out.write_text(desired[rel])
 (isolated/rel).write_text(desired[rel])
 patch+=''.join(difflib.unified_diff(before[rel].splitlines(True),desired[rel].splitlines(True),fromfile='a/'+rel,tofile='b/'+rel))
(s/'scoped.patch').write_text(patch)
(s/'scoped-files.json').write_text(json.dumps(files,indent=2)+'\n')
(s/'scoped-pins.json').write_text(json.dumps({rel:hashlib.sha256(desired[rel].encode()).hexdigest() for rel in files},indent=2)+'\n')
print('Installed independent3file binding patch; inherited empty-carrier fix excluded')
