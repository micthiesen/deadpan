from pathlib import Path
import json,difflib,hashlib
s=Path(__file__).resolve().parent
root=Path('/Users/michael/Code/deadpan')
isolated=Path('/tmp/deadpan-query-groundwork-2026-10-26/scoped')
files=json.loads((s/'scoped-files.json').read_text())
before={}
desired={}
for rel in files:
 desired[rel]=(s/'scope'/rel).read_text()
 if rel.endswith('audio_sound_processing_history.rs'): before[rel]=(s/'plan_history.before.rs').read_text()
 elif rel.endswith('beat_sounds.rs'): before[rel]=(s/'beat-sounds-head.rs').read_text()
 else: before[rel]=(s/'authority_tests.before.rs').read_text()
 assert (isolated/rel).read_text()==desired[rel],rel
rel='crates/deadpan-plan/src/plan.rs'
before[rel]=(s/'plan-head.rs').read_text()
assert (isolated/rel).read_text()==before[rel]
current=(root/rel).read_text()
start='    /// Bind one compiled plan to this exact frozen layout and sound recipe.'
end='\n}\n\nimpl AudioSoundClockBinding'
assert before[rel].count(start)==1 and current.count(start)==1
a=before[rel].index(start); b=before[rel].index(end,a)
c=current.index(start); d=current.index(end,c)
desired[rel]=before[rel][:a]+current[c:d]+before[rel][b:]
files.append(rel)
rel='crates/deadpan-plan/tests/sound_plan_binding.rs'
assert not (isolated/rel).exists()
before[rel]='';desired[rel]=(root/rel).read_text();files.append(rel)
patch=''
for rel in files:
 out=s/'scope'/rel;out.parent.mkdir(parents=True,exist_ok=True);out.write_text(desired[rel])
 (isolated/rel).write_text(desired[rel])
 patch+=''.join(difflib.unified_diff(before[rel].splitlines(True),desired[rel].splitlines(True),fromfile='a/'+rel if before[rel] else '/dev/null',tofile='b/'+rel))
(s/'combined-scoped.patch').write_text(patch)
(s/'combined-scoped-files.json').write_text(json.dumps(files,indent=2)+'\n')
(s/'combined-scoped-pins.json').write_text(json.dumps({rel:hashlib.sha256(desired[rel].encode()).hexdigest() for rel in files},indent=2)+'\n')
manifest=json.loads((s/'scoped-source-files.json').read_text())
assert files[-1] not in manifest
manifest.append(files[-1]);manifest.sort()
(s/'scoped-source-files.json').write_text(json.dumps(manifest,indent=2)+'\n')
print('Installed isolated five-file patch',len(manifest),'inputs')
