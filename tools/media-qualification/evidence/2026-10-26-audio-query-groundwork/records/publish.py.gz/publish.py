from pathlib import Path
import gzip,hashlib,json
scratch=Path(__file__).resolve().parent
out=Path('/Users/michael/Code/deadpan/tools/media-qualification/evidence/2026-10-26-audio-query-groundwork')
out.mkdir(parents=True,exist_ok=False)
sources=[]
for folder in [scratch,scratch/'core',scratch/'standalone']:
    sources.extend(p for p in sorted(folder.iterdir()) if p.is_file() and p.suffix in ('.json','.stdout','.stderr','.patch','.py','.txt'))
entries=[]
for source in sources:
    raw=source.read_bytes(); relative=Path('records')/source.relative_to(scratch)
    relative=relative.with_name(relative.name+'.gz')
    encoded=gzip.compress(raw,compresslevel=9,mtime=0)
    target=out/relative; target.parent.mkdir(parents=True,exist_ok=True); target.write_bytes(encoded)
    entries.append({'path':relative.as_posix(),'bytes':len(encoded),'sha256':hashlib.sha256(encoded).hexdigest(),'expanded_bytes':len(raw),'expanded_sha256':hashlib.sha256(raw).hexdigest()})
inventory={'schema_version':1,'base_revision':'0ac0e595','scope':'Independent 23-file borrowed Audio query and Core/Plan retained-heap groundwork. Current Core795/Plan95/Audio194 and existing stage201 passes; unfinished general Split7 filtered, no new qualification. Isolated HEAD overlay check and Audio180/Plan82 pass. No query cache/dependency/new limit. Executables/source base tar excluded; exact overlay, source and binary identities retained.','files':entries}
(out/'inventory.json').write_text(json.dumps(inventory,indent=2)+'\n')
for entry in entries:
    encoded=(out/entry['path']).read_bytes(); raw=gzip.decompress(encoded)
    assert len(encoded)==entry['bytes'] and hashlib.sha256(encoded).hexdigest()==entry['sha256']
    assert len(raw)==entry['expanded_bytes'] and hashlib.sha256(raw).hexdigest()==entry['expanded_sha256']
print(json.dumps({'files':len(entries),'stored_bytes':sum(e['bytes'] for e in entries),'expanded_bytes':sum(e['expanded_bytes'] for e in entries),'inventory_sha256':hashlib.sha256((out/'inventory.json').read_bytes()).hexdigest(),'all_payloads_verified':True}))
