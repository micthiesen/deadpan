from pathlib import Path
import os,subprocess,json,hashlib,shutil
s=Path('/tmp/deadpan-named-mark-selectors-2026-10-22')
env=dict(os.environ,DEADPAN_FFMPEG_PREFIX='/Users/michael/Library/Developer/Deadpan/ffmpeg-8.0.3-opus-1.6.1-dav1d-1.5.4-qualified-3/prefix',CARGO_PROFILE_DEV_OPT_LEVEL='2')
subprocess.run(['cargo','fmt','--all'],check=True,env=env)
with (s/'registry-generation-list.json').open('w') as out,(s/'registry-generation-build.log').open('w') as err:
 subprocess.run(['cargo','nextest','list','--locked','-p','deadpan-app','--bin','deadpan-app','--features','ui-harness','-E','test(commands_reference_is_current) | test(routing_matches_the_pre_registry_baseline)','--message-format','json'],stdout=out,stderr=err,check=True,env=env)
suites=json.loads((s/'registry-generation-list.json').read_text())['rust-suites']
matched=[v for v in suites.values() if any(c.get('filter-match',{}).get('status')=='matches' for c in v.get('testcases',{}).values())]
assert len(matched)==1
binary=Path(matched[0]['binary-path']); retained=s/'registry-generation-bin'/binary.name
retained.parent.mkdir(exist_ok=True);shutil.copy2(binary,retained)
rows=[]
for test,key in [('commands_reference_is_current','DEADPAN_UPDATE_COMMANDS_MD'),('routing_matches_the_pre_registry_baseline','DEADPAN_UPDATE_ROUTING_BASELINE')]:
 name='navigation::registry::tests::'+test
 with (s/('registry-generate-'+test+'.log')).open('w') as out:
  run=subprocess.run([str(binary),'--exact',name,'--nocapture'],stdout=out,stderr=subprocess.STDOUT,env=dict(env,**{key:'1'}))
 assert run.returncode==101,(test,run.returncode)
 text=(s/('registry-generate-'+test+'.log')).read_text()
 assert 'rewritten; review the diff' in text,test
 rows.append({'test':name,'exit':run.returncode,'expected_regeneration_stop':True,'binary_sha256':hashlib.sha256(binary.read_bytes()).hexdigest()})
(s/'registry-generation.json').write_text(json.dumps(rows,indent=2)+'\n')
print('Both references generated with expected intentional test failures; review diff before rerun.')
