from pathlib import Path
import subprocess,json,hashlib,shutil,os,time
s=Path('/tmp/deadpan-named-mark-selectors-2026-10-22')
env=dict(os.environ,DEADPAN_FFMPEG_PREFIX='/Users/michael/Library/Developer/Deadpan/ffmpeg-8.0.3-opus-1.6.1-dav1d-1.5.4-qualified-3/prefix',DEADPAN_REQUIRE_PHYSICAL_MAC='1',DEADPAN_REQUIRE_SYNTHETIC_WORKER='1')
assert (s/'broad-first-result.json').exists()
subprocess.run(['python',str(s/'guard.py'),'broad-first'],env=env,check=True)
identities=json.loads((s/'broad-first-identities.json').read_text())['test_binaries']
cases=[('deadpan-app::bin/deadpan-app','project::tests::native_new_starts_with_the_full_original_and_history_stops_at_that_baseline'),('deadpan-core::adversarial','adversarial_command_requests_are_atomic_and_reversible_under_mutation')]
rows=[]
for index,(key,case) in enumerate(cases):
 row=identities[key];p=Path(row['path']);target=s/'broad-isolated-bin'/p.name
 target.parent.mkdir(exist_ok=True);shutil.copy2(p,target)
 assert hashlib.sha256(target.read_bytes()).hexdigest()==row['sha256']
 started=time.monotonic()
 result=subprocess.run([str(target),'--exact',case,'--nocapture'],env=env,capture_output=True,text=True,timeout=60)
 (s/f'broad-isolated-{index}.stdout').write_text(result.stdout)
 (s/f'broad-isolated-{index}.stderr').write_text(result.stderr)
 passed=result.returncode==0 and '1 passed; 0 failed' in result.stdout
 rows.append({'suite':key,'case':case,'retained':str(target),'sha256':row['sha256'],'exit':result.returncode,'passed':passed,'seconds':time.monotonic()-started,'stdio_eof_within_seconds':60})
 (s/'broad-isolated-results.json').write_text(json.dumps(rows,indent=2)+'\n')
 assert passed,rows[-1]
 assert hashlib.sha256(target.read_bytes()).hexdigest()==row['sha256']
 print(json.dumps(rows[-1]),flush=True)
subprocess.run(['python',str(s/'guard.py'),'broad-first'],env=env,check=True)
