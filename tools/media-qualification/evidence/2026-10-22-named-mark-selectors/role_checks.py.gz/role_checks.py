from pathlib import Path
import subprocess,hashlib,json,shutil,os,time
s=Path('/tmp/deadpan-named-mark-selectors-2026-10-22')
env=dict(os.environ,DEADPAN_FFMPEG_PREFIX='/Users/michael/Library/Developer/Deadpan/ffmpeg-8.0.3-opus-1.6.1-dav1d-1.5.4-qualified-3/prefix',CARGO_PROFILE_DEV_OPT_LEVEL='2',DEADPAN_REQUIRE_PHYSICAL_MAC='1',DEADPAN_REQUIRE_SYNTHETIC_WORKER='1')
base=json.loads((s/'broad-first-source-identities.json').read_text());current=json.loads((s/'role-final-source-identities.json').read_text())
delta={p:{'broad_first':base.get(p),'role_final':current.get(p)}for p in base.keys()|current.keys() if base.get(p)!=current.get(p)}
assert set(delta)=={'crates/deadpan-core/tests/marks/named_mark_selectors.rs','crates/deadpan-core/tests/marks/named_mark_roles.rs'},delta
(s/'broad-to-role-test-only-delta.json').write_text(json.dumps({'production_rust_identical':True,'files':delta},indent=2)+'\n')
expression='test(named_mark_)'
args=['cargo','nextest','list','--locked','-p','deadpan-core','--test','marks','-E',expression,'--message-format','json']
with (s/'role-final-list.json').open('w') as out,(s/'role-final-build.log').open('w') as err:
 subprocess.run(args,stdout=out,stderr=err,env=env,check=True)
rows={}
for key,row in json.loads((s/'role-final-list.json').read_text())['rust-suites'].items():
 tests=[name for name,case in row.get('testcases',{}).items() if case.get('filter-match',{}).get('status')=='matches']
 if not tests: continue
 p=Path(row['binary-path']);target=s/'role-final-bin'/p.name
 target.parent.mkdir(exist_ok=True);shutil.copy2(p,target)
 rows[key]={'path':str(p),'retained':str(target),'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'tests':tests}
(s/'role-final-binaries.json').write_text(json.dumps(rows,indent=2)+'\n')
subprocess.run(['python',str(s/'guard.py'),'role-final'],env=env,check=True)
started=time.monotonic()
with (s/'role-final.log').open('w') as log:
 result=subprocess.run(['cargo','nextest','run','--locked','-p','deadpan-core','--test','marks','-E',expression,'--no-fail-fast'],stdout=log,stderr=subprocess.STDOUT,env=env)
subprocess.run(['python',str(s/'guard.py'),'role-final'],env=env,check=True)
for row in rows.values():
 for key in ['path','retained']: assert hashlib.sha256(Path(row[key]).read_bytes()).hexdigest()==row['sha256']
receipt={'exit':result.returncode,'seconds':time.monotonic()-started,'tests':sum(len(row['tests'])for row in rows.values()),'sources_inputs_binaries_unchanged':True}
(s/'role-final-result.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt))
raise SystemExit(result.returncode)
