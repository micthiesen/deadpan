#!/bin/sh
set -eu
export DEADPAN_FFMPEG_PREFIX=/Users/michael/Library/Developer/Deadpan/ffmpeg-8.0.3-opus-1.6.1-dav1d-1.5.4-qualified-3/prefix
export CARGO_PROFILE_DEV_OPT_LEVEL=2
s=/tmp/deadpan-named-mark-selectors-2026-10-22
rustfmt --edition 2024 crates/deadpan-core/tests/marks.rs crates/deadpan-core/tests/marks/named_mark_selectors.rs > "$s/baseline-format.log" 2>&1
python "$s/freeze_baseline.py" > "$s/baseline-freeze.log"
cargo nextest list --locked -p deadpan-core --test marks -E 'test(named_mark_range_semantic_yank_admits_after_public_resolver_and_visual_controls)' --message-format json > "$s/baseline-list.json" 2> "$s/baseline-build.log"
python "$s/baseline_identity.py" > "$s/baseline-identity.log"
cargo nextest run --locked -p deadpan-core --test marks -E 'test(named_mark_range_semantic_yank_admits_after_public_resolver_and_visual_controls)' --no-fail-fast > "$s/baseline.log" 2>&1
