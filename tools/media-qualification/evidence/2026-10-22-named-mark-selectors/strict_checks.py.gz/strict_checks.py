from pathlib import Path
import subprocess, os, json, time
s=Path('/tmp/deadpan-named-mark-selectors-2026-10-22')
env=dict(os.environ,DEADPAN_FFMPEG_PREFIX='/Users/michael/Library/Developer/Deadpan/ffmpeg-8.0.3-opus-1.6.1-dav1d-1.5.4-qualified-3/prefix',CARGO_PROFILE_DEV_OPT_LEVEL='2',DEADPAN_REQUIRE_PHYSICAL_MAC='1',DEADPAN_REQUIRE_SYNTHETIC_WORKER='1')
broad=json.loads((s/'broad-first-result.json').read_text())
assert broad['selected_tests']==4532 and broad['exit']==100
assert all(row['passed'] for row in json.loads((s/'broad-isolated-results.json').read_text()))
assert json.loads((s/'role-final-result.json').read_text())['exit']==0
subprocess.run(['python',str(s/'guard.py'),'role-final'],check=True,env=env)
commands=[
 ('strict-check',['cargo','xtask','check','--since','74616d32a40f9ea75ededcaedbe7edd8613bfec6','--no-test']),
 ('strict-ui-clippy',['cargo','clippy','--locked','-p','deadpan-app','--features','ui-harness','--all-targets','--','-D','warnings']),
 ('strict-format',['cargo','fmt','--all','--','--check']),
 ('strict-whitespace',['git','diff','--check'])]
rows=[]
for name,command in commands:
 started=time.monotonic()
 with (s/(name+'.log')).open('w') as log:
  result=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT,env=env)
 rows.append({'name':name,'command':command,'exit':result.returncode,'seconds':time.monotonic()-started})
 (s/'strict-results.json').write_text(json.dumps(rows,indent=2)+'\n')
 print(json.dumps(rows[-1]),flush=True)
 if result.returncode: raise SystemExit(result.returncode)
subprocess.run(['python',str(s/'guard.py'),'role-final'],check=True,env=env)
