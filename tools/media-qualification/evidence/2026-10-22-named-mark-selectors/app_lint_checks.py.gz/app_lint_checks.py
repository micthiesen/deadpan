from pathlib import Path
import subprocess,hashlib,json,shutil,os,time
s=Path('/tmp/deadpan-named-mark-selectors-2026-10-22')
env=dict(os.environ,DEADPAN_FFMPEG_PREFIX='/Users/michael/Library/Developer/Deadpan/ffmpeg-8.0.3-opus-1.6.1-dav1d-1.5.4-qualified-3/prefix',CARGO_PROFILE_DEV_OPT_LEVEL='2',DEADPAN_REQUIRE_PHYSICAL_MAC='1',DEADPAN_REQUIRE_SYNTHETIC_WORKER='1')
for phase,features in [('app-lint-final',[]),('ui-lint-final',['--features','ui-harness'])]:
 subprocess.run(['python',str(s/'guard.py'),'lint-final'],env=env,check=True)
 with (s/(phase+'-list.json')).open('w') as out,(s/(phase+'-build.log')).open('w') as err:
  subprocess.run(['cargo','nextest','list','--locked','-p','deadpan-app',*features,'-E','test(group_refresh_failure_retains_proof_and_exact_retry_does_not_replace_newer_intent) | test(saved_count_refresh_failure_keeps_receipt_and_exact_retry_cannot_replace_newer_proof) | test(repeat_refresh_failure_retains_proof_and_retry_does_not_replace_a_newer_cut)','--message-format','json'],stdout=out,stderr=err,env=env,check=True)
 rows={}
 for key,row in json.loads((s/(phase+'-list.json')).read_text())['rust-suites'].items():
  tests=[name for name,case in row.get('testcases',{}).items() if case.get('filter-match',{}).get('status')=='matches']
  if not tests: continue
  p=Path(row['binary-path']);target=s/(phase+'-bin')/p.name
  target.parent.mkdir(exist_ok=True);shutil.copy2(p,target)
  rows[key]={'path':str(p),'retained':str(target),'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'tests':tests}
 for name in ['deadpan-app','deadpan-cli','deadpan-media-worker','deadpan-transcribe','deadpan-track']:
  p=Path('target/debug')/name
  rows['helper-'+name]={'path':str(p),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
 (s/(phase+'-binaries.json')).write_text(json.dumps(rows,indent=2)+'\n')
 subprocess.run(['python',str(s/'guard.py'),'lint-final'],env=env,check=True)
 started=time.monotonic()
 with (s/(phase+'.log')).open('w') as log:
  result=subprocess.run(['cargo','nextest','run','--locked','-p','deadpan-app',*features,'-E','test(group_refresh_failure_retains_proof_and_exact_retry_does_not_replace_newer_intent) | test(saved_count_refresh_failure_keeps_receipt_and_exact_retry_cannot_replace_newer_proof) | test(repeat_refresh_failure_retains_proof_and_retry_does_not_replace_a_newer_cut)','--test-threads','8','--no-fail-fast'],stdout=log,stderr=subprocess.STDOUT,env=env)
 subprocess.run(['python',str(s/'guard.py'),'lint-final'],env=env,check=True)
 for row in rows.values():
  assert hashlib.sha256(Path(row['path']).read_bytes()).hexdigest()==row['sha256']
  if 'retained' in row: assert hashlib.sha256(Path(row['retained']).read_bytes()).hexdigest()==row['sha256']
 receipt={'exit':result.returncode,'tests':sum(len(row.get('tests',[]))for row in rows.values()),'driver_seconds':time.monotonic()-started,'sources_inputs_binaries_unchanged':True,'test_threads':8}
 (s/(phase+'-result.json')).write_text(json.dumps(receipt,indent=2)+'\n')
 print(phase,json.dumps(receipt),flush=True)
 if result.returncode:raise SystemExit(result.returncode)
