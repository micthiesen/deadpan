from pathlib import Path
import subprocess, json, hashlib, shutil, os, time
s=Path('/tmp/deadpan-named-mark-selectors-2026-10-22')
phase='integrated-first'
env=dict(os.environ,DEADPAN_FFMPEG_PREFIX='/Users/michael/Library/Developer/Deadpan/ffmpeg-8.0.3-opus-1.6.1-dav1d-1.5.4-qualified-3/prefix',CARGO_PROFILE_DEV_OPT_LEVEL='2',DEADPAN_UPDATE_COMMANDS_MD='1')
subprocess.run(['cargo','fmt','--all'],check=True,env=env)
subprocess.run(['python',str(s/'freeze.py'),phase],check=True,env=env)
cases=[
 ('cli',['-p','deadpan-cli','--test','project_commands'],'test(named_mark_range)'),
 ('app-ui',['-p','deadpan-app','--bin','deadpan-app','--features','ui-harness'],'test(named_mark) | test(edit_range) | test(navigation::) | test(preview::macros::tests) | test(project::semantic::tests)'),
]
results=[]
for label,targets,expression in cases:
 prefix=s/(phase+'-'+label)
 listing=prefix.with_suffix('.list.json')
 with listing.open('w') as out,prefix.with_suffix('.build.log').open('w') as err:
  built=subprocess.run(['cargo','nextest','list','--locked',*targets,'-E',expression,'--message-format','json'],stdout=out,stderr=err,env=env)
 if built.returncode:
  results.append({'label':label,'build_exit':built.returncode}); continue
 suites=json.loads(listing.read_text())['rust-suites']
 identities={}
 selected=0
 for key,suite in suites.items():
  matches=[name for name,case in suite.get('testcases',{}).items() if case.get('filter-match',{}).get('status')=='matches']
  if not matches: continue
  selected+=len(matches)
  p=Path(suite['binary-path']); dest=s/(phase+'-bins')/label/p.name
  dest.parent.mkdir(parents=True,exist_ok=True); shutil.copy2(p,dest)
  identities[key]={'executed':str(p),'retained':str(dest),'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'tests':matches}
 assert selected>0,label
 prefix.with_suffix('.binaries.json').write_text(json.dumps(identities,indent=2)+'\n')
 subprocess.run(['python',str(s/'guard.py'),phase],check=True,env=env)
 with prefix.with_suffix('.log').open('w') as log:
  started=time.monotonic()
  run=subprocess.run(['cargo','nextest','run','--locked',*targets,'-E',expression,'--no-fail-fast'],stdout=log,stderr=subprocess.STDOUT,env=env)
 elapsed=time.monotonic()-started
 subprocess.run(['python',str(s/'guard.py'),phase],check=True,env=env)
 for row in identities.values():
  for field in ['executed','retained']: assert hashlib.sha256(Path(row[field]).read_bytes()).hexdigest()==row['sha256']
 result={'label':label,'tests_selected':selected,'run_exit':run.returncode,'wall_seconds':elapsed,'source_and_binary_unchanged':True}
 results.append(result)
 (s/(phase+'-results.json')).write_text(json.dumps(results,indent=2)+'\n')
 print(json.dumps(result),flush=True)
assert all(r.get('run_exit')==0 for r in results),results
