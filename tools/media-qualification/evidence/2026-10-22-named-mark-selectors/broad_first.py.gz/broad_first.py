from pathlib import Path
import subprocess,hashlib,json,os
s=Path('/tmp/deadpan-named-mark-selectors-2026-10-22')
phase='broad-first'
env=dict(os.environ,DEADPAN_FFMPEG_PREFIX='/Users/michael/Library/Developer/Deadpan/ffmpeg-8.0.3-opus-1.6.1-dav1d-1.5.4-qualified-3/prefix',CARGO_PROFILE_DEV_OPT_LEVEL='2',DEADPAN_REQUIRE_PHYSICAL_MAC='1',DEADPAN_REQUIRE_SYNTHETIC_WORKER='1')
subprocess.run(['python',str(s/'guard.py'),'debug-third'],check=True,env=env)
subprocess.run(['python',str(s/'freeze.py'),phase],check=True,env=env)
targets=['-p','deadpan-core','-p','deadpan-plan','-p','deadpan-audio','-p','deadpan-store','-p','deadpan-app','-p','deadpan-cli']
expression='package(deadpan-core) | package(deadpan-plan) | package(deadpan-audio) | package(deadpan-store) | package(deadpan-app) | test(macros) | test(semantic) | test(mark) | test(project_commands) | test(selection)'
with (s/(phase+'-list.json')).open('w') as out,(s/(phase+'-build.log')).open('w') as err:
 subprocess.run(['cargo','nextest','list','--locked',*targets,'-E',expression,'--message-format','json'],stdout=out,stderr=err,env=env,check=True)
suites=json.loads((s/(phase+'-list.json')).read_text())['rust-suites']
identities={}
count=0
for key,suite in suites.items():
 tests=[name for name,case in suite.get('testcases',{}).items() if case.get('filter-match',{}).get('status')=='matches']
 if not tests: continue
 p=Path(suite['binary-path'])
 identities[key]={'path':str(p),'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'tests':tests}
 count+=len(tests)
helpers={}
for name in ['deadpan-app','deadpan-media-worker','deadpan-transcribe','deadpan-track','deadpan-cli']:
 p=Path('target/debug')/name
 if p.exists():helpers[name]={'path':str(p),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
(s/(phase+'-identities.json')).write_text(json.dumps({'test_binaries':identities,'helpers':helpers,'selected_tests':count},indent=2)+'\n')
subprocess.run(['python',str(s/'guard.py'),phase],check=True,env=env)
with (s/(phase+'.log')).open('w') as out:
 run=subprocess.run(['cargo','nextest','run','--locked',*targets,'-E',expression,'--no-fail-fast'],stdout=out,stderr=subprocess.STDOUT,env=env)
subprocess.run(['python',str(s/'guard.py'),phase],check=True,env=env)
for row in [*identities.values(),*helpers.values()]: assert hashlib.sha256(Path(row['path']).read_bytes()).hexdigest()==row['sha256'],row['path']
result={'exit':run.returncode,'selected_tests':count,'test_binaries':len(identities),'helpers':len(helpers),'rust_and_inputs_and_binaries_unchanged':True}
(s/(phase+'-result.json')).write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result))
raise SystemExit(run.returncode)
