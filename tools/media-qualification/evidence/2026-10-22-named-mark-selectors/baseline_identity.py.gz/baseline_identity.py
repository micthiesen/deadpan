from pathlib import Path
import hashlib,json,shutil
s=Path('/tmp/deadpan-named-mark-selectors-2026-10-22')
rows=json.loads((s/'baseline-source-identities.json').read_text())
for name,digest in rows.items():
 assert hashlib.sha256(Path(name).read_bytes()).hexdigest()==digest,name
listing=json.loads((s/'baseline-list.json').read_text())
test='named_mark_selectors::named_mark_range_semantic_yank_admits_after_public_resolver_and_visual_controls'
suites=[(k,v) for k,v in listing['rust-suites'].items() if test in v.get('testcases',{})]
assert len(suites)==1,suites
name,suite=suites[0]; p=Path(suite['binary-path']); target=s/'baseline-bin'/p.name
target.parent.mkdir(exist_ok=True); shutil.copy2(p,target)
row={'base':'74616d32','test':test,'suite':name,'executed':str(p),'retained':str(target),'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'rust_files':len(rows),'scope':'Synthetic structural public mark resolver and Visual capture controls before sole positive mark_range semantic wire admission assertion. No real media qualification.'}
assert hashlib.sha256(target.read_bytes()).hexdigest()==row['sha256']
(s/'baseline.json').write_text(json.dumps(row,indent=2)+'\n')
print(json.dumps(row))
