from pathlib import Path
import hashlib,json,gzip
s=Path(__file__).resolve().parent
repo=Path('/Users/michael/Code/deadpan')
dest=repo/'tools/media-qualification/evidence/2026-10-28-node-description'
assert not dest.exists(),'Archive only once all receipts are terminal'
allowed={'.rs','.json','.py','.md','.patch','.stdout','.stderr','.txt'}
entries=[]
sources=[('description',p,p.relative_to(s)) for p in sorted(s.rglob('*')) if p.is_file() and p.suffix in allowed and p.name!='qualification-draft.md']
for group,root in [('heap-research',Path('/tmp/deadpan-context-heap-2026-10-28')),('ancestry-design',Path('/tmp/deadpan-exact-node-2026-10-28'))]:
 sources.extend((group,p,p.relative_to(root)) for p in sorted(root.rglob('*')) if p.is_file() and p.suffix in allowed)
for group,p,relative in sources:
 data=p.read_bytes()
 if p.suffix=='.json':
  value=json.loads(data)
  if isinstance(value,dict) and 'command' in value and 'started_at' in value:
   assert 'exit_code' in value and value['sources_unchanged'] and value['binaries_unchanged'],str(p)
 out=dest/'records'/group/relative
 out=out.with_name(out.name+'.gz');out.parent.mkdir(parents=True,exist_ok=True)
 compressed=gzip.compress(data,mtime=0);out.write_bytes(compressed)
 entries.append({'path':str(out.relative_to(dest)),'bytes':len(compressed),'sha256':hashlib.sha256(compressed).hexdigest(),'expanded_bytes':len(data),'expanded_sha256':hashlib.sha256(data).hexdigest()})
manifest={'schema_version':1,'base_revision':(s/'base-revision.txt').read_text().strip(),'scope':'Three-file mechanical numerical temporal-node metadata constructor extraction. Actual numerical builder consumes returned context/boundary/stop/kind; metadata statement sequence and cache/native guards unchanged. Five context/work/error tests; headroom test corrected with retained diagnostic/literal evidence, preserving pre-existing None-probe billing behavior. No new Plan API, cold activation/resource proof or batching. Ancestry/heap notes are read-only research, not implementation evidence. Earlier Split four-pass/three-work-fail result is not rerun.','prior_runtime_evidence':{'path':'../2026-10-28-eq-admission/inventory.json','inventory_sha256':'dc4c62e8dc990aa87275c72de89513a3e3fe5038becda11b541861e131e6eb54'},'files':entries}

file=dest/'inventory.json';file.write_text(json.dumps(manifest,indent=2)+'\n')
stored=expanded=0
for row in entries:
 data=(dest/row['path']).read_bytes();plain=gzip.decompress(data)
 assert len(data)==row['bytes'] and hashlib.sha256(data).hexdigest()==row['sha256']
 assert len(plain)==row['expanded_bytes'] and hashlib.sha256(plain).hexdigest()==row['expanded_sha256']
 stored+=len(data);expanded+=len(plain)
print(json.dumps({'files':len(entries),'stored_bytes':stored,'expanded_bytes':expanded,'inventory_sha256':hashlib.sha256(file.read_bytes()).hexdigest()}))
