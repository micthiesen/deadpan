# Mechanical numerical node-description extraction

Scratch-only candidate, 2026-10-28. No live writes, compiler, Cargo, tests,
Git operations or worktrees. Source/tests are FROZEN for parent integration.
Only the three paths in after.json change. Four before inputs were captured
before any edits; all still hash-match live source at final audit.

## Scope and actual use

Modified: crates/deadpan-audio/src/shared_eq.rs.
New: shared_eq/node_description.rs and node_description_tests.rs.
authored_eq.rs and Plan are untouched. No new observation/classification API.

node_description::describe(plan, Request, control) owns the former numerical
new-node metadata statements. Request borrows the actual incoming Contexts and
actual demanded owner; carries at/kind, the ALREADY computed stage and the
actual original_only flag. Recomputing stage inside the helper would repeat
the wet treatment-length inspection and move it after the inherited hit path;
the caller therefore passes its original value.

Description returns the actual Contexts, treatment boundary, legacy Boundary
stop and kind. shared_eq_node destructures and consumes those fields directly
for resident/native choice and Node publication. It does not independently
reconstruct a context, stop, boundary or kind.

The inherited node-cache predicate and combined owner/event-node count limit
remain outside the helper. Native reservation, taps work, make_room,
Equalizer::new, final cancellation, publication and resident updates remain
after metadata exactly as in the current EQ-fixed source.

## Semantic audit

audit.json records:
- moved metadata tokens equal the captured old body after ONLY receiver
  renaming graph.plan -> plan, graph.original_only -> original_only and
  program.context -> incoming, ignoring formatting whitespace;
- original cache lookup and stage-count limit bytes unchanged;
- current native admission body bytes unchanged;
- read-context copied files unchanged; no live file modified.

This preserves:
1. OwnerKey clone before sound context construction.
2. Existing current audio_sound_instance_context call and construction_work
   spend, unless original_only or default gap.
3. Checked at+1 AFTER sound context construction and its spend.
4. Actual incoming support clip and incoming owners query.
5. FIRST key-equal observed Original clock, with its original clone point.
6. Existing Context::owner_context call on that selected clock, including all
   Root/Domain input and retained queries/spends/Arc choices.
7. Existing sound processing Domain fallback when no Original clock selected.
8. Existing missing-context error when no fallback exists.
9. Boundary validation AFTER the context work.

No additional traversal, comparison, charge, native operation, source read,
Arc/path clone or permission check is added. Description is a stack aggregate
of the values that previously remained local until Node publication. The
legacy stop now moves into that aggregate before native construction; this is
a move of the existing key, not a clone/allocation or different validation.

The helper is not an exact cold ancestry certificate. OwnerKey remains only
the inherited numerical selection behavior. Incoming Retained stays opaque;
no Root/Domain substitute, exact-membership restriction or new rejection is
introduced. Source admission remains in actual read paths.

## Tests authored, not executed

Under stages::shared_eq::node_description::tests:
- root_and_actual_domain_descriptions_keep_literal_context_stop_and_kind:
  Root plus a real captured Domain; EQ and wet kinds; original_only true/false;
  literal root support0..512, visible support, instance, stop, boundary and
  sound-history choice. Incoming Sounds::Root does not silently become the
  returned sound context.
- empty_original_support_keeps_current_sound_fallback_and_missing_error:
  actual sample600 outside fixture allocation; exact current sound processing
  Domain fallback when allowed, existing missing-Original error otherwise.
- incoming_retained_description_clones_the_exact_input_arc:
  a real bound Tone recipe and RootRoundEven retained input; obtains its actual
  retained owner query, checks returned Arc identity, empty Sounds, stop and
  exactly the incoming owners query work. No Graph initializer/WIP-only fields.
- metadata_budget_is_exact_without_native_filter_construction:
  measures real metadata query work, then runs at exactly that remaining
  canonical budget or one less. Exact succeeds; one less keeps existing
  Stage limit OR child Plan AudioQueryLimit behavior. No native taps charge
  occurs in the helper.
- overflow_cancellation_and_late_boundary_failure_keep_existing_order:
  sound context work precedes at+1 overflow when enabled; original_only avoids
  that sound work; cancelled/expired control has zero completed work; invalid
  final boundary still performs exactly the successful metadata query work.

These are semantic parity/new-boundary tests. A correct old renderer should
not fail its existing PCM tests. No old-failing-PCM or performance claim is made.
Parent owns compile, lint, focused tests and existing native/PCM regressions.
The retained fixture uses public Core binding construction rather than hidden
Plan test setters, and must be exercised by parent before any success claim.

## Bounded next-fold implication from parent

A cold inventory may not need the proposed public Plan observes API at all if
it owns the ACTUAL returned descriptors and numerical new-node execution consumes
those SAME descriptors once. Its resource fold can follow the selected opaque
Root/Domain/Retained handles and checked Sounds context rather than infer
ancestry from OwnerKey or equate demanded and Original clocks.

That is not implemented here. It requires admitted transient descriptor heap,
inventory/continuation identity and exact handling of actual node-cache hits.
Later hits must refer to the actual same node inventory continuation, not turn
a legacy key/boundary hit into an independent raw-context certificate.
Retained/Projected processing that lacks a recursive resource proof remains
unsupported for the cold optimization even when the real renderer supports it.
No metadata bound, cache, pooling, retry, limit/weight change, resource proof,
cold activation, batching or full-Split acceptance follows from this extraction.
