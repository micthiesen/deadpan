# Test-only headroom correction: diagnostic stage

Original candidate/patch/pins remain untouched. before.rs is the current live
test file captured before this correction. Only diagnostic.rs is modified in
scratch; no production changes, compiler or test execution.

The old assertion inferred minimum successful query headroom from completed
ReadWork.plan_work charges. That inference is false in the pre-existing path:
Context::owner_context bills input.work(), then calls control.query_limits()
for input.retained_at(); retained_at(None) performs an audio_walk_editorial but
returns no work field. It therefore needs positive query headroom beyond the
completed billed total even though no additional amount is billed.

This behavior already exists in the old renderer and is not introduced by
moving the metadata statements into node_description.rs. It is an accounting
API limitation, not evidence to lower charges, raise limits or alter production.

diagnostic.patch replaces only the failing test. It:
- measures the usual completed billed amount;
- searches minimum headroom between billed and billed+one usual query allowance;
- uses at most19 binary-search probes plus final boundary confirmations;
- accepts only canonical plan-work refusal or typed Plan AudioQueryLimit as a
  diagnostic shortfall; unrelated errors panic;
- asserts successful and final failing probes preserve the same already-billed
  prefix, and prints the exact minimum/error once.

Parent runs ONLY the focused test with output, then returns the observed
minimum and typed one-short error. Replace the search/print with independently
fixed literal minimum and one-short assertions. Do not retain diagnostic
eprintln or claim billed==all traversal. No broad suite rerun is necessary
until that final literal source is ready.

## Parent diagnostic result and final literal patch

Parent reported the focused diagnostic compiled/passed with both source guards:
billed19, minimum28, one-short billed19, error
Plan(AudioQueryLimit("structural work")).

literal-before.rs exactly matches diagnostic.rs SHA256; literal.patch is built
against that CURRENT LIVE diagnostic text. The final test is renamed
metadata_query_headroom_is_distinct_from_completed_billed_work and checks:
- headroom28 succeeds, completed billed work19, remaining unbilled headroom9;
- headroom27 returns exactly Plan AudioQueryLimit("structural work"), completed
  billed work19, remaining unbilled headroom8.

All binary search, diagnostic print and broad error acceptance are removed.
No production files or original candidate artifacts changed. Child did not
execute the final test; parent owns final compile/verification.
