# Independent review: shared EQ node description extraction

Scope: frozen `node-description.patch` against its pinned snapshots. Read-only; no live source changes or Cargo/rustc/Git runs.

## Findings

None supported in the assigned lens.

## Evidence and limits

`shared_eq_node` keeps the existing cache lookup and stage computation before the extracted helper call. `describe` is a private, metadata-only extraction of the former new-node body: it constructs the same `OwnerKey`, resolves sound history only for non-`original_only` Node owners, charges its construction work before the Original support query, performs the same checked one-sample range construction and owners query, uses the same `OwnerKey::new(clock)` comparison plus clone for the matched clock, preserves the Retained `owner_context` path and its existing ARC behavior, and keeps the same fresh sound-domain fallback or missing-context error. Boundary validation remains after the preceding context work. `shared_eq_node` then performs the unchanged native admission/construction path and publishes the returned context, boundary, stop, and kind.

The added five tests cover Root and checked Domain inputs, newly resolved sound history versus `original_only`, empty-support fallback/error, exact retained-Arc behavior and owner-query work, exact metadata-work exhaustion, overflow/cancellation/deadline ordering, and late boundary failure after the prior work. The audit confirms the cache/stage-limit and native-admission hunks are unchanged and no Plan API is added. These tests are not yet compiled or run, as instructed; this review does not independently verify the audit’s textual/hash checks.

## Metadata query headroom test correction

Reviewed `budget-correction/literal.patch` and its diagnostic receipt. No supported issue in the correction. The earlier test treated completed `ReadWork.plan_work` as the full query budget needed by the call; the bounded diagnostic demonstrates a fixture result of 19 billed units, minimum headroom 28, and at 27 a typed `AudioQueryLimit("structural work")` with the same 19 billed units. The final literal test reports that distinction directly: 28 succeeds with 9 units remaining, while 27 fails with 8 remaining and the exact structural-query error. It removes search, logging, and broad error acceptance. The patch changes only the test; the extraction and production behavior are unchanged. The unbilled work in `retained_at(None)` is an existing accounting/API behavior and not evidence of a regression from this extraction. Parent owns verification of the final literal test; I did not run Cargo.
