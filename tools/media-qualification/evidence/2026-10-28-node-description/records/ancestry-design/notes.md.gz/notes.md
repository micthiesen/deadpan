# Next exact-node slice: preserve execution, classify the checked observation

Read-only research, 2026-10-28. No repository edits, compiler, Cargo, Git,
renderer, provider or media execution. The live shared_eq.rs already includes
parent's EQ admission fix; preserve that, not the earlier scratch's ordering.

## Recommendation

Extract the actual current new-node metadata construction, for ALL its current
forms, and make shared_eq_node consume that returned description. Add cold
exact-membership as a separate checked observation, never as a replacement
numerical algorithm. Exercise it through the existing real completed-policy
visitor tests. Do not activate recursive resource/batch execution.

The previous note's direct owner_input(demand_clock) exact-only constructor
would change the normal renderer: current code intentionally may resolve an
Original clock different from the first admitted sound's clock, and it may
return an existing Retained context. Its sound fallback is also existing
behavior. Keep those numerical behaviors while narrowing Cold eligibility.

## Exact code facts

- shared_eq.rs::shared_eq_node (754+) first performs the inherited node-cache
  lookup using parent/kind/stage/matches_clock_at; then the combined temporal
  stage-count limit. Keep BOTH outside the new-node constructor and unchanged.
- Its new branch (777..816) creates the same OwnerKey; creates current Sounds
  through audio_sound_instance_context unless original_only/default-gap;
  clips at..at+1 against incoming Original support; queries its owners;
  selects the FIRST key-equal clock; calls owner_context with THAT selected
  clock, or clones the checked sound processing Domain as fallback. Boundary
  creation follows those queries.
- Parent's current native admission (817+) computes reservation, bills taps,
  calls make_room before Equalizer::new, checks cancellation, then publishes
  Node and updates active/graph resident. None belongs in the metadata helper.
- authored_eq.rs::Context::{support,owners,owner_context} (32/45/65) are the real
  checked parent operations. owner_context resolves Root/Domain AudioOwnerInput,
  charges input.work, resolves retained_at and charges retained.work, queries
  retained owners/charges work, and chooses Retained vs captured Domain.
  Incoming Retained returns the SAME Arc clone immediately.
- Plan audio_owner_input.rs::resolve_input (253+) already binds the actual
  owner query and audio_walk_owner_input to the exact Root/Domain seed. It
  resolves candidate.same_at(owner,at), captures the actual context, and records
  its checked owner, observed_at and Owner/EnclosingProcessor scope together.
- audio_owners.rs::same_at (115) includes actual plan identity, definition,
  full instance, Node/gap, gap-after, Repeat play, retained origin, affine slope
  and equal local value at that sample. OwnerKey omits several of these.
  treatment-boundary matches_clock_at deliberately omits whole-Repeat play and
  says it is not a raw-context identity.
- Context::owner_context has TWO current consumers: authored_eq.rs::eq_node
  (428) and shared_eq.rs::shared_eq_node (809). Keep the former's behavior too.

## Concrete implementation slice

Files:
1. Plan audio_owner_input.rs plus its existing audio_owners/input_tests.rs.
2. Audio authored_eq.rs: one factored owner-context conversion helper.
3. New private shared_eq/node_description.rs and numerical new-node callsite.
4. Focused private node-description tests and existing cold completion fixture
   integration. No event graph/cache changes.

Use the existing AudioOwnerInput as the checked Plan capability. Add only:

    impl AudioOwnerInput<'_> {
        pub fn observes(&self, candidate: &AudioOwnerClock<'_>) -> bool {
            self.owner.same_at(candidate, self.observed_at)
        }
    }

This does not expose same_at as arbitrary public clock equality. Its resolving
sample and captured parent seed are fixed inside the checked input; callers
cannot substitute an at argument or construct the capability. No traversal,
query, clone or heap is added by this method. Audio calls it WHILE the already
resolved input is live. It does not prove a relation to a separate clock.

Factor existing owner_context after the Root/Domain owner_input lookup into one
private conversion procedure. It must still perform the identical retained_at,
retained owner query/boundary check and Domain clone at their existing points.
Capture the cold observation before the input drops; do not retain a second
AudioOwnerInput/query graph merely to classify it later.

A small const-generic capture switch is appropriate to keep numerical work
unchanged (same pattern as the earlier placement/context capture unit):

    fn describe_new_node<const OBSERVE_COLD: bool>(
        plan: &'plan RenderPlan,
        incoming: &Contexts<'plan>,
        owner: &AudioOwnerClock<'plan>,
        at: AudioSample,
        kind: Temporal,
        original_only: bool,
        control: WorkControl<'_>,
    ) -> Result<(NewNodeDescription<'plan>, Observation), StageAudioError>

    struct NewNodeDescription<'plan> {
        context: Contexts<'plan>,
        boundary: AudioTreatmentBoundary<'plan>,
        legacy_stop: Boundary,
        kind: Temporal,
    }

    enum Observation {
        NotRequested,
        ExactAtResolution { at: AudioSample, scope: AudioOwnerInputScope },
        DifferentAtResolution,
        IncomingRetained,
        SoundFallback,
    }

These Audio types have private constructors/fields. Observation is scalar data
computed from the checked Plan capability; it is not an OwnerKey certificate.
Return it alongside the description, not stored persistently in Node or reused
across a node hit. No extra owned clock, input, Domain or retained graph is
kept solely for classification.

Numerical shared_eq_node calls <false>, consumes all actual execution fields,
and ignores the explicit NotRequested result. Its metadata branch is otherwise
byte-for-byte the original algorithm, including key selection, fallback,
Retained behavior, query/clone order and work scopes. <false> performs NO extra
classification query/comparison/spend. The common Context::owner_context
wrapper also selects the no-observation path for authored_eq.rs.

Cold calls <true> from its existing visitor callback, closing over the ACTUAL
incoming Program context/plan/original_only. Only this branch spends for the
additional observation inspection, calls input.observes(demand.clock), and
returns the typed observation. It executes the same actual context derivation;
it must not call owner_input a second time with the demand clock.

A narrower typed wrapper may return ColdEligibility plus this exact execution
description. Do not change the numerical branch to match ColdEligibility.

## Meaningful use now, without an unused speculative public API

The new private constructor is production-used immediately by every actual
new shared node. The one public Plan method is called by the compiled cold
capture path, and tested through an actual completed-policy visit, not a stub
future hook. No general ancestry API is added.

Extend the existing cold fixture test path to close over its actual incoming
Root/Domain Program and synchronously describe/classify each emitted demand.
Inspect/drop one description at a time. This is real metadata demand consumption
from the existing production visitor and constructor. It is not a resource
fold and must not be installed as an extra discard-only walk in normal reads.
There is no performance credit from computing and throwing away descriptions.

Do not expose a new public renderer entry merely to demonstrate this test.
Do not publish a separate milestone containing an uncalled generic ancestry
API. If these bounded Cold tests cannot be wired to real parent contexts yet,
land only the mechanical numerical constructor extraction and explicitly keep
the Plan classification part in scratch until it has that real consumer.

## Eligibility is separate from errors

Numerical execution always consumes the existing derived description, including
DifferentAtResolution, IncomingRetained and SoundFallback behavior. No new
Unsupported error may replace those normal paths.

Cold classification can say NotEligible(reason) for an actually resolved
different observation, incoming Retained, sound fallback, or an exact result
whose resulting Original is Retained (current recursive policy unavailable).
That is NOT proof that Original is silent or that the sound Domain is equivalent.
Retained reference grids must never be reconstructed from the nominal clock.

For the first checked Cold subset, also decline definition-relative/separate
current-sound correspondence which the actual observation does not prove.
The checked current sound-instance lookup alone is not this correspondence.
The actual returned Sounds handle remains part of the execution description.

Cold validates foreign plan/context/window and malformed stage arguments using
typed checks before accepting the description. Plan/time/query/cancellation/
work-limit errors from construction propagate as errors, never as NotEligible.
Do not inspect error strings or catch arbitrary InvalidPlan as an unsupported
subset. A false observes result is available without provoking any Plan error
because the selected Original input already resolved successfully.

Unsupported classification is not permission for a failed cold execution to
reset budgets/retry numerically. Every performed construction charge remains.
This unit does not add a scalar retry or a retained description cache.

## Lifetimes, clones and storage

Incoming Contexts borrows only for the call. NewNodeDescription<'plan> owns the
same Arc Domain/Retained/Sound handles the old Node would receive and borrows the
same exact external RenderPlan. No self-reference, new plan Arc or lifetime pin.
Perform observation while the old local AudioOwnerInput is alive, then discard
it at the old conversion boundary. Cold's observation tag is fixed scalar state.

Preserve current OwnerKey construction and every existing clone in the numerical
path initially, even if a borrowed lookup could later save allocation. The
mechanical extraction must not silently combine that separate optimization.

Cold description ownership is NEW retained metadata relative to permission
visitation; its header/handle/Arc capacities require honest transient admission.
Existing order-vector admission does not pay for it. Existing Plan owned-heap
coverage does not yet publish all OwnerInput/Retained/SoundContext bounds.
Until parent supplies that bound, keep the new constructor consumer confined to
bounded tests and the actual existing numerical new-node lifetime. Never assert
that query work limits or a small number of Arcs prove its heap peak.

## Focused tests and concrete counterexamples

1. Root and captured Domain exact observation:
   actual completed-policy fixture emits EQ and wet requests; metadata callback
   uses the same incoming Program as numerical new-node creation. Assert exact
   classification and compare resulting context processing/owners/support,
   boundary and stop against an explicit old-branch oracle. Exact and one-short
   construction work; provider/native counters remain unchanged by metadata.

2. Separate-clock preservation:
   use retained/moved sound-clock fixtures already in
   audio_definition/sound_clocks/owner_input.rs and sound_clocks.rs. Construct
   incoming Original and demanded current sound clock with equal OwnerKey but
   different origin/sampling. Old selection still produces its checked Original
   context. Cold returns DifferentAtResolution and does not substitute the
   current sound clock. Ordinary rendered PCM/suppression/source-admission
   regression tests must remain unchanged.

3. Existing Plan retained-binding counterexample:
   audio_owners/input_tests.rs::retained_binding_is_not_reconstructed_from_its_nominal_descendant_clock
   already has current consumer sample1, local owner3/2, reference3, retained
   reference0 at consumer-2, scope EnclosingProcessor. Preserve that exact
   retained input and mapping. An exact clock observation does NOT upgrade the
   resulting Retained context into recursively eligible Root/Domain.

4. Whole-Repeat play distinction:
   audio_owners/input_tests.rs::repeat_play_gap_and_whole_repeat_have_distinct_contexts
   already shows whole-Repeat boundary matching across plays while their
   observation identities differ. Input resolved at6 must observe that actual
   play's clock and reject a play0 observation used at6, even if key/boundary
   matching succeeds. Also reject a freshly compiled equal-content plan.
   This is an old-failing proof oracle if the classifier is faulted back to
   OwnerKey or boundary matching.

5. Incoming Retained:
   Context::owner_context still returns the same Arc immediately and does not
   re-enter root owner_input. Cold yields IncomingRetained, normal rendering
   continues. Test exact Arc identity plus no extra query work.

6. Missing key/sound fallback and empty support:
   numerical branch still takes its checked sound processing Domain fallback,
   or existing missing-context error when Sounds=None. Cold marks fallback
   NotEligible; a missing key is not an OriginalAbsent certificate.

7. Source checks and failure cleanup:
   actual provider invalidation tests remain on the unchanged numerical reader.
   Metadata construction must not publish node/filter state on an error. Match
   query-budget, overflow, foreign Domain and cancelled errors; no native
   constructor runs in the metadata-only callback.

Because this slice preserves numerical behavior, a correct new PCM regression
test should NOT fail the old renderer. The old-failing tests target the new
proof boundary: substituting key equality for observes or treating exact
Retained observation as eligible must fail. Do not claim otherwise.

## Explicitly deferred

The inherited node-cache hit predicate is unchanged and is NOT proof-carrying.
Its first descriptor's observation may not be replayed for a later demand:
whole-Repeat play changes are intentionally outside that cache identity.
A later exact inventory/one-shot continuation must decide whether numerical
execution consumes the same descriptor or an already described node hit.
Do not use this helper as a cache-hit authority or skip fresh source/depth checks.

Separate-clock correspondence needs a future Plan-owned relation over actual
parent/reference ancestry. This slice deliberately does not invent it.
Full recursive metadata/native/PCM resource admission, event-local nodes and
batched histories remain owed. No new cap, cache, weight, refund or full-Split
acceptance claim follows from this extraction.
