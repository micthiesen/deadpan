# Temporal context heap admission

Read-only research, 2026-10-28. Fifteen focused live source files are captured
in source-snapshot/; source-sha256.json and .txt pin their exact bytes.
No repository edits, Cargo/rustc, Git, provider reads, StageAudio construction,
native probes, or acceptance tests were run.

## Recommendation

There is no existing published bound for the complete transient construction
of these contexts. The existing heap visitor is a good foundation for their
retained bound, but explicitly does not bound construction. Measuring a returned
context after construction is not prior admission of its construction peak.

The smallest useful implementation has two separate parts:

1. Extend Plan's existing OwnedHeap implementations and public measurement
   methods to cover the actual description's owned metadata. This is small,
   measures actual capacities, and is independent of native processors.
2. Add narrowly scoped before-allocation accounting to the real metadata
   constructors, including the Core binding helpers they actually call.
   Share those actual constructors with the numerical path. Do not build a
   second context/counting walk, an Audio graph, or a fake renderer to estimate
   the first one. Until every reached allocation is covered, a cold caller
   cannot honestly admit extra histories from a returned-handle byte count.

The current-sound context has a particularly small, closed allocation recipe
described below. Full Root/Domain owner-input construction is not comparably
closed by an existing public API. An upfront cold refusal for unsupported
binding/constructor forms is honest; ordinary numerical behavior must remain.
A postconstruction refusal cannot undo metadata allocations already performed.

This is a proposal, not a completed resource system or permission to activate
recursive or batched histories.

## Actual allocations and overlap

All lookups use the existing Plan and exact context seed. Metadata construction
neither opens PCM nor grants source authority.

| Actual phase | New heap and important overlap |
| --- | --- |
| shared_eq_node, shared_eq.rs:777-816 | OwnerKey owns an instance-path clone. Current Sounds may be constructed and wrapped in an outer Arc. The incoming owners query constructs spans and per-span clocks. Selection clones a clock; the query then drops before owner_context. Temporary OwnerKey::new(clock) values in the legacy predicate clone paths too. The selected clock stays live during the next call. |
| audio_owner_input / AudioDomain::owner_input, audio_owner_input.rs:217-310 | A second one-sample membership query remains alive in resolve_input while audio_walk_owner_input captures the Domain and produces its ordinary walk result. The final owner clone borrows that query. Query, capture, and walk scratch/result can overlap. |
| audio_walk_internal, audio.rs:490-1078 | Constraints, editorial markers, Repeat path and retimes are independent Vecs. A seeded walk clones these before descent. Capture clones prefixes into a second seed and clones the instance; descent can continue afterward. The discarded walk result can allocate boundary-origin lists and paths, a Preserve stage descriptor/path, or a boxed AudioBound. |
| AudioOwnerInput::retained_at, audio_owner_input.rs:65-101 | The still-live input Domain is walked again with editorial capture. A Bound result retains processing span, captured editorial vectors, and bound.raw_domain() together. Raw Domain is an additional owned Root or Point Domain, not a borrowed view into the span. Non-Bound results are discarded after the real walk. |
| AudioOwnerRetainedInput::owners, audio_owners.rs:484-534 | The retained input stays live. bound.envelope_domain() builds a temporary Root Domain even for PointCeil. Walk::from_seed clones its path; query_mapped clones the Walk per span, builds RawOwner clocks, then converts them into a returned clock Vec. |
| Context::owner_context, authored_eq.rs:65-101 | Input, retained result, retained owner query and temporary treatment-boundary clock may overlap. Retained success moves into an Arc; fallback clones input.context() into another Domain before input drops. Incoming Retained only clones its Arc. |
| shared_eq_node publication | Final context handles, final treatment boundary and legacy stop/key exist before native construction. Native admission from b97fcce9 pays EQ native state, not preceding metadata or node Vec capacity. |

One integer-sample request has at most one nonempty returned owner span:
the cursor must advance by at least one integer label. This does not limit
the owner stack to one, nor to one current structural path. A binding can
recurse and append another ancestry to the same stack. The walker limits
binding recursion and spends 1 + state.repeats.len() per visited node.
These checks bound work/depth, not an allocation receipt covering capacities,
origin clones, and overlapping conversion buffers.

query_mapped consumes Vec<RawOwner> into Result<Vec<AudioOwnerClock>>.
A hard peak must allow source and destination buffers to coexist; it cannot
depend on an implementation-specific in-place collect optimization.

## Current-sound constructor: a small closed recipe

audio_sound_instance_context (audio_sound_owner_context.rs:47-137) calls
resolve_edges (audio_source_occurrence.rs:471-573):

* chain: Vec<usize> follows host parents to the root. The existing guard permits
  at most MAX_DOCUMENT_DEPTH + 1 slots on success, hence at most
  MAX_DOCUMENT_DEPTH edges.
* edges: Vec<Edge> is allocated while chain is still live. Edge holds scalar
  placements, counts, optional exact ranges and play positions, no nested heap.
* Chain drops when resolve_edges returns. Edges remains alive during final
  sound-context construction.

Let R be the input instance Repeat count and P the selected processing-instance
Repeat count, with P <= R. The returned handle owns:

* owner.repeats: R elements;
* processing_instance.repeats: P elements;
* policy.seed.repeats: P elements;
* policy.instance.repeats: P elements;
* one Arc<AudioDomain>, including payload and counters.

Its four vector payloads therefore require (R + 3P) * size_of::<RepeatInstance>()
when each capacity equals required length. Measure actual capacities today.
All other policy seed Vecs start empty. NodeId/RevisionId clones share existing
Arc text and allocate no new text here, although the conservative retained
visitor counts owning text edges. Audio subsequently adds the outer
Arc<AudioSoundOwnerContext>.

The actual phase peak is:

    max(chain storage + edges storage,
        edges storage + final sound-context allocations)

plus the outer sound-context Arc after edges drops. For the sound-only
fallback, processing_domain().clone() creates another Domain with TWO
P-element Repeat buffers and its outer Arc while Sounds remains live.
processing_domain() itself is a borrow and allocates nothing.

A private Plan preparation bound could use checked Layout::array::<usize>(D+1),
Layout::array::<Edge>(D), R/P Repeat-vector layouts, and Arc layouts.
Before advertising a hard bound, make capacity policy explicit at these
sites: current growing chain and derived Vec clones publish no upper-capacity
contract. Do not silently equate spare capacity with length or assume a
general Vec growth rule. No ancestry reconstruction, PCM or native probe is
needed for this recipe. Exact P is available after actual edge resolution;
an upfront bound can conservatively substitute R.

## Binding resolution is part of metadata construction

Owner queries and audio_walk_internal both call RenderPlan::bound_at
(audio_bound.rs:130-282). It allocates an occurrence Repeat vector, optional
definition-exclusion vector, resolved binding/lattice, and mapped constraints.

Core AudioBindings::resolve_binding (audio_binding.rs:1790-1855) keeps the
lattice placement alive while resolving each phase term/reanchor placement.
AudioPlacementTemplate::resolve_with (866-1036) calls scoped_repeats to build
a required NodeId path, then builds the resolved Repeat vector while the path
iterator still owns its buffer. project_scoped_inner returns a projection with
another instance-path clone. Working instance and projection clone can
coexist; the final placement keeps the former.

These operations inspect admitted immutable layout indices. They do not clone
the entire FrozenAudioLayout or build native state. Nevertheless, the final
AudioBound visitor sees neither discarded required-path buffers nor temporary
phase/reanchor placements. Final-lattice measurement misses their peaks.

AudioBound::raw_domain (420+) creates another owned domain:

* Root: the placed-domain seed starts with a placement constraint, then gets
  cloned constraints and Repeat paths from the bound.
* Point: AudioPointDomain contains selector and AudioSignal. Setting evaluation
  owns a cloned Repeat path. Existing Point Domain/Signal heap visitors cover
  those retained children.

bound.envelope_domain independently builds a Root-shaped inspection Domain.
Preserve the PointCeil/RootRoundEven distinction; it removes no allocation.

## Minimum retained visitor extension

Reuse audio_allocated.rs's checked measure, HeapBudget::storage, generic
Vec/Option/Box/Arc visits, and Arc Layout calculation. They count actual
capacities, padding, identifier text and repeated Arc edges, with checked
overflow, traversal work/depth, and no allocating visited-pointer set.
Borrowed RenderPlan storage stays excluded.

Existing implementations cover Domain, DomainGap, owner Clock, ProcessingSpan,
AudioBound, PointDomain, Signal, stage descriptors, resolved binding/lattice,
constraints and editorial constraints.

| Missing type | Owned fields to visit |
| --- | --- |
| AudioOwnerInput | owner, context; observed sample/scope/work scalar |
| AudioOwnerRetainedInput | processing, editorial, domain; plan borrowed |
| EditorialCapture | editorial, constraints, repeats |
| AudioBoundDomain | Root Domain or Point Domain; Empty has no child heap |
| AudioSoundOwnerContext | owner, policy Arc, processing_instance; plan borrowed |
| AudioOwnerSpan<S> | owners; range/support/silent flag scalar |
| AudioOwnerQuery<S> | spans; plan borrowed |
| AudioTreatmentBoundary | owned clock |

Expose allocated_bytes_bound for the owned handles Audio needs, plus Domain
and Clock where measured independently. Query/Span traversal can remain generic
in S internally because sample labels add no heap.

For an Audio description, count the actual wrapped Arcs, not just inner
handles. Existing public methods exclude the inline handle. An Arc needs
its full allocation Layout plus nested heap; a bare handle stored inline
in an inventory needs only nested heap because the inventory pays its slot.
Add Audio boundary/legacy stop/key owned paths and inventory/Node Vec capacity
separately. Do not count inline headers twice or omit Arc payloads/spare slots.

Visiting both a retained processing Bound and its raw Domain can count
identifier Arcs repeatedly. That is the existing conservative contract;
new pointer-dedup storage is unnecessary. Owning clones must remain under
whichever lease pays for them.

This proves retained bytes AFTER construction, with checked inspection work.
It does not prove transient construction or pay that new work automatically.

## Minimum construction admission proposal

Add a narrowly scoped Plan metadata allocation budget to the actual
owner-input, retained lookup/owner query, and sound-context call graph:

1. Keep existing entrypoints as compatibility wrappers. A resource-aware
   variant takes an admitted metadata byte allowance and returns the normal
   result plus construction/retained receipts. Context selection, binding
   resolution and ordinary work/error semantics remain the same.
2. Before each allocating Vec growth/clone/collect or Box/Arc creation, check
   a typed layout amount. Vector helpers need an explicit bounded capacity
   policy and must reserve old and new buffers together for realloc peak.
   Nested owned clones include child allocations. Move the actual result
   onward, never recompute it.
3. A simple conservative first receipt may monotonically accumulate newly
   allocated payload layouts through one description construction. This
   overbounds live peak without a lifetime oracle or mid-construction release.
   Include cloned-input heap as appropriate and Core binding temporaries.
   This is not a guessed bytes-per-work weight. If it exceeds the unchanged
   cap, report refusal. Tighter live-set accounting needs explicit drop and
   ownership evidence.
4. Audio admits that allowance in its existing resident ledger before calling
   the resource-aware constructor. An alternative per-allocation callback
   must reserve BEFORE allocation in the same ledger and preserve cumulative
   admission through construction. Neither requires StageAudio inside Plan.
5. A retained lease follows the resulting description/node until all owned
   clones drop. Moving it into another inventory or temporarily taking an EQ
   filter must not release its charge. Native and PCM/history admission add
   to it, not replace it.

Without constructor changes, size_of::<AudioDomain>(), a flat amount per owner,
or work multiplied by guessed bytes is not this bound. A worst-case formula
using actual typed layouts, query/recursive-path limits and inherited seed
lengths could be proved, but requires auditing the same call graph and capacity
policy. No validated formula currently exists. A global worst-case allowance
could also refuse ordinary paths needlessly; do not claim an invented numeric
ceiling is minimal.

Before extra cold histories/native states, decline forms whose reached
allocations remain uncovered. Incoming Retained's Arc clone is small, but
does not cover its recursive queries, processing or policy population.
Detecting Retained only after construction is too late to claim its
transient heap was never used. Owner-ID/nominal-clock/boundary equivalence
cannot repair that.

## Work-bearing None obligation

Root reported, and source confirms, that Context::owner_context bills
input.work(), then calls input.retained_at(at, control.query_limits()).
retained_at always audio_walk_editorial-walks with a real Budget.
Bound returns AudioOwnerRetainedInput { work: used, ... }; non-Bound returns
bare None and discards the amount. Audio can bill Bound but cannot bill the
successful None traversal. That branch also constructed the discarded walk
result. It is neither zero work nor zero heap.

Preserve baseline billing in the mechanical extraction. A separate minimal
fix is a work-bearing retained lookup result, conceptually
AudioRetainedLookup { input: Option<AudioOwnerRetainedInput>, work }.
Return actual work from BOTH success branches of the same walk, without
performing it twice, moving it to cache_key_scope, renewing a budget, or
refunding constructor work. A compatibility wrapper may preserve the old API.
Bound's existing work must not then be billed twice.

Other ordinary failed Plan results also do not expose partial work.
Full cold accounting must state how failed performed work remains charged,
rather than treating errors or unsupported forms as free trials.
This heap proposal does not silently change that contract.

Root's separate real root-Tone probe reports 19 billed units, 28 minimum
headroom, and structural-work failure with headroom 27 after 19 billed units.
That is supplied probe evidence, not a run performed for these notes.
The separate scratch work-bearing-lookup task may add one fixed inline
Option-plus-work header with the same payload and no extra heap. Treat that
as a proposed change until its implementation is checked; it does not solve
the discarded traversal's heap admission.

Current-sound construction, Original owner queries, input capture, successful
Bound retained resolution and retained owner queries remain canonical.
New required retained-heap inspection is real bounded work to account for.
Persistent-key allowance is no authority to move actual query/DSP construction
out of canonical billing.

## Cleanup and focused evidence needed

Current numerical creation resolves metadata before native admission and node
publication. Construction errors drop locals. Do not publish partial
descriptions/nodes or take native filters before admission. Performed work
stays spent. A new byte lease must drop on every Result error, including
membership, range/overflow, work/heap limits, cancellation and timeout, and
must survive success through every owner of its Arcs. Existing native Graph
cleanup does not prove a new metadata lease is covered.

Meaningful tests for the proposed bounded change:

1. Extend retained-heap tests with spare capacities in missing types, exact byte
   deltas, identifier Arc text, repeated edges, one-short visitor work and
   overflow. Cover both BoundDomain variants, empty/inactive owners and origin.
2. Exercise real Root and captured Domain owner_input/retained_at/owners and
   sound construction under exact and one-short CONSTRUCTION allowances.
   Include non-Bound lookup, enclosing Preserve, Root/PointCeil binding and
   phase/reanchor resolution, so discarded temporaries must be paid.
3. Compare actual numerical description/PCM to compatibility behavior. Preserve
   canonical work and failed-attempt work. Bill successful None only after
   its separate receipt fix.
4. Refuse bytes/cancel/work at allocation phases; assert no lease/node remains.
   A subsequent operation on the SAME request must not get renewed work.
5. Prove refusal precedes additional history/native allocation with real entry
   counters. No fake provider planner, native estimator or throwaway renderer.

No such tests were run for this research. Full admission and all product/Split
requirements remain open.

## Smallest immediate slice and resource inputs

The immediately bounded, independent patch is the retained-visitor coverage
above, tested on real returned handles. It must explicitly claim retained
postconstruction bytes only. The sound-context peak recipe is a second small
candidate once its buffer-capacity contract is explicit. Closing all
Root/Domain/retained transient sites is further work, including Core helpers;
it need not be solved by the mechanical metadata extraction.

A future description constructor needs the actual incoming context, requested
clock, resolving sample, original-only flag, same canonical query limits and
deadline, plus byte headroom from the existing resident ledger. Native/PCM
inputs remain separate. Admission must include pinned existing metadata,
the constructor allowance, already resident native state and any subsequently
requested history at their actual overlap. Round byte amounts upward into
the renderer's existing 8-byte stereo-f32 frame units with checked arithmetic.
Do not lower native bounds, increase caps, trade work units for guessed bytes,
or replace exact contexts with owner IDs to make that sum fit.
