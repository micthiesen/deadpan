//! Literal whole-owner audio setters isolate the invocation's concrete Play.
//!
//! Register as a child of scoped_gain.rs to reuse the nested scoped fixture.
use super::*;

fn db(value: i32) -> crate::GainDb {
    crate::GainDb::new(value).unwrap()
}

fn eq() -> crate::EqualizerRecipe {
    crate::EqualizerRecipe::new(
        [db(6000), db(-3000), db(9000)],
        Some(crate::EqCutoffHz::new(80).unwrap()),
        None,
    )
    .unwrap()
}

fn seeded_setters() -> ProjectDocument {
    let mut before = fixture();
    let local = crate::GainRange::new(ExactRatio::ZERO, ExactRatio::integer(4)).unwrap();
    let envelope = crate::GainEnvelope::new(
        crate::GainClock::OwnerOutput,
        local,
        db(-3000),
        vec![crate::GainSegment::new(local.end(), db(3000), crate::GainCurve::Linear).unwrap()],
    )
    .unwrap();
    let clip = crate::ClipGain::new(
        db(6000),
        false,
        vec![envelope],
        vec![crate::GainRange::new(ExactRatio::ONE, ExactRatio::integer(2)).unwrap()],
    )
    .unwrap();
    // A legal nondefault order makes accidental reconstruction visible.
    before.nodes.get_mut(&node("a")).unwrap().audio_treatments =
        crate::AudioTreatments::with_equalizer_stages(
            vec![
                crate::AudioTreatmentStage::Saturation,
                crate::AudioTreatmentStage::Equalizer,
                crate::AudioTreatmentStage::ClipGain,
                crate::AudioTreatmentStage::StereoBalance,
            ],
            Some(clip),
            Some(crate::Saturation::new(db(9000)).unwrap()),
            Some(crate::StereoBalance::new(-25).unwrap()),
            Some(eq()),
        )
        .unwrap();
    before.validate().unwrap();
    before
}

fn assert_setter(change: AudioChange) {
    let before = seeded_setters();
    let context = entry();
    let scoped = context.scoped.as_ref().unwrap();
    assert!(
        scoped
            .target
            .matches_instance(&before, &scoped.presentation)
            .unwrap()
    );
    let seed = &before.nodes()[&node("a")].audio_treatments;
    let expected = change.apply(seed).unwrap();
    assert_ne!(&expected, seed, "the witness must change a valid treatment");
    assert_eq!(expected.order(), seed.order());
    let expected_clip = expected.clip_gain().unwrap();
    let seed_clip = seed.clip_gain().unwrap();
    assert_eq!(expected_clip.envelopes(), seed_clip.envelopes());
    assert_eq!(expected_clip.mute_ranges(), seed_clip.mute_ranges());
    assert_eq!(expected_clip.muted(), seed_clip.muted());
    assert_eq!(expected.tail_sends(), seed.tail_sends());
    assert_eq!(expected.wet_sends(), seed.wet_sends());
    match change {
        AudioChange::Trim { gain } => {
            assert_eq!(expected.trim(), gain);
            assert_eq!(expected.saturation(), seed.saturation());
            assert_eq!(expected.balance(), seed.balance());
            assert_eq!(expected.equalizer(), seed.equalizer());
        }
        AudioChange::Saturation { drive } => {
            assert_eq!(expected.saturation().map(crate::Saturation::drive), drive);
            assert_eq!(expected.clip_gain(), seed.clip_gain());
            assert_eq!(expected.balance(), seed.balance());
            assert_eq!(expected.equalizer(), seed.equalizer());
        }
        AudioChange::Balance { balance } => {
            assert_eq!(expected.balance(), balance);
            assert_eq!(expected.clip_gain(), seed.clip_gain());
            assert_eq!(expected.saturation(), seed.saturation());
            assert_eq!(expected.equalizer(), seed.equalizer());
        }
        AudioChange::Equalizer { recipe } => {
            assert_eq!(expected.equalizer(), recipe);
            assert_eq!(expected.clip_gain(), seed.clip_gain());
            assert_eq!(expected.saturation(), seed.saturation());
            assert_eq!(expected.balance(), seed.balance());
        }
        _ => panic!("this witness covers only literal recipe setters"),
    }

    let edit = crate::ScopedNodeEdit::SetAudioTreatments {
        treatments: expected.clone(),
    };
    let needs = before
        .scoped_edit_requirements(&scoped.target, &edit)
        .unwrap();
    assert_eq!((needs.nodes, needs.marks), (10, 2));
    let allocation_request = SemanticAllocationRequest::Isolation {
        step_index: 0,
        nodes: needs.nodes,
        marks: needs.marks,
    };
    let SemanticAllocation::Isolation {
        new_revision,
        identities,
    } = allocator("setter", allocation_request.clone()).unwrap()
    else {
        panic!("the scoped fixture requires exact isolation identities")
    };
    let raw_request = crate::CommandRequest {
        project_id: before.project_id().clone(),
        expected_revision: before.revision_id().clone(),
        new_revision,
        command: Command::EditScoped {
            target: scoped.target.clone(),
            edit,
            identities,
        },
    };
    let snapshot = before.to_json().unwrap();
    // Public backend/pool success is a required prefix: an old-code failure
    // must identify semantic admission, not invalid DSP values or scope.
    let raw = crate::prepare_scoped_edit(&before, &raw_request).unwrap();
    assert_eq!(
        raw.document.nodes()[&raw.target.node].audio_treatments,
        expected
    );
    assert_eq!(raw.document.duration().unwrap(), before.duration().unwrap());
    assert_eq!(raw.document.audio_bindings(), before.audio_bindings());
    assert_eq!(
        raw.transaction.inverse.apply(&raw.document).unwrap(),
        before
    );
    assert_eq!(
        ProjectDocument::from_json(&raw.document.to_json().unwrap()).unwrap(),
        raw.document
    );
    for outer in 0..3 {
        for inner in 0..2 {
            let mapped = raw
                .map_instance(&before, &presentation(outer, inner))
                .unwrap();
            assert_eq!(
                raw.document.nodes()[&mapped.node].audio_treatments,
                if outer == 1 && inner == 1 {
                    &expected
                } else {
                    seed
                }
                .clone()
            );
            let peer = InstancePath {
                node: node("b"),
                ..presentation(outer, inner)
            };
            let mapped_peer = raw.map_instance(&before, &peer).unwrap();
            assert_eq!(
                raw.document.nodes()[&mapped_peer.node].audio_treatments,
                before.nodes()[&node("b")].audio_treatments
            );
        }
    }
    assert_eq!(before.to_json().unwrap(), snapshot);

    let mut allocations = Vec::new();
    let plan = resolve(
        &before,
        &context,
        vec![SemanticInstruction::SetAudio { change }],
        &BTreeMap::new(),
        |request| {
            allocations.push(request.clone());
            allocator("setter", request)
        },
    )
    .expect("an explicit nested Play must admit this whole-owner literal audio setter");
    assert_eq!(allocations, vec![allocation_request]);
    assert_context(&context, &plan.context);
    let mapped = plan.context.scoped.as_ref().unwrap();
    assert_eq!(mapped.target, raw.target);
    assert_eq!(
        mapped.presentation,
        raw.map_instance(&before, &scoped.presentation).unwrap()
    );
    assert!(
        mapped
            .target
            .matches_instance(&plan.document, &mapped.presentation)
            .unwrap()
    );
    assert_eq!(
        plan.document.nodes()[&mapped.target.node].audio_treatments,
        expected
    );
    // Same pool identities make the independently executed backend result an
    // exact authored-content oracle; only the outer Compound revision differs.
    assert_eq!(plan.document.nodes(), raw.document.nodes());
    assert_eq!(plan.document.marks(), raw.document.marks());
    assert_eq!(plan.document.overrides(), raw.document.overrides());
    assert_eq!(plan.document.gap_overrides(), raw.document.gap_overrides());
    assert_eq!(plan.document.audio_bindings(), before.audio_bindings());
    assert_eq!(
        plan.document.duration().unwrap(),
        before.duration().unwrap()
    );
    for (owner, authored) in before.nodes() {
        assert_eq!(
            &plan.document.nodes()[owner],
            authored,
            "shared template {owner}"
        );
    }
    assert!(plan.register_writes.is_empty());
    assert_eq!(before.to_json().unwrap(), snapshot);
    assert_reversible(&before, &plan);
}

#[test]
fn scoped_trim_literal_isolates_one_play_and_preserves_peer_treatments_and_timing() {
    assert_setter(AudioChange::Trim { gain: db(-6250) });
}

#[test]
fn scoped_saturation_literal_isolates_one_play_and_preserves_peer_treatments_and_timing() {
    assert_setter(AudioChange::Saturation {
        drive: Some(db(12000)),
    });
}

#[test]
fn scoped_balance_literal_isolates_one_play_and_preserves_peer_treatments_and_timing() {
    assert_setter(AudioChange::Balance {
        balance: Some(crate::StereoBalance::new(40).unwrap()),
    });
}

#[test]
fn scoped_equalizer_literal_isolates_one_play_and_preserves_peer_treatments_and_timing() {
    assert_setter(AudioChange::Equalizer {
        recipe: Some(
            crate::EqualizerRecipe::new(
                [db(-6000), db(3000), db(-9000)],
                Some(crate::EqCutoffHz::new(100).unwrap()),
                Some(crate::EqCutoffHz::new(12000).unwrap()),
            )
            .unwrap(),
        ),
    });
}
