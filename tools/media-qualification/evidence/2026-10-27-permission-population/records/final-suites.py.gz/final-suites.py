from pathlib import Path
import subprocess
s=Path(__file__).resolve().parent
cases=[
 ('run.py','definition3','build3-audio-definition',[]),
 ('run.py','stages-enabled3','build3-stages',['--skip','general_split_sound']),
 ('run_scoped.py','scoped-stages3','scoped-build3-stages',[]),
]
for runner,label,binary,arguments in cases:
 command=['python',str(s/runner),'--binary',str(s/binary),label,'--',str(s/binary),*arguments,'--test-threads=4']
 subprocess.run(command,check=True)
