from pathlib import Path
import difflib,json,hashlib,subprocess
s=Path(__file__).resolve().parent;r=Path('/Users/michael/Code/deadpan');q=Path('/tmp/deadpan-query-groundwork-2026-10-26/scoped')
name='crates/deadpan-audio/src/shared_eq.rs'
before=(s/'shared_eq.before-unselected.rs').read_text();after=(r/name).read_text()
patch=''.join(difflib.unified_diff(before.splitlines(True),after.splitlines(True),fromfile='a/'+name,tofile='b/'+name))
p=s/'unselected-shared-eq.patch';p.write_text(patch)
result=subprocess.run(['patch','--dry-run','-p1','-i',str(p)],cwd=q,capture_output=True,text=True);assert result.returncode==0,(result.stdout,result.stderr)
subprocess.run(['patch','-p1','-i',str(p)],cwd=q,check=True)
for name in ['crates/deadpan-audio/src/shared_eq/policy_prediction.rs','crates/deadpan-audio/src/shared_eq/policy_prediction_tests.rs']:
 (q/name).write_bytes((r/name).read_bytes())
for root in [r,q]:
 names=['crates/deadpan-audio/src/shared_eq.rs','crates/deadpan-audio/src/shared_eq/policy_prediction.rs','crates/deadpan-audio/src/shared_eq/policy_prediction_tests.rs']
 subprocess.run(['rustfmt','--edition','2024','--config','skip_children=true',*[str(root/n) for n in names]],check=True)
for root,listname,frozen in [(r,'source-files.json','source-frozen.json'),(q,'scoped-source-files.json','scoped-source-frozen.json')]:
 files=json.loads((s/listname).read_text())
 pins={str(root/p):{'bytes':(root/p).stat().st_size,'sha256':hashlib.sha256((root/p).read_bytes()).hexdigest()} for p in files}
 (s/frozen).write_text(json.dumps(pins,indent=2)+'\n')
print('Updated and froze both source variants')
