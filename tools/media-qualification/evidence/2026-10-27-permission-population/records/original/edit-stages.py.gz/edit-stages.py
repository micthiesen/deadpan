from pathlib import Path
p=Path('/tmp/deadpan-permission-population-2026-10-27/original/source/crates/deadpan-audio/src/stages.rs')
s=p.read_text()
anchor="struct RootReadQueries<'plan> {"; assert s.count(anchor)==1
s=s.replace(anchor,'#[path = "original_request.rs"]\nmod original_request;\n\n'+anchor)
start=s.index('    fn read_context_controlled('); end=s.index('\n    /// A retained processor',start)
old=s[start:end]
header=old[:old.index('        control.check()?;')]
new=header+'''        let request = self.prepare_original_domain(domain, start, frames, control, edge_fades)?;
        self.read_prepared_original(provider, request, control, depth)
    }
'''
s=s[:start]+new+s[end:]
start=s.index('    fn read_controlled(');end=s.index('\n    fn preflight_root_queries(',start)
old=s[start:end]
header=old[:old.index('        control.check()?;')]
new=header+'''        // Keep the borrowed queries independent of the mutable preparation
        // controller, as before; the request itself retains no Arc.
        let plan = Arc::clone(&self.plan);
        let request = self.prepare_original_root(&plan, start, frames, control, edge_fades)?;
        self.read_prepared_original(provider, request, control, depth)
    }
'''
s=s[:start]+new+s[end:];p.write_text(s)
print('Only two read wrappers and one module declaration changed in scratch stages.rs.')
