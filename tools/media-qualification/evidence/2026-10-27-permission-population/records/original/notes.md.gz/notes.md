# One Original request for preparation and actual read

Scratch-only candidate, frozen2026-10-27. No repository writes, Cargo, rustc, commits, pushes or worktrees. Main owns integration/build/verification.

## Scope and exact inputs

before/ + before.json retain five exact inputs, including stages.rs and read-only raw_policy/authored_eq/original_inputs/audio_domain context. Source pinning began against the task's bcbc6738/1408-input checkpoint.

original-request.patch changes ONLY:
- stages.rs: one module declaration immediately before RootReadQueries, plus read_controlled/read_context_controlled bodies;
- NEW original_request.rs;
- NEW original_request/tests.rs.

No apply_suppression, raw-policy loop, shared_eq/shared_mix/shared_components/Original cache changes are in this patch. Main's concurrent authorized stages.rs edits outside the two wrappers are recorded in audit.json; both owned wrapper bodies still match the captured baseline in main. Apply the small hunks/barrel, never overwrite the whole copied stages.rs.

## API

original_request::PreparedOriginalRequest<'context,'plan> is sealed and non-Clone. It owns the same RootReadQueries allocation the old read constructed and stores start/frames/edge_fades plus one borrowed origin:
- Root(&'plan RenderPlan)
- Domain(&'context AudioDomain<'plan>)

StageAudio methods, all used by actual production readers:
- prepare_original_root(plan,start,frames,control,edge_fades)
- prepare_original_domain(domain,start,frames,control,edge_fades)
- read_prepared_original(provider,request,control,depth)

Request methods, also used by production consumption:
- queries() -> RootReadQueriesRef for borrowed raw-policy inspection;
- matches_root(plan,start,frames,edge_fades)
- matches_domain(plan,domain,start,frames,edge_fades)

Root matcher requires exact immutable plan pointer. Domain matcher requires belongs_to(actual plan), pointer equality of the borrowed Domain wrapper, and exact window/fade flag. Equal-content foreign plans and separately cloned Domain wrappers cannot alias. Existing Context::Domain Arc clones retain the same wrapper address and can match normally. The request itself stores no Arc or cloned context.

Root preparation returns a Root request with both lifetimes equal to the plan borrow; covariance permits it to join a local optional Domain request with a shorter context borrow. Domain preparation retains only its original domain borrow; self.plan is used for validation but is not an additional retained lifetime. AudioDomain::processing returns AudioProcessingQuery<'plan>, so no self-reference/self_cell is required.

Parent cache integration can accept an optional two-lifetime request, validate against its actual Context/window/fades before hit/miss handling, borrow policy, and consume it on a miss. On a hit retain normal exact key/depth/source fingerprint admission, then drop the request. This patch does not change that cache.

## Preserved preparation/read sequence

Constructors retain the exact old fallible validation/query order:
- control.check;
- Domain foreign-plan check, checked end and frame count (Root also checks nonnegative/root duration);
- flattened query, spend its work;
- processing query, spend;
- policy query, spend;
- optional creative-fade query, spend.

Root has one additional exact-plan argument check, necessarily true in the ordinary reader. Root's existing local Arc clone now occurs just before entering the factored constructor rather than after its validation; it is infallible, retains no extra graph beyond this read, and changes no fallible/error/query order. Domain adds no Arc clone.

Actual read_controlled/read_context_controlled immediately prepare and consume the request. read_prepared_original checks that the stored origin still belongs to the controller's actual immutable plan, then calls the existing read_queries_borrowed with the exact stored window and borrowed query allocation. No query construction/work charge is repeated there.

The existing borrowed read still performs control/depth checks, full preflight_root_queries, live provider resolution/fingerprint observation, intrinsic stage admission, final raw policy and creative fades, and final control check. Nothing from the numerical reader moved. No media provider is accepted by either constructor, and constructors do not preflight assets or claim source admission.

A foreign *prepared* request is rejected by its new origin check before entering the numerical reader. Valid legacy readers preserve their existing cancellation/range/foreign/fade/depth/source behavior. Invalid Domain ranges still surface their old Plan range error rather than being converted to Root's range rules. Domain negative root labels are not rejected by an invented global nonnegative check.

No new cache, source authority, deadline, work allowance/refund, query clone or retained plan pin is introduced. Ordinary callers still construct once and immediately read. The future cold path may hold this same call-local request during metadata population; that parent integration must keep its original Context/plan alive, account any changed metadata lifetime and retain all additional visitor work.

Context::Retained is deliberately absent. Its transfer-policy adapter remains unsupported for cold eligibility and the existing runtime retained reader stays unchanged.

## Authored focused tests (not run by this worker)

Filter: stages::original_request::tests::

1. prepared_root_and_domain_match_previous_query_content_work_and_actual_reads:
   Root/Domain, fades off/on, Source0/RoomTone512/Preserve640 fixtures. Independent previous construction sequence compares all query data/work then actual bitwise PCM, masks, dependencies, depth, provider calls and aggregate work.

2. prepared_source_read_does_not_requery_with_no_plan_work_remaining:
   prepare Source query with no provider calls; consume at MAX_PLAN_WORK_PER_READ with no remaining query allowance and require live provider access. A fresh ordinary Root/Domain wrapper also succeeds with exactly the measured preparation work, proving the production wrapper prepares only once. An unprepared read at exhausted work fails before source access.

3. prepared_identity_requires_exact_plan_domain_window_and_edge_mode:
   exact identity positive cases; foreign equal-content plan, cloned Domain wrapper, wrong start/count/fade flag and Root/Domain mismatch rejected. Foreign request consumption performs no source call.

4. preparation_preserves_root_and_domain_range_and_foreign_errors:
   zero/oversized frames, checked overflow, Root negative range, Domain Plan range and foreign context; no work/source reads.

5. exact_preparation_budget_and_one_short_match_previous_query_sequence:
   both forms preserve exact/one-short outcome, error and already-spent work against the old query sequence.

6. prepared_read_still_checks_cancellation_deadline_and_depth_before_sources:
   both forms keep already spent construction work and refuse before source admission.

7. planning_cancellation_and_deadline_keep_priority_over_invalid_range:
   cancellation/timeout precede malformed-range rejection, without query/source work.

8. prepared_metadata_does_not_waive_fresh_source_admission:
   source revocation after metadata preparation still fails on a fresh actual provider call; existing preflight assets are established at read time, with no new query charge.

Tests reuse the existing controlled_reads fixture/provider, guarded for macOS/Linux like that fixture. No Graph/cache WIP-only fields are referenced. Parent must compile/run these and existing controlled/domain/root/definition/stages regressions; none is claimed passing here.

## Open verification/integration points

- Two-lifetime borrow/type checking awaits parent Cargo; no compiler was run.
- Exact budget boundaries and Preserve query equality are authored assertions awaiting actual execution.
- No cache-hit test is added here because cache ownership/integration is assigned to main; fresh admission/range/context identity must still be rechecked there.
- Source authority, complete pre-PCM permission population, independent planned-vs-observed oracle and cold recursive resource closure remain separate work.
- Request fixed header is new call-local metadata; it does not create another query graph allocation. Retaining it across more of a chunk must not be mistaken for a free lifetime extension or persisted query proof.
