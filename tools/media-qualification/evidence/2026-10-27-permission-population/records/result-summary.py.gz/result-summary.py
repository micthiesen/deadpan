from pathlib import Path
import json,re
s=Path(__file__).resolve().parent
labels=['build3','library3','definition3','stages-enabled3','strict3','scoped-build3','scoped-library3','scoped-birth-pcm3','scoped-stages3','root-regression3','split-rest3']
rows={}
for label in labels:
 receipt=json.loads((s/(label+'.json')).read_text())
 assert 'exit_code' in receipt and receipt['sources_unchanged'] and receipt['binaries_unchanged'],label
 expected=101 if label=='split-rest3' else 0
 assert receipt['exit_code']==expected,(label,receipt['exit_code'])
 text=(s/(label+'.stdout')).read_text()
 counts=re.findall(r'test result: (?:ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out;',text)
 rows[label]={'seconds':round(receipt['seconds'],2),'exit_code':receipt['exit_code'],'test_counts':counts}
assert rows['library3']['test_counts']==[('256','0','0','0','0')]
assert rows['definition3']['test_counts']==[('171','0','0','0','0')]
assert rows['stages-enabled3']['test_counts']==[('203','0','0','0','7')]
assert rows['scoped-library3']['test_counts']==[('237','0','0','0','0')]
assert rows['scoped-birth-pcm3']['test_counts']==[('8','0','0','0','163')]
assert rows['scoped-stages3']['test_counts']==[('203','0','0','0','0')]
assert rows['root-regression3']['test_counts']==[('1','0','0','0','209')]
assert rows['split-rest3']['test_counts']==[('3','3','0','0','204')]
(s/'result-summary.json').write_text(json.dumps(rows,indent=2)+'\n')
print(json.dumps(rows,indent=2))
