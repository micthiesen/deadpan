# Prepared input policy adapters, scratch candidate

Base HEAD bcbc673823b878863f51c6bf905049ab3b2ae22c. Exact inputs are under
before/, final outputs under after/, with SHA-256 manifests. initial.patch and
initial-after/ preserve the first candidate; initial-before-manifest.json and
initial-after-manifest.json preserve its receipts. supplement.patch applies the
O(1) support-probe addition to that initial candidate. candidate.patch and
final.patch are identical complete patches against before/. Final patch SHA-256:
0d896358879a3814375d3f5ce21072e0dd56b61907d1c489c9302687be6bf9e8.

No live checkout edits, Cargo, rustc, provider/native execution, commits or
pushes. Rustfmt +1.97.1 with edition 2024 and skip_children=true parsed all
changed/new files. Tests are supplied for main to compile/run, not claimed
passing here. No runtime population, resource proof, batching, product
acceptance or performance claim.

## API

- policy_ranges::visit(start,frames,ranges,index,charge,emit) is generic over
  typed sample labels. It validates every range with checked subtraction and
  bounds before any emission. Production apply_suppression supplies a no-op
  charge hook and zeroes PCM in the callback, replacing its temporary offset
  Vec with two borrowed walks. All old production control/work boundaries stay
  outside the helper. The index callback is assumed pure, as all current typed
  label callbacks are; it is evaluated again during emission.
- policy_ranges::Support::{Complete,Unsupported} reports final-mask availability.
- PreparedSoundInput, PreparedBeatInput and PreparedRoutedRootQuery each expose
  policy_support(), an O(1) sealed-kind probe before prediction carrier
  allocation/reservation. The visitors share that predicate; root/retained
  classification uses retained_sound_input::policy_support(input). Main bills
  each outer root/occurrence probe. No query, record visit or plan pin is needed.
  Probe Complete does not validate sealed stored raw state; visit handles that.
- PreparedSoundInput::visit_policy(control,emit) forwards Direct signal policy
  via the generic helper, or an existing routed query.
- PreparedBeatInput::visit_policy(samples,control,emit) borrows existing Current
  RootReadQueries through raw_policy, or forwards Routed.
- PreparedRoutedRootQuery::visit_policy(control,emit) walks stored route spans
  and stored prepared retained inputs. There is no route/query reconstruction.
- PreparedRetainedSoundInput::visit_policy(input,control,emit) visits its stored
  raw query, classifying Source and Occurrence silence. The exact leaf-silence
  predicate is shared by occurrence_raw_queries and actual raw Source reading.

All outer emit hooks take Range<AudioSample> and return Result<(),StageAudioError>.
They emit blocked intervals only. Current raw input forwards suppressed and
exhausted intervals; its admitted occurrence constructor has no Original flat
spans. Routed reads intentionally emit suppression only, matching production's
discard of the independent input-exhaustion channel.

Complete is NOT processing eligibility. Direct signal, Current occurrence and
retained Occurrence processing may contain Stage/ProjectedStage/Bound. Their
final policy is available without querying children; Complete grants no native,
source or preparation capability. An outer cold resource gate must inspect or
reject unsupported actual processing boundary forms. In contrast, actual
AudioRoutedRootInput::Projected has no retained policy query in this preparation
representation and returns Unsupported before visiting records/emitting even
route gaps. Nothing silently converts a projected input into suppression.

## Shared production facts

- Generic checked range arithmetic and all-list-before-zeroing operation is
  consumed by existing stages.rs::apply_suppression, including the final typed
  Signal output boundary.
- PreparedRootSpan::delivery supplies the same Gap/Input distinction and missing
  input error for production and metadata paths. Production calls it at the old
  per-span boundary, after its existing check and span count.
- PreparedRootSpan::translate_policy calls the original checked shift_label for
  both labels. The production reader and cold visitor use exactly that method.
- retained_sound_input::is_raw_silence is the production Occurrence suppressed
  selection and raw Source silence match. There is no processing-child union,
  gain/creative-fade evaluation or source-value inference.
- Actual retained source admission still happens before route gaps in the real
  reader. Native/projected preflight/processing is unchanged. Source revocation,
  fingerprint, numeric finite and canonical envelope checks remain owed by PCM.

## Billing and failure

Cold forwarders check WorkControl on entry/exit, including empty inputs. Every
additional generic range validation and emission has its supplied precharge.
Retained cold walks charge each raw span before first-pass classification and
selected-range validation, then each raw span before second-pass classification
and possible emission. Routed cold walks charge each delivery span before
dispatch, each gap emission, and each checked range translation/emission.
Downstream cold input walks bill their own two passes. The exact fixture with
two one-span source inputs and one gap costs eight visits.

Caller carrier writes/storage/query construction need their own billing and
admission. No refund occurs on failure. A late route/child error may follow prior
emissions; discard all observations from that failed visit. The generic typed
range helper completes validation before its first emission, preserving old
all-or-nothing explicit policy PCM zeroing. Callback failure can leave partial
metadata and must also discard it.

The production path has no new work charge or control check and no whole
extra query traversal. It uses the shared operations at old boundaries.

## Tests included (not run here)

Three policy_ranges tests cover late invalid range before any PCM/metadata
mutation, signed labels/order/duplicates and retained validation work on a
callback error.

Five routed/policy_tests tests reuse real Plan constructors and the existing
real-WAV provider fixture, collecting cold observations separately from actual
successful reader masks. They cover root Source/Occurrence route gaps and source
support tail, Direct/current occurrence forwarding, exact/one-short budgets,
partial observations and cancellation, an actual publicly admitted signed
Projected root returning Unsupported without observations/work, and exact signed
route translation/overflow. Signed translation is an arithmetic helper test;
supported raw Source constructors themselves require the absolute root grid.
No test treats premarked OR bits as its own oracle.

The new nested test module is declared by three lines appended to existing
routed/tests.rs. Do not replace the live file wholesale. Main owns integration
with other worker's stages.rs query-preparation changes and immediate producer
callers, so no dead_code expectations were added.
