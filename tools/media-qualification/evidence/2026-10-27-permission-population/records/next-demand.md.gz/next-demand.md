# Next unit: share the owner-phase driver

Read-only design, 2026-10-27. No compiler, Cargo, repository edits or batching.
There is no member_phases.rs in the current Audio tree or task scratch
candidates. Parent confirmed visitors.rs and policy.rs are the actual helpers.

## Preferred production change

Extract one common owner-body procedure into a new private
shared_components/member_phases.rs, with explicit extents Block and Sample(at).
Both numerical engines must call it. Add the cold consumer to that same
procedure rather than maintaining a second owner/stage walker.

The common nesting already exists:

    owner:
        ordered dry stages:
            stage's samples:
                ordered admitted members / EQ callbacks
        owner's tail sends
        ordered wet members:
            member's samples:
                Reverb callback, then Delay callback

Constant execution calls this body once per owner with Block. Dynamic execution
calls it once per owner with Sample(at), inside its sample loop. Move those
small outer-order adapters into the same module: Block means owners; Dynamic
means samples then owners. Do not normalize the two orders.

Current anchors:
- shared_components.rs::finish_into: route Program preparation and mode dispatch
  at 390..435; dynamic sample/owner/stage nesting at 436/467/485; EQ visit at 532;
  wet owner/member phase at 605/638; output finalization follows it.
- block.rs::finish_constant_into at 71: initial sends; owner/stage nesting at
  101/104; whole-block transfer before samples; EQ visit at 169; tail sends at
  221; wet member/sample nesting at 240/258 and visit at 277.
- visitors.rs::visit_equalizer and visit_wet_effects remain shared emitters.
  Requests borrow the existing phase clock; do not clone for every member.

## API and numerical boundaries

Prefer a scoped procedure with numerical continuations, not an Iterator of
precomputed demands. Inputs: actual mutable Components, execution extent, owner
identity, policy-carrier selector, WorkControl and private numerical executor.
The common procedure owns structural eligibility, stage/sample/member order,
masks, clock choice and invocation of the existing temporal visitors.

Move current numerical blocks into private executor methods with unchanged
bodies: initial sends/sample gain initialization; owner gain entry; constant
stage-block flush; shared-stage preparation and saturation; dynamic memoryless
gain updates; tail sends; wet-route preparation/dry flush/returned-sample
application; dynamic output finalization. Numerical methods return errors
synchronously. The driver advances only after they succeed.

A cold executor skips numerical operations and folds each real TemporalDemand.
It assumes numeric success: numerical failure can shorten the real schedule.
It does not inspect amplitude/mute, prepare gains or invoke fake providers/PCM.
Keep an explicit fallible numerical barrier before EQ emission and before/after
every wet callback. Failure applying a wet return must stop before the next
effect. Dynamic output failure must stop before the next sample.

Constant wet needs a SCOPED continuation: current Program::take,
next_transfers(count), borrowed transfer slice and Program restoration surround
the entire route's sample loop. Invoke the common wet-sample traversal INSIDE
that lexical bracket. Do not make a request iterator that borrows this state
across arbitrary advancement, or fetch checkpoints anew per sample. A concrete
private helper receiving the sample-loop closure is sufficient; a generic
public execution framework is unnecessary.

Merely yielding owner/stage indices while numerical and cold engines separately
walk samples/members would not share complete callback order. Moving finite
checks into a policy helper would also be wrong.

## Exact invariants to retain

- Dynamic checks the owner's sample mask before entering stages. Constant checks
  stage kind and flushes a whole block before sample-mask checks.
- Constant skips memoryless stages here because Program checkpoints include
  them. Dynamic applies those stages to each nonconstant route's GainSum.
- Constant runtime wet requires Program Some. Cold equivalence is structurally
  constant AND at least one planned permission bit; it must not evaluate gains.
- Dynamic wet_context combines mask/clock in one owner/sample walk, even before
  finding a member's sends. Constant retains separate mask and first-clock
  walks per eligible route/sample after its block flush. Preserve existing
  clock clone count and relative checks.
- Owner ancestry/order, skipped stages, stop-derived wet=false, stage cuts and
  later explicit Tail exclusion for Original use actual prepared metadata.
- All permitted driver voices remain, independent of selected output. Distinct
  output alias masks and route-order terminal sums stay separate; final gain
  remains lazy for selected routes.
- No gain/PCM value or mute influences structural demand.

Expose the existing pure Program::constant predicate privately for cold mode
selection; do not replicate its ClipGain envelope/mute-range test. Cold activity
comes from completed planned rows, not unset event_gain/program. Scan actual
carrier words once with additional work billed, then select exactly
all-inactive-or-constant. Treating every route as active is wrong: an inactive
dynamic route would switch other routes' otherwise-constant callback order.
After successful add/verification, any permission bit iff event_gain Some.
An earlier finite error may set event_gain but aborts before finish.

Validate carrier shape AND completed population at the cold entry. Allocated
all-false storage alone is not completion. Current begin_prediction /
predict_range / verify_prediction separate planned and observed carriers;
finish_into rightly rejects a pending prediction. A narrow borrowed planned
view may be used after the actual local producer finishes, without letting
numerical finish accept unverified prediction or public unchecked completion.
Keep independent positive-and-negative observation verification later.

## Independent literal oracle

Two samples 100/101; one owner with nonunity EQ and Reverb+Delay; routes in
insertion order VOICES 5 and 2, both admitted at both samples. Select only output
voice 2, proving voice5 remains a driver. All dry/wet masks are {5,2}; clock is
the exact first admitted route5 clock.

Literal (kind,sample,voice) expectations:

Block:
  EQ100/5, EQ100/2, EQ101/5, EQ101/2,
  Rev100/5, Delay100/5, Rev101/5, Delay101/5,
  Rev100/2, Delay100/2, Rev101/2, Delay101/2.

Dynamic:
  EQ100/5, EQ100/2, Rev100/5, Delay100/5, Rev100/2, Delay100/2,
  EQ101/5, EQ101/2, Rev101/5, Delay101/5, Rev101/2, Delay101/2.

Use independently authored constant versus envelope-bearing ClipGain fixtures
to choose modes. Compare both real numerical and cold traces to those literal
vectors, not to another helper-generated expected trace. Route5 inactive at101
must remove its101 calls, change101 masks to {2}, and choose route2's clock.
An Original route5 with a later explicit Tail keeps dry masks {5,2} but wet
masks {2}; stop/skip remove only their actual phases. Retain independent PCM
oracles, including mixed constant/nonconstant routes.

Failure cases: first shared-stage numerical preparation fails => zero EQ calls;
first wet-result application fails => no Delay or later callbacks; cancel or
one-short inspection budget => exact emitted prefix and actual spent work.
Cold fixtures leave PCM empty and never open media. These tests establish
sequencing, not source admission or recursive resource closure.

## Ownership, work and remaining resource inputs

Borrow only current route/owner metadata and completed flags. Retain no plan
Arc, query, PCM, native state, callback result or context beyond the synchronous
visit. Reuse the existing owner-order allocation once; any additional cold
order/index storage needs its actual metadata peak admitted. Measure the small
extent/executor header rather than claiming zero memory.

Existing numerical checks/spends stay at their old points. Existing replacement
visits retain noop inspection hooks; additional cold walks charge each actual
owner/stage/member/effect/word inspection BEFORE inspection, including inactive
and absent probes, with no refunds. Fold demands synchronously; allocating a
Vec of all requests would be new retention and is outside this unit.

TemporalDemand's clock/kind/stage/sample/mask/voice are insufficient to close
recursive allocation. The caller still needs actual Graph plan/context and
parent/node identity, raw clock/range/halo rules, source contracts,
selected-family/alias state, depth, stop/send/skip, and cold-versus-cache-hit
required reservations. This extraction creates no new authority and no batch
admission. Unknown forms retain explicit scalar fallback before speculative
prefix work. Native ownership, current caps and resource ledger stay unchanged.

This is the next focused sequencing extraction. Current pre-PCM permission
population and existing per-phase visitors do not yet implement the complete
cold driver or prove recursive residency.
