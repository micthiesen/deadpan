from pathlib import Path
import hashlib,json,gzip
s=Path(__file__).resolve().parent
repo=Path('/Users/michael/Code/deadpan')
dest=repo/'tools/media-qualification/evidence/2026-10-27-permission-population'
assert not dest.exists(),'Archive once final receipts are terminal'
for p in s.glob('*.json'):
 r=json.loads(p.read_text())
 if isinstance(r,dict) and 'command' in r and 'started_at' in r:
  assert 'exit_code' in r and r['sources_unchanged'] and r['binaries_unchanged'],p.name
allowed={'.rs','.json','.py','.md','.patch','.stdout','.stderr','.txt'}
payloads=[p for p in s.rglob('*') if p.is_file() and p.suffix in allowed and p.name != 'qualification-draft.md']
entries=[]
for p in sorted(payloads):
 relative=p.relative_to(s);out=dest/'records'/str(relative)
 out=out.with_name(out.name+'.gz');out.parent.mkdir(parents=True,exist_ok=True)
 data=p.read_bytes();compressed=gzip.compress(data,mtime=0);out.write_bytes(compressed)
 entries.append({'path':str(out.relative_to(dest)),'bytes':len(compressed),'sha256':hashlib.sha256(compressed).hexdigest(),'expanded_bytes':len(data),'expanded_sha256':hashlib.sha256(data).hexdigest()})
manifest={'schema_version':1,'base_revision':(s/'base-revision.txt').read_text().strip(),'scope':'Nineteen-file production current-chunk permission prediction before contribution PCM; independent observed whole-row comparison; Original request reuse; 23 published new tests. Main additionally qualifies inherited cache adapter and two tests, left as WIP. No batching or recursive cold resource proof. All published source bytes equal isolated and staged bytes. Main baseline and isolated source guards retained.','prior_runtime_evidence':{'path':'../2026-10-27-audio-policy-visits/inventory.json','inventory_sha256':'a1b8f5e4ff5c94cb0af6de2edfcaad81c45f9bce12a9ef0cf1a9330bc0006922'},'files':entries}
file=dest/'inventory.json';file.write_text(json.dumps(manifest,indent=2)+'\n')
stored=expanded=0
for item in entries:
 data=(dest/item['path']).read_bytes();plain=gzip.decompress(data)
 assert len(data)==item['bytes'] and hashlib.sha256(data).hexdigest()==item['sha256']
 assert len(plain)==item['expanded_bytes'] and hashlib.sha256(plain).hexdigest()==item['expanded_sha256']
 stored+=len(data);expanded+=len(plain)
print(json.dumps({'files':len(entries),'stored_bytes':stored,'expanded_bytes':expanded,'inventory_sha256':hashlib.sha256(file.read_bytes()).hexdigest()}))
