from pathlib import Path
import json,difflib,hashlib
s=Path(__file__).resolve().parent
q=Path('/tmp/deadpan-query-groundwork-2026-10-26/scoped')
r=Path('/Users/michael/Code/deadpan')
c=json.loads((s/'changed-files.json').read_text())
omit={'crates/deadpan-audio/src/shared_eq/original_inputs.rs','crates/deadpan-audio/src/shared_eq/original_inputs_tests.rs','crates/deadpan-audio/src/shared_eq/prepared_input_tests.rs'}
parts=[];comparison=[];live=[]
index={}
for line in (s/'index-files.txt').read_text().splitlines():
 meta,p=line.split('\t',1);mode,sha,stage=meta.split();assert stage=='0';index[p]=(mode,sha)
equal=[]
for name in c['changed']+c['added']:
 before=(s/'before'/name).read_text() if name in c['changed'] else ''
 after=(r/name).read_text()
 live.extend(difflib.unified_diff(before.splitlines(True),after.splitlines(True),fromfile='a/'+name,tofile='b/'+name))
 if name in omit:continue
 before=s/'published-before'/name.removeprefix('crates/deadpan-audio/src/')
 a=before.read_text() if name in c['changed'] else ''
 data=(q/name).read_bytes();b=data.decode()
 parts.extend(difflib.unified_diff(a.splitlines(True),b.splitlines(True),fromfile='a/'+name,tofile='b/'+name))
 comparison.append({'path':name,'main_sha256':hashlib.sha256((r/name).read_bytes()).hexdigest(),'published_sha256':hashlib.sha256(data).hexdigest(),'equal':(r/name).read_bytes()==data})
 blob=hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()
 assert index[name][1]==blob,name
 equal.append({'path':name,'index_blob_sha1':blob,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest(),'published_equals_index':True})
(s/'final-published.patch').write_text(''.join(parts))
(s/'final-live.patch').write_text(''.join(live))
(s/'published-main-comparison.json').write_text(json.dumps(comparison,indent=2)+'\n')
(s/'published-index-equality.json').write_text(json.dumps(equal,indent=2)+'\n')
(s/'published-shared_eq.rs').write_bytes((q/'crates/deadpan-audio/src/shared_eq.rs').read_bytes())
for label,basefile,finalfile,root in [('main','before-manifest.json','source-frozen.json',r),('scoped','scoped-before-manifest.json','scoped-source-frozen.json',q)]:
 def normalize(m):return {k.removeprefix(str(root)+'/'):v for k,v in m.items()}
 before=normalize(json.loads((s/basefile).read_text()));after=normalize(json.loads((s/finalfile).read_text()))
 changed=[p for p in sorted(before.keys()&after.keys()) if before[p]!=after[p]]
 added=sorted(after.keys()-before.keys());removed=sorted(before.keys()-after.keys())
 assert not removed,removed
 for p,v in after.items():
  f=root/p;assert f.stat().st_size==v['bytes'] and hashlib.sha256(f.read_bytes()).hexdigest()==v['sha256'],p
 (s/(label+'-lineage.json')).write_text(json.dumps({'base_count':len(before),'final_count':len(after),'changed':changed,'added':added,'removed':removed,'all_current_bytes_match':True},indent=2)+'\n')
 print(label,'changed',len(changed),'added',len(added),'frozen',len(after))
print('Published source matches isolated + staged:',len(equal))
