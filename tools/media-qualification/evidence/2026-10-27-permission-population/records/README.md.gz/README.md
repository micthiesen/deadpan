# Current-chunk permission population qualification

Base: bcbc673823b878863f51c6bf905049ab3b2ae22c.
Main: /Users/michael/Code/deadpan.
Published comparison: /tmp/deadpan-query-groundwork-2026-10-26/scoped.

final-published.patch is the independently publishable 19-file change. Its source
matches the isolated build and staged index byte for byte. The main working tree
retains inherited Split/index work and its Original cache. The focused-integration
patch additionally adapts that private cache and adds two cache-specific tests.
Those cache files and inherited work are not part of the published change.
beat_sounds.rs, shared_eq.rs and stages.rs have inherited main overlays; compare
published-main-comparison.json and published-index-equality.json.

The production Components path predicts current input permissions before
contribution PCM allocation. It admits a distinct predicted payload alongside
actual observations, then compares all packed words after successful input
reads, including untouched negatives. Actual sample producers never mark the
predicted carrier or read predictions as permission. A mismatch refuses finish.
After success, release only the dropped predicted payload capacity. The inline
header remains accounted. The comparison precedes common owner callbacks through
mix.finish; event-return input preparation already happened. This is not proof
of cold recursive resource eligibility and does not enable batching.

Original Root/Domain preparation is sealed to exact plan/context pointer, range
and fade mode. One query supplies metadata and the actual read on a miss. Main
cache hits add genuine billed query work and still re-admit dependencies.
Context::Retained and actual Projected inputs use explicit unsupported-policy
fallback. A final-policy-complete child is not a native preparation exemption.

Receipts pin commands, exact source and binary identities, stdout, stderr,
elapsed times and terminal exits. Source guards cover 1,417 main / 1,188 isolated
inputs. Source lineage captures only the expected 13 changed + nine added main
files and 11 changed + eight added published files. Removed rejected experiments
remain absent.

Retained failures:
- build: one test-only ambiguous generic AudioSoundRoute::new call; explicit
  AudioSample specialization fixes compilation without weakening assertions.
- scoped-build: an orchestration continuation ran the unchanged prior published
  baseline after a patch-generation uniqueness assertion failed. It is not a
  qualification build of this change. scoped-build2 is the first successfully patched, guarded build; build3 and
  scoped-build3 include the reviewed unselected-row cost correction. The observed diagnostic is recorded in transfer-generation-failure.md;
  corrected publish_scoped.py is retained.
- split-matrix: initial three-pass/four-failure matrix, including a new
  processed-root work-limit regression. Avoiding metadata inspection for
  provably unselected rows restores that targeted case at unchanged limits
  (root-regression3). split-rest3 covers the other six final cases. No performed
  work is refunded and no cache, limit increase or failed-batch retry is added.

Independent review is scratchreview.md. Any next-demand.md is read-only research,
not implementation or acceptance evidence. Binary bytes are not archived; exact
Cargo JSON inventories and copied-executable SHA-256 pins are retained. Archive
records use deterministic gzip and include stored/expanded hashes.
