# Observed transfer-generation failure

This is a recorded diagnostic from the tool result, not a saved process stream.
The initial inline Python generator required a globally unique exact replacement:

    replace('        let reservation = u64::from(frames)', ...)

The replacement helper asserted uniqueness and returned:

    AssertionError: ('        let reservation = u64::from(frames)', 2)

The generator failed before applying either patch to the isolated tree. The next
commands in the exec orchestration continued, refreshed the old isolated source
manifest and launched scoped-build against the unchanged prior baseline. Its
terminal receipt/source hashes preserve exactly what actually built; it is not
qualification of the new change.

The corrected publish_scoped.py uses the output-alias + reservation block as its
unique anchor, dry-runs both patches, asserts each result, applies them, formats
the file and freezes the full isolated source. scoped-build2 then qualifies that
first patched source. scoped-build3 qualifies the later unselected-row fix.

No failed context patch was blindly retried, no live source or unrelated WIP
was restored/reset, and no baseline build is counted as a passing new build.
