from pathlib import Path
import difflib,subprocess,json,hashlib
s=Path('/tmp/deadpan-permission-population-2026-10-27')
r=Path('/Users/michael/Code/deadpan')
q=Path('/tmp/deadpan-query-groundwork-2026-10-26/scoped')
name='crates/deadpan-audio/src/shared_eq.rs'
old=(s/'published-shared_eq.rs.before').read_text()
live=(r/name).read_text()
out=old
def replace(a,b):
 global out
 assert out.count(a)==1,(a[:100],out.count(a))
 out=out.replace(a,b)
replace('use event_returns::{EventKey, EventRead, EventSource};','use event_returns::{EventKey, EventRead, EventSource};\n\n#[path = "shared_eq/policy_prediction.rs"]\nmod policy_prediction;')
pre=live[live.index('        let predict ='):live.index('        let mut reservation =')]
anchor='''            mix.include_output_aliases(split_family_aliases(&families, selected, control)?);
        }
        let reservation = u64::from(frames)'''
replace(anchor,anchor.replace('        let reservation = u64::from(frames)',pre+'        let mut reservation = u64::from(frames)'))
a=out.index('        let result = (|| {',out.index('        let predict ='))
b=out.index('                let raw = match &program.context.original {',a)
la=live.index('        let result = (|| {',live.index('        let predict ='))
lb=live.index('                let raw = if let Some(request)',la)
replace(out[a:b],live[la:lb])
a=out.index('                let raw = match &program.context.original {',a)
b=out.index('                for (span, route)',a)
match=out[a:b].replace('                let raw = match','                    match',1)
match='\n'.join('    '+line if i>0 else line for i,line in enumerate(match.rstrip().split('\n')))
match=match.rsplit('};',1)[0]+'}\n'
new='''                let raw = if let Some(request) = prepared_original.take() {
                    policy_prediction::validate_original(
                        &request,
                        &program.context.original,
                        plan,
                        original_range.start,
                        count(&original_range)?,
                        control,
                    )?;
                    self.read_prepared_original(provider, request, control, program.depth)?
                } else {
'''+match+'''                };
'''
replace(out[a:b],new)
a=live.index('                            let allow = policy_prediction::original_allowed(')
b=live.index('                            mix.add(',a)
replace('''                            let allow = admitted(original_id)
                                && span.support() == AudioOwnerSupport::Active
                                && permitted(&raw, AudioSample(sample));
''',live[a:b])
a=live.index('            let released = mix.verify_prediction(control)?;')
b=live.index('            let mixed = mix.finish',a)
replace('            let mixed = mix.finish',live[a:b]+'            let mixed = mix.finish')
a=live.index('            let allowed = policy_prediction::sound_allowed(')
b=live.index('            let value =',a)
aold=out.index('            let allowed = if span.length != 0')
bold=out.index('            let value =',aold)
replace(out[aold:bold],live[a:b])
patch=''.join(difflib.unified_diff(old.splitlines(True),out.splitlines(True),fromfile='a/'+name,tofile='b/'+name))
(s/'transfer-shared-eq.patch').write_text(patch)
for patchname in ['transfer-independent.patch','transfer-shared-eq.patch']:
 p=s/patchname
 dry=subprocess.run(['patch','--dry-run','-p1','-i',str(p)],cwd=q,capture_output=True,text=True)
 assert dry.returncode==0,(dry.stdout,dry.stderr)
 actual=subprocess.run(['patch','-p1','-i',str(p)],cwd=q,capture_output=True,text=True)
 assert actual.returncode==0,(actual.stdout,actual.stderr)
 print(actual.stdout)
subprocess.run(['rustfmt','--edition','2024','--config','skip_children=true',str(q/name)],check=True)
(s/'published-shared_eq.rs').write_bytes((q/name).read_bytes())
files=set(json.loads((s/'scoped-source-files.json').read_text()))
files.update(str(p.relative_to(q)) for p in (q/'crates/deadpan-audio/src').rglob('*.rs'))
(s/'scoped-source-files.json').write_text(json.dumps(sorted(files),indent=2)+'\n')
frozen={str(q/p):{'bytes':(q/p).stat().st_size,'sha256':hashlib.sha256((q/p).read_bytes()).hexdigest()} for p in sorted(files)}
(s/'scoped-source-frozen.json').write_text(json.dumps(frozen,indent=2)+'\n')
print('scoped sources',len(frozen))
