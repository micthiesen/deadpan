from pathlib import Path
import json,subprocess,hashlib
s=Path(__file__).resolve().parent
for variant in ['scoped','main']:
 build=f'native-fixture-{variant}-final-native-build'
 pins=json.loads((s/(build+'-pins.json')).read_text())
 artifacts=[]
 for line in (s/(build+'.stdout')).read_text().splitlines():
  try:value=json.loads(line)
  except ValueError:continue
  if value.get('reason')=='compiler-artifact'and value.get('executable'):artifacts.append(value)
 helpers={a['target']['name']:a['executable']for a in artifacts if not a['profile']['test']and a['target']['name']in ['deadpan-track','deadpan-media-worker']}
 assert len(helpers)==2
 track=next(p for p in pins if p['package']=='track'and p['name']=='worker')
 data=Path(track['path']).read_bytes()
 for row in json.loads((s/'embedded-fixture-pins.json').read_text()):
  root=Path('/Users/michael/Code/deadpan')if variant=='main'else Path('/tmp/deadpan-query-groundwork-2026-10-26/scoped')
  fixture=(root/row['path']).read_bytes()
  assert hashlib.sha256(fixture).hexdigest()==row['sha256']and fixture in data,row['path']
 proof={'variant':variant,'worker_binary_sha256':track['sha256'],'fixtures_embedded_exact':json.loads((s/'embedded-fixture-pins.json').read_text()),'helpers':{name:{'path':path,'sha256':hashlib.sha256(Path(path).read_bytes()).hexdigest()}for name,path in helpers.items()}}
 (s/f'native-fixture-{variant}-embedded-input-proof.json').write_text(json.dumps(proof,indent=2)+'\n')
 runner=s/('run_qualified.py'if variant=='main'else 'run_scoped_qualified.py')
 for package,target,suffix,args in [
 ('track','worker','tracking',['--test-threads=1']),
 ('media-worker','extension_quality','extension-geometry',['geometry::','--test-threads=1'])]:
  pin=next(p for p in pins if p['package']==package and p['name']==target)
  label=f'native-fixture-{variant}-{suffix}'
  guards=[pin['path'],*helpers.values(),'/opt/homebrew/bin/ffmpeg']
  command=['python',str(runner)]
  for binary in guards:command+=['--binary',binary]
  command+=[label,'--',pin['path'],*args]
  subprocess.run(command,check=True)
