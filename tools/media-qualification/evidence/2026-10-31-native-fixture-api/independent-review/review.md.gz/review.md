# Separate native fixture API follow-up

Preferred fixes are in minimal.patch and exact candidate files under new/.
Neither root was edited; no build, native run, Git operation, fixture capture,
or generation was performed. Current target files are byte-identical between
Main and Scope, and both initial target hashes are recorded in source-pins.json.
The parent's earlier B initial pins establish that these fixtures were untouched
by B; this review does not independently claim Git-history provenance.

## Selected extension geometry

Append `.into()` to the existing TargetRegion literal at selected.rs125.
Core target/geometry.rs defines From<TargetRegion> for TargetGeometry as exactly
TargetGeometry::Region(value). The center500000,500000 and size333333,333333
are retained exactly. Region serialization preserves the same center/size
object, and this conversion does not create a Point, change target selection,
or invent dimensions. No import change is needed.

## Saved tracking Follow centering

Add `centering: deadpan_core::FollowCentering::Unconstrained` to the existing
Follow literal at worker.rs517. This is an explicit existing policy, not an
invented default. Core declares Unconstrained as the compatibility default and
omits it from serialized Follow values. Core's centering tests establish old
wire compatibility and that Unconstrained leaves the live center unchanged.

The native test itself expects FramingPose::new(x,y,scale2) directly from the
saved target for frames0,5,10, with identity fallback after the cut. Its generated
frame0 target center is58/320 in x, below the scale2 CanvasClamped margin1/4.
CanvasClamped would move that center to80/320 and violate the test's explicit
expectation. Unconstrained therefore preserves its measured intent; choosing
CanvasClamped would change the fixture behavior. Fallback remains unchanged.

## Follow-up verification

Keep this outside B's publication. After applying the two tiny edits, repeat
the workspace all-target compile that exposed the errors. Then run the existing
media-worker extension-quality geometry tests and the native tracking test
`a_saved_target_reloads_follows_in_the_plan_and_corrects_only_its_range` on the
qualified host, under the repository's required native validation procedure.
These existing tests already exercise actual selected geometry and resolved
centering; no new mirror test is warranted for these constructor repairs.

The missing Scope encoded-manifest.json is independent. No replacement was
generated or proposed here; parent restoration must use exact published bytes.
