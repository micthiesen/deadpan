use std::collections::BTreeMap;

use deadpan_core::{
    BeatNode, Command, CommandRequest, EndpointPolicy, ExactRatio, FrameDuration, HoldAudio,
    HoldRecipe, HoldVideo, NodeId, ProjectDocument, ProjectId, RevisionId, SourceVideoMapping,
    Subtree,
};
use deadpan_media::audio_session::{AudioSession, AudioSessionLimits};
use deadpan_media::source_input::VerifiedSourceInput;
use deadpan_media::source_qualification::DecodedSourceQualification;
use deadpan_plan::RenderPlan;
use deadpan_store::ProjectStore;
use deadpan_store::original_media::OriginalOwnership;
use deadpan_store::source_registration::{
    SourceInsertionPurpose, SourceInsertionRequest, SourceRegistration,
};

use super::*;

#[path = "proposed_tests.rs"]
mod proposed_tests;

#[path = "edited_slice_tests.rs"]
mod edited_slice_tests;

#[path = "proxy_tests.rs"]
mod proxy_tests;

#[path = "stress_tests.rs"]
mod stress_tests;

#[path = "lookahead_tests.rs"]
mod lookahead_tests;

#[path = "generated_playback_tests.rs"]
mod generated_playback_tests;

#[test]
fn interpretation_changes_invalidate_reused_original_and_edit_decoders() {
    use deadpan_core::{SourceColorRange, SourceInterpretation};
    let mut fixture = Fixture::source("hevc-sdr-8-limited.mp4");
    let before = fixture.workspace(1);
    let active = AtomicBool::new(false);
    let mut retained = None;
    let mut picture = |workspace: &Arc<Workspace>, view: ProjectView| {
        project_picture(
            workspace,
            &workspace.document,
            &workspace.plan,
            &view,
            &active,
            &mut retained,
        )
        .unwrap()
        .frame
        .unwrap()
    };
    let original = picture(&before, source(2));
    let choice = SourceInterpretation {
        range: Some(SourceColorRange::Full),
        chroma_location: None,
    };
    fixture
        .store
        .commit(&CommandRequest {
            project_id: before.document.project_id().clone(),
            expected_revision: before.document.revision_id().clone(),
            new_revision: revision("interpreted"),
            command: Command::SetSourceInterpretation {
                asset: asset(),
                interpretation: Some(choice),
            },
        })
        .unwrap();
    let mut corrected = fixture.workspace(1);
    // Source catalog entries legitimately survive authored revisions.
    Arc::get_mut(&mut corrected).unwrap().sources = before.sources.clone();
    let corrected_source = picture(&corrected, source(2));
    assert_ne!(corrected_source.bytes(), original.bytes());
    assert_eq!(corrected_source.metadata(), original.metadata());
    assert_eq!(
        picture(&corrected, sequence(2)).bytes(),
        corrected_source.bytes()
    );
    assert_eq!(picture(&before, source(2)).bytes(), original.bytes());
    assert_eq!(
        picture(&corrected, source(2)).bytes(),
        corrected_source.bytes()
    );
    fixture
        .store
        .undo(&revision("interpreted"), revision("undo"))
        .unwrap();
    assert_eq!(
        picture(&fixture.workspace(1), source(2)).bytes(),
        original.bytes()
    );
}

#[test]
fn generated_decoder_identity_preserves_edits_but_rechecks_media_interpretation() {
    use deadpan_core::{
        AssetRecord, BridgeInterpolation, BridgeSamplingMap, GeneratedArtifact, GeneratedContentId,
        GeneratedObjectRef, SourceSpan, SourceTimeBase,
    };

    let object = |digit: char| {
        GeneratedObjectRef::new(
            GeneratedContentId::new(digit.to_string().repeat(64)).unwrap(),
            1024,
        )
        .unwrap()
    };
    let artifact = Arc::new(GeneratedArtifact {
        native_asset: AssetId::new("native").unwrap(),
        native_object: object('a'),
        sampled_asset: AssetId::new("sampled").unwrap(),
        sampled_object: object('b'),
        provenance: object('c'),
        sampling: BridgeSamplingMap::new(
            deadpan_core::FrameRate::new(30, 1).unwrap(),
            deadpan_core::FrameRate::new(24, 1).unwrap(),
            FrameDuration::new(25).unwrap(),
            FrameDuration::new(30).unwrap(),
            BridgeInterpolation::EncodedSrgbRgb8LinearHalfUp,
        )
        .unwrap()
        .into(),
        content_aspect: None,
    });
    let initial = ProjectDocument::new(
        ProjectId::new("generated-key").unwrap(),
        revision("before"),
        deadpan_core::PresentationBasis {
            width: 1920,
            height: 1080,
            frame_rate: deadpan_core::FrameRate::new(30, 1).unwrap(),
            color_policy: deadpan_core::ColorPolicy::SdrRec709,
        },
        node("root"),
    )
    .unwrap();
    let mut wire = serde_json::to_value(&initial).unwrap();
    let clock = SourceTimeBase::new(1, 1000).unwrap();
    for (asset, object, count, end) in [
        (&artifact.native_asset, &artifact.native_object, 25, 1041),
        (&artifact.sampled_asset, &artifact.sampled_object, 30, 1000),
    ] {
        wire["assets"][asset.as_str()] = serde_json::to_value(AssetRecord {
            label: "Generated".into(),
            content_hash: object.content().to_string(),
            video: Some(
                SourceSpan::new(
                    SourceTimestamp {
                        ticks: 0,
                        time_base: clock,
                    },
                    SourceTimestamp {
                        ticks: end,
                        time_base: clock,
                    },
                )
                .unwrap(),
            ),
            audio: None,
            still_image: false,
            frame_count: Some(FrameDuration::new(count).unwrap()),
            source_qualification: None,
        })
        .unwrap();
    }
    let key = |wire: &serde_json::Value| {
        GeneratedMediaKey::new(
            &ProjectDocument::from_json(&wire.to_string()).unwrap(),
            &artifact,
        )
        .unwrap()
    };
    let before = key(&wire);
    wire["revision_id"] = serde_json::json!("after");
    wire["nodes"]["root"]["label"] = serde_json::json!("Revised group");
    wire["presentation_basis"]["width"] = serde_json::json!(1280);
    assert_eq!(
        before,
        key(&wire),
        "editorial revision/canvas changes reuse media"
    );
    for asset in [&artifact.native_asset, &artifact.sampled_asset] {
        let mut changed = wire.clone();
        changed["assets"][asset.as_str()]["frame_count"] = serde_json::json!(31);
        assert_ne!(before, key(&changed), "changed {asset} must be readmitted");
    }
    wire["presentation_basis"]["color_policy"] = serde_json::json!("hdr_rec2020_pq");
    assert_ne!(before, key(&wire), "HDR cannot reuse an SDR admission");
}

#[test]
fn index_validation_observes_cancellation_between_bounded_chunks() {
    let make = |last_keyframe| {
        SourceFrameIndex::new(
            asset(),
            deadpan_core::SourceTimeBase::new(1, 30).unwrap(),
            (0..4096)
                .map(|i| deadpan_core::IndexedSourceFrame {
                    identity: SourceFrameId(i as u64),
                    pts: i,
                    reported_duration: Some(1),
                    keyframe: i == 0 || (i == 4095 && last_keyframe),
                    seek_from: Some(SourceFrameId(0)),
                    decode_timestamp: Some(i),
                })
                .collect(),
            4096,
            deadpan_core::TerminalProvenance::Explicit,
        )
        .unwrap()
    };
    let left = make(false);
    let mut polls = 0;
    let error = same_index_mapping(&left, &left, || {
        polls += 1;
        polls == 3
    })
    .unwrap_err();
    assert!(error.contains("cancelled"));
    assert_eq!(polls, 3);
    assert!(same_index_mapping(&left, &left, || false).unwrap());
    assert!(!same_index_mapping(&left, &make(true), || false).unwrap());
}

pub(super) struct Fixture {
    scratch: tempfile::TempDir,
    store: ProjectStore,
}

impl Fixture {
    fn empty() -> Self {
        let scratch = tempfile::tempdir().unwrap();
        let document = ProjectDocument::new_automatic(
            ProjectId::new("worker-project").unwrap(),
            revision("initial"),
            node("root"),
        )
        .unwrap();
        let store =
            ProjectStore::create(&scratch.path().join("preview.deadpan"), &document).unwrap();
        Self { scratch, store }
    }

    pub(super) fn source(name: &str) -> Self {
        Self::with_source(Self::empty(), name)
    }

    fn with_source(mut fixture: Self, name: &str) -> Self {
        let cancelled = AtomicBool::new(false);
        let limits = OriginalMediaLimits::default();
        let path = PathBuf::from(env!("CARGO_MANIFEST_DIR"))
            .join("../../native/deadpan-source/tests/fixtures")
            .join(name)
            .canonicalize()
            .unwrap();
        let original = fixture
            .store
            .retain_original(&path, OriginalOwnership::Managed, limits, &cancelled)
            .unwrap()
            .record;
        let mut snapshot = fixture
            .store
            .snapshot_original(original.object().content(), limits, &cancelled)
            .unwrap();
        let input = VerifiedSourceInput::copy_verified(
            &mut snapshot,
            SourceContentIdentity::new(original.sha256(), original.object().byte_length()).unwrap(),
            2_000_000,
            Duration::from_secs(10),
            &cancelled,
        )
        .unwrap();
        let video = SourceSession::open_input(
            input.clone(),
            asset(),
            SourceSessionLimits::default(),
            &cancelled,
        )
        .unwrap();
        let audio = video.info().audio_streams.first().map(|stream| {
            AudioSession::open_input(
                input,
                stream.stream_index,
                AudioSessionLimits::default(),
                &cancelled,
            )
            .unwrap()
        });
        let decoded =
            DecodedSourceQualification::from_sessions(Some(&video), audio.as_ref()).unwrap();
        fixture
            .store
            .register_source(
                &SourceRegistration {
                    expected_revision: revision("initial"),
                    new_revision: revision("registered"),
                    original: original.object().content().clone(),
                    new_asset_id: asset(),
                    label: name.into(),
                    insertion: Some(SourceInsertionRequest {
                        parent: node("root"),
                        index: 0,
                        node: node("source"),
                        label: "Full source".into(),
                        purpose: SourceInsertionPurpose::Primary,
                    }),
                },
                &decoded,
                None,
                limits,
                &cancelled,
            )
            .unwrap();
        fixture
    }

    pub(super) fn workspace(&self, session: u64) -> Arc<Workspace> {
        workspace_of(
            &self.store,
            session,
            self.scratch.path().join("preview.deadpan"),
        )
    }

    fn append_hold(&mut self, name: &str, index: usize, video: HoldVideo) {
        let document = self.store.snapshot().unwrap();
        self.store
            .commit(&CommandRequest {
                project_id: document.project_id().clone(),
                expected_revision: document.revision_id().clone(),
                new_revision: revision(name),
                command: Command::Insert {
                    parent: node("root"),
                    index,
                    subtree: Subtree {
                        root: node(name),
                        nodes: BTreeMap::from([(
                            node(name),
                            BeatNode::hold(
                                name,
                                HoldRecipe {
                                    picture_context: None,
                                    duration: FrameDuration::new(3).unwrap(),
                                    video,
                                    audio: HoldAudio::Silence,
                                },
                            ),
                        )]),
                        overrides: BTreeMap::new(),
                        gap_overrides: BTreeMap::new(),
                    },
                },
            })
            .unwrap();
    }
}

/// The native workspace of `store`'s current revision, as the project
/// service publishes it.
pub(super) fn workspace_of(store: &ProjectStore, session: u64, path: PathBuf) -> Arc<Workspace> {
    let document = Arc::new(store.snapshot().unwrap());
    let sources = document
        .assets()
        .iter()
        .filter(|(_, record)| record.source_qualification.is_some())
        .map(|(asset, record)| {
            let receipt = store
                .registered_source(document.revision_id(), asset)
                .unwrap();
            let original = store
                .original_record(receipt.original().content())
                .unwrap()
                .unwrap();
            let receipt = Arc::new(receipt);
            let original_audition = Arc::new(
                deadpan_playback::Original::new(
                    document.presentation_basis().frame_rate,
                    asset.clone(),
                    receipt.clone(),
                )
                .unwrap(),
            );
            let video_index = Some(original_audition.index().clone());
            (
                asset.clone(),
                Arc::new(RegisteredSource {
                    asset: asset.clone(),
                    label: record.label.clone(),
                    receipt,
                    original,
                    video_index,
                    original_audition: Some(original_audition),
                    sound_audition: None,
                }),
            )
        })
        .collect();
    Arc::new(Workspace {
        color: store.output_color(&document).unwrap(),
        session,
        path,
        plan: Arc::new(RenderPlan::compile(&document).unwrap()),
        document,
        sources,
        originals: store.original_import_handle().unwrap(),
        generated: store.generated_read_handle(),
        can_undo: false,
        can_redo: false,
        single_source: None,
        original_duration: None,
        transcript: None,
        speech_activity: None,
        shot_analysis: None,
        corrections: None,
        read_only: None,
    })
}

fn asset() -> AssetId {
    AssetId::new("camera").unwrap()
}

fn node(value: &str) -> NodeId {
    NodeId::new(value).unwrap()
}

fn revision(value: &str) -> RevisionId {
    RevisionId::new(value).unwrap()
}

fn source(frame: u64) -> ProjectView {
    ProjectView::Source {
        asset: asset(),
        frame: SourceFrameId(frame),
    }
}

fn sequence(frame: i64) -> ProjectView {
    ProjectView::Sequence {
        frame: ProjectFrame(frame),
    }
}

fn request(workspace: &Arc<Workspace>, view: ProjectView, serial: u64) -> Request {
    Request {
        ticket: Ticket {
            transport: None,
            source: workspace.session,
            request: serial,
        },
        work: Work::Project {
            workspace: workspace.clone(),
            view,
        },
        loop_ahead: None,
        cancelled: Arc::new(AtomicBool::new(false)),
        arrived: Instant::now(),
    }
}

fn await_reply(worker: &PreviewWorker) -> Reply {
    let deadline = Instant::now() + Duration::from_secs(15);
    loop {
        if let Some(reply) = worker.take_reply() {
            return reply;
        }
        assert!(
            Instant::now() < deadline,
            "project preview response deadline"
        );
        std::thread::sleep(Duration::from_millis(2));
    }
}

#[test]
fn actual_decoded_freeze_keeps_sequence_position_and_rejects_old_revision_reply() {
    let mut fixture = Fixture::source("cfr-bframes.mp4");
    let before = fixture.workspace(1);
    let time_base = before.sources[&asset()]
        .video_index
        .as_ref()
        .unwrap()
        .time_base();
    let worker = PreviewWorker::new(egui::Context::default()).unwrap();
    let mut presentation = crate::presentation::Presentation::default();
    let first = request(&before, sequence(20), 1);
    presentation.request(first.ticket, &first.work);
    worker.submit(first.ticket, first.work);
    let old_reply = await_reply(&worker);

    fixture.append_hold(
        "freeze",
        1,
        HoldVideo::Freeze {
            asset: asset(),
            timestamp: SourceTimestamp {
                ticks: 20 * 1001,
                time_base,
            },
        },
    );
    let after = fixture.workspace(1);
    assert_ne!(before.document.revision_id(), after.document.revision_id());
    presentation.clear();
    let next = request(&after, sequence(121), 2);
    presentation.request(next.ticket, &next.work);
    assert!(presentation.receive(old_reply).is_none());
    assert!(presentation.loading());
    assert!(!presentation.has_displayed());
    worker.submit(next.ticket, next.work);
    assert!(presentation.receive(await_reply(&worker)).unwrap().is_ok());
    let frozen_bytes = presentation
        .picture()
        .unwrap()
        .frame
        .as_ref()
        .unwrap()
        .bytes()
        .to_vec();
    assert_eq!(presentation.picture().unwrap().id, SourceFrameId(20));
    assert_eq!(presentation.displayed_label(), None);
    presentation.presented();
    assert_eq!(
        presentation.displayed_label().as_deref(),
        Some("Showing sequence frame 122")
    );
    assert_eq!(
        presentation.displayed_source_frame(),
        Some(SourceFrameId(20))
    );

    let next = request(&after, sequence(122), 3);
    presentation.request(next.ticket, &next.work);
    worker.submit(next.ticket, next.work);
    assert!(presentation.receive(await_reply(&worker)).unwrap().is_ok());
    assert_eq!(
        presentation
            .picture()
            .unwrap()
            .frame
            .as_ref()
            .unwrap()
            .bytes(),
        frozen_bytes
    );
    assert!(
        presentation.needs_render(),
        "identical decoded pixels still occupy a new sequence frame"
    );
    assert_eq!(
        presentation.displayed_label().as_deref(),
        Some("Showing sequence frame 122")
    );
    presentation.presented();
    assert_eq!(
        presentation.displayed_label().as_deref(),
        Some("Showing sequence frame 123")
    );
    worker.shutdown();
}

#[test]
fn registered_source_and_sequence_decode_the_same_original_frame() {
    let fixture = Fixture::source("cfr-bframes.mp4");
    let workspace = fixture.workspace(1);
    assert_eq!(workspace.plan.duration().frames(), 120);
    let worker = PreviewWorker::new(egui::Context::default()).unwrap();
    let first = request(&workspace, source(20), 1);
    worker.submit(first.ticket, first.work);
    let first = await_reply(&worker).picture.unwrap();
    assert_eq!(first.id, SourceFrameId(20));
    assert_eq!(first.canvas, None);
    assert_eq!(
        first.frame.as_ref().unwrap().metadata().pts.ticks,
        20 * 1001
    );
    for serial in 2..=20 {
        let next = request(&workspace, sequence(serial as i64), serial);
        worker.submit(next.ticket, next.work);
    }
    let last = await_reply(&worker);
    assert_eq!(last.ticket.request, 20);
    let last = last.picture.unwrap();
    assert_eq!(last.id, SourceFrameId(20));
    assert_eq!(last.canvas, Some((320, 180)));
    assert_eq!(last.frame.unwrap().bytes(), first.frame.unwrap().bytes());
    worker.clear();
    let after_clear = request(&workspace, source(42), 21);
    worker.submit(after_clear.ticket, after_clear.work);
    assert_eq!(await_reply(&worker).picture.unwrap().id, SourceFrameId(42));
    worker.shutdown();
}

#[cfg(feature = "ui-harness")]
#[test]
fn worker_timing_precedes_notification_and_preserves_decoder_across_revisions() {
    let mut fixture = Fixture::source("cfr-bframes.mp4");
    let before = fixture.workspace(1);
    let context = egui::Context::default();
    let (notified, notifications) = std::sync::mpsc::sync_channel(1);
    context.set_request_repaint_callback(move |_| {
        let _ = notified.try_send(Instant::now());
    });
    let worker = PreviewWorker::new(context.clone()).unwrap();
    let submit = |request: Request| {
        // Consume egui's settling repaints before submitting the next request.
        // A fresh worker repaint then wakes this test without polling or sleeps.
        for _ in 0..3 {
            let mut output = context.run_ui(egui::RawInput::default(), |_| {});
            output.textures_delta.clear();
        }
        while notifications.try_recv().is_ok() {}
        let submitted = Instant::now();
        let ticket = request.ticket;
        worker.submit(ticket, request.work);
        let notified = notifications
            .recv_timeout(Duration::from_secs(15))
            .expect("preview worker repaint deadline");
        let reply = worker.take_reply().expect("reply published before repaint");
        let received = Instant::now();
        let timing = reply.timing.expect("real worker timing");
        let published = timing.published.expect("accepted publication time");
        assert_eq!(reply.ticket, ticket);
        assert!(submitted <= timing.started);
        assert!(timing.started <= timing.finished);
        assert!(timing.finished <= published);
        assert!(published <= notified);
        assert!(notified <= received);
        reply
    };
    let first = submit(request(&before, source(20), 1));
    let first_timing = first.timing.unwrap();
    let first = first.picture.unwrap();
    assert_eq!(first.id, SourceFrameId(20));

    fixture.append_hold(
        "freeze",
        1,
        HoldVideo::Freeze {
            asset: asset(),
            timestamp: SourceTimestamp {
                ticks: 20 * 1001,
                time_base: before.sources[&asset()]
                    .video_index
                    .as_ref()
                    .unwrap()
                    .time_base(),
            },
        },
    );
    let after = fixture.workspace(1);
    assert_ne!(before.document.revision_id(), after.document.revision_id());
    // Closing the writer revokes its original-import handles. An attempted
    // reopen would fail; the live decoder must survive the unrelated revision.
    drop(fixture.store);
    let mut next = request(&after, sequence(121), 2);
    next.ticket.source = 2;
    let second = submit(next);
    assert!(first_timing.published.unwrap() <= second.timing.unwrap().started);
    let second = second.picture.unwrap();
    assert_eq!(second.id, first.id);
    assert_eq!(second.canvas, Some((320, 180)));
    assert_eq!(second.frame.unwrap().bytes(), first.frame.unwrap().bytes());

    worker.clear();
    let after_clear = submit(request(&after, sequence(121), 3));
    assert!(after_clear.picture.is_err(), "cleared decoder must reopen");
    worker.shutdown();
}

#[test]
fn sequence_samples_exact_mapping_and_endpoint_policy_after_a_revision_change() {
    let mut fixture = Fixture::source("cfr-bframes.mp4");
    let before = fixture.workspace(1);
    let mut retained = None;
    let original = perform(&request(&before, sequence(20), 1), &mut retained, &mut None).unwrap();
    assert_eq!(original.id, SourceFrameId(20));
    fixture
        .store
        .commit(&CommandRequest {
            project_id: before.document.project_id().clone(),
            expected_revision: before.document.revision_id().clone(),
            new_revision: revision("picture-rate"),
            command: Command::SetSourceVideoMapping {
                node: node("source"),
                mapping: SourceVideoMapping::Duration {
                    frames: ExactRatio::integer(60),
                    endpoints: EndpointPolicy::HoldAdjacent,
                },
            },
        })
        .unwrap();
    let after = fixture.workspace(1);
    let faster = perform(&request(&after, sequence(20), 2), &mut retained, &mut None).unwrap();
    assert_eq!(faster.id, SourceFrameId(41));
    assert_eq!(faster.frame.unwrap().metadata().pts.ticks, 41 * 1001);
    let endpoint = perform(&request(&after, sequence(119), 3), &mut retained, &mut None).unwrap();
    assert_eq!(endpoint.id, SourceFrameId(119));
}

#[test]
fn frozen_context_reaches_sequence_preview_without_leaking_into_original_view() {
    use deadpan_core::{CapturedCanvas, CapturedFit, CapturedFraming, FramingPose};
    let mut fixture = Fixture::source("cfr-bframes.mp4");
    let workspace = fixture.workspace(1);
    let time_base = workspace.sources[&asset()]
        .video_index
        .as_ref()
        .unwrap()
        .time_base();
    fixture.append_hold(
        "framed-freeze",
        1,
        HoldVideo::Freeze {
            asset: asset(),
            timestamp: SourceTimestamp {
                ticks: 20 * 1001,
                time_base,
            },
        },
    );
    let context = CapturedFraming::capture(
        None,
        CapturedCanvas {
            width: 320,
            height: 180,
            fit: CapturedFit::Fit,
            layers: vec![
                Some(FramingPose {
                    scale: ExactRatio::integer(2),
                    ..Default::default()
                }),
                Some(FramingPose {
                    scale: ExactRatio::new(1, 2).unwrap(),
                    ..Default::default()
                }),
            ],
        },
    )
    .unwrap();
    let before = fixture.store.snapshot().unwrap();
    fixture
        .store
        .commit(&CommandRequest {
            project_id: before.project_id().clone(),
            expected_revision: before.revision_id().clone(),
            new_revision: revision("captured-view"),
            command: Command::SetHoldPictureContext {
                node: node("framed-freeze"),
                context: Some(context.clone()),
            },
        })
        .unwrap();
    let workspace = fixture.workspace(1);
    let sample = workspace.plan.picture(ProjectFrame(121)).unwrap();
    let mut retained = None;
    let frozen = perform(
        &request(&workspace, sequence(121), 1),
        &mut retained,
        &mut None,
    )
    .unwrap();
    assert_eq!(frozen.id, SourceFrameId(20));
    assert_eq!(frozen.picture_context.as_deref(), Some(&context));
    assert!(Arc::ptr_eq(
        frozen.picture_context.as_ref().unwrap(),
        sample.picture_context.as_ref().unwrap()
    ));
    assert_eq!(
        frozen.frame.as_ref().unwrap().metadata().pts.ticks,
        20 * 1001
    );
    let original = perform(
        &request(&workspace, source(20), 2),
        &mut retained,
        &mut None,
    )
    .unwrap();
    assert_eq!(original.id, frozen.id);
    assert!(original.picture_context.is_none());
    assert!(original.framing.is_empty());
    let ordinary = perform(
        &request(&workspace, sequence(20), 3),
        &mut retained,
        &mut None,
    )
    .unwrap();
    assert!(ordinary.picture_context.is_none());
    let frozen_again = perform(
        &request(&workspace, sequence(122), 4),
        &mut retained,
        &mut None,
    )
    .unwrap();
    assert!(Arc::ptr_eq(
        frozen.picture_context.as_ref().unwrap(),
        frozen_again.picture_context.as_ref().unwrap()
    ));
}

#[test]
fn freeze_background_and_empty_sequence_follow_the_plan() {
    let mut fixture = Fixture::source("cfr-bframes.mp4");
    let workspace = fixture.workspace(1);
    let time_base = workspace.sources[&asset()]
        .video_index
        .as_ref()
        .unwrap()
        .time_base();
    fixture.append_hold(
        "freeze",
        1,
        HoldVideo::Freeze {
            asset: asset(),
            timestamp: SourceTimestamp {
                ticks: 20 * 1001,
                time_base,
            },
        },
    );
    fixture.append_hold("background", 2, HoldVideo::Background);
    let workspace = fixture.workspace(1);
    let mut retained = None;
    let frozen = perform(
        &request(&workspace, sequence(121), 1),
        &mut retained,
        &mut None,
    )
    .unwrap();
    assert_eq!(frozen.id, SourceFrameId(20));
    assert_eq!(
        frozen.frame.as_ref().unwrap().metadata().pts.ticks,
        20 * 1001
    );
    let background = perform(
        &request(&workspace, sequence(123), 2),
        &mut retained,
        &mut None,
    )
    .unwrap();
    assert!(background.frame.is_none());
    assert_eq!(background.canvas, Some((320, 180)));
    assert!(
        perform(
            &request(&workspace, sequence(126), 3),
            &mut retained,
            &mut None
        )
        .is_err()
    );
    assert!(
        perform(
            &request(&workspace, source(120), 4),
            &mut retained,
            &mut None
        )
        .is_err()
    );
    assert_eq!(
        perform(
            &request(&workspace, source(20), 5),
            &mut retained,
            &mut None
        )
        .unwrap()
        .id,
        SourceFrameId(20)
    );
    let empty = Fixture::empty();
    let workspace = empty.workspace(2);
    let blank = perform(
        &request(&workspace, sequence(0), 4),
        &mut retained,
        &mut None,
    )
    .unwrap();
    assert!(blank.frame.is_none());
    assert_eq!(blank.canvas, Some((1920, 1080)));
    assert!(
        perform(
            &request(&workspace, sequence(-1), 5),
            &mut retained,
            &mut None
        )
        .is_err()
    );
}

#[test]
fn cancelled_open_does_not_leave_a_later_project_request_without_a_source() {
    let fixture = Fixture::source("cfr-bframes.mp4");
    let workspace = fixture.workspace(1);
    let mut mailbox = Mailbox::default();
    let first = request(&workspace, source(0), 1);
    mailbox.submit(first.ticket, first.work);
    let first = mailbox.start_next().unwrap();
    let replacement = request(&workspace, sequence(37), 2);
    mailbox.submit(replacement.ticket, replacement.work);
    let mut retained = None;
    let result = perform(&first, &mut retained, &mut None);
    assert!(result.is_err());
    assert!(!mailbox.publish(Reply {
        ticket: first.ticket,
        picture: result,
        #[cfg(feature = "ui-harness")]
        timing: None,
    }));
    let latest = mailbox.start_next().unwrap();
    let picture = perform(&latest, &mut retained, &mut None).unwrap();
    assert_eq!(picture.id, SourceFrameId(37));
    assert_eq!(picture.frame.unwrap().metadata().pts.ticks, 37 * 1001);
}

#[test]
fn revision_receipt_index_and_session_identity_are_checked() {
    let mut fixture = Fixture::source("cfr-bframes.mp4");
    let old = fixture.workspace(1);
    fixture.append_hold("background", 1, HoldVideo::Background);
    let mut current = fixture.workspace(1);
    let current_mut = Arc::get_mut(&mut current).unwrap();
    current_mut.plan = old.plan.clone();
    let mut retained = None;
    assert!(
        perform(&request(&current, sequence(0), 1), &mut retained, &mut None)
            .err()
            .unwrap()
            .contains("another project revision")
    );

    let other_fixture = Fixture::source("offset-bframes.mp4");
    let other = other_fixture.workspace(1);
    let mut inconsistent = fixture.workspace(1);
    Arc::get_mut(&mut inconsistent).unwrap().sources = other.sources.clone();
    assert!(
        perform(
            &request(&inconsistent, source(0), 2),
            &mut retained,
            &mut None
        )
        .err()
        .unwrap()
        .contains("selected project revision")
    );

    let mut inconsistent = fixture.workspace(1);
    let registered = Arc::get_mut(
        Arc::get_mut(&mut inconsistent)
            .unwrap()
            .sources
            .get_mut(&asset())
            .unwrap(),
    )
    .unwrap();
    registered.video_index = other.sources[&asset()].video_index.clone();
    assert!(
        perform(
            &request(&inconsistent, source(0), 3),
            &mut retained,
            &mut None
        )
        .err()
        .unwrap()
        .contains("immutable receipt")
    );

    let first = perform(&request(&old, source(0), 4), &mut retained, &mut None).unwrap();
    let replacement = perform(&request(&other, source(0), 5), &mut retained, &mut None).unwrap();
    assert_ne!(
        first.frame.unwrap().metadata().pts.ticks,
        replacement.frame.unwrap().metadata().pts.ticks
    );
    let new_session = other_fixture.workspace(2);
    drop(other_fixture.store);
    assert!(
        perform(
            &request(&new_session, source(0), 6),
            &mut retained,
            &mut None
        )
        .is_err()
    );
    // Reopening was attempted despite identical alias and receipt. The old
    // private decoder cannot cross a project-service session boundary.
    assert!(retained.is_none());
}

#[test]
fn interrupted_index_verification_readmits_and_recovers() {
    use deadpan_media::source_session::IndexMeasurement;
    let fixture = Fixture::source("cfr-bframes.mp4");
    let workspace = fixture.workspace(1);
    let mut retained = None;
    tests_support::ADMISSIONS.set(0);
    tests_support::INTERRUPT_MEASUREMENTS.set(1);
    // The first admission's background verification is interrupted. Whether
    // that is observed during this request (retried at once) or the next one
    // (dropped and re-admitted there), no request fails.
    let first = perform(
        &request(&workspace, source(20), 1),
        &mut retained,
        &mut None,
    )
    .unwrap();
    assert_eq!(first.id, SourceFrameId(20));
    let state = retained
        .as_ref()
        .unwrap()
        .source
        .wait_measured(Duration::from_secs(30));
    if tests_support::ADMISSIONS.get() == 1 {
        assert!(
            matches!(state, IndexMeasurement::Interrupted(_)),
            "{state:?}"
        );
    }
    let second = perform(
        &request(&workspace, source(21), 2),
        &mut retained,
        &mut None,
    )
    .unwrap();
    assert_eq!(second.id, SourceFrameId(21));
    assert_eq!(tests_support::ADMISSIONS.get(), 2);
    assert_eq!(
        retained
            .as_ref()
            .unwrap()
            .source
            .wait_measured(Duration::from_secs(30)),
        IndexMeasurement::Verified
    );
    let again = perform(
        &request(&workspace, source(20), 3),
        &mut retained,
        &mut None,
    )
    .unwrap();
    assert_eq!(again.frame.unwrap().bytes(), first.frame.unwrap().bytes());
    assert_eq!(tests_support::ADMISSIONS.get(), 2);
}

#[test]
fn mismatched_index_verification_fails_clearly_without_readmitting() {
    use deadpan_media::source_session::IndexMeasurement;
    let fixture = Fixture::source("cfr-bframes.mp4");
    let workspace = fixture.workspace(1);
    let mut retained = None;
    tests_support::ADMISSIONS.set(0);
    tests_support::TAMPER_INDEX.set(true);
    // Frame 0 may be served before the background verdict; it is verified
    // against the (unaffected) receipt entry either way.
    let _ = perform(&request(&workspace, source(0), 1), &mut retained, &mut None);
    tests_support::TAMPER_INDEX.set(false);
    let state = retained
        .as_ref()
        .unwrap()
        .source
        .wait_measured(Duration::from_secs(30));
    assert!(matches!(state, IndexMeasurement::Mismatch(_)), "{state:?}");
    for serial in 2..5 {
        let error = perform(
            &request(&workspace, source(serial), serial),
            &mut retained,
            &mut None,
        )
        .err()
        .unwrap();
        assert!(error.starts_with("Source verification failed:"), "{error}");
    }
    assert_eq!(tests_support::ADMISSIONS.get(), 1);
}
