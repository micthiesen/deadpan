from pathlib import Path
import hashlib,json,re
s=Path(__file__).resolve().parent
main=Path('/Users/michael/Code/deadpan');scope=Path('/tmp/deadpan-query-groundwork-2026-10-26/scoped')
sha=lambda b:hashlib.sha256(b).hexdigest()
negative={'tile-strict1':1,'tile-strict2':1,'tile-split':101}
receipts=[]
for p in sorted(s.glob('*.json')):
 r=json.loads(p.read_text())
 if not isinstance(r,dict)or 'started_at'not in r or 'command'not in r:continue
 assert r.get('exit_code')==negative.get(p.stem,0),(p.stem,r.get('exit_code'))
 assert r['sources_unchanged']and r['binaries_unchanged'],p.stem
 for name,h in r['streams'].items():
  data=Path(name).read_bytes();assert len(data)==h['bytes']and sha(data)==h['sha256']
 receipts.append({'label':p.stem,'exit_code':r['exit_code'],'seconds':r['seconds'],'sha256':sha(p.read_bytes()),'source_inputs':len(r['source_before'])})
final=['tile-strict3','tile-build1','tile-audio1','tile-stages','tile-definition','tile-doctests','tile-scoped-build1','tile-scoped-audio','tile-scoped-stages','tile-scoped-birth','tile-split']
for label in final:
 r=json.loads((s/(label+'.json')).read_text())
 for name,h in r['source_after'].items():
  data=Path(name).read_bytes();assert len(data)==h['bytes']and sha(data)==h['sha256'],(label,name)
rows=json.loads((s/'task-source-pins.json').read_text());raw=(s/'index-blobs.bin').read_bytes();offset=0;equality=[]
for row in rows:
 end=raw.index(b'\n',offset);header=raw[offset:end].decode().split();assert header[1]=='blob'
 n=int(header[2]);data=raw[end+1:end+1+n];offset=end+2+n
 assert data==(scope/row['path']).read_bytes()and sha(data)==row['sha256']
 assert data==(main/row['path']).read_bytes()
 equality.append({'path':row['path'],'blob':header[0],'sha256':row['sha256'],'scoped_index_main_equal':True})
assert offset==len(raw)and len(rows)==9
(s/'index-source-equality.json').write_text(json.dumps(equality,indent=2)+'\n')
owned={r['path']for r in rows};unchanged={}
for variant,root in [('main',main),('scoped',scope)]:
 initial=json.loads((s/(variant+'-initial-authority.json')).read_text());count=0
 for name,h in initial.items():
  if name in owned:continue
  assert sha((root/name).read_bytes())==h,(variant,name)
  count+=1
 unchanged[variant]=count
for row in json.loads((s/'immutable-oracle-pins.json').read_text()):
 for root in [main,scope]:assert sha((root/row['path']).read_bytes())==row['sha256']
old_a=json.loads((s/'tile-oracle-main-snapshot.json').read_text());old_b=json.loads((s/'tile-oracle-scoped-snapshot.json').read_text())
for obj in [old_a,old_b]:
 for key in ['variant','source_sha256']:obj.pop(key)
assert old_a==old_b
tests={}
expected={'tile-audio1':370,'tile-scoped-audio':351,'tile-stages':203,'tile-definition':171,'tile-scoped-stages':203,'tile-scoped-birth':8}
for label,count in expected.items():
 matches=re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;',(s/(label+'.stdout')).read_text())
 assert len(matches)==1 and int(matches[0][0])==count and int(matches[0][1])==0,(label,matches)
 tests[label]={'passed':count,'ignored':int(matches[0][2]),'seconds':json.loads((s/(label+'.json')).read_text())['seconds']}
reuse=json.loads((s/'plan-reuse-audit.json').read_text())
assert len(reuse)==2 and all(row['all_29_executable_hashes_preserved']for row in reuse)
split=re.findall(r'^test ([\w:]+) \.\.\. (ok|FAILED|ignored)',(s/'tile-split.stdout').read_text(),re.M)
assert len(split)==7
result={'all_terminal':True,'receipts':receipts,'negative_results_retained':negative,'source_files':9,'rust_files':7,'all_main_scope_index_equal':True,'other_initial_inputs_unchanged':unchanged,'final_compiled_sources_current':True,'tests':tests,'plan_reuse':reuse,'immutable_oracles_unchanged':8,'old_tile_matrix_literal_cross_variant_equal':True,'split':{'passed':sum(v=='ok'for _,v in split),'failed':sum(v=='FAILED'for _,v in split),'cases':split,'seconds':json.loads((s/'tile-split.json').read_text())['seconds']},'scoped_patch_sha256':sha((s/'task-scoped.patch').read_bytes())}
(s/'final-audit.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items()if k not in ['receipts','plan_reuse']}))
