from pathlib import Path
import hashlib,json,os,subprocess,sys
s=Path(__file__).resolve().parent
label,build,variant=sys.argv[1:]
assert variant in ['main','scoped']
root=Path('/Users/michael/Code/deadpan')if variant=='main'else Path('/tmp/deadpan-query-groundwork-2026-10-26/scoped')
paths=json.loads((s/('source-files.json'if variant=='main'else'scoped-source-files.json')).read_text())
manifest={n:{'bytes':(root/n).stat().st_size,'sha256':hashlib.sha256((root/n).read_bytes()).hexdigest()}for n in paths}
p=s/(label+'-source-manifest.json')
with p.open('x')as f:f.write(json.dumps(manifest,indent=2)+'\n')
digest=hashlib.sha256(p.read_bytes()).hexdigest()
pins=json.loads((s/(build+'-pins.json')).read_text())
binary=next(r['path']for r in pins if r['package']=='audio'and r['name']=='deadpan_audio')
env=os.environ.copy();env.update({'DEADPAN_AUTHORED_TILE_OUTPUT':str(s/(label+'-snapshot.json')),'DEADPAN_AUTHORED_TILE_VARIANT':'main-inherited'if variant=='main'else'scoped-published','DEADPAN_AUTHORED_TILE_SOURCE_SHA256':digest})
runner='run_qualified.py'if variant=='main'else'run_scoped_qualified.py'
raise SystemExit(subprocess.run(['python',str(s/runner),'--binary',binary,label,'--',binary,'produce_legacy_authored_tile_baseline','--ignored','--nocapture','--test-threads=1'],env=env).returncode)
