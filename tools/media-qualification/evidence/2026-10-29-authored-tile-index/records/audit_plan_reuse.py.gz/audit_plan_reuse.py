from pathlib import Path
import hashlib,json
s=Path(__file__).resolve().parent
prior=Path('/tmp/deadpan-authored-owner-admission-2026-10-29')
rows=[]
for variant,build,results_build in [('main','authored-build4','authored-build1'),('scoped','authored-scoped-build3','authored-scoped-build2')]:
 receipt=json.loads((prior/(build+'.json')).read_text())
 changes=[]
 for name,h in receipt['source_after'].items():
  p=Path(name);data=p.read_bytes()
  if len(data)!=h['bytes']or hashlib.sha256(data).hexdigest()!=h['sha256']:changes.append(name)
 assert len(changes)==2
 assert all(n.endswith(('/crates/deadpan-audio/src/authored_eq.rs','/crates/deadpan-audio/src/sound_context_admission.rs'))for n in changes)
 pins=[p for p in json.loads((prior/(build+'-pins.json')).read_text())if p['package']=='plan']
 assert len(pins)==29
 for p in pins:assert hashlib.sha256(Path(p['path']).read_bytes()).hexdigest()==p['sha256']
 results=json.loads((prior/'plan-results'/results_build/'results.json').read_text())
 assert len(results)==29 and all(r['exit_code']==0 for r in results)
 counts={'passed':sum(int(t[1])for r in results for t in r['test_results']),'ignored':sum(int(t[3])for r in results for t in r['test_results'])}
 rows.append({'variant':variant,'prior_build':build,'prior_results_build':results_build,'targets':29,'reused_counts':counts,'all_29_executable_hashes_preserved':True,'other_prior_guarded_inputs_current':True,'only_changed_prior_inputs_unlinked_audio':changes,'dependency_basis':'Plan depends internally only on Core; Plan/Core sources, fixtures, manifests, workspace Cargo.toml, Cargo.lock and compiler configuration remain unchanged. Audio is not a Plan dependency. Newly added files are Audio only.','prior_reuse_audit_sha256':hashlib.sha256((prior/'plan-binary-reuse-audit.json').read_bytes()).hexdigest()})
(s/'plan-reuse-audit.json').write_text(json.dumps(rows,indent=2)+'\n')
print(json.dumps(rows,indent=2))
