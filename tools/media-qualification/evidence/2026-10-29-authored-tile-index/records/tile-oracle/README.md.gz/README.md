# OLD Authored EQ tile oracle

Source-only freeze for the parent-owned optimized executable build, prior to
changing production `eq_tile`, `read_eq_program`, or `Node.tiles`.

Owned repository changes: a cfg(test) module hook after authored_eq module docs,
and new `authored_eq/legacy_tile_baseline.rs`, mirrored byte-for-byte in main and
scoped. `before/` contains each prior hook file; the new module did not exist.
`candidate/`, `candidate.patch`, `pins.json`, and `taskfiles.json` describe this
candidate. Parent owns builds, executable pins, capture invocation and Git.

Ignored filter: `produce_legacy_authored_tile_baseline`.
Required environment: `DEADPAN_AUTHORED_TILE_OUTPUT` (new absolute /tmp path),
`DEADPAN_AUTHORED_TILE_VARIANT` (`main-inherited` or `scoped-published`), and
`DEADPAN_AUTHORED_TILE_SOURCE_SHA256` (64 hex digits). Output uses create_new and
sync_all. Only top-level `variant` and `source_sha256` are provenance exclusions
for OLD cross-variant equality. This is not a rewritten-code test.

Seven actual execution scenarios cover short Tone suppression and refusal order,
16-plus sorted BTreeMap tile keys including negative and adjacent keys, repeated
cache hits, nested EQ recursion, real nonempty dependencies through the verified
repository stereo WAV and RoomTone renderer, existing Repeat gaps, an actual
captured physical Domain and an actual retained capture. Existing immutable
13+3 node and numerical golden observations are untouched. The new derived
documents are serialized into the capture; existing capture documents are
reconstructed by their unchanged legacy_node_baseline helpers. Owner setup
searches all actual returned spans rather than assuming every span has owners.

Every scenario labels the real eq_node setup separately from measured eq_tile
and read_eq_program calls. PCM is complete stereo f64::to_bits, not f32. The
capture retains ranges, dependencies, relative depth, source calls, filter
presence, cache entries/order, actual Vec capacities, actual returned/cache Arc
strong counts, shallow type sizes, and current controller/active/resident
observations. `old_total_controller_work` includes all admission fees already
present at the base revision, not an assertion of globally canonical query work.
Counter/layout/resource observations are separate from the numerical blocks so
the parent can independently reconcile new index fees and Node layout changes.

Old BTreeMap private node capacity remains explicitly unknown. No node-byte
estimate, unsafe allocator instrumentation, native allocation closure, or variable
suppression/dependency allocation closure is claimed. Arc observations are counts,
not inferred allocation bytes. Actual returned Arc clones are dropped before
the after-return cache count; all captures release Graph before its aggregate
resident charge.

Refusals cover cancellation before invalid depth/cache hits, expired deadline,
absolute depth before cache, cached nested relative depth, range before depth,
checked key/end overflow, input/output/prepared/resident refusal, cycle and retry.
The nested no-work relative-depth probe explicitly imposes the existing work
counter at MAX_PLAN_WORK_PER_READ, records that input separately, and restores
only that artificial input after a call that accepts no additional work. This is
an old resource fact, not a requirement that a new paid lookup preserve its error.

Source is frozen pending parent compile and capture; no production refactor may
precede successful OLD captures of both variants and retained executable pins.
