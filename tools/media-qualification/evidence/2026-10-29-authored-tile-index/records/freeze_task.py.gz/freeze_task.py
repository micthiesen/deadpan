from pathlib import Path
import json,hashlib,tarfile,difflib,shutil
s=Path(__file__).resolve().parent;main=Path('/Users/michael/Code/deadpan');scope=Path('/tmp/deadpan-query-groundwork-2026-10-26/scoped')
files=json.loads((s/'task-files.json').read_text())
with tarfile.open(s/'base-source.tar') as tar:
 old={m.name:tar.extractfile(m).read()for m in tar if m.isfile()}
patch=[];rows=[]
for rel in files:
 a=old.get(rel,b'');b=(scope/rel).read_bytes();m=(main/rel).read_bytes()
 assert a!=b,rel
 patch.extend(difflib.unified_diff(a.decode().splitlines(True),b.decode().splitlines(True),fromfile='a/'+rel if a else '/dev/null',tofile='b/'+rel,n=3))
 rows.append({'path':rel,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'main_sha256':hashlib.sha256(m).hexdigest(),'main_equals_scoped':b==m})
 for variant,root in [('main',main),('scoped',scope)]:
  dest=s/'final-source'/variant/rel;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(root/rel,dest)
(s/'task-scoped.patch').write_text(''.join(patch))
(s/'task-source-pins.json').write_text(json.dumps(rows,indent=2)+'\n')
(s/'index-specs.txt').write_text(''.join(':'+r['path']+'\n'for r in rows))
print(json.dumps({'sourcefiles':len(rows),'main_equal':sum(r['main_equals_scoped']for r in rows),'patch_sha256':hashlib.sha256((s/'task-scoped.patch').read_bytes()).hexdigest()}))
