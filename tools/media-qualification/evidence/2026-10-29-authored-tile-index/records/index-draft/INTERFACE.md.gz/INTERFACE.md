# Authored tile-index draft

Scratch only. Not applied, compiled, formatted, or qualified. Parent owns integration, Arc wrapper, Cargo/native runs, and Git. Sources were captured before drafting; `before.sha256` records their bytes. Do not apply until the independently frozen old actual `eq_tile` AND `read_eq_program` oracles exist in both source variants.

## Contents and ownership

- `tile_index.draft.rs`: proposed new Authored-local child module.
- `tile_index.draft.patch`: the same new-file draft as a patch.
- `sound_context_admission.draft.rs` / `.draft.patch`: narrowly named tile transfer constructor sharing existing private ledger mechanics. This is optional if parent implements equivalent mechanics.
- `*.before.rs`: current whole source files, retaining exact before snippets and imports.
- `before.sha256` and `draft.sha256`: source/draft fingerprints.

No repository files changed. SharedEq maps, node-capacity weights, other vectors, source/provider reads, suppression merging, dependencies, and PCM work are unchanged by this draft.

## Helper contract

Parent adds `#[path = "authored_eq/tile_index.rs"] mod tile_index;`, changes only Authored `Node.tiles` to `tile_index::TileIndex`, and initializes it with `TileIndex::new()`.

`get::<METER_WORK>(tile, control)` returns `Result<Option<&Arc<WideBlock>>, StageAudioError>`. Keep existing `control.check()` and absolute-depth refusal before calling it. Keep cached relative-depth arithmetic/refusal after paid lookup and before `Arc::clone`. The borrowed result must go out of scope before any recursion. No insertion location from that initial miss survives recursion.

After recursive compute, filtering, suppressed-sample zeroing, and the existing final control check, call:

```rust
let mut index = tile_index::prepare::<METER_WORK>(
    self,
    &graph.nodes[id].tiles,
    tile,
    control,
)?;
```

This validates the actual prior index-capacity counter, performs a new paid binary search, refuses a duplicate, computes checked geometric capacity and exact entry operations, and admits replacement capacity while the old index remains resident. It does not hold any Graph reference and does not yet allocate. There is no count maximum argument and no coupling to `maximum_prepared_stages`.

Parent constructs/adopts its own pending Arc shell and checks retained PCM/next aggregate arithmetic. Capture `index.new_frames()` and `index.retired_frames()` before lease disarming; test-only `index.capacity_frames_after()` exposes its final capacity charge. Both pending storage values must declare their actual value before their lease, including on partial-construction errors.

Before the publication tail, complete `index.allocate()`, `index.prepay_moves::<METER_WORK>(control)`, `index.validate_current::<METER_WORK>(&graph.nodes[id].tiles, control)`, parent Arc allocation/validation, all issuer/sum/subtraction checks, and final cancellation checks. Parent is free to order these fallible suffix checks to preserve its selected resource-prefix behavior. No Graph borrow may cross the earlier recursion.

`index.publish(&mut graph.nodes[id].tiles, Arc::clone(&block))` is then an audited, no-Result tail. Growth drains old entries in order, moving each old entry once and writing the new entry once. Spare insertion shifts only the suffix. Growth swaps vectors and drops the now-empty old backing allocation before parent retires its prior charge. Parent then publishes checked aggregate accounting and commits the named two-lane lease transfer. No fallible operation or callback belongs between first drain and the completed transfer. This follows existing `PendingNodeCapacity` orchestration; validation must be immediately followed by that tail, with no intervening index mutation.

The two-lane names are `TileTransferLeases { index, arc_shell }`, `TileTransferLeasesMut { index, arc_shell }`, and `preflight_tile_transfer`. Do not put Arc leases in existing `key`, `sound`, or `boundary` slots. The draft factors only private `preflight_slots`/`commit_slots` mechanics from existing `JointTransfer`; it does not expose a new public generic admission framework or alter existing slot weights/semantics.

## Memory proof boundary

For Entry = `(i64, Arc<WideBlock>)`, `old_index_frames = ceil(Layout::array::<Entry>(actual_old_capacity).size / 8)`. Every accepted replacement has allocator-reported `Vec::capacity()` whose Layout exactly equals the admitted target Layout. `try_reserve_exact` failures or mismatched actual capacity refuse before any old entry moves. Allocator-hidden heap overhead remains outside the existing Layout accounting contract; there is no new claim to observe allocator internals.

At growth, the existing Graph active accounting retains old index frames and the pending metadata ledger retains the complete replacement frames. At spare insertion, no capacity lease exists and the full old capacity remains billed, including slack. Peak admission must include old Graph/index/filter state, existing tile workspace, index replacement, Arc shell, existing boundary/context leases, and the established retained `OUTPUT * 2` PCM charge. Parent's final PCM `make_room` must happen after both new leases are live, with no further memory reservations between that check and publication unless it rechecks room.

`WideBlock` PCM is already charged as `OUTPUT * 2` frames. Do not also bill its samples capacity through the Arc shell. Shell Layout must use the existing Plan formula exactly: `Layout::new::<[usize; 2]>().extend(Layout::new::<WideBlock>())`, then `.pad_to_align()`. This is the existing pinned Rust/toolchain Arc shape contract, not a stable-language promise about private Arc implementation or allocator overhead. No invented additional work fee attaches to the Arc allocation or clone. Variable suppression Vec capacity and deep Dependencies BTreeMap remain explicitly open.

`TileIndex` holds a 24-byte Vec plus a u64 capacity counter on common 64-bit targets, compared with BTreeMap's prior common 24-byte shallow value. Use actual `size_of::<Node>()`, never these illustrative numbers, when preparing Graph node vectors. Existing node admission tests derive their frame charge from `Node`; this representation delta can change node-capacity residency even while tiles are empty. That is an expected candidate allocation delta, separate from old canonical work and tile payload fees. Keep existing node prepay/weights exactly as-is.

Test-only `is_empty()` preserves current Authored node/admission observers. Test-only `entries()`, `capacity()`, and `capacity_frames()` borrow without resource spends and expose real candidate capacity/entry order. Observers must not clone Arc values, collect a new Vec, or count their traversal as production work. The old BTree oracle's private node-allocation capacity stays opaque.

Graph drops before aggregate release in the actual outer caller. Parent must still audit all returned/cache Arc clone scopes: `eq_tile` returns a plain Arc with no Graph lifetime in its type. There must be no surviving returned clone when the aggregate Graph allocation charge is released. No additional Arc allocation is needed solely for handoff.

## Work reconciliation

True mode spends immediately before every actual binary-search key comparison, each final neighboring-key comparison, and the checked batch of actual entry operations. Entry operations equal:

- growth: `old_len + 1` (old entries relocated once, plus one new entry write);
- spare insertion: `old_len - position + 1` (shifted suffix, plus one new entry write).

No free preliminary key scan or search is permitted. Every helper spend is additive to all unchanged controller fees. The index does not replace any old canonical fee, refund accepted work, or change weights in any other container. Once accepted, inspection/move work remains spent if a later suffix check refuses.

`METER_WORK = false` skips only the new index spends and their extra spend-time checks. It performs the same actual sorted-vector searches/moves/allocations, the same Layout calculations and memory reservations, the same actual-capacity checks and publication. Parent must thread the mode through the entire recursive `read_eq_program`/`eq_tile` kernel; setting it only on the initial call does not isolate descendant fees. Production wrappers always use true. Arc shells have no new work fee, so both modes reserve identical memory and initialize the same Arc shape.

Under ample memory/work/time, independently prove: candidate false controller work equals frozen actual old controller work; candidate true work equals candidate false work plus the independently observed exact comparison/entry-operation sum. Compare old/new PCM bits, ranges, dependencies, provider read order/count, depths, cache keys/entry count, and cleanup separately. For refusals, assert accepted-work retention and resource-specific new prefixes. Do not infer old semantics from a self-consistency comparison of two copies of new code.

Additional paid cache lookup may refuse plan work before an old cached relative-depth failure is reached. This new resource-prefix precedence is intentional; old literal error parity applies with ample headroom. Absolute-depth and initial cancellation/deadline checks still precede any key inspection. Do not scan free first to recover old relative-depth precedence.

## Required focused tests when parent authorizes implementation

1. Empty insertion (capacity 0 to actual 4), spare prepend/middle/append, and full growth (actual 4 to 8), with exact independently counted search/neighbor/entry-write work. Negative keys, adjacent keys, i64 endpoints, exact hits/misses, sorted uniqueness, one published entry per miss. Candidate capacity observations must come from actual `Vec::capacity()`.
2. Duplicate preflight refusal and validate refusal for changed length/capacity/counter/neighbor. None moves old entries; both old storage and keys stay intact. The index owns no public key mutator; sortedness is preserved by construction, not by unpaid full-array validation.
3. Exact old+new overlap memory succeeds and one frame less refuses before allocation; accepted replacement capacity equals admitted Layout. Arc-suffix refusal drops the replacement before its capacity lease and leaves current entries/filter intact. Capture actual allocator-capacity mismatch only with a narrow test seam if useful, without unsafe/global allocator instrumentation.
4. Every feasible work-prefix refusal: initial key comparison, late prepare comparison, movement batch, final left/right validation comparison. Existing accepted spends survive refusal. Move refusal precedes drain; no published tile remains; filter restored; retry succeeds and the Graph remains usable.
5. Initial cancellation and absolute-depth refusal with no key spend; cache hit with valid relative depth; cache hit with bad relative depth at ample headroom; bad relative depth with zero remaining plan work explicitly expects the new plan-work refusal first. Empty-index miss performs no search comparison.
6. Existing native filter restoration and recursive-cycle guard behavior, late publication refusal, exact active/metadata restoration after returned temporaries drop, and outer Graph destruction before aggregate release. Parent Arc tests cover its own value-before-lease and named transfer lanes; parent index tests do not substitute a fake Arc layout.
7. Complete old-oracle semantic and canonical-work comparison in both Main/scoped source variants. Preserve source-variant WIP fields and old Three Tone window golden; that golden alone does not prove deep metadata capacity or this old actual tile path.

No runtime check has been run for this draft. It requires parent's review and authorized integration before compilation or execution.
