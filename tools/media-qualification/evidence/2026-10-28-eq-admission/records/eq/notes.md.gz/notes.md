# EQ native admission scratch candidate

This candidate changes scratch copies only. No live source edit, Cargo/rustc/native execution, test run, commit, new worktree, native estimate reduction, cap change, or pooling. The primary session owns review, application and compilation.

## Files and provenance

* `before/` contains byte-for-byte initial source/reference snapshots; `before-pins.json` records their SHA-256 hashes.
* `candidate/` contains only two modified source files and four new narrowly related test files. It is not a standalone checkout/crate.
* `eq-admission.patch` is the integration diff against the pinned before sources.
* `candidate-pins.json` and `candidate-sha256.txt` pin all candidate files and the patch.
* Read-only lifecycle/bound research is in `/tmp/deadpan-cold-context-2026-10-28/eq-admission.md`, with its own source hashes.

The primary reported the cold milestone at `b0088ba201333f87fd7f6a45fda91eebf37a72c5` and confirmed the captured node-builder bytes were unchanged. Finalization independently compares the two live owned files against the initial snapshots. No inherited WIP is removed from the scratch copies.

## Numerical change

`authored_eq.rs::eq_node` and `shared_eq.rs::shared_eq_node` become mutable methods. A new EQ node:

1. resolves its existing context and validates the treatment boundary;
2. computes the full published Equalizer bound: 2129928bytes /8 =266241 residency units;
3. computes checked prospective active and graph-resident totals;
4. keeps the existing4097-tap work charge, then calls existing `make_room(full_bound, false, control)` before native construction;
5. constructs the real Equalizer and runs the existing final control check;
6. publishes the complete node, then commits both already-checked residency totals with no intervening fallible Result step.

Any ordinary context/boundary/work/resident/native/cancellation/timeout failure before publication leaves the new native residency uncommitted; a locally constructed filter drops normally. The constructor cannot re-enter the exclusively borrowed StageAudio, so admission before synchronous construction covers its complete peak even though resident counters are committed only after successful construction/publication.

The SAME full published bound remains active for the whole owning graph lifetime. No smaller retained estimate is introduced. Existing numerical node hits add no new charge. A filter temporarily taken by tile preparation stays charged. Existing outer graph cleanup subtracts the graph total after both success and error. Tile PCM/prepared-frame allowances are unchanged.

Wet node creation retains its prior zero EQ charge. Event-local EQ already admits this same bound and is untouched. No coefficient, native DSP, PCM math, treatment order, query cache, clock lookup predicate or selection changes are included. Invalid internal treatment boundaries now fail before constructing a native filter, rather than afterward; valid execution is unchanged.

## Tests proposed for the primary to run

Four real tests are instantiated as two common checks in BOTH actual numerical graph modules. Thin adapters call the real node, tile and top-level renderer; they do not synthesize PCM, replace native filters, or substitute provider planning. Test fixture: one non-unity EQ over a512-sample440Hz Tone Hold at48000fps, no media. The provider refuses every unexpected source call.

`actual_node_requires_full_eq_native_headroom_and_retains_it_once`:

* exact cap one residency unit below the full native allowance refuses the real node and publishes no filter/node/residency;
* exact full allowance constructs the real native processor, charges active/graph totals exactly once, and reuses the numerical node without recharging/recompiling;
* the filter's charge remains while the Option is temporarily empty;
* the real tile entry refuses its additional PCM workspace at the exact cap, restores the taken filter, preserves the native charge, and leaves no tile;
* the performed6144 prepared-frame tile charge remains spent on that failure.

`numerical_read_refuses_small_native_budget_and_cleans_both_results`:

* the normal-cap real renderer returns nonzero finite PCM;
* two actual1-frame reads at half the native bound refuse and restore a sentinel active residency, rather than allowing unaccounted native allocation;
* a fresh request at full native allowance plus explicit PCM headroom succeeds on that same controller;
* PCM bits, suppression/exhaustion, dependencies and depth match the normal-cap renderer; both success/error graph cleanup restore the sentinel; no media is opened.

The common checks are located under:

* `stages::authored_eq::admission_tests::checks::*`;
* `stages::shared_eq::admission_tests::checks::*`.

The refusal test fails against the old numerical node behavior: the old constructor admits no native bytes and would create a node despite the one-unit-short cap. Provider call counts are not misrepresented as a native-constructor counter.

## Verification actually performed

* Scoped rustfmt on scratch owned/new files.
* `rustfmt --check` on both test adapters, their actual common child module path, and the fixture succeeded.
* Checked final candidate text for trailing whitespace.
* SHA-256 pins and unified integration patch generated in scratch.
* No Cargo/rustc/test/native run. Compile and runtime behavior remain unverified.

If correct native accounting makes a normal-path resource limit fail, report the actual failure and its required native residency. Do not lower the bound, raise a cap, refund work, mask the error, or add pooling. This candidate does not complete the separate recursive/cold resource proof or any product/Split gate.
