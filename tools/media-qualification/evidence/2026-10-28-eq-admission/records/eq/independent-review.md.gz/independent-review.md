# Independent review: EQ native residency admission

Scope: `/tmp/deadpan-eq-admission-2026-10-28/eq-admission.patch` against its pinned `before/` snapshots. I inspected both production hunks and the shared test fixture/adapters; no Cargo, rustc, Git, or live source changes.

## Findings

None supported in the assigned admission/lifetime lens.

## Evidence and limits

- Both `authored_eq::eq_node` and `shared_eq::shared_eq_node` compute the same full `Equalizer::preparation_bytes_bound()` in the existing 8-byte residency unit, with checked conversion/addition. They call `make_room` before native construction. The EQ fixed-work charge remains before admission; active and graph resident totals are committed only after native construction, the final control check, and node publication. The shared wet branch retains zero EQ residency.
- Cache hits return before any new preparation charge. Newly published EQ charges remain in `active_frames` and `graph.resident` through tile processing, including while the node temporarily takes its filter. Existing top-level cleanup subtracts `reservation + graph.resident` after either `Result` outcome. Tile failure restores the taken filter and does not publish a tile; the charge stays associated with the graph until its ordinary cleanup.
- The common test module is instantiated by both real graph modules through thin adapters. It checks one-unit-short refusal before node publication, exact-bound admission, no re-charge on an existing node, tile workspace refusal after taking the filter, retained filter/native charge, fixed tile work charge, repeated small-budget top-level failures without leaking the sentinel active count, and a full-budget render against a normal-cap render for PCM bits and metadata. The fixture uses an actual 512-frame tone and refuses media reads. These tests meaningfully distinguish the old uncharged native-node behavior; they were not run in this review.
- The full native bound is retained; no lower estimate, cap change, pooling, or error masking is introduced. Scope does not establish recursive/cold resource admission or any broader product gate.

One failure-path nuance is intentional in the candidate notes: a malformed treatment boundary is validated before native construction, while the old path checked it after construction. Valid-plan execution and the fixed work weight are preserved; this avoids creating an unpublishable native filter for an invalid boundary.

## Test architecture refactor addendum

Reviewed `/tmp/deadpan-eq-admission-2026-10-28/lint-fixed/test-architecture.patch`. No supported finding. The delta is confined to the four test files; production patch hunks are untouched. `checks.rs` is now compiled once beneath the fixture module and exposes generic common assertions through a narrow `Harness` interface. Both real graph modules retain actual `eq_node`/`shared_eq_node`, `eq_tile`/`shared_eq_tile`, and full numerical read entry points. The four wrappers still execute both checks for each graph; threshold, node reuse, native residency, taken-filter restoration, tile failure/work, cleanup, and bitwise PCM/metadata equality assertions remain in the shared body. The shared initializer keeps all current Graph fields; dropping `selected_family_count`, `canonical_families`, and `original_inputs` is only specified for the separately named published-source validation overlay. Parent reports focused pass evidence for the refactor; I did not compile or run it.
