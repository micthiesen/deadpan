from pathlib import Path
import difflib,hashlib,json,datetime
root=Path('/Users/michael/Code/deadpan')
out=Path('/tmp/deadpan-eq-admission-2026-10-28')
before=json.loads((out/'before-pins.json').read_text())
files=sorted(p for p in (out/'candidate').rglob('*') if p.is_file())
patch=[]
pins=[]
stats=[]
for candidate in files:
 rel=candidate.relative_to(out/'candidate').as_posix()
 original=out/'before'/rel
 old=original.read_text() if original.exists() else ''
 new=candidate.read_text()
 assert all(line==line.rstrip() for line in new.splitlines()), rel+' trailing whitespace'
 lines=list(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile='a/'+rel if original.exists() else '/dev/null',tofile='b/'+rel))
 if lines:
  patch.append(f'diff --git a/{rel} b/{rel}\n')
  if not original.exists(): patch.append('new file mode 100644\n')
  patch.extend(lines)
  stats.append({'path':rel,'new_file':not original.exists(),'added':sum(x.startswith('+') and not x.startswith('+++') for x in lines),'removed':sum(x.startswith('-') and not x.startswith('---') for x in lines)})
 data=candidate.read_bytes()
 pins.append({'path':rel,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest(),'new_file':not original.exists()})
changed=[]
for source in before['files']:
 if source['role']=='owned' and hashlib.sha256((root/source['path']).read_bytes()).hexdigest()!=source['sha256']:
  changed.append(source['path'])
(out/'eq-admission.patch').write_text(''.join(patch))
manifest={
'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
'live_owned_files_changed_since_snapshot':changed,
'candidate_files':pins,
'diff_stats':stats,
'patch_sha256':hashlib.sha256((out/'eq-admission.patch').read_bytes()).hexdigest(),
'notes_sha256':hashlib.sha256((out/'notes.md').read_bytes()).hexdigest(),
'no_build_or_runtime_checks':True,
}
(out/'candidate-pins.json').write_text(json.dumps(manifest,indent=2)+'\n')
(out/'candidate-sha256.txt').write_text(''.join(f"{p['sha256']}  {p['path']}\n" for p in pins))
print(json.dumps({'candidate_files':len(files),'patch_lines':len(''.join(patch).splitlines()),'live_owned_changed':changed,'patch_sha256':manifest['patch_sha256'],'notes_sha256':manifest['notes_sha256']},indent=2))
