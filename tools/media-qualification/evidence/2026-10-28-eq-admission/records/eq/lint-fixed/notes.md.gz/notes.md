# EQ admission test architecture, lint-fixed candidate

Distinct scratch revision. Original `candidate/`, `eq-admission.patch`, before/after hashes, and first-run evidence in the parent scratch directory remain unchanged.

The two production source copies are byte-for-byte identical to the original candidate. Only four test files change. No live source, Cargo/rustc, native execution, commit, cap, admission semantics, or assertion reduction.

`eq_admission/fixture.rs` now declares `checks.rs` once as its child module. The common checks define `Harness<'plan>` with associated Graph and real graph/node/tile/read adapters, plus narrowly scoped state/filter access used by the same assertions. Generic common functions borrow the fixture plan for the actual graph lifetime. They are not separately registered tests.

Each numerical graph test module implements that trait with its real private Graph and actual StageAudio entrypoints. Two small `#[test]` wrappers per graph invoke the common functions. All four tests still use the real native Equalizer and refusing media provider; no native or PCM mock is added. The exact threshold, reuse, taken-filter, tile failure/restore, spent frame, active/graph residency and successful PCM comparisons are preserved.

The common source is compiled once, so the previous repeated `#[path = "../eq_admission/checks.rs"]` declarations no longer trigger `clippy::duplicate_mod`. There is no lint suppression or duplicate assertion implementation.

## Integration artifacts

* `eq-admission.patch`: full candidate against the original pinned before files.
* `test-architecture.patch`: only the test-file delta from the original candidate, for the primary's already-integrated candidate.
* `candidate-pins.json`: hashes, production-identity assertion and patch hashes.
* `published-adapter.patch`: test-only adjustment for old published-source validation. Remove exactly the three inherited WIP Graph initializer fields `selected_family_count`, `canonical_families`, and `original_inputs`. Apply it only to that published validation tree. The primary/main adapter keeps all three fields.

Focused filter is now `admission_tests::` (the four actual wrappers), not `admission_tests::checks`, because the common checks are ordinary generic functions under the fixture module.

## Verification

Scoped rustfmt and `rustfmt --check` recursive test-child path resolution passed. Production byte identity checked by SHA-256. No build, strict lint, or runtime test performed in this worker revision. The primary reported four focused passes,277 library passes, and four old-published failures for the original architecture; these are preserved prior evidence, not a claim that this uncompiled architecture has passed.
