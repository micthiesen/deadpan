from pathlib import Path
import hashlib,json,gzip
s=Path(__file__).resolve().parent
repo=Path('/Users/michael/Code/deadpan')
dest=repo/'tools/media-qualification/evidence/2026-10-28-eq-admission'
assert not dest.exists(),'Archive only once all receipts are terminal'
allowed={'.rs','.json','.py','.md','.patch','.stdout','.stderr','.txt'}
entries=[]
sources=[('eq',p,p.relative_to(s)) for p in sorted(s.rglob('*')) if p.is_file() and p.suffix in allowed and p.name!='qualification-draft.md']
research=Path('/tmp/deadpan-cold-context-2026-10-28')
sources.extend(('research',p,p.relative_to(research)) for p in sorted(research.rglob('*')) if p.is_file() and (p.name.startswith('eq-') or 'eq-source-snapshot' in p.parts))
for group,p,relative in sources:
 data=p.read_bytes()
 if p.suffix=='.json':
  value=json.loads(data)
  if isinstance(value,dict) and 'command' in value and 'started_at' in value:
   assert 'exit_code' in value and value['sources_unchanged'] and value['binaries_unchanged'],str(p)
 out=dest/'records'/group/relative
 out=out.with_name(out.name+'.gz');out.parent.mkdir(parents=True,exist_ok=True)
 compressed=gzip.compress(data,mtime=0);out.write_bytes(compressed)
 entries.append({'path':str(out.relative_to(dest)),'bytes':len(compressed),'sha256':hashlib.sha256(compressed).hexdigest(),'expanded_bytes':len(data),'expanded_sha256':hashlib.sha256(data).hexdigest()})
manifest={'schema_version':1,'base_revision':(s/'base-revision.txt').read_text().strip(),'scope':'Six-file authored/shared native EQ admission fix; full 2129928-byte bound admitted before construction and retained for graph lifetime. Four actual graph tests fail old builders and pass patched. Test-only duplicate-mod refactor preserves production bytes and passing media lineage. Main retains unrelated WIP in shared_eq.rs and three fixture initializer fields. No cold recursive/batch or product gate completion.','prior_runtime_evidence':{'path':'../2026-10-28-cold-demand/inventory.json','inventory_sha256':'44c4b03efa2106ae01b65c60ac3698062da292376c742add2d6f8fa38a21b5a7'},'files':entries}
file=dest/'inventory.json';file.write_text(json.dumps(manifest,indent=2)+'\n')
stored=expanded=0
for row in entries:
 data=(dest/row['path']).read_bytes();plain=gzip.decompress(data)
 assert len(data)==row['bytes'] and hashlib.sha256(data).hexdigest()==row['sha256']
 assert len(plain)==row['expanded_bytes'] and hashlib.sha256(plain).hexdigest()==row['expanded_sha256']
 stored+=len(data);expanded+=len(plain)
print(json.dumps({'files':len(entries),'stored_bytes':stored,'expanded_bytes':expanded,'inventory_sha256':hashlib.sha256(file.read_bytes()).hexdigest()}))
