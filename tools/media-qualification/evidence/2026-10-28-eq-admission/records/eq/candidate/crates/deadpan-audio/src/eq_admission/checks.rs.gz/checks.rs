use super::*;
use crate::stages::authored_eq::eq_admission_fixture::*;

#[test]
fn actual_node_requires_full_eq_native_headroom_and_retains_it_once() {
    let plan = fixture();
    let owner = owner(&plan);
    let cancelled = AtomicBool::new(false);
    let native = units();
    assert_eq!(native, 266_241);
    for headroom in [native - 1, native] {
        let mut renderer = StageAudio::with_limits(
            Arc::clone(&plan),
            StageLimits {
                maximum_resident_frames: u32::try_from(BASE + headroom).unwrap(),
                ..Default::default()
            },
        )
        .unwrap();
        renderer.active_frames = BASE;
        let mut graph = graph(&plan);
        let work = RefCell::new(ReadWork::default());
        let control = control(&cancelled, &work);
        let result = node(&mut renderer, &mut graph, &owner, control);
        if headroom < native {
            assert!(matches!(
                result,
                Err(StageAudioError::Limit("resident PCM or stage cache"))
            ));
            assert!(graph.nodes.is_empty());
            assert_eq!(graph.resident, 0);
            assert_eq!(renderer.active_frames, BASE);
            assert!(work.borrow().plan_work >= deadpan_dsp::FINITE_FILTER_TAPS);
            continue;
        }
        let id = result.unwrap();
        assert_eq!(graph.nodes.len(), 1);
        assert!(graph.nodes[id].filter.is_some());
        assert_eq!(graph.resident, native);
        assert_eq!(renderer.active_frames, BASE + native);
        let spent = work.borrow().plan_work;
        assert_eq!(
            node(&mut renderer, &mut graph, &owner, control).unwrap(),
            id
        );
        assert_eq!(graph.nodes.len(), 1);
        assert_eq!(graph.resident, native);
        assert_eq!(renderer.active_frames, BASE + native);
        assert_eq!(work.borrow().plan_work, spent);

        let filter = graph.nodes[id].filter.take().unwrap();
        assert!(matches!(
            renderer.make_room(1, false, control),
            Err(StageAudioError::Limit("resident PCM or stage cache"))
        ));
        assert_eq!(renderer.active_frames, BASE + native);
        graph.nodes[id].filter = Some(filter);

        // The actual tile entry takes the filter, then refuses its separately
        // admitted PCM workspace. It must restore the same retained processor.
        let mut provider = NoSources(0);
        assert!(matches!(
            tile(&mut renderer, &mut provider, &mut graph, id, control),
            Err(StageAudioError::Limit("resident PCM or stage cache"))
        ));
        assert!(graph.nodes[id].filter.is_some());
        assert!(graph.nodes[id].tiles.is_empty());
        assert_eq!(graph.resident, native);
        assert_eq!(renderer.active_frames, BASE + native);
        assert_eq!(
            work.borrow().prepared_frames,
            (deadpan_dsp::FINITE_FILTER_INPUT_FRAMES + deadpan_dsp::FINITE_FILTER_OUTPUT_FRAMES)
                as u64
        );
        assert_eq!(provider.0, 0);
        renderer.active_frames -= graph.resident;
        drop(graph);
        assert_eq!(renderer.active_frames, BASE);
    }
}

#[test]
fn numerical_read_refuses_small_native_budget_and_cleans_both_results() {
    let plan = fixture();
    let cancelled = AtomicBool::new(false);
    let native = units();
    let mut provider = NoSources(0);
    let mut normal = StageAudio::new(Arc::clone(&plan));
    normal.active_frames = BASE;
    let normal_work = RefCell::new(ReadWork::default());
    let expected = read(
        &mut normal,
        &mut provider,
        control(&cancelled, &normal_work),
    )
    .unwrap();
    assert!(expected.samples.iter().any(|frame| *frame != [0.0; 2]));
    assert!(
        expected
            .samples
            .iter()
            .flatten()
            .all(|sample| sample.is_finite())
    );
    assert_eq!(normal.active_frames, BASE);

    let mut renderer = StageAudio::with_limits(
        Arc::clone(&plan),
        StageLimits {
            maximum_resident_frames: u32::try_from(BASE + native / 2).unwrap(),
            ..Default::default()
        },
    )
    .unwrap();
    renderer.active_frames = BASE;
    for _ in 0..2 {
        let work = RefCell::new(ReadWork::default());
        assert!(matches!(
            read(&mut renderer, &mut provider, control(&cancelled, &work)),
            Err(StageAudioError::Limit("resident PCM or stage cache"))
        ));
        assert_eq!(renderer.active_frames, BASE);
        assert!(work.borrow().plan_work >= deadpan_dsp::FINITE_FILTER_TAPS);
    }
    // A fresh request after ordinary graph failure must not inherit a leaked
    // native charge. This test adjustment is not a production error fallback.
    renderer.limits.maximum_resident_frames = u32::try_from(BASE + native + 65_536).unwrap();
    let work = RefCell::new(ReadWork::default());
    let actual = read(&mut renderer, &mut provider, control(&cancelled, &work)).unwrap();
    assert_eq!(actual.start, expected.start);
    assert_eq!(
        actual
            .samples
            .iter()
            .map(|frame| frame.map(f32::to_bits))
            .collect::<Vec<_>>(),
        expected
            .samples
            .iter()
            .map(|frame| frame.map(f32::to_bits))
            .collect::<Vec<_>>()
    );
    assert_eq!(actual.suppressed, expected.suppressed);
    assert_eq!(actual.exhausted, expected.exhausted);
    assert_eq!(actual.dependencies, expected.dependencies);
    assert_eq!(actual.relative_depth, expected.relative_depth);
    assert_eq!(renderer.active_frames, BASE);
    assert_eq!(provider.0, 0);
}
