use super::*;

fn graph(plan: &RenderPlan) -> Graph<'_, '_> {
    Graph {
        plan,
        nodes: Vec::new(),
        resident: 0,
        skip: &[],
    }
}

fn node<'plan>(
    renderer: &mut StageAudio,
    graph: &mut Graph<'plan, '_>,
    owner: &AudioOwnerClock<'plan>,
    control: WorkControl<'_>,
) -> Result<usize, StageAudioError> {
    renderer.eq_node(
        graph,
        Program {
            context: &Context::Root,
            stop: None,
            parent: usize::MAX,
            depth: 0,
        },
        owner,
        AudioSample(128),
        crate::stages::authored_eq::eq_admission_fixture::stage(owner),
        control,
    )
}

fn tile(
    renderer: &mut StageAudio,
    provider: &mut impl AudioSourceProvider,
    graph: &mut Graph<'_, '_>,
    id: usize,
    control: WorkControl<'_>,
) -> Result<(), StageAudioError> {
    renderer
        .eq_tile(provider, graph, id, 0, control, 1)
        .map(|_| ())
}

fn read(
    renderer: &mut StageAudio,
    provider: &mut impl AudioSourceProvider,
    control: WorkControl<'_>,
) -> Result<ReadBlock, StageAudioError> {
    renderer.read_authored_equalizers(provider, AudioSample(128), 1, control, 0, &[])
}

#[path = "../eq_admission/checks.rs"]
mod checks;
