use super::*;

fn graph(plan: &RenderPlan) -> Graph<'_> {
    Graph {
        plan,
        nodes: Vec::new(),
        resident: 0,
        wet_filters: std::array::from_fn(|_| None),
        event_tiles: BTreeMap::new(),
        event_nodes: Default::default(),
        event_filters: BTreeMap::new(),
        voices: BTreeMap::new(),
        permission_families: BTreeMap::new(),
        selected_family_count: 0,
        canonical_families: FamilyRegistry::default(),
        sends: None,
        skip: Vec::new(),
        original_only: true,
        original_inputs: original_inputs::Cache::default(),
    }
}

fn node<'plan>(
    renderer: &mut StageAudio,
    graph: &mut Graph<'plan>,
    owner: &AudioOwnerClock<'plan>,
    control: WorkControl<'_>,
) -> Result<usize, StageAudioError> {
    let context = Contexts {
        original: Context::Root,
        sounds: Sounds::None,
    };
    renderer.shared_eq_node(
        graph,
        Program {
            context: &context,
            stop: None,
            allowed: None,
            output_voice: None,
            parent: usize::MAX,
            depth: 0,
        },
        owner,
        AudioSample(128),
        Temporal::Equalizer(crate::stages::authored_eq::eq_admission_fixture::stage(
            owner,
        )),
        control,
    )
}

fn tile(
    renderer: &mut StageAudio,
    provider: &mut impl AudioSourceProvider,
    graph: &mut Graph<'_>,
    id: usize,
    control: WorkControl<'_>,
) -> Result<(), StageAudioError> {
    let mut permissions = Permissions::default();
    permissions.insert(0)?;
    renderer
        .shared_eq_tile(provider, graph, id, (0, permissions, None), control, 1)
        .map(|_| ())
}

fn read(
    renderer: &mut StageAudio,
    provider: &mut impl AudioSourceProvider,
    control: WorkControl<'_>,
) -> Result<ReadBlock, StageAudioError> {
    renderer.read_shared_input(
        provider,
        AudioSample(128),
        1,
        control,
        InputSelection::default(),
    )
}

#[path = "../eq_admission/checks.rs"]
mod checks;
