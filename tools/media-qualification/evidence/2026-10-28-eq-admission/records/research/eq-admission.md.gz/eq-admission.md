# Legacy numerical EQ native residency admission

Read-only follow-up. No Cargo/rustc/native execution, tests, live edits, or commits. Exact reviewed source bytes and snapshots are recorded in `eq-source-sha256.json`, `eq-source-sha256.txt`, and `eq-source-snapshot/` beside this note.

## Conclusion

**Admission is missing for the worker-owned filters created by both `shared_eq.rs::shared_eq_node` and `authored_eq.rs::eq_node`. No outer allowance covers them.** The event-local EQ path already admits and retains the existing conservative bound and is the numerical precedent to follow.

The smallest fix is two local numerical node-builder changes, not a cold resource framework: make those builders mutable, call the existing `make_room` with the full published EQ construction bound before `Equalizer::new`, and keep that same full bound in `active_frames` plus the owning `Graph.resident` until normal graph cleanup. Do not derive a smaller retained native estimate.

## Allocation and exact bound

`equalizer.rs::Equalizer` owns:

* `coefficients: Box<[f64; FINITE_FILTER_TAPS]>`, with4097 retained coefficients;
* `filter: Option<FiniteStereoFilter>` for a non-unity recipe;
* its copied recipe.

`Equalizer::new` computes coefficients, boxes them, then constructs `FiniteStereoFilter` for a non-unity recipe. `FiniteStereoFilter` owns the `ffi::FilterEngine` handle. The FFI `new` calls `dp_dsp_filter_create`, whose C++ implementation allocates `new FiniteFilter(coefficients)`.

The C++ `FiniteFilter` retains its portable FFT object, kernel, time buffer, spectrum, product and two-channel staged output. Its constructor initializes the kernel FFT. Its later `read` reuses those arrays; the Rust wrapper also uses fixed stack arrays for staged output. The native object remains alive until `FilterEngine::drop` calls `dp_dsp_filter_destroy`.

The authoritative bound is already published in `Equalizer::preparation_bytes_bound()`:

```text
INPUT.next_power_of_two() *128 +1_048_576 +TAPS*8
=8192*128 +1_048_576 +4097*8
=2_129_928 bytes
=266_241 existing f32-stereo residency units (8bytes/unit)
```

This is the existing conservative bound for portable FFT/native arrays plus retained coefficients. Input/output PCM is explicitly separate. It is not an RSS measurement and need not be reverse-engineered into a smaller C++ estimate. EQ currently publishes no distinct smaller retained bound. Use **266241 units for construction admission and keep all266241 units retained**. The fact that the constructor's local coefficient-generation stack arrays disappear does not authorize lowering the published native allowance.

The normal shared/authored owner traversal only dispatches non-unity EQ. If an internal helper accepts unity too, keeping the same conservative bound is safe; do not introduce special native-budget estimates as part of this fix.

## Why an outer reservation does not pay for it

| Location | Current allowance | What it covers |
| --- | --- | --- |
| `prepare_bus_inner` dispatch | No native EQ allowance before calling a shared/authored EQ reader | Selects the renderer; collecting result PCM is not a native filter reservation |
| `read_shared_input` | `3*requested_frames + original_inputs::Cache::resident_frames()` | Final/root PCM assembly and the fixed Original-cache metadata inventory |
| `read_authored_equalizers` | `3*requested_frames` | Final/root PCM assembly |
| `read_shared_program` | `12*chunk_frames + mix.resident_frames()` (later reduces only verified policy storage) | Current chunk's contributions, sum, raw processing and policy/mix storage |
| `read_eq_program` | `3*chunk_frames` | Current authored Original program PCM |
| `shared_eq_tile` / `eq_tile` | `2*INPUT +4*OUTPUT =14336 units` | Left/right f64 input histories, output staging and collection coexistence |
| successful tile insertion | `2*OUTPUT =2048 units` | Retained1024-frame f64 stereo output tile |
| Tail/Preserve caller reservations | Their own explicit PCM/preparation bounds | Those caller allocations remain live; they do not grant an untracked child filter allowance |

None scales with the number of resident EQ filter objects or adds `Equalizer::preparation_bytes_bound`. A very large root read may happen to reserve more bytes than one native filter, but that allowance already describes actual coexisting PCM and is not free native headroom. Several child/ancestor filters can coexist. A small1-sample read still constructs the same native FFT/filter, so window-sized allowances cannot establish the missing bound.

`StageAudio::make_room_for` sums cached PCM, `active_frames`, request-pinned projected residency, and the requested additional allowance. It can evict Original input/cache PCM, but never counts a native EQ object by inspecting a Graph. Therefore an EQ omitted from `active_frames` is invisible to every later admission, including nested EQ or wet construction.

The current event-local EQ path (`event_returns.rs`, inside `event_tile`) already does exactly the important part:

```text
charge TAPS work
resident =ceil(Equalizer::preparation_bytes_bound()/8)
make_room(resident)
Equalizer::new(...)
active_frames +=resident
graph.resident +=resident
insert event filter
```

The shared wet helper separately admits its larger construction bound and retains its published smaller native bound. EQ has no equivalent smaller contract, so preserve the entire EQ bound.

## Current numerical lifecycle and all Result cleanup boundaries

### New nodes

* Both owner builders currently take `&self`, which prevents native-budget eviction/admission there.
* They return an existing numerical node on their current lookup predicate, without constructing another filter. This research does not endorse that predicate as a cold ancestry proof or change it.
* On a new node, count limits/context queries happen first. Then TAPS4097 work is charged, `Equalizer::new` runs, `control.check` runs, and the node is pushed.
* Neither new-node branch calls `make_room` for EQ or increments `active_frames`/`graph.resident` for the filter.
* `owner.treatment_boundary(stage)?` currently occurs while constructing the pushed node, after filter creation. Precompute it before the new resident/native commit so a boundary refusal cannot leave a resident ledger increment without a published node.

### Tiles and temporary filter ownership

* Depth checks, exact tile cache lookup/relative-depth checks, checked tile arithmetic and context/boundary clones occur before taking the filter.
* The filter is taken from the node's Option before tile preparation, guarding against a recursive cycle. The native object is still alive in a local variable while recursive child reads occur.
* Input/output limit/work checks and `make_room(tile_workspace)` can fail after that take. The outer Result closure restores the filter to the node afterward in BOTH `shared_eq_tile` and `eq_tile`.
* After successful workspace admission, history/raw reads, source admission, cancellation/timeouts, numerical processing, output checks, and output-retention admission all live inside the inner Result closure. Whether success or error, the transient tile allowance is subtracted before restoring the filter.
* Successful tiles add their output PCM to `graph.resident`/`active_frames`. Failed tiles publish no output block. A native processing error may make the filter unusable, but its allocation stays owned until graph teardown and still needs residency accounting.

**The EQ filter's resident charge must stay active while the Option is empty and the filter is held locally.** Do not refund it on `take()` and re-charge on restore: nested work would otherwise see false headroom.

### Owning graph cleanup

* `read_shared_input` executes its fallible work in a closure. After either Result, it clears request-local Original-cache handles, subtracts `root_reservation +graph.resident`, and returns. Its local Graph then drops all node filters, event filters, wet processors, contexts and tile maps.
* `read_authored_equalizers` likewise subtracts `root_reservation +graph.resident` after its closure on success/error; its Graph drops all filters/tiles before the caller continues.
* Recursive child errors unwind through each tile closure, restore all taken filters, release each transient allowance, and eventually reach the single owning graph cleanup. Newly added filter residency belongs in that existing graph total, not in a second per-node cleanup path.
* An error before graph construction/root reservation does not need graph cleanup. An error while deriving a new node before publication should leave node count and native residency unchanged.
* `Equalizer::new` failure drops already constructed Rust/native members. The C++ constructor publishes only a fully built object; failed `new` construction unwinds its constructed members and the create wrapper returns no usable handle. Cancellation immediately after successful construction similarly drops the local filter before any node is published.
* Fatal allocator abort is outside Result recovery. Ordinary fallible boundary/context/work/resident/native/cancel/timeout failures must keep the accounting invariants above.

## Smallest numerical fix

Apply the same pattern separately to `shared_eq_node` and `eq_node`, without changing their request ordering, node-cache predicate, permissions or PCM math:

1. Change receiver to `&mut self`.
2. Preserve existing context/recipe validation. Compute the checked treatment boundary before the commit point.
3. For a new EQ, convert the **entire** published bound to residency units. Compute checked prospective `active_frames` and `graph.resident` totals before allocating native state.
4. Preserve the existing TAPS work charge. Call `self.make_room(full_bound, false, control)?` before `Equalizer::new`.
5. Construct the filter, then perform the existing final `control.check()?`. If any of those steps fails, the local filter drops and no native resident total is published.
6. Push the complete numerical node with the prechecked boundary and filter. With no remaining fallible Result step between publication and accounting, commit the prospective active/graph totals. Alternatively use a tiny existing-style helper that commits immediately before an otherwise infallible publication; ensure an intervening boundary failure cannot strand the charge.
7. Retain that full amount until the existing graph cleanup. Cache hits charge nothing again. Wet node creation contributes zero EQ charge. Leave tile PCM reservations and prepared-frame charging unchanged.

`make_room` followed by synchronous `Equalizer::new` is a valid construction-peak admission here: the constructor cannot re-enter this `&mut StageAudio`, allocate another stage through it, or run a later `make_room` between the admission check and completion. The established event EQ/wet paths use that pattern. No separate speculative resource framework or native memory measurement is needed.

Do not add the same allowance at the outer read or per tile: that either undercounts multiple simultaneous filters or charges a reused native filter repeatedly. Do not double-add event EQ residency, which is already accounted. A common helper can be considered later; two local fixes are sufficient and minimize unrelated changes.

There is also a caller-owned `PreparedOwnerEqualizer::new` API outside these Graph constructors. It creates a worker object without a StageAudio budget parameter; later reads accept that prebuilt object. This finding/fix concerns the two owned numerical Graph paths and does not claim a global StageLimits cap on externally constructed processor objects.

## Meaningful small-budget regressions

Use a headless qualified-free fixture: root non-unity EQ over a short Tone Hold, with no media. Reuse the style of `event_returns/tests.rs` (48000fps, e.g.512 samples, Tone440Hz at-6dB, `NoSources` provider that fails if called). Choose a genuinely non-unity EQ recipe. Native EQ is real; do not fake PCM or replace the filter. No real WAV is necessary to expose this missing native allocation.

### A. Exact native allowance / publication test, for each numerical graph

In a child unit test with access to the real graph/node builder:

1. Start with `BASE_RESIDENCY =17` active units and no evictable caches. Resolve a real root owner clock at sample128 through the plan's owner query.
2. Set `maximum_resident_frames =BASE_RESIDENCY +266241 -1`. Call the actual new-node builder. Expect `Limit("resident PCM or stage cache")`, zero new nodes, unchanged graph residency, and unchanged active frames. The old code returns a new node here, so the test fails against the old implementation for a real behavioral reason.
3. At `BASE_RESIDENCY +266241`, create exactly one filter successfully. Assert one node/filter, `graph.resident ==266241`, and active frames increased by exactly266241.
4. Request that same numerical node again. Assert no second native resident charge or duplicate node. Keep existing TAPS-work behavior: a new filter spends4097, a reused node does not recompile.
5. Take the filter into a local exactly as the real tile reader does, then attempt an additional1-unit admission at the exact cap. It must still fail; the allocation has not disappeared because the Option is empty. Restore the filter.
6. Drop/clean the graph under the owning cleanup and verify the base active count is restored. Also test a later ordinary failure after a published filter, so graph teardown releases previously retained EQ residency rather than only refusing a fresh filter.

Do not assert "native constructor was not called" using provider-call counts: EQ construction never uses the media provider. The real old-code-failing outcome at266240 available units plus absence of node publication is the meaningful admission witness. A test-only constructor hook is unnecessary.

### B. Real numerical read below the bound, plus cleanup and success

Exercise BOTH `read_authored_equalizers` and `read_shared_input` directly on the same Tone/EQ plan (the latter is the real private shared renderer even though this simple plan needs no independent media):

* Set the cap to half the full bound (`133120` units), retaining a small sentinel base active count. This comfortably exceeds the legacy short-read PCM/tile allowances, but cannot admit the native filter. A sample128,1-frame read must now refuse with the resident limit and restore the sentinel active count. It must not publish native/tile state or call the NoSources provider. Before the fix the two owner-node constructors do not charge the native bound and this small Tone read can render, which is the regression.
* With `BASE +266241 +65536` units, the same read should succeed, remain nonzero/finite, and match the normal-cap result's exact PCM/suppression/dependencies/depth. Verify active frames restore to the sentinel after success too.
* Repeat a small-cap failure on the same controller, then a normal-cap successful retry with a fresh request budget. This checks no stale node/filter accounting survives graph teardown. It is a test operation, not a production fallback on an error.
* Retain existing work, deadline, cancellation, source and prepared-frame counters; do not reset/refund a production failure's work to make this pass.

A smaller standalone helper test can cover cancel/timeout/work refusal immediately before publication, analogous to existing wet helper tests, but it does not replace at least one old-code-failing actual node/read regression. All native-platform checks must be run by the primary session before claiming the fix works.

## Scope and remaining uncertainty

This is a confirmed accounting omission by source inspection, not a measured RSS claim. Exact source-level allocation bound and ownership paths are identified; no runtime test was run in this research. Newly charged legitimate residency can expose configurations which were previously passing only because native memory was invisible. Do not raise ceilings or lower the native bound to preserve such passes. Re-run the numerical gates and product matrix after the small fix; do not close the future recursive/batched proof on that basis.

## Exact source SHA-256

```text
5d13199e931af535e9aecd9462da9b5f2f094dccc48d817bc73fde0920a4a8f3  crates/deadpan-audio/src/equalizer.rs
1ab40d68d676118e28c9c3874271f0ee670eb5fab850711f547de2144aff0a32  crates/deadpan-audio/src/shared_eq.rs
da4e6ca83f259c208697bffb1ae7b5936d43f0ac8dd29c75bde6332d2a37922a  crates/deadpan-audio/src/authored_eq.rs
22a3cd864bf8bbcfa254a068407751a2d465e51230d10fd9b1b65585ad9915e8  crates/deadpan-audio/src/event_returns.rs
accd73f4397687bcdf417ddd221f292078e4f1c6e3a09340d48edf8d786e8b28  crates/deadpan-audio/src/finite_wet.rs
f46d5d0423bf1874165e2f0c97d5453aa2e33186982254b9cef226ea2e5e2a83  crates/deadpan-audio/src/stages.rs
ecb1b57a64395b53a3e776fa9b80372805ce51d13271f368160f0bc6bd760fb1  crates/deadpan-audio/src/sound_events.rs
ce58a42a5fc50b07f80c153579443186243c07147dbac2800bb40da73a6a6cba  crates/deadpan-audio/src/owner_equalizer.rs
bec6a141ea46f6734dab8acba9e0a95a86f25c0abcc5296ac8b16b14f364300b  crates/deadpan-audio/src/shared_eq/original_inputs.rs
413e90261b1e77b41e5838f873fdcff1599b4691725e345579aca329de4381b9  crates/deadpan-audio/src/shared_eq/permission_families.rs
4afe21954dff8cae4567f6c3bbb8c026740517401fd980aa6a7e26ed20233749  crates/deadpan-audio/src/event_returns/tests.rs
5ce90756aa91a2aebebb5857bb9ae07276851a669bdc6afddd4f4ee00596ee8e  native/deadpan-dsp/src/finite_filter.rs
46f8d7d75a5a00a023cf4f0bc06649b470e0167aa911b221552aee0f21bca252  native/deadpan-dsp/src/ffi/finite_filter.rs
97ffa7684c11174757c47b9c27ba5643121f801b3a60c24d999f13ebc25863da  native/deadpan-dsp/src/finite_filter.cpp
```
