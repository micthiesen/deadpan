from pathlib import Path
import re,json,hashlib
s=Path(__file__).resolve().parent
label='selected-post-policy-profile'
r=json.loads((s/(label+'.json')).read_text())
assert r['exit_code']==101 and r['sources_unchanged']and r['binaries_unchanged']
raw=(s/(label+'.stderr')).read_text()
begin=[x for x in raw.splitlines()if x.startswith('DP_WORK_TRACE_BEGIN ')]
assert len(begin)==1 and raw.count('DP_WORK_TRACE_END')==1
assert 'DP_WORK_TRACE_UNAVAILABLE'not in raw and 'DP_CORE_LOCAL_OVERFLOW'not in raw
line=begin[0]
assert 'conserved=true'in line and 'overflow_calls=[0, 0]'in line and 'overflow_units=[0, 0]'in line
num=lambda key:int(re.search(r'\b'+key+r'=(\d+)',line).group(1))
assert num('canonical')==num('accepted_canonical')and num('cache')==num('accepted_cache')
failure=re.search(r'^one selected play, revision prefix-two, limited 0\+4096: (.+)$',raw,re.M).group(1)
assert failure=='Stage(Limit("plan work per read"))'
assert num('canonical_remaining')<65536
sites=[]
for text in raw.splitlines():
 if not text.startswith('DP_WORK_SITE '):continue
 fields=dict(re.findall(r'(\w+)=(\S+)',text))
 file,row,col=fields['site'].rsplit(':',2)
 sites.append({'cache':fields['cache']=='true','admission':fields['admission']=='true','transfer_identity':fields['transfer_identity'],'calls':int(fields['calls']),'units':int(fields['units']),'file':file,'line':int(row),'column':int(col)})
assert sum(x['units']for x in sites if not x['cache'])==num('canonical')
assert sum(x['units']for x in sites if x['cache'])==num('cache')
hits=[x for x in raw.splitlines()if x.startswith('DP_ORIGINAL_PCM_HITS ')]
assert len(hits)==1
pcm={k:int(v)for k,v in re.findall(r'(\w+)=(\d+)',hits[0])}
keys=['prepared_flat_work','prepared_processing_work','prepared_policy_work','prepared_fades_work']
files={}
for row in sites:
 files[row['file']]=files.get(row['file'],0)+row['units']
transfer={key:sum(x['units']for x in sites if x['transfer_identity']==key)for key in ['true','false']}
mapping={127:'Domain flattened',131:'Domain fades',205:'Domain first processing',208:'Domain newly performed policy'}
attributed=[]
for row in sites:
 if row['file'].endswith('/original_request.rs')and row['line']in mapping:
  attributed.append({'operation':mapping[row['line']],**row})
result={'base_revision':(s/'base-revision.txt').read_text().strip(),'validity':'same exact outer prefix-two limited0+4096 work-refusal, same exact observed prefix as current uninstrumented reference','failure':failure,'canonical':num('canonical'),'cache':num('cache'),'canonical_remaining':num('canonical_remaining'),'conserved':True,'overflow':False,'pcm_hit_probe':pcm,'already_billed_query_work_at_successful_prepared_pcm_hits':sum(pcm[k]for k in keys),'pcm_hit_query_units_are_not_free_savings':'They still feed prediction before payload lookup; retention requires complete metadata admission. Nonadditive and not comparable as net savings against the older cap-truncated profile.','transfer_units_by_actual_identity':transfer,'original_request_bill_attribution':attributed,'files':sorted([{'file':k,'units':v}for k,v in files.items()],key=lambda x:-x['units']),'sites':sorted(sites,key=lambda x:-x['units']),'seconds':r['seconds'],'no_latency_peak_memory_or_acceptance_claim':True}
(s/(label+'-analysis.json')).write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items()if k not in ['sites','files']}))
