# Post-policy diagnostic-only work profile

Frozen ordinary diagnostic copy based on production d0d850207079c389d6820c6288eb1cbf92df4fd7. The production domain-policy first-tape reuse remains intact. Only the seven owned existing diagnostic files and one new module change. All 1,513 pinned main inputs remain byte-identical; 1,506 diagnostic baseline inputs outside those seven files remain byte-identical. No Cargo, native execution or Git command was run by this worker.

`before/` and `before-pins.json` capture every existing owned source before edits. `candidate.patch` is the complete narrow patch. `candidate-pins.json` pins all eight resulting sources. All eight files passed standalone rustfmt with edition 2024 and skip_children=true. Static verification confirmed the entire prepare_bus_inner body is byte-identical inside prepare_bus_diagnostic_inner. No compilation or witness acceptance is claimed here.

## Accepted global work and transfer labels

This ports the verified phase 1/2 instrumentation from /tmp/deadpan-split-work-profile-2026-10-29/instrumentation and instrumentation-phase2. ReadWork owns a fixed 512-slot open-addressed table keyed by the static caller Location pointer, canonical/cache lane, direct/admission category and optional actual transfer-identity label. There is no per-charge allocation, formatting, string hash or output. Lookup is bounded by 512 slots; full-table work enters explicit overflow counters. Detailed attribution requires zero overflow in both lanes.

All original checks, amounts, counter caps and assignment order remain. Global acceptance records only after the original checked assignment succeeds. Cancellation/deadline and limit refusals enter a separate rejected field without adding accepted units; try_borrow_mut preserves the original cancellation/error path if the optional record cannot borrow. The admission adapter labels the actual construction site. PreparedTransfer::apply_wide labels its actual billed caller and existing is_identity() result while always billing the original 1 + stages.len() before applying the transfer. It skips no sample operation or charge.

The preparation wrapper dumps once per actual ReadWork on errors, including propagated Core/Plan errors. It copies trace and authoritative counters, releases the RefCell borrow, then formats. Unavailable snapshots print an explicit incomplete marker. DP_WORK_TRACE_BEGIN compares both traced lane sums including overflow to the authoritative canonical/cache counters; conserved=true plus zero overflow is required. DP_WORK_QUERY records the most recent successful query_limits remaining allowance and actual local cap. DP_WORK_REJECT stays outside accepted totals; DP_WORK_SITE lists accepted attribution; DP_WORK_TRACE_END completes the block.

## Exact successful PCM payload returns

Only the phase 3 PCM probe is retained. At the existing successful Read::Cached return in shared_eq/original_inputs.rs, after exact prepared request, context/range/depth, dependency/fingerprint readmission and final control.check, it records prepared Some/None and the existing RootReadQueries already-billed flat/processing/policy/fades work scalars, plus fades-present count. It borrows query products without new lookup, clone, walk, charge or bypass. DP_ORIGINAL_PCM_HITS is explicitly nonadditive. try_borrow_mut passively skips the optional record if borrowed.

No old AudioDomain policy observer, PolicySample, PolicyTotals, false-mode processing query or original_request method instrumentation is ported. Those would misrepresent the new production first-tape reuse. AudioDomain policy and original_request.rs remain baseline-identical.

## Core local refusals

Core binding Work::spend retains its original committed increment before maximum refusal; arithmetic overflow leaves used unchanged. Work::remaining retains its refusal without mutation. Build::local projection and audio_reference::spend retain checked-filter assignment, leaving used unchanged on refusal. track_caller forwards structural caller locations; Location is captured outside error closures. DP_CORE_LOCAL_REFUSAL includes sequence, seam, local counter identity, raw before/attempted/after/maximum and site. Those raw local amounts must never be added to globally forwarded units. The shared 64-record cap emits DP_CORE_LOCAL_OVERFLOW on the next event, invalidating complete local attribution.

## Parent acceptance owed

Update the source guard to include the one new module. Build the optimized existing exact one-explicit-play filter and preserve its command/environment, all source/executable pins, stdout/stderr, and raw failure prefix. Require the same outer prefix-two limited 0+4096 resource-exhaustion witness, authoritative global conservation, and zero table overflow. Reject a diagnosis if instrumentation changes the witness to a timeout or unrelated error. Preserve near-cap prefix variation verbatim. Instrumented time, stack and memory are not performance evidence. This remains discovery for the next bottleneck; no production optimization, weights/caps/refunds, cold/batch activation or numerical changes are included.
