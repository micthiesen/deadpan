# Prepared Original query retention: ownership and accounting constraints

Read-only source analysis, 2026-10-29. No Cargo, native runs, Git operations, implementation, or performance claims. Paths below are relative to /Users/michael/Code/deadpan. This cache integration is inherited Main WIP, not the published d0d850207 Plan API checkpoint; publication details are clarified in the follow-up below.

## Answer

The successful **RootReadQueries<'plan> payload can be moved** into the existing request-local Cache<'plan> without self-reference. The complete PreparedOriginalRequest cannot simply become an entry field: its Origin::Domain borrows an AudioDomain for a separate, potentially shorter 'context lifetime. Moving the payload requires a new consuming extraction/validated-holder seam, and reuse before prediction requires moving the cache lookup earlier. The existing APIs do not already implement those seams.

RootReadQueries holds owned flattened/processing/policy/fade query values; its only lifetime is the processing query's 'plan. AudioDomain::processing returns AudioProcessingQuery<'plan>, explicitly independent of its &self borrow. Processing spans' Stage/Bound/ProjectedStage operands retain plan references and owned metadata, not references to the originating AudioDomain or PreparedOriginalRequest. Thus retaining a Context::Domain Arc next to these products is not self-referential. Root queries borrow Graph's externally pinned RenderPlan, whose local Arc lives until Graph cleanup.

Sources: stages.rs:366-392; original_request.rs:7-23,108-148; deadpan-plan/src/audio_domain.rs:427-450; deadpan-plan/src/audio_signal.rs:574-603; shared_eq.rs:222-242,295-301.

## Holder and borrow seams

- PreparedOriginalRequest owns queries privately and exposes only queries(&self). Origin::Domain(&'context AudioDomain<'plan>) plus start/frames/edge_fades is its exact-match validation receipt. matches_domain requires same plan AND same domain address. Extracting only products must preserve an equally exact validation boundary; a content-equivalent reconstructed Domain is not the current key. Context already retains the domain identity Arc.
- Cache's Entry<'plan> can own RootReadQueries<'plan> directly. StageAudio's controller map cannot own it unchanged: StageAudio has no 'plan parameter and may outlive this request's borrowed Graph plan. The existing controller Cached owns only Arc<ReadBlock> and a resident count.
- Prediction already consumes RootReadQueriesRef<'query,'plan>; it can borrow a stored payload for a bounded scope. Current read_shared_program instead creates prepared_original before policy_prediction::populate and only then calls shared_original_input_prepared. Moving just post-read retention changes nothing about the next pre-prediction construction.
- read_prepared_original consumes PreparedOriginalRequest; shared_original_input_prepared also consumes it. Neither accepts a cache-borrowed query holder. read_queries_borrowed exists and can process a RootReadQueriesRef, but it is beneath the Origin validation boundary. A borrowed public-to-this-module entry point must retain equivalent identity/range/fade/depth/preflight checks.
- A query reference borrowed from graph.original_inputs cannot remain live across a call taking &mut Graph (shared_original_input_mode and recursive read work). Even though the values are not self-referential, this is a real ordinary Rust aliasing seam. Prediction's borrow can end before mutable cache use; miss-path reading would need independent owned access or temporary ownership separation. An Arc-held query value would permit an independent owning handle, but then the Arc allocation, ownership/pinning, resident charge, and eviction must all be covered. This is a constraint, not a proposed design.
- An exact PCM hit does not numerically read queries at present. The products are required for prediction; the hit path uses context/range/depth validation and fresh dependency resolution/fingerprints. Query reuse cannot replace those live checks. A stale PCM key can coexist with useful products only if their separate charge and lifetime are explicit.

Sources: original_request.rs:13-50,151-190; shared_eq/policy_prediction.rs:11-49,118-145; shared_eq.rs:497-576; shared_eq/original_inputs.rs:14-45,311-420; authored_eq.rs:55-60; stages.rs:1831-1855.

## Existing bounded heap machinery and concrete closure gaps

deadpan-plan/src/audio_allocated.rs supplies OwnedHeap, HeapBudget, measure and public allocated_bytes_bound. It uses checked byte arithmetic, actual Vec capacities, traversal-work limits, MAX_DOCUMENT_DEPTH, Box/Arc shells, identifier Arc text and recursively owned values. It conservatively charges shared Arc allocation at each owning edge and excludes borrowed RenderPlan storage and the measured inline root handle. It measures an already constructed graph; it does not admit transient construction.

**AudioProcessingQuery already has a complete existing OwnedHeap/public allocated_bytes_bound path**, including project/revision IDs, span capacity, definition/instance/gap IDs, retimes, AudioSignalContent, Stage, AudioBound, and projected operands. AudioBound already visits definition, instance, DomainGap, ResolvedAudioBinding, and its constraints vector. EnvelopeConstraint includes its gap_after identity. Domain/point/projection/signal visitors recursively cover their owned vectors and boxes. Do not count “Bound vectors” as a wholly missing visitor: they are covered through this existing path, but must remain included in any retained whole-query charge.

Concrete missing whole-product closures/API coverage for this candidate:

1. AudioQuery: no OwnedHeap/public byte-bound path. Needs project/revision identifiers and actual Vec<AudioSpan> capacity.
2. AudioSpan: needs exhaustive owned-field visitor for definition, AudioBoundaries, instance, gap_after, retimes and AudioContent. Time ranges/transforms/grid/sampling/envelope are inline scalar-only values.
3. AudioBoundaries: both Vec<AudioBoundaryOrigin> capacities and their elements. AudioBoundaryOrigin must visit instance and gap_after; its kind, placement_support and policy are inline.
4. AudioPolicyQuery<AudioSample>: suppressed Vec<Range<AudioSample>> capacity plus contents Vec<AudioContent> capacity and recursively owned source identifiers. Scalar-only range vectors need charged bounded traversal/storage even if no generic Range visitor exists. Generic policy S would require an appropriate bound or deliberately concrete implementation.
5. AudioFadeQuery -> Vec<AudioFadeSpan> -> each start/end Vec<AudioFadeEdge> -> each origins Vec<AudioBoundaryOrigin> -> instance/repeat/iteration identities. All actual capacities must count, not just outer spans or length. at/length/distance/editorial/sample ranges are inline.
6. RootReadQueries/retained holder aggregate: no common measure/admitted wrapper exists. Sum all four complete closures with checked arithmetic and bounded paid traversal; include any new Box/Arc shell. Cache::resident_frames currently covers size_of<Cache>, so an added inline Option<RootReadQueries> shell would enlarge that fixed reservation, but it covers none of the query heap.

Sources: audio_allocated.rs:1-107,110-185,219-297,350-374; audio_bound.rs:54-74,110-133; audio_domain.rs:218-297; audio.rs:242-271,301-312; audio_policy.rs:14-23; audio_fades.rs:20-43; audio_boundary.rs:20-42; audio_signal.rs:658-702.

The existing **admission** backend is sound_context_admission::Admission/Lease: reserve checks cancellation, checked bytes-to-frame accounting and make_room, increments ReadWork.sound_context_frames; Lease::drop releases it. make_room_for includes cached PCM, active_frames, projected frames and sound_context_frames. Existing admitted owner/context/binding constructors show pre-reservation, issuer checks, retained leases and transfer mechanics, but the ordinary RootReadQueries constructors do not return such a lease.

A Lease<'work> cannot be added to Cache<'plan> without also threading 'work into its owning type, or using another explicitly accounted ownership mechanism (Graph already has both lifetimes and resident accounting). A raw byte count alone is not a reservation. Measuring products after construction is useful admission before retention, but cannot claim a whole-construction peak bound. Also note original_inputs' local optional-PCM fits expression at lines 473-481 currently sums cached/active/projected/resident, unlike make_room_for it omits sound_context_frames; a new query reservation must not assume that expression accounts for it.

Sources: sound_context_admission.rs:21-30,138-192; shared_eq.rs:94-111,295-301; stages.rs:2464-2511; shared_eq/original_inputs.rs:115-120,472-481; deadpan-plan/src/audio_bound_query.rs:43-56,104-139; audio_context_sharing.rs:28-37.

## Eviction and failure constraints

Current fixed slots/bucket links/LRU bound identity count, not variable product bytes. Query retention needs admission before publication and a matching release on every remove, clear, graph teardown, rejected insertion and error. PCM eviction from StageAudio can leave its Graph entry stale; query heap retained by that stale entry would remain resident and cannot be decremented merely because PCM disappeared. Conversely, evicting an entry drops its query metadata and must release that charge even if a PCM reader still pins the block.

Current eviction avoids active PCM readers using Arc::strong_count==1. That does not establish whether a separately pinned query holder is unused. Any separate Arc products would need a defined pin/removal policy and a charge that survives until the last owner drops. The 64 slots cannot justify unmetered retained query DAGs. Preserve optional-cache fallback when byte/work admission fails, cumulative work accounting (no re-billing prior query construction), exact context/range/depth/controller scope, cancellation, nested-depth checks, and source admission/fingerprint checks on warm PCM.

Sources: shared_eq/original_inputs.rs:123-139,192-231,286-299,379-414,435-520; shared_eq.rs:295-301.

This establishes feasibility with bounded ownership/API/accounting work. It does not establish that retaining these products is the next measured bottleneck or that a cache expansion is approved.

## Follow-up: omitted metadata term is a reachable admission defect

**Concrete source-level finding:** this is not a conservative precheck followed by an enforcing allocation gate. It can publish optional Original PCM while the ledger's total exceeds maximum_resident_frames. This is an accounting-limit violation; no native failure or measured physical-memory overrun is claimed.

Exact order in shared_original_input_mode:

1. Validate scope/domain/range/depth and optional request (345-378), then try exact cache hit.
2. On miss, perform the actual fresh raw read (416-438) and final control.check (440). For the existing fixture's 0..64 Source region this takes the Leaf Source branch in read_queries_borrowed (stages.rs:1851-1877); it does not call StageAudio::make_room.
3. Compute resident(&block), then loop on cached + active + projected + candidate resident (441-492). sound_context_frames is omitted.
4. Once that succeeds, construct Arc<ReadBlock>, insert the key, insert Cached and return it (493-519). Cache::insert only bills fixed plan work and mutates links (235-255); it does not reserve memory or call make_room_for. No aggregate enforcement follows the loop.

Live real metadata is reachable in the inherited Main WIP path: read_shared_program obtains owners via Context::owners_admitted and Admission::new at shared_eq.rs:327-341, then keeps that admitted owner query alive across shared_original_input[_prepared] at 569-589 so it can use owners.query() afterward. The mix reservation make_room call is earlier (shared_eq.rs:521-526), before the optional candidate is added. Later make_room calls can repair an unpinned optional cache by eviction, but do not retroactively validate this publication, and this read can return without any such call.

Small **unrun test outline**, suitable for shared_eq/original_inputs_tests.rs using its existing fixture()/graph()/control() and real owner constructor, with no invented ledger reservations:

- Use fixture()'s real WAV-backed Source interval 0..64 (stages.rs:3340-3341). Obtain a reference block with read_controlled and calculate P = resident(&block).unwrap(); drop it. The leaf path leaves no prepared stage cache; assert cached_resident_frames()==0.
- On a measurement renderer/ledger, construct actual Context::Root.owners_admitted(&plan, range, control, &mut Admission::new(...)); record M = work.sound_context_frames and assert M>0. Drop it and assert M returns to zero.
- Use a fresh renderer, fresh finite ReadWork, graph and provider. Set maximum_resident_frames = checked_u32(P + M - 1). Construct the same actual owners_admitted query under this finite limit; assert its live charge is M and all nonmetadata resident terms remain zero. M alone fits because P>=1.
- Keep that query alive. Call shared_original_input for Root, 0..64, depth 0. Existing code returns Read::Cached, with resident P; assert samples/masks equal the reference and provider readmission occurred. At this point cached_resident_frames + active_frames + projected_resident_frames + sound_context_frames == P+M > limit. This assertion establishes the current bug with a real finite lease, not a fabricated sound_context_frames assignment.
- The corrected behavior is successful Read::Fresh with the same samples/masks/dependencies and no new cache entry, because optional memoization cannot fit while the real owners query is live. Drop owners, assert lease release, clear graph and assert no retained cache/active accounting. An additional sufficient-room case at P+M should still cache.

Minimal fix is a checked_add of control.work.borrow().sound_context_frames in the local fits chain before adding resident, preserving the existing optional-cache eviction/fresh fallback. Replacing it with make_room_for would change policy by allowing this optional memoization to evict unrelated prepared stages or fail an otherwise valid fresh read, contrary to the comment at lines 485-487.

Scope correction: this is an **inherited Main WIP finding**, not a finding against the published Plan API checkpoint. The frozen diagnostic baseline's instrumentation/before/crates/deadpan-audio/src/shared_eq/original_inputs.rs is byte-identical to live Main (cmp exit 0), but its base-revision.txt names a Git base, not the provenance of every overlaid WIP source body. The actual /tmp/deadpan-query-groundwork-2026-10-26/scoped tree has no original_inputs.rs; its shared_eq.rs neither declares the module nor has a Graph.original_inputs field or shared_original_input calls, and scoped stages.rs has no original_inputs integration. Scoped shared_eq.rs:622-634 instead directly consumes read_prepared_original or read_controlled. Thus this optional cache defect is outside that TaskScope source body. Parent can establish tracked publication history independently; no Git command was used here. No code was changed and the outlined test has not run.
