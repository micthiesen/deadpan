from pathlib import Path
import json,hashlib
s=Path(__file__).resolve().parent
repo=Path('/Users/michael/Code/deadpan')
rows=[]
for label,code in [('post-policy-profile-build1',0),('selected-post-policy-profile',101)]:
 p=s/(label+'.json');r=json.loads(p.read_text())
 assert r['exit_code']==code and r['sources_unchanged']and r['binaries_unchanged']
 for path,h in r['streams'].items():
  b=Path(path).read_bytes();assert len(b)==h['bytes']and hashlib.sha256(b).hexdigest()==h['sha256']
 for path,h in r['source_after'].items():
  b=Path(path).read_bytes();assert len(b)==h['bytes']and hashlib.sha256(b).hexdigest()==h['sha256']
 rows.append({'label':label,'exit_code':code,'seconds':r['seconds'],'source_inputs':len(r['source_before']),'receipt_sha256':hashlib.sha256(p.read_bytes()).hexdigest()})
baseline=json.loads((s/'main-baseline-pins.json').read_text())
for path,h in baseline.items():
 b=(repo/path).read_bytes();assert len(b)==h['bytes']and hashlib.sha256(b).hexdigest()==h['sha256'],path
a=json.loads((s/'selected-post-policy-profile-analysis.json').read_text());assert a['conserved']and not a['overflow']and a['canonical']==16777216
result={'all_terminal':True,'all_main_baseline_inputs_preserved_before_next_task':len(baseline),'all_guarded_sources_and_executable_and_streams_verified':True,'same_outer_and_exact_reference_work_refusal':True,'global_work_conserved':True,'table_overflow':False,'runs':rows,'accepted_canonical':a['canonical'],'already_billed_query_units_before_actual_pcm_hits':a['already_billed_query_work_at_successful_prepared_pcm_hits'],'actual_prepared_pcm_hits':a['pcm_hit_probe']['prepared'],'no_savings_latency_memory_or_acceptance_claim':True}
(s/'profile-audit.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result))
