# Frozen optional Original PCM cache port

Target: /tmp/deadpan-query-groundwork-2026-10-26/scoped
Nine owned files changed: three new cache/test modules, six selective integration/fixture edits. Added 14 cache/prepared tests, including the real held-owner metadata boundary regression.

Production slices:
- StageAudio owns optional cache payloads, monotonic keys and controller identity; cached residency and entry limits include both caches; required pressure evicts unpinned optional Original inputs before prepared stages.
- Graph reserves its fixed cache shell before construction, owns cache identities, clears matching payloads before teardown, and releases its existing reservation.
- read_shared_program routes the prepared/nonprepared Original read through the cache, clones dependency handles from its borrowed result, and drops the PCM pin before later sound returns.
- The optional-fit sum includes checked live sound_context_frames and preserves Fresh fallback on insufficient room.

Scope permission_families, selected_split_families, aliases and graph-node selection remain unchanged. Main selected_family_count, canonical_families, FamilyRegistry and adjacent helper WIP were not imported. No Main source was edited.

The two new test files match Main except the Original fixture omits Main's two family-only Graph fields. original_inputs.rs matches the fixed Main source verbatim. Existing four fixture files only initialize original_inputs.

Verification performed by worker: targeted rustfmt with skip_children=true on the nine owned paths; entire existing-file diff reviewed; all new cache/test source reviewed; Graph literals and StageAudio constructors searched. No Cargo/native/Git operations. Parent owns guarded compilation, tests and publication.

Frozen sources are in port-candidate/, exact unified diff is port-candidate.patch, hashes and byte lengths are port-candidate.json.
The fixed Arc scope shell and empty BTreeMap root release findings are deliberately left for the parent's next integration unit.
