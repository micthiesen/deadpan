# Original PCM cache shell accounting

Read-only source research, 2026-10-29. Main and scoped source remain untouched; no Cargo, compiler/native executable, or Git ran. Official pinned Rust source copies are scratch evidence only.

## Publishable recommendation

The parent's proposed closure is sufficient for the cache's newly retained allocation layouts on the supported aarch64-apple-darwin target and pinned Rust 1.97.1:

1. In Cache::resident_frames, add exactly the scope Arc's two-usize header to the existing inline Cache size before converting to u64/frame units.
2. Centralize controller payload removal; after removing a key, if original_inputs.is_empty(), drop its remaining BTreeMap root by replacing the map with BTreeMap::new(). Use this at the three payload-removal sites in Cache::clear, evict_original_input and request-key capacity eviction.
3. Keep the checked sound_context_frames addition and current optional fresh-read fallback.

Smallest arithmetic expression for the fixed reservation (avoids any unchecked multiplication):

    let bytes = std::mem::size_of::<Self>()
        .checked_add(std::mem::size_of::<[usize; 2]>())
        .ok_or(StageAudioError::Range)?;
    Ok(u64::try_from(bytes)
        .map_err(|_| StageAudioError::Range)?
        .div_ceil(8))

size_of::<[usize;2]>() equals 2*size_of::<usize>() with array size computed by the compiler. On the supported target this is 16 bytes, so the delta is two stereo-f32 frame units. It conservatively charges the shared controller token for each active request Graph rather than inventing a new identity mechanism.

Suggested qualification comment: “Rust 1.97.1 ArcInner<()> is two pointer-sized atomic counters plus a unit payload; cover that controller identity allocation as well as the inline lookup slots.” This counts requested Rust allocation layouts, consistently with the existing resident ledger, not malloc size-class rounding/allocator-private bookkeeping or physical process RSS.

## Exact scope Arc and existing block Arc convention

rust-toolchain.toml pins 1.97.1. Local rustup manifest identifies 1.97.1 (8bab26f4f 2026-07-14), distribution 2026-07-16. docs/PACKAGING.md:4 states Apple Silicon macOS 15+; its qualification records use arm64 macOS and Rust 1.97.1.

Pinned alloc/src/sync.rs:382-405 declares #[repr(C, align(2))] ArcInner<T> with strong: Atomic<usize>, weak: Atomic<usize>, data: T. arcinner_layout_for_value_layout extends the ArcInner<()> header by the payload layout and pads it. For unit data on this target, the header is two eight-byte counters, eight-byte alignment, total 16. Arc handles in Cache/StageAudio are only thin pointers; size_of<Cache> cannot include that separate allocation.

resident(&ReadBlock) currently adds size_of::<ReadBlock>() plus 2*size_of::<usize>() separately. The current ReadBlock consists of eight-byte-aligned scalars/Vec/BTreeMap handles, so adding 16 already equals its actual ArcInner layout on this target. A future more-aligned ReadBlock field would need a Layout-based padded bound; no such field exists today. The proposed scope shell addition follows the existing qualified convention.

## Concrete BTree node bound

Pinned alloc/src/collections/btree/node.rs:43-66 sets B=6, capacity=11. LeafNode has one parent pointer, two u16 fields, eleven keys and eleven values. InternalNode (repr(C), lines104-110) contains that leaf plus twelve child pointers; BoxedNode is one NonNull pointer (line137). Pinned map.rs:33-39 requires every nonempty root to hold at least one key and every non-root node to hold at least five. Therefore a stable nonempty map with N entries has at most N allocated nodes. Charging 1024*N is far above the retained node layouts for both actual map types:

- Dependencies = BTreeMap<AssetId,[u8;32]>. AssetId is a single Arc<str> field (deadpan-core/src/document.rs:49-57), hence a 16-byte fat pointer; fingerprint is 32 inline bytes. Usual pinned leaf geometry is 8+2+2+11*16+11*32, rounded to eight-byte alignment =544 bytes; internal adds96=640 bytes.
- Controller original_inputs = BTreeMap<u64,Cached>. Key is8 bytes; Cached holds Arc<ReadBlock> (8) and resident:u64 (8), total16. Leaf geometry rounds 8+2+2+11*8+11*16 to280 bytes; internal adds96=376 bytes.

The proof need not rely on the repr(Rust) leaf selecting its usual minimum-padding order. Conservatively allowing up to seven padding bytes before each of five leaf fields plus seven tail bytes gives <584 bytes for the dependency leaf and <320 for the controller leaf; adding96 stays below680 and416 respectively, both below1024. No field alignment exceeds8 here. Even charging each dependency's separately owned maximum128-byte identity text plus its16-byte Arc header would leave its per-entry conservative bound below1024; current code correctly notes those identities are already shared with the pinned immutable plan.

This is a cumulative retained-tree bound, not “one map node allocated for every entry.” Spare key/value slots and internal edges are covered because the bound permits a complete largest node for every live entry. Insertions reserve the incoming candidate before publication; splits can add nodes, but the existing 5-key minimum provides substantial slack. Removals allocate no replacement nodes. General transient allocation of raw query/PCM construction is outside this retained-cache calculation.

## Empty root exception and closure

Per-live-entry charging alone does NOT cover an allocated empty root at N=0. Pinned map.rs:38-39 explicitly permits an empty leaf root, and remove delegates to remove_entry rather than clear. The current three removal sites can retain that one empty controller leaf after the last payload disappears, while cached_resident_frames reports zero.

BTreeMap::clear does guarantee root=None in the pinned implementation: map.rs:670-678 replaces self.root with None, resets length, and drops the old map/root. Replacing an empty map with BTreeMap::new() equally drops the old allocation and establishes root=None without allocating. Either is sufficient; replacement is explicit and matches the parent's proposed helper. It must run after the final removal at every one of the three sites. There is no need for a persistent extra1024 allowance once the zero-entry root is actually released.

Existing ReadBlock dependency maps start new and are grown by insert/extend; I found no dependency remove/clear/retain/split_off path that could leave an allocated zero-entry root. The empty-root defect is specifically reachable in the reused controller map. The helper also preserves pinned-read semantics: normal eviction already refuses pinned blocks, and Graph cleanup occurs after its raw readers have dropped.

## Concrete test strategy without new allocator infrastructure

A logical is_empty/cached_resident_frames assertion cannot distinguish root=None from an allocated empty leaf; copying the helper into a test would prove nothing about this omission. Reuse the repository's existing per-thread CountingAllocator in the deadpan-cli library test binary (src/adversarial.rs already installs it), and allocation_baseline() as the current-live-byte observation:

- Build an actual simple Source+root-sound/shared-treatment fixture that enters prepare_authored_bus's shared path, with no underlying room-tone/Preserve persistent stage. Use the same warmed provider and immutable plan throughout.
- Warm source halos/native lazy setup using a throwaway controller, then drop that controller. Construct the measured controller before taking baseline so its16-byte identity allocation is outside the delta.
- Record B=allocation_baseline(); prepare the actual shared bus once; drop its returned output; ensure required stage cache remains empty. Record A=allocation_baseline() immediately, without formatting/allocating between snapshots.
- Expect A==B after request cleanup. Before the empty-root fix, the actual cache's last removal retains its controller leaf (nominal280 requested bytes), so A>B. After the fix no controller map node survives. Repeat the request to verify reuse and cleanup remain stable.
- Keep this a narrowly qualified arm64/pinned-toolchain regression and warm the same source range in setup to exclude media-cache changes. The existing allocator counts requested layout bytes on this thread; it does not require new global allocator code. Parent owns implementation and execution.

If keeping all tests in deadpan-audio is preferred, retain its behavioral lifecycle tests and the pinned-source proof; do not claim those tests observe the physical empty-root release unless an existing allocation-observing harness is used.

## Pinned source evidence

Fetched with required User-Agent from rust-lang/rust tag1.97.1 and saved under this report's sibling rust-1.97.1-accounting/. SHA-256:

- https://raw.githubusercontent.com/rust-lang/rust/1.97.1/library/alloc/src/collections/btree/node.rs
  2200ca0a4fe38592c314dc7f5f40bbb160e06b6f9e4abd1eb5bc40701540ab25
- https://raw.githubusercontent.com/rust-lang/rust/1.97.1/library/alloc/src/collections/btree/map.rs
  f58ece50e59502b344616a4c7dcbb13987b5b5ef6b2c4038888ceefaac5635d1
- https://raw.githubusercontent.com/rust-lang/rust/1.97.1/library/alloc/src/sync.rs
  768776d4a37cfeb28c71a0c6d8b2ad33332d11ceaef7e47cb01463bd71b9048a

No remaining accounting blocker identified for this narrow retained-cache checkpoint after the fixed scope shell, empty controller root release and metadata-budget term are included. No query retention or performance claim is implied.
