# Minimal scoped Original PCM-cache port

Read-only comparison of Main with /tmp/deadpan-query-groundwork-2026-10-26/scoped, 2026-10-29. No source writes, Cargo/native execution, or Git. Cache code is inherited Main WIP; the scoped published checkpoint does not include it. Line numbers describe the source inspected and can move during the parent's work.

## Small independent production slice

Three production files suffice. No deadpan-core/deadpan-plan API changes are needed.

1. **Add deadpan-audio/src/shared_eq/original_inputs.rs** from Main, independently of the permission-family modules. It uses only existing super::* types, std Hash/Hasher, StageAudio's new fields, Graph's new field and existing policy_prediction::validate_original. Its full implementation is one unit: Cached/Read, Entry/LookupKey, fixed-capacity Cache with hash/LRU helpers, same_context/resident, StageAudio::evict_original_input, shared_original_input, shared_original_input_prepared and shared_original_input_mode. Include the metadata-budget correction in the local fits chain. There is no compile dependency on GeneralSplit, FamilyRegistry/FamilyToken, delivery-forest, canonical-families or their new APIs.

2. **Selective shared_eq.rs hunks**, keeping all existing Scope family logic:
   - Declare only original_inputs module after event_returns; do not copy adjacent permission_families module/use additions.
   - Add Graph.original_inputs: original_inputs::Cache<'plan>. Keep Scope's existing permission_families type unchanged.
   - In read_shared_input, before Graph construction, compute Cache::resident_frames; checked-add it to the existing frames*3 reservation, make_room, checked-add active_frames; then initialize Cache::default in Graph. Remove the later duplicate old reservation. Main's lines 212-240 contain the desired ordering but adjacent new family initializers must be omitted.
   - release_shared_graph takes mut graph, clears its Original entries/controller payloads before dropping Graph, then releases the existing reservation+graph.resident.
   - In read_shared_program's Original branch (Scope:622-660), replace validate_original + read_prepared_original or the Root/Domain/Retained match with shared_original_input_prepared / shared_original_input. Keep prepared_original creation/prediction in place.
   - Because Read can dereference an Arc, replace moving raw.dependencies with iterating/cloning the AssetId/fingerprint pairs into the existing result map; drop(raw) promptly before later sound returns. This removes an otherwise avoidable pin during recursive sound processing.
   - Keep all selected_split_families, permission aliases and graph-node selection code from Scope.

3. **Selective stages.rs hunks**:
   - StageAudio fields: original_inputs BTreeMap<u64,Cached>, next_original_input u64, original_input_scope Arc<()>; corresponding new() initializers.
   - cached_resident_frames sums both caches' retained resident units.
   - make_room_for uses combined cache entry count for new_entry; before evicting a required PreparedStage, try evict_original_input(control).
   - No changes to ReadWork, PreparedOriginalRequest, read_queries_borrowed, source provider, policy prediction or DSP are required for this PCM-only cache port.

Physical difflib hunk anchors: stages.rs Scope lines 658,700,758,2480; shared_eq.rs Scope lines 37,95,275,287,348,619,682. These are surgical selections, not whole-file copies.

## Tests and fixture-only integration

Add original_inputs_tests.rs and prepared_input_tests.rs. The first module includes the second through #[path="prepared_input_tests.rs"] mod prepared. Its test helper must match Scope Graph: omit Main's selected_family_count and canonical_families, retain Scope permission_families: BTreeMap::new(), and add original_inputs. Carry the parent's actual metadata-lease finite-budget regression, not a synthetic ledger assignment.

Add only original_inputs: Cache::default() to the existing Graph literal in each scoped shared_eq/{admission_tests,caller_graph_tests,sound_admission_tests,wide_query_graph_tests}. No other new Main test modules are necessary for compilation or this cache behavior. Existing cache tests cover exact source readmission/provenance/cancellation, context allocation identity, range/depth/controller separation, PCM/mask equality, pins and pressure, stale keys, collisions/LRU, and the fixed-shell pre-admission failure. Prepared tests cover consuming already-billed requests, mismatched window and revoked source. The parent owns checks.

## Published APIs already suffice

Scope already has PreparedOriginalRequest<'context,'plan>, exact root/domain match methods, read_prepared_original and RootReadQueriesRef. policy_prediction::validate_original is already called in the scoped Original path. The cache relocates that exact validation into its shared entry point; it neither clones nor retains query products. Consequently none of the missing whole-query heap visitors from the earlier retention research are a blocker to this PCM-only port.

Scope also has resolve_source, WorkControl::observe/admit_dependency, cancelled/deadline/work checks, relative_depth and ordinary read_context/read_retained variants. The hit path must keep all those existing live dependency/fingerprint and depth checks. Original raw PCM is before owner treatment/mix selection, so the key intentionally excludes parent EQ node/permission mask; Context allocation+range+entry depth and fixed per-context fade mode remain required. Root/Domain use fades=true; Retained uses authored=false. The controller scope token rejects use of a Graph by a different StageAudio.

## Narrow memory/semantic findings before publication

**Must fix:** add sound_context_frames with checked_add to the optional fits expression. Otherwise a real admitted owner query held through read_shared_program can coexist with a newly published cache payload above the aggregate ceiling. No enforcing make_room follows that insertion. Preserve the existing fresh fallback rather than using generic make_room_for, which can evict unrelated stages or fail otherwise valid fresh work.

**Fixed cache shell:** Cache::resident_frames covers the actual inline Cache, including all 64 Option<Entry> slots, both link sets, buckets, free slots and Arc handle fields. It is reserved before construction. Capacity is fixed and maximum_cached_stages is already validated 1..=64. No additional variable allocation is introduced by those arrays.

**Entry::context.clone:** Context::Domain clones an Arc; Context::Retained clones a shared wrapper. Neither deep-clones a Domain, retained graph or Vec. In the production Scope path, recursive Program contexts come from Graph nodes (shared_eq.rs:1110); node construction already transfers their actual context leases into graph.resident/active_frames (1009-1067), retained until release_shared_graph. Root has no payload. Clearing cache entries before dropping nodes keeps that ownership ordering. Thus no additional full context heap charge or Plan visitor is required for the clone. Tests constructing independent contexts must retain their own owners; this does not establish a new unmetered context-construction API.

**resident(ReadBlock):** counts sample capacity, both mask capacities, ReadBlock inline payload, Arc counters, and conservative BTreeMap allowances (1024 per dependency plus 1024 per controller entry). Its AssetId keys share immutable plan identifier allocations. The cache adds no new identity text allocation. This is a coarse bound rather than allocator-exact measurement; I found no concrete smaller-than-actual node allocation or semantic error in those constants. It should be documented/tested as an explicit conservative bound, not described as a full structural heap measurement. Query products are not retained here.

**One precise shell accounting gap to close if publishing complete new-cache allocation accounting:** original_input_scope: Arc<()> is newly allocated once by StageAudio::new, while size_of<Cache> includes only a cloned Arc handle, not the ArcInner allocation. This is a fixed two-usize shell on this target, not an unbounded leak. Cover its allocation explicitly in the fixed request cache reservation (checked Layout for Arc counters+unit payload, conservative repeated charge acceptable), or document an existing controller-shell accounting exclusion that truly owns it. Do not silently label size_of<Cache> as all newly introduced heap. The block Arc header already has its own resident term.

**Lifecycle constraints preserved by the slice:** controller eviction can leave stale bounded Graph keys; next lookup removes them. Metadata handles stay in the fixed shell. PCM returns are pinned only while used; optional eviction skips pinned Arc blocks. Graph cleanup removes every matching controller entry. Returned mixed output contains no cache Read handle. Active source admission still happens on every warm read. No known semantic requirement forces unrelated Main WIP into this port.

This supports one coherent cache-plus-budget-correction checkpoint. It makes no new speed claim and does not authorize retaining RootReadQueries.
