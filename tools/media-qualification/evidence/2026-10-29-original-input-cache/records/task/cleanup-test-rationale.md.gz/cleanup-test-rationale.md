# Actual shared Original cache cleanup allocation regression

Exact CLI libtest filter:
adversarial::original_cache::shared_original_cache_releases_actual_controller_allocations_after_each_request

Added one arm64 macOS qualified regression under the existing CLI library CountingAllocator. No allocator infrastructure, Cargo dependencies or production sources changed. Main and Scope versions of both paths are byte-identical.

The real stereo WAV provider and one natural-rate Source share an immutable plan with one independent root sound whose only treatment is constant -6 dB trim. The test asserts nonempty root sounds plus has_sound_treatments and no EQ/wet effects. These predicates force StageAudio::prepare_authored_bus -> read_shared_equalizers -> read_shared_input -> read_shared_program. The single supported Source 0..64 Original read has a cache miss, ample default residency and no other prepared cache entries, so it publishes its optional Original payload. No RoomTone/Preserve/time-pitch/return processing exists in the fixture, and no historical sound routes can install retained sound-processing plans. Graph cleanup removes that actual cache payload.

A throwaway controller warms the identical public request, provider media halo and lazy setup, then drops. The measured controller is constructed before baseline, so its fixed scope Arc belongs to the baseline. The measured public request completes, compares literal PCM to warm reference, and its output is dropped. The private PreparationBudget and ReadWork have returned/dropped with prepare_authored_bus. allocation_baseline then observes the actual current-live requested-layout bytes on the same thread, with no formatting between snapshots. The assertion requires exact before/after equality while the controller remains alive; no allowance/subtraction/fabricated charge hides retained storage. A positive observed heap peak, source readmission and zero prepared-stage/cache residency are also required. The same request is checked twice.

Before the empty-root reset, an actual controller BTreeMap leaf can remain after its last payload removal; pinned-layout research predicts approximately 280 requested bytes. Parent will execute that exact old-root-only variant and restore the fix for green. This worker makes no execution claim.

Targeted rustfmt with skip_children=true completed for the four owned physical paths; complete new source and module-only diff reviewed. No Cargo, native executable or Git command ran. Other source paths remain outside this unit.

Before copies/pins: cleanup-test-before-{main,scope}-adversarial.rs and cleanup-test-before-pins.json.
After source copies: cleanup-test-after-{main,scope}/. Exact diff/pins: cleanup-test.patch, cleanup-test-after-pins.json.
