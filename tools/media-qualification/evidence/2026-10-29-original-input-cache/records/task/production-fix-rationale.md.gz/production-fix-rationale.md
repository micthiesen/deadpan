# Minimal optional Original cache admission correction

Inherited Main WIP only. Added checked_add(control.work.borrow().sound_context_frames) to the completed-read optional cache fit sum, between projected residency and candidate PCM residency.

This includes the live admitted owner query metadata before Arc allocation and cache publication. Overflow or a sum beyond maximum_resident_frames follows the existing optional Original eviction/Fresh fallback. It does not invoke make_room_for, evict unrelated prepared stages, or turn a completed fresh read into an allocation error.

No query retention or ownership/accounting redesign. The measured held-owner boundary regression is unchanged.
Before and after source copies and SHA-256 pins are stored beside this rationale.
rustfmt --edition 2024 --config skip_children=true completed for original_inputs.rs.
Worker ran no Cargo, native test executable, or Git operations. Parent owns guarded green execution.
