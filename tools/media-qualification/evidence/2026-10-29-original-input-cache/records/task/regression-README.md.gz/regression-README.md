# Optional Original cache / held owner metadata regression

Scope: inherited Main WIP only. The published Plan API TaskScope source does not include this cache integration.

Test-only edit: crates/deadpan-audio/src/shared_eq/original_inputs_tests.rs.
Exact libtest filter: stages::shared_eq::original_inputs::tests::original_input_optional_cache_respects_live_owner_query_metadata_budget.

Measures P from the actual one-entry controller Cached.resident and renderer cached-residency delta after the real WAV-backed Root 0..64 read. Measures M > 0 from actual Root.owners_admitted under sound_context_admission::Admission, verifies query identity/range, drops the adapter borrow while retaining its query lease, and verifies release on query drop. Fresh StageAudio::with_limits controllers exercise cap P+M first (must cache) then P+M-1 (must complete Fresh without publishing key or payload). Each completed read compares literal PCM, masks, dependencies and depth to the ample-budget reference and confirms actual source/provider admission. The aggregate assertion prints measured resident, active, projected, metadata, candidate, total and cap.

Expected red: the short-cap completed read publishes Cached and fails the aggregate assertion. No synthetic ledger assignment or fabricated reservation is used.

Copies: regression-before-original_inputs_tests.rs, regression-before-original_inputs.rs, regression-red-original_inputs_tests.rs. SHA-256 pins: regression-before-source-pins.json and regression-red-source-pins.json.
Production source was checked byte-identical to its before copy after test formatting.
rustfmt --edition 2024 --config skip_children=true was run on the test file.
No Cargo, native execution or Git operation was run by the regression worker. Parent owns the red run, production fix authorization and all execution/publication.
