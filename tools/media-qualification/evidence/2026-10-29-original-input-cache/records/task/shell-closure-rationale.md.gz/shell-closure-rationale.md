# Fixed cache shell and empty controller root closure

Only Main and isolated Scope shared_eq/original_inputs.rs changed; both source bodies are byte-identical after this closure. Other eight isolated port files remain byte-identical to port-candidate.json.

Cache::resident_frames now uses checked multiplication/addition to cover the pinned Rust 1.97.1 Arc<()> heap shell's two usize counters, conservatively billed per Graph. Inline Arc handles remain covered by size_of<Self>. Scope identity is unchanged.

Central private StageAudio::remove_original_input removes the requested payload and replaces an empty controller BTreeMap with BTreeMap::new(). This drops the possible retained empty root before reporting zero retained cache payload residency. All three controller-removal call sites use it: graph clear, individual optional eviction and capacity eviction. Graph key removal stays independent.

The existing iteration, work charges, pinned-reader rule, eviction order and Fresh fallback are unchanged. No query retention, broad accounting redesign or allocator-test infrastructure added.

Targeted rustfmt with skip_children=true completed for both owned files; the entire closure diff and all module remove sites were inspected. No Cargo, native execution or Git operations by this worker. Parent owns guarded compilation/tests.

Exact before/after copies: shell-closure-{before,after}-{main,scope}-original_inputs.rs.
Exact diff: shell-closure.patch. Source hashes and byte lengths: shell-closure-{before,after}-pins.json.
