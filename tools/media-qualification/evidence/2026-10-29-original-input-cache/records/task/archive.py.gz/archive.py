from pathlib import Path
import gzip,hashlib,json
s=Path(__file__).resolve().parent
profile=Path('/tmp/deadpan-post-policy-work-profile-2026-10-29')
repo=Path('/Users/michael/Code/deadpan')
dest=repo/'tools/media-qualification/evidence/2026-10-29-original-input-cache'
assert not dest.exists()
audit=json.loads((s/'final-audit.json').read_text());assert audit['all_terminal']
prior=repo/'tools/media-qualification/evidence/2026-10-29-authored-domain-policy-reuse/inventory.json'
prior_sha='41471115e7cde2ae11059dccbbe9d7a04b7bde8600c3f325e126547084859bb4'
assert hashlib.sha256(prior.read_bytes()).hexdigest()==prior_sha
rows=[]
allowed={'.rs','.json','.py','.md','.patch','.stdout','.stderr','.txt','.sha256','.toml'}
for prefix,root in [('task',s),('profile',profile)]:
 for p in sorted(root.rglob('*')):
  if not p.is_file()or p.suffix not in allowed:continue
  rel=p.relative_to(root)
  if prefix=='profile'and rel.parts[0]=='diagnostic':continue
  if prefix=='task'and rel.parts[0]=='rust-1.97.1-accounting':continue
  if prefix=='task'and rel.name=='qualification-draft.md':continue
  data=p.read_bytes()
  if p.suffix=='.json':
   obj=json.loads(data)
   if isinstance(obj,dict)and 'command'in obj and 'started_at'in obj:
    assert 'exit_code'in obj and obj['sources_unchanged']and obj['binaries_unchanged'],str(p)
  target=(dest/'records'/prefix/rel).with_name(rel.name+'.gz');target.parent.mkdir(parents=True,exist_ok=True)
  packed=gzip.compress(data,mtime=0);target.write_bytes(packed)
  rows.append({'path':str(target.relative_to(dest)),'bytes':len(packed),'sha256':hashlib.sha256(packed).hexdigest(),'expanded_bytes':len(data),'expanded_sha256':hashlib.sha256(data).hexdigest()})
manifest={'schema_version':1,'base_revision':(s/'base-revision.txt').read_text().strip(),'scope':'Scoped optional request-local Original PCM cache port only, with live metadata admission, fixed scope Arc shell charge and actual empty controller map root release. Real finite held owner query red/green and real requested-layout cleanup red/green. Separate post-policy work profile remains diagnostic evidence, not production instrumentation or claimed savings. GeneralSplit remains disabled; no requirement or gate closes.','prior_policy_inventory':{'path':'../2026-10-29-authored-domain-policy-reuse/inventory.json','sha256':prior_sha},'exclusions':'Executables, diagnostic filesystem copy and raw downloaded standard-library copies excluded. Source/executable/stream identities, exact scoped patch, before/after source, raw failures and passes, instrumentation and source research with immutable upstream URLs/hashes are retained. Audio manifests predate the CLI coverage expansion; fullguard CLI build and subsequent tests have expanded complete workspace Rust/native/config guards. See guard-expansion-note.md.','files':rows}
p=dest/'inventory.json';p.write_text(json.dumps(manifest,indent=2)+'\n')
for row in rows:
 packed=(dest/row['path']).read_bytes();plain=gzip.decompress(packed)
 assert len(packed)==row['bytes']and hashlib.sha256(packed).hexdigest()==row['sha256']
 assert len(plain)==row['expanded_bytes']and hashlib.sha256(plain).hexdigest()==row['expanded_sha256']
result={'files':len(rows),'stored_bytes':sum(r['bytes']for r in rows),'expanded_bytes':sum(r['expanded_bytes']for r in rows),'inventory_sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
(s/'published-evidence.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result))
