from pathlib import Path
import hashlib,json,re
s=Path(__file__).resolve().parent
main=Path('/Users/michael/Code/deadpan')
scope=Path('/tmp/deadpan-query-groundwork-2026-10-26/scoped')
sha=lambda b:hashlib.sha256(b).hexdigest()
negative={'metadata-budget-red':101,'cleanup-root-red':101,'cache-final-split':101,'cache-final-scoped-strict':1}
receipts=[]
for p in sorted(s.glob('*.json')):
 r=json.loads(p.read_text())
 if not isinstance(r,dict)or 'command'not in r or 'started_at'not in r:continue
 assert r.get('exit_code')==negative.get(p.stem,0),(p.stem,r.get('exit_code'))
 assert r['sources_unchanged']and r['binaries_unchanged'],p.stem
 for name,h in r['streams'].items():
  data=Path(name).read_bytes();assert len(data)==h['bytes']and sha(data)==h['sha256'],name
 receipts.append({'label':p.stem,'exit_code':r['exit_code'],'seconds':r['seconds'],'source_inputs':len(r['source_before']),'receipt_sha256':sha(p.read_bytes())})
for variant,root in [('main',main),('scoped',scope)]:
 for name,h in json.loads((s/(variant+'-expanded-final-source-authority.json')).read_text()).items():
  data=(root/name).read_bytes();assert len(data)==h['bytes']and sha(data)==h['sha256'],(variant,name)
rows=json.loads((s/'task-source-pins.json').read_text())
for name,h in rows.items():assert sha((scope/name).read_bytes())==h['sha256'],name
index=json.loads((s/'index-source-equality.json').read_text())
assert len(index)==len(rows)==11 and all(r['scoped_index_equal']for r in index)
for row in json.loads((s/'immutable-oracle-pins.json').read_text()):
 for root in [main,scope]:assert sha((root/row['path']).read_bytes())==row['sha256']
tests={}
for label in ['cache-final-main-lib','cache-final-scoped-lib','cache-final-main-stages','cache-final-scoped-stages','cache-final-main-definition','cache-final-scoped-definition','cleanup-root-green','cleanup-main-green']:
 m=re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;', (s/(label+'.stdout')).read_text())
 assert len(m)==1 and int(m[0][1])==0,(label,m)
 tests[label]={'passed':int(m[0][0]),'ignored':int(m[0][2]),'seconds':json.loads((s/(label+'.json')).read_text())['seconds']}
assert tests['cache-final-main-lib']['passed']==378 and tests['cache-final-scoped-lib']['passed']==372
assert tests['cache-final-main-stages']['passed']==tests['cache-final-scoped-stages']['passed']==203
split=re.findall(r'^test (general_split_sound::[\w:]+) \.\.\. (ok|FAILED)',(s/'cache-final-split.stdout').read_text(),re.M)
assert len(split)==7,split
assert 'aggregate=420, cap=419'in(s/'metadata-budget-red.stderr').read_text()
red=(s/'cleanup-root-red.stderr').read_text()
m=re.search(r'left: (\d+)\s+right: (\d+)',red);assert m and int(m[1])-int(m[2])==280
result={'all_terminal':True,'receipts':receipts,'negative_results_retained':negative,'source_files':len(rows),'all_scoped_index_equal':True,'main_files_also_equal':sum(r['main_equal']for r in index),'all_expanded_final_sources_current':True,'initial_source_preservation':json.loads((s/'source-preservation-audit.json').read_text()),'tests':tests,'audio_source_reuse_proof':json.loads((s/'audio-executable-source-proof.json').read_text()),'profile':json.loads((s/'profile-receipt-audit.json').read_text()),'metadata_red':{'candidate_pcm':336,'live_metadata':84,'aggregate':420,'cap':419},'cleanup_root_red':{'before':int(m[2]),'after':int(m[1]),'retained_requested_bytes':280},'split':{'cases':split,'passed':sum(v=='ok'for _,v in split),'failed':sum(v=='FAILED'for _,v in split),'seconds':json.loads((s/'cache-final-split.json').read_text())['seconds']},'scoped_patch_sha256':sha((s/'task-scoped.patch').read_bytes()),'native_suites_serial':True,'review_triage':'review-triage.md','guard_expansion':'guard-expansion-note.md'}
(s/'final-audit.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:result[k]for k in ['all_terminal','source_files','all_scoped_index_equal','tests','metadata_red','cleanup_root_red','split','scoped_patch_sha256']}))
