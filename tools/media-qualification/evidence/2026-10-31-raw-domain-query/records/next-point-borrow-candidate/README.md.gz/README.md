# Next Point signal borrow candidate

Scratch-only candidate based on the live Deadpan root after current lint fixes. No actual source files were edited and no build, test, native run, oracle generation, or Git operation was performed.

## Proposed source changes

- Add documented AudioPointDomain::signal_ref() returning the exact internal AudioSignal by borrow; leave AudioPointDomain::signal() clone behavior untouched.
- Replace the single downstream domain.signal() temporary in StageAudio::read_point_domain_controlled with domain.signal_ref(). The reader consumes only a borrowed AudioSignal synchronously, and the admitted Point domain carrier outlives the call.
- Add a test-only child/helper under raw_domain_admission_tests. Its new Mode reuses the existing 77-operand actual visitor and immutable baseline. For every Point entry it compares the borrowed AudioSignal complete private snapshot against the frozen Point payload; the corpus asserts 18 Point payloads.

The borrow introduces no owning copy, canonical/additional work, or new lease. The raw domain result's existing carrier lease already covers its stored Point AudioSignal through the synchronous consumer. The public signal() clone API remains available unchanged.

## Inputs and hashes

before.sha256 gives exact SHA-256s for the three existing source files copied as candidate bases from /Users/michael/Code/deadpan. raw_domain_point_borrow_tests.rs is a new scratch candidate file with no prior hash. candidate.patch is the complete proposed patch.

This candidate has not been compiled or executed. It is for review only; integrate after the current raw-domain unit is published and the live root is safe to change.
