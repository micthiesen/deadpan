from pathlib import Path
import json,sys,subprocess
s=Path(__file__).resolve().parent
build,variant,package,target,label,*args=sys.argv[1:]
if label.startswith('raw-final-') and (s/'pause-final-native-for-lint.txt').exists():
 raise SystemExit('Native matrix paused before another target for a source correction; no test launched')
pins=json.loads((s/(build+'-pins.json')).read_text())
binary=next(p['path']for p in pins if p['package']==package and p['name']==target)
runner=s/('run_qualified.py' if variant=='main' else 'run_scoped_qualified.py')
if variant=='main' and target=='stages' and label=='retained-final2-main-audio-stages':
 args=['--skip','general_split_sound::',*args]
raise SystemExit(subprocess.run(['python',str(runner),'--binary',binary,label,'--',binary,*args]).returncode)
