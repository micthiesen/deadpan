
thread_local! {
    static CAPTURING: Cell<bool> = const { Cell::new(false) };
}
struct Capture;
impl Capture {
    fn new() -> Self {
        assert!(!CAPTURING.replace(true));
        Self
    }
}
impl Drop for Capture {
    fn drop(&mut self) {
        raw_domain_query_trace::disable();
        CAPTURING.set(false);
    }
}
pub(super) fn reset_if_capturing() {
    if CAPTURING.get() {
        raw_domain_query_trace::reset();
    }
}
pub(super) fn receipt_if_capturing() -> Option<Value> {
    CAPTURING.get().then(|| serde_json::to_value(raw_domain_query_trace::snapshot()).unwrap())
}

#[test]
#[ignore = "manual admitted raw-domain capture; fresh /tmp output and pinned actual source required"]
fn capture_new_raw_domain_native_v1() {
    let path = std::env::var("DEADPAN_RAW_HOST_OUTPUT").expect("explicit fresh output");
    let path = Path::new(&path);
    assert!(path.is_absolute());
    assert!(path.parent().unwrap().canonicalize().unwrap()
        .starts_with(Path::new("/tmp").canonicalize().unwrap()));
    let variant = std::env::var("DEADPAN_RAW_HOST_VARIANT").expect("actual source variant");
    assert!(matches!(variant.as_str(), "main-inherited" | "scoped-published"));
    let source = std::env::var("DEADPAN_RAW_HOST_SOURCE_SHA256").expect("actual complete source manifest");
    assert!(source.len() == 64 && source.bytes().all(|byte| byte.is_ascii_hexdigit()));
    let checkpoint = std::env::var("DEADPAN_RAW_HOST_PUBLISHED_CHECKPOINT").expect("published preceding checkpoint");
    assert_eq!(checkpoint, "87ab6192e765a34dae9595139e10bd9010d6315e");
    let file = OpenOptions::new().create_new(true).write(true).open(path).unwrap();
    let value = {
        let _capture = Capture::new();
        let mut value = current_body(&variant, &source);
        value["schema"] = json!("raw-domain-native-admitted-v1");
        value["pre_raw_frozen_sha256"] = json!(SHA256);
        value["published_retained_fade_checkpoint"] = json!(checkpoint);
        value["scope"] = json!("Complete fresh admitted raw-domain native results with separate scoped constructor receipts. The embedded pair comparison still names the earlier retained legacy reference; this unit compares paired.new against raw-domain-host-baseline-v1 paired.new. No whole recursive preparation claim.");
        value
    };
    let mut writer = std::io::BufWriter::new(file);
    serde_json::to_writer_pretty(&mut writer, &value).unwrap();
    writer.write_all(b"\n").unwrap();
    writer.flush().unwrap();
    writer.get_ref().sync_all().unwrap();
}
