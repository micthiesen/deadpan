# OLD Plan raw-domain producer candidate

Scratch-only preparation for published retained-fade checkpoint
`87ab6192e765a34dae9595139e10bd9010d6315e`. No expected semantic body is present.
Neither actual root, production algorithm, public API nor existing oracle was
edited. No builds, native tests, Git operations or network requests were run.

## Integration

1. Check the selected root's `pins/<variant>.source.sha256` against its current
   source. These per-file reads are guards for parent verification, not an atomic
   checkout snapshot. Main and Scope intentionally have different inherited test
   inventories. `pins/candidates.json` records both identities.
2. Apply only `patches/<variant>.patch` in the matching root. It adds
   `audio_owners/raw_domain_baseline.rs` and six narrow test-only additions to
   `retained_fade_baseline.rs`: module declaration, three actual origin scopes,
   fixture scope and observer. Full before/current hook files are included under
   `before/<variant>/` and `current/<variant>/`; the complete new module is in
   `new/`. There are no production visibility changes.
3. Verify the resulting files and the overlaid
   `pins/<variant>.candidate-source.sha256`. Parent must bind the real compiled
   source, checkpoint and binary in its own guarded wrapper. The candidate
   manifest covers Core/Plan Rust sources, tests, JSON/Markdown fixture contracts,
   crate manifests, workspace manifest/lock and Rust toolchain. It is not a hash
   of all files in the repository or the native binary. Do not use its hash as a
   claim that parent observed a different compiled source inventory.
4. Build/type-check only under parent's serial native guard. The author checked
   Rust parsing/formatting with rustfmt on scratch files and exact edit anchors;
   no Rust type or runtime check has been performed.
5. Before changing raw-domain production behavior, capture from each actual new
   Plan test binary using the exact ignored test below, a fresh absolute `/tmp`
   output path and the required environment fields. The producer opens with
   `create_new` and requires the exact published checkpoint. Parent should retain
   full output plus compiled source/binary/fixture pins, then compare full bodies
   after removing only the three declared envelope fields. Freeze a NEW oracle
   after independently agreeing captures. Existing 21 bodies stay immutable.
6. Run the separate exact ignored external regression against that independent
   immutable capture. No include_str golden or generated expectation is supplied
   before capture. Preserve this test after implementation; if the internal
   private helper is renamed, update only the call name and revalidate against
   the same body.

Exact producer test:

```text
plan::audio_owners::wide_gain_query_admission_tests::retained_fade_baseline::raw_domain_baseline::capture_old_raw_domain_query_baseline_v1
```

Required environment:

```text
DEADPAN_RAW_DOMAIN_OUTPUT=<fresh absolute /tmp filename>
DEADPAN_RAW_DOMAIN_VARIANT=main-inherited|scoped-published
DEADPAN_RAW_DOMAIN_SOURCE_SHA256=<parent-verified complete actual source manifest hash>
DEADPAN_RAW_DOMAIN_PUBLISHED_CHECKPOINT=87ab6192e765a34dae9595139e10bd9010d6315e
```

Run the actual test binary with that exact name plus `--exact --ignored
--test-threads=1`. Do not run native executables in parallel.

Exact external regression test:

```text
plan::audio_owners::wide_gain_query_admission_tests::retained_fade_baseline::raw_domain_baseline::raw_domain_matches_explicit_external_old_v1
```

Its required field is `DEADPAN_RAW_DOMAIN_EXPECTED=<independent capture>` and it
uses the same `--exact --ignored --test-threads=1` test arguments. It strips only
`variant`, `source_sha256` and `published_retained_fade_checkpoint`.

## What is observed

The collector is absent by default. Existing baseline, owning supplement and
checked coincident setup functions run unchanged and their full bodies retain
all actual Some/None/rejected/error results, documents, selections and commands.
The observer executes only inside their real owning functions. Origin strings
name the actual ordinary probe, admitted-false probe, admitted-true probe and
selected-then-shared construction scopes. The producer asserts exactly 54
observed Some scopes across the three corpora. Every record also includes its
full actual fixture descriptor; it is not joined to a reconstructed input.

For each live Some it captures complete original input, retained input, cached
raw domain and Bound snapshots before/after. Bound's existing exhaustive
snapshot retains full resolved/lattice structures; literal retained, Bound,
resolved and lattice work remain separate and unchanged. The fresh result comes
from the actual public `bound.raw_domain()` call. Root uses the existing complete
domain serializer; Point uses the borrowed exhaustive private snapshot including
its eleven Structural Signal fields after evaluation replacement. Serialization
does not call Point::signal or clone an equivalent raw value.

A separate lane invokes the already-existing private `raw_domain_admitted` using
the ordinary wrapper's literal 65,536 local allowance and default lookup. Its
policy forwards to the existing owning `Policy<true>`; it does not introduce a
second residency ledger. Each spend, requested Layout and merge records actual
before/after policy state, accepted work, lease sizes and same-issuer checks.
The result remains owned while serialized, then drops before the zero-live check.
Canonical zero, accepted=additional and allowance use are asserted independently
of all literal input work. The actual input-construction caller state must stay
identical while ordinary/helper products live and after they drop. No ordinary
allocation admission is claimed by this helper lane.

The additive direct lane uses the existing checked processing visitor's actual
Root and Domain parents, full document, exact full window and ordinary processing
query. It reconstructs each real Bound while that query lives. For each actual
Root parent it also invokes `plan.audio_signal()` and its actual full Signal
query, then reconstructs every real Bound while Signal/query are alive. Full
processing snapshots and Signal query serialization are paired with explicit
query work and exhaustive private Bound snapshots. Counts are observed, not
invented coverage thresholds. Parent must inspect `direct_processing.actual_bound_counts`
before claiming these lanes reached a Bound. A plain real Signal handle is
queried for this caller coverage; it is not used to serialize a Point clone.

## Concrete limits and owed validation

- Genuine Empty reachability is not established. No synthetic_empty_support_for_test
  call, private mutation, fabricated Bound or nominal clock is used. An actual
  Empty result, if a checked corpus reaches it, would be captured literally.
- One existing storage-only processing fixture lacks a full document in its
  visitor descriptor. This direct case is explicitly NotMeasured. The actual
  retained corpora and other checked processing documents are retained.
- Direct Root/Signal Bound counts, raw result variant distribution, Root/Point
  metadata lanes, helper peak/events and 54-Some count await execution. Existing
  source indicates the routes exist; this candidate is not execution evidence.
- The generous internal helper policy observes actual construction; this OLD
  producer does not sweep work/reservation refusals or issuer rotations. Those
  are acceptance tests for the new public sealed result, using this independently
  captured callback sequence. It records literal actual errors from all measured
  calls and preserves genuine setup None/rejection/error cases.
- Raw ordinary errors expose no partial accepted-work receipt. Helper local and
  policy state are reported separately; no receipt is manufactured for ordinary.
- No phase-peak proof, allocation overflow fixture, allocator/RSS claim or full
  recursive Signal/Tape/Mix preparation is supplied. Source/provider I/O and
  native carrier lifetime require the separately captured host witness.
- Parent reports a new independent native OLD body already matched both roots:
  `raw-domain-host-baseline-v1/snapshot.json`, 26,575,199 bytes,
  SHA-256 `2f57d0404dad1cb2d33054958d0578f67dd9e2ecc154a1d17fd2824d65700745`,
  744 requests, 264 Ok and 480 Error, with current admitted fade/owner behavior
  active. This is parent-provided evidence, not a run performed by this worker.

Expected parent checks: guarded type-check/build both variants; exact producer
captures and full-body agreement; exact external regressions both variants;
existing retained baseline/supplement/coincident frozen regressions with collector
off; existing raw helper tests. No cap increase, source-method change or old body
regeneration is needed to integrate this candidate.
