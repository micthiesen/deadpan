from pathlib import Path
import difflib
import hashlib
import json

BASE = Path(__file__).resolve().parent
ROOTS = {
    "main-inherited": Path("/Users/michael/Code/deadpan"),
    "scoped-published": Path("/tmp/deadpan-query-groundwork-2026-10-26/scoped"),
}
TARGET = Path("crates/deadpan-plan/src/audio_owners/retained_fade_baseline.rs")
NEW = Path("crates/deadpan-plan/src/audio_owners/raw_domain_baseline.rs")
EDITS = [
    (
        "    overlap_tests::observe(input, retained, &observations);\n",
        "    overlap_tests::observe(input, retained, &observations);\n"
        "    raw_domain_baseline::observe(input, retained, caller);\n",
    ),
    (
        "fn ordinary_handle(input: &AudioOwnerInput<'_>, extra: &[(&str, i64, i64)]) -> Value {\n",
        "fn ordinary_handle(input: &AudioOwnerInput<'_>, extra: &[(&str, i64, i64)]) -> Value {\n"
        '    let _raw_scope = raw_domain_baseline::Scope::new("ordinary_probe");\n',
    ),
    (
        '        "actual_admitted_probe_unmetered"\n    };\n',
        '        "actual_admitted_probe_unmetered"\n    };\n'
        "    let _raw_scope = raw_domain_baseline::Scope::new(mode);\n",
    ),
    (
        "fn shared_handle(input: &AudioOwnerInput<'_>, extra: &[(&str, i64, i64)]) -> Value {\n",
        "fn shared_handle(input: &AudioOwnerInput<'_>, extra: &[(&str, i64, i64)]) -> Value {\n"
        '    let _raw_scope = raw_domain_baseline::Scope::new("actual_admitted_probe_selected_then_shared");\n',
    ),
    (
        "fn one(descriptor: &Value, input: &AudioOwnerInput<'_>, extra: &[(&str, i64, i64)]) -> Value {\n",
        "fn one(descriptor: &Value, input: &AudioOwnerInput<'_>, extra: &[(&str, i64, i64)]) -> Value {\n"
        "    let _raw_fixture = raw_domain_baseline::FixtureScope::new(descriptor);\n",
    ),
    (
        '#[path = "retained_fade_overlap_tests.rs"]\nmod overlap_tests;\n',
        '#[path = "retained_fade_overlap_tests.rs"]\nmod overlap_tests;\n\n'
        '#[path = "raw_domain_baseline.rs"]\nmod raw_domain_baseline;\n',
    ),
]

def sha(value):
    return hashlib.sha256(value).hexdigest()

def write(path, text):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(text)

new = (BASE / "new" / NEW).read_text()
pins = {"checkpoint": "87ab6192e765a34dae9595139e10bd9010d6315e", "variants": {}}
for variant, root in ROOTS.items():
    before = (root / TARGET).read_text()
    after = before
    for old, replacement in EDITS:
        assert after.count(old) == 1, (variant, old, after.count(old))
        after = after.replace(old, replacement, 1)
    write(BASE / "before" / variant / TARGET, before)
    write(BASE / "current" / variant / TARGET, after)
    patch = "".join(difflib.unified_diff(
        before.splitlines(keepends=True), after.splitlines(keepends=True),
        fromfile="a/" + str(TARGET), tofile="b/" + str(TARGET),
    ))
    patch += "".join(difflib.unified_diff(
        [], new.splitlines(keepends=True),
        fromfile="/dev/null", tofile="b/" + str(NEW),
    ))
    write(BASE / "patches" / (variant + ".patch"), patch)
    paths = set()
    for crate in ("deadpan-core", "deadpan-plan"):
        crate_root = root / "crates" / crate
        paths.add(crate_root / "Cargo.toml")
        for directory in ("src", "tests"):
            for path in (crate_root / directory).rglob("*"):
                if path.is_file() and path.suffix in (".rs", ".json", ".md"):
                    paths.add(path)
    for filename in ("Cargo.toml", "Cargo.lock", "rust-toolchain.toml"):
        if (root / filename).is_file():
            paths.add(root / filename)
    source_hashes = {str(path.relative_to(root)): sha(path.read_bytes()) for path in sorted(paths)}
    assert source_hashes[str(TARGET)] == sha(before.encode()), "source changed during read"
    manifest = "".join(f"{value}  {path}\n" for path, value in sorted(source_hashes.items()))
    manifest_path = BASE / "pins" / (variant + ".source.sha256")
    write(manifest_path, manifest)
    source_hashes[str(TARGET)] = sha(after.encode())
    source_hashes[str(NEW)] = sha(new.encode())
    candidate_manifest = "".join(f"{value}  {path}\n" for path, value in sorted(source_hashes.items()))
    write(BASE / "pins" / (variant + ".candidate-source.sha256"), candidate_manifest)
    pins["variants"][variant] = {
        "root": str(root),
        "before_target_sha256": sha(before.encode()),
        "candidate_target_sha256": sha(after.encode()),
        "new_module_sha256": sha(new.encode()),
        "patch_sha256": sha(patch.encode()),
        "source_manifest_sha256": sha(manifest.encode()),
        "source_manifest_files": len(paths),
        "candidate_source_manifest_sha256": sha(candidate_manifest.encode()),
    }
write(BASE / "pins" / "candidates.json", json.dumps(pins, indent=2) + "\n")
print(json.dumps(pins, indent=2))
