from pathlib import Path
import hashlib
import json
import re

base = Path(__file__).resolve().parent
pins = json.loads((base / "pins/candidates.json").read_text())
target = Path("crates/deadpan-plan/src/audio_owners/retained_fade_baseline.rs")
module = Path("crates/deadpan-plan/src/audio_owners/raw_domain_baseline.rs")

def sha(data):
    return hashlib.sha256(data).hexdigest()

def apply_one(before, lines, index):
    out = []
    source = before.splitlines(keepends=True)
    cursor = 0
    while index < len(lines) and lines[index].startswith("@@"):
        match = re.match(r"@@ -(\d+)(?:,(\d+))? \+(\d+)(?:,(\d+))? @@", lines[index])
        assert match, lines[index]
        old_start, old_count, new_start, new_count = match.groups()
        old_start = int(old_start)
        old_count = int(old_count or 1)
        new_count = int(new_count or 1)
        start = old_start - 1 if old_count else old_start
        assert start >= cursor
        out.extend(source[cursor:start])
        cursor = start
        old_seen = new_seen = 0
        index += 1
        while index < len(lines) and not lines[index].startswith(("@@", "--- ")):
            kind, text = lines[index][0], lines[index][1:]
            assert kind in " +-", lines[index]
            if kind in " -":
                assert cursor < len(source) and source[cursor] == text
                cursor += 1
                old_seen += 1
            if kind in " +":
                out.append(text)
                new_seen += 1
            index += 1
        assert old_seen == old_count and new_seen == new_count
    out.extend(source[cursor:])
    return "".join(out), index

results = {}
for variant, expected in pins["variants"].items():
    before = (base / "before" / variant / target).read_text()
    current = (base / "current" / variant / target).read_text()
    new = (base / "new" / module).read_text()
    patch_bytes = (base / "patches" / (variant + ".patch")).read_bytes()
    assert sha(before.encode()) == expected["before_target_sha256"]
    assert sha(current.encode()) == expected["candidate_target_sha256"]
    assert sha(new.encode()) == expected["new_module_sha256"]
    assert sha(patch_bytes) == expected["patch_sha256"]
    lines = patch_bytes.decode().splitlines(keepends=True)
    assert lines[0] == "--- a/" + str(target) + "\n"
    assert lines[1] == "+++ b/" + str(target) + "\n"
    applied, index = apply_one(before, lines, 2)
    assert applied == current
    assert lines[index] == "--- /dev/null\n"
    assert lines[index + 1] == "+++ b/" + str(module) + "\n"
    applied_new, index = apply_one("", lines, index + 2)
    assert applied_new == new and index == len(lines)
    for suffix, key in (("source.sha256", "source_manifest_sha256"),
                        ("candidate-source.sha256", "candidate_source_manifest_sha256")):
        assert sha((base / "pins" / (variant + "." + suffix)).read_bytes()) == expected[key]
    results[variant] = {"exact_patch_roundtrip": "passed", "file_pins": "passed",
                        "source_manifest_file_hash": "passed",
                        "actual_source_reverification": "parent-owned after integration"}

result = {"validation": results,
          "rustfmt_scratch_parse_check": "passed; edition 2024, skip_children=true",
          "type_check": "not performed", "build": "not performed",
          "native_tests_or_capture": "not performed", "git_or_network": "not performed",
          "expected_semantic_json_generated": False}
(base / "validation.json").write_text(json.dumps(result, indent=2) + "\n")
print(json.dumps(result, indent=2))
