from pathlib import Path
import subprocess,json,hashlib
s=Path(__file__).resolve().parent
prior=Path('/tmp/deadpan-retained-fade-query-admission-2026-10-30')
audit=json.loads((prior/'final-audit.json').read_text())
valid=[]
for label in audit['tests']:
 if '-audio-'not in label:continue
 r=json.loads((prior/(label+'.json')).read_text())
 for p,h in r['binary_before'].items():
  valid.append((h['sha256'],prior,label))
for v in ['main','scoped']:
 label=f'raw-native5-{v}-library'
 r=json.loads((s/(label+'.json')).read_text())
 for p,h in r['binary_before'].items():valid.append((h['sha256'],s,label))
rows=[]
for v in ['scoped','main']:
 build=f'raw-final-audio-{v}-build'
 pins=json.loads((s/(build+'-pins.json')).read_text());assert len(pins)==21
 for p in sorted(pins,key=lambda p:p['name']):
  assert hashlib.sha256(Path(p['path']).read_bytes()).hexdigest()==p['sha256']
  same=next(((directory,label)for digest,directory,label in valid if digest==p['sha256']),None)
  if same:
   directory,label=same
   r=json.loads((directory/(label+'.json')).read_text())
   assert r['exit_code']==0 and r['sources_unchanged']and r['binaries_unchanged']
   rows.append({'variant':v,'target':p['name'],'reused':True,'receipt':str(directory/(label+'.json')),'sha256':p['sha256']})
   continue
  label=f"raw-final-{v}-audio-{p['name'].replace('_','-')}"
  args=['--skip','general_split_sound::']if v=='main'and p['name']=='stages'else[]
  subprocess.run(['python3',str(s/'run_target.py'),build,v,'audio',p['name'],label,*args,'--test-threads=1'],check=True)
  rows.append({'variant':v,'target':p['name'],'reused':False,'receipt':str(s/(label+'.json')),'sha256':p['sha256']})
 (s/'final-audio-coverage-progress.json').write_text(json.dumps(rows,indent=2)+'\\n')
(s/'final-audio-coverage.json').write_text(json.dumps(rows,indent=2)+'\\n')
