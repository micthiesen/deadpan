1. Severity: Major
   crates/deadpan-plan/src/audio_bound_probe.rs:29-33
   AdmittedAudioBoundDomain::domain() returns &AudioBoundDomain, whose public enum derives Clone in audio_bound.rs:25. A caller can clone the freshly admitted Root/Point domain, drop the carrier, and keep using the cloned allocation after its request lease is released. That bypasses the new result-lifetime resource admission in an ordinary use of this public API. Expose a non-cloneable borrowed view, or make clones retain/share the same lease; the current “no Clone or detach operation” contract is not enforced by the getter.

Resolution after contract clarification:
- Withdraw the Major finding above. A caller's explicit .domain().clone() is a cooperative copy performed outside the admitted carrier lifetime contract, consistent with the prior admitted APIs and ordinary/unmetered constructors. The getter does not force that clone or detach.
- I found no new production path that clones or detaches the admitted payload: the Root transfer borrows the result; Point rendering reads the admitted domain through the transfer closure. Point signal() clone behavior remains the explicitly open existing surface.
