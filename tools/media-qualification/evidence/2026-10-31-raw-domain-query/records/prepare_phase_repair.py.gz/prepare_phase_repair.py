from pathlib import Path
import json,subprocess
s=Path(__file__).resolve().parent;old=s/'phase-test-candidate';dest=s/'phase-repair'
dest.mkdir(exist_ok=False);(dest/'patches').mkdir()
pins=json.loads((old/'pins.json').read_text())
for v,root in [('main-inherited',Path('/Users/michael/Code/deadpan')),('scoped-published',Path('/tmp/deadpan-query-groundwork-2026-10-26/scoped'))]:
 for name,pin in pins[v].items():
  if not isinstance(pin,dict):continue
  data=(root/name).read_bytes()
  for folder in ['before','after']:
   p=dest/folder/v/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data)
code=(old/'finalize_phase.py').read_text()
anchor='    # Thread the actual temporary definition through the Root helper lifetime.\n'
assert code.count(anchor)==1
code=code.replace(anchor,'    p.write_text(s)\n'+anchor)
code=code.replace('        definition: &AudioDefinition<\\\'plan>,','        _definition: &AudioDefinition<\\\'plan>,')
for fn in ['root_selector','root_repeats','root_constraints','root_instance']:
 code=code.replace('definition_value);", "phase_trace::'+fn, 'definition_value);", "phase_trace::'+fn)
code=code.replace('next_definition.as_ref(), definition);','next_definition.as_ref(), _definition);')
code=code.replace('&copied_repeats.value, definition);','&copied_repeats.value, _definition);')
code=code.replace('&next.value, definition);','&next.value, _definition);')
code=code.replace('instance.value.as_ref().unwrap(), definition);','instance.value.as_ref().unwrap(), _definition);')
code=code.replace('assert!(summary.phases[2].selector_pairs > 0);','assert_eq!(summary.phases[2].selector_pairs, 0, "all frozen Root evaluation selectors are None");')
code=code.replace('assert!(summary.phases[2].nonempty_new_selectors > 0);','assert_eq!(summary.phases[2].nonempty_new_selectors, 0);')
code=code.replace('selector.as_ref().map_or(true, |value| value == top_selector)','selector.as_ref().is_none_or(|value| value == top_selector)')
(dest/'finalize.py').write_text(code)
subprocess.run(['python3',str(dest/'finalize.py')],check=True)
