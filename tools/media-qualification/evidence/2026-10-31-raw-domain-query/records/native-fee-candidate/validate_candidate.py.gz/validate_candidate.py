from pathlib import Path
import hashlib
import json
import re

base = Path(__file__).resolve().parent
pins = json.loads((base / "pins/candidates.json").read_text())
def sha(data): return hashlib.sha256(data).hexdigest()
def apply_one(before, lines, at):
    source = before.splitlines(keepends=True)
    output = []
    cursor = 0
    while at < len(lines) and lines[at].startswith("@@"):
        match = re.match(r"@@ -(\d+)(?:,(\d+))? \+(\d+)(?:,(\d+))? @@", lines[at])
        assert match
        old_start, old_count, _, new_count = match.groups()
        old_count, new_count = int(old_count or 1), int(new_count or 1)
        start = int(old_start) - 1 if old_count else int(old_start)
        assert start >= cursor
        output.extend(source[cursor:start]); cursor = start
        old_seen = new_seen = 0
        at += 1
        while at < len(lines) and not lines[at].startswith(("@@", "--- ")):
            kind, text = lines[at][0], lines[at][1:]
            assert kind in " +-"
            if kind in " -":
                assert source[cursor] == text
                cursor += 1; old_seen += 1
            if kind in " +": output.append(text); new_seen += 1
            at += 1
        assert (old_seen, new_seen) == (old_count, new_count)
    output.extend(source[cursor:])
    return "".join(output), at

report = {}
for variant, pin in pins["variants"].items():
    patch = (base / "patches" / (variant + ".patch")).read_text()
    assert sha(patch.encode()) == pin["patch_sha256"]
    lines, at = patch.splitlines(keepends=True), 0
    for relative, expected in pin["files"].items():
        before = (base / "before" / variant / relative).read_text()
        current = (base / "current" / variant / relative).read_text()
        assert sha(before.encode()) == expected["before_sha256"]
        assert sha(current.encode()) == expected["after_sha256"]
        assert lines[at:at+2] == ["--- a/" + relative + "\n", "+++ b/" + relative + "\n"]
        applied, at = apply_one(before, lines, at + 2)
        assert applied == current
    assert at == len(lines)
    pair = "crates/deadpan-audio/src/bound_reads/retained_host_pairs.rs"
    before = (base / "before" / variant / pair).read_text()
    current = (base / "current" / variant / pair).read_text()
    for start, end in [('fn invoke(', 'fn mode('), ('fn current_body(', '#[path = "raw_domain_host_baseline.rs"]')]:
        assert before[before.index(start):before.index(end)] == current[current.index(start):current.index(end)]
    report[variant] = {"file_pins": "passed", "exact_patch_roundtrip": "passed",
                       "pair_invoke_and_current_body": "byte-identical"}
report["checks"] = {"rustfmt_scratch_parse_check": "passed", "type_build_native": "not performed",
    "git_network": "not performed", "expected_body_generation": False,
    "actual_root_writes": False}
(base / "validation.json").write_text(json.dumps(report, indent=2) + "\n")
print(json.dumps(report, indent=2))
