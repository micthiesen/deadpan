from pathlib import Path
import hashlib
import difflib
import json

base = Path(__file__).resolve().parent
source_pins = json.loads((base / "pins/candidates-unformatted.json").read_text())
def sha(data): return hashlib.sha256(data).hexdigest()
pins = {"variants": {}}
for variant, source in source_pins["variants"].items():
    root = Path(source["root"])
    entries = {}
    patch = ""
    for relative in source["files"]:
        path = Path(relative)
        before = (base / "before" / variant / path).read_text()
        current = (base / "current" / variant / path).read_text()
        assert sha(before.encode()) == source["files"][relative]["before_sha256"]
        patch += "".join(difflib.unified_diff(before.splitlines(keepends=True), current.splitlines(keepends=True),
                fromfile="a/" + relative, tofile="b/" + relative))
        entries[relative] = {"before_sha256": sha(before.encode()), "after_sha256": sha(current.encode()),
                             "before_bytes": len(before.encode()), "after_bytes": len(current.encode())}
    protected = []
    pair_path = Path("crates/deadpan-audio/src/bound_reads/retained_host_pairs.rs")
    before = (base / "before" / variant / pair_path).read_text()
    current = (base / "current" / variant / pair_path).read_text()
    for start, end in [('fn invoke(', 'fn mode('), ('fn current_body(', '#[path = "raw_domain_host_baseline.rs"]')]:
        old = before[before.index(start):before.index(end)]
        new = current[current.index(start):current.index(end)]
        assert old == new
        protected.append({"function": start, "identical_sha256": sha(old.encode())})
    child = '#[path = "raw_domain_host_baseline.rs"]\nmod raw_domain_host_baseline;'
    assert before.count(child) == current.count(child) == 1
    guards = {}
    for relative in [
        "crates/deadpan-audio/src/original_request/flattened_work_trace.rs",
        "crates/deadpan-audio/src/retained_request/trace.rs",
        "crates/deadpan-audio/src/bound_reads/raw_domain_host_baseline.rs",
        "crates/deadpan-audio/tests/fixtures/authored-tile-baseline-v1/snapshot.json",
        "crates/deadpan-audio/tests/fixtures/retained-host-read-baseline-v1/snapshot.json",
        "crates/deadpan-audio/tests/fixtures/raw-domain-host-baseline-v1/snapshot.json",
    ]:
        guards[relative] = sha((root / relative).read_bytes())
    (base / "patches" / (variant + ".patch")).write_text(patch)
    pins["variants"][variant] = {"root": str(root), "files": entries, "patch_sha256": sha(patch.encode()),
        "protected_pair_functions": protected, "unchanged_dependency_guards": guards}
(base / "pins/candidates.json").write_text(json.dumps(pins, indent=2) + "\n")
print(json.dumps(pins, indent=2))
