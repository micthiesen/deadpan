# Native raw-domain fee adapter candidate

Scratch-only candidate for the three stale fee comparisons after raw-domain
admission. Neither actual root nor any fixture was edited. No builds, native
execution, Git operation, network request or expected-body generation was run.
The reported differences 9248/8908, 9249/8909 and 112/95 were not used as fees.

Complete before/current files are under `before/<variant>/` and
`current/<variant>/`. Exact patches are `patches/<variant>.patch`. All per-file
before/after SHA-256 and byte counts are in `pins/candidates.json`; the two patches
are identical because these four current source files agree between roots.

## Integration and validation

Check current source against the before pins, preserve concurrent edits, then
apply the matching patch. The only files changed are:

1. `raw_domain_query_trace.rs`: clarify the new trace's disjoint counters.
2. `authored_eq/legacy_tile_baseline.rs`: reset/snapshot the independent Raw
   trace per actual scenario and disable it on scope exit.
3. `authored_eq/tile_admission_tests.rs`: validate Raw receipts separately and
   reconcile the witnessed additional units alongside the existing receipt fees.
4. `bound_reads/retained_host_pairs.rs`: use an out-of-body Raw snapshot for the
   40 successful pair assertions.

Run guarded builds/type checks in both actual roots, then these exact tests
serially with `--exact --test-threads=1` on each built Audio test binary:

```text
stages::authored_eq::tile_admission_tests::false_recursive_kernel_preserves_complete_old_matrix_and_total_work
stages::authored_eq::tile_admission_tests::metered_recursive_kernel_preserves_old_matrix_with_exact_new_index_fees
stages::bound_reads::retained_host_baseline::pairs::new_native_success_matches_full_old_pcm_masks_dependencies_depth_and_explicit_fees
```

Do not launch native executables in parallel.
After focused passes, run the complete pre-raw 744-body regression and full
Audio libraries in both roots, keeping all 23 oracle pins intact.

Scratch formatting and exact patch/pin checks are reported in `validation.json`.
These parse/static checks do not establish Rust type correctness or runtime
behavior. The whole 744-body frozen regression and the previously failing
comparisons have not been executed by this worker.

## Receipt semantics

The new raw trace previously incremented `completed_queries` for ordinary
success and also incremented `ordinary_calls`, which made the requested disjoint
formula false. Parent explicitly authorized clarifying this new test-only trace
before freezing it. Completed now means forwarded/admitted success only;
ordinary means successful unmetered construction, and failed means an attempt
without a completed product. The fields and fixed two-lane shape stay identical:

```text
constructor_calls = completed_queries + ordinary_calls + failed_queries
admitted_calls = completed_queries
sum(kind_counts) = completed_queries + ordinary_calls
canonical_units = 0
accepted_work = additional_units + partial_work + host_eviction_work
```

The existing four Original and two retained trace files, shapes and semantics
are untouched and pinned as unchanged dependencies. No public production code,
query allowance, residency cap, weight, DSP arithmetic or work refund changes.

## Tile comparisons

Every actual counter snapshot now includes the independent raw trace. The
scenario resets it after resetting the existing Original/retained traces. The
scope guard disables only Raw tracing at exit. Ordinary complete baseline
captures continue to run in the whole-Original legacy scope, so raw queries are
actually ordinary and must contribute zero additional work.

The adapters validate flags/depth, the disjoint call counts, product-kind totals,
canonical zero and the complete accepted/additional/partial/host equation before
using fees. Raw local eviction units must be included in the same global host
receipt already observed by the Original/retained instrumentation. Only actual
raw `additional_units` enters the added-fee term. Raw gross accepted work and its
local host subset are not added again.

The current-vs-ordinary counter equation is the existing independent Original
fees plus independent retained fees plus Raw additional units, with exactly one
actual-minus-ordinary GLOBAL host-eviction adjustment. There is no fee inferred
from a leftover ReadWork difference. Raw outcome/call/kind counts must agree
between the actual reader and its actual ordinary paired reader. The final
corpus must witness positive raw additional work. Direct-vs-certified and Domain
policy comparison paths validate these added snapshots too, rather than letting
the new instrumentation silently change their structural comparisons.

An explicitly imposed plan-work input overwrites the counter before a cached
refusal probe. Its plan counter comparison therefore suppresses all cumulative
receipt differences for that phase, and separately requires the Raw and other
constructor traces to be identical before/after the probe. This changes no real
work debit or refund. The cache lane remains independently reconciled.

The tile corpus's current OLD comparison has no independent qualification for
an accepted failed Raw prefix. The adapter first checks the full accepted-work
equation, then explicitly requires `partial_work == 0`. Unexpected partial work
must fail and be reviewed; it is not absorbed into a success fee or normalized
out of the OLD body.

## Forty successful native pairs

Only the successful-pair test resets Raw immediately before each whole paired
execution, obtains its actual snapshot after the legacy and current reads, then
disables tracing and passes the snapshot directly to `assert_success_pair`.
Ordinary successes from the legacy leg remain visible as disjoint ordinary
calls; completed/admitted successes belong to the current leg. Zero canonical,
complete receipt sums, kind counts and flags are checked independently.

The successful ReadWork difference must equal existing retained successful
additional receipts PLUS observed raw additional receipts. Both actual legacy
and current global host-eviction receipts, Raw local eviction work, and every
partial/failed constructor count are explicitly zero for these fresh successful
pairs. PCM, masks, dependencies, depth, provider calls, controller state and
cleanup checks remain in force. No residual is used as a fee.

`invoke`, `current_body` and the `raw_domain_host_baseline` child declaration are
byte-identical before/after; their protected hashes are recorded in the pins.
There is no per-invoke Raw reset, new receipt field or capture flag in the frozen
body. The parent's whole-RawLegacy regression can therefore reset once and
accumulate ordinary calls across all 744 requests as before. Parent still owns
any NEW per-read Raw capture hooks and may add them separately under an explicit,
default-off capture flag.

## Limits

- Rust type/borrow checks and all actual native checks remain unperformed here.
- The comparison intentionally rejects unexpected Raw partial-work cases; a
  separate qualified failure comparison is needed if the real corpus reaches one.
- The candidate adds no cache-eviction scenario or native lifetime test. It
  validates real existing global/local receipts when the selected matrix runs.
- Only the new Raw trace's completed/ordinary meaning changes. No OLD body or
  existing Original/retained trace slot is changed, widened or regenerated.
