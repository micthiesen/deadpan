from pathlib import Path
import difflib
import hashlib
import json

BASE = Path(__file__).resolve().parent
ROOTS = {"main-inherited": Path("/Users/michael/Code/deadpan"),
         "scoped-published": Path("/tmp/deadpan-query-groundwork-2026-10-26/scoped")}
PREFIX = Path("crates/deadpan-audio/src")
FILES = [PREFIX / path for path in ["raw_domain_query_trace.rs", "authored_eq/legacy_tile_baseline.rs",
    "authored_eq/tile_admission_tests.rs", "bound_reads/retained_host_pairs.rs"]]

def sha(data): return hashlib.sha256(data).hexdigest()
def write(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(value)
def replace(text, old, new):
    assert text.count(old) == 1, (old, text.count(old))
    return text.replace(old, new, 1)
def function(text, start, next_start, edit):
    at, end = text.index(start), text.index(next_start, text.index(start) + len(start))
    return text[:at] + edit(text[at:end]) + text[end:]

def raw_trace(text):
    text = replace(text, '    completed_queries: usize,\n',
        '    // Admitted successes; ordinary success is counted only in ordinary_calls.\n    completed_queries: usize,\n')
    text = replace(text, '                add(&mut lane.completed_queries, 1, &mut overflow);\n', '')
    return replace(text, '                if was_forwarded {\n                    add(&mut lane.admitted_calls, 1, &mut overflow);',
        '                if was_forwarded {\n                    add(&mut lane.completed_queries, 1, &mut overflow);\n                    add(&mut lane.admitted_calls, 1, &mut overflow);')

def legacy_tile(text):
    text = replace(text, '        "retained_owners_work_trace": crate::stages::retained_request::trace::owners_snapshot(),\n',
        '        "retained_owners_work_trace": crate::stages::retained_request::trace::owners_snapshot(),\n'
        '        "raw_domain_work_trace": crate::stages::raw_domain_query_trace::snapshot(),\n')
    return replace(text, '    crate::stages::retained_request::trace::reset();\n',
        '    crate::stages::retained_request::trace::reset();\n'
        '    crate::stages::raw_domain_query_trace::reset();\n'
        '    struct DisableRawTrace;\n'
        '    impl Drop for DisableRawTrace {\n'
        '        fn drop(&mut self) { crate::stages::raw_domain_query_trace::disable(); }\n'
        '    }\n'
        '    let _raw_trace = DisableRawTrace;\n')

def tile(text):
    text = replace(text, 'fn reconcile_paired_flat_host_receipts(',
        (BASE / "raw_tile_helper.rs.txt").read_text() + 'fn reconcile_paired_flat_host_receipts(')
    def flat(part):
        part = replace(part,
            '    for (index, field) in ["old_total_controller_work", "cache_plan_work"]\n',
            '    let raw = take_query_trace(actual, "raw_domain_work_trace");\n'
            '    let ordinary_raw = take_query_trace(&mut ordinary, "raw_domain_work_trace");\n'
            '    let raw_additional = raw_query_additional(&raw, actual_host);\n'
            '    assert_eq!(raw_query_additional(&ordinary_raw, ordinary_host), [0, 0]);\n'
            '    for lane in ["plan", "cache"] {\n'
            '        assert_eq!(ordinary_raw[lane]["admitted_calls"], 0);\n'
            '        for field in ["constructor_calls", "failed_queries", "kind_counts"] {\n'
            '            assert_eq!(raw[lane][field], ordinary_raw[lane][field], "same raw-domain outcomes on the actual paired reader");\n'
            '        }\n'
            '    }\n'
            '    for (index, field) in ["old_total_controller_work", "cache_plan_work"]\n')
        part = replace(part,
            '            i128::from(fees[index]) + i128::from(host[index]) - i128::from(old_host[index])\n'
            '        } + i128::from(retained_query_work[index]);',
            '            i128::from(fees[index]) + i128::from(host[index]) - i128::from(old_host[index])\n'
            '                + i128::from(retained_query_work[index]) + i128::from(raw_additional[index])\n'
            '        };')
        return replace(part, 'only independently observed new query fees and global paired host evictions differ:',
            'only independent Original/retained/raw fees and one global paired host eviction receipt differ:')
    text = function(text, 'fn compare_flattened_counter(', 'fn remove_flattened_traces(', flat)
    def remove_flat(part):
        return replace(part, '        "retained_owners_work_trace",\n', '        "retained_owners_work_trace",\n        "raw_domain_work_trace",\n')
    text = function(text, 'fn remove_flattened_traces(', 'fn compare_flattened_matrix(', remove_flat)
    def flat_matrix(part):
        part = replace(part, '    let mut total_fees = [0_u64; 2];\n', '    let mut total_fees = [0_u64; 2];\n    let mut raw_additional_witnessed = 0_u64;\n')
        part = replace(part, '                    "retained_owners_work_trace",\n', '                    "retained_owners_work_trace",\n                    "raw_domain_work_trace",\n')
        part = replace(part, '        let fees = compare_flattened_counter(&mut observed["final"], &expected["final"], false);\n',
            '        for lane in ["plan", "cache"] {\n'
            '            raw_additional_witnessed = raw_additional_witnessed.checked_add(number(&observed["final"]["raw_domain_work_trace"][lane], "additional_units")).unwrap();\n'
            '        }\n'
            '        let fees = compare_flattened_counter(&mut observed["final"], &expected["final"], false);\n')
        return replace(part, '    assert!(witnessed.into_iter().all(|units| units > 0));\n',
            '    assert!(witnessed.into_iter().all(|units| units > 0));\n'
            '    assert!(raw_additional_witnessed > 0, "actual raw-domain construction fees are exercised");\n')
    text = function(text, 'fn compare_flattened_matrix(', 'fn normalize_counter(', flat_matrix)
    def normalize(part):
        part = replace(part, '    let retained_query_work = retained_query_additional(actual, root_host_evictions);\n',
            '    let retained_query_work = retained_query_additional(actual, root_host_evictions);\n'
            '    let raw = take_query_trace(actual, "raw_domain_work_trace");\n'
            '    assert_eq!(raw_query_additional(&raw, root_host_evictions), [0, 0]);\n'
            '    for lane in ["plan", "cache"] {\n'
            '        assert_eq!(raw[lane]["admitted_calls"], 0, "whole Original legacy scope keeps raw reconstruction ordinary");\n'
            '    }\n')
        return part
    text = function(text, 'fn normalize_counter(', 'fn compare_matrix<', normalize)
    def domain(part):
        part = replace(part, '    let removed = reconcile_domain_policy_receipts(&trace, &old_trace);\n',
            '    let raw = take_query_trace(actual, "raw_domain_work_trace");\n'
            '    let old_raw = take_query_trace(&mut old, "raw_domain_work_trace");\n'
            '    let raw_fees = raw_query_additional(&raw, host_eviction_receipt(&processing));\n'
            '    let old_raw_fees = raw_query_additional(&old_raw, host_eviction_receipt(&old_processing));\n'
            '    assert_raw_pair_except_host(&raw, &old_raw);\n'
            '    let removed = reconcile_domain_policy_receipts(&trace, &old_trace);\n')
        return replace(part,
            '            - i128::from(old_fade_fees[lane])\n',
            '            - i128::from(old_fade_fees[lane])\n'
            '            + i128::from(raw_fees[lane]) - i128::from(old_raw_fees[lane])\n')
    text = function(text, 'fn compare_domain_policy_counter(', 'fn remove_domain_policy_traces(', domain)
    text = function(text, 'fn remove_domain_policy_traces(', 'fn compare_domain_policy_matrix(',
        lambda part: replace(part, '        "fade_work_trace",\n', '        "fade_work_trace",\n        "raw_domain_work_trace",\n'))
    def certified(part):
        return replace(part, '    let captures = actual\n',
            '    raw_query_additional(&actual["raw_domain_work_trace"], host_eviction_receipt(&actual["flattened_work_trace"]));\n'
            '    raw_query_additional(&direct["raw_domain_work_trace"], host_eviction_receipt(&direct["flattened_work_trace"]));\n'
            '    assert_eq!(actual["raw_domain_work_trace"], direct["raw_domain_work_trace"], "certified capture preserves actual raw constructor receipts");\n'
            '    let captures = actual\n')
    return function(text, 'fn compare_certified_counter(', 'fn compare_certified_matrix(', certified)

def pairs(text):
    text = replace(text, 'fn assert_success_pair(old: &Value, pair: &Value) {',
        (BASE / "raw_pairs_helper.rs.txt").read_text() + 'fn assert_success_pair(old: &Value, pair: &Value, raw_receipt: &Value) {\n'
        '    let raw_additional = assert_raw_receipt(raw_receipt);')
    text = replace(text, '        assert_eq!(lane_total(receipt, "partial_work", lane), 0);\n',
        '        assert_eq!(lane_total(receipt, "partial_work", lane), 0);\n'
        '        assert_eq!(raw_receipt[lane]["failed_queries"], 0, "successful raw metadata construction has no failed prefix");\n'
        '        assert_eq!(raw_receipt[lane]["partial_work"], 0);\n'
        '        assert_eq!(raw_receipt[lane]["host_eviction_work"], 0);\n')
    text = replace(text, '            lane_total(receipt, "additional_units", lane),\n',
        '            lane_total(receipt, "additional_units", lane).checked_add(raw_additional[usize::from(lane == "cache")]).unwrap(),\n')
    text = replace(text, 'complete NEW minus OLD debit equals independent successful additional receipts',
        'complete NEW minus OLD debit equals independent retained and raw successful receipts; global host eviction is zero in these fresh pairs')
    text = replace(text,
        '            "complete NEW minus OLD debit equals independent retained and raw successful receipts; global host eviction is zero in these fresh pairs"\n        );\n',
        '            "complete NEW minus OLD debit equals independent retained and raw successful receipts; global host eviction is zero in these fresh pairs"\n        );\n'
        '        assert_eq!(pair["legacy_receipts"]["fade"]["all_host_eviction_work"][usize::from(lane == "cache")], 0, "actual legacy paired host receipt is zero too");\n')
    def success(part):
        part = replace(part, '    let mut count = 0;\n', '    let mut count = 0;\n    let mut raw_completed = 0_u64;\n')
        part = replace(part,
            '            let paired = pair(fixture, value, true);\n            assert_success_pair(value, &paired);\n',
            '            raw_domain_query_trace::reset();\n'
            '            let paired = pair(fixture, value, true);\n'
            '            let raw_receipt = serde_json::to_value(raw_domain_query_trace::snapshot()).unwrap();\n'
            '            raw_domain_query_trace::disable();\n'
            '            assert_success_pair(value, &paired, &raw_receipt);\n'
            '            raw_completed += integer(&raw_receipt["plan"]["completed_queries"]) + integer(&raw_receipt["cache"]["completed_queries"]);\n')
        return replace(part, '    assert_eq!(count, 40);\n',
            '    assert_eq!(count, 40);\n    assert!(raw_completed > 0, "fresh actual public raw constructors are exercised");\n')
    return function(text, 'fn new_native_success_matches_full_old_pcm_masks_dependencies_depth_and_explicit_fees()',
        '#[test]\nfn actual_early_and_source_failures', success)

editors = [raw_trace, legacy_tile, tile, pairs]
pins = {"variants": {}}
for variant, root in ROOTS.items():
    entries = {}
    for path, edit in zip(FILES, editors):
        before = (root / path).read_text()
        after = edit(before)
        if path.name == "retained_host_pairs.rs":
            for start, end in [('fn invoke(', 'fn mode('), ('fn current_body(', '#[path = "raw_domain_host_baseline.rs"]')]:
                assert before[before.index(start):before.index(end)] == after[after.index(start):after.index(end)]
        write(BASE / "before" / variant / path, before)
        write(BASE / "current" / variant / path, after)
        entries[str(path)] = {"before_sha256": sha(before.encode()), "candidate_sha256": sha(after.encode())}
    pins["variants"][variant] = {"root": str(root), "files": entries}
write(BASE / "pins/candidates-unformatted.json", json.dumps(pins, indent=2) + "\n")
print("Prepared complete scratch candidates; format, then finalize patches/pins.")
