from pathlib import Path
import hashlib,json,subprocess
s=Path(__file__).resolve().parent
roots={'main':Path('/Users/michael/Code/deadpan'),'scoped':Path('/tmp/deadpan-query-groundwork-2026-10-26/scoped')}
owned=json.loads((s/'owned-paths.json').read_text())
sha=lambda b:hashlib.sha256(b).hexdigest()
entries={}
for line in(s/'index-source-entries.txt').read_text().splitlines():
 meta,path=line.split('\t',1);mode,oid,stage=meta.split()
 assert stage=='0';entries[path]=(mode,oid)
rows=[]
for name in owned:
 mode,oid=entries[name]
 data=subprocess.check_output(['git','cat-file','blob',oid],cwd=roots['main'])
 assert mode=='100644'and data==(roots['scoped']/name).read_bytes(),name
 rows.append({'path':name,'mode':mode,'git_blob':oid,'bytes':len(data),'sha256':sha(data),'scoped_index_equal':True,'main_equal':data==(roots['main']/name).read_bytes()})
assert[r['path']for r in rows if not r['main_equal']]==['crates/deadpan-plan/src/plan.rs']
(s/'index-source-equality.json').write_text(json.dumps(rows,indent=2)+'\n')
preserved={}
for v,root in roots.items():
 initial=json.loads((s/(v+'-initial-authority.json')).read_text())
 others={p:h for p,h in initial.items()if p not in owned}
 for p,h in others.items():
  b=(root/p).read_bytes();assert len(b)==h['bytes']and sha(b)==h['sha256'],(v,p)
 preserved[v]=len(others)
 names=json.loads((s/('source-files.json'if v=='main'else'scoped-source-files.json')).read_text())
 current={}
 for p in names:
  b=(root/p).read_bytes();current[p]={'bytes':len(b),'sha256':sha(b)}
 build=json.loads((s/f'raw-lintfinal-audio-{v}-build.json').read_text())
 assert{str(root/p):h for p,h in current.items()}==build['source_after'],v
 (s/(v+'-final-source-pins.json')).write_text(json.dumps(current,indent=2)+'\n')
assert preserved=={'main':2821,'scoped':2493}
oracles=json.loads((s/'immutable-oracle-pins.json').read_text());assert len(oracles)==23
for row in oracles:
 for root in roots.values():assert sha((root/row['path']).read_bytes())==row['sha256']
actual=subprocess.check_output(['git','diff','--cached','--name-only','-z'],cwd=roots['main']).decode().strip('\0').split('\0')
assert set(actual)==set(owned)
out={'preserved_unowned':preserved,'immutable_oracles':23,'owned_paths':30,'index_scoped_equal':30,'index_main_equal':29,'main_scoped_differing_owned_paths':['crates/deadpan-plan/src/plan.rs']}
(s/'preserved-source-and-oracle-final-audit.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out))
