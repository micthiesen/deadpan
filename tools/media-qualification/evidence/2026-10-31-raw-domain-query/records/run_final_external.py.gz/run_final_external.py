from pathlib import Path
import subprocess,os
s=Path(__file__).resolve().parent
for v in ['scoped','main']:
 names=[l.removesuffix(': test')for l in(s/f'raw-old-plan-{v}-list.stdout').read_text().splitlines()if l.endswith('raw_domain_baseline::raw_domain_matches_explicit_external_old_v1: test')]
 assert len(names)==1
 env=os.environ.copy();env['DEADPAN_RAW_DOMAIN_EXPECTED']=str(s/'raw-old-plan-canonical-body.json')
 subprocess.run(['python3',str(s/'run_logic_target.py'),f'raw-final-plan-{v}-build',v,'plan','deadpan_plan',f'raw-final-{v}-external','--ignored','--exact',names[0],'--test-threads=1'],env=env,check=True)
