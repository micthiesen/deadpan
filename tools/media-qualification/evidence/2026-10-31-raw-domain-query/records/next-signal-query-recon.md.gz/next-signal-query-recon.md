# Next content-query admission boundary after Point borrowing

Read-only source reconnaissance of the current Main tree. No source, oracle,
build, native executable, Git state or production setting was changed. Ripwire
was used first; its map was capped and query/policy name edges were ambiguous,
so the exact implementation files below were read directly.

## Preferred next unit

Admit the **fresh Structural Point content query**, reached from
StageAudio::read_point_domain_controlled, as its own sealed borrowed product.
Expose it through AudioPointDomain (whose stored signal is constructed as
Structural), using the existing actual structural_child_query algorithm on
PointCeil with stops (true, true). Retain its carrier through the ordinary
policy query, preflight, numerical nested reads and final check. Keep policy
admission as a separately named next product.

Do not apply a nominal query_admitted wrapper indiscriminately to
SignalInput::Signal: that input also accepts Source, Projected and Silence
providers. The existing admitted helper explicitly accepts only Structural.
Tape, PreserveTape and Mix each need their actual construction/aggregation
algorithms admitted separately. A Point-only unit is narrower and reuses real
already admitted traversal without advertising those other paths as covered.

This is after the independent signal_ref change, not a replacement for it.
Borrowing the stored signal prevents the unnecessary clone; it does not admit
the subsequent fresh spans or policy.

## Exact native dispatch and caller map

- crates/deadpan-audio/src/signal_input.rs:12-17: SignalInput is a closed Copy
  enum of Signal(&AudioSignal), Tape(&AudioSignalTape),
  PreserveTape(&AudioSignalTape), Mix(&AudioSignalMix).
- signal_input.rs:50-59: query dispatches Signal to signal.query and both tape
  variants to tape.query; Mix explicitly rejects this entry.
- signal_input.rs:62-72: policy dispatches Signal to signal.policy, Tape to
  tape.policy, PreserveTape to tape.policy_after_preserve; Mix rejects.
- stages.rs:2782-2824: read_signal first routes Mix to read_mix_controlled.
  Other inputs call query, debit its returned work only after construction,
  call policy, debit that work only after construction, preflight policy
  contents and query spans, then pass both owned products to
  read_signal_queries. No admitted Signal product is retained there.
- stages.rs:1167-1205: read_point_domain_controlled validates domain identity,
  depth, frames and reference/sample mapping, then delegates to read_signal.
  The planned signal_ref change affects only its argument expression.
- Additional read_signal entries: read_definition_controlled at stages.rs:1061;
  public tape read at 1098; streamed stage input at 2758; independent routed
  source voice at routed.rs:208. Staged tape/PreserveTape sources also enter via
  stage_cache.rs:106, stage_projection.rs:118/175 and routed.rs:482.
- read_signal_queries has three callers: read_signal at stages.rs:2823;
  per-voice render_mix_query at signal_mix.rs:121; and prepared direct root
  sound at sound_events.rs:216. The latter two arrive with their own already
  constructed owned query/policy pairs and bypass read_signal construction.

Line numbers are current-tree inspection positions, not stable API identifiers.

## Existing admitted machinery to reuse

crates/deadpan-plan/src/audio_signal_processing_query.rs:

- SignalBuffer<'plan,I,L> at 8-11 owns AudioSignalQuery and a distinct vector
  capacity Memory. SignalValue at 14-23 wraps this entire buffer in
  GuardedBound, which retains other owning metadata leases.
- structural_query_unmetered at 46-69 is the actual ordinary Structural
  algorithm: it calls structural_query_admitted with Unmetered and only then
  unwraps the result. Thus there is no separate traversal to reimplement.
- structural_child_query at 71-85 accepts an existing QueryBudget, checks the
  exact grid/range and rejects any non-Structural provider, then invokes the
  same actual algorithm.
- structural_query_admitted at 88-149 uses one cumulative budget and requires
  limits.maximum_work to equal the current budget remainder. It admits each
  span, grows/retains accumulator storage, admits project/revision/definition
  headers and records usage since its checkpoint.
- RenderPlan::audio_processing_admitted at 152-193 already uses that helper on
  RoundEven and converts it into the public AdmittedAudioProcessingQuery.
  The SignalValue intermediate is not itself publicly exposed.
- Conversion at 195-296 proves the existing pattern for retaining input vector
  capacity while moving elements to an independently admitted output vector.

crates/deadpan-plan/src/audio_signal_query.rs:84 onward:
span_admitted is shared actual traversal. It admits Repeat/retime vectors and
identities, concrete Leaf contents, Stage descriptors and boxed Bound metadata,
then merges those owning leases into the returned span. Reuse it rather than
cloning and charging an already materialized AudioSignalQuery afterward.

crates/deadpan-plan/src/audio_policy_query.rs:

- Public AdmittedAudioPolicyQuery (27-52), RenderPlan::audio_policy_admitted
  (89-122) and AudioDomain::policy_admitted (125-153) are AudioSample products,
  not SignalSample products.
- Its private signal_policy at 522-584 already uses structural_child_query
  with stops (false,false) and (false,true) for Root/raw-Point traversal. It
  deliberately comments that arbitrary voice providers retain ordinary policy.
- finish at 829-918 specifically builds Range<AudioSample> and
  AudioPolicyQuery<AudioSample>. It cannot be reused as a SignalSample public
  policy product merely by relabeling the existing carrier. A future Point
  policy product needs its own typed finalization and full before witness.

No public AdmittedAudioSignalQuery, AudioSignal::query_admitted or generic
SignalSample policy carrier was found. No Tape/Mix admitted query factory was
found in audio_tape.rs or audio_mix.rs. Exact searches supplement, rather than
depend on, Ripwire's incomplete name map.

## Concrete owning result payloads

AudioSignalQuery, audio_signal.rs:530-540, owns:

- ProjectId and RevisionId header identities;
- optional AudioDefinitionSelector;
- Vec<AudioSignalSpan>, with vector capacity distinct from payload leases;
- samples, LookupStats and work are scalar/value metadata.

Each AudioSignalSpan (496-514) owns optional definition, InstancePath and
RepeatInstance identity vector, optional gap IterationId, retimes vector, and
AudioSignalContent. Its exact extents, transforms, grid and sample map are
value fields. Content (460-465) can own Leaf(AudioContent),
Stage(AudioStage), Box<AudioBound>, or Arc<AudioStageProjection>. The latter
must retain the actual ownership/share semantics of its provider, not be
flattened into fabricated Structural data. The narrow Point Structural helper
does not grant coverage for the independent Projected provider.

AudioPolicyQuery<SignalSample>, audio_policy.rs:19-26, owns a suppressed range
Vec and a contents Vec<AudioContent>, plus scalar lookup/work. Ordinary policy
construction additionally has transient original/merged/output range buffers
and recursive content inventories.

The tape outer query, audio_tape.rs:317-386, dispatches runs using one aggregate
work/span allowance, receives each run's query, and moves query.spans into its
outer spans Vec. Tape policy (408-496) dispatches policy_override or each run's
signal on the declared grid, extends suppressed/contents, then sorts/merges.
Those aggregate overlap and transfer lifetimes are not admitted by exposing the
Structural child helper alone.

## Native moves that a sealed borrowed Signal carrier must address

read_signal_queries (stages.rs:2826-2940) consumes query.spans with an owning
for loop. The actual per-span operations already inspect by reference: content
matching, source recipe derivation, prepare_stage/prepare_projected/read_bound,
and sampling recipes. Its metadata cannot remain in an opaque carrier if this
function requires the entire AudioSignalQuery by value.

The narrow consumption adaptation is to accept &AudioSignalQuery and iterate
&query.spans, keeping the sealed carrier at the caller. Existing ordinary owned
callers can also borrow their product for that synchronous call. This avoids an
unadmitted clone or a public detach API. Review all three call sites above;
Mix may continue owning/moving its voice while borrowing the voice.signal field
for the call, and direct root-sound input can retain its owned query locally.

Policy may remain owned for this content-query-only unit. The function's final
moves are different: apply_suppression borrows policy.suppressed, then
merged_suppression(policy.suppressed) consumes and sorts that range Vec and
returns an owned suppression Vec in SignalBlock. A later sealed policy product
must account this transfer/output ownership explicitly; replacing it with an
unbilled clone to satisfy the old signature would leave a new boundary.

Keep result metadata alive across both preflight and all numerical reads.
Returning borrowed spans alone is insufficient if the outer carrier is dropped
before recursive Bound/Stage consumption.

## Work and evidence constraints

The Structural helper's returned query.work comes from usage_since:
canonical traversal plus additional admitted units in metered mode. The carrier
should separately expose canonical/additional/forwarded receipts under the
existing pattern. Do not normalize the actual returned field to a guessed old
counter or charge query.work again after admission. Existing ordinary native
debits must remain for the explicitly unmetered/legacy lane; admitted forwarding
must be exactly once. No local allowance or existing weight needs changing.

Freeze fresh ordinary Point content-query results before changing this public/
native boundary. The current 77 raw-domain witness includes all 18 private
Point stored-signal payloads, but it does not serialize the later generated
query's complete spans, work, lookup or query errors. Use those actual checked
operands and valid full/crop/empty/limit requests for a new query witness,
preserving real setup and any existing internal metered-helper observations
separately. Do not manufacture unsupported providers or Empty products.

Focused verification should include full ordinary/false parity, actual
canonical/additional receipts, exact/short work and requested Layout peaks,
callback-prefix refusal/cancellation/issuer rotation, overlap of vector
capacity and owning payloads, and real native lease liveness through
preflight/provider/nested success and failure. Existing native 744 captures
supply whole-read before behavior but are not a substitute for a complete
Point content-query oracle. None of this reconnaissance establishes a test
pass, a whole-read admission result or a memory/performance measurement.
