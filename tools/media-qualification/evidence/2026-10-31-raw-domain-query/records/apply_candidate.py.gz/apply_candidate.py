from pathlib import Path
base=Path('/tmp/deadpan-raw-domain-query-admission-2026-10-31/production-candidate')
main=base/'main'
# guarded plan-side carrier and public entrypoint
p=main/'crates/deadpan-plan/src/audio_bound_probe.rs'
s=p.read_text()
s=s.replace('    Budget as QueryBudget, Owned, Result,\n','    Budget as QueryBudget, Owned, Result, outer,\n')
needle=next(line for line in s.splitlines(True) if line.startswith("type RawResult"))
assert needle in s
s=s.replace(needle,needle+"""
enum RawDomainValue<'plan, I, L> {
    Ordinary(AudioBoundDomain<'plan>),
    Admitted(Owned<AudioBoundDomain<'plan>, I, L>),
}

/// A fresh raw-domain result with its independent construction lease.
/// This carrier has no Clone or detach operation; borrow domain() while it lives.
pub struct AdmittedAudioBoundDomain<'plan, I, L> {
    value: RawDomainValue<'plan, I, L>,
    canonical: usize,
    additional: usize,
    forwarded: bool,
}

impl<I, L> AdmittedAudioBoundDomain<'_, I, L> {
    pub fn domain(&self) -> &AudioBoundDomain<'_> {
        match &self.value {
            RawDomainValue::Ordinary(value) => value,
            RawDomainValue::Admitted(value) => &value.value,
        }
    }
    pub fn canonical_units(&self) -> usize { self.canonical }
    pub fn additional_units(&self) -> usize { self.additional }
    pub fn total_units(&self) -> usize { self.canonical + self.additional }
    pub fn was_forwarded(&self) -> bool { self.forwarded }
}
""")
needle='''    fn set_root_evaluation_admitted<A: AudioSoundContextAdmission>(
'''
assert needle in s
wrapper="""    /// Rebuild the actual raw domain under this caller's admission policy.
    /// The historical fixed local allowance remains 65,536; Bound/Core work
    /// is not forwarded a second time.
    pub fn raw_domain_query<A: AudioSoundContextAdmission>(
        &self,
        admission: &mut A,
    ) -> std::result::Result<AdmittedAudioBoundDomain<'plan, A::Issuer, A::Lease>, A::Error> {
        if !A::METERED {
            return Ok(AdmittedAudioBoundDomain {
                value: RawDomainValue::Ordinary(self.raw_domain()?),
                canonical: 0,
                additional: 0,
                forwarded: false,
            });
        }

        let mut local = Budget {
            remaining: 65_536,
            lookup: super::LookupStats::default(),
        };
        let mut budget = QueryBudget::new(&mut local, admission);
        let value = self.raw_domain_admitted(&mut budget);
        let canonical = budget.canonical_used;
        let additional = budget.additional_used;
        let value = outer::<_, A>(value)?;
        budget.check_memory(&value.memory)?;
        budget.check()?;
        if canonical != 0 {
            return Err(PlanError::InvalidPlan("raw-domain canonical work must remain zero").into());
        }
        Ok(AdmittedAudioBoundDomain {
            value: RawDomainValue::Admitted(value),
            canonical,
            additional,
            forwarded: true,
        })
    }

"""
s=s.replace(needle,wrapper+needle)
p.write_text(s)
p=main/'crates/deadpan-plan/src/audio_bound.rs'
s=p.read_text()
needle='mod probe;\n'
assert needle in s
s=s.replace(needle,needle+'pub use probe::AdmittedAudioBoundDomain;\n')
p.write_text(s)
for v in ['main','scoped']:
 p=base/v/'crates/deadpan-plan/src/plan.rs'
 s=p.read_text()
 old='pub use audio_bound::{AudioBound, AudioBoundDomain};'
 assert old in s
 p.write_text(s.replace(old,'pub use audio_bound::{AdmittedAudioBoundDomain, AudioBound, AudioBoundDomain};'))
# mirror plan/audio_bound changes into scope, preserving only plan.rs inherited difference
scope=base/'scoped'
for rel in ['crates/deadpan-plan/src/audio_bound_probe.rs','crates/deadpan-plan/src/audio_bound.rs']:
 (scope/rel).write_bytes((main/rel).read_bytes())
# domain transfer common geometry and borrowed view
p=main/'crates/deadpan-audio/src/domain_transfer.rs'
s=p.read_text()
old='''        let root_support = domain.root_samples();
        let length = root_support
            .end
            .0
            .checked_sub(root_support.start.0)
            .filter(|length| *length > 0)
            .ok_or(SignalTransferError::Range)?;
        let carrier = RootSignalTransfer::new(
            AudioSample(0)..AudioSample(length),
            root_at_anchor.checked_sub(ExactRatio::integer(root_support.start.0))?,
            signal_anchor,
            root_samples_per_signal_sample,
            output.clone(),
        )?;
        Ok(Self {
            domain,
            descriptor: DomainTransferDescriptor {
                root_support,
                root_at_anchor,
                signal_anchor,
                root_samples_per_signal_sample,
                output,
            },
            carrier,
        })
'''
assert old in s
new='''        let (descriptor, carrier) = transfer_parts(
            &domain, root_at_anchor, signal_anchor, root_samples_per_signal_sample, output,
        )?;
        Ok(Self { domain, descriptor, carrier })
    }

    pub(crate) fn borrowed<'domain>(
        domain: &'domain AudioDomain<'plan>,
        root_at_anchor: ExactRatio,
        signal_anchor: SignalSample,
        root_samples_per_signal_sample: ExactRatio,
        output: Range<SignalSample>,
    ) -> Result<BorrowedDomainSignalTransfer<'domain, 'plan>, SignalTransferError> {
        let (descriptor, carrier) = transfer_parts(
            domain, root_at_anchor, signal_anchor, root_samples_per_signal_sample, output,
        )?;
        Ok(BorrowedDomainSignalTransfer { domain, descriptor, carrier })
'''
s=s.replace(old,new)
s += '''

pub(crate) struct BorrowedDomainSignalTransfer<'domain, 'plan> {
    domain: &'domain AudioDomain<'plan>,
    descriptor: DomainTransferDescriptor,
    carrier: RootSignalTransfer,
}

pub(crate) trait DomainTransferView<'plan> {
    fn domain(&self) -> &AudioDomain<'plan>;
    fn descriptor(&self) -> &DomainTransferDescriptor;
    fn carrier(&self) -> &RootSignalTransfer;
}
impl<'plan> DomainTransferView<'plan> for DomainSignalTransfer<'plan> {
    fn domain(&self) -> &AudioDomain<'plan> { &self.domain }
    fn descriptor(&self) -> &DomainTransferDescriptor { &self.descriptor }
    fn carrier(&self) -> &RootSignalTransfer { &self.carrier }
}
impl<'domain, 'plan> DomainTransferView<'plan>
    for BorrowedDomainSignalTransfer<'domain, 'plan>
{
    fn domain(&self) -> &AudioDomain<'plan> { self.domain }
    fn descriptor(&self) -> &DomainTransferDescriptor { &self.descriptor }
    fn carrier(&self) -> &RootSignalTransfer { &self.carrier }
}

fn transfer_parts(
    domain: &AudioDomain<'_>,
    root_at_anchor: ExactRatio,
    signal_anchor: SignalSample,
    root_samples_per_signal_sample: ExactRatio,
    output: Range<SignalSample>,
) -> Result<(DomainTransferDescriptor, RootSignalTransfer), SignalTransferError> {
    let root_support = domain.root_samples();
    let length = root_support.end.0.checked_sub(root_support.start.0)
        .filter(|length| *length > 0).ok_or(SignalTransferError::Range)?;
    let carrier = RootSignalTransfer::new(
        AudioSample(0)..AudioSample(length),
        root_at_anchor.checked_sub(ExactRatio::integer(root_support.start.0))?,
        signal_anchor, root_samples_per_signal_sample, output.clone(),
    )?;
    Ok((DomainTransferDescriptor {
        root_support, root_at_anchor, signal_anchor, root_samples_per_signal_sample, output,
    }, carrier))
}
'''
p.write_text(s)
# host native integration plus legacy TLS scaffolding
p=main/'crates/deadpan-audio/src/stages.rs'
s=p.read_text()
s=s.replace('''    AudioBound, AudioBoundDomain, AudioContent,''','''    AdmittedAudioBoundDomain, AudioBound, AudioBoundDomain, AudioContent,''')
s=s.replace('''struct ReadBlock {
''','''enum RawBoundDomain<'plan, I, L> {
    Ordinary(AudioBoundDomain<'plan>),
    Admitted(AdmittedAudioBoundDomain<'plan, I, L>),
}
impl<'plan, I, L> RawBoundDomain<'plan, I, L> {
    fn domain(&self) -> &AudioBoundDomain<'plan> {
        match self {
            Self::Ordinary(value) => value,
            Self::Admitted(value) => value.domain(),
        }
    }
}

struct ReadBlock {
''')
needle='''#[path = "sound_context_admission.rs"]
mod sound_context_admission;
'''
assert needle in s
s=s.replace(needle,needle+'''#[cfg(test)]
#[path = "raw_domain_request.rs"]
mod raw_domain_request;
''')
s=s.replace('''    fn read_domain_transferred_controlled(
        &mut self,
        provider: &mut impl AudioSourceProvider,
        transfer: &DomainSignalTransfer<'_>,
''','''    fn read_domain_transferred_controlled<'plan, T: crate::domain_transfer::DomainTransferView<'plan>>(
        &mut self,
        provider: &mut impl AudioSourceProvider,
        transfer: &T,
''')
s=s.replace('''        match bound.raw_domain()? {
            AudioBoundDomain::Root(domain) => {
''','''        #[cfg(test)]
        let raw_domain = if raw_domain_request::legacy() {
            RawBoundDomain::Ordinary(bound.raw_domain()?)
        } else {
            let mut admission = sound_context_admission::Admission::new(self, control);
            RawBoundDomain::Admitted(bound.raw_domain_query(&mut admission)?)
        };
        #[cfg(not(test))]
        let raw_domain = {
            let mut admission = sound_context_admission::Admission::new(self, control);
            RawBoundDomain::Admitted(bound.raw_domain_query(&mut admission)?)
        };
        match raw_domain.domain() {
            AudioBoundDomain::Root(domain) => {
''')
s=s.replace('''                let transfer = DomainSignalTransfer::new(domain, at, output.start, step, output)?;
''','''                let transfer = crate::domain_transfer::DomainSignalTransfer::borrowed(
                    domain, at, output.start, step, output,
                )?;
''')
p.write_text(s)
(scope/'crates/deadpan-audio/src/domain_transfer.rs').write_bytes((main/'crates/deadpan-audio/src/domain_transfer.rs').read_bytes())
(scope/'crates/deadpan-audio/src/stages.rs').write_bytes((main/'crates/deadpan-audio/src/stages.rs').read_bytes())
# Test-only legacy selection. Whole retained and Original wrappers call this; narrow fade wrapper remains unchanged.
p=main/'crates/deadpan-audio/src/raw_domain_request.rs'
p.parent.mkdir(parents=True,exist_ok=True)
p.write_text('''//! Test-only switch for whole-read OLD raw-domain observations.
thread_local! {
    static LEGACY: std::cell::Cell<bool> = const { std::cell::Cell::new(false) };
}
pub(super) fn legacy() -> bool { LEGACY.with(std::cell::Cell::get) }
pub(super) fn with_legacy<T>(action: impl FnOnce() -> T) -> T {
    struct Restore(bool);
    impl Drop for Restore {
        fn drop(&mut self) { LEGACY.with(|mode| mode.set(self.0)); }
    }
    let _restore = Restore(LEGACY.with(|mode| mode.replace(true)));
    action()
}
''')
p=main/'crates/deadpan-audio/src/retained_request.rs'
s=p.read_text()
old='''    let _restore = Restore(LEGACY.with(|mode| mode.replace(true)));
    action()
}
'''
assert old in s
s=s.replace(old,'''    let _restore = Restore(LEGACY.with(|mode| mode.replace(true)));
    super::raw_domain_request::with_legacy(action)
}
''',1)
p.write_text(s)
p=main/'crates/deadpan-audio/src/original_request.rs'
s=p.read_text()
start=s.index('pub(super) fn with_legacy_original_queries')
end=s.index('\n}',start)+2
block=s[start:end]
old='''pub(super) fn with_legacy_original_queries<T>(action: impl FnOnce() -> T) -> T {
    super::retained_request::with_legacy_retained_queries(|| {
'''
assert old in block
block=block.replace(old,'''pub(super) fn with_legacy_original_queries<T>(action: impl FnOnce() -> T) -> T {
    super::raw_domain_request::with_legacy(|| {
        super::retained_request::with_legacy_retained_queries(|| {
''',1)
assert block.endswith('    })\n}')
block=block[:-len('    })\n}')]+'    })\n    })\n}'
p.write_text(s[:start]+block+s[end:])
for rel in ['crates/deadpan-audio/src/raw_domain_request.rs','crates/deadpan-audio/src/retained_request.rs','crates/deadpan-audio/src/original_request.rs']:
 (scope/rel).write_bytes((main/rel).read_bytes())
