# Raw-domain implementation adjudication

Initial runner-env patching searched for a native-only allowlist anchor in the
pure Plan runners. It stopped before changing those two runners; no capture had
run. Their original versions are retained and the actual Plan anchor was patched.
Build receipts retain the originally executed runner hash.

The first production candidate Plan builds failed in both roots: LookupStats was
looked up in the wrong parent module and the new carrier lacked the crate-level
public re-export. The parent changed the path to crate::LookupStats and added the
public export. These failures have no acceptance credit; frozen bodies stay exact.

The initial scratch-only trace used an unbounded event vector. Before integrating
production source it was replaced with default-off bounded scalar lane counters,
separate accepted partial and independently observed host-eviction work. Existing
four-Original and two-retained snapshot shapes are unchanged.

The first native builds exposed an elided Plan payload lifetime in the carrier
getter. The returned borrow must retain the stored plan lifetime independently
of its shorter carrier borrow. The parent named that lifetime on the impl and
domain getter. No data, constructor work or oracle changed.

Adding a raw receipt field to the large tile-test JSON macro hit Rust's macro
recursion limit in both variants. The parent assigns that one new field after
the existing object construction. No crate recursion cap or semantic expected
body changed. The failed builds remain preserved.

The first phase integration was the older weak layer (patch07eb96...), not the
reported ledger-backed revision. The manifest reader treated the string
patch_sha256 entry as a file record, and orchestration incorrectly continued
after that check failed. The first phase compile failed before any runtime test.
Its new phase test file was also missing from that first build's source list;
those two failed build receipts have no complete-source acceptance credit.

The worker's attempted scratch regeneration later overwrote some historical
before/after copies without changing repository source or refreshing the old
patch/pins. The parent preserved the actual integrated first layer separately,
then reconstructed a reviewed repair in phase-repair from exact current source.
The repaired layer installs a real policy-live getter, excludes stack and
unowned input sizes from its heap lower bound, and skips unobserved internal
calls. The parent fixed the generation script's lost working text, threaded the
temporary definition through the Root helper, verified all actual before/after
hashes, applied both repair patches, and added every phase file to source lists
before rebuilding. All earlier failures remain explicit.

The frozen corpus proves every one of its59Root evaluation selectors is None.
The phase test therefore records this absence and does not fabricate a Some
replacement to satisfy a coverage assertion. Point selector coverage is checked
separately. No oracle was regenerated.

Strict lint rejected the production-unused ordinary raw enum variant and the
phase helper with eight parameters. The native matrix stopped after the fully
passing isolated definition target (171 tests); the next target was never
launched and no source changed during that guarded run. Ordinary and its match
arm are now cfg(test). Every phase call counts exactly one temporary definition,
so the redundant constant eighth argument was removed without changing phase
checks. Failed strict runs retain their exits with no acceptance credit. The
first generated patch used numeric diff headers unsupported by apply_patch;
it failed without changing the phase file, which was reread before correction.

The first scratch full-body auditor subtracted the embedded pair's older
retained-legacy read delta rather than the frozen raw OLD paired.new. Its provider
liveness helper also looked up an unset synthetic key, making that assertion
vacuous. The parent found both during review, and the worker preserved v1
separately before repair. The corrected auditor computes both actual read deltas
from their full before/after states, passes the actual raw receipt into the
lifetime check, retains complete state differences and outside receipt leaves,
and requires exact reconciliation for all 664 non-injected requests. The parent
ran that corrected script independently on both final5 bodies. The 80 injected
requests and 56 differing plan-lane arithmetic checks remain explicit, rather
than attributing nested surrounding work to raw construction. An early parent
estimate of 28 mismatches was corrected to the observed 56 per root.

The first archive attempt encountered the failed phase preparer's empty
phase-test-candidate/prepare-run.json. That incomplete, unpublished archive
directory was moved to scratch without deleting it. The final writer preserves
this exact zero-byte stub as opaque failed-preparer evidence, not JSON execution
or acceptance data; every other JSON file still parses and every actual run
receipt remains terminal and guarded.
