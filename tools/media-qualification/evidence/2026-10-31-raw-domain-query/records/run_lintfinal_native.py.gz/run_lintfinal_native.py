from pathlib import Path
import subprocess,json,hashlib
s=Path(__file__).resolve().parent
prior=Path('/tmp/deadpan-retained-fade-query-admission-2026-10-30')
valid=[]
for label in json.loads((prior/'final-audit.json').read_text())['tests']:
 if '-audio-'not in label:continue
 r=json.loads((prior/(label+'.json')).read_text())
 for p,h in r['binary_before'].items():valid.append((h['sha256'],prior,label))
for p in s.glob('*.json'):
 try:r=json.loads(p.read_text())
 except ValueError:continue
 if not isinstance(r,dict)or r.get('exit_code')!=0 or not r.get('binaries_unchanged')or not r.get('sources_unchanged'):continue
 if 'binary_before'not in r:continue
 stdout=s/(p.stem+'.stdout')
 if not stdout.exists()or 'test result: ok.'not in stdout.read_text():continue
 if any(a in r['command']for a in ['--list','--exact']):continue
 if not (p.stem.startswith('raw-native5-')and p.stem.endswith('-library')or p.stem.startswith('raw-final-')and'-audio-'in p.stem):continue
 for _,h in r['binary_before'].items():valid.append((h['sha256'],s,p.stem))
rows=[]
for v in ['scoped','main']:
 build=f'raw-lintfinal-audio-{v}-build'
 subprocess.run(['python3',str(s/'run_target.py'),build,v,'audio','deadpan_audio',f'raw-lintfinal-audio-{v}-list','--list'],check=True)
 pins=json.loads((s/(build+'-pins.json')).read_text());assert len(pins)==21
 for p in sorted(pins,key=lambda p:p['name']):
  assert hashlib.sha256(Path(p['path']).read_bytes()).hexdigest()==p['sha256']
  same=next(((directory,label)for digest,directory,label in valid if digest==p['sha256']),None)
  if same:
   directory,label=same
   r=json.loads((directory/(label+'.json')).read_text())
   assert r['exit_code']==0 and r['sources_unchanged']and r['binaries_unchanged']
   rows.append({'variant':v,'target':p['name'],'reused':True,'receipt':str(directory/(label+'.json')),'sha256':p['sha256']})
  else:
   label=f"raw-lintfinal-{v}-audio-{p['name'].replace('_','-')}"
   args=['--skip','general_split_sound::']if v=='main'and p['name']=='stages'else[]
   subprocess.run(['python3',str(s/'run_target.py'),build,v,'audio',p['name'],label,*args,'--test-threads=1'],check=True)
   rows.append({'variant':v,'target':p['name'],'reused':False,'receipt':str(s/(label+'.json')),'sha256':p['sha256']})
  (s/'final-audio-coverage-progress.json').write_text(json.dumps(rows,indent=2))
 subprocess.run(['python3',str(s/'capture_new_native6.py'),v],check=True)
(s/'final-audio-coverage.json').write_text(json.dumps(rows,indent=2))
subprocess.run(['python3',str(s/'classify_new_native6.py')],check=True)
subprocess.run(['python3',str(s/'run_target.py'),'raw-lintfinal-audio-main-build','main','audio','stages','raw-final-fresh-split','general_split_sound::','--nocapture','--test-threads=1'],check=False)
