from pathlib import Path
import hashlib,json,re
BASE=Path(__file__).resolve().parent
pins=json.loads((BASE/'pins/candidates.json').read_text())
def sha(data):return hashlib.sha256(data).hexdigest()
def apply_one(before,lines,at):
    source=before.splitlines(keepends=True);output=[];cursor=0
    while at<len(lines) and lines[at].startswith('@@'):
        match=re.match(r'@@ -(\d+)(?:,(\d+))? \+(\d+)(?:,(\d+))? @@',lines[at]);assert match
        start,old_count,_,new_count=match.groups();old_count=int(old_count or 1);new_count=int(new_count or 1)
        start=int(start)-1 if old_count else int(start);assert start>=cursor
        output.extend(source[cursor:start]);cursor=start;old_seen=new_seen=0;at+=1
        while at<len(lines) and not lines[at].startswith(('@@','--- ')):
            kind,text=lines[at][0],lines[at][1:];assert kind in ' +-'
            if kind in ' -':assert source[cursor]==text;cursor+=1;old_seen+=1
            if kind in ' +':output.append(text);new_seen+=1
            at+=1
        assert (old_seen,new_seen)==(old_count,new_count)
    output.extend(source[cursor:]);return ''.join(output),at
report={}
for variant,pin in pins['variants'].items():
    patch=(BASE/'patches'/f'{variant}.patch').read_text();assert sha(patch.encode())==pin['patch_sha256']
    lines=patch.splitlines(keepends=True);at=0
    for name,entry in pin['files'].items():
        new=entry['before_sha256'] is None
        before='' if new else (BASE/'before'/variant/name).read_text()
        after=(BASE/'new'/name).read_text() if new else (BASE/'current'/variant/name).read_text()
        if not new:assert sha(before.encode())==entry['before_sha256']
        assert sha(after.encode())==entry['after_sha256']
        old_name='/dev/null' if new else 'a/'+name
        assert lines[at:at+2]==['--- '+old_name+'\n','+++ b/'+name+'\n']
        applied,at=apply_one(before,lines,at+2);assert applied==after
    assert at==len(lines)
    stage=(BASE/'current'/variant/'crates/deadpan-audio/src/stages.rs').read_text()
    start=stage.index('    fn read_bound_at(');end=stage.index('    /// Convert the complete root signal',start)
    function=stage[start:end]
    assert function.index('let mut raw_result_lifetime')<function.index('let raw_domain = {')<function.index('raw_result_lifetime.acquired()')<function.index('match raw_domain.domain()')
    report[variant]={"pins":"passed","exact_patch_roundtrip":"passed","actual_value_before_marker_drop_order":"declaration order checked"}
report['checks']={"rustfmt_scratch_parse_check":"passed","type_build_native":"not performed","git_network":"not performed","actual_root_writes":False,"expected_body_generation":False}
(BASE/'validation.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
