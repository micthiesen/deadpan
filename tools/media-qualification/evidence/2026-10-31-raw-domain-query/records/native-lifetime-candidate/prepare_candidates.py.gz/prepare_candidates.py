from pathlib import Path
import hashlib
import difflib
import json

BASE=Path(__file__).resolve().parent
ROOTS={"main-inherited":Path("/Users/michael/Code/deadpan"),"scoped-published":Path("/tmp/deadpan-query-groundwork-2026-10-26/scoped")}
PREFIX=Path("crates/deadpan-audio/src")
PATHS=[PREFIX/p for p in ["stages.rs","raw_domain_query_trace.rs","bound_reads/retained_host_baseline.rs","shared_eq/retained_host_gap_tests.rs"]]
NEW=[PREFIX/p for p in ["bound_reads/raw_domain_lifetime_tests.rs","shared_eq/raw_domain_gap_tests.rs"]]
def sha(data):return hashlib.sha256(data).hexdigest()
def write(path,text):path.parent.mkdir(parents=True,exist_ok=True);path.write_text(text)
def replace(text,old,new):assert text.count(old)==1,(old,text.count(old));return text.replace(old,new,1)
def stage(text):
    text=replace(text,'        let output = SignalSample(0)..SignalSample(i64::from(frames));\n        #[cfg(test)]\n        let raw_domain = {',
        '        let output = SignalSample(0)..SignalSample(i64::from(frames));\n'
        '        #[cfg(test)]\n        let mut raw_result_lifetime = raw_domain_query_trace::ResultGuard::new();\n'
        '        #[cfg(test)]\n        let raw_domain = {')
    text=replace(text,'        match raw_domain.domain() {\n',
        '        #[cfg(test)]\n'
        '        if matches!(&raw_domain, RawBoundDomain::Admitted(_)) {\n'
        '            raw_result_lifetime.acquired();\n        }\n'
        '        match raw_domain.domain() {\n')
    text=replace(text,'            |at, count| {\n                // `at` indexes a zero-based carrier of already allocated root\n',
        '            |at, count| {\n'
        '                #[cfg(test)]\n'
        '                raw_domain_query_trace::nested_callback(raw_domain_query_trace::Product::Root);\n'
        '                // `at` indexes a zero-based carrier of already allocated root\n')
    return replace(text,'                    |storage, count| {\n                        let reference = domain.reference_at_signal(SignalSample(storage.0))?;\n',
        '                    |storage, count| {\n'
        '                        #[cfg(test)]\n'
        '                        raw_domain_query_trace::nested_callback(raw_domain_query_trace::Product::Point);\n'
        '                        let reference = domain.reference_at_signal(SignalSample(storage.0))?;\n')
def trace(text):
    text=replace(text,'    max_active_depth: usize,\n',
        '    max_active_depth: usize,\n'
        '    live_results: usize,\n    peak_live_results: usize,\n'
        '    result_creations: usize,\n    result_drops: usize,\n'
        '    nested_root_callbacks: usize,\n    nested_point_callbacks: usize,\n')
    text=replace(text,'        assert_eq!(trace.get().active_depth, 0);\n',
        '        assert_eq!(trace.get().active_depth, 0);\n        assert_eq!(trace.get().live_results, 0);\n')
    return text+'\n'+(BASE/'result_guard.rs.txt').read_text()
def baseline(text):return text+'\n#[path = "raw_domain_lifetime_tests.rs"]\nmod raw_domain_lifetime_tests;\n'
def gaps(text):return text+'\n#[path = "raw_domain_gap_tests.rs"]\nmod raw_domain_gap_tests;\n'
editors=[stage,trace,baseline,gaps]
pins={"variants":{}}
for variant,root in ROOTS.items():
    files={}
    for path,edit in zip(PATHS,editors):
        before=(root/path).read_text();current=edit(before)
        write(BASE/'before'/variant/path,before);write(BASE/'current'/variant/path,current)
        files[str(path)]={"before_sha256":sha(before.encode()),"candidate_unformatted_sha256":sha(current.encode())}
    pins["variants"][variant]={"root":str(root),"files":files}
write(BASE/'pins/before.json',json.dumps(pins,indent=2)+'\n')
print('Prepared four exact layered scratch files in each variant; two new private children are separate.')
