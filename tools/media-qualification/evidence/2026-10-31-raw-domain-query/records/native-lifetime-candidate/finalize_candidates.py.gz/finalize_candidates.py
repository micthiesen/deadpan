from pathlib import Path
import hashlib,difflib,json
BASE=Path(__file__).resolve().parent
source=json.loads((BASE/'pins/before.json').read_text())
NEW=[Path('crates/deadpan-audio/src')/p for p in ['bound_reads/raw_domain_lifetime_tests.rs','shared_eq/raw_domain_gap_tests.rs']]
def sha(data):return hashlib.sha256(data).hexdigest()
pins={"variants":{}}
for variant,original in source['variants'].items():
    entries={};patch=''
    for name,oldpin in original['files'].items():
        before=(BASE/'before'/variant/name).read_text();after=(BASE/'current'/variant/name).read_text()
        assert sha(before.encode())==oldpin['before_sha256']
        patch+=''.join(difflib.unified_diff(before.splitlines(keepends=True),after.splitlines(keepends=True),fromfile='a/'+name,tofile='b/'+name))
        entries[name]={"before_sha256":sha(before.encode()),"after_sha256":sha(after.encode())}
    for path in NEW:
        after=(BASE/'new'/path).read_text();name=str(path)
        patch+=''.join(difflib.unified_diff([],after.splitlines(keepends=True),fromfile='/dev/null',tofile='b/'+name))
        entries[name]={"before_sha256":None,"after_sha256":sha(after.encode())}
    root=Path(original['root'])
    guards={}
    for name in [
        'crates/deadpan-audio/src/bound_reads/retained_host_pairs.rs',
        'crates/deadpan-audio/src/bound_reads/raw_domain_host_baseline.rs',
        'crates/deadpan-audio/src/bound_reads/retained_host_cases.rs',
        'crates/deadpan-audio/src/original_request/flattened_work_trace.rs',
        'crates/deadpan-audio/src/retained_request/trace.rs',
        'crates/deadpan-audio/tests/fixtures/raw-domain-host-baseline-v1/snapshot.json',
        'crates/deadpan-plan/tests/fixtures/retained-fade-query-supplement-v1/snapshot.json']:
        guards[name]=sha((root/name).read_bytes())
    (BASE/'patches'/f'{variant}.patch').write_text(patch)
    pins['variants'][variant]={"root":str(root),"files":entries,"patch_sha256":sha(patch.encode()),"untouched_guards":guards}
(BASE/'pins/candidates.json').write_text(json.dumps(pins,indent=2)+'\n')
for variant,pin in pins['variants'].items():
    print(variant,pin['patch_sha256'])
    for name,value in pin['files'].items(): print(value['after_sha256'],name)
