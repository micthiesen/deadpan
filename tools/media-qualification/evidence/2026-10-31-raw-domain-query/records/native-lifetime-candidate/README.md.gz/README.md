# Native raw-domain lifetime candidate

Scratch-only layered candidate over the parent's current admitted raw reader,
native fee adapter and default-off NEW-capture hooks. No actual root, fixture or
parent capture file was edited; no build/type check, native run, Git operation,
network request or expected-body generation was performed.

## Integration

Use `pins/candidates.json` to check the selected root's current before hashes.
Apply `patches/main-inherited.patch` or `patches/scoped-published.patch` only to
the matching root, preserving concurrent source changes. Complete before/current
copies are supplied for four existing files, and complete new files are in
`new/`. The changed files are:

- `stages.rs`, four small cfg(test) additions around the actual raw value and
  actual Root/Point numerical render closures.
- `raw_domain_query_trace.rs`, bounded liveness counters and private guard.
- `bound_reads/retained_host_baseline.rs`, one new private child declaration.
- `shared_eq/retained_host_gap_tests.rs`, one new private child declaration.
- New `bound_reads/raw_domain_lifetime_tests.rs` and
  `shared_eq/raw_domain_gap_tests.rs`.

The gap child remains under the existing authentic cache fixture's private
scope. This avoids copying its Graph factory, widening private interfaces or
inventing cache payloads. `retained_host_pairs.rs` and
`raw_domain_host_baseline.rs` are untouched and hashed as guards. Their current
`CAPTURING` reset/snapshot hooks remain intact. Existing four Original/two
retained trace files and all 23 OLD oracle bodies stay unchanged.

Parent must build/type-check and run native binaries under its serial source
guard. Exact lifetime test prefix:

```text
stages::bound_reads::retained_host_baseline::raw_domain_lifetime_tests::
```

Append each name and use `--exact --test-threads=1`:

```text
actual_root_and_fractional_point_raw_carriers_survive_nested_wav_success_error_and_cancel
raw_local_work_refusal_retains_exact_accepted_prefix_before_provider_in_both_lanes
actual_result_drop_is_tracked_when_source_disables_the_trace_while_it_is_live
raw_bound_foreign_depth_range_and_cancel_priorities_precede_construction_and_io
genuine_frozen_silent_hold_bound_bypasses_raw_constructor_and_provider
```

Exact cache test prefix:

```text
stages::shared_eq::original_inputs::tests::retained_host_gap_tests::raw_domain_gap_tests::
```

Append:

```text
real_retained_original_cache_hit_rechecks_wav_without_any_fresh_raw_constructor
actual_raw_constructor_evicts_real_unpinned_wav_cache_in_each_accounting_lane
```

Then rerun the complete pre-raw 744-body regression, successful native pairs,
tile tests and full Audio libraries in both roots. The new Raw snapshot shape is
not an OLD oracle. Any NEW admitted raw capture made before these added fields
must be independently recaptured under the new source/binary guards before it
is frozen. This candidate does not write such a capture.

## Liveness mechanism

Snapshot adds six scalar fields: live/peak-live results, result creations/drops,
and Root/Point nested render-callback counts. ResultGuard is declared BEFORE the
actual `raw_domain` local. It is acquired only after successful construction of
the actual Admitted enum variant. Rust's reverse local drop order therefore
drops the actual raw value and lease before its marker on every success/error
exit. Ordinary results and constructor failures create no marker.

The marker is default-off unless the trace is enabled at acquisition. Its own
creation boolean governs Drop even if a provider later disables tracing. Reset
requires both no active constructor and no live result. Disabling does not
erase an existing result or prevent its eventual decrement. A real source test
disables tracing while the actual carrier is live, then verifies cleanup and a
subsequent safe reset. No heap tracking, callback/debit, clone, detach or public
prepared-controller API is introduced. All Stage additions are cfg(test), and
the trace module itself is cfg(test), so production has no added execution.

The actual Root transferred-read render closure and Point transfer render
closure each emit a scalar notification, counted only while a tracked raw result
is live. Standalone transfers with no raw result and ordinary legacy reads add
no such liveness counts. These direct observations support the nested-callback
claim; provider-time work frames separately prove positive actual admission.

## Tests and evidence required from execution

The real-WAV tests reuse current `retained_host_cases` factories and actual
ordinary-probe/shared input constructors, with those owning scopes alive through
the read. Root and fractional Point fixtures each run authored false/true,
ordinary/shared origins and success/source-error/provider-cancellation cases.
Each current read is paired with the same actual input construction and narrow
legacyRaw read using current admitted fades/owners. Complete PCM/masks/
dependencies/depth or exact typed source errors must match. The observed
additional raw fee must equal the actual read-work difference in each lane;
fresh host-eviction and partial receipts are explicitly zero, so accepted fees
remain once through later source failures and cancellation.

At every actual provider source callback the current marker must be positive,
the paired legacy marker zero, and actual sound-context frames strictly above
the same legacy caller/fade/owner state. After native return, even while returned
PCM is still held, raw liveness is zero, creations equal drops and metadata
frames equal the still-live caller's baseline. Caller literal work stays fixed.
The appropriate actual nested Root/Point closure counter must be positive.

Raw-local work refusal uses direct real `read_bound_at` with a real shared caller
and no fade/owner precharges inside that call. First a real successful native
read supplies its completed raw fee. Fresh equivalent actual caller scopes then
raise only the selected existing work counter to leave zero or exactly one unit
less than that fee. Both plan and cache lanes require the exact typed work-limit
error, one failed raw constructor, zero completed result/marker/provider calls,
the exact accepted partial prefix (0 or fee-1), no refund, no other-lane debit,
and restored metadata/caller frames. No existing accepted setup work is lowered.

Early checks exercise the actual direct Bound entry: depth before foreign/range,
foreign before zero frames, current zero/overlarge frames, relative negative
offset, cancellation and expired deadline before all other checks. They assert
exact typed errors, zero constructors/provider calls, identical full ReadWork
state and zero controller active PCM/disk. These priorities deliberately follow
the direct Bound algorithm; the enclosing retained entry has its own existing
foreign-before-depth priority.

The silent case uses the already frozen checked
`retained_supplement/captured_marked_repeat_fragment` document and its real voice
Hold. It constructs an actual retained Some, asserts `bound.is_silent_hold()`,
then observes exact zero PCM, full suppression, empty dependencies/depth, no
raw constructor/provider and unchanged WorkControl state even at an extreme
signed reference position. No Hold replacement, private Bound mutation or fake
Empty is used.

The real cache-hit tests copy the existing checked cache workflow, not its data:
actual paid input -> real admitted shared caller -> real cold retained read ->
actual cache publication -> exact-key hit. They run in both external accounting
lanes. The cold read must create a raw result. The hit must return the same Arc
with identical PCM/masks/dependencies/depth, re-admit real WAV provenance, accept
actual lookup/source-check work, publish no new cache id and invoke zero raw
constructors/markers. Graph, caller and renderer cleanup remain explicit.

The eviction test fills 16 actual unpinned WAV-backed Original entries through
the existing real factory, then bounds residency by their actual cached frames
plus the live shared caller. A real native raw read must evict real payloads in
both lanes, return nonempty real PCM/dependencies and restore caller metadata.
Its raw scope must record positive local host eviction work separately from its
successful additional receipt. The same global accepted eviction receipt must
equal actual removed controller entries and include that raw subset; later
numerical work is allowed to evict further actual entries. No whole-read
residual is interpreted as raw work, no eviction receipt is added twice and no
cache state is fabricated.

## Limits

- Rustfmt parsing/checking and exact scratch patch/pin checks are static only.
  Type/borrow checks, runtime outcomes and native timings have NOT been run here.
- The optional pressure/cache-hit paths are source-grounded candidates awaiting
  authentic native execution; if a real path refuses or is unavailable, report
  that typed outcome rather than substitute fabricated cache/receipt state.
- No genuine public Empty product is reached or claimed. No huge inventory,
  arbitrary metadata cap, synthetic handle, fee estimate or golden regeneration.
- The liveness marker observes this actual carrier's scope and paired real
  admission frames. It does not measure allocator/RSS or admit the separate
  ordinary Point::signal clone, recursive Signal/Tape/Mix preparation, Graph
  containers or native decoder/DSP workspaces.
