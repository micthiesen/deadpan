from pathlib import Path
import hashlib,json,subprocess,sys,os
s=Path(__file__).resolve().parent
v=sys.argv[1];assert v in ['main','scoped']
root=Path('/Users/michael/Code/deadpan')if v=='main'else Path('/tmp/deadpan-query-groundwork-2026-10-26/scoped')
build=f'raw-old-plan-{v}-build';label=f'raw-old-plan-{v}'
r=json.loads((s/(build+'.json')).read_text());assert r['exit_code']==0 and r['sources_unchanged']
pins=json.loads((s/(build+'-pins.json')).read_text());pin=next(p for p in pins if p['package']=='plan'and p['name']=='deadpan_plan')
assert pin['artifact']['profile']['opt_level']=='0'and pin['artifact']['profile']['debug_assertions']and pin['artifact']['profile']['overflow_checks']
assert hashlib.sha256(Path(pin['path']).read_bytes()).hexdigest()==pin['sha256']
manifest={}
for absolute,p in r['source_after'].items():
 b=Path(absolute).read_bytes();actual={'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()};assert actual==p,absolute
 manifest[str(Path(absolute).relative_to(root))]=actual
data=(json.dumps(manifest,sort_keys=True,separators=(',',':'))+'\n').encode();sha=hashlib.sha256(data).hexdigest()
m=s/(label+'-source-manifest.json');assert not m.exists();m.write_bytes(data)
names=[l.removesuffix(': test')for l in(s/(label+'-list.stdout')).read_text().splitlines()if l.endswith('raw_domain_baseline::capture_old_raw_domain_query_baseline_v1: test')]
assert len(names)==1,names
out=s/(label+'-body.json');assert not out.exists()
tag='main-inherited'if v=='main'else'scoped-published'
env=os.environ.copy();env.update({'DEADPAN_RAW_DOMAIN_OUTPUT':str(out),'DEADPAN_RAW_DOMAIN_VARIANT':tag,'DEADPAN_RAW_DOMAIN_SOURCE_SHA256':sha,'DEADPAN_RAW_DOMAIN_PUBLISHED_CHECKPOINT':(s/'base-revision.txt').read_text().strip()})
subprocess.run(['python3',str(s/'run_logic_target.py'),build,v,'plan','deadpan_plan',label,'--ignored','--exact',names[0],'--nocapture','--test-threads=1'],env=env,check=True)
run=json.loads((s/(label+'.json')).read_text());assert run['exit_code']==0 and run['sources_unchanged']and run['binaries_unchanged']
for k,val in env.items():
 if k.startswith('DEADPAN_RAW_DOMAIN_'):assert run['environment'][k]==val,k
body=json.loads(out.read_text());assert body['variant']==tag and body['source_sha256']==sha and body['published_retained_fade_checkpoint']==env['DEADPAN_RAW_DOMAIN_PUBLISHED_CHECKPOINT']
assert len(body['retained_some_constructions'])==54
proof={'variant':v,'root':str(root),'source_inputs':len(manifest),'source_manifest_sha256':sha,'binary_sha256':pin['sha256'],'body_bytes':out.stat().st_size,'body_sha256':hashlib.sha256(out.read_bytes()).hexdigest(),'exact_named_test':names[0],'published_checkpoint':env['DEADPAN_RAW_DOMAIN_PUBLISHED_CHECKPOINT'],'ordinary_raw_algorithm_unchanged':True,'full_private_point_serializer':True,'source_and_binary_guards':True}
(s/(label+'-proof.json')).write_text(json.dumps(proof,indent=2)+'\n')
print(json.dumps(proof))
