from pathlib import Path
base=Path('/tmp/deadpan-raw-domain-query-admission-2026-10-31/production-candidate')
trace_text='''//! Bounded test-only receipt trace for the fresh raw-domain constructor.
use super::WorkControl;
use serde::Serialize;
use std::cell::Cell;

#[derive(Clone, Copy, Default, Serialize)]
pub(super) struct Lane {
    constructor_calls: usize,
    ordinary_calls: usize,
    admitted_calls: usize,
    completed_queries: usize,
    failed_queries: usize,
    accepted_work: usize,
    canonical_units: usize,
    additional_units: usize,
    partial_work: usize,
    host_eviction_work: usize,
    kind_counts: [usize; 3],
}

#[derive(Clone, Copy, Default, Serialize)]
pub(super) struct Snapshot {
    plan: Lane,
    cache: Lane,
    active_depth: usize,
    max_active_depth: usize,
    nested: bool,
    invalid: bool,
    overflow: bool,
}

#[derive(Clone, Copy)]
pub(super) enum Product { Root, Point, Empty }
impl Product {
    const fn index(self) -> usize {
        match self { Self::Root => 0, Self::Point => 1, Self::Empty => 2 }
    }
}
#[derive(Clone, Copy)]
enum LaneKind { Plan, Cache }
impl LaneKind {
    const fn index(self) -> usize {
        match self { Self::Plan => 0, Self::Cache => 1 }
    }
}

#[derive(Clone, Copy, Default)]
struct TraceState {
    lanes: [Snapshot; 1],
    enabled: bool,
}
thread_local! {
    static TRACE: Cell<Snapshot> = const { Cell::new(Snapshot {
        plan: Lane { constructor_calls: 0, ordinary_calls: 0, admitted_calls: 0,
            completed_queries: 0, failed_queries: 0, accepted_work: 0,
            canonical_units: 0, additional_units: 0, partial_work: 0,
            host_eviction_work: 0, kind_counts: [0; 3] },
        cache: Lane { constructor_calls: 0, ordinary_calls: 0, admitted_calls: 0,
            completed_queries: 0, failed_queries: 0, accepted_work: 0,
            canonical_units: 0, additional_units: 0, partial_work: 0,
            host_eviction_work: 0, kind_counts: [0; 3] },
        active_depth: 0, max_active_depth: 0, nested: false, invalid: false, overflow: false,
    }) };
    static ENABLED: Cell<bool> = const { Cell::new(false) };
}

fn host_evictions() -> ([usize; 2], bool) {
    super::original_request::flattened_work_trace::host_eviction_units()
}

pub(super) fn reset() {
    TRACE.with(|trace| {
        assert_eq!(trace.get().active_depth, 0);
        trace.set(Snapshot::default());
    });
    ENABLED.with(|enabled| enabled.set(true));
}

pub(super) fn disable() {
    TRACE.with(|trace| assert_eq!(trace.get().active_depth, 0));
    ENABLED.with(|enabled| enabled.set(false));
}

pub(super) fn snapshot() -> Snapshot {
    TRACE.with(Cell::get)
}

fn add(value: &mut usize, amount: usize, overflow: &mut bool) {
    if let Some(next) = value.checked_add(amount) {
        *value = next;
    } else {
        *overflow = true;
    }
}

pub(super) struct ScopeGuard<'work> {
    control: WorkControl<'work>,
    lane: LaneKind,
    before: [usize; 2],
    before_host: [usize; 2],
    tracked: bool,
    completed: Option<(usize, usize, usize, bool, Product)>,
}

impl<'work> ScopeGuard<'work> {
    pub(super) fn new(control: WorkControl<'work>) -> Self {
        let enabled = ENABLED.with(Cell::get);
        let (before, lane) = {
            let work = control.work.borrow();
            (
                [work.plan_work, work.cache_plan_work],
                if work.cache_key_scopes > 0 { LaneKind::Cache } else { LaneKind::Plan },
            )
        };
        let before_host = host_evictions().0;
        let tracked = enabled && TRACE.with(|trace| {
            let mut state = trace.get();
            state.nested |= state.active_depth != 0;
            if let Some(depth) = state.active_depth.checked_add(1) {
                state.active_depth = depth;
                state.max_active_depth = state.max_active_depth.max(depth);
                trace.set(state);
                true
            } else {
                state.overflow = true;
                trace.set(state);
                false
            }
        });
        Self { control, lane, before, before_host, tracked, completed: None }
    }

    pub(super) fn completed(
        &mut self,
        canonical: usize,
        additional: usize,
        total: usize,
        forwarded: bool,
        product: Product,
    ) {
        if self.tracked {
            self.completed = Some((canonical, additional, total, forwarded, product));
        }
    }
}

impl Drop for ScopeGuard<'_> {
    fn drop(&mut self) {
        if !self.tracked { return; }
        let after = {
            let work = self.control.work.borrow();
            [work.plan_work, work.cache_plan_work]
        };
        let (host_after, host_overflow) = host_evictions();
        TRACE.with(|trace| {
            let mut state = trace.get();
            state.overflow |= host_overflow;
            let deltas = [
                after[0].checked_sub(self.before[0]),
                after[1].checked_sub(self.before[1]),
            ];
            let host_deltas = [
                host_after[0].checked_sub(self.before_host[0]),
                host_after[1].checked_sub(self.before_host[1]),
            ];
            if deltas.iter().any(Option::is_none) || host_deltas.iter().any(Option::is_none) {
                state.invalid = true;
            }
            let deltas = deltas.map(|value| value.unwrap_or(0));
            let host_deltas = host_deltas.map(|value| value.unwrap_or(0));
            let mut forwarded = [0; 2];
            for lane in 0..2 {
                match deltas[lane].checked_sub(host_deltas[lane]) {
                    Some(value) => forwarded[lane] = value,
                    None => state.invalid = true,
                }
            }
            let selected = self.lane.index();
            let other = 1 - selected;
            state.invalid |= deltas[other] != 0 || host_deltas[other] != 0;

            for lane_index in 0..2 {
                let lane = if lane_index == 0 { &mut state.plan } else { &mut state.cache };
                add(&mut lane.accepted_work, deltas[lane_index], &mut state.overflow);
                add(&mut lane.host_eviction_work, host_deltas[lane_index], &mut state.overflow);
            }
            let lane = if selected == 0 { &mut state.plan } else { &mut state.cache };
            add(&mut lane.constructor_calls, 1, &mut state.overflow);
            if let Some((canonical, additional, total, was_forwarded, product)) = self.completed {
                let expected = if was_forwarded { total } else { 0 };
                state.invalid |= canonical.checked_add(additional) != Some(total)
                    || forwarded[selected] != expected
                    || (was_forwarded && canonical != 0);
                add(&mut lane.completed_queries, 1, &mut state.overflow);
                add(&mut lane.canonical_units, canonical, &mut state.overflow);
                add(&mut lane.additional_units, additional, &mut state.overflow);
                add(&mut lane.kind_counts[product.index()], 1, &mut state.overflow);
                if was_forwarded {
                    add(&mut lane.admitted_calls, 1, &mut state.overflow);
                } else {
                    add(&mut lane.ordinary_calls, 1, &mut state.overflow);
                }
            } else {
                add(&mut lane.failed_queries, 1, &mut state.overflow);
                add(&mut lane.partial_work, forwarded[selected], &mut state.overflow);
            }
            if let Some(depth) = state.active_depth.checked_sub(1) {
                state.active_depth = depth;
            } else {
                state.invalid = true;
            }
            trace.set(state);
        });
    }
}
'''
for v in ['main','scoped']:
 root=base/v
 (root/'crates/deadpan-audio/src/raw_domain_query_trace.rs').write_text(trace_text)
 # Stage: expose product index and scope only raw construction, not transfer/output callbacks.
 p=root/'crates/deadpan-audio/src/stages.rs'
 s=p.read_text()
 old='''    #[cfg(test)]
    fn trace_event(&self) -> raw_domain_query_trace::Event {
        use raw_domain_query_trace::{Construction, Product};
        let product = match self.domain() {
            AudioBoundDomain::Root(_) => Product::Root,
            AudioBoundDomain::Point(_) => Product::Point,
            AudioBoundDomain::Empty => Product::Empty,
        };
        match self {
            Self::Ordinary(_) => raw_domain_query_trace::Event {
                construction: Construction::Ordinary,
                product,
                canonical: 0,
                additional: 0,
                forwarded: false,
            },
            Self::Admitted(value) => raw_domain_query_trace::Event {
                construction: Construction::Admitted,
                product,
                canonical: value.canonical_units(),
                additional: value.additional_units(),
                forwarded: value.was_forwarded(),
            },
        }
    }
'''
 new='''    #[cfg(test)]
    fn trace_product(&self) -> raw_domain_query_trace::Product {
        match self.domain() {
            AudioBoundDomain::Root(_) => raw_domain_query_trace::Product::Root,
            AudioBoundDomain::Point(_) => raw_domain_query_trace::Product::Point,
            AudioBoundDomain::Empty => raw_domain_query_trace::Product::Empty,
        }
    }
'''
 assert old in s
 s=s.replace(old,new)
 old='''        #[cfg(test)]
        let raw_domain = if raw_domain_request::legacy() {
            RawBoundDomain::Ordinary(bound.raw_domain()?)
        } else {
            let mut admission = sound_context_admission::Admission::new(self, control);
            RawBoundDomain::Admitted(bound.raw_domain_query(&mut admission)?)
        };
        #[cfg(not(test))]
        let raw_domain = {
            let mut admission = sound_context_admission::Admission::new(self, control);
            RawBoundDomain::Admitted(bound.raw_domain_query(&mut admission)?)
        };
        #[cfg(test)]
        raw_domain_query_trace::observe(raw_domain.trace_event());
'''
 new='''        #[cfg(test)]
        let raw_domain = {
            let mut trace = raw_domain_query_trace::ScopeGuard::new(control);
            let raw_domain = if raw_domain_request::legacy() {
                RawBoundDomain::Ordinary(bound.raw_domain()?)
            } else {
                let mut admission = sound_context_admission::Admission::new(self, control);
                RawBoundDomain::Admitted(bound.raw_domain_query(&mut admission)?)
            };
            let product = raw_domain.trace_product();
            let receipt = match &raw_domain {
                RawBoundDomain::Ordinary(_) => (0, 0, 0, false),
                RawBoundDomain::Admitted(value) => (
                    value.canonical_units(),
                    value.additional_units(),
                    value.total_units(),
                    value.was_forwarded(),
                ),
            };
            trace.completed(receipt.0, receipt.1, receipt.2, receipt.3, product);
            raw_domain
        };
        #[cfg(not(test))]
        let raw_domain = {
            let mut admission = sound_context_admission::Admission::new(self, control);
            RawBoundDomain::Admitted(bound.raw_domain_query(&mut admission)?)
        };
'''
 assert old in s
 s=s.replace(old,new)
 p.write_text(s)
 # Add named raw-only legacy wrapper and chain existing whole-retained wrapper to it.
 p=root/'crates/deadpan-audio/src/raw_domain_request.rs'
 s=p.read_text()
 s=s.replace('pub(super) fn with_legacy<T>(action: impl FnOnce() -> T) -> T {',
             'pub(super) fn with_legacy_raw_domain<T>(action: impl FnOnce() -> T) -> T {')
 s += '''
#[cfg(test)]
pub(super) fn with_legacy<T>(action: impl FnOnce() -> T) -> T {
    with_legacy_raw_domain(action)
}
'''
 p.write_text(s)
 p=root/'crates/deadpan-audio/src/retained_request.rs'
 s=p.read_text().replace('super::raw_domain_request::with_legacy(action)',
                          'super::raw_domain_request::with_legacy_raw_domain(action)')
 p.write_text(s)
 p=root/'crates/deadpan-audio/src/original_request.rs'
 s=p.read_text().replace('super::raw_domain_request::with_legacy(|| {',
                          'super::raw_domain_request::with_legacy_raw_domain(|| {')
 p.write_text(s)
