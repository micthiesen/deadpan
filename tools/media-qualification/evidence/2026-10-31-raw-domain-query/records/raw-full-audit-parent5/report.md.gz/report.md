# Raw-domain native full-body audit

Read-only audit of the 744 final native5 NEW operations per target against each frozen pre-raw body’s `paired.new`. No executables were run and no expected body was generated.

## Equality and classifications

- Main/scoped NEW bodies equal after removing only capture `variant` and `source_sha256`: **True**.
- Main/scoped frozen raw-OLD bodies equal after the same envelope removal: **True**.
- Per body output classifications: `{"different_work_budget_error": 12, "same_complete_success": 264, "same_complete_typed_error": 468}` (main); `{"different_work_budget_error": 12, "same_complete_success": 264, "same_complete_typed_error": 468}` (scoped).
- Output differences are limited to work-budget errors; all other full payloads and error objects match.

## Direct raw fees, surrounding deltas, and receipts

### main

- Input SHA-256: final capture daa9c3acf45c0a3fa2e6ec71c1c2b6fe31519e2bae876d9036585834b741f61f; frozen raw-OLD baseline d6ddc11ce40376bfb8ac17e5e25c2ca2a3d80756d5b78165e17cc12a25d0ee74.
- Direct raw fees by lane: `{"cache": {"accepted_work": 632, "additional_units": 632, "host_eviction_work": 0, "partial_work": 0}, "plan": {"accepted_work": 5784, "additional_units": 5784, "host_eviction_work": 0, "partial_work": 0}}`.
- Current full-read delta minus frozen raw-OLD full-read delta by lane: `{"cache": 632, "plan": 4860}`.
- Per-lane delta formula checks: `{"ordinary|reconciled": 1328, "tight|not_reconciled": 56, "tight|reconciled": 104}`. Ordinary rows must equal raw additional + raw partial + fade/owner accepted receipt delta + global host eviction delta counted once. Tight injected-work rows are preserved separately; nested outside receipts are listed but not summed.
- Outside receipt differences: `{"changed_leaf_path_counts": {"original_queries/flattened/plan/accepted_work": 24, "original_queries/flattened/plan/additional_units": 8, "original_queries/flattened/plan/canonical_units": 8, "original_queries/flattened/plan/completed_queries": 8, "original_queries/flattened/plan/failed_queries": 8, "original_queries/flattened/plan/partial_work": 24, "original_queries/processing/max_active_depth": 8, "original_queries/processing/plan/accepted_work": 16, "original_queries/processing/plan/constructor_calls": 8, "original_queries/processing/plan/failed_queries": 8, "original_queries/processing/plan/partial_work": 16}, "names_checked": ["fade", "owners", "original_queries"], "rows_with_changes_by_receipt_and_mode": {"original_queries": 32}}`.
- Tight injected-work records: 80; details are in `audit.json` without additive attribution.
- Audit issue rows: 0.

### scoped

- Input SHA-256: final capture 942e94cfb9073357f036fe4ba2a53774491be00d120b489ff3ec41a12f5145fb; frozen raw-OLD baseline 6ab8d5da9910878de1fa003a1e5e8e37d62dd9c654ed65803293c984eb0e5209.
- Direct raw fees by lane: `{"cache": {"accepted_work": 632, "additional_units": 632, "host_eviction_work": 0, "partial_work": 0}, "plan": {"accepted_work": 5784, "additional_units": 5784, "host_eviction_work": 0, "partial_work": 0}}`.
- Current full-read delta minus frozen raw-OLD full-read delta by lane: `{"cache": 632, "plan": 4860}`.
- Per-lane delta formula checks: `{"ordinary|reconciled": 1328, "tight|not_reconciled": 56, "tight|reconciled": 104}`. Ordinary rows must equal raw additional + raw partial + fade/owner accepted receipt delta + global host eviction delta counted once. Tight injected-work rows are preserved separately; nested outside receipts are listed but not summed.
- Outside receipt differences: `{"changed_leaf_path_counts": {"original_queries/flattened/plan/accepted_work": 24, "original_queries/flattened/plan/additional_units": 8, "original_queries/flattened/plan/canonical_units": 8, "original_queries/flattened/plan/completed_queries": 8, "original_queries/flattened/plan/failed_queries": 8, "original_queries/flattened/plan/partial_work": 24, "original_queries/processing/max_active_depth": 8, "original_queries/processing/plan/accepted_work": 16, "original_queries/processing/plan/constructor_calls": 8, "original_queries/processing/plan/failed_queries": 8, "original_queries/processing/plan/partial_work": 16}, "names_checked": ["fade", "owners", "original_queries"], "rows_with_changes_by_receipt_and_mode": {"original_queries": 32}}`.
- Tight injected-work records: 80; details are in `audit.json` without additive attribution.
- Audit issue rows: 0.

## Tight injected-work rows with outside-receipt changes

These rows are deliberately not attributed to raw-domain fees alone. Each mode has 20 rows per scope; its raw plan receipt sums to 238 accepted units while the full-read delta against raw OLD sums to 7 (difference −231). Across the four modes, this is 952 direct raw plan units versus 28 measured plan delta (difference −924). Nested original_queries receipts changed on eight rows per mode; they are preserved by exact row/path/value in audit.json and are not added again to avoid double-counting nested work.

| Scope | Mode | Rows | Plan raw fee | Plan read delta | Difference | Rows with outside changes |
|---|---|---:|---:|---:|---:|---:|
| main | actual_admitted_probe_metered | 20 | 238 | 7 | -231 | 8 |
| main | actual_admitted_probe_unmetered | 20 | 238 | 7 | -231 | 8 |
| main | actual_selected_then_shared | 20 | 238 | 7 | -231 | 8 |
| main | ordinary_probe | 20 | 238 | 7 | -231 | 8 |
| scoped | actual_admitted_probe_metered | 20 | 238 | 7 | -231 | 8 |
| scoped | actual_admitted_probe_unmetered | 20 | 238 | 7 | -231 | 8 |
| scoped | actual_selected_then_shared | 20 | 238 | 7 | -231 | 8 |
| scoped | ordinary_probe | 20 | 238 | 7 | -231 | 8 |

Outside changes in these tight rows are all under original_queries; fade and owner receipts are unchanged. Signed numeric path deltas across the 80 tight rows per scope are:

| Outside receipt field | Rows | Signed new minus raw OLD sum |
|---|---:|---:|
| original_queries.flattened.plan.accepted_work | 24 | -332 |
| original_queries.flattened.plan.additional_units | 8 | -456 |
| original_queries.flattened.plan.canonical_units | 8 | -104 |
| original_queries.flattened.plan.completed_queries | 8 | -8 |
| original_queries.flattened.plan.failed_queries | 8 | 8 |
| original_queries.flattened.plan.partial_work | 24 | 228 |
| original_queries.processing.max_active_depth | 8 | -8 |
| original_queries.processing.plan.accepted_work | 16 | -212 |
| original_queries.processing.plan.constructor_calls | 8 | -8 |
| original_queries.processing.plan.failed_queries | 8 | -8 |
| original_queries.processing.plan.partial_work | 16 | -212 |

These signed sums describe nested receipt changes, not independently chargeable totals. audit.json retains every row's old/new leaf value. No outside receipt changed in the other 664 non-tight rows.

## Findings

No unexpected state, payload, provider-order, cleanup, raw-counter, or body-shape discrepancies were found.

## Exact work-budget error differences

| Scope | Fixture / operation | Mode | Old typed error | New typed error | Raw fee in plan/cache |
|---|---|---|---|---|---|
| main | `root-ntsc-enclosing-and-silence` / 15 | ordinary_probe | `Limit("plan work per read")` | `Plan(AudioQueryLimit("recursive policy work"))` | plan 17, cache 0 |
| main | `root-ntsc-enclosing-and-silence` / 16 | ordinary_probe | `Plan(AudioQueryLimit("structural work"))` | `Plan(AudioQueryLimit("recursive policy work"))` | plan 17, cache 0 |
| main | `root-ntsc-enclosing-and-silence` / 33 | ordinary_probe | `Plan(AudioQueryLimit("structural work"))` | `Limit("plan work per read")` | plan 17, cache 0 |
| main | `root-ntsc-enclosing-and-silence` / 49 | actual_admitted_probe_unmetered | `Limit("plan work per read")` | `Plan(AudioQueryLimit("recursive policy work"))` | plan 17, cache 0 |
| main | `root-ntsc-enclosing-and-silence` / 50 | actual_admitted_probe_unmetered | `Plan(AudioQueryLimit("structural work"))` | `Plan(AudioQueryLimit("recursive policy work"))` | plan 17, cache 0 |
| main | `root-ntsc-enclosing-and-silence` / 67 | actual_admitted_probe_unmetered | `Plan(AudioQueryLimit("structural work"))` | `Limit("plan work per read")` | plan 17, cache 0 |
| main | `root-ntsc-enclosing-and-silence` / 83 | actual_admitted_probe_metered | `Limit("plan work per read")` | `Plan(AudioQueryLimit("recursive policy work"))` | plan 17, cache 0 |
| main | `root-ntsc-enclosing-and-silence` / 84 | actual_admitted_probe_metered | `Plan(AudioQueryLimit("structural work"))` | `Plan(AudioQueryLimit("recursive policy work"))` | plan 17, cache 0 |
| main | `root-ntsc-enclosing-and-silence` / 101 | actual_admitted_probe_metered | `Plan(AudioQueryLimit("structural work"))` | `Limit("plan work per read")` | plan 17, cache 0 |
| main | `root-ntsc-enclosing-and-silence` / 117 | actual_selected_then_shared | `Limit("plan work per read")` | `Plan(AudioQueryLimit("recursive policy work"))` | plan 17, cache 0 |
| main | `root-ntsc-enclosing-and-silence` / 118 | actual_selected_then_shared | `Plan(AudioQueryLimit("structural work"))` | `Plan(AudioQueryLimit("recursive policy work"))` | plan 17, cache 0 |
| main | `root-ntsc-enclosing-and-silence` / 135 | actual_selected_then_shared | `Plan(AudioQueryLimit("structural work"))` | `Limit("plan work per read")` | plan 17, cache 0 |
| scoped | `root-ntsc-enclosing-and-silence` / 15 | ordinary_probe | `Limit("plan work per read")` | `Plan(AudioQueryLimit("recursive policy work"))` | plan 17, cache 0 |
| scoped | `root-ntsc-enclosing-and-silence` / 16 | ordinary_probe | `Plan(AudioQueryLimit("structural work"))` | `Plan(AudioQueryLimit("recursive policy work"))` | plan 17, cache 0 |
| scoped | `root-ntsc-enclosing-and-silence` / 33 | ordinary_probe | `Plan(AudioQueryLimit("structural work"))` | `Limit("plan work per read")` | plan 17, cache 0 |
| scoped | `root-ntsc-enclosing-and-silence` / 49 | actual_admitted_probe_unmetered | `Limit("plan work per read")` | `Plan(AudioQueryLimit("recursive policy work"))` | plan 17, cache 0 |
| scoped | `root-ntsc-enclosing-and-silence` / 50 | actual_admitted_probe_unmetered | `Plan(AudioQueryLimit("structural work"))` | `Plan(AudioQueryLimit("recursive policy work"))` | plan 17, cache 0 |
| scoped | `root-ntsc-enclosing-and-silence` / 67 | actual_admitted_probe_unmetered | `Plan(AudioQueryLimit("structural work"))` | `Limit("plan work per read")` | plan 17, cache 0 |
| scoped | `root-ntsc-enclosing-and-silence` / 83 | actual_admitted_probe_metered | `Limit("plan work per read")` | `Plan(AudioQueryLimit("recursive policy work"))` | plan 17, cache 0 |
| scoped | `root-ntsc-enclosing-and-silence` / 84 | actual_admitted_probe_metered | `Plan(AudioQueryLimit("structural work"))` | `Plan(AudioQueryLimit("recursive policy work"))` | plan 17, cache 0 |
| scoped | `root-ntsc-enclosing-and-silence` / 101 | actual_admitted_probe_metered | `Plan(AudioQueryLimit("structural work"))` | `Limit("plan work per read")` | plan 17, cache 0 |
| scoped | `root-ntsc-enclosing-and-silence` / 117 | actual_selected_then_shared | `Limit("plan work per read")` | `Plan(AudioQueryLimit("recursive policy work"))` | plan 17, cache 0 |
| scoped | `root-ntsc-enclosing-and-silence` / 118 | actual_selected_then_shared | `Plan(AudioQueryLimit("structural work"))` | `Plan(AudioQueryLimit("recursive policy work"))` | plan 17, cache 0 |
| scoped | `root-ntsc-enclosing-and-silence` / 135 | actual_selected_then_shared | `Plan(AudioQueryLimit("structural work"))` | `Limit("plan work per read")` | plan 17, cache 0 |

These are the only output differences. All are non-cancellation errors in the work-budget family. The full typed objects, frozen requests, state differences, and per-row outside-receipt paths remain in `audit.json`.
