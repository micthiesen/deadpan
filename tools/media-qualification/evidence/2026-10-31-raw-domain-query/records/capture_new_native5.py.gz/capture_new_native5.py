from pathlib import Path
import json,hashlib,os,subprocess,sys
s=Path(__file__).resolve().parent
v=sys.argv[1];assert v in ['main','scoped']
build=f'raw-native5-{v}-build';label=f'raw-new-host5-{v}'
root=Path('/Users/michael/Code/deadpan')if v=='main'else Path('/tmp/deadpan-query-groundwork-2026-10-26/scoped')
receipt=json.loads((s/(build+'.json')).read_text());assert receipt['exit_code']==0 and receipt['sources_unchanged']
pin=next(p for p in json.loads((s/(build+'-pins.json')).read_text())if p['package']=='audio'and p['name']=='deadpan_audio')
profile=pin['artifact']['profile'];assert profile['opt_level']=='2'and profile['debug_assertions']and profile['overflow_checks']
assert hashlib.sha256(Path(pin['path']).read_bytes()).hexdigest()==pin['sha256']
manifest={}
for absolute,old in receipt['source_after'].items():
 b=Path(absolute).read_bytes();actual={'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()};assert actual==old,absolute
 manifest[str(Path(absolute).relative_to(root))]=actual
encoded=(json.dumps(manifest,sort_keys=True,separators=(',',':'))+'\n').encode();sha=hashlib.sha256(encoded).hexdigest()
p=s/(label+'-source-manifest.json');assert not p.exists();p.write_bytes(encoded)
names=[l.removesuffix(': test')for l in(s/f'raw-native5-{v}-list.stdout').read_text().splitlines()if l.endswith('raw_domain_host_baseline::capture_new_raw_domain_native_v1: test')]
assert len(names)==1,names
out=s/(label+'-body.json');assert not out.exists()
tag='main-inherited'if v=='main'else'scoped-published'
env=os.environ.copy();env.update({'DEADPAN_RAW_HOST_OUTPUT':str(out),'DEADPAN_RAW_HOST_VARIANT':tag,'DEADPAN_RAW_HOST_SOURCE_SHA256':sha,'DEADPAN_RAW_HOST_PUBLISHED_CHECKPOINT':(s/'base-revision.txt').read_text().strip()})
subprocess.run(['python3',str(s/'run_target.py'),build,v,'audio','deadpan_audio',label,'--ignored','--exact',names[0],'--nocapture','--test-threads=1'],env=env,check=True)
run=json.loads((s/(label+'.json')).read_text());assert run['exit_code']==0 and run['sources_unchanged']and run['binaries_unchanged']
for k,val in env.items():
 if k.startswith('DEADPAN_RAW_HOST_'):assert run['environment'][k]==val,k
body=json.loads(out.read_text());assert body['variant']==tag and body['source_sha256']==sha and body['operations']==744
assert body['schema']=='raw-domain-native-admitted-v1'and body['pre_raw_frozen_sha256']=='2f57d0404dad1cb2d33054958d0578f67dd9e2ecc154a1d17fd2824d65700745'
assert all('raw_domain'in row['paired']['receipts']for case in body['cases']for row in case['operations'])
proof={'variant':v,'root':str(root),'binary_sha256':pin['sha256'],'source_inputs':len(manifest),'source_manifest_sha256':sha,'body_bytes':out.stat().st_size,'body_sha256':hashlib.sha256(out.read_bytes()).hexdigest(),'source_and_binary_guards':True,'all744_scoped_raw_receipts':True,'preceding_published_checkpoint':body['published_retained_fade_checkpoint'],'exact_named_test':names[0]}
(s/(label+'-proof.json')).write_text(json.dumps(proof,indent=2)+'\n');print(json.dumps(proof))
