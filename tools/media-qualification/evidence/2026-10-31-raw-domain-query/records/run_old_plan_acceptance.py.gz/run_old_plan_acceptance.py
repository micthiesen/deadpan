from pathlib import Path
import subprocess,os,sys
s=Path(__file__).resolve().parent;v=sys.argv[1]
build=f'raw-old-plan-{v}-build'
listed=(s/f'raw-old-plan-{v}-list.stdout').read_text().splitlines()
names=[l.removesuffix(': test')for l in listed if l.endswith('raw_domain_baseline::raw_domain_matches_explicit_external_old_v1: test')]
assert len(names)==1
env=os.environ.copy();env['DEADPAN_RAW_DOMAIN_EXPECTED']=str(s/'raw-old-plan-canonical-body.json')
subprocess.run(['python3',str(s/'run_logic_target.py'),build,v,'plan','deadpan_plan',f'raw-old-plan-{v}-external','--ignored','--exact',names[0],'--test-threads=1'],env=env,check=True)
subprocess.run(['python3',str(s/'run_logic_target.py'),build,v,'plan','deadpan_plan',f'raw-old-plan-{v}-library','--test-threads=1'],check=True)
