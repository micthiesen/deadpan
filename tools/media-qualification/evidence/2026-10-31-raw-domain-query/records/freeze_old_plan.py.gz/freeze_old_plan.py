from pathlib import Path
import json,hashlib,collections
s=Path(__file__).resolve().parent
bodies=[]
for v in ['main','scoped']:
 d=json.loads((s/f'raw-old-plan-{v}-body.json').read_text())
 for k in ['variant','source_sha256','published_retained_fade_checkpoint']:del d[k]
 bodies.append(d)
assert bodies[0]==bodies[1]
body=bodies[0];data=(json.dumps(body,sort_keys=True,separators=(',',':'))+'\n').encode()
digest=hashlib.sha256(data).hexdigest()
found=[]
def visit(v):
 if isinstance(v,dict):
  if {'existing_internal_metered_helper','ordinary','bound_before'}<=v.keys():found.append(v);return
  for x in v.values():visit(x)
 elif isinstance(v,list):
  for x in v:visit(x)
visit(body)
assert len(found)==77 and len(body['retained_some_constructions'])==54
kinds=collections.Counter();units=[]
for c in found:
 o=c['ordinary'];h=c['existing_internal_metered_helper']
 assert o['result']['result']=='Ok'
 assert h['canonical']==0 and h['accepted_work']==h['additional']
 assert c['bound_before']==c['bound_after']
 assert o['caller_before']==o['caller_while_result_live']==o['caller_after_result_drop']==h['caller_while_result_live']==h['caller_after_result_drop']
 assert h['ledger_before']['live']==h['ledger_after_result_drop']['live']==0
 assert h['ledger_while_result_live']['live']>0
 kinds[o['result']['raw_domain']['tag']]+=1;units.append(h['additional'])
assert kinds=={'RootRoundEven':59,'PointCeil':18}
relative=Path('crates/deadpan-plan/tests/fixtures/raw-domain-query-baseline-v1')
readme='''# Fresh raw-domain query baseline v1

Captured before changing raw-domain production behavior or public/host ownership,
after publishing 87ab6192e765a34dae9595139e10bd9010d6315e. Both source variants
ran independent pinned unoptimized Plan test binaries with complete source and
binary guards. Their complete bodies agree after removing only variant,
source_sha256 and published_retained_fade_checkpoint.

There are 77 fresh actual ordinary reconstructions: 54 real retained Some
owning scopes across four actual constructor origins, eight Root-processing,
seven Domain-processing and eight Root-Signal Bound operands. All 77 succeed:
59 RootRoundEven and 18 PointCeil. Full setup bodies retain None, rejection,
documents, selections and commands. The 33 direct visitor cases report observed
counts; the storage-only case without a document stays NotMeasured.

Every ordinary result retains all actual Root fields or the complete borrowed
private Point/Structural Signal snapshot. No Point::signal clone is substituted
for serialization. Complete before/after Bound/input/cached result and literal
retained/resolved/lattice work are separate. Actual caller ledgers remain live.

A separate already-existing internal metered-helper lane records its complete
result and actual spend/Layout/merge events through the existing policy. All
canonical work is zero; accepted additional work ranges from 11 to 30 units.
This lane is not an admission receipt for the ordinary constructor. Local
allowance and actual input/caller/result ledger states remain independent.
No source/algorithm change, expectation generation after implementation, fake
nominal clock, private Empty mutation, phase-peak/RSS claim or whole recursive
preparation claim is made. No genuine Empty result was reached.

External full-body regression uses this immutable independent capture. Existing
oracle bodies and weights are not regenerated.
'''
for root in [Path('/Users/michael/Code/deadpan'),Path('/tmp/deadpan-query-groundwork-2026-10-26/scoped')]:
 dest=root/relative;assert not dest.exists();dest.mkdir()
 (dest/'snapshot.json').write_bytes(data);(dest/'snapshot.sha256').write_text(digest+'\n');(dest/'README.md').write_text(readme)
(s/'raw-old-plan-canonical-body.json').write_bytes(data)
proof={'complete_main_scoped_equality':True,'removed_only':['variant','source_sha256','published_retained_fade_checkpoint'],'canonical_bytes':len(data),'canonical_sha256':digest,'actual_constructions':77,'actual_retained_some':54,'ordinary_results':{'Ok':77,'Error':0},'kinds':dict(kinds),'direct_actual_counts':body['direct_processing']['actual_bound_counts'],'helper_canonical':0,'helper_additional_range':[min(units),max(units)],'caller_and_bound_unchanged':True,'no_genuine_empty_reached':True,'fixture':str(relative),'before_raw_production_changes':True}
(s/'raw-old-plan-equality.json').write_text(json.dumps(proof,indent=2)+'\n')
pins=json.loads((s/'immutable-oracle-pins.json').read_text());assert len(pins)==22
pins.append({'path':str(relative/'snapshot.json'),'bytes':len(data),'sha256':digest,'scope':'Fresh actual ordinary raw-domain and existing internal helper before public/native admission'})
(s/'immutable-oracle-pins.json').write_text(json.dumps(pins,indent=2)+'\n')
for root in [Path('/Users/michael/Code/deadpan'),Path('/tmp/deadpan-query-groundwork-2026-10-26/scoped')]:
 for pin in pins:assert hashlib.sha256((root/pin['path']).read_bytes()).hexdigest()==pin['sha256']
paths=[str(relative/x)for x in ['README.md','snapshot.json','snapshot.sha256']]
(s/'owned-plan-baseline-paths.json').write_text(json.dumps(paths,indent=2)+'\n')
for name in ['source-files.json','main-logic-source-files.json','scoped-source-files.json','scoped-logic-source-files.json']:
 p=s/name;values=json.loads(p.read_text());assert not set(values)&set(paths);p.write_text(json.dumps(sorted(values+paths),indent=2)+'\n')
print(proof)
