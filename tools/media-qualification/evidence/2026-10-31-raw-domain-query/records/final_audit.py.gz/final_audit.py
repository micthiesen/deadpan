from pathlib import Path
from datetime import datetime
import hashlib,json,re
s=Path(__file__).resolve().parent
sha=lambda b:hashlib.sha256(b).hexdigest()
negative={
'raw-integrated-audio-main-build':101,'raw-integrated-audio-scoped-build':101,
'raw-integrated-audio-scoped-library':101,'raw-integrated-plan-main-build':101,
'raw-integrated-plan-scoped-build':101,'raw-native3-main-build':101,
'raw-native3-scoped-build':101,'raw-phase-plan-main-build':101,
'raw-phase-plan-scoped-build':101,'raw-phase2-plan-main-build':101,
'raw-phase2-plan-scoped-build':101,'raw-strict-main-initial':1,
'raw-strict-scoped-initial':101}
receipts=[];native=[]
for p in sorted(s.glob('*.json')):
 r=json.loads(p.read_text())
 if not isinstance(r,dict)or'command'not in r or'started_at'not in r:continue
 assert'exit_code'in r,p.stem
 if p.stem=='raw-final-fresh-split':assert r['exit_code']in [0,101]
 else:assert r['exit_code']==negative.get(p.stem,0),(p.stem,r['exit_code'])
 assert r['sources_unchanged']and r['binaries_unchanged'],p.stem
 for path,h in r['streams'].items():
  b=Path(path).read_bytes();assert len(b)==h['bytes']and sha(b)==h['sha256'],path
 receipts.append({'label':p.stem,'exit_code':r['exit_code'],'seconds':r['seconds'],'sha256':sha(p.read_bytes()),'acceptance_credit':r['exit_code']==0 and p.stem not in ['raw-phase-plan-main-build','raw-phase-plan-scoped-build']})
 if r['binary_before']and r['environment'].get('CARGO_PROFILE_DEV_OPT_LEVEL')=='2':
  native.append((datetime.fromisoformat(r['started_at']),datetime.fromisoformat(r['finished_at']),p.stem))
for a,b in zip(sorted(native),sorted(native)[1:]):assert a[1]<=b[0],('native overlap',a[2],b[2])
tests={};coverage={}
def read_result(p,digest):
 r=json.loads(p.read_text())
 assert r['exit_code']==0 and r['sources_unchanged']and r['binaries_unchanged'],str(p)
 assert any(h['sha256']==digest for h in r['binary_before'].values()),str(p)
 matches=re.findall(r'test result: ok\. (\d+) passed; 0 failed; (\d+) ignored;',p.with_suffix('.stdout').read_text())
 assert len(matches)==1,str(p)
 passed,ignored=map(int,matches[0]);tests[str(p)]={'passed':passed,'ignored':ignored,'seconds':r['seconds']}
 return passed,ignored
for v,lib in [('main',277),('scoped',264)]:
 rows=json.loads((s/f'final-plan-{v}-coverage.json').read_text());assert len(rows)==29
 pins=json.loads((s/f'raw-lintfinal-plan-{v}-build-pins.json').read_text())
 passed=ignored=0
 for row in rows:
  pin=next(p for p in pins if p['name']==row['target'])
  assert sha(Path(pin['path']).read_bytes())==pin['sha256']==row['sha256']
  p,i=read_result(Path(row['receipt']),pin['sha256']);passed+=p;ignored+=i
  if row['target']=='deadpan_plan':assert(p,i)==(lib,24)
  else:assert i==0
 assert(passed,ignored)==(lib+450,24)
 coverage[v]={'plan':{'executables':29,'passed':passed,'ignored':ignored,'identical_reuses':sum(r['reused']for r in rows)}}
audio=json.loads((s/'final-audio-coverage.json').read_text());assert len(audio)==42
for v,lib in [('main',437),('scoped',431)]:
 rows=[r for r in audio if r['variant']==v];assert len(rows)==21
 pins=json.loads((s/f'raw-lintfinal-audio-{v}-build-pins.json').read_text())
 passed=ignored=small=0
 for row in rows:
  pin=next(p for p in pins if p['name']==row['target'])
  profile=pin['artifact']['profile']
  assert profile['opt_level']=='2'and profile['debug_assertions']and profile['overflow_checks']
  assert sha(Path(pin['path']).read_bytes())==pin['sha256']==row['sha256']
  p,i=read_result(Path(row['receipt']),pin['sha256']);passed+=p;ignored+=i
  if row['target']=='deadpan_audio':assert(p,i)==(lib,10)
  elif row['target']=='stages':assert(p,i)==(203,0)
  elif row['target']=='audio_definition':assert(p,i)==(171,0)
  else:assert i==0;small+=p
 assert small==207 and(passed,ignored)==(lib+581,10)
 coverage[v]['audio']={'executables':21,'passed':passed,'ignored':ignored,'identical_reuses':sum(r['reused']for r in rows)}
for label in ['raw-strict-main-final','raw-strict-scoped-final','raw-final-scoped-format','raw-final-main-doctests','raw-final-scoped-doctests','raw-final-hygiene']:
 r=json.loads((s/(label+'.json')).read_text());assert r['exit_code']==0,label
body=json.loads((s/'raw-full-audit-parent6/audit.json').read_text())
assert not body['global_errors']and all(not p['failures']for p in body['scopes'])
assert body['combined_classifications']=={'same_complete_success':528,'same_complete_typed_error':936,'different_work_budget_error':24}
classification=json.loads((s/'raw-new-host6-classification.json').read_text())
assert classification['canonical_sha256']=='164f9543d7db901b20a8d1a4d200a9853cd3a89e6fc0615aaf61f4ee2dee38c3'
split_text=(s/'raw-final-fresh-split.stdout').read_text()
m=re.search(r'test result: (?:FAILED|ok)\. (\d+) passed; (\d+) failed;',split_text);assert m
split={'passed':int(m[1]),'failed':int(m[2]),'seconds':json.loads((s/'raw-final-fresh-split.json').read_text())['seconds']}
assert split['passed']+split['failed']==7
source=json.loads((s/'preserved-source-and-oracle-final-audit.json').read_text())
assert source['preserved_unowned']=={'main':2821,'scoped':2493}and source['immutable_oracles']==23
out={'all_terminal':True,'receipts':receipts,'native_audio_runs_serial':True,'native_runs':len(native),'coverage':coverage,'tests':tests,'source_audit':source,'native_pair_audit':{'scope':'raw OLD paired.new','classifications':classification['classifications'],'canonical_sha256':classification['canonical_sha256'],'full_audit':'raw-full-audit-parent6/audit.json'},'split':split,'source_tree':(s/'index-source-tree.txt').read_text().strip(),'shipping_source_patch_sha256':sha((s/'shipping-source.patch').read_bytes())}
(s/'final-audit.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({k:v for k,v in out.items()if k not in ['receipts','tests']},indent=2))
