from pathlib import Path
import subprocess
s=Path(__file__).resolve().parent
for v in ['scoped','main']:
 build=f'raw-native4-{v}-build'
 subprocess.run(['python3',str(s/'pin.py'),build],check=True)
 subprocess.run(['python3',str(s/'run_target.py'),build,v,'audio','deadpan_audio',f'raw-native4-{v}-list','--list'],check=True)
 subprocess.run(['python3',str(s/'run_target.py'),build,v,'audio','deadpan_audio',f'raw-native4-{v}-library','--test-threads=1'],check=True)
 subprocess.run(['python3',str(s/'capture_new_native.py'),v],check=True)
