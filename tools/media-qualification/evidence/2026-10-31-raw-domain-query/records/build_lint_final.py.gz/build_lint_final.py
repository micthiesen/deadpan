from pathlib import Path
import subprocess,sys
s=Path(__file__).resolve().parent;v=sys.argv[1]
logic=s/('run_main_logic.py'if v=='main'else'run_scoped_logic.py')
native=s/('run_qualified.py'if v=='main'else'run_scoped_qualified.py')
for package,runner in [('plan',logic),('audio',native)]:
 label=f'raw-lintfinal-{package}-{v}-build'
 subprocess.run(['python3',str(runner),label,'--','cargo','test','-p','deadpan-'+package,'--locked','--no-run','--message-format=json'],check=True)
 subprocess.run(['python3',str(s/'pin.py'),label],check=True)
command=['cargo','xtask','check','--no-test']if v=='main'else['cargo','clippy','-p','deadpan-plan','-p','deadpan-audio','--all-targets','--locked','--','-D','warnings']
subprocess.run(['python3',str(native),f'raw-strict-{v}-final','--',*command],check=True)
