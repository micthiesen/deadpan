from pathlib import Path
import difflib, hashlib, json, subprocess

base=Path(__file__).resolve().parent
roots={
  'main-inherited':Path('/Users/michael/Code/deadpan'),
  'scoped-published':Path('/tmp/deadpan-query-groundwork-2026-10-26/scoped'),
}
paths=[
 'crates/deadpan-plan/src/audio_bound.rs',
 'crates/deadpan-plan/src/audio_bound_probe.rs',
 'crates/deadpan-plan/src/audio_bound_probe_phase_trace_tests.rs',
 'crates/deadpan-plan/src/audio_owners/raw_domain_baseline.rs',
 'crates/deadpan-plan/src/audio_owners/raw_domain_admission_tests.rs',
 'crates/deadpan-plan/src/audio_point_domain.rs',
 'crates/deadpan-plan/src/audio_signal.rs',
]
trace_source=(base/'after/main-inherited/crates/deadpan-plan/src/audio_bound_probe_phase_trace_tests.rs').read_text()

for name,root in roots.items():
    before=base/'before'/name
    after=base/'after'/name
    for rel in paths:
        p=Path(rel)
        src=(root/p).read_text()
        (before/p).parent.mkdir(parents=True,exist_ok=True)
        (after/p).parent.mkdir(parents=True,exist_ok=True)
        (before/p).write_text(src)
        (after/p).write_text(src)

    p=after/paths[1]
    s=p.read_text()
    old='''                    self.set_root_evaluation_admitted(&mut domain, budget)?;'''
    assert s.count(old)==1
    s=s.replace(old,'''                    self.set_root_evaluation_admitted(&mut domain, budget, definition_value)?;''',1)
    old='''        budget: &mut QueryBudget<'_, A>,
    ) -> Result<(), A> {
        // Each real replacement'''
    new='''        budget: &mut QueryBudget<'_, A>,
        definition: &AudioDefinition<'plan>,
    ) -> Result<(), A> {
        // Each real replacement'''
    assert s.count(old)==1
    s=s.replace(old,new,1)
    for old,new in [
      ('phase_trace::root_selector(&domain.value, next_definition.as_ref());','phase_trace::root_selector(&domain.value, next_definition.as_ref(), definition);'),
      ('phase_trace::root_repeats(&domain.value, &copied_repeats.value);','phase_trace::root_repeats(&domain.value, &copied_repeats.value, definition);'),
      ('phase_trace::root_constraints(&domain.value, &next.value);','phase_trace::root_constraints(&domain.value, &next.value, definition);'),
      ('phase_trace::root_instance(&domain.value, instance.value.as_ref().unwrap());','phase_trace::root_instance(&domain.value, instance.value.as_ref().unwrap(), definition);'),
    ]:
      assert s.count(old)==1,old
      s=s.replace(old,new,1)
    p.write_text(s)
    # Replace the test-only trace module with the fixed-size live-ledger implementation.
    p=after/paths[2]
    p.write_text(trace_source)

    # Add the live Structural selector view and forward it from Point.
    p=after/paths[6]
    s=p.read_text()
    anchor='''    pub(in crate::plan) fn probe_structural_definition_present(&self) -> bool {
        assert!(matches!(&self.provider, SignalProvider::Structural));
        self.definition.is_some()
    }
}'''
    assert s.count(anchor)==1
    s=s.replace(anchor,'''    pub(in crate::plan) fn probe_structural_definition_present(&self) -> bool {
        assert!(matches!(&self.provider, SignalProvider::Structural));
        self.definition.is_some()
    }

    pub(in crate::plan) fn probe_structural_selector(&self) -> Option<&AudioDefinitionSelector> {
        assert!(matches!(&self.provider, SignalProvider::Structural));
        self.definition.as_ref()
    }
}''',1)
    p.write_text(s)
    p=after/paths[5]
    s=p.read_text()
    anchor='''    pub(in crate::plan) fn probe_structural_definition_present(&self) -> bool {
        self.signal.probe_structural_definition_present()
    }
    #[cfg(test)]
    pub(in crate::plan) fn probe_top_selector'''
    assert s.count(anchor)==1
    s=s.replace(anchor,'''    pub(in crate::plan) fn probe_structural_definition_present(&self) -> bool {
        self.signal.probe_structural_definition_present()
    }
    #[cfg(test)]
    pub(in crate::plan) fn probe_structural_selector(&self) -> Option<&AudioDefinitionSelector> {
        self.signal.probe_structural_selector()
    }
    #[cfg(test)]
    pub(in crate::plan) fn probe_top_selector''',1)
    p.write_text(s)

    # The trace is activated only around the public query; don't wrap all retaining carriers.
    p=after/paths[3]
    s=p.read_text()
    old='''    let phase_case = crate::plan::audio_bound::phase_trace::InputScope::new(input, retained);
    let construction = reconstruct(plan, retained.bound(), caller);
    drop(phase_case);'''
    assert s.count(old)==1
    s=s.replace(old,'    let construction = reconstruct(plan, retained.bound(), caller);',1)
    p.write_text(s)

    # Add one mode that checks every public query against its own live ledger.
    p=after/paths[4]
    s=p.read_text()
    old='''enum Mode {
    Values,
    Budgets,
    Failures,
}'''
    assert s.count(old)==1
    s=s.replace(old,'''enum Mode {
    Values,
    Budgets,
    Failures,
    Phase,
}''',1)
    anchor='''pub(super) fn observe(
    plan: &RenderPlan,
    bound: &AudioBound<'_>,
    caller: Option<&Rc<RefCell<PolicyState>>>,
) {'''
    assert s.count(anchor)==1
    helper='''fn phase_query(
    plan: &RenderPlan,
    bound: &AudioBound<'_>,
    row: &Value,
    caller: Option<&Rc<RefCell<PolicyState>>>,
) -> usize {
    let mut recorder = Recording::<true>::new(caller, Fault::None);
    let live = Rc::clone(&recorder.policy.0);
    let result = crate::plan::audio_bound::phase_trace::with_live(
        move || live.borrow().live,
        || bound.raw_domain_query(&mut recorder),
    );
    match result {
        Ok(value) => {
            assert_eq!(row["ordinary"]["result"]["result"], "Ok");
            assert_value(plan, &value, row, &recorder);
            drop(value);
        }
        Err(error) => {
            assert_eq!(row["ordinary"]["result"]["result"], "Error");
            assert_eq!(snapshot::error_json(&error), row["ordinary"]["result"]["error"]);
        }
    }
    let seals = public_events(&frozen_events(row), &recorder.events);
    recorder.assert_released();
    seals
}
'''
    s=s.replace(anchor,helper+anchor,1)
    old='''        Mode::Failures => failures(plan, bound, &row, caller),'''
    assert s.count(old)==1
    s=s.replace(old,old+'''
        Mode::Phase => (0, phase_query(plan, bound, &row, caller)),''',1)
    old='''        Mode::Values => assert_eq!(run.attempts, 0),'''
    assert s.count(old)==1
    s=s.replace(old,'''        Mode::Values | Mode::Phase => assert_eq!(run.attempts, 0),''',1)
    start=s.index('#[test]\\nfn independent_layout_lower_bounds_observe_real_overlap_with_input_carriers_for_all_77()')
    test='''#[test]
fn phase_heap_lower_bounds_are_covered_by_actual_public_policy_live_bytes_for_all_77() {
    crate::plan::audio_bound::phase_trace::start();
    run(Mode::Phase);
    let summary = crate::plan::audio_bound::phase_trace::finish();
    let counts = summary.phases.map(|row| row.calls);
    assert_eq!(counts[0], 77, "one actual temporary definition per public query");
    assert_eq!(counts[1], 59, "one actual Root initial allocation per public query");
    assert_eq!(counts[2], 59, "one actual Root selector replacement per public query");
    assert_eq!(counts[3], 59, "one actual Root repeat replacement per public query");
    assert!(counts[4] > 0, "actual Root constraint replacements are exercised");
    assert_eq!(counts[5], 59, "one actual Root instance replacement per public query");
    assert_eq!(counts[6], 18, "one actual Point initial allocation per public query");
    assert_eq!(counts[7], 18, "one actual Point evaluation replacement per public query");
    for (index, count) in summary.phases.iter().enumerate() {
        assert!(count.max_heap_lower_bound > 0, "phase {index} has measured owned heap");
    }
    assert!(summary.phases[2].selector_pairs > 0);
    assert_eq!(
        summary.phases[2].nonempty_new_selectors + summary.phases[2].empty_new_selectors,
        counts[2],
        "Root Some and None replacement options are counted from actual values"
    );
    assert_eq!(summary.phases[0].logical_definition_ids, 77);
    assert_eq!(summary.phases[6].selector_pairs, 18);
    assert_eq!(summary.phases[7].selector_pairs, summary.phases[7].nonempty_new_selectors);
    assert_eq!(
        summary.phases[7].nonempty_new_selectors + summary.phases[7].empty_new_selectors,
        counts[7],
        "Point Some and None evaluation options are counted from actual values"
    );
}
'''
    s=s[:start]+test
    p.write_text(s)

    files=[after/Path(rel) for rel in paths]
    subprocess.run(['rustfmt','--edition','2024','--config','skip_children=true',*map(str,files)],check=True)

# Exact source pins and one patch per current source root.
pins={}
for name in roots:
    before=base/'before'/name
    after=base/'after'/name
    patch=''
    for rel in paths:
        patch+=''.join(difflib.unified_diff((before/rel).read_text().splitlines(True),
           (after/rel).read_text().splitlines(True),fromfile='a/'+rel,tofile='b/'+rel))
    (base/'patches'/f'{name}.patch').write_text(patch)
    entries={}
    for rel in paths:
        b=(before/rel).read_bytes(); a=(after/rel).read_bytes()
        entries[rel]={'before_sha256':hashlib.sha256(b).hexdigest(),'after_sha256':hashlib.sha256(a).hexdigest(),'before_bytes':len(b),'after_bytes':len(a)}
    entries['patch_sha256']=hashlib.sha256(patch.encode()).hexdigest()
    pins[name]=entries
(base/'pins.json').write_text(json.dumps(pins,indent=2)+'\\n')
(base/'pins-output.json').write_text(json.dumps(pins,indent=2)+'\\n')
