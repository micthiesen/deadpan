# Raw-domain phase-heap test candidate

This scratch-only layer reuses the frozen 77-case OLD raw-domain matrix and the current admission-test child. It adds one Phase mode pass: for each of the 77 actual public raw_domain_query calls, a test-only TLS getter owns an Rc clone of that call's real policy ledger and reads its current live byte count at constructor hooks. The existing internal-helper constructions run with no getter and are skipped. The matrix includes 54 retained-Some and 23 direct operands, with 59 Root and 18 Point constructors.

## Candidate files

- patches/main-inherited.patch
- patches/scoped-published.patch
- pins.json and pins-output.json hold before/after SHA-256 and byte counts for every changed file, plus each patch SHA-256.
- after/<root>/... contains formatted candidate sources.
- before/<root>/... contains the source snapshots used to form the patches.
- Run prepare.py, then finalize_phase.py, to regenerate from the current guarded source and admission-test candidate.

The Main and Scope patches are byte-identical because their seven target files were equal in the source snapshots; the inherited plan.rs difference is untouched. The 77-case OLD fixture remains SHA-256 4f5d102d00454c81282f6ead82824d2984e626888ed8013d2de9452eccee8d0c.

## What is checked

At each instrumented phase, the test sums Layout sizes from the actual old and replacement Vec capacities and the actual NodeId string lengths held by temporary definitions and live selectors. Each string length is a lower bound on its owned heap buffer. The hook immediately asserts that the same public query's real PolicyState.live covers that combined lower bound. It does not infer a fee from a whole-read residual. Root selector replacements count a pair only when the actual replacement Option is Some; Some and None values are counted separately. Point checks inspect the actual Structural selector and top selector and verify equality, then count a replacement selector only when the actual evaluation Option is Some.

The constructor hooks cover the temporary definition, Root initial state and selector/repeat/constraint/instance replacements, and Point initial state and evaluation replacement. The trace separately counts the temporary logical definition ID at every query. Hook counters are bounded fixed-size TLS values, and constructors are not observed unless the test explicitly starts the trace and installs a getter for a live policy.

## Limits

These are actual policy-ledger comparisons for selected constructor-owned heap Layout lower bounds. They exclude stack inline values, borrowed input/retained carriers, nested heap payloads not included in the measured vectors and ID strings, allocator overhead, RSS, phase-wide process peak, and the conservative dead-edge charge. No empty domain is fabricated. This does not claim a full admission-memory model.

prepare.py and finalize_phase.py pass py_compile; candidate sources pass rustfmt --check. No Rust name-resolution/type-check, build, native test, or capture was run; parent owns those checks.
