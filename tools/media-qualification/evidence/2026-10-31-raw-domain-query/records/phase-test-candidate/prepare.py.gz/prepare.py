from pathlib import Path
import difflib, hashlib, json, subprocess
base=Path(__file__).resolve().parent
roots={
  'main-inherited':Path('/Users/michael/Code/deadpan'),
  'scoped-published':Path('/tmp/deadpan-query-groundwork-2026-10-26/scoped'),
}
probe=Path('crates/deadpan-plan/src/audio_bound_probe.rs')
baseline=Path('crates/deadpan-plan/src/audio_owners/raw_domain_baseline.rs')
admission=Path('crates/deadpan-plan/src/audio_owners/raw_domain_admission_tests.rs')
point=Path('crates/deadpan-plan/src/audio_point_domain.rs')
signal=Path('crates/deadpan-plan/src/audio_signal.rs')
for name,root in roots.items():
  adir=base/'after'/name
  bdir=base/'before'/name
  adir.mkdir(parents=True,exist_ok=True); bdir.mkdir(parents=True,exist_ok=True)
  audio_bound=Path('crates/deadpan-plan/src/audio_bound.rs')
  for p in (probe,baseline,admission,audio_bound,point,signal):
    src=(root/p).read_text() if p != admission else (base.parent/'admission-test-candidate/new'/p).read_text()
    (bdir/p).parent.mkdir(parents=True,exist_ok=True); (bdir/p).write_text(src)
    (adir/p).parent.mkdir(parents=True,exist_ok=True); (adir/p).write_text(src)
  p=adir/audio_bound
  s=p.read_text()
  anchor='pub use probe::AdmittedAudioBoundDomain;\n'
  assert s.count(anchor)==1
  s=s.replace(anchor,anchor+'#[cfg(test)]\npub(in crate::plan) use probe::phase_trace;\n',1)
  p.write_text(s)
  p=adir/probe
  s=p.read_text()
  anchor='''        definition_value.validate_physical_placement(&placement)?;
        match lattice.grid_rule {'''
  assert s.count(anchor)==1
  s=s.replace(anchor, '''        definition_value.validate_physical_placement(&placement)?;
        #[cfg(test)]
        phase_trace::temporary_definition::<A>(definition_value);
        match lattice.grid_rule {''',1)
  anchor='''                let mut domain = definition_value.root_domain_on_grid_query(
                    placement,
                    ExactRatio::ZERO,
                    crate::AudioBoundaryRule::RoundEven,
                    budget,
                )?;
                if !A::METERED {'''
  assert s.count(anchor)==1
  s=s.replace(anchor, '''                let mut domain = definition_value.root_domain_on_grid_query(
                    placement,
                    ExactRatio::ZERO,
                    crate::AudioBoundaryRule::RoundEven,
                    budget,
                )?;
                #[cfg(test)]
                if A::METERED { phase_trace::root_initial(&domain.value, definition_value); }
                if !A::METERED {''',1)
  anchor='''        domain.value.seed.definition = budget.definition(&mut domain.memory, &self.definition)?;
        domain.value.seed.bypass_binding = Some(self.binding_target());
        let mut copied_repeats = repeats(&self.instance.repeats, budget)?;'''
  assert s.count(anchor)==1
  s=s.replace(anchor, '''        let next_definition = budget.definition(&mut domain.memory, &self.definition)?;
        #[cfg(test)]
        phase_trace::root_selector(&domain.value, next_definition.as_ref());
        domain.value.seed.definition = next_definition;
        domain.value.seed.bypass_binding = Some(self.binding_target());
        let mut copied_repeats = repeats(&self.instance.repeats, budget)?;''',1)
  anchor='''        let mut copied_repeats = repeats(&self.instance.repeats, budget)?;
        budget.check_memory(&domain.memory)?;'''
  assert s.count(anchor)==1
  s=s.replace(anchor, '''        let mut copied_repeats = repeats(&self.instance.repeats, budget)?;
        #[cfg(test)]
        phase_trace::root_repeats(&domain.value, &copied_repeats.value);
        budget.check_memory(&domain.memory)?;''',1)
  anchor='''            for value in &self.constraints {
                next.value.push(budget.constraint(&mut next.memory, value)?);
            }
            budget.check_memory(&domain.memory)?;'''
  assert s.count(anchor)==1
  s=s.replace(anchor, '''            for value in &self.constraints {
                next.value.push(budget.constraint(&mut next.memory, value)?);
            }
            #[cfg(test)]
            phase_trace::root_constraints(&domain.value, &next.value);
            budget.check_memory(&domain.memory)?;''',1)
  anchor='''        instance.value = Some(budget.instance_fixed(&mut instance.memory, &self.instance)?);
        budget.check_memory(&domain.memory)?;'''
  assert s.count(anchor)==1
  s=s.replace(anchor, '''        instance.value = Some(budget.instance_fixed(&mut instance.memory, &self.instance)?);
        #[cfg(test)]
        phase_trace::root_instance(&domain.value, instance.value.as_ref().unwrap());
        budget.check_memory(&domain.memory)?;''',1)
  anchor='''                let mut domain = AudioPointDomain::new_admitted(
                    definition_value,
                    placement,
                    lattice.grid_origin,
                    budget,
                )?;
                // The old call evaluates both copies before replacing either'''
  assert s.count(anchor)==1
  s=s.replace(anchor, '''                let mut domain = AudioPointDomain::new_admitted(
                    definition_value,
                    placement,
                    lattice.grid_origin,
                    budget,
                )?;
                #[cfg(test)]
                if A::METERED { phase_trace::point_initial(&domain.value, definition_value); }
                // The old call evaluates both copies before replacing either''',1)
  anchor='''                let mut copied_repeats = repeats(&self.instance.repeats, budget)?;
                budget.check_memory(&evaluation.memory)?;'''
  assert s.count(anchor)==1
  s=s.replace(anchor, '''                let mut copied_repeats = repeats(&self.instance.repeats, budget)?;
                #[cfg(test)]
                phase_trace::point_evaluation(&domain.value, definition_value, &selector, &copied_repeats.value);
                budget.check_memory(&evaluation.memory)?;''',1)
  s+='''
#[cfg(test)]
#[path = "audio_bound_probe_phase_trace_tests.rs"]
pub(in crate::plan) mod phase_trace;
'''
  p.write_text(s)
  p=adir/baseline
  s=p.read_text()
  anchor='''    let construction = reconstruct(plan, retained.bound(), caller);
    let input_after = snapshot::input(input);'''
  assert s.count(anchor)==1
  s=s.replace(anchor, '''    let phase_case = crate::plan::audio_bound::phase_trace::InputScope::new(input, retained);
    let construction = reconstruct(plan, retained.bound(), caller);
    drop(phase_case);
    let input_after = snapshot::input(input);''',1)
  p.write_text(s)
  p=adir/signal
  s=p.read_text()
  anchor="""impl crate::audio_allocated::OwnedHeap for AudioSignal<'_> {"""
  assert s.count(anchor)==1
  helpers="""#[cfg(test)]
impl AudioSignal<'_> {
    pub(in crate::plan) fn probe_structural_repeat_capacity(&self) -> usize {
        assert!(matches!(&self.provider, SignalProvider::Structural));
        self.repeats.capacity()
    }

    pub(in crate::plan) fn probe_structural_definition_present(&self) -> bool {
        assert!(matches!(&self.provider, SignalProvider::Structural));
        self.definition.is_some()
    }
}

"""
  s=s.replace(anchor,helpers+anchor,1)
  p.write_text(s)
  p=adir/point
  s=p.read_text()
  anchor="""    pub(super) fn set_evaluation("""
  assert s.count(anchor)==1
  s=s.replace(anchor,"""    #[cfg(test)]
    pub(in crate::plan) fn probe_structural_repeat_capacity(&self) -> usize {
        self.signal.probe_structural_repeat_capacity()
    }
    #[cfg(test)]
    pub(in crate::plan) fn probe_structural_definition_present(&self) -> bool {
        self.signal.probe_structural_definition_present()
    }
    #[cfg(test)]
    pub(in crate::plan) fn probe_top_selector(&self) -> &AudioDefinitionSelector {
        &self.selector
    }

    pub(super) fn set_evaluation(""",1)
  p.write_text(s)
  # New trace module.
  trace='''//! Fixed-size test-only Layout lower bounds at real constructor overlap phases.
use super::*;
use crate::{AudioOwnerInput, AudioOwnerRetainedInput};
use deadpan_core::RepeatInstance;
use std::{alloc::Layout, cell::RefCell};

#[derive(Clone, Copy, Debug)]
#[repr(usize)]
enum Phase { TemporaryDefinition, RootInitial, RootSelectorReplacement, RootRepeatReplacement, RootConstraintReplacement, RootInstanceReplacement, PointInitial, PointEvaluationReplacement }
pub(in crate::plan) const PHASES: usize = 8;
#[derive(Clone, Copy, Debug, Default)]
pub(in crate::plan) struct Count { pub(in crate::plan) calls: usize, pub(in crate::plan) overlap_calls: usize, pub(in crate::plan) selector_pairs: usize, pub(in crate::plan) max_total_lower_bound: usize, pub(in crate::plan) max_old_arrays: usize, pub(in crate::plan) max_new_arrays: usize }
#[derive(Clone, Copy, Debug, Default)]
pub(in crate::plan) struct Summary { pub(in crate::plan) phases: [Count; PHASES] }
thread_local! { static ACTIVE: RefCell<Option<Summary>> = const { RefCell::new(None) }; static CARRIER: RefCell<Option<usize>> = const { RefCell::new(None) }; }

pub(in crate::plan) fn start() { ACTIVE.with(|slot| { assert!(slot.borrow().is_none()); *slot.borrow_mut()=Some(Summary::default()); }); }
pub(in crate::plan) fn finish() -> Summary { CARRIER.with(|slot| assert!(slot.borrow().is_none())); ACTIVE.with(|slot| slot.borrow_mut().take().expect("active phase trace")) }
pub(in crate::plan) struct InputScope(bool);
impl InputScope { pub(in crate::plan) fn new(input: &AudioOwnerInput<'_>, retained: &AudioOwnerRetainedInput<'_>) -> Self {
    let active = ACTIVE.with(|slot| slot.borrow().is_some());
    if active {
        let bound = retained.bound();
        let bytes = sum(&[
            Layout::new::<AudioOwnerInput<'_>>().size(),
            Layout::new::<AudioOwnerRetainedInput<'_>>().size(),
            Layout::new::<AudioBound<'_>>().size(),
            root_arrays(input.context()),
            array::<RepeatInstance>(bound.instance.repeats.capacity()),
            array::<crate::plan::audio::EnvelopeConstraint>(bound.constraints.capacity()),
        ]);
        CARRIER.with(|slot| { assert!(slot.borrow().is_none()); *slot.borrow_mut()=Some(bytes); });
    }
    Self(active)
} }
impl Drop for InputScope { fn drop(&mut self) { if self.0 { CARRIER.with(|slot| assert!(slot.borrow_mut().take().is_some())); } } }
fn array<T>(len: usize) -> usize { Layout::array::<T>(len).expect("actual Vec layout").size() }
fn sum(parts: &[usize]) -> usize { parts.iter().try_fold(0usize, |a,b| a.checked_add(*b)).expect("actual-layout lower-bound sum") }
fn record(phase: Phase, old: usize, new: usize, inline: usize) {
    ACTIVE.with(|slot| { let mut state=slot.borrow_mut(); let Some(state)=state.as_mut() else { return; };
        let carrier=CARRIER.with(|slot| slot.borrow().expect("phase call remains under actual input carrier"));
        let count=&mut state.phases[phase as usize]; count.calls+=1; if old>0 && new>0 { count.overlap_calls+=1; } count.max_old_arrays=count.max_old_arrays.max(old); count.max_new_arrays=count.max_new_arrays.max(new); count.max_total_lower_bound=count.max_total_lower_bound.max(sum(&[carrier,inline,old,new]));
    });
}
fn root_arrays(domain: &AudioDomain<'_>) -> usize {
    let seed=&domain.seed;
    sum(&[array::<crate::plan::audio::EnvelopeConstraint>(seed.constraints.capacity()), array::<crate::plan::audio::EditorialConstraint>(seed.editorial.capacity()), array::<RepeatInstance>(seed.repeats.capacity()), array::<crate::AudioRetimeStage>(seed.retimes.capacity()), array::<RepeatInstance>(domain.instance.repeats.capacity())])
}
pub(super) fn temporary_definition<A: AudioSoundContextAdmission>(definition: &AudioDefinition<'_>) { if A::METERED { let _=definition.selector(); record(Phase::TemporaryDefinition,0,0,Layout::new::<AudioDefinition<'_>>().size()); } }
pub(super) fn root_initial(domain: &AudioDomain<'_>, _definition: &AudioDefinition<'_>) { record(Phase::RootInitial,root_arrays(domain),0,Layout::new::<AudioDomain<'_>>().size()+Layout::new::<AudioDefinition<'_>>().size()); }
pub(super) fn root_selector(domain: &AudioDomain<'_>, next: Option<&AudioDefinitionSelector>) { assert!(domain.seed.definition.is_some(), "actual old Root selector is present"); let _new_selector = next; record(Phase::RootSelectorReplacement,0,0,Layout::new::<AudioDomain<'_>>().size()+Layout::new::<AudioDefinition<'_>>().size()+Layout::new::<Option<AudioDefinitionSelector>>().size()); ACTIVE.with(|slot| slot.borrow_mut().as_mut().unwrap().phases[Phase::RootSelectorReplacement as usize].selector_pairs += 1); }
pub(super) fn root_repeats(domain: &AudioDomain<'_>, next: &Vec<RepeatInstance>) { record(Phase::RootRepeatReplacement,root_arrays(domain),array::<RepeatInstance>(next.capacity()),Layout::new::<AudioDomain<'_>>().size()+Layout::new::<AudioDefinition<'_>>().size()); }
pub(super) fn root_constraints(domain: &AudioDomain<'_>, next: &Vec<crate::plan::audio::EnvelopeConstraint>) { record(Phase::RootConstraintReplacement,root_arrays(domain),array::<crate::plan::audio::EnvelopeConstraint>(next.capacity()),Layout::new::<AudioDomain<'_>>().size()+Layout::new::<AudioDefinition<'_>>().size()); }
pub(super) fn root_instance(domain: &AudioDomain<'_>, next: &deadpan_core::InstancePath) { record(Phase::RootInstanceReplacement,root_arrays(domain),array::<RepeatInstance>(next.repeats.capacity()),Layout::new::<AudioDomain<'_>>().size()+Layout::new::<AudioDefinition<'_>>().size()+Layout::new::<deadpan_core::InstancePath>().size()); }
fn point_old_repeat_capacity(point: &AudioPointDomain<'_>) -> usize { point.probe_structural_repeat_capacity() }
pub(super) fn point_initial(point: &AudioPointDomain<'_>, _definition: &AudioDefinition<'_>) { assert!(point.probe_structural_definition_present(), "actual initial Structural signal retains its selector"); let _top_selector = point.probe_top_selector(); let old=array::<RepeatInstance>(point_old_repeat_capacity(point)); record(Phase::PointInitial,old,0,Layout::new::<AudioPointDomain<'_>>().size()+Layout::new::<AudioDefinition<'_>>().size()); ACTIVE.with(|slot| slot.borrow_mut().as_mut().unwrap().phases[Phase::PointInitial as usize].selector_pairs += 1); }
pub(super) fn point_evaluation(point: &AudioPointDomain<'_>, _definition: &AudioDefinition<'_>, selector: &Option<AudioDefinitionSelector>, next: &Vec<RepeatInstance>) { assert!(point.probe_structural_definition_present(), "old Structural selector overlaps replacement evaluation"); let _top_selector = point.probe_top_selector(); let old=array::<RepeatInstance>(point.probe_structural_repeat_capacity()); let new=array::<RepeatInstance>(next.capacity()); record(Phase::PointEvaluationReplacement,old,new,Layout::new::<AudioPointDomain<'_>>().size()+Layout::new::<Option<AudioDefinitionSelector>>().size()); assert!(selector.as_ref().map_or(true, |value| value == point.probe_top_selector()), "the replacement selector, when present, is the actual Point top selector"); ACTIVE.with(|slot| slot.borrow_mut().as_mut().unwrap().phases[Phase::PointEvaluationReplacement as usize].selector_pairs += 1); }
'''
  trace_lines = trace.splitlines()
  guarded = []
  for line in trace_lines:
    if line.startswith('pub(super) fn '):
      brace = line.find(' {')
      assert brace >= 0
      line = line[:brace + 2] + ' if !enabled() { return; } ' + line[brace + 2:]
    guarded.append(line)
  trace = '\n'.join(guarded) + '\n'
  trace = trace.replace(
      'thread_local! { static ACTIVE:',
      'fn enabled() -> bool { ACTIVE.with(|slot| slot.borrow().is_some()) }\nthread_local! { static ACTIVE:',
      1,
  )
  tp=adir/probe.parent/'audio_bound_probe_phase_trace_tests.rs'
  tp.write_text(trace)
  # Add test using existing admission matrix and exact actual input scopes.
  p=adir/admission
  s=p.read_text()
  s += '''
#[test]
fn independent_layout_lower_bounds_observe_real_overlap_with_input_carriers_for_all_77() {
    crate::plan::audio_bound::phase_trace::start();
    run(Mode::Values);
    let summary=crate::plan::audio_bound::phase_trace::finish();
    let counts=summary.phases.map(|row| row.calls);
    assert_eq!(counts[0],154,"temporary definitions live in both metered constructions per frozen row");
    assert_eq!(counts[1],118,"Root initial results across all Root operands");
    assert_eq!(counts[2],118,"Root selector replacements across both metered constructions");
    assert_eq!(counts[3],118,"Root repeat replacements across both metered constructions");
    assert!(counts[4] > 0,"actual Root constraint replacement is exercised");
    assert_eq!(counts[5],118,"Root instance replacements across both metered constructions");
    assert_eq!(counts[6],36,"Point initial signal and top selector across both metered constructions");
    assert_eq!(counts[7],36,"Point evaluation replacement across both metered constructions");
    for index in 0..PHASES { assert!(summary.phases[index].max_total_lower_bound > 0); }
    assert_eq!(summary.phases[2].selector_pairs,118,"old Root selector and replacement option are both observed");
    for index in [3,4,5] { assert!(summary.phases[index].overlap_calls > 0,"Root old/new vector allocations overlap in phase {index}"); }
    assert!(summary.phases[3].max_new_arrays > 0);
    assert!(summary.phases[4].max_new_arrays > 0);
    assert!(summary.phases[5].max_new_arrays > 0);
    assert_eq!(summary.phases[6].selector_pairs,36,"old Structural signal selector and Point top selector coexist");
    assert_eq!(summary.phases[7].selector_pairs,36,"old Structural selector and new evaluation option coexist");
}
'''
  p.write_text(s)
  # Emit per-file diffs from candidate baseline, including new files.
  subprocess.run([
      'rustfmt', '--edition', '2024', '--config', 'skip_children=true',
      *[str(adir/p) for p in [audio_bound,probe,baseline,admission,point,signal,probe.parent/'audio_bound_probe_phase_trace_tests.rs']],
  ], check=True)
  before=bdir
  after=adir
  patch=[]
  for p in [audio_bound,probe,baseline,admission,point,signal,probe.parent/'audio_bound_probe_phase_trace_tests.rs']:
    old=(before/p).read_text() if (before/p).exists() else ''
    newtext=(after/p).read_text()
    patch.extend(difflib.unified_diff(old.splitlines(keepends=True),newtext.splitlines(keepends=True),fromfile='a/'+str(p),tofile='b/'+str(p)))
  (base/'patches'/f'{name}.patch').write_text(''.join(patch))
# Pins
pins={}
for name,root in roots.items():
  after=base/'after'/name
  before=base/'before'/name
  pins[name]={}
  for p in [audio_bound,probe,baseline,admission,point,signal,probe.parent/'audio_bound_probe_phase_trace_tests.rs']:
    path=after/p
    old=before/p
    pins[name][str(p)]={
      'before_sha256':hashlib.sha256(old.read_bytes()).hexdigest() if old.exists() else None,
      'after_sha256':hashlib.sha256(path.read_bytes()).hexdigest(),
      'before_bytes':old.stat().st_size if old.exists() else 0,
      'after_bytes':path.stat().st_size,
    }
  pins[name]['patch_sha256']=hashlib.sha256((base/'patches'/f'{name}.patch').read_bytes()).hexdigest()
(base/'pins.json').write_text(json.dumps(pins,indent=2)+'\n')
print(json.dumps(pins,indent=2))
