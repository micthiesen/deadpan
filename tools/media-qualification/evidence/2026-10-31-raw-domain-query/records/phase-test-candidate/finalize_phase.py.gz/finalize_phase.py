from pathlib import Path
import difflib, hashlib, json, subprocess

base = Path(__file__).resolve().parent
roots = ("main-inherited", "scoped-published")
trace = r'''//! Test-only heap Layout lower bounds checked against the live admission ledger.
use super::*;
use deadpan_core::RepeatInstance;
use std::{alloc::Layout, cell::RefCell};

#[derive(Clone, Copy, Debug)]
#[repr(usize)]
enum Phase {
    TemporaryDefinition,
    RootInitial,
    RootSelectorReplacement,
    RootRepeatReplacement,
    RootConstraintReplacement,
    RootInstanceReplacement,
    PointInitial,
    PointEvaluationReplacement,
}
pub(in crate::plan) const PHASES: usize = 8;
#[derive(Clone, Copy, Debug, Default)]
pub(in crate::plan) struct Count {
    pub(in crate::plan) calls: usize,
    pub(in crate::plan) selector_pairs: usize,
    pub(in crate::plan) selector_ids: usize,
    pub(in crate::plan) nonempty_new_selectors: usize,
    pub(in crate::plan) empty_new_selectors: usize,
    pub(in crate::plan) logical_definition_ids: usize,
    pub(in crate::plan) max_heap_lower_bound: usize,
    pub(in crate::plan) min_live_bytes: usize,
    pub(in crate::plan) min_margin_bytes: usize,
    pub(in crate::plan) max_old_arrays: usize,
    pub(in crate::plan) max_new_arrays: usize,
}
#[derive(Clone, Copy, Debug, Default)]
pub(in crate::plan) struct Summary {
    pub(in crate::plan) phases: [Count; PHASES],
}
thread_local! {
    static ACTIVE: RefCell<Option<Summary>> = const { RefCell::new(None) };
    static LIVE: RefCell<Option<Box<dyn Fn() -> usize>>> = const { RefCell::new(None) };
}
pub(in crate::plan) fn start() {
    ACTIVE.with(|slot| {
        assert!(slot.borrow().is_none());
        *slot.borrow_mut() = Some(Summary::default());
    });
}
pub(in crate::plan) fn finish() -> Summary {
    LIVE.with(|slot| assert!(slot.borrow().is_none()));
    ACTIVE.with(|slot| slot.borrow_mut().take().expect("active phase trace"))
}
struct LiveReset;
impl Drop for LiveReset {
    fn drop(&mut self) {
        LIVE.with(|slot| assert!(slot.borrow_mut().take().is_some()));
    }
}
pub(in crate::plan) fn with_live<R>(
    getter: impl Fn() -> usize + 'static,
    f: impl FnOnce() -> R,
) -> R {
    assert!(ACTIVE.with(|slot| slot.borrow().is_some()));
    LIVE.with(|slot| {
        assert!(slot.borrow().is_none());
        *slot.borrow_mut() = Some(Box::new(getter));
    });
    let _reset = LiveReset;
    f()
}
fn enabled() -> bool {
    ACTIVE.with(|slot| slot.borrow().is_some())
        && LIVE.with(|slot| slot.borrow().is_some())
}
fn live_bytes() -> Option<usize> {
    LIVE.with(|slot| slot.borrow().as_ref().map(|get| get()))
}
fn array<T>(len: usize) -> usize {
    Layout::array::<T>(len).expect("actual Vec layout").size()
}
fn sum(parts: &[usize]) -> usize {
    parts.iter().try_fold(0usize, |a, b| a.checked_add(*b))
        .expect("actual allocation lower-bound sum")
}
fn record(phase: Phase, old: usize, new: usize, selector_bytes: usize, selector_pairs: usize, selector_ids: usize, new_selectors: usize, definition_ids: usize) {
    let Some(live) = live_bytes() else { return; };
    let lower = sum(&[old, new, selector_bytes]);
    assert!(live >= lower, "actual live admission bytes {live} must cover constructor-owned heap Layout lower bound {lower} at {phase:?}");
    ACTIVE.with(|slot| {
        let mut state = slot.borrow_mut();
        let state = state.as_mut().expect("active phase summary");
        let count = &mut state.phases[phase as usize];
        count.calls += 1;
        count.selector_pairs += selector_pairs;
        count.selector_ids += selector_ids;
        count.nonempty_new_selectors += new_selectors;
        if matches!(phase, Phase::RootSelectorReplacement | Phase::PointEvaluationReplacement) {
            count.empty_new_selectors += usize::from(new_selectors == 0);
        }
        count.logical_definition_ids += definition_ids;
        count.max_heap_lower_bound = count.max_heap_lower_bound.max(lower);
        count.min_live_bytes = if count.calls == 1 { live } else { count.min_live_bytes.min(live) };
        count.min_margin_bytes = if count.calls == 1 { live - lower } else { count.min_margin_bytes.min(live - lower) };
        count.max_old_arrays = count.max_old_arrays.max(old);
        count.max_new_arrays = count.max_new_arrays.max(new);
    });
}
fn root_arrays(domain: &AudioDomain<'_>) -> usize {
    let seed = &domain.seed;
    sum(&[
        array::<crate::plan::audio::EnvelopeConstraint>(seed.constraints.capacity()),
        array::<crate::plan::audio::EditorialConstraint>(seed.editorial.capacity()),
        array::<RepeatInstance>(seed.repeats.capacity()),
        array::<crate::AudioRetimeStage>(seed.retimes.capacity()),
        array::<RepeatInstance>(domain.instance.repeats.capacity()),
    ])
}
fn selector_id_bytes(selector: &AudioDefinitionSelector) -> usize {
    let id = match selector {
        AudioDefinitionSelector::Node { node } => node,
        AudioDefinitionSelector::RepeatDefault { repeat } | AudioDefinitionSelector::RepeatGap { repeat } => repeat,
    };
    let bytes = id.as_str().len();
    assert!(bytes > 0, "validated NodeId has nonempty owned string storage");
    bytes
}
pub(super) fn temporary_definition<A: AudioSoundContextAdmission>(definition: &AudioDefinition<'_>) {
    if !enabled() || !A::METERED { return; }
    let selector = definition.selector();
    record(Phase::TemporaryDefinition, 0, 0, selector_id_bytes(selector), 0, 1, 0, 1);
}
pub(super) fn root_initial(domain: &AudioDomain<'_>, _definition: &AudioDefinition<'_>) {
    if !enabled() { return; }
    let mut selector_bytes = selector_id_bytes(_definition.selector());
    let mut selector_ids = 1;
    if let Some(selector) = domain.seed.definition.as_ref() {
        selector_bytes += selector_id_bytes(selector);
        selector_ids += 1;
    }
    let initial_pair = usize::from(domain.seed.definition.is_some());
    record(Phase::RootInitial, root_arrays(domain), 0, selector_bytes, initial_pair, selector_ids, 0, 1);
}
pub(super) fn root_selector(domain: &AudioDomain<'_>, next: Option<&AudioDefinitionSelector>, definition: &AudioDefinition<'_>) {
    if !enabled() { return; }
    assert!(domain.seed.definition.is_some(), "actual old Root selector is present");
    let mut selector_bytes = selector_id_bytes(domain.seed.definition.as_ref().unwrap()) + selector_id_bytes(definition.selector());
    let mut selector_ids = 2;
    let new_present = usize::from(next.is_some());
    if let Some(selector) = next {
        selector_bytes += selector_id_bytes(selector);
        selector_ids += 1;
    }
    record(Phase::RootSelectorReplacement, 0, 0, selector_bytes, new_present, selector_ids, new_present, 1);
}
pub(super) fn root_repeats(domain: &AudioDomain<'_>, next: &Vec<RepeatInstance>, _definition: &AudioDefinition<'_>) {
    if !enabled() { return; }
    record(Phase::RootRepeatReplacement, root_arrays(domain), array::<RepeatInstance>(next.capacity()), selector_id_bytes(_definition.selector()), 0, 1, 0, 1);
}
pub(super) fn root_constraints(domain: &AudioDomain<'_>, next: &Vec<crate::plan::audio::EnvelopeConstraint>, _definition: &AudioDefinition<'_>) {
    if !enabled() { return; }
    record(Phase::RootConstraintReplacement, root_arrays(domain), array::<crate::plan::audio::EnvelopeConstraint>(next.capacity()), selector_id_bytes(_definition.selector()), 0, 1, 0, 1);
}
pub(super) fn root_instance(domain: &AudioDomain<'_>, next: &deadpan_core::InstancePath, _definition: &AudioDefinition<'_>) {
    if !enabled() { return; }
    record(Phase::RootInstanceReplacement, root_arrays(domain), array::<RepeatInstance>(next.repeats.capacity()), selector_id_bytes(_definition.selector()), 0, 1, 0, 1);
}
pub(super) fn point_initial(point: &AudioPointDomain<'_>, _definition: &AudioDefinition<'_>) {
    if !enabled() { return; }
    assert!(point.probe_structural_definition_present(), "actual initial Structural signal retains its selector");
    let top_selector = point.probe_top_selector();
    assert_eq!(point.probe_structural_selector(), Some(top_selector));
    let old = array::<RepeatInstance>(point.probe_structural_repeat_capacity());
    record(Phase::PointInitial, old, 0, selector_id_bytes(point.probe_structural_selector().unwrap()) + selector_id_bytes(top_selector) + selector_id_bytes(_definition.selector()), 1, 3, 0, 1);
}
pub(super) fn point_evaluation(point: &AudioPointDomain<'_>, _definition: &AudioDefinition<'_>, selector: &Option<AudioDefinitionSelector>, next: &Vec<RepeatInstance>) {
    if !enabled() { return; }
    assert!(point.probe_structural_definition_present(), "old Structural selector overlaps replacement evaluation");
    let top_selector = point.probe_top_selector();
    assert_eq!(point.probe_structural_selector(), Some(top_selector));
    let old = array::<RepeatInstance>(point.probe_structural_repeat_capacity());
    let new = array::<RepeatInstance>(next.capacity());
    let new_present = usize::from(selector.is_some());
    assert!(selector.as_ref().map_or(true, |value| value == top_selector), "replacement selector, when present, is the actual Point top selector");
    let mut selector_bytes = selector_id_bytes(point.probe_structural_selector().unwrap()) + selector_id_bytes(top_selector) + selector_id_bytes(_definition.selector());
    let mut selector_ids = 3;
    if let Some(selector) = selector.as_ref() {
        selector_bytes += selector_id_bytes(selector);
        selector_ids += 1;
    }
    record(Phase::PointEvaluationReplacement, old, new, selector_bytes, new_present, selector_ids, new_present, 1);
}
'''
for root in roots:
    d = base/'after'/root/'crates/deadpan-plan/src'
    (d/'audio_bound_probe_phase_trace_tests.rs').write_text(trace)
    p=d/'audio_owners/raw_domain_baseline.rs'
    s=p.read_text()
    old='''    let phase_case = crate::plan::audio_bound::phase_trace::InputScope::new(input, retained);
    let construction = reconstruct(plan, retained.bound(), caller);
    drop(phase_case);'''
    assert old in s
    s=s.replace(old, '    let construction = reconstruct(plan, retained.bound(), caller);', 1)
    p.write_text(s)
    p=d/'audio_owners/raw_domain_admission_tests.rs'
    s=p.read_text()
    s=s.replace('''enum Mode {
    Values,
    Budgets,
    Failures,
}''','''enum Mode {
    Values,
    Budgets,
    Failures,
    Phase,
}''',1)
    anchor='''pub(super) fn observe(
    plan: &RenderPlan,
    bound: &AudioBound<'_>,
    caller: Option<&Rc<RefCell<PolicyState>>>,
) {'''
    assert anchor in s
    helper='''fn phase_query(
    plan: &RenderPlan,
    bound: &AudioBound<'_>,
    row: &Value,
    caller: Option<&Rc<RefCell<PolicyState>>>,
) -> usize {
    let mut recorder = Recording::<true>::new(caller, Fault::None);
    let live = Rc::clone(&recorder.policy.0);
    let result = crate::plan::audio_bound::phase_trace::with_live(
        move || live.borrow().live,
        || bound.raw_domain_query(&mut recorder),
    );
    match result {
        Ok(value) => {
            assert_eq!(row["ordinary"]["result"]["result"], "Ok");
            assert_value(plan, &value, row, &recorder);
            drop(value);
        }
        Err(error) => {
            assert_eq!(row["ordinary"]["result"]["result"], "Error");
            assert_eq!(snapshot::error_json(&error), row["ordinary"]["result"]["error"]);
        }
    }
    let seals = public_events(&frozen_events(row), &recorder.events);
    recorder.assert_released();
    seals
}
'''
    s=s.replace(anchor, helper+anchor, 1)
    s=s.replace('''        Mode::Failures => failures(plan, bound, &row, caller),''','''        Mode::Failures => failures(plan, bound, &row, caller),
        Mode::Phase => (0, phase_query(plan, bound, &row, caller)),''',1)
    s=s.replace('''        Mode::Values => assert_eq!(run.attempts, 0),
        Mode::Budgets =>''','''        Mode::Values | Mode::Phase => assert_eq!(run.attempts, 0),
        Mode::Budgets =>''',1)
    oldtest='''fn independent_layout_lower_bounds_observe_real_overlap_with_input_carriers_for_all_77() {
    crate::plan::audio_bound::phase_trace::start();
    run(Mode::Values);
    let summary = crate::plan::audio_bound::phase_trace::finish();
    let counts = summary.phases.map(|row| row.calls);
    assert_eq!(
        counts[0], 154,
        "temporary definitions live in both metered constructions per frozen row"
    );
    assert_eq!(
        counts[1], 118,
        "Root initial results across all Root operands"
    );
    assert_eq!(
        counts[2], 118,
        "Root selector replacements across both metered constructions"
    );
    assert_eq!(
        counts[3], 118,
        "Root repeat replacements across both metered constructions"
    );
    assert!(
        counts[4] > 0,
        "actual Root constraint replacement is exercised"
    );
    assert_eq!(
        counts[5], 118,
        "Root instance replacements across both metered constructions"
    );
    assert_eq!(
        counts[6], 36,
        "Point initial signal and top selector across both metered constructions"
    );
    assert_eq!(
        counts[7], 36,
        "Point evaluation replacement across both metered constructions"
    );
    for index in 0..PHASES {
        assert!(summary.phases[index].max_total_lower_bound > 0);
    }
    assert_eq!(
        summary.phases[2].selector_pairs, 118,
        "old Root selector and replacement option are both observed"
    );
    for index in [3, 4, 5] {
        assert!(
            summary.phases[index].overlap_calls > 0,
            "Root old/new vector allocations overlap in phase {index}"
        );
    }
    assert!(summary.phases[3].max_new_arrays > 0);
    assert!(summary.phases[4].max_new_arrays > 0);
    assert!(summary.phases[5].max_new_arrays > 0);
    assert_eq!(
        summary.phases[6].selector_pairs, 36,
        "old Structural signal selector and Point top selector coexist"
    );
    assert_eq!(
        summary.phases[7].selector_pairs, 36,
        "old Structural selector and new evaluation option coexist"
    );
}'''
    assert oldtest in s, 'previous test exact block not found'
    test='''fn phase_heap_lower_bounds_are_covered_by_actual_public_policy_live_bytes_for_all_77() {
    crate::plan::audio_bound::phase_trace::start();
    run(Mode::Phase);
    let summary = crate::plan::audio_bound::phase_trace::finish();
    let counts = summary.phases.map(|row| row.calls);
    assert_eq!(counts[0], 77, "one actual temporary definition per public query");
    assert_eq!(counts[1], 59, "one actual Root initial allocation per public query");
    assert_eq!(counts[2], 59, "one actual Root selector replacement per public query");
    assert_eq!(counts[3], 59, "one actual Root repeat replacement per public query");
    assert!(counts[4] > 0, "actual Root constraint replacements are exercised");
    assert_eq!(counts[5], 59, "one actual Root instance replacement per public query");
    assert_eq!(counts[6], 18, "one actual Point initial allocation per public query");
    assert_eq!(counts[7], 18, "one actual Point evaluation replacement per public query");
    for (index, count) in summary.phases.iter().enumerate() {
        assert!(count.max_heap_lower_bound > 0, "phase {index} has measured owned heap");
    }
    assert!(summary.phases[2].selector_pairs > 0);
    assert!(summary.phases[2].nonempty_new_selectors > 0);
    assert_eq!(
        summary.phases[2].nonempty_new_selectors + summary.phases[2].empty_new_selectors,
        counts[2],
        "Root Some and None replacement options are counted from actual values"
    );
    assert_eq!(summary.phases[0].logical_definition_ids, 77);
    assert!(summary.phases[6].selector_pairs == 18);
    assert!(summary.phases[7].selector_pairs > 0);
    assert_eq!(summary.phases[7].selector_pairs, summary.phases[7].nonempty_new_selectors);
    assert_eq!(
        summary.phases[7].nonempty_new_selectors + summary.phases[7].empty_new_selectors,
        counts[7],
        "Point Some and None evaluation options are counted from actual values"
    );
}'''
    s=s.replace(oldtest,test,1)
    p.write_text(s)
    # Add actual borrowed selector accessors to the Point probe.
    p=d/'audio_signal.rs'
    s=p.read_text()
    anchor="""    pub(in crate::plan) fn probe_structural_definition_present(&self) -> bool {
        assert!(matches!(&self.provider, SignalProvider::Structural));
        self.definition.is_some()
    }
}"""
    assert s.count(anchor)==1
    s=s.replace(anchor,"""    pub(in crate::plan) fn probe_structural_definition_present(&self) -> bool {
        assert!(matches!(&self.provider, SignalProvider::Structural));
        self.definition.is_some()
    }

    pub(in crate::plan) fn probe_structural_selector(&self) -> Option<&AudioDefinitionSelector> {
        assert!(matches!(&self.provider, SignalProvider::Structural));
        self.definition.as_ref()
    }
}""",1)
    p.write_text(s)
    p=d/'audio_point_domain.rs'
    s=p.read_text()
    anchor="""    pub(in crate::plan) fn probe_structural_definition_present(&self) -> bool {
        self.signal.probe_structural_definition_present()
    }
    #[cfg(test)]
    pub(in crate::plan) fn probe_top_selector"""
    assert s.count(anchor)==1
    s=s.replace(anchor,"""    pub(in crate::plan) fn probe_structural_definition_present(&self) -> bool {
        self.signal.probe_structural_definition_present()
    }
    #[cfg(test)]
    pub(in crate::plan) fn probe_structural_selector(&self) -> Option<&AudioDefinitionSelector> {
        self.signal.probe_structural_selector()
    }
    #[cfg(test)]
    pub(in crate::plan) fn probe_top_selector""",1)
    p.write_text(s)
    # Keep the live temporary definition in Root phase measurements.
    p=d/'audio_bound_probe.rs'
    s=p.read_text()
    for old,new in [
        ("phase_trace::root_selector(&domain.value, next_definition.as_ref());", "phase_trace::root_selector(&domain.value, next_definition.as_ref(), definition_value);"),
        ("phase_trace::root_repeats(&domain.value, &copied_repeats.value);", "phase_trace::root_repeats(&domain.value, &copied_repeats.value, definition_value);"),
        ("phase_trace::root_constraints(&domain.value, &next.value);", "phase_trace::root_constraints(&domain.value, &next.value, definition_value);"),
        ("phase_trace::root_instance(&domain.value, instance.value.as_ref().unwrap());", "phase_trace::root_instance(&domain.value, instance.value.as_ref().unwrap(), definition_value);"),
    ]:
        assert s.count(old)==1
        s=s.replace(old,new,1)
    # Thread the actual temporary definition through the Root helper lifetime.
    p=d/'audio_bound_probe.rs'
    s=p.read_text()
    old="self.set_root_evaluation_admitted(&mut domain, budget)?;"
    assert s.count(old)==1
    s=s.replace(old,"self.set_root_evaluation_admitted(&mut domain, budget, definition_value)?;",1)
    old="""        budget: &mut QueryBudget<'_, A>,
    ) -> Result<(), A> {
        // Each real replacement"""
    new="""        budget: &mut QueryBudget<'_, A>,
        definition: &AudioDefinition<'plan>,
    ) -> Result<(), A> {
        // Each real replacement"""
    assert s.count(old)==1
    s=s.replace(old,new,1)
    for old,new in [
        ("phase_trace::root_selector(&domain.value, next_definition.as_ref(), definition_value);", "phase_trace::root_selector(&domain.value, next_definition.as_ref(), definition);"),
        ("phase_trace::root_repeats(&domain.value, &copied_repeats.value, definition_value);", "phase_trace::root_repeats(&domain.value, &copied_repeats.value, definition);"),
        ("phase_trace::root_constraints(&domain.value, &next.value, definition_value);", "phase_trace::root_constraints(&domain.value, &next.value, definition);"),
        ("phase_trace::root_instance(&domain.value, instance.value.as_ref().unwrap(), definition_value);", "phase_trace::root_instance(&domain.value, instance.value.as_ref().unwrap(), definition);"),
    ]:
        assert s.count(old)==1
        s=s.replace(old,new,1)
    p.write_text(s)
    # rustfmt candidate source only.
    files=[d/'audio_bound.rs',d/'audio_bound_probe.rs',d/'audio_bound_probe_phase_trace_tests.rs',
      d/'audio_owners/raw_domain_baseline.rs',d/'audio_owners/raw_domain_admission_tests.rs',
      d/'audio_point_domain.rs',d/'audio_signal.rs']
    subprocess.run(['rustfmt','--edition','2024','--config','skip_children=true',*map(str,files)],check=True)

# Rebuild patches and exact pins from before/after snapshots.
pins={}
for root in roots:
    bdir=base/'before'/root
    adir=base/'after'/root
    rels=sorted(str(p.relative_to(bdir)) for p in bdir.rglob('*.rs'))
    patch=''
    for r in rels:
        patch += ''.join(difflib.unified_diff(
            (bdir/r).read_text().splitlines(True),
            (adir/r).read_text().splitlines(True),
            fromfile='a/'+r,tofile='b/'+r))
    # Include added file absent from before.
    newrel='crates/deadpan-plan/src/audio_bound_probe_phase_trace_tests.rs'
    if not (bdir/newrel).exists():
        patch += ''.join(difflib.unified_diff([], (adir/newrel).read_text().splitlines(True),
            fromfile='/dev/null',tofile='b/'+newrel))
    (base/'patches'/f'{root}.patch').write_text(patch)
    summary={}
    for r in rels+[newrel]:
        before=(bdir/r).read_bytes() if (bdir/r).exists() else b''
        after=(adir/r).read_bytes()
        summary[r]={'before_sha256':hashlib.sha256(before).hexdigest() if before else None,
                    'after_sha256':hashlib.sha256(after).hexdigest(),
                    'before_bytes':len(before),'after_bytes':len(after)}
    summary['patch_sha256']=hashlib.sha256(patch.encode()).hexdigest()
    pins[root]=summary
(base/'pins.json').write_text(json.dumps(pins,indent=2)+'\n')
(base/'pins-output.json').write_text(json.dumps(pins,indent=2)+'\n')
