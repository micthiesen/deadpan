from pathlib import Path
import json,re
s=Path(__file__).resolve().parent;r=Path('/Users/michael/Code/deadpan')
audit=json.loads((s/'final-audit.json').read_text());assert audit['all_terminal']
archive=json.loads((s/'published-evidence.json').read_text())
pair=json.loads((s/'raw-new-host6-classification.json').read_text())
text=(s/'qualification-draft.md').read_text()
old="""The final complete 744-request captures must be recorded here after the final
native matrix. The preceding guarded native5 capture agrees across both roots:
264 exact successful payloads, 468 exact typed errors and 12 changed work-budget
errors, all confined to injected prior plan work. No new success, new refusal or
successful payload difference occurs. Final recapture and full audit are pending."""
new=f"""Both final complete 744-request captures agree after removing only variant
and source digest. The canonical body is {pair['canonical_bytes']:,} bytes,
SHA-256 {pair['canonical_sha256']}. It preserves 264 exact successful payloads
and 468 complete typed errors. Twelve changed work-budget errors occur only under
injected prior plan work; each reaches the same 13 provider calls as raw OLD.
No new success, new refusal or successful payload difference occurs.

All 744 requests compare complete non-budget caller, controller, cache and source
state, exact provider ordering, raw trace consistency and released leases.
All 664 non-injected requests reconcile their extra read work with direct raw
constructor fees and independent surrounding/host receipts. Across each complete
body, 360 plan-lane constructors accept 5,784 additional units and 40 cache-lane
constructors accept 632. Raw canonical, partial and host-eviction work are zero
in this corpus; focused native refusal and pressure tests cover actual nonzero
partial and eviction receipts separately.

The 80 injected-work requests remain explicit. Their 56 plan-lane arithmetic
differences against direct fees are not attributed to raw construction. Only
outside Original-query receipts change, on 32 requests; nested flattened and
processing receipts are not added together. The full audit retains every signed
work delta, complete receipt and exact changed typed error. This is not a
whole-read work or memory admission claim."""
assert text.count(old)==1;text=text.replace(old,new)
old="""Final native matrix, strict results, fresh Split research, exact shipping-source
audit and evidence inventory will be inserted after terminal verification."""
split=audit['split'];native_reuse=sum(audit['coverage'][v]['audio']['identical_reuses']for v in ['main','scoped'])
new=f"""Host: Apple M5 Max, Mac17,7, 128 GiB RAM, macOS 26.5.2 (25F84), arm64,
Rust/Cargo 1.97.1. Native Audio uses qualified FFmpeg 8.0.3 and ORT 1.31.0,
optimization level 2, debug assertions and overflow checks. Plan uses normal
optimization level 0. All {audit['native_runs']} recorded native executable invocations
are serial; complete named source inputs, binaries and streams retain before/
after identity guards.

All 29 Plan executables pass per root: Main 727 passed / 24 ignored, isolated
714 / 24. The changed libraries pass 277/264; 28 integration executable passes
per root reuse identical final bytes. All 21 native Audio executables pass per
root: Main 1,018 passed / 10 ignored, isolated 1,012 / 10. These include libraries
437/431, ordinary stages 203, definition/history 171 and 207 smaller integration
tests per root. There are {native_reuse} byte-identical native result reuses.

Main cargo xtask check --no-test and isolated explicit all-target Plan/Audio
Clippy with -D warnings pass. The isolated filesystem copy has no .git, so the
Git-based package selector is not invoked there. Formatting, both crates'
doctests and hygiene pass. No UI or native release bundle is rebuilt for this
backend unit.

Fresh seven-case Split research reports {split['passed']} pass/{split['failed']} fail in
{split['seconds']:.2f} seconds:

- Source/Sequence refinement, cut-three, 0+511: plan work per read.
- Nested selected play without root sound, prefix-two, 0+4,096: plan work per read.
- One selected play, prefix-two, 0+4,096: sound route work.
- Processed root sound, root-sound-refinement, 0+511: source occurrence construction work.

These are research results, separate from the ordinary shipping stage suite.
Full failures remain in the archived stdout/stderr. General sound-bearing Split
stays disabled.

Every one of the 30 staged source/fixture blobs equals the isolated candidate.
Only Main's plan.rs differs from its staged counterpart because unrelated
working-tree module changes remain unpublished. Main's 2,821 and the isolated
copy's 2,493 initial unowned named source inputs remain exact; all 23 oracle
bodies retain their hashes.

The [evidence inventory](../../tools/media-qualification/evidence/2026-10-31-raw-domain-query/inventory.json)
contains {archive['files']:,} verified compressed records ({archive['stored_bytes']:,} stored bytes;
{archive['expanded_bytes']:,} expanded), SHA-256
{archive['inventory_sha256']}.
It pins the preceding retained-fade inventory and retains OLD/NEW bodies, source/
binary/media identities, accepted-work audits, commands, failed attempts, reviews
and the exact scoped shipping patch. Executables and the unrelated whole-index
listing are excluded. Every archived record is re-expanded and hash-checked."""
assert text.count(old)==1;text=text.replace(old,new)
assert 'pending'not in text and 'will be inserted'not in text
q=r/'docs/qualification/raw-domain-query-admission-2026-10-31.md';assert not q.exists();q.write_text(text)
handoff=r/'docs/spec/AGENT_HANDOFF.md';old=handoff.read_text()
anchor='## Current state: retained fades admitted, product goal active\n'
assert old.count(anchor)==1
section="""## Current state: raw domains admitted, product goal active

The [raw-domain checkpoint](../qualification/raw-domain-query-admission-2026-10-31.md)
exposes the existing admitted fresh Bound constructor through a sealed carrier.
Native Root transfer borrows it; Root/Point consumption retains its lease until
the read ends. The fixed 65,536 allowance, zero canonical work and literal stored
Bound/Core work remain unchanged. Additional finite metadata is charged once.
No production cap, canonical weight, DSP or persisted format changes.

Two pre-implementation witnesses retain 77 complete ordinary Root/Point operands
and 744 actual native requests. All 23 oracle hashes stay exact. Public false/
true parity, exact/short work and Layout limits, callback refusal/cancellation/
issuer sweeps and real-ledger phase checks pass. All 59 Root evaluation
replacement selectors in that corpus are None; no Some or Empty is fabricated.
Seven new real-WAV tests verify actual native carrier lifetime, error cleanup,
local refusal, genuine silent Hold bypass, cache re-admission and actual eviction.

Both final native bodies agree: 264 successful payloads and 468 typed errors are
unchanged; 12 work-budget errors differ only with injected prior plan work and
reach the same provider events. All 664 non-injected requests reconcile direct
fees. The 80 injected requests retain their surrounding work separately; nested
Original receipts are not added or called whole-read admission.

Main/isolated Plan pass 727/714 across 29 targets each, 24 ignored each; native
Audio passes 1,018/1,012 across 21 each, 10 ignored each. Strict checks,
formatting, doctests, hygiene, independent reviews and final source/index/evidence
audits pass. The qualification records the fresh Split research failures;
general sound-bearing Split stays disabled. All 30 shipping blobs equal the
isolated candidate and Main's unrelated working-tree research remains intact.

Next remove the unnecessary Point::signal clone in the synchronous native
Point reader by borrowing its already leased stored signal. Preserve the public
owning clone method. The current immutable private Point snapshots and native
captures supply the before witness. Recursive Signal/Tape/Mix/Source/
Occurrence/Projected products, general Graph containers, full preparation and
the remaining specification remain open. No requirement or Gate closes;
the full DP-01..24/Gates A..G goal stays active.

"""
handoff.write_text(old.replace(anchor,section+'## Retained fades admitted (historical)\n'))
requirements=r/'docs/REQUIREMENTS.md';old=requirements.read_text()
anchor='The following paragraphs retain the earlier preparation checkpoints and their\noriginal three-pass/four-fail results.\n'
assert old.count(anchor)==1
new="""The [fresh raw-domain checkpoint](qualification/raw-domain-query-admission-2026-10-31.md)
admits the actual standalone Bound reconstruction and retains its sealed carrier
through native Root/Point consumption. Root transfer borrows its already leased
domain. False mode preserves the ordinary algorithm; true mode retains zero
canonical work, literal stored work and the fixed local allowance. Pre-change
witnesses preserve 77 complete actual Root/Point operands and 744 real-WAV native
requests; all 23 oracle hashes stay exact. Exact/short limits, callback-prefix/
issuer failures, selected live heap overlap and seven real native lifetime/cache/
eviction tests pass. Final Main/isolated native bodies agree: 264 same successful
payloads, 468 same typed errors, 12 differing work-budget errors only under
injected prior work. All 664 non-injected requests reconcile direct constructor
fees; the other 80 retain surrounding Original work separately. Plan passes
727/714 and Audio 1,018/1,012, with strict checks, formatting, doctests, hygiene,
reviews and exact scoped source/evidence audits. General sound-bearing Split
stays disabled. The later Point signal clone, recursive products and complete
preparation remain open. No cap, prior weight, refund, requirement/Gate status
or speed/RSS claim changes.

"""
requirements.write_text(old.replace(anchor,new+anchor))
print('Wrote qualification and updated handoff/requirements without changing statuses')
