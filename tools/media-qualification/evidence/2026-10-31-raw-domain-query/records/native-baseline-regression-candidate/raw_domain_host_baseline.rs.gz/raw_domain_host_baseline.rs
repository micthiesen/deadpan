//! Frozen native behavior before admitting fresh Bound raw-domain metadata.
use super::*;

const SHA256: &str = "2f57d0404dad1cb2d33054958d0578f67dd9e2ecc154a1d17fd2824d65700745";

fn expected() -> Value {
    let bytes = include_bytes!("../../tests/fixtures/raw-domain-host-baseline-v1/snapshot.json");
    assert_eq!(hex(Sha256::digest(bytes)), SHA256);
    serde_json::from_slice(bytes).unwrap()
}

#[test]
fn complete_pre_raw_native_body_keeps_current_fades_and_owners() {
    let expected = expected();
    let mut actual = raw_domain_request::with_legacy_raw_domain(|| {
        current_body("raw-domain-regression", &"0".repeat(64))
    });
    actual.as_object_mut().unwrap().remove("variant");
    actual.as_object_mut().unwrap().remove("source_sha256");
    assert_eq!(actual, expected, "complete frozen raw-domain caller body");
}
