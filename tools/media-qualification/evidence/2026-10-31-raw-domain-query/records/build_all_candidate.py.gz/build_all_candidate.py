from pathlib import Path
import subprocess,sys
s=Path(__file__).resolve().parent;v=sys.argv[1];assert v in ['main','scoped']
qualified='run_qualified.py'if v=='main'else'run_scoped_qualified.py'
logic='run_main_logic.py'if v=='main'else'run_scoped_logic.py'
if v=='main':
 subprocess.run(['python3',str(s/qualified),'retained-strict-main-third','--','cargo','xtask','check','--no-test'],check=True)
else:
 subprocess.run(['python3',str(s/qualified),'retained-format-scoped','--','cargo','fmt','--all','--','--check'],check=True)
 subprocess.run(['python3',str(s/qualified),'retained-strict-scoped-equivalent','--','cargo','clippy','-p','deadpan-plan','-p','deadpan-audio','--all-targets','--locked','--','-D','warnings'],check=True)
for package,runner in [('plan',logic),('audio',qualified)]:
 label=f'retained-all-{v}-{package}-build'
 subprocess.run(['python3',str(s/runner),label,'--','cargo','test','-p',f'deadpan-{package}','--no-run','--message-format=json'],check=True)
 subprocess.run(['python3',str(s/'pin.py'),label],check=True)
