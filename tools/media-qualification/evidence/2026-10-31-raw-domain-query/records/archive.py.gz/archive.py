from pathlib import Path
import gzip,hashlib,json
s=Path(__file__).resolve().parent
repo=Path('/Users/michael/Code/deadpan')
dest=repo/'tools/media-qualification/evidence/2026-10-31-raw-domain-query'
assert not(dest/'inventory.json').exists()
audit=json.loads((s/'final-audit.json').read_text());assert audit['all_terminal']
prior=repo/'tools/media-qualification/evidence/2026-10-31-retained-fade-query/inventory.json'
prior_sha='b1040fe261d8454d767788c7b25c0f066e1c6e60e0934a7b341a2b67f19f96a1'
assert hashlib.sha256(prior.read_bytes()).hexdigest()==prior_sha
allowed={'.rs','.json','.py','.md','.patch','.stdout','.stderr','.txt','.sha256','.toml','.sh'}
rows=[]
for p in sorted(s.rglob('*')):
 if not p.is_file()or p.suffix not in allowed:continue
 rel=p.relative_to(s)
 if rel.name in {'qualification-draft.md','published-evidence.json','index-source-entries.txt'}:continue
 data=p.read_bytes()
 if p.suffix=='.json':
  if str(rel)=='phase-test-candidate/prepare-run.json':
   assert data==b'', 'known failed preparer stub must remain empty'
   obj=None
  else:
   obj=json.loads(data)
  if isinstance(obj,dict)and'command'in obj and'started_at'in obj:
   assert'exit_code'in obj and obj['sources_unchanged']and obj['binaries_unchanged'],str(p)
 target=(dest/'records'/rel).with_name(rel.name+'.gz')
 target.parent.mkdir(parents=True,exist_ok=True);assert not target.exists()
 packed=gzip.compress(data,mtime=0);target.write_bytes(packed)
 rows.append({'path':str(target.relative_to(dest)),'bytes':len(packed),'sha256':hashlib.sha256(packed).hexdigest(),'expanded_bytes':len(data),'expanded_sha256':hashlib.sha256(data).hexdigest()})
manifest={'schema_version':1,'base_revision':(s/'base-revision.txt').read_text().strip(),
'scope':'Fresh Bound raw-domain admission and actual native retained carrier lifetime, borrowed Root transfer, independent canonical-zero constructor fees and bounded test liveness. No cap, prior weight, refund, DSP, persisted format or requirement/Gate status changes. Point signal cloning, recursive preparation and full product goal remain open. General sound-bearing Split stays disabled.',
'prior_retained_fade_inventory':{'path':'../2026-10-31-retained-fade-query/inventory.json','sha256':prior_sha},
'exclusions':'Native executables and nontext files excluded. Whole repository index entries excluded; the exact 30-file scoped shipping patch, staged blob equality and tree are retained. Complete immutable OLD captures, separately identified initial/final NEW captures, source/binary/media/stream pins, commands/environment/timing, failed attempts, candidate provenance failures, repairs and reviews remain. The first weak phase build source list omitted the new phase file and receives no acceptance credit. Its empty phase-test-candidate/prepare-run.json preparer stub is retained as opaque zero bytes, never an execution receipt or acceptance evidence. Scratch candidate historical copies overwritten by their worker are not authoritative; actual first integrated roots and the parent repair are retained. v1 work auditor compared the older pair accounting lane and had a vacuous liveness check; corrected parent audits use the frozen raw OLD paired.new and real raw receipt. Nonzero runs are explicit failures or research results. Test pass reuse requires identical final executable bytes.',
'files':rows}
assert{str(p.relative_to(dest))for p in dest.rglob('*')if p.is_file()}=={r['path']for r in rows}
p=dest/'inventory.json';p.write_text(json.dumps(manifest,indent=2)+'\n')
for row in rows:
 packed=(dest/row['path']).read_bytes();plain=gzip.decompress(packed)
 assert len(packed)==row['bytes']and hashlib.sha256(packed).hexdigest()==row['sha256']
 assert len(plain)==row['expanded_bytes']and hashlib.sha256(plain).hexdigest()==row['expanded_sha256']
out={'files':len(rows),'stored_bytes':sum(r['bytes']for r in rows),'expanded_bytes':sum(r['expanded_bytes']for r in rows),'inventory_sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
(s/'published-evidence.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out))
