from pathlib import Path
import hashlib, json, difflib
base=Path('/tmp/deadpan-raw-domain-query-admission-2026-10-31')
candidate=base/'production-candidate'
roots={'main':Path('/Users/michael/Code/deadpan'),
       'scoped':Path('/tmp/deadpan-query-groundwork-2026-10-26/scoped')}
paths=[
'crates/deadpan-plan/src/audio_bound_probe.rs',
'crates/deadpan-plan/src/audio_bound.rs',
'crates/deadpan-plan/src/plan.rs',
'crates/deadpan-audio/src/domain_transfer.rs',
'crates/deadpan-audio/src/stages.rs',
'crates/deadpan-audio/src/retained_request.rs',
'crates/deadpan-audio/src/original_request.rs',
'crates/deadpan-audio/src/raw_domain_request.rs',
'crates/deadpan-audio/src/raw_domain_query_trace.rs',
]
for v,root in roots.items():
 manifest=[]
 diffs=[]
 for rel in paths:
  after=(candidate/v/rel).read_bytes()
  before_path=root/rel
  if before_path.exists():
   before=before_path.read_bytes()
   before_sha=hashlib.sha256(before).hexdigest()
   old=before.decode().splitlines(keepends=True)
  else:
   before=b''
   before_sha=None
   old=[]
  after_sha=hashlib.sha256(after).hexdigest()
  manifest.append({'path':rel,'before_exists':before_path.exists(),'before_bytes':len(before),'before_sha256':before_sha,'after_bytes':len(after),'after_sha256':after_sha})
  if before != after:
   diffs.extend(difflib.unified_diff(old,after.decode().splitlines(keepends=True),fromfile='a/'+rel,tofile='b/'+rel))
 (candidate/'patches'/f'{v}.patch').write_text(''.join(diffs))
 (candidate/f'{v}-pins.json').write_text(json.dumps({'root':str(root),'files':manifest},indent=2)+chr(10))
