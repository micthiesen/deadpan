from pathlib import Path
import subprocess
s=Path(__file__).resolve().parent
for v in ['scoped','main']:
 build=f'raw-native5-{v}-build'
 for filter_,tag in [('raw_domain_lifetime_tests::','lifetime'),('raw_domain_gap_tests::','gaps')]:
  subprocess.run(['python3',str(s/'run_target.py'),build,v,'audio','deadpan_audio',f'raw-native5-{v}-{tag}',filter_,'--test-threads=1'],check=True)
