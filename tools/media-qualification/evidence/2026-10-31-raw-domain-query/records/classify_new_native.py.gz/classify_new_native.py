from pathlib import Path
import json,hashlib,collections
s=Path(__file__).resolve().parent
bodies=[]
for v in ['main','scoped']:
 d=json.loads((s/f'raw-new-host-{v}-body.json').read_text())
 for k in ['variant','source_sha256']:del d[k]
 bodies.append(d)
assert bodies[0]==bodies[1]
data=(json.dumps(bodies[0],sort_keys=True,separators=(',',':'))+'\n').encode();sha=hashlib.sha256(data).hexdigest()
(s/'raw-new-host-canonical-body.json').write_bytes(data)
old=json.loads((s/'raw-old-host-canonical-body.json').read_text())
counts=collections.Counter();changes=[];rawcounts=collections.Counter();seen=0
for case in bodies[0]['cases']:
 prior=next(x for x in old['cases']if x['fixture']==case['fixture'])
 assert len(case['operations'])==len(prior['operations'])
 for i,row in enumerate(case['operations']):
  p=prior['operations'][i];n=row['paired']['new'];o=p['paired']['new'];q=row['paired']['receipts']['raw_domain']
  assert row['old_operation_index']==p['old_operation_index']==i
  assert row['old_request']==p['old_request']
  assert n['read']['request']==o['read']['request']
  for field in ['nested','invalid','overflow']:assert q[field]is False,(case['fixture'],i,field)
  assert q['active_depth']==0 and q['max_active_depth']<=1
  for lane in ['plan','cache']:
   x=q[lane]
   assert x['constructor_calls']==x['completed_queries']+x['ordinary_calls']+x['failed_queries']
   assert x['admitted_calls']==x['completed_queries'] and x['ordinary_calls']==0
   assert x['canonical_units']==0
   assert x['accepted_work']==x['additional_units']+x['partial_work']+x['host_eviction_work']
   assert sum(x['kind_counts'])==x['completed_queries']
   for k in ['constructor_calls','completed_queries','failed_queries','partial_work','host_eviction_work','additional_units']:rawcounts[(lane,k)]+=x[k]
  a=n['read']['output'];b=o['read']['output']
  if a==b:k='same_complete_success'if a['status']=='Ok'else'same_complete_typed_error'
  elif a['status']=='Error'and b['status']=='Ok':k='new_refusal'
  elif a['status']=='Error'and b['status']=='Error':k='different_typed_error'
  else:k='unexpected_success_difference'
  counts[k]+=1;seen+=1
  if k not in ['same_complete_success','same_complete_typed_error']:
   changes.append({'fixture':case['fixture'],'index':i,'mode':row['mode'],'authored':row['authored'],'fault':row['old_request']['fault'],'classification':k,'old_status':b['status'],'old_error':b.get('error'),'new_error':a.get('error'),'old_provider_calls':o['provider_calls'],'new_provider_calls':n['provider_calls'],'raw':q})
assert seen==744
out={'full_main_scoped_equality':True,'removed_only':['variant','source_sha256'],'canonical_bytes':len(data),'canonical_sha256':sha,'operations':seen,'classifications':dict(counts),'raw_totals':[{'lane':a,'field':b,'value':v}for(a,b),v in sorted(rawcounts.items())],'changed_rows':changes}
(s/'raw-new-host-classification.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({k:v for k,v in out.items()if k not in ['changed_rows','raw_totals']}))
print('changed fault counts',dict(collections.Counter((x['classification'],x['fault'])for x in changes)))
print('raw totals',dict((str(k),v)for k,v in rawcounts.items()))
