# Public raw-domain admission acceptance candidate

Scratch-only tests against the independently frozen Plan OLD body
`raw-domain-query-baseline-v1/snapshot.json`, SHA-256
`4f5d102d00454c81282f6ead82824d2984e626888ed8013d2de9452eccee8d0c`.
No production, actual-root, fixture, Git or network writes were made. No build,
type check or native execution was performed by this worker.

## Integration

The candidate contains the complete new
`crates/deadpan-plan/src/audio_owners/raw_domain_admission_tests.rs`, exact
per-root patches and full before/current `raw_domain_baseline.rs` files.
`pins/candidates.json` records all SHA-256 identities, including the immutable
golden and inspected production API candidate. The current root already contains
the public API with parent's `crate::LookupStats` compiler fix; its hash is
separately pinned from the initial production candidate. Neither is overwritten
by this test patch.

1. Check the current target against `before_target_sha256` for the selected root.
2. Apply `patches/main-inherited.patch` or `patches/scoped-published.patch` to its
   matching root. It adds exactly one default-off observer call after the actual
   Bound before/after assertion in `reconstruct`, and a private child declaration.
   If a concurrent phase test has added its own observer, preserve that addition
   and merge these two narrow hooks by their current text; do not replace the
   whole file from this candidate.
3. Build/type-check only under parent's serial native guard. Run the three exact
   tests below with `--exact --test-threads=1` on each actual Plan test binary.
   Run existing raw OLD external/frozen regressions with the admission observer
   off, and the appropriate complete Plan suites after focused tests pass.
4. Keep all 23 existing oracle bodies/pins immutable. The new tests read the
   frozen raw body; no test writes or regenerates it.

Exact test prefix:

```text
plan::audio_owners::wide_gain_query_admission_tests::retained_fade_baseline::raw_domain_baseline::admission_tests::
```

Append these test names individually:

```text
public_false_and_true_match_all_77_frozen_operands_without_rebilling
public_exact_and_one_short_work_and_requested_peak_for_all_77
public_every_callback_refusal_cancellation_and_issuer_rotation_for_all_77
```

No environment fields or expected-output generation are required. Each test
explicitly enables its own thread-local observer, invokes the existing actual
matrix once and compares its complete returned body to the immutable OLD JSON.
Normal frozen regressions leave this observer off. Unwinding clears the test
observer, as well as the original collector's existing reset behavior.

## Assertions

The actual traversal is checked against all 77 frozen Bound rows, in exact
sequence: 54 actual retained Some from their four real owning origins, eight
Root processing, seven Domain processing and eight Root Signal operands. Each
mode asserts 59 Root and 18 Point results. Each callback runs while the parent
owns the same Bound and original input/query carrier. Cloning an Rc to inspect a
caller ledger does not clone or substitute its lease. Full caller state is
checked before/after every callback and after cleanup. Full Bound and literal
resolved/lattice work are checked before/after each observer. Complete matrix
equality also preserves input/cached raw data and genuine setup None/rejections.

False calls use a poisoned zero-cap policy. Domain output must equal all frozen
Root fields or the borrowed private Point/Structural Signal fields. Canonical,
additional and total are zero, forwarded is false, issuer reads are zero, no
spend/reserve/merge callback occurs, and the policy/caller ledgers stay identical.

True baseline calls compare every result field, canonical zero and
additional=total=accepted work against the independent OLD helper's literal fees.
All original Bound/Core work remains separate. Callback events retain requested
Layout size/alignment, exact merge source/target sizes, accepted flag and owning
live/peak/reservation/work counters before and after the actual issuing policy.
The existing Policy/Lease performs accounting; the recorder does not implement a
second lease ledger. All same-issuer relationships are asserted at reservation
and merge, and all result leases are zero after drop.

The complete frozen helper event sequence must be the public query's exact
prefix. The only allowed public extension is one explicitly recognized accepted
`spend(0)` at the final seal, with unchanged live/peak/work total and exactly one
extra work callback. Its before-state is the frozen helper's live-result state.
It remains in the full public event sequence, and all refusal, cancellation and
rotation sweeps include it. Nothing subtracts its callback, bills its zero units
as a positive fee or silently discards it. The public tail must be uniform across
all 77 actual successful calls.

Work caps use the external policy's accepted-work cap, because the public query
preserves the fixed 65,536 internal allowance. Frozen fees range from 11 to 30.
The exact work cap succeeds with the complete public event sequence; one unit
less fails at the independently predicted first overflowing spend, with exact
typed error and prefix. Residency caps similarly use the OLD helper's requested
peak: exact succeeds, one byte less fails at the independently predicted first
reservation crossing that cap. These are requested logical Layout charges, not
allocator/RSS measurements or a cap increase.

Every actual spend and reserve callback is separately refused. Every spend is
also cancelled by its explicit callback ordinal, including a zero-unit public
seal if present. Every spend, reserve and merge rotates the policy's issuer in
its own run. Each case asserts its exact typed error, complete accepted prefix,
exact final rejected or accepted-rotation event, no later callback, unchanged
caller, accepted work retained on the issuing state, and zero leases in both old
and new issuer states after cleanup. Merge is infallible, so only its authentic
issuer-rotation boundary is tested.

The frozen helper contains 1,343 spend, 481 reserve and 327 merge callbacks. The
failure test requires exactly 5,318 fault attempts if there is no public seal,
or 5,549 when every successful public call adds its zero-unit seal. These totals
are derived directly from the frozen rows and explicit observed seal count.

## Limits and owed checks

- Rustfmt parsed and checked the scratch files; exact patch/pin checks are in
  `validation.json`. Rust name resolution, borrow/type checking, all test runs,
  timing and cleanup execution remain parent-owned and unperformed here.
- All 77 independently frozen raw constructions succeed. No genuine Empty or
  ordinary raw-constructor validation error was reached. The false test has a
  typed-error comparison branch, but there is no claim of executed validation-
  error coverage. Genuine setup None/rejection/error data remains in the full
  matrix. No synthetic invalid Bound is introduced merely to claim that lane.
- The public fixed local allowance has no test parameter. These tests use real
  independent fees and external policy work limits; they do not invent a large
  input to force local 65,536 exhaustion or Layout overflow.
- Public error calls expose no completed receipt. Accepted partial work is
  asserted from the actual issuing policy and callback prefix, including old
  and new issuer states, without fabricating a returned receipt.
- This worker does not add phase Layout/overlap tests or native lifetime/cache/
  provider tests. Those remain the parent's separate owned work.
