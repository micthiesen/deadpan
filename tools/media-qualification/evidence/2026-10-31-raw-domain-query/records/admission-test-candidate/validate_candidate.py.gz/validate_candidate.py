from pathlib import Path
import hashlib
import json
import re

base = Path(__file__).resolve().parent
pins = json.loads((base / "pins/candidates.json").read_text())
target = Path("crates/deadpan-plan/src/audio_owners/raw_domain_baseline.rs")
module = Path("crates/deadpan-plan/src/audio_owners/raw_domain_admission_tests.rs")

def sha(data):
    return hashlib.sha256(data).hexdigest()

def apply_one(before, lines, index):
    source = before.splitlines(keepends=True)
    output = []
    cursor = 0
    while index < len(lines) and lines[index].startswith("@@"):
        match = re.match(r"@@ -(\d+)(?:,(\d+))? \+(\d+)(?:,(\d+))? @@", lines[index])
        assert match
        old_start, old_count, _, new_count = match.groups()
        old_count, new_count = int(old_count or 1), int(new_count or 1)
        start = int(old_start) - 1 if old_count else int(old_start)
        assert start >= cursor
        output.extend(source[cursor:start])
        cursor = start
        seen_old = seen_new = 0
        index += 1
        while index < len(lines) and not lines[index].startswith(("@@", "--- ")):
            kind, text = lines[index][0], lines[index][1:]
            assert kind in " +-"
            if kind in " -":
                assert cursor < len(source) and source[cursor] == text
                seen_old += 1
                cursor += 1
            if kind in " +":
                output.append(text)
                seen_new += 1
            index += 1
        assert (seen_old, seen_new) == (old_count, new_count)
    output.extend(source[cursor:])
    return "".join(output), index

report = {}
for variant, pin in pins["variants"].items():
    before = (base / "before" / variant / target).read_text()
    current = (base / "current" / variant / target).read_text()
    new = (base / "new" / module).read_text()
    patch = (base / "patches" / (variant + ".patch")).read_text()
    for value, field in ((before, "before_target_sha256"), (current, "candidate_target_sha256"),
                         (new, "new_module_sha256"), (patch, "patch_sha256")):
        assert sha(value.encode()) == pin[field]
    lines = patch.splitlines(keepends=True)
    assert lines[:2] == ["--- a/" + str(target) + "\n", "+++ b/" + str(target) + "\n"]
    applied, at = apply_one(before, lines, 2)
    assert applied == current
    assert lines[at:at+2] == ["--- /dev/null\n", "+++ b/" + str(module) + "\n"]
    applied, at = apply_one("", lines, at + 2)
    assert applied == new and at == len(lines)
    report[variant] = {"file_pins": "passed", "exact_patch_roundtrip": "passed"}

report["checks"] = {"rustfmt_scratch_parse_check": "passed", "type_check": "not performed",
                    "build": "not performed", "native_execution": "not performed",
                    "git_network": "not performed", "expected_body_generation": False}
(base / "validation.json").write_text(json.dumps(report, indent=2) + "\n")
print(json.dumps(report, indent=2))
