from pathlib import Path
import difflib
import hashlib
import json

BASE = Path(__file__).resolve().parent
ROOTS = {
    "main-inherited": (Path("/Users/michael/Code/deadpan"), "main"),
    "scoped-published": (Path("/tmp/deadpan-query-groundwork-2026-10-26/scoped"), "scoped"),
}
TARGET = Path("crates/deadpan-plan/src/audio_owners/raw_domain_baseline.rs")
NEW = Path("crates/deadpan-plan/src/audio_owners/raw_domain_admission_tests.rs")
GOLDEN = Path("crates/deadpan-plan/tests/fixtures/raw-domain-query-baseline-v1/snapshot.json")
PROBE = Path("crates/deadpan-plan/src/audio_bound_probe.rs")

def sha(data):
    return hashlib.sha256(data).hexdigest()

def write(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(value)

new = (BASE / "new" / NEW).read_text()
pins = {"variants": {}}
for variant, (root, production_variant) in ROOTS.items():
    before = (root / TARGET).read_text()
    anchor = "    assert_eq!(bound_before, bound_after);\n"
    assert before.count(anchor) == 1
    after = before.replace(anchor, anchor + "    admission_tests::observe(plan, bound, caller);\n", 1)
    after += '\n#[path = "raw_domain_admission_tests.rs"]\nmod admission_tests;\n'
    write(BASE / "before" / variant / TARGET, before)
    write(BASE / "current" / variant / TARGET, after)
    patch = "".join(difflib.unified_diff(
        before.splitlines(keepends=True), after.splitlines(keepends=True),
        fromfile="a/" + str(TARGET), tofile="b/" + str(TARGET)))
    patch += "".join(difflib.unified_diff(
        [], new.splitlines(keepends=True), fromfile="/dev/null", tofile="b/" + str(NEW)))
    write(BASE / "patches" / (variant + ".patch"), patch)
    golden = (root / GOLDEN).read_bytes()
    assert sha(golden) == "4f5d102d00454c81282f6ead82824d2984e626888ed8013d2de9452eccee8d0c"
    production = BASE.parent / "production-candidate" / production_variant / PROBE
    pins["variants"][variant] = {
        "root": str(root), "before_target_sha256": sha(before.encode()),
        "candidate_target_sha256": sha(after.encode()), "new_module_sha256": sha(new.encode()),
        "patch_sha256": sha(patch.encode()), "golden_sha256": sha(golden),
        "production_probe_candidate_sha256": sha(production.read_bytes()),
        "actual_probe_before_sha256": sha((root / PROBE).read_bytes()),
    }
write(BASE / "pins/candidates.json", json.dumps(pins, indent=2) + "\n")
print(json.dumps(pins, indent=2))
