//! Fixed-size test-only Layout lower bounds at real constructor overlap phases.
use super::*;
use crate::{AudioOwnerInput, AudioOwnerRetainedInput};
use deadpan_core::RepeatInstance;
use std::{alloc::Layout, cell::RefCell};

#[derive(Clone, Copy, Debug)]
#[repr(usize)]
enum Phase {
    TemporaryDefinition,
    RootInitial,
    RootSelectorReplacement,
    RootRepeatReplacement,
    RootConstraintReplacement,
    RootInstanceReplacement,
    PointInitial,
    PointEvaluationReplacement,
}
pub(in crate::plan) const PHASES: usize = 8;
#[derive(Clone, Copy, Debug, Default)]
pub(in crate::plan) struct Count {
    pub(in crate::plan) calls: usize,
    pub(in crate::plan) overlap_calls: usize,
    pub(in crate::plan) selector_pairs: usize,
    pub(in crate::plan) max_total_lower_bound: usize,
    pub(in crate::plan) max_old_arrays: usize,
    pub(in crate::plan) max_new_arrays: usize,
}
#[derive(Clone, Copy, Debug, Default)]
pub(in crate::plan) struct Summary {
    pub(in crate::plan) phases: [Count; PHASES],
}
fn enabled() -> bool {
    ACTIVE.with(|slot| slot.borrow().is_some())
}
thread_local! { static ACTIVE: RefCell<Option<Summary>> = const { RefCell::new(None) }; static CARRIER: RefCell<Option<usize>> = const { RefCell::new(None) }; }

pub(in crate::plan) fn start() {
    ACTIVE.with(|slot| {
        assert!(slot.borrow().is_none());
        *slot.borrow_mut() = Some(Summary::default());
    });
}
pub(in crate::plan) fn finish() -> Summary {
    CARRIER.with(|slot| assert!(slot.borrow().is_none()));
    ACTIVE.with(|slot| slot.borrow_mut().take().expect("active phase trace"))
}
pub(in crate::plan) struct InputScope(bool);
impl InputScope {
    pub(in crate::plan) fn new(
        input: &AudioOwnerInput<'_>,
        retained: &AudioOwnerRetainedInput<'_>,
    ) -> Self {
        let active = ACTIVE.with(|slot| slot.borrow().is_some());
        if active {
            let bound = retained.bound();
            let bytes = sum(&[
                Layout::new::<AudioOwnerInput<'_>>().size(),
                Layout::new::<AudioOwnerRetainedInput<'_>>().size(),
                Layout::new::<AudioBound<'_>>().size(),
                root_arrays(input.context()),
                array::<RepeatInstance>(bound.instance.repeats.capacity()),
                array::<crate::plan::audio::EnvelopeConstraint>(bound.constraints.capacity()),
            ]);
            CARRIER.with(|slot| {
                assert!(slot.borrow().is_none());
                *slot.borrow_mut() = Some(bytes);
            });
        }
        Self(active)
    }
}
impl Drop for InputScope {
    fn drop(&mut self) {
        if self.0 {
            CARRIER.with(|slot| assert!(slot.borrow_mut().take().is_some()));
        }
    }
}
fn array<T>(len: usize) -> usize {
    Layout::array::<T>(len).expect("actual Vec layout").size()
}
fn sum(parts: &[usize]) -> usize {
    parts
        .iter()
        .try_fold(0usize, |a, b| a.checked_add(*b))
        .expect("actual-layout lower-bound sum")
}
fn record(phase: Phase, old: usize, new: usize, inline: usize) {
    ACTIVE.with(|slot| {
        let mut state = slot.borrow_mut();
        let Some(state) = state.as_mut() else {
            return;
        };
        let carrier = CARRIER.with(|slot| {
            slot.borrow()
                .expect("phase call remains under actual input carrier")
        });
        let count = &mut state.phases[phase as usize];
        count.calls += 1;
        if old > 0 && new > 0 {
            count.overlap_calls += 1;
        }
        count.max_old_arrays = count.max_old_arrays.max(old);
        count.max_new_arrays = count.max_new_arrays.max(new);
        count.max_total_lower_bound = count
            .max_total_lower_bound
            .max(sum(&[carrier, inline, old, new]));
    });
}
fn root_arrays(domain: &AudioDomain<'_>) -> usize {
    let seed = &domain.seed;
    sum(&[
        array::<crate::plan::audio::EnvelopeConstraint>(seed.constraints.capacity()),
        array::<crate::plan::audio::EditorialConstraint>(seed.editorial.capacity()),
        array::<RepeatInstance>(seed.repeats.capacity()),
        array::<crate::AudioRetimeStage>(seed.retimes.capacity()),
        array::<RepeatInstance>(domain.instance.repeats.capacity()),
    ])
}
pub(super) fn temporary_definition<A: AudioSoundContextAdmission>(
    definition: &AudioDefinition<'_>,
) {
    if !enabled() {
        return;
    }
    if A::METERED {
        let _ = definition.selector();
        record(
            Phase::TemporaryDefinition,
            0,
            0,
            Layout::new::<AudioDefinition<'_>>().size(),
        );
    }
}
pub(super) fn root_initial(domain: &AudioDomain<'_>, _definition: &AudioDefinition<'_>) {
    if !enabled() {
        return;
    }
    record(
        Phase::RootInitial,
        root_arrays(domain),
        0,
        Layout::new::<AudioDomain<'_>>().size() + Layout::new::<AudioDefinition<'_>>().size(),
    );
}
pub(super) fn root_selector(domain: &AudioDomain<'_>, next: Option<&AudioDefinitionSelector>) {
    if !enabled() {
        return;
    }
    assert!(
        domain.seed.definition.is_some(),
        "actual old Root selector is present"
    );
    let _new_selector = next;
    record(
        Phase::RootSelectorReplacement,
        0,
        0,
        Layout::new::<AudioDomain<'_>>().size()
            + Layout::new::<AudioDefinition<'_>>().size()
            + Layout::new::<Option<AudioDefinitionSelector>>().size(),
    );
    ACTIVE.with(|slot| {
        slot.borrow_mut().as_mut().unwrap().phases[Phase::RootSelectorReplacement as usize]
            .selector_pairs += 1
    });
}
pub(super) fn root_repeats(domain: &AudioDomain<'_>, next: &Vec<RepeatInstance>) {
    if !enabled() {
        return;
    }
    record(
        Phase::RootRepeatReplacement,
        root_arrays(domain),
        array::<RepeatInstance>(next.capacity()),
        Layout::new::<AudioDomain<'_>>().size() + Layout::new::<AudioDefinition<'_>>().size(),
    );
}
pub(super) fn root_constraints(
    domain: &AudioDomain<'_>,
    next: &Vec<crate::plan::audio::EnvelopeConstraint>,
) {
    if !enabled() {
        return;
    }
    record(
        Phase::RootConstraintReplacement,
        root_arrays(domain),
        array::<crate::plan::audio::EnvelopeConstraint>(next.capacity()),
        Layout::new::<AudioDomain<'_>>().size() + Layout::new::<AudioDefinition<'_>>().size(),
    );
}
pub(super) fn root_instance(domain: &AudioDomain<'_>, next: &deadpan_core::InstancePath) {
    if !enabled() {
        return;
    }
    record(
        Phase::RootInstanceReplacement,
        root_arrays(domain),
        array::<RepeatInstance>(next.repeats.capacity()),
        Layout::new::<AudioDomain<'_>>().size()
            + Layout::new::<AudioDefinition<'_>>().size()
            + Layout::new::<deadpan_core::InstancePath>().size(),
    );
}
fn point_old_repeat_capacity(point: &AudioPointDomain<'_>) -> usize {
    point.probe_structural_repeat_capacity()
}
pub(super) fn point_initial(point: &AudioPointDomain<'_>, _definition: &AudioDefinition<'_>) {
    if !enabled() {
        return;
    }
    assert!(
        point.probe_structural_definition_present(),
        "actual initial Structural signal retains its selector"
    );
    let _top_selector = point.probe_top_selector();
    let old = array::<RepeatInstance>(point_old_repeat_capacity(point));
    record(
        Phase::PointInitial,
        old,
        0,
        Layout::new::<AudioPointDomain<'_>>().size() + Layout::new::<AudioDefinition<'_>>().size(),
    );
    ACTIVE.with(|slot| {
        slot.borrow_mut().as_mut().unwrap().phases[Phase::PointInitial as usize].selector_pairs += 1
    });
}
pub(super) fn point_evaluation(
    point: &AudioPointDomain<'_>,
    _definition: &AudioDefinition<'_>,
    selector: &Option<AudioDefinitionSelector>,
    next: &Vec<RepeatInstance>,
) {
    if !enabled() {
        return;
    }
    assert!(
        point.probe_structural_definition_present(),
        "old Structural selector overlaps replacement evaluation"
    );
    let _top_selector = point.probe_top_selector();
    let old = array::<RepeatInstance>(point.probe_structural_repeat_capacity());
    let new = array::<RepeatInstance>(next.capacity());
    record(
        Phase::PointEvaluationReplacement,
        old,
        new,
        Layout::new::<AudioPointDomain<'_>>().size()
            + Layout::new::<Option<AudioDefinitionSelector>>().size(),
    );
    assert!(
        selector
            .as_ref()
            .map_or(true, |value| value == point.probe_top_selector()),
        "the replacement selector, when present, is the actual Point top selector"
    );
    ACTIVE.with(|slot| {
        slot.borrow_mut().as_mut().unwrap().phases[Phase::PointEvaluationReplacement as usize]
            .selector_pairs += 1
    });
}
