# Point signal clone: next-boundary reconnaissance

## Finding and narrow direction

The one downstream clone is at deadpan-audio/src/stages.rs:1192-1198: read_point_domain_controlled passes &domain.signal() into read_signal. AudioPointDomain::signal() at deadpan-plan/src/audio_point_domain.rs:228-229 clones its stored AudioSignal.

For the newly admitted raw Point result, this helper runs from read_bound_at at stages.rs:1729-1731. The raw carrier remains in scope around the full synchronous RootSignalTransfer::render call. Its Point domain and signal therefore remain alive throughout read_point_domain_controlled and read_signal. read_signal takes an input convertible from &AudioSignal and only queries it by reference (query and policy at stages.rs:2780-2821); it returns an owned SignalBlock and retains no AudioSignal. The clone is unnecessary for this consumer.

Recommended narrow fix direction: provide an explicitly borrowed/scoped accessor on AudioPointDomain (prefer a hidden with_signal(|signal| ...) bridge at the deadpan-plan crate boundary, or a narrowly documented borrowed accessor) and have read_point_domain_controlled pass that reference to read_signal. This removes the allocation and keeps the raw result lease alive across the borrow. Leave public signal() clone semantics as-is. A new admitted clone carrier is unnecessary unless a future consumer must own/detach the signal.

The generic helper is also called by public read_point_domain at stages.rs:1124-1135 and by an internal test at stages.rs:3854-3864; replacing this one clone site gives those synchronous consumers the same no-copy behavior. The raw-bound use is covered by raw_domain_lifetime_tests.rs; test the Point path's lease while the borrowed query runs and verify release on source error/cancel. Do not alter the independent existing Point signal clone contract.

## Exact cloned fields and current admission machinery

AudioPointDomain owns signal: AudioSignal (audio_point_domain.rs:19-28). AudioSignal's structural clone in audio_signal.rs:825-865 copies:

- repeats: Vec<RepeatInstance> including the allocated vector and each RepeatInstance's owning NodeId/IterationId.
- definition: Option<AudioDefinitionSelector>, owning the selector's NodeId when present.
- gap: Option<DomainGap>, owning its optional IterationId/RevisionId allocation.
- support and sampling_support ranges (value fields, no heap payload); plan, root, booleans, transform, and bypass target are references/indices/copy values.
- provider is checked to be Structural and copied as the no-heap Structural variant.

The existing metered implementation is already present: AudioPointDomain::signal_admitted (audio_point_domain.rs:231-239) delegates to AudioSignal::point_signal_clone_admitted. It builds a QueryBudget under the caller's issuer; its repeated metadata and identity allocations use the common admission helpers, reserve layouts, and hold a RAII Owned lease. Additional work is counted; this clone adds no canonical work. The helper rejects non-Structural providers in metered mode and tests clone parity, exact peak budget, failure cleanup, and issuer rotation in policy_point_clone_tests.rs:77-140. That method and its QueryBudget are pub(in crate::plan), so deadpan-audio cannot directly call it or construct the required budget. If a future caller truly needs an owned Point signal, deadpan-plan would need a narrow opaque admitted carrier or scoped callback that constructs through this existing helper; do not expose QueryBudget.

## Caller and lifetime map

- stages.rs:1112-1135: public read_point_domain creates request control, calls read_point_domain_controlled, then returns an owned PointDomainAudioBlock.
- stages.rs:1165-1201: shared synchronous helper validates plan/depth/range, maps the retained sample labels, clones signal, calls read_signal, checks cancellation/deadline, returns owned SignalBlock.
- stages.rs:1624-1758: read_bound_at creates the admitted raw-domain carrier, borrows its Point domain at line 1701, and calls the helper inside the transfer render callback. The carrier remains alive until this call and the complete callback return.
- stages.rs:3854-3864: a direct internal test also calls the helper. It verifies PCM/dependency parity for a Point-domain read.

The overall Point domain's own signal and evaluation copies are already charged during AudioPointDomain::new_admitted and the later evaluation replacement in audio_bound_probe.rs:136-178. Keeping the downstream consumer borrowed adds no second lease and no work. By contrast, retaining the clone would require wiring an Admission using the same WorkControl, charging additional clone work/resident memory while the raw domain's lease is live, and holding the cloned signal's Owned carrier through read_signal.

## Baseline/test reference

- crates/deadpan-plan/src/audio_owners/policy_point_clone_tests.rs: exact owning clone accounting and issuer/failure cleanup for the existing admitted clone helper.
- crates/deadpan-audio/src/bound_reads/raw_domain_lifetime_tests.rs: newly added real WAV, Point/Root, success/error/cancel and raw-carrier lifetime coverage. It currently exercises the raw Point route but does not separately account the clone at read_point_domain_controlled.
- crates/deadpan-plan/src/audio_point_domain.rs:347-439: existing public signal() behavior, including PointCeil sample count/support/query semantics. Preserve these semantics.
- crates/deadpan-plan/src/audio_signal.rs:825-865: exact admitted clone recipe and lease behavior.
