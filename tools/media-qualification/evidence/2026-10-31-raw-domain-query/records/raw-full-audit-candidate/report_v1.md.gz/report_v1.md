# Raw-domain native full-body audit

Read-only audit of the 744 current NEW operations per target against each frozen pre-raw body’s `paired.new`. No executables/builds were run; no expected body was generated.

## Equality and classifications

- Main/scoped NEW bodies equal after removing only capture `variant` and `source_sha256`: **True**.
- Main/scoped frozen raw-OLD bodies equal after the same envelope removal: **True**.
- Per body output classifications: `{"different_work_budget_error": 12, "same_complete_success": 264, "same_complete_typed_error": 468}` (main); `{"different_work_budget_error": 12, "same_complete_success": 264, "same_complete_typed_error": 468}` (scoped).
- Whole-read work deltas and direct raw-domain receipts are reported separately. Deltas include the surrounding operation; no unreceipted difference is attributed to raw-domain admission.

## Direct raw-domain fees and surrounding work

### main

- Direct raw fees by lane: `{"cache": {"accepted_work": 632, "additional_units": 632, "host_eviction_work": 0, "partial_work": 0}, "plan": {"accepted_work": 5784, "additional_units": 5784, "host_eviction_work": 0, "partial_work": 0}}`.
- Sum of captured whole-read delta differences by lane: `{"cache": 5824, "plan": 41494}`.
- Outside receipts compared: `{"changed_leaf_path_counts": {"original_queries/flattened/plan/accepted_work": 24, "original_queries/flattened/plan/additional_units": 8, "original_queries/flattened/plan/canonical_units": 8, "original_queries/flattened/plan/completed_queries": 8, "original_queries/flattened/plan/failed_queries": 8, "original_queries/flattened/plan/partial_work": 24, "original_queries/processing/max_active_depth": 8, "original_queries/processing/plan/accepted_work": 16, "original_queries/processing/plan/constructor_calls": 8, "original_queries/processing/plan/failed_queries": 8, "original_queries/processing/plan/partial_work": 16}, "names_checked": ["fade", "owners", "original_queries"], "rows_with_changes": {"original_queries": 32}}`.
- Audit issue rows: 0.

### scoped

- Direct raw fees by lane: `{"cache": {"accepted_work": 632, "additional_units": 632, "host_eviction_work": 0, "partial_work": 0}, "plan": {"accepted_work": 5784, "additional_units": 5784, "host_eviction_work": 0, "partial_work": 0}}`.
- Sum of captured whole-read delta differences by lane: `{"cache": 5824, "plan": 41494}`.
- Outside receipts compared: `{"changed_leaf_path_counts": {"original_queries/flattened/plan/accepted_work": 24, "original_queries/flattened/plan/additional_units": 8, "original_queries/flattened/plan/canonical_units": 8, "original_queries/flattened/plan/completed_queries": 8, "original_queries/flattened/plan/failed_queries": 8, "original_queries/flattened/plan/partial_work": 24, "original_queries/processing/max_active_depth": 8, "original_queries/processing/plan/accepted_work": 16, "original_queries/processing/plan/constructor_calls": 8, "original_queries/processing/plan/failed_queries": 8, "original_queries/processing/plan/partial_work": 16}, "names_checked": ["fade", "owners", "original_queries"], "rows_with_changes": {"original_queries": 32}}`.
- Audit issue rows: 0.

## Findings

No unexpected state, payload, provider-order, cleanup, raw-counter, or body-shape discrepancies were found.

## Exact work-budget error differences

| Scope | Fixture / operation | Mode | Old typed error | New typed error | Raw fee in plan/cache |
|---|---|---|---|---|---|
| main | `root-ntsc-enclosing-and-silence` / 15 | ordinary_probe | `Limit("plan work per read")` | `Plan(AudioQueryLimit("recursive policy work"))` | plan 17, cache 0 |
| main | `root-ntsc-enclosing-and-silence` / 16 | ordinary_probe | `Plan(AudioQueryLimit("structural work"))` | `Plan(AudioQueryLimit("recursive policy work"))` | plan 17, cache 0 |
| main | `root-ntsc-enclosing-and-silence` / 33 | ordinary_probe | `Plan(AudioQueryLimit("structural work"))` | `Limit("plan work per read")` | plan 17, cache 0 |
| main | `root-ntsc-enclosing-and-silence` / 49 | actual_admitted_probe_unmetered | `Limit("plan work per read")` | `Plan(AudioQueryLimit("recursive policy work"))` | plan 17, cache 0 |
| main | `root-ntsc-enclosing-and-silence` / 50 | actual_admitted_probe_unmetered | `Plan(AudioQueryLimit("structural work"))` | `Plan(AudioQueryLimit("recursive policy work"))` | plan 17, cache 0 |
| main | `root-ntsc-enclosing-and-silence` / 67 | actual_admitted_probe_unmetered | `Plan(AudioQueryLimit("structural work"))` | `Limit("plan work per read")` | plan 17, cache 0 |
| main | `root-ntsc-enclosing-and-silence` / 83 | actual_admitted_probe_metered | `Limit("plan work per read")` | `Plan(AudioQueryLimit("recursive policy work"))` | plan 17, cache 0 |
| main | `root-ntsc-enclosing-and-silence` / 84 | actual_admitted_probe_metered | `Plan(AudioQueryLimit("structural work"))` | `Plan(AudioQueryLimit("recursive policy work"))` | plan 17, cache 0 |
| main | `root-ntsc-enclosing-and-silence` / 101 | actual_admitted_probe_metered | `Plan(AudioQueryLimit("structural work"))` | `Limit("plan work per read")` | plan 17, cache 0 |
| main | `root-ntsc-enclosing-and-silence` / 117 | actual_selected_then_shared | `Limit("plan work per read")` | `Plan(AudioQueryLimit("recursive policy work"))` | plan 17, cache 0 |
| main | `root-ntsc-enclosing-and-silence` / 118 | actual_selected_then_shared | `Plan(AudioQueryLimit("structural work"))` | `Plan(AudioQueryLimit("recursive policy work"))` | plan 17, cache 0 |
| main | `root-ntsc-enclosing-and-silence` / 135 | actual_selected_then_shared | `Plan(AudioQueryLimit("structural work"))` | `Limit("plan work per read")` | plan 17, cache 0 |
| scoped | `root-ntsc-enclosing-and-silence` / 15 | ordinary_probe | `Limit("plan work per read")` | `Plan(AudioQueryLimit("recursive policy work"))` | plan 17, cache 0 |
| scoped | `root-ntsc-enclosing-and-silence` / 16 | ordinary_probe | `Plan(AudioQueryLimit("structural work"))` | `Plan(AudioQueryLimit("recursive policy work"))` | plan 17, cache 0 |
| scoped | `root-ntsc-enclosing-and-silence` / 33 | ordinary_probe | `Plan(AudioQueryLimit("structural work"))` | `Limit("plan work per read")` | plan 17, cache 0 |
| scoped | `root-ntsc-enclosing-and-silence` / 49 | actual_admitted_probe_unmetered | `Limit("plan work per read")` | `Plan(AudioQueryLimit("recursive policy work"))` | plan 17, cache 0 |
| scoped | `root-ntsc-enclosing-and-silence` / 50 | actual_admitted_probe_unmetered | `Plan(AudioQueryLimit("structural work"))` | `Plan(AudioQueryLimit("recursive policy work"))` | plan 17, cache 0 |
| scoped | `root-ntsc-enclosing-and-silence` / 67 | actual_admitted_probe_unmetered | `Plan(AudioQueryLimit("structural work"))` | `Limit("plan work per read")` | plan 17, cache 0 |
| scoped | `root-ntsc-enclosing-and-silence` / 83 | actual_admitted_probe_metered | `Limit("plan work per read")` | `Plan(AudioQueryLimit("recursive policy work"))` | plan 17, cache 0 |
| scoped | `root-ntsc-enclosing-and-silence` / 84 | actual_admitted_probe_metered | `Plan(AudioQueryLimit("structural work"))` | `Plan(AudioQueryLimit("recursive policy work"))` | plan 17, cache 0 |
| scoped | `root-ntsc-enclosing-and-silence` / 101 | actual_admitted_probe_metered | `Plan(AudioQueryLimit("structural work"))` | `Limit("plan work per read")` | plan 17, cache 0 |
| scoped | `root-ntsc-enclosing-and-silence` / 117 | actual_selected_then_shared | `Limit("plan work per read")` | `Plan(AudioQueryLimit("recursive policy work"))` | plan 17, cache 0 |
| scoped | `root-ntsc-enclosing-and-silence` / 118 | actual_selected_then_shared | `Plan(AudioQueryLimit("structural work"))` | `Plan(AudioQueryLimit("recursive policy work"))` | plan 17, cache 0 |
| scoped | `root-ntsc-enclosing-and-silence` / 135 | actual_selected_then_shared | `Plan(AudioQueryLimit("structural work"))` | `Limit("plan work per read")` | plan 17, cache 0 |

These are the only output differences. All are non-cancellation errors in the work-budget family. The full typed objects, frozen requests, state differences, and per-row outside-receipt paths remain in `audit.json`.
