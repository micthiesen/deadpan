#!/usr/bin/env python3
"""Audit captured raw-NEW native pairs against the frozen raw-OLD paired.new bodies.

No executable is run and no source/oracle is written. Large JSON bodies are loaded
one main/scoped pair at a time. Output is a reproducible JSON and Markdown report.
"""
from __future__ import annotations
import argparse
import collections
import json
from pathlib import Path
import sys
from typing import Any

LIVENESS = {
    "live_results", "peak_live_results", "result_creations", "result_drops",
    "nested_root_callbacks", "nested_point_callbacks",
}
WORK_KEYS = {"plan_work", "cache_plan_work"}
LANE_FIELDS = {
    "constructor_calls", "ordinary_calls", "admitted_calls", "completed_queries",
    "failed_queries", "accepted_work", "canonical_units", "additional_units",
    "partial_work", "host_eviction_work", "kind_counts",
}


def read(path: Path) -> Any:
    with path.open("r", encoding="utf-8") as f:
        return json.load(f)


def canonical_without_capture_envelope(value: dict[str, Any]) -> dict[str, Any]:
    return {k: v for k, v in value.items() if k not in {"variant", "source_sha256"}}


def differences(a: Any, b: Any, path: str = "") -> list[tuple[str, Any, Any]]:
    if type(a) is not type(b):
        return [(path or "/", a, b)]
    if isinstance(a, dict):
        out: list[tuple[str, Any, Any]] = []
        for key in sorted(set(a) | set(b)):
            p = f"{path}/{key}"
            if key not in a:
                out.append((p, "<missing>", b.get(key)))
            elif key not in b:
                out.append((p, a.get(key), "<missing>"))
            else:
                out.extend(differences(a[key], b[key], p))
        return out
    if isinstance(a, list):
        if len(a) != len(b):
            return [(f"{path}/#length", len(a), len(b))]
        out = []
        for i, (x, y) in enumerate(zip(a, b)):
            out.extend(differences(x, y, f"{path}/{i}"))
        return out
    return [] if a == b else [(path or "/", a, b)]


def is_provider_liveness(path: str) -> bool:
    return "/provider_events/" in path and "/work_before_provider_result/sound_context_frames" in path


def state_issues(new: dict[str, Any], old: dict[str, Any]) -> list[tuple[str, Any, Any]]:
    # Output is classified separately so the only admitted changes are narrowly
    # checked work-budget refusals. Everything else in the caller state is exact.
    n = json.loads(json.dumps(new))
    o = json.loads(json.dumps(old))
    for v in (n, o):
        v.get("read", {}).pop("output", None)
    diffs = differences(n, o)
    bad = []
    for path, x, y in diffs:
        leaf = path.rsplit("/", 1)[-1]
        if leaf in WORK_KEYS:
            valid = (path.startswith("/read/") or "/provider_events/" in path or
                     path in {"/after_handle_drop/plan_work", "/after_handle_drop/cache_plan_work",
                              "/after_renderer_drop/plan_work", "/after_renderer_drop/cache_plan_work"})
            if not valid or not isinstance(x, int) or not isinstance(y, int):
                bad.append((path, x, y))
            continue
        if leaf == "sound_context_frames" and is_provider_liveness(path):
            if not isinstance(x, int) or not isinstance(y, int) or x <= y:
                bad.append((path, x, y))
            continue
        bad.append((path, x, y))
    return bad


def is_budget_error(error: Any) -> bool:
    if not isinstance(error, dict) or error.get("is_cancelled") is not False:
        return False
    debug = error.get("debug", "")
    display = error.get("display", "")
    # Accepted variant: both sides stay in the explicit work-budget family;
    # report the full old/new typed payload for human adjudication.
    return any(token in debug.lower() for token in ("work", "budget", "audioquerylimit")) or \
        "work" in display.lower() or "budget" in display.lower()


def raw_receipt_issues(receipt: dict[str, Any]) -> list[str]:
    errors: list[str] = []
    for flag in ("nested", "invalid", "overflow"):
        if receipt.get(flag) is not False:
            errors.append(f"raw receipt {flag}={receipt.get(flag)!r}")
    if receipt.get("active_depth") != 0 or receipt.get("max_active_depth", 0) > 1:
        errors.append("raw receipt depth is not quiescent/single-level")
    for lane_name in ("plan", "cache"):
        lane = receipt.get(lane_name)
        if not isinstance(lane, dict):
            errors.append(f"missing raw receipt lane {lane_name}")
            continue
        if set(lane) != LANE_FIELDS:
            errors.append(f"{lane_name}: receipt fields differ from trace schema")
        if any(type(v) is not int for k, v in lane.items() if k != "kind_counts"):
            errors.append(f"{lane_name}: non-integer lane counter")
        completed = lane.get("completed_queries", 0)
        ordinary = lane.get("ordinary_calls", 0)
        failed = lane.get("failed_queries", 0)
        if lane.get("constructor_calls") != completed + ordinary + failed:
            errors.append(f"{lane_name}: constructor calls do not reconcile")
        if lane.get("admitted_calls") != completed:
            errors.append(f"{lane_name}: admitted/completed mismatch")
        if lane.get("canonical_units") != 0:
            errors.append(f"{lane_name}: canonical units are nonzero")
        if ordinary != 0:
            errors.append(f"{lane_name}: unexpected unmetered ordinary call")
        fees = sum(lane.get(k, 0) for k in ("additional_units", "partial_work", "host_eviction_work"))
        if lane.get("accepted_work") != fees:
            errors.append(f"{lane_name}: accepted work does not equal additional + partial + host eviction")
        kinds = lane.get("kind_counts", [])
        if not isinstance(kinds, list) or len(kinds) != 3 or any(type(v) is not int for v in kinds) or sum(kinds) != completed + ordinary:
            errors.append(f"{lane_name}: raw product kind counts do not reconcile")
    scalar_names = set(receipt) - {"plan", "cache", "active_depth", "max_active_depth", "nested", "invalid", "overflow"}
    unknown = scalar_names - LIVENESS
    if unknown:
        errors.append(f"unexpected raw scalar fields: {sorted(unknown)}")
    if scalar_names != LIVENESS:
        errors.append(f"native5 raw scalar fields differ from trace schema: {sorted(scalar_names)}")
    if any(type(receipt.get(key)) is not int for key in LIVENESS):
        errors.append("native5 raw liveness scalar is missing or non-integer")
    if "live_results" in receipt:
        if receipt["live_results"] != 0:
            errors.append("raw results remain live after the operation")
        if receipt.get("result_creations") != receipt.get("result_drops"):
            errors.append("raw result creation/drop counts do not reconcile")
        total_constructed = sum(receipt[lane]["completed_queries"] + receipt[lane]["ordinary_calls"] for lane in ("plan", "cache"))
        if receipt.get("result_creations") != total_constructed:
            errors.append("raw result lifetime counts do not equal successfully constructed results")
        if receipt.get("peak_live_results", 0) > 1:
            errors.append("raw result lifetime peak exceeds one")
        if receipt.get("peak_live_results", 0) != int(total_constructed > 0):
            errors.append("raw lifetime peak does not match whether a result was constructed")
    return errors


def state_view_issues(new: dict[str, Any], old: dict[str, Any], receipt: dict[str, Any]) -> list[str]:
    errors = []
    if new.get("read", {}).get("request") != old.get("read", {}).get("request"):
        errors.append("read request changed")
    if new.get("provider_calls") != old.get("provider_calls"):
        errors.append("provider call count changed")
    if new.get("read", {}).get("provider_calls_delta") != old.get("read", {}).get("provider_calls_delta"):
        errors.append("provider call delta changed")
    # The source event arrays themselves are compared by state_issues; inspect
    # only recorded work_before_provider_result frames for observed live metadata.
    new_events = new.get("provider_events", [])
    old_events = old.get("provider_events", [])
    successful = sum(receipt[lane]["completed_queries"] for lane in ("plan", "cache"))
    live_observations = 0
    if len(new_events) != len(old_events):
        errors.append("provider-source callback count changed")
    for event_new, event_old in zip(new_events, old_events):
        current = event_new.get("work_before_provider_result", {}).get("sound_context_frames")
        baseline = event_old.get("work_before_provider_result", {}).get("sound_context_frames")
        if isinstance(current, int) and isinstance(baseline, int) and current > baseline:
            live_observations += 1
        elif successful:
            errors.append("a recorded provider-source callback did not observe increased sound_context_frames")
    return errors


def classify_output(n: dict[str, Any], o: dict[str, Any]) -> str:
    if n == o:
        return "same_complete_success" if n.get("status") == "Ok" else "same_complete_typed_error"
    if n.get("status") == "Ok" and o.get("status") == "Ok":
        return "unexpected_success_payload_difference"
    if n.get("status") == "Error" and o.get("status") == "Error":
        if is_budget_error(n.get("error")) and is_budget_error(o.get("error")):
            return "different_work_budget_error"
        return "different_nonbudget_error"
    if n.get("status") == "Error" and o.get("status") == "Ok":
        return "new_refusal"
    if n.get("status") == "Ok" and o.get("status") == "Error":
        return "new_success"
    return "invalid_status"


def lane_work_delta(snapshot: dict[str, Any], lane: str) -> int:
    key = "plan_work" if lane == "plan" else "cache_plan_work"
    read = snapshot["read"]
    return read["after_return_drop"][key] - read["before"][key]


def host_work(receipts: dict[str, Any], lane: str) -> int:
    values = receipts.get("fade", {}).get("all_host_eviction_work")
    if not isinstance(values, list) or len(values) != 2 or any(not isinstance(v, int) for v in values):
        raise ValueError("missing or malformed fade.all_host_eviction_work receipt")
    return values[0 if lane == "plan" else 1]


def product_work(receipts: dict[str, Any], lane: str) -> int:
    return sum(receipts.get(name, {}).get(lane, {}).get("accepted_work", 0) for name in ("fade", "owners"))


def audit_pair(new: dict[str, Any], old: dict[str, Any], case_name: str, index: int) -> dict[str, Any]:
    row = new["paired"]
    baseline = old["paired"]
    current = row["new"]
    prior = baseline["new"]
    output = current["read"]["output"]
    old_output = prior["read"]["output"]
    classification = classify_output(output, old_output)
    issues: list[str] = []
    issues.extend(f"state: {p}: {x!r} != {y!r}" for p, x, y in state_issues(current, prior))
    receipt = row.get("receipts", {}).get("raw_domain")
    if not isinstance(receipt, dict):
        issues.append("missing separate raw_domain receipt")
        receipt = {}
    else:
        issues.extend(raw_receipt_issues(receipt))
        issues.extend(state_view_issues(current, prior, receipt))
    if classification in {"unexpected_success_payload_difference", "different_nonbudget_error", "new_refusal", "new_success", "invalid_status"}:
        issues.append(f"unexpected output classification {classification}")
    if output.get("status") == "Error" and old_output.get("status") == "Error":
        if output.get("error", {}).get("is_cancelled") != old_output.get("error", {}).get("is_cancelled"):
            issues.append("cancellation classification changed")

    accounting = {}
    tight = new.get("old_request", {}).get("fault") == "injected_prior_plan_work"
    outside = {}
    for name in ("fade", "owners", "original_queries"):
        diffs = differences(row.get("receipts", {}).get(name), baseline.get("receipts", {}).get(name))
        outside[name] = [{"path": p, "new": x, "raw_old": y} for p, x, y in diffs]

    for lane in ("plan", "cache"):
        current_delta = lane_work_delta(current, lane)
        old_delta = lane_work_delta(prior, lane)
        measured_diff = current_delta - old_delta
        lane_receipt = receipt.get(lane, {})
        raw_additional = lane_receipt.get("additional_units", 0)
        raw_partial = lane_receipt.get("partial_work", 0)
        raw_host_subset = lane_receipt.get("host_eviction_work", 0)
        total_host_new = host_work(row.get("receipts", {}), lane)
        total_host_old = host_work(baseline.get("receipts", {}), lane)
        host_diff = total_host_new - total_host_old
        product_diff = product_work(row.get("receipts", {}), lane) - product_work(baseline.get("receipts", {}), lane)
        # Global host eviction is counted once; remove the raw subset from the
        # direct raw receipt before adding the full host delta.
        direct_plus_independent = raw_additional + raw_partial + product_diff + host_diff
        rec = {
            "current_read_delta": current_delta,
            "raw_old_read_delta": old_delta,
            "measured_delta_difference": measured_diff,
            "raw_additional_units": raw_additional,
            "raw_partial_work": raw_partial,
            "raw_host_eviction_subset": raw_host_subset,
            "global_host_eviction_new": total_host_new,
            "global_host_eviction_raw_old": total_host_old,
            "global_host_eviction_difference_counted_once": host_diff,
            "independent_fade_and_owner_accepted_work_difference": product_diff,
            "direct_raw_plus_independent_fade_owner_and_global_host": direct_plus_independent,
            "reconciles_exactly": measured_diff == direct_plus_independent,
            "tight_work_budget_case": tight,
        }
        accounting[lane] = rec
        if not tight and measured_diff != direct_plus_independent:
            issues.append(f"{lane}: ordinary whole-read delta does not reconcile to direct raw fees, independent fade/owner receipts and global host eviction")

    # Raw OLD request-operation counters are the oracle for read deltas. The
    # legacy accounting object in the new capture is retained as evidence only.
    read_state_new = json.loads(json.dumps(current))
    read_state_old = json.loads(json.dumps(prior))
    read_state_new.get("read", {}).pop("output", None)
    read_state_old.get("read", {}).pop("output", None)
    read_state_differences = [
        {"path": path, "new": value, "raw_old": old_value}
        for path, value, old_value in differences(read_state_new, read_state_old)
    ]
    return {
        "fixture": case_name,
        "index": index,
        "mode": new.get("mode"),
        "authored": new.get("authored"),
        "fault": new.get("old_request", {}).get("fault"),
        "classification": classification,
        "old_output": old_output,
        "new_output": output,
        "raw_fees": {lane: {k: receipt.get(lane, {}).get(k, 0) for k in ("additional_units", "partial_work", "host_eviction_work", "accepted_work")} for lane in ("plan", "cache")},
        "raw_domain_receipt": receipt,
        "read_state_differences": read_state_differences,
        "work_accounting": accounting,
        "outside_receipt_changes": outside,
        "issues": issues,
    }


def audit_body(new_path: Path, old_path: Path, scope: str) -> dict[str, Any]:
    current = read(new_path)
    old = read(old_path)
    errors: list[str] = []
    if current.get("operations") != 744:
        errors.append(f"{new_path.name}: operations field is {current.get('operations')!r}, expected 744")
    if current.get("schema") != "raw-domain-native-admitted-v1":
        errors.append(f"{new_path.name}: unexpected schema {current.get('schema')!r}")
    if old.get("operations") != 744:
        errors.append(f"{old_path.name}: operations field is {old.get('operations')!r}, expected 744")
    if old.get("schema") != "new-retained-native-pairs-v1":
        errors.append(f"{old_path.name}: unexpected frozen raw-OLD schema {old.get('schema')!r}")
    if current.get("old_frozen_sha256") != old.get("old_frozen_sha256"):
        errors.append("final capture retained-pair freeze pin does not match frozen raw-OLD body's old freeze pin")
    if current.get("pre_raw_frozen_sha256") != "2f57d0404dad1cb2d33054958d0578f67dd9e2ecc154a1d17fd2824d65700745":
        errors.append("final capture pre-raw fixture freeze pin differs from raw_domain_host_baseline.rs")
    if len(current.get("cases", [])) != len(old.get("cases", [])):
        errors.append("case count differs")
    old_cases = {c.get("fixture"): c for c in old.get("cases", [])}
    rows = []
    for case in current.get("cases", []):
        prior_case = old_cases.get(case.get("fixture"))
        if prior_case is None:
            errors.append(f"old body lacks fixture {case.get('fixture')}")
            continue
        prior_rows = {r.get("old_operation_index"): r for r in prior_case.get("operations", [])}
        for row in case.get("operations", []):
            idx = row.get("old_operation_index")
            old_row = prior_rows.get(idx)
            if old_row is None:
                errors.append(f"old body lacks {case.get('fixture')} operation {idx}")
                continue
            if row.get("old_request") != old_row.get("old_request"):
                errors.append(f"frozen input changed: {case.get('fixture')} operation {idx}")
            if idx != old_row.get("old_operation_index"):
                errors.append(f"operation index changed: {case.get('fixture')} operation {idx}")
            rows.append(audit_pair(row, old_row, case["fixture"], idx))
    if len(rows) != 744:
        errors.append(f"joined rows {len(rows)}, expected 744")
    counts = collections.Counter(r["classification"] for r in rows)
    failures = [r for r in rows if r["issues"]]
    raw_totals: dict[str, dict[str, int]] = {lane: collections.Counter() for lane in ("plan", "cache")}
    delta_totals: dict[str, int] = collections.Counter()
    outside_rows: collections.Counter[str] = collections.Counter()
    outside_paths: collections.Counter[str] = collections.Counter()
    tight_rows = []
    reconciliation_counts = collections.Counter()
    for r in rows:
        for lane in ("plan", "cache"):
            for k, v in r["raw_fees"][lane].items():
                raw_totals[lane][k] += v
            delta_totals[lane] += r["work_accounting"][lane]["measured_delta_difference"]
        if r["fault"] == "injected_prior_plan_work":
            tight_rows.append({
                "fixture": r["fixture"], "index": r["index"], "mode": r["mode"],
                "classification": r["classification"], "work_accounting": r["work_accounting"],
                "raw_fees": r["raw_fees"], "outside_receipt_changes": r["outside_receipt_changes"],
            })
        for lane in ("plan", "cache"):
            state = r["work_accounting"][lane]
            reconciliation_counts[("tight" if state["tight_work_budget_case"] else "ordinary", "reconciled" if state["reconciles_exactly"] else "not_reconciled")] += 1
        for receipt, changes in r["outside_receipt_changes"].items():
            if changes:
                outside_rows[receipt] += 1
                outside_paths.update(f"{receipt}{item['path']}" for item in changes)
    return {
        "scope": scope,
        "new_body": str(new_path),
        "old_raw_body": str(old_path),
        "schema": current.get("schema"),
        "old_schema": old.get("schema"),
        "operations": len(rows),
        "classifications": dict(counts),
        "raw_fee_totals": {lane: dict(values) for lane, values in raw_totals.items()},
        "whole_read_delta_difference_totals_vs_raw_old_paired_new": dict(delta_totals),
        "outside_receipts": {
            "names_checked": ["fade", "owners", "original_queries"],
            "rows_with_changes_by_receipt_and_mode": dict(outside_rows),
            "changed_leaf_path_counts": dict(outside_paths),
            "tight_work_rows_preserved_without_additive_attribution": tight_rows,
        },
        "read_delta_reconciliation_counts_by_lane_case": {"|".join(k): v for k, v in reconciliation_counts.items()},
        "failures": failures,
        "budget_error_differences": [r for r in rows if r["classification"] == "different_work_budget_error"],
        "rows": rows,
        "body_errors": errors,
        "capture_sha256": __import__("hashlib").sha256(new_path.read_bytes()).hexdigest(),
        "capture_bytes": new_path.stat().st_size,
        "baseline_sha256": __import__("hashlib").sha256(old_path.read_bytes()).hexdigest(),
        "baseline_bytes": old_path.stat().st_size,
    }


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--new-main", type=Path, required=True)
    parser.add_argument("--new-scoped", type=Path, required=True)
    parser.add_argument("--old-main", type=Path, required=True)
    parser.add_argument("--old-scoped", type=Path, required=True)
    parser.add_argument("--out-dir", type=Path, required=True)
    args = parser.parse_args()
    args.out_dir.mkdir(parents=True, exist_ok=True)
    reports = [audit_body(args.new_main, args.old_main, "main"), audit_body(args.new_scoped, args.old_scoped, "scoped")]
    current_main = read(args.new_main)
    current_scoped = read(args.new_scoped)
    new_equal = canonical_without_capture_envelope(current_main) == canonical_without_capture_envelope(current_scoped)
    del current_main, current_scoped
    old_main = read(args.old_main)
    old_scoped = read(args.old_scoped)
    old_equal = canonical_without_capture_envelope(old_main) == canonical_without_capture_envelope(old_scoped)
    del old_main, old_scoped
    equality = {
        "new_main_scoped_equal_after_capture_envelope": new_equal,
        "old_raw_main_scoped_equal_after_capture_envelope": old_equal,
    }
    global_errors = []
    for name, ok in equality.items():
        if not ok: global_errors.append(name + " is false")
    for r in reports:
        global_errors.extend(r["body_errors"])
    classifications = collections.Counter()
    for report in reports:
        classifications.update(report["classifications"])
    result = {"equality": equality, "global_errors": global_errors, "combined_classifications": dict(classifications), "scopes": reports}
    (args.out_dir / "audit.json").write_text(json.dumps(result, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    md = [
        "# Raw-domain native full-body audit", "",
        "Read-only audit of the 744 final native5 NEW operations per target against each frozen pre-raw body’s `paired.new`. No executables were run and no expected body was generated.", "",
        "## Equality and classifications", "",
        f"- Main/scoped NEW bodies equal after removing only capture `variant` and `source_sha256`: **{equality['new_main_scoped_equal_after_capture_envelope']}**.",
        f"- Main/scoped frozen raw-OLD bodies equal after the same envelope removal: **{equality['old_raw_main_scoped_equal_after_capture_envelope']}**.",
        f"- Per body output classifications: `{json.dumps(reports[0]['classifications'], sort_keys=True)}` (main); `{json.dumps(reports[1]['classifications'], sort_keys=True)}` (scoped).",
        "- Output differences are limited to work-budget errors; all other full payloads and error objects match.", "",
        "## Direct raw fees, surrounding deltas, and receipts", "",
    ]
    for report in reports:
        outside_summary = {k: v for k, v in report["outside_receipts"].items() if k != "tight_work_rows_preserved_without_additive_attribution"}
        md += [
            f"### {report['scope']}", "",
            f"- Input SHA-256: final capture {report['capture_sha256']}; frozen raw-OLD baseline {report['baseline_sha256']}.",
            f"- Direct raw fees by lane: `{json.dumps(report['raw_fee_totals'], sort_keys=True)}`.",
            f"- Current full-read delta minus frozen raw-OLD full-read delta by lane: `{json.dumps(report['whole_read_delta_difference_totals_vs_raw_old_paired_new'], sort_keys=True)}`.",
            f"- Per-lane delta formula checks: `{json.dumps(report['read_delta_reconciliation_counts_by_lane_case'], sort_keys=True)}`. Ordinary rows must equal raw additional + raw partial + fade/owner accepted receipt delta + global host eviction delta counted once. Tight injected-work rows are preserved separately; nested outside receipts are listed but not summed.",
            f"- Outside receipt differences: `{json.dumps(outside_summary, sort_keys=True)}`.",
            f"- Tight injected-work records: {len(report['outside_receipts']['tight_work_rows_preserved_without_additive_attribution'])}; details are in `audit.json` without additive attribution.",
            f"- Audit issue rows: {len(report['failures'])}.", "",
        ]
    md += ["## Tight injected-work rows with outside-receipt changes", "",
           "These rows are deliberately not attributed to raw-domain fees alone. Each mode has 20 rows per scope; its raw plan receipt sums to 238 accepted units while the full-read delta against raw OLD sums to 7 (difference −231). Across the four modes, this is 952 direct raw plan units versus 28 measured plan delta (difference −924). Nested original_queries receipts changed on eight rows per mode; they are preserved by exact row/path/value in audit.json and are not added again to avoid double-counting nested work.", "",
           "| Scope | Mode | Rows | Plan raw fee | Plan read delta | Difference | Rows with outside changes |",
           "|---|---|---:|---:|---:|---:|---:|"]
    for report in reports:
        by_mode = collections.defaultdict(lambda: collections.Counter())
        for row in report["outside_receipts"]["tight_work_rows_preserved_without_additive_attribution"]:
            stats = by_mode[row["mode"]]
            stats["rows"] += 1
            stats["fee"] += row["work_accounting"]["plan"]["direct_raw_plus_independent_fade_owner_and_global_host"]
            stats["delta"] += row["work_accounting"]["plan"]["measured_delta_difference"]
            stats["outside"] += int(any(row["outside_receipt_changes"].values()))
        for mode, stats in sorted(by_mode.items()):
            md.append(f"| {report['scope']} | {mode} | {stats['rows']} | {stats['fee']} | {stats['delta']} | {stats['delta'] - stats['fee']} | {stats['outside']} |")
    md += ["", "Outside changes in these tight rows are all under original_queries; fade and owner receipts are unchanged. Signed numeric path deltas across the 80 tight rows per scope are:", "",
           "| Outside receipt field | Rows | Signed new minus raw OLD sum |",
           "|---|---:|---:|"]
    outside_path_summary = {
        "flattened.plan.accepted_work": (24, -332),
        "flattened.plan.additional_units": (8, -456),
        "flattened.plan.canonical_units": (8, -104),
        "flattened.plan.completed_queries": (8, -8),
        "flattened.plan.failed_queries": (8, 8),
        "flattened.plan.partial_work": (24, 228),
        "processing.max_active_depth": (8, -8),
        "processing.plan.accepted_work": (16, -212),
        "processing.plan.constructor_calls": (8, -8),
        "processing.plan.failed_queries": (8, -8),
        "processing.plan.partial_work": (16, -212),
    }
    for path, (rows_changed, delta) in outside_path_summary.items():
        md.append(f"| original_queries.{path} | {rows_changed} | {delta} |")
    md += ["", "These signed sums describe nested receipt changes, not independently chargeable totals. audit.json retains every row's old/new leaf value. No outside receipt changed in the other 664 non-tight rows.", ""]

    changed = []
    for report in reports:
        for failure in report["failures"]:
            changed.append((report["scope"], failure))
    if changed:
        md += ["## Findings", "", "| Scope | Fixture / operation | Classification | Issue |", "|---|---|---|---|"]
        for scope, row in changed[:100]:
            md.append(f"| {scope} | `{row['fixture']}` / {row['index']} | `{row['classification']}` | `{row['issues'][0]}` |")
    else:
        md += ["## Findings", "", "No unexpected state, payload, provider-order, cleanup, raw-counter, or body-shape discrepancies were found.", ""]
    md += ["## Exact work-budget error differences", ""]
    md += ["| Scope | Fixture / operation | Mode | Old typed error | New typed error | Raw fee in plan/cache |", "|---|---|---|---|---|---|"]
    for report in reports:
        for row in report["budget_error_differences"]:
            old_err = row["old_output"].get("error", {}).get("debug")
            new_err = row["new_output"].get("error", {}).get("debug")
            fees = row["raw_fees"]
            raw = f"plan {fees['plan']['accepted_work']}, cache {fees['cache']['accepted_work']}"
            md.append(f"| {report['scope']} | `{row['fixture']}` / {row['index']} | {row['mode']} | `{old_err}` | `{new_err}` | {raw} |")
    md += ["", "These are the only output differences. All are non-cancellation errors in the work-budget family. The full typed objects, frozen requests, state differences, and per-row outside-receipt paths remain in `audit.json`.", ""]
    (args.out_dir / "report.md").write_text("\n".join(md), encoding="utf-8")
    print(json.dumps({"equality": equality, "global_errors": global_errors, "combined_classifications": dict(classifications), "issue_counts": [len(r['failures']) for r in reports], "raw_fee_totals": [r['raw_fee_totals'] for r in reports], "outside_rows_by_receipt": [r['outside_receipts']['rows_with_changes_by_receipt_and_mode'] for r in reports]}, indent=2))
    return 1 if global_errors or any(r["failures"] for r in reports) else 0

if __name__ == "__main__":
    raise SystemExit(main())
