#!/usr/bin/env python3
"""Audit captured raw-NEW native pairs against the frozen raw-OLD paired.new bodies.

No executable is run and no source/oracle is written. Large JSON bodies are loaded
one main/scoped pair at a time. Output is a reproducible JSON and Markdown report.
"""
from __future__ import annotations
import argparse
import collections
import json
from pathlib import Path
import sys
from typing import Any

LIVENESS = {
    "live_results", "peak_live_results", "result_creations", "result_drops",
    "nested_root_callbacks", "nested_point_callbacks",
}
WORK_KEYS = {"plan_work", "cache_plan_work"}


def read(path: Path) -> Any:
    with path.open("r", encoding="utf-8") as f:
        return json.load(f)


def canonical_without_capture_envelope(value: dict[str, Any]) -> dict[str, Any]:
    return {k: v for k, v in value.items() if k not in {"variant", "source_sha256"}}


def differences(a: Any, b: Any, path: str = "") -> list[tuple[str, Any, Any]]:
    if type(a) is not type(b):
        return [(path or "/", a, b)]
    if isinstance(a, dict):
        out: list[tuple[str, Any, Any]] = []
        for key in sorted(set(a) | set(b)):
            p = f"{path}/{key}"
            if key not in a:
                out.append((p, "<missing>", a.get(key)))
            elif key not in b:
                out.append((p, a.get(key), "<missing>"))
            else:
                out.extend(differences(a[key], b[key], p))
        return out
    if isinstance(a, list):
        if len(a) != len(b):
            return [(f"{path}/#length", len(a), len(b))]
        out = []
        for i, (x, y) in enumerate(zip(a, b)):
            out.extend(differences(x, y, f"{path}/{i}"))
        return out
    return [] if a == b else [(path or "/", a, b)]


def is_provider_liveness(path: str) -> bool:
    return "/provider_events/" in path and "/work_before_provider_result/sound_context_frames" in path


def state_issues(new: dict[str, Any], old: dict[str, Any]) -> list[tuple[str, Any, Any]]:
    # Output is classified separately so the only admitted changes are narrowly
    # checked work-budget refusals. Everything else in the caller state is exact.
    n = json.loads(json.dumps(new))
    o = json.loads(json.dumps(old))
    for v in (n, o):
        v.get("read", {}).pop("output", None)
    diffs = differences(n, o)
    bad = []
    for path, x, y in diffs:
        leaf = path.rsplit("/", 1)[-1]
        if leaf in WORK_KEYS:
            if not isinstance(x, int) or not isinstance(y, int):
                bad.append((path, x, y))
            continue
        if leaf == "sound_context_frames" and is_provider_liveness(path):
            if not isinstance(x, int) or not isinstance(y, int) or x < y:
                bad.append((path, x, y))
            continue
        bad.append((path, x, y))
    return bad


def is_budget_error(error: Any) -> bool:
    if not isinstance(error, dict) or error.get("is_cancelled") is not False:
        return False
    debug = error.get("debug", "")
    display = error.get("display", "")
    # Accepted variant: both sides stay in the explicit work-budget family;
    # report the full old/new typed payload for human adjudication.
    return any(token in debug.lower() for token in ("work", "budget", "audioquerylimit")) or \
        "work" in display.lower() or "budget" in display.lower()


def raw_receipt_issues(receipt: dict[str, Any]) -> list[str]:
    errors: list[str] = []
    for flag in ("nested", "invalid", "overflow"):
        if receipt.get(flag) is not False:
            errors.append(f"raw receipt {flag}={receipt.get(flag)!r}")
    if receipt.get("active_depth") != 0 or receipt.get("max_active_depth", 0) > 1:
        errors.append("raw receipt depth is not quiescent/single-level")
    for lane_name in ("plan", "cache"):
        lane = receipt.get(lane_name)
        if not isinstance(lane, dict):
            errors.append(f"missing raw receipt lane {lane_name}")
            continue
        completed = lane.get("completed_queries", 0)
        ordinary = lane.get("ordinary_calls", 0)
        failed = lane.get("failed_queries", 0)
        if lane.get("constructor_calls") != completed + ordinary + failed:
            errors.append(f"{lane_name}: constructor calls do not reconcile")
        if lane.get("admitted_calls") != completed:
            errors.append(f"{lane_name}: admitted/completed mismatch")
        if lane.get("canonical_units") != 0:
            errors.append(f"{lane_name}: canonical units are nonzero")
        if ordinary != 0:
            errors.append(f"{lane_name}: unexpected unmetered ordinary call")
        fees = sum(lane.get(k, 0) for k in ("additional_units", "partial_work", "host_eviction_work"))
        if lane.get("accepted_work") != fees:
            errors.append(f"{lane_name}: accepted work does not equal additional + partial + host eviction")
        kinds = lane.get("kind_counts", [])
        if len(kinds) != 3 or sum(kinds) != completed + ordinary:
            errors.append(f"{lane_name}: raw product kind counts do not reconcile")
    scalar_names = set(receipt) - {"plan", "cache", "active_depth", "max_active_depth", "nested", "invalid", "overflow"}
    unknown = scalar_names - LIVENESS
    if unknown:
        errors.append(f"unexpected raw scalar fields: {sorted(unknown)}")
    if "live_results" in receipt:
        missing_liveness = LIVENESS - scalar_names
        if missing_liveness:
            errors.append(f"missing native5 raw liveness scalars: {sorted(missing_liveness)}")
        if receipt["live_results"] != 0:
            errors.append("raw results remain live after the operation")
        if receipt.get("result_creations") != receipt.get("result_drops"):
            errors.append("raw result creation/drop counts do not reconcile")
        total_constructed = sum(receipt[lane]["completed_queries"] + receipt[lane]["ordinary_calls"] for lane in ("plan", "cache"))
        if receipt.get("result_creations") != total_constructed:
            errors.append("raw result lifetime counts do not equal successfully constructed results")
        if receipt.get("peak_live_results", 0) > 1:
            errors.append("raw result lifetime peak exceeds one")
        if receipt.get("peak_live_results", 0) != int(total_constructed > 0):
            errors.append("raw lifetime peak does not match whether a result was constructed")
    return errors


def state_view_issues(new: dict[str, Any], old: dict[str, Any]) -> list[str]:
    errors = []
    # The operation must preserve its exact request and all source event ordering.
    if new.get("read", {}).get("request") != old.get("read", {}).get("request"):
        errors.append("read request changed")
    if new.get("provider_calls") != old.get("provider_calls"):
        errors.append("provider call count changed")
    if new.get("read", {}).get("provider_calls_delta") != old.get("read", {}).get("provider_calls_delta"):
        errors.append("provider call delta changed")
    events_new = new.get("provider_events", [])
    events_old = old.get("provider_events", [])
    if len(events_new) != len(events_old):
        errors.append(f"provider event count changed {len(events_old)}->{len(events_new)}")
    for i, (a, b) in enumerate(zip(events_new, events_old)):
        if a.get("stage") != b.get("stage") or a.get("source") != b.get("source"):
            errors.append(f"provider event order/identity changed at {i}")
        if a.get("work_before_provider_result", {}).get("sound_context_frames", 0) <= b.get("work_before_provider_result", {}).get("sound_context_frames", 0):
            # A completed admitted constructor is expected to retain its metadata
            # lease through source acquisition; no raw query means no new lease.
            receipt = new.get("_raw_receipt")
            total = sum(receipt[l]["completed_queries"] for l in ("plan", "cache")) if receipt else 0
            if total and len(events_new):
                errors.append(f"provider event {i} did not observe the live raw lease")
    return errors


def classify_output(n: dict[str, Any], o: dict[str, Any]) -> str:
    if n == o:
        return "same_complete_success" if n.get("status") == "Ok" else "same_complete_typed_error"
    if n.get("status") == "Ok" and o.get("status") == "Ok":
        return "unexpected_success_payload_difference"
    if n.get("status") == "Error" and o.get("status") == "Error":
        if is_budget_error(n.get("error")) and is_budget_error(o.get("error")):
            return "different_work_budget_error"
        return "different_nonbudget_error"
    if n.get("status") == "Error" and o.get("status") == "Ok":
        return "new_refusal"
    if n.get("status") == "Ok" and o.get("status") == "Error":
        return "new_success"
    return "invalid_status"


def audit_pair(new: dict[str, Any], old: dict[str, Any], case_name: str, index: int) -> dict[str, Any]:
    row = new["paired"]
    baseline = old["paired"]
    current = row["new"]
    prior = baseline["new"]
    output = current["read"]["output"]
    old_output = prior["read"]["output"]
    classification = classify_output(output, old_output)
    issues: list[str] = []
    issues.extend(f"state: {p}: {x!r} != {y!r}" for p, x, y in state_issues(current, prior))
    receipt = row.get("receipts", {}).get("raw_domain")
    if not isinstance(receipt, dict):
        issues.append("missing separate raw_domain receipt")
        receipt = {}
    else:
        issues.extend(raw_receipt_issues(receipt))
        issues.extend(state_view_issues(current, prior))
    if classification in {"unexpected_success_payload_difference", "different_nonbudget_error", "new_refusal", "new_success", "invalid_status"}:
        issues.append(f"unexpected output classification {classification}")
    # Every output error is typed and non-cancellation state stays the same.
    if output.get("status") == "Error" and old_output.get("status") == "Error":
        if output.get("error", {}).get("is_cancelled") != old_output.get("error", {}).get("is_cancelled"):
            issues.append("cancellation classification changed")
    # Per-lane whole-read deltas and raw receipts are retained separately. Do not
    # attribute unreceipted totals to raw admission.
    acc = row.get("accounting", {})
    delta_diff = {}
    for lane in ("plan", "cache"):
        delta_diff[lane] = acc.get("new_read_delta", {}).get(lane, 0) - acc.get("old_read_delta", {}).get(lane, 0)
    raw_fees = {lane: {k: receipt.get(lane, {}).get(k, 0) for k in ("additional_units", "partial_work", "host_eviction_work", "accepted_work")} for lane in ("plan", "cache")}
    outside = {}
    for name in ("fade", "owners", "original_queries"):
        diffs = differences(row.get("receipts", {}).get(name), baseline.get("receipts", {}).get(name))
        outside[name] = [p for p, _, _ in diffs]
    return {
        "fixture": case_name,
        "index": index,
        "mode": new.get("mode"),
        "authored": new.get("authored"),
        "fault": new.get("old_request", {}).get("fault"),
        "classification": classification,
        "old_output": old_output,
        "new_output": output,
        "raw_fees": raw_fees,
        "whole_read_delta_difference": delta_diff,
        "outside_receipt_changed_paths": outside,
        "issues": issues,
    }


def audit_body(new_path: Path, old_path: Path, scope: str) -> dict[str, Any]:
    current = read(new_path)
    old = read(old_path)
    errors: list[str] = []
    if current.get("operations") != 744:
        errors.append(f"{new_path.name}: operations field is {current.get('operations')!r}, expected 744")
    if current.get("schema") != "raw-domain-native-admitted-v1":
        errors.append(f"{new_path.name}: unexpected schema {current.get('schema')!r}")
    if old.get("operations") != 744:
        errors.append(f"{old_path.name}: operations field is {old.get('operations')!r}, expected 744")
    if len(current.get("cases", [])) != len(old.get("cases", [])):
        errors.append("case count differs")
    old_cases = {c.get("fixture"): c for c in old.get("cases", [])}
    rows = []
    for case in current.get("cases", []):
        prior_case = old_cases.get(case.get("fixture"))
        if prior_case is None:
            errors.append(f"old body lacks fixture {case.get('fixture')}")
            continue
        prior_rows = {r.get("old_operation_index"): r for r in prior_case.get("operations", [])}
        for row in case.get("operations", []):
            idx = row.get("old_operation_index")
            old_row = prior_rows.get(idx)
            if old_row is None:
                errors.append(f"old body lacks {case.get('fixture')} operation {idx}")
                continue
            if row.get("old_request") != old_row.get("old_request"):
                errors.append(f"frozen input changed: {case.get('fixture')} operation {idx}")
            if idx != old_row.get("old_operation_index"):
                errors.append(f"operation index changed: {case.get('fixture')} operation {idx}")
            rows.append(audit_pair(row, old_row, case["fixture"], idx))
    if len(rows) != 744:
        errors.append(f"joined rows {len(rows)}, expected 744")
    counts = collections.Counter(r["classification"] for r in rows)
    failures = [r for r in rows if r["issues"]]
    raw_totals: dict[str, dict[str, int]] = {lane: collections.Counter() for lane in ("plan", "cache")}
    delta_totals: dict[str, int] = collections.Counter()
    outside_rows: collections.Counter[str] = collections.Counter()
    outside_paths: collections.Counter[str] = collections.Counter()
    for r in rows:
        for lane in ("plan", "cache"):
            for k, v in r["raw_fees"][lane].items():
                raw_totals[lane][k] += v
            delta_totals[lane] += r["whole_read_delta_difference"][lane]
        for receipt, paths in r["outside_receipt_changed_paths"].items():
            if paths:
                outside_rows[receipt] += 1
                outside_paths.update(f"{receipt}{p}" for p in paths)
    return {
        "scope": scope,
        "new_body": str(new_path),
        "old_raw_body": str(old_path),
        "schema": current.get("schema"),
        "old_schema": old.get("schema"),
        "operations": len(rows),
        "classifications": dict(counts),
        "raw_fee_totals": {lane: dict(values) for lane, values in raw_totals.items()},
        "whole_read_delta_difference_totals": dict(delta_totals),
        "outside_receipts": {
            "names_checked": ["fade", "owners", "original_queries"],
            "rows_with_changes": dict(outside_rows),
            "changed_leaf_path_counts": dict(outside_paths),
        },
        "failures": failures,
        "budget_error_differences": [r for r in rows if r["classification"] == "different_work_budget_error"],
        "rows": rows,
        "body_errors": errors,
        "capture_sha256": __import__("hashlib").sha256(new_path.read_bytes()).hexdigest(),
        "capture_bytes": new_path.stat().st_size,
        "baseline_sha256": __import__("hashlib").sha256(old_path.read_bytes()).hexdigest(),
        "baseline_bytes": old_path.stat().st_size,
    }


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--new-main", type=Path, required=True)
    parser.add_argument("--new-scoped", type=Path, required=True)
    parser.add_argument("--old-main", type=Path, required=True)
    parser.add_argument("--old-scoped", type=Path, required=True)
    parser.add_argument("--out-dir", type=Path, required=True)
    args = parser.parse_args()
    args.out_dir.mkdir(parents=True, exist_ok=True)
    reports = [audit_body(args.new_main, args.old_main, "main"), audit_body(args.new_scoped, args.old_scoped, "scoped")]
    current_main = read(args.new_main)
    current_scoped = read(args.new_scoped)
    new_equal = canonical_without_capture_envelope(current_main) == canonical_without_capture_envelope(current_scoped)
    del current_main, current_scoped
    old_main = read(args.old_main)
    old_scoped = read(args.old_scoped)
    old_equal = canonical_without_capture_envelope(old_main) == canonical_without_capture_envelope(old_scoped)
    del old_main, old_scoped
    equality = {
        "new_main_scoped_equal_after_capture_envelope": new_equal,
        "old_raw_main_scoped_equal_after_capture_envelope": old_equal,
    }
    global_errors = []
    for name, ok in equality.items():
        if not ok: global_errors.append(name + " is false")
    for r in reports:
        global_errors.extend(r["body_errors"])
    classifications = collections.Counter()
    for report in reports:
        classifications.update(report["classifications"])
    result = {"equality": equality, "global_errors": global_errors, "combined_classifications": dict(classifications), "scopes": reports}
    (args.out_dir / "audit.json").write_text(json.dumps(result, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    md = ["# Raw-domain native full-body audit", "", "Read-only audit of the 744 current NEW operations per target against each frozen pre-raw body’s `paired.new`. No executables/builds were run; no expected body was generated.", "", "## Equality and classifications", "", f"- Main/scoped NEW bodies equal after removing only capture `variant` and `source_sha256`: **{equality['new_main_scoped_equal_after_capture_envelope']}**.", f"- Main/scoped frozen raw-OLD bodies equal after the same envelope removal: **{equality['old_raw_main_scoped_equal_after_capture_envelope']}**.", f"- Per body output classifications: `{json.dumps(reports[0]['classifications'], sort_keys=True)}` (main); `{json.dumps(reports[1]['classifications'], sort_keys=True)}` (scoped).", "- Whole-read work deltas and direct raw-domain receipts are reported separately. Deltas include the surrounding operation; no unreceipted difference is attributed to raw-domain admission.", "", "## Direct raw-domain fees and surrounding work", ""]
    for report in reports:
        md += [f"### {report['scope']}", "", f"- Direct raw fees by lane: `{json.dumps(report['raw_fee_totals'], sort_keys=True)}`.", f"- Sum of captured whole-read delta differences by lane: `{json.dumps(report['whole_read_delta_difference_totals'], sort_keys=True)}`.", f"- Outside receipts compared: `{json.dumps(report['outside_receipts'], sort_keys=True)}`.", f"- Audit issue rows: {len(report['failures'])}.", ""]
    changed = []
    for report in reports:
        for failure in report["failures"]:
            changed.append((report["scope"], failure))
    if changed:
        md += ["## Findings", "", "| Scope | Fixture / operation | Classification | Issue |", "|---|---|---|---|"]
        for scope, row in changed[:100]:
            md.append(f"| {scope} | `{row['fixture']}` / {row['index']} | `{row['classification']}` | `{row['issues'][0]}` |")
    else:
        md += ["## Findings", "", "No unexpected state, payload, provider-order, cleanup, raw-counter, or body-shape discrepancies were found.", ""]
    md += ["## Exact work-budget error differences", ""]
    md += ["| Scope | Fixture / operation | Mode | Old typed error | New typed error | Raw fee in plan/cache |", "|---|---|---|---|---|---|"]
    for report in reports:
        for row in report["budget_error_differences"]:
            old_err = row["old_output"].get("error", {}).get("debug")
            new_err = row["new_output"].get("error", {}).get("debug")
            fees = row["raw_fees"]
            raw = f"plan {fees['plan']['accepted_work']}, cache {fees['cache']['accepted_work']}"
            md.append(f"| {report['scope']} | `{row['fixture']}` / {row['index']} | {row['mode']} | `{old_err}` | `{new_err}` | {raw} |")
    md += ["", "These are the only output differences. All are non-cancellation errors in the work-budget family. The full typed objects, frozen requests, state differences, and per-row outside-receipt paths remain in `audit.json`.", ""]
    (args.out_dir / "report.md").write_text("\n".join(md), encoding="utf-8")
    print(json.dumps({"equality": equality, "global_errors": global_errors, "combined_classifications": dict(classifications), "issue_counts": [len(r['failures']) for r in reports], "raw_fee_totals": [r['raw_fee_totals'] for r in reports], "outside_rows": [r['outside_receipts']['rows_with_changes'] for r in reports]}, indent=2))
    return 1 if global_errors or any(r["failures"] for r in reports) else 0

if __name__ == "__main__":
    raise SystemExit(main())
