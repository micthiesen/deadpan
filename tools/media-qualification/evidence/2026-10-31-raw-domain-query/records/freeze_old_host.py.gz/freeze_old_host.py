from pathlib import Path
import json,hashlib,collections
s=Path(__file__).resolve().parent
bodies=[]
for v in ['main','scoped']:
 data=json.loads((s/f'raw-old-host-{v}-body.json').read_text())
 assert set(data)>={'variant','source_sha256','cases','operations'}
 del data['variant'];del data['source_sha256']
 bodies.append(data)
assert bodies[0]==bodies[1]
data=(json.dumps(bodies[0],sort_keys=True,separators=(',',':'))+'\n').encode()
digest=hashlib.sha256(data).hexdigest()
counts=collections.Counter()
for case in bodies[0]['cases']:
 for row in case['operations']:counts[row['paired']['new']['read']['output']['status']]+=1
assert counts=={'Ok':264,'Error':480}
readme='''# Raw-domain native baseline v1

Captured before changing native raw-domain reconstruction or its lifetime,
after publishing87ab6192e765a34dae9595139e10bd9010d6315e.
Both actual source variants use that checkpoint's byte-pinned final optimized
Audio executable and unchanged complete source. Admitted retained fades/owners
remain active. The native fresh Bound raw-domain call remains ordinary.

The existing complete retained-pair driver replays744 literal requests on five
real-WAV cases, four actual owning construction origins and both authored modes.
Current outputs have264 successes and480 typed errors. The envelope also
retains its original request witness, comparisons and independent ordinary
metadata/accepted receipts; its schema name and old_frozen_sha256 continue to
name the earlier retained unit. No field is rewritten to pretend otherwise.
The raw-domain unit's OLD output is paired.new in each operation.

Main/isolated full JSON bodies agree after removing ONLY variant and
source_sha256. Nested provenance, checkpoint data and all complete values stay.
This is a fresh pre-raw-domain baseline with today's admitted fades/owners,
not the older retained legacy-mode native witness. Full PCM bits, masks,
dependencies, depth, work/controller/cache states and provider events remain.

No result was regenerated after a raw-domain algorithm or host-lifetime change.
The separate Plan witness is responsible for exhaustive private Point-domain
fields; the native body does not claim that private structural payload.
'''
relative=Path('crates/deadpan-audio/tests/fixtures/raw-domain-host-baseline-v1')
for root in [Path('/Users/michael/Code/deadpan'),Path('/tmp/deadpan-query-groundwork-2026-10-26/scoped')]:
 dest=root/relative
 assert not dest.exists();dest.mkdir()
 (dest/'snapshot.json').write_bytes(data)
 (dest/'snapshot.sha256').write_text(digest+'\n')
 (dest/'README.md').write_text(readme)
(s/'raw-old-host-canonical-body.json').write_bytes(data)
proof={'complete_main_scoped_equality':True,'removed_only':['variant','source_sha256'],'canonical_bytes':len(data),'canonical_sha256':digest,'operations':744,'current_default_results':dict(counts),'before_raw_domain_production_changes':True,'admitted_retained_fades_and_owners_active':True,'public_raw_domain_still_ordinary':True,'published_checkpoint':(s/'base-revision.txt').read_text().strip(),'fixture':str(relative)}
(s/'raw-old-host-equality.json').write_text(json.dumps(proof,indent=2)+'\n')
pins=json.loads((s/'immutable-oracle-pins.json').read_text());assert len(pins)==21
pins.append({'path':str(relative/'snapshot.json'),'bytes':len(data),'sha256':digest,'scope':'Raw-domain native preimplementation; current admitted retained fade/owner behavior active'})
(s/'immutable-oracle-pins.json').write_text(json.dumps(pins,indent=2)+'\n')
for root in [Path('/Users/michael/Code/deadpan'),Path('/tmp/deadpan-query-groundwork-2026-10-26/scoped')]:
 for pin in pins:assert hashlib.sha256((root/pin['path']).read_bytes()).hexdigest()==pin['sha256']
paths=[str(relative/x)for x in ['README.md','snapshot.json','snapshot.sha256']]
(s/'owned-native-baseline-paths.json').write_text(json.dumps(paths,indent=2)+'\n')
for name in ['source-files.json','main-logic-source-files.json','scoped-source-files.json','scoped-logic-source-files.json']:
 p=s/name;lst=json.loads(p.read_text());assert not set(paths)&set(lst)
 p.write_text(json.dumps(sorted(lst+paths),indent=2)+'\n')
print(proof)
