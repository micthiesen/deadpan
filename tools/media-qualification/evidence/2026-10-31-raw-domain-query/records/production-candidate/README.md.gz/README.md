# Raw-domain admission candidate

This is a scratch-only candidate for the next raw-domain admission unit. No repository source files were changed, and no Cargo build, native run, or expected-body capture was performed.

## Patch sets and pins

- patches/main.patch applies to /Users/michael/Code/deadpan.
- patches/scoped.patch applies to /tmp/deadpan-query-groundwork-2026-10-26/scoped.
- main-pins.json and scoped-pins.json hold exact before and after SHA-256 and byte counts for all touched paths. The two plan.rs starting files differ; the two patches preserve that inherited difference.
- Candidate source copies are mirrored beneath main/ and scoped/.

## Shape

Plan adds a public, private-field, non-Clone AdmittedAudioBoundDomain carrier around the existing raw_domain_admitted constructor. Its public query retains the historical local work budget of 65,536, forwards only the constructor's additional units, checks the returned issuer/lease, and returns a borrowed domain view. The unmetered path calls ordinary raw_domain and reports zero units without calling admission policy methods.

The native read_bound_at keeps its existing early control, depth, plan, range, and silent-Hold checks. It takes a short Admission borrow for construction, then keeps the carrier in scope through Root/Point transfer rendering and nested read callbacks. A private borrowed transfer view factors the same Root integer rebasing and render loop; public DomainSignalTransfer::new keeps its owned API and geometry.

Test-only raw_domain_request selects ordinary raw reconstruction only inside the explicit whole-retained and whole-Original compatibility scopes. The narrower fade scope is unchanged. A separate test-only raw_domain_query_trace is default-off and enabled by reset(). It scopes only the raw constructor, uses fixed plan/cache counters and fixed [usize; 3] Root/Point/Empty counts, records successful canonical/additional receipts or failed accepted partial work, and subtracts the independently recorded host-eviction receipts. It does not change the existing Root trace shape. The named raw_domain_request::with_legacy_raw_domain scope keeps admitted fades/owners active while selecting ordinary raw reconstruction for the pre-raw native body.

## Application order

Apply the plan-side files in the selected root first (audio_bound_probe.rs, audio_bound.rs, and that root's plan.rs), then the audio transfer and stage files, then the two legacy-scope edits and the two new test-only files. Apply the Main and Scope patches independently. Do not regenerate any OLD body after applying.

## Static limits

The candidate was formatted and parsed with rustfmt --edition 2024 --config skip_children=true --check over its edited Rust files. This does not type-check the candidate. There are no Cargo or native results here.

The bounded trace records accepted partial work on constructor failure and keeps host eviction work separate from constructor-spend work. Issuer callback prefix/state should still be asserted using the test admission policy callback log; the candidate does not infer fees from a gross ReadWork delta. The existing AudioPointDomain::signal() clone inside read_point_domain_controlled remains ordinary and explicitly outside this unit. No claim is made for recursive Signal/Tape/Mix preparation, allocator/RSS, or whole-read work attribution.
