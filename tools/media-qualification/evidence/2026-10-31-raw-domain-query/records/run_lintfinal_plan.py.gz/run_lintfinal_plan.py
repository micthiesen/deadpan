from pathlib import Path
import subprocess,json,sys
s=Path(__file__).resolve().parent;v=sys.argv[1]
build=f'raw-lintfinal-plan-{v}-build'
old=json.loads((s/f'raw-final-plan-{v}-build-pins.json').read_text())
new=json.loads((s/(build+'-pins.json')).read_text());rows=[]
for p in new:
 q=next(x for x in old if x['name']==p['name'])
 if p['sha256']==q['sha256']:
  label=f"raw-final-{v}-plan-{p['name'].replace('_','-')}"
  r=json.loads((s/(label+'.json')).read_text());assert r['exit_code']==0 and r['binaries_unchanged']and r['sources_unchanged']
  reused=True
 else:
  label=f"raw-lintfinal-{v}-plan-{p['name'].replace('_','-')}"
  subprocess.run(['python3',str(s/'run_logic_target.py'),build,v,'plan',p['name'],label,'--test-threads=1'],check=True)
  reused=False
 rows.append({'variant':v,'target':p['name'],'receipt':str(s/(label+'.json')),'reused':reused,'sha256':p['sha256']})
(s/f'final-plan-{v}-coverage.json').write_text(json.dumps(rows,indent=2))
