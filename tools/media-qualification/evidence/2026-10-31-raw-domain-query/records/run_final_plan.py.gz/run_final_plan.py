from pathlib import Path
import subprocess,json
s=Path(__file__).resolve().parent
v=__import__('sys').argv[1]
build=f'raw-final-plan-{v}-build'
pins=json.loads((s/(build+'-pins.json')).read_text())
for p in pins:
 assert p['package']=='plan'
 label=f"raw-final-{v}-plan-{p['name'].replace('_','-')}"
 subprocess.run(['python3',str(s/'run_logic_target.py'),build,v,'plan',p['name'],label,'--test-threads=1'],check=True)
