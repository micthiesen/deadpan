The first inline candidate patch generator had an unterminated Python string
before execution; no patch was applied. The corrected version is retained as
prepare_candidate.py and verifies all actual before hashes. The worker v1
candidate discarded the observed public seal count in its new test mode; before
integration the parent requested and reviewed a corrected scratch candidate
that preserves the actual public_events count and existing uniform seal check.
