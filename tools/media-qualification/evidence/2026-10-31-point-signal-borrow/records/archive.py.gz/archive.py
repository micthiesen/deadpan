from pathlib import Path
import gzip,json,hashlib
s=Path(__file__).resolve().parent;repo=Path('/Users/michael/Code/deadpan')
dest=repo/'tools/media-qualification/evidence/2026-10-31-point-signal-borrow'
assert not dest.exists()
assert json.loads((s/'final-audit.json').read_text())['all_terminal']
prior=repo/'tools/media-qualification/evidence/2026-10-31-raw-domain-query/inventory.json'
prior_sha='93f5dc491cd9367bb5321ae0f042b709658f02146b50ea97a35fb21b18b30a44'
assert hashlib.sha256(prior.read_bytes()).hexdigest()==prior_sha
allowed={'.rs','.json','.py','.md','.patch','.stdout','.stderr','.txt','.sha256'}
rows=[]
for p in sorted(s.rglob('*')):
 if not p.is_file()or p.suffix not in allowed or p.name=='published-evidence.json':continue
 data=p.read_bytes()
 if p.suffix=='.json':
  obj=json.loads(data)
  if isinstance(obj,dict)and'command'in obj and'started_at'in obj:assert obj['exit_code']==0 and obj['sources_unchanged']and obj['binaries_unchanged']
 rel=p.relative_to(s);target=(dest/'records'/rel).with_name(rel.name+'.gz');target.parent.mkdir(parents=True,exist_ok=True)
 packed=gzip.compress(data,mtime=0);target.write_bytes(packed)
 rows.append({'path':str(target.relative_to(dest)),'bytes':len(packed),'sha256':hashlib.sha256(packed).hexdigest(),'expanded_bytes':len(data),'expanded_sha256':hashlib.sha256(data).hexdigest()})
manifest={'schema_version':1,'base_revision':(s/'base-revision.txt').read_text().strip(),'scope':'Borrow the exact stored Point Structural signal during the synchronous native reader; preserve owning signal() behavior and all constructor work/leases. No caps, prior weights, DSP, formats, requirement/Gate statuses or general sound-bearing Split changes. Future fresh Signal content/policy construction and recursive preparation stay open.','prior_raw_domain_inventory':{'path':'../2026-10-31-raw-domain-query/inventory.json','sha256':prior_sha},'exclusions':'Executables and nontext artifacts excluded. Published raw-domain canonical body is the pre-change native reference, pinned and decoded by the capture wrapper; no expected body or oracle regenerated. Complete NEW bodies retain the historical raw capture schema and retained checkpoint truthfully, while external proofs name this unit base. Narrow verification uses both Plan/Audio libraries, public Point integration and all744complete native operations, plus strict checks, format, doctests and hygiene; the preceding broader29Plan/21Audio/Split matrix is identified separately, not rerun or relabelled.','files':rows}
p=dest/'inventory.json';p.write_text(json.dumps(manifest,indent=2)+'\n')
for row in rows:
 packed=(dest/row['path']).read_bytes();plain=gzip.decompress(packed)
 assert len(packed)==row['bytes']and hashlib.sha256(packed).hexdigest()==row['sha256']
 assert len(plain)==row['expanded_bytes']and hashlib.sha256(plain).hexdigest()==row['expanded_sha256']
out={'files':len(rows),'stored_bytes':sum(r['bytes']for r in rows),'expanded_bytes':sum(r['expanded_bytes']for r in rows),'inventory_sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
(s/'published-evidence.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out))
