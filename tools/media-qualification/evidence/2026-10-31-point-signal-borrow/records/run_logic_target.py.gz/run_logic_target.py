from pathlib import Path
import json,sys,subprocess
s=Path(__file__).resolve().parent
build,variant,package,target,label,*args=sys.argv[1:]
pins=json.loads((s/(build+'-pins.json')).read_text())
binary=next(p['path']for p in pins if p['package']==package and p['name']==target)
runner=s/('run_main_logic.py' if variant=='main' else 'run_scoped_logic.py')
raise SystemExit(subprocess.run(['python',str(runner),'--binary',binary,label,'--',binary,*args]).returncode)
