from pathlib import Path
import subprocess,sys
s=Path(__file__).resolve().parent;v=sys.argv[1];build=f'point-plan-{v}-build'
for label,args in [(f'point-{v}-borrowed-focused',['borrowed_point_signal_matches_all_18_frozen_point_payloads','--test-threads=1']),(f'point-{v}-plan-library',['--test-threads=1'])]:
 subprocess.run(['python3',str(s/'run_logic_target.py'),build,v,'plan','deadpan_plan',label,*args],check=True)
