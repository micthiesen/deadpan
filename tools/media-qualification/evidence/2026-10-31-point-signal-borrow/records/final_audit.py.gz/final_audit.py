from pathlib import Path
from datetime import datetime
import hashlib,json,re,subprocess
s=Path(__file__).resolve().parent;r=Path('/Users/michael/Code/deadpan');scope=Path('/tmp/deadpan-query-groundwork-2026-10-26/scoped')
sha=lambda b:hashlib.sha256(b).hexdigest()
owned=json.loads((s/'owned-paths.json').read_text())
preserved={};source_counts={}
for v,root in [('main',r),('scoped',scope)]:
 initial=json.loads((s/(v+'-initial-authority.json')).read_text())
 for p,h in initial.items():
  if p in owned:continue
  b=(root/p).read_bytes();assert len(b)==h['bytes']and sha(b)==h['sha256'],(v,p)
 preserved[v]=len([p for p in initial if p not in owned])
 current={}
 names=json.loads((s/('source-files.json'if v=='main'else'scoped-source-files.json')).read_text())
 for p in names:
  b=(root/p).read_bytes();current[str(root/p)]={'bytes':len(b),'sha256':sha(b)}
 build=json.loads((s/f'point-audio-{v}-build.json').read_text());assert current==build['source_after']
 source_counts[v]=len(current)
 (s/(v+'-final-source-pins.json')).write_text(json.dumps(current,indent=2)+'\n')
 for p in owned:assert(r/p).read_bytes()==(scope/p).read_bytes(),p
assert preserved=={'main':2848,'scoped':2520}
oracles=json.loads((s/'immutable-oracle-pins.json').read_text());assert len(oracles)==23
for p in oracles:
 for root in [r,scope]:assert sha((root/p['path']).read_bytes())==p['sha256']
actual=subprocess.check_output(['git','diff','--cached','--name-only','-z'],cwd=r).decode().strip('\0').split('\0')
assert set(actual)==set(owned)
for p in owned:
 staged=subprocess.check_output(['git','show',':'+p],cwd=r)
 assert staged==(r/p).read_bytes()==(scope/p).read_bytes(),p
receipts=[];native=[]
for p in sorted(s.glob('*.json')):
 d=json.loads(p.read_text())
 if not isinstance(d,dict)or'command'not in d or'started_at'not in d:continue
 assert d.get('exit_code')==0 and d['sources_unchanged']and d['binaries_unchanged'],p.name
 for path,h in d['streams'].items():
  b=Path(path).read_bytes();assert len(b)==h['bytes']and sha(b)==h['sha256'],path
 receipts.append({'label':p.stem,'seconds':d['seconds'],'sha256':sha(p.read_bytes())})
 if d['binary_before']and d['environment'].get('CARGO_PROFILE_DEV_OPT_LEVEL')=='2':
  native.append((datetime.fromisoformat(d['started_at']),datetime.fromisoformat(d['finished_at']),p.stem))
for a,b in zip(sorted(native),sorted(native)[1:]):assert a[1]<=b[0],(a[2],b[2])
tests={}
for v,plan,audio in [('main',278,437),('scoped',265,431)]:
 for suffix,expected in [('borrowed-focused',(1,0)),('plan-library',(plan,24)),('audio-library',(audio,10)),('audio-domain',(12,0)),('gap-bindings',(10,0)),('gap-definition',(6,0)),('point-selection',(1,0))]:
  label=f'point-{v}-{suffix}'
  d=json.loads((s/(label+'.json')).read_text())
  matches=re.findall(r'test result: ok\. (\d+) passed; 0 failed; (\d+) ignored;',(s/(label+'.stdout')).read_text())
  assert len(matches)==1 and tuple(map(int,matches[0]))==expected,(label,matches)
  for p,h in d['binary_before'].items():assert sha(Path(p).read_bytes())==h['sha256']
  tests[label]={'passed':expected[0],'ignored':expected[1]}
 proof=json.loads((s/f'point-new-native-{v}-proof.json').read_text())
 assert proof['full_body_equality']and proof['canonical_sha256']=='164f9543d7db901b20a8d1a4d200a9853cd3a89e6fc0615aaf61f4ee2dee38c3'and proof['operations']==744
out={'all_terminal':True,'owned_paths':4,'all_index_main_scoped_blobs_equal':True,'preserved_unowned':preserved,'immutable_oracles':23,'source_counts':source_counts,'native_runs_serial':True,'native_runs':len(native),'receipts':receipts,'tests':tests,'native_full_744_body_equal_to_published_raw':True,'native_canonical_sha256':'164f9543d7db901b20a8d1a4d200a9853cd3a89e6fc0615aaf61f4ee2dee38c3','shipping_patch_sha256':sha((s/'shipping-source.patch').read_bytes()),'broader_matrix':'Not rerun for this single copy-elision change; preceding c2ef raw-domain qualification retains all29Plan/all21Audio executables perroot and threepass/fourfail Split research. No new Split or whole preparation claim.'}
(s/'final-audit.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({k:v for k,v in out.items()if k not in ['receipts','tests']},indent=2))
