from pathlib import Path
import json,hashlib,os,subprocess,sys,gzip
s=Path(__file__).resolve().parent
v=sys.argv[1];assert v in ['main','scoped']
root=Path('/Users/michael/Code/deadpan')if v=='main'else Path('/tmp/deadpan-query-groundwork-2026-10-26/scoped')
repo=Path('/Users/michael/Code/deadpan')
prefix=repo/'tools/media-qualification/evidence/2026-10-31-raw-domain-query'
inventory=json.loads((prefix/'inventory.json').read_text())
assert hashlib.sha256((prefix/'inventory.json').read_bytes()).hexdigest()=='93f5dc491cd9367bb5321ae0f042b709658f02146b50ea97a35fb21b18b30a44'
row=next(r for r in inventory['files']if r['path']=='records/raw-new-host6-canonical-body.json.gz')
packed=(prefix/row['path']).read_bytes()
assert hashlib.sha256(packed).hexdigest()==row['sha256']
baseline=gzip.decompress(packed)
assert len(baseline)==27092643 and hashlib.sha256(baseline).hexdigest()==row['expanded_sha256']=='164f9543d7db901b20a8d1a4d200a9853cd3a89e6fc0615aaf61f4ee2dee38c3'
build=f'point-audio-{v}-build';label=f'point-new-native-{v}'
receipt=json.loads((s/(build+'.json')).read_text());assert receipt['exit_code']==0 and receipt['sources_unchanged']
pin=next(p for p in json.loads((s/(build+'-pins.json')).read_text())if p['name']=='deadpan_audio')
profile=pin['artifact']['profile'];assert profile['opt_level']=='2'and profile['debug_assertions']and profile['overflow_checks']
assert hashlib.sha256(Path(pin['path']).read_bytes()).hexdigest()==pin['sha256']
manifest={}
for absolute,h in receipt['source_after'].items():
 b=Path(absolute).read_bytes();actual={'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()};assert actual==h,absolute
 manifest[str(Path(absolute).relative_to(root))]=actual
data=(json.dumps(manifest,sort_keys=True,separators=(',',':'))+'\n').encode();digest=hashlib.sha256(data).hexdigest()
p=s/(label+'-source-manifest.json');assert not p.exists();p.write_bytes(data)
names=[l.removesuffix(': test')for l in(s/f'point-{v}-audio-list.stdout').read_text().splitlines()if l.endswith('raw_domain_host_baseline::capture_new_raw_domain_native_v1: test')]
assert len(names)==1
out=s/(label+'-body.json');assert not out.exists()
tag='main-inherited'if v=='main'else'scoped-published'
env=os.environ.copy();env.update({'DEADPAN_RAW_HOST_OUTPUT':str(out),'DEADPAN_RAW_HOST_VARIANT':tag,'DEADPAN_RAW_HOST_SOURCE_SHA256':digest,'DEADPAN_RAW_HOST_PUBLISHED_CHECKPOINT':'87ab6192e765a34dae9595139e10bd9010d6315e'})
subprocess.run(['python3',str(s/'run_target.py'),build,v,'audio','deadpan_audio',label,'--ignored','--exact',names[0],'--nocapture','--test-threads=1'],env=env,check=True)
run=json.loads((s/(label+'.json')).read_text());assert run['exit_code']==0 and run['sources_unchanged']and run['binaries_unchanged']
body=json.loads(out.read_text());assert body.pop('variant')==tag and body.pop('source_sha256')==digest
canonical=(json.dumps(body,sort_keys=True,separators=(',',':'))+'\n').encode()
assert canonical==baseline,'all 744 complete values, work, provider events, receipts and cleanup must equal published raw-domain result'
canonical_path=s/(label+'-canonical-body.json');assert not canonical_path.exists();canonical_path.write_bytes(canonical)
proof={'variant':v,'base_revision':(s/'base-revision.txt').read_text().strip(),'source_manifest_sha256':digest,'source_inputs':len(manifest),'binary_sha256':pin['sha256'],'full_body_equality':True,'removed_only':['variant','source_sha256'],'operations':744,'canonical_bytes':len(canonical),'canonical_sha256':hashlib.sha256(canonical).hexdigest(),'reference_inventory_sha256':'93f5dc491cd9367bb5321ae0f042b709658f02146b50ea97a35fb21b18b30a44','reference_record':row,'historical_raw_capture_schema_and_retained_checkpoint_preserved':True,'all_source_binary_guards':True}
(s/(label+'-proof.json')).write_text(json.dumps(proof,indent=2)+'\n');print(json.dumps(proof))
