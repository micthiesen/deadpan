# Point signal borrow scope

The just-published raw-domain unit's final 744-request captures are the immutable
before behavior for this change. Their canonical full body is 27,092,643 bytes,
SHA-256 164f9543d7db901b20a8d1a4d200a9853cd3a89e6fc0615aaf61f4ee2dee38c3,
published in the raw-domain inventory 93f5dc491cd9367bb5321ae0f042b709658f02146b50ea97a35fb21b18b30a44.
Their Rust sources are unchanged at this unit's start; the initial source
authorities have been rechecked. No before body is regenerated.

The existing immutable 77-operand Plan corpus includes all 18 complete private
Point/Structural signal payloads. It remains exact. A borrowed accessor and one
synchronous native argument change remove an unnecessary owning copy. Public
signal() semantics, canonical/additional work, caller admission, DSP and formats
stay unchanged. No allocation peak, speed/RSS or full recursive admission claim.

Verify the new full-field test, raw admission tests and full Plan libraries, both
native Audio libraries (including real Root/Point lifetime/error/cache tests),
targeted public Point integration, and fresh complete 744 captures. Compare the
latter to the published final raw body after removing only capture variant and
source digest. Run strict checks, formatting and doctests; reuse broader raw-unit
verification only for unchanged behavior and explicitly identify that scope.
