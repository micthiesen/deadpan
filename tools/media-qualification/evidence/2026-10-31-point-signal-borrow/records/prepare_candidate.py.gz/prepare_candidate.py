from pathlib import Path
import hashlib,json,difflib
s=Path(__file__).resolve().parent
c=Path('/tmp/deadpan-raw-domain-query-admission-2026-10-31/next-point-borrow-candidate')
patches=[]
pins={}
for line in(c/'before.sha256').read_text().splitlines():
 digest,name=line.split(maxsplit=1);pins[name.lstrip('*')]=digest
owned=json.loads((s/'owned-paths.json').read_text())
for root in [Path('/Users/michael/Code/deadpan'),Path('/tmp/deadpan-query-groundwork-2026-10-26/scoped')]:
 for name in owned:
  p=root/name;after=(c/p.name).read_text()
  if p.exists():
   before=p.read_text()
   key=next(k for k in pins if k.endswith(name))
   assert hashlib.sha256(p.read_bytes()).hexdigest()==pins[key],(str(p),key)
   diff=list(difflib.unified_diff(before.splitlines(True),after.splitlines(True)))
   assert diff
   body=''.join('@@\n'if line.startswith('@@')else line for line in diff[2:]if not line.startswith('\\ No newline'))
   patch='*** Begin Patch\n*** Update File: '+str(p)+'\n'+body+'*** End Patch'
  else:
   assert name==owned[-1]
   patch='*** Begin Patch\n*** Add File: '+str(p)+'\n'+''.join('+'+line for line in after.splitlines(True))+'*** End Patch'
  patches.append(patch)
(s/'candidate-apply-patches.json').write_text(json.dumps(patches,indent=2)+'\n')
print(json.dumps(patches))
