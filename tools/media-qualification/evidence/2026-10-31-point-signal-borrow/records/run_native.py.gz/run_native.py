from pathlib import Path
import subprocess
s=Path(__file__).resolve().parent
for v in ['scoped','main']:
 build=f'point-audio-{v}-build'
 for target,tag,args in [('deadpan_audio','audio-list',['--list']),('deadpan_audio','audio-library',['--test-threads=1']),('audio_domain','audio-domain',['--test-threads=1']),('gap_bindings','gap-bindings',['--test-threads=1']),('gap_definition','gap-definition',['--test-threads=1']),('stages','point-selection',['selection::selected_empty_host_intersections_and_zero_point_windows_do_not_read_media','--exact','--test-threads=1'])]:
  subprocess.run(['python3',str(s/'run_target.py'),build,v,'audio',target,f'point-{v}-{tag}',*args],check=True)
 subprocess.run(['python3',str(s/'capture_native.py'),v],check=True)
