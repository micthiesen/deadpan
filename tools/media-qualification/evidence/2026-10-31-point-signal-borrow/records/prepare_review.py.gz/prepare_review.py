from pathlib import Path
import subprocess,json,difflib,hashlib
s=Path(__file__).resolve().parent;r=Path('/Users/michael/Code/deadpan');scope=Path('/tmp/deadpan-query-groundwork-2026-10-26/scoped')
paths=json.loads((s/'owned-paths.json').read_text())
patch='';pins={}
for name in paths:
 if not name.endswith('.rs'):continue
 data=(scope/name).read_bytes()
 old=subprocess.run(['git','show','c2ef0dba6f187271498737f3c9660e461becdb81:'+name],cwd=r,capture_output=True)
 before=old.stdout if old.returncode==0 else b''
 patch+=''.join(difflib.unified_diff(before.decode().splitlines(True),data.decode().splitlines(True),fromfile='a/'+name,tofile='b/'+name))
 pins[name]={'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest(),'base_exists':old.returncode==0}
(s/'review-source.patch').write_text(patch)
(s/'review-source-pins.json').write_text(json.dumps(pins,indent=2)+'\n')
print('review Rust paths',len(pins),'patch bytes',len(patch))
