from pathlib import Path
import json,hashlib,os,subprocess,sys
s=Path(__file__).resolve().parent
build,variant,label=sys.argv[1:]
root=Path('/Users/michael/Code/deadpan')if variant=='main'else Path('/tmp/deadpan-query-groundwork-2026-10-26/scoped')
runner=s/'run_logic_target.py'
listed=label+'-list'
subprocess.run(['python',str(runner),build,variant,'plan','deadpan_plan',listed,'--list'],check=True)
names=[line.removesuffix(': test')for line in(s/(listed+'.stdout')).read_text().splitlines()if line.endswith('::capture_old_fade_query_baseline_v1: test')]
assert len(names)==1,names
paths=json.loads((s/('main-logic-source-files.json'if variant=='main'else'scoped-logic-source-files.json')).read_text())
manifest={p:{'bytes':len((root/p).read_bytes()),'sha256':hashlib.sha256((root/p).read_bytes()).hexdigest()}for p in paths}
file=s/(label+'-runtime-source.json');assert not file.exists()
file.write_text(json.dumps(manifest,indent=2)+'\n')
source_sha=hashlib.sha256(file.read_bytes()).hexdigest()
built=json.loads((s/(build+'.json')).read_text())
assert built['exit_code']==0 and built['sources_unchanged']
for name,pin in built['source_after'].items():
 assert hashlib.sha256(Path(name).read_bytes()).hexdigest()==pin['sha256'],name
output=s/(label+'-body.json');assert not output.exists()
env=os.environ.copy()
env.update({'DEADPAN_FADE_QUERY_OUTPUT':str(output),'DEADPAN_FADE_QUERY_VARIANT':'main-inherited'if variant=='main'else'scoped-published','DEADPAN_FADE_QUERY_SOURCE_SHA256':source_sha,'DEADPAN_FADE_QUERY_PUBLISHED_POLICY_CHECKPOINT':(s/'published-policy-checkpoint.txt').read_text().strip()})
result=subprocess.run(['python',str(runner),build,variant,'plan','deadpan_plan',label,'--ignored','--nocapture',names[0],'--exact','--test-threads=1'],env=env)
if result.returncode:raise SystemExit(result.returncode)
text=(s/(label+'.stdout')).read_text()
assert 'running 1 test'in text and'test result: ok. 1 passed;'in text
assert output.stat().st_size>0
print(json.dumps({'label':label,'output_bytes':output.stat().st_size,'source_sha256':source_sha}),flush=True)
