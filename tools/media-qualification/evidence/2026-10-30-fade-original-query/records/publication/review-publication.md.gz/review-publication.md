# Publication review: fade original-query checkpoint

## Result

No concrete factual, count, error, limit, or inventory-integrity defect found in the current publication prose.

## Cross-checks

- The qualification page, current handoff section, and appended requirement paragraph describe the same bounded admission: actual Root/physical-Domain fade construction and conditional fourth Original carrier are covered; standalone retained-input fades, other variable containers, inner ordinary queries, complete recursive preparation, and sound-bearing General Split remain open. They do not imply full product completion, a cap/weight/refund change, or production-limit change.
- The OLD corpus counts agree with the frozen snapshot: 80 parents (63 Root, 17 physical Domain), 2,354 calls (1,046 successes, 1,308 typed errors); the four error categories total 1,308. The default-work and literal work/span claims, including the 54 positive one-short span cases and 26 without a legal positive predecessor, match the corpus. The six retained-factory supplement is correctly limited to one Some and does not establish standalone retained-input admission.
- The nine Plan tests, six host cases, primary/second-walk and origin/side-buffer accounting description, and stated limitation on per-lease identity are consistent with the documented evidence and the implementation-scope review. Resource-phase prose now distinguishes installed hooks from phases asserted as reached; it does not claim absent-envelope or before/after-support hooks were individually reached.
- Sound-events and definition/history fixture narratives correctly distinguish initial failures, the metadata corrections, unchanged PCM allowances and production caps, final corrected passes (171/171 for definition/history), and the interrupted isolated run (89 pass/82 fail, no acceptance credit). The restoration record reports 2,231 source inputs restored and preserved owned pins; the final definition suite was rerun successfully.
- Suite arithmetic is consistent: Plan library 262/249 plus 450 integration tests per root; Audio library 419/413 with six ignored; Stage 203/203; definition/history 171/171; 207/207 across the other 18 Audio integration executables. The separate Main Split result is 3 pass/4 fail in 257.58 seconds, and its four table entries match the retained failure output. General sound-bearing Split remains disabled.
- The current native equality record confirms 336,993 bytes, SHA-256 `f075df4c9d1113cf436a06d0230c49108ea521d31da489c5c407195ab09b2af1`, byte equality, and the documented cold/repeat work deltas. The report correctly says these are work counts, not speed or RSS.
- The inventory currently hashes to `77e107c0184a89acd3d7b826d8c33327ab1018efdae2d16336ba2b829d7bb862`, as stated in the qualification page. Its 1,562 gzip entries and aggregate stored/expanded byte counts agree with the prose; all listed compressed and expanded lengths and SHA-256 digests were independently verified. The final audit and filesystem-interruption/restoration records support the corresponding publication claims.

## Publication caveat

The qualification page names the inventory's current pre-review SHA-256. Per the publication workflow, the parent plans to append this review and its resolution to the inventory, which will change that digest. Update the prose hash after that append and verify the resulting inventory digest; the current named hash is accurate for the inventory reviewed here.

This review checked published evidence and claims only. It did not rerun builds or native tests, and the stated results are evidence cross-checks, not a new runtime verification.
