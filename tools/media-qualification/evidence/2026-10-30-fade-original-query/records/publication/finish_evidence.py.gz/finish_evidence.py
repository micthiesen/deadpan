from pathlib import Path
import gzip,hashlib,json
s=Path(__file__).resolve().parent;root=Path('/Users/michael/Code/deadpan');scope=Path('/tmp/deadpan-query-groundwork-2026-10-26/scoped')
dest=root/'tools/media-qualification/evidence/2026-10-30-fade-original-query'
p=dest/'inventory.json';old=p.read_bytes();inv=json.loads(old)
assert hashlib.sha256(old).hexdigest()=='77e107c0184a89acd3d7b826d8c33327ab1018efdae2d16336ba2b829d7bb862'
records={'review-publication.md':(s/'review-publication.md').read_bytes(),'publication-review-resolution.md':(s/'publication-review-resolution.md').read_bytes(),'inventory-before-publication-review.json':old,'finish_evidence.py':Path(__file__).read_bytes()}
for name,data in records.items():
 path=dest/'records/publication'/(name+'.gz');assert not path.exists();path.parent.mkdir(parents=True,exist_ok=True)
 packed=gzip.compress(data,mtime=0);path.write_bytes(packed)
 inv['files'].append({'path':str(path.relative_to(dest)),'bytes':len(packed),'sha256':hashlib.sha256(packed).hexdigest(),'expanded_bytes':len(data),'expanded_sha256':hashlib.sha256(data).hexdigest()})
p.write_text(json.dumps(inv,indent=2)+'\n')
result={'files':len(inv['files']),'stored_bytes':sum(r['bytes']for r in inv['files']),'expanded_bytes':sum(r['expanded_bytes']for r in inv['files']),'inventory_sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
prior=json.loads((s/'published-evidence.json').read_text())
reportpath=root/'docs/qualification/fade-original-query-admission-2026-10-30.md';report=reportpath.read_text()
for key in ['files','stored_bytes','expanded_bytes']:
 a=f"{prior[key]:,}";b=f"{result[key]:,}";assert report.count(a)==1,(key,a);report=report.replace(a,b)
assert report.count(prior['inventory_sha256'])==1
report=report.replace(prior['inventory_sha256'],result['inventory_sha256'])
reportpath.write_text(report);(scope/reportpath.relative_to(root)).write_text(report)
(s/'published-evidence-final.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result))
