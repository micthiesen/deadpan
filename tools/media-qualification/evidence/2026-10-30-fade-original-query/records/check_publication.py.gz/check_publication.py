from pathlib import Path
import gzip,hashlib,json,subprocess
s=Path(__file__).resolve().parent; root=Path('/Users/michael/Code/deadpan'); scope=Path('/tmp/deadpan-query-groundwork-2026-10-26/scoped')
sha=lambda b:hashlib.sha256(b).hexdigest()
owned=set(json.loads((s/'owned-paths.json').read_text()))
docs={'docs/qualification/fade-original-query-admission-2026-10-30.md','docs/spec/AGENT_HANDOFF.md','docs/REQUIREMENTS.md'}
prefix='tools/media-qualification/evidence/2026-10-30-fade-original-query/'
inv=json.loads((root/(prefix+'inventory.json')).read_text())
evidence={prefix+r['path']for r in inv['files']}|{prefix+'inventory.json'}
assert {str(p.relative_to(root))for p in(root/prefix).rglob('*')if p.is_file()}==evidence
staged=set(subprocess.check_output(['git','diff','--cached','--name-only'],cwd=root,text=True).splitlines())
assert staged==owned|docs|evidence,('scope mismatch',staged-(owned|docs|evidence),(owned|docs|evidence)-staged)
entries={}
for line in subprocess.check_output(['git','ls-files','--stage'],cwd=root,text=True).splitlines():
 mode,oid,rest=line.split(' ',2); stage,name=rest.split('\t',1)
 entries[name]=(oid,stage)
for name in owned|docs:
 data=(scope/name).read_bytes()
 assert entries[name]==(hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest(),'0'),name
for row in inv['files']:
 data=(root/(prefix+row['path'])).read_bytes(); plain=gzip.decompress(data)
 assert len(data)==row['bytes'] and sha(data)==row['sha256'],row['path']
 assert len(plain)==row['expanded_bytes'] and sha(plain)==row['expanded_sha256'],row['path']
for variant,here in [('main',root),('scoped',scope)]:
 initial=json.loads((s/(variant+'-initial-authority.json')).read_text())
 for name,pin in initial.items():
  if name not in owned:assert sha((here/name).read_bytes())==pin['sha256'],(variant,name)
 for name,pin in json.loads((s/(variant+'-final-source-pins.json')).read_text()).items():
  assert sha((here/name).read_bytes())==pin['sha256'],(variant,name)
result={'staged_files':len(staged),'source_and_fixtures':len(owned),'docs':len(docs),'evidence_files':len(evidence),'inventory_sha256':sha((root/(prefix+'inventory.json')).read_bytes()),'source_blobs_match_scoped':True,'unowned_initial_inputs_unchanged':True,'complete_archive_verified':True}
(s/'publication-index-audit.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result))
