from pathlib import Path
from datetime import datetime,timezone
import json,hashlib,re
s=Path(__file__).resolve().parent;label='fade-terminal-scoped-audio-audio-definition'
p=s/(label+'.json');receipt=json.loads(p.read_text());assert'exit_code'not in receipt
stdout=(s/(label+'.stdout')).read_text()
assert'test result: FAILED. 89 passed; 82 failed;'in stdout
assert 'No such file or directory'in stdout
sha=lambda b:hashlib.sha256(b).hexdigest()
streams={str(p):{'bytes':p.stat().st_size,'sha256':sha(p.read_bytes())}for p in[s/(label+'.stdout'),s/(label+'.stderr')]}
binary_after={name:{'bytes':Path(name).stat().st_size,'sha256':sha(Path(name).read_bytes())}for name in receipt['binary_before']}
assert binary_after==receipt['binary_before']
result={'label':label,'raw_incomplete_receipt_sha256':sha(p.read_bytes()),'observed_completion_at':datetime.now(timezone.utc).isoformat(),'test_summary':{'passed':89,'failed':82,'seconds_reported_by_test_harness':108.92},'runner_exit_code':1,'child_exit_code':'not recorded by runner; failed test summary observed','source_guard_status':'failed to complete: .cargo/config.toml missing at post-run stat; 2231 initial source paths missing in subsequent inspection','native_media_failure':'runtime WAV path native/deadpan-source/tests/audio-fixtures/pcm-stereo-48000.wav missing at FixtureProvider::new','source_restoration_receipt':'scoped-restoration.json','streams':streams,'binary_after':binary_after,'binaries_unchanged':True,'acceptance_credit':False,'timing_limit':'Observed completion is a conservative upper bound, not the native process finish timestamp.'}
(s/'filesystem-interruption.json').write_text(json.dumps(result,indent=2)+'\n')
print('Retained original incomplete receipt and recorded explicit failed source guard; no acceptance credit.')
