from pathlib import Path
s=Path(__file__).resolve().parent
p=s/'plan-tests-candidate/fade_query_admission_tests.rs'
before=p.read_text();(s/'plan-tests-candidate/before-contract-review.rs').write_text(before)
text=before
anchor='''        let value = admitted(parent, range.clone(), Default::default(), &mut generous).unwrap();
        assert_true(&value, &row["output"]["query"], &generous);'''
assert text.count(anchor)==1
text=text.replace(anchor,'''        let mut observer = Observer::new(&mut generous);
        let value = admitted(parent, range.clone(), Default::default(), &mut observer).unwrap();
        let allocations = observer.reservation_layouts.clone();
        let prefixes = observer.reservations.clone();
        drop(observer);
        assert_true(&value, &row["output"]["query"], &generous);''',1)
anchor='''        assert!(
            admitted(parent, range, Default::default(), &mut short_memory).is_err()
        );'''
# Match current rustfmt exactly, then replace the single statement below.
if anchor not in text:
 anchor='''        assert!(admitted(parent, range, Default::default(), &mut short_memory).is_err());'''
assert text.count(anchor)==1,anchor
text=text.replace(anchor,'''        let refused = allocations
            .iter()
            .position(|(live, size)| live.checked_add(*size).unwrap() > peak - 1)
            .expect("the exact peak has an actual reservation");
        assert!(matches!(
            admitted(parent, range, Default::default(), &mut short_memory),
            Err(PlanError::AudioQueryLimit("test wide allocation refusal"))
        ));
        assert_eq!(short_memory.0.borrow().reservations, refused + 1);
        assert_eq!(short_memory.0.borrow().forwarded, prefixes[refused]);''',1)
anchor='''        drop(value);
        assert_eq!(admission.0.borrow().live, 0);
    });
    assert_eq!(checked, 960);'''
assert text.count(anchor)==1
text=text.replace(anchor,'''        drop(value);
        let state = admission.0.borrow();
        assert_eq!((state.work_calls, state.reservations, state.forwarded, state.live), (0, 0, 0, 0));
    });
    assert_eq!(checked, 960);''',1)
anchor='''        assert_eq!(
            oracle::query_snapshot(value.query())["spans"],
            row["output"]["query"]["spans"]
        );'''
assert text.count(anchor)==1
text=text.replace(anchor,'''        let observed = oracle::query_snapshot(value.query());
        let old = &row["output"]["query"];
        assert_eq!(observed.as_object().unwrap().len(), 3);
        assert_eq!(observed["spans"], old["spans"]);
        assert_eq!(observed["lookup"], old["lookup"]);
        assert_eq!(value.canonical_units(), old["work"].as_u64().unwrap() as usize);
        assert_eq!(observed["work"].as_u64().unwrap() as usize, value.work());
        assert_eq!(value.work(), value.canonical_units() + value.additional_units());
        assert!(value.was_forwarded());
        assert_eq!(state.borrow().forwarded, value.work());''',1)
anchor='''    reservations: Vec<usize>,
}'''
assert text.count(anchor)==1
text=text.replace(anchor,'''    reservations: Vec<usize>,
    reservation_layouts: Vec<(usize, usize)>,
    merges: Vec<usize>,
}

impl<'a> Observer<'a> {
    fn new(policy: &'a mut Policy<true>) -> Self {
        Self { policy, spends: Vec::new(), reservations: Vec::new(), reservation_layouts: Vec::new(), merges: Vec::new() }
    }
}''',1)
anchor='''        let lease = self.policy.reserve(layout)?;
        self.reservations.push(self.policy.0.borrow().forwarded);'''
assert text.count(anchor)==1
text=text.replace(anchor,'''        let before = self.policy.0.borrow().live;
        let lease = self.policy.reserve(layout)?;
        self.reservations.push(self.policy.0.borrow().forwarded);
        self.reservation_layouts.push((before, layout.size()));''',1)
anchor='''        self.policy.merge(target, source);
    }
}'''
assert text.count(anchor)==1
text=text.replace(anchor,'''        self.merges.push(self.policy.0.borrow().forwarded);
        self.policy.merge(target, source);
    }
}''',1)
anchor='''        let mut observer = Observer {
            policy: &mut baseline,
            spends: Vec::new(),
            reservations: Vec::new(),
        };'''
assert text.count(anchor)==1
text=text.replace(anchor,'        let mut observer = Observer::new(&mut baseline);',1)
p.write_text(text)
print('Tightened allocation refusal, empty callback, lifetime and merge observations.')
