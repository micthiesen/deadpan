from pathlib import Path
import json,re
s=Path(__file__).resolve().parent
root=Path('/Users/michael/Code/deadpan');scope=Path('/tmp/deadpan-query-groundwork-2026-10-26/scoped')
a=json.loads((s/'final-audit.json').read_text());e=json.loads((s/'published-evidence.json').read_text())
assert a['all_terminal']
split_errors=re.findall(r'^(.+), revision ([^,]+), limited ([^:]+): (.+)$',(s/'fade-final-fresh-split.stderr').read_text(),flags=re.M)
assert len(split_errors)==a['split']['failed']
split_table="\n| Witness | Revision | Window | Actual error |\n| --- | --- | --- | --- |\n"+"".join(f"| {w} | {r} | {window} | {error} |\n"for w,r,window,error in split_errors)
split_short="\n".join(f"- {w}: {r}, {window}, "+("frozen projection work exhausted"if"frozen projection work exhausted"in error else"plan work per read"if"plan work per read"in error else error)+"."for w,r,window,error in split_errors)
d=a['current_native_body'];cold=d['work_deltas']['cold'];warm=d['work_deltas']['repeat'];split=a['split']
def suite(variant,target):
 rows=[v for v in a['tests'].values()if v.get('variant')==variant and v.get('target')==target];assert len(rows)==1;return rows[0]
report=(s/'qualification-draft.md').read_text()
report=report.replace('Status: implementation and logical verification complete; final native verification pending.','Status: reviewed and verified backend checkpoint, 2026-10-30.')
anchor='## Verification pending\n'
assert report.count(anchor)==1
report=report[:report.index(anchor)]+'''## Verification and publication

All production source preceded both final qualified native builds. A later independent sound_events and audio_definition test-only corrections is covered by revised builds and strict checks. Previously passing native targets are reused only where final executable bytes match exactly; each reused receipt is listed in evidence.

| Final suite | Main | Isolated |
| --- | ---: | ---: |
| Plan library | 262 passed, 14 ignored | 249 passed, 14 ignored |
| Plan integrations | 450 passed in 28 executables | 450 passed in 28 executables |
'''
for target,title in [('deadpan_audio','Audio library'),('stages','Ordinary native Stage'),('audio_definition','Native definition/history')]:
 m=suite('main',target);n=suite('scoped',target)
 extra=lambda row: f"{row['passed']} passed"+(f", {row['ignored']} ignored"if row['ignored']else'')+f", {row['seconds']:.2f} s"
 report+=f"| {title} | {extra(m)} | {extra(n)} |\n"
others={}
for variant in ['main','scoped']:
 rows=[v for v in a['tests'].values()if v.get('variant')==variant and v.get('target')not in['deadpan_audio','stages','audio_definition']]
 assert len(rows)==18
 others[variant]=sum(v['passed']for v in rows)
report+=f"""
All 21 native Audio executables per root have passing results, including {others['main']}/{others['scoped']} tests in the other 18 integration executables. Native executables ran serially. The current producer ran one exact ignored test in each root, outside ordinary suite coverage. Existing ignored tests and manual OLD producers supply no ordinary-suite credit. Core source is unchanged from the prior checkpoint; its previously recorded 827/802 results are not represented as new runs.

Main cargo xtask check --no-test, isolated all-target Plan/Audio Clippy with warnings denied, formatting and Main hygiene pass. Final builds use opt-level 2 with debug assertions and overflow checks. Plan feedback remains unoptimized.

Complete eight-case current native bodies agree byte for byte: {d['bytes']:,} bytes, SHA-256 {d['sha256']}. Every changed work debit reconciles with actual phase receipts. Cold work adds {min(cold)}-{max(cold)} units over fully legacy; warm reads retain {-max(warm)}-{-min(warm)}-unit savings. These are work counts, not speed or RSS measurements.

The separate fresh Main General Split audit has {split['passed']} passes and {split['failed']} failures in {split['seconds']:.2f} seconds. The exact failures are:
{split_table}
Their stdout/stderr are retained in evidence. General sound-bearing Split remains disabled; no failure is waived.

All 45 staged source/fixture paths equal the isolated candidate. Main matches 44 exactly; only plan.rs retains unrelated research module declarations in its working tree while its staged blob equals the isolated file. The source-only staged tree is {a['source_tree']}. The source patch has {a['source_patch']['bytes']:,} bytes, SHA-256 {a['source_patch']['sha256']}. The initial 2,764 Main and 2,436 isolated inputs outside the owned scope remain unchanged; all seventeen immutable oracle bodies retain their pins.

The [evidence inventory](../../tools/media-qualification/evidence/2026-10-30-fade-original-query/inventory.json) contains {e['files']:,} deterministic gzip records ({e['stored_bytes']:,} stored bytes, {e['expanded_bytes']:,} expanded bytes). Its SHA-256 is {e['inventory_sha256']}. Every compressed and expanded record was reread and verified. Complete raw OLD/current bodies, owned before/current/candidate source, exact shipping patch, commands, environment, source/executable/stream pins, failures, resource observations and reviews are retained. A bounded 50-file Main Rust overlay preserves the inherited research context for the separate Split audit; it is not shipping implementation. Executables and the broad base archive are excluded.

Independent reviews cover the OLD producer/capture, constructor design, host lifetime, shared merge ownership, final general/resource lenses, test tightening and metadata fixtures. The Plan test-contract assertions were tightened before final runs. A proposed unused Range import finding was dismissed because the included child metadata module uses it. No concrete material finding remains in those reviews. All initial merge, fixture, compiler, lint and sound-events failures remain evidence.

No UI, model generation, release bundle, export or broader product acceptance is established by this backend checkpoint.

## Continuation

The next bounded unit is the actual standalone retained-fade constructor and its read_retained_controlled lifetime. Freeze complete OLD retained input provenance and work before changing it. Actual admitted-created handles can contain augmented resolved work; ordinary reconstruction is not an interchangeable witness. Only one of the six previous retained factory setups returned Some, so that supplement does not establish the broader path. Other variable containers, inner ordinary queries and full recursive preparation remain owed under the active full-product goal.
"""
rel=Path('docs/qualification/fade-original-query-admission-2026-10-30.md')
assert not(root/rel).exists()
(root/rel).write_text(report);(scope/rel).write_text(report)
handoff=root/'docs/spec/AGENT_HANDOFF.md';text=handoff.read_text()
old='## Current state: policy Original queries admitted, product goal active'
assert text.count(old)==1
text=text.replace(old,'## Policy Original queries admitted (historical)',1)
pos=text.index('## Policy Original queries admitted (historical)')
current=f"""## Current state: four Original queries admitted, product goal active

The [fade-query checkpoint](../qualification/fade-original-query-admission-2026-10-30.md)
admits actual Root/physical-Domain fades and retains the conditional fourth
carrier through Original prediction and numerical consumption. Actual primary,
geometry, envelope, origin and side-buffer operations retain their overlapping
Plan/Core leases. The shared private merge helper checks both issuer lanes
before and after every actual merge; all 49 callers propagate failure.

After publishing policy checkpoint 7da84fc1b57897bd990a51f575b60f1b903c7318,
both roots froze 2,354 complete OLD Root/Domain observations from 80 parents.
False mode replays all fields/errors/work/lookup without spend/reserve/merge callbacks; true mode
compares all 1,046 successful outputs under literal span caps and the existing
default work allowance for new fees. Exact/one-short admitted work and requested
Layout peaks cover all 80 full parents. Nine focused Plan tests plus real WAV
host tests cover allocation overlap, accepted-prefix failure, cancellation,
issuer rotation, optional fade comparison and complete cleanup. All seventeen
immutable oracle bodies retain their hashes.

Four-product eviction evidence uses two real cached 256-frame WAV windows and
reconciles actual host eviction once in both lanes. Native residency fixtures
measure simultaneous metadata separately from PCM. Four sound-events fixtures
initially refused before their provider/cancellation sentinel; they now add
actual measured metadata to their unchanged PCM allowances. All six pass,
including the larger refusal and repeated cleanup. Production caps are unchanged.

Main/isolated Plan pass 262/249 plus all 28 integration executables, 450 tests
each; Audio {suite('main','deadpan_audio')['passed']}/{suite('scoped','deadpan_audio')['passed']};
ordinary Stage 203/203; definition/history 171/171; the other 18 Audio integration
executables pass {others['main']}/{others['scoped']}. Plan retains fourteen ignored tests
and Audio six. All 21 native Audio executables per root have passing results;
unchanged executable pins retain earlier passes after the independent test-only
correction. Final strict checks, formatting, hygiene, reviews and source/index/
evidence audits pass. Complete eight-case native bodies agree exactly.
Cold work adds {min(cold)}-{max(cold)} units over fully legacy; warm savings remain
{-max(warm)}-{-min(warm)}. These are work counts, not speed or RSS measurements.

Fresh Split: {split['passed']} pass/{split['failed']} fail in {split['seconds']:.2f} seconds.
{split_short}
General sound-bearing Split remains disabled. All 45 shipping source/fixture
paths equal the isolated candidate. Main's unrelated research, including its
working-tree-only plan.rs module declarations, remains unpublished.

Next freeze complete OLD standalone retained-fade queries and actual retained
input provenance before changing that independent product and its
read_retained_controlled lifetime. An actual admitted-created retained handle
can carry augmented resolved.work; do not replace it with an ordinary rebuild
or normalize that scalar. The prior six-factory supplement has only one Some.
Other variable containers, inner ordinary queries and complete recursive
preparation remain open. No cap, prior weight, refund, requirement or gate
changes. The full DP-01..24/Gates A..G goal stays active.

"""
text=text[:pos]+current+text[pos:]
handoff.write_text(text);(scope/handoff.relative_to(root)).write_text(text)
req=root/'docs/REQUIREMENTS.md';text=req.read_text()
anchor='The following paragraphs retain the earlier preparation checkpoints and their\noriginal three-pass/four-fail results.\n'
assert text.count(anchor)==1
para=f"""The [fade Original query checkpoint](qualification/fade-original-query-admission-2026-10-30.md)
admits actual Root/physical-Domain fades and the conditional fourth Original
carrier. The independent 80-parent OLD corpus has 2,354 actual calls; true mode
compares all 1,046 successes and false mode all complete outputs/errors/work.
All seventeen oracle pins remain unchanged. Nine focused Plan tests and real
WAV/ReadWork tests cover actual overlapping layouts, exact/short work and peaks,
issuer/cancellation/refusal cleanup, optional consumption and four-product
eviction receipts. The shared merge seam checks both issuer lanes before and
after all actual callbacks. Main/isolated Plan pass 712/699 including integrations,
Audio {suite('main','deadpan_audio')['passed']}/{suite('scoped','deadpan_audio')['passed']},
ordinary Stage 203/203, definition/history 171/171 and all other Audio integration
executables. Strict checks, reviews and source/index/evidence audits pass.
Complete current native bodies agree; cold work adds {min(cold)}-{max(cold)} units
over fully legacy and warm savings remain {-max(warm)}-{-min(warm)}.
Fresh General Split remains {split['passed']} pass/{split['failed']} fail in
{split['seconds']:.2f} seconds and stays disabled. Standalone retained-input fades,
other variable containers, inner ordinary queries and full recursive preparation
remain open. No cap, prior weight, refund, requirement/gate status or speed/RSS
claim changes.

"""
text=text.replace(anchor,para+anchor,1);req.write_text(text);(scope/req.relative_to(root)).write_text(text)
print('Wrote qualification, current handoff and tracker paragraph without changing requirement statuses.')
