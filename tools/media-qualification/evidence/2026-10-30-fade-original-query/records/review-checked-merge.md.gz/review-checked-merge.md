# Checked lease merge review

## Findings

None in the integrated checked-merge change, within the requested ownership and opaque-Core-lane lens.

`QueryBudget::merge_checked` now checks both memories before merging, then checks the target and source again after the callback (`crates/deadpan-plan/src/audio_owner_query_admission.rs:316-331`). The merge-rotation path therefore returns the issuer mismatch at the merge boundary. All 49 callers in the Plan source propagate that result with `?`; the Main and scoped patch snapshots are byte-identical.

I traced the newly fallible post-merge points where values may already have moved. The boundary extent owns its `AudioExtent` before its three Memory lanes, so a failed `finish` drops boundary vectors before guards (`audio_boundary.rs:154-160,240-252`). Owner repeat state and flattened build likewise put values before guards (`audio_owner_query.rs:7-10,98-111`; `audio_flattened_query.rs:49-55,157-162`). At these sites a merge callback that rotates the issuer has already transferred the source lease into the target before the postcheck fails; the target remains the live guard for the value, and propagated failure unwinds the owner. In the boundary finish case, the first failed merge stops before attempting the second, while the still-separate end lane remains guarded until its value is dropped.

The exact regression diagnostic is consistent with this fix: the failing callback merged leases, rotated the issuer, and the former implementation reached a later merge that asserted on the stale issuer. The new central postcheck covers that callback behavior, and the existing refusal/rotation conservation test is structured to verify every accepted merge prefix and released old/current lease state.

## Limits

Static review only. I did not run Cargo or native checks, as requested. The parent reported both Plan library builds running; no build result is inferred here. This review does not assess unrelated changes in the broader shared worktree.
