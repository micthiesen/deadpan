from pathlib import Path
import hashlib,json
s=Path(__file__).resolve().parent
roots={'main':Path('/Users/michael/Code/deadpan'),'scoped':Path('/tmp/deadpan-query-groundwork-2026-10-26/scoped')}
owned=json.loads((s/'owned-paths.json').read_text())
for name in owned:
 base=s/'base-source'/name
 if base.exists():
  target=s/'published-before'/name
  target.parent.mkdir(parents=True,exist_ok=True)
  assert not target.exists()
  target.write_bytes(base.read_bytes())
 for variant,root in roots.items():
  target=s/'published-source'/variant/name
  target.parent.mkdir(parents=True,exist_ok=True)
  assert not target.exists()
  target.write_bytes((root/name).read_bytes())
initial=json.loads((s/'main-initial-authority.json').read_text())
overlay={}
for name in initial:
 if not name.endswith('.rs'):continue
 main=roots['main']/name
 other=roots['scoped']/name
 if not other.exists() or main.read_bytes()!=other.read_bytes():
  target=s/'main-diagnostic-overlay'/name
  target.parent.mkdir(parents=True,exist_ok=True)
  assert not target.exists()
  data=main.read_bytes();target.write_bytes(data)
  overlay[name]={'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}
(s/'main-diagnostic-overlay.json').write_text(json.dumps(overlay,indent=2)+'\n')
print({'owned_source_paths':len(owned),'main_rust_overlay_files':len(overlay)})
