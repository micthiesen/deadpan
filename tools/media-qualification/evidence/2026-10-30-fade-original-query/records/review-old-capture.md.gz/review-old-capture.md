# OLD fade capture audit

## Findings

None open in the final frozen capture package.

The two original `fade-old-*` build receipts did contain warnings in the test-only capture producer (an unused `deadpan_core::*` import and an unused `gap_cases::ratio` helper). The producer was cleaned up before the final frozen-baseline build: both `fade-frozen-*` build receipts have no compiler warnings, and `frozen-baseline-audit.json` records zero for Main and scoped. This is resolved, not a remaining finding.

## Evidence reviewed

- Both capture builds use the exact pinned `deadpan_plan` test executable, test profile, debug assertions and overflow checks. Each runs only `capture_old_fade_query_baseline_v1` with `--ignored --exact --test-threads=1`; both pass. Capture stderr is empty. The external OLD regression passes once for each Main and scoped variant.
- Source/runtime pins and the published checkpoint `7da84fc1b57897bd990a51f575b60f1b903c7318` are recorded. Existing source inputs remain unchanged except the test-only module declaration; actual fade implementation/callers remain pinned.
- I independently parsed both OLD bodies. Removing only `variant`, `source_sha256`, and `published_policy_checkpoint` yields equality between Main, scoped, and the canonical body. Canonical bytes are 2,302,377 with SHA-256 `09502b80324734819b4f9acdd62b1dbd42eeeb29083d61366ecc88d28f8526f7`.
- Successful rows include samples, every span and edge field, complete boundary origins, lookup stats, and explicit work. Error rows preserve typed errors, requests and limits.
- Actual Root/physical-Domain coverage is 80 parents (63 Root, 17 Domain), 2,354 calls (1,046 success, 1,308 error), and all 80 default-full calls succeed with canonical work 7 through 356. Error counts: 640 invalid-limit, 320 out-of-range, 240 structural-work, and 108 span-count. Exact work caps pass all 80 and one-short work caps fail all 80. Exact span caps pass all 80; one-short positive span caps are applicable to 54 cases and fail all 54. The remaining 26 have no legal positive predecessor.
- Retained-input factory evidence is separate: six setups, one `Some`, six actual fade calls (four success, two error). The five `None` setups add no fade calls.

## Limits

The body freezes named requests and outputs, not internal terminal-dispatch or allocation branches. It supports output parity and named-case claims, but does not establish direct runtime branch coverage. The broad recursive `result_counts` in `old-equality-and-coverage.json` include the retained supplement; use `actual-call-coverage.json` for Root/Domain totals.

Read-only review; no source edits, Cargo runs, captures, or Git operations were performed.
