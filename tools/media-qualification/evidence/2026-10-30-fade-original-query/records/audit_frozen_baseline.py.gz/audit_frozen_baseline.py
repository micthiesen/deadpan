from pathlib import Path
import json,hashlib,re
s=Path(__file__).resolve().parent
sha=lambda b:hashlib.sha256(b).hexdigest()
owned=set(json.loads((s/'owned-baseline-paths.json').read_text()))
result={'published_policy_checkpoint':(s/'published-policy-checkpoint.txt').read_text().strip(),'immutable_oracles':17,'variants':{}}
for variant,root,passed in [('main',Path('/Users/michael/Code/deadpan'),253),('scoped',Path('/tmp/deadpan-query-groundwork-2026-10-26/scoped'),240)]:
 initial=json.loads((s/(variant+'-initial-authority.json')).read_text())
 unchanged=0
 for name,pin in initial.items():
  if name in owned:continue
  assert sha((root/name).read_bytes())==pin['sha256'],(variant,name)
  unchanged+=1
 for pin in json.loads((s/'immutable-oracle-pins.json').read_text()):
  assert sha((root/pin['path']).read_bytes())==pin['sha256'],(variant,pin['path'])
 pins={name:{'bytes':len((root/name).read_bytes()),'sha256':sha((root/name).read_bytes())}for name in sorted(owned)}
 (s/(variant+'-frozen-baseline-source-pins.json')).write_text(json.dumps(pins,indent=2)+'\n')
 for suffix in ['build','plan']:
  label='fade-frozen-'+variant+'-'+suffix
  receipt=json.loads((s/(label+'.json')).read_text())
  assert receipt['exit_code']==0 and receipt['sources_unchanged'] and receipt['binaries_unchanged']
  for name,pin in receipt['source_after'].items():assert sha(Path(name).read_bytes())==pin['sha256'],name
 text=(s/('fade-frozen-'+variant+'-plan.stdout')).read_text()
 assert f'test result: ok. {passed} passed; 0 failed; 14 ignored;'in text
 for line in(s/('fade-frozen-'+variant+'-build.stdout')).read_text().splitlines():
  try:v=json.loads(line)
  except ValueError:continue
  assert not(v.get('reason')=='compiler-message' and v['message']['level']=='warning')
 result['variants'][variant]={'unchanged_existing_source_inputs_outside_test_declaration':unchanged,'plan_passed':passed,'plan_ignored':14,'compiler_warnings':0,'final_baseline_pins':len(pins)}
result['coverage']=json.loads((s/'actual-call-coverage.json').read_text())
result['canonical_sha256']=sha((s/'fade-old-canonical-body.json').read_bytes())
(s/'frozen-baseline-audit.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
