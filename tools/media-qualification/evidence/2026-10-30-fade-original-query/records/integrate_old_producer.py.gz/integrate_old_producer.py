from pathlib import Path
import hashlib,json,difflib
s=Path(__file__).resolve().parent;prior=Path('/tmp/deadpan-policy-query-admission-2026-10-30');candidate=s/'old-producer-candidate'
paths=['crates/deadpan-plan/src/audio_owners/legacy_snapshot_v1/fade_query_baseline.rs','crates/deadpan-plan/src/audio_owners/legacy_snapshot_v1/fade_query_cases.rs']
decl='crates/deadpan-plan/src/audio_owners/legacy_snapshot_v1.rs'
marker='#[path = "legacy_snapshot_v1/policy_query_baseline.rs"]\npub(in crate::plan) mod policy_query_baseline;'
addition='\n\n#[path = "legacy_snapshot_v1/fade_query_baseline.rs"]\npub(in crate::plan) mod fade_query_baseline;'
sha=lambda b:hashlib.sha256(b).hexdigest()
assert (s/'published-policy-checkpoint.txt').read_text().strip()=='7da84fc1b57897bd990a51f575b60f1b903c7318'
for variant,root in [('main',Path('/Users/michael/Code/deadpan')),('scoped',Path('/tmp/deadpan-query-groundwork-2026-10-26/scoped'))]:
 oldlist=json.loads((prior/('source-files.json' if variant=='main' else 'scoped-source-files.json')).read_text())
 authority={name:{'bytes':len((root/name).read_bytes()),'sha256':sha((root/name).read_bytes())}for name in oldlist}
 out=s/(variant+'-initial-authority.json');assert not out.exists();out.write_text(json.dumps(authority,indent=2)+'\n')
 original=(root/decl).read_text();assert original.count(marker)==1 and 'mod fade_query_baseline;'not in original
 before=s/'integration-before'/variant/decl;before.parent.mkdir(parents=True,exist_ok=True);before.write_text(original)
 for name in paths:assert not(root/name).exists()
 for name in paths:(root/name).write_bytes((candidate/name).read_bytes())
 (root/decl).write_text(original.replace(marker,marker+addition,1))
 names=sorted(set(oldlist)|set(paths))
 (s/(variant+'-logic-source-files.json')).write_text(json.dumps(names,indent=2)+'\n')
patch=''.join('diff --git a/'+name+' b/'+name+'\nnew file mode 100644\n'+''.join(difflib.unified_diff([], (candidate/name).read_text().splitlines(keepends=True),fromfile='/dev/null',tofile='b/'+name))for name in paths)
(candidate/'new-files.patch').write_text(patch)
pins={str(p.relative_to(candidate)):sha(p.read_bytes())for p in candidate.rglob('*')if p.is_file()and p.name!='candidate-pins.json'}
(candidate/'candidate-pins.json').write_text(json.dumps(pins,indent=2)+'\n')
(s/'owned-producer-paths.json').write_text(json.dumps([decl,*paths],indent=2)+'\n')
(s/'immutable-oracle-pins.json').write_bytes((prior/'immutable-oracle-pins.json').read_bytes())
(s/'producer-review-resolution.md').write_text('Before integration/capture, retained the reviewed original candidate. Corrected the span predecessor trial to execute only when the actual output has more than one span; otherwise explicit metadata records that no legal positive predecessor exists. No ordinary fade algorithm changed. Both actual roots received the corrected identical producer.\n')
print('Integrated corrected test-only OLD producer in Main and isolated roots.')
