# Final resource ownership/API review

## Findings

None within the assigned resource ownership and API lens.

The guarded query retains the actual `AudioFadeQuery` inside the same `GuardedBound<FadeBuffer<…>>`; the public surface exposes only immutable query/work/receipt accessors. No detached Core-backed binding, arbitrary provider factory, or public mutable allocation escape was introduced. The unmetered branch still delegates to the existing ordinary fade query, while metered Root and Domain calls enter the shared guarded constructor.

At construction, the primary walk remains owned and metered while the first start-side edge allocation is reserved, then remains live while the separately fallible opposite-side calculation and end-side reservation run. The side-growth path keeps the old vector and replacement vector charged together until the old allocation is explicitly dropped. Origin growth similarly retains old capacity while reserving the replacement; coincident edge copies keep the new edge and old span guarded until the merge/move boundary. The post-merge issuer check in `merge_checked` covers a merge callback that rotates issuers, and audited callers propagate failure with the moved value still preceding its guards. The test-only phase observer brackets actual allocation sites; resource tests compare callback `Layout`s and live totals for initial sides, origin growth, side growth, and coincident origin merges, plus refusal/rotation at the actual second-side reservation.

The host carrier remains conditional on `edge_fades`, lives inside `PreparedQueries` through the existing read boundary, and participates in issuer validation after the existing three carriers but before numerical source I/O. Construction failures unwind earlier products; read/provider/cancellation failures drop all products through the request boundary. The fade-specific tests inspect real charged state at the provider callback, foreign-carrier rejection, work boundary, and capacity restoration after releasing only Fade. Prepared cache hits reuse the supplied carrier and still perform all four issuer checks; an early cache hit does not construct carriers. Existing test-only legacy behavior remains isolated behind its fade flag.

## Limits

This was static review only. I did not run Cargo, native, browser, or runtime checks, and I did not read the large golden snapshot body. The parent’s separate builds/checks are not assumed to have succeeded. The broad list of 49 fallible merge callers was not exhaustively re-audited beyond the fade path and the relevant guarded merge/value-before-guard patterns; the prior checked-merge review records its wider caller audit.
