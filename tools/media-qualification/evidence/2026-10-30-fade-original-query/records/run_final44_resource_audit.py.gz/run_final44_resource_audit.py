import hashlib, json, pathlib, re, subprocess, datetime
base = pathlib.Path('/tmp/deadpan-fade-query-admission-2026-10-30')
main = pathlib.Path('/Users/michael/Code/deadpan')
scope = pathlib.Path('/tmp/deadpan-query-groundwork-2026-10-26/scoped')
owned = json.loads((base/'owned-paths.json').read_text())
def digest(p):
    try: data=p.read_bytes()
    except FileNotFoundError: return None
    return {'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}
checks={}
for name, root, pinfile in [('main',main,'main-final-source-pins.json'),('scoped',scope,'scoped-final-source-pins.json')]:
    expected=json.loads((base/pinfile).read_text())
    mismatches=[]
    for rel,want in expected.items():
        if digest(root/rel)!=want: mismatches.append(rel)
    checks[name]={'expected_count':len(expected),'mismatches':mismatches}
diffs=[]
for rel in owned:
    a,b=digest(main/rel),digest(scope/rel)
    if a!=b: diffs.append({'path':rel,'main':a,'scoped':b})
oracles=json.loads((base/'immutable-oracle-pins.json').read_text())
oracle_mismatches=[]
for row in oracles:
    for label,root in [('main',main),('scoped',scope)]:
        got=digest(root/row['path'])
        if got is None or got['sha256']!=row['sha256'] or got['bytes']!=row.get('bytes',got['bytes']):
            oracle_mismatches.append({'tree':label,'path':row['path']})
initial={}
for label,root,file in [('main',main,'main-initial-authority.json'),('scoped',scope,'scoped-initial-authority.json')]:
    rows=json.loads((base/file).read_text())
    intersects=set(rows)&set(owned)
    mismatch=[]; missing=[]
    for rel,want in rows.items():
        if rel in owned: continue
        got=digest(root/rel)
        if got is None: missing.append(rel)
        elif got!=want: mismatch.append(rel)
    initial[label]={'captured_paths':len(rows),'owned_paths_excluded':len(intersects),'unowned_checked':len(rows)-len(intersects),'unowned_missing':missing,'unowned_mismatches':mismatch}
# Plan test receipts: one receipt per emitted specific test binary invocation.
plan=[]
for label in ('main','scoped'):
    for p in sorted(base.glob(f'fade-final-{label}-plan-*.json')):
        rec=json.loads(p.read_text())
        if not p.name.endswith('.json') or 'build-pins' in p.name or 'build.json' in p.name: continue
        out=next(pathlib.Path(v) for v in rec['streams'] if v.endswith('.stdout'))
        lines=out.read_text(errors='replace').splitlines()
        res=next((x.strip() for x in lines if x.strip().lower().startswith('test result:')), '')
        m=re.search(r'(\d+) passed;\s*(\d+) failed(?:;\s*(\d+) ignored)?',res)
        passed,failed,ignored=(int(m.group(1)),int(m.group(2)),int(m.group(3) or 0)) if m else (None,None,None)
        plan.append({'tree':label,'receipt':p.name,'exit_code':rec['exit_code'],'passed':passed,'failed':failed,'ignored':ignored,'result_line':res,'source_guard':rec.get('sources_unchanged'),'binary_guard':rec.get('binaries_unchanged'),'all_pass':rec['exit_code']==0 and failed==0 and passed is not None})
strict=[]
for label in ('main','scoped'):
    p=base/f'fade-terminal-{label}-strict.json'
    rec=json.loads(p.read_text())
    strict.append({'tree':label,'receipt':p.name,'command':rec['command'],'exit_code':rec['exit_code'],'source_before_count':len(rec['source_before']),'source_after_count':len(rec['source_after']),'sources_unchanged':rec['sources_unchanged'],'binary_before_count':len(rec['binary_before']),'binary_after_count':len(rec['binary_after']),'binaries_unchanged':rec['binaries_unchanged']})
# Source-inventory run receipts are compared to current source inventories via recorded guard only.
# Read the corrected scope sound-events run and the stale failed attempt explicitly.
def test_receipt(name):
    rec=json.loads((base/name).read_text())
    stdout=next(pathlib.Path(v) for v in rec['streams'] if v.endswith('.stdout'))
    txt=stdout.read_text(errors='replace')
    result=next((x.strip() for x in txt.splitlines() if x.strip().lower().startswith('test result:')), '')
    return {'receipt':name,'command':rec['command'],'exit_code':rec['exit_code'],'result_line':result,'sources_unchanged':rec['sources_unchanged'],'binaries_unchanged':rec['binaries_unchanged']}
sound=[test_receipt(n) for n in ['fade-final-scoped-audio-sound-events.json','fade-revised-scoped-audio-sound-events.json']]
# Parent said corrected source has 6 tests and separate fade-sound-metadata2 build/run receipts.
metadata_build=json.loads((base/'fade-sound-metadata2-build.json').read_text())
metadata_run=json.loads((base/'fade-sound-metadata2.json').read_text())
# The stored command may reference build target; extract result from the runner stream.
def result_line(rec):
    out=next((pathlib.Path(v) for v in rec.get('streams',[]) if v.endswith('.stdout')),None)
    if out is None or not out.exists(): return ''
    return next((x.strip() for x in out.read_text(errors='replace').splitlines() if x.strip().lower().startswith('test result:')), '')
metadata={'build':{'exit_code':metadata_build['exit_code'],'source_guard':metadata_build.get('sources_unchanged'),'binary_guard':metadata_build.get('binaries_unchanged')},'run':{'exit_code':metadata_run['exit_code'],'result_line':result_line(metadata_run),'source_guard':metadata_run.get('sources_unchanged'),'binary_guard':metadata_run.get('binaries_unchanged')}}
# Check docs diff against required base using Main's git metadata, read-only.
docs=subprocess.run(['git','diff','--quiet','7da84fc1b57897bd990a51f575b60f1b903c7318','--','docs'],cwd=main).returncode
result={'audit':'final44 static source/inventory audit','audited_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':{'base':'7da84fc1b57897bd990a51f575b60f1b903c7318','owned_path_count':len(owned),'main':str(main),'scoped':str(scope)},'source_pins':checks,'owned_tree_differences':diffs,'immutable_oracles':{'count':len(oracles),'mismatches':oracle_mismatches,'contents_read':False},'initial_authority_retention':initial,'plan_receipts':{'count':len(plan),'passed':sum(x['passed'] or 0 for x in plan),'failed':sum(x['failed'] or 0 for x in plan),'ignored':sum(x['ignored'] or 0 for x in plan),'all_pass':all(x['all_pass'] and x['source_guard'] and x['binary_guard'] for x in plan),'all_source_binary_guards':all(x['source_guard'] and x['binary_guard'] for x in plan),'items':plan},'terminal_strict_receipts':{'count':len(strict),'all_pass':all(x['exit_code']==0 and x['sources_unchanged'] and x['binaries_unchanged'] for x in strict),'items':strict},'sound_events_receipts':sound,'corrected_scope_metadata_fixture_receipt':metadata,'docs_tracked_diff_from_base_exit_code':docs,'limits':['No builds, native runs, fixture-content reads or source edits were performed in this audit.','Test execution claims below are read from durable prior receipts; source guards are the recorded inventories for those runs, not a new execution.','No claim is made about native end-to-end runtime behavior beyond receipts explicitly listed.']}
(base/'final-source-audit-final44.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k!='plan_receipts'},indent=2))
print('plan receipts summary',result['plan_receipts']['count'],result['plan_receipts']['passed'],result['plan_receipts']['failed'],result['plan_receipts']['ignored'],result['plan_receipts']['all_pass'])
