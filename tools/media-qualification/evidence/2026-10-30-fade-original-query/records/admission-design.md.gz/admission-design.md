# Admit the actual Root and physical-Domain fade constructors

Read-only design against the published policy checkpoint `7da84fc1b57897bd990a51f575b60f1b903c7318` and the current shared sources. No actual source edits, build, capture, expected-body generation or production implementation were performed. Navigation used ripwire first, followed by bounded reads of the exact constructors, guard helpers and consuming call sites.

The parent reports the independent OLD fade witness is now reviewed and frozen in both roots at `crates/deadpan-plan/tests/fixtures/fade-query-baseline-v1/snapshot.json`: 2,302,377 bytes, SHA256 `09502b80324734819b4f9acdd62b1dbd42eeeb29083d61366ecc88d28f8526f7`. Its 80 actual parents are 63 Root and 17 Domain, with 2,354 calls, 1,046 successes and 1,308 typed errors. All 80 full default calls succeed with work 7 through 356. The separate six retained factories yield one Some; their six fade calls yield four successes and two errors. These are parent-reported execution facts, not runs performed by this worker.

## Recommended bounded unit and API

Implement one testable constructor closure: actual Root `audio_fades_admitted` and physical-Domain `fades_admitted`, including all their current ordinary Leaf, Stage and retained Bound work. Retain the returned carrier through conditional Original prediction and numeric read. Keep arbitrary signal/projected APIs and the standalone retained-input factory ordinary compatibility APIs; this scope follows the real public factories, not an invented refusal of a reachable internal variant.

Use a child `query` module of `audio_fades.rs`, preferably `audio_fade_query.rs`. Reexport its public carrier through `audio_fades` and the existing Plan exports, plus the narrow root lib reexport. The public type needs no sample or Plan lifetime generic because the actual returned AudioFadeQuery owns only sample labels and edge/origin metadata:

```rust
pub struct AdmittedAudioFadeQuery<I, L> {
    value: GuardedBound<FadeBuffer<I, L>, I, L>,
    canonical: usize,
    additional: usize,
    forwarded: bool,
}
struct FadeBuffer<I, L> {
    query: AudioFadeQuery,
    capacity: Memory<I, L>,
}
```

Expose immutable `query()`, `work()`, `canonical_units()`, `additional_units()` and `was_forwarded()` following the processing/policy conventions. No Clone, mutable query, charge detachment or public extraction. Root/Domain methods take the existing generic AudioSoundContextAdmission and return its Error. Actual Core guard lanes persist inside GuardedBound even after its mapped payload no longer contains AudioBound. No new Core composition API is required.

For `METERED == false`, call the existing literal ordinary Root/Domain constructor and wrap its actual result with an empty same-issuer guard, canonical equal to its existing work, additional zero and forwarded false. The wrapper must refuse use of this compatibility helper in true mode. This is the reviewed policy pattern and preserves all ordinary vec!/push/clone allocation behavior, observer behavior, error order and canonical work. It also preserves every ordinary retained-input caller of the existing shared retained helper. The existing deep physical walk already shares the actual generic implementation in both modes.

For true mode, validate limits and the exact Root/Domain range in the original order before creating the QueryBudget. Use one local Budget and one QueryBudget for the complete top product; child walks, capture and envelope-domain construction mutate that same budget. Do not call ordinary queries and charge their final size, fold their work/lookup again or use independent private 65,536-unit child allowances. Seal only at the top, checking cumulative canonical plus additional, actual remaining subtraction and returned query.work. Empty requests produce no spans, no header or collection allocation, canonical zero and additional zero. There is no requirement that an empty fade carrier have positive live bytes.

## Actual control flow and ownership

`audio_fades.rs:49` validates limits, rejects negative Root start, reversed range or end beyond actual audio_duration, then calls fade_query. `AudioDomain::fades:67` validates limits, then checks signed samples against the exact physical support. A Domain is not clipped to visible delivery. The top loop checks output span count before spend(1), then performs its actual true/true walk. Existing interval checks are start equality and positive advance; do not silently add a new top-level upper-end error check or substitute the retained factory's differently worded checks.

| Branch | Existing actual operations | Required ownership during each fallible step |
| --- | --- | --- |
| Leaf | derive voice sample extent; ordinary/retained edge construction; add_editorial | Whole first WalkResult and captured editorial data precede all Plan guards until origins move into the result. Source/Hold payloads and unused paths are real constructor copies even though fades later discard them. |
| Stage or ProjectedStage | retain first opaque processing output; run second false/false geometry walk; ordinary clip ends at the first processing allocation; add_editorial | First processing guard stays live throughout the second walk and all its allocations. Pass the same Owned editorial capture slot to the second walk, preserving actual replacement rather than accumulating the first capture. Old capture stays live while the walker constructs its replacement. |
| Bound | clip to current allocated end; compute exact q and positive step; build optional envelope Domain; transport outer editorial; handle out-of-support q; floor probe into retained geometry; inverse-ceil end; virtual width; retained edges; project captured constraints/incidents; add_editorial | Keep the whole first processing/Bound guard, outer capture, envelope Domain and its seed vectors, second walk and current result owned together through every error/callback. Do not move AudioBound out to call an ordinary helper. |

The existing primary `audio_walk_inner_admitted` accepts `Owned<EditorialCapture>` in WalkCaptures, returns `WalkResult { value: GuardedBound<AudioWalkSpan>, memory }`, and already admits Source identity copies, Hold source copies, repeats, retimes, definition/gap identities, constraints/editorial, extent origins, Stage construction and actual Core binding resolution. Adopt the independent returned memory into its guarded value with `adopt_memory`; do not forget either lane. Preserve the actual `(true, true)` first flags and `(false, false)` geometry flags, seed and editorial-presence predicate. Do not replace Root traversal by physical capture or vice versa.

For true/true Leaf, map the whole guarded walk into the finished span or a partial span state; a general Leaf unwrap is unnecessary. For second false/false geometry, the existing narrow `WalkResult::flattened_leaf` is valid and retains both actual Plan lanes, refusing Stage/Core shapes. Do not broaden its documented contract to arbitrary primary values to avoid a map. The first Stage/Bound can remain in a surrounding value-first work state while the independently owned geometry is assembled, then be zipped/mapped into the final span. These are actual moves, not clones of the geometry origins.

Fade does not take policy's `raw_domain_admitted -> AudioBoundDomain::Point -> PointDomain.signal_admitted` clone path. Its existing `AudioBound::envelope_domain_query` returns an owned physical AudioDomain. It uses the resolved lattice origin, grid origin and RootRoundEven or PointCeil boundary rule, exact support and definition/gap selector, then restores evaluation definition, bypass binding, repeated path, constraints and instance. A Point binding therefore keeps PointCeil through the same physical envelope inspection. Adding a policy-style Point signal clone here would invent both storage and semantic work.

The physical walker contains no construction of AudioSignalContent::ProjectedStage today: its terminal mapper recognizes that variant and the fade dispatcher retains the compatibility arm, but reachable Retime construction returns Stage. Owned-Preserve input is rejected at its existing explicit error before ordinary Stage construction. Do not claim projected-source/tape admission from this arm, and do not add a new refusal to the public Root/Domain constructor. Confirm this reachability statement if the walker changes.

## Literal canonical debit sites

All of these old weights remain canonical. Additional fees account only for actual new ownership inspections, reservations, conversions and moves. Sort estimates, membership comparisons already prepaid by these lengths and unused budget are not additional work.

| Old site | Debit and order |
| --- | --- |
| fade_query:98 | Output span cap first, then 1 before each true/true walk. Keep every existing deep walker debit and lookup mutation literally. |
| envelope_domain / envelope_domain_query | `constraints.len + instance.repeats.len + 1` before nonpositive-support early return. Existing admitted helper already supplies it; do not charge it again. |
| retained_bound_fade:229 | `outer.editorial.len` after q/step, optional envelope creation and positive virtual-scale validation, before transforming markers. |
| retained_bound_fade matching owner | `marker.boundary.repeat_count` only after node, repeat-count and gap predicates match, before checking the actual repeat prefix and suppressing entry markers. A mismatching prefix still pays this old debit. |
| retained_bound_fade:317 | `captured.editorial.len + captured.constraints.len` after retained edges construct and before projecting the capture ranges/incidents. |
| add_editorial:397 | 1 per marker, before grid conversions and voice intersection/eligibility. Inactive and rejected incident sides still preserve this marker debit. |
| append_origins:467 | 1 per candidate constraint before validating its captured repeat prefix. For exact coordinate matches, BoundaryOwner capture pays `owner.repeats.len + 1`, constructs the origin, then the old code pays `output.len` before contains. Duplicate origins were still captured and inspected; retain that operation/order. |
| merge_edge:503 | `edges.len + 1` before finding coincident exact at. For every old origin, `new.origins.len + origin.instance.repeats.len + 1` before contains, even if no clone will follow. |

The primary/secondary walker and root_domain_on_grid_query canonical weights are already reviewed shared implementations, not a second local model to reproduce. Core receipts are consumed/accounted by bound_at_query before their guarded result is exposed; zip/map must neither forward them again nor detach them. Final fade values contain no nested resolved/lattice work counters, but the existing paired finite Core witness should still cover any actual metered binding resolution used here.

Old arithmetic remains fallible in its original order. In particular q is anchored at original allocated_samples.start, step positivity precedes envelope creation, virtual scale positivity follows successful Some(domain), and outside-support q checks occur only after the actual outer-editorial transformations. Floor selects a retained discrete interval without discarding fractional phase. inverse_end uses ceil and clamps before narrowing. Current delivered voice width and separately rounded historical virtual width remain independent.

## Actual allocations and replacement overlap

| Site | Storage/copies to admit |
| --- | --- |
| top spans Vec::push | Full replacement span buffer while prior spans, old buffer, current completed guarded span and every Core/Plan lane remain live. Reuse processing_query::{empty,push}; final outer capacity stays independently inside FadeBuffer. |
| retained:349 | Real one-element start Vec, then fallible opposite-side distance, then real one-element end Vec. Pre-admit the first buffer before its allocation; do not precompute/reorder the end-side error ahead of the start allocation. Empty retained support has two zero-capacity Vecs. Boundaries.start/end move, not clone. |
| add_editorial active incident side | Fresh origins Vec; captured constraints/editorial/repeats remain live. Each successful unique append may replace the buffer while the old origins, pending new origin and all existing span edges remain live. |
| append_origins capture | Actual independent NodeId/iteration/path ownership, repeated path Vec, optional gap identity and exact current policy. Reuse BoundaryOwner::capture_admitted. Keep a duplicate captured origin owned until its actual drop, then release its own lease. |
| merge_edge coincident side | Complete old edge/origins and complete new edge/origins coexist. If old is editorial, min length is scalar. Each unique old origin really clones its instance NodeId, repeat vector and each repeat's node/iteration identities plus optional gap iteration. New origin buffer can replace repeatedly while all old/current/new values remain owned. The old edge drops only at actual assignment. |
| merge_edge new coordinate | Potential start/end edge-list replacement while every previous edge and the pending new edge remain live. Preserve existing order and exact-coordinate find/contains semantics. |
| Bound outer editorial transport | Envelope Domain's existing seed.editorial plus full incoming iterator buffer, remaining markers, current marker, captured repeats/constraints and first Bound guard. Grow seed.editorial at the old push site after marker transforms; admit actual replacement and moves. Do not recompute the outer captured query or synthesize marker lengths. |
| envelope_domain_query | Its existing guarded definition/gap/root-domain copies and actual seed constraints/repeats/instance replacements remain the implementation. Preserve its temporary header/path ownership even when overwritten or subsequently discarded. No additional clone of the entire Domain is needed. |
| first/second walk and capture | All existing site guards, Source/Hold payload ownership and copied occurrence identities. The second capture's new vectors overlap the first capture until assignment, as implemented in audio_capture.rs. |

AudioFadeQuery has no project/revision/definition header. Do not invent header clones or fixed header reservations. Boundary origin identities are its real owning edges.

Add one narrow private boundary-origin copy helper for the actual `origin.clone()` site in merge_edge. Existing QueryBudget::origin copies AudioOwnerClockOrigin, not AudioBoundaryOrigin. Compose QueryBudget::{instance,node,repeats,iteration} while preserving the copied origin's `kind`, `placement_support` and already captured `policy`. Reconstructing a BoundaryOwner and calling capture again would both add a second canonical debit and risk reading a different policy. False compatibility continues to call the old clone literally.

## Concrete collection shape without a Core escape

Use a private value-first work wrapper when nested side capacities must remain separately replaceable:

```rust
struct SpanWork<I, L> {
    value: GuardedBound<AudioFadeSpan, I, L>,
    start_capacity: Memory<I, L>,
    end_capacity: Memory<I, L>,
}
```

This is internal working storage, not a second public payload. Initial retained assembly may use a partial value state containing scalar fields, the already allocated start list and still-unmoved end origins. All value fields precede every independent guard. Compute fallible scalars from borrowed fields, reserve independent replacement storage while the old value is owned, and use allocation-free map only for the actual move. For start/end list growth, consume SpanWork into a temporary wrapper whose value is `GuardedBound<SideGrowth>` holding the rest of the span, old IntoIter, replacement and pending edge; keep old/new capacity Memory as later fields of that same wrapper. Each move's additional unit is forwarded outside map, then one infallible map moves one old element. The final map drops the exhausted old iterator/buffer before its old capacity guard is released. The returned SpanWork installs the independent replacement capacity. No policy callback mutates an unguarded external output.

This outer wrapper avoids trying to extract a Memory field through a Core map. It also avoids a sidecar Vec of leases, a new Core method or keeping a second mutable copy of AudioFadeQuery. The generic processing collector is already the concrete precedent for old/current/replacement overlap; its nested-field variant can remain private to fades rather than become a broad callback API.

Fresh editorial origin construction can use a plain value-first owned OriginList with payload and capacity Memory. QueryBudget::grow is appropriate for that plain local vector while both captures and the guarded existing span stay named and owned. Capture a pending origin before the old output.len debit/contains. Only append after uniqueness; merge its payload memory after issuer checks and check again after merge. When the completed new edge is installed, adopt its fixed payload/capacity Memory into the span guard. The same shape works when copying old origins from an immutable guarded edge into the independently owned new edge.

Once a span is complete, consume SpanWork and adopt start/end capacity guards into its GuardedBound with the existing checked helper, then pass it to collection::push. The original walked/consumed payload leases may remain conservatively attached to the final guard, as in policy; this must be documented and included in exact cap tests. It is proof of retained logical requested-Layout charge, not RSS. Do not claim a refund when an unused Source/Bound/header payload drops but its merged guard still remains. Conversely, separately tracked replacement buffers may release their old charge only after actual buffer destruction. Avoid unbounded accumulation of known old side-buffer capacities when exact separate release is available.

Bound assembly can borrow the primary guarded content for envelope_domain_query, build a separately owned result using the independently guarded Domain/geometry, then zip/map primary and result while dropping only the consumed value in the final infallible map. Retaining the primary guard keeps all actual Core lanes through intermediate errors and after mapping. All issuer checks, reservations, canonical/additional debits and merge postchecks happen with the complete current values owned. Error, cancellation, policy refusal and merge-triggered issuer rotation must leave no live leases after caller values drop; accepted work is never refunded.

## Host conditional lifetime integration

`original_request.rs` currently builds flattened, processing and admitted policy first, then conditionally builds ordinary fades and spends their successful work. Replace only this conditional product with a private Fades enum following Policy, holding `AdmittedAudioFadeQuery<Issuer<'work>, Lease<'work>>` and the originating issuer, plus a cfgtest Legacy variant. PreparedQueries stores `Option<Fades>`. RootReadQueriesRef borrows the actual AudioFadeQuery via query(), preserving every numerical reader/DSP interface.

The short Admission borrow ends after actual construction. Canonical/additional/total were already forwarded; remove only the second successful fade work bill. Failed partial constructor work remains spent. Add an optional fade issuer check after flat/processing/policy at the existing consuming boundaries, billing the actual one comparison once per boundary. Preserve initial plan/domain/range/error checks ahead of metadata validation, then reject a foreign fade issuer before source/query I/O. Use explicit legacy modes for earlier products when isolating a fade mismatch; do not overload an existing legacy flag to mean all four products.

Retain all four metadata products during policy population, prepared prediction and numeric source/DSP read. The current `read_prepared_original` explicitly drops the consumed request before returning raw PCM; preserve that boundary. In `shared_eq/original_inputs`, validate a supplied prepared request before graph/cache lookup; a prepared late hit must drop it and release all four leases. A warm early Probe hit should build none of the four queries. Edge-fades false builds no fade carrier and incurs no fade issuer comparison. Do not add retention to Graph or change caches, endpoint policy, fade gain/minimum semantics, source dependencies, masks, depth or DSP.

Extend the existing test-only product trace with a Fade lane and actual constructor scope. Scope ends at constructor return, before unrelated policy/read work. Preserve canonical/additional/total conservation and the explicitly measured accepted `host_eviction_work` from the existing real eviction debit site; never infer it as Plan additional. Paired OLD/current cache behavior can legitimately differ because all four carriers reduce PCM room. Update only fixture-derived pressure/fees where paired receipts support it; do not raise production caps or erase resource differences.

## Proof still owed after the frozen logical oracle

1. Literal false-mode full-body equality over all 80 parents, all errors and standalone compatibility supplement, with no spend/reserve/merge callbacks. Retain the corrected actual one-short span trials; do not regenerate OLD because the new accounting differs.
2. True canonical equals frozen successful work; total equals canonical plus actual additional and accepted Plan/Core forwarded units. Final public fade fields other than top work compare literally. Empty true queries have zero construction charge/work. Preserve typed invalid-limit/range/tiny-positive priority.
3. Exact/one-short real total work and requested-Layout peak on both Root and Domain; every meaningful reservation/work refusal and issuer rotation; failed partial debits never refunded. Separate final-storage measurement is useful only as a crosscheck, not constructor-peak evidence.
4. Independent Layout expectations for initial start/end buffers, outer span growth with multiple prior/current spans, origin replacement with old/new edges live, pending captured duplicate origin and envelope seed.editorial growth with retained Bound/capture still live. Identity-size deltas should use equal-structure fixtures, avoiding collisions with unrelated padded layouts.
5. A co-produced branch proof for actual primary Leaf, Stage second-walk, Root-clock Bound and PointCeil Bound; support None, q before/after support, resumed seam, negative/fractional origin, incident marker acceptance/rejection, old/new coincident edge merge, duplicate origin, Hard precedence and multiple origins/repeat paths. The OLD matrix freezes outputs, not terminal-dispatch or allocation events. Present checked fixtures plus successful final values do not by themselves prove each of these branches executed. A narrow cfgtest event at actual dispatch/early-return can close such gaps without fabricating internal spans or changing ordinary output.
6. Source/endpoints and retained factories need actual availability facts: only one of the six existing standalone factory setups returns Some. Their four successful wider-history outputs do not establish standalone admission or cover every optional raw/Point history. Current ProjectedStage arm has no physical-walker constructor, so report that factory limitation rather than invent a Span to claim public coverage.
7. Real ReadWork/WAV proof of positive fade charge at actual population/source/DSP callbacks when present, zero after success/error/unused drop/late hit, foreign fade rejection with earlier legacy products, exact source admission before I/O, four-product aggregate PCM pressure and actual cache eviction conservation. Early warm Probe constructs none; edge_fades false constructs no fade product.

No semantic conflict was found in this bounded design. The main implementation hazard is moving a current edge/origin/Bound outside its guards while making a fallible reserve or debit. Preserve whole named value-first states and use existing checked zip/map rather than adding escape APIs. Production implementation remains a separate explicitly assigned scratch candidate task.

## Exact read pins

SHA256 of actual source bytes read for this design. These are source observations, not a new execution or source-publication claim. Main and Scope equality is stated per file.

| Path | Main SHA256 | Scope |
| --- | --- | --- |
| `crates/deadpan-plan/src/audio_fades.rs` | `a59a08eee74ed6e2f6f4d6afa1f5ffcff467ecb08278da71306461ed1e91e118` | same |
| `crates/deadpan-plan/src/audio_capture.rs` | `2c9f78b038f80306f7f990229a43a9571f7f68ae74ce94e692d4c7c318c778b9` | same |
| `crates/deadpan-plan/src/audio_capture_storage.rs` | `3ad18964cf9beb34b878f3e3c8fbd286a4ab4d08a8df83e738bdd666dc9b6c08` | same |
| `crates/deadpan-plan/src/audio_boundary.rs` | `50bdefa0e2c9646b859b197a579dd044498b471a3c998a88ad6d7f9b768a701b` | same |
| `crates/deadpan-plan/src/audio_bound_query.rs` | `01a5b56b65a373e422620d14371a222e33c0394310262c14887b45f29f66e040` | same |
| `crates/deadpan-plan/src/audio_bound.rs` | `ac25028a624378198c3fe4276ccaec42cf898fc80f12a88d5266b32d6fbb306f` | same |
| `crates/deadpan-plan/src/audio_owner_query_admission.rs` | `1a8d2bc8541da7d44308afc239c08bd7b90775c05d93cfd5b800ede8804de7ab` | same |
| `crates/deadpan-plan/src/audio_processing_query.rs` | `0e07e0d251f140ad53efb891cba8cc2654f0d8d4f3da061f4e60c7ed0b65c793` | same |
| `crates/deadpan-plan/src/audio_policy_query.rs` | `4b09dd0ac140db1e7e5a58e9092a5e2ecaa29d45d4bc303a56b4e815985a28a9` | same |
| `crates/deadpan-plan/src/audio_domain.rs` | `16bfede5f9b3747da9200362ea95ef74df2719c322a061ed79461e1d5ad1c242` | same |
| `crates/deadpan-plan/src/audio_owner_input.rs` | `39236727cb8a7c9af7ae1b29982a9c6ada991f8c2c47ca96e1996dd1b41bc5f3` | same |
| `crates/deadpan-plan/src/audio_sound_admission.rs` | `fc068b6cf458a643cb0641f59570ee2b09eecb98646070f797da9257522c85e2` | same |
| `crates/deadpan-plan/tests/fixtures/fade-query-baseline-v1/snapshot.json` | `09502b80324734819b4f9acdd62b1dbd42eeeb29083d61366ecc88d28f8526f7` | same |
| `crates/deadpan-audio/src/original_request.rs` | `9137ceedf78678928f8672866405e0ce9a91159437b3a72faa3cd039e5c8ef70` | same |
| `crates/deadpan-audio/src/original_request/flattened_work_trace.rs` | `3dc46c3906e29b06e59d844118001667612829cfabd3dc090f3f773339ea526b` | same |
| `crates/deadpan-audio/src/shared_eq/policy_prediction.rs` | `0813efabcc3ae641ea8435f55da42790e6222417063f22643c72db0a2314545b` | same |
| `crates/deadpan-audio/src/shared_eq/original_inputs.rs` | `b029c29784b9ffc03cb84a8209eab68c3930a8fb86e2e1e87e83ff83956caba3` | same |
