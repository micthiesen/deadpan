from pathlib import Path
import hashlib,json,re,difflib
s=Path(__file__).resolve().parent
roots={'main':Path('/Users/michael/Code/deadpan'),'scoped':Path('/tmp/deadpan-query-groundwork-2026-10-26/scoped')}
path='crates/deadpan-plan/src/audio_owner_query_admission.rs'
old='''    /// Call only after checking both issuers and completing all fallible work.
    pub(in crate::plan) fn merge_checked(
        &mut self,
        a: &mut Memory<A::Issuer, A::Lease>,
        b: &mut Memory<A::Issuer, A::Lease>,
    ) {
        if let Some(mut issued) = b.lease.take() {
            if let Some(target) = a.lease.as_mut() {
                self.admission.merge(target, &mut issued);
            } else {
                a.lease = Some(issued);
            }
        }
    }
'''
new='''    pub(in crate::plan) fn merge_checked(
        &mut self,
        a: &mut Memory<A::Issuer, A::Lease>,
        b: &mut Memory<A::Issuer, A::Lease>,
    ) -> Result<(), A> {
        self.check_memory(a)?;
        self.check_memory(b)?;
        if let Some(mut issued) = b.lease.take() {
            if let Some(target) = a.lease.as_mut() {
                self.admission.merge(target, &mut issued);
            } else {
                a.lease = Some(issued);
            }
        }
        self.check_memory(a)?;
        self.check_memory(b)
    }
'''
changed={}
for variant,root in roots.items():
 paths=sorted(p for p in(root/'crates/deadpan-plan/src').rglob('*.rs')if '.merge_checked('in p.read_text())
 total=0;outpins={};patch=''
 for p in paths:
  rel=str(p.relative_to(root));before=p.read_text();after,count=re.subn(r'(?m)^(\s*(?:budget|self)\.merge_checked\([^\n]+\));$',r'\1?;',before)
  assert count==before.count('.merge_checked('),(variant,rel,count)
  total+=count
  if rel==path:
   assert after.count(old)==1
   after=after.replace(old,new,1)
  saved=s/'merge-fix-before'/variant/rel;saved.parent.mkdir(parents=True,exist_ok=True);saved.write_text(before)
  p.write_text(after)
  outpins[rel]={'before_sha256':hashlib.sha256(before.encode()).hexdigest(),'after_sha256':hashlib.sha256(after.encode()).hexdigest(),'calls':count}
  patch+=''.join(difflib.unified_diff(before.splitlines(keepends=True),after.splitlines(keepends=True),fromfile='a/'+rel,tofile='b/'+rel))
 assert total==49,(variant,total)
 (s/('checked-merge-'+variant+'.patch')).write_text(patch)
 changed[variant]=outpins
(s/'checked-merge-changes.json').write_text(json.dumps(changed,indent=2)+'\n')
owned=set(json.loads((s/'owned-plan-paths.json').read_text()))|set(changed['main'])
(s/'owned-plan-paths.json').write_text(json.dumps(sorted(owned),indent=2)+'\n')
print('Checked merge now validates both issuer lanes before and after each merge;49callers propagate its error.')
