# Prepare-only OLD fade witness

This candidate adds only a test producer and checked fixture visitors. It has not been integrated, compiled, executed, captured or frozen by this worker. Do not capture until the current policy checkpoint has been published. No ordinary fade algorithm changes or expected body are included.

Apply `module-declaration.patch` and `new-files.patch` to each actual root after its source guard releases. The declaration is under the existing test-only `audio_owners::tests::legacy_snapshot_v1` parent. The new child needs no new public product API or visibility patch. Existing `processing_query_baseline::visit_cases`, `policy_query_baseline::descriptor_snapshot`, `policy_retained_cases::source_endpoint_parent`, `policy_binding_baseline::visit_additional` and retained `capture_baseline_snapshot` are already visible within Plan.

The initial candidate parses with `rustfmt --edition 2024 --check`; compilation and runtime checks remain parent-owned. Source pins describe the read state, not the future publication. Refresh the complete source manifest after integration and publication, before capture. The prepare-only manifests include Core and Plan Rust source, Plan Rust tests/JSON fixture data, workspace/package manifests, Cargo.lock and rust-toolchain.toml. They deliberately do not purport to identify a compiled executable.

## Outputs and provenance

`fade_query_baseline.rs` serializes every public FadeQuery, FadeSpan, FadeEdge and BoundaryOrigin field using exhaustive patterns. It explicitly records the skipped query work and the false-valued placement-support flag, exact ratios as numerator/denominator strings, all ordered origin instance/repeat/gap identities and policies, lookup counters and typed errors. No normalized work or fabricated expected cap is used. Failed ordinary queries expose no accepted partial-work receipt, which is stated rather than inferred.

The shared processing visitor reconstructs the checked 33 parents. Its storage-fixture source is expanded by the existing policy descriptor helper. `fade_query_cases.rs` adds complete checked project documents, old reference documents, selectors/placements, current physical-Domain snapshots and explicit incident windows. Fixtures come from actual fade/gap/endpoint tests. It includes translations; Point and Preserve; fractional phase; signed and negative origins; coincident Hard versus crop; editorial entry and tiny voices; exact-coordinate Hard precedence; virtual Source zero/one width; retained current-versus-selected-leaf policy; resumed delivery seam and delivered width; hidden-owner eligibility; opaque-owner/inner marker; command-created repeated fragments; Start/End endpoint histories; bound moved gaps in Root and physical Domain.

Every visited parent records full, clipped and empty calls; actual full/clipped returned-work caps and one-short when a predecessor exists; legal positive span-cap and one-short trials; minimum positive empty limits; invalid zero/above-hard-cap limits; before/after support; reversed range; mixed invalid-limit/range priority; tiny positive allowances; one-sample start/mid/end and adjacent pages. Extra fixture windows retain the exact original creative seam/cut probes. A zero-work success is tried literally at cap zero and recorded as the actual result; no nonexistent negative one-short cap is invented. Empty output uses the legal minimum positive span cap, not a claim that its count is one.

The separate standalone retained-input supplement reconstructs the existing actual checked inputs, records Some/None/Error, captures complete private retained processing/editorial/raw-domain/work data, and calls its ordinary `.fades` over delivery, wider history, empty, reversed, exact/short work. It explicitly preserves this factory's distinct prepaid work and range semantics. It is not claimed admitted by a future Root/Domain carrier.

## Parent-owned execution after publication

First build and use `--list` to confirm the actual paths. Expected paths, based on the existing parent declaration:

- `plan::audio_owners::tests::legacy_snapshot_v1::fade_query_baseline::capture_old_fade_query_baseline_v1`
- `plan::audio_owners::tests::legacy_snapshot_v1::fade_query_baseline::ordinary_fades_match_explicit_external_old_capture_v1`

The earlier missing `plan::` prefix ran zero policy tests. Do not count a successful zero-test filter as coverage. This worker has not run a listing or executable.

Manual capture needs `--ignored --exact` and all four variables:

- `DEADPAN_FADE_QUERY_OUTPUT`: a new absolute path whose existing canonical parent is under `/tmp`; writer uses create_new and sync_all.
- `DEADPAN_FADE_QUERY_VARIANT`: `main-inherited` or `scoped-published`.
- `DEADPAN_FADE_QUERY_SOURCE_SHA256`: complete actual OLD capture source-manifest SHA256, 64 hex characters.
- `DEADPAN_FADE_QUERY_PUBLISHED_POLICY_CHECKPOINT`: actual published checkpoint identity. The producer only checks nonempty text; the parent must verify publication independently.

Capture each root independently, compare the entire parsed body after removing exactly `variant`, `source_sha256`, `published_policy_checkpoint`, review all actual errors/coverage, then freeze independently. The manual regression scaffold requires `DEADPAN_FADE_QUERY_EXPECTED` and compares the full literal body with exactly those provenance keys removed. It has no expected snapshot dependency or generation fallback.

## Owed checks and bounded gaps

Parent must compile both roots, confirm test paths, run each actual producer after publication, inspect fixture setup failures and typed outputs, compare both complete bodies, and only then decide freeze. No runtime parent/observation count or successful path coverage is claimed yet. Default failure results are preserved without assuming every full corpus query succeeds.

This is logical OLD evidence, not an allocation/peak/lease or host ReadWork proof. No failed-prefix receipt exists in the ordinary API. There are no fabricated legal-layout overflow or work offsets. Future true admission tests still owe callback refusal/rotation, actual requested Layout overlap and output lifetime, failed accepted work, final storage, conditional host fade construction, four-product aggregate room, source/DSP callbacks, foreign issuer and early/late cache behavior.

The standalone retained supplement records actual factory availability; it does not require every setup to produce Some. The gap default-override/edit/delete combinations beyond the checked moved-gap fixture and the captured-layout editorial round trip are not separately ported here. Existing common fixture parents may cover some, but only captured outputs can establish that. No generic opaque Core serializer or production escape has been added.
