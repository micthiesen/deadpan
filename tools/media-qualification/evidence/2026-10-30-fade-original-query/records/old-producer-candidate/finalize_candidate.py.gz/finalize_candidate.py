from pathlib import Path
import hashlib,json,difflib
base=Path('/tmp/deadpan-fade-query-admission-2026-10-30/old-producer-candidate')
relative=Path('crates/deadpan-plan/src/audio_owners/legacy_snapshot_v1.rs')
main=Path('/Users/michael/Code/deadpan')
scope=Path('/tmp/deadpan-query-groundwork-2026-10-26/scoped')
fragment='\n#[path = "legacy_snapshot_v1/fade_query_baseline.rs"]\npub(in crate::plan) mod fade_query_baseline;\n'
(base/'module-declaration.rs.txt').write_text(fragment)
before=(main/relative).read_text()
assert 'mod fade_query_baseline;' not in before
saved=base/'before'/relative
saved.parent.mkdir(parents=True,exist_ok=True);saved.write_text(before)
(base/'module-declaration.patch').write_text(''.join(difflib.unified_diff(before.splitlines(True),(before+fragment).splitlines(True),fromfile='a/'+str(relative),tofile='b/'+str(relative))))
patches=[]
for path in sorted((base/'crates').rglob('*.rs')):
    text=path.read_text()
    patches.append(''.join(difflib.unified_diff([],text.splitlines(True),fromfile='/dev/null',tofile='b/'+str(path.relative_to(base)))))
(base/'new-files.patch').write_text(''.join(patches))
read_paths=[
'crates/deadpan-plan/src/audio_fades.rs','crates/deadpan-plan/src/audio_boundary.rs',
'crates/deadpan-plan/src/audio.rs','crates/deadpan-plan/src/audio_domain.rs',
'crates/deadpan-plan/src/audio_owner_input.rs','crates/deadpan-plan/src/audio_bound_probe.rs',
'crates/deadpan-plan/src/audio_owners/legacy_snapshot_v1.rs',
'crates/deadpan-plan/src/audio_owners/legacy_snapshot_v1/wide_baseline.rs',
'crates/deadpan-plan/src/audio_owners/legacy_snapshot_v1/processing_query_baseline.rs',
'crates/deadpan-plan/src/audio_owners/legacy_snapshot_v1/policy_query_baseline.rs',
'crates/deadpan-plan/src/audio_owners/legacy_snapshot_v1/policy_retained_cases.rs',
'crates/deadpan-plan/src/audio_owners/legacy_snapshot_v1/policy_binding_baseline.rs',
'crates/deadpan-plan/src/audio_owners/legacy_snapshot_v1/capture_baseline.rs',
'crates/deadpan-plan/src/audio_allocated/query_storage_tests.rs',
'crates/deadpan-plan/tests/audio_fades.rs','crates/deadpan-plan/tests/gap_bindings.rs',
'crates/deadpan-plan/tests/fixtures/wide-gain-owner-baseline-v1/snapshot.json']
pins={}
for label,root in [('main',main),('scoped',scope)]:
    pins[label]={path:hashlib.sha256((root/path).read_bytes()).hexdigest() for path in read_paths}
(base/'read-source-pins.json').write_text(json.dumps(pins,indent=2,sort_keys=True)+'\n')
# These complete source-manifest candidates are read-only and must be refreshed by the
# parent at actual capture; they are not the future published source identities.
for label,root in [('main',main),('scoped',scope)]:
    paths=set()
    for prefix in ['crates/deadpan-core/src','crates/deadpan-plan/src','crates/deadpan-plan/tests']:
        for path in (root/prefix).rglob('*'):
            if path.is_file() and path.suffix in ['.rs','.json']:
                paths.add(path.relative_to(root).as_posix())
    for name in ['Cargo.toml','Cargo.lock','rust-toolchain.toml','crates/deadpan-core/Cargo.toml','crates/deadpan-plan/Cargo.toml']:
        if (root/name).is_file(): paths.add(name)
    manifest=''.join(f'{hashlib.sha256((root/path).read_bytes()).hexdigest()}  {path}\n' for path in sorted(paths))
    (base/f'prepare-only-{label}-source-manifest.sha256').write_text(manifest)
