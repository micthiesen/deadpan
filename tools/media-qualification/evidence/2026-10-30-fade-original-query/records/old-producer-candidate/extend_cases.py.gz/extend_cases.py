from pathlib import Path
base = Path('/tmp/deadpan-fade-query-admission-2026-10-30/old-producer-candidate')
path = base/'crates/deadpan-plan/src/audio_owners/legacy_snapshot_v1/fade_query_cases.rs'
source = Path('/Users/michael/Code/deadpan/crates/deadpan-plan/tests/audio_fades.rs').read_text()
current = path.read_text()
marker = 'pub(super) fn visit_cases(mut visit: impl FnMut(Parent<\'_, \'_>, &Value)) {'
assert current.count(marker)==1
prefix, old_visit = current.split(marker)
def setup(name, stop='    let plan = RenderPlan::compile'):
    start = source.index('fn '+name+'() {') + len('fn '+name+'() {\n')
    end = source.index(stop,start)
    return source[start:end]
added = ''
added += 'fn virtual_source(visit: &mut impl FnMut(Parent<\'_, \'_>, &Value)) {\n'
added += setup('virtual_source_support_can_have_zero_or_one_fade_samples')
added += '''
    root("fade/virtual_source/original", &original, None,
        "virtual_source_support_can_have_zero_or_one_fade_samples",
        json!({"pair":"virtual_source"}), &[("original_probe",0,1)], visit);
    let faster = bind(&source_document(true), &original, "voice",
        AudioClockRoot::ProjectRootRoundEven, None);
    root("fade/virtual_source/bound_fast", &faster, Some(&original),
        "virtual_source_support_can_have_zero_or_one_fade_samples",
        json!({"pair":"virtual_source","current_document":source_document(true)}),
        &[("original_probe",0,1)], visit);
}
'''
added += 'fn retained_editorial_geometry(visit: &mut impl FnMut(Parent<\'_, \'_>, &Value)) {\n'
added += setup('bound_preserve_inner_leaf_cannot_lend_hard_policy_to_a_different_current_leaf')
added += '''
    root("fade/retained/current_leaf_hard_mismatch", &bound, Some(&base),
        "bound_preserve_inner_leaf_cannot_lend_hard_policy_to_a_different_current_leaf",
        json!({"current_document":marked}),
        &[("seam_straddle",2400,2402),("second_incident",2401,2402)],visit);
'''
added += setup('bound_outer_edge_fades_the_voice_delivered_at_the_cut_not_the_next_inner_voice')
added += '''
    root("fade/retained/delivered_cut", &bound, Some(&reference),
        "bound_outer_edge_fades_the_voice_delivered_at_the_cut_not_the_next_inner_voice",
        json!({"current_document":current,"marked_document":marked}),
        &[("cut_straddle",4800,4812),("inside_remaining_voice",4804,4807)],visit);
}
'''
added += 'fn delivered_width(visit: &mut impl FnMut(Parent<\'_, \'_>, &Value)) {\n'
added += setup('new_bound_edge_width_uses_delivered_samples_instead_of_virtual_envelope_rounding')
added += '''
        root(&format!("fade/retained/delivered_width_start_{start_edge}"), &current, Some(&reference),
            "new_bound_edge_width_uses_delivered_samples_instead_of_virtual_envelope_rounding",
            json!({"start_edge":start_edge,"crop_start":crop_start,"crop_end":crop_end,"marked_document":marked}),
            &[("one_sample_voice",5,6),("complete_crop",crop_start,crop_end)],visit);
    }
}
'''
added += 'fn hidden_eligibility(visit: &mut impl FnMut(Parent<\'_, \'_>, &Value)) {\n'
added += setup('later_partition_drops_ancestor_marker_but_retains_its_own_hidden_owner_edge', '    let reference = RenderPlan::compile')
added += '''
    let symbol = "later_partition_drops_ancestor_marker_but_retains_its_own_hidden_owner_edge";
    for (name,current) in [("plain",&plain),("ancestor",&ancestor)] {
        root(&format!("fade/hidden/{name}"), current, Some(&plain), symbol,
            json!({"pair":"hidden_partition"}), &[("later_partition",1,97)], visit);
    }
    let owned = with_editorial(&plain,"voice",true,false,false);
    for bound in [false,true] {
        let current = if bound { bind(&owned,&plain,"voice",AudioClockRoot::ProjectRootRoundEven,None) } else { owned.clone() };
        root(&format!("fade/hidden/owner_bound_{bound}"),&current,Some(&plain),symbol,
            json!({"pair":"hidden_partition","bound":bound,"marked_document":owned}), &[("own_hidden_edge",1,2)],visit);
    }
'''
# Copy ordinary setup through creation of marked document, stopping before assertion plans.
added += setup('transported_bound_owner_edges_are_not_reintroduced_after_eligibility_rejects_them', '        let original = RenderPlan::compile')
added += '''
        for (label,current) in [("bound",&bound),("marked",&marked)] {
            root(&format!("fade/eligibility/start_{start}/{label}"), current, Some(&plain),
                "transported_bound_owner_edges_are_not_reintroduced_after_eligibility_rejects_them",
                json!({"pair":format!("eligibility_start_{start}"),"start_edge":start,"end_edge":end,"phase":phase}),
                &[("selected",range.start,range.end),("incident",range.start,range.start+1)],visit);
        }
    }
'''
added += setup('bound_opaque_owner_suppression_keeps_a_distinct_inner_marker', '    let original = RenderPlan::compile')
added += '''
    for (label,current) in [("bound",&bound),("outer_marked",&marked)] {
        root(&format!("fade/opaque_owner/{label}"), current, Some(&plain),
            "bound_opaque_owner_suppression_keeps_a_distinct_inner_marker",
            json!({"pair":"opaque_owner","inner_marked_document":inner}),
            &[("rejected_outer",10,20),("distinct_inner",110,111)],visit);
    }
}
'''
added += 'fn repeat_editorial(visit: &mut impl FnMut(Parent<\'_, \'_>, &Value)) {\n'
added += setup('marked_fragment_play_seams_fade_or_cut_by_their_policy', '    // The seam')
added += '''
    let marked = edit(&looped,"marked",Command::SetEditorialEdges {
        node:id("fragment"),edges:AudioEditorialEdges{start:true,end:true}
    });
    let mut hard = marked.clone();
    for (revision,edge) in [("hard-start",AudioBoundaryKind::NodeStart),("hard-end",AudioBoundaryKind::NodeEnd)] {
        hard = edit(&hard,revision,Command::SetAudioEdge {node:id("fragment"),edge,policy:AudioEdgePolicy::Hard});
    }
    for (label,current) in [("unmarked",&looped),("marked",&marked),("hard",&hard)] {
        root(&format!("fade/repeat_fragment/{label}"), current, Some(&base),
            "marked_fragment_play_seams_fade_or_cut_by_their_policy",
            json!({"pair":"fragment_seam","construction":"actual WrapRepeat, SetEditorialEdges and SetAudioEdge commands"}),
            &[("whole_two_plays",0,12800),("repeat_seam",6399,6401)],visit);
    }
}
'''
gap_source = Path('/Users/michael/Code/deadpan/crates/deadpan-plan/tests/gap_bindings.rs').read_text()
gap_helpers = gap_source[gap_source.index('fn id('):gap_source.index('#[test]')]
added += 'mod gap_cases {\nuse super::*;\n'+gap_helpers+'''
pub(super) fn visit(visit:&mut impl FnMut(Parent<'_, '_>,&Value)) {
    let before=captured(3);
    let moved=edit(&before,"moved",Command::SetHoldDuration {node:id("prefix"),duration:frames(2)});
    let plan=RenderPlan::compile(&moved).unwrap();
    let source=json!({"kind":"checked_port_of_existing_gap_test","path":"tests/gap_bindings.rs",
        "symbol":"moved_gap_is_bound_in_root_and_captured_domains_with_its_own_edges",
        "document":moved,"reference_document":before,"setup":{"plays":3,"domain_observed_at":4805}});
    let parent=Parent::Root(&plan);
    visit(parent,&descriptor("fade/gap_bound/root",parent,source.clone(),&[("original_gap_delivery",4805,8008)]));
    let physical=plan.audio_domain_at(AudioSample(4805),Default::default()).unwrap();
    let parent=Parent::Domain(&physical);
    visit(parent,&descriptor("fade/gap_bound/domain",parent,source,&[("original_gap_delivery",4805,8008)]));
}
}
'''
old_visit = old_visit.replace('    source_endpoints(&mut visit);','''    source_endpoints(&mut visit);
    virtual_source(&mut visit);
    retained_editorial_geometry(&mut visit);
    delivered_width(&mut visit);
    hidden_eligibility(&mut visit);
    repeat_editorial(&mut visit);
    gap_cases::visit(&mut visit);''')
path.write_text(prefix+added+'\n'+marker+old_visit)
