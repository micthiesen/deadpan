from pathlib import Path
import json,hashlib,difflib
base=Path('/tmp/deadpan-fade-query-admission-2026-10-30/plan-candidate')
main=Path('/Users/michael/Code/deadpan')
scope=Path('/tmp/deadpan-query-groundwork-2026-10-26/scoped')
changes={
'crates/deadpan-plan/src/audio_fades.rs':(
'/// One side of a creative envelope.',
'#[path = "audio_fades_query.rs"]\npub(in crate::plan) mod query;\npub use query::AdmittedAudioFadeQuery;\n\n/// One side of a creative envelope.'),
'crates/deadpan-plan/src/plan.rs':(
'pub use audio_fades::{AudioFadeEdge, AudioFadeQuery, AudioFadeSpan};',
'pub use audio_fades::{AdmittedAudioFadeQuery, AudioFadeEdge, AudioFadeQuery, AudioFadeSpan};'),
'crates/deadpan-plan/src/lib.rs':(
'pub use plan::{AdmittedAudioPolicyQuery, AdmittedAudioProcessingQuery, AdmittedAudioQuery};',
'pub use plan::{AdmittedAudioFadeQuery, AdmittedAudioPolicyQuery, AdmittedAudioProcessingQuery, AdmittedAudioQuery};')
}
patches={'main':[], 'scoped':[]}
pins={}
for name,(old,new) in changes.items():
    for lane,root in [('main',main),('scoped',scope)]:
        before=(root/name).read_text()
        assert before.count(old)==1,(lane,name,before.count(old))
        assert 'mod query;' not in before if name.endswith('audio_fades.rs') else True
        after=before.replace(old,new)
        pins[lane+'/'+name]=hashlib.sha256(before.encode()).hexdigest()
        p=base/'before'/lane/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(before)
        p=base/'after'/lane/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(after)
        pins['after/'+lane+'/'+name]=hashlib.sha256(after.encode()).hexdigest()
        patches[lane].append(''.join(difflib.unified_diff(before.splitlines(True),after.splitlines(True),fromfile='a/'+name,tofile='b/'+name)))
for lane,patch in patches.items():
    (base/f'declarations-{lane}.patch').write_text(''.join(patch))
newpatch=[]
for p in sorted((base/'crates').rglob('*.rs')):
    name=p.relative_to(base).as_posix()
    pins['candidate/'+name]=hashlib.sha256(p.read_bytes()).hexdigest()
    newpatch.append(''.join(difflib.unified_diff([],p.read_text().splitlines(True),fromfile='/dev/null',tofile='b/'+name)))
(base/'new-files.patch').write_text(''.join(newpatch))
readfiles=['audio.rs','audio_capture.rs','audio_capture_storage.rs','audio_bound_query.rs','audio_bound.rs',
'audio_boundary.rs','audio_owner_query_admission.rs','audio_processing_query.rs','audio_policy_query.rs',
'audio_domain.rs','audio_sound_admission.rs']
for name in readfiles:
    rel='crates/deadpan-plan/src/'+name
    for lane,root in [('main',main),('scoped',scope)]:
        pins[lane+'/'+rel]=hashlib.sha256((root/rel).read_bytes()).hexdigest()
(base/'source-pins.json').write_text(json.dumps(pins,indent=2,sort_keys=True)+'\n')
print(json.dumps({name:hashlib.sha256((base/name).read_bytes()).hexdigest() for name in ['declarations-main.patch','declarations-scoped.patch','new-files.patch']},indent=2))
