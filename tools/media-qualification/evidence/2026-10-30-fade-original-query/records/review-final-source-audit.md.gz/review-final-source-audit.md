# Final source audit

## Results

- All 43 final-source pins match the current Main and scoped trees exactly.
- Comparing those 43 owned paths between trees, only `crates/deadpan-plan/src/plan.rs` differs. Main is 82,056 bytes (SHA-256 `6cf630e2…86daf082`); scoped is 78,539 bytes (`c21a682f…8e5de5d`). This is the inherited-module exception specified for this audit.
- All 17 immutable oracle pins match in both trees.
- The captured initial authority inventories contain 2,799 Main paths and 2,471 scoped paths. Excluding the 33 exact owned paths present in each inventory leaves 2,766 and 2,438 unowned paths. One unowned current mismatch is present in both trees: `crates/deadpan-audio/tests/sound_events.rs` (captured 17,364 bytes, SHA-256 `fcbcfc86…3096cb9`; current 17,378 bytes, `acdd2d0e…1038724c`). Its current diff changes `reached_provider` to match `&error` and adds `{error:?}` to the assertion. The file is not in the owned-path list; Main reports it modified. All other unowned authority paths match and none are missing.
- The 29 final Plan test receipts all show exit 0 and `test result: ok`: 712 passed, 14 ignored, 0 failed. Each receipt also records unchanged source and binary inventories.
- Both final strict sourceguard receipts passed: Main `cargo xtask check --no-test` (2,807 source paths unchanged); scoped `cargo clippy -p deadpan-plan -p deadpan-audio --all-targets -- -D warnings` (2,479 source paths unchanged). Both report unchanged binary inventories. These receipts predate the current `sound_events.rs` diff, so they do not attest that later edit.
- Main `docs/` has no diff from base `7da84fc1b57897bd990a51f575b60f1b903c7318`; `docs/STATE.md` is absent in both trees and docs were not part of either initial authority manifest. Scoped and Main docs are inherited snapshots with different inventories (669 vs 705 files), outside the 43 owned paths.

## Runtime limit

The parent reports that the later native Scope `sound_events` integration stopped at 2 passed and 4 failed. The failure and any subsequent repair are outside these frozen-source receipts; no runtime success is claimed here. The audit JSON is `final-source-audit.json`.
