from pathlib import Path
import json
s=Path(__file__).resolve().parent
rel='crates/deadpan-audio/src/shared_eq/processing_eviction_trace_tests.rs'
for variant,root in [('main',Path('/Users/michael/Code/deadpan')),('scoped',Path('/tmp/deadpan-query-groundwork-2026-10-26/scoped'))]:
 p=root/rel;before=p.read_text()
 saved=s/'eviction-proof-before'/variant/rel;saved.parent.mkdir(parents=True,exist_ok=True);saved.write_text(before)
 anchor='''#[test]
fn completed_original_constructors_separate_real_eviction_work_in_both_products_and_lanes() {
'''
 assert before.count(anchor)==1
 text=before.replace(anchor,'''#[test]
fn completed_original_constructors_separate_real_eviction_work_in_both_products_and_lanes() {
    original_request::with_legacy_fade_queries(|| eviction_receipts(256, false));
}

#[test]
fn four_products_keep_actual_eviction_receipts_with_larger_real_cached_wav_input() {
    eviction_receipts(512, true);
}

fn eviction_receipts(cached_input_frames: i64, admitted_fades: bool) {
''',1)
 anchor='''                    AudioSample(0)..AudioSample(256),
                    control,
                    0,
'''
 assert text.count(anchor)==1
 text=text.replace(anchor,'''                    AudioSample(0)..AudioSample(cached_input_frames),
                    control,
                    0,
''',1)
 anchor='''            let lane = if cache_lane { "cache" } else { "plan" };
'''
 assert text.count(anchor)==1
 addition='''            let policy =
                serde_json::to_value(original_request::flattened_work_trace::policy_snapshot())
                    .unwrap();
            let fades =
                serde_json::to_value(original_request::flattened_work_trace::fade_snapshot())
                    .unwrap();
'''
 text=text.replace(anchor,addition+anchor,1)
 anchor='''            for trace in [&flat, &processing] {
'''
 assert text.count(anchor)==1
 text=text.replace(anchor,'''            let mut products = vec![&flat, &processing, &policy];
            if admitted_fades {
                products.push(&fades);
            } else {
                assert_eq!(fades[lane]["constructor_calls"], 0);
                assert_eq!(fades[lane]["accepted_work"], 0);
            }
            for trace in products {
''',1)
 anchor='''            assert_eq!(not_selected[lane]["host_eviction_work"], 0);
'''
 assert text.count(anchor)==1
 text=text.replace(anchor,anchor+'''            assert_eq!(policy[lane]["host_eviction_work"], 0);
            assert_eq!(fades[lane]["host_eviction_work"], 0);
''',1)
 p.write_text(text)
 names=set(json.loads((s/(variant+'-logic-source-files.json')).read_text()))|{rel}
 for file in [variant+'-logic-source-files.json','source-files.json'if variant=='main'else'scoped-source-files.json']:
  (s/file).write_text(json.dumps(sorted(names),indent=2)+'\n')
owned=set(json.loads((s/'owned-paths.json').read_text()))|{rel}
(s/'owned-paths.json').write_text(json.dumps(sorted(owned),indent=2)+'\n')
print('Preserved prior eviction mode; added actual four-product pressure with a larger cached WAV window.')
