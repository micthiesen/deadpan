from pathlib import Path
import tarfile,json,hashlib
from datetime import datetime,timezone
s=Path(__file__).resolve().parent
scope=Path('/tmp/deadpan-query-groundwork-2026-10-26/scoped')
sha=lambda b:hashlib.sha256(b).hexdigest()
initial=json.loads((s/'scoped-initial-authority.json').read_text())
missing=[n for n in initial if not(scope/n).exists()]
restored=[]
with tarfile.open(s/'base-source.tar')as archive:
 for item in archive:
  if not item.isfile()or item.name.startswith('tools/media-qualification/evidence/'):continue
  assert not Path(item.name).is_absolute()and'..'not in Path(item.name).parts,item.name
  p=scope/item.name
  if p.exists():continue
  data=archive.extractfile(item).read()
  p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data);p.chmod(item.mode)
  restored.append({'path':item.name,'bytes':len(data),'sha256':sha(data)})
owned=json.loads((s/'owned-paths.json').read_text())
for name in owned:
 data=(s/'published-source/scoped'/name).read_bytes()
 p=scope/name
 if not p.exists():p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data)
 assert p.read_bytes()==data,name
unmatched=[]
for name,pin in initial.items():
 if name in owned:continue
 p=scope/name
 if not p.exists()or sha(p.read_bytes())!=pin['sha256']:unmatched.append(name)
for name,pin in json.loads((s/'scoped-final-source-pins.json').read_text()).items():
 p=scope/name;assert p.exists()and sha(p.read_bytes())==pin['sha256'],name
result={'at':datetime.now(timezone.utc).isoformat(),'initial_source_files_missing_before':len(missing),'restored_base_files':restored,'owned_source_pins_preserved':len(owned),'unowned_initial_mismatches_after':unmatched,'excluded':'Historical evidence archive files are not runtime/source inputs and were not restored.'}
(s/'scoped-restoration.json').write_text(json.dumps(result,indent=2)+'\n')
assert not unmatched,unmatched
print({'missing_before':len(missing),'restored_files':len(restored),'owned_pins':len(owned),'unowned_mismatches':len(unmatched)})
