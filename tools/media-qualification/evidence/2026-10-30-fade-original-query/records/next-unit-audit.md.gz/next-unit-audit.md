# Next unit: the retained-input fade product

Read-only audit while the current fade checkpoint finishes. Navigation began with the requested `ripwire . --for='AudioRetainedInput::fades AudioOwnerInput audio_fades.rs remaining ordinary queries'` in Main, then bounded source reads and exact caller searches. The actual type is `AudioOwnerRetainedInput`. No repository edits, build, native execution, OLD capture, oracle changes or production implementation were performed.

## Preferred bounded unit

Admit actual `AudioOwnerRetainedInput::fades`, reuse the existing fixed-sample `AdmittedAudioFadeQuery<I,L>`, and retain that local carrier through its actual consumer `StageAudio::read_retained_controlled`. This closes the remaining live ordinary creative-fade constructor. It is independently useful for the public retained read, authored retained treatment read, owner equalizer halo chunks and retained Original operands in authored/shared EQ.

Do not couple this unit to admitting every Signal/Tape/Mix/Source/Projected constructor. Those are real remaining work, mapped below, but they form a broader recursive preparation family. A retained fade product can be complete while those independent metadata products remain explicitly open. There is no reason to change general Split behavior, increase a cap, alter DSP, introduce a public preparation split or put the new carrier in Graph.

Proposed public addition: `AudioOwnerRetainedInput::fades_admitted<A: AudioSoundContextAdmission>(samples, limits, &mut A) -> Result<AdmittedAudioFadeQuery<A::Issuer,A::Lease>, A::Error>`. The ordinary method remains the literal false backend. This is a separate API from Root/physical-Domain fades: its input range can precede and follow current delivery.

## Actual remaining callers

| Actual site | What remains ordinary | Reachability and boundary |
| --- | --- | --- |
| `stages.rs:1383`, `read_retained_controlled` | `input.fades`, followed by successful `spend_plan_work(fades.work)` | Live production call. Public `read_retained_owner_input` and `read_retained_owner_treatments` both reach it. |
| `owner_equalizer.rs:481`, `equalize_owner_tile` | Calls the same retained controller with authored=false for retained halo chunks | The equalizer keeps its own ordinary retained handle. Do not replace this with the nominal descendant clock. |
| `authored_eq.rs:608` | Calls the retained controller for `Context::Retained` with authored=false | The graph's shared retained handle can have been created by the actual admitted retained-probe/share path at authored_eq.rs:171/208. |
| `shared_eq/original_inputs.rs:563` | Calls the retained controller on a retained Original cache miss | A graph/original cache hit already bypasses this constructor. Retained final policy is not accepted by prepared Root/Domain policy prediction, so do not invent a new policy-availability claim. |
| `read_retained_controlled:1387` | In the authored=true branch, `input.owners` is ordinary and successfully billed | An admitted constructor already exists: `AudioOwnerRetainedInput::owners_admitted` in audio_owners.rs:527. A host follow-through can use it without creating a new owner algorithm. Keep this a separately identified existing product/receipt. |
| `read_bound_at:1608` | Actual `bound.raw_domain()` construction on every bound read | Live recursive path, including retained reads. Root maps to transferred Domain reading; Point maps to point-domain signal reading; silent Hold and empty support can return early. This is not fixed by admitting fade metadata. Do not silently substitute cached input.domain() for the existing raw-domain construction. |
| `stages.rs:2714/2719`, `read_signal` | `SignalInput::query` then `SignalInput::policy`, both successful-only bills | Live definition, point-domain, tape and streamed-stage input path. It dispatches Structural, Source, Silence, Projected and tape providers. Structural's shared algorithm currently runs through its Unmetered wrapper here; the existence of an internal admitted Structural assembler does not admit these public callers. |
| `stages.rs:2535`, `build_stage` | Complete output policy pages before source I/O | Live intrinsic preparation, including output-grid audible policy not represented by input points. Preserve this complete-history preflight. |
| `stages.rs:3002`, `suppress_signal` | Output policy after DSP | Live stage output suppression, separate from the earlier input query/policy. |
| `stage_projection.rs:252..274`, `preflight_intrinsic` | Mix query, or input policy then input query, plus complete output policy pages | Actual projected/tape/mix recursive preflight. Mix scopes and PreserveTape output policy cannot be replaced by a flattened query. |
| `signal_mix.rs:90`, `read_mix_controlled` | Actual `mix.query`, containing per-voice signal and policy products | The complete query is preflighted before any voice source I/O, then held into rendering. Admitting only one voice would leave the returned mix closure open. |
| `retained_sound_input.rs:215..261`, `prepare_retained_sound_query` | Source root query, Projected root policy, or Occurrence processing query | This is independent sound input, not AudioOwnerRetainedInput. Its prepared raw query and synthesized occurrence read views remain separate ordinary metadata. It does not call creative `fades`. |

The Root and physical-Domain ordinary fade calls remaining in `original_request.rs:498/499` are inside the explicit cfgtest legacy branch. Production `prepare_fades` uses `audio_fades_admitted`/`fades_admitted`. The calls in `audio_fades_query.rs:85/106` are the intended false compatibility backend. Other direct Root/Domain `.fades` hits are tests/oracles. Public ordinary compatibility APIs remain callable externally by design; their existence alone is not an internal production bypass.

## Retained canonical work and failure order

`AudioOwnerRetainedInput::fades` at audio_owner_input.rs:308:

1. Validate limits, then reject only reversed ranges. Do not impose nonnegative start, root support, current delivery, or cached raw-domain bounds.
2. Empty requests return spans=[], default lookup and work=0 under valid positive limits.
3. Before each output span, enforce `retained fade span count`.
4. Prepay the existing canonical aggregate exactly:

   `1 + self.bound().work() + processing.retimes.len() + processing.instance.repeats.len() + editorial.editorial.len() + editorial.constraints.len() + editorial.repeats.len()`.

5. Clone actual processing first, then actual editorial capture, then call shared retained_bound_fade with the complete requested end. Its q, positive-step, optional envelope, scale, outer-marker transformation, support checks, floor/inverse-ceil geometry and edge merge order remain unchanged.
6. Validate exact start, positive advance and `span.samples.end <= samples.end`, using the current `retained fade interval did not advance` label, then push.

This caller's canonical aggregate is not the Root loop's spend(1), and is not a new Core resolution. Do not replace, subtract or refund the existing `bound.work` scalar because the value was already constructed. Similarly, the host currently spends `input.work()` before constructing fades; keep that pre-existing debit until a separately witnessed provenance contract explicitly changes it. Successful fade work should cease to be rebilled only after the new admitted fade constructor forwards its actual receipt.

There are two input-construction provenances in real callers. `PreparedOwnerEqualizer::new:246` uses ordinary retained_probe_at. Authored EQ's capture adapter uses retained_probe_at_admitted and into_shared_admitted. Actual admitted probing may leave augmented resolved.work inside the immutable retained Bound, unlike an ordinary reconstruction. Since the old retained fade formula reads `self.bound().work()`, the OLD fade result for an admitted-created handle can differ from the result for a separately rebuilt ordinary handle. Freeze and compare the exact same input provenance and counters. Do not recursively strip work, substitute canonical resolved counters, fabricate an offset or claim an unrelated ordinary input is equivalent.

## Ownership and the minimal implementation seam

The existing admitted fade Bound helper is useful but currently clips end to processing.allocated_samples.end at audio_fades_query.rs:445. Calling it unchanged for retained history would truncate or reject valid beyond-delivery reads. Factor the already shared body so Root's wrapper alone performs the old current-allocation clip; a narrow within-Plan retained helper receives the untrimmed end. Return a guarded completed span with its side capacities adopted, and reuse the existing outer collector and final immutable carrier seal. This needs no public Core escape and no arbitrary provider extension.

Place the retained factory's private implementation as a child of audio_owner_input, where it can inspect the real private processing/editorial fields. Expose only the narrow guarded retained-span assembly and carrier seal within Plan. Do not make the fields generally mutable or detach charges. Every earlier span, current copy, old/replacement buffer and retained envelope must remain owned before all their independent leases on failure/unwind.

Actual per-span copy ownership that the present Root/Domain factory does not need to perform:

- `AudioProcessingSpan::clone`: optional definition selector, independent occurrence instance and repeat Vec/identities, optional gap iteration, retime Vec and each node identity, then the Bound content Box. Samples/extents/transforms/grid/map are scalar copies.
- `AudioBound::clone` inside that Box: its own optional definition, independent instance/repeat Vec, optional DomainGap/iteration, resolved placement's separate instance/repeat Vec and gap identity, plus constraints Vec and nested optional gap identities. `resolved.resume` and ratio/range/grid/work fields are scalar. The resolved placement path and outer bound path are independent owning edges even when structurally equal.
- `EditorialCapture::clone`: editorial Vec with each constraint's optional gap identity, constraints Vec, repeats Vec and independent node/iteration edges.
- Original cloned processing and editorial coexist before any retained q/support early return. Do not borrow instead of copying and then claim the original cloning path was admitted. Keep the false path's literal derived clone behavior.
- Shared envelope-domain allocation, transported outer editorial growth, retained geometry/capture copies, start-before-end side allocation, owning origins and coincident-origin replacement are the newly reviewed fade implementation. Reuse that closure, including centrally checked merge propagation, rather than add a second edge algorithm.
- Outer output Vec growth must hold all completed spans, the old buffer and current guarded span while reserving the full replacement, with actual move fees outside guarded infallible maps.

A narrow private admitted clone for this exact Bound/processing shape can be implemented entirely in Plan. ResolvedAudioBinding and ResolvedAudioPlacement expose their actual finite owning fields; copying that already resolved immutable value does not execute another Core resolution or mint a Core receipt. Reserve and guard the real copies/Box and preserve both numeric work fields. This must not become a general public clone/detach of AudioBindingValue. Verify the pinned toolchain's Box clone allocation ordering when choosing the conservative reservation bracket; false mode must remain literal, and the admitted copied value must always precede all payload/capacity guards.

At the host, keep the new local carrier alive through creative-fade validation, later owner-query construction, required PCM room checks, read_bound_at and final creative application. Its read-only query reference replaces the current AudioFadeQuery borrow. End the short Admission borrow after construction; do not second-bill a successfully forwarded fade. Release metadata before returning PCM. No new externally reusable prepared retained request is required by this synchronous local call. If a private split is introduced for an actual caller, it must validate actual issuer/mode before I/O rather than inventing a public generalized split.

For authored=true, prefer using the existing owners_admitted API in the same host integration, retaining its separate carrier through gain application. It already has its own frozen constructor evidence. Otherwise state explicitly that retained authored-owner metadata remains ordinary after fade closure. Neither choice admits read_bound_at's raw domain, Point signal clone, recursive signal/tape/mix queries or native workspace.

## OLD witness required before changes

The frozen fade-query-baseline-v1 standalone supplement has six factory setups, one Some and six fade calls. It is useful regression evidence, not enough to freeze this new complete retained constructor closure or actual host provenance.

Prepare a separate test-only ordinary retained-fade producer before changing clone/helper algorithms. Reuse complete checked fixtures and existing exhaustive serializers. Record final full ProjectDocument/reference timing state, selector/owner setup, actual observed_at, exact physical delivery, actual raw-domain tag and complete retained processing/editorial/Bound/domain/work snapshot. Record whether the factory returns Some, None or an error; do not turn a None setup into synthetic success.

Add the checked Root retained case `audio_owners/input_tests.rs::retained_binding_is_not_reconstructed_from_its_nominal_descendant_clock` with its actual -3..7 history, phase and page seams. Add actual Source/Point histories from `bound_reads/owner_input.rs::retained_point_input_fades_keep_fractional_source_phase_before_delivery`, plus `retained_ntsc_binding_and_silence_keep_the_current_output_policy` and `retained_treatments_keep_reference_gain_mute_and_order_without_exterior_owners`. Port the actual document construction and declared source metadata into Plan setup; WAV reading stays a separate host proof. Reuse existing admitted/ordinary retained-probe fixtures to obtain both actual provenance modes, retaining their independent guard while querying the borrowed input.

For each genuine Some, record actual full delivery, before/after delivery, negative and fractional phase, one-sample incident/seam pages, empty and reversed ranges, exact actual returned work, one-short when representable, actual positive span-boundary trials, invalid zero/above-cap limits mixed with reversed ranges and tiny positive work. Preserve every successful field/lookup/work and typed error literally. Add extreme signed requests only as actual API trials; do not invent their expected overflow result. The ordinary error API still exposes no accepted partial-work receipt.

Separately freeze real host ordinary current values, masks, dependencies, depth, source admission and exact ReadWork with the exact retained provenance. Preserve old input.work and authored owner query debits in these receipts. Use explicit legacy mode once new admitted fades/owners land so OLD and new fees can be paired without erasing cache/eviction differences. Do not regenerate any of the existing 17 frozen oracles.

Synthetic_empty_support_for_test is private branch coverage and explicitly not a document/provider oracle. It must stay separate from the OLD corpus and from claims of publicly reachable meaningful-support None/Empty. Prefer actual checked fixtures; if no factory produces that branch, report the bounded gap.

## Acceptance and completion boundary

1. Both roots independently capture/equal/review the new complete OLD witness before implementation. False admitted mode matches it literally with zero resource callbacks and ordinary helpers unchanged.
2. True output has identical complete fields apart from reconciled top work; canonical equals OLD for the exact same retained provenance; total equals canonical plus actual additional and accepted callbacks. Preserve bound.work's literal prepay, no new Core resolution, all old validation/error priority and unrestricted history behavior.
3. Actual initial clone/Box/old-new path and editorial/output-buffer overlap get independent requested-Layout expectations, not a final-size estimate. Exact/one-short total/peak, every meaningful reserve/spend/merge refusal and cancellation/issuer rotation leave all old/new issuer ledgers at zero after drop, with accepted work never refunded. Central checked merge remains authoritative.
4. Positive live metadata at real WAV source/nested DSP callbacks; aggregate retained fade plus later owner metadata reduces actual PCM room; success, error and unused local drop release charges before returned PCM. Source/domain/depth/range priority and fresh-source preflight remain exact. Real cache hits continue to skip actual construction where the caller already bypasses this local read.
5. Retained Root, PointCeil fractional source, before/after support, resumed delivery seam, SilentHold versus actual raw emptiness, incident editorial eligibility, Hard precedence and independent origin paths remain covered by real constructors. No scalar-counter normalization or fake span/query supplies a missing proof.

Completion means the standalone retained creative fade product and its real host lifetime are admitted, plus explicitly named reuse of existing owner admission if included. General Signal/Tape/Mix/Source/Occurrence/Projected metadata, raw bound-domain construction and arbitrary native preparation remain visible later units. The current four-product Root/Domain checkpoint must not be described as closing those recursive factories.

## Exact read pins

SHA256 observations only. These identify the read state, not a new executable/capture/publication. Scope equality is stated for each file.

| Path | Main SHA256 | Scope |
| --- | --- | --- |
| `crates/deadpan-plan/src/audio_owner_input.rs` | `3e05de22bd25de72882d942c11221043a06c53a2d9536ca502814088b2c665c2` | same |
| `crates/deadpan-plan/src/audio_owner_probe.rs` | `2d51a72c6a54452eacd4d8d305821dab45ac98ac4307998895f1b7036e3bd97f` | same |
| `crates/deadpan-plan/src/audio_fades.rs` | `b9ea79fbe311e790861fc9a65118616be26947357235c7242edfc84d00e74af2` | same |
| `crates/deadpan-plan/src/audio_fades_query.rs` | `b69db756a935582720c131b9ce30c63b78ba630b0b3967780fe723123f2ee051` | same |
| `crates/deadpan-plan/src/audio_bound.rs` | `ac25028a624378198c3fe4276ccaec42cf898fc80f12a88d5266b32d6fbb306f` | same |
| `crates/deadpan-plan/src/audio_bound_query.rs` | `d57c9d91afc4c1542860fb575dddd37f464ea1aec6cc6a4def6249aa4a566c4b` | same |
| `crates/deadpan-plan/src/audio_owners.rs` | `091063782b42fb715274e8c678ab383273cc2002e8584855a80e07ce621ff47f` | same |
| `crates/deadpan-plan/src/audio_retained_owner_query.rs` | `541a87095a44140d982b3ead4b3d8596d5446bcad586b36e7e9c75a812ed176d` | same |
| `crates/deadpan-plan/src/audio_signal.rs` | `115e8a3162122f16127aabac15e0283a35262f20541af16f2be64044931df76f` | same |
| `crates/deadpan-plan/src/audio_signal_processing_query.rs` | `d3cfe70a9d6b4d7e324c9a7da9d99693795289078564acb65ff350f57d1b2cf7` | same |
| `crates/deadpan-plan/src/audio_owners/input_tests.rs` | `ec8399829f11cf40b417f3892e18bcd836d6b5169c1db74af492e7594c19715e` | same |
| `crates/deadpan-core/src/audio_binding.rs` | `cc69f19a1efb0bf8667080eb4433f76bd841aa4495f44d8237fb16f932263564` | `e4504ced21a29b595cfc15a8e15d63d0003336c9b864f2335e3479c92398965f` |
| `crates/deadpan-audio/src/stages.rs` | `7fa81e333bf6cbfb777d807f3e52f498f415169775f0db0f7d2e552482509e77` | same |
| `crates/deadpan-audio/src/signal_input.rs` | `e1b9782f8730a19ce2fc46e393033f642d666d6109466b045146d747b8a08085` | same |
| `crates/deadpan-audio/src/signal_mix.rs` | `a0d083a6b11287681b2d5bcbd6f21ce62baa11a1ed3e1322adeaeb31e5fb062d` | same |
| `crates/deadpan-audio/src/stage_projection.rs` | `a5f08ab39c0f3b24538f69d0ce8560bc00544ca262fb6340bd92298a9a03f2c6` | same |
| `crates/deadpan-audio/src/retained_sound_input.rs` | `06f8dbbfa1a1c538c0da315d675b720c4ca404e22f137d8ce700a9e3078a2002` | same |
| `crates/deadpan-audio/src/authored_eq.rs` | `99f5d5b6243492dadcf1815d3b360fc3fe824fdc730fd646d9e24c4e02145125` | same |
| `crates/deadpan-audio/src/owner_equalizer.rs` | `b83d0d41d4a11054d626f31574651e8dfb078410ed40b3ca4de668b2bbc7c5fa` | same |
| `crates/deadpan-audio/src/shared_eq/original_inputs.rs` | `b029c29784b9ffc03cb84a8209eab68c3930a8fb86e2e1e87e83ff83956caba3` | same |
| `crates/deadpan-audio/src/bound_reads/owner_input.rs` | `53e83f654691063478a3af23aa7a96e6f82f24d136c7f90b1bfe15bc466f5b6b` | same |
| `crates/deadpan-audio/src/original_request.rs` | `e1e5ae79e003d1a25f71b03ce1d7b9ba6085bb89daaad99d793e12684c487da1` | same |
| `crates/deadpan-plan/tests/fixtures/fade-query-baseline-v1/snapshot.json` | `09502b80324734819b4f9acdd62b1dbd42eeeb29083d61366ecc88d28f8526f7` | same |
