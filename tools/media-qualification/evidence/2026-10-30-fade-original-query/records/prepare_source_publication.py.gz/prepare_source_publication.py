from pathlib import Path
import tarfile,json,hashlib,difflib
s=Path(__file__).resolve().parent
base=s/'base-source'
paths=json.loads((s/'owned-paths.json').read_text())
assert not base.exists()
with tarfile.open(s/'base-source.tar') as archive:
 for item in archive:
  if item.isdir() or item.name not in paths:continue
  assert item.isfile() and '..' not in Path(item.name).parts
  target=base/item.name
  target.parent.mkdir(parents=True,exist_ok=True)
  target.write_bytes(archive.extractfile(item).read())
roots={'main':Path('/Users/michael/Code/deadpan'),'scoped':Path('/tmp/deadpan-query-groundwork-2026-10-26/scoped')}
paths=json.loads((s/'owned-paths.json').read_text())
initial=json.loads((s/'scoped-initial-authority.json').read_text())
sha=lambda b:hashlib.sha256(b).hexdigest()
patch=[]
rows=[]
for name in paths:
 old=(base/name).read_bytes() if (base/name).exists() else b''
 if name in initial:
  assert sha(old)==initial[name]['sha256'],('initial differs from published base',name)
 else:
  assert not old,('unexpected existing base',name)
 new=(roots['scoped']/name).read_bytes()
 patch.extend(difflib.unified_diff(old.decode().splitlines(True),new.decode().splitlines(True),fromfile='a/'+name if old else '/dev/null',tofile='b/'+name))
 rows.append({'path':name,'base_exists':bool(old),'base_sha256':sha(old),'scoped_bytes':len(new),'scoped_sha256':sha(new),'main_equal':(roots['main']/name).read_bytes()==new})
p=s/'shipping-source.patch';assert not p.exists()
p.write_text(''.join(patch))
(s/'publication-source-plan.json').write_text(json.dumps(rows,indent=2)+'\n')
for variant,root in roots.items():
 pins={name:{'bytes':len((root/name).read_bytes()),'sha256':sha((root/name).read_bytes())} for name in paths}
 (s/(variant+'-final-source-pins.json')).write_text(json.dumps(pins,indent=2)+'\n')
print(json.dumps({'paths':len(paths),'base_existing':sum(r['base_exists'] for r in rows),'main_equal':sum(r['main_equal'] for r in rows),'patch_bytes':p.stat().st_size,'patch_sha256':sha(p.read_bytes())}))
