from pathlib import Path
import json,hashlib
s=Path(__file__).resolve().parent
a=(s/'fade-current-body-main.json').read_bytes()
b=(s/'fade-current-body-scoped.json').read_bytes()
assert a==b
d=json.loads(a)
assert set(d)=={'legacy','legacy_zero','reconciliation','warm','warm_zero','zero_reconciliation'}
deltas={'cold':[],'repeat':[]}
for group in ['reconciliation','zero_reconciliation']:
 for case in d[group]:
  for interval in case['intervals']:
   for lane in interval['lanes'].values():
    assert lane['warm']-lane['legacy']==lane['actual_delta']==sum(lane['phase_deltas'])
   deltas[interval['interval']].append(interval['lanes']['plan_work']['actual_delta'])
assert len(deltas['cold'])==len(deltas['repeat'])==8
assert all(v<0 for v in deltas['repeat'])
result={'bytes':len(a),'sha256':hashlib.sha256(a).hexdigest(),'main_scoped_equal':True,'work_deltas':deltas}
(s/'current-native-equality.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result))
