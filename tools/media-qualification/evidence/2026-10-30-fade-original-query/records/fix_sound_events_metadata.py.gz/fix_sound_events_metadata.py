from pathlib import Path
import json
s=Path(__file__).resolve().parent
rel='crates/deadpan-audio/tests/sound_events.rs'
roots=[Path('/Users/michael/Code/deadpan'),Path('/tmp/deadpan-query-groundwork-2026-10-26/scoped')]
for root in roots:
 p=root/rel;t=p.read_text()
 t=t.replace('use std::collections::BTreeMap;','use std::collections::BTreeMap;\nuse std::ops::Range;',1)
 anchor='const PROVIDER_SENTINEL: &str = "synthetic provider reached after admission";\n'
 assert t.count(anchor)==1
 t=t.replace(anchor,anchor+'''
#[path = "stages/flattened_metadata.rs"]
mod flattened_metadata;

fn resident_limit(plan: &RenderPlan, pcm_frames: u64) -> u64 {
    let metadata = flattened_metadata::root(plan, AudioSample(0)..AudioSample(256));
    pcm_frames.checked_add(metadata.peak_frames).unwrap()
}
''',1)
 old='''    let mut renderer = StageAudio::with_limits(
        held_sound(),
        StageLimits {
            maximum_resident_frames: 640,'''
 new='''    let plan = held_sound();
    let limit = resident_limit(&plan, 640);
    let mut renderer = StageAudio::with_limits(
        plan,
        StageLimits {
            maximum_resident_frames: limit,'''
 assert t.count(old)==2;t=t.replace(old,new)
 old='''    let mut renderer = StageAudio::with_limits(
        plan,
        StageLimits {
            maximum_resident_frames: 640,'''
 new='''    let limit = resident_limit(&plan, 640);
    let mut renderer = StageAudio::with_limits(
        plan,
        StageLimits {
            maximum_resident_frames: limit,'''
 assert t.count(old)==1;t=t.replace(old,new)
 old='''    let mut renderer = StageAudio::with_limits(
        gap_masked_sound(),
        StageLimits {
            maximum_resident_frames: 768,'''
 new='''    let plan = gap_masked_sound();
    let limit = resident_limit(&plan, 768);
    let mut renderer = StageAudio::with_limits(
        plan,
        StageLimits {
            maximum_resident_frames: limit,'''
 assert t.count(old)==1;t=t.replace(old,new)
 p.write_text(t)
owned=set(json.loads((s/'owned-paths.json').read_text()));owned.add(rel)
(s/'owned-paths.json').write_text(json.dumps(sorted(owned),indent=2)+'\n')
print('Sound tests measure actual four-query metadata peak separately from their unchanged PCM allowance.')
