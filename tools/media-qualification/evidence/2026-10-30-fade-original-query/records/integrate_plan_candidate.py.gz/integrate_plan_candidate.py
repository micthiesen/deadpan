from pathlib import Path
import hashlib,json
s=Path(__file__).resolve().parent;c=s/'plan-candidate'
sourcepaths=['crates/deadpan-plan/src/audio_fades.rs','crates/deadpan-plan/src/plan.rs','crates/deadpan-plan/src/lib.rs']
newpaths=['crates/deadpan-plan/src/audio_fades_query.rs','crates/deadpan-plan/src/audio_fades_query_trace.rs']
test='crates/deadpan-plan/src/audio_owners/fade_query_admission_tests.rs'
declaration='crates/deadpan-plan/src/audio_owners/wide_gain_query_admission_tests.rs'
pins=json.loads((c/'source-pins.json').read_text())
for variant,root in [('main',Path('/Users/michael/Code/deadpan')),('scoped',Path('/tmp/deadpan-query-groundwork-2026-10-26/scoped'))]:
 for name in sourcepaths:
  before=(root/name).read_bytes()
  assert hashlib.sha256(before).hexdigest()==pins[variant+'/'+name],(variant,name)
  out=s/'plan-integration-before'/variant/name;out.parent.mkdir(parents=True,exist_ok=True);out.write_bytes(before)
  (root/name).write_bytes((c/'after'/variant/name).read_bytes())
 for name in newpaths:
  assert not(root/name).exists()
  data=(c/name).read_bytes()
  assert hashlib.sha256(data).hexdigest()==pins['candidate/'+name],name
  (root/name).write_bytes(data)
 assert not(root/test).exists()
 (root/test).write_bytes((s/'plan-tests-candidate/fade_query_admission_tests.rs').read_bytes())
 before=(root/declaration).read_text()
 assert 'mod fade_admission;'not in before
 out=s/'plan-integration-before'/variant/declaration;out.parent.mkdir(parents=True,exist_ok=True);out.write_text(before)
 (root/declaration).write_text(before+'\n#[path = "fade_query_admission_tests.rs"]\nmod fade_admission;\n')
 names=json.loads((s/(variant+'-logic-source-files.json')).read_text())
 names=sorted(set(names)|set(newpaths)|{test})
 (s/(variant+'-logic-source-files.json')).write_text(json.dumps(names,indent=2)+'\n')
owned=json.loads((s/'owned-baseline-paths.json').read_text())
(s/'owned-plan-paths.json').write_text(json.dumps(sorted(set(owned)|set(sourcepaths)|set(newpaths)|{test,declaration}),indent=2)+'\n')
print('Integrated initial guarded Plan constructor and seven test contracts in both roots.')
