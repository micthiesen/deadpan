from pathlib import Path
import collections,hashlib,json
s=Path(__file__).resolve().parent
bodies=[]
for variant in ['main','scoped']:
 value=json.loads((s/('fade-old-'+variant+'-body.json')).read_text())
 assert value['published_policy_checkpoint']==(s/'published-policy-checkpoint.txt').read_text().strip()
 for name in ['variant','source_sha256','published_policy_checkpoint']:assert value.pop(name) is not None
 bodies.append(value)
assert bodies[0]==bodies[1]
value=bodies[0]
data=(json.dumps(value,separators=(',',':'),ensure_ascii=False)+'\n').encode()
canonical=s/'fade-old-canonical-body.json';assert not canonical.exists();canonical.write_bytes(data)
cases=value['cases']
errors=collections.Counter(); results=collections.Counter(); default=[]; policies=collections.Counter(); kinds=collections.Counter()
def walk(x):
 if isinstance(x,dict):
  if 'result'in x:results[x['result']]+=1
  if x.get('result')=='Error':errors[json.dumps(x['error'],sort_keys=True)]+=1
  if 'policy'in x:policies[str(x['policy'])]+=1
  if 'kind'in x:kinds[str(x['kind'])]+=1
  for item in x.values():walk(item)
 elif isinstance(x,list):
  for item in x:walk(item)
walk(value)
for case in cases:
 first=case['observations'][0]
 assert first['name']=='default_full'
 out=first['output']
 default.append({'name':case.get('name',case.get('case')),'parent_kind':case['parent_kind'],'observations':len(case['observations']),'default_result':out['result'],'default_error':out.get('error'),'work':out.get('query',{}).get('work'),'spans':len(out.get('query',{}).get('spans',[])),'one_short_availability':case['one_short_output_span_limit_availability']})
summary={'equal_excluding_exactly_three_provenance_fields':True,'canonical_bytes':len(data),'canonical_sha256':hashlib.sha256(data).hexdigest(),'coverage':value['coverage'],'result_counts':dict(results),'typed_error_counts':dict(errors),'default_cases':default,'boundary_policies':dict(policies),'boundary_kinds':dict(kinds),'standalone_retained_input':{'scope':value['standalone_retained_input']['scope'],'cases':len(value['standalone_retained_input']['cases'])}}
(s/'old-equality-and-coverage.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps({k:v for k,v in summary.items()if k!='default_cases'},indent=2))
print('Default parents:',len(default),'errors:',sum(r['default_result']=='Error'for r in default))
print('Case keys:', list(cases[0]))
