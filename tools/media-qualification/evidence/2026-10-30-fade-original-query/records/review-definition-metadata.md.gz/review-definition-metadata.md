# Review: sound-clock residency test metadata correction

1. **Test evidence gap: the allowance measures a different request window.** In `crates/deadpan-audio/tests/audio_definition/sound_clocks.rs`, the helper measures `flattened_metadata::root(&plan, 4805..4837)` (32 samples), but the operation under test calls `prepare_authored_bus(..., 4805, 256, ...)`, which constructs Root queries for `4805..5061`. The cap is therefore 1280 PCM frames plus the 32-sample query's peak. If the 256-sample query has a larger metadata peak, metadata admission itself can cause the expected `Limit("resident PCM or stage cache")` before provider I/O; the test would still pass without demonstrating the intended PCM-residency refusal. Measure the exact 256-sample query peak, or assert that its peak equals the 32-sample peak; ideally distinguish metadata-reservation refusal from the later PCM reservation.

The `Range` import supplied by the integration parent is visible through the child modules' `use super::*`; it is not unused. Static review only; I ran no build or test.

## Resolution check

The follow-up now measures both 4805..4837 and the exact 256-sample request window 4805..5061, then adds the larger observed peak. This addresses the range mismatch identified above. The scratch `fade-definition-final-sanity.json` receipt also reports exit 0, the exact test passed (1 passed, 170 filtered), and source/binary guards remained unchanged. I did not run it. The test still asserts the resident-limit error and zero provider calls; the review claim is now bounded to the corrected two-window measurement plus that observed outcome.

Static follow-up: current fixture computes `large_metadata` over `AudioSample(4805)..AudioSample(5061)`, the half-open range for the exact 256-sample request beginning at 4805, and sets the allowance from `1280 + max(small_metadata.peak_frames, large_metadata.peak_frames)`. This resolves the reviewed mismatch; no source execution was performed by me.
