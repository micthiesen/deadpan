from pathlib import Path
import hashlib,json,re,difflib
s=Path(__file__).resolve().parent
root=Path('/Users/michael/Code/deadpan')
candidate=s/'native-proofs-candidate'
paths=['crates/deadpan-audio/src/authored_eq/legacy_tile_baseline.rs','crates/deadpan-audio/src/authored_eq/tile_admission_tests.rs','crates/deadpan-audio/tests/stages/flattened_metadata.rs']
before={}
for name in paths:
 p=candidate/'before'/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes((root/name).read_bytes());before[name]=p.read_text()
name=paths[0];text=before[name]
anchor='        "policy_work_trace": crate::stages::original_request::flattened_work_trace::policy_snapshot(),\n'
assert text.count(anchor)==1
text=text.replace(anchor,anchor+'        "fade_work_trace": crate::stages::original_request::flattened_work_trace::fade_snapshot(),\n',1)
after={name:text}
name=paths[1];text=before[name]
anchor='        ("policy_work_trace", "policy"),\n'
assert text.count(anchor)==3,text.count(anchor)
text=text.replace(anchor,anchor+'        ("fade_work_trace", "fade"),\n')
text,count=re.subn(r'(?m)^(\s*)"policy_work_trace",\n',lambda m:m[0]+m[1]+'"fade_work_trace",\n',text)
assert count==3,count
anchor='    let old_policy_fees = query_fees(&old_policy, "policy reference");\n'
assert text.count(anchor)==1
text=text.replace(anchor,anchor+'    let fade = take_query_trace(actual, "fade_work_trace");\n    let old_fade = take_query_trace(&mut old, "fade_work_trace");\n    let fade_fees = query_fees(&fade, "fade");\n    let old_fade_fees = query_fees(&old_fade, "fade reference");\n')
anchor='        assert_eq!(host_eviction_receipt(&old_policy), old_host);\n'
assert text.count(anchor)==1
text=text.replace(anchor,anchor+'        assert_eq!(host_eviction_receipt(&fade), host);\n        assert_eq!(host_eviction_receipt(&old_fade), old_host);\n')
anchor='            - i128::from(old_policy_fees[lane])\n'
assert text.count(anchor)==1
text=text.replace(anchor,anchor+'            + i128::from(fade_fees[lane])\n            - i128::from(old_fade_fees[lane])\n')
text=text.replace('separately witnessed processing/policy fees differ','separately witnessed processing/policy/fade fees differ')
after[name]=text
name=paths[2];text=before[name]
anchor='        .audio_policy_admitted(\n            samples,\n'
assert text.count(anchor)==1
text=text.replace(anchor,'        .audio_policy_admitted(\n            samples.clone(),\n',1)
anchor='    assert!(ledger.reservations.get() > 0);\n'
assert text.count(anchor)==1
addition='''    let fade = plan
        .audio_fades_admitted(
            samples,
            AudioQueryLimits::default(),
            &mut Admission(&ledger),
        )
        .unwrap();
    assert!(fade.was_forwarded());
    assert_eq!(fade.work(), fade.canonical_units() + fade.additional_units());
    assert_eq!(
        ledger.work.get(),
        query.work() + processing.work() + policy.work() + fade.work()
    );
'''
text=text.replace(anchor,addition+anchor,1)
assert text.count('drop((query, processing, policy));')==1
text=text.replace('drop((query, processing, policy));','drop((query, processing, policy, fade));')
after[name]=text
for name,text in after.items():
 p=candidate/'after'/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(text)
patch=''.join(''.join(difflib.unified_diff(before[name].splitlines(keepends=True),after[name].splitlines(keepends=True),fromfile='a/'+name,tofile='b/'+name))for name in paths)
(candidate/'changes.patch').write_text(patch)
(candidate/'pins.json').write_text(json.dumps({name:{phase:hashlib.sha256((candidate/phase/name).read_bytes()).hexdigest()for phase in ['before','after']}for name in paths},indent=2)+'\n')
print('Prepared fourth actual receipt and four-product residency candidate; not integrated or compiled.')
