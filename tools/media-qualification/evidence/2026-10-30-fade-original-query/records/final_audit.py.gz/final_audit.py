from pathlib import Path
from datetime import datetime
import hashlib,json,re
s=Path(__file__).resolve().parent
roots={'main':Path('/Users/michael/Code/deadpan'),'scoped':Path('/tmp/deadpan-query-groundwork-2026-10-26/scoped')}
sha=lambda b:hashlib.sha256(b).hexdigest()
negative={
'fade-eviction-scoped-test':101,
'fade-final-scoped-audio-sound-events':101,
'fade-integrated-main-strict':1,
'fade-integrated-scoped-audio':101,
'fade-integrated-scoped-strict':101,
'fade-plan-initial-main-tests':101,
'fade-plan-initial-scoped-tests':101,
'fade-plan-merge-diagnostic':101,
'fade-sound-diagnostic':101,
'fade-sound-metadata-build':101,
'fade-final-fresh-split':101,
'fade-revised-scoped-audio-audio-definition':101,
}
receipts=[];native=[]
for p in sorted(s.glob('*.json')):
 row=json.loads(p.read_text())
 if not isinstance(row,dict)or'command'not in row or'started_at'not in row:continue
 if p.stem=='fade-terminal-scoped-audio-audio-definition':
  interruption=json.loads((s/'filesystem-interruption.json').read_text())
  assert 'exit_code'not in row and interruption['raw_incomplete_receipt_sha256']==sha(p.read_bytes())and not interruption['acceptance_credit']
  for path,pin in interruption['streams'].items():
   b=Path(path).read_bytes();assert len(b)==pin['bytes']and sha(b)==pin['sha256']
  native.append((datetime.fromisoformat(row['started_at']),datetime.fromisoformat(interruption['observed_completion_at']),p.stem))
  continue
 if p.stem=='fade-final-fresh-split':
  assert row.get('exit_code')in(0,101),(p.stem,row.get('exit_code'))
 else:assert row.get('exit_code')==negative.get(p.stem,0),(p.stem,row.get('exit_code'))
 assert row['sources_unchanged']and row['binaries_unchanged'],p.stem
 for path,pin in row['streams'].items():
  b=Path(path).read_bytes();assert len(b)==pin['bytes']and sha(b)==pin['sha256'],path
 receipts.append({'label':p.stem,'exit_code':row['exit_code'],'seconds':row['seconds'],'source_inputs':len(row['source_before']),'sha256':sha(p.read_bytes())})
 if row['binary_before']and'-build-audio-'in row['command'][0]:
  native.append((datetime.fromisoformat(row['started_at']),datetime.fromisoformat(row['finished_at']),p.stem))
for a,b in zip(sorted(native),sorted(native)[1:]):assert a[1]<=b[0],('native overlap',a[2],b[2])
owned=json.loads((s/'owned-paths.json').read_text());assert len(owned)==45
assert set((s/'index-source-paths.txt').read_text().splitlines())==set(owned)
index=json.loads((s/'index-source-equality.json').read_text())
assert len(index)==45 and all(r['scoped_index_equal']for r in index)
assert {r['path']for r in index if not r['main_equal']}=={'crates/deadpan-plan/src/plan.rs'}
preserved={}
for variant,root in roots.items():
 pins=json.loads((s/(variant+'-final-source-pins.json')).read_text());assert set(pins)==set(owned)
 for name,pin in pins.items():
  data=(root/name).read_bytes();assert len(data)==pin['bytes']and sha(data)==pin['sha256'],(variant,name)
 initial=json.loads((s/(variant+'-initial-authority.json')).read_text())
 others={name:pin for name,pin in initial.items()if name not in owned}
 for name,pin in others.items():assert sha((root/name).read_bytes())==pin['sha256'],(variant,'unowned',name)
 preserved[variant]=len(others)
assert preserved=={'main':2764,'scoped':2436}
goldens=json.loads((s/'immutable-oracle-pins.json').read_text());assert len(goldens)==17
for row in goldens:
 for root in roots.values():assert sha((root/row['path']).read_bytes())==row['sha256'],row['path']
tests={}
for variant,expected in [('main',262),('scoped',249)]:
 labels=[r['label']for r in receipts if r['label'].startswith('fade-final-'+variant+'-plan-')and not r['label'].endswith('-build')]
 assert len(labels)==29
 count=0
 for label in labels:
  pairs=re.findall(r'test result: ok\. (\d+) passed; 0 failed; (\d+) ignored;',(s/(label+'.stdout')).read_text())
  assert len(pairs)==1,label
  passed,ignored=map(int,pairs[0])
  if label.endswith('-deadpan-plan'):assert(passed,ignored)==(expected,14)
  else:assert ignored==0;count+=passed
  tests[label]={'passed':passed,'ignored':ignored,'seconds':json.loads((s/(label+'.json')).read_text())['seconds']}
 assert count==450
reused=json.loads((s/'reused-native-receipts.json').read_text())
for variant in roots:
 build='fade-qualified-release-'+variant+'-build'
 row=json.loads((s/(build+'.json')).read_text());assert row['environment']['CARGO_PROFILE_DEV_OPT_LEVEL']=='2'
 pins=json.loads((s/(build+'-pins.json')).read_text());assert len(pins)==21
 for binary in pins:
  target=binary['name']
  prior=next((r for r in reused if r['variant']==variant and r['target']==target),None)
  if prior:
   label=Path(prior['receipt']).stem;assert prior['binary_sha256']==binary['sha256']
  else:label='fade-terminal-'+variant+'-audio-'+target.replace('_','-')
  if variant=='scoped'and target=='audio_definition':label='fade-recovered-scoped-audio-audio-definition'
  r=json.loads((s/(label+'.json')).read_text());assert r['exit_code']==0
  matches=re.findall(r'test result: ok\. (\d+) passed; 0 failed; (\d+) ignored;',(s/(label+'.stdout')).read_text());assert len(matches)==1,label
  passed,ignored=map(int,matches[0])
  if target=='deadpan_audio':assert(passed,ignored)==((419 if variant=='main'else 413),6)
  if target=='stages':assert(passed,ignored)==(203,0)
  if target=='audio_definition':assert(passed,ignored)==(171,0)
  tests[label]={'passed':passed,'ignored':ignored,'seconds':r['seconds'],'target':target,'variant':variant,'reused_unchanged_binary':bool(prior)}
 for name in owned:
  absolute=str(roots[variant]/name)
  if absolute in row['source_after']:assert row['source_after'][absolute]['sha256']==sha((roots[variant]/name).read_bytes()),(variant,'post-native-build source change',name)
  else:assert name.startswith('crates/deadpan-plan/tests/fixtures/'),name
current=json.loads((s/'current-native-equality.json').read_text())
a=(s/'fade-current-body-main.json').read_bytes();assert a==(s/'fade-current-body-scoped.json').read_bytes()
assert current['bytes']==len(a)and current['sha256']==sha(a)
split=(s/'fade-final-fresh-split.stdout').read_text()
matched=re.search(r'test result: (?:FAILED|ok)\. (\d+) passed; (\d+) failed;',split);assert matched
splitresult={'passed':int(matched[1]),'failed':int(matched[2]),'seconds':json.loads((s/'fade-final-fresh-split.json').read_text())['seconds']}
assert splitresult['passed']+splitresult['failed']==7
result={'all_terminal':True,'receipts':receipts,'native_audio_runs_serial':True,'tests':tests,'source_paths':45,'index_scoped_equal':45,'main_scoped_equal':44,'preserved_initial_inputs_outside_scope':preserved,'immutable_oracles':17,'current_native_body':current,'source_tree':(s/'index-source-tree.txt').read_text().strip(),'source_patch':{'bytes':(s/'shipping-source.patch').stat().st_size,'sha256':sha((s/'shipping-source.patch').read_bytes())},'split':splitresult,'reused_native_passes':len(reused),'filesystem_interruption':json.loads((s/'filesystem-interruption.json').read_text())}
(s/'final-audit.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items()if k not in ['receipts','tests']},indent=2))
