from pathlib import Path
import hashlib,json
s=Path(__file__).resolve().parent
body=(s/'fade-old-canonical-body.json').read_bytes()
digest=hashlib.sha256(body).hexdigest()
assert len(body)==2302377 and digest=='09502b80324734819b4f9acdd62b1dbd42eeeb29083d61366ecc88d28f8526f7'
review=s/'review-old-capture.md';assert review.exists(),'independent capture audit required before freeze'
paths=json.loads((s/'owned-producer-paths.json').read_text())
source='crates/deadpan-plan/src/audio_owners/legacy_snapshot_v1/fade_query_baseline.rs'
fixture='crates/deadpan-plan/tests/fixtures/fade-query-baseline-v1'
test='''
#[test]
fn ordinary_fades_match_frozen_old_capture_v1() {
    let expected: Value = serde_json::from_str(include_str!(concat!(
        env!("CARGO_MANIFEST_DIR"),
        "/tests/fixtures/fade-query-baseline-v1/snapshot.json"
    )))
    .unwrap();
    assert_eq!(matrix(), expected);
}
'''
readme=f"""# OLD ordinary fade query witness

Captured independently from Main and the isolated published candidate after policy
checkpoint 7da84fc1b57897bd990a51f575b60f1b903c7318 was pushed and remote-verified,
before any fade production algorithm changes.

The complete parsed bodies agree after removing exactly variant, source_sha256
and published_policy_checkpoint. Compact serialization removes whitespace only.
The body has {len(body):,} bytes and SHA-256 {digest}.

The Root/physical-Domain matrix has 80 actual parents (63 Root, 17 Domain) and
2,354 named actual calls: 1,046 successes and 1,308 typed errors. Every default
full query succeeds; canonical work ranges from 7 through 356. Empty positive
limits succeed with canonical work zero. Invalid zero work and span caps remain
literal invalid-limit observations. A legal positive one-short output-span cap
exists for 54 parents; 26 record its absence explicitly.

The separate standalone retained-input supplement has six actual factory
setups: one Some and five None. Only Some runs its six actual fade calls
(four successes,two typed errors). It retains distinct prepaid work and wider
history semantics; this is not a Root/Domain admission claim.

Each successful query serializes every FadeQuery/FadeSpan/FadeEdge and origin
field, exact coordinates, ordered identities, policies, lookup and work.
Errors retain their typed variant. Ordinary failed calls expose no accepted
partial-work receipt; no failed work value is inferred.

Both external complete-body regressions passed against this independent
capture before freezing. No expected-derived caps, normalized work, fabricated
spans or production changes created the witness. Raw pretty bodies, complete
source manifests, executable/stream pins and exact one-test commands remain in
the checkpoint evidence. Descriptor names alone do not prove branch execution.
Future admission still owes actual callback, allocation, overlap and host
lifetime evidence. Existing immutable oracle bodies are unchanged.
"""
sha=lambda b:hashlib.sha256(b).hexdigest()
for variant,root in [('main',Path('/Users/michael/Code/deadpan')),('scoped',Path('/tmp/deadpan-query-groundwork-2026-10-26/scoped'))]:
 receipt=json.loads((s/('fade-old-'+variant+'-external-regression.json')).read_text())
 assert receipt['exit_code']==0 and receipt['sources_unchanged'] and receipt['binaries_unchanged']
 before=(root/source).read_text();assert 'fn ordinary_fades_match_frozen_old_capture_v1()'not in before
 dest=root/fixture;assert not dest.exists();dest.mkdir(parents=True)
 (dest/'snapshot.json').write_bytes(body)
 (dest/'snapshot.sha256').write_text(digest+'  snapshot.json\n')
 (dest/'README.md').write_text(readme)
 (s/(variant+'-before-frozen-producer.rs')).write_text(before)
 (root/source).write_text(before+test)
 names=json.loads((s/(variant+'-logic-source-files.json')).read_text())
 names=sorted(set(names)|{fixture+'/snapshot.json'})
 (s/(variant+'-logic-source-files.json')).write_text(json.dumps(names,indent=2)+'\n')
 for pin in json.loads((s/'immutable-oracle-pins.json').read_text()):
  assert sha((root/pin['path']).read_bytes())==pin['sha256']
pins=json.loads((s/'immutable-oracle-pins.json').read_text())
pins.append({'path':fixture+'/snapshot.json','bytes':len(body),'sha256':digest})
(s/'immutable-oracle-pins.json').write_text(json.dumps(pins,indent=2)+'\n')
(s/'owned-baseline-paths.json').write_text(json.dumps(paths+[fixture+'/snapshot.json',fixture+'/snapshot.sha256',fixture+'/README.md'],indent=2)+'\n')
print('Frozen17th literal oracle; added ordinary complete-body regression in both roots.')
