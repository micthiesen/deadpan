# Plan fade test-contract review

Reviewed the parent-written candidate against `admission-design.md`, the captured 80-parent / 2,354-call corpus, and the existing `Policy` test double. This is a static review only; the candidate has rustfmt output but was not compiled.

## Findings

1. **Minor — `fade_query_admission_tests.rs:229-231`.** The one-byte-under-peak case accepts any error. A wrong early error (including a constructor regression unrelated to memory admission) therefore satisfies the boundary test. Assert the exact injected allocation-refusal error and the expected accepted forwarded-work prefix / reservation count, while confirming all leases are released.

2. **Minor — `fade_query_admission_tests.rs:276-295`.** The separately constructed `start..start` request uses positive limits and checks zero reported units and live bytes, but never checks `work_calls`, `reservations`, or `forwarded`. A zero-sized reservation or `spend(0)` can pass. Assert all four counters are zero for this exact request; the captured `default_empty` check does not make the generated positive-limit request's callback behavior explicit.

3. **Minor — `fade_query_admission_tests.rs:300-324`.** The outlives-admission check validates only `query.spans` after the admission value leaves scope. Compare the complete query snapshot and the carrier's work/canonical/additional/forwarded receipt there, so a lifetime bug affecting lookup metadata or accounting cannot hide behind intact spans.

4. **Minor — `fade_query_admission_tests.rs:335-359, 395-455`.** The observer records `spend` and successful `reserve` only. `merge` is forwarded without an event count or issuer-rotation injection, so these tests do not establish the post-merge issuer check called out in the design. Add a merge rotation case or explicitly leave merge-rotation coverage to the later actual branch/overlap hook tests; do not describe this suite as exercising every admission callback's rotation path.

## Checks that do line up

- The false-mode loop walks all 80 Root/Domain parents and all 2,354 observations, compares every success/error with the frozen output, and asserts no spend, reservation, forwarding, or live charge.
- The true-mode defaults select exactly `default_full`, `default_clipped`, and `default_empty` for each parent (240 calls); the corpus confirms all succeed and clipped rows are nonempty. Query snapshot shape is asserted as three fields, with spans, lookup, and work checked; canonical work is compared with OLD, total equals canonical plus additional, and the test policy's forwarded total equals work.
- The exact-work/exact-peak cases use each parent's observed full-call work and requested-Layout peak. One-short work asserts the structural-work error, an accepted partial work prefix, and cleanup.
- The pre-callback loop selects the 960 invalid-limit/range errors and checks both exact error parity and zero callback/lease state. It also asserts exact zero work for its explicit positive-limit empty range, subject to finding 2.
- The full-query lifetime test visits all 80 parents. The focused refusal/cancellation/rotation test resolves six named cases, tests every observed spend and reservation index, and checks accepted work and lease cleanup. It intentionally does not replace the separately owed branch/overlap tests.

No source edits or Cargo runs were performed.
