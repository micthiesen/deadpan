from pathlib import Path
import json,os,subprocess,hashlib
s=Path(__file__).resolve().parent
reused=[]
for variant in ['scoped','main']:
 build='fade-qualified-revised-'+variant+'-build'
 pins=json.loads((s/(build+'-pins.json')).read_text())
 old={row['name']:row for row in json.loads((s/('fade-qualified-final-'+variant+'-build-pins.json')).read_text())}
 names={row['name']for row in pins};assert len(names)==21
 order=['deadpan_audio']+sorted(names-{'deadpan_audio','stages','audio_definition'})+['stages','audio_definition']
 for target in order:
  prior=s/('fade-final-'+variant+'-audio-'+target.replace('_','-')+'.json')
  current=next(p for p in pins if p['name']==target)
  if prior.exists():
   receipt=json.loads(prior.read_text())
   if receipt.get('exit_code')==0 and current['sha256']==old[target]['sha256']:
    assert receipt['sources_unchanged']and receipt['binaries_unchanged']
    reused.append({'variant':variant,'target':target,'receipt':prior.name,'binary_sha256':current['sha256'],'reason':'unchanged executable; only independent sound_events integration source changed'})
    print('Reused unchanged passing executable',variant,target,flush=True)
    continue
  label='fade-revised-'+variant+'-audio-'+target.replace('_','-')
  args=['--test-threads=1']
  if variant=='main'and target=='stages':args=['--skip','general_split_sound::',*args]
  print('Starting',variant,target,flush=True)
  subprocess.run(['python3',str(s/'run_target.py'),build,variant,'audio',target,label,*args],check=True)
 label='fade-current-'+variant
 listed=label+'-list'
 subprocess.run(['python3',str(s/'run_target.py'),build,variant,'audio','deadpan_audio',listed,'--list'],check=True)
 names=[line.removesuffix(': test')for line in(s/(listed+'.stdout')).read_text().splitlines()if line.endswith('::produce_current_cached_prediction_observations: test')]
 assert len(names)==1,names
 output=s/('fade-current-body-'+variant+'.json');assert not output.exists()
 env=os.environ.copy();env['DEADPAN_CACHED_PREDICTION_CURRENT']=str(output)
 subprocess.run(['python3',str(s/'run_target.py'),build,variant,'audio','deadpan_audio',label,'--ignored','--exact',names[0],'--nocapture','--test-threads=1'],env=env,check=True)
 assert 'test result: ok. 1 passed;'in(s/(label+'.stdout')).read_text()
(s/'reused-native-receipts.json').write_text(json.dumps(reused,indent=2)+'\n')
print('Starting separate inherited General Split audit',flush=True)
code=subprocess.run(['python3',str(s/'run_target.py'),'fade-qualified-revised-main-build','main','audio','stages','fade-final-fresh-split','general_split_sound::','--nocapture','--test-threads=1']).returncode
print('General Split exit',code,flush=True)
raise SystemExit(code)
