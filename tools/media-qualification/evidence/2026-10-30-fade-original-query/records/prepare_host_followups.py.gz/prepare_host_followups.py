from pathlib import Path
import json,hashlib,re
s=Path(__file__).resolve().parent;root=Path('/Users/michael/Code/deadpan');c=s/'host-followups-candidate'
paths=['crates/deadpan-audio/src/original_request/policy_reuse_tests.rs','crates/deadpan-audio/src/original_request/processing_policy_admission_tests.rs','crates/deadpan-audio/src/original_request/flattened_admission_tests.rs','crates/deadpan-audio/src/shared_eq/prepared_input_tests.rs']
before={}
for name in paths:
 p=c/'before'/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes((root/name).read_bytes());before[name]=p.read_text()
after={}
name=paths[0];text=before[name]
anchor='    super::with_legacy_policy_queries(|| super::with_legacy_processing_queries(action))'
assert text.count(anchor)==1
text=text.replace(anchor,'    super::with_legacy_fade_queries(|| super::with_legacy_policy_queries(|| super::with_legacy_processing_queries(action)))')
after[name]=text
for name,count in [(paths[1],1),(paths[2],5)]:
 text,n=re.subn(r'#\[test\]\nfn ([a-zA-Z_0-9]+)\(\) \{',lambda m:'#[test]\nfn '+m[1]+'() {\n    with_legacy_fade_queries(historical_'+m[1]+');\n}\n\nfn historical_'+m[1]+'() {',before[name])
 assert n==count,(name,n)
 after[name]=text
name=paths[3];text=before[name]
anchor='use super::*;\n'
assert text.count(anchor)==1
helper='''
fn prepared_query_receipts() -> [serde_json::Value; 4] {
    use crate::stages::original_request::flattened_work_trace as trace;
    [trace::snapshot(), trace::processing_snapshot(), trace::policy_snapshot(), trace::fade_snapshot()]
        .map(|value| serde_json::to_value(value).unwrap())
}
'''
text=text.replace(anchor,anchor+helper,1)
anchor='    let before_legacy = work.borrow().plan_work;\n'
assert text.count(anchor)==1
text=text.replace(anchor,anchor+'    let before_early_receipts = prepared_query_receipts();\n',1)
anchor='    let hit_work = work.borrow().plan_work - before_legacy;\n'
assert text.count(anchor)==1
text=text.replace(anchor,'    assert_eq!(prepared_query_receipts(), before_early_receipts, "an early warm cache hit builds and compares none of the four query carriers");\n'+anchor,1)
anchor='    let before_hit = work.borrow().plan_work;\n'
assert text.count(anchor)==1
text=text.replace(anchor,anchor+'    let before_hit_receipts = prepared_query_receipts();\n',1)
anchor='''        hit_work + 1 + 3,
        "the hit bills sealed request validation and all three actual issuer comparisons once each"'''
assert text.count(anchor)==1
text=text.replace(anchor,'''        hit_work + 1 + 4,
        "the hit bills sealed request validation and all four actual issuer comparisons once each"''',1)
anchor='''    assert!(provider.calls > calls);
'''
assert text.count(anchor)==1
proof='''    let after_hit_receipts = prepared_query_receipts();
    for (before, after) in before_hit_receipts.iter().zip(&after_hit_receipts) {
        for lane in ["plan", "cache"] {
            let increase = if lane == "plan" { 1 } else { 0 };
            for field in ["issuer_checks", "issuer_work"] {
                assert_eq!(after[lane][field].as_u64().unwrap(), before[lane][field].as_u64().unwrap() + increase);
            }
            for field in ["constructor_calls", "completed_queries", "failed_queries", "accepted_work"] {
                assert_eq!(after[lane][field], before[lane][field], "late hit retains its supplied carrier without reconstruction: {field}");
            }
        }
    }
'''
text=text.replace(anchor,anchor+proof,1)
after[name]=text
for name,text in after.items():
 p=c/'after'/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(text)
print('Prepared explicit old-phase fade modes and actual four-product early/late cache receipts.')
