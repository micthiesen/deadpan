use super::*;

use deadpan_core::{
    AssetId, AssetRecord, AudioBindingState, AudioEdgePolicy, AudioSample, AudioTimingId,
    AudioTimingRecord, BeatNode, BeatSound, ColorPolicy, FrameDuration, FrameRate,
    FrozenAudioLayout, HoldAudio, HoldRecipe, HoldVideo, NodeId, PresentationBasis,
    ProjectDocument, ProjectId, RevisionId, SoundClockJournal, SoundClockReference, SoundId,
    SoundOverflowPolicy, SourceAudio, SourceAudioMapping, SourceQualificationId, SourceSpan,
    SourceTimeBase, SourceTimestamp,
};
use std::{
    cell::RefCell,
    sync::Arc,
    sync::atomic::AtomicBool,
    time::{Duration, Instant},
};

fn id(value: &str) -> NodeId {
    NodeId::new(value).unwrap()
}

fn revision(value: &str) -> RevisionId {
    RevisionId::new(value).unwrap()
}

fn source_span() -> SourceSpan {
    let time_base = SourceTimeBase::new(1, 48_000).unwrap();
    SourceSpan::new(
        SourceTimestamp {
            ticks: 10,
            time_base,
        },
        SourceTimestamp {
            ticks: 4_810,
            time_base,
        },
    )
    .unwrap()
}

fn asset(label: &str) -> AssetRecord {
    AssetRecord {
        label: label.into(),
        content_hash: "a".repeat(64),
        video: None,
        audio: Some(source_span()),
        still_image: false,
        frame_count: None,
        source_qualification: Some(SourceQualificationId::new("b".repeat(64)).unwrap()),
    }
}

fn beat_sound(label: &str, asset: &str) -> BeatSound {
    let source = SourceAudio {
        asset: AssetId::new(asset).unwrap(),
        span: source_span(),
    };
    BeatSound {
        label: label.into(),
        mapping: SourceAudioMapping::natural_rate(
            source.span,
            FrameRate::new(30_000, 1_001).unwrap(),
        )
        .unwrap(),
        source,
        offset: AudioSample(0),
        treatments: deadpan_core::AudioTreatments::default(),
        start_edge: AudioEdgePolicy::Automatic,
        end_edge: AudioEdgePolicy::Automatic,
        overflow: SoundOverflowPolicy::Reject,
    }
}

fn document(event_assets: &[&str], clocks_per_event: usize) -> ProjectDocument {
    let rate = FrameRate::new(30_000, 1_001).unwrap();
    let owner = id("owner");
    let root = id("root");
    let document = ProjectDocument::new(
        ProjectId::new("sound-clock-cache").unwrap(),
        revision("live"),
        PresentationBasis {
            width: 16,
            height: 16,
            frame_rate: rate,
            color_policy: ColorPolicy::SdrRec709,
        },
        root.clone(),
    )
    .unwrap();
    let mut wire = serde_json::to_value(&document).unwrap();
    wire["nodes"] = serde_json::to_value(BTreeMap::from([
        (root, BeatNode::sequence("Root", vec![owner.clone()])),
        (
            owner.clone(),
            BeatNode::hold(
                "Owner",
                HoldRecipe {
                    duration: FrameDuration::new(100).unwrap(),
                    video: HoldVideo::Background,
                    picture_context: None,
                    audio: HoldAudio::Silence,
                },
            ),
        ),
    ]))
    .unwrap();
    wire["assets"] = serde_json::to_value(
        event_assets
            .iter()
            .map(|name| (AssetId::new((*name).to_owned()).unwrap(), asset(name)))
            .collect::<BTreeMap<_, _>>(),
    )
    .unwrap();
    wire["beat_sounds"] = serde_json::to_value(BTreeMap::from([(
        owner.clone(),
        event_assets
            .iter()
            .enumerate()
            .map(|(index, asset_name)| {
                let sound = SoundId::new(format!("sound-{index}")).unwrap();
                (sound, beat_sound(&format!("Sound {index}"), asset_name))
            })
            .collect::<BTreeMap<_, _>>(),
    )]))
    .unwrap();
    let document = ProjectDocument::from_json(&wire.to_string()).unwrap();
    let layout = FrozenAudioLayout::capture(&document).unwrap();

    let mut timing_records = Vec::new();
    let mut clocks_by_sound = BTreeMap::new();
    for (event_index, _) in event_assets.iter().enumerate() {
        let sound = SoundId::new(format!("sound-{event_index}")).unwrap();
        let mut clocks = Vec::with_capacity(clocks_per_event);
        for ordinal in 0..clocks_per_event {
            let timing = AudioTimingId {
                allocation: revision(&format!("timing-{event_index}-{ordinal}")),
                ordinal: 0,
            };
            clocks.push(SoundClockReference::new(
                timing.clone(),
                owner.clone(),
                owner.clone(),
            ));
            timing_records.push(AudioTimingRecord {
                id: timing,
                layout: layout.clone(),
            });
        }
        clocks_by_sound.insert(
            sound,
            SoundClockJournal::new(owner.clone(), clocks).unwrap(),
        );
    }
    let bindings = AudioBindingState::new_with_sound_clocks(
        timing_records,
        BTreeMap::new(),
        BTreeMap::new(),
        BTreeMap::from([(owner, clocks_by_sound)]),
    )
    .unwrap();
    let mut wire = serde_json::to_value(document).unwrap();
    wire["audio_bindings"] = serde_json::to_value(bindings).unwrap();
    ProjectDocument::from_json(&wire.to_string()).unwrap()
}

fn control<'a>(cancelled: &'a AtomicBool, work: &'a RefCell<ReadWork>) -> WorkControl<'a> {
    WorkControl {
        cancelled,
        deadline: Instant::now() + Duration::from_secs(5),
        work,
    }
}

fn prepare(
    stage: &mut StageAudio,
    plan: &RenderPlan,
) -> Result<SoundProcessingPlans, StageAudioError> {
    let cancelled = AtomicBool::new(false);
    let work = RefCell::new(ReadWork::default());
    stage.prepare_sound_processing_plans(
        plan,
        AudioSample(0)..AudioSample(1),
        control(&cancelled, &work),
    )
}

#[test]
fn seeking_between_birth_cohorts_replaces_cached_processing_plans() {
    use deadpan_core::{
        Command, CommandRequest, RepeatSelectionIdentities, SliceCaptureSelection, SplitIdentities,
    };
    fn apply_edit(document: &ProjectDocument, name: &str, command: Command) -> ProjectDocument {
        let edit = deadpan_core::apply(
            document,
            &CommandRequest {
                project_id: document.project_id().clone(),
                expected_revision: document.revision_id().clone(),
                new_revision: revision(name),
                command,
            },
        )
        .unwrap();
        edit.forward.apply(document).unwrap()
    }
    let clock = |name| AudioTimingId {
        allocation: revision(name),
        ordinal: 0,
    };
    let original = document(&["asset-a"], 1);
    let mut current = apply_edit(
        &original,
        "wrapped",
        Command::RepeatSelection {
            parent: id("root"),
            selection: SliceCaptureSelection::Child { node: id("owner") },
            plays: 2,
            identities: RepeatSelectionIdentities {
                repeat: id("repeat"),
                group: None,
                split: SplitIdentities::default(),
            },
            timing: clock("wrapped"),
        },
    );
    for (name, plays) in [("three", 3), ("four", 4), ("five", 5)] {
        current = apply_edit(
            &current,
            name,
            Command::SetRepeatPlays {
                node: id("repeat"),
                plays,
                timing: clock(name),
            },
        );
    }
    let plan = RenderPlan::compile(&current).unwrap();
    let mut stage = StageAudio::new(Arc::new(plan.clone()));
    let cancelled = AtomicBool::new(false);
    // Third and fourth plays first existed at different retained captures.
    for (sample, expected) in [
        (320_320, Some(clock("four"))),
        (480_480, Some(clock("five"))),
        (640_640, None),
    ] {
        let work = RefCell::new(ReadWork::default());
        let prepared = stage
            .prepare_sound_processing_plans(
                &plan,
                AudioSample(sample)..AudioSample(sample + 1),
                control(&cancelled, &work),
            )
            .unwrap();
        assert_eq!(
            prepared.keys().cloned().collect::<Vec<_>>(),
            expected.into_iter().collect::<Vec<_>>()
        );
        assert_eq!(stage.sound_processing_plans.len(), prepared.len());
    }
}

#[test]
fn one_sound_reuses_its_first_clock_plan_for_long_journal_and_retry() {
    let document = document(&["asset-a"], 80);
    let plan = RenderPlan::compile(&document).unwrap();
    let mut stage = StageAudio::new(Arc::new(plan.clone()));

    let prepared = prepare(&mut stage, &plan).unwrap();
    assert_eq!(prepared.len(), 1);
    assert_eq!(stage.sound_processing_plans.len(), 1);
    let first = prepared.values().next().unwrap();
    assert_eq!(first.audio_context_assets().unwrap().len(), 1);
    assert!(
        first
            .audio_context_assets()
            .unwrap()
            .contains_key(&AssetId::new("asset-a").unwrap())
    );

    let repeated = prepare(&mut stage, &plan).unwrap();
    assert_eq!(repeated.len(), 1);
    assert_eq!(stage.sound_processing_plans.len(), 1);
    assert!(Arc::ptr_eq(repeated.values().next().unwrap(), first));

    let mut limited_stage = StageAudio::new(Arc::new(plan.clone()));
    let cancelled = AtomicBool::new(false);
    let limited_work = RefCell::new(ReadWork {
        plan_work: MAX_PLAN_WORK_PER_READ - 1,
        ..Default::default()
    });
    assert!(matches!(
        limited_stage.prepare_sound_processing_plans(
            &plan,
            AudioSample(0)..AudioSample(1),
            control(&cancelled, &limited_work)
        ),
        Err(StageAudioError::Limit("plan work per read"))
    ));
    assert!(limited_stage.sound_processing_plans.is_empty());

    assert_eq!(prepare(&mut limited_stage, &plan).unwrap().len(), 1);
    assert_eq!(limited_stage.sound_processing_plans.len(), 1);
}

#[test]
fn empty_current_support_does_not_retrieve_a_long_sound_clock_journal() {
    const CLOCKS: usize = 80;
    let original = document(&["asset-a"], CLOCKS);
    let mut wire = serde_json::to_value(original).unwrap();
    wire["nodes"]["prefix"] = serde_json::to_value(BeatNode::hold(
        "Unrelated silent prefix",
        HoldRecipe {
            duration: FrameDuration::new(1).unwrap(),
            video: HoldVideo::Background,
            picture_context: None,
            audio: HoldAudio::Silence,
        },
    ))
    .unwrap();
    wire["nodes"]["root"]["kind"]["children"] = serde_json::json!(["prefix", "owner"]);
    let document = ProjectDocument::from_json(&wire.to_string()).unwrap();
    let plan = RenderPlan::compile(&document).unwrap();
    let event = &plan.beat_sounds()[&id("owner")][&SoundId::new("sound-0").unwrap()];
    let cancelled = AtomicBool::new(false);
    let probe = RefCell::new(ReadWork::default());
    let batch = current_occurrence_supports(
        &plan,
        None,
        &id("owner"),
        event,
        AudioSample(0)..AudioSample(1),
        CLOCKS,
        control(&cancelled, &probe),
    )
    .unwrap();
    assert!(batch.supports().is_empty());
    // The clock count is a single lookup. Its immutable asset inventory was
    // built with the plan, not reconstructed from all 80 clocks on this read.
    let required = 1 + probe.borrow().plan_work;
    let work = RefCell::new(ReadWork {
        plan_work: MAX_PLAN_WORK_PER_READ - required,
        ..Default::default()
    });
    let mut stage = StageAudio::new(Arc::new(plan.clone()));
    let prepared = stage
        .prepare_sound_processing_plans(
            &plan,
            AudioSample(0)..AudioSample(1),
            control(&cancelled, &work),
        )
        .unwrap();
    assert!(prepared.is_empty());
    assert!(stage.sound_processing_plans.is_empty());
    assert_eq!(work.borrow().plan_work, MAX_PLAN_WORK_PER_READ);

    // The same allowance cannot waive the real occurrence, alias and retained
    // plan work once the sound's current owner actually contributes.
    let work = RefCell::new(ReadWork {
        plan_work: MAX_PLAN_WORK_PER_READ - required,
        ..Default::default()
    });
    assert!(
        stage
            .prepare_sound_processing_plans(
                &plan,
                AudioSample(1602)..AudioSample(1603),
                control(&cancelled, &work),
            )
            .is_err()
    );
    assert!(stage.sound_processing_plans.is_empty());
}

#[test]
fn distinct_first_clocks_keep_each_sound_asset_contract_separate() {
    let document = document(&["asset-a", "asset-b"], 80);
    let plan = RenderPlan::compile(&document).unwrap();
    let mut stage = StageAudio::new(Arc::new(plan.clone()));
    let prepared = prepare(&mut stage, &plan).unwrap();

    assert_eq!(prepared.len(), 2);
    assert_eq!(stage.sound_processing_plans.len(), 2);
    let retained: Vec<_> = stage.sound_processing_plans.iter().collect();
    assert_ne!(retained[0].0, retained[1].0);
    for (_, plan) in retained {
        let assets = plan.audio_context_assets().unwrap();
        assert_eq!(assets.len(), 1);
        assert!(
            assets.contains_key(&AssetId::new("asset-a").unwrap())
                || assets.contains_key(&AssetId::new("asset-b").unwrap())
        );
    }
    assert_eq!(
        stage
            .sound_processing_plans
            .values()
            .map(|plan| plan
                .audio_context_assets()
                .unwrap()
                .keys()
                .next()
                .unwrap()
                .clone())
            .collect::<BTreeSet<_>>(),
        BTreeSet::from([
            AssetId::new("asset-a").unwrap(),
            AssetId::new("asset-b").unwrap()
        ])
    );
    for (index, asset_name) in ["asset-a", "asset-b"].iter().enumerate() {
        let sound = SoundId::new(format!("sound-{index}")).unwrap();
        let clocks = plan.beat_sound_clock_layouts(&id("owner"), &sound).unwrap();
        let (first_clock, _) = clocks.first().unwrap();
        let retained = &prepared[*first_clock];
        assert_eq!(
            retained
                .audio_context_assets()
                .unwrap()
                .keys()
                .cloned()
                .collect::<BTreeSet<_>>(),
            BTreeSet::from([AssetId::new((*asset_name).to_owned()).unwrap()]),
        );
    }
}

#[test]
fn shared_first_clock_retains_every_event_asset_across_cached_reads() {
    let original = document(&["asset-b", "asset-a", "asset-b"], 3);
    let state = original.audio_bindings();
    let first = state.sound_clocks()[&id("owner")][&SoundId::new("sound-0").unwrap()].clone();
    let clocks = first
        .clocks()
        .iter()
        .map(|reference| AudioTimingRecord {
            id: reference.timing().clone(),
            layout: state.timings()[reference.timing()].clone(),
        })
        .collect();
    let bindings = AudioBindingState::new_with_sound_clocks(
        clocks,
        BTreeMap::new(),
        BTreeMap::new(),
        BTreeMap::from([(
            id("owner"),
            (0..3)
                .map(|index| {
                    (
                        SoundId::new(format!("sound-{index}")).unwrap(),
                        first.clone(),
                    )
                })
                .collect(),
        )]),
    )
    .unwrap();
    let mut wire = serde_json::to_value(original).unwrap();
    wire["audio_bindings"] = serde_json::to_value(bindings).unwrap();
    let document = ProjectDocument::from_json(&wire.to_string()).unwrap();
    let plan = RenderPlan::compile(&document).unwrap();
    let mut stage = StageAudio::new(Arc::new(plan.clone()));
    let prepared = prepare(&mut stage, &plan).unwrap();
    assert_eq!(prepared.len(), 1);
    let retained = prepared.values().next().unwrap();
    assert_eq!(
        retained
            .audio_context_assets()
            .unwrap()
            .keys()
            .cloned()
            .collect::<Vec<_>>(),
        vec![
            AssetId::new("asset-a").unwrap(),
            AssetId::new("asset-b").unwrap()
        ]
    );
    let repeated = prepare(&mut stage, &plan).unwrap();
    assert!(Arc::ptr_eq(retained, repeated.values().next().unwrap()));
}

#[test]
fn clock_discovery_keeps_exact_full_batch_paths_and_scoped_halos() {
    let document = document(&["asset-a"], 3);
    let plan = RenderPlan::compile(&document).unwrap();
    let event = &plan.beat_sounds()[&id("owner")][&SoundId::new("sound-0").unwrap()];
    let cancelled = AtomicBool::new(false);
    let work = RefCell::new(ReadWork::default());
    let context = plan
        .audio_sound_instance_context(
            &deadpan_core::InstancePath {
                node: id("owner"),
                repeats: Vec::new(),
            },
            control(&cancelled, &work).query_limits().unwrap(),
        )
        .unwrap();
    for context in [None, Some(&context)] {
        for (start, end) in [(0, 1), (1, 1601), (1601, 1602), (160_157, 160_160)] {
            let full_work = RefCell::new(ReadWork::default());
            let full = current_occurrences(
                &plan,
                context,
                &id("owner"),
                event,
                AudioSample(start)..AudioSample(end),
                3,
                control(&cancelled, &full_work),
            )
            .unwrap();
            let support_work = RefCell::new(ReadWork::default());
            let supports = current_occurrence_supports(
                &plan,
                context,
                &id("owner"),
                event,
                AudioSample(start)..AudioSample(end),
                3,
                control(&cancelled, &support_work),
            )
            .unwrap();
            assert_eq!(
                supports
                    .supports()
                    .iter()
                    .map(|voice| (voice.instance(), voice.samples()))
                    .collect::<Vec<_>>(),
                full.voices()
                    .iter()
                    .map(|voice| (voice.instance(), voice.samples()))
                    .collect::<Vec<_>>(),
            );
            assert!(support_work.borrow().plan_work < full_work.borrow().plan_work);
        }
    }
    let foreign = RenderPlan::compile(&document).unwrap();
    assert!(matches!(
        current_occurrence_supports(
            &foreign,
            Some(&context),
            &id("owner"),
            event,
            AudioSample(0)..AudioSample(1),
            3,
            control(&cancelled, &work),
        ),
        Err(StageAudioError::ForeignDomain)
    ));
}

#[test]
fn placement_cursor_checks_cancellation_and_aggregate_work_between_steps() {
    let document = document(&["asset-a"], 2);
    let plan = RenderPlan::compile(&document).unwrap();
    let scopes = plan
        .beat_sound_clock_scopes(&id("owner"), &SoundId::new("sound-0").unwrap(), 65_536)
        .unwrap();
    let historical = plan
        .compile_sound_processing_layout(
            scopes[0].historical_layout(),
            &BTreeSet::from([AssetId::new("asset-a").unwrap()]),
        )
        .unwrap();
    let event = &document.beat_sounds()[&id("owner")][&SoundId::new("sound-0").unwrap()];
    let recipe = AudioSourceVoiceRecipe {
        source: event.source.clone(),
        mapping: event.mapping,
        offset: event.offset,
    };
    let instance = deadpan_core::InstancePath {
        node: id("owner"),
        repeats: Vec::new(),
    };
    let original = historical
        .source_voice_occurrence(instance.clone(), recipe.clone(), Default::default())
        .unwrap();
    let current = plan
        .source_voice_occurrence(instance, recipe, Default::default())
        .unwrap();
    let cancelled = AtomicBool::new(false);
    let work = RefCell::new(ReadWork::default());
    let control = control(&cancelled, &work);
    let mut cursor = current
        .placement_history_cursor(&original, &scopes, None)
        .unwrap();
    let used = cursor
        .advance(control.query_limits().unwrap().maximum_work)
        .unwrap();
    control.spend_plan_work(used).unwrap();
    let used = cursor
        .advance(control.query_limits().unwrap().maximum_work)
        .unwrap();
    control.spend_plan_work(used).unwrap();
    let before = work.borrow().plan_work;
    cancelled.store(true, std::sync::atomic::Ordering::Relaxed);
    assert!(matches!(
        control.query_limits(),
        Err(StageAudioError::Preparation(PreparationError::Cancelled))
    ));
    assert_eq!(work.borrow().plan_work, before);
    assert!(cursor.finish().is_err());
    cancelled.store(false, std::sync::atomic::Ordering::Relaxed);
    work.borrow_mut().plan_work = MAX_PLAN_WORK_PER_READ - 6;
    let mut cursor = current
        .placement_history_cursor(&original, &scopes, None)
        .unwrap();
    assert_eq!(control.query_limits().unwrap().maximum_work, 6);
    let used = cursor.advance(6).unwrap();
    control.spend_plan_work(used).unwrap();
    assert!(matches!(
        control.query_limits(),
        Err(StageAudioError::Limit("plan work per read"))
    ));
    assert!(cursor.finish().is_err());
}
