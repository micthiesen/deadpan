from pathlib import Path
import json,os,subprocess
s=Path(__file__).resolve().parent
for variant in ['scoped','main']:
 build='fade-qualified-final-'+variant+'-build'
 pins=json.loads((s/(build+'-pins.json')).read_text())
 names={row['name']for row in pins}
 assert len(names)==21
 order=['deadpan_audio']+sorted(names-{'deadpan_audio','stages','audio_definition'})+['stages','audio_definition']
 for target in order:
  label='fade-final-'+variant+'-audio-'+target.replace('_','-')
  args=['--test-threads=1']
  if variant=='main'and target=='stages':args=['--skip','general_split_sound::',*args]
  print('Starting',variant,target,flush=True)
  result=subprocess.run(['python',str(s/'run_target.py'),build,variant,'audio',target,label,*args])
  if result.returncode:raise SystemExit(result.returncode)
 label='fade-current-'+variant
 listed=label+'-list'
 subprocess.run(['python',str(s/'run_target.py'),build,variant,'audio','deadpan_audio',listed,'--list'],check=True)
 names=[line.removesuffix(': test')for line in(s/(listed+'.stdout')).read_text().splitlines()if line.endswith('::produce_current_cached_prediction_observations: test')]
 assert len(names)==1,names
 output=s/('fade-current-body-'+variant+'.json');assert not output.exists()
 env=os.environ.copy();env['DEADPAN_CACHED_PREDICTION_CURRENT']=str(output)
 subprocess.run(['python',str(s/'run_target.py'),build,variant,'audio','deadpan_audio',label,'--ignored','--exact',names[0],'--nocapture','--test-threads=1'],env=env,check=True)
 assert 'test result: ok. 1 passed;'in(s/(label+'.stdout')).read_text()
print('Starting separate inherited General Split audit',flush=True)
code=subprocess.run(['python',str(s/'run_target.py'),'fade-qualified-final-main-build','main','audio','stages','fade-final-fresh-split','general_split_sound::','--nocapture','--test-threads=1']).returncode
print('General Split exit',code,flush=True)
raise SystemExit(code)
