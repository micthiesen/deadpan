from pathlib import Path
s=Path(__file__).resolve().parent
edits={
'crates/deadpan-plan/src/audio_fades_query.rs':[
('''    if index.is_some() {
        trace::observe(trace::Event::lengths(
            trace::Phase::OriginMergeAfter,
            side(&value, start)[index.expect("coincident edge")]
                .origins
                .len(),''','''    if let Some(index) = index {
        trace::observe(trace::Event::lengths(
            trace::Phase::OriginMergeAfter,
            side(&value, start)[index].origins.len(),''')],
'crates/deadpan-plan/src/audio_owners/fade_query_admission_tests.rs':[
('            drop(rotating);\n','')],
'crates/deadpan-plan/src/audio_owners/fade_query_resource_tests.rs':[
('''        if event.phase == Phase::InitialEndBefore && !active.armed {
            if let Some(fault) = active.fault {
                active.armed = true;
                let mut state = active.state.borrow_mut();
                let index = state.reservations + 1;
                match fault {
                    Fault::RefuseEnd => state.refuse_reservation = Some(index),
                    Fault::RotateEnd => state.rotate_reservation = Some(index),
                }
            }
        }''','''        if event.phase == Phase::InitialEndBefore
            && !active.armed
            && let Some(fault) = active.fault
        {
            active.armed = true;
            let mut state = active.state.borrow_mut();
            let index = state.reservations + 1;
            match fault {
                Fault::RefuseEnd => state.refuse_reservation = Some(index),
                Fault::RotateEnd => state.rotate_reservation = Some(index),
            }
        }''')]
}
for variant,root in [('main',Path('/Users/michael/Code/deadpan')),('scoped',Path('/tmp/deadpan-query-groundwork-2026-10-26/scoped'))]:
 for name,changes in edits.items():
  p=root/name;text=p.read_text();saved=s/'lint-fix-before'/variant/name;saved.parent.mkdir(parents=True,exist_ok=True);saved.write_text(text)
  for before,after in changes:
   assert text.count(before)==1,(variant,name,before)
   text=text.replace(before,after,1)
  p.write_text(text)
 name='crates/deadpan-audio/src/shared_eq/processing_eviction_trace_tests.rs';p=root/name;text=p.read_text()
 saved=s/'second-eviction-fixture-before'/variant/name;saved.parent.mkdir(parents=True,exist_ok=True);saved.write_text(text)
 text=text.replace('eviction_receipts(256, false)','eviction_receipts(1, false)').replace('eviction_receipts(512, true)','eviction_receipts(2, true)').replace('with_larger_real_cached_wav_input','with_multiple_real_cached_wav_inputs').replace('cached_input_frames: i64','cached_inputs: usize')
 before='''            let cached = renderer
                .shared_original_input(
                    &mut provider,
                    &mut graph,
                    &Context::Root,
                    AudioSample(0)..AudioSample(cached_input_frames),
                    control,
                    0,
                )
                .unwrap();
            let original_inputs::Read::Cached(cached) = cached else {
                panic!("real cold read must publish the verified WAV cache payload");
            };
            drop(cached); // Leave the controller's single Arc evictable.
            assert_eq!(renderer.original_inputs.len(), 1);'''
 after='''            for index in 0..cached_inputs {
                let start = i64::try_from(index).unwrap() * 256;
                let cached = renderer
                    .shared_original_input(
                        &mut provider,
                        &mut graph,
                        &Context::Root,
                        AudioSample(start)..AudioSample(start + 256),
                        control,
                        0,
                    )
                    .unwrap();
                let original_inputs::Read::Cached(cached) = cached else {
                    panic!("real cold read must publish the verified WAV cache payload");
                };
                drop(cached); // Leave the controller's cache Arcs evictable.
            }
            assert_eq!(renderer.original_inputs.len(), cached_inputs);'''
 assert text.count(before)==1
 text=text.replace(before,after,1)
 before='''            assert!(
                renderer.original_inputs.is_empty(),
                "actual existing cache payload was evicted"
            );'''
 after='''            let remaining = usize::from(admitted_fades && processing_eviction);
            assert_eq!(renderer.original_inputs.len(), remaining);
            let evicted = cached_inputs - remaining;'''
 assert text.count(before)==1
 text=text.replace(before,after,1)
 replacements=[
 ('trace["all_host_eviction_work"][usize::from(cache_lane)], 1','trace["all_host_eviction_work"][usize::from(cache_lane)], evicted'),
 ('selected[lane]["host_eviction_work"], 1','selected[lane]["host_eviction_work"], evicted'),
 ('constructor_and_policy + 1','constructor_and_policy + evicted')]
 for before,after in replacements:
  assert text.count(before)==1,(before,text.count(before))
  text=text.replace(before,after,1)
 p.write_text(text)
print('Resolved three lint findings; preserved one-cache historical proof and added two-cache four-product case.')
