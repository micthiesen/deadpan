from pathlib import Path
import hashlib,json,difflib
s=Path(__file__).resolve().parent
candidates=[s/'host-candidate',s/'host-followups-candidate',s/'native-proofs-candidate']
roots={'main':Path('/Users/michael/Code/deadpan'),'scoped':Path('/tmp/deadpan-query-groundwork-2026-10-26/scoped')}
planned={}
for c in candidates:
 afters=sorted((c/'after').rglob('*.rs'))
 for p in afters:
  rel=str(p.relative_to(c/'after'));assert rel not in planned
  before=c/'before'/rel
  planned[rel]=(before.read_bytes()if before.exists()else None,p.read_bytes(),str(c.name))
rows={}
for variant,root in roots.items():
 for rel,(before,after,owner) in planned.items():
  path=root/rel
  if before is None:assert not path.exists(),(variant,rel)
  else:
   assert path.read_bytes()==before,(variant,rel,'concurrent source changed')
   saved=s/'host-integration-before'/variant/rel;saved.parent.mkdir(parents=True,exist_ok=True);saved.write_bytes(before)
  path.write_bytes(after)
 doc='crates/deadpan-plan/src/audio_sound_admission.rs'
 before=(root/doc).read_text()
 old='//! flattened, processing and recursive policy queries, including cold Original preparation.\n//! Fade construction peaks remain separate.'
 new='//! flattened, processing, recursive policy and creative fade queries, including cold Original preparation.\n//! Standalone retained-input fade construction remains separate.'
 assert before.count(old)==1
 saved=s/'host-integration-before'/variant/doc;saved.parent.mkdir(parents=True,exist_ok=True);saved.write_text(before)
 (root/doc).write_text(before.replace(old,new,1))
 names=set(json.loads((s/(variant+'-logic-source-files.json')).read_text()))|set(planned)
 (s/(variant+'-logic-source-files.json')).write_text(json.dumps(sorted(names),indent=2)+'\n')
 (s/('source-files.json'if variant=='main'else'scoped-source-files.json')).write_text(json.dumps(sorted(names),indent=2)+'\n')
 rows[variant]={rel:{'owner':owner,'before_sha256':hashlib.sha256(before).hexdigest()if before is not None else None,'after_sha256':hashlib.sha256(after).hexdigest()}for rel,(before,after,owner)in planned.items()}
owned=set(json.loads((s/'owned-plan-paths.json').read_text()))|set(planned)|{doc}
(s/'owned-paths.json').write_text(json.dumps(sorted(owned),indent=2)+'\n')
(s/'host-integrated-pins.json').write_text(json.dumps(rows,indent=2)+'\n')
for label in ['run_qualified.py','run_scoped_qualified.py']:
 (s/label).write_bytes((Path('/tmp/deadpan-policy-query-admission-2026-10-30')/label).read_bytes())
print('Integrated',len(planned),'host/proof files and one scope-comment update; owned paths',len(owned))
