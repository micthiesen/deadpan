import hashlib, json, pathlib, datetime
root = pathlib.Path('/Users/michael/Code/deadpan')
scope = pathlib.Path('/tmp/deadpan-query-groundwork-2026-10-26/scoped')
tmp = pathlib.Path('/tmp/deadpan-fade-query-admission-2026-10-30')
owned = json.loads((tmp/'owned-paths.json').read_text())

def digest(path):
    if not path.is_file(): return None
    return {'bytes': path.stat().st_size, 'sha256': hashlib.sha256(path.read_bytes()).hexdigest()}

pins = {}
pin_mismatches = {}
for label, base, filename in [('main', root, 'main-final-source-pins.json'), ('scoped', scope, 'scoped-final-source-pins.json')]:
    expected = json.loads((tmp/filename).read_text())
    mismatches=[]
    for rel, row in expected.items():
        got=digest(base/rel)
        if got != row: mismatches.append(rel)
    pins[label]={'count':len(expected),'mismatch_paths':mismatches}
    pin_mismatches[label]=mismatches

owned_diffs=[]
for rel in owned:
    a=digest(root/rel); b=digest(scope/rel)
    if a != b: owned_diffs.append({'path':rel,'main':a,'scoped':b})

oracle=json.loads((tmp/'immutable-oracle-pins.json').read_text())
oracle_bad=[]
for row in oracle:
    for label,base in [('main',root),('scoped',scope)]:
        if digest(base/row['path']) != {'bytes':(base/row['path']).stat().st_size if (base/row['path']).is_file() else None,'sha256':row['sha256']}:
            oracle_bad.append({'tree':label,'path':row['path']})

initial={}
for label,base,filename in [('main',root,'main-initial-authority.json'),('scoped',scope,'scoped-initial-authority.json')]:
    rows=json.loads((tmp/filename).read_text())
    changed=[]; missing=[]
    for rel, expected in rows.items():
        if rel in owned: continue
        got=digest(base/rel)
        if got is None: missing.append(rel)
        elif got != expected: changed.append(rel)
    initial[label]={'inventory_paths':len(rows),'owned_intersections_excluded':len(set(rows)&set(owned)), 'unowned_checked':len(rows)-len(set(rows)&set(owned)), 'unowned_mismatches':changed,'unowned_missing':missing}

plan_receipts=[]
total_test_passed=0
for path in sorted(tmp.glob('fade-final-main-plan-*.json')):
    if path.name.endswith('build-pins.json') or path.name.endswith('build.json'): continue
    rec=json.loads(path.read_text())
    stdout_path=next(pathlib.Path(name) for name in rec['streams'] if name.endswith('.stdout'))
    text=stdout_path.read_text(errors='replace')
    line=next((x.strip() for x in text.splitlines() if x.strip().lower().startswith('test result:')), '')
    import re
    m=re.search(r'(\d+) passed;\s*(\d+) failed(?:;\s*(\d+) ignored)?',line)
    passed=int(m.group(1)) if m else None
    failed=int(m.group(2)) if m else None
    ignored=int(m.group(3) or 0) if m else None
    if passed is not None: total_test_passed += passed
    plan_receipts.append({'receipt':path.name,'exit_code':rec['exit_code'],'result_line':line,'all_pass':rec['exit_code']==0 and failed==0 and passed is not None,'source_guard':rec.get('sources_unchanged'),'binary_guard':rec.get('binaries_unchanged')})

strict=[]
for name in ['fade-final-main-strict.json','fade-final-scoped-strict.json']:
    rec=json.loads((tmp/name).read_text())
    strict.append({'receipt':name,'command':rec['command'],'exit_code':rec['exit_code'],'source_paths_before':len(rec['source_before']),'source_paths_after':len(rec['source_after']),'sources_unchanged':rec['sources_unchanged'],'binary_paths_before':len(rec['binary_before']),'binary_paths_after':len(rec['binary_after']),'binaries_unchanged':rec['binaries_unchanged']})

# Docs are checked against Git base on Main; initial source inventories are code-only.
import subprocess
p=subprocess.run(['git','diff','--quiet','7da84fc1b57897bd990a51f575b60f1b903c7318','--','docs'],cwd=root)
doc_files=[str(x.relative_to(root/'docs')) for x in (root/'docs').rglob('*') if x.is_file()]
scope_docs=[str(x.relative_to(scope/'docs')) for x in (scope/'docs').rglob('*') if x.is_file()]
docs={'main_tracked_diff_from_base':p.returncode,'main_files':len(doc_files),'scope_files':len(scope_docs),'state_md_present_main':(root/'docs/STATE.md').exists(),'state_md_present_scoped':(scope/'docs/STATE.md').exists(),'scope_vs_main_file_count_delta':len(scope_docs)-len(doc_files)}

result={'audited_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':{'owned_paths':len(owned),'base':'7da84fc1b57897bd990a51f575b60f1b903c7318','trees':{'main':str(root),'scoped':str(scope)}},'final_source_pins':pins,'owned_main_scoped_differences':owned_diffs,'immutable_oracle':{'pins':len(oracle),'mismatches':oracle_bad},'initial_authority_unowned_retention':initial,'plan_test_receipts':{'count':len(plan_receipts),'all_pass':all(x['all_pass'] and x['source_guard'] and x['binary_guard'] for x in plan_receipts),'total_test_passed':total_test_passed,'items':plan_receipts},'strict_source_guards':{'count':len(strict),'all_pass':all(x['exit_code']==0 and x['sources_unchanged'] and x['binaries_unchanged'] for x in strict),'items':strict},'docs':docs,'runtime_limit':'Parent reported final native scope sound_events integration stopped at 2 passed / 4 failed; this audit predates and excludes any subsequent repair.'}
(tmp/'final-source-audit.json').write_text(json.dumps(result,indent=2)+'\n')

print(json.dumps({k:v for k,v in result.items() if k not in ('plan_test_receipts',)},indent=2))
print('PLAN_RECEIPTS',len(plan_receipts),'TOTAL_PASSED',total_test_passed,'ALL',result['plan_test_receipts']['all_pass'])
