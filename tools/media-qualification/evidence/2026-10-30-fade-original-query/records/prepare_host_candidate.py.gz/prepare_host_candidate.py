from pathlib import Path
import hashlib,json,re,difflib
root=Path('/Users/michael/Code/deadpan')
dest=Path('/tmp/deadpan-fade-query-admission-2026-10-30/host-candidate')
paths=['crates/deadpan-audio/src/original_request.rs','crates/deadpan-audio/src/original_request/flattened_work_trace.rs','crates/deadpan-audio/src/original_request/tests.rs','crates/deadpan-audio/src/original_request/policy_admission_tests.rs','crates/deadpan-audio/src/original_request/processing_admission_tests.rs']
for name in paths:
 for kind in ['before','after']:
  p=dest/kind/name;p.parent.mkdir(parents=True,exist_ok=True);assert not p.exists();p.write_bytes((root/name).read_bytes())
def replace(name,old,new):
 p=dest/'after'/name;s=p.read_text();assert s.count(old)==1,(name,old[:100],s.count(old));p.write_text(s.replace(old,new,1))
name=paths[0]
replace(name,'//! Flattened, processing and policy metadata retain allocation-site charges through the read.\n//! Fades and the captured Domain identity keep their existing borrows.','//! Flattened, processing, policy and conditional fades retain allocation-site charges through the read.\n//! The captured Domain identity keeps its existing borrow.')
replace(name,'use deadpan_plan::{AdmittedAudioPolicyQuery, AdmittedAudioProcessingQuery, AdmittedAudioQuery};','use deadpan_plan::{\n    AdmittedAudioFadeQuery, AdmittedAudioPolicyQuery, AdmittedAudioProcessingQuery,\n    AdmittedAudioQuery,\n};')
marker="struct PreparedQueries<'plan, 'work> {"
fade="""enum Fade<'work> {
    Admitted {
        query: AdmittedAudioFadeQuery<
            sound_context_admission::Issuer<'work>,
            sound_context_admission::Lease<'work>,
        >,
        issuer: sound_context_admission::Issuer<'work>,
    },
    #[cfg(test)]
    Legacy(AudioFadeQuery),
}

impl Fade<'_> {
    fn query(&self) -> &AudioFadeQuery {
        match self {
            Self::Admitted { query, .. } => query.query(),
            #[cfg(test)]
            Self::Legacy(query) => query,
        }
    }

    fn validate_issuer(&self, control: WorkControl<'_>) -> Result<(), StageAudioError> {
        match self {
            Self::Admitted { issuer, .. } => {
                control.spend_plan_work(1)?;
                #[cfg(test)]
                flattened_work_trace::fade_issuer_spent(control);
                if *issuer != sound_context_admission::issuer(control) {
                    return Err(PlanError::AudioMetadataIssuerMismatch.into());
                }
                Ok(())
            }
            #[cfg(test)]
            Self::Legacy(_) => Ok(()),
        }
    }
}

"""
replace(name,marker,fade+marker)
replace(name,'    fades: Option<AudioFadeQuery>,','    fades: Option<Fade<\'work>>,')
replace(name,'            fades: self.queries.fades.as_ref(),','            fades: self.queries.fades.as_ref().map(Fade::query),')
replace(name,'        self.queries.policy.validate_issuer(control)\n','        self.queries.policy.validate_issuer(control)?;\n        if let Some(fades) = &self.queries.fades {\n            fades.validate_issuer(control)?;\n        }\n        Ok(())\n')
replace(name,"""        let fades = if edge_fades {
            let query = plan.audio_fades(start..AudioSample(end), control.query_limits()?)?;
            control.spend_plan_work(query.work)?;
            Some(query)
        } else {
            None
        };""","""        let fades = if edge_fades {
            Some(self.prepare_fades(Origin::Root(plan), start..AudioSample(end), control)?)
        } else {
            None
        };""")
replace(name,"""        let fades = if edge_fades {
            let query = domain.fades(start..end, control.query_limits()?)?;
            control.spend_plan_work(query.work)?;
            Some(query)
        } else {
            None
        };""","""        let fades = if edge_fades {
            Some(self.prepare_fades(Origin::Domain(domain), start..end, control)?)
        } else {
            None
        };""")
helper="""    fn prepare_fades<'work>(
        &mut self,
        origin: Origin<'_, '_>,
        samples: Range<AudioSample>,
        control: WorkControl<'work>,
    ) -> Result<Fade<'work>, StageAudioError> {
        let limits = control.query_limits()?;
        #[cfg(test)]
        if legacy_fade_queries() {
            let query = match origin {
                Origin::Root(plan) => plan.audio_fades(samples, limits)?,
                Origin::Domain(domain) => domain.fades(samples, limits)?,
            };
            control.spend_plan_work(query.work)?;
            return Ok(Fade::Legacy(query));
        }
        let issuer = sound_context_admission::issuer(control);
        #[cfg(test)]
        let mut fade_work_trace = flattened_work_trace::ScopeGuard::new_fade(control);
        let query = {
            let mut admission = sound_context_admission::Admission::new(self, control);
            match origin {
                Origin::Root(plan) => plan.audio_fades_admitted(samples, limits, &mut admission)?,
                Origin::Domain(domain) => domain.fades_admitted(samples, limits, &mut admission)?,
            }
        };
        #[cfg(test)]
        {
            fade_work_trace.completed(
                query.canonical_units(),
                query.additional_units(),
                query.work(),
                query.was_forwarded(),
            );
            drop(fade_work_trace);
        }
        Ok(Fade::Admitted { query, issuer })
    }

"""
replace(name,"    fn prepare_flattened<'work>(\n",helper+"    fn prepare_flattened<'work>(\n")
legacy="""#[cfg(test)]
thread_local! {
    static LEGACY_FADE_QUERIES: std::cell::Cell<bool> = const { std::cell::Cell::new(false) };
}

#[cfg(test)]
fn legacy_fade_queries() -> bool {
    LEGACY_FADE_QUERIES.with(std::cell::Cell::get)
}

/// Keep earlier product proofs on the literal ordinary conditional-fade path.
#[cfg(test)]
pub(super) fn with_legacy_fade_queries<T>(action: impl FnOnce() -> T) -> T {
    struct Restore(bool);
    impl Drop for Restore {
        fn drop(&mut self) {
            LEGACY_FADE_QUERIES.with(|mode| mode.set(self.0));
        }
    }
    let _restore = Restore(LEGACY_FADE_QUERIES.with(|mode| mode.replace(true)));
    action()
}

"""
replace(name,'#[cfg(test)]\nfn legacy_policy_queries() -> bool {',legacy+'#[cfg(test)]\nfn legacy_policy_queries() -> bool {')
replace(name,'/// Select the literal OLD constructors for flattened, processing and policy\n/// queries in one Original preparation.','/// Select the literal OLD constructors for all four products in one Original preparation.')
replace(name,"""    with_legacy_policy_queries(|| {
        with_legacy_processing_queries(|| with_legacy_flattened_queries(action))
    })""","""    with_legacy_fade_queries(|| {
        with_legacy_policy_queries(|| {
            with_legacy_processing_queries(|| with_legacy_flattened_queries(action))
        })
    })""")
name=paths[1]
replace(name,'    Policy,\n','    Policy,\n    Fade,\n')
replace(name,'            Self::Policy => 2,\n','            Self::Policy => 2,\n            Self::Fade => 3,\n')
p=dest/'after'/name;s=p.read_text().replace('Cell<[Snapshot; 3]> = Cell::new([Snapshot::default(); 3])','Cell<[Snapshot; 4]> = Cell::new([Snapshot::default(); 4])').replace('trace.set([Snapshot::default(); 3]);','trace.set([Snapshot::default(); 4]);').replace('for product in [Product::Flattened, Product::Processing, Product::Policy] {','for product in [\n            Product::Flattened,\n            Product::Processing,\n            Product::Policy,\n            Product::Fade,\n        ] {');p.write_text(s)
replace(name,'fn snapshot_product(product: Product) -> Snapshot {','pub(in crate::stages) fn fade_snapshot() -> Snapshot {\n    snapshot_product(Product::Fade)\n}\n\nfn snapshot_product(product: Product) -> Snapshot {')
replace(name,'fn issuer_spent_for(product: Product, control: WorkControl<\'_>) {','pub(super) fn fade_issuer_spent(control: WorkControl<\'_>) {\n    issuer_spent_for(Product::Fade, control);\n}\n\nfn issuer_spent_for(product: Product, control: WorkControl<\'_>) {')
replace(name,'    fn new_product(product: Product, control: WorkControl<\'work>) -> Self {','    pub(super) fn new_fade(control: WorkControl<\'work>) -> Self {\n        Self::new_product(Product::Fade, control)\n    }\n\n    fn new_product(product: Product, control: WorkControl<\'work>) -> Self {')
for name in paths[2:]:
 p=dest/'after'/name;s=p.read_text()
 pattern=r'#\[test\]\nfn ([A-Za-z0-9_]+)\(\) \{'
 def wrap(m):
  ident=m[1]
  return '#[test]\nfn '+ident+'() {\n    with_legacy_fade_queries('+ident+'_legacy_fade);\n}\n\nfn '+ident+'_legacy_fade() {'
 s,n=re.subn(pattern,wrap,s);assert n>0,(name,n);p.write_text(s)
 print(name,'legacy-fade test wrappers',n)
name=paths[2]
replace(name,'#[path = "policy_admission_tests.rs"]\nmod policy_admission;','#[path = "fade_admission_tests.rs"]\nmod fade_admission;\n\n#[path = "policy_admission_tests.rs"]\nmod policy_admission;')
def pin_tree(kind):
 return {str(p.relative_to(dest/kind)):{'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}for p in sorted((dest/kind).rglob('*'))if p.is_file()}
(dest/'before-pins.json').write_text(json.dumps(pin_tree('before'),indent=2)+'\n')
(dest/'after-pins.json').write_text(json.dumps(pin_tree('after'),indent=2)+'\n')
print('Prepared scratch host source and prior-phase test isolation.')
