from pathlib import Path
import json,os,subprocess,sys
s=Path(__file__).resolve().parent
variant=sys.argv[1];build='fade-old-'+variant+'-build';label='fade-old-'+variant+'-external-regression'
listing=(s/('fade-old-'+variant+'-list.stdout')).read_text()
names=[line.removesuffix(': test')for line in listing.splitlines()if line.endswith('::ordinary_fades_match_explicit_external_old_capture_v1: test')]
assert len(names)==1,names
env=os.environ.copy();env['DEADPAN_FADE_QUERY_EXPECTED']=str(s/'fade-old-canonical-body.json')
code=subprocess.run(['python',str(s/'run_logic_target.py'),build,variant,'plan','deadpan_plan',label,'--ignored','--exact',names[0],'--test-threads=1'],env=env).returncode
assert code==0,code
assert 'test result: ok. 1 passed;'in(s/(label+'.stdout')).read_text()
