# Host candidate review: conditional admitted Fade product

## Findings

None in the scoped host candidate. Static review of `host.patch` against the current `original_request.rs`, the documented admitted-fade API, and the existing `WorkControl` / trace conventions found no concrete lifetime, fee-order, optional-path, or cleanup defect.

The candidate keeps the optional Fade carrier inside `PreparedQueries`; its borrowed accessor presents the same `AudioFadeQuery` to numerical readers. `prepare_fades` is reached only when `edge_fades` is true, and its admitted branch forwards through `Admission` without a second successful-work debit. The legacy constructor and debit exist only under `cfg(test)`. The saved issuer is checked after the earlier three issuers, before `read_queries_borrowed`, so a foreign fourth carrier is rejected before source/read I/O while preserving the intended comparison billing. Existing root/domain/range checks remain before query preparation. The fade carrier lives until the existing request-drop boundary after the numerical read, and ordinary error returns drop the request and its leases.

The six new tests are attached through the test-only path module and exercise Root and Domain, fade enabled and disabled, real WAV parity, live leases during provider failure/cancellation, foreign-carrier refusal, one-short constructor failure, exact four-issuer read boundary, and releasing only Fade to restore actual resident-frame room. The older three-product proof wrappers use the independent legacy-fade mode, avoiding accidental changes to their historical budgets.

## Limits

This is a static review of an unapplied scratch patch. No Cargo/native tests or compiler run was performed, and the admitted Plan constructors are not yet integrated in the candidate under review. The candidate README also lists additional parent-owned test paths and native/cache reconciliation obligations; those remain necessary before claiming full integrated verification. The scratch README records rustfmt parsing with `skip_children=true`, not a successful type check or runtime proof.
