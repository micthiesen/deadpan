from pathlib import Path
import json,os,subprocess
s=Path(__file__).resolve().parent
reused=[]
for variant in ['scoped','main']:
 build='fade-qualified-release-'+variant+'-build'
 pins=json.loads((s/(build+'-pins.json')).read_text())
 names={row['name']for row in pins};assert len(names)==21
 order=['deadpan_audio']+sorted(names-{'deadpan_audio','stages','audio_definition'})+['stages','audio_definition']
 for target in order:
  current=next(p for p in pins if p['name']==target)
  prior=None
  for version,prefix in [('revised','fade-revised-'),('final','fade-final-')]:
   p=s/(prefix+variant+'-audio-'+target.replace('_','-')+'.json')
   if not p.exists():continue
   receipt=json.loads(p.read_text())
   oldpins=json.loads((s/('fade-qualified-'+version+'-'+variant+'-build-pins.json')).read_text())
   old=next(row for row in oldpins if row['name']==target)
   if receipt.get('exit_code')==0 and current['sha256']==old['sha256']:
    assert receipt['sources_unchanged']and receipt['binaries_unchanged']
    prior={'variant':variant,'target':target,'receipt':p.name,'binary_sha256':current['sha256'],'reason':'unchanged executable; only independent sound_events/audio_definition test sources changed'}
    break
  if prior:
   reused.append(prior);print('Reused unchanged passing executable',variant,target,flush=True);continue
  label='fade-terminal-'+variant+'-audio-'+target.replace('_','-')
  if variant=='scoped'and target=='audio_definition':label='fade-recovered-scoped-audio-audio-definition'
  args=['--test-threads=1']
  if variant=='main'and target=='stages':args=['--skip','general_split_sound::',*args]
  print('Starting',variant,target,flush=True)
  subprocess.run(['python3',str(s/'run_target.py'),build,variant,'audio',target,label,*args],check=True)
 label='fade-current-'+variant;listed=label+'-list'
 subprocess.run(['python3',str(s/'run_target.py'),build,variant,'audio','deadpan_audio',listed,'--list'],check=True)
 names=[line.removesuffix(': test')for line in(s/(listed+'.stdout')).read_text().splitlines()if line.endswith('::produce_current_cached_prediction_observations: test')]
 assert len(names)==1,names
 output=s/('fade-current-body-'+variant+'.json');assert not output.exists()
 env=os.environ.copy();env['DEADPAN_CACHED_PREDICTION_CURRENT']=str(output)
 subprocess.run(['python3',str(s/'run_target.py'),build,variant,'audio','deadpan_audio',label,'--ignored','--exact',names[0],'--nocapture','--test-threads=1'],env=env,check=True)
 assert 'test result: ok. 1 passed;'in(s/(label+'.stdout')).read_text()
(s/'reused-native-receipts.json').write_text(json.dumps(reused,indent=2)+'\n')
print('Starting separate inherited General Split audit',flush=True)
code=subprocess.run(['python3',str(s/'run_target.py'),'fade-qualified-release-main-build','main','audio','stages','fade-final-fresh-split','general_split_sound::','--nocapture','--test-threads=1']).returncode
print('General Split exit',code,flush=True)
raise SystemExit(code)
