from pathlib import Path
import json,tarfile,difflib,hashlib,shutil,sys
s=Path(__file__).resolve().parent
names=['main-final-source-pins.json','scoped-final-source-pins.json','publication-source-plan.json','shipping-source.patch','published-source','published-before']
prior=s/(sys.argv[1]if len(sys.argv)>1 else'before-sound-events-publication');assert not prior.exists();prior.mkdir()
for name in names:shutil.move(str(s/name),str(prior/name))
owned=json.loads((s/'owned-paths.json').read_text())
with tarfile.open(s/'base-source.tar')as archive:
 for item in archive:
  if item.isfile()and item.name in owned:
   p=s/'base-source'/item.name
   if not p.exists():p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(archive.extractfile(item).read())
roots={'main':Path('/Users/michael/Code/deadpan'),'scoped':Path('/tmp/deadpan-query-groundwork-2026-10-26/scoped')}
sha=lambda b:hashlib.sha256(b).hexdigest()
patch=[];rows=[]
initial=json.loads((s/'scoped-initial-authority.json').read_text())
for name in owned:
 p=s/'base-source'/name;old=p.read_bytes()if p.exists()else b''
 assert (sha(old)==initial[name]['sha256'])if name in initial else not old,name
 new=(roots['scoped']/name).read_bytes()
 patch.extend(difflib.unified_diff(old.decode().splitlines(True),new.decode().splitlines(True),fromfile='a/'+name if old else'/dev/null',tofile='b/'+name))
 rows.append({'path':name,'base_exists':bool(old),'base_sha256':sha(old),'scoped_bytes':len(new),'scoped_sha256':sha(new),'main_equal':(roots['main']/name).read_bytes()==new})
 if p.exists():
  dest=s/'published-before'/name;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(old)
 for variant,root in roots.items():
  dest=s/'published-source'/variant/name;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes((root/name).read_bytes())
(s/'shipping-source.patch').write_text(''.join(patch))
(s/'publication-source-plan.json').write_text(json.dumps(rows,indent=2)+'\n')
for variant,root in roots.items():
 pins={name:{'bytes':len((root/name).read_bytes()),'sha256':sha((root/name).read_bytes())}for name in owned}
 (s/(variant+'-final-source-pins.json')).write_text(json.dumps(pins,indent=2)+'\n')
print({'paths':len(rows),'main_equal':sum(r['main_equal']for r in rows),'patch_bytes':(s/'shipping-source.patch').stat().st_size,'patch_sha256':sha((s/'shipping-source.patch').read_bytes())})
