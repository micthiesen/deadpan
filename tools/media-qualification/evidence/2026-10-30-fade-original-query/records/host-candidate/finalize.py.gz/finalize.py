from pathlib import Path
import difflib,hashlib,json,subprocess
d=Path(__file__).resolve().parent
root=Path('/Users/michael/Code/deadpan')
sha=lambda b:hashlib.sha256(b).hexdigest()
before={str(p.relative_to(d/'before')):p for p in(d/'before').rglob('*')if p.is_file()}
after={str(p.relative_to(d/'after')):p for p in(d/'after').rglob('*')if p.is_file()}
assert len(before)==5 and len(after)==6
for name,p in before.items():assert p.read_bytes()==(root/name).read_bytes(),('actual source changed',name)
patch=''
for name,p in sorted(after.items()):
 old=before[name].read_text().splitlines(keepends=True)if name in before else[]
 new=p.read_text().splitlines(keepends=True)
 patch+='diff --git a/'+name+' b/'+name+'\n'
 if not old:patch+='new file mode 100644\n'
 patch+=''.join(difflib.unified_diff(old,new,fromfile='a/'+name if old else'/dev/null',tofile='b/'+name))
(d/'host.patch').write_text(patch)
for kind,paths in [('before',before),('after',after)]:
 (d/(kind+'-pins.json')).write_text(json.dumps({name:{'bytes':p.stat().st_size,'sha256':sha(p.read_bytes())}for name,p in sorted(paths.items())},indent=2)+'\n')
run=subprocess.run(['rustfmt','--edition','2024','--check','--config','skip_children=true',*[str(p)for p in after.values()]],capture_output=True,text=True)
(d/'rustfmt.stdout').write_text(run.stdout);(d/'rustfmt.stderr').write_text(run.stderr)
(d/'checks.json').write_text(json.dumps({'rustfmt_parse_and_format_exit':run.returncode,'skip_children':True,'actual_five_source_files_unchanged':True,'cargo_or_native_tests_run':False,'patch_bytes':len(patch.encode()),'patch_sha256':sha(patch.encode())},indent=2)+'\n')
assert run.returncode==0
print(json.dumps({'paths':len(after),'patch_bytes':len(patch.encode()),'patch_sha256':sha(patch.encode())}))
