# Original fade host candidate

Scratch-only candidate for the conditional fourth Original query product.
No actual Main/Scope source, golden, Git state or native runtime was changed.
The five existing source files still match their before copies at finalization.

## Files and behavior

- original_request.rs adds private Fade with admitted value and exact ReadWork issuer, Option<Fade> ownership in PreparedQueries, conditional Root/Domain admitted constructors, borrowed public-query access for the numerical read, and the fourth separately billed issuer comparison.
- original_request/flattened_work_trace.rs adds Product::Fade, fourth fixed TLS slot, fade_snapshot, fade_issuer_spent and ScopeGuard::new_fade. Its Lane schema and actual host-eviction receipt logic are unchanged.
- original_request/tests.rs includes fade_admission_tests and wraps its eight existing earlier-phase tests in with_legacy_fade_queries.
- original_request/policy_admission_tests.rs wraps its four existing three-product proofs in that independent legacy-fade mode.
- original_request/processing_admission_tests.rs similarly wraps its four existing processing proofs without changing their original bodies or budget assertions.
- original_request/fade_admission_tests.rs contains six new tests for the actual four-product path.

Admitted fade construction forwards work once through the existing Admission adapter. Only the cfg(test) legacy arm retains the ordinary constructor's successful-work debit. All earlier three products remain owned while optional fade construction runs. Fade ownership then remains attached to the prepared request through source/DSP reading and drops before returned PCM escapes. Failure returns unwind the same owned request.

The fade flag remains a true conditional: false creates no Fade, calls no fade constructor, and performs no fourth issuer comparison. Root/Domain identity and range validation retain their previous ordering. Sealed-request matching and its separate cost were not altered. A present fade issuer is checked after the first three issuers and before numerical source use.

The independent with_legacy_fade_queries flag has RAII restoration, including nested mode/unwinding. with_legacy_original_queries selects all four literal OLD constructors. Other compatibility flags keep their original meaning.

## Intended API

The candidate expects these confirmed Plan interfaces:

- AdmittedAudioFadeQuery<I,L>: query, work, canonical_units, additional_units, was_forwarded.
- RenderPlan::audio_fades_admitted(samples, limits, admission).
- AudioDomain::fades_admitted(samples, limits, admission).

No extraction, public metered detach, retained-input constructor, new source provider or new accounting ledger is introduced.

## New test contracts

1. conditional_fades_match_ordinary_values_and_wav_reads_with_actual_four_product_receipts covers Root/Domain, enabled/disabled fades and three actual source windows. It compares all existing logical fields, separately compares complete fade spans/lookup and canonical work, reconciles all four additional receipts and actual host evictions once, checks exact PCM bits/dependencies/source admission, and checks zero fade trace/cost when disabled.
2. all_four_metadata_products_stay_live_at_real_source_failure_and_cancellation observes actual shared ledger residency inside the source callback, then fails or cancels there. It also cancels after preparation but before the read, requiring no source callback or successful issuer debit.
3. a_foreign_fade_carrier_is_rejected_after_the_three_valid_issuers_before_wav_io swaps only Fade between two real issuers. Both sets of leases must release, all four actual comparisons are billed to the consuming ledger, and the source stays untouched.
4. failed_fade_construction_keeps_actual_partial_work_and_drops_all_four_products measures full construction, retries at exact and one-short allowance, and reconciles actual fourth-product failed-prefix work and eviction receipts without an invented successful query total.
5. four_product_consumption_has_an_exact_four_unit_boundary_before_source_io prepares the actual four products, then distinguishes allowance four from three before source I/O.
6. fade_charge_outlives_preparation_reduces_real_pcm_room_and_drops_without_refund retains all four products against real reserve(1,1), verifies the one-short resident limit, drops only Fade, observes remaining first-three residency, then succeeds with the newly available room and releases the unused request without refunding work.

These are test implementations, not passed results. The ordinary WAV fixture and existing real ReadWork/StageAudio helpers are reused. The source-failure/cancellation tests intentionally reject at admission; the successful parity test exercises actual WAV reads.

## Parent integration obligations outside ownership

The parent owns authored native reconciliation and Stage residency, so this candidate does not edit them.

- Add fade_work_trace from fade_snapshot in authored_eq/legacy_tile_baseline.rs. Extend tile_admission_tests query-trace tuples and paired/certified current-counter reconciliation to include the fourth category. Keep complete PCM/cache/errors literal and global host eviction differences once. Only subtract independently recorded additional and issuer fees; a true canonical mismatch requires separate actual-category proof.
- Existing native early warm prediction must still show zero constructors in all four slots. Existing late prepared-cache hit tests must release all four products and pay the separate request seal plus four issuer comparisons when fades are present. These cache paths live outside direct Original request tests and remain parent-owned.
- The Parent-owned stages/flattened_metadata.rs helper must measure the simultaneous fourth-product construction/retained peak for its existing gain/streaming residency bounds.
- Review earlier-phase exact-budget callers outside these five files for explicit legacy-fade scope. In particular, original_request/policy_reuse_tests.rs defines a local with_legacy_processing_queries wrapper; add the independent legacy-fade scope there or wrap its prior-reuse tests. Its processing_policy_admission_tests.rs child also has a prior-phase wrapper. original_request/flattened_admission_tests.rs contains earlier final-query failure/budget assumptions that can move after adding fourth-product fees. Do not revise those old expected work values to guessed offsets.
- shared_eq/prepared_input_tests.rs and any exact late-hit comparison may need current four-product evidence or explicit historical mode. This candidate leaves them untouched as assigned.

## Verification and limits

rustfmt with edition 2024 and skip_children=true parsed and formatted all six after files. A check rerun passed. The initial ordinary rustfmt invocation refused missing sibling module files in this intentionally partial scratch tree; skip_children limits formatting to the owned files. No compiler or runtime result is inferred.

No Cargo, Clippy, native, browser, source capture or golden generation was run. Parent must compile against the actual integrated Plan API, execute all new tests in the qualified native test profile, review actual failures and complete required gates. In particular, the exact partial-prefix and four-unit tests use the existing simple source fixture, but their actual integrated receipt behavior remains to be exercised.

before-pins.json and after-pins.json pin the complete files. host.patch contains normalized repository paths. checks.json records parsing/formatting and the actual-root preservation check.
