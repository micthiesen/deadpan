import hashlib, json, pathlib, datetime, re, subprocess
root=pathlib.Path('/Users/michael/Code/deadpan')
scope=pathlib.Path('/tmp/deadpan-query-groundwork-2026-10-26/scoped')
tmp=pathlib.Path('/tmp/deadpan-fade-query-admission-2026-10-30')
owned=json.loads((tmp/'owned-paths.json').read_text())
def digest(f):
    return {'bytes':f.stat().st_size,'sha256':hashlib.sha256(f.read_bytes()).hexdigest()} if f.is_file() else None
pins={}
for label,base,pinfile in [('main',root,'main-final-source-pins.json'),('scoped',scope,'scoped-final-source-pins.json')]:
    expected=json.loads((tmp/pinfile).read_text())
    mismatches=[rel for rel,row in expected.items() if digest(base/rel)!=row]
    pins[label]={'count':len(expected),'mismatches':mismatches}
differences=[]
for rel in owned:
    a,b=digest(root/rel),digest(scope/rel)
    if a!=b:differences.append({'path':rel,'main':a,'scoped':b})
ora=json.loads((tmp/'immutable-oracle-pins.json').read_text());oracle_bad=[]
for row in ora:
    for label,base in [('main',root),('scoped',scope)]:
        d=digest(base/row['path'])
        if d is None or d['sha256']!=row['sha256'] or ('bytes' in row and d['bytes']!=row['bytes']):oracle_bad.append({'tree':label,'path':row['path']})
authority={}
for label,base,file in [('main',root,'main-initial-authority.json'),('scoped',scope,'scoped-initial-authority.json')]:
    rows=json.loads((tmp/file).read_text());owned_present=sorted(set(rows)&set(owned));mismatch=[];missing=[]
    for rel,expected in rows.items():
        if rel in owned:continue
        d=digest(base/rel)
        if d is None:missing.append(rel)
        elif d!=expected:mismatch.append(rel)
    authority[label]={'inventory_paths':len(rows),'owned_paths_excluded':len(owned_present),'unowned_checked':len(rows)-len(owned_present),'unowned_mismatches':mismatch,'unowned_missing':missing}
plan={}
for tree in ['main','scoped']:
    rows=[];passed=failed=ignored=0
    for path in sorted(tmp.glob(f'fade-final-{tree}-plan-*.json')):
        if path.name.endswith('build-pins.json') or path.name.endswith('build.json'):continue
        rec=json.loads(path.read_text());out=next(pathlib.Path(k) for k in rec['streams'] if k.endswith('.stdout'))
        text=out.read_text(errors='replace');line=next((x.strip() for x in text.splitlines() if x.strip().lower().startswith('test result:')),'')
        match=re.search(r'(\d+) passed;\s*(\d+) failed(?:;\s*(\d+) ignored)?',line)
        p,f,i=(int(match.group(1)),int(match.group(2)),int(match.group(3) or 0)) if match else (None,None,None)
        if p is not None:passed+=p;failed+=f;ignored+=i
        rows.append({'receipt':path.name,'exit_code':rec.get('exit_code'),'result':line,'source_guard':rec.get('sources_unchanged'),'binary_guard':rec.get('binaries_unchanged'),'all_pass':rec.get('exit_code')==0 and f==0 and p is not None})
    plan[tree]={'receipt_count':len(rows),'passed':passed,'failed':failed,'ignored':ignored,'all_receipts_pass':len(rows)==29 and all(r['all_pass'] and r['source_guard'] and r['binary_guard'] for r in rows),'receipts':rows}
build=json.loads((tmp/'fade-sound-metadata2-build.json').read_text())
native=json.loads((tmp/'fade-sound-metadata2.json').read_text())
native_out=pathlib.Path('/tmp/deadpan-fade-query-admission-2026-10-30/fade-sound-metadata2.stdout').read_text(errors='replace')
match=re.search(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored',native_out)
strict=[]
for name in ['fade-final-main-strict.json','fade-final-scoped-strict.json']:
    rec=json.loads((tmp/name).read_text());strict.append({'receipt':name,'command':rec['command'],'exit_code':rec['exit_code'],'source_inventory':len(rec['source_before']),'sources_unchanged':rec['sources_unchanged'],'binary_inventory':len(rec['binary_before']),'binaries_unchanged':rec['binaries_unchanged'],'applies_to_44_path_snapshot':False})
doc_diff=subprocess.run(['git','diff','--quiet','7da84fc1b57897bd990a51f575b60f1b903c7318','--','docs'],cwd=root).returncode
result={
 'audited_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
 'scope':{'owned_path_count':44,'base':'7da84fc1b57897bd990a51f575b60f1b903c7318','main':str(root),'scoped':str(scope)},
 'final_source_pins':pins,
 'owned_main_scoped_differences':differences,
 'immutable_oracle':{'pin_count':len(ora),'mismatches':oracle_bad,'contents_read':False},
 'initial_authority_retention':authority,
 'plan_receipts':plan,
 'corrected_scope_sound_events':{'build_receipt':'fade-sound-metadata2-build.json','build_exit_code':build.get('exit_code'),'build_source_guard':build.get('sources_unchanged'),'build_binary_guard':build.get('binaries_unchanged'),'test_receipt':'fade-sound-metadata2.json','test_exit_code':native.get('exit_code'),'test_source_guard':native.get('sources_unchanged'),'test_binary_guard':native.get('binaries_unchanged'),'result_line':next((x.strip() for x in native_out.splitlines() if x.strip().lower().startswith('test result:')),''),'passed':int(match.group(1)) if match else None,'failed':int(match.group(2)) if match else None,'ignored':int(match.group(3)) if match else None},
 'strict_receipts':{'final_44_path_receipts_available':False,'historical_43_source_receipts':strict},
 'docs':{'main_tracked_diff_from_base':doc_diff,'state_md_present_main':(root/'docs/STATE.md').exists(),'state_md_present_scoped':(scope/'docs/STATE.md').exists(),'initial_authority_contains_docs':False},
 'static_review':{'metadata_helper':'sound_events imports Range for its child flattened_metadata module, which uses super::* and names Range<AudioSample>; therefore the import is used. The corrected scoped no-run build receipt exits 0.','limits':'Read-only receipt and hash audit. No build or native run performed by this auditor.'},
 'runtime_limits':{'scope_sound_events_corrected_receipt':'6 passed, 0 failed, 0 ignored','coverage':'Scope corrected sound_events integration only; Main sound_events result and final strict sourceguards after the 44-path source update are not available in these receipts.'}
}
(tmp/'final-source-audit-revised.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k not in ('plan_receipts',)},indent=2))
