#!/bin/sh
set -eu
export DEADPAN_FFMPEG_PREFIX=/Users/michael/Library/Developer/Deadpan/ffmpeg-8.0.3-opus-1.6.1-dav1d-1.5.4-qualified-3/prefix
export CARGO_PROFILE_DEV_OPT_LEVEL=2
s=/tmp/deadpan-mixed-fixed-retime-duration-2026-10-22
rg -q '3515 tests run: 3515 passed' "$s/regression.log"
rg -q '208 tests run: 208 passed' "$s/ui.log"
test -f "$s/whitespace.log"
python "$s/guard.py" focused-first > "$s/pre-release-source-guard.log"
python "$s/freeze.py" final > "$s/final-freeze.log"
cargo build --locked -p deadpan-app --release --features ui-harness --bin deadpan-app > "$s/release-app.log" 2>&1
sh "$s/native.sh"
sh "$s/encoded.sh"
