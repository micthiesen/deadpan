# Draft notes

This is a scratch-only child module for `crates/deadpan-app/src/preview/scoped/model/tests/nested_fixed_retime_duration.rs`. No repository file was changed and no Cargo, formatting, build, test, or Git command was run. This is an uncompiled draft, not a test result or success claim.

The witness runs both native navigation paths at cursor 22:

- Outer Default, Inner second Play. The second inner occurrence is the captured representative; changing its Hold should affect the corresponding inner-second use under all three outer iterations.
- Outer second Play, Inner Default. The cursor retains the second inner occurrence; changing its Hold should affect both inner uses under that one selected outer iteration.

For each path it checks the actual selected `RepeatEditBranch` values, keeps the visible `presentation(...).instance`, and maps all queried instances and targets through the actual `PreparedScopedEdit` proof. It runs Rename isolation with expected identity pools 5/0 and 6/0 respectively, raw mapped `SetHoldDuration` 2f→4f, unchanged 42-frame enclosing extent and six-frame `[0,8)` FollowSpeed/Edit Retime, six occurrence enumeration with expected affected use counts, exact Hold and following Speech boundaries, JSON round trips, and both structural inverses. Both original availability values are saved; the sole final assertion checks that both are true.

Likely compile or assumption risks to check when installing:

- The child module should be pasted at file scope after the existing test function in the parent module, preserving `use super::*` so fixture and navigation helpers resolve. The comment in the draft that suggests a closing brace is unnecessary and can be ignored; the parent source is a module file, not a braced inline module.
- Confirm the requested scoped requirement counts are exactly `(5, 0)` for Outer Default/Inner second Play and `(6, 0)` for Outer second Play/Inner Default. Those values came from the task; they were not executed here.
- Confirm `prepare_scoped_edit` reports two isolation steps for both mixed directions. The draft intentionally uses only public Rename and raw Hold duration APIs as positive controls, and does not call mixed semantic/preparation APIs.
- The no-default authored iteration IDs are checked against cursor 22's representative second/second path. This follows the fixture geometry: lead 3, two inner windows of 6 per outer play, cursor 22 selects outer 1 / inner 1.
- The expected mapped scoped Stage clone changes its child link to the proof-mapped body while retaining the original Retime fields. The other original nodes must remain byte-for-byte structurally equal.
- RenderPlan first/last framing identity checks were omitted because their public API/identity type was not established by the requested files. Add them only if the parent milestone's compile surface makes them clear.
- The split between source node IDs and representative occurrence IDs is intentional. Do not replace `prepared.map_instance`/`map_target` with hand-built clones or guessed identifiers.
