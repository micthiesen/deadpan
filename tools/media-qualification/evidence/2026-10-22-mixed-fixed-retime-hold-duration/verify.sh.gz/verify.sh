#!/bin/sh
set -eu
export DEADPAN_FFMPEG_PREFIX=/Users/michael/Library/Developer/Deadpan/ffmpeg-8.0.3-opus-1.6.1-dav1d-1.5.4-qualified-3/prefix
export CARGO_PROFILE_DEV_OPT_LEVEL=2
export DEADPAN_REQUIRE_PHYSICAL_MAC=1
export DEADPAN_REQUIRE_SYNTHETIC_WORKER=1
s=/tmp/deadpan-mixed-fixed-retime-duration-2026-10-22
rg -q '48 tests run: 48 passed' "$s/focused-first.log"
python "$s/guard.py" focused-first > "$s/pre-verification-source-guard.log"
cargo check --locked -p deadpan-app --features ui-harness --all-targets > "$s/ui-check.log" 2>&1
python "$s/freeze.py" regression > "$s/regression-freeze.log"
cargo build --locked -p deadpan-app --features ui-harness --bin deadpan-app > "$s/dev-native-build.log" 2>&1
python "$s/guard.py" regression > "$s/pre-debug-source-guard.log"
python "$s/debug_identity.py" > "$s/debug-identity.log"
"$s/debug-bin/deadpan-app" --ui-check --scenario mixed-fixed-duration --mode visual --output "$s/debug-visual" --kestrel-source /Users/michael/.dotfiles/kestrel/Sources/Kestrel/Shortcuts.swift > "$s/debug-visual.log" 2>&1
filter='test(semantic) | test(macros) | test(scoped) | test(hold_duration) | test(retime) | test(completion) | test(registry) | test(owned_gap)'
normal="package(deadpan-core) | package(deadpan-plan) | package(deadpan-audio) | package(deadpan-store) | $filter"
cargo nextest list --locked -p deadpan-core -p deadpan-plan -p deadpan-audio -p deadpan-store -p deadpan-app -p deadpan-cli -E "$normal" --message-format json > "$s/regression-list.json" 2> "$s/regression-list-build.log"
python "$s/identity.py" regression hash-only > "$s/regression-identity.log"
cargo nextest run --locked -p deadpan-core -p deadpan-plan -p deadpan-audio -p deadpan-store -p deadpan-app -p deadpan-cli --no-fail-fast -E "$normal" > "$s/regression.log" 2>&1
python "$s/freeze.py" ui > "$s/ui-freeze.log"
cargo nextest list --locked -p deadpan-app --features ui-harness -E "$filter" --message-format json > "$s/ui-list.json" 2> "$s/ui-list-build.log"
python "$s/identity.py" ui hash-only > "$s/ui-identity.log"
cargo nextest run --locked -p deadpan-app --features ui-harness --no-fail-fast -E "$filter" > "$s/ui.log" 2>&1
cargo xtask check --since 310c1b7b1c433bec7d87f60fc389a35694d4edb7 --no-test > "$s/lint.log" 2>&1
cargo clippy --locked -p deadpan-app --features ui-harness --all-targets -- -D warnings > "$s/ui-lint.log" 2>&1
cargo fmt --all -- --check > "$s/final-format.log" 2>&1
git diff --check > "$s/whitespace.log" 2>&1
