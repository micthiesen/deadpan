from pathlib import Path
import hashlib,json,sys
s=Path('/tmp/deadpan-mixed-fixed-retime-duration-2026-10-22')
stage=sys.argv[1]
rows=json.loads((s/(stage+'-source-identities.json')).read_text())
for name,digest in rows.items():
 assert hashlib.sha256(Path(name).read_bytes()).hexdigest()==digest,name
print(len(rows),'frozen source hashes verified for',stage)
