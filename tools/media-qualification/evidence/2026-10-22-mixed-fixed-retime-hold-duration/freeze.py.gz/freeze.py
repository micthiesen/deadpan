from pathlib import Path
import subprocess,hashlib,json,shutil,sys
s=Path('/tmp/deadpan-mixed-fixed-retime-duration-2026-10-22')
stage=sys.argv[1]
names=subprocess.check_output(['rg','--files','-g','*.rs'],text=True).splitlines()
rows={}
for name in names:
 p=Path(name); target=s/(stage+'-source')/name
 target.parent.mkdir(parents=True,exist_ok=True); shutil.copy2(p,target)
 rows[name]=hashlib.sha256(p.read_bytes()).hexdigest()
(s/(stage+'-source-identities.json')).write_text(json.dumps(rows,indent=2)+'\n')
print(len(rows),'Rust files frozen for',stage)
