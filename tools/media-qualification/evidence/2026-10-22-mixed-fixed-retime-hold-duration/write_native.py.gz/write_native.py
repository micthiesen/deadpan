from pathlib import Path
s=Path('crates/deadpan-app/src/preview/harness/scoped_plays/nested_fixed_duration.rs').read_text()
s=s[:s.index('\nmod fixture {')]
s=s.replace('//! Native explicit middle/middle duration editing beneath nested Repeat bodies.','//! Native mixed Default/Play duration editing beneath one fixed Retime.')
s=s.replace('    AudioTimingId, BeatNode, Command, CommandRequest, FrameDuration, FrameRange, HoldAudio,\n    HoldRecipe, HoldVideo, IterationOrder, NodeId, NodeKind, PitchPolicy, ProjectFrame,\n    RepeatEditBranch, RevisionId, SourceTimestamp, Subtree,','    Command, CommandRequest, FrameDuration, HoldAudio, HoldVideo, NodeId, NodeKind,\n    ProjectFrame, RepeatEditBranch, RevisionId, SourceTimestamp,')
s=s.replace('use deadpan_store::{AccessMode, ProjectStore};\n','')
s=s.replace('use std::{collections::BTreeMap, num::NonZeroU32, path::Path};','use std::{num::NonZeroU32, path::Path};\nuse super::nested_fixed_duration::fixture;')
a=s.index('    let live = scratch.path()')
b=s.index('    d.app_mut().feedback.hold_project_updates = false;',a)
s=s[:a]+'''    let result = (|| {
        for outer_default in [true, false] {
            let live = scratch.path().join(if outer_default { "mixed-default-play.deadpan" } else { "mixed-play-default.deadpan" });
            fixture::create(&previous, &live, freeze.clone())?;
            super::shared_hold_duration::open(d, &live, original)?;
            fixture::assert_fixture(d)?;
            controls(d, outer_default)?;
            recording_and_delayed(d, outer_default)?;
            let committed = document(d)?.clone();
            reopen_check(d, &live, original, &committed, outer_default)?;
            d.app().service.submit(ProjectRequest::Close)?;
            d.wait_for("Close completed mixed direction", |app| app.workspace.is_none() && !app.service.is_busy())?;
        }
        Ok(())
    })();
''' + s[b:]
s=s.replace('Nested This-play','Mixed fixed-window').replace('nested duration','mixed duration')
s=s.replace('fn controls(d: &mut Driver<\'_>)', "fn controls(d: &mut Driver<'_>, outer_default: bool)")
s=s.replace('fn recording_and_delayed(d: &mut Driver<\'_>)', "fn recording_and_delayed(d: &mut Driver<'_>, outer_default: bool)")
s=s.replace('    choose(d)?;', '    choose(d, outer_default)?;')
s=s.replace('fn choose(d: &mut Driver<\'_>)', "fn choose(d: &mut Driver<'_>, outer_default: bool)")
s=s.replace('    expected: &ProjectDocument,\n)', '    expected: &ProjectDocument,\n    outer_default: bool,\n)')
s=s.replace('.occurrence_hold_duration_requirements(\n            instance,', '.scoped_hold_duration_requirements(\n            &prior.target,')
s=s.replace('new_revision: RevisionId::new("ui-nested-duration-preflight")', 'new_revision: RevisionId::new("ui-mixed-duration-preflight")')
a=s.index('        command: Command::EditOccurrence {')
b=s.index('            identities: deadpan_core::OccurrenceIdentities {',a)
s=s[:a]+'''        command: Command::SetScopedHoldDuration {
            target: prior.target.clone(),
            duration: FrameDuration::new(4).map_err(|e| e.to_string())?,
''' + s[b:]
s=s.replace('ui-nested-duration-preflight-', 'ui-mixed-duration-preflight-')
s=s.replace('deadpan_core::prepare_occurrence_hold_duration(&baseline, &preflight_request)', 'deadpan_core::prepare_scoped_hold_duration(&baseline, &preflight_request, Some(instance))')
s=s.replace('== preflight.presentation', '== preflight.presentation.clone().ok_or("No preflight representative")?')
s=s.replace('Independent preflight requires two outside-in clones, 11 nodes and no marks', 'Independent mixed preflight requires one explicit Play clone and no marks')
s=s.replace('needs.nodes == 11', 'needs.nodes == expected_pool')
s=s.replace('preflight_proof.record().steps().len() == 2', 'preflight_proof.record().steps().len() == 1')
s=s.replace('"nodes":11,"marks":0,"isolation_steps":2', '"nodes":expected_pool,"marks":0,"isolation_steps":1')
s=s.replace('    let fixed = baseline.nodes()[&stage].clone();','    let fixed = baseline.nodes()[&stage].clone();\n    let expected_pool = if outer_default { 5 } else { 6 };')
s=s.replace('            && matches!(&prior.target.repeats[0].branch,\n                RepeatEditBranch::Play { iteration } if iteration.ordinal == 1)\n            && matches!(&prior.target.repeats[1].branch,\n                RepeatEditBranch::Play { iteration } if iteration.ordinal == 1)', '            && branch_choices(&prior.target) == [!outer_default, outer_default]')
s=s.replace('prior.has_single_play_authority()', '!prior.has_single_play_authority()')
s=s.replace('second stable play at both Repeat levels through one fixed Edit Retime', 'explicit mixed choices through one fixed Edit Retime')
s=s.replace('"scope":"This play outer 2/3, inner 2/2"', '"outer_default":outer_default')
s=s.replace('This play changes only the selected play.', "Changes follow each level's All plays or This play choice.")
# remove prefill capture; keep one final capture per direction.
s=s.replace('    d.capture("Nested This play fixed Retime duration prefill")?;\n', '')
s=s.replace('grown.nodes().len() == baseline.nodes().len() + 11', 'grown.nodes().len() == baseline.nodes().len() + expected_pool')
s=s.replace('                == 2', '                == 1')
s=s.replace('"overrides":2', '"overrides":1')
s=s.replace('after.target.repeats[1].repeat != prior.target.repeats[1].repeat', '(after.target.repeats[1].repeat != prior.target.repeats[1].repeat) == !outer_default')
# Existing repeat variable should name the actual explicit scope for both cases.
s=s.replace('let repeat = fixture::id("outer")?;', 'let repeat = fixture::id(if outer_default { "inner" } else { "outer" })?;')
# after branches may inner Default: equality check branch holds.
s=s.replace('.occurrence_hold_duration_requirements(\n            owned.presentation.as_ref().ok_or("No owned nested Hold")?,', '.scoped_hold_duration_requirements(\n            &owned.target,')
# account actual formatting in current source
s=s.replace('.occurrence_hold_duration_requirements(\n            owned\n                .presentation\n                .as_ref()\n                .ok_or("No owned nested Hold")?,', '.scoped_hold_duration_requirements(\n            &owned.target,')
s=s.replace('    d.capture("Nested This play fixed Retime duration history")?;', '''    d.capture(if outer_default {
        "Mixed fixed Retime All plays then This play duration history"
    } else {
        "Mixed fixed Retime This play then All plays duration history"
    })?;''')
# Scope navigation selects explicit All at the shared dimension.
s=s.replace('    d.command("scope play 2")?;\n    d.key(Key::Enter)?; // Outer selected play -> Inner Repeat.\n    d.command("scope play 2")?;', '    d.command(if outer_default { "scope all" } else { "scope play 2" })?;\n    d.key(Key::Enter)?; // Outer branch -> actual Inner Repeat.\n    d.command(if outer_default { "scope play 2" } else { "scope all" })?;')
# expected generic check must include literal mixed branches.
s=s.replace('        || target.target.repeats.len() != 2', '        || branch_choices(&target.target) != [!outer_default, outer_default]')
# Clarify identifiers clone observation used by both scope forms.
s=s.replace('/// Fresh isolation remaps Inner; its authored default ID cannot select this Hold.', '/// Play/Default remaps Inner, while Default/Play owns the selected Stage.')
Path('crates/deadpan-app/src/preview/harness/scoped_plays/mixed_fixed_duration.rs').write_text(s)
