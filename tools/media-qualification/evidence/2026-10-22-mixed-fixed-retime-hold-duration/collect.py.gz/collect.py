from pathlib import Path
import gzip,hashlib,io,json,tarfile
s=Path('/tmp/deadpan-mixed-fixed-retime-duration-2026-10-22')
out=Path('tools/media-qualification/evidence/2026-10-22-mixed-fixed-retime-hold-duration')
out.mkdir(parents=True,exist_ok=True)
def copy(source,name=None):
 name=name or source.name; data=source.read_bytes()
 compress=source.suffix in ['.log','.rs','.txt','.stdout','.stderr','.sh','.py','.md','.patch','.sha256'] or (source.suffix=='.json' and len(data)>100000)
 if compress: name+='.gz'; data=gzip.compress(data,mtime=0)
 (out/name).write_bytes(data)
 return name
retained={}
for source in sorted(s.iterdir()):
 if source.is_file() and source.suffix in ['.log','.json','.sh','.py','.txt','.md','.rs','.sha256','.patch','.stdout','.stderr']:
  if any(word in source.name.lower() for word in ['artifact','progress','next-selected']): continue
  retained[source.name]=copy(source)
snapshots={}; unique={}
for directory in sorted(p for p in s.iterdir() if p.is_dir() and p.name.endswith('source')):
 rows={str(p.relative_to(directory)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(directory.rglob('*.rs'))}
 manifest_name=directory.name+'-identities.json'
 assert rows==json.loads((s/manifest_name).read_text()),directory
 content_hash=hashlib.sha256(json.dumps(rows,sort_keys=True,separators=(',',':')).encode()).hexdigest()
 archive_name=unique.get(content_hash)
 if archive_name is None:
  buffer=io.BytesIO()
  with tarfile.open(fileobj=buffer,mode='w') as archive:
   for name in rows:
    data=(directory/name).read_bytes(); entry=tarfile.TarInfo(name)
    entry.size=len(data); entry.mode=0o644; entry.mtime=0; archive.addfile(entry,io.BytesIO(data))
  archive_name=directory.name+'.tar.gz'; (out/archive_name).write_bytes(gzip.compress(buffer.getvalue(),mtime=0))
  unique[content_hash]=archive_name
 snapshots[directory.name]={'archive':archive_name,'manifest':retained[manifest_name],'files':len(rows),'content_sha256':content_hash}
 with tarfile.open(fileobj=io.BytesIO(gzip.decompress((out/archive_name).read_bytes())),mode='r:') as archive:
  assert sorted(m.name for m in archive.getmembers())==sorted(rows)
  for name,digest in rows.items(): assert hashlib.sha256(archive.extractfile(name).read()).hexdigest()==digest,name
(out/'source-snapshots.json').write_text(json.dumps(snapshots,indent=2)+'\n')
for mode in ['debug-visual','visual','performance']:
 for source in sorted((s/mode).rglob('*.json')):
  copy(source,mode+'__'+str(source.relative_to(s/mode)).replace('/','__'))
for capture in json.loads((s/'selected-captures.json').read_text()):
 copy(s/capture['mode']/capture['file'],capture['mode']+'-'+capture['file'])
for row in json.loads((s/'encoded-identities.json').read_text())['outputs']:
 movie=Path(row['movie']); assert hashlib.sha256(movie.read_bytes()).hexdigest()==row['movie_sha256']
 copy(movie,'encoded-'+movie.name)
for row in json.loads((s/'owner-fixtures-identity.json').read_text()):
 p=s/row['archive']; assert hashlib.sha256(p.read_bytes()).hexdigest()==row['sha256']; (out/p.name).write_bytes(p.read_bytes())
inventory=[{'file':p.name,'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in sorted(out.iterdir()) if p.name!='inventory.json']
(out/'inventory.json').write_text(json.dumps(inventory,indent=2)+'\n')
for row in inventory:
 data=(out/row['file']).read_bytes(); assert len(data)==row['bytes'] and hashlib.sha256(data).hexdigest()==row['sha256']
print(len(inventory),'entries;',sum(r['bytes'] for r in inventory),'bytes;',len(snapshots),'source stages in',len(unique),'distinct fully rehashed archives')
