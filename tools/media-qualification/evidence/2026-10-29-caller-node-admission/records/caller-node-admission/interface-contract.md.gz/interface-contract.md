# Caller admission implementation contract

Base 4289f89e. The immutable five-case caller Description oracle is now captured from both old variants; golden fe460483643923727e3af2f6c46d41f0d4c4ec1088c7bed28e7d0d1eea40fc5b, common logical 7a8a2c208b98cd5ceee23681fd758b66e84c4c5f0dcd7038bc32775d76441e29. Old numerical receipts stay unchanged.

Adopt the two design reviews with this resolution: reject owned-boundary publication callbacks. Store a non-Clone admitted boundary wrapper directly in Description and Node. Thread the request work lifetime through Node/Graph as needed. This avoids a new Arc allocation and naked value extraction. Keep the value before its charge in all fields. Graph teardown already drops Graph before releasing aggregate resident frames; preserve it.

## Plan API (Plan author)

AudioOwnerClock::matches_treatment_owner(&self, candidate: &AudioOwnerClock<'_>) -> bool is the exact existing AudioTreatmentBoundary::matches conjunction: same Plan pointer, definition, instance, kind, gap_after, origin. Do not add sampling or play. Delegate old matches to it. Stage0 is universally valid, so the Audio acceptance comparison can use this borrowed predicate.

AudioOwnerClock::treatment_boundary_admitted<A:AudioSoundContextAdmission>(&self, before_stage:usize, limits:AudioQueryLimits, admission:&mut A) -> Result<AdmittedAudioTreatmentBoundary<'plan,A::Issuer,A::Lease>,A::Error>.
Validate the old stage condition before copying, and document its order relative to supplied limits. Share that validation with the old normal constructor. Reuse actual Budget::owner and preserve exhaustive field copies. Old boundary construction has zero canonical work; new copy inspections are additional and consume one remaining local budget plus the actual policy. False mode copies the old value, no additional/spend/reserve/merge, issuer checks allowed.

The exported non-Clone wrapper provides owner() as a borrowed clock for existing checked observations; before_stage(), matches(), matches_clock_at(), issuer(), lease(), work(), canonical_units() (zero), additional_units(), was_forwarded(). It has no Deref, Clone, into_value/parts/take or mutable value access. with_lease_mut(&mut self, callback:impl FnOnce(Option<&mut L>)) lends only the actual opaque charge for trusted Graph transfer and returns unit; no value can leave. The constructor and wrapper preserve value-before-charge drop order. Graph owns this SAME wrapper after publication; disarmed charge remains alongside its value and Graph counters become durable accounting.

## Audio caller (parent)

Replace the two candidate temporary OwnerKey constructions with key.matches. Admit the one persistent key's actual repeats array before its field-exhaustive copy; keep its lease through Description and Node. Borrowed Arc identity clones allocate nothing. No ad hoc key estimate that ignores repeat capacity.

Use actual owners_admitted in the retained incoming one-sample branch, preserve first-match order/grid and old layer validation, bill false once and skip already-forwarded true work. Avoid cloning the found clock solely to immediately Arc-clone the existing context.

DescriptionValues becomes generic for its admitted boundary. The real Graph Node stores the boundary wrapper with Issuer/Lease tied to the same request 'work. Other stop clones in renderer/SharedMix and wide Context::owners remain explicitly deferred; do not claim all Graph maps or temporary comparisons are closed.

## Capacity, native peak and joint handoff

Deterministic checked next capacity is bounded by maximum_prepared_stages; account full Layout::array<Node>(capacity), including spare storage. Old and next buffers coexist and both remain charged. Reserve planned next-capacity lease before native filter creation, so its later make_room sees key/boundary/context plus new capacity. Allocate actual Vec at the old post-filter site. Preserve recipe/error/canonical-tap order where possible; new resource refusal can preempt later work.

Prepay actual old-node movement work and all issuer/work/cancellation/arithmetic/transfer checks before any drain/move. Prepare the next Vec empty; old Graph stays untouched on any error. Fixed named lease lanes are Original Plan/Core/buffer, sound, key, boundary and optional capacity. Read-only preflight and mutable commit must mechanically use the same actual lane set, no copied frame receipts or substitute leases.

In the single infallible tail inside existing context transfer: move old nodes to admitted next Vec if growing, push the new Node with SAME boundary wrapper/key charge, swap into Graph, drop old buffer, then update checked active/resident counts (subtract old capacity ONCE) and disarm all actual lanes, accessing boundary/key charges in the published Node. No mutable Admission borrow survives into this tail. No fallible lookup, work, validation, allocation or external callback while moving/publishing. Without growth, push is capacity-guaranteed and no old-capacity subtraction occurs.

Store exact accounted node-capacity frames in Graph. Preserve source/PCM/native requirements, no cap/weight/refund/cache/cold/batch changes. Full renderer enumeration, other Graph containers, stop clones and recursive cold closure remain open.

## Required verification

Immutable old Description fields in false mode, normal/admitted boundary fields and borrowed-predicate identity counterexamples, wrong issuer, every allocation refusal, exact/one-short copy and full caller peaks, nonempty repeat paths, retained incoming first match and error order, no work refund, Graph same-lane handoff, old/new Vec peak and failed post-filter preflight with Graph untouched, real Graph reads and cleanup. Parent owns all Cargo/runtime; authors freeze both copies before execution. Independent review, strict check, optimized main/scoped tests/media and scoped main push required.
