# Design stress review: caller admission lifetimes

## Recommendation

Avoid the proposed callback that receives an owned `AudioTreatmentBoundary`. The boundary is `Clone` (`deadpan-plan/src/audio_owners.rs`), so any public callback can clone the value and retain a second uncharged set of repeat vectors. A `FnOnce` signature limits invocation count, but does not prove that the exact charged value is the only value published. A callback can also panic after publishing a clone. The current concrete caller can be disciplined, but the public Plan API would make the ownership guarantee conventional rather than structural.

Prefer keeping each admitted persistent value and its charge together through Graph ownership. Make the admitted boundary non-`Clone`, expose only the operations the caller needs, and store that wrapper in `Node` instead of extracting a plain boundary. This avoids an Arc and makes Description/Node's field drop order keep value before charge. No callback needs to move a boundary into the graph. On failed description or preflight, the local wrapper drops value then lease; a retry constructs a fresh wrapper. On successful publication, the same wrapper moves once from Description to Node and stays charged until the graph's ordinary cleanup.

A Plan API with this shape is sufficient:

```rust
pub struct AdmittedAudioTreatmentBoundary<'plan, I, L> {
    value: AudioTreatmentBoundary<'plan>,
    charge: Option<L>,
    issuer: I,
}

impl<'plan, I: Copy + Eq, L> AdmittedAudioTreatmentBoundary<'plan, I, L> {
    pub fn before_stage(&self) -> usize;
    pub fn matches(&self, candidate: &AudioOwnerClock<'_>) -> bool;
    pub fn matches_clock_at(&self, candidate: &AudioOwnerClock<'_>, at: AudioSample) -> bool;
    pub fn issuer(&self) -> I;
    pub fn lease(&self) -> Option<&L>;
    pub fn with_lease_mut<R>(&mut self, use_lease: impl FnOnce(Option<&mut L>) -> R) -> R;
}

impl AudioOwnerClock<'_> {
    pub fn treatment_boundary_admitted<A: AudioSoundContextAdmission>(
        &self,
        before_stage: usize,
        admission: &mut A,
    ) -> Result<AdmittedAudioTreatmentBoundary<'_, A::Issuer, A::Lease>, A::Error>;
}
```

The constructor should perform the same `before_stage` range check first, then copy via `Budget::owner` so the top-level owner, definition, instance repeats, gap iteration, retained origin definition/instance/gap are all charged before their copies. The wrapper should not expose `value`, `Deref`, `into_boundary`, `parts`, or `Clone`. The caller can store it directly in `DescriptionValues`/`Node`, and use only its read methods. `with_lease_mut` lends only the opaque charge for the existing joint transfer; it does not give the closure the owned boundary to clone or detach.

Keep the first-match predicate borrowed and independent of boundary allocation:

```rust
impl AudioOwnerClock<'_> {
    pub fn matches_treatment_owner(&self, candidate: &AudioOwnerClock<'_>) -> bool;
}
```

Its implementation must be exactly the existing `AudioTreatmentBoundary::matches` conjunction: same plan pointer, `definition`, `instance`, `kind`, `gap_after`, and `origin`; omit `play` and sampling just as the old method does. Delegate `AudioTreatmentBoundary::matches` to this helper. The old `treatment_boundary(0)?.matches(candidate)` performs a validation before comparison, but `0` is valid for every owner, so the new caller's predicate is equivalent. Keep tests for foreign plans and all listed identity/origin mismatches. Use `OwnerKey::matches` for the candidate scans, preserving `.find`/first-match order.

## Joint transfer and Graph accounting

Do not rely on a callback that both extracts the value and disarms its lease. The existing `JointTransfer` can continue to preflight actual borrowed leases before mutation; after the one publication push, it can disarm the carriers now stored in the new Node. Replace the positional expansion with a fixed lease record to make omissions harder:

```rust
pub(super) struct TransferLeases<'borrow, 'work> {
    pub original: [Option<&'borrow Lease<'work>>; 3],
    pub sound: Option<&'borrow Lease<'work>>,
    pub owner_key: Option<&'borrow Lease<'work>>,
    pub boundary: Option<&'borrow Lease<'work>>,
    pub node_capacity: Option<&'borrow Lease<'work>>,
}

pub(super) struct TransferLeasesMut<'borrow, 'work> {
    pub original: [Option<&'borrow mut Lease<'work>>; 3],
    pub sound: Option<&'borrow mut Lease<'work>>,
    pub owner_key: Option<&'borrow mut Lease<'work>>,
    pub boundary: Option<&'borrow mut Lease<'work>>,
    pub node_capacity: Option<&'borrow mut Lease<'work>>,
}

pub(super) fn preflight_transfer<'work>(
    control: WorkControl<'work>,
    leases: TransferLeases<'_, 'work>,
) -> Result<JointTransfer<'work>, StageAudioError>;

impl<'work> JointTransfer<'work> {
    pub(super) fn commit(self, leases: TransferLeasesMut<'_, 'work>);
}
```

Use the actual leases in these records, not copied frame totals or synthetic receipts. Preflight verifies issuer identity and checked sum for all lanes before the push. In the non-fallible tail: push the already-built node with its admitted key/boundary wrappers, update checked counters, then disarm those wrappers and existing Original/Core/buffer/sound leases through `JointTransfer`. The wrappers' leases can be disarmed through `with_lease_mut`; they remain value wrappers in Graph with empty charges, and Graph resident/active counters become the durable accounting until cleanup. Before this tail, a failed preflight leaves the carrier fields untouched and drop refunds the charges. The token is consumed once, so a successful publication cannot replay.

For Vec capacity, keep the old Graph capacity lease active while reserving the complete next capacity; charge the allocation before `Vec::with_capacity`. Compute the net resident replacement once as `new_capacity - old_capacity` (plus the new node/filter/metadata) only after capacity is known. Keep the new capacity lease armed until the final tail; failure before publication drops it, and the old Graph Vec and charge remain valid.

## Concrete boundary gaps to resolve in this closure

- A non-Clone boundary wrapper cannot be passed through the current `SharedMix::new(..., program.stop.cloned(), ...)` at `shared_eq.rs:360` or cloned from `graph.nodes[id].stop` at `shared_eq.rs:952`. Those copies also own the stop key's repeats vector. Either include each actual copy in the query's admission/lifetime, or change these short-lived consumers to borrow a read-only stop view. Do not silently charge only the Node's retained stop key while continuing to allocate these clones.
- The two candidate scans described by the draft are not the only `OwnerKey::new(owner)` site in the route: `shared_mix.rs:227` creates a temporary key for each owner. That renderer enumeration is explicitly a later slice, so it need not block this caller closure, but record it as still unadmitted and do not claim that all temporary owner comparisons are allocation-free.
- The retained incoming branch can use `owners_admitted` and the borrowed predicate, then return `incoming.owner_context(...)` on the first matching clock. `owner_context`'s Retained arm ignores the owner and only clones the same retained Arc, so `.cloned()` at `node_description.rs:195-201` is avoidable. Keep the query alive through the `.find(...)` predicate, then let it drop before returning; first-match order and the exact `at..at+1` range remain unchanged.
