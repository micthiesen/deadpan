from pathlib import Path
import difflib,json,hashlib
d=Path(__file__).resolve().parent
rel='crates/deadpan-audio/src/shared_eq/caller_baseline_tests.rs'
s=(d/'before/main'/rel).read_text()
s=s.replace('fn legacy_description_snapshot() -> Value {','''fn legacy_description_snapshot() -> Value {
    description_fixture_snapshot::<false>()
}

fn description_fixture_snapshot<const M: bool>() -> Value {''',1)
start=s.index('        let cancelled = AtomicBool::new(false);')
end=s.index('\n    }\n\n    // This is the established',start)
s=s[:start]+'''        cases.push(snapshot_case::<M>(
            name,
            &plan,
            request(&incoming, &owner, at, Temporal::Equalizer(stage), false),
            None,
        ));'''+s[end:]
start=s.index('    let cancelled = AtomicBool::new(false);',s.index('// This is the established'))
end=s.index('\n\n    // A frozen, ordinary',start)
s=s[:start]+'''    cases.push(snapshot_case::<M>(
        "incoming_retained",
        &retained_plan,
        request(
            &incoming,
            retained_owner,
            at,
            Temporal::Wet(TailEffect::Reverb),
            true,
        ),
        Some(&retained_input),
    ));'''+s[end:]
start=s.index('    let cancelled = AtomicBool::new(false);',s.index('// A frozen, ordinary'))
end=s.index('\n\n    // Inspect the first repeated',start)
s=s[:start]+'''    cases.push(snapshot_case::<M>(
        "normal_document_repeat_default_gap",
        &repeat_plan,
        request(
            &incoming,
            gap_owner,
            gap_at,
            Temporal::Wet(TailEffect::Delay),
            true,
        ),
        None,
    ));'''+s[end:]
start=s.index('    let cancelled = AtomicBool::new(false);',s.index('// Inspect the first repeated'))
end=s.index('\n\n    json!({',start)
s=s[:start]+'''    cases.push(snapshot_case::<M>(
        "normal_document_first_repeat_voice",
        &repeat_plan,
        request(
            &incoming,
            voice_owner,
            voice_at,
            Temporal::Wet(TailEffect::Delay),
            true,
        ),
        None,
    ));'''+s[end:]
s=s.replace('fn description_snapshot(\n','fn description_snapshot<I: Copy + Eq, L>(\n',1)
s=s.replace("description: &node_description::Description<'_, (), ()>,","description: &node_description::Description<'_, I, L>,",1)
helper='''// Each fixture invokes exactly one Description constructor. False preserves
// the frozen producer's legacy path; true uses the actual request admission.
fn snapshot_case<'plan, const M: bool>(
    name: &str,
    plan: &'plan Arc<RenderPlan>,
    request: node_description::Request<'_, 'plan>,
    expected_retained: Option<&deadpan_plan::SharedAudioOwnerRetainedInput<'plan>>,
) -> Value {
    let owner = request.owner;
    let at = request.at;
    let cancelled = AtomicBool::new(false);
    let work = RefCell::new(ReadWork::default());
    let control = fixture::control(&cancelled, &work);
    let snapshot = if M {
        let before_work = work.borrow().plan_work;
        let mut renderer = StageAudio::new(Arc::clone(plan));
        let description = {
            let mut admission =
                sound_context_admission::Admission::new(&mut renderer, control);
            node_description::describe_admitted(plan, request, control, &mut admission)
                .expect("actual admitted description fixture succeeds")
        };
        assert!(work.borrow().sound_context_frames > 0, "{name}");
        assert!(work.borrow().plan_work > before_work, "{name}");
        let snapshot = description_snapshot(plan, &description, owner, at, expected_retained);
        let billed = work.borrow().plan_work;
        drop(description);
        assert_eq!(work.borrow().sound_context_frames, 0, "{name}");
        assert_eq!(work.borrow().plan_work, billed, "{name}: no work refund");
        snapshot
    } else {
        let description =
            describe(plan, request, control).expect("legacy description fixture succeeds");
        description_snapshot(plan, &description, owner, at, expected_retained)
    };
    json!({
        "case":name,
        "description":snapshot,
        "controller_work":controller_work(&work.borrow()),
    })
}

'''
anchor='#[test]\nfn oracle_output_rejects_parent_escape()'
assert s.count(anchor)==1
s=s.replace(anchor,helper+anchor,1)
test='''#[test]
fn actual_admitted_descriptions_match_all_five_frozen_public_observations() {
    let frozen: Value = serde_json::from_str(include_str!(
        "../../tests/fixtures/caller-description-baseline-v1/snapshot.json"
    ))
    .expect("immutable caller description baseline parses");
    let actual = description_fixture_snapshot::<true>();
    let expected = frozen["cases"].as_array().expect("frozen cases");
    let observed = actual["cases"].as_array().expect("admitted cases");
    assert_eq!(observed.len(), 5);
    assert_eq!(observed.len(), expected.len());
    for (actual, old) in observed.iter().zip(expected) {
        assert_eq!(actual["case"], old["case"]);
        assert_eq!(
            actual["description"], old["description"],
            "actual metered Description must preserve every frozen field: {}",
            old["case"]
        );
    }
    let incoming = observed.iter().find(|case| case["case"] == "incoming_retained").unwrap();
    assert_eq!(
        incoming["description"]["context"]["original"]["same_arc_as_incoming"],
        json!(true),
        "the first matching retained owner keeps the exact incoming Arc"
    );
    let repeated = observed.iter().find(|case| case["case"] == "normal_document_first_repeat_voice").unwrap();
    assert!(
        !repeated["description"]["selected_owner"]["instance"]["repeats"]
            .as_array().unwrap().is_empty(),
        "the actual persistent key and boundary have a nonempty RepeatInstance path"
    );
}

'''
anchor='#[test]\n#[ignore = "parent-owned compiler/runtime pins'
assert s.count(anchor)==1
s=s.replace(anchor,test+anchor,1)
for label in ['main','scoped']:
 out=d/'candidate'/label/rel;out.parent.mkdir(parents=True,exist_ok=True);out.write_text(s)
