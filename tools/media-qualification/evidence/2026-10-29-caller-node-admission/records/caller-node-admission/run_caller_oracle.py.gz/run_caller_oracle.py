from pathlib import Path
import json,hashlib,os,subprocess,sys
s=Path(__file__).resolve().parent
label,build,variant=sys.argv[1:]
assert variant in ['main','scoped']
root=Path('/Users/michael/Code/deadpan') if variant=='main' else Path('/tmp/deadpan-query-groundwork-2026-10-26/scoped')
paths=json.loads((s/('source-files.json' if variant=='main' else 'scoped-source-files.json')).read_text())
manifest={n:{'bytes':(root/n).stat().st_size,'sha256':hashlib.sha256((root/n).read_bytes()).hexdigest()} for n in paths}
p=s/(label+'-source-manifest.json')
with p.open('x') as f:f.write(json.dumps(manifest,indent=2)+'\n')
digest=hashlib.sha256(p.read_bytes()).hexdigest()
pins=json.loads((s/(build+'-pins.json')).read_text())
binary=next(row['path'] for row in pins if row['package']=='audio' and row['name']=='deadpan_audio')
env=os.environ.copy()
env.update(DEADPAN_CALLER_BASELINE_OUTPUT=str(s/(label+'-snapshot.json')),DEADPAN_CALLER_BASELINE_VARIANT=variant,DEADPAN_CALLER_BASELINE_SOURCE_SHA256=digest)
runner='run.py' if variant=='main' else 'run_scoped.py'
raise SystemExit(subprocess.run(['python',str(s/runner),'--binary',binary,label,'--',binary,'produce_legacy_description_oracle_once_for_external_freeze','--ignored','--nocapture','--test-threads=1'],env=env).returncode)
