from pathlib import Path
roots=[Path('/Users/michael/Code/deadpan'),Path('/tmp/deadpan-query-groundwork-2026-10-26/scoped')]
block="""        let sound_frames = description
            .sound
            .as_ref()
            .and_then(|value| value.lease())
            .map_or(0, sound_context_admission::Lease::frames);
        let original_frames = description
            .original
            .as_ref()
            .map(|value| {
                value.leases().into_iter().flatten().try_fold(0_u64, |total, lease| {
                    total.checked_add(lease.frames()).ok_or(StageAudioError::Range)
                })
            })
            .transpose()?
            .unwrap_or(0);
        let key_frames = description.stop.lease().map_or(0, sound_context_admission::Lease::frames);
        let boundary_frames = description.boundary.lease().map_or(0, sound_context_admission::Lease::frames);
        let metadata_frames = [original_frames, sound_frames, key_frames, boundary_frames]
            .into_iter()
            .try_fold(0_u64, |total, frames| total.checked_add(frames).ok_or(StageAudioError::Range))?;
        let expected_issuer = sound_context_admission::issuer(control);
        if description.sound.as_ref().is_some_and(|value| value.issuer() != expected_issuer)
            || description.original.as_ref().is_some_and(|value| value.issuer() != expected_issuer)
            || description.stop.issuer() != expected_issuer
            || description.boundary.issuer() != expected_issuer
        {
            return Err(PlanError::AudioMetadataIssuerMismatch.into());
        }
        let resident = match kind {
            Temporal::Equalizer(_) => u64::try_from(crate::Equalizer::preparation_bytes_bound())
                .map_err(|_| StageAudioError::Range)?
                .div_ceil(std::mem::size_of::<[f32; 2]>() as u64),
            Temporal::Wet(_) => 0,
        };
        let recipe = match kind {
            Temporal::Equalizer(_) => Some(owner.treatments().and_then(|value| value.equalizer())
                .ok_or(PlanError::InvalidPlan("EQ recipe absent"))?),
            Temporal::Wet(_) => None,
        };
        if recipe.is_some() {
            control.spend_plan_work(deadpan_dsp::FINITE_FILTER_TAPS)?;
        }
        // This reservation precedes filter construction: its make_room must
        // see the complete planned metadata plus the still-live old buffer.
        let mut capacity = node_capacity::prepare(
            self, &graph.nodes, graph.node_capacity_frames,
            self.limits.maximum_prepared_stages as usize, control,
        )?;
        let retained = resident.checked_add(metadata_frames)
            .and_then(|value| value.checked_add(capacity.new_frames()))
            .ok_or(StageAudioError::Range)?;
        let next_active = self.active_frames.checked_sub(capacity.retired_frames())
            .and_then(|value| value.checked_add(retained))
            .ok_or(StageAudioError::Range)?;
        let next_resident = graph.resident.checked_sub(capacity.retired_frames())
            .and_then(|value| value.checked_add(retained))
            .ok_or(StageAudioError::Range)?;
        let next_capacity_frames = capacity.capacity_frames_after();
        let filter = if let Some(recipe) = recipe {
            self.make_room(resident, false, control)?;
            Some(crate::Equalizer::new(recipe, control.cancelled)?)
        } else {
            None
        };
        control.check()?;
        capacity.allocate()?;
        capacity.prepay_moves(control)?;
        capacity.validate_current(&graph.nodes, graph.node_capacity_frames)?;
        control.check()?;
        let node_description::Description { values, original, sound } = &mut description;
        let context_transfer = {
            let mut admission = sound_context_admission::Admission::new(self, control);
            deadpan_plan::preflight_context_transfer(
                original.as_mut(), sound.as_mut(), &mut admission,
            )?
        };
        let [plan, core, buffer, sound] = context_transfer.leases();
        let unpublished = values.as_ref().expect("unpublished description");
        let transfer = sound_context_admission::preflight_transfer(
            control,
            sound_context_admission::TransferLeases {
                original: [plan, core, buffer],
                sound,
                key: unpublished.stop.lease(),
                boundary: unpublished.boundary.lease(),
                capacity: capacity.lease(),
            },
        )?;
        let id = graph.nodes.len();
        context_transfer.commit(|plan, core, buffer, sound| {
            let node_description::DescriptionValues { context, boundary, stop, kind } =
                values.take().expect("unpublished description");
            capacity.publish(&mut graph.nodes, Node {
                parent: program.parent, context, boundary, stop, filter, kind,
                tiles: BTreeMap::new(),
            });
            // publish has physically freed the old vector before retiring it.
            self.active_frames = next_active;
            graph.resident = next_resident;
            graph.node_capacity_frames = next_capacity_frames;
            let Node { boundary, stop, .. } = &mut graph.nodes[id];
            boundary.with_lease_mut(|boundary| {
                stop.with_lease_mut(|key| {
                    transfer.commit(sound_context_admission::TransferLeasesMut {
                        original: [plan, core, buffer], sound, key, boundary,
                        capacity: capacity.lease_mut(),
                    });
                });
            });
        });
"""
for root in roots:
 p=root/'crates/deadpan-audio/src/shared_eq.rs';s=p.read_text()
 def one(old,new):
  global s
  assert s.count(old)==1,(root,old,s.count(old))
  s=s.replace(old,new)
 one('use super::shared_mix::{Boundary, Contribution, OwnerKey, Permissions, SharedMix, Temporal};','use super::shared_mix::{AdmittedStop, Boundary, Contribution, OwnerKey, Permissions, SharedMix, Temporal};')
 one('mod node_description;','mod node_description;\n#[path = "shared_eq/node_capacity.rs"]\nmod node_capacity;')
 one('AudioSoundOwnerContext, AudioTreatmentBoundary,','AudioSoundOwnerContext, AdmittedAudioTreatmentBoundary,')
 one("struct Node<'plan> {","struct Node<'plan, 'work> {")
 one("    boundary: AudioTreatmentBoundary<'plan>,\n    stop: Boundary,","    boundary: AdmittedAudioTreatmentBoundary<'plan, sound_context_admission::Issuer<'work>, sound_context_admission::Lease<'work>>,\n    stop: AdmittedStop<sound_context_admission::Issuer<'work>, sound_context_admission::Lease<'work>>,")
 s=s.replace("Graph<'plan>","Graph<'plan, 'work>").replace("Node<'plan>","Node<'plan, 'work>").replace("Graph<'_>","Graph<'_, '_>")
 one("struct Graph<'plan, 'work> {","struct Graph<'plan, 'work> {")
 one("impl<'plan> Graph<'plan, 'work> {","impl<'plan, 'work> Graph<'plan, 'work> {")
 one('    resident: u64,\n    wet_filters:','    resident: u64,\n    node_capacity_frames: u64,\n    wet_filters:')
 one('            resident: 0,\n','            resident: 0,\n            node_capacity_frames: 0,\n')
 for fn in ['read_shared_program','shared_eq_node']:
  one("fn "+fn+"<'plan>(","fn "+fn+"<'plan, 'work>(")
 one('fn shared_eq_tile(','fn shared_eq_tile<\'plan, \'work>(')
 for fn in ['read_shared_program','shared_eq_node','shared_eq_tile']:
  start=s.index('    fn '+fn+'<');end=s.index('    ) ->',start)
  header=s[start:end]
  header=header.replace("Graph<'_, '_>","Graph<'plan, 'work>").replace("control: WorkControl<'_>","control: WorkControl<'work>")
  s=s[:start]+header+s[end:]
 start=s.index('        let sound_frames = description',s.index("fn shared_eq_node<"))
 end=s.index('\n        Ok(graph.nodes.len() - 1)',start)
 s=s[:start]+block+s[end:]
 p.write_text(s)
