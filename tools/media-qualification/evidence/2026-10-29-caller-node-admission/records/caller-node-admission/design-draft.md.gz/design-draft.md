# Caller admission draft, for independent stress review

Base 4289f89e. No new source edits yet. Scope the actual shared_eq new-node caller: temporary identity comparisons, persistent OwnerKey and AudioTreatmentBoundary copies, retained incoming one-sample query, and Vec<Node> capacity. Wider renderer enumeration/other Graph maps/full recursive cold-resource closure remain later. No cap/weight/refund/native bound/cache/cold/batch changes.

## Avoid temporary owning values

Replace the two candidate OwnerKey::new(clock)==key scans with existing OwnerKey::matches. Add one borrowed Plan treatment-owner predicate implementing the exact old AudioTreatmentBoundary::matches fields, and delegate the owning method to it. The acceptance stage is zero, always valid; the temporary treatment_boundary(0) clone can disappear. Freeze old literal truth cases before changing the predicate, including foreign Plan, retained origin and repeat/gap mismatches.

## Persist actual key and boundary charges

The persistent stop key owns a repeats Vec; identity wrappers clone Arcs without new allocations. Audio can reserve a known repeat-array capacity before a field-exhaustive key copy and retain a private value-before-lease key guard through Description and Graph publication.

The persistent Plan boundary owns its clock payload. Reuse existing Budget::owner copies, preserving an exhaustive owner-field construction and charge before copy. Prefer a narrow admitted boundary carrier rather than adding an Arc allocation solely to make ownership easy. It lends its boundary and exposes a value-tied one-shot publication preflight. A temporary policy borrow ends at preflight. Commit takes a unit-returning infallible callback with the actual owned boundary AND mutable actual charge, moves the boundary only inside that callback, and marks the carrier committed. No public into_boundary/parts/take, replay or detached proof. Callback cannot return the raw value; the concrete Audio callback publishes Node and disarms its charge in the same tail. Review whether this narrow owned-value publication API is sound enough or propose a simpler equally charged design.

Description holds key/boundary guards before publication. Retained Original Plan/Core/buffer and sound charges stay as now. Extend the private Audio joint transfer to a bounded array including boundary, key and optional node-capacity leases, checked before any mutation; one final callback publishes Node and transfers all actual lanes. Empty leases and false mode retain old semantics. Persistent charges become Graph resident/active accounting until its normal cleanup. Do not drop an armed local lease after pushing its value.

## Vec<Node> capacity

Use explicit bounded capacity transitions rather than Vec::reserve's unspecified spare capacity. Reserve the complete next allocation before Vec::with_capacity; keep old Graph storage charged through overlap. If growth is needed, prepare a separate empty next Vec, but leave old nodes untouched until the infallible publication tail. Prepay actual movement work before draining; do not fallibly inspect nodes while moving.

The old filter allocation occurs before nodes.reserve and is not yet active until publication. New metadata admission after constructing that filter would miss its live peak. Proposed fix: reserve the planned next-capacity lease BEFORE filter creation, so the existing native make_room(resident) sees that charge; allocate the actual Vec at its old site. This is conservative early reservation, not minimum physical heap timing. Final publication moves old nodes into the new known-capacity Vec, pushes the new Node, swaps, drops old allocation, then replaces old capacity accounting with new capacity and node charges. Checked next_active/next_resident arithmetic must be computed after capacity is known and subtract the old capacity exactly once. All fallible validation, work, allocation and arithmetic precedes moving any old node.

Stress-test native headroom and drop/error cases, especially refusal after a real filter exists, failure before publishing a node, old/new Vec overlap, and double subtraction. Keep one joint no-fail tail. An empty BTreeMap and Arc clones allocate nothing.

## Retained incoming branch

Its one-sample Context::owners call remains legacy and currently clones a found clock solely to invoke owner_context, which immediately Arc-clones the already-retained input. Use the new actual owners_admitted guard, preserve the exact first matching borrowed clock and checked retained grid, and bill only unforwarded work. Remove the unnecessary clock clone only if all old checks/order are preserved. Root/Domain Q/C/P/R carriers remain unchanged.

## Evidence before and after

Freeze a small current legacy Description oracle before edits (literal fields, key/gap/origin/before-stage/kind, exact same retained Arc identity attestation, retained reference map and owner query); keep immutable old numerical work receipts independent. Add true/false constructor equivalence, every reservation failure, native/filter plus metadata peak, exact/one-short, wrong issuer, replay, actual Graph reads and failed-read cleanup. No caller lease may be refunded while its value or spare capacity survives. Main/scoped source variants, independent review, strict checks, optimized native/media validation and scoped main commit/push remain required.
