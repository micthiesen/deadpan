from pathlib import Path
import json,hashlib,difflib
s=Path(__file__).resolve().parent
files=json.loads((s/'task-files.json').read_text())
pins={}
for label,root in [('main',Path('/Users/michael/Code/deadpan')),('scoped',Path('/tmp/deadpan-query-groundwork-2026-10-26/scoped'))]:
 diffs=[]
 for f in files:
  p=root/f;data=p.read_bytes();dest=s/'candidate'/label/f;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(data)
  pins[label+'/'+f]=hashlib.sha256(data).hexdigest()
  before=s/'before'/label/f
  diffs.extend(difflib.unified_diff(before.read_text().splitlines(True) if before.exists() else [],data.decode().splitlines(True),fromfile='a/'+f,tofile='b/'+f))
 (s/(label+'.patch')).write_text(''.join(diffs))
(s/'candidate-pins.json').write_text(json.dumps(pins,indent=2)+'\n')
digest=hashlib.sha256((s/'candidate-pins.json').read_bytes()).hexdigest()
(s/'FREEZE.json').write_text(json.dumps({'status':'frozen','pins_sha256':digest,'files':files,'validation':'rustfmt parse/format only; Cargo/runtime delegated to parent'},indent=2)+'\n')
print(digest)
for f in files:
 print(f, pins['main/'+f], 'same' if pins['main/'+f]==pins['scoped/'+f] else 'preserved variant overlay')
