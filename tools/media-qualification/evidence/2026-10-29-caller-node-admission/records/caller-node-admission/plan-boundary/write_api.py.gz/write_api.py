from pathlib import Path
roots=[Path('/Users/michael/Code/deadpan'),Path('/tmp/deadpan-query-groundwork-2026-10-26/scoped')]
main=roots[0]/'crates/deadpan-plan/src'
body='''//! Admitted copy of one treatment boundary. The value precedes its charge.
use super::{
    AudioOwnerClock, AudioQueryLimits, AudioTreatmentBoundary, Budget, LookupStats,
    admission::{self, Owned},
};
use crate::AudioSoundContextAdmission;
use deadpan_core::AudioSample;

/// The exact immutable boundary and its independent opaque charge remain
/// together through publication. This carrier intentionally cannot be cloned.
pub struct AdmittedAudioTreatmentBoundary<'plan, I, L> {
    boundary: Owned<AudioTreatmentBoundary<'plan>, I, L>,
    additional: usize,
    forwarded: bool,
}

impl<'plan, I: Copy + Eq, L> AdmittedAudioTreatmentBoundary<'plan, I, L> {
    pub fn owner(&self) -> &AudioOwnerClock<'plan> {
        self.boundary.value.owner()
    }

    pub fn before_stage(&self) -> usize {
        self.boundary.value.before_stage()
    }

    pub fn matches(&self, candidate: &AudioOwnerClock<'_>) -> bool {
        self.boundary.value.matches(candidate)
    }

    pub fn matches_clock_at(&self, candidate: &AudioOwnerClock<'_>, at: AudioSample) -> bool {
        self.boundary.value.matches_clock_at(candidate, at)
    }

    pub fn issuer(&self) -> I {
        self.boundary.memory.issuer
    }

    pub fn lease(&self) -> Option<&L> {
        self.boundary.memory.lease.as_ref()
    }

    /// Trusted accounting transfer only: the callback must be infallible,
    /// non-unwinding and allocation-free. It borrows only the actual opaque
    /// lease; the boundary remains in this carrier, including after disarming.
    pub fn with_lease_mut(&mut self, callback: impl FnOnce(Option<&mut L>)) {
        callback(self.boundary.memory.lease.as_mut());
    }

    pub fn work(&self) -> usize {
        self.additional
    }

    /// The legacy boundary constructor performed no canonical query work.
    pub fn canonical_units(&self) -> usize {
        0
    }

    pub fn additional_units(&self) -> usize {
        self.additional
    }

    pub fn was_forwarded(&self) -> bool {
        self.forwarded
    }
}

impl<'plan> AudioOwnerClock<'plan> {
    /// Validate the legacy stage condition first, then the supplied limits,
    /// before inspecting/copying any payload or calling the admission policy.
    /// Copy inspections consume one shared local budget and are additional to
    /// the legacy constructor's zero canonical work.
    pub fn treatment_boundary_admitted<A: AudioSoundContextAdmission>(
        &self,
        before_stage: usize,
        limits: AudioQueryLimits,
        policy: &mut A,
    ) -> Result<AdmittedAudioTreatmentBoundary<'plan, A::Issuer, A::Lease>, A::Error> {
        self.validate_treatment_stage(before_stage)?;
        limits.validate()?;
        let mut local = Budget {
            remaining: limits.maximum_work,
            lookup: LookupStats::default(),
        };
        let mut budget = admission::Budget::new(&mut local, policy);
        admission::outer::<_, A>(copy(self, before_stage, &mut budget))
    }
}

fn copy<'plan, A: AudioSoundContextAdmission>(
    owner: &AudioOwnerClock<'plan>,
    before_stage: usize,
    budget: &mut admission::Budget<'_, A>,
) -> admission::Result<AdmittedAudioTreatmentBoundary<'plan, A::Issuer, A::Lease>, A> {
    let mut memory = budget.memory();
    let value = AudioTreatmentBoundary {
        owner: budget.owner(&mut memory, owner)?,
        before_stage,
    };
    budget.check_memory(&memory)?;
    Ok(AdmittedAudioTreatmentBoundary {
        boundary: Owned { value, memory },
        additional: budget.additional_used,
        forwarded: A::METERED,
    })
}
'''
(main/'audio_treatment_boundary_admission.rs').write_text(body)
for root in roots:
 src=root/'crates/deadpan-plan/src'
 for filename in ['lib.rs','plan.rs']:
  p=src/filename;s=p.read_text();old='    AdmittedAudioOwnerQuery, AudioOwnerClock, AudioOwnerClockOrigin, AudioOwnerKind,'
  assert s.count(old)==1,(p,s.count(old))
  s=s.replace(old,'    AdmittedAudioOwnerQuery, AdmittedAudioTreatmentBoundary, AudioOwnerClock, AudioOwnerClockOrigin, AudioOwnerKind,')
  p.write_text(s)
 if root!=roots[0]:
  # Apply only the authored owner-module deltas, preserving independent overlays.
  p=src/'audio_owners.rs';s=p.read_text()
  for old,new in [
   ('pub use retained_query::AdmittedAudioOwnerQuery;','pub use retained_query::AdmittedAudioOwnerQuery;\\n#[path = "audio_treatment_boundary_admission.rs"]\\nmod treatment_boundary_admission;\\npub use treatment_boundary_admission::AdmittedAudioTreatmentBoundary;'),
   ('''        if before_stage > self.treatments().map_or(0, |value| value.order().len()) {
            return Err(PlanError::InvalidPlan(
                "audio treatment boundary out of range",
            ));
        }
        Ok(AudioTreatmentBoundary {
            owner: self.clone(),
            before_stage,
        })''','''        self.validate_treatment_stage(before_stage)?;
        Ok(AudioTreatmentBoundary {
            owner: self.clone(),
            before_stage,
        })
    }

    fn validate_treatment_stage(&self, before_stage: usize) -> Result<(), PlanError> {
        if before_stage > self.treatments().map_or(0, |value| value.order().len()) {
            return Err(PlanError::InvalidPlan(
                "audio treatment boundary out of range",
            ));
        }
        Ok(())
    }

    /// Same treatment input identity, independent of current Repeat play or
    /// affine sampling. This inspection borrows both clocks without copying.
    pub fn matches_treatment_owner(&self, candidate: &AudioOwnerClock<'_>) -> bool {
        self.belongs_to(candidate.plan)
            && self.definition == candidate.definition
            && self.instance == candidate.instance
            && self.kind == candidate.kind
            && self.gap_after == candidate.gap_after
            && self.origin == candidate.origin'''),
   ('''        self.owner.belongs_to(candidate.plan)
            && self.owner.definition == candidate.definition
            && self.owner.instance == candidate.instance
            && self.owner.kind == candidate.kind
            && self.owner.gap_after == candidate.gap_after
            && self.owner.origin == candidate.origin''','''        self.owner.matches_treatment_owner(candidate)'''),
   ('pub(in crate::plan) mod tests;','''pub(in crate::plan) mod tests;

#[cfg(test)]
#[path = "audio_owners/treatment_boundary_admission_tests.rs"]
mod treatment_boundary_admission_tests;''')]:
   assert s.count(old)==1,(p,old)
   s=s.replace(old,new)
  p.write_text(s)
  (src/'audio_treatment_boundary_admission.rs').write_text(body)
