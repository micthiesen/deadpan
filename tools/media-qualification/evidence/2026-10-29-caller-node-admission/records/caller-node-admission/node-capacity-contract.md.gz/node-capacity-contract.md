# Node capacity helper ownership and exact API

New private child module shared_eq/node_capacity.rs, parent will mount it. No edits to Graph/shared_eq.rs or controller policy. Parent owns all Cargo.

pub(super) struct PendingNodeCapacity<'work,T>: value Option<Vec<T>> BEFORE actual optional sound_context_admission::Lease<'work>, plus planned len/cap/target and exact old frame data. No Clone/Deref/mutable Vec escape.

pub(super) fn prepare<'work,T>(controller:&mut StageAudio,current:&Vec<T>,accounted_frames:u64,maximum:usize,control:WorkControl<'work>)->Result<PendingNodeCapacity<'work,T>,StageAudioError>.
Validate current capacity Layout/frame count equals accounted_frames before mutation. Nonzero T is the production Node; reject unsupported zero-sized shape explicitly if needed. Validate len+1 and maximum. No growth if len<capacity. On growth choose deterministic capacity min(max(4, old_capacity*2), maximum), checked and >=len+1. Use Layout::array<T>, checked byte/frame conversions. Reserve FULL new capacity with real sound_context_admission::Admission before returning; no Vec allocation yet. Existing old capacity remains in active/resident. Issuer checks follow the actual policy.

Methods:
- new_frames(): u64, actual new lease frames or0.
- retired_frames(): u64, exact old frames only when growing, otherwise0.
- capacity_frames_after(): u64, new actual lease frames when growing, old accounted frames otherwise.
- lease(): Option<&Lease<'work>> and lease_mut(): Option<&mut Lease<'work>> (private accounting only).
- allocate(&mut self): allocate Vec::with_capacity(planned_target) only on growth, verify actual capacity admitted; called after filter creation at old allocation site. Layout already checked. Value precedes lease on all error/drop paths.
- prepay_moves(&self, control:WorkControl<'work>)->Result<(),StageAudioError>: spend actual old len once only if growing and nonzero. Parent calls once after allocation and before all final preflight/mutation. No synthetic zero debit.
- validate_current(&self,current:&Vec<T>,accounted_frames:u64)->Result<(),StageAudioError>: ensure the planned old len/cap/accounted frames still match; called before mutation.
- publish(&mut self,current:&mut Vec<T>,node:T): unit-returning infallible tail, no allocation/work/validation/callback. On growth take prepared Vec, move old values in order with explicit pushes into known spare capacity, push new node, swap, DROP old allocation. Without growth push to guaranteed spare capacity. Actual new-capacity lease remains in this helper afterward until parent jointly disarms it. Do not subtract counters here.

Parent will preflight next_active/resident = old minus retired_frames plus node/filter/metadata/new_frames, then use publish in one infallible tail before counter updates and actual lease transfer. It stores capacity_frames_after in Graph. Native make_room occurs after prepare, so it sees planned new capacity; no metadata reserve may ignore an already-live uncommitted filter.

Tests should use real StageAudio/control/Admission with nonzero simple T, cover no growth,0->initial and later growth with old/new overlap; exact/one-short budget, cancellation/error with old vector unchanged, wrong accounted frames/limit/layout, element order and value-before-lease cleanup on refusal/drop. Do not claim native-filter execution in helper tests; parent real Graph tests cover it.
