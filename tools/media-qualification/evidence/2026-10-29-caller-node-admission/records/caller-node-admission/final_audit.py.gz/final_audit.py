from pathlib import Path
import hashlib,json,re
s=Path(__file__).resolve().parent
main=Path('/Users/michael/Code/deadpan')
scope=Path('/tmp/deadpan-query-groundwork-2026-10-26/scoped')
sha=lambda b:hashlib.sha256(b).hexdigest()
negative={'caller-boundary-build1':101,'caller-integrated-build1':101,'caller-scoped-integrated-build1':101,'caller-qualified-build2':101,'caller-audio1':101,'caller-stages':101}
setup={'caller-focused1':127}
receipts=[]
for p in sorted(s.glob('*.json')):
 r=json.loads(p.read_text())
 if not isinstance(r,dict) or 'started_at' not in r or 'command' not in r:continue
 assert r.get('exit_code')==negative.get(p.stem,setup.get(p.stem,0)),(p.stem,r.get('exit_code'))
 if p.stem in setup:
  assert r['setup_error'] and r['test_executed'] is False
 else:
  assert r['sources_unchanged'] and r['binaries_unchanged'],p.stem
  for stream,h in r['streams'].items():
   b=Path(stream).read_bytes()
   assert len(b)==h['bytes'] and sha(b)==h['sha256']
 receipts.append({'label':p.stem,'exit_code':r['exit_code'],'seconds':r.get('seconds'),'source_inputs':len(r['source_before']),'sha256':sha(p.read_bytes()),'setup_failure_no_execution':p.stem in setup})
final=['caller-qualified-build3','caller-audio3','caller-plan3','caller-stages','caller-scoped-qualified-build1','caller-scoped-audio','caller-scoped-plan','caller-scoped-stages','caller-definition','caller-scoped-birth','caller-strict1']
for name in final:
 r=json.loads((s/(name+'.json')).read_text())
 for n,h in r['source_after'].items():
  b=Path(n).read_bytes();assert len(b)==h['bytes'] and sha(b)==h['sha256'],(name,n)
rows=json.loads((s/'task-source-pins.json').read_text())
data=(s/'index-blobs.bin').read_bytes();offset=0;equal=[]
for row in rows:
 end=data.index(b'\n',offset);header=data[offset:end].decode().split();assert header[1]=='blob'
 length=int(header[2]);body=data[end+1:end+1+length];offset=end+2+length
 assert body==(scope/row['path']).read_bytes()
 assert sha(body)==row['sha256'] and sha((main/row['path']).read_bytes())==row['main_sha256']
 equal.append({'path':row['path'],'blob':header[0],'sha256':row['sha256'],'scoped_index_equal':True,'main_equal':row['main_equals_scoped']})
assert offset==len(data) and len(rows)==26 and sum(x['main_equal'] for x in equal)==21
(s/'index-source-equality.json').write_text(json.dumps(equal,indent=2)+'\n')
owned={x['path'] for x in rows}
compat=set(json.loads((s/'main-compat-files.json').read_text()))
unchanged={};compat_pins=[]
for variant,root in [('main',main),('scoped',scope)]:
 pins=json.loads((s/(variant+'-initial-authority.json')).read_text());count=0
 for n,h in pins.items():
  if n in owned:continue
  current=sha((root/n).read_bytes())
  if variant=='main' and n in compat:
   assert current!=h,n
   compat_pins.append({'path':n,'initial_sha256':h,'sha256':current,'published':False})
  else:
   assert current==h,(variant,n)
   count+=1
 unchanged[variant]=count
assert len(compat_pins)==5
(s/'compat-final-pins.json').write_text(json.dumps(compat_pins,indent=2)+'\n')
oracles=json.loads((s/'immutable-oracle-pins.json').read_text())
for item in oracles:
 for root in [main,scope]:assert sha((root/item['path']).read_bytes())==item['sha256']
plans={}
for label in ['caller-qualified-build3','caller-scoped-qualified-build1']:
 rs=json.loads((s/'plan-results'/label/'results.json').read_text())
 assert len(rs)==29 and all(r['exit_code']==0 for r in rs)
 plans[label]={'targets':29,'passed':sum(int(v[1]) for r in rs for v in r['test_results']),'ignored':sum(int(v[3]) for r in rs for v in r['test_results'])}
stage_text=(s/'caller-stages.stdout').read_text()
matches=re.findall(r'^test ([\w:]+) \.\.\. (ok|FAILED|ignored)',stage_text,re.M)
regular=[r for r in matches if not r[0].startswith('general_split_sound::')]
split=[r for r in matches if r[0].startswith('general_split_sound::')]
assert len(regular)==203 and all(r[1]=='ok' for r in regular),(len(regular),[r for r in regular if r[1]!='ok'])
assert len(split)==7 and sum(r[1]=='ok' for r in split)==4 and sum(r[1]=='FAILED' for r in split)==3,split
result={'all_terminal':True,'receipts':receipts,'source_files':26,'rust_files':24,'main_equal_source_files':21,'scoped_index_source_equality':True,'other_initial_guard_inputs_unchanged':unchanged,'main_only_inherited_compatibility_files':compat_pins,'immutable_oracles_unchanged':True,'final_compiled_sources_current':True,'plan_results':plans,'main_combined_stage_result':{'regular_passed':203,'split':split,'total_passed':207,'failed':3,'seconds':json.loads((s/'caller-stages.json').read_text())['seconds']},'negative_results_retained':negative,'setup_failure_no_execution':setup,'scoped_patch_sha256':sha((s/'task-scoped.patch').read_bytes())}
(s/'final-audit.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k not in ['receipts','main_only_inherited_compatibility_files']}))
