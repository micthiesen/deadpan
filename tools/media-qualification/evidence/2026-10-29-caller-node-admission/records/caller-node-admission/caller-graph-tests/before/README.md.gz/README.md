`caller_graph_tests.rs` did not exist before this task. The candidate adds a new test module only; the parent owns the cfg(test) hook.
