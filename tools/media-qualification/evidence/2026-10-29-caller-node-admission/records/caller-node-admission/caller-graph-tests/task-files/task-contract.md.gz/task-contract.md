# Caller Graph admission tests

Owned file: `crates/deadpan-audio/src/shared_eq/caller_graph_tests.rs` only.

Tests enter the actual shared EQ Graph path with a voice from the frozen
stable-repeat baseline document, with an EQ treatment added and validated using
normal document/plan constructors. They cover real stop and treatment-boundary
leases, Node Vec no-growth and replacement growth, exact/one-short combined
native/metadata/capacity headroom, replacement-capacity overlap refusal, and a
plan-work refusal at the post-native, post-capacity-allocation move-prepayment
stage. A separate pre-cancelled case checks early cleanup. Parent owns the cfg
hook and Cargo execution. No allocator/RSS/native bounds claim is made.
