# Retained-owner query decisions and observed corrections

The scope is the actual one-sample owner query in numerical Original acceptance. The wider Context::owners render enumeration and caller treatment-boundary/OwnerKey/NodeVec allocations remain separate closure work. No complete allocator/native peak, cold-resource closure or general Split readiness is claimed.

The plain owners wrapper and admitted wrapper share orchestration. Envelope construction and the actual owner walker share one local remaining budget and one admission policy; returned query capacity and owning payload remain value-before-lease. The original retained origin is copied under admission before subsequent per-owner copies. The source probe guard stays live throughout the acceptance comparison, and accepted-query storage overlaps final sharing exactly as in the old lexical scope.

The immutable capture baseline already contains complete observed_owners for four actual Some cases, plus three source-split witness rows. No golden regeneration is needed. Hidden resumed group is work11; the fractional Point and Root split observations are work5. An early index shorthand misidentified work11 as Point; literal fixture names correct that ambiguity.

Independent design review identified the second-validation zero-remainder error precedence. A zero-only metered precheck preserves InvalidAudioLimits before newly charged seed copies. Positive remainders retain validation at the old point. This avoids an unnecessary unobservable seed clone only when zero would otherwise change the typed legacy error.

The first compile failed because Product was imported from admission rather than query_admission. The corrected import compiled. The first Plan library run passed152/failed3/ignored4: three new assertions compared METERED total work to frozen canonical work. The correction asserts canonical equality to the immutable old work, total equals checked canonical-plus-additional, and changes only the expected top-level work view before comparing all logical fields. It never resets product work or rewrites a golden.

Byte caps do not exercise every later reservation below a previous peak. A separate reservation-index refusal schedule is required alongside exact peak/one-short tests.

The initial source-guard setup stopped before Cargo because the parent treated the author's task-files object as an array. Its owned_files key was removed and the actual array applied. The failed patch anchor during the import correction wrote nothing; the actual import block was reread before applying the one-line correction.

The accounting reviewer found that the phrase calls no policy was too broad: the existing admission infrastructure calls read-only issuer() in both modes to preserve carrier identity. The contract now explicitly excludes spend/reserve/merge calls in false mode and permits existing issuer checks. No code was changed to weaken identity validation; this is a terminology correction, not a product requirement change.

A lifetime reviewer initially claimed Owners survived rejected block exit into fallback. Re-evaluation withdrew that finding: Owners is declared inside the if-let block and drops at its closing brace before drop(probe) and share.domain. Accepted return evaluation still overlaps Owners and final sharing. The corrected reviewer report is retained.

The synthetic empty-support test initially expected zero additional work for a nonempty inactive result. Its actual Vec capacity growth costs one additional unit. It now uses the same canonical-plus-additional reconciliation and full-field comparison as other retained queries; no product accounting changed. One compile also found a test variable shadowing the policy factory, fixed by qualifying self::policy. Two Audio filter receipts selected zero tests and carry no coverage credit; corrected filters execute five prefix and three pure sharing tests.
