from pathlib import Path
import json,hashlib
s=Path(__file__).resolve().parent;main=Path('/Users/michael/Code/deadpan');scoped=Path('/tmp/deadpan-query-groundwork-2026-10-26/scoped')
sha=lambda b:hashlib.sha256(b).hexdigest()
rows=json.loads((s/'task-source-pins.json').read_text());data=(s/'index-blobs.bin').read_bytes();off=0
for row in rows:
 end=data.index(b'\n',off);head=data[off:end].decode().split();assert head[1]=='blob'
 length=int(head[2]);b=data[end+1:end+1+length];off=end+2+length
 assert b==(scoped/row['path']).read_bytes() and sha(b)==row['sha256']
 assert sha((main/row['path']).read_bytes())==row['main_sha256']
assert off==len(data)
owned={row['path'] for row in rows};counts={}
for name,root in [('main',main),('scoped',scoped)]:
 pins=json.loads((s/(name+'-initial-authority.json')).read_text());count=0
 for path,h in pins.items():
  if path in owned:continue
  assert sha((root/path).read_bytes())==h,(name,path)
  count+=1
 counts[name]=count
result={'source_files':len(rows),'scope_index_equal':True,'main_equal':sum(row['main_equals_scoped'] for row in rows),'other_initial_inputs_unchanged':counts,'scope_patch_sha256':sha((s/'task-scoped.patch').read_bytes())}
(s/'source-audit.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
