from pathlib import Path
import json,hashlib,difflib
s=Path(__file__).resolve().parent
r=Path('/Users/michael/Code/deadpan');q=Path('/tmp/deadpan-query-groundwork-2026-10-26/scoped')
rows=[];patch=[]
for n in json.loads((s/'task-files.json').read_text()):
 head=s/'head'/n;b=head.read_bytes() if head.exists() else b''
 live=(r/n).read_bytes();a=(q/n).read_bytes()
 assert a!=b,n
 patch.extend(difflib.unified_diff(b.decode().splitlines(True),a.decode().splitlines(True),fromfile='a/'+n if head.exists() else '/dev/null',tofile='b/'+n))
 rows.append({'path':n,'before_sha256':hashlib.sha256(b).hexdigest() if head.exists() else None,'sha256':hashlib.sha256(a).hexdigest(),'main_sha256':hashlib.sha256(live).hexdigest(),'main_equals_scoped':live==a})
(s/'task-scoped.patch').write_text(''.join(patch))
(s/'task-source-pins.json').write_text(json.dumps(rows,indent=2)+'\n')
(s/'index-queries.txt').write_text(''.join(':'+x['path']+'\n' for x in rows))
print(json.dumps({'source_files':len(rows),'main_equal':sum(x['main_equals_scoped'] for x in rows),'scoped_patch_sha256':hashlib.sha256((s/'task-scoped.patch').read_bytes()).hexdigest()}))
