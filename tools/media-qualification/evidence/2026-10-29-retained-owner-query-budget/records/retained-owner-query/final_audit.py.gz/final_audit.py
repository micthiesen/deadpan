from pathlib import Path
import hashlib,json
s=Path(__file__).resolve().parent
main=Path('/Users/michael/Code/deadpan');scoped=Path('/tmp/deadpan-query-groundwork-2026-10-26/scoped')
sha=lambda b:hashlib.sha256(b).hexdigest()
negative={'retained-build1':101,'retained-build3':101,'retained-plan1':101,'retained-plan2':101,'retained-strict':1,'retained-strict2':1,'retained-split':101}
receipts=[]
for p in sorted(s.glob('*.json')):
 x=json.loads(p.read_text())
 if not isinstance(x,dict) or 'started_at' not in x or 'command' not in x:continue
 assert x.get('exit_code')==negative.get(p.stem,0),(p.stem,x.get('exit_code'))
 assert x['sources_unchanged'] and x['binaries_unchanged'],p.stem
 receipts.append({'label':p.stem,'exit_code':x['exit_code'],'seconds':x['seconds'],'source_inputs':len(x['source_before']),'sha256':sha(p.read_bytes())})
final=['retained-final-build','retained-final-audio','retained-final-plan','retained-final-stages','retained-scoped-build','retained-scoped-plan','retained-scoped-audio','retained-scoped-stages','retained-definition','retained-scoped-birth','retained-strict3','retained-split']
for name in final:
 x=json.loads((s/(name+'.json')).read_text())
 for n,h in x['source_after'].items():
  b=Path(n).read_bytes();assert len(b)==h['bytes'] and sha(b)==h['sha256'],(name,n)
rows=json.loads((s/'task-source-pins.json').read_text())
data=(s/'index-blobs.bin').read_bytes();off=0;equal=[]
for row in rows:
 end=data.index(b'\n',off);head=data[off:end].decode().split();assert head[1]=='blob'
 length=int(head[2]);body=data[end+1:end+1+length];off=end+2+length
 assert body==(scoped/row['path']).read_bytes()
 assert sha(body)==row['sha256'] and sha((main/row['path']).read_bytes())==row['main_sha256']
 equal.append({'path':row['path'],'blob':head[0],'sha256':row['sha256'],'scoped_index_equal':True,'main_equal':row['main_equals_scoped']})
assert off==len(data) and len(rows)==12 and sum(x['main_equal'] for x in equal)==11
(s/'index-source-equality.json').write_text(json.dumps(equal,indent=2)+'\n')
owned={x['path'] for x in rows};unchanged={}
for variant,root in [('main',main),('scoped',scoped)]:
 pins=json.loads((s/(variant+'-initial-authority.json')).read_text());count=0
 for n,h in pins.items():
  if n in owned:continue
  assert sha((root/n).read_bytes())==h,(variant,n)
  count+=1
 unchanged[variant]=count
for item in json.loads((s/'immutable-oracle-pins.json').read_text()):
 for root in [main,scoped]:assert sha((root/item['path']).read_bytes())==item['sha256']
plans={}
for label in ['retained-final-build','retained-scoped-build']:
 rs=json.loads((s/'plan-results'/label/'results.json').read_text())
 assert len(rs)==29 and all(r['exit_code']==0 for r in rs)
 plans[label]={'targets':29,'passed':sum(int(v[1]) for r in rs for v in r['test_results']),'ignored':sum(int(v[3]) for r in rs for v in r['test_results'])}
result={'all_terminal':True,'receipts':receipts,'source_files':12,'main_equal_source_files':11,'scoped_index_source_equality':True,'other_initial_guard_inputs_unchanged':unchanged,'immutable_oracles_unchanged':True,'final_compiled_sources_current':True,'plan_results':plans,'negative_results_retained':negative,'zero_test_filters_no_credit':['retained-audio-prefix','retained-audio-metadata'],'scoped_patch_sha256':sha((s/'task-scoped.patch').read_bytes()),'synthetic_empty_support_not_valid_document_oracle':True}
(s/'final-audit.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k!='receipts'}))
