No unresolved accounting/query-admission findings.

The previous Minor finding is withdrawn under the clarified contract: `Budget::new` and `Budget::check` read `issuer()` to preserve identity validation, while the METERED=false path skips spend/reserve/merge side effects.

The synthetic empty-support test now uses `assert_retained_query_fields`, which checks frozen canonical work, checked canonical-plus-additional total, and all query fields while rewriting only the expected work view; the nonempty inactive-span allocation's `grow` debit is therefore accounted for. It checks forwarded work against the actual admitted total. The corrected self-qualified policy helper is present. The live reservation-index loop exercises refusal at every reservation site observed in a successful query and verifies prior leases are released. No tests were run per instruction.
