No remaining issues in the bounded final test-only and correction deltas.

The empty-support fixture changes only the captured bound's support and matching domain tag; its cases cover both empty and nonempty sample ranges, both admission modes, expected canonical work, metered forwarding, and reservation refusals. Reservation-index failure injection releases earlier leases. The latest export reorder is behavior-neutral, and the noted lint corrections simplify the tests without weakening the production assertions.

Parent reports the scoped Plan and Audio tests and strict lint pass. I ran no commands that build or test the code.
