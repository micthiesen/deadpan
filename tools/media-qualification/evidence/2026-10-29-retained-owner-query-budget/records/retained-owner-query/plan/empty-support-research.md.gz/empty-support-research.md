# Empty-support retained probe research

## Result

No existing frozen fixture or regression in `crates/deadpan-plan/src/audio_owners` returns `AudioBoundDomain::Empty`; the only occurrences are the serializer arms and the constructor branch itself. Existing `retained_probe_at` fixtures exercise present Root/Point domains and absent probes, but not a present probe whose raw domain is Empty.

The branch is reachable through ordinary construction in principle, without mutating private fields: `AudioBound` is made by `RenderPlan::bound_at_query`, and its `support` is the intersection of the binding node's intrinsic local extent with the current walk's meaningful `envelope` (`audio_bound_query.rs`, around lines 314-331). `AudioCapture` computes this envelope by intersecting authored node supports (`audio_capture.rs`, around lines 345-405); `intersect` retains a touching endpoint as an empty range. The outer delivery/allocated `extent` and meaningful `envelope` are separate. A one-sample owner context can therefore capture an enclosing Bound while the binding's meaningful operand is clipped to a zero-width touching intersection. `AudioBound::envelope_domain_query` and `raw_domain_admitted` both intentionally classify that support as empty.

I did not find a checked-in document that demonstrates the exact combination. The quickest public-constructor search target for a test is a valid retained binding below a Retime/Partition seam where the ancestor's selected meaningful interval ends exactly where the bound node's local support begins, while the ancestor's allocated extent still includes the observed owner sample. Use `ProjectDocument` / normal bind helpers, compile, obtain `AudioOwnerInput`, call `retained_probe_at`, assert `Some(input)` and `AudioBoundDomain::Empty`, then call `owners_admitted` and compare the legacy logical observation against an inactive empty-owner span. Do not set `AudioBound.support` directly.

A selected Source with an empty selection is not a suitable fixture: `bound_at_query` returns `None` before resolving the binding for this case (except gap bindings), so it tests absent-probe handling, not the empty retained envelope branch. The existing positive-duration `PointCeil` fixtures also do not suffice: they prove that a nonempty support can contain no grid points, which is a different state.

## Relevant ownership path

- `audio_capture.rs`: while capturing a bound processor, `BoundPlacement.support` borrows the current envelope; the `AudioBound` constructor intersects it with `0..duration` and optional selected physical source support.
- `audio_owner_input.rs`: `retained_probe_at` walks the checked one-sample context and calls `bound.raw_domain()` when the stage content is `Bound`; the resulting `AudioBoundDomain::Empty` is stored in the returned retained input.
- `audio_bound_probe.rs`: `raw_domain_admitted` returns `Empty` before copying a definition or constructing a domain when `support.end <= support.start`.
- `audio_bound_query.rs`: the admitted retained owners query calls `envelope_domain_query`; `None` takes the legacy empty-support work path.
