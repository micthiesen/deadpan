from pathlib import Path
import hashlib
import json
import difflib
import shutil

repo = Path('/Users/michael/Code/deadpan')
scoped = Path('/tmp/deadpan-query-groundwork-2026-10-26/scoped')
base = Path('/tmp/deadpan-retained-owner-query-2026-10-29/plan')
paths = [
    'crates/deadpan-plan/src/audio_owner_input.rs',
    'crates/deadpan-plan/src/audio_owners.rs',
    'crates/deadpan-plan/src/audio_owner_query.rs',
    'crates/deadpan-plan/src/audio_retained_owner_query.rs',
    'crates/deadpan-plan/src/audio_owners/legacy_snapshot_v1.rs',
    'crates/deadpan-plan/src/audio_owners/owner_query_admission_tests.rs',
    'crates/deadpan-plan/src/plan.rs',
    'crates/deadpan-plan/src/lib.rs',
]
for variant, root in [('main', repo), ('scoped', scoped)]:
    out = base / f'candidate-{variant}'
    for rel in paths:
        target = out / rel
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(root / rel, target)

patch_parts = []
for rel in paths:
    before_path = base / 'before' / rel
    after_path = repo / rel
    after = after_path.read_text()
    if before_path.exists():
        before = before_path.read_text()
        old_name = f'a/{rel}'
        new_name = f'b/{rel}'
    else:
        before = ''
        old_name = '/dev/null'
        new_name = f'b/{rel}'
    patch_parts.extend(difflib.unified_diff(
        before.splitlines(keepends=True), after.splitlines(keepends=True),
        fromfile=old_name, tofile=new_name, n=3))
(base / 'task.patch').write_text(''.join(patch_parts))

pins = {'main_head_at_capture': 'dcd69393c783b7eba4b86fd525b24b2358461721',
        'origin_main_at_capture': 'dcd69393c783b7eba4b86fd525b24b2358461721',
        'baseline': 'pre-edit files captured from the shared live candidate; clean files recovered from HEAD',
        'files': {}}
for variant, root in [('main', repo), ('scoped', scoped)]:
    for rel in paths:
        data = (root / rel).read_bytes()
        pins['files'][f'{variant}:{rel}'] = hashlib.sha256(data).hexdigest()
(base / 'pins.json').write_text(json.dumps(pins, indent=2) + '\n')
(base / 'task-files.json').write_text(json.dumps({'owned_files': paths}, indent=2) + '\n')
