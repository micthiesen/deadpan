from pathlib import Path
import gzip,hashlib,json
s=Path(__file__).resolve().parent;repo=Path('/Users/michael/Code/deadpan')
dest=repo/'tools/media-qualification/evidence/2026-10-29-retained-owner-query-budget'
assert not dest.exists()
audit=json.loads((s/'final-audit.json').read_text());assert audit['all_terminal']
prior=repo/'tools/media-qualification/evidence/2026-10-29-owner-probe-budget/inventory.json'
prior_sha='b770e9973559582960bc5679011b22d8839bae5d3f19abe4f93e6c11df973070'
assert hashlib.sha256(prior.read_bytes()).hexdigest()==prior_sha
rows=[];allowed={'.rs','.json','.py','.md','.patch','.stdout','.stderr','.txt'}
for p in sorted(s.rglob('*')):
 if not p.is_file() or p.suffix not in allowed:continue
 data=p.read_bytes()
 if p.suffix=='.json':
  obj=json.loads(data)
  if isinstance(obj,dict) and 'command' in obj and 'started_at' in obj:
   assert 'exit_code' in obj and obj['sources_unchanged'] and obj['binaries_unchanged'],str(p)
 target=dest/'records/retained-owner-query'/p.relative_to(s);target=target.with_name(target.name+'.gz')
 target.parent.mkdir(parents=True,exist_ok=True);packed=gzip.compress(data,mtime=0);target.write_bytes(packed)
 rows.append({'path':str(target.relative_to(dest)),'bytes':len(packed),'sha256':hashlib.sha256(packed).hexdigest(),'expanded_bytes':len(data),'expanded_sha256':hashlib.sha256(data).hexdigest()})
manifest={'schema_version':1,'base_revision':(s/'base-revision.txt').read_text().strip(),'scope':'Actual retained-owner one-sample decision query admission, shared envelope/walker budget, initial retained origin and owned result; once-only Audio billing. Immutable full old observations; synthetic empty-support branch coverage is explicitly not a normal-document/Empty-provider witness. Negative compiler/test/lint, zero-test filters and unfinished Split receipts retained. Wide renderer queries, caller containers and complete recursive cold closure remain open. No cap/weight/refund/cache/cold/batch or native peak changes.','prior_probe_inventory':{'path':'../2026-10-29-owner-probe-budget/inventory.json','sha256':prior_sha},'files':rows}
p=dest/'inventory.json';p.write_text(json.dumps(manifest,indent=2)+'\n')
for row in rows:
 packed=(dest/row['path']).read_bytes();plain=gzip.decompress(packed)
 assert len(packed)==row['bytes'] and hashlib.sha256(packed).hexdigest()==row['sha256']
 assert len(plain)==row['expanded_bytes'] and hashlib.sha256(plain).hexdigest()==row['expanded_sha256']
print(json.dumps({'files':len(rows),'stored_bytes':sum(x['bytes'] for x in rows),'expanded_bytes':sum(x['expanded_bytes'] for x in rows),'inventory_sha256':hashlib.sha256(p.read_bytes()).hexdigest()}))
