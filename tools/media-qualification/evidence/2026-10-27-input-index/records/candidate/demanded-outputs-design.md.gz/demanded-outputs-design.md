# Required-output prefix execution: design and review gates

Read-only design, 2026-10-27. No source edits or Cargo. This is not an implementation proposal to revive the removed prefix cache. Current real-WAV failures remain unqualified.

## What the rejected implementation actually did

Source inspected: `/tmp/deadpan-prefix-reuse-2026-10-26/candidate.patch`, `candidate-untracked.tar`, `review-notes.json`, and final `full-split-second` streams. The archived final review records no remaining supported source finding after corrections, but runtime was3pass/4work-limit failures, with processed-root refinement regressing. The archive does not quantitatively attribute that regression to one overhead.

Archived `shared_eq/batched_tiles.rs` was still a scalar-prefix/cache design. For every256-frame input chunk it called read_shared_program for the requested voice, retained an owned all-route Prepared snapshot, then called cached_shared_prefix separately for each sibling. COHORT was4 and output histories were optional, later chunks exact-cache-hit-only. Dynamic/missing/evicted payloads discarded histories after work had already been spent. Required-memory failures could release optional histories and retry, preserving spent work. Corrected canonical EQ/wet callers did need every permitted cohort output at the same sample; merely renaming the cohort to a demand set is therefore not a new semantic distinction.

Archived `shared_components/prepared.rs` moved route PCM and final transfers into persistent-within-request payloads. `prefix_inputs.rs` retained payload headers, alias ordinals, dependencies and relative depth. Retained prefixes and sibling tiles competed with Original/prepared payloads in the same64-stage controller slot count and resident limit. Every cache hit had lookup, alias remix, depth and source re-admission work. Clocked sources also required conservative contextual-contract checks; a conservative source refusal dropped the cache hit and fell back to the ordinary path. Corrections addressed swallowed admission errors, dynamic later chunks, evictability, discarded allocations, output/workspace starvation and prepared-frame headroom. Those were real architectural costs, not evidence that provenance was impossible.

## Current duplicate execution

Current `shared_components/block.rs::finish_constant` processes each owner/stage over the admitted route buffers. Common saturation uses all permitted routes; EQ assigns each route a selected contribution from the complete jointly driven prefix. The wet path likewise asks for each route's wet contribution while preserving wet_allowed, send levels and permission masks. These are the exact locations where the caller knows which outputs it will consume.

The callback at `shared_eq.rs:622-640` currently resolves one shared_eq_node and calls shared_eq_tile with `(tile,permissions,voice)`. On a miss, `shared_eq_tile` (`:744-895`) reserves one input history, loops its complete halo in256-frame chunks and invokes read_shared_program with that selected voice. A second required voice repeats query construction and the complete shared component driver. Prefix computation depends on the input permission set, exact context and stop boundary; only terminal selection should differ for eligible targets.

PreparedTransfer.apply_wide's millions of applications are real nonidentity gain boundaries. Identity block transfers and unselected final passes are already removed. Moving gains across filters/nonlinear boundaries, aggregating outputs by subtraction, changing sum association, or simply dropping their charges is invalid.

## Materially different execution API

A new required-output path would execute each prefix chunk **once for an explicit set of missing outputs**, writing directly to borrowed slices of already-admitted caller input histories. It would not create Prepared snapshots, prefix cache entries, sibling caches, retained route PCM, generic cache keys, optional history fallback, or a new controller cache count. Existing per-node finished temporal tiles remain the only result cache.

Suggested narrow internal shape, not a generic callback framework:

- A required temporal demand identifies one existing node, tile, common input Permissions, common depth and an ordered deduplicated slice of target voice IDs.
- Each target has its own borrowed left/right input-history sink for the current256-frame chunk. No extra intermediate per-target WideBlock is needed before the final native tile outputs.
- read_shared_program_outputs_into constructs the current owners, sound queries, exact alias families, routes and raw inputs once, then runs one Components traversal. Components emits one route-ordered terminal sum per target into those sinks.
- Components' existing temporal callback must accept/fill a required output set at the point where finish_constant currently loops owner.members and invokes EQ/wet once per route. Returning one vector from the current scalar callback and then continuing per-target read_shared_program would retain the duplicate driver and would not be this design.
- Dynamic routes need either the same output-set scalar-sample driver (common owner state once per sample), or a decision to use the unchanged old scalar path before work starts. First-chunk constant eligibility cannot authorize later dynamic chunks. Do not infer whole-tile eligibility from one chunk.

This would remove actual repeated owner/occurrence queries and common transfer/saturation work for each successful output group. Each required native filter still processes its own input; those computations and prepared-frame charges remain. Final gain applications remain for every actually needed route, with the same channel order and finite checks. No numeric rounding/phase improvement is assumed.

## Output-specific state that must remain exact

Program.output_voice currently affects more than final summing:

1. selected_split_families uses `selected = allowed union output_voice`.
2. include_output_aliases computes one selected family's physical aliases.
3. SharedMix::separate is forced by selected output even without global automation/wet.
4. Program::prepare decides whether a route's final transfer is prepared.
5. The terminal route sum selects the target and its aliases.

Require every batched target to already belong to the **same common input Permissions mask**. Otherwise use the old scalar path. This makes the selected-family discovery input identical across eligible targets, while preserving its exact current context checks. Do not OR input masks from different consuming samples or share a saturator driven by their union.

Retain a separate output alias mask for each target. The union of those masks may decide which final route transfers are actually consumed, but it cannot become a single output selection. For each target, initialize zero and add selected route values in the original route order. Route-major iteration adding into independent target accumulators preserves each target's existing addition order. Do not derive one target from total-minus-others, merge different route clocks, or move gains into kernels.

Prepare/apply final transfers only for the union of routes used by the explicit required targets and their aliases. Driver-only routes still participate in common saturation/earlier stages but must not acquire an unused final gain failure. Dormant event_gain=None routes stay dormant; no speculative escalation or gain preparation. Duplicate requests for the same voice may share a computed value, but concrete output alias masks and source ownership must first be proved equal by the existing family machinery. Never choose outputs from all graph.voices.

The full original/current plan, raw Context, node parent, stop boundary, stable Repeat/gap identity and phase stay those of the existing node. Equal node IDs or equal AudioTreatmentBoundary affine clocks cannot establish raw-context equivalence; matches_clock_at explicitly says so. No owned-plan Arc identity shortcut is appropriate.

## Memory is the implementation gate

An N-output call still needs N independent full filter input histories. EQ histories are comparatively small; wet histories are192,000 or384,000 plus output width, in stereo-f64. Direct writes remove intermediate blocks and retained prefix payloads, but do **not** remove this simultaneous N*halo allocation. Baseline reserves one halo at a time. A naive N*current-reservation check ignores deeper recursion and can starve a later required native workspace or output allocation, reproducing the old retries/regressions.

Before doing any new prefix work or taking a filter from the node, the caller needs a reservation plan covering:

- all group input-history actual capacities and sink/target/alias headers;
- per-target dependencies and relative-depth state (or a proven identical shared dependency carrier with bounded final cloning);
- the one native filter/wet workspace used in existing per-target order;
- all required final output buffers/cache entries and their metadata;
- the maximum simultaneous recursive child prefix reservation, live queries, component buffers, projected workspaces and currently pinned result tiles.

No extra historical plans, current query graphs or route PCM may be retained across input chunks merely to make that plan easier. Construct/consume each current chunk's existing query data once as today.

Group only missing tiles from the explicit required set. Choose group size using existing residency/prepared-frame allowances and a proved recursive peak, not a new arbitrary cohort cap. The existing scalar path is group size1 and must remain available. An eligibility/capacity decision should be non-evicting and precede work, so opting out does not discard useful caches or replay spent work. Charge actual decision/graph-planning operations; never reset the canonical ledger on fallback.

**Unresolved proof question:** current graph construction is lazy, so its future recursive required workspace is not fully known at the call site. One cannot claim safe batching merely because N input arrays fit now. Options require a bounded preflight demand/allocation plan using the same exact structural queries, or a conservative recursive bound that still permits useful groups. If obtaining that plan requires retaining all future query graphs, it reintroduces the peak problem. Until a useful bound is demonstrated, keep runtime batching disabled rather than rely on catch-memory-error/retry. The old scalar path may be chosen before execution; after batch execution begins, budget/source/deadline/depth errors propagate with no rerun or refunds.

## Admission, work, depth and cancellation

A direct multi-output prefix read performs the normal static query/preflight and fresh source/context admission for its one exact common input. It cannot use cached PCM as source authority. Empty prepared sound carriers and fully masked dependencies remain admitted, including historical exact contracts through the existing with_plan_scope path. Each actually computed source input still resolves/observes fingerprints; each finished output retains its real dependencies and relative depth. Existing temporal cache-hit depth checks remain per requested output. Do not replace exact per-output depth with an unproved union maximum that can reject a valid shallower read.

All existing per-query65,536 limits and the16,777,216 aggregate work units remain. Returning each actual Plan work count and charging it once is proper only when the corresponding construction/query genuinely ran once. Each actual native output retains its prepared-frame contribution. Each256-frame chunk calls the same WorkControl.query_limits/spend/check boundaries; owner/sample loops and native processing preserve cancellation checks. The deadline is never renewed. Required-output errors propagate, with no optional InvalidSamples suppression. Preserve original required target order so filter processing and failure ordering do not become arbitrary.

## Review and verification questions before production integration

- Can the exact EQ/wet caller provide the complete currently required output set without speculative graph IDs, and keep each target in the common mask?
- Does one Components pass truly serve every sink, recursively, or does an adapter still invoke the scalar driver per output?
- Are output-specific family masks, final transfer selection and route-order additions byte-for-byte equivalent to separate old calls, including signed zeros and gain overflow on used versus unused routes?
- What proves recursive peak before work begins? What exact bytes/capacities are charged, and can group-size1 preserve the old required allocation path without a failed batch replay?
- Does a later dynamic chunk select the old scalar driver before work, or have a proved multi-output dynamic implementation?
- Are source revocation, historical contract refusal, empty/currently absent sounds, source exhaustion, silent Holds, Repeat gaps and Split aliases all handled through normal admission rather than a new shortcut?
- Do tests compare required outputs against independent scalar calls over EQ/wet, nonlinear cancellation, different route clocks/permissions and fractional histories, with exact/one-less work and residency boundaries and cancellation between chunks?

Start with a pure Components multi-output oracle and exact accounting proof, not a full cache prototype. Only enable a graph/tile caller after its recursive reservation plan is reviewable. The existing full real-WAV matrix remains the acceptance test; library tests and reduced charged work alone close no product requirement.
