from pathlib import Path
import json, subprocess, sys
s=Path(__file__).resolve().parent
p=Path('/tmp/deadpan-input-index-profile-2026-10-27')
assert json.loads((s/'definitions.json').read_text())['exit_code']==0
assert json.loads((p/'build.json').read_text())['exit_code']==0
b=str(p/'profile-stages')
jobs=[
 ('profile-allowner',[sys.executable,str(p/'runner.py'),'--binary',b,'allowner','--',b,'--exact','general_split_sound::all_owner_kinds_keep_full_sound_pcm_after_split_and_refinement_with_prior_clocks','--nocapture','--test-threads=1']),
 ('profile-analysis',[sys.executable,str(p/'analyze.py'),'allowner']),
 ('remaining-split',[sys.executable,str(s/'run.py'),'--binary',str(s/'stages'),'remaining-split','--',str(s/'stages'),'general_split_sound::','--skip','general_split_sound::all_owner_kinds_keep_full_sound_pcm_after_split_and_refinement_with_prior_clocks','--nocapture','--test-threads=1']),
]
results=[]
for label,command in jobs:
 print(json.dumps({'starting':label}),flush=True)
 if label=='profile-analysis':
  with (s/'profile-analysis.stdout').open('xb') as out:
   code=subprocess.call(command,stdout=out)
 else:
  code=subprocess.call(command)
 results.append({'label':label,'exit_code':code})
 (s/'next-results.json').write_text(json.dumps(results,indent=2)+'\n')
 if label=='profile-analysis' and code:raise SystemExit(code)
raise SystemExit(any(row['exit_code'] not in [0,101] for row in results))
