from pathlib import Path
import gzip, hashlib, json
s=Path(__file__).resolve().parent
p=Path('/tmp/deadpan-input-index-profile-2026-10-27')
dest=Path('/Users/michael/Code/deadpan/tools/media-qualification/evidence/2026-10-27-input-index')
assert not dest.exists(), 'refuse evidence overwrite'
for root,labels in [(s,['build','audio-lib','strict','allowner','definitions','remaining-split']), (p,['build','allowner'])]:
 for label in labels:
  r=json.loads((root/(label+'.json')).read_text())
  assert 'exit_code' in r and r['sources_unchanged'] and r['binaries_unchanged']
dest.mkdir(parents=True)
files=[]
for prefix,root in [('candidate',s),('profile',p)]:
 for path in sorted(root.iterdir()):
  if not path.is_file() or path.suffix not in {'.json','.py','.md','.patch','.rs','.before','.stdout','.stderr'}:continue
  data=path.read_bytes();compressed=gzip.compress(data,mtime=0)
  out=dest/'records'/prefix/(path.name+'.gz');out.parent.mkdir(parents=True,exist_ok=True);out.write_bytes(compressed)
  files.append(dict(path=str(out.relative_to(dest)),bytes=len(compressed),sha256=hashlib.sha256(compressed).hexdigest(),expanded_bytes=len(data),expanded_sha256=hashlib.sha256(data).hexdigest()))
inventory=dict(schema_version=1,base_revision='cf796605',scope='Uncommitted general-Split WIP: replace existing64-slot Original-input sorted index with intrusive buckets, preserving source/clock/PCM/LRU authority. Independent review and202 Audio/171 definition/strict pass; unchanged seven Split tests across two source-stable invocations remain4pass3work failures. Two-file exact patch/before-files and separate copied-runtime attribution retained. No product acceptance credit and no runtime diagnostic code in main.',runtime_baseline_evidence=dict(path='../2026-10-27-work-attribution/inventory.json',inventory_sha256='7f30a780fe7c4f0d335a90dd4e89a6bc7a1f117814fbf0573a0e4d9c4b24ed99',note='Baseline copy/input identities and exact diagnostic patch. This inventory retains index delta and second-copy lineage; no redundant source tree/executable archive.'),files=files)
out=dest/'inventory.json';out.write_text(json.dumps(inventory,indent=2)+'\n')
for row in files:
 data=(dest/row['path']).read_bytes();expanded=gzip.decompress(data)
 assert len(data)==row['bytes'] and hashlib.sha256(data).hexdigest()==row['sha256']
 assert len(expanded)==row['expanded_bytes'] and hashlib.sha256(expanded).hexdigest()==row['expanded_sha256']
print(json.dumps(dict(payloads=len(files),stored_bytes=sum(r['bytes'] for r in files),expanded_bytes=sum(r['expanded_bytes'] for r in files),inventory_sha256=hashlib.sha256(out.read_bytes()).hexdigest()),indent=2))
