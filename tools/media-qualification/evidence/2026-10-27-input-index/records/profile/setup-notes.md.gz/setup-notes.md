# Second diagnostic copy, frozen

This copy is derived from the immutable placement-profile source, not from a Git checkout or a fresh main-tree copy. `copy_runtime.py` verifies all5,279 prior profile inputs, copies that source excluding only anchored build-output target directories, then overlays precisely:

- crates/deadpan-audio/src/shared_eq/original_inputs.rs
- crates/deadpan-audio/src/shared_eq/original_inputs_tests.rs

Both overlays come byte-for-byte from the current frozen main candidate. Main's1,395 guarded inputs match `/tmp/deadpan-input-index-2026-10-27/build.json` source_before. All other1,393 guarded inputs equal the previous candidate baseline. All other5,277 copied profile files equal the published prior profile bytes. Main and the previous profile were hash-verified unchanged across this operation.

`profile-input-pins.json` pins all5,279 new diagnostic inputs. `base-input-pins.json` is the corresponding latest candidate without diagnostics. Their only difference is copied stages.rs. `diagnostic.patch`, `stages.before.rs`, reconstructed baseline and line mappings are byte-identical copies of the prior audited diagnostic overlay. Stripping that overlay from the new copy recovers current main stages.rs exactly. No diagnostic code, real charge, source admission, read boundaries, quotas or cancellation/deadline behavior was changed for the index experiment.

`lineage.json` records before/after relationships, exact overlay pins, new manifest pins, the main build-receipt hash and unchanged parent-profile manifest. `parent-profile-input-pins.json` preserves the previous profile's exact manifest, and `guarded-baseline.json` records the latest1,395 runtime baseline pins. Removed prototype paths remain absent. The prior profile source and published evidence are untouched.

Parent owns runner/build/pin/analyzer and the fresh target at `/tmp/deadpan-input-index-profile-2026-10-27/target`. Suggested sole build remains `cargo test --locked -p deadpan-audio --test stages --no-run --message-format=json` from copied source with the existing qualified prefixes and opt-level2/incremental0 settings. Execute only pinned compiler-reported stage binaries. This setup agent ran no Cargo, compiler or tests and claims no new runtime attribution or acceptance result.
