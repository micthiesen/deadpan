#!/usr/bin/env python3
"""Guard the copied diagnostic inputs and retain one exact invocation."""
import argparse
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import subprocess
import time

SCRATCH = Path(__file__).resolve().parent
ROOT = SCRATCH / 'source'
MANIFEST = SCRATCH / 'profile-input-pins.json'


def pin(path):
    data = path.read_bytes()
    return {'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}


def pins(paths):
    return {str(path): pin(path) for path in paths}


parser = argparse.ArgumentParser()
parser.add_argument('--binary', action='append', default=[])
parser.add_argument('label')
parser.add_argument('command', nargs=argparse.REMAINDER)
args = parser.parse_args()
command = args.command
if command and command[0] == '--':
    command = command[1:]
assert command and args.label.replace('-', '').isalnum()
receipt = SCRATCH / f'{args.label}.json'
assert not receipt.exists(), 'refuse receipt overwrite'
expected = json.loads(MANIFEST.read_text())
sources = [ROOT / path for path in expected]
binaries = [Path(path) for path in args.binary]
removed = json.loads((SCRATCH / 'removed-files.json').read_text())
assert all(not (ROOT / path).exists() for path in removed)
before = pins(sources)
assert before == {str(ROOT / path): row for path, row in expected.items()}
environment = dict(os.environ)
environment.update({
    'DEADPAN_FFMPEG_PREFIX': '/Users/michael/Library/Developer/Deadpan/ffmpeg-8.0.3-opus-1.6.1-dav1d-1.5.4-qualified-3/prefix',
    'DEADPAN_ORT_PREFIX': '/Users/michael/Library/Developer/Deadpan/onnxruntime-1.31.0-qualified-1/prefix',
    'CARGO_TARGET_DIR': str(SCRATCH / 'target'),
    'DEADPAN_REQUIRE_PHYSICAL_MAC': '1',
    'CARGO_PROFILE_DEV_OPT_LEVEL': '2',
    'CARGO_INCREMENTAL': '0',
})
keys = (
    'DEADPAN_FFMPEG_PREFIX', 'DEADPAN_ORT_PREFIX', 'CARGO_TARGET_DIR',
    'DEADPAN_REQUIRE_PHYSICAL_MAC', 'CARGO_PROFILE_DEV_OPT_LEVEL',
    'CARGO_PROFILE_TEST_OPT_LEVEL', 'CARGO_INCREMENTAL', 'RUSTFLAGS',
    'CARGO_ENCODED_RUSTFLAGS', 'RUSTDOCFLAGS', 'CC', 'CXX', 'CFLAGS',
    'CXXFLAGS', 'LDFLAGS', 'SDKROOT', 'MACOSX_DEPLOYMENT_TARGET',
    'DEADPAN_MEDIA_WORKER', 'DEADPAN_PREVIEW_EXPORT_KEEP',
    'DEADPAN_ALIGN_REFERENCE_ROOT', 'DEADPAN_ALIGN_CHECKPOINT',
    'DEADPAN_ALIGN_STATISTICS', 'DEADPAN_ALIGN_PARITY_OUTPUT',
    'DEADPAN_ALIGN_OBSERVED_OUTPUT', 'DEADPAN_ALIGN_TEST_WORKER',
    'DEADPAN_ALIGN_MODEL_ROOT',
)
record = {
    'started_at': datetime.now(timezone.utc).isoformat(),
    'cwd': str(ROOT), 'command': command,
    'environment': {key: environment[key] for key in keys if key in environment},
    'cargo_config': (ROOT / '.cargo/config.toml').read_text(),
    'input_manifest': pin(MANIFEST), 'runner': pin(Path(__file__)),
    'source_before': before, 'binary_before': pins(binaries),
    'removed_paths_absent_before': removed,
}
receipt.write_text(json.dumps(record, indent=2) + '\n')
start = time.monotonic()
with (SCRATCH / f'{args.label}.stdout').open('xb') as stdout:
    with (SCRATCH / f'{args.label}.stderr').open('xb') as stderr:
        process = subprocess.Popen(command, cwd=ROOT, env=environment,
                                   stdout=stdout, stderr=stderr)
        record['pid'] = process.pid
        receipt.write_text(json.dumps(record, indent=2) + '\n')
        code = process.wait()
record.update({
    'exit_code': code, 'seconds': time.monotonic() - start,
    'finished_at': datetime.now(timezone.utc).isoformat(),
    'source_after': pins(sources), 'binary_after': pins(binaries),
})
record['sources_unchanged'] = record['source_before'] == record['source_after']
record['binaries_unchanged'] = record['binary_before'] == record['binary_after']
record['removed_paths_absent_after'] = [p for p in removed if not (ROOT / p).exists()]
record['streams'] = pins([SCRATCH / f'{args.label}.stdout', SCRATCH / f'{args.label}.stderr'])
receipt.write_text(json.dumps(record, indent=2) + '\n')
assert record['sources_unchanged'] and record['binaries_unchanged']
assert record['removed_paths_absent_after'] == removed
print(json.dumps({key: record[key] for key in (
    'exit_code', 'seconds', 'sources_unchanged', 'binaries_unchanged')}), flush=True)
raise SystemExit(code)
