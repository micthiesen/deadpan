from pathlib import Path
import hashlib,json,subprocess,shutil,time
from datetime import datetime,timezone
MAIN=Path('/Users/michael/Code/deadpan')
PARENT=Path('/tmp/deadpan-placement-profile-2026-10-27')
S=Path('/tmp/deadpan-input-index-profile-2026-10-27');SOURCE=S/'source'
BUILD=Path('/tmp/deadpan-input-index-2026-10-27/build.json')
OWNED=['crates/deadpan-audio/src/shared_eq/original_inputs.rs','crates/deadpan-audio/src/shared_eq/original_inputs_tests.rs']
STAGES='crates/deadpan-audio/src/stages.rs'
assert not SOURCE.exists(),'refuse to overwrite a source copy'
def pin(p):
 b=p.read_bytes();return {'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def allpins(root):return {str(p.relative_to(root)):pin(p) for p in sorted(root.rglob('*')) if p.is_file()}
parent_expected=json.loads((PARENT/'profile-input-pins.json').read_text())
parent_before=allpins(PARENT/'source');assert parent_before==parent_expected,'old profile source changed'
assert len(parent_before)==5279
build=json.loads(BUILD.read_text());assert build['exit_code']==0 and build['sources_unchanged']
assert len(build['source_before'])==1395
main_expected={str(Path(name).relative_to(MAIN)):row for name,row in build['source_before'].items()}
main_before={name:pin(MAIN/name) for name in main_expected};assert main_before==main_expected
old_guarded=json.loads((PARENT/'guarded-baseline.json').read_text());assert set(old_guarded)==set(main_before)
main_delta=[name for name in main_before if main_before[name]!=old_guarded[name]]
assert sorted(main_delta)==sorted(OWNED),(main_delta,'main candidate differs outside two index files')
command=['rsync','-a','--exclude=/target/','--exclude=/fuzz/target/',str(PARENT/'source')+'/',str(SOURCE)+'/']
started=datetime.now(timezone.utc).isoformat();start=time.monotonic();subprocess.run(command,check=True)
assert allpins(SOURCE)==parent_expected,'unmodified profile clone mismatch'
for name in OWNED:shutil.copy2(MAIN/name,SOURCE/name)
profile=allpins(SOURCE)
assert set(profile)==set(parent_expected)
profile_delta=[name for name in profile if profile[name]!=parent_expected[name]]
assert sorted(profile_delta)==sorted(OWNED),profile_delta
assert profile[STAGES]==parent_expected[STAGES]
# New uninstrumented baseline is the latest candidate, with precisely the same
# stages overlay as the parent profile. Baseline-only larger copied docs are
# held fixed from that parent; the guarded runtime files all match current main.
base=dict(profile);base[STAGES]=pin(PARENT/'stages.before.rs')
assert [name for name in profile if profile[name]!=base[name]]==[STAGES]
for name,row in main_before.items():assert base[name]==row, name
main_after={name:pin(MAIN/name) for name in main_expected};assert main_after==main_before
parent_after=allpins(PARENT/'source');assert parent_after==parent_before
removed=json.loads((PARENT/'removed-files.json').read_text());assert all(not (SOURCE/name).exists() for name in removed)
for filename in ['diagnostic.patch','stages.before.rs','stages.reconstructed-baseline.rs','stages-line-map.json']:
 shutil.copy2(PARENT/filename,S/filename)
(S/'base-input-pins.json').write_text(json.dumps(base,indent=2)+'\n')
(S/'profile-input-pins.json').write_text(json.dumps(profile,indent=2)+'\n')
(S/'guarded-baseline.json').write_text(json.dumps(main_before,indent=2)+'\n')
(S/'removed-files.json').write_text(json.dumps(removed,indent=2)+'\n')
shutil.copy2(PARENT/'profile-input-pins.json',S/'parent-profile-input-pins.json')
# Undo only the previously audited stages overlay and prove exact candidate bytes.
old=(S/'stages.before.rs').read_text();new=(SOURCE/STAGES).read_text()
a=new.index('// Diagnostic-only copied-runtime instrumentation.');b=new.index('const MAX_PLAN_WORK_PER_READ:',a)
stripped=new[:a]+new[b:];stripped=stripped.replace('    work_trace: PlanWorkTrace,\n','',1)
a=stripped.index('    #[track_caller]\n    fn spend_plan_work(');b=stripped.index('    fn query_limits(',a)
x=old.index('    fn spend_plan_work(');y=old.index('    fn query_limits(',x)
stripped=stripped[:a]+old[x:y]+stripped[b:]
assert stripped.encode()==(MAIN/STAGES).read_bytes(),'diagnostic overlay no longer strips to candidate stages'
record={'started_at':started,'finished_at':datetime.now(timezone.utc).isoformat(),'seconds':time.monotonic()-start,'command':command,'parent_profile':str(PARENT),'parent_profile_manifest_pin':pin(PARENT/'profile-input-pins.json'),'parent_source_unchanged':parent_before==parent_after,'parent_profile_input_count':len(parent_before),'main_build_receipt':str(BUILD),'main_build_receipt_pin':pin(BUILD),'main_guarded_count':len(main_before),'main_guarded_unchanged':main_before==main_after,'main_changed_vs_previous_guarded_baseline':main_delta,'overlay_from_main':{name:main_before[name] for name in OWNED},'new_profile_changes_vs_previous_profile':profile_delta,'all_other_5277_profile_inputs_identical':len(profile_delta)==2,'new_profile_input_count':len(profile),'new_baseline_diagnostic_delta':[STAGES],'same_stage_diagnostic_overlay':True,'stripped_stage_matches_latest_candidate':True,'no_cargo':True,'no_main_or_parent_source_edits':True,'profile_input_manifest_pin':pin(S/'profile-input-pins.json'),'base_input_manifest_pin':pin(S/'base-input-pins.json'),'diagnostic_patch_pin':pin(S/'diagnostic.patch'),'removed_paths_absent':removed}
(S/'lineage.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps({k:record[k] for k in ['main_guarded_count','main_guarded_unchanged','parent_source_unchanged','new_profile_changes_vs_previous_profile','new_profile_input_count','same_stage_diagnostic_overlay']}))
