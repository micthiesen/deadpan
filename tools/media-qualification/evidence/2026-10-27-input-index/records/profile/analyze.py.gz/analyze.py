"""Reconcile diagnostic counters; never count a refused charge as accepted."""
from pathlib import Path
import argparse
import json

s = Path(__file__).resolve().parent
parser = argparse.ArgumentParser()
parser.add_argument('label')
args = parser.parse_args()
receipt = json.loads((s / f'{args.label}.json').read_text())
assert 'exit_code' in receipt and receipt['sources_unchanged'] and receipt['binaries_unchanged']
stderr = (s / f'{args.label}.stderr').read_text()
groups = {}
for line in stderr.splitlines():
    at = line.find('AUDIO_WORK_PROFILE_')
    if at < 0:
        continue
    fields = line[at:].split()
    kind = fields[0].removeprefix('AUDIO_WORK_PROFILE_')
    row = dict(field.split('=', 1) for field in fields[1:])
    for key, value in row.items():
        if value in ('true', 'false'):
            row[key] = value == 'true'
        elif value.isdecimal():
            row[key] = int(value)
    group = groups.setdefault(row['id'], {'sites': [], 'categories': [], 'refusals': []})
    if kind == 'BEGIN':
        assert 'header' not in group
        group['header'] = row
    elif kind == 'END':
        assert 'end' not in group
        group['end'] = row
    else:
        group[{'SITE': 'sites', 'CATEGORY': 'categories', 'REFUSAL': 'refusals'}[kind]].append(row)

for group in groups.values():
    header, end = group['header'], group['end']
    assert header['version'] == 1
    assert header['reconciled'] and header['exact_sites'] and not header['counter_overflow']
    assert header['canonical'] <= 16_777_216 and header['optional'] <= 16_777_216
    assert len(group['categories']) == 2
    for cache, name in ((False, 'canonical'), (True, 'optional')):
        category = next(row for row in group['categories'] if row['cache'] == cache)
        total = sum(row['units'] for row in group['sites'] if row['cache'] == cache)
        assert category['overflow_calls'] == 0 and category['overflow_units'] == 0
        assert total + category['overflow_units'] == header[name] == end[f'{name}_sum']
        for row in group['sites']:
            if row['cache'] == cache:
                row['fraction_of_category'] = row['units'] / total if total else 0
    group['sites'].sort(key=lambda row: (row['cache'], -row['units'], row['file'], row['line']))
    for row in group['sites']:
        path = s / 'source' / row['file']
        if path.is_file():
            row['source_line'] = path.read_text().splitlines()[row['line'] - 1].strip()

result = {
    'label': args.label, 'exit_code': receipt['exit_code'],
    'seconds': receipt['seconds'], 'summaries': list(groups.values()),
    'diagnostic_only': True,
    'limitations': [
        'Accepted returned work at spend sites only; no partial work from failing child queries.',
        'Near-limit-final-summary does not establish a failure without fixture outcome.',
        'Instrumented timing and heap are not product qualification measurements.',
    ],
}
out = s / f'{args.label}-analysis.json'
assert not out.exists()
out.write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({
    'label': args.label, 'exit_code': receipt['exit_code'], 'seconds': receipt['seconds'],
    'summaries': [{
        'header': g['header'], 'refusals': g['refusals'],
        'top_canonical': [r for r in g['sites'] if not r['cache']][:12],
    } for g in groups.values()],
}, indent=2))
