# Bounded GroupSelection sound transport design

The current reducer already has the necessary Original-audio capture and passes the sound Split context through both endpoints. No new timing merge helper or schema is needed. Make GroupSelection enter the existing outer sound transport only when its exact preflight requires endpoint Splits; retain aligned grouping's current path byte for byte.

## Precise changes

1. In sound_events.rs::validate_group_ownership remove only the GroupSelection blanket nonempty-BeatSound/required_split_ids refusal. Still run group_selection preflight, and retain the ancestry check rejecting changes inside any existing journal scope. Preserve Ungroup-own-sounds and root-owned-attachment restrictions.

2. In sound_clock/edit.rs::timing add GroupSelection's existing timing. In SoundClockEditCapture::prepare, before capture_timing/allocation checks and before cloning or pruning anything, special-case GroupSelection: use document.group_selection(parent, selection), and return Ok(None) when required_split_ids == 0. Do not infer from selection kind or nonempty supplied identities: use exact authoritative preflight. This makes transports classify the command while only actual endpoint work captures sounds. GroupSelection is already in preserves_sound_clocks; keep that classification for root-event behavior and aligned groups.

3. Leave command.rs's generic prepare/detach/restore orchestration intact. It already supplies EditContext.sound_clocks to group_selection::apply and restores RootSoundEditCapture before BeatSound clocks. GroupSelection goes through the existing arm at command.rs:1540. An explanatory comment at that arm or in group_selection::apply is enough; do not add a second capture, second allocation or post-hoc transplant.

4. Leave group_selection.rs::apply's required_split_ids branch intact: capture_unbound_audio_bindings(document, timing.clone()) is a COMPLETE capture, not capture_for_insertion_scoped. Then split_prepared uses the same timing state and passes EditContext through split.rs::apply. SoundClockEditCapture::split receives each exact copied-node map. Both endpoint refinements therefore retain the same pre-edit Original lattice while collecting independent owner aliases.

## Why timing sharing is already safe

- Outer SoundClockEditCapture::prepare captures the complete original FrozenAudioLayout before detach. It retains prior sound-only layouts privately.
- detach removes BeatSound recipes/journals and prunes unused binding tables. It does not alter the structural inputs of FrozenAudioLayout::capture: root/rate, frozen nodes/durations, overrides, audio lineage and derived clocks (audio_reference.rs:508-556).
- GroupSelection's capture_unbound_audio_bindings calls capture(..., retain_timing=false), with LayoutScope=None (audio_binding_lifecycle.rs:248-260). Therefore even a surrounding command-work setting cannot make this capture provisional. Unlike InsertTime, no with_scoped_timing_captures wrapper is needed.
- If unbound Original recipes exist, that capture installs the same complete pre-edit layout under GroupSelection's timing. Sound restore's install_layout compares exact equality and reuses it, refusing any mismatch.
- If every Original recipe is already bound, capture returns the current binding state without consuming GroupSelection's timing. Sound restore installs its complete layout when adding the new crop reference.
- Existing Original bindings retain their old timing identities. Existing sound journals retain their chronological identities. The new sound crop references use the one GroupSelection timing; no second ordinal is required.
- command.rs later prunes/compacts only after sound restoration. compact_new_timings explicitly includes sound journal references, preventing a sound-referenced complete table from losing its independent owner aliases.

No-Split GroupSelection must return before the outer sound capture. Otherwise detach/prune can remove sound-only tables and unclocked sounds can gain unnecessary placement state or a broader top-branch scope, violating the existing exact-equality control.

## Public oracle and first checks

The scratch sound_group_endpoints_counterfactual.rs is suitable: Source and Hold fixtures both have owner-local finite offset sound, independent event/owner EQ, existing prefix journal, root outside the owner scope, and literal [5,11) endpoints requiring exactly five IDs. Its plain Split and aligned GroupSelection controls establish existing positive behavior before the old blanket guard fails. Candidate must reach the postconditions: unchanged 17-frame extent, six-frame group, three complete-owner sound aliases, serializable state and exact inverse bytes.

Extend after the frozen old-code failure, without weakening the oracle:

- Assert every surviving alias preserves its prefix reference first and adds one endpoints timing reference with the exact original owner/scope; three aliases must not produce three separately captured clocks.
- Add fully bound versus newly unbound Original recipes and inspect the shared timing table, not only owner counts. The public prefix fixture leaves the new prefix Hold unbound and already exercises one shared-table creation case.
- Preserve aligned GroupSelection's exact audio_bindings/beat_sounds control for both fresh and clocked events, including unrelated root-owned attachments if that aligned path currently works.
- Keep clocked grouping inside top scope negative. Existing selected_groups_still_refuse_partial_sound_owners_with_or_without_clocks needs splitting: its unclocked case should now succeed, while the clocked case must still fail at the separate retained-scope guard (its old message assertion becomes stale).
- Verify full canonical PCM, both seams and terminal sample with Original plus independent event/shared EQ, cold reads and nonaligned partitions. Later GroupSelection wrapper movement/copy/reopen and root SoundEvent coexistence are downstream checks of this existing lifecycle, not new clock semantics.

## Risks

- Do not remove the second retained-scope ancestry guard just to make the existing combined negative test pass.
- Split replication can exceed the shared 64-event limit; preserve SoundClockEditCapture::split's bounded failure and atomicity.
- Never recapture after the first endpoint: it would turn the second fragment's current allocation into its historical source clock.
- Never replace Original audio bindings with sound journals or rewrite prior references to the new timing. AudioSourceOccurrence and BeatSoundOwnerInput already consume these independent histories.
- No runtime or compile checks were run for this design; root owns all verification. Repository was read only.
