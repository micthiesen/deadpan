from pathlib import Path
import json,hashlib
s=Path('/tmp/deadpan-sound-group-endpoints-2026-10-22')
labels=['Sound endpoint group with intact picture and key teaching at 960x640','Sound endpoint group breadcrumb and parent key at 960x640']
rows=[]
for mode in ['debug-first-visual','release-visual']:
 report=json.loads((s/mode/'report.json').read_text())
 scenario=next(x for x in report['scenarios']if x['name']=='sound-group-endpoints')
 for label in labels:
  step=next(x for x in scenario['steps']if x['input']==label)
  p=s/mode/step['screenshot']
  rows.append({'mode':mode,'file':p.name,'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'checkpoint':label,'frame':step['frame']})
(s/'selected-captures.json').write_text(json.dumps(rows,indent=2)+'\n')
print(json.dumps(rows))
