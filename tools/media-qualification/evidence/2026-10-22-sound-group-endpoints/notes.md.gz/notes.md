# Public Core endpoint-grouping failure oracle draft

Prepared as scratch only. **Not compiled or executed. No verification claim.**
No repository files, Git state, Cargo outputs, formatters, helpers, or worktrees
were changed by this subtask.

## Files

- `sound_group_endpoints_counterfactual.rs`: self-contained draft integration
  test using only public `deadpan_core` and `serde_json` APIs.
- `qualified-asset-metadata.json`: exact existing AssetRecord and extraction
  provenance, read from the real portable fixture's SQLite database in
  `mode=ro`. Its SHA-256 is
  `f65d79635a72771faacac4e198c2bdf343dfa39e4724151dcb44d8c9af212bd7`.

The actual cfr-bframes asset id is
`5ced4d7d-272f-46f0-a901-b0c82f67fd2b`, content is
`blake3:16614ec12d06396d3c0f0e7b91cc902c6dc30ad89c28d74b805cf64dc60d8aa1`,
and the existing receipt is
`c6bc3e81ab69906267164469d11739cf1363eea546436761ddd219069ed496b6`.
The draft copies that complete AssetRecord unchanged. There is no invented
qualification token. No decoding, new host admission, PCM rendering, or new
media qualification happens in this pure Core test.

## Fixture and scope

Two independent tests run the same witness with a Hold or a Source owner.
Each graph and its event/treatment choices are explicitly synthetic authored
recipes over the actual asset metadata.

Initial ordinary root children: `lead` (2 frames), `owner` (12 frames), `tail`
(2 frames). The owner has its own EQ `[3000,-1500,1000]` millidecibels.
Its independent `effect` event uses source samples `[0,16016)`, an exact
natural duration of ten frames at 30000/1001, offset `+37` samples, separate
EQ `[6000,-6000,3000]`, Hard start/end edges, and Reject overflow.

The Source variant also owns original audio samples `[0,16016)` with its
exact natural mapping and zero offset, and twelve pictures covering
`[0,12012)` ticks at time base 1/30000. That independently exercises the
physical Source binding path alongside the attached sound path. The Hold
variant has Background picture and Silence audio.

A public `InsertTime` of one silent frame at zero creates the existing clock
journal. Its caller-owned timing is `prefix:0`; the journal scope and prior
reference scope/owner are all `owner`. Afterward owner is a direct root child
at `[3,15)`, total project duration is 17 frames, and the grouping parent
`root` is outside the retained scope. The draft asserts this explicitly.
It never constructs a journal or timing table through a private state bypass.

Origin-based exact sample boundaries are independently asserted:
`B(3)=4805`, `B(5)=8008`, `B(11)=17618`, `B(17)=27227`.
Consecutive frame increments differ: `B(3)-B(2)=1602`,
`B(4)-B(3)=1601`. No repeatedly rounded per-frame accumulation is used.

## Controls before the intended old-code failure

1. Public plain `Split owner at 4` on that journaled state, with exact supplied
   nodes `plain-left`, `plain-right`, `plain-owner-copy`. It must preserve
   duration and complete sound recipes, create two sound aliases, retain the
   prior journal reference and append `plain-split:0`. The forward/inverse
   control requires byte-identical serialized restoration, not only structural
   equality.
2. Public aligned `GroupSelection` selecting child `owner` under `root`.
   Public preflight must request zero split identities. It must keep sound
   recipes and all audio bindings/timing tables identical. A public Ungroup
   must restore nodes, sounds and bindings exactly. Each control also checks
   wire roundtrip and inverse serialization.

Controls run independently from the same journaled document. Each emits an
explicit `CONTROL ... passed` line only after its assertions finish.

## Desired acceptance and exact old-code outcome

The final `GroupSelection` names root and selects strict absolute `[5,11)`.
Both endpoints lie inside owner. Public preflight should request exactly five
Split IDs: one leaf Split (three IDs), then its right-partition refinement
(two IDs). Allocation is explicit and deterministic:
`endpoints-group`, `endpoints-split-0` through `endpoints-split-4`, timing
`endpoints:0`, new revision `endpoints`.

On the current implementation, the desired acceptance assertion must fail
after the positive controls. A preceding diagnostic assertion requires any
error to be `EditErrorCode::InvalidCommand` with the exact message:

> group endpoint splits cannot yet preserve beat-owned sound clocks

An earlier fixture/admission error, different refusal, compile failure, or
failed positive control is not the intended counterfactual outcome.

The final assertion asks for success. On a candidate that accepts the command,
the reachable follow-up checks require total duration 17, group duration 6,
three complete unchanged BeatSound recipes, exact inverse bytes and document
roundtrip. This is a structural oracle only; later sound PCM, plan, Store,
CLI/native, durable reopen and real MP4 checks remain necessary.

## Public APIs checked in source, not by compilation

- `ProjectDocument::{new,from_json,to_json,group_selection,source_splice_boundary,
  node_duration,duration,root,nodes,beat_sounds,audio_bindings}`.
- `Command::{InsertTime,Split,GroupSelection,Ungroup}`, `CommandRequest`,
  public `apply`, transaction `.forward.apply` and `.inverse.apply`.
- `BeatNode::{hold,sequence}` and public `kind`, `label`, `audio_treatments`;
  `SourceNode`, `BeatSound`, `SourceAudioMapping::natural_rate`,
  `AudioTreatments::with_equalizer`, `EqualizerRecipe::new`.
- `GroupSelectionPlan::{range,required_split_ids}`,
  `GroupSelectionIdentities`, `SplitIdentities`, `AudioTimingId`.
- `AudioBindingState::sound_clocks`, journal `.scope/.clocks`, reference
  `.scope/.owner/.timing`, public `EditError::{code,message}`.
- `ExactRatio::{new,integer,round_even}` and checked integer conversion.

The test uses the crate's existing dev dependency `serde_json` and no feature
gates or other integration-test fixture module. Cargo's normal automatic
integration-test discovery should find it when copied to
`crates/deadpan-core/tests/sound_group_endpoints_counterfactual.rs` in the
root-owned frozen baseline source copy.

## Compilation/runtime questions for root's frozen baseline run

No known unresolved API type mismatch remains after source inspection.
Unexecuted runtime assumptions to validate before accepting an oracle:

- `from_json` populates ordinary derived lineage for the synthetic graph, as
  established public fixtures do.
- Prefix transport scopes this direct owner exactly to `owner` for both
  variants, and plain Split preserves the complete prior reference unchanged.
- The Source's twelve-frame picture allocation and natural ten-frame audio
  mapping are admitted without an explicit common edit window.
- The endpoint plan requests five IDs with the owner's EQ present.

If a control fails, repair the draft fixture or its expectation while retaining
the failed attempt, then rerun before changing production code. Do not weaken
admission or count a setup failure as the intended old-code refusal.

The separate existing refusal for grouping inside a retained processing scope
must remain and should keep its own production regression. This oracle's
grouping parent is deliberately outside that scope.
