from pathlib import Path
import subprocess,hashlib,json,shutil,os,time
s=Path('/tmp/deadpan-sound-group-endpoints-2026-10-22')
env=dict(os.environ,DEADPAN_FFMPEG_PREFIX='/Users/michael/Library/Developer/Deadpan/ffmpeg-8.0.3-opus-1.6.1-dav1d-1.5.4-qualified-3/prefix',CARGO_PROFILE_DEV_OPT_LEVEL='2',DEADPAN_REQUIRE_PHYSICAL_MAC='1',DEADPAN_REQUIRE_SYNTHETIC_WORKER='1')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def run(name,args,extra=None):
 start=time.monotonic()
 with (s/(name+'.log')).open('w')as log:r=subprocess.run(args,stdout=log,stderr=subprocess.STDOUT,env=dict(env,**(extra or {})))
 row={'command':args,'exit':r.returncode,'seconds':time.monotonic()-start}
 (s/(name+'-receipt.json')).write_text(json.dumps(row,indent=2)+'\n');print(name,json.dumps(row),flush=True)
 if r.returncode:raise SystemExit(r.returncode)
def guard():subprocess.run(['python',str(s/'guard.py'),'release-final'],env=env,check=True)
for name in ['strict-passed-check','strict-passed-ui-clippy','strict-passed-format']:
 assert json.loads((s/(name+'-receipt.json')).read_text())['exit']==0
assert json.loads((s/'ui-complete-final-result.json').read_text())['exit']==0
assert json.loads((s/'broad-second-result.json').read_text())['exit']==0
subprocess.run(['python',str(s/'guard.py'),'lint-second'],env=env,check=True)
subprocess.run(['python',str(s/'freeze.py'),'release-final'],env=env,check=True)
run('release-app-build',['cargo','build','--locked','-p','deadpan-app','--release','--features','ui-harness','--bin','deadpan-app'])
binaries={}
for name in ['deadpan-app','deadpan-media-worker','deadpan-transcribe','deadpan-track']:
 p=Path('target/release')/name;t=s/'release-bin'/name;t.parent.mkdir(exist_ok=True);shutil.copy2(p,t)
 binaries[name]={'source':str(p),'executed':str(t),'sha256':sha(p),'freshly_built':name=='deadpan-app'}
(s/'release-native-binaries.json').write_text(json.dumps(binaries,indent=2)+'\n');guard()
kestrel='/Users/michael/.dotfiles/kestrel/Sources/Kestrel/Shortcuts.swift'
(s/'kestrel-source.json').write_text(json.dumps({'path':kestrel,'sha256':sha(Path(kestrel))},indent=2)+'\n')
for mode in ['visual','performance']:
 if mode=='performance':
  lines=subprocess.check_output(['ps','-axo','pid,ppid,etime,pcpu,comm'],text=True).splitlines()
  conflicts=[l for l in lines if any(x in l.split()[-1].lower()for x in ['cargo','rustc','deadpan'])]
  (s/'pre-performance-processes.json').write_text(json.dumps(conflicts,indent=2)+'\n')
  assert not conflicts,conflicts
  (s/'power.txt').write_text(subprocess.check_output(['pmset','-g','batt'],text=True))
 run('release-'+mode,[binaries['deadpan-app']['executed'],'--ui-check','--scenario','sound-group-endpoints','--mode',mode,'--output',str(s/('release-'+mode)),'--kestrel-source',kestrel]);guard()
 for r in binaries.values():assert sha(Path(r['executed']))==r['sha256']
report={}
for mode in ['visual','performance']:
 r=json.loads((s/('release-'+mode)/'report.json').read_text())
 report[mode]={'failed':r['failed'],'metadata':r['metadata'],'scenarios':[{'name':x['name'],'failed':x['failed'],'checks':len(x['checks']),'frames':len(x['steps']),'findings':x['findings'],'timings':{t['name']:t['summary']for t in x['timings']}}for x in r['scenarios']]}
(s/'release-native-summary.json').write_text(json.dumps(report,indent=2)+'\n')
expression='test(sound_group_endpoint_splits_preserve_complete_pcm_and_verified_export)'
archive=s/'release-media.tar.zst';target=s/'release-media-extracted';target.mkdir(exist_ok=True)
run('release-media-build',['cargo','nextest','archive','--release','--locked','-p','deadpan-cli','--test','preview_export','--archive-file',str(archive),'--zstd-level=-1'])
with(s/'release-media-extract.log').open('w')as log:
 subprocess.run(['cargo','nextest','list','--archive-file',str(archive),'--extract-to',str(target),'--extract-overwrite','--workspace-remap',str(Path.cwd()),'-E',expression],env=env,stdout=log,stderr=subprocess.STDOUT,check=True)
helpers={}
for name in ['deadpan-cli','deadpan-media-worker','deadpan-transcribe','deadpan-track']:
 p=Path('target/release')/name;matches=list(target.rglob(name))
 if not matches:
  t=target/'target/release'/name;t.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,t);matches=[t]
 assert len(matches)==1 and sha(matches[0])==sha(p)
 helpers[name]={'source':str(p),'path':str(matches[0]),'sha256':sha(p)}
(s/'release-media-helpers.json').write_text(json.dumps(helpers,indent=2)+'\n');guard()
run('release-media-driver',['python',str(s/'run_archive.py'),'release-media',expression],{'DEADPAN_PREVIEW_EXPORT_KEEP':'1','DEADPAN_PREVIEW_EXPORT_RESULTS':str(s/'release-media-fixture.json')});guard()
for r in helpers.values():assert sha(Path(r['path']))==r['sha256']
(s/'release-final-post.json').write_text(json.dumps({'sources_inputs_native_and_media_binaries_unchanged':True},indent=2)+'\n')
