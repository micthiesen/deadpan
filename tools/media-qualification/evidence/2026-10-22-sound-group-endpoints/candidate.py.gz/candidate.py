from pathlib import Path
import json,os,subprocess,sys,time
s=Path('/tmp/deadpan-sound-group-endpoints-2026-10-22')
stage=sys.argv[1]
env=dict(os.environ,CARGO_PROFILE_DEV_OPT_LEVEL='2',DEADPAN_FFMPEG_PREFIX='/Users/michael/Library/Developer/Deadpan/ffmpeg-8.0.3-opus-1.6.1-dav1d-1.5.4-qualified-3/prefix',DEADPAN_REQUIRE_PHYSICAL_MAC='1',DEADPAN_REQUIRE_SYNTHETIC_WORKER='1')
subprocess.run(['python',str(s/'freeze.py'),stage],env=env,check=True)
args=['cargo','nextest','archive','--locked','-p','deadpan-core','-p','deadpan-audio','-p','deadpan-store','--test','sound_group_endpoints_counterfactual','--test','audio_definition','--test','source_registration','--archive-file',str(s/(stage+'.tar.zst')),'--zstd-level=-1']
start=time.monotonic()
with(s/(stage+'-build.log')).open('w')as log:r=subprocess.run(args,env=env,stdout=log,stderr=subprocess.STDOUT)
receipt={'command':args,'exit':r.returncode,'seconds':time.monotonic()-start}
(s/(stage+'-build-result.json')).write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt),flush=True)
if r.returncode:raise SystemExit(r.returncode)
subprocess.run(['python',str(s/'guard.py'),stage],env=env,check=True)
expression='binary(=sound_group_endpoints_counterfactual) | test(sound_clocks::group_endpoints::)'
subprocess.run(['python',str(s/'run_archive.py'),stage,expression],env=env,check=True)
subprocess.run(['python',str(s/'guard.py'),stage],env=env,check=True)
