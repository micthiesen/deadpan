from pathlib import Path
import subprocess,hashlib,json,shutil,os,time,sys
s=Path('/tmp/deadpan-sound-group-endpoints-2026-10-22')
stage=sys.argv[1]
env=dict(os.environ,DEADPAN_FFMPEG_PREFIX='/Users/michael/Library/Developer/Deadpan/ffmpeg-8.0.3-opus-1.6.1-dav1d-1.5.4-qualified-3/prefix',CARGO_PROFILE_DEV_OPT_LEVEL='2',DEADPAN_REQUIRE_PHYSICAL_MAC='1',DEADPAN_REQUIRE_SYNTHETIC_WORKER='1')
subprocess.run(['python',str(s/'freeze.py'),stage],env=env,check=True)
args=['cargo','build','--locked','-p','deadpan-app','--features','ui-harness','--bin','deadpan-app']
start=time.monotonic()
with(s/(stage+'-build.log')).open('w')as log:r=subprocess.run(args,env=env,stdout=log,stderr=subprocess.STDOUT)
receipt={'command':args,'exit':r.returncode,'seconds':time.monotonic()-start}
(s/(stage+'-build-result.json')).write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt),flush=True)
subprocess.run(['python',str(s/'guard.py'),stage],env=env,check=True)
if r.returncode:raise SystemExit(r.returncode)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
binaries={}
for name in ['deadpan-app','deadpan-media-worker','deadpan-transcribe','deadpan-track']:
 p=Path('target/debug')/name;t=s/(stage+'-bin')/name;t.parent.mkdir(exist_ok=True);shutil.copy2(p,t)
 binaries[name]={'source':str(p),'executed':str(t),'sha256':sha(p),'freshly_built':name=='deadpan-app'}
(s/(stage+'-binaries.json')).write_text(json.dumps(binaries,indent=2)+'\n')
kestrel=Path('/Users/michael/.dotfiles/kestrel/Sources/Kestrel/Shortcuts.swift')
(s/(stage+'-kestrel.json')).write_text(json.dumps({'path':str(kestrel),'sha256':sha(kestrel)},indent=2)+'\n')
args=[binaries['deadpan-app']['executed'],'--ui-check','--scenario','sound-group-endpoints','--mode','visual','--output',str(s/(stage+'-visual')),'--kestrel-source',str(kestrel)]
start=time.monotonic()
with(s/(stage+'-visual.log')).open('w')as log:r=subprocess.run(args,env=env,stdout=log,stderr=subprocess.STDOUT)
subprocess.run(['python',str(s/'guard.py'),stage],env=env,check=True)
for row in binaries.values():assert sha(Path(row['executed']))==row['sha256']
summary={'command':args,'exit':r.returncode,'seconds':time.monotonic()-start,'source_inputs_and_executed_hashes_unchanged':True}
p=s/(stage+'-visual/report.json')
if p.exists():
 report=json.loads(p.read_text());summary['failed']=report['failed']
 summary['scenarios']=[{'name':x['name'],'failed':x['failed'],'checks':len(x['checks']),'frames':len(x['steps']),'failures':[f for f in x['findings']if f['severity']=='failure'],'warnings':sum(f['severity']=='warning'for f in x['findings'])}for x in report['scenarios']]
(s/(stage+'-result.json')).write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary),flush=True)
raise SystemExit(r.returncode)
