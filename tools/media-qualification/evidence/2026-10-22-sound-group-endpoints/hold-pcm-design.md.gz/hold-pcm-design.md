# Audible Hold owner for endpoint grouping PCM

Use an explicitly non-silent RoomTone Hold. BeatSound-specific silent-Hold permission is not implemented; SetSoundAllowance cannot authorize a BeatSound and must not be repurposed here.

## Existing narrow fixture pattern

- audio_definition.rs:87 supplies hold(duration, HoldAudio), constructing Background picture with the exact policy.
- audio_definition/tape.rs:229, tape_keeps_repeat_default_and_actual_room_tone_occurrence_scopes_distinct, uses `hold(128, HoldAudio::RoomTone { source: audio(512..640) })` on the existing FixtureProvider media. No extra asset or receipt is needed.
- audio_definition/waveform.rs:243 similarly uses RoomTone Holds of 512 samples with audio(512..640) and audio(1024..1152).
- These examples use 48000 fps to make one frame equal one sample. For the new endpoint fixture retain 30000/1001 and use `hold(12, HoldAudio::RoomTone { source: audio(512..640) })`: duration is twelve PROJECT frames, the source span is still the existing 128-sample fixture region. RoomTone intentionally loops its source to fill the Hold.

## Minimal setup in group_endpoints.rs

In initial fixture construction, replace the owner's picture-only Source with the twelve-frame RoomTone Hold BEFORE insert_prefix. Keep the same independent event (audio(0..8197), offset 37, event EQ/Hard edges), owner EQ, lead/tail picture-only Sources and existing ClockProvider context convention. Set only the owner's kind, or reapply its treatments if constructing a replacement BeatNode. Do not switch Source to Hold after the prefix capture, because the old clock would describe a different carrier recipe.

Run the existing plain-Split/aligned controls and endpoint GroupSelection full/cold/partitioned comparisons for this Hold variant. The parent source fixture already admits the existing media; the Hold reuses it. The existing prefix journal and new physical capture must preserve RoomTone phase across both splits and attached sound support independently.

Prove the attached contribution is audible, rather than passing only because RoomTone itself is audible: create a control through public `Command::DeleteBeatSound { owner: id("owner"), id: sound_id("effect") }`, then compare full buses and require nonzero difference in interior windows crossing both selected seams. DeleteBeatSound prunes its own journal legitimately; do not hand-edit timing maps. Alternatively inspect/read the existing independent voice occurrence. Full mix equality alone cannot distinguish a suppressed event from a retained event on an audible carrier.

Keep a separate Silence-Hold variant whose complete bus remains silent (apart from deliberately unrelated contributions). Grouping must preserve suppression, never bypass it.

## Why this preserves policy

- deadpan-plan/src/audio_hold_policy.rs:201, is_silent_hold, issues a default gate only for AudioContent::Silence with SilenceReason::SilentHold. RoomTone is an explicit non-silent policy, so its independent BeatSound is not suppressed by the carrier's own default gate.
- deadpan-core/src/sound_allowance.rs:158-186 requires allowance IDs to exist in document.sounds (root SoundEvents). A local BeatSound ID belongs to document.beat_sounds[owner], so SetSoundAllowance correctly returns sound event is absent. Adding a same-named root event would authorize that separate root event only.
- OWNED_SOUND_VOICES.md:179/313 explicitly leaves scoped beat-sound allowances open. Do not broaden this feature to implement them just for testing.

No repository edits, commands with runtime side effects, builds or formatters were run.
