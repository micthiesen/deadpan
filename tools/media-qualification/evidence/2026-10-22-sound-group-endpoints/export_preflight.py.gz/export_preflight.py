from pathlib import Path
import subprocess,json,hashlib,os,shutil,time
s=Path('/tmp/deadpan-sound-group-endpoints-2026-10-22')
stage='export-second'
env=dict(os.environ,DEADPAN_FFMPEG_PREFIX='/Users/michael/Library/Developer/Deadpan/ffmpeg-8.0.3-opus-1.6.1-dav1d-1.5.4-qualified-3/prefix',CARGO_PROFILE_DEV_OPT_LEVEL='2',DEADPAN_REQUIRE_PHYSICAL_MAC='1',DEADPAN_REQUIRE_SYNTHETIC_WORKER='1',DEADPAN_RUN_IGNORED='1',DEADPAN_PREVIEW_EXPORT_KEEP='1',DEADPAN_PREVIEW_EXPORT_RESULTS=str(s/(stage+'-fixture.json')))
subprocess.run(['python',str(s/'freeze.py'),stage],env=env,check=True)
args=['cargo','nextest','archive','--locked','-p','deadpan-cli','--test','preview_export','--archive-file',str(s/(stage+'.tar.zst')),'--zstd-level=-1']
start=time.monotonic()
with(s/(stage+'-build.log')).open('w')as log:r=subprocess.run(args,env=env,stdout=log,stderr=subprocess.STDOUT)
receipt={'command':args,'exit':r.returncode,'seconds':time.monotonic()-start}
(s/(stage+'-build-result.json')).write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt),flush=True)
subprocess.run(['python',str(s/'guard.py'),stage],env=env,check=True)
if r.returncode:raise SystemExit(r.returncode)
target=s/(stage+'-extracted');target.mkdir(exist_ok=True)
expression='test(sound_group_endpoint_splits_preserve_complete_pcm_and_verified_export)'
with(s/(stage+'-extract.log')).open('w')as log:
 subprocess.run(['cargo','nextest','list','--archive-file',str(s/(stage+'.tar.zst')),'--extract-to',str(target),'--extract-overwrite','--workspace-remap',str(Path.cwd()),'-E',expression],env=env,stdout=log,stderr=subprocess.STDOUT,check=True)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
helpers={}
for helper in ['deadpan-cli','deadpan-media-worker','deadpan-transcribe','deadpan-track']:
 p=Path('target/debug')/helper;matches=list(target.rglob(helper))
 if not matches:
  t=target/'target/debug'/helper;t.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,t);matches=[t]
 assert len(matches)==1,(helper,matches)
 helpers[helper]={'path':str(matches[0]),'sha256':sha(matches[0])}
(s/(stage+'-helpers.json')).write_text(json.dumps(helpers,indent=2)+'\n')
subprocess.run(['python',str(s/'run_archive.py'),stage,expression],env=env,check=True)
subprocess.run(['python',str(s/'guard.py'),stage],env=env,check=True)
for row in helpers.values():assert sha(Path(row['path']))==row['sha256']
