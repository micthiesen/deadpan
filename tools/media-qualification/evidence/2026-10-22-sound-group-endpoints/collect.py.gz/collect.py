from pathlib import Path
import gzip,hashlib,io,json,tarfile

s=Path('/tmp/deadpan-sound-group-endpoints-2026-10-22')
out=Path('tools/media-qualification/evidence/2026-10-22-sound-group-endpoints')
out.mkdir(parents=True,exist_ok=True)
def digest(data):return hashlib.sha256(data).hexdigest()
def copy(source,name=None):
 name=name or source.name;data=source.read_bytes()
 if source.suffix in ['.log','.txt','.py','.stdout','.stderr','.patch','.sha256','.sh','.md'] or (source.suffix=='.json' and len(data)>100000):
  name+='.gz';data=gzip.compress(data,mtime=0)
 (out/name).write_bytes(data)
 return name

retained={}
for source in sorted(s.iterdir()):
 if not source.is_file() or source.suffix not in ['.log','.json','.txt','.py','.stdout','.stderr','.patch','.sha256','.sh','.md']:continue
 if any(word in source.name.lower() for word in ['artifact','progress','next-','collect-driver']):continue
 retained[source.name]=copy(source)
# Store each exact byte payload once; path/hash manifests reconstruct all
# frozen candidates without duplicating the unchanged repository each time.
snapshots={};blobs={}
for suffix,manifest_suffix,label in [('-source','-source-identities.json','Rust'),('-inputs','-lock.json','supplemental')]:
 for directory in sorted(p for p in s.iterdir() if p.is_dir() and p.name.endswith(suffix)):
  stage=directory.name[:-len(suffix)]
  rows={str(p.relative_to(directory)):digest(p.read_bytes())for p in sorted(directory.rglob('*'))if p.is_file()}
  manifest_name=stage+manifest_suffix
  expected=json.loads((s/manifest_name).read_text())
  if stage=='old-audio' and suffix=='-source':
   expected.update(json.loads((s/'old-audio-input-identities.json').read_text()))
  assert rows==expected,directory
  for name,sha in rows.items():
   data=(directory/name).read_bytes()
   assert digest(data)==sha
   if sha in blobs:assert blobs[sha]==data
   else:blobs[sha]=data
  snapshots[directory.name]={'manifest':retained[manifest_name],'kind':label,'files':len(rows),'content_sha256':digest(json.dumps(rows,sort_keys=True,separators=(',',':')).encode())}
  if stage=='old-audio' and suffix=='-source':
   snapshots[directory.name]['kind']='archived Rust and build inputs'
   snapshots[directory.name]['input_manifest']=retained['old-audio-input-identities.json']
buffer=io.BytesIO()
with tarfile.open(fileobj=buffer,mode='w')as archive:
 for sha,data in sorted(blobs.items()):
  entry=tarfile.TarInfo(sha);entry.size=len(data);entry.mode=0o644;entry.mtime=0;archive.addfile(entry,io.BytesIO(data))
archive_name='frozen-source-and-input-blobs.tar.gz'
(out/archive_name).write_bytes(gzip.compress(buffer.getvalue(),mtime=0))
with tarfile.open(fileobj=io.BytesIO(gzip.decompress((out/archive_name).read_bytes())),mode='r:')as archive:
 assert len(archive.getmembers())==len(blobs)
 for sha,data in blobs.items():assert archive.extractfile(sha).read()==data and digest(data)==sha
(out/'frozen-snapshots.json').write_text(json.dumps({'format':'sha256-content-addressed-tar-1','blob_archive':archive_name,'unique_payloads':len(blobs),'snapshots':snapshots},indent=2)+'\n')
for mode in ['debug-first-visual','release-visual','release-performance']:
 for source in sorted((s/mode).rglob('*.json')):copy(source,mode+'__'+str(source.relative_to(s/mode)).replace('/','__'))
for row in json.loads((s/'selected-captures.json').read_text()):
 source=s/row['mode']/row['file'];assert digest(source.read_bytes())==row['sha256'];copy(source,row['mode']+'-'+row['file'])
media=json.loads((s/'media-identities.json').read_text())
movie=Path(media['movie']);assert digest(movie.read_bytes())==media['movie_sha256'];copy(movie,'sound-group-endpoints.mp4')
package=Path(media['package']);root=package.parent.parent
for source in sorted(root.rglob('*.json')):
 if package not in source.parents:copy(source,'media__'+str(source.relative_to(root)).replace('/','__'))
owner=json.loads((s/'owner-fixture-identity.json').read_text());archive=s/owner['archive']
assert digest(archive.read_bytes())==owner['sha256'];copy(archive)
if (s/'media-preflight-retained').exists():
 for source in sorted((s/'media-preflight-retained').iterdir()):copy(source,'debug-preflight__'+source.name)
inventory=[{'file':p.name,'bytes':p.stat().st_size,'sha256':digest(p.read_bytes())}for p in sorted(out.iterdir())if p.name!='inventory.json']
(out/'inventory.json').write_text(json.dumps(inventory,indent=2)+'\n')
for row in inventory:
 data=(out/row['file']).read_bytes();assert len(data)==row['bytes'] and digest(data)==row['sha256']
print(json.dumps({'entries':len(inventory),'bytes':sum(r['bytes']for r in inventory),'unique_frozen_payloads':len(blobs),'inventory_verified':True}))
