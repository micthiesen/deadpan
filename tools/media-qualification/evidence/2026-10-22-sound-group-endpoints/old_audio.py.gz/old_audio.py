from pathlib import Path
import hashlib,json,os,shutil,subprocess,tarfile,time
s=Path('/tmp/deadpan-sound-group-endpoints-2026-10-22')
root=s/'old-audio-source';root.mkdir()
with tarfile.open(s/'old-audio-base.tar') as archive:archive.extractall(root,filter='data')
source=json.loads((s/'base-source-identities.json').read_text())
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
before={str(p.relative_to(root)):sha(p)for p in root.rglob('*.rs')}
assert all(source[p]==h for p,h in before.items())
parent='crates/deadpan-audio/tests/audio_definition/sound_clocks.rs'
test='crates/deadpan-audio/tests/audio_definition/sound_clocks/group_endpoints.rs'
assert sha(root/parent)==source[parent]
for name in [parent,test]:
 p=root/name;p.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(Path(name),p)
rows={str(p.relative_to(root)):sha(p)for p in root.rglob('*.rs')}
inputs={str(p.relative_to(root)):sha(p)for p in root.rglob('*')if p.is_file()and p.suffix!='.rs'}
(s/'old-audio-source-identities.json').write_text(json.dumps(rows,indent=2)+'\n')
(s/'old-audio-input-identities.json').write_text(json.dumps(inputs,indent=2)+'\n')
(s/'old-audio-source-audit.json').write_text(json.dumps({'base_commit':(s/'base-commit.txt').read_text().strip(),'archive_selected_paths':['Cargo.toml','Cargo.lock','rust-toolchain.toml','.cargo','crates','native','docs/COMMANDS.md'],'base_rust_files':len(before),'all_base_rust_match_recorded_git_blobs':True,'control_addition':test,'only_modified_base_rust':parent,'modified_module_is_only_test_registration':(root/parent).read_text().replace('#[path = \"sound_clocks/group_endpoints.rs\"]\nmod group_endpoints;\n\n','')== (s/'base-source'/parent).read_text(),'core_production_identical_to_committed_baseline':all(rows[p]==source[p]for p in rows if p.startswith('crates/deadpan-core/'))},indent=2)+'\n')
def guard():
 assert {str(p.relative_to(root)):sha(p)for p in root.rglob('*.rs')}==rows
 assert {str(p.relative_to(root)):sha(p)for p in root.rglob('*')if p.is_file()and p.suffix!='.rs'}==inputs
env=dict(os.environ,CARGO_PROFILE_DEV_OPT_LEVEL='2',DEADPAN_FFMPEG_PREFIX='/Users/michael/Library/Developer/Deadpan/ffmpeg-8.0.3-opus-1.6.1-dav1d-1.5.4-qualified-3/prefix')
args=['cargo','nextest','list','--locked','-p','deadpan-audio','--test','audio_definition','--target-dir',str(s/'old-audio-target'),'--message-format','json']
start=time.monotonic()
with(s/'old-audio-list.json').open('w')as out,(s/'old-audio-build.log').open('w')as err:r=subprocess.run(args,cwd=root,env=env,stdout=out,stderr=err)
receipt={'command':args,'cwd':str(root),'exit':r.returncode,'seconds':time.monotonic()-start}
(s/'old-audio-build-result.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt),flush=True)
if r.returncode:raise SystemExit(r.returncode)
suites=json.loads((s/'old-audio-list.json').read_text())['rust-suites'];assert len(suites)==1
row=next(iter(suites.values()));p=Path(row['binary-path']);retained=s/'old-audio-bin'/p.name;retained.parent.mkdir();shutil.copy2(p,retained)
identity={'source':str(p),'executed':str(retained),'sha256':sha(p)}
(s/'old-audio-binary.json').write_text(json.dumps(identity,indent=2)+'\n')
results=[]
suffixes=['endpoint_grouping_plain_split_and_aligned_controls_preserve_complete_pcm','endpoint_group_control_range_copy_has_exact_pcm_at_same_ntsc_phase','endpoint_groups_keep_every_ntsc_sample_through_event_and_shared_eq','endpoint_group_copy_keeps_full_owner_processing_and_both_cropped_seams']
for index,suffix in enumerate(suffixes):
 names=[n for n in row['testcases']if n.endswith('::'+suffix)];assert len(names)==1
 start=time.monotonic();r=subprocess.run([str(retained),'--exact',names[0],'--nocapture'],cwd=root,env=env,capture_output=True,text=True,timeout=90)
 (s/('old-audio-'+suffix+'.stdout')).write_text(r.stdout);(s/('old-audio-'+suffix+'.stderr')).write_text(r.stderr)
 expected=(r.returncode==0 and '1 passed; 0 failed' in r.stdout)if index<2 else(r.returncode==101 and 'group endpoint splits cannot yet preserve beat-owned sound clocks' in r.stderr and '0 passed; 1 failed' in r.stdout)
 result={'test':names[0],'exit':r.returncode,'expected_pass':index<2,'expected_outcome':expected,'seconds':time.monotonic()-start,'sha256':identity['sha256']}
 results.append(result);(s/'old-audio-results.json').write_text(json.dumps(results,indent=2)+'\n');print(json.dumps(result),flush=True)
 assert expected,r.stdout+r.stderr
guard();assert sha(p)==sha(retained)==identity['sha256']
print('Old audio source, every build input and executed binary unchanged',flush=True)
