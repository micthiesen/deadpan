from pathlib import Path
import hashlib,json,os,subprocess,time
s=Path('/tmp/deadpan-sound-group-endpoints-2026-10-22')
test='voice_occurrence::beat_sounds::sound_clocks::group_endpoints::endpoint_hold_groups_keep_permitted_sound_and_room_tone_phase'
rows=json.loads((s/'candidate-fourth-binaries.json').read_text())
row=next(r for r in rows.values()if test in r['tests'])
p=Path(row['path']);sha=lambda:hashlib.sha256(p.read_bytes()).hexdigest();assert sha()==row['sha256']
start=time.monotonic()
r=subprocess.run([str(p),'--exact',test,'--nocapture'],env=dict(os.environ,DEADPAN_FFMPEG_PREFIX='/Users/michael/Library/Developer/Deadpan/ffmpeg-8.0.3-opus-1.6.1-dav1d-1.5.4-qualified-3/prefix'),capture_output=True,timeout=60)
(s/'candidate-fourth-isolated-hold.stdout').write_bytes(r.stdout);(s/'candidate-fourth-isolated-hold.stderr').write_bytes(r.stderr)
expected=r.returncode==101 and b'provider.fixture.context_calls > 0' in r.stderr
assert sha()==row['sha256']
receipt={'binary':str(p),'sha256':row['sha256'],'test':test,'exit':r.returncode,'expected_original_fixture_assertion':expected,'seconds':time.monotonic()-start,'stdout_stderr_reached_eof':True,'scope':'Resolve concurrent output-handle warning using the same retained failing executable. This remains a failed fixture check, not passing candidate evidence.'}
(s/'candidate-fourth-isolated-hold.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt));assert expected
