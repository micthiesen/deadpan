from pathlib import Path
import hashlib,json,os,shutil,subprocess,time,sys
s=Path('/tmp/deadpan-sound-group-endpoints-2026-10-22')
phase=sys.argv[1]
env=dict(os.environ,CARGO_PROFILE_DEV_OPT_LEVEL='2')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
subprocess.run(['python',str(s/'guard.py'),phase],check=True)
subprocess.run(['python',str(s/'verify_base.py'),phase],check=True)
args=['cargo','nextest','list','--locked','-p','deadpan-core','--test','sound_group_endpoints_counterfactual','--target-dir',str(s/'baseline-target'),'--message-format','json']
start=time.monotonic()
with(s/(phase+'-list.json')).open('w')as out,(s/(phase+'-build.log')).open('w')as err:
 r=subprocess.run(args,env=env,stdout=out,stderr=err)
receipt={'command':args,'exit':r.returncode,'seconds':time.monotonic()-start}
(s/(phase+'-build-result.json')).write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt),flush=True)
if r.returncode:raise SystemExit(r.returncode)
suites=json.loads((s/(phase+'-list.json')).read_text())['rust-suites']
assert len(suites)==1
row=next(iter(suites.values()));tests=[n for n,c in row['testcases'].items()if c['filter-match']['status']=='matches']
assert len(tests)==2,tests
p=Path(row['binary-path']);retained=s/(phase+'-bin')/p.name;retained.parent.mkdir(exist_ok=True);shutil.copy2(p,retained)
identity={'source':str(p),'executed':str(retained),'sha256':sha(p),'tests':tests}
(s/(phase+'-binary.json')).write_text(json.dumps(identity,indent=2)+'\n')
results=[]
for test in tests:
 start=time.monotonic()
 r=subprocess.run([str(retained),'--exact',test,'--nocapture'],env=env,capture_output=True,text=True,timeout=60)
 (s/(phase+'-'+test+'.stdout')).write_text(r.stdout)
 (s/(phase+'-'+test+'.stderr')).write_text(r.stderr)
 expected=r.returncode==101 and 'group endpoint splits cannot yet preserve beat-owned sound clocks' in r.stderr and 'CONTROL plain Split passed' in r.stdout and 'CONTROL aligned GroupSelection passed' in r.stdout and '0 passed; 1 failed' in r.stdout
 result={'test':test,'exit':r.returncode,'seconds':time.monotonic()-start,'expected_exact_endpoint_refusal_after_both_positive_controls':expected,'sha256':identity['sha256']}
 results.append(result);(s/(phase+'-results.json')).write_text(json.dumps(results,indent=2)+'\n')
 print(json.dumps(result),flush=True)
 assert expected,r.stdout+r.stderr
subprocess.run(['python',str(s/'guard.py'),phase],check=True)
assert sha(p)==sha(retained)==identity['sha256']
