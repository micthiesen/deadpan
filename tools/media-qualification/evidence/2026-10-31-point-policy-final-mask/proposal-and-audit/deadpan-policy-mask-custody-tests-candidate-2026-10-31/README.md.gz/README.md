# Native Point policy custody tests

Candidate only. No checkout changes, Cargo, native test execution, Git, or fixture updates. rustfmt --edition 2024 succeeded; compilation and execution are owed to the parent.

Install policy_mask_custody_tests.rs as crates/deadpan-audio/src/sound_context_admission/policy_mask_custody_tests.rs. Append this separate child hook to sound_context_admission/policy_mask_handoff.rs, alongside the existing primitive test hook:

    #[cfg(test)]
    #[path = "policy_mask_custody_tests.rs"]
    mod custody_tests;

The inherited stages target cfg already restricts this child to supported native platforms. Keep the existing policy_mask_handoff_tests.rs primitive tests intact.

Run filter: policy_mask_handoff::custody_tests. Eight tests:

- actual_factory_native_handoff_keeps_exact_vec_and_outlives_all_request_owners
- actual_factory_keeps_all_plan_guards_during_box_only_prepare_and_other_owner_drop
- actual_capacity_zero_factory_uses_no_account_or_storage
- actual_factory_entry_cancel_deadline_and_work_refusals_release_query_guards
- actual_factory_all_small_prepare_work_prefixes_and_exact_resident_ceiling
- cancellation_after_real_box_preparation_releases_both_owners
- positive_capacity_empty_uses_real_lease_and_retains_its_exact_empty_vec
- actual_factory_foreign_ledger_rejects_equal_sized_native_custody

## Real inputs and authority

The fixture starts from the existing qualified native WAV/document helper, installs a public 64-frame SilentHold at 48 kHz through BeatNode::hold, reparses ProjectDocument, compiles RenderPlan, selects the checked node, and calls public in_point_clock. Policy is obtained only with actual AudioPointDomain::policy_admitted and actual Admission. No private Point/Bound construction, invented lease/counter, Plan descriptor construction, source extraction, unsafe, or production instrumentation.

The WAV helper is invoked to retain existing checked fixture qualification. These metadata-only tests do not invoke a source provider or assert numerical PCM. Genuine Bound callback/rendering remains separately exercised by the native read tests and replay corpus.

The direct success test calls the actual native trait implementation for both prepare and commit. It uses separate Admission values sharing the same real WorkControl issuer. It checks source slice pointer/length and exact target pointer/length/capacity/value, final Plan ledger zero, unique target ownership, and output surviving query, Admission, controller and ReadWork. A closed account observer remains after physical mask destruction; only its shell remains charged.

The equal-sized foreign test constructs two actual factory queries on distinct native ReadWork ledgers and rejects the cross-issuer consuming handoff before any destination account allocation. It then checks the unrelated destination query remains live until its own drop.

## Observation wrapper boundary

Observing is explicitly a test backend, not a transparent wrapper around Admission::prepare_signal_mask. It delegates every Plan spend/reserve/merge to real Admission and delegates commit immediately. For positive prepare, it calls the exact existing native prepare_policy_mask and preflight_source_lease primitives.

This is necessary because SignalPolicyMaskRef::lease(&self) currently borrows the descriptor: a saved lease reference cannot safely survive moving the descriptor into the native trait prepare. No capability or lifetime API is widened for observation.

All snapshots and the joined external-owner thread happen before the final cancellation check and final real exclusive preflight. The returned token stores the newly computed remaining ledger. There is no observation, callback, destructor, allocation, budget check, trace, or assertion between that successful final preflight and delegating actual commit. Assertions about destination vector provenance occur before final preflight.

The wrapper observes the actual whole-query aggregate Plan ledger unchanged during Box preparation, the exact final lease still charged, and only the new native Box added. Individual inventory guard identities are not instrumented; the source-pinned factory's immediate prepare/commit tail and drop-after-commit order supply that Rust-level proof. The unchanged aggregate ledger is the runtime overlap evidence, not a claim of per-guard telemetry.

The thread drops a real native-owned mask made by the existing real-context admitted builder. It is deterministically joined after destination Box preparation and before final preflight/publication. This proves atomic publication credit does not reinstall an account total observed before the other owner's release. It does not insert a thread barrier into production commit.

## Failure and layout checks

All work refusals are created by real successful WorkControl debits consuming the remaining allowance, with no reset or refund. One successful actual handoff measures its short native work delta; every strictly shorter prefix is attempted on a fresh real query/controller. Accepted units must reach exactly the actual unchanged global cap before refusal, the Plan source guards must clean up, and only a successfully initialized account shell may remain.

Memory cases lower only the test controller's existing ceiling after the actual source query is constructed: source ledger plus shell - 1, shell + Box - 1, and shell + Box. They assert the precise boundary with no duplicate final Vec reservation. No resident counter is fabricated.

Pinned shell = 3 and Box<Storage<SignalSample>> = 5 frame equivalents are explicit layout assertions already covered by existing account/layout tests. Final vector frames come from the production vector_frames(capacity) helper. Those constants must be updated only if the separately qualified layout changes, not to accommodate a failing custody result.

The positive-capacity empty case is a lower native protocol test using actual Admission::reserve and actual native preparation/commit. It is explicitly not a factory-produced empty-with-capacity query: current final collection allocates exact final length and cannot naturally produce that state.

No test holds a Ref/RefMut across consuming query error cleanup. Borrow conflicts remain covered only by the separate borrowed-helper primitives; the caller releases Ref before dropping its source owner. The existing Lease Drop contract is unchanged.

## Execution owed

All eight new tests must compile and pass in Main and Scope with the parent's qualified build process. Runtime results, exact observed work delta and actual source-ledger size are not claimed by this candidate. Source pins are in pins.json. Existing before bodies and all 31 oracles are untouched.
