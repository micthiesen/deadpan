# C native final-policy-mask custody test contract

Design/proposal only. No test is implemented or run here. Parent owns the private PreparedMask/MaskLeaseTransfer APIs, root integration, builds, captures and Git. No author design or root source was changed.

Use the proposed AudioPointDomain::policy_admitted and AdmittedSignalPolicyQuery::into_suppression against the actual native Admission, same controller, same WorkControl and real ReadWork. Preserve every B/T oracle. Construction canonical/additional work, native preparation work, and custody transfer are three separate observations; transfer is not a vector-allocation debit or refund.

## Test locations and minimum observation seam

- A private child of sound_context_admission for exact Lease/MaskLeaseTransfer preflight and identity tests.
- A private child of point_suppression for PreparedMask storage, account and abandonment tests.
- A bound_reads child for complete actual Point factory/consumer/handoff/lifetime tests, reusing checked quiet_and_padded and bound_preserve fixtures.
- Plan-owned protocol tests for FinalSignalMask/inventory lease independence and GuardedBound/Core lifetime. Do not expose Plan private carrier fields to Audio.

Do not add a public donor constructor, generic lease extraction, mutable mask access, returned Vec, public token or commit callback. Lower-level test inputs are actual Vec allocations funded by actual native Admission::reserve, with the value declared before its real Lease. They are labeled primitive tests, not forged Plan products or Bound/Point domains.

Collect the source pointer/length from a scoped query.view().suppressed borrow before consuming the query. The descriptor's actual capacity/exact source frames can be recorded during preparation before its final exclusive check. After return, use the native mask's borrowed slice pointer, length and capacity. Pointer equality is compared directly while allocation custody remains live; raw pointer values are not dereferenced after owner drop or normalized into a fixture body.

No observer call, trace emission, barrier, destructor, cancellation check or arithmetic may be inserted between successful production preparation and commit. Observe preparation before its final validated return and output after the whole method. Test-only metadata storage is outside the accounting claim.

## Eight focused tests

### 1. Actual Point handoff preserves the exact final allocation and Box-only overlap

Suggested name: actual_point_policy_handoff_moves_exact_vec_and_reserves_only_box.

Use a genuine positive-mask quiet/selected-placement Point and a genuine Preserve Bound Point from the existing checked fixtures. Construct the query using one Admission, end that mutable borrow, consume it using a new Admission with the SAME control and renderer. This deliberately proves issuer reuse rather than requiring an admission object to live for the whole read.

Before handoff record actual source slice pointer/length, work/lookup/canonical/additional/forwarded, current ReadWork.sound_context_frames L, account live A, and complete existing native/controller residency. During preparation record the descriptor's actual capacity c and source lease frames v. Require:

    v = ceil(Layout::array<Range<SignalSample>>(c).size / FRAME_BYTES)

All inventory/Core/contents guards and the source Vec remain live. With a warmed account, preparation increases native live by exactly b=ceil(Layout::new<Storage<SignalSample>>().size/FRAME_BYTES), not v+b. Unwarmed preparation adds the qualified shell s as well. No native AllocateVector receipt or vector payload reservation occurs for this handoff.

After commit output pointer/len/cap equals the original ptr/len/c. Query inventory is allowed to free only after commit. The source capacity lease is disarmed once. Output charge is b+v on the existing account; source ledger drops v at custody transfer, then only physically freed inventory metadata charges. Construction work was forwarded once. Do not derive v or any native fee from an unexplained total-work remainder.

Runtime pointer and account assertions are not, alone, proof that inventory guards survived; test8 supplies that protocol evidence.

### 2. Actual issuer and exact-lease isolation

Suggested name: mask_lease_preflight_reuses_same_issuer_and_rejects_foreign_equal_frames.

For the full public Plan path, create a real query on ledger A and consume it with a fresh Admission on A. It succeeds. Consume another query with Admission on actual ledger B; it rejects issuer mismatch before native preparation/credit. Both real ledger cleanup states are observed after the consuming error. Source remains charged until its actual allocation is freed; it is not returned to the caller on this consuming error.

For the private borrowed MaskLeaseTransfer helper, create actual equal-sized capacity leases on A and B through their Admissions and allocate the corresponding real Vecs afterward. Ask A to preflight B's same-sized lease. It must reject identity even though frame/capacity arithmetic matches. Original owners remain live and unchanged during rejection, then drop normally.

Also test a real over-sized lease/request mismatch without assigning private frame counters. A lease reserved for a larger real layout cannot be accepted as the exact final allocation lease.

Do not claim the native frame check can distinguish two unrelated same-issuer/same-sized leases. Plan's sealed dedicated FinalSignalMask construction and no-merge proof establish that missing allocation identity. No valid public descriptor can be manufactured from an unrelated lease.

### 3. Empty capacity and positive capacity/empty length

Suggested name: mask_handoff_distinguishes_zero_capacity_from_zero_length.

A real public Point policy with final cap0 has no final lease. Handoff creates no account when unwarmed, no Box, no vector/native fee, and returns heapless empty. With an already-live account, existing live charges remain exactly unchanged. Isolate the handoff after construction so earlier query-construction residency work is not called a handoff fee.

The current finish_signal allocates cap=final count, so cap>0,len0 is NOT reachable from its normal public factory. Exercise it only at the private native import primitive using a real Vec::with_capacity(c), len0 and its actual independently reserved exact lease. It must remain Owned with capacity c and b+v charge until physical destruction, even though the values slice is empty. Verify pointer preservation here too.

Reject cap0 with an unexpected lease and positive capacity without the exact lease at the appropriate private protocol layer. Do not fabricate an invalid public Plan carrier or pretend this shape came from a checked Point factory.

### 4. Prepared-token abandonment and actual reserve/work/cancel/memory failures

Suggested name: final_mask_prepare_failures_release_only_real_destination_storage.

Cover warmed and unwarmed accounts. Use actual existing layout calculations and actual real ledger state; do not search for a mysterious first-success cap.

For a warmed controlled fixture with no other unmeasured residency, define exact peak C from the existing controller residency + L + A + b, where L already includes the final vector. C succeeds, C-1 refuses before Box allocation/commit. If other controller products exist, include their measured real formula, never assume zero.

Measure a successful preparation's actual work first, then test its small refusal prefixes with fresh controllers/query owners. Consume remaining allowance through real prior control.spend_plan_work debits; do not set counters, refund accepted work, raise caps or normalize atomic debits. Record exact native phases and residency work. Failures release pending Box charge; a legitimately initialized controller shell can persist. The still-existing source/query remains charged until its actual error-path destruction.

Test cancellation/deadline already refused at preparation entry. Test final validation refusal after Box preparation at the private preparation layer only if its natural internal stages allow deterministic scheduling without introducing a callback into the commit boundary. Otherwise label that mid-preparation scheduling gap rather than claim it from a pre-cancel test. Keep the later ordinary caller control check.

An unused PreparedMask must drop through OwnedMask, not bare Box. After dropping the token, source Vec/lease are unchanged and account is back to A plus any legitimately initialized shell. A separate consumed-query error naturally destroys source/query too; distinguish these two cleanup states.

### 5. Exclusive RefCell preflight, with the source owner retained

Suggested name: borrowed_mask_lease_preflight_rejects_shared_ref_before_any_native_credit.

Hold an actual shared Ref to the source ReadWork while retaining its actual source Vec/Lease in the caller. Invoke ONLY the borrowed MaskLeaseTransfer preflight. Require a typed rejection via try_borrow_mut before native vector credit or lease disarm. Account, ledger and source pointer/len/cap/frames remain unchanged by the rejected transfer.

Release the shared Ref BEFORE dropping the source owner. Then its real Lease Drop can use borrow_mut and cleanup must succeed. Also hold a mutable Ref to check the same rejected access path where appropriate.

Do NOT test graceful recovery by consuming query.into_suppression while a shared ledger Ref remains held. That method consumes and drops the query on Error, and existing Lease::drop itself needs borrow_mut. The held Ref can therefore make that cleanup panic even when preflight correctly rejected. Parent explicitly excludes graceful consuming-query conflict cleanup from this unit. Do not widen the error API or change shared Lease Drop to hide this limit.

### 6. Output survives local budget, ledger, provider and controller

Suggested name: imported_policy_mask_owns_charge_after_ledger_and_controller_drop.

Return the actual native mask and its closed account Observer from a helper that locally owns the real ReadWork, query, Admission and controller. The output type must compile without carrying their lifetimes. Before local ledger destruction, sound_context_frames must be zero and no armed final lease may remain. Destroy any provider and Plan inventory normally.

Read all values and exact capacity after the helper returns. Account live must still equal shell plus actual imported Box/vector and any intentionally retained independent native owners. Drop output; with only the observer left, live is shell3. Drop observer last. Also require the unchanged concrete mask to satisfy Send where the existing labels/account already do.

This is both a Rust lifetime obligation and a proposed runtime check. No such native handoff test has run yet.

### 7. Concurrent independent owner drops cannot resurrect charge

Suggested name: imported_vector_credit_uses_atomic_delta_under_other_owner_drops.

Create several real independently owned masks on the SAME account using existing admitted builders. Move only those native masks to a worker thread; ReadWork/query/Admission stay on the calling thread. Start the worker before the immediate Plan handoff, allow its drops to overlap, and join only after handoff completes. Assert all source/native cleanup and final live frames from actual remaining owners.

A bounded repeated stress run covers naturally overlapping schedules, but does not prove a specific interleaving occurred. For a deterministic regression against stale total storage, test the private account-credit primitive separately: precheck a real account value, let another actual owner drop, then credit v using the same primitive. The final live value must use current atomic state plus v, not the old captured total. This primitive test is NOT an execution of the production immediate Plan prepare/commit path.

Do not put a barrier, join, callback, foreign ledger mutation or test trace inside the real prepare-to-commit window merely to force an interleaving. External native drops only subtract and are permitted by the account invariant.

### 8. Complete query guards survive until custody is complete

Suggested name: final_policy_memory_stays_separate_and_inventory_guards_drop_after_transfer.

Plan-owned tests must show the final dedicated Memory has exactly one final typed Vec reservation and is never merged/adopted/zipped with inventory/temporary memory. Its capacity lease cannot be an aggregate of same-sized unrelated allocations. Inventory retains all current GuardedBound/Core/contents-capacity guards.

For native-backed runtime evidence, a private protocol-conforming test admission may wrap actual native Leases in tracked guards while every spend/reserve/merge delegates to real Admission/ReadWork. A private helper can forward the wrapper's inner immutable/mutable Lease to the concrete native preflight/commit; it must not create an uncharged substitute.

Use a bounded, preallocated test observer log so lease-drop bookkeeping allocates no storage. Track actual lease IDs, merges, frames observed before real Lease Drop, and release completion. Descriptor preparation identifies the final capacity lease ID; all other live query IDs remain alive through successful preparation. The final source lease's observed frames0 Drop occurs only after custody has completed, and inventory release events follow it, matching the proposed Plan consuming method. No trace is emitted in commit itself.

If this native-backed tracked wrapper requires widening production APIs, keep the exact per-guard evidence in Plan protocol tests and the native aggregate lifetime tests separate. Aggregate ledger totals cannot alone prove each Core guard's physical lifetime. Report the split proof; do not invent per-guard native evidence.

## Required observations and proof limits

Record literal before/after ledger frames, account frames, existing controller residency, native phase/work receipts, capacity/len/pointers, issuer equality and source lease frames. Keep partial/error cases and actual accepted prefix. Typed mismatch/cancel/deadline/refusal errors are actual outputs, not expected-body substitutions.

Stable residency transfer is checked as an explicit custody equation, not residual fee attribution:

    ledger_before includes v; native_before includes only prepared Box
    ledger_after_transfer = prechecked ledger_before - v
    native_after_transfer = current native account + v

No allocation/admission/cap check observes the internal conservative double charge. This stable before/after equation is tested with other owners held still. In the concurrent-drop test, compare final state after joining against actual remaining owners; do not require a captured preflight total to survive unrelated drops. Post-commit inventory cleanup is a separate real physical release, not a refund.

Rust/source guarantees still require review: private descriptor/token constructors; exact same Vec/Lease moves; no post-prepare callback/drop/check; precomputed final ledger/Charge totals; atomic fetch_add rather than stale store; existing OwnedMask unbox/Vec/Charge destructor; no ledger reference in output. Tests cannot mechanically prove an arbitrary open backend never unwinds.

Account observations before/after Drop prove charge lifetime, not the machine instruction ordering of physical Box deallocation. Reuse the already-qualified OwnedMask destructor unchanged. If that helper or Storage representation changes, qualify the physical deallocation ordering independently; do not infer it from a final zero count.

Native test fixtures use actual checked PointCeil Signal policy factories and real Preserve Bound cases. Pointer/lease edge primitives are explicitly lower-layer tests. None creates expected native JSON or changes canonical weights, caps, compatibility lanes, old invalid flags or frozen before data.


## Concrete borrowed-helper candidate

policy_mask_handoff_tests.rs is a new scratch-only candidate for the private child of sound_context_admission::policy_mask_handoff. It replaces the draft's inline manufactured Lease/preloaded-frame test, using:

    #[cfg(test)]
    #[path = "policy_mask_handoff_tests.rs"]
    mod tests;

The checked public fixture and real StageAudio are created through controlled_reads::fixture_document_at_rate. All source leases come from actual Admission::reserve of the exact real Layout, followed by real Vec allocation. Each Source declares its Vec before Lease. No frame field or ledger counter is assigned by the tests.

Two tests cover shared/mutable conflicting Ref rejection with source retained, successful same-issuer borrowed preflight, equal-frame foreign issuer/ledger rejection, replaced same-ledger lease pointer rejection and actual larger-layout lease mismatch. The conflicting Ref is released before real owner destruction. Original source/account/ledger state and final cleanup are inspected.

These are concrete preflight primitive tests, not complete actual Plan factory handoff evidence. The full eight-case contract above remains implementation/qualification work for the parent. This candidate is rustfmt-parsed only; no compilation/native execution occurred.
