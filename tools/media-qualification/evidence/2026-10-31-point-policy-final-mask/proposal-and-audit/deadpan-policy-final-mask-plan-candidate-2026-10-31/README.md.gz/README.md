# Plan-side C policy final-mask patch proposal

candidate.patch is the concrete proposal. Existing-source snapshots are in
before/, proposed files in new/, and exact dependency hashes in source-pins.json.
Only scratch was written. Rustfmt edition2024 parsed/formatted the proposals;
there was no build, native run, fixture generation, root edit or Git operation.

## Scope

New audio_point_policy_query.rs contains the Point-only carrier, borrowed view,
exact final-mask descriptor, trusted backend protocol, closed PointCeil factory,
and fallible Signal finalizer. Existing audio_policy_query.rs adds only its child
declaration and re-exports. audio_policy.rs, plan.rs and lib.rs expose the four
new public types/trait. Root finish's entire function body remains byte-identical;
the existing Root PolicyBuffer/AdmittedAudioPolicyQuery representation is intact.

IMPORTANT: Main plan.rs differs from Scope at the read snapshot. Apply only the
narrow pub-use hunk to Main, preserving its inherited changes. Do not copy the
complete proposed Scope plan.rs over it. The other three existing targets match
between roots. This proposal does not change either source root while interval
observer qualification runs.

## Concrete lifetime and ownership

FinalSignalMask privately owns Vec<Range<SignalSample>> followed by its own
Memory. Its Memory receives exactly one direct final vector reservation and
never enters adopt_memory, zip, merge_checked or any inventory merge. Inventory
retains its existing GuardedBound/Core lanes and separate content capacity.

view() borrows both products. No owning query, Clone, mutable Vec, Memory setter,
lease-take method or generic GuardedBound extraction is added. into_suppression
checks metered provenance, exact issuer, and empty/positive capacity lease
presence before backend preparation. Plan then performs only field moves and
Option::as_mut before immediately invoking commit with that same Vec/lease.
It performs no post-prepare identity callback/check, allocation or destructor.
Inventory remains alive until commit completes.

The backend trait's prepare contract requires final revalidation AFTER all
reservations, exclusive try_borrow_mut access to the concrete source ledger for
positive-capacity transfer, precomputed remaining ledger and final charge totals,
and no retained Ref/RefMut. Native should store charge_frames_after explicitly.
Its commit must be infallible, non-unwinding and allocation-free, move the exact
Vec into already admitted owning storage before disarming its source lease,
and use precomputed totals. No trace callback belongs in that mutation window.

This open cross-crate trait is trusted accounting infrastructure like existing
Admission::merge. The source, descriptor construction and native token stay
closed. It does not prevent a deliberately nonconforming external backend from
extracting/dropping a Vec or violating custody. Safe Rust cannot enforce the
trait's non-unwinding/accounting contract. The native implementation and its
actual output lifetime tests remain parent-owned and are not supplied here.

Unmetered policy_admitted uses the ordinary actual policy and empty memories,
preserving values/canonical work without spend/reserve/merge callbacks. It does
obtain issuer for its carrier, like the existing Root admitted-policy wrapper.
Nonempty unmetered values cannot enter the owned handoff; into_suppression
rejects unmetered provenance before preparation. Audio's B replay should keep
its literal ordinary policy/Vec path through its distinct C compatibility switch.

## Actual Signal finalizer work

The new finalizer deliberately does not copy Root's uninterruptible
sort_unstable_by_key. It uses in-place heapsort, additional debit before each
sift iteration/comparison/swap, and additional debit before each merge scan,
overlap comparison/update, and typed mapping. push_range retains its existing
growth/insertion admission. Output is allocated directly at exact final count
as Range<SignalSample>, with assert_eq actual capacity like Root's current
finalizer, and remains guarded throughout every refusal.

Canonical traversal accounting is untouched. New finalizer CPU/allocation
charges are additional and included in work/provenance checks. This proposal
does not claim exhaustive qualification of the inherited recursive policy
engine: its actual work/refusal coverage must be tested with the new entrypoint.

## Parent integration boundary

Native implements AudioSignalPolicyMaskHandoff on its closed Admission. It must
preallocate B's existing OwnedMask wrapping Box<Storage<SignalSample>> with an
empty Vec and Box-only charge. An unused token needs the existing OwnedMask
destructor; a bare Box default Drop would retire Charge before physical Box
deallocation. Commit credits vector frames, moves the exact allocation, assigns
remaining ledger/disarms exact lease, and returns its existing owned mask.

Only that concrete native backend can establish exclusive RefCell access and
account continuity. Plan itself cannot inspect a generic Lease's ledger or
frame count; the sealed final-mask allocation construction plus native exact
Layout/frame check together supply that proof. No native implementation is
invented by this proposal, and the API is not runtime-integrated here.

Meaningful qualification obligations are in tests.md. No tests are reported
passing. Patch SHA is recorded in source-pins.json and parent message.

The separate audio_point_policy_query_tests.rs proposes seven focused Plan
protocol tests using all three successful checked public supplement fixtures
from immutable documents/placement/grid bytes. It checks exact frozen Point
geometry, ordinary policy numerical values/canonical work, pointer/len/cap,
exclusive reservation identity, inventory liveness, real same-sized vector
guard identity, refusals and unmetered/issuer behavior. Its recording backend
is a Plan protocol model, not native Box/account lifetime evidence.

Accepted borrow limit: into_suppression consumes the source. If an external
shared ledger Ref causes prepare to fail, dropping that consumed query would
also need RefMut in Lease::drop. This unit does NOT promise graceful consuming
recovery under that conflict. The borrowed-helper test retains the actual
source owner, observes prepare refusal, ends the shared Ref, then drops source.
The real closed native caller must hold no ReadWork Ref across construction
or consumption. Final exclusive preflight still proves commit borrow safety
under that conforming caller/backend. No API widening or Lease Drop rewrite
is proposed to handle the nonconforming consuming case.
