# Qualification required before C admission credit

No execution performed. These are acceptance obligations for this Plan patch
and the parent's concrete native backend; tests must identify which side they
exercise rather than substitute a generic backend for native lifetime evidence.

## Plan constructor and finalizer

- Use existing actual public Point factories from initial and supplemental
  Point matrices, including negative/fractional PointCeil origins, selected
  Source endpoints, explicit Hold, nested real Bound, Repeat and empty ranges.
  Compare metered view values/contents/lookup and canonical work directly with
  signal_ref().policy. Compare false-policy values/work to the same ordinary
  result, with no spend/reserve/merge callback. Additional work must match the
  literal accepted callbacks and total work equals canonical+additional.
- Record real reservation identities in a conforming test admission. Identify
  the dedicated final Vec reservation by the exact observed final pointer/cap
  at the private finalizer boundary. Require exact typed Layout capacity, one
  independent lease, and no merge using that lease as source OR target,
  including an unrelated lease with equal byte size. Inventory/Core/contents
  leases stay live independently during borrowed views and preparation.
- Exercise unsorted starts, equal starts/different ends, overlap, adjacency,
  disjoint ranges and empty/invalid ranges through finish_signal unit cases.
  These verify heapsort/merge logic, and do not claim public factory authority.
  Check integer union semantics against ordinary policy's union, sorted/coalesced
  final output, unchanged contents order, and bounded actual final capacity.
- Refuse every spend/reserve prefix on representative real public Point
  construction, including heapsort, merge growth and typed mapping. Require
  accepted work never refunded and all physical source/temporary/final Vecs
  destroyed before their exact leases release. Rotate issuer at each allowed
  callback and ensure failure preserves complete owners through cleanup.
- Drop completed positive and empty carriers without handoff; require all real
  leases released in physical order and no aliasing of the dedicated mask lease
  with inventory/Core guards. Root's complete frozen policy bodies must pass
  exactly, with no normalization or layout/counter subtraction.

## Plan handoff protocol

- A conforming recording backend should observe borrowed pointer/len/cap from
  view, exact descriptor issuer/capacity/lease, then receive that identical Vec
  once in commit. This verifies protocol selection only, not native accounting.
- Wrong issuer and unmetered handoff must reject before prepare/commit. Empty
  metered final capacity has no lease; positive capacity has its dedicated
  lease even for a private finalizer test with length0/positive capacity.
- Prepare refusal must not invoke commit and the complete source/inventory
  must remain guarded until cleanup. Successful prepare's event must be
  immediately adjacent to commit: no issuer, spend, reserve, merge, Drop or
  trace callback occurs between them. No generic guard extraction is used.

## Native parent proof

- Use actual WorkControl, closed Admission, real Point producer and final native
  owner. Test shared-Ref refusal through the borrowed preparation helper while
  retaining the actual source owner; end that Ref before dropping the source.
  Do not claim graceful failure of consuming into_suppression under a conflicting
  Ref, since source Lease::drop would also need RefMut. Verify the actual closed
  caller holds no ledger Ref across construction/consumption and that final
  exclusive preflight ends every temporary borrow before commit.
- Force failures after lazy account admission, Box reservation and actual Box
  allocation; an unused prepared OwnedMask must physically free Box before
  retiring Box charge. No second vector allocation or reservation is accepted.
- At the final boundary, observe complete inventory/Core/contents + exact final
  vector + existing native payload + new shell/Box simultaneously. Stable total
  before/after commit differs only by actual new shell/Box; vector debit moves
  ledger->account exactly once. Final pointer/len/cap are identical.
- Confirm the token stores charge_frames_after and remaining ledger after all
  fallible work. Concurrent drops must not be resurrected by storing an old
  atomic live total. Commit must have no user callback, assertion failure,
  formatting, trace emission, allocation or cancellation check in its window.
- Destroy ReadWork, provider and controller before reading the actual final
  mask; its output type must contain no request ledger reference. Last payload
  drop reaches actual shell3 through the closed observer, then final account
  shell frees before its shell debit retires.
- Existing B Point/Bound/Root/Domain/retained/cache ownership tests and C-specific
  ordinary B replay compare true old semantics. Later Reference/Audio mapping
  must still admit the complete second destination while source remains live.
- Exact warmed resident cap including inventory/final Vec/shell/Box succeeds;
  one below refuses before allocation/commit. Existing invalid query flags
  remain literal, with independent host/native interval receipts explaining
  actual new debits. No canonical query weight or production cap is raised.
