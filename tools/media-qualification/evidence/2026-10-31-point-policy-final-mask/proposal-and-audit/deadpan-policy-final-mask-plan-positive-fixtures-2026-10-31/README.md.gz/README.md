# Genuine positive Plan policy fixture coverage

Scratch-only correction to the focused test visitor. Neither root nor any
fixture/oracle was edited. Rustfmt edition2024 parsed/formatted the new source;
no build, native run, capture, generation or Git operation was performed here.

## Retained failure evidence

The parent's first focused runs on both roots reported4 passed and3 failed.
The failing assertions were positivity coverage at lines364/427/557 in the
original source: positive>0/covered>0. All three selected frozen public
supplement Point domains produced empty policy. No production value mismatch
was observed before those final assertions. Those receipts remain unchanged:

- /tmp/deadpan-point-policy-final-mask-qualification-2026-10-31/policy-plan-focused-main.stdout
- /tmp/deadpan-point-policy-final-mask-qualification-2026-10-31/policy-plan-focused-scoped.stdout

This proposal corrects the fixture coverage, not the expected behavior or
positivity assertions. Existing seven test bodies remain byte-identical.

## Added actual factory inputs

The original three supplement documents/placements/grids and their exact
geometry assertions remain. The visitor additionally selects three named
records from the existing pre-C immutable Audio fixture:

- private-point-silent-hold: actual quiet Hold Point, frozen request0..16.
- private-point-source-padding: actual SelectedPlacement Source Point, frozen
  request0..32 with suppression0..16.
- private-point-genuine-preserve-bound: actual historical Preserve Bound Point,
  frozen request0..32 with suppression0..32.

Each record is reconstructed through public checked ProjectDocument parsing,
RenderPlan compilation, audio_definition(Node), and in_point_clock using its
exact frozen placement and grid origin. Definition, root, placement, grid,
reference sampling and reference support must match the immutable descriptor.
The ordinary policy for the literal recorded request must be nonempty and its
actual ranges must equal the frozen returned mask values. Full-support ordinary
policy must also be nonempty. No private Bound, fabricated mask or policy value
is constructed. Document/Point snapshots must remain unchanged afterward.

Every existing test then runs on all six checked domains. Its full-support and
empty-range requests therefore exercise positive and empty final Vecs through
real factories. The sort, exact dedicated lease, pointer/capacity, inventory
liveness, refusal-prefix and same-sized guard checks now receive positive input.
The recording backend remains Plan protocol evidence only, not native account/
Storage Box ownership evidence.

The new include_str references the already-existing sibling Audio test fixture
from Plan src: ../../deadpan-audio/tests/fixtures/point-policy-final-mask-baseline-v1/snapshot.json.
It adds no Cargo dependency or native invocation. Its exact bytes are34,885,733
and SHAaf7a292718365c34fa03692e2cbe58a2cfb3c6d444b5ae29d52647e1fdbbff14.
The parent's before-freeze-proof.json pins its independent pre-C source capture
and matching Main/Scope bodies; that proof is included in source-pins.json.

## Integration and verification owed

candidate.patch applies to the pinned original focused test file; the complete
source has SHA62bbeb5b8e5d40f3c1dd671437702250a0661dc8718ab6febc10df1a75299564.
At final pinning, both roots already matched the proposed complete source,
following parent-owned integration. This agent made no root edits. No API or
production change is proposed. Parent must recompile/rerun the same seven tests
on both roots. No corrected run is claimed here; any new value, canonical-work
or protocol failure must remain literal evidence.
