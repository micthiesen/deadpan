# Native Point final-mask backend candidate

Scratch proposal only. No repository files were edited; no build or native test was run.

The patch adds two private child modules and path declarations:

- `point_suppression/policy_handoff.rs` reserves the existing `Storage<SignalSample>` Box-only charge, constructs the existing `OwnedMask` wrapper around an empty-capacity Vec, prechecks the transferable vector charge, then moves the exact final Vec into that storage on commit.
- `sound_context_admission/policy_mask_handoff.rs` implements Plan's `AudioSignalPolicyMaskHandoff` on the private existing `Admission`, checks the issuer/capacity/source ledger, performs the final fallible `try_borrow_mut` subtraction preflight, and immediately applies that precomputed subtraction in commit. Its private `preflight_source_lease` helper is exercised by an own-module test holding an external `Ref` while retaining a Lease value of the concrete source type; the test releases the `Ref` before dropping the Lease.

The chosen native helper API is:

```rust
point_suppression::policy_handoff::vector_frames(capacity)
    -> Result<u64, StageAudioError>
point_suppression::policy_handoff::prepare_policy_mask(
    renderer: &mut StageAudio,
    capacity: usize,
    control: WorkControl<'_>,
) -> Result<PreparedPolicyMask, StageAudioError>
PreparedPolicyMask::vector_frames() -> u64
PreparedPolicyMask::publish(
    self,
    exact_ranges: Vec<Range<SignalSample>>,
) -> SignalSuppressionMask
```

The admission token stores the prepared native owner and, for a positive capacity, the exact request ledger reference plus its precomputed remaining value. It relies on Plan's private consuming handoff calling commit immediately with the same source lease that its descriptor carried. The trait contract is trusted infrastructure, as documented in the Plan candidate.

`proposal.patch` is the filesystem diff from `before/` to `new/`. It expects the separately pinned Plan candidate to export `AudioSignalPolicyMaskHandoff` and `SignalPolicyMaskRef`. The exact checked-in native sources and Plan candidate/design/review inputs are listed in `source-pins.sha256`.

Review points for parent integration:

- `Admission` and its concrete token are module-private; retain that visibility.
- There is no new unsafe code. The positive-token `expect` follows the private constructor invariant that only prepares `Owned { owner.storage: Some(Box<Storage>) }`; source-lease and commit-borrow `expect`s occur before publication begins. Keep these constructors private.
- The borrowed-ledger test constructs the concrete Lease value directly instead of obtaining one through `Admission::reserve`; it exercises rejection before consuming a query. It does not claim recovery when consuming `into_suppression` encounters an external RefCell borrow; the real caller has no callback or interposed borrow between prepare and commit.
- Empty capacity produces no account, Box, or charge.
- Positive capacity first charges only `Layout::new::<Storage<SignalSample>>()`; the source Vec stays separately leased through Box preparation and final preflight. Commit credits the already checked vector frames to the same existing account charge, installs the exact Vec, then clears the source ledger and lease.
- Commit obtains the source lease reference and a fresh exclusive `RefMut` before the first account or Vec mutation. The prepare-time checked borrow was already released before returning its token. Error cleanup, concurrent controller mutation, and panic-in-allocator behavior were not experimentally executed here.
