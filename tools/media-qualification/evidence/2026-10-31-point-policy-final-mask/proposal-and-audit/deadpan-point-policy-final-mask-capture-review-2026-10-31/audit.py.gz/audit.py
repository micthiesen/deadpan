from pathlib import Path
import hashlib,json,collections
P=Path('/tmp/deadpan-point-policy-final-mask-qualification-2026-10-31')
D=Path('/tmp/deadpan-point-policy-final-mask-capture-review-2026-10-31')
cache={}
def pin(path):
 p=Path(path).resolve()
 if str(p) in cache:return cache[str(p)]
 h=hashlib.sha256();size=0
 with p.open('rb') as f:
  for chunk in iter(lambda:f.read(1024*1024),b''):size+=len(chunk);h.update(chunk)
 r={'bytes':size,'sha256':h.hexdigest()};cache[str(p)]=r;return r
def load(name):return json.loads((P/name).read_text())
pins={}
def evidence(path):
 p=Path(path)
 pins[str(p)]=pin(p)
def check_streams(r):
 for path,want in r['streams'].items():assert pin(path)==want,path;evidence(path)
def guard(r):
 assert r['exit_code']==0
 assert r['source_before']==r['source_after'] and r['sources_unchanged']
 assert r['binary_before']==r['binary_after'] and r['binaries_unchanged']
 assert r['removed_paths_absent_before']==r['removed_paths_absent_after']
 assert all(not (Path(r['cwd'])/a).exists() for a in r['removed_paths_absent_after'])
 for path,want in r['binary_after'].items():assert pin(path)==want,path;evidence(path)
 check_streams(r)
results={'captures':[]}
active_sha='afa6038a02c959c7192c09c08a89266c7d52151a5e59a4f69828fbdf67e7414e'
base='eedbc58272bdd009a65239b7104ddb786a2554fc'
current_changes={}
for variant,root in [('main',Path('/Users/michael/Code/deadpan')),('scoped',Path('/tmp/deadpan-query-groundwork-2026-10-26/scoped'))]:
 runner=P/('run_qualified.py' if variant=='main' else 'run_scoped_qualified.py')
 evidence(runner)
 for suffix in ['','-2','-3']:
  label=f'policy-final-active-{variant}{suffix}'
  r=load(label+'.json');proof=load(label+'-proof.json');m=load(label+'-source-manifest.json')
  for ending in ['.json','-proof.json','-source-manifest.json','-body.json','-canonical.json']:evidence(P/(label+ending))
  guard(r)
  assert r['cwd']==str(root)
  assert r['runner_sha256']==pin(runner)['sha256']
  norm={str(Path(k).relative_to(root)):v for k,v in r['source_before'].items()}
  assert norm==m
  assert proof['source_inputs']==len(m)
  assert proof['source_manifest_sha256']==pin(P/(label+'-source-manifest.json'))['sha256']
  assert proof['base_revision']==base and proof['mode']=='policy' and proof['variant']==variant
  assert len(r['binary_after'])==1
  bp=next(iter(r['binary_after']))
  assert r['command']==[bp,'--ignored','--exact','stages::bound_reads::retained_host_baseline::pairs::native_mask_after::capture_active_point_policy_after_v1','--nocapture','--test-threads=1']
  assert proof['binary_sha256']==pin(bp)['sha256']
  env=r['environment'];pre='DEADPAN_POINT_POLICY_AFTER'
  assert Path(env[pre+'_OUTPUT']).resolve()==(P/(label+'-body.json')).resolve()
  assert env[pre+'_SOURCE_SHA256']==proof['source_manifest_sha256']
  assert env[pre+'_PUBLISHED_CHECKPOINT']==base
  var='main-inherited' if variant=='main' else 'scoped-published'
  assert env[pre+'_VARIANT']==var
  assert env['CARGO_PROFILE_DEV_OPT_LEVEL']=='2' and env['CARGO_INCREMENTAL']=='0' and env['DEADPAN_REQUIRE_PHYSICAL_MAC']=='1'
  assert env['DEADPAN_BRIDGE_FFMPEG']=='/opt/homebrew/bin/ffmpeg'
  body=load(label+'-body.json')
  assert body.pop('variant')==var and body.pop('source_sha256')==proof['source_manifest_sha256']
  native=body['native_requests']
  assert native.pop('variant')==var and native.pop('source_sha256')==proof['source_manifest_sha256']
  canonical=(json.dumps(body,sort_keys=True,separators=(',',':'))+'\n').encode()
  assert hashlib.sha256(canonical).hexdigest()==active_sha
  assert canonical==(P/(label+'-canonical.json')).read_bytes()
  assert proof['bytes']==len(canonical)==35440148 and proof['sha256']==active_sha
  results['captures'].append({'label':label,'source_inputs':len(m),'source_manifest':proof['source_manifest_sha256'],'binary':proof['binary_sha256'],'canonical':active_sha,'exit_code':0})
 # current-byte checks once per root, separate from historical guards
 current_changes[variant]=[rel for rel,want in m.items() if not (root/rel).exists() or pin(root/rel)!=want]
results['current_source_changes']=current_changes
historical={}
for mode,sha in [('before-off','af7a292718365c34fa03692e2cbe58a2cfb3c6d444b5ae29d52647e1fdbbff14'),('before-interval','f64d3a00a10967cc3822083d21705bd454f2d33ff2198da30e25671092ab5a53')]:
 for variant in ['main','scoped']:
  f=P/f'policy-final-{mode}-{variant}-canonical.json'
  assert pin(f)['sha256']==sha;evidence(f);historical[f.name]=pin(f)
results['historical']=historical
old=load('policy-final-before-interval-scoped-canonical.json')
new=load('policy-final-active-scoped-canonical.json')
left=old['native_requests']['cases'];right=new['native_requests']['cases'];assert len(left)==len(right)
counts=collections.Counter()
for a,b in zip(left,right):
 assert a['fixture']==b['fixture'] and len(a['operations'])==len(b['operations'])
 for x,y in zip(a['operations'],b['operations']):
  assert {k:v for k,v in x.items() if k!='paired'}=={k:v for k,v in y.items() if k!='paired'}
  outx=x['paired']['new']['read']['output'];outy=y['paired']['new']['read']['output']
  assert outx==outy
  counts[outx['status']]+=1
assert sum(counts.values())==744 and counts=={'Ok':264,'Error':480}
results['complete_native_outputs']={'count':744,'statuses':dict(counts)}
fields=[]
for name,a,b in [('internal',old['internal_and_transfer_paths']['cases'],new['internal_and_transfer_paths']['cases']),('transfer',old['internal_and_transfer_paths']['public_transfers']['cases'],new['internal_and_transfer_paths']['public_transfers']['cases'])]:
 assert len(a)==len(b)==(10 if name=='internal' else 4)
 for x,y in zip(a,b):
  assert x['name']==y['name']
  ks=[k for k in x if k.startswith('result_') or k.startswith('account_')]
  for k in ks:assert x[k]==y[k],(x['name'],k)
  fields.append({'group':name,'name':x['name'],'complete_exact_fields':ks})
results['internal_and_transfer']=fields
intervals=collections.Counter();partial=[];invalid=0
def visit(v,path=''):
 global invalid
 if isinstance(v,dict):
  if v.get('invalid') is True:invalid+=1
  if v.get('schema')=='native-mask-query-intervals-v1':
   assert v['active_intervals']==v['dropped_intervals']==0 and not v['misnested'] and not v['overflow'],path
   intervals['snapshots']+=1
   for r in v['rows']:
    intervals['rows']+=1
    assert r['attributable'] and not r['foreign_work_overlap']
    assert r['selected_lane'] in [0,1]
    assert len(r['work_before'])==len(r['work_after'])==2
    for pre in ['native','host']:
     a=r[pre+'_before'];b=r[pre+'_after']
     assert a['reset_epoch'] is not None and a['reset_epoch']==b['reset_epoch']
     assert not a['overflow'] and not b['overflow']
    assert r['native_before']['enabled'] and r['native_after']['enabled']
    assert len(r['native_before']['lanes'])==len(r['native_after']['lanes'])==2
    if r['claim'] is None:
     intervals['partial']+=1;partial.append({'path':path,'row':r});continue
    intervals['completed']+=1
    c=r['claim'];assert c['canonical']+c['additional']==c['total']
    assert c['forwarded'] and not c['ordinary'] and c['expected_debit']==c['total']
    for lane in [0,1]:
     a=r['native_before']['lanes'][lane];b=r['native_after']['lanes'][lane]
     assert len(a)==len(b)==8
     phases=[z-w for w,z in zip(a,b)]
     host=r['host_after']['units'][lane]-r['host_before']['units'][lane]
     observed=r['work_after'][lane]-r['work_before'][lane]
     assert min(phases)>=0 and host>=0 and observed>=0
     assert observed==(c['expected_debit'] if lane==r['selected_lane'] else 0)+sum(phases)+host
  else:
   for k,a in v.items():visit(a,path+'/'+k)
 elif isinstance(v,list):
  for i,a in enumerate(v):visit(a,path+'/'+str(i))
visit(new)
assert dict(intervals)=={'snapshots':758,'rows':478,'completed':477,'partial':1}
results['intervals']=dict(intervals);results['partial']=partial;results['literal_invalid_true_fields']=invalid
join=load('final-qualification-join.json');evidence(P/'final-qualification-join.json')
join_results={}
for variant,root in [('main',Path('/Users/michael/Code/deadpan')),('scoped',Path('/tmp/deadpan-query-groundwork-2026-10-26/scoped'))]:
 oldr=load(f'policy-all-targets-{variant}.json');newr=load(f'policy-final-library-build-{variant}.json')
 for n in [f'policy-all-targets-{variant}.json',f'policy-final-library-build-{variant}.json',f'policy-all-targets-{variant}-pins.json',f'policy-final-library-build-{variant}-pins.json']:evidence(P/n)
 assert oldr['exit_code']==newr['exit_code']==0 and oldr['sources_unchanged'] and newr['sources_unchanged']
 check_streams(oldr);check_streams(newr)
 rel='crates/deadpan-audio/src/bound_reads/native_mask_after.rs';absolute=str(root/rel)
 assert set(oldr['source_after'])==set(newr['source_after'])
 assert [k for k in oldr['source_after'] if oldr['source_after'][k]!=newr['source_after'][k]]==[absolute]
 current=(root/rel).read_bytes();before=current.replace(b'independent projected-provider and derived policies remain ordinary',b'independent Root/derived policies remain ordinary')
 assert before!=current
 assert {'bytes':len(before),'sha256':hashlib.sha256(before).hexdigest()}==oldr['source_after'][absolute]
 assert pin(root/rel)==newr['source_after'][absolute]
 compiled=load(f'policy-all-targets-{variant}-pins.json')
 retained=[x for x in compiled if x['name']!='deadpan_audio'];assert len(retained)==20
 assert join[variant]['unchanged_integration_binaries']==[{'target':x['name'],'sha256':x['sha256']} for x in retained]
 for x in retained:
  assert pin(x['path'])=={'bytes':x['bytes'],'sha256':x['sha256']}
  evidence(x['path'])
  a=x['artifact'];assert a['reason']=='compiler-artifact' and a['target']['name']==x['name'] and a['profile']['opt_level']=='2' and a['profile']['test']
  # published pin is copied exact from compiler artifact executable
  assert a['executable'] in a['filenames']
  receipt=load(f"policy-matrix-{variant}-{x['name'].replace('_','-')}.json")
  guard(receipt)
  assert receipt['command'][0]==x['path']
  assert receipt['source_before']==oldr['source_after']
  assert receipt['binary_before'][x['path']]==pin(x['path'])
  evidence(P/f"policy-matrix-{variant}-{x['name'].replace('_','-')}.json")
 finalpins=load(f'policy-final-library-build-{variant}-pins.json')
 assert join[variant]['final_library_pins']==finalpins
 assert len(finalpins)==1 and finalpins[0]['name']=='deadpan_audio'
 x=finalpins[0];assert pin(x['path'])=={'bytes':x['bytes'],'sha256':x['sha256']}
 assert newr['source_after']==load(f'policy-final-active-{variant}.json')['source_before']
 a=x['artifact'];assert a['profile']['opt_level']=='2' and a['profile']['test'] and Path(a['target']['src_path']).resolve()==(root/'crates/deadpan-audio/src/lib.rs').resolve()
 join_results[variant]={'retained_integrations':20,'exact_scope_label_only':True,'final_library_compiler_artifact':True}
results['join']=join_results
for n in ['final-capture-analysis.json','before-freeze-proof.json','capture_after.py','analyze_final_capture.py','extend_final_capture_proof.py','final_join.py']:evidence(P/n)
(D/'evidence-pins.json').write_text(json.dumps(pins,indent=2,sort_keys=True)+'\n')
(D/'audit-results.json').write_text(json.dumps(results,indent=2,sort_keys=True)+'\n')
print(json.dumps({k:v for k,v in results.items() if k not in ['internal_and_transfer','partial','historical']},indent=2))
