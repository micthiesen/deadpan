exec(open('/tmp/deadpan-point-policy-final-mask-capture-review-2026-10-31/audit.py').read().split("print(json.dumps(")[0])
import re
extra={'historical_receipts':[],'runtime_receipts':{},'authority_bytes':{}}
for mode,prefix,checkpoint in [
 ('before-off','DEADPAN_INTERNAL_MASK_AFTER','e8fcdb3cb02f9682bef53f6ba2709e8a5ad692d0'),
 ('before-interval','DEADPAN_QUERY_INTERVAL_AFTER','ab211a2f132379a246157c3596d95fc42121541c')]:
 for variant in ['main','scoped']:
  label=f'policy-final-{mode}-{variant}'
  r=load(label+'.json');guard(r)
  proof=load(label+'-proof.json')
  assert proof['base_revision']==checkpoint
  env=r['environment'];assert env[prefix+'_PUBLISHED_CHECKPOINT']==checkpoint
  assert env[prefix+'_SOURCE_SHA256']==proof['source_manifest_sha256']
  assert pin(P/(label+'-source-manifest.json'))['sha256']==proof['source_manifest_sha256']
  body=load(label+'-body.json')
  var=env[prefix+'_VARIANT']
  assert body.pop('variant')==var and body.pop('source_sha256')==proof['source_manifest_sha256']
  assert body['native_requests'].pop('variant')==var and body['native_requests'].pop('source_sha256')==proof['source_manifest_sha256']
  canonical=(json.dumps(body,sort_keys=True,separators=(',',':'))+'\n').encode()
  assert canonical==(P/(label+'-canonical.json')).read_bytes()
  assert pin(P/(label+'-canonical.json'))=={'bytes':proof['bytes'],'sha256':proof['sha256']}
  for end in ['.json','-proof.json','-source-manifest.json','-body.json']:evidence(P/(label+end))
  extra['historical_receipts'].append(label)
for variant,root in [('main',Path('/Users/michael/Code/deadpan')),('scoped',Path('/tmp/deadpan-query-groundwork-2026-10-26/scoped'))]:
 for auth in [*new['before_authorities'],new['immediate_before']]:
  p=root/'crates/deadpan-audio'/auth['path']
  assert pin(p)['sha256']==auth['sha256'];evidence(p)
  extra['authority_bytes'][str(p)]=pin(p)
 for rel in ['crates/deadpan-audio/src/bound_reads/native_mask_after.rs','crates/deadpan-audio/src/stages.rs','crates/deadpan-audio/src/bound_reads/retained_host_pairs.rs','crates/deadpan-audio/src/bound_reads/retained_host_baseline.rs','crates/deadpan-audio/src/bound_reads/internal_suppression_baseline.rs']:
  evidence(root/rel)
 label=f'policy-final-library-{variant}';r=load(label+'.json');guard(r)
 assert r['source_before']==load(f'policy-final-active-{variant}.json')['source_before']
 libpin=load(f'policy-final-library-build-{variant}-pins.json')[0]
 assert r['command'][0]==libpin['path'] and r['binary_before'][libpin['path']]==pin(libpin['path'])
 evidence(P/(label+'.json'))
 text=(P/(label+'.stdout')).read_text()
 m=re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored; \d+ measured; (\d+) filtered out',text)
 assert len(m)==1
 passed,failed,ignored,filtered=map(int,m[0])
 assert failed==0 and passed==(526 if variant=='main' else 520) and ignored==21 and filtered==0
 rows=load(f'policy-matrix-{variant}-matrix.json');assert len(rows)==21
 total=collections.Counter()
 for row in rows:
  run=row.get('run',row.get('retained_exact_binary_run'))
  receipt=load(run+'.json');guard(receipt);evidence(P/(run+'.json'))
  stdout=(P/(run+'.stdout')).read_text()
  match=re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored; \d+ measured; (\d+) filtered out',stdout)
  assert len(match)==1
  for k,v in zip(['passed','failed','ignored','filtered'],match[0]):total[k]+=int(v)
  assert next(iter(receipt['binary_after'].values()))['sha256']==row['sha256']
 assert total=={'passed':1107 if variant=='main' else 1101,'failed':0,'ignored':21,'filtered':7 if variant=='main' else 0}
 extra['runtime_receipts'][variant]={'matrix':dict(total),'final_audio_library':{'passed':passed,'failed':failed,'ignored':ignored,'filtered':filtered}}
for variant in ['main','scoped']:
 label=f'policy-plan-library-{variant}'
 r=load(label+'.json');guard(r);evidence(P/(label+'.json'))
 text=(P/(label+'.stdout')).read_text()
 matches=re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored; \d+ measured; (\d+) filtered out',text)
 assert matches==[(str(289 if variant=='main' else 276),'0','28','0')]
 extra['runtime_receipts'][variant]['plan_library']={'passed':289 if variant=='main' else 276,'failed':0,'ignored':28,'filtered':0}
(D/'extra-results.json').write_text(json.dumps(extra,indent=2,sort_keys=True)+'\n')
(D/'evidence-pins.json').write_text(json.dumps(pins,indent=2,sort_keys=True)+'\n')
print(json.dumps({'historical_receipts':extra['historical_receipts'],'runtime_receipts':extra['runtime_receipts'],'authority_files':len(extra['authority_bytes'])},indent=2))
