// DESIGN SKETCH ONLY. Separate proposed Plan and Audio declarations.
// No compilation or native execution. Existing Root/Audio API remains unchanged.

// PLAN: opaque source descriptor; fields and constructor remain Plan-private.
pub struct SignalPolicyMaskRef<'value, I, L> {
    issuer: I,
    capacity: usize,
    lease: Option<&'value L>,
}
impl<I: Copy, L> SignalPolicyMaskRef<'_, I, L> {
    pub fn issuer(&self) -> I { self.issuer }
    pub fn capacity(&self) -> usize { self.capacity }
    pub fn lease(&self) -> Option<&L> { self.lease }
}

// Trusted accounting infrastructure, with the same non-unwinding contract as
// AudioSoundContextAdmission::merge. This trait is OPEN for the Audio backend;
// source construction, extraction and concrete Audio token construction are sealed.
pub trait AudioSignalPolicyMaskHandoff: AudioSoundContextAdmission {
    type PreparedMask;
    type Mask;
    fn prepare_signal_mask(
        &mut self,
        source: SignalPolicyMaskRef<'_, Self::Issuer, Self::Lease>,
    ) -> Result<Self::PreparedMask, Self::Error>;
    // Allocation-free, infallible, non-unwinding. Receives exactly the descriptor's
    // Vec and lease from Plan's closed consuming method, once.
    fn commit_signal_mask(
        &mut self,
        prepared: Self::PreparedMask,
        ranges: Vec<std::ops::Range<SignalSample>>,
        source_lease: Option<&mut Self::Lease>,
    ) -> Self::Mask;
}

// No final mask is ever adopted into/merged with the inventory's guard memory.
struct FinalSignalMask<I, L> {
    ranges: Vec<std::ops::Range<SignalSample>>,
    memory: Memory<I, L>,
}
struct SignalPolicyInventory<I, L> {
    contents: Vec<AudioContent>,
    contents_capacity: Memory<I, L>,
}
pub struct AdmittedSignalPolicyQuery<I, L> {
    mask: FinalSignalMask<I, L>,
    inventory: GuardedBound<SignalPolicyInventory<I, L>, I, L>,
    lookup: LookupStats,
    canonical: usize,
    additional: usize,
    forwarded: bool,
}
pub struct SignalPolicyView<'value> {
    pub suppressed: &'value [std::ops::Range<SignalSample>],
    pub contents: &'value [AudioContent],
    pub lookup: LookupStats,
    pub work: usize,
}
// Proposed inherent API:
// impl AudioPointDomain {
//   fn policy_admitted<A: AudioSoundContextAdmission>(
//     &self, samples: Range<SignalSample>, limits: AudioQueryLimits, admission: &mut A,
//   ) -> Result<AdmittedSignalPolicyQuery<A::Issuer,A::Lease>,A::Error>;
// }
// impl<I:Copy+Eq,L> AdmittedSignalPolicyQuery<I,L> {
//   fn view(&self)->SignalPolicyView<'_>;
//   fn canonical_units(&self)->usize;
//   fn additional_units(&self)->usize;
//   fn was_forwarded(&self)->bool;
//   fn into_suppression<A: AudioSignalPolicyMaskHandoff<Issuer=I,Lease=L>>(
//      self, admission:&mut A,
//   )->Result<A::Mask,A::Error>;
// }

// AUDIO: private token, and a closed implementation on existing Admission.
struct PreparedPolicyMask<'work> {
    // Nonempty path: existing OwnedMask wrapper, containing the prepared
    // Box<Storage<SignalSample>> with an empty Vec. Its existing custom Drop
    // frees Box before retiring Charge; a bare Box field would not do so.
//  owner: OwnedMask<SignalSample>,
    // That Storage's ordinary Charge already owns ONLY actual Box frames.
//  ledger: &'work RefCell<ReadWork>,
    remaining_ledger_frames: u64,
    vector_frames: u64,
}
// impl<'work> AudioSignalPolicyMaskHandoff for Admission<'_,'work> {
//   type PreparedMask = PreparedPolicyMask<'work>;
//   type Mask = SignalSuppressionMask;
//   ... concrete preparation/commit steps in contract.md ...
// }
//
// The real token needs no new Box layout or Option<Storage>: initialize the
// existing Storage { ranges: Vec::new(), charge: actual_box_only_charge }.
// Reserve its real Layout::new::<Storage<SignalSample>>() through make_room.
// Empty final Vec cap0 uses no native shell/Box and returns Default mask.
