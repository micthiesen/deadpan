# C: exact Point policy final-mask handoff

Design only, based on the pinned active Scope sources. No root edits, builds,
native execution, or policy admission claim. B must qualify first.

## Preferred boundary

Add a Point-only admitted policy product. It constructs the final
Vec<Range<SignalSample>> directly with PointCeil, retains that Vec's independent
capacity lease, and transfers that exact allocation to B's existing native
Storage after numerical use. Keep Root/Audio policy's existing finish, carrier,
layout, work and compatibility body unchanged in this unit.

Do not consume Root policy and relabel AudioSample. The actual ordinary Signal
entry uses PointCeil in audio_policy.rs; the admitted factory must call existing
audio_policy_query::signal_policy with PointCeil and endpoints=true on the
actual closed AudioPointDomain::signal_ref(). Arbitrary provider-backed Signal
policy remains outside this entrypoint.

The final Vec has exact count capacity as in existing admitted finish. Its
Memory is never passed to adopt_memory, merge_checked, or GuardedBound::zip.
The inventory still needs its complete existing independent Plan/Core guards.

## Concrete Plan types and APIs

See api-sketch.rs for signatures. Add these in audio_policy_query.rs and export
only the new public types/trait required by Audio in the existing Plan exports:

- FinalSignalMask<I,L> has ranges first, then its one independent Memory<I,L>.
  Both fields and every constructor are Plan-private. The lease is exclusively
  the exact final Vec Layout; do not combine it with work buffers or inventory.
- SignalPolicyInventory<I,L> owns contents and its capacity Memory behind the
  existing GuardedBound. It has no final mask member or final mask lease.
- AdmittedSignalPolicyQuery holds both owners, lookup, canonical/additional and
  forwarding provenance. view() returns a borrowed SignalPolicyView containing
  suppressed and contents slices, lookup and work. This small view avoids
  extracting fields from a potentially Core-backed GuardedBound.
- AudioPointDomain::policy_admitted(samples,limits,&mut A) builds that product.
  A new finish_signal follows the existing integer merge and direct typed final
  allocation order. The existing Audio finish stays unchanged; do not perform a
  generic Root finalizer refactor merely to share these lines.
- into_suppression(self,&mut A) is the only consuming final-mask handoff. It
  retains the inventory guard and FinalSignalMask through preflight. It validates
  issuer and metered provenance before calling the trusted backend, then moves
  the exact ranges Vec and exact mutable lease into one no-fail commit. Only
  after commit may the complete inventory and the disarmed final Memory drop.

SignalPolicyMaskRef is a public opaque descriptor, privately constructed by
Plan, exposing issuer(), capacity(), lease(). It exposes no mutable ranges or
lease, and cannot be fabricated as a valid Plan product by normal construction.

AudioSignalPolicyMaskHandoff extends AudioSoundContextAdmission with associated
PreparedMask/Mask, a fallible prepare_signal_mask(descriptor), and infallible
commit_signal_mask(prepared, exact Vec, exact Option<&mut Lease>). The concrete
Audio token and constructors stay private. There is no general into_parts,
mutable Vec access, Clone, Vec conversion, or owning iterator.

Trust qualification: this cross-crate backend trait must be OPEN so Audio can
implement it. It cannot truthfully be described as a globally sealed trait or
as mechanically enforcing non-unwinding callbacks. Its trust contract matches
the existing AudioSoundContextAdmission::merge and GuardedChargeTransfer commit
callbacks. The source carrier, descriptor construction, consuming selection,
and concrete Audio destination token are sealed. An arbitrary malicious backend
could violate this accounting contract just as it can today's Admission trait.

Compatibility A::METERED=false may expose the same borrowed view around the
ordinary policy result, but must not import a nonempty uncharged Vec through
the owned handoff. Reject unmetered handoff before preparation; Audio's actual
legacy path calls its existing ordinary constructor and literal Vec body.

## Concrete native destination, with no replacement Vec

Implement the new trait on sound_context_admission::Admission<'controller,
'work>, using its existing renderer/control. The implementation delegates to
private helpers in point_suppression.rs and sound_context_admission.rs.

PreparedPolicyMask<'work> contains an existing OwnedMask<SignalSample> wrapping
the prepared Box<Storage<SignalSample>>, source ledger reference, precomputed
remaining ledger frames, and exact vector frames. It does not hold a live
mutable controller borrow. A bare Box field's default Drop is WRONG here:
it would retire its inner Charge before freeing the Box allocation. The
existing OwnedMask destructor is required on unused/failed prepared tokens too.

Use the EXISTING Box<Storage<SignalSample>> representation. Its initial contents
are Storage { ranges: Vec::new(), charge: admitted_box_only_charge }. There is
no need for Box<Option<Storage>>, a new Storage layout, dummy allocated Vec,
or an unused builder API. The prepared empty Vec has capacity0 and no payload.

Preparation order for a positive final capacity:

1. Check current WorkControl and exact issuer identity. Compute the actual
   Layout::array<Range<SignalSample>>(capacity) and its frame count. Require the
   source lease to belong to that same actual ledger and contain exactly that
   count. This is possible only because Plan never merged this lease away.
2. Ensure/charge the existing lazy account shell using existing Account work,
   make_room and checks. All Plan inventory, temporary survivors and final
   Vec remain live and counted. Any existing target account payload stays live.
3. Reserve ONLY actual Layout::new<Storage<SignalSample>>() through the existing
   account/controller mechanism. make_room sees shell + Box + the still-live
   final Vec + all other Plan/native allocations. Do not reserve the vector
   again; it already physically exists under its exact request lease.
4. Accept AllocateStorage work immediately before allocating that actual Box.
   Initialize it with empty Vec and the Box-only Charge, immediately inside
   existing OwnedMask with no intervening fallible code. That owner's custom
   drop follows physical Box, Vec, Charge order on every failure.
5. Perform final cancellation/control and source identity/capacity/lease checks,
   checked ledger subtraction, checked charge.frames+vector_frames and checked
   account live+vector_frames. All must precede publication. The account's sole
   mutable publisher is still this controller; concurrent others only subtract.
6. Return the private prepared token. Plan immediately invokes commit with the
   original Vec and original lease, without checks, callbacks, allocation,
   arithmetic, vector operations, guard drops, or other code between them.

The checked remaining ledger total is valid only because the COMPLETE query
owner remains live and no request-lease owner may drop between steps5 and
commit. Do not store this token for later, expose its constructor, or permit
an arbitrary host callback between preparation and commit.

No-fail commit steps:

1. Credit vector_frames to the prepared Storage's existing account with the
   prechecked atomic fetch_add; extend that same Charge's frames with its
   prechecked total. This duplicates no Arc handle and reserves no new quota.
2. Move the exact source Vec into prepared Storage.ranges, replacing only the
   empty capacity0 Vec. Its pointer, len and capacity remain identical.
3. Set the source ledger to the precomputed remaining value and disarm exactly
   that source lease. The native account already owns all vector frames.
4. Move the prepared OwnedMask into Value::Owned and return
   SignalSuppressionMask. No allocation occurs in this publication tail.

This is a custody transfer, not a refund: the vector allocation remains alive
and continuously charged. Its final payload charge can disappear only after
the actual final Box and vector are freed by B's existing destructor. There is
a transient conservative overlap of vector charges inside the no-callback
commit, but no intervening allocation/admission or cap decision sees it. Total
stable residency is unchanged by moving vector frames between ledger/account.

Capacity0 is a separate exact empty case: final Memory has no lease, ranges
has capacity0, and preparation creates no account, Box or native allocation
fee. Commit returns the ordinary heapless empty mask. Nonempty capacity with
length0 would still require the full charge; never branch on length alone.

## Native callsite and compatibility scope

Introduce private SignalPolicyInput<'work> in stages or a focused child:
Ordinary(AudioPolicyQuery<SignalSample>) and Admitted(AdmittedSignalPolicyQuery<
Issuer<'work>,Lease<'work>>). Both provide the borrowed policy view. Wrap the
other ordinary read_signal caller rather than generalizing every renderer type.

read_point_domain_controlled builds the new admitted Point policy using a fresh
sound_context Admission on its same controller/control, then ends that mutable
borrow. It forwards canonical/additional work once according to the returned
forwarded flag, like current content queries. Preflight and numerical consumers
borrow view(). The admitted policy stays alive during child/media reads and
actual PCM suppression. At the current end of read_signal_queries:

- Ordinary keeps literal merged_suppression(policy.suppressed), Plain wrapping,
  and B's existing Point-tail into_admitted copy when the new policy lane is off.
- Admitted consumes into_suppression using a fresh Admission with the SAME
  control/issuer and renderer. Do not call merged_suppression or into_admitted
  again: the Plan finalizer already sorted/coalesced and owns this allocation.

B's later Point public mapping, Bound transfer, retained Audio mapping and cache
owners then operate unchanged. Their actual replacement destinations remain
separately admitted while this imported source stays alive.

Preserve the existing foreign-domain/depth/range, content-before-policy,
preflight-before-media, cancellation, suppression and final control-check order.
Every fallible action is before this handoff's commit; later ordinary caller
checks may still return Error and correctly dispose the newly owned mask.
Do not remove a later cancellation check to make publication look infallible.

Use a distinct cfgtest C-legacy switch to replay B's qualified behavior with
all B owners still active. Existing pre-B legacy chains must also select this
ordinary policy lane. Do not conflate C legacy with internal_mask_request,
which would turn off the B behavior that C's before comparison needs.

## Files and exact obligations

Plan: audio_policy_query.rs (new carrier/factory/finalizer/descriptor/trait),
existing Plan public exports, and focused Point policy admission/handoff tests.
No necessary Root finish/GuardedBound/Core changes.

Audio: sound_context_admission.rs (exact lease preflight and no-fail custody
transfer), point_suppression.rs (prepared existing Box/account publication),
stages.rs or new private Point policy adapter (two private numerical/preflight
callers), separate C trace and legacy switch, focused native tests.
mask_context.rs need not grow a generic public import method: this import uses
the original Plan Admission and its exact Lease, not arbitrary MaskContext.

No canonical weight changes. Existing policy canonical operations remain
canonical; actual Signal finalizer allocation/mapping work is additional through
the existing QueryBudget convention. New native shell/Box work remains native
work, separately identifiable. Vector handoff is a transfer counter, not a new
native vector-allocation/reservation receipt. Existing query trace invalid flags
must not be normalized to absorb these independent host phases.

## Meaningful tests and remaining proof risks

1. Plan PointCeil equivalence against ordinary actual Point factory for negative
   and fractional boundaries, SelectedPlacement padding, explicit Hold,
   genuine nested Preserve Bound and empty ranges. Compare labels, contents,
   lookup and canonical work; capacity is actual and final lease bytes exactly
   match its real Layout. Root admitted regressions remain byte-identical.
2. Final capacity lease remains separate from inventory Plan/Core/contents
   leases. Count actual reservations/merges; assert no merge targets it. Failure
   of every reserve/work prefix drops physical Vecs before their real leases.
3. Handoff identity mismatch, wrong capacity lease and cancellation before
   publication cannot invoke commit or alter the source vector/lease. An unused
   prepared Box must dispose Box before charge; original guarded query remains
   valid or drops under its original lease.
4. Capture actual final Vec pointer/len/cap in Plan and final native storage:
   identical across commit. No second vector allocation, map/merge fee or
   native vector reservation. Observe simultaneous source/query metadata,
   existing native payload, shell and Box charges during preflight.
5. At commit stable total before/after differs only by actual new shell+Box,
   while vector frames move ledger->account exactly once. No borrowed ledger
   reference remains in output. Drop local ReadWork/provider/controller, then
   inspect actual retained mask and release to shell3 via a closed observer.
6. Existing B active native Point/Bound/transfer/retained/cache tests plus C
   ordinary-lane frozen before comparisons. Public reference mapping still
   requires source+destination overlap and preserves JSON/PCM masks and bits.
7. Real warmed cap exactly covers existing metadata+final Vec+native shell+Box
   and succeeds; one below rejects before allocation/commit. Avoid unstable
   first-success cap searches. Failed attempts do not refund accepted work.

Safe Rust cannot mechanically prove non-unwinding backend callbacks or absence
of retained RefCell borrows. The concrete implementation must make that tail
small, private and inspectable, with all temporary borrows ending before commit.
No user callbacks occur. Generic Plan backends remain trusted infrastructure.

The proposed finish_signal must undergo its own actual-work audit. Existing
finish contains sort/merge loops outside per-operation cancellation callbacks;
reusing that shape is not proof that every C loop satisfies the complete spec.
This seam design does not resolve unrelated independent bus/derived policy
products or claim whole preparation admission.
