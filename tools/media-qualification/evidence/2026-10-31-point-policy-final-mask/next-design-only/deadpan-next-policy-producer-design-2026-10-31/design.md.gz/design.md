# Next bounded producer: final raw Root suppression collector

Read-only design against the pinned current Scope sources. No implementation,
root edits, builds, native runs or Git operations. C is still parent-owned;
this note neither completes/publishes C nor awards a Gate.

## Recommendation

Close the ordinary **native final Root suppression collector** in
raw_policy::apply/read_queries_borrowed next. Keep the existing admitted
AudioSample policy carrier and its Root numerical semantics. This is smaller
than adding ProjectedRoot policy admission or changing the derived bus/owner-EQ
products, and it needs no Plan API, final-lease extraction or public type change.

The exact ordinary producer is raw_policy.rs::apply: fresh Vec pushes for
SilentHold and Suppressed events. stages.rs::read_queries_borrowed then allocates
again through merged_suppression and wraps the result Plain. The source Root/
Domain policy is already admitted on the Original path. Its final Vec lease is
merged into its inventory guard, but that does not obstruct a separately funded
destination copy while the complete source owner remains alive.

This is deliberately not a Root zero-copy handoff. Root output also includes
SilentHold ranges from the flattened product, and its union can differ from
the policy Vec. Moving only the Plan final Vec would omit those actual events.

## Actual producers considered

| Producer | Actual path and allocation | Reason to defer or select |
| --- | --- | --- |
| Raw Root final collector | raw_policy::apply pushes actual AudioSample event ranges; read_queries_borrowed merges into another Vec | Select: one production consumer, existing opaque output/account/builders, no Plan representation change |
| ProjectedRoot | read_projected_root_controlled calls AudioProjectedRoot::policy; it builds outside-meaningful ranges, invokes tape policy_after_preserve, rebases retained labels, merges Vec | Defer: needs admitted tape/run/override recursion and projected resume composition, not a simple Root factory call |
| Shared EQ bus | SharedMix::finish derives per-sample ranges from empty permissions and merges; Components::finish writes through Output.suppressed=&mut Vec, then merges | Defer: independent newly derived output, borrowed output API/multiple targets and Graph residency/caches need a separate closure |
| Owner equalizer | equalize_owner_tile uses stack admitted:[bool;1024], pushes one range for every false flag, merges; read_owner_equalized_controlled clips/extends/merges again | Defer: independent derived product plus public Clone/Vec surface and both tile/output allocations, with less central runtime reach |

No source mask's admission automatically admits the new bus/EQ policy allocation.
Owner EQ's actual tile is1024 samples, so no256-inline-mask shortcut is valid.

## Concrete smallest boundary

Production files: raw_policy.rs and the one tail in stages.rs. Reuse existing
point_suppression::RangeBuilder<AudioSample>, MaskContext and owned in-place
merge. Do not generalize Plan's GuardedBound or alter AdmittedAudioPolicyQuery.

Keep existing raw_policy::apply literally available for compatibility/tests.
Add an active adapter conceptually:

    apply_owned<C: MaskContext>(queries, start, samples, control, &mut C)
        -> Result<AppliedPending, StageAudioError>

AppliedPending contains the existing ordinary exhausted Vec plus a private
collector enum: legacy Vec or an optional actual RangeBuilder<AudioSample>.
The builder is real destination storage, not an abstract escrow: its pending
Storage owns the actual destination Vec and exact Vec+future-Box Charge. The
only receiving caller finalizes it into the existing native ReadBlock owner.

1. Count successful suppression emissions with an allocation-free scan of
   flattened SilentHold tags plus policy.suppressed.len(), checked addition.
   Debit native Scan before each inspected flattened tag. Do not evaluate
   envelopes, validate offsets or execute the visitor twice. Each successful
   visit emits exactly one SilentHold range per matching flattened span and
   one Suppressed range per explicit policy entry; duplicates are intentional.
2. Retain an empty pending collector until the first actual SilentHold or
   Suppressed event. At its old push position, begin_ranges<AudioSample> with
   that exact emission count, admitting its requested Vec+Box before allocating
   Vec. The complete borrowed flattened/processing/policy/fade owners remain
   alive. No emitted range means no account or payload allocation.
3. Run the existing raw_policy::visit once. Keep its exact operation order:
   per-span check/offset validation; SilentHold zeroing or retained envelope;
   exhaustion; whole explicit-policy validation; then explicit policy zeroing.
   At each old suppressed.push position, push the actual typed range into the
   funded builder with its existing Map/check. Do not infer ranges from PCM.
   Existing envelope/PCM numerical code and creative-fade semantics stay intact.
4. Return the actual pending builder while the caller applies creative fades
   and its existing control.check. At the current merged_suppression position,
   finish the builder's actual Box, then use existing owned in-place merge.
   This keeps the new Box allocation at the old final-mask construction boundary.
   On any error, pending Vec/charge or completed OwnedMask follows its existing
   physical disposal order. No unused Box allocation or source detachment occurs.
5. Return the resulting AudioSuppressionMask directly in ReadBlock. Its account
   survives request/query/controller destruction as in B/C. Original cache's
   existing Owned unaccounted_capacity0 branch then prevents payload double debit.

The successful emission count is also the legacy final destination's capacity:
merged_suppression uses Vec::with_capacity(raw_ranges.len()). Owned merge keeps
that funded capacity while compacting its length. Thus even duplicate SilentHold/
explicit-policy unions retain the same final capacity without a new output Vec.

Keep the legacy branch's exact apply Vec pushes and merged_suppression body;
do not replace their iterator/allocation behavior with borrowed clones. The
adapter can select it under a new test-only Root-mask override. Chaining older
legacy wrappers to this override protects old bodies; replaying the immediately
pre-unit C body must select only Root legacy, leaving C Point handoff active.

exhausted remains its existing separate ordinary Vec in this bounded unit.
Its storage, PCM/dependencies/envelope work, and whole preparation remain owed;
do not claim those allocations admitted because suppression now has an owner.
New fees belong to native Scan/Map/Vector/Storage/merge phases, not canonical
Plan policy weights. Existing query invalid flags remain literal.

## Caller inventory and retained lifetime

The only production raw_policy::apply call is stages.rs::read_queries_borrowed.
Its direct callers are:

- original_request.rs::read_prepared_original, used by the prepared Root and
  physical-Domain Original paths. It holds PreparedQueries (flattened,
  processing, admitted Audio policy, optional fades) until the complete numerical
  call returns, then explicitly drops the request.
- stages.rs::read_queries, which owns ordinary RootReadQueries and borrows them
  for the call. Its production consumers are beat_sounds::read_prepared_beat_sound
  Current, voice_occurrence::read_source_occurrence, and
  voice_occurrences::render_source_occurrences.
- retained_sound_input.rs::read_retained_sound_query_borrowed Occurrence branch,
  which retains its prepared query owner for the borrowed call.

The ordinary occurrence/beat query inputs remain ordinary setup products in
this unit. The new destination is genuinely admitted; that does not retroactively
admit their source metadata. Admitted Original sources retain all existing
charges through the destination's full overlap.

Existing public Root/Domain/occurrence outputs already carry opaque Audio masks,
so no public Vec->opaque migration or Clone removal is needed for this seam.
Root transfer, retained reads and Original cache publication already receive
that ReadBlock type. Test actual cache pins/lifetime with the new raw owner;
do not manufacture ReadBlock payloads to assert the resident formula.

## Why not change Root Plan finish now

audio_policy_query::finish constructs final Vec<Range<AudioSample>>, then
adopt_memory and inventory.zip merge its capacity lease into the complete
guard. Original request/Domain processing-policy wrappers expose borrowed
AudioPolicyQuery and retain that guard across the read. Extracting this Vec
would need a new dedicated carrier while preserving existing Root/Domain
inventory/Core identity/reuse APIs and immutable old bodies. It would still
not supply flattened SilentHold emissions. A real charged destination copy is
the smaller correct next step; no fake refund or unmerge is necessary.

ProjectedRoot is also not interchangeable with this carrier: its actual policy
source is AudioSignalTape, whose policy_inner performs run lookup, optional
policy_override recursion, per-run ordinary policy calls and Vec aggregation.
ProjectedRoot then adds out-of-meaningful-support silence and applies checked
i128 resume/reference offsets. Its tape labels are SignalSample even on its
RoundEven remapped grid; C's PointCeil factory is not that grid. The eventual
ProjectedRoot unit must admit those actual producers and emit AudioSample
directly, preserve endpoints=false after Preserve and keep resume geometry.
Wrapping its already-created Vec after return would close only a destination
copy, not its ordinary Plan policy construction.

## Proof needed after parent qualifies C

Freeze the immediate pre-unit complete bodies before production edits. Preserve
their legacy replay, and capture new actual work/residency independently.
Use genuine checked Root/Domain SilentHold, SelectedPlacement, retained-envelope
exhaustion and duplicate SilentHold+policy cases; compare every output f32 bit,
range, exhausted interval and capacity. Include malformed/unsupported envelope
and policy-range errors to preserve non-resource validation ordering.

Assert real counted emission capacity, no hidden intermediate Vec, full source
metadata plus native destination overlap, each accepted construction/merge work
prefix, no account on an actually empty collector, and real request/controller
drop with external output held. Use exact warmed cap/one-below and actual Original
cache publish/hit/pin/evict behavior. Do not use first-success probing through
mutating cache warmup as a minimum-cap proof.

This design leaves existing raw PCM/envelope loops unchanged and makes no claim
that every such numeric operation is newly billed. A count/tag prepass adds
explicit bounded native work but no new non-resource validation. Resource-error
prefixes must be recorded honestly; canonical weights/caps cannot be raised.
