from pathlib import Path
import hashlib,json
s=Path(__file__).parent
result={}
rel='crates/deadpan-audio/src/bound_reads/native_mask_after.rs'
for variant,root in [('main',Path('/Users/michael/Code/deadpan')),('scoped',Path('/tmp/deadpan-query-groundwork-2026-10-26/scoped'))]:
 old=json.loads((s/f'policy-all-targets-{variant}.json').read_text())['source_after']
 new=json.loads((s/f'policy-final-library-build-{variant}.json').read_text())['source_after']
 assert set(old)==set(new)
 changed=[p for p in old if old[p]!=new[p]]
 assert changed==[str(root/rel)],changed
 current=(root/rel).read_bytes()
 before=current.replace(b'independent projected-provider and derived policies remain ordinary',b'independent Root/derived policies remain ordinary')
 assert before!=current and {'bytes':len(before),'sha256':hashlib.sha256(before).hexdigest()}==old[str(root/rel)]
 old_pins=json.loads((s/f'policy-all-targets-{variant}-pins.json').read_text())
 retained=[{'target':r['name'],'sha256':r['sha256']}for r in old_pins if r['name']!='deadpan_audio']
 assert len(retained)==20
 result[variant]={'sole_source_change':rel,'exact_scope_label_replacement':True,'test_only_ancestor':'crates/deadpan-audio/src/stages.rs #[cfg(all(test, any(target_os = macos, target_os = linux)))] bound_reads','unchanged_integration_binaries':retained,'final_library_pins':json.loads((s/f'policy-final-library-build-{variant}-pins.json').read_text())}
(s/'final-qualification-join.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:{'sole_source_change':v['sole_source_change'],'retained_integration_binaries':len(v['unchanged_integration_binaries'])}for k,v in result.items()}))
