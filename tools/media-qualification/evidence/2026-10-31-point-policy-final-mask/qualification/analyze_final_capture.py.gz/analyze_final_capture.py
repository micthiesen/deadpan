from pathlib import Path
from collections import Counter
import json,hashlib
s=Path(__file__).parent
old=json.loads((s/'policy-final-before-interval-scoped-canonical.json').read_text())
new=json.loads((s/'policy-final-active-scoped-canonical.json').read_text())
counts=Counter();changes=[];rows=[]
for i,(before,after)in enumerate(zip(old['native_requests']['cases'],new['native_requests']['cases'])):
 assert len(before['operations'])==len(after['operations'])
 for j,(a,b)in enumerate(zip(before['operations'],after['operations'])):
  assert {k:v for k,v in a.items()if k!='paired'}=={k:v for k,v in b.items()if k!='paired'}
  a=a['paired']['new']['read']['output'];b=b['paired']['new']['read']['output']
  counts['native_requests']+=1
  if a==b:counts['exact_'+a['status']]+=1
  else:
   kind=a['status']+'_to_'+b['status'];counts[kind]+=1
   changes.append({'case':i,'operation':j,'kind':kind,'before':a if a['status']!='Ok' else {'status':'Ok'},'after':b if b['status']!='Ok' else {'status':'Ok'}})
def visit(v,path=''):
 if isinstance(v,dict):
  if v.get('schema')=='native-mask-query-intervals-v1':
   assert v['active_intervals']==v['dropped_intervals']==0 and not v['misnested'] and not v['overflow'],path
   counts['interval_snapshots']+=1
   for r in v['rows']:
    counts['interval_rows']+=1
    assert r['attributable'] and not r['foreign_work_overlap'],(path,r)
    for prefix in ['native','host']:
     a=r[prefix+'_before'];b=r[prefix+'_after']
     assert a['reset_epoch']is not None and a['reset_epoch']==b['reset_epoch']and not a['overflow']and not b['overflow']
    claim=r['claim']
    if claim is None:counts['partial_intervals']+=1;rows.append({'path':path,'partial':r});continue
    counts['completed_intervals']+=1
    assert claim['total']==claim['canonical']+claim['additional']
    for lane in range(2):
     phase=[b-a for a,b in zip(r['native_before']['lanes'][lane],r['native_after']['lanes'][lane])]
     host=r['host_after']['units'][lane]-r['host_before']['units'][lane]
     observed=r['work_after'][lane]-r['work_before'][lane]
     assert min(phase)>=0 and host>=0 and observed>=0
     expected=(claim['expected_debit']if lane==r['selected_lane']else 0)+sum(phase)+host
     assert observed==expected,(path,lane,r)
  else:
   for k,a in v.items():visit(a,path+'/'+k)
 elif isinstance(v,list):
  for i,a in enumerate(v):visit(a,path+'/'+str(i))
visit(new)
assert counts['native_requests']==744
for mode,sha in [('before-off','af7a292718365c34fa03692e2cbe58a2cfb3c6d444b5ae29d52647e1fdbbff14'),('before-interval','f64d3a00a10967cc3822083d21705bd454f2d33ff2198da30e25671092ab5a53')]:
 for variant in ['main','scoped']:
  assert hashlib.sha256((s/f'policy-final-{mode}-{variant}-canonical.json').read_bytes()).hexdigest()==sha
a=(s/'policy-final-active-main-canonical.json').read_bytes();b=(s/'policy-final-active-scoped-canonical.json').read_bytes();assert a==b
proof={'active_bytes':len(b),'active_sha256':hashlib.sha256(b).hexdigest(),'cross_root_exact':True,'both_historical_bodies_exact_in_both_variants':True,'counts':counts,'output_changes':changes,'partial_intervals':rows,'limits':'Compare complete output including capacities and errors; no normalization. Inclusive interval rows reconcile individually, never summed. Native whole invocation work is separate from these constructor boundaries. No C policy query fee is inferred from residuals.'}
(s/'final-capture-analysis.json').write_text(json.dumps(proof,indent=2)+'\n')
print(json.dumps({k:v for k,v in proof.items()if k not in ['output_changes','partial_intervals','limits']}))
