from pathlib import Path
s=Path(__file__).parent
text=(s/'qualification-draft.md').read_text()
old='''Validation: PENDING final matrix, doctests, hygiene, repeated final captures.
Already passed: Plan289/276 and Audio526/520 library tests, required Main strict
check with --no-test and isolated all-target Plan/Audio Clippy with warnings
denied.'''
new='''All 21 Audio targets pass per variant: 1107 Main and 1101 isolated tests,
21 ignored manual captures, with Main's seven unfinished Split tests filtered.
Plan libraries pass 289/276 with 28 manual captures ignored; final Audio
libraries pass 526/520 with 21 ignored. Required Main strict check with
--no-test, isolated all-target Plan/Audio Clippy with warnings denied,
formatting and both hygiene checks pass. Rustdoc verification passes with no
executable examples. After the last test-only capture-label correction, both
libraries were rerun; all 20 integration binaries retain their exact earlier
passes, joined to final sources by the single excluded test-module change.'''
assert old in text;text=text.replace(old,new)
text=text.replace('Current 744+10+4 captures agree across builds.','Three final 744+10+4 captures per build agree byte-for-byte: 35440148 canonical\nbytes, SHA-256 afa6038a02c959c7192c09c08a89266c7d52151a5e59a4f69828fbdf67e7414e.')
text=text.replace('derived bus/equalizer masks, PCM/','derived bus/equalizer masks, exhausted vectors, PCM/')
for old,new in [('All31','All 31'),('new31st','new 31st'),('All744','All 744'),('including264','including 264'),('and480','and 480'),('The477','The 477'),("Main's2900","Main's 2900"),("copy's2572","copy's 2572")]:
 text=text.replace(old,new)
(s/'qualification-draft.md').write_text(text)
for root in [Path('/Users/michael/Code/deadpan'),Path('/tmp/deadpan-query-groundwork-2026-10-26/scoped')]:
 p=root/'docs/qualification/point-policy-final-mask-custody-2026-10-31.md'
 assert not p.exists();p.write_text(text)
