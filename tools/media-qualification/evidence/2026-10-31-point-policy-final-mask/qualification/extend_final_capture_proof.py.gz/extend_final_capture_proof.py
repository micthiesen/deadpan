from pathlib import Path
import hashlib,json
s=Path(__file__).parent
p=s/'final-capture-analysis.json';proof=json.loads(p.read_text())
old=json.loads((s/'policy-final-before-interval-scoped-canonical.json').read_text())['internal_and_transfer_paths']
new=json.loads((s/'policy-final-active-scoped-canonical.json').read_text())['internal_and_transfer_paths']
proof['internal_and_transfer_outputs_exact']=[]
for group,left,right in [('internal',old['cases'],new['cases']),('transfer',old['public_transfers']['cases'],new['public_transfers']['cases'])]:
 for x,y in zip(left,right):
  assert x['name']==y['name']
  fields=[k for k in x if k.startswith('result_')or k.startswith('account_after_')]
  for field in fields:assert x[field]==y[field],(x['name'],field)
  proof['internal_and_transfer_outputs_exact'].append({'group':group,'name':x['name'],'exact_complete_output_and_held_account_fields':fields})
proof['repeated_captures']=[]
for variant in ['main','scoped']:
 for suffix in ['','-2','-3']:
  label=f'policy-final-active-{variant}{suffix}'
  result=json.loads((s/(label+'-proof.json')).read_text())
  data=(s/(label+'-canonical.json')).read_bytes()
  assert result['bytes']==len(data)==35440148
  assert result['sha256']==hashlib.sha256(data).hexdigest()=='afa6038a02c959c7192c09c08a89266c7d52151a5e59a4f69828fbdf67e7414e'
  run=json.loads((s/(label+'.json')).read_text())
  assert run['exit_code']==0 and run['sources_unchanged'] and run['binaries_unchanged']
  proof['repeated_captures'].append({'label':label,**result})
p.write_text(json.dumps(proof,indent=2)+'\n')
print(json.dumps({'independent_complete_native_outputs':744,'complete_internal_transfer_outputs':len(proof['internal_and_transfer_outputs_exact']),'repeated_final_captures':len(proof['repeated_captures'])}))
