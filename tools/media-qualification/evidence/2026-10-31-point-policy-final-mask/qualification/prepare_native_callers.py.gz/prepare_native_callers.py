from pathlib import Path
import json,difflib
p=Path(__file__).parent
roots=[Path('/Users/michael/Code/deadpan'),Path('/tmp/deadpan-query-groundwork-2026-10-26/scoped')]
new={
'crates/deadpan-audio/src/point_policy_request.rs':'''//! Exact ordinary Point policy lane for immutable pre-handoff regressions.
thread_local! {
    static LEGACY: std::cell::Cell<bool> = const { std::cell::Cell::new(false) };
}
pub(super) fn legacy() -> bool {
    LEGACY.with(std::cell::Cell::get)
}
pub(super) fn with_legacy_policy<T>(action: impl FnOnce() -> T) -> T {
    struct Restore(bool);
    impl Drop for Restore {
        fn drop(&mut self) {
            LEGACY.with(|legacy| legacy.set(self.0));
        }
    }
    let _restore = Restore(LEGACY.with(|legacy| legacy.replace(true)));
    action()
}
''',
'crates/deadpan-audio/src/signal_policy_input.rs':'''//! A borrowed policy view keeps the exact final Point lease alive through PCM use.
use super::*;
use deadpan_plan::{AdmittedSignalPolicyQuery, SignalPolicyView};

pub(super) fn legacy() -> bool {
    #[cfg(test)]
    return super::point_policy_request::legacy();
    #[cfg(not(test))]
    false
}

pub(super) enum SignalPolicyInput<'work> {
    Ordinary(AudioPolicyQuery<SignalSample>),
    Admitted(AdmittedSignalPolicyQuery<
        sound_context_admission::Issuer<'work>,
        sound_context_admission::Lease<'work>,
    >),
}
impl From<AudioPolicyQuery<SignalSample>> for SignalPolicyInput<'_> {
    fn from(query: AudioPolicyQuery<SignalSample>) -> Self {
        Self::Ordinary(query)
    }
}
impl<'work> SignalPolicyInput<'work> {
    pub(super) fn view(&self) -> SignalPolicyView<'_> {
        match self {
            Self::Ordinary(query) => SignalPolicyView {
                suppressed: &query.suppressed,
                contents: &query.contents,
                lookup: query.lookup,
                work: query.work,
            },
            Self::Admitted(query) => query.view(),
        }
    }
    pub(super) fn was_forwarded(&self) -> bool {
        match self {
            Self::Ordinary(_) => false,
            Self::Admitted(query) => query.was_forwarded(),
        }
    }
    pub(super) fn into_suppression(
        self,
        renderer: &mut StageAudio,
        control: WorkControl<'work>,
    ) -> Result<SignalSuppressionMask, StageAudioError> {
        match self {
            Self::Ordinary(query) => Ok(SignalSuppressionMask::plain(
                super::merged_suppression(query.suppressed),
            )),
            Self::Admitted(query) => {
                let mut admission = sound_context_admission::Admission::new(renderer, control);
                query.into_suppression(&mut admission)
            }
        }
    }
}
'''}
for root in roots:
 for rel,data in new.items():
  target=root/rel
  if target.exists():assert target.read_text()==data
  else:target.write_text(data)
files={}
def edit(rel,old,new):
 text=files.get(rel,(roots[0]/rel).read_text())
 assert text.count(old)==1,(rel,old)
 files[rel]=text.replace(old,new,1)
rel='crates/deadpan-audio/src/stages.rs'
edit(rel,'use signal_input::SignalInput;','use signal_input::SignalInput;\n\n#[path = "signal_policy_input.rs"]\nmod signal_policy_input;\nuse signal_policy_input::SignalPolicyInput;\n\n#[cfg(test)]\n#[path = "point_policy_request.rs"]\nmod point_policy_request;')
edit(rel,'''        let policy = domain
            .signal_ref()
            .policy(samples, control.query_limits()?)?;
        control.spend_plan_work(policy.work)?;
        self.preflight_signal_queries(query.query(), &policy, control, depth)?;
        let mut block =
            self.read_signal_queries(query.query(), policy, provider, control, depth)?;
        if !point_suppression::internal_legacy() {''','''        let ordinary_policy = signal_policy_input::legacy();
        let policy = if ordinary_policy {
            SignalPolicyInput::Ordinary(domain.signal_ref().policy(samples, control.query_limits()?)?)
        } else {
            let limits = control.query_limits()?;
            let mut admission = sound_context_admission::Admission::new(self, control);
            SignalPolicyInput::Admitted(domain.policy_admitted(samples, limits, &mut admission)?)
        };
        if !policy.was_forwarded() {
            control.spend_plan_work(policy.view().work)?;
        }
        self.preflight_signal_queries(query.query(), policy.view(), control, depth)?;
        let mut block =
            self.read_signal_queries(query.query(), policy, provider, control, depth)?;
        if ordinary_policy && !point_suppression::internal_legacy() {''')
edit(rel,'''        self.preflight_signal_queries(&query, &policy, control, depth)?;
        self.read_signal_queries(&query, policy, provider, control, depth)''','''        let policy = SignalPolicyInput::Ordinary(policy);
        self.preflight_signal_queries(&query, policy.view(), control, depth)?;
        self.read_signal_queries(&query, policy, provider, control, depth)''')
edit(rel,'        policy: &AudioPolicyQuery<SignalSample>,','        policy: deadpan_plan::SignalPolicyView<\'_>,')
edit(rel,'point_content_query_trace::Consumer::Preflight);\n        for content in &policy.contents {','point_content_query_trace::Consumer::Preflight);\n        for content in policy.contents {')
edit(rel,'    fn read_signal_queries(\n','    fn read_signal_queries<\'work>(\n')
edit(rel,'''        policy: AudioPolicyQuery<SignalSample>,
        provider: &mut impl AudioSourceProvider,
        control: WorkControl<'_>,''','''        policy: SignalPolicyInput<'work>,
        provider: &mut impl AudioSourceProvider,
        control: WorkControl<'work>,''')
edit(rel,'''        apply_suppression(start, &mut samples, &policy.suppressed, |sample| sample.0)?;
        let suppressed = SignalSuppressionMask::plain(merged_suppression(policy.suppressed));''','''        apply_suppression(start, &mut samples, policy.view().suppressed, |sample| sample.0)?;
        let suppressed = policy.into_suppression(self, control)?;''')
rel='crates/deadpan-audio/src/signal_mix.rs'
edit(rel,'self.read_signal_queries(&voice.signal, voice.policy, provider, control, depth)?;','self.read_signal_queries(&voice.signal, voice.policy.into(), provider, control, depth)?;')
rel='crates/deadpan-audio/src/internal_mask_request.rs'
edit(rel,'    action()\n','    super::point_policy_request::with_legacy_policy(action)\n')
for rel,newtext in files.items():
 old=(roots[0]/rel).read_text()
 diff=''.join(list(difflib.unified_diff(old.splitlines(True),newtext.splitlines(True),n=3))[2:])
 (p/('callers-'+Path(rel).name+'.patch')).write_text('*** Begin Patch\n*** Update File: ROOT/'+rel+'\n'+diff+'*** End Patch\n')
for name in ['owned-code-paths.json','source-files.json','scoped-source-files.json']:
 f=p/name
 f.write_text(json.dumps(sorted(set(json.loads(f.read_text()))|set(new)),indent=2)+'\n')
