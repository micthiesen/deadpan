from pathlib import Path
import json,hashlib,difflib
s=Path(__file__).parent;t=Path('/tmp/deadpan-native-query-interval-qualification-2026-10-31')
roots=[Path('/Users/michael/Code/deadpan'),Path('/tmp/deadpan-query-groundwork-2026-10-26/scoped')]
fixture='crates/deadpan-audio/tests/fixtures/point-policy-final-mask-baseline-v1/snapshot.json'
data=(t/'interval-off-scoped-canonical.json').read_bytes()
assert data==(t/'interval-off-main-canonical.json').read_bytes()
sha=hashlib.sha256(data).hexdigest();assert sha=='af7a292718365c34fa03692e2cbe58a2cfb3c6d444b5ae29d52647e1fdbbff14'
for root in roots:
 p=root/fixture;assert not p.exists();p.parent.mkdir(parents=True);p.write_bytes(data)
proof={'source_checkpoint':'eedbc58272bdd009a65239b7104ddb786a2554fc','actual_capture_checkpoint':'ab211a2f132379a246157c3596d95fc42121541c','source_capture':'/tmp/deadpan-native-query-interval-qualification-2026-10-31/interval-off-scoped-canonical.json','independent_source_proof':json.loads((t/'interval-off-scoped-proof.json').read_text()),'matching_main_proof':json.loads((t/'interval-off-main-proof.json').read_text()),'new_oracle':fixture,'bytes':len(data),'sha256':sha,'scope':'Exact historical active internal-mask body captured before C; byte copy only, no C code ran to generate expected data'}
(s/'before-freeze-proof.json').write_text(json.dumps(proof,indent=2)+'\n')
rel='crates/deadpan-audio/src/bound_reads/native_mask_after.rs';old=(roots[0]/rel).read_text();text=old
def edit(old,new):
 global text
 assert text.count(old)==1,old
 text=text.replace(old,new,1)
edit('    capture_after("DEADPAN_INTERNAL_MASK_AFTER", false);','    crate::stages::point_policy_request::with_legacy_policy(|| {\n        capture_after("DEADPAN_INTERNAL_MASK_AFTER", false, false);\n    });')
edit('    capture_after("DEADPAN_QUERY_INTERVAL_AFTER", true);','    crate::stages::point_policy_request::with_legacy_policy(|| {\n        capture_after("DEADPAN_QUERY_INTERVAL_AFTER", true, false);\n    });')
edit('fn capture_after(prefix: &str, intervals: bool) {','''#[test]
#[ignore = "manual active Point policy handoff capture; pinned sources and fresh /tmp"]
fn capture_active_point_policy_after_v1() {
    capture_after("DEADPAN_POINT_POLICY_AFTER", true, true);
}

fn capture_after(prefix: &str, intervals: bool, policy: bool) {''')
edit('        if intervals {\n            "ab211a2f132379a246157c3596d95fc42121541c"','        if policy {\n            "eedbc58272bdd009a65239b7104ddb786a2554fc"\n        } else if intervals {\n            "ab211a2f132379a246157c3596d95fc42121541c"')
start=text.index('    let _capture = Capture::new();')
end=text.index('    let file = OpenOptions::new()',start)
body=text[start:end]
text=text[:start]+'    let value = observed_body(&variant, &source, intervals, policy);\n'+text[end:]
body=body.replace('    });\n    if intervals {','    });\n    if intervals {',1)
# The completed body remains literal in both historical modes.
body+='''    if policy {
        value["schema"] = json!("active-point-policy-after-v1");
        value["policy_checkpoint"] = json!("eedbc58272bdd009a65239b7104ddb786a2554fc");
        value["immediate_before"] = json!({
            "path":"tests/fixtures/point-policy-final-mask-baseline-v1/snapshot.json",
            "sha256":"af7a292718365c34fa03692e2cbe58a2cfb3c6d444b5ae29d52647e1fdbbff14",
        });
        value["native_requests"]["scope"] = json!(
            "744 actual current requests. Point Signal policy is admitted and transfers its exact final Vec lease; independent native phase receipts remain whole invocation and raw/Point content intervals remain separately observed."
        );
        value["scope"] = json!(
            "Current Point SignalSample PointCeil policy metadata and exact final Vec lease handoff. Root/derived bus/equalizer products and whole preparation remain outside this claim. Historical authorities remain literal; the immediate complete before body is separately named."
        );
        for row in value["internal_and_transfer_paths"]["cases"].as_array_mut().unwrap() {
            row["scope"]["internal_masks"] = json!(
                "actual native destinations and admitted Point Signal policy; independent Root/derived policies remain ordinary"
            );
        }
    }
    value
'''
text+='\nfn observed_body(variant: &str, source: &str, intervals: bool, policy: bool) -> Value {\n'+body+'}\n'
text+='''\n#[test]
fn active_internal_masks_before_point_policy_match_frozen_v1() {
    let bytes = include_bytes!("../../tests/fixtures/point-policy-final-mask-baseline-v1/snapshot.json");
    assert_eq!(
        hex(Sha256::digest(bytes)),
        "af7a292718365c34fa03692e2cbe58a2cfb3c6d444b5ae29d52647e1fdbbff14",
    );
    let expected: Value = serde_json::from_slice(bytes).unwrap();
    let mut actual = crate::stages::point_policy_request::with_legacy_policy(|| {
        observed_body("scoped-published", &"0".repeat(64), false, false)
    });
    for field in ["variant", "source_sha256"] {
        actual.as_object_mut().unwrap().remove(field);
        actual["native_requests"].as_object_mut().unwrap().remove(field);
    }
    assert_eq!(actual, expected);
}
'''
diff=''.join(list(difflib.unified_diff(old.splitlines(True),text.splitlines(True),n=3))[2:])
(s/'capture-apply.patch').write_text('*** Begin Patch\n*** Update File: ROOT/'+rel+'\n'+diff+'*** End Patch\n')
for name in ['owned-code-paths.json','source-files.json','scoped-source-files.json']:
 p=s/name;p.write_text(json.dumps(sorted(set(json.loads(p.read_text()))|{fixture}),indent=2)+'\n')
pins=json.loads((s/'immutable-oracle-pins.json').read_text());pins.append({'path':fixture,'sha256':sha,'bytes':len(data)})
(s/'immutable-oracle-pins.json').write_text(json.dumps(pins,indent=2)+'\n')
for name in ['run_qualified.py','run_scoped_qualified.py','run_plan_qualified.py','run_scoped_plan_qualified.py']:
 p=s/name;t=p.read_text();anchor="        'DEADPAN_QUERY_INTERVAL_AFTER_OUTPUT', 'DEADPAN_QUERY_INTERVAL_AFTER_VARIANT',"
 assert t.count(anchor)==1
 p.write_text(t.replace(anchor,"        'DEADPAN_POINT_POLICY_AFTER_OUTPUT', 'DEADPAN_POINT_POLICY_AFTER_VARIANT',\n        'DEADPAN_POINT_POLICY_AFTER_SOURCE_SHA256', 'DEADPAN_POINT_POLICY_AFTER_PUBLISHED_CHECKPOINT',\n"+anchor))
