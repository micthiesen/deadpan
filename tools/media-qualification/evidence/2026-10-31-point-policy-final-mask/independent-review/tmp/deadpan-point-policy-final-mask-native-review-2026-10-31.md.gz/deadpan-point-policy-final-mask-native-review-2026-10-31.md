# Native C final Point mask handoff static review

Reviewed 2026-10-31. No root edits, build, native run, fixture work or Git
operation performed. Exact current Main/Scope and candidate pins are in
/tmp/deadpan-point-policy-final-mask-native-review-2026-10-31/pins.json.
All thirteen inspected current target/dependency files match between roots.
The two candidate backend files differ from current Scope only in formatting
and import order; both versions are pinned.

## Findings

No remaining material static blocker found in native allocation/charge custody
or the current real caller's borrow ordering, under the accepted closed-caller
and trusted-backend contracts.

One integration error was found and reported promptly: sound_events.rs passed
AudioPolicyQuery directly to read_signal_queries after the latter changed to
SignalPolicyInput. Parent confirmed both first Audio builds failed E0308 and
fixed the call to policy.into() in both roots, preserving failed receipts.
The final reviewed snapshot includes that fix. signal_mix.rs already converts
voice.policy; read_signal wraps its ordinary result explicitly. Exact search
found no remaining unwrapped ordinary caller. I did not run those builds.

## Allocation and account continuity

point_suppression/policy_handoff.rs derives vector frames from the actual typed
Layout::array<Range<SignalSample>>(capacity), and derives Box frames from actual
Layout::new<Storage<SignalSample>>. It reserves only Storage frames through the
existing controller account. The exact final source Vec and complete policy
inventory remain in Plan's ledger during this reservation and actual Box
allocation. The lazy account shell is admitted by the existing helper, with
its own actual fee and residency. This introduces no second Vec allocation.

The prepared destination is already wrapped in existing OwnedMask, containing
Some(Box<Storage>) with an empty capacity0 Vec and Box-only Charge. Thus unused
tokens use B's explicit physical Box-free, Vec-free, then Charge release order.
A bare Box default Drop would be wrong here; the candidate avoids that.

Storage+vector frames and account live+vector overflow are checked before
publication. The account check occurs before the final exclusive preflight,
but remains valid: this mutable controller is the sole publisher, subsequent
work/Box construction does not publish another payload, and other threads only
subtract live charges. Final credit uses atomic fetch_add, never a stale live
total store. The precomputed total_frames becomes the existing Charge.frames.
No new Arc is allocated or duplicated for the transferred vector itself.

PreparedPolicyMask::publish resolves owner.storage and the closed account
handle before atomic credit. After that it only performs prechecked credit,
assigns the charge total, moves the exact Vec over the old empty Vec, and moves
the owner into Value::Owned. There is no fallible call, iterator, map, collect,
sort, capacity change, trace callback or assertion after native credit starts.
The old empty Vec has no allocation or lease to release during assignment.

Capacity0 validates no source lease and allocates no account/Storage, accepting
no new native fee. Positive capacity is handled independently of length, so a
positive-capacity/length0 Vec would still retain its full real charge.

## Source validation and no-fail mutation window

sound_context_admission/policy_mask_handoff.rs first validates actual issuer,
source lease presence, exact vector frames and actual ReadWork identity. After
all destination admission/allocation it checks cancellation, descriptor capacity
and destination vector frames again, then preflight_source_lease revalidates
issuer, exact same lease address, frames and ledger.

Its final try_borrow_mut both proves exclusive ledger access and computes the
checked remaining sound_context_frames. That RefMut ends before the token is
returned. The token retains the prepared native owner and the actual ledger
reference plus remaining scalar; it retains no source borrow or RefCell guard.

Plan's current consuming method retains its exact final-mask Memory and complete
guarded inventory through preparation. Its successful prepare->commit gap has
only destructuring/scalar field moves and Option::as_mut. No owner drops,
callback, issuer inspection, arithmetic or check can invalidate the final
exclusive preflight there.

commit_signal_mask resolves Some(source_lease) and acquires the exclusive ledger
RefMut BEFORE destination.publish starts mutation. publish resolves its own
checked internal accesses before its first account mutation. The subsequent
window credits native custody, moves the Vec, assigns remaining ledger frames,
disarms the exact source lease, and returns the native mask. No possible normal
input failure is introduced after account mutation. The held ledger RefMut is
released on return before Plan drops inventory leases.

The stable ledger+account total is unchanged by moving vector frames. Its
temporary conservative duplicate debit occurs only inside the no-callback
window; no admission or allocation sees it. Source final lease.frames becomes0
and its later Drop does not touch ReadWork. Inventory is destroyed and releases
its independent leases only after native publication. Final output contains
the existing owned account handle, not a request ledger reference.

## Real caller and compatibility

read_point_domain_controlled keeps both content and admitted policy owners live
through preflight/media/PCM work. Its Admission construction borrow ends at
each narrow scope; it retains no Ref/RefMut of ReadWork. read_signal_queries
borrows policy.view during apply_suppression, then consumes that same owner
through SignalPolicyInput::into_suppression. The policy inventory is not cloned,
detached or replaced before use. The return type is the existing lifetime-free
SignalSuppressionMask. Existing final control.check remains after the handoff;
a late cancellation can dispose the newly owned result normally.

The only admitted SignalPolicyInput constructor found is the closed Point
factory. Other signal/mix/direct-sound paths stay Ordinary. Ordinary preserves
the literal merged_suppression(query.suppressed) Vec body. Only that ordinary
Point path then performs B's previous into_admitted copy, and only when B
internal legacy is disabled. Admitted skips that copy and retains the exact
Plan final allocation. Forwarded policy total is not spent again.

point_policy_request is an independent C-only ordinary-policy override, so it
can preserve B owners during B31 replay. internal_mask_request's older legacy
wrapper now also selects ordinary policy for pre-B lanes. This structure is
correct; it does not itself prove complete B31/T/older-body equality. The parent
must wrap each qualified pre-C body at the C-only boundary where appropriate,
then run full exact regressions with existing invalid flags and fields intact.
Do not substitute B-disabling internal legacy when replaying B31.

## Accepted limit and verification still owed

A consuming query is not promised to recover gracefully while an external
shared Ref of its ledger is live. If prepare refuses that conflict, automatic
query cleanup would itself require RefMut in Lease::drop. The accepted test
uses the borrowed helper while retaining the actual source owner, releases
the external Ref, then drops source. The actual closed Admission caller must
exclude ledger borrows across construction/consumption. Current inspected
callers meet that static condition; no shared Lease Drop/API rewrite is proposed.

The existing helper test manually initializes frames and constructs Lease; it
is bookkeeping evidence only. It does not establish actual native allocation
ownership or reserve/cap behavior. Parent/author's actual reserve-based tests
remain required for exact pointer/len/cap, dedicated final lease, full inventory
liveness through actual consumers, shell/Box/source peak overlap, unused token
drop order, real warmed exact cap/one-below failure, output after ReadWork and
controller disposal, positive-capacity/length0 and empty cases, and each accepted
work/refusal prefix. Concurrent independent owner drops need real account tests.

The backend's non-unwinding/no-callback conditions and sole-publisher model are
trusted internal contracts, not type-enforced guarantees for arbitrary custom
Admission implementations. No unsafe code is present in the reviewed backend.
This review provides static evidence only and makes no compilation, test-pass,
full legacy equality or complete preparation-admission claim.
