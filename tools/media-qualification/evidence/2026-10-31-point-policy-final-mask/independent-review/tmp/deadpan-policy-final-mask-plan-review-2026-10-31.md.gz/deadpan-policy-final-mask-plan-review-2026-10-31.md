# Plan C final Point-mask proposal review

Static review only, 2026-10-31. Reviewed the Plan candidate and its design/review contract. No source edits, builds, native runs, or Git operations.

## Findings

No material Plan-side blocker found in the pinned candidate.

The candidate keeps the final Point mask lease structurally separate: `finish_signal` creates a fresh `Memory`, reserves only `Layout::array<Range<SignalSample>>(count)`, constructs the exact-capacity final Vec, and moves both directly into private `FinalSignalMask` (`audio_point_policy_query.rs:305-339`). It does not call `adopt_memory`, `merge_checked`, or `GuardedBound::zip` on this memory. Inventory content and its own Memory remain a separate `GuardedBound` (`:75-78, 340-347`). The carrier declares final mask before inventory (`:81-89`), and final mask declares Vec before Memory (`:71-78`), preserving values-before-charge drop order.

`into_suppression` rejects unmetered/nonforwarded handoffs and issuer/capacity-lease mismatch before backend preparation (`:117-135`). It retains inventory and source mask through prepare, then only destructures/moves them before the adjacent commit call; post-commit drops occur afterward (`:136-149`). This is consistent with the stated no-fail publication boundary. As the contract/review correctly acknowledge, the cross-crate backend trait is open and cannot mechanically enforce non-unwinding or exact-custody behavior for arbitrary implementations (`:32-68`); that remains a trusted infrastructure contract and must be met by the private Audio implementation.

New finalizer loops have metered `budget.additional(1)` before each iteration/comparison/swap/push traversal (`:224-272, 275-325`). Final capacity is charged before allocation, and the provenance equation checks `maximum_work - remaining == canonical + additional` (`:326-334`). Inventory mapping afterward uses existing `GuardedBound::map`, which preserves its independent guard and checks issuer/memory before and after.

The metered entry is the actual `AudioPointDomain::signal_ref()`, `PointCeil`, endpoints enabled path (`:187-220`). The ordinary compatibility branch delegates to that same signal's ordinary policy and marks the carrier unforwarded (`:153-184`); it cannot pass the owned handoff gate. Existing Root admitted implementation is unchanged in the candidate diff: `audio_policy_query.rs` adds only the Point submodule/export; `plan.rs` and `lib.rs` add exports.

No-callback/unwind guarantees are documentation and trust obligations, not type-enforced guarantees. The candidate has no Audio backend implementation or focused tests in this scratch patch, so backend exclusive-borrow preflight, token totals, actual custody transfer/drop order, and runtime parity remain unverified here. Those are correctly left as implementation obligations in the design contract and prior handoff review.

## Source pins (SHA-256)

Candidate:

- `new/crates/deadpan-plan/src/audio_point_policy_query.rs`: `91c8fc2af245dc1337324212366d53eb3ce8c0a8cc5de3d347fc0f3c1bb06ef3`
- `new/crates/deadpan-plan/src/audio_policy_query.rs`: `ae9363b8043665a45336c2e577b60d1d963c92a2ef2cd297f6adced3109a5d06`
- `new/crates/deadpan-plan/src/plan.rs`: `d5ad8977bd90dd9f05dd06715eb597d3a2b88b12662f0697af6339d36fea0b23`
- `new/crates/deadpan-plan/src/lib.rs`: `38b15a7c06b8633ca89491288550f4fbdf8310d8bd610d2498b395452c3f75ab`
- Design contract: `8a3a7feb947e693aaf60cb6af30df266afd423629806ec23cf98872474950342`
- Prior design review: `1d47bb959061bf9ad9a1200507feffefc1c044e013606e6981ee94332a23a530`

Reviewed helper/source context:

- `crates/deadpan-plan/src/audio_policy.rs`: `8195ffc909c9ddfed0ea04132244750d10e9b9668461a7e7493b59f666f56e80`
- `crates/deadpan-plan/src/audio_owner_query_admission.rs`: `9f52395699a7cdd95b0c1329d0d7ee1b12459b2b2fd0c27a4fc53f952910c150`
- `crates/deadpan-plan/src/audio_bound_query.rs`: `acc588fa302333bdec892b03fb58963d338b25870665c6cf5b9ef9af7e5b0ef2`

## Scope

This review covers the Plan-side candidate only. It does not verify compilation, Plan tests, Audio's implementation of `AudioSignalPolicyMaskHandoff`, or the end-to-end native handoff.
