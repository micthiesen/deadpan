# Review: Point policy mask custody test candidate

## Findings

- **Portability issue in the primitive lease fixture:** source() reserves bytes for the requested capacity, then creates Vec::with_capacity(capacity) and requires ranges.capacity() == capacity (current policy_mask_handoff_tests.rs:29-41, 36-37). Rust guarantees at least the requested capacity, not exact equality. If an allocator returns more, the lease understates the actual Vec allocation and this fixture fails before exercising the intended lease checks. Build the Vec first, then reserve using its actual capacity and only then populate it; retain the intended exact-lease assertions. Candidate custody tests also assert exact allocator capacity in the production exact-capacity case (policy_mask_custody_tests.rs:115-119), but there it is checking the factory's explicit exact-capacity contract rather than allocator behavior.

No other actionable issue found in the requested scope.

## Review notes

The custody candidate distinguishes the real factory path from the observation backend. The direct success, empty, failure, and foreign-ledger tests use the real AudioPointDomain::policy_admitted factory and real Admission; the wrapper is explicitly described as a separate test backend and delegates commit. It calls the same native prepare and preflight primitives and keeps its snapshots/thread join before the final preflight. The README does not claim per-inventory-guard telemetry or transparent wrapping.

The reservation sources are genuine. Custody test source ranges and leases come from actual Plan queries; the concurrent released owner comes from the existing admitted mask builder. The separate primitive conflict tests use Admission::reserve leases and release both RefCell borrows before the source lease destructor. The deliberately inconsistent issuer metadata case is explicitly labeled private-helper-only and not constructible from sealed Plan descriptors. The proposed tests do not claim recovery from a RefCell conflict during consuming-query cleanup.

The direct success case checks exact source/destination pointer, ranges, capacity, and value; verifies Plan ledger release; then drops request/controller owners while retaining the returned mask and account observer. The prepared-box test samples the real aggregate Plan ledger and native account around preparation and a joined concurrent owner drop, checks the resident boundary from those values, and exercises cancellation cleanup. README states that compilation/execution remains owed; I did not build or execute these candidates.

## Pins

Candidate:
- policy_mask_custody_tests.rs: SHA-256 dc69eb21bb819fdb774d5f7e3ab7c76c48de45060aababc15776a798288048d8
- README.md: SHA-256 d7c98d8449bb570a0e3d00bb496e39b53db09c2db962de068fd5c39306dff8a3
- Candidate pins.json says rustfmt only; no build or native runs.

Primitive test source reviewed:
- /Users/michael/Code/deadpan/crates/deadpan-audio/src/sound_context_admission/policy_mask_handoff_tests.rs: SHA-256 e9ec3593b2e4c0eaa0624859aa0c8ecb54d51306d3ecee25836063e2307b45c3.

The candidate manifest pins the reviewed production helpers and Plan candidate for its snapshot. The live policy_mask_handoff.rs has since changed from that manifest's hash during concurrent work, so integration should recheck against the final source before applying.
