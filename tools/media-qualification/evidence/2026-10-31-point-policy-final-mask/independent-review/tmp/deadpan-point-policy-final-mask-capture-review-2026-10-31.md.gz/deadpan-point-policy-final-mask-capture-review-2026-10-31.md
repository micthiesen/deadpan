# C final capture and evidence review

No material finding in the reviewed capture evidence. This is an independent read-only audit of retained files, not a new build or native execution. Publication, final documentation, doctests and hygiene remain the parent's work. No product requirement or Gate credit changes.

Evidence root: /tmp/deadpan-point-policy-final-mask-qualification-2026-10-31.

Reproducible read-only audit, exact evidence pins and detailed results: /tmp/deadpan-point-policy-final-mask-capture-review-2026-10-31/{audit.py,extra.py,evidence-pins.json,audit-results.json,extra-results.json}. SHA-256 inputs were read in 1 MiB chunks. The audit used its own equality, cardinality, receipt and equation assertions rather than accepting final-capture-analysis.json as proof.

## Six final captures

All six final captures, Main and Scope with suffixes empty, -2 and -3, independently reconstruct the retained canonical bytes:

- 35,440,148 bytes.
- SHA-256 afa6038a02c959c7192c09c08a89266c7d52151a5e59a4f69828fbdf67e7414e.

Main has 2,922 named source inputs, manifest SHA 5128f1c367787bd769e130b1c26d0863d6d81f0872ed2866488694a4e964a92b, retained executable SHA 8666758d2ba1a4f67ebe53378bb07fa73bd9849277664055e11d5e96d2594750.

Scope has 2,594 named source inputs, manifest SHA 23933f9bfbdaac30e2c85379e910266e0c1bba07e109826cf552bde7e10a7b74, retained executable SHA a1562cb85b2cd5418c4217f346285a8489e8e26141772c1115206f699db70455.

Each receipt has exit zero, the exact ignored capture test and single-thread command, the correct body output path, variant, source-manifest digest and C checkpoint eedbc58272bdd009a65239b7104ddb786a2554fc. Its runner digest matches the retained runner. Before/after source and binary maps match literally; stream byte counts and hashes match stdout/stderr files; removed paths remain absent. Actual current named source bytes also match the captures in both roots at audit time.

Canonical reconstruction removes only the four separately verified provenance fields: top-level variant/source_sha256 and the same fields under native_requests. Sorting object keys and whitespace does not alter JSON values. No output, error, capacity, receipt, counter or invalid flag was removed.

## Before authorities and complete outputs

Both final old/off captures reproduce SHA af7a292718365c34fa03692e2cbe58a2cfb3c6d444b5ae29d52647e1fdbbff14. Both T interval captures reproduce SHA f64d3a00a10967cc3822083d21705bd454f2d33ff2198da30e25671092ab5a53. Their receipts, streams, body reconstruction and proof/environment identities also check.

The four named authority fixtures in each root, including the immediate pre-C fixture, match their literal recorded SHA-256 values. These are eight physical fixture checks.

Independent comparison against the immediate T before body checks fixture identities, case and operation lengths, and all operation metadata outside paired. All 744 complete paired.new.read.output values match without output projection or normalization: 264 Ok and 480 Error.

The ten internal cases and four public transfer cases have the same names and lengths. Every complete result_* and account_* field matches. This includes output values after local-work, provider and controller disposal, available account observations and final observer-drop booleans. Nine internal reads succeed and the lower-quota held-mask read remains an actual error; all four public transfers succeed. Recorded absent observers remain None, not simulated account readings.

## Intervals and work

The independent recursive traversal finds exactly 758 interval snapshots and 478 rows: 477 completed and one partial. Every snapshot has active/dropped counts zero, no misnesting and no overflow. Every row is attributable, has no foreign overlap, has enabled native boundaries, and retains equal non-null reset epochs with no boundary overflow.

For each completed row, canonical plus additional equals total. All 477 literal claims are forwarded, metered claims with expected_debit equal to total. In each of both lanes independently:

observed ReadWork delta = selected-lane expected_debit + sum of eight native phase deltas + host-eviction delta.

All deltas are nonnegative. This is a per-row equation; no row totals were summed into a whole-invoke attribution. These particular captures contain depth-one rows, so they do not add nested-interval runtime coverage.

The sole partial is internal case 7, held-public-mask-lower-quota-private-point, kind point_content. It retains claim: null, ReadWork delta [6,0], native residency delta one in lane zero and host delta zero. There is no invented completed-query fee for the remainder. Existing invalid flags remain literal; exact historical body replay checks that the compatibility captures did not reset or normalize them.

## Retained integration join and runtime receipts

final-qualification-join.json is valid. The all-target build source inventory and final-library inventory differ in exactly crates/deadpan-audio/src/bound_reads/native_mask_after.rs, with the exact text replacement from “independent Root/derived policies remain ordinary” to “independent projected-provider and derived policies remain ordinary”. The ancestor in stages.rs is gated by cfg(all(test, any(target_os = "macos", target_os = "linux"))). The replacement changes test capture scope text only.

All 20 retained integration executable files per root match their compiler-artifact pins and their actual matrix-run binary guards. Every integration receipt has stable sources/binaries, exit zero and matching output stream hashes. The final library executable pins and compiler-artifact opt-level/test identities also match the final capture binary and source inventory. /tmp and /private/tmp spellings were resolved as filesystem aliases for artifact source paths, without normalizing file contents.

The retained 21-target matrix receipts independently total Main 1,107 passed, 21 ignored, seven inherited WIP tests filtered; Scope 1,101 passed, 21 ignored, zero filtered. Final Audio library receipts show Main 526 / Scope 520 passed, 21 ignored, zero failed or filtered. Plan library receipts show Main 289 / Scope 276 passed, 28 ignored, zero failed or filtered.

## Scope and limits

The schema and scope text are accurate for this checkpoint: current closed Point SignalSample / PointCeil policy metadata and exact final Vec lease handoff. The old published_checkpoint, observer checkpoint and C policy_checkpoint are separately named, and the immediate before authority is explicit. The corrected internal scope distinguishes ordinary projected-provider and independently derived policies from already admitted Root input policy.

Root output-mask emission, ordinary projected-provider policy production, derived bus/equalizer masks, PCM/dependencies and whole preparation remain outside the C ownership claim. Whole-invocation native receipts and constructor intervals are distinct observations. Complete output equality and observed account lifetimes support these exercised paths; they do not prove arbitrary allocator behavior, an unexercised path, or physical ownership from public capacity alone.

The draft qualification document still read “PENDING final matrix, doctests, hygiene, repeated final captures” during this audit. The matrix and repeated capture portions are now independently supported above. This review does not certify the parent's later doctest, hygiene, documentation or publication work.
