# Independent final-mask handoff review

Verdict: implement this seam with the concrete conditions below. I found no need for a broader generic lease extraction, a new Storage representation, or a second destination Vec. The overall custody transfer is compatible with the current Plan Memory and B native owner. This is a read-only design review; no implementation, build, native run or root edit was performed.

Reviewed author inputs: /tmp/deadpan-point-policy-final-mask-handoff-design-2026-10-31/contract.md and api-sketch.rs. Exact input/current-source hashes and comparison with the author's pins are recorded beside this note.

## Conditions to make explicit before implementation

### 1. Final preflight must establish exclusive ledger access

Step5 must obtain the actual source ledger using try_borrow_mut, compute the remaining sound_context_frames while that exclusive borrow is held, then release it before returning the private token. A shared borrow() plus checked_sub proves the arithmetic but does not prove that commit's borrow_mut cannot panic: an already-live shared Ref permits the preflight read and rejects the later write.

This matters because the proposed commit has already credited native vector frames and moved the Vec by then. An unwind after writing remaining_ledger_frames but before disarming the source lease would also cause its later Drop to subtract those frames again.

This is a required implementation condition, not a claim that current production callers already hold a conflicting Ref. The ledger is a real RefCell and existing transfer code uses borrow_mut in publication and Lease::drop, so the non-unwinding proof needs this exact final borrow exclusion. No new public API is required.

The exclusive check alone is insufficient if anything can run between it and commit. Keep the complete query/inventory/mask owner intact, end every temporary Ref/RefMut, and perform no destructor, callback, extra issuer check, accounting check, allocation or trace callback in that gap. Descriptor/field moves and taking the existing Option<&mut Lease> are the only preparation for the immediately adjacent commit call. ReadWork is not shared across threads through this RefCell, so the remaining threat in this gap is local code execution or a retained borrow.

### 2. The token must store the final charge total

The contract already says the total is prechecked. Add its concrete field to the sketch:

    charge_frames_after: u64

Commit assigns that value to the existing Charge rather than recomputing checked_add or using an unchecked +=. The vector account credit remains the explicitly permitted prechecked atomic fetch_add. Precompute ledger remaining, vector frames and final Charge frames after every fallible reservation/check, with the source query still fully alive.

Do not retain an old account live total and later store it. Other threads can drop independent native owners between preflight and commit. Their only effect is subtraction, so the prechecked fetch_add bound remains safe; assigning a stale live total would resurrect freed charges.

### 3. Specify prepare's postconditions on the open trait

The actual native implementation has a stable issuer because Admission holds the same WorkControl/ReadWork reference. Its preparation must recheck that actual ledger and exact source lease after all make_room/Box work, end all borrows, and return a token tied to that precise descriptor.

Document these as trusted prepare_signal_mask postconditions: issuer unchanged and validated on return, no retained RefCell borrow, token not stored/deferred/reused, and the empty/positive-capacity cases validated exactly. Plan cannot add an arbitrary admission.issuer() callback after successful preparation without violating the proposed immediate commit boundary. A generic implementation that mutates its identity or retains a ledger borrow has broken this new protocol.

This is an OPEN trusted accounting trait, as the contract correctly states. Safe Rust does not enforce non-unwinding commit behavior. Keep the concrete native commit short and private, with no user callback, formatting, event emission, assertions that can fail on ordinary input, or fallible helper in the mutation window. Counter/trace publication belongs before preparation finishes or after the custody transfer is complete.

## Why the principal design is sound

### Exact independent lease and capability boundary

Current Memory is issuer plus Option<Lease>; it does not prove a specific allocation by itself. Current Root finish deliberately adopts/merges its final Vec lease into a GuardedBound inventory. That path cannot provide the proposed exact final allocation charge.

The new private FinalSignalMask solves this by construction: ranges precede its dedicated Memory, and that Memory is never adopted, zipped or merged. Native capacity/frame equality is a second check, not a substitute for that sealed construction invariant. Tests must verify that no final-mask reservation is ever a merge target/source, including a same-sized unrelated lease.

The descriptor exposes an immutable lease borrow only to a matching trusted backend. Commit grants that backend a scoped mutable lease and the exact Vec. That is an intentional accounting capability. It does not expose inventory/Core leases or create a generic GuardedBound::into_parts capability.

A generic backend can choose Mask=Vec or violate charge custody, just as a backend can violate today's reserve/merge/Drop contracts. Therefore describe the guarantee for the closed native destination and protocol-conforming backends, not as global prevention of extraction by arbitrary implementations. The closed Audio Admission and private native token remain the practical boundary.

Keep all source/descriptor constructors private and export only the Point-specific carrier/view/descriptor/trait. Do not add mutable Memory access, generic lease-take APIs, public token constructors, or an unrelated MaskContext import path.

### Peak accounting and continuity

Before commit, make_room must see:

    existing native payload + lazy shell + new Box
    + exact source Vec still in the Plan ledger
    + complete query inventory/Core/contents guards
    + all other current resident products

Reserve only the actual Storage Box. Reserving the vector again would manufacture a second physical destination and can falsely reject the correct cap. Skipping the Box reservation would undercount the real overlap.

If Plan ledger L includes vector frames v and native account A includes the prepared Box, stable total before commit is L+A. Credit v into native, move the same Vec, then set ledger to L-v and disarm exactly its lease. Stable total remains L+A. The transient conservative double charge is acceptable because no allocation, admission or external callback observes it. Releasing inventory afterward is legitimate only after its actual values are destroyed.

The exact Vec pointer/len/cap must remain unchanged. No merged_suppression, map, clone, collect, shrink or into_admitted copy may follow the admitted finalizer/handoff. Later Signal-to-Reference/Audio maps are separate actual destinations and retain their existing source/destination overlap.

### Drop behavior

Current OwnedMask::drop takes the Box, unboxes it, drops ranges, then Charge. Reusing it for the prepared empty-Vec Box preserves Box-before-Charge order on failure and for unused tokens. A bare Box<Storage> field would free its Box allocation after dropping Storage fields and therefore release the Charge too soon.

After successful commit the native Charge covers exactly Box plus actual vector capacity. The source lease has frames0 and its later Drop does not borrow ReadWork. The returned native mask must contain no ledger reference or work lifetime; a test that destroys ReadWork and controller before using the output verifies that erasure concretely.

The zero-capacity case requires Memory.lease=None, same issuer/metered validation, and no shell/Box fee. Positive capacity requires the actual matching Some(Lease), even if len0. Reject missing/excess/merged capacity leases before preparation/publication. Do not branch only on length.

### Forwarding, Point geometry and cancellation

The closed AudioPointDomain factory using its actual signal_ref, PointCeil and endpoints=true is the correct boundary. Root RoundEven policy or an arbitrary provider-backed signal is not an interchangeable source.

Construction forwards canonical/additional work once through the existing admission. The host must not spend the returned total again when forwarded=true; ordinary B replay keeps its existing literal debit/copy route. Handoff shell/Box work is separate native work, and moving existing vector custody is neither a second vector allocation nor a query-work refund.

Retain the same WorkControl/deadline across factory, consumers and handoff. The final preparation check is the last fallible check before commit. Cancellation/deadline can naturally change immediately afterward; a later existing caller check may then return Error and destroy the newly owned mask. That is correct cooperative cancellation. Do not insert a check mid-commit or remove the later caller check.

## Further implementation obligations

The new Signal finalizer needs its own bounded fallible sort/merge/mapping work audit. Current Root finish sorts and has some loops outside per-operation callbacks. Copying that body into C does not establish complete cancellation/work coverage. Keep Root unchanged and charge new actual Signal work as additional while preserving ordinary canonical units.

The inventory must retain all existing Plan/Core/capacity guards through media/preflight/PCM suppression and final preparation. A borrowed view is suitable. Public Clone on borrowed element types remains a cooperative API limitation; the actual native consumer must borrow and must not create owning unadmitted copies.

Use a distinct C ordinary-policy override that retains B native owners. Chaining C compatibility to the B-disabling internal legacy switch would compare the wrong behavior.

Prioritize tests for: exact source/destination pointer identity, all final-vector Memory separation/merge counts, post-reservation issuer/lease mismatch, actual conflicting shared ledger Ref rejected before commit, unused prepared Box drop order, simultaneous inventory/native peaks, exact warmed cap and one-below rejection, zero-cap/no-lease and positive-cap/len0 cases, each admitted work refusal prefix, output after ReadWork/controller drop, unchanged Root policy bodies and qualified B replay. Keep legacy query invalid flags literal; separate native handoff receipts must explain actual work.
