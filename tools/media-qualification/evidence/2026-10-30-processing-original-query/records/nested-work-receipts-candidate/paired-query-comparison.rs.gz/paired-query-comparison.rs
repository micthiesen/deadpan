fn assert_processing_with_paired_core_work(
    observed: &Value,
    canonical_work: usize,
    old: &Value,
    events: &[Value],
    case: &str,
) {
    let paired = events
        .iter()
        .map(|event| &event["observation"])
        .filter(|event| event["kind"] == "actual_processing_paired_core_binding")
        .collect::<Vec<_>>();
    let mut used = vec![false; paired.len()];
    let mut comparison = observed.clone();
    comparison["work"] = json!(canonical_work);
    let old_spans = old["spans"].as_array().unwrap();
    let spans = comparison["spans"].as_array_mut().unwrap();
    assert_eq!(spans.len(), old_spans.len(), "{case} span count");
    for (index, span) in spans.iter_mut().enumerate() {
        if span["content"]["tag"] != "Bound" {
            continue;
        }
        let bound = &span["content"]["value"];
        let admitted = &bound["resolved"];
        let selected = paired
            .iter()
            .enumerate()
            .position(|(at, record)| {
                !used[at]
                    && record["owner"] == bound["node"]
                    && record["environment"]["instance"] == bound["instance"]
                    && record["is_gap"] == json!(!bound["gap"].is_null())
                    && record["admitted"] == *admitted
            })
            .expect("every actual returned Bound must have a same-input full Core observation");
        used[selected] = true;
        let record = paired[selected];
        assert_eq!(
            record["ordinary"]["result"], "Ok",
            "{case} ordinary Core probe"
        );
        let ordinary = &record["ordinary"]["resolved"];
        let expected = &old_spans[index]["content"]["value"]["resolved"];
        assert_eq!(
            ordinary, expected,
            "{case} independent ordinary complete resolved value"
        );
        let receipt = &record["receipt"];
        let total = receipt["total"].as_u64().unwrap();
        let canonical = receipt["canonical"].as_u64().unwrap();
        let additional = receipt["additional"].as_u64().unwrap();
        assert_eq!(receipt["forwarded"], true);
        assert_eq!(total, admitted["work"].as_u64().unwrap());
        assert_eq!(canonical, ordinary["work"].as_u64().unwrap());
        assert_eq!(canonical.checked_add(additional), Some(total));
        assert_eq!(total.checked_sub(canonical), Some(additional));
        assert_eq!(
            record["extra_scope"]["entire_additional_is_main_lattice"], true,
            "{case} needs a separate local-category witness for nonempty outer environment/journal work"
        );
        for key in [
            "environment_repeat_count",
            "excluded_count",
            "resume_terms",
            "reanchors",
        ] {
            assert_eq!(
                record["extra_scope"][key], 0,
                "{case} extra-scope predicate {key}"
            );
        }
        let admitted_lattice = admitted["lattice"]["work"].as_u64().unwrap();
        let ordinary_lattice = ordinary["lattice"]["work"].as_u64().unwrap();
        assert_eq!(
            admitted_lattice.checked_sub(ordinary_lattice),
            Some(additional),
            "{case} complete additional scope is inside the main lattice for this checked input"
        );
        let mut scalar_checked = admitted.clone();
        scalar_checked["work"] = ordinary["work"].clone();
        scalar_checked["lattice"]["work"] = ordinary["lattice"]["work"].clone();
        assert_eq!(
            &scalar_checked, ordinary,
            "{case} every other Core field remains literal"
        );
        span["content"]["value"]["resolved"]["work"] = ordinary["work"].clone();
        span["content"]["value"]["resolved"]["lattice"]["work"] =
            ordinary["lattice"]["work"].clone();
    }
    assert!(
        used.iter().all(|value| *value),
        "{case} unused actual paired Bound observations: {used:?}"
    );
    assert_eq!(
        &comparison, old,
        "{case} full query with independently checked work scopes"
    );
}
