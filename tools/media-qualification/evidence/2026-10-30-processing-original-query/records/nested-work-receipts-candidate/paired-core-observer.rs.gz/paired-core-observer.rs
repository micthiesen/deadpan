pub(in crate::plan) fn paired_core_binding(
    bindings: &deadpan_core::AudioBindingState,
    owner: &NodeId,
    environment: deadpan_core::AudioBindingEnvironment<'_>,
    is_gap: bool,
    maximum_work: usize,
    admitted: &deadpan_core::ResolvedAudioBinding,
    receipt: (usize, usize, usize, bool),
) {
    let enabled = RECORDING.with(|slot| {
        slot.borrow()
            .as_ref()
            .is_some_and(|state| state.case.is_some() && state.phase == "admitted_processing_query")
    });
    if !enabled {
        return;
    }
    use deadpan_core::{AudioBindingEnvironment as Environment, AudioDefinitionScope};
    let (path, excluded, environment_json) = match environment {
        Environment::Occurrence(path) => (
            path,
            0,
            json!({"tag":"Occurrence","instance":instance(path)}),
        ),
        Environment::Definition {
            root,
            instance: path,
            outside_repeats,
        } => (
            path,
            outside_repeats.len(),
            json!({"tag":"Definition","root":root,"instance":instance(path),"outside_repeats":outside_repeats}),
        ),
        Environment::GapOccurrence {
            instance: path,
            after,
        } => (
            path,
            0,
            json!({"tag":"GapOccurrence","instance":instance(path),"after":after}),
        ),
        Environment::GapDefinition {
            root,
            instance: path,
            outside_repeats,
            after,
        } => (
            path,
            outside_repeats.len(),
            json!({"tag":"GapDefinition","root":match root {
                AudioDefinitionScope::NodeOutput(node)=>json!({"tag":"NodeOutput","node":node}),
                AudioDefinitionScope::RepeatGap(repeat)=>json!({"tag":"RepeatGap","repeat":repeat}),
            },"instance":instance(path),"outside_repeats":outside_repeats,"after":after}),
        ),
    };
    let binding = if is_gap {
        bindings.gap_bindings()
    } else {
        bindings.bindings()
    }
    .get(owner)
    .expect("actual successful Core binding");
    let resume_terms = binding
        .resume
        .as_ref()
        .map_or(0, |value| value.phase.terms.len());
    let entire_extra_is_main_lattice = path.repeats.is_empty()
        && excluded == 0
        && resume_terms == 0
        && binding.reanchors.is_empty();
    let ordinary = if is_gap {
        bindings.resolve_gap_in(owner, environment, maximum_work)
    } else {
        bindings.resolve_in(owner, environment, maximum_work)
    };
    let ordinary = match ordinary {
        Ok(value) => json!({"result":"Ok","resolved":value}),
        Err(error) => json!({"result":"Error","error":{"code":error.code,"message":error.message}}),
    };
    record(json!({
        "kind":"actual_processing_paired_core_binding","owner":owner,"is_gap":is_gap,
        "environment":environment_json,"maximum_work":maximum_work,"binding":binding,
        "admitted":admitted,"ordinary":ordinary,
        "receipt":{"total":receipt.0,"canonical":receipt.1,"additional":receipt.2,"forwarded":receipt.3},
        "extra_scope":{"environment_repeat_count":path.repeats.len(),"excluded_count":excluded,
            "resume_terms":resume_terms,"reanchors":binding.reanchors.len(),
            "entire_additional_is_main_lattice":entire_extra_is_main_lattice},
    }));
}
