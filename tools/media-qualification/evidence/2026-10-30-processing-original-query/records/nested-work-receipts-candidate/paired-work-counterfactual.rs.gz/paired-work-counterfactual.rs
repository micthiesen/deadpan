#[test]
fn paired_work_comparison_rejects_unwitnessed_lattice_fee_and_canonical_drift() {
    let mut checked = 0;
    visit(|domain, case| {
        if case["name"] != "hidden_resumed_actual_capture_domain" {
            return;
        }
        let mut admission = Admission::new();
        let samples = window(&case["request"]);
        let (first, events) = capture_baseline::observe_case(
            case["name"].as_str().unwrap(),
            "admitted_processing_query",
            || domain.processing_for_policy_admitted(samples, Default::default(), &mut admission),
        );
        let first = first.unwrap();
        let query = first.query();
        let canonical = query.canonical_units();
        let observed = processing(domain, query.query());
        let old = &case["first_processing_true"]["query"];
        let name = case["name"].as_str().unwrap();
        assert_processing_with_paired_core_work(&observed, canonical, old, &events, name);
        let mut bad_observed = observed.clone();
        let span = bad_observed["spans"]
            .as_array_mut()
            .unwrap()
            .iter_mut()
            .find(|span| span["content"]["tag"] == "Bound")
            .unwrap();
        let lattice_work = &mut span["content"]["value"]["resolved"]["lattice"]["work"];
        *lattice_work = json!(lattice_work.as_u64().unwrap() + 1);
        let mut bad_events = events.clone();
        let recorded = bad_events
            .iter_mut()
            .find(|event| event["observation"]["kind"] == "actual_processing_paired_core_binding")
            .unwrap();
        let lattice_work = &mut recorded["observation"]["admitted"]["lattice"]["work"];
        *lattice_work = json!(lattice_work.as_u64().unwrap() + 1);
        assert!(
            std::panic::catch_unwind(|| {
                assert_processing_with_paired_core_work(
                    &bad_observed,
                    canonical,
                    old,
                    &bad_events,
                    name,
                );
            })
            .is_err(),
            "an invented lattice fee cannot hide behind known outer added work"
        );
        let mut canonical_drift = events.clone();
        let recorded = canonical_drift
            .iter_mut()
            .find(|event| event["observation"]["kind"] == "actual_processing_paired_core_binding")
            .unwrap();
        let ordinary_work = &mut recorded["observation"]["ordinary"]["resolved"]["work"];
        *ordinary_work = json!(ordinary_work.as_u64().unwrap() + 1);
        assert!(
            std::panic::catch_unwind(|| {
                assert_processing_with_paired_core_work(
                    &observed,
                    canonical,
                    old,
                    &canonical_drift,
                    name,
                );
            })
            .is_err(),
            "paired ordinary canonical work must stay literal against the frozen value"
        );
        drop(first);
        assert_eq!(admission.0.borrow().live, 0);
        checked += 1;
    });
    assert_eq!(checked, 1);
}
