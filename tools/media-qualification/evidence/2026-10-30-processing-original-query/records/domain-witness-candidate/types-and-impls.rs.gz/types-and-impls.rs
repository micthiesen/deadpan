/// One admitted first processing query sealed to its exact Domain and range.
/// The construction lease remains live through policy reuse and fallback.
pub struct AdmittedAudioDomainProcessing<'context, 'plan, I, L> {
    domain: &'context AudioDomain<'plan>,
    samples: Range<AudioSample>,
    query: super::audio::AdmittedAudioProcessingQuery<'plan, I, L>,
    stops: super::audio::capture::ProcessingStops,
}

/// Admitted first-query storage paired with separately performed policy work.
pub struct AdmittedAudioDomainProcessingPolicy<'plan, I, L> {
    processing: super::audio::AdmittedAudioProcessingQuery<'plan, I, L>,
    policy: super::AudioPolicyQuery<AudioSample>,
}

impl<'plan, I: Copy + Eq, L> AdmittedAudioDomainProcessing<'_, 'plan, I, L> {
    pub fn query(&self) -> &super::audio::AdmittedAudioProcessingQuery<'plan, I, L> {
        &self.query
    }

    /// Fresh limits cover policy only; first-query work stays separate.
    pub fn finish_policy(
        self,
        caller: &AudioDomain<'plan>,
        samples: Range<AudioSample>,
        limits: AudioQueryLimits,
    ) -> Result<AdmittedAudioDomainProcessingPolicy<'plan, I, L>, PlanError> {
        if !std::ptr::eq(self.domain, caller) || self.samples != samples {
            return Err(PlanError::InvalidPlan(
                "processing policy identity mismatch",
            ));
        }
        let policy = if self.stops.permits_binding_reuse() {
            super::audio_policy::domain_policy_with_processing(
                caller,
                samples,
                limits,
                &self.query.query().spans,
            )?
        } else {
            caller.policy(samples, limits)?
        };
        Ok(AdmittedAudioDomainProcessingPolicy {
            processing: self.query,
            policy,
        })
    }
}

impl<'plan, I, L> AdmittedAudioDomainProcessingPolicy<'plan, I, L> {
    pub fn into_queries(
        self,
    ) -> (
        super::audio::AdmittedAudioProcessingQuery<'plan, I, L>,
        super::AudioPolicyQuery<AudioSample>,
    ) {
        (self.processing, self.policy)
    }
}
