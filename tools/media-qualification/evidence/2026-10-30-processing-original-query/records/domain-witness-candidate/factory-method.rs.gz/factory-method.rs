    /// Co-produce the policy witness while retaining actual processing leases.
    pub fn processing_for_policy_admitted<A: crate::AudioSoundContextAdmission>(
        &self,
        samples: Range<AudioSample>,
        limits: AudioQueryLimits,
        admission: &mut A,
    ) -> Result<AdmittedAudioDomainProcessing<'_, 'plan, A::Issuer, A::Lease>, A::Error> {
        let mut stops = super::audio::capture::ProcessingStops::default();
        let query = self.processing_observing_admitted(
            samples.clone(),
            limits,
            true,
            Some(&mut stops),
            admission,
        )?;
        Ok(AdmittedAudioDomainProcessing {
            domain: self,
            samples,
            query,
            stops,
        })
    }
