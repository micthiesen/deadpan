# Paired processing witness audit

Audited the current scoped tree at /tmp/deadpan-query-groundwork-2026-10-26/scoped. Read-only source review; no Git, Cargo, native execution or repository writes. Concurrent edits were preserved.

## Finding: source identity helper needs receipt checks before replacing work

Location: crates/deadpan-plan/src/audio_owners/processing_query_identity_tests.rs, processing_asset_observation, approximately lines 61-70.

The helper replaces admitted_snapshot["work"] with the ordinary snapshot work before comparing the complete source query, but does not first assert this admitted carrier's canonical work equals ordinary.work, its total equals canonical + additional, or its total equals the policy's actual forwarded work. This is a test coverage gap, not evidence of a current production error. A regression limited to the longer changed AssetId's admitted canonical/receipt fields would be hidden by that replacement. The general metered frozen test covers the original frozen ID, not this changed document.

Add these checks before the replacement, using the already-live carrier and observer:

    assert_eq!(admitted.canonical_units(), ordinary.work);
    assert_eq!(admitted.canonical_units().checked_add(admitted.additional_units()), Some(admitted.work()));
    assert_eq!(admitted.query().work, admitted.work());
    assert!(admitted.was_forwarded());
    assert_eq!(observer.policy.0.borrow().forwarded, admitted.work());
    assert_eq!(observer.spends.iter().sum::<usize>(), admitted.work());

The remaining source identity proof is appropriately narrow: one actual frozen Source Root is pinned to its checked document and immutable full OLD body; both original and changed admitted bodies are compared completely with their own ordinary bodies; only the specific AssetId string/key is changed for ordinary body comparison; the entire requested Layout multiset must differ by exactly the independently calculated identity Layout on every observed Source edge. Domain is acquired through the actual owner input and checked root sample range. No arbitrary nested work stripping occurs here.

## Paired Bound normalization is independently supported

capture_baseline::paired_core_binding is called at audio_bound_query.rs's actual successful metered resolution site after taking the real linear receipt and before account_core. It receives the same borrowed binding state, owner, environment, gap mode and pre-account remaining cap that the real resolver used. It serializes the complete actual admitted value and runs resolve_in/resolve_gap_in separately with Unmetered. That ordinary run has no admission callback or access to the live host ledger. Work is local scalar state; the extra allocation work is inactive in Unmetered. The observed ordinary probe does not enter Plan processing again.

The callback returns immediately unless an explicit recording has a case and phase admitted_processing_query. Session/CaseScope Drop clear recording state on unwind. Nested sessions are refused. The existing recorder was already test-only; no production observer or persistent cache is introduced.

assert_processing_with_paired_core_work matches each actual Bound to an unused paired observation by owner, instance, gap status and complete admitted resolved value. It requires the paired complete ordinary resolved value equal the corresponding frozen complete resolved value. Hence canonical metadata or historical semantic drift cannot be normalized away. It rejects unmatched spans and unused paired observations. The final complete query comparison retains all Stage/Bound history, headers, samples, span metadata, lookup and other scalar fields.

For every matched binding, the actual receipt must be forwarded; total must equal admitted resolved.work; canonical must equal paired ordinary resolved.work; checked canonical + additional and total - canonical must both reconcile. Only resolved.work and resolved.lattice.work are replaced, after all these assertions. The top query work replacement is supplied from the actual carrier's canonical_units; both helper callers independently require it equal frozen work and reconcile carrier total/additional and actual forwarded work.

## Why the whole additional receipt bounds this corpus's main lattice delta

The extra_scope predicate is based on the actual binding and environment, not expected subtraction. It requires no environment repeats, no definition exclusions, no resume terms and no reanchors. The normalizer requires the flag and all four actual counts zero, then requires admitted main lattice work - ordinary main lattice work exactly equal actual receipt.additional.

Source proof: AudioBindingEnvironment::validate_build only enters ScratchSet insertion for repeats/exclusions; with both empty it adds no work or allocation. ScratchSet::new/extend_capacity alone are metadata operations. resolve_binding_build then performs a canonical-only initial spend, resolves the main lattice through a shared Build fork, and only the absent resume-term/reanchor loops could resolve other placements. merge_value transfers leases and validates but does not add work. Consequently every admitted-only addition for these checked successful inputs lies within the main lattice's resolve_with_build interval. That interval stores work.used() - before, not whole-resolver used work. Build::account_child includes child additional work in that interval; receipt categories remain independent of frozen values.

This is a finite input proof. The code deliberately rejects nonempty outer environment/journal cases rather than claiming whole additional is always lattice-local. The separate Core test lattice_work_is_local_category_delta_after_real_outer_prefix verifies true local-category accounting with a nonempty prefix; it is supplementary evidence, not used to infer a Plan offset.

The negative Plan test changes both a serialized actual lattice work and its paired admitted record; this bypasses only equality matching and still must fail the independent whole-additional delta check. Its other mutation changes the paired ordinary canonical work and fails the frozen full ordinary comparison. Neither mutation regenerates expectations.

## Corpus and policy checks

processing_query_admission_tests compares the complete ordinary matrix to all 446 frozen observations, then repeats all observations with METERED=false and zero policy callbacks. The metered default full/crop/empty coverage is pinned to 99 queries, 74 without Bound content and 29 matched Bound observations. Successful metered queries reconcile canonical frozen work, total and actual policy forwarded work; lease lifetime and accepted prefixes are checked separately. Invalid limit/range errors remain literal and precede callbacks.

audio_domain_admitted_policy_tests independently checks all 26 first-query frozen bodies using the paired normalizer, 22 reuse and four fallback cases, exact returned buffer identity, live carrier ownership and unchanged first-query work through finish. Policy expected-work reduction is the existing separately frozen actual second-query receipt; full policy output/lookup remains checked. Fresh limits, empty exact-work refusal, cloned Domain identity and changed ranges remain literal behavior checks. No second admission walk is normalized away.

## Verdict and limits

No broad stripping, circular expected-derived nested fee, regenerated oracle or unproved nested-work adjustment found in the paired Bound normalizer. The source identity helper receipt gap above should be closed before relying on that test for changed-identity work evidence. Actual current test execution remains parent-owned; this review makes no pass claim.

Host downstream accounting of Bound.work is a separate integration question. This test audit proves constructor and nested receipt identities, not whether every later host consumer avoids re-billing the admitted work. No production conclusion about that risk is inferred here.

## Source pins at review completion

- crates/deadpan-plan/src/audio_owners/legacy_snapshot_v1/capture_baseline.rs: 0a7443fbe4c6e8b95cf44d5cf2c53944cc91eaddd14a16abfc04def135569d3f (26455 bytes)
- crates/deadpan-plan/src/audio_owners/processing_query_admission_tests.rs: 00e0a22a49b472f86f49b93c5356400ba8c15ab64184c4e6e08f15eed348e297 (27204 bytes)
- crates/deadpan-plan/src/audio_owners/processing_query_identity_tests.rs: 94ab4fa2d9e65e20aaec13d946e674db28700f114ef8d217fe720186bdf5b92a (8617 bytes)
- crates/deadpan-plan/src/audio_domain_admitted_policy_tests.rs: 950149e653c3c2ade32ff238b6c4bd8c4bb025c8a53fb919128b96401b6c3b82 (12607 bytes)
- crates/deadpan-plan/src/audio_bound_query.rs: 01a5b56b65a373e422620d14371a222e33c0394310262c14887b45f29f66e040 (27179 bytes)
- crates/deadpan-core/src/audio_binding.rs: e4504ced21a29b595cfc15a8e15d63d0003336c9b864f2335e3479c92398965f (108063 bytes)
- crates/deadpan-core/src/audio_binding/admission.rs: ca5f7bf85c965b5555f3435144258024f1783c584a73bf0ef628ca25279ecd75 (25117 bytes)

## Finding addressed

Parent reports the Source identity helper receipt gap was fixed in both roots before the final Plan library/integration runs: forwarded true, canonical equal ordinary work, total equal canonical + additional, and actual observer policy forwarded equal total, all before top-work normalization. Parent owns execution evidence. This closes the source-review finding; no additional production issue was found.
