# Guard-preserving processing collection: checked zip plus existing map

Read-only design, 2026-10-30. No actual repository edits, Git, Cargo, compiler/native runs. Code below is deliberately compilable-shaped, not compiler-verified. It uses actual current type/error names. Parent owns the compile/test proof.

## Decision

Add one checked Core zip operation and one read-only composition-readiness check. Keep existing infallible AudioBindingValue::map_value. Do not add a fallible callback, policy-free value token, public mutable value accessor, generic detachment, or numerical reader view API.

Plan holds a replacement/conversion state INSIDE the guarded value. Pre-reserve/allocate a replacement Vec while the complete old accumulator and current span remain guarded. Move one element per existing map callback. Debit its actual move through QueryBudget before that callback, outside the Core policy borrow. For Root conversion, compute only the next span's fallible scalar grid/map from borrowed fields before moving that one span.

This meets the actual incremental grow failure semantics without a bulk copy precharge. Preallocating and then moving every old item in one callback would not: the old Budget::grow charges per moved item, and a failed bulk precharge must not pretend those moves happened.

Current OLD processing captures now cover 446 observations/33 parents and match Main/Scope; parent supplied frozen body SHA256 edf714032313470dd98537e69c363e07ed687e2791df8ebfa3e58daafcea0f5e. This design does not alter those observations.

## Core API

In deadpan-core/src/audio_binding/admission.rs:

    impl<T, I: Copy + Eq, L> AudioBindingValue<T, I, L> {
        pub fn validate_composition<P>(
            &self,
            policy: &P,
        ) -> BuildResult<(), P::Error>
        where
            P: AudioBindingAdmission<Issuer = I, Lease = L>,
        {
            self.validate(policy)?;
            if self.charge_transferred {
                return Err(invalid("binding charge already transferred").into());
            }
            if self.work.is_some() {
                return Err(invalid("binding work must be consumed before composition").into());
            }
            Ok(())
        }

        pub fn zip_value<U, P>(
            mut self,
            mut other: AudioBindingValue<U, I, L>,
            policy: &mut P,
        ) -> BuildResult<AudioBindingValue<(T, U), I, L>, P::Error>
        where
            P: AudioBindingAdmission<Issuer = I, Lease = L>,
        {
            // Construct this before ANY policy/check callback.
            let mut pending = ZipPending {
                value: (self.value.take(), other.value.take()),
                left_issuer: self.issuer,
                right_issuer: other.issuer,
                left_metered: self.metered,
                right_metered: other.metered,
                left_transferred: self.charge_transferred,
                right_transferred: other.charge_transferred,
                left_work: self.work.take(),
                right_work: other.work.take(),
                left_payload: self.lease.take(),
                left_buffer: self.buffer.take(),
                right_payload: other.lease.take(),
                right_buffer: other.buffer.take(),
            };
            pending.validate(policy)?;
            merge_slots(policy, &mut pending.left_payload, &mut pending.right_payload);
            pending.validate(policy)?;
            merge_slots(policy, &mut pending.left_buffer, &mut pending.right_buffer);
            pending.validate(policy)?;

            let result = AudioBindingValue {
                value: Some((
                    pending.value.0.take().expect("validated left value"),
                    pending.value.1.take().expect("validated right value"),
                )),
                issuer: pending.left_issuer,
                lease: pending.left_payload.take(),
                buffer: pending.left_buffer.take(),
                work: None,
                metered: pending.left_metered,
                charge_transferred: false,
            };
            result.validate_composition(policy)?;
            Ok(result)
        }
    }

ZipPending's exact field order is part of the design:

    struct ZipPending<T, U, I, L> {
        value: (Option<T>, Option<U>),
        left_issuer: I,
        right_issuer: I,
        left_metered: bool,
        right_metered: bool,
        left_transferred: bool,
        right_transferred: bool,
        left_work: Option<AudioBindingForwardedWork<I>>,
        right_work: Option<AudioBindingForwardedWork<I>>,
        left_payload: Option<L>,
        left_buffer: Option<L>,
        right_payload: Option<L>,
        right_buffer: Option<L>,
    }

Its private validate method checks:

1. Both value slots are Some, else the existing internal invalid-state error.
2. Both issuers equal the current policy issuer; both modes equal P::METERED. Mismatch returns Policy(policy.issuer_mismatch()).
3. Neither transferred flag is set.
4. Both work slots are None.

Capture policy.issuer() once per validation to compare both inputs to the same observation. Validation never spends or reserves. It runs before either merge and after EACH merge, so a policy rotation during the first merge cannot lead to a second merge against a foreign policy.

Merge slots by borrowing the source in its pending field until the trusted merge finishes:

    fn merge_slots<P: AudioBindingAdmission>(
        policy: &mut P,
        into: &mut Option<P::Lease>,
        from: &mut Option<P::Lease>,
    ) {
        if into.is_none() {
            *into = from.take();
        } else if let Some(source) = from.as_mut() {
            policy.merge(into.as_mut().expect("occupied target"), source);
            // The trusted merge disarmed this source without a refund.
            drop(from.take());
        }
    }

Do not take the live source lease into a local before calling merge. With the borrowed-slot form, even a merge unwind leaves all still-present lease slots after both actual values in ZipPending. Source dropping after a successful merge is zero-charge by the existing policy contract.

The output has one payload and one buffer lane, each the checked merge of its corresponding two input lanes. Both values precede both output lanes. It has no manufactured work receipt. zip_value itself does not debit/replay work, reserve storage or allocate.

validate_composition is a read-only check used for mixed plain/Core Plan cases before existing map_value. It returns no value, charge or certificate. A locally owned Core value cannot have its receipt/transferred state mutated by another writer between this check and map_value; map_value still performs its own current issuer/mode pre/post validation. The Plan helper must hold the whole value before its Plan memory throughout both calls.

Existing map_value retains its current broader callers and semantics. Do not globally add the new consumed-receipt requirement to it: bound construction still uses ordinary maps in other phases.

## Receipts: concrete existing sequence

audio_bound_query.rs currently resolves Core, calls resolved.take_work through CoreAdmission, then QueryBudget::account_core before constructing/exposing QueryBound. A processing span produced through that path therefore has its Core work slot None before collection.

For two Core spans:

- each resolution already forwarded its real successful callbacks;
- each take_work transfers its receipt once;
- account_core debits only the local Plan allowance and reconciles canonical/additional counters;
- zip requires both work slots None;
- zip returns work None, so neither input receipt can be taken a second time;
- final processing query work comes from the one QueryBudget's checked canonical+additional counters.

The first plain accumulator has no Core receipt. A plain span's existing canonical/extra Plan work is already in that same Budget. A missing Core account call is a private producer bug, not something zip can infer from a discarded receipt; keep composition behind the existing sealed Plan producer/helper.

An attempted zip with an unconsumed receipt fails without invoking either merge. An attempted zip/map composition after charge publication fails before adopting another value. A join never resets a used transfer state into fresh credit.

## Plan GuardedBound zip helper

Add private GuardedBound::zip in audio_bound_query.rs. It accepts two complete GuardedBounds plus &mut QueryBudget and returns GuardedBound<(T,U)>.

Keep a named input state owning BOTH BoundValue fields before BOTH Plan Memory fields. Check both Plan issuers while that state is intact. Under a short CoreAdmission reborrow, call validate_composition for each Metered variant. End that adapter borrow before any other Budget operation.

Dispatch:

- Legacy + Legacy: construct Legacy((left,right)).
- Legacy + Metered: existing right.map_value captures the plain left by move and returns (left,right).
- Metered + Legacy: existing left.map_value captures the plain right by move and returns (left,right).
- Metered + Metered: call left.zip_value(right,&mut adapter).

Every callback owns its inputs and returns its complete output. It mutates no external output Vec or value slot. The external Plan memory fields stay owned by the named input state until the resulting BoundValue is owned in a named output state BEFORE both Plan memories. Then validate/merge those same-issuer Plan memories and return the usual GuardedBound field order. On a Core precheck/callback/postcheck error, the Core values die before their Core leases inside that call; the caller's Plan memories remain live until the call has returned.

CoreAdmission exists only inside the dispatch call. Nothing stored in the returned value borrows the adapter or QueryBudget. Use the existing admission::core error mapping, so Document errors remain Plan errors and policy errors preserve A::Error.

Because the callback is still infallible and allocation-free, the current GuardedBound::map signature works unchanged after zip.

## Real collection state and call sequence

A Plan accumulator can keep its capacity charge inside its value:

    struct Acc<S, I, L> {
        spans: Vec<S>,
        capacity: Memory<I, L>,
    }

GuardedBound<Acc<S,I,L>> additionally holds the actual Plan payload memory in _memory, and, after the first Bound, its Core lane covers all accumulated Core-backed values. Acc drops Vec elements/buffer before its capacity memory. Core then drops its independent lanes; outer GuardedBound drops its payload memory last.

Start with GuardedBound::plain(Acc { spans: Vec::new(), capacity: budget.memory() }, budget.issuer). No Core value is minted. WalkResult's actual Plan memory is merged into the returned guarded span before collection, with that span owned during the merge. Convert AudioWalkSpan to processing content through an existing infallible map, never via flattened_leaf.

When capacity is already sufficient:

    let joined = accumulator.zip(current_span, budget)?;
    accumulator = joined.map(budget, |(mut acc, span)| {
        // Capacity was inspected before zip; neither zip nor map changes it.
        acc.spans.push(span);
        acc
    })?;

This map performs no allocation. It accepts the first plain accumulator plus a Core span through the Legacy/Metered branch, and later independently Core-backed spans through zip_value. Mixed Leaf/Stage and Bound spans use the same code.

When growth is required:

1. Borrow immutable accumulator.spans.len/capacity, compute needed with checked arithmetic.
2. Prepare a full replacement Vec in Owned while accumulator/current span are still guarded.
3. zip accumulator/current span, then map that tuple plus the owned replacement into Growth below.
4. Debit/move exactly one old element at a time.
5. Drop the old iterator/buffer before dropping its capacity lease; append pending into already admitted spare capacity.

    struct Growth<S, I, L> {
        old: std::vec::IntoIter<S>,
        replacement: Vec<S>,
        pending: Option<S>,
        old_capacity: Memory<I, L>,
        replacement_capacity: Memory<I, L>,
    }

All values precede both capacity memories. It remains INSIDE GuardedBound, which retains all combined Core lanes and Plan payload memory.

    let replacement = budget.prepare_replacement::<S>(
        accumulator.spans.capacity(), needed,
    )?;
    let joined = accumulator.zip(current_span, budget)?;
    let mut growth = joined.map(budget, move |(acc, span)| Growth {
        old: acc.spans.into_iter(),
        replacement: replacement.value,
        pending: Some(span),
        old_capacity: acc.capacity,
        replacement_capacity: replacement.memory,
    })?;
    while !growth.old.as_slice().is_empty() {
        budget.additional(1)?;
        growth = growth.map(budget, |mut state| {
            let value = state.old.next().expect("observed remaining item");
            state.replacement.push(value);
            state
        })?;
    }
    accumulator = growth.map(budget, |state| {
        let Growth {
            old, mut replacement, pending,
            old_capacity, replacement_capacity,
        } = state;
        drop(old);             // Actually frees old buffer first.
        drop(old_capacity);    // Only its capacity charge now ends.
        replacement.push(pending.expect("current span"));
        Acc { spans: replacement, capacity: replacement_capacity }
    })?;

prepare_replacement is a small private factoring of the existing metered Budget::grow preparation: count=max(needed,old_capacity.checked_mul(2)?,1), reserve the complete Layout::array<S>(count) into Owned memory, Vec::with_capacity(count), and existing exact-capacity assertion. The old/current values stay alive during reserve/allocation. It performs no copy precharge.

Use that helper from ordinary Budget::grow as well if implementation duplication would otherwise drift. Preserve Budget::grow's false early-return and exact original push/extend backend. The guarded growth loop reproduces its per-element additional(1), actual drain/move order and old-buffer drop point; it does not need mutable access to a Core value.

**Borrow proof:** every fallible Budget call occurs before or between GuardedBound calls. Each map internally reborrows budget.admission for only its call. Its closure captures only owned values/scalars, never budget or its admission. When the next budget.additional runs, that reborrow has ended. There is no overlapping &mut A, no reconstruction of QueryBudget, and no counter writeback path.

## Root fallible conversion

Keep the actual admitted AudioSignalQuery, all accumulated Core lanes, its headers and input capacity. Prepare/admit the output buffer while it remains live. Map into a guarded conversion state with these fields in this order:

- project/revision IDs and scalar query metadata;
- input IntoIter<AudioSignalSpan>;
- output Vec<AudioProcessingSpan>;
- input/output capacity Memory fields.

Before each step, borrow input.as_slice().first(). Compute AudioSampleGrid::new and AudioSampleMap::new from that next span's scalar fields, using the original per-span failure order. No IDs, content or guards move at that point. Do not precompute all spans: that changes failure order and requires another owned vector.

After scalar success, bill any actual new conversion/move unit outside map, then use one allocation-free map to take exactly that input span, move its fields and prepared scalar grid/map into one output span, and return the full state. A scalar/debit/issuer failure leaves the complete current guarded state owned and all leases live until its values drop. Partial outputs/remaining inputs therefore cannot outlive their leases.

At completion, drop the exhausted input iterator before its input-buffer capacity charge. Map the header IDs and output Vec into the actual AudioProcessingQuery; the read-only public carrier borrows that query through its internal guard. No second header clone, public detach or callback escape occurs.

METERED=false keeps the original Result collect allocator backend; share the per-span scalar/field conversion without substituting the metered vector algorithm. Do not change Root/Domain canonical weights or replace their different walkers.

## Errors and unwind

- Core precheck: ZipPending already owns both actual values before all four lanes.
- Foreign issuer/mode, unconsumed work or transferred charge: no merge/map or new ownership occurs; values drop before leases.
- Issuer rotation during a merge: validation immediately after that merge prevents the next merge. Pending still holds both values before remaining lanes.
- Existing map callback error: maps are infallible; all actual Plan failures occur outside the callback with a whole guarded state owned.
- Callback unwind: moved callback inputs/partial local output drop while Core's independent lanes remain in the calling map frame; caller's Plan payload memory remains live outside the Core call. A callback must not put owning fields into external storage or leak them, matching the existing trusted map contract.
- Post-map validation error: existing Core map owns completed output before its leases; outer Plan memories remain live until the Core error returns.
- Plan grow reserve/copy refusal: the current Growth/accumulator and span are complete guards. Only successful actual per-item debits remain spent.
- Allocation failure that aborts the process has no observable cleanup requirement. Ordinary Rust panic/unwind must follow the ordering above.
- Admission.merge remains trusted infallible, non-unwinding, allocation-free and source-disarming. Keeping borrowed slots improves drop ordering even if it panics, but cannot repair arbitrary ledger corruption inside a violated policy contract.

## Why not the fallible-budget callback alternative

A Core try_join_map(&mut P, callback(T,U,&mut P)) can be made borrowable by splitting QueryBudget, wrapping only admission in CoreAdmission, and reconstructing a temporary Budget in the callback. But scalar count writeback would need an RAII guard to run even on panic; local allowance and forwarded work mutate before callback return. It also needs a second callback-error type and explicit mapping between Core and Plan errors.

The stepwise guarded state above needs none of that API surface. Its callbacks match the existing infallible map contract, and actual Budget methods run with the original intact Budget. Prefer it unless measured overhead of one map per old element becomes material. Work limits bound the number of steps; do not optimize by changing debit semantics preemptively.

## Exact changes and tests

Core:
- audio_binding/admission.rs: add validate_composition, zip_value, private ZipPending validation and borrowed-slot merge helper.
- Existing AudioBindingValue layout, map_value, take_work and transfer public semantics stay unchanged.
- No new exported type is necessary; existing AudioBindingValue reexport suffices.

Plan:
- audio_bound_query.rs: private GuardedBound::zip with all four variant combinations and full caller-memory ordering.
- audio_owner_query_admission.rs: private prepare_replacement factoring shared with existing grow, if desired; no generic Core callback/context API.
- New processing constructor module: guarded Acc/Growth/conversion states and sealed admitted query; actual Root structural admission and Domain walker assembly as already scoped.
- audio_domain.rs: admitted sealed witness/completed product preserving exact identity/range, fresh policy limits, tape reuse/fallback.
- Host original_request.rs: admitted processing carrier and existing real-ledger lifetime/issuer pattern.

Before production callers, test the narrow Core seam with: all four lanes nonempty; each lane missing; two independently consumed receipts; refusal with either unconsumed receipt; foreign issuer/mode; either transferred flag; rotation at each validation/merge; map panic after zip; drop-traced values before every lease; no second take_work; no new spend/reserve; transfer still works once on the composed output.

Then test Plan: first plain+Core, Core+plain and several independent Core spans; growth with old/current plus replacement live; each per-move work refusal; header/scalar-conversion failure before/after earlier output; callback panic; exact requested peak and one short; zero leases afterward; retained OLD fields/work/lookup/error order for both modes. Preserve actual full Stage/Bound history, Domain witness reuse/fallback and aggregate request residency. No content eligibility scope reduction is required.
