# Root outer processing admission candidate

Scratch only. No actual repository edits, Git, Cargo, rustc, native runners or expected-data regeneration. Rustfmt parsed/formatted the new module, helper fragment and minimal existing-file candidate. Parent owns compilation, lint, frozen oracle comparison and integration.

## Files and integration

- Apply `audio_signal.patch` against its pinned input, resolving concurrent changes rather than replacing the full file blindly. Three hunks only: add child module, replace ordinary Root processing body with its Unmetered admitted wrapper, and route only Structural `query_inner` through the new shared assembler.
- Add `audio_signal_processing_query.rs`, also supplied as a new-file patch.
- Append `processing-helpers.rs.fragment` to parent-owned `audio_processing_query.rs`. `Accumulator.capacity` is already visible within Plan in the current actual helper; no other visibility widening is needed. The fragment does not copy or overwrite shared collector implementation.
- Keep parent's Collected alias, Domain stop/witness tuple, Stage adopt_memory postcheck, existing Core zip and removed old bound wrapper intact. This candidate edits none of those files.

## Actual shared flow

`RenderPlan::audio_processing` calls public generic `audio_processing_admitted` with Unmetered and uses the exact Unmetered carrier extractor. The generic false branch calls actual ordinary Structural `query_inner`, then the literal old fallible Result collect conversion. Only this branch calls helper `ordinary`, which rejects metered mode before forming an empty same-issuer guard. It records canonical=query.work, additional=0, forwarded=false and exposes no detach API.

Structural `query_inner` now calls `structural_query_unmetered`. It and the true Root factory share `structural_query_admitted`, after the identical scalar prelude: limits validation, owned-input refusal, transform/grid construction, first/count boundaries, requested-range validation. No admission work/reservation precedes scalar validation. Source voice, silence, projected and owned-input provider bodies remain literal and outside the shared Structural path.

The generic assembler calls actual `span_admitted`, clips the whole guarded span via allocation-free map, and uses current actual collection::push for accumulator ownership/growth. It clones project, revision and signal definition at the original final-header site, retaining that header in an Owned value before zip/map. It reconciles local consumed work with canonical+additional before forming a guarded `SignalBuffer` containing the actual complete AudioSignalQuery followed by its independent vector capacity Memory.

The true Root factory reserves/allocates the entire processing output Vec while SignalBuffer and all input spans, headers, Core lanes and capacity charge remain owned. It maps into `Conversion`, whose headers, input IntoIter and output Vec precede both capacity guards. Each iteration computes the next actual grid, then sample map from borrowed input fields in old error order. Only after those succeed does it bill one new additional unit and move exactly one span in an allocation-free map. No canonical conversion debit is invented. It drops the exhausted input IntoIter before dropping its capacity guard, moves original headers into AudioProcessingQuery once, and retains the full output capacity inside the sealed carrier.

The narrow `seal` helper receives a whole guarded `(actual query, capacity)` tuple. It checks query.work=canonical+additional=maximum_work-remaining, validates capacity issuer, then maps into the existing private ProcessingValue and existing public sealed carrier. It spends, reserves and allocates nothing.

## Checks completed

- Rustfmt parsing, edition 2024, skip_children=true.
- Main and Scope audio_signal inputs are byte identical.
- Existing-file patch has only the three intentional hunks.
- The moved ordinary conversion expression equals the old expression after whitespace removal, including `.collect::<Result<_, PlanError>>()?` and grid-before-map scalar order.
- Structural traversal canonical weights remain in integrated span_admitted; the outer assembler adds no canonical spend. It retains original span-cap check before each walk and end-header order. Existing `query_inner` alternative provider text remains unchanged beneath its new Structural early dispatch.
- No golden data changed. Full frozen 446-observation/33-parent execution remains owed to parent, body SHA `edf714032313470dd98537e69c363e07ed687e2791df8ebfa3e58daafcea0f5e`.

## Parent verification owed

Compile/lint both actual variants with helper fragment integrated, then run the frozen ordinary processing matrix. Verify false admitted output equals every frozen field with additional=0 and no metered spend/reserve/merge callbacks. Metered Root tests should independently reconcile full/crop/empty output canonical work, additional work, forwarded work, query.work, requested Layout final/peak and cleanup.

Exercise exact/one-short total work and byte room; initial/input-buffer growth; output allocation while complete input remains live; late conversion refusal; header refusal/issuer rotation; multiple Core spans with earlier leases still retained; successful/unused drop. Scalar conversion grid/map failures must retain existing error order and clean all lanes. Test callback refusal/issuer rotations around zip/map/reservation and ensure spent work never refunds. No heap/RSS claim follows from requested Layout accounting.

## Limitations

Parser checked only. No test-only production hooks, broad projected/source-voice admission, metadata cache, retained-query cache, budget increase, old-weight change or new Core API. SignalBuffer output capacity is real actual Vec capacity; payload/Core charges remain separate and can conservatively include discarded internal temporary metadata until carrier drop. The integrated span's inherited Repeat lookup Arc-temporary distinction remains unchanged.
