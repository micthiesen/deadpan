# Root structural span admitted candidate

Scratch only. No actual repository writes, Git, Cargo, rustc, or native execution. Both candidates passed rustfmt parsing with edition 2024 and skip_children=true. Parent owns compile/test execution and shared integration.

## Integration

1. Apply `audio_signal.patch` against the pinned original, preserving concurrent edits if its pin changed. It adds child `query` and replaces only the old `span` body with the Unmetered wrapper. The full candidate file is a convenience snapshot, not a blanket replacement for later parent edits.
2. Add `audio_signal_query.rs` (also supplied as a new-file patch).
3. Apply the two narrow `storage-visibility.patch-fragment` changes in parent-owned shared files. Existing `audio::capture` is already visible within Plan. Only `hold` needs widened function visibility.
4. The actual structural Root collector can call `signal.span_admitted(sample, grid, stop_at_preserve, stop_at_bindings, &mut query_budget)`. Its result is `QueryResult<GuardedBound<AudioSignalSpan<'plan>, A::Issuer, A::Lease>, A>` and visibility is within Plan.
5. Outer `query_inner`, Root `audio_processing`, projected/source-voice/silence providers, Domain, host and Core zip changes remain with their owners.

## Behavior and accounting

The body is the original structural traversal with old canonical `spend` calls replaced one-for-one by `canonical`. Node visits, Sequence comparisons, bounded Repeat comparison limits/debits, lookup updates, Preserve selection/refusal, binding-before-child order, scalar arithmetic/error strings and final allocated interval/sample map remain literal. Root Stage selection has no invented `repeats.len()+1` canonical debit. No physical capture traversal substitutes for Root traversal.

Initial repeats use existing `Budget::repeats`; initial gap uses `Budget::gap`. Transparent retime/repeat paths use existing `Budget::grow` at actual pushes and `node`/`own_iteration` helpers for retained owning edges. Source uses `Budget::source`; Hold/gap Hold use existing storage helper. Stage uses `for_node_admitted`; binding uses actual `bound_at_query`, guarded Box preparation, and allocation-free `map`. Final definition and instance node clone at the original final construction site through existing identity helpers.

False mode follows the same traversal with ordinary clone/to_vec/push allocator backends. Helpers spend/reserve no additional work. The ordinary wrapper constructs a short-lived Unmetered QueryBudget over the caller's actual Budget and uses only the exact Unmetered GuardedBound extractor.

## Ownership

During traversal each vector/value is declared after its independent capacity/payload guards so error cleanup drops values first. Content remains GuardedBound, retaining Core payload/buffer lanes. All fallible final scalar calculations occur with content and earlier vectors still owned and guards live. Capacity guards merge while vectors and content remain named locals. No fallible operation separates constructing final Owned fields from passing them to `finish`.

`finish` immediately forms one named `Mapping` with content, remaining fields, then Plan memory. Its callback only assembles AudioSignalSpan; every identity copy, Vec allocation and scalar failure happened beforehand. Core pre/post-map failures retain fields under outside Plan memory while Core retains its own guards. The whole returned span then absorbs complete Plan memory through existing merge. No detached Core payload, external unguarded output mutation, generic unwrap, new Core API, mutable query exposure or metered `unmetered` call is introduced.

## Parent verification owed

- Compile both actual variants after integrating shared visibility changes.
- Compare all frozen OLD ordinary processing observations and lookup/work/error output, including 446 observations/33 parents with canonical body SHA `edf714032313470dd98537e69c363e07ed687e2791df8ebfa3e58daafcea0f5e`. Do not rewrite expected output.
- Through the eventual actual Root constructor test Stage, Bound including gap Bound, leaf Source, room-tone/reverse Hold, nested transparent retimes, repeated paths and retime/repeat Vec growth.
- Exercise work/reservation refusal and issuer rotation around initial clones, Stage, boxed Bound, vector replacement and final definition/instance. All live leases must reach zero on failure; callback work stays spent.
- Cross-check final owning layouts separately from peak actual requested Layouts. Discarded temporary metadata may conservatively retain charge until span/query drop. No heap/RSS peak equality claim.

## Explicit seam limitation

Repeat lookup remains original `ExactRepeatLayout::locate_bounded`, which internally clones returned play Arc-backed identity handles before Plan receives them. Like existing admitted capture, this port calls `own_iteration` immediately after the original canonical comparison debit, before retaining/moving that iteration into result or gap. It does not claim to pre-admit Core lookup internal temporary child/gap-child handle clones or change Core lookup APIs. This is the inherited distinction between retained owning-edge accounting and allocation-free Arc clone temporaries, not a new allocation-after-inspection claim. Keep this distinction explicit in acceptance scope.

Parser checked only. No expected golden data changed.
