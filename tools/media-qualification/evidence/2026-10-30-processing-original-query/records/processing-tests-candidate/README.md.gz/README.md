# Processing constructor admission tests

Scratch-only new test module. No actual repo writes, Cargo/rustc/native execution, Git, production hooks, fixture constructors, accounting framework, expected normalization or golden regeneration. Rustfmt parsed/formatted the candidate. Parent owns integration and execution.

## Integration

Add `processing_query_admission_tests.rs` beside existing wide_gain_query_admission_tests.rs. Apply `module-declaration.patch` or append `module-declaration.rs.fragment` to that existing parent. The child reuses its actual private Policy<M>, PolicyState, Lease, Parent and imports through `use super::*`. This file does not shadow the parent admitted/normal helpers. Main/Scope parent helpers were byte identical at the recorded pin.

Run the module filter `audio_owners::wide_gain_query_admission_tests::processing_admission::` in each actual variant's Plan library runner. There are 11 tests. Run strict lint after compilation; only syntax/formatting was checked here. Pins include actual source/fixture inputs and candidate SHA256.

## Coverage

1. All 446 ordinary observations via the existing immutable producer matrix, then every false-mode admitted result/error with literal field/work equality, canonical=oldwork, additional=0, forwarded=false and zero policy spend/reserve activity. Typed frozen Document LimitExceeded errors remain explicit.
2. All 99 true full/crop/empty results across 33 independently checked Root/Domain parents, with descriptor and source-provenance equality before use. Every top-level field, every span field and complete Stage descriptor/history are compared. Top canonical=OLD work, total=canonical+actual additional=accepted policy spend, forwarded=true, live positive through carrier lifetime and zero after drop, including when policy goes away first.
3. Actual full-query exact NEW total work and exact requested-Layout peak for every parent; fresh total-1 and peak-1 refuse and release all leases. Total-1 accepts only a work-limit typed error, including Core Document LimitExceeded. Spent work never refunds.
4. Actual invalid limits/ranges retain scalar error priority with zero admission callbacks. Positive span caps fail after earlier actual spans and release their guards.
5. Focused callback refusal, exact accepted-prefix cancellation, and issuer rotation at every spend/reservation for five-leaf Root growth, mixed Stage/Bound Root, two-Core Root and two-Core Domain. The observer delegates all ledger/lease accounting to existing Policy; it only records callback layouts/units. Refusal spend equals exact baseline accepted prefix; reservation refusal preserves exact spend before that reservation. Rotation keeps the old Rc ledger for both-old-and-current-zero assertions.
6. Empty queries independently calculate Arc identity layouts from std::alloc::Layout and require exactly project/revision charge, zero Vec capacity and no canonical work. Root's actual None definition inspection adds one work unit without storage; Domain retains four header units, Root five.
7. The five-span Root independently expects 8-element SignalSpan input capacity and 5-element ProcessingSpan output capacity. The final requested output layout must match its std Layout; observed post-allocation charge minus final retained charge must equal exactly 8 SignalSpan slots. Outer growth at capacities 1/2/4/8 requires old buffer plus measured prior/current span payloads to remain live. These expectations do not derive all sizes/overlap solely from callback totals.
8. Separate final-storage measurement bills its actual observer work, including a failed inspection, without changing constructor work or live admission. It checks final bytes <= retained charge and explicitly makes no peak claim.
9. Two simultaneous carriers require aggregate retained+solo-peak room; one-short second construction fails while the first remains valid/charged; drop returns room for a fresh query.

## Bounded unresolved receipt comparison

The metered metadata test explicitly names its pending Bound receipt comparison. It compares every Bound object key, array position and leaf exactly except these two exact relative paths beneath a Bound value:

- `/resolved/work`
- `/resolved/lattice/work`

Those numeric values are currently asserted nondecreasing, not normalized into expected data or claimed equal to independently reconstructed receipts. All non-Bound results retain full deep equality apart from separately reconciled top work. Parent is integrating the separate paired ordinary/admitted Core witness at exact actual bound inputs. It must replace this bounded deferral with that witness before claiming complete nested work equivalence. Do not equate lattice delta to total Core additional work: environment fees and post-lattice resume/reanchor fees can occur elsewhere.

Frozen body remains SHA256 `edf714032313470dd98537e69c363e07ed687e2791df8ebfa3e58daafcea0f5e`. The report/pins give exact default-result counts and deferred fields. No broad work-key stripping occurs.

## Explicit gaps

No legal finite fixture reaches allocation Layout overflow, so that branch is untested rather than fabricated with invalid Vec metadata. No allocator/RSS/heap peak equality is claimed beyond actual requested Layout accounting. Scalar conversion grid/map failure fixtures are not invented here; these real frozen plans successfully convert. Native/host residency, policy finish witness reuse and paired nested Core work reconstruction remain with their respective owners. No production code is changed by this candidate.
