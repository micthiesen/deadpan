# Exact nested Bound work receipts

Read-only source research and scratch candidate, 2026-10-30. Neither actual repository was modified. No Cargo, native tests, producer, new expected snapshot or production observer API was used. The current source/input hashes and scratch files are in `nested-work-receipts-candidate/pins.json`.

## Actual failure and scopes

`witness-scoped-all-four.stderr` fails the complete private first-witness comparison for `hidden_resumed_actual_capture_domain`. Its returned Bound has `resolved.work = 13` and `resolved.lattice.work = 12`; the frozen ordinary values are 8 and 7. The failure does not justify ignoring either field.

The two fields have different scopes. Core `AudioPlacementTemplate::resolve_with_build` in `audio_binding.rs` records a `before = work.used()` at entry and assigns `ResolvedAudioPlacement.work = work.used() - before`. `AudioBindingState::resolve_binding_build` performs the outer resolver prefix, resolves the main lattice, handles resume phase terms/reanchors, then assigns `ResolvedAudioBinding.work = work.used()`. `Build::fork` shares the actual raw/additional counters. The existing Core `lattice_work_is_local_category_delta_after_real_outer_prefix` test checks these scopes against actual local total/additional deltas after a real prefix.

`Build::additional` advances the raw and additional counters together. `Build::spend` advances canonical work. Child receipts enter through `account_child` with their own canonical/additional distinction. Neither `resolve_binding_build` nor `resolve_with_build` has an accounting-mode branch; the same actual resolver and projection bodies run in both modes. The METERED branches are confined to the shared admission helpers, where the additional operations are explicitly categorized.

The existing Plan `capture_baseline::core_receipt` at `audio_bound_query.rs::bound_at_query` observes the actual successful resolved/lattice scalar values and the whole linear Core receipt before `budget.account_core`. It proves whole resolved canonical/additional work. By itself it does not prove an arbitrary main-lattice added-work category: `environment.validate_build` may incur ScratchSet fees before the main lattice, and resume/reanchor placement resolutions may incur fees after it.

## Preferred narrow witness

Add only a cfg(test) Plan call at the existing successful Core boundary, before the linear receipt moves into account_core. A helper in the existing test-only capture_baseline module activates only for an explicit active case whose phase is `admitted_processing_query`. Inactive calls return before serialization or another resolver call. Existing producer phases and frozen observations remain unchanged.

When active, record:

- The actual owner, Node/Gap choice, complete borrowed environment and maximum allowance.
- The complete actual OwnedAudioBinding input and admitted ResolvedAudioBinding value.
- The actual linear receipt's total, canonical, additional and forwarding flag.
- The literal result of a separate ordinary Core resolve_in/resolve_gap_in using exactly those borrowed inputs and the same pre-account allowance.
- Actual empty-environment/journal scope predicates described below.

The ordinary probe is callback-free Unmetered Core work. It does not borrow or mutate the actual admission policy, controller or ReadWork ledger, does not issue source I/O, and does not call back into Plan. It allocates ordinary test observation storage only while explicitly tracing. It must not feed a cache or write expected output. Ordinary failure remains a recorded typed failure and fails the comparison rather than silently disappearing.

Use the existing observe_case/Session/CaseScope RAII to start and finish tracing around just the first processing factory. Their Drop implementations clear the TLS on unwind. Finish-policy work runs after that trace has ended, so its fallback queries cannot be mistaken for first-query work.

## Exact comparison contract

The scratch correction binds each returned serialized Bound to one unused observation by actual owner, current instance, gap kind and complete admitted resolved value. A full-value match includes both scalar work fields. Every returned Bound must match; every paired observation must be used. An extra event means the actual walker built a discarded/intermediate Bound and requires a named explanation/phase distinction, not permission to ignore unused observations.

For each pair require:

1. The observed ordinary FULL resolved value equals the corresponding frozen resolved object literally, including its resolved and lattice work. This catches canonical drift and any other changed Core fact.
2. Actual linear receipt units equal the observed admitted resolved.work; canonical equals the independently observed ordinary resolved.work; canonical plus additional equals units, and their actual delta equals additional.
3. Every Core field besides exactly resolved.work and resolved.lattice.work is equal between the admitted and ordinary values.
4. Replace only those two exact scalar paths in the local comparison copy with the independently observed ordinary values. The frozen expectation is never changed, and no delta is derived by subtracting expected values. The root query work is compared through the carrier's actual canonical/additional receipt as before.
5. Compare the entire resulting processing query against the frozen full query, keeping headers, lookup, allocation, private Stage/Bound history and all other fields literal.

The main-lattice difference is an observed same-input extra scalar count. It is not a general new local-category receipt. The existing Core local-category test remains independent evidence for the helper's counting rules.

## Stronger finite-corpus check

All bindings serialized by the existing 26-case Domain corpus have no phase terms or reanchors; their template arguments/births are also empty. The new helper additionally records the ACTUAL environment Repeat/exclusion lengths rather than inferring them from the frozen document. When both are zero and the actual binding has no resume phase terms/reanchors, the whole additional receipt lies inside the main lattice:

- Empty environment validation runs no ScratchSet insert/search/growth and incurs no additional work.
- The outer `resolve_binding_build` prefix is one canonical spend.
- All allocation/identity/projection work is inside the first main-lattice resolution.
- Resume constants are arithmetic only; with no phase terms or reanchors, no later resolver runs.
- Final lease merging and validation do not spend work.

For this explicitly checked subset, require the actual admitted lattice work minus the paired ordinary lattice work to equal the ACTUAL whole additional receipt as well. This rejects an invented lattice +1 even if the outer receipt is unchanged. The scratch test correction fails closed if an input violates these scope predicates. Such a case needs a real local-counter witness or a separately justified accounting scope; it is not normalized with the whole receipt.

For the reported hidden binding, the five added units are source-identifiable inside the main lattice: one clock-copy operation; one empty Repeat-vector array operation; one physical NodeId ownership operation; and two projection-instance ownership operations (NodeId plus empty Repeat-vector array). The recorded whole receipt must independently confirm five. This explains 13 versus 8 and 12 versus 7 without changing the old canonical counts.

The scratch counterfactual test uses a real paired observation, then separately corrupts the admitted/recorded lattice count by one and the paired ordinary canonical count by one. Both comparisons must fail. It does not regenerate expected data. All scratch Rust fragments parse under Rustfmt; actual type-checking and execution remain the parent's work.

## Host accounting risk, separate from this test fix

`AudioBound::work()` in `audio_bound.rs` exposes resolved.work, which now includes admitted Core fees for the new constructor path. Once the parent processing carrier has forwarded its whole query work, adding bound.work() again would double bill an already included constructor debit. That would be a host integration bug; changing nested serialized fields in a test cannot fix it.

The inspected current StageAudio Bound dispatches at `stages.rs` (Root and signal processing), read_bound and read_bound_at do not call bound.work() or debit it. read_bound_at checks current control/depth/Plan/range, maps the retained operand and performs legitimate fresh recursive queries. A scoped search found no current host bound.work() consumer, so an actual double debit is not established. `input.work()` on AudioOwnerInput/AudioOwnerRetainedInput is a different product and must not be conflated with AudioBound by name alone. Parent integration should keep a named live Bound case in its actual work-phase ledger and confirm query forwarding once, with later fresh recursive work accounted separately.

The source-proven rule is to remove only the host's first-processing-query debit when the actual admitted constructor forwards that exact query. Do not zero bound.work, rewrite canonical weights, refund work, increase caps or suppress later genuine recursive planning.
