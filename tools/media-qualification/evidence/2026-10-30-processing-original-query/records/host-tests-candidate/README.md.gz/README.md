# Processing host tests and existing assertion adaptations

Scratch only. No actual repository/test writes, Cargo/rustc/native execution, Git, expected-file generation, production hooks, cap raises or error broadening. Rustfmt parsed/formatted candidates. Parent owns compile, native WAV execution and strict lint.

## Integration and ownership

`all-host-tests.patch` contains four existing-file patches and three new test files. Per-file patches and whole scratch candidates are supplied too. Apply against recorded pins, preserving concurrent parent/worker changes. Existing parent declarations are included in those patches:

- original_request/tests.rs -> new processing_admission_tests.rs, four tests.
- original_request/policy_reuse_tests.rs -> new processing_policy_admission_tests.rs, one test.
- shared_eq/flattened_original_admission_tests.rs -> new processing_original_admission_tests.rs, four tests. This new child intentionally reuses the parent private flattened_context and its imported cached_prediction_baseline fixture/Graph helpers.

Actual Main/Scope inputs for all four existing test files were byte identical at initial capture. Pins identify those sources, actual request/trace APIs and all candidates. No other owner's authored/cached fee oracle, native pressure fixture or production file is edited.

## Existing tests adapted

original_request/tests.rs now compares all processing headers, range, full spans/history and lookup explicitly. It omits only the top processing work total, alongside existing top flat work omission. New processing_work/assert_processing_cost helpers independently prove old canonical equality, forwarded mode, total=canonical+additional, and actual query.work equality. Main WAV fixtures contain no Bound, so their full spans compare literally, including complete Stage descriptors.

The existing preparation work assertions add actual processing additional units to actual flat units. Consuming same-issuer reads get exactly two new comparison units. Exact consuming allowance is two; one-short leaves one, spends the flat comparison, then refuses processing before source I/O. Cancellation/deadline do not spend either comparison, while depth and fresh-source rejection spend both. The exact preparation/final-fade failure test preserves its original final error and completed-query accounting, now including real processing constructor total. No allowance/cap is raised.

The five existing policy_reuse_tests bodies remain unchanged in separately named inner functions, called under explicit with_legacy_processing_queries from the same original test names. This isolates the earlier old-processing policy-reuse savings and its old exact/failure boundaries. It does not change default production/test mode. A new actual admitted Bound Domain WAV test separately covers the default path.

Existing flattened lifecycle assertions now describe aggregate prepared metadata where they actually observe aggregate ReadWork frames. Its old failed-ordinary-processing test is explicitly isolated with legacy processing; the new default test separately proves real failed processing partial work. Foreign flat rejection still bills one comparison and remains unchanged. The aggregate reservation test name now names flat and processing.

## Nine new tests

1. Processing-only real WAV source boundary: legacy flat + actual admitted processing isolates positive processing frames. Checks completed constructor bill exactly once, canonical/additional/forwarded facts, actual trace units, immutable source spans against ordinary output, zero source access during preparation, positive lease at source callback, zero before returned PCM, zero after unused drop or SourceUnavailable, and exact one processing issuer fee in this mode.
2. Processing-only foreign ledger: with legacy flat, genuine processing issuer refusal bills exactly one comparison and releases its original ledger charge before any source/preflight/prepared-stage work. Both original and foreign ledgers reach zero.
3. Aggregate room: independent flat-only, processing-only and default preparations must retain exactly additive real frame charges. Required reserve(1,1) refuses one frame below both metadata charges plus its known 3-frame PCM requirement. Dropping only the processing carrier frees exactly its measured share, allowing PCM while flat remains charged; later drop reaches zero.
4. Default failed processing: allowance equals completed flat plus completed actual processing total minus one. The actual processing scope records failed=1, completed=0, accepted/partial=processing total-1. The real global work reaches its existing cap without refund, both metadata leases release and no source I/O occurs. Error remains the precise local structural-work refusal for this unbound WAV fixture.
5. Default Bound Domain: uses the existing Source/Unrelated binding fixture and current sealed policy reuse. Compares canonical processing work to legacy processing, additional units separately, immutable outer span fields, policy/fades, exact preparation work delta, actual WAV bits/masks/dependencies/depth and fresh source calls. The one additional consuming issuer comparison is explicit. Complete private Bound history/counter equivalence remains Plan's independent paired constructor proof; this host test does not recursively normalize or strip work.
6. Processing-only actual policy_population callback: legacy flat leaves only processing charge in ReadWork; callback observes its unchanged positive charge, then actual numeric WAV read releases it before live returned PCM. Existing prediction verification and exact output contribution logic execute.
7. Processing-only late cache hit: prepared processing lease drops unused, cached Arc identity stays equal, source is re-admitted and published cache identity remains stable.
8. Processing-only foreign prepared late hit: actual processing issuer rejects before source/cache mutation, bills exactly one comparison and releases both ledgers. Foreign work is declared before Graph to preserve the real borrowed ledger lifetime.
9. Default early warm Probe: cold read executes both actual constructors; warm read changes neither complete flat nor processing trace. Queries phase work/calls stay zero, OriginalRead work stays zero, Probe and fresh source admission remain live, PCM/policy output is exact, and no query charge survives.

All observers delegate accounting to real ReadWork/sound_context Admission. No replacement policy or synthetic metadata charge is used. The only source wrapper checks the actual ledger at the existing provider boundary and delegates to the same verified WAV Provider.

## Suggested targeted filters

- `original_request::tests::` for adapted existing tests, existing flat tests and new source/Bound tests.
- `processing_admission::` for all three newly declared child modules (nine tests).
- `processing_only_` and `warm_probe_constructs_neither_flattened_nor_processing_query` for focused Graph/policy lifecycle checks.
- Existing `policy_reuse` filter proves isolated old policy savings still holds; default admitted Bound proof is its new child.

Then run the appropriate full Audio libraries and lint in both actual variants after parent/other-worker fixture/oracle adaptations. No execution claim is made here.

## Explicit boundaries

Host Bound private receipt normalization is not invented here; paired Plan evidence owns it. Full legacy authored/cached oracle wrappers and product fee comparison helpers remain with their assigned worker. Native gain/streaming pressure fixture changes remain with parent. Tests use real finite WAV fixtures and make no heap/RSS peak claim or unreachable Layout-overflow claim.
