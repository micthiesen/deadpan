from pathlib import Path
out=Path('/tmp/deadpan-processing-query-admission-2026-10-30/host-tests-candidate')
base=Path('/Users/michael/Code/deadpan/crates/deadpan-audio/src')
paths=['original_request/tests.rs','original_request/policy_reuse_tests.rs','original_request/flattened_admission_tests.rs','shared_eq/flattened_original_admission_tests.rs']
for f in paths:
 p=out/f;p.parent.mkdir(parents=True,exist_ok=True)
 text=(base/f).read_text()
 (out/(f+'.before')).write_text(text)
 p.write_text(text)
p=out/'original_request/tests.rs'
s=p.read_text()
s=s.replace('''/// Compare every query field except flattened work, whose canonical and
/// allocation-site units are checked independently below.''','''/// Compare every query field except the two top-level constructor work totals.
/// Canonical and additional units are reconciled separately below.''')
s=s.replace('    assert_eq!(actual.processing, expected.processing);','''    assert_eq!(actual.processing.project_id, expected.processing.project_id);
    assert_eq!(actual.processing.revision_id, expected.processing.revision_id);
    assert_eq!(actual.processing.samples, expected.processing.samples);
    assert_eq!(actual.processing.spans, expected.processing.spans);
    assert_eq!(actual.processing.lookup, expected.processing.lookup);''',1)
anchor='fn same_blocks(actual: &ReadBlock, expected: &ReadBlock) {'
helper='''fn processing_work(request: &PreparedOriginalRequest<'_, '_, '_>) -> (usize, usize) {
    match &request.queries.processing {
        Processing::Admitted { query, .. } => {
            assert!(query.was_forwarded());
            assert_eq!(query.work(), query.canonical_units().checked_add(query.additional_units()).unwrap());
            assert_eq!(request.queries().processing.work, query.work());
            (query.canonical_units(), query.additional_units())
        }
        Processing::Legacy(query) => (query.work, 0),
    }
}

fn assert_processing_cost(
    request: &PreparedOriginalRequest<'_, '_, '_>,
    ordinary: &AudioProcessingQuery<'_>,
) -> usize {
    let (canonical, additional) = processing_work(request);
    assert_eq!(canonical, ordinary.work);
    assert!(additional > 0, "this default path must admit actual processing metadata");
    additional
}

'''
assert s.count(anchor)==1;s=s.replace(anchor,helper+anchor,1)
s=s.replace('let additional = assert_flattened_cost(&request, &expected.flattened);','''let additional = assert_flattened_cost(&request, &expected.flattened)
                    + assert_processing_cost(&request, &expected.processing);''',1)
s=s.replace('let additional = assert_flattened_cost(&reference, &ordinary.flattened);','''let additional = assert_flattened_cost(&reference, &ordinary.flattened)
            + assert_processing_cost(&reference, &ordinary.processing);''',1)
s=s.replace('expected_work.borrow().plan_work + additional + 1,','expected_work.borrow().plan_work + additional + 2,',1)
s=s.replace('"the consuming read bills its actual issuer comparison"','"the consuming read bills both actual issuer comparisons"',1)
s=s.replace('work.borrow_mut().plan_work = MAX_PLAN_WORK_PER_READ - 1;','work.borrow_mut().plan_work = MAX_PLAN_WORK_PER_READ - 2;',1)
s=s.replace('plan_work: MAX_PLAN_WORK_PER_READ - preparation_work - 1,','plan_work: MAX_PLAN_WORK_PER_READ - preparation_work - 2,',1)
s=s.replace('short_work.borrow_mut().plan_work = MAX_PLAN_WORK_PER_READ;','short_work.borrow_mut().plan_work = MAX_PLAN_WORK_PER_READ - 1;',1)
s=s.replace('spent + usize::from(failure == 2),','spent + 2 * usize::from(failure == 2),',1)
s=s.replace('"only a live control can bill the issuer comparison before depth rejection"','"only a live control bills both issuer comparisons before depth rejection"',1)
s=s.replace('''            spent + 1,
            "fresh source rejection follows the actual issuer comparison"''','''            spent + 2,
            "fresh source rejection follows both actual issuer comparisons"''',1)
s=s.replace('''                assert_eq!(flattened_work(&request), flattened_work(&reference));''','''                assert_eq!(flattened_work(&request), flattened_work(&reference));
                assert_eq!(processing_work(&request), processing_work(&reference));''',1)
s+='''\n#[path = "processing_admission_tests.rs"]\nmod processing_admission;\n'''
p.write_text(s)
p=out/'original_request/policy_reuse_tests.rs'
s=p.read_text()
names=['binding_domain_reuses_one_walk_without_changing_queries_or_pcm','exposed_stage_fallback_preserves_exact_and_one_short_global_budgets','failed_first_processing_query_keeps_old_partial_bill_and_error','root_preparation_with_bindings_keeps_the_original_query_and_work_path','eligible_domain_preparation_obeys_its_exact_new_cumulative_budget']
for name in names:
 anchor='#[test]\nfn '+name+'() {'
 assert s.count(anchor)==1,name
 s=s.replace(anchor,'#[test]\nfn '+name+'() {\n    with_legacy_processing_queries('+name+'_legacy_processing);\n}\n\nfn '+name+'_legacy_processing() {',1)
s=s.replace('use super::*;','''// These tests isolate the prior policy-reuse change. Default admitted processing
// has separate actual ReadWork lifecycle and receipt coverage.
use super::*;''',1)
p.write_text(s)
p=out/'original_request/flattened_admission_tests.rs'
s=p.read_text()
name='flattened_later_processing_failure_drops_earlier_flattened_lease_without_refunding_work'
anchor='#[test]\nfn '+name+'() {'
assert s.count(anchor)==1
s=s.replace(anchor,'#[test]\nfn '+name+'() {\n    with_legacy_processing_queries('+name+'_legacy_processing);\n}\n\nfn '+name+'_legacy_processing() {',1)
s=s.replace('actual numerical source admission must retain the flattened query lease','actual numerical source admission must retain both prepared query leases')
s=s.replace('returned PCM does not retain flattened metadata','returned PCM does not retain prepared query metadata')
s=s.replace('fn flattened_live_charge_reduces_actual_required_pcm_reservation_room()', 'fn flattened_and_processing_live_charge_reduces_actual_required_pcm_reservation_room()')
p.write_text(s)
p=out/'shared_eq/flattened_original_admission_tests.rs'
s=p.read_text()
s=s.replace("actual Original selection callback sees the request's live flattened charge","actual Original selection callback sees both prepared query leases")
s=s.replace('unused prepared flattened query and its lease die on the hit return','unused prepared query metadata and both leases die on the hit return')
s+='''\n#[path = "processing_original_admission_tests.rs"]\nmod processing_admission;\n'''
p.write_text(s)
