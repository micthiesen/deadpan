# Non-finite authored-gain fixture candidate

## Candidate

`gain.patch` changes only the body of `nonfinite_authored_output_rejects_after_admission_without_poisoning_inspection_or_budget` in a scratch copy of `tests/stages/gain.rs`.

The actual plan's Root flattened + processing metadata peak is measured with `super::flattened_metadata::root` over exactly `0..256`. The sufficient ceiling is `3 * 256` frames, matching the production authored-gain path's fixed three-frame reservation, plus that simultaneous Layout peak. The test asserts this exceeds the old 1024-frame ceiling.

The test now separates two outcomes:

1. At 1024 frames, a successful edge-faded inspection is followed by the known `Limit("resident PCM or stage cache")` authored-bus refusal. Provider calls are asserted unchanged; inspection after refusal must equal the pre-read inspection.
2. At the measured sufficient ceiling, edge-faded inspection succeeds, two authored-bus attempts each admit fresh source data and fail with `PreparationError::InvalidSamples`, and final inspection remains identical.

## Basis and limits

- Parent diagnostic receipt reported the old 1024 case as `Limit("resident PCM or stage cache")`, rather than `InvalidSamples`.
- The three-frame amount is the real authored-gain reservation already used by `read_authored_bus`; it is not an arbitrary cap increase.
- The fixture has no independent sounds/wet sends/EQ, so that fixed reservation is the applicable path. The dynamic metadata component is measured from its own plan/range.
- No Cargo or native checks were run for this candidate. Parent should run the single focused test. Confirm the 1024 edge-faded inspections fit and its pressure refusal occurs before provider I/O; confirm the measured ceiling reaches the real non-finite conversion twice.
