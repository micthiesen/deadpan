# Host eviction receipt review

Reviewed the current Scope source at /tmp/deadpan-query-groundwork-2026-10-26/scoped. No correctness finding in the requested trace/reconciliation change. This is read-only source review, not a test execution result. No Git, Cargo, native execution or repository writes.

## Debit placement and scope accounting

The sole host receipt hook in shared_eq/original_inputs.rs follows successful control.spend_plan_work(1) immediately within evict_original_input's real cache-entry scan. Rejected work returns before the hook. A scan of a pinned entry is correctly counted even if no payload can be removed, because its unit was actually accepted. No work is debited or refunded by the hook itself.

ScopeGuard records the selected control's actual plan/cache totals and global accepted scan counters at entry. Exit observes both again; checked differences require monotonic counters, host units not exceeding accepted work, and no debit in the unselected lane. The successful Plan receipt must equal accepted delta minus host scan delta and must reconcile canonical + additional. Failure keeps that same nonhost accepted prefix in partial_work. accepted_work still stores the complete actual counter delta, and host_eviction_work stores only its independently observed scan component. Therefore accepted = canonical + additional + partial + host, while issuer validation remains separately observed outside constructor scopes.

No double charge occurs in this instrumentation: it records counters only. query_fees validates the full equality but returns additional + issuer, deliberately excluding host. Authored comparisons take the global host difference once, rather than summing duplicated global values or product-local host fields.

## OLD and paired comparison behavior

assert_ordinary_query_trace requires zero constructor depth and all product lane fields zero. It intentionally does not require all_host_eviction_work zero: ordinary queries can cause real host cache scans outside an admitted constructor. Treating that global receipt as zero would be false. compare_flattened_counter compares the two product snapshots' duplicated global arrays for equality, adds actual host - OLD host once to the sum of independently checked product additional/issuer fees, then checks all remaining controller/resource/cache facts literally.

compare_domain_policy_counter similarly uses processing fee difference plus one global host difference, minus the independently checked plan-lane canonical policy saving. It verifies the flattened and processing global snapshots agree on each side. reconcile_paired_flat_host_receipts first requires identical flattened fees and identical accepted-minus-host units, then permits only accepted_work, local host_eviction_work and the global host array to differ. Complete flattened trace equality after that retains canonical, additional, constructors, issuer counters and flags. The outer complete comparison retains resources and cache behavior. Certified/direct comparison still requires product trace snapshots literally equal.

Full OLD normalization removes only explicitly named instrumentation after checking ordinary product lanes. The unchanged OLD controller total comparison separately includes its actual historical host work. No host amount is invented from expected totals, and no unknown work field is stripped.

Nonzero partial_work still fails explicit OLD qualification. It is present in the conservation equation and never classified as host, set to zero or deducted from expected work. The host change does not justify relaxing that pending failed-construction branch. Imposed plan-work overrides retain the preexisting special comparison and require product snapshots unchanged across the refused operation.

## Why the global counter is sound for current callers

HOST_EVICTIONS is thread-local, not keyed by ledger. For the actual synchronous active constructor path, sound_context_admission::Admission captures one WorkControl and uses that same control for spend, reserve, StageAudio::make_room and evict_original_input. make_room does not call arbitrary user code or start an operation using another work ledger. The constructor closure cannot reborrow its mutably borrowed StageAudio to drive an unrelated host read. Current prepare_original_root constructs flattened and processing sequentially, dropping each ScopeGuard before the next product. cache_key_scopes stays on the same ledger for the complete measured constructor. This establishes same-ledger/same-lane accounting for these paths; it is not an API-wide promise about arbitrary test code interleaving unrelated ledgers inside a fabricated active scope.

The authored baseline resets traces per case and uses one ReadWork for its measured operation sequence. The new pressure test's two measurement controls are used sequentially before the actual trace reset. No measurement constructor or foreign ledger is active inside its measured constructor interval. A speculative keyed registry is unnecessary for these established synchronous callers.

## Forced-pressure test is meaningful

processing_eviction_trace_tests uses the existing checked WAV fixture and first publishes an actual cached Original payload through shared_original_input. It drops the caller Arc, checks exactly one cached payload remains, then limits residency and calls the actual prepare_original_root. Provider calls must remain unchanged, the actual payload cache must become empty, and the completed carrier must remain live until its explicit drop.

For each of flattened/processing pressure and plan/cache lanes, both constructors must complete once with zero partial work, clear invalid/nested/overflow flags, exactly one global accepted scan in the selected lane, and no opposite-lane accepted work. Only the intended product may report one local scan. Each product reconciles accepted work to canonical + additional + host, and the independent actual controller interval must equal both returned constructor totals plus returned ordinary policy/fades work plus exactly one host scan. This final equality prevents the test from passing through duplicated or missing host attribution.

The flat-pressure ceiling uses retained complete request storage plus the independently computed one-element SignalSpan input buffer as a concrete overlap bound for this explicitly checked one-span Source Root. Processing pressure admits the measured flattened retained amount alongside the existing payload, then lets the actual processing allocation force removal. Neither choice alone proves eviction or an exact general peak; the direct cache removal, local product selection, callback totals and successful completion assertions supply that proof. A larger unexpected peak would fail completion rather than be silently normalized. The test makes no universal allocator-capacity claim.

The test is completed-constructor coverage. It does not prove rejected spend-after-pressure attribution by itself; the source's accepted-only hook and unchanged explicit partial qualification cover that narrow distinction without claiming an executed failure case.

## Verification limits

Inspected the four requested files plus actual WorkControl::spend_plan_work, Admission::reserve, make_room_for, prepare_original_root/prepare_flattened/prepare_processing_root, and baseline reset/control setup. Parent owns the live native compile and execution. No fixture, limit, production behavior or expected body was changed by this review.

## Source pins

- crates/deadpan-audio/src/original_request/flattened_work_trace.rs: 23d1bccd11652758c9cdd0a918b5f6ea3afc8aca3bce84dd75ce1560c674881e (8902 bytes)
- crates/deadpan-audio/src/shared_eq/original_inputs.rs: b029c29784b9ffc03cb84a8209eab68c3930a8fb86e2e1e87e83ff83956caba3 (23960 bytes)
- crates/deadpan-audio/src/authored_eq/tile_admission_tests.rs: bf79570e88beee40b6968349533d456a627fa9dc47c9327db49559dfff151532 (39059 bytes)
- crates/deadpan-audio/src/shared_eq/processing_eviction_trace_tests.rs: 9ff8e08792f6dbf5ea14c49f9db9d2bda0132d0dbeeb516e2de1f0406ece0cc1 (6656 bytes)
- crates/deadpan-audio/src/sound_context_admission.rs: f15f6bba0ab8b4382f46dcf1ef369688a231b23f7f78855f7c14573f6df6884d (6902 bytes)
- crates/deadpan-audio/src/stages.rs: 7fa81e333bf6cbfb777d807f3e52f498f415169775f0db0f7d2e552482509e77 (163164 bytes)
- crates/deadpan-audio/src/original_request.rs: ba7e11a30c6d57c4991270021419625a15afc8318c2e14685b6dec012fa18b17 (17035 bytes)
- crates/deadpan-audio/src/authored_eq/legacy_tile_baseline.rs: dd2c03858341b755c47c08b73c3273557f701ddd61cce5578e6fa2639d696794 (27832 bytes)

## Runtime correction supplied by parent

The initial static review missed the existing MAX_OUTPUT_FRAMES = 256 bound: the original 512-frame setup failed Range before reaching the tested property. Parent changed all four requests to 256 (plus a diagnostic message) and ran eviction2-scoped, whose supplied JSON records exit_code 0 and unchanged sources/binary; supplied stdout reports one test passed, exercising its four product/lane cases. I inspected that result artifact but did not execute the test. The accepted scan attribution reasoning above is unchanged, but the earlier source pins and unexecuted setup were not proof the original 512-frame test reached its assertions. Published source now contains the corrected request length.
