# Core guarded composition candidate

Scratch-only implementation: `admission.rs`, unified `admission.patch`, new `composition_tests.rs`, minimal `test-parent.patch` and exact input/candidate `pins.json`. Main and Scope admission source and test parent are byte-identical at the recorded baseline. Neither actual repository was edited. Git, Cargo and native tests were not run. Rustfmt parsed/formatted both candidate Rust files with child traversal disabled.

`validate_composition(&P)` is a read-only public check. Existing issuer and accounting-mode validation runs first. It then refuses an already committed charge transfer or an unconsumed work receipt. Failure preserves the value, guards, receipt and transfer state for a valid retry. A consumed receipt is the existing linear boundary; callers remain responsible for accounting it exactly once.

`zip_value(self, other, &mut P)` returns only another sealed AudioBindingValue containing `(T, U)`. There is no public constructor, owned extraction, mutable-value access or detached charge. It allocates no storage, reserves no Layout and spends no work. It does not mint a combined receipt. The existing map_value implementation and its trusted infallible, allocation-free callback contract are unchanged.

The implementation creates a private PendingComposition before any validation can fail. Its first field owns both values; the following four fields retain both independent payload and buffer lanes. The consumed source carriers retain only metadata needed for validation. This order matters even before the first merge: independently dropping two rejected source carriers would release the first carrier's guard before the second value.

Corresponding lane merges borrow both actual Option lease slots. A live source lease is never taken into a temporary before merge. When the destination slot is empty, the complete source lease simply moves behind the pending tuple. Pair validation captures the current policy issuer exactly once and compares both immutable input issuers and modes against that observation, then refuses either transferred state or pending receipt. This check runs before merging and after each lane, so rotation after the payload merge stops before the buffer merge; rotation after the buffer merge also fails with both values still preceding all charge slots. Tests count three issuer observations on complete success and exactly one more observation than the actual merge count on rotation failure. Successful construction moves the tuple and destination lanes into the ordinary value-first AudioBindingValue. Any remaining source lease objects are disarmed by the trusted merge contract and carry no resource charge.

Eleven new tests use the actual admission helpers:

- Real resolved binding plus a two-lane Build/Growing value, exact lane sums, preserved buffer address, unchanged policy work/reservation counters, exhausted work/residency budgets, and the unchanged map operation after zip.
- Two actual two-lane values, both merge callbacks and both value-drop markers before every live charge.
- Read-only pending-receipt refusal with a valid retry after linear receipt consumption.
- Either pending receipt, either transferred input or either foreign issuer refused before any merge, preserving all-value-before-live-charge destruction.
- Wrong policy mode and either mixed-mode input refused before callbacks.
- Issuer rotation after either real merge, exact callback stopping point, unchanged work/reservation counters and zero live charge after both values drop.
- Retry after wrong issuer/mode without consuming state.
- Empty first metered value receiving both right lanes without a merge callback.
- Empty Unmetered compatibility composition with no leases or new receipt.

The tests observe policy requests and lease ownership, not allocator traffic or process RSS. No panic-in-merge test was added: merge is explicitly trusted infallible/non-unwinding in this use. Existing lease guards and the tuple carrier still determine unwind order if another operation outside that contract unwinds. No speculative guard was added for internally impossible empty value slots; they retain the existing `unmoved binding value` invariant.

Parent verification remains required: integrate the candidate after OLD captures, type-check and run these tests in both actual hierarchies, run the existing admission suite and required package checks, and independently review the public API/Plan call sequence. Syntax formatting does not establish that the candidate compiles or that tests pass. The candidate does not implement Plan's growing collector or Root/Domain processing admission, and does not claim the whole processing product is complete.
