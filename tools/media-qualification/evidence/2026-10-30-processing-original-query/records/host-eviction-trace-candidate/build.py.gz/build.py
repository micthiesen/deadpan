from pathlib import Path
base=Path('/tmp/deadpan-query-groundwork-2026-10-26/scoped/crates/deadpan-audio/src')
out=Path('/tmp/deadpan-processing-query-admission-2026-10-30/host-eviction-trace-candidate')
for path in ['original_request/flattened_work_trace.rs','shared_eq/original_inputs.rs','authored_eq/tile_admission_tests.rs','shared_eq/processing_original_admission_tests.rs']:
 p=out/path;p.parent.mkdir(parents=True,exist_ok=True)
 s=(base/path).read_text()
 (out/(path+'.before')).write_text(s);p.write_text(s)
p=out/'original_request/flattened_work_trace.rs'
s=p.read_text()
s=s.replace('    partial_work: usize,','    partial_work: usize,\n    host_eviction_work: usize,',1)
s=s.replace('''    max_active_depth: u32,
    nested: bool,''','''    max_active_depth: u32,
    all_host_eviction_work: [usize; 2],
    nested: bool,''',1)
anchor='''thread_local! {
    static TRACE: Cell<[Snapshot; 2]> = Cell::new([Snapshot::default(); 2]);
}'''
new='''#[derive(Clone, Copy, Default)]
struct HostEvictions {
    units: [usize; 2],
    overflow: bool,
}

thread_local! {
    static TRACE: Cell<[Snapshot; 2]> = Cell::new([Snapshot::default(); 2]);
    static HOST_EVICTIONS: Cell<HostEvictions> = Cell::new(HostEvictions::default());
}

// Called only after the existing real eviction scan debit succeeds.
pub(in crate::stages) fn host_eviction_spent(control: WorkControl<'_>) {
    let lane = usize::from(control.work.borrow().cache_key_scopes > 0);
    HOST_EVICTIONS.with(|counter| {
        let mut state = counter.get();
        if let Some(next) = state.units[lane].checked_add(1) {
            state.units[lane] = next;
        } else {
            state.overflow = true;
        }
        counter.set(state);
    });
}'''
assert s.count(anchor)==1;s=s.replace(anchor,new,1)
s=s.replace('''        trace.set([Snapshot::default(); 2]);
    });
}''','''        trace.set([Snapshot::default(); 2]);
    });
    HOST_EVICTIONS.with(|counter| counter.set(HostEvictions::default()));
}''',1)
s=s.replace('''    TRACE.with(|trace| trace.get()[product.index()])
}''','''    let mut snapshot = TRACE.with(|trace| trace.get()[product.index()]);
    let host = HOST_EVICTIONS.with(Cell::get);
    snapshot.all_host_eviction_work = host.units;
    snapshot.overflow |= host.overflow;
    snapshot
}''',1)
s=s.replace('    before: [usize; 2],','    before: [usize; 2],\n    before_host_evictions: [usize; 2],',1)
s=s.replace('''            before,
            cache,''','''            before,
            before_host_evictions: HOST_EVICTIONS.with(|counter| counter.get().units),
            cache,''',1)
s=s.replace('''        drop(work);
        TRACE.with(|trace| {
            let mut slots = trace.get();
            let state = &mut slots[self.product.index()];''','''        drop(work);
        let host = HOST_EVICTIONS.with(Cell::get);
        TRACE.with(|trace| {
            let mut slots = trace.get();
            let state = &mut slots[self.product.index()];
            state.overflow |= host.overflow;''',1)
anchor='''            let deltas = deltas.map(|delta| delta.unwrap_or(0));
            let selected = usize::from(self.cache);
            state.invalid |= deltas[1 - selected] != 0;'''
new='''            let deltas = deltas.map(|delta| delta.unwrap_or(0));
            let host_deltas = std::array::from_fn::<_, 2, _>(|lane| {
                host.units[lane].checked_sub(self.before_host_evictions[lane])
            });
            if host_deltas.iter().any(Option::is_none) {
                state.invalid = true;
            }
            let host_deltas = host_deltas.map(|delta| delta.unwrap_or(0));
            let forwarded = std::array::from_fn::<_, 2, _>(|lane| {
                deltas[lane].checked_sub(host_deltas[lane])
            });
            if forwarded.iter().any(Option::is_none) {
                state.invalid = true;
            }
            let forwarded = forwarded.map(|units| units.unwrap_or(0));
            let selected = usize::from(self.cache);
            state.invalid |= deltas[1 - selected] != 0 || host_deltas[1 - selected] != 0;'''
assert s.count(anchor)==1;s=s.replace(anchor,new,1)
s=s.replace('|| deltas[selected] != total;','|| forwarded[selected] != total;',1)
s=s.replace('''                add(&mut lane.accepted_work, accepted, &mut state.overflow);''','''                add(&mut lane.accepted_work, accepted, &mut state.overflow);
                add(&mut lane.host_eviction_work, host_deltas[index], &mut state.overflow);''',1)
s=s.replace('add(&mut lane.partial_work, accepted, &mut state.overflow);','add(&mut lane.partial_work, forwarded[index], &mut state.overflow);',1)
p.write_text(s)
p=out/'shared_eq/original_inputs.rs'
s=p.read_text()
a=s.index("    pub(in crate::stages) fn evict_original_input(")
b=s.index('\n    pub(super) fn shared_original_input',a)
block=s[a:b]
old='''            control.spend_plan_work(1)?;
            if Arc::strong_count(&cached.block) == 1 {'''
new='''            control.spend_plan_work(1)?;
            #[cfg(test)]
            original_request::flattened_work_trace::host_eviction_spent(control);
            if Arc::strong_count(&cached.block) == 1 {'''
assert block.count(old)==1
s=s[:a]+block.replace(old,new,1)+s[b:]
p.write_text(s)
p=out/'authored_eq/tile_admission_tests.rs'
s=p.read_text()
s=s.replace('''                .checked_add(number(lane, "partial_work"))
                .unwrap(),''','''                .checked_add(number(lane, "partial_work"))
                .unwrap()
                .checked_add(number(lane, "host_eviction_work"))
                .unwrap(),''',1)
anchor='fn assert_ordinary_query_trace(trace: &Value, product: &str) {'
helper='''fn host_eviction_receipt(trace: &Value) -> [u64; 2] {
    let lanes = trace["all_host_eviction_work"].as_array().unwrap();
    assert_eq!(lanes.len(), 2);
    [lanes[0].as_u64().unwrap(), lanes[1].as_u64().unwrap()]
}

'''
assert s.count(anchor)==1;s=s.replace(anchor,helper+anchor,1)
s=s.replace('''    let mut fees = [0_u64; 2];
    for (field, product) in [''','''    let mut fees = [0_u64; 2];
    let mut paired_host = None;
    for (field, product) in [''',1)
s=s.replace('''        let product_fees = query_fees(&trace, product);
        for lane in 0..2 {''','''        let product_fees = query_fees(&trace, product);
        let host = (host_eviction_receipt(&trace), host_eviction_receipt(&old_trace));
        if let Some(previous) = paired_host {
            assert_eq!(host, previous, "both product snapshots share one actual host debit receipt");
        }
        paired_host = Some(host);
        for lane in 0..2 {''',1)
s=s.replace('''        let additional = if imposed && index == 0 {
            0
        } else {
            fees[index]
        };
        assert_eq!(
            number(actual, field),
            number(&ordinary, field).checked_add(additional).unwrap(),
            "only independently observed flattened/processing additional and issuer receipts differ: {field}"
        );''','''        let (host, old_host) = paired_host.expect("both actual product receipts");
        let additional = if imposed && index == 0 {
            0
        } else {
            i128::from(fees[index]) + i128::from(host[index]) - i128::from(old_host[index])
        };
        assert_eq!(
            i128::from(number(actual, field)),
            i128::from(number(&ordinary, field)) + additional,
            "only independently observed query fees and paired actual host eviction debits differ: {field}"
        );''',1)
old='''        let difference = i128::from(fees[lane]) - i128::from(old_fees[lane]);'''
new='''        let host = host_eviction_receipt(&processing);
        let old_host = host_eviction_receipt(&old_processing);
        assert_eq!(host_eviction_receipt(&actual["flattened_work_trace"]), host);
        assert_eq!(host_eviction_receipt(&old["flattened_work_trace"]), old_host);
        let difference = i128::from(fees[lane]) - i128::from(old_fees[lane])
            + i128::from(host[lane]) - i128::from(old_host[lane]);'''
assert s.count(old)==1;s=s.replace(old,new,1)
anchor='''    assert_eq!(
        actual, &old,
        "all other controller/resource/cache fields remain literal"
    );'''
new='''    actual["flattened_work_trace"]["all_host_eviction_work"] =
        old["flattened_work_trace"]["all_host_eviction_work"].clone();
'''+anchor
assert s.count(anchor)==1;s=s.replace(anchor,new,1)
p.write_text(s)
