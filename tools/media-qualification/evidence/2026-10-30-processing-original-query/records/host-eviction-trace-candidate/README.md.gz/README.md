# Explicit host eviction work in constructor traces

Scratch-only candidate, parser checked with rustfmt. No actual repo/Cargo/rustc/native/Git execution or expected-data generation. Apply per-file patches or all.patch against recorded pins; Main/Scope inputs matched. Parent owns runtime and strict lint.

The only production-file insertion is cfg(test), immediately AFTER evict_original_input's actual accepted spend_plan_work(1). Rejected spends record nothing. This existing debit is unchanged. No new production fees, callbacks, caps, lease changes or guard instrumentation are introduced.

The shared trace records accepted host eviction units in a tiny plan/cache TLS counter. ScopeGuard snapshots this explicit event counter before/after each actual constructor. Each lane now conserves:

`accepted_work = canonical_units + additional_units + partial_work + host_eviction_work`

Completed constructor validation compares its Plan receipt with ledger units AFTER excluding explicitly recorded host eviction events. Failed partial_work likewise remains actual accepted Plan units, while accepted_work retains the complete real ledger delta. Snapshots expose all_host_eviction_work from the one global counter, including OLD ordinary paths outside constructor scopes. Both products expose the same global receipt and it is counted only once in paired comparisons. Overflow/negative subtraction/wrong lane remain invalid evidence; no inferred residual is labeled host work.

authored query_fees validates the new conservation identity but continues returning Plan additional plus issuer fees only. Full OLD/current comparison separately adds signed current-minus-OLD global eviction receipts once. Domain-policy comparison does the same, and explicitly reconciles only flat host receipt fields after proving paired flat non-host units/fees/counters equal. Literal cache, residency, provider, PCM, policy and error fields still compare unchanged. Certified capture comparisons remain strict; new resource differences there still need separate qualification. Partial Plan refusals retain the existing separate-qualification assertion, rather than being normalized away.

New shared_eq/processing_eviction_trace_tests.rs is a child of current processing_original_admission_tests.rs and reuses real verified WAV fixture/Graph helpers. It populates one real evictable cached Original block, forces a completing flat or processing constructor to evict that exact block, and covers both plan/cache work lanes. It requires exactly one real host scan receipt, correct selected product attribution, unchanged canonical/additional receipt totals, accepted=Plan+host, constructor success, no source access during preparation, exact total host bill, zero released metadata frames and actual cache removal. Peak setup uses the known one-span Root input/output Vec overlap; no synthetic cache payload, mocked debit or new fixture is created.

Filter: `completed_original_constructors_separate_real_eviction_work_in_both_products_and_lanes`. Run it plus authored tile admission tests and Original request lifecycle filters before claiming the trace fix verified. This candidate has no execution claim.

The original static lifecycle review is at ../review-host-current.md. Apart from this explicit trace categorization issue, that bounded review found no material lifetime, issuer, successful double-bill or work-refund defect. Its input pins and static-only limitations remain in the report.
