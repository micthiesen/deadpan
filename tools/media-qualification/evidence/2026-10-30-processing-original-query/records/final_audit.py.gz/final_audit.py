from pathlib import Path
from datetime import datetime
import hashlib,json,re
s=Path(__file__).resolve().parent
roots={'main':Path('/Users/michael/Code/deadpan'),'scoped':Path('/tmp/deadpan-query-groundwork-2026-10-26/scoped')}
sha=lambda b:hashlib.sha256(b).hexdigest()
negative={name:101 for name in [
 'composition-scoped-clippy','eviction-scoped-lib','host-scoped-lib','host-tests-scoped-lib',
 'nonfinite-scoped-diagnostic','pressure-diagnostic-scoped','processing-scoped-stages',
 'witness-scoped-all-four','witness-scoped-live-diagnostic','witness-scoped-live',
 'processing-fresh-split']}
receipts=[];intervals=[]
for p in sorted(s.glob('*.json')):
 row=json.loads(p.read_text())
 if not isinstance(row,dict)or'command'not in row or'started_at'not in row:continue
 assert row.get('exit_code')==negative.get(p.stem,0),(p.stem,row.get('exit_code'))
 assert row['sources_unchanged']and row['binaries_unchanged'],p.stem
 for path,pin in row['streams'].items():
  b=Path(path).read_bytes()
  assert len(b)==pin['bytes']and sha(b)==pin['sha256'],path
 receipts.append({'label':p.stem,'exit_code':row['exit_code'],'seconds':row['seconds'],'source_inputs':len(row['source_before']),'sha256':sha(p.read_bytes())})
 if row['binary_before']and'-audio-'in row['command'][0]:
  intervals.append((datetime.fromisoformat(row['started_at']),datetime.fromisoformat(row['finished_at']),p.stem))
for a,b in zip(sorted(intervals),sorted(intervals)[1:]):
 assert a[1]<=b[0],('native overlap',a[2],b[2])
paths=json.loads((s/'published-source-paths.json').read_text())
assert len(paths)==48
assert set((s/'index-source-paths.txt').read_text().splitlines())==set(paths)
index=json.loads((s/'index-source-equality.json').read_text())
assert len(index)==48 and all(r['scoped_index_equal']for r in index)
assert {r['path']for r in index if not r['main_equal']}=={
 'crates/deadpan-audio/src/shared_eq/cached_prediction_baseline.rs',
 'crates/deadpan-audio/src/shared_eq/original_inputs_tests.rs',
 'crates/deadpan-plan/src/plan.rs'}
correction=json.loads((s/'post-native-doc-correction-proof.json').read_text())
for variant,root in roots.items():
 row=correction[variant];spec=row['only_change']
 after=(root/spec['path']).read_text()
 assert after.startswith(spec['new'])
 before=after.replace(spec['new'],spec['old'],1)
 assert sha(before.encode())==row['before_sha256']
 assert sha(after.encode())==row['after_sha256']
 runtime=json.loads((s/(variant+'-runtime-source-pins.json')).read_text())
 final=json.loads((s/(variant+'-final-source-pins.json')).read_text())
 assert len(runtime)==47 and all(final[name]==pin for name,pin in runtime.items())
preserved={}
for variant,root in roots.items():
 pins=json.loads((s/(variant+'-final-source-pins.json')).read_text())
 assert set(pins)==set(paths)
 for name,pin in pins.items():
  b=(root/name).read_bytes()
  assert len(b)==pin['bytes']and sha(b)==pin['sha256'],(variant,name)
 initial=json.loads((s/(variant+'-initial-authority.json')).read_text())
 others={name:pin for name,pin in initial.items()if name not in paths}
 for name,pin in others.items():assert sha((root/name).read_bytes())==pin['sha256'],(variant,name)
 preserved[variant]=len(others)
assert preserved=={'main':2738,'scoped':2410}
baseline=json.loads((s/'scoped-baseline-head-equality.json').read_text())
assert len(baseline)==48 and sum(r['existing']for r in baseline)==33
assert all(r['scoped_initial_matches_HEAD']for r in baseline)
goldens=json.loads((s/'immutable-oracle-pins.json').read_text())
assert len(goldens)==15
for row in goldens:
 for root in roots.values():assert sha((root/row['path']).read_bytes())==row['sha256'],row['path']
expected={'composition-main-core':(827,0),'composition-scoped-core':(802,0),
 'processing-final-main-plan-deadpan-plan':(229,11),'processing-final-scoped-plan-deadpan-plan':(216,11),
 'processing-final-main-audio':(408,6),'processing-final-scoped-audio':(402,6),
 'processing-final-main-stages':(203,0),'processing-final-scoped-stages':(203,0),
 'processing-final-main-definition':(171,0),'processing-final-scoped-definition':(171,0)}
tests={}
for label,pair in expected.items():
 matches=re.findall(r'test result: ok\. (\d+) passed; 0 failed; (\d+) ignored;', (s/(label+'.stdout')).read_text())
 assert len(matches)==1 and tuple(map(int,matches[0]))==pair,(label,matches)
 tests[label]={'passed':pair[0],'ignored':pair[1],'seconds':json.loads((s/(label+'.json')).read_text())['seconds']}
for variant in roots:
 labels=[r['label']for r in receipts if r['label'].startswith('processing-final-'+variant+'-plan-')and not r['label'].endswith('-deadpan-plan')and not r['label'].endswith('-build')]
 assert len(labels)==28,(variant,len(labels))
 count=0
 for label in labels:
  matches=re.findall(r'test result: ok\. (\d+) passed; 0 failed; 0 ignored;', (s/(label+'.stdout')).read_text())
  assert len(matches)==1,label
  count+=int(matches[0])
 assert count==450,(variant,count)
 tests[variant+'-plan-integration']={'executables':len(labels),'passed':count}
a=(s/'processing-current-body-main.json').read_bytes()
b=(s/'processing-current-body-scoped.json').read_bytes()
assert a==b
current=json.loads(a)
work_deltas={'cold':[],'repeat':[]}
for row in current['reconciliation']+current['zero_reconciliation']:
 for interval in row['intervals']:
  for field,lane in interval['lanes'].items():
   assert lane['warm']-lane['legacy']==lane['actual_delta']==sum(lane['phase_deltas'])
   if field=='plan_work':work_deltas[interval['interval']].append(lane['actual_delta'])
assert all(len(rows)==8 for rows in work_deltas.values())
assert min(work_deltas['cold'])==59 and max(work_deltas['cold'])==114
assert min(work_deltas['repeat'])==-63 and max(work_deltas['repeat'])==-24
split=(s/'processing-fresh-split.stdout').read_text()
assert '3 passed; 4 failed;'in split
result={'all_terminal':True,'receipts':receipts,'native_audio_runs_serial':True,
 'tests':tests,'preserved_initial_inputs_outside_scope':preserved,'source_paths':len(paths),'index_scoped_equal':48,'main_scoped_equal':45,'late_change':'Only three module-scope Rustdoc lines; byte-proved; strict checks rerun',
 'immutable_oracles':len(goldens),'current_native_body':{'bytes':len(a),'sha256':sha(a),'main_scoped_equal':True,'work_deltas':work_deltas},
 'source_patch':{'bytes':(s/'shipping-source.patch').stat().st_size,'sha256':sha((s/'shipping-source.patch').read_bytes())},
 'split':{'passed':3,'failed':4,'seconds':json.loads((s/'processing-fresh-split.json').read_text())['seconds']}}
(s/'final-audit.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items()if k!='receipts'},indent=2))
