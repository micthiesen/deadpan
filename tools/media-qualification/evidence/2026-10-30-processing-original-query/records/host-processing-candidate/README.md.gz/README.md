# Original request processing admission integration

Scratch-only candidate for `crates/deadpan-audio/src/original_request.rs`. No actual repo edits, Cargo/rustc/native execution, Git, test edits, generated expectations or budget changes. Rustfmt parsed/formatted the whole candidate with child traversal disabled. Parent owns compilation, lint and host/Plan integration. Main/Scope source inputs were byte identical at the pin.

## Integration

Apply `original_request.patch` against its pinned source; preserve any concurrent parent changes. `original_request.rs` is the full candidate for review, not permission to overwrite a changed actual file blindly. No other production file belongs to this candidate.

The pending trace worker must supply these exact existing-namespace additions:

- `flattened_work_trace::ScopeGuard::new_processing(control)`
- `flattened_work_trace::processing_issuer_spent(control)`

The existing `completed(canonical, additional, total, forwarded)` method serves both product-specific scope kinds. Root/Domain processing scopes complete/drop immediately after the actual admitted constructor returns, before fresh policy limits or policy work. A constructor error drops the active scope normally, preserving its actual partial-work observation. No policy fee is accidentally attributed to the processing constructor.

## Product changes

Private Processing holds either the actual admitted immutable processing query plus its real ReadWork issuer, or cfg(test) Legacy ordinary query. query() returns only an immutable borrowed AudioProcessingQuery. PreparedQueries stores this carrier, and RootReadQueriesRef borrows its actual query. Plan/Domain/window checks and explicit drop(request) before returning PCM are untouched.

PreparedRequest validates flattened issuer first and processing issuer second. Each actual admitted product bills its own one comparison at the existing consuming boundary; a refusal at the first comparison prevents the second. Processing reports its bill through the product-specific trace API. Existing foreign flattened tests therefore still observe one comparison; a same-issuer request with both products admitted now consumes two comparisons. With explicitly legacy flattened and admitted processing, foreign processing is rejected by its one comparison before read I/O.

Root preparation now uses private prepare_processing_root with a short sound_context Admission borrow. The actual constructor forwards canonical/additional units once; no successful processing.work rebill exists on the admitted path. Policy/fades retain their existing constructors and actual separate bills.

Domain prepare_domain_policy becomes an &mut self method. Production creates actual processing_for_policy_admitted with the same short adapter, preserving its co-produced terminal witness and all Plan/Core leases. After the constructor trace closes, fresh remaining limits go to finish_policy. Successful completion retains the admitted processing carrier plus ordinary policy and bills policy only. First-query storage remains live across both content reuse and complete-history fallback; finish failure drops it before the enclosing flattened value drops and returns the error without refunds.

## Explicit legacy modes

New cfg(test) LEGACY_PROCESSING_QUERIES and with_legacy_processing_queries use the same nested/unwind-safe Cell restoration pattern as existing flattened compatibility. They do not implicitly alter or extend with_legacy_flattened_queries.

- Root legacy processing executes ordinary audio_processing and its one old canonical host bill.
- Domain policy_trace::legacy() remains first and executes its literal ordinary processing + ordinary policy path with both old bills, independent of the new TLS.
- Legacy processing with current policy reuse executes the old sealed processing_for_policy path, bills its first query once, gives fresh limits to finish_policy, and bills returned policy only.
- Current production and test default paths admit processing normally.

All Domain trace records receive the actual borrowed processing.query(), including admitted top work. No Graph packing/cache, controller caps, weight changes, work refunds, numerical-reader or DSP edits are introduced.

## Existing test/oracle adaptations owed to parent

1. Full old modes must explicitly nest with_legacy_processing_queries around their existing with_legacy_flattened_queries calls. Known sites: authored_eq/legacy_tile_baseline.rs producer; authored_eq/tile_admission_tests.rs ordinary baseline branch; shared_eq/cached_prediction_trace.rs with_legacy wrapper; shared_eq/cached_prediction_baseline.rs request construction used for old query-visitor observations. Preserve the frozen expected files, do not regenerate them.
2. Original request tests' previous_queries remain literal old ordinary queries. Their same_queries processing equality and assert_flattened_cost-only work arithmetic must account for admitted processing total versus old canonical. Bound nested resolved/lattice work requires the independent paired evidence, not broad work-field stripping. The consuming-read exact allowance and +1 assertions now need both real issuer receipts when both carriers are admitted. Flat-foreign early rejection still bills only one.
3. original_request/policy_reuse_tests.rs currently compares old/new processing_work and full processing query equality, and models limited-allowance boundaries using ordinary completed-query aggregate bills. Preserve a legacy-processing/current-reuse branch to isolate policy savings, then test the default admitted path separately with actual constructor partial fees, carrier cleanup, fresh finish limits and both issuer comparisons. Do not raise caps to make old arithmetic pass.
4. authored_eq/tile_admission_tests.rs flattened_fees/compare_flattened_counter and cached prediction counter comparison helpers must reconcile the new processing product lanes, accepted work, failed partial work and issuer work. Existing flat trace lanes retain their meaning and must not absorb processing fees. Snapshot source names can remain compatibility names as specified by trace owner.
5. Existing original_request/flattened_admission_tests.rs and shared_eq/flattened_original_admission_tests.rs observe aggregate sound_context_frames. Those live sums now include processing leases. Tests explicitly isolating flattened bytes should compare the flat-only setup or subtract an independently observed processing contribution, not rename the aggregate as flattened-only. General positive/zero cleanup remains valid. Their late processing-failure setup that budgeted an ordinary processing query must now use actual admitted constructor work/prefixes.
6. Add or adapt host processing lifecycle evidence for positive processing charge through actual prediction/read, zero after success/error/unused drop/late cache hit, processing-only foreign rejection with legacy flat, required PCM room reduced by both live carriers, and early warm Probe Queries phase construction count zero. The parent's existing test owners retain these files.

No tests were edited here. The new legacy wrapper is intentionally unused until parent wraps old baseline sites, so finish those dependent edits before claiming strict test lint clean.

## Verification boundary

Parser checked only. Parent should run both actual variants' targeted Original request, policy-reuse, authored/cached literal oracle and lifecycle tests, followed by existing appropriate libraries/lint. Failure cleanup must retain accepted forwarded work while releasing all real ReadWork sound_context_frames. No callback-derived heap/RSS claim and no expected-file generation is part of this candidate.
