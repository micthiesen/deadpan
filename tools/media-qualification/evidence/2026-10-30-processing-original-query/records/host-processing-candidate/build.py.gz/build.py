from pathlib import Path
p=Path('/Users/michael/Code/deadpan/crates/deadpan-audio/src/original_request.rs')
out=Path('/tmp/deadpan-processing-query-admission-2026-10-30/host-processing-candidate')
s=p.read_text()
(out/'original_request.rs.before').write_text(s)
s=s.replace('''//! Flattened metadata retains its allocation-site charge through the read.
//! Other queries and the captured Domain identity keep their existing borrows.''','''//! Flattened and processing metadata retain allocation-site charges through the read.
//! Policy, fades and the captured Domain identity keep their existing borrows.''')
s=s.replace('use deadpan_plan::AdmittedAudioQuery;','use deadpan_plan::{AdmittedAudioProcessingQuery, AdmittedAudioQuery};')
s=s.replace('''/// The immutable flattened value owns its allocation-site charge. Processing,
/// policy and fades still use their existing, unadmitted constructors.''','''/// The immutable flattened value owns its allocation-site charge.''')
anchor="struct PreparedQueries<'plan, 'work> {"
processing='''enum Processing<'plan, 'work> {
    Admitted {
        query: AdmittedAudioProcessingQuery<
            'plan,
            sound_context_admission::Issuer<'work>,
            sound_context_admission::Lease<'work>,
        >,
        issuer: sound_context_admission::Issuer<'work>,
    },
    #[cfg(test)]
    Legacy(AudioProcessingQuery<'plan>),
}

impl<'plan> Processing<'plan, '_> {
    fn query(&self) -> &AudioProcessingQuery<'plan> {
        match self {
            Self::Admitted { query, .. } => query.query(),
            #[cfg(test)]
            Self::Legacy(query) => query,
        }
    }

    fn validate_issuer(&self, control: WorkControl<'_>) -> Result<(), StageAudioError> {
        match self {
            Self::Admitted { issuer, .. } => {
                control.spend_plan_work(1)?;
                #[cfg(test)]
                flattened_work_trace::processing_issuer_spent(control);
                if *issuer != sound_context_admission::issuer(control) {
                    return Err(PlanError::AudioMetadataIssuerMismatch.into());
                }
                Ok(())
            }
            #[cfg(test)]
            Self::Legacy(_) => Ok(()),
        }
    }
}

'''
assert s.count(anchor)==1
s=s.replace(anchor,processing+anchor,1)
s=s.replace("    processing: AudioProcessingQuery<'plan>,","    processing: Processing<'plan, 'work>,",1)
s=s.replace('            processing: &self.queries.processing,','            processing: self.queries.processing.query(),',1)
s=s.replace('''        self.queries.flattened.validate_issuer(control)
''','''        self.queries.flattened.validate_issuer(control)?;
        self.queries.processing.validate_issuer(control)
''',1)
s=s.replace('''        let processing = plan.audio_processing(start..AudioSample(end), control.query_limits()?)?;
        control.spend_plan_work(processing.work)?;''','''        let processing = self.prepare_processing_root(plan, start..AudioSample(end), control)?;''',1)
s=s.replace('''        let (processing, policy) = prepare_domain_policy(domain, start..end, control)?;''','''        let (processing, policy) = self.prepare_domain_policy(domain, start..end, control)?;''',1)
a=s.index("fn prepare_domain_policy<'plan>(")
b=s.index('\n#[cfg(test)]\n#[path = "original_request/domain_policy_trace.rs"]',a)
old_domain=s[a:b]
(out/'old-domain-policy.txt').write_text(old_domain)
s=s[:a]+s[b:]
helpers='''    fn prepare_processing_root<'plan, 'work>(
        &mut self,
        plan: &'plan RenderPlan,
        samples: Range<AudioSample>,
        control: WorkControl<'work>,
    ) -> Result<Processing<'plan, 'work>, StageAudioError> {
        let limits = control.query_limits()?;
        #[cfg(test)]
        if legacy_processing_queries() {
            let query = plan.audio_processing(samples, limits)?;
            control.spend_plan_work(query.work)?;
            return Ok(Processing::Legacy(query));
        }
        let issuer = sound_context_admission::issuer(control);
        #[cfg(test)]
        let mut processing_work_trace = flattened_work_trace::ScopeGuard::new_processing(control);
        let query = {
            let mut admission = sound_context_admission::Admission::new(self, control);
            plan.audio_processing_admitted(samples, limits, &mut admission)?
        };
        #[cfg(test)]
        {
            processing_work_trace.completed(
                query.canonical_units(),
                query.additional_units(),
                query.work(),
                query.was_forwarded(),
            );
            drop(processing_work_trace);
        }
        Ok(Processing::Admitted { query, issuer })
    }

    fn prepare_domain_policy<'plan, 'work>(
        &mut self,
        domain: &AudioDomain<'plan>,
        samples: Range<AudioSample>,
        control: WorkControl<'work>,
    ) -> Result<(Processing<'plan, 'work>, AudioPolicyQuery<AudioSample>), StageAudioError> {
        #[cfg(test)]
        if policy_trace::legacy() {
            let processing = domain.processing(samples.clone(), control.query_limits()?)?;
            control.spend_plan_work(processing.work)?;
            let policy = domain.policy(samples.clone(), control.query_limits()?)?;
            control.spend_plan_work(policy.work)?;
            policy_trace::record(domain, samples, &processing, &policy);
            return Ok((Processing::Legacy(processing), policy));
        }
        #[cfg(test)]
        if legacy_processing_queries() {
            let processing = domain.processing_for_policy(samples.clone(), control.query_limits()?)?;
            control.spend_plan_work(processing.query().work)?;
            let completed = processing.finish_policy(domain, samples.clone(), control.query_limits()?)?;
            let (processing, policy) = completed.into_queries();
            control.spend_plan_work(policy.work)?;
            policy_trace::record(domain, samples, &processing, &policy);
            return Ok((Processing::Legacy(processing), policy));
        }
        let limits = control.query_limits()?;
        let issuer = sound_context_admission::issuer(control);
        #[cfg(test)]
        let mut processing_work_trace = flattened_work_trace::ScopeGuard::new_processing(control);
        let processing = {
            let mut admission = sound_context_admission::Admission::new(self, control);
            domain.processing_for_policy_admitted(samples.clone(), limits, &mut admission)?
        };
        #[cfg(test)]
        {
            let query = processing.query();
            processing_work_trace.completed(
                query.canonical_units(),
                query.additional_units(),
                query.work(),
                query.was_forwarded(),
            );
            drop(processing_work_trace);
        }
        let completed = processing.finish_policy(domain, samples.clone(), control.query_limits()?)?;
        let (query, policy) = completed.into_queries();
        control.spend_plan_work(policy.work)?;
        let processing = Processing::Admitted { query, issuer };
        #[cfg(test)]
        policy_trace::record(domain, samples, processing.query(), &policy);
        Ok((processing, policy))
    }

'''
anchor="    fn prepare_flattened<'work>("
assert s.count(anchor)==1
s=s.replace(anchor,helpers+anchor,1)
anchor='''#[cfg(test)]
thread_local! {
    static LEGACY_FLATTENED_QUERIES: std::cell::Cell<bool> = const { std::cell::Cell::new(false) };
}'''
new=anchor+'''

#[cfg(test)]
thread_local! {
    static LEGACY_PROCESSING_QUERIES: std::cell::Cell<bool> = const { std::cell::Cell::new(false) };
}

#[cfg(test)]
fn legacy_processing_queries() -> bool {
    LEGACY_PROCESSING_QUERIES.with(std::cell::Cell::get)
}

/// Explicit old processing mode, independent of flattened-query compatibility.
#[cfg(test)]
pub(super) fn with_legacy_processing_queries<T>(action: impl FnOnce() -> T) -> T {
    struct Restore(bool);
    impl Drop for Restore {
        fn drop(&mut self) {
            LEGACY_PROCESSING_QUERIES.with(|mode| mode.set(self.0));
        }
    }
    let _restore = Restore(LEGACY_PROCESSING_QUERIES.with(|mode| mode.replace(true)));
    action()
}'''
assert s.count(anchor)==1
s=s.replace(anchor,new,1)
(out/'original_request.rs').write_text(s)
