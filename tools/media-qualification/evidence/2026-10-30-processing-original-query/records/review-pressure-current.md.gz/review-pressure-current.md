# Current pressure-test review (updated)

## Findings

No material findings in the updated publisher extraction and focused test flow.

The earlier cold-owner finding is fixed: the test now establishes that owners-only admission succeeds at the `PCM + owner metadata` ceiling, then calls the actual cold `shared_original_input` route and expects its specific resident-limit refusal while preserving only the live owner charge. This is separate from publication.

`shared_original_input_mode` now sends its completed, already-read `ReadBlock` to `cache_original_input`. The helper contains the pre-existing post-read tail unchanged: it checks cancellation, computes actual block residency, handles overflow/cache-slot limits, accounts cached + active + projected + sound-context + candidate residency, evicts only optional original inputs, then links the exact entry and payload. It returns `Fresh` on optional-capacity refusal. Production calls this helper with the same validated context, sample range, depth and lookup key generated before reading.

The publication test now obtains the candidate with the real `read_controlled` path under ample capacity while the real WAV-backed Root owner query is live. It applies the exact/one-frame-short ceiling immediately before calling the same private helper production uses, with the real Root lookup. The helper does no source reads; unchanged provider/source-check counts establish that the exact/one-short outcome comes from publication. The output is compared against the earlier real cached reference, and Cached versus Fresh, graph/map counts, retained aggregate, and post-drop cleanup are checked.

The adjacent cached-probe fixture still preserves the exact two-entry warm state before applying its target probe cap. The separate cold seed case records shedding without weakening that warm assertion. The prepared-input `+3` remains scoped to sealed request validation and two actual issuer comparisons. The combined metadata helper still measures real Root flattened and processing queries simultaneously on one ledger with production-equivalent per-Layout frame rounding and verifies all leases drop.

The gain test uses an actual authored-bus path and a measured simultaneous query peak, with exact/one-short success/failure and canonical sample equality. The streaming test's `PCM + peak` remains explicitly a sufficient bound: it checks long-history canonical output and failure at PCM-only capacity, without claiming that its chosen upper bound is the minimum.

## Limits

Read-only review only; no Cargo/native build was run. Parent owns current host rebuild. A useful optional strengthening is to assert the cold read's provider-call count is unchanged on its resident-limit refusal, if that is the intended guarantee; this is not a current correctness finding because the assertion is about cold admission pressure, while the exact publication assertions already prove no reread in the extracted publisher.
