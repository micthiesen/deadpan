from pathlib import Path
import os,subprocess
s=Path(__file__).resolve().parent
rows=[
 ('scoped','stages','processing-final-scoped-stages',['--test-threads=1']),
 ('scoped','audio_definition','processing-final-scoped-definition',['--test-threads=1']),
 ('scoped','deadpan_audio','processing-current-scoped',['produce_current_cached_prediction_observations','--ignored','--nocapture','--test-threads=1']),
 ('main','deadpan_audio','processing-final-main-audio',['--test-threads=1']),
 ('main','stages','processing-final-main-stages',['--skip','general_split_sound::','--test-threads=1']),
 ('main','audio_definition','processing-final-main-definition',['--test-threads=1']),
 ('main','deadpan_audio','processing-current-main',['produce_current_cached_prediction_observations','--ignored','--nocapture','--test-threads=1']),
 ('main','stages','processing-fresh-split',['general_split_sound::','--nocapture','--test-threads=1']),
]
for variant,target,label,args in rows:
 env=os.environ.copy()
 if label.startswith('processing-current-'):
  output=s/('processing-current-body-'+variant+'.json')
  assert not output.exists()
  env['DEADPAN_CACHED_PREDICTION_CURRENT']=str(output)
 command=['python',str(s/'run_target.py'),'processing-final-'+variant+'-audio-build',variant,'audio',target,label,*args]
 result=subprocess.run(command,env=env)
 if result.returncode:raise SystemExit(result.returncode)
