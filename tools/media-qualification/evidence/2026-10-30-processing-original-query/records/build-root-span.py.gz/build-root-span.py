from pathlib import Path
import hashlib,json,difflib
root=Path('/Users/michael/Code/deadpan/crates/deadpan-plan/src')
out=Path('/tmp/deadpan-processing-query-admission-2026-10-30/root-span-candidate')
src=(root/'audio_signal.rs').read_text()
start=src.index('    fn span(\n')
end=src.index('\n}\n\nfn positive_range',start)
old=src[start:end]
(out/'audio_signal.rs.before').write_text(src)
body=old
body=body.replace('    fn span(\n','    pub(in crate::plan) fn span_admitted<A: AudioSoundContextAdmission>(\n',1)
body=body.replace('budget: &mut Budget,','budget: &mut QueryBudget<\'_, A>,',1)
body=body.replace(") -> Result<AudioSignalSpan<'plan>, PlanError> {",") -> QueryResult<GuardedBound<AudioSignalSpan<'plan>, A::Issuer, A::Lease>, A> {",1)
body=body.replace('        let mut repeats = self.repeats.clone();\n        let mut retimes = Vec::new();\n        let mut gap = self.gap.clone();',
'''        let mut memory = budget.memory();
        let mut repeats_capacity = budget.memory();
        let mut repeats = budget.repeats(&mut memory, &mut repeats_capacity, &self.repeats)?;
        let mut retimes_capacity = budget.memory();
        let mut retimes = Vec::new();
        let mut gap = budget.gap(&mut memory, &self.gap)?;''')
body=body.replace('budget.spend(', 'budget.canonical(')
body=body.replace('self.plan.bound_at(', 'self.plan.bound_at_query(')
body=body.replace('break (AudioSignalContent::Bound(Box::new(bound)), gap.after);',
'''break (
                        bound.boxed(budget)?.map(budget, AudioSignalContent::Bound)?,
                        gap.after,
                    );''')
body=body.replace('''                    AudioSignalContent::Leaf(AudioContent::from_hold(audio, gap.duration)),
                    gap.after.clone(),''',
'''                    Content::plain(
                        AudioSignalContent::Leaf(storage::hold(audio, gap.duration, &mut memory, budget)?),
                        budget.issuer,
                    ),
                    gap.after.as_ref().map(|value| budget.iteration(&mut memory, value)).transpose()?,''')
body=body.replace('break (AudioSignalContent::Bound(Box::new(bound)), None);',
'''break (
                    bound.boxed(budget)?.map(budget, AudioSignalContent::Bound)?,
                    None,
                );''')
body=body.replace('''AudioSignalContent::Leaf(AudioContent::Silence {
                            reason: SilenceReason::NoSourceAudio,
                        })''','''Content::plain(
                            AudioSignalContent::Leaf(AudioContent::Silence {
                                reason: SilenceReason::NoSourceAudio,
                            }),
                            budget.issuer,
                        )''')
body=body.replace('''AudioSignalContent::Leaf(AudioContent::Silence {
                                reason: SilenceReason::OutsideSourceSelection,
                            })''','''Content::plain(
                                AudioSignalContent::Leaf(AudioContent::Silence {
                                    reason: SilenceReason::OutsideSourceSelection,
                                }),
                                budget.issuer,
                            )''')
body=body.replace('source: audio.source.clone(),','source: budget.source(&mut memory, &audio.source)?,')
body=body.replace('break (AudioSignalContent::Leaf(content), None);','break (Content::plain(AudioSignalContent::Leaf(content), budget.issuer), None);')
body=body.replace('''                        AudioSignalContent::Leaf(AudioContent::from_hold(
                            audio,
                            node.inspection.duration,
                        )),''','''                        Content::plain(
                            AudioSignalContent::Leaf(storage::hold(
                                audio,
                                node.inspection.duration,
                                &mut memory,
                                budget,
                            )?),
                            budget.issuer,
                        ),''')
body=body.replace('''AudioSignalContent::Stage(AudioStage::for_node(
                                self.plan,
                                current,
                                &repeats,
                                self.definition.as_ref(),
                                self.bypass_binding,
                            )?)''','''stage_content(
                                AudioStage::for_node_admitted(
                                    self.plan,
                                    current,
                                    &repeats,
                                    self.definition.as_ref(),
                                    self.bypass_binding,
                                    budget,
                                )?,
                                budget,
                            )?''')
body=body.replace('''                        retimes.push(AudioRetimeStage {
                            node: node.inspection.id.clone(),''','''                        let needed = retimes.len() + 1;
                        budget.grow(&mut retimes, &mut retimes_capacity, needed)?;
                        retimes.push(AudioRetimeStage {
                            node: budget.node(&mut memory, &node.inspection.id)?,''')
body=body.replace('''                    budget.lookup.iteration_run_comparisons += location.comparisons;
                    if location.in_gap''','''                    budget.lookup.iteration_run_comparisons += location.comparisons;
                    budget.own_iteration(&mut memory, &location.play.iteration)?;
                    if location.in_gap''')
body=body.replace('''                            repeats.push(RepeatInstance {
                                node: node.inspection.id.clone(),''','''                            let needed = repeats.len() + 1;
                            budget.grow(&mut repeats, &mut repeats_capacity, needed)?;
                            repeats.push(RepeatInstance {
                                node: budget.node(&mut memory, &node.inspection.id)?,''')
body=body.replace('''                    repeats.push(RepeatInstance {
                        node: node.inspection.id.clone(),''','''                    let needed = repeats.len() + 1;
                    budget.grow(&mut repeats, &mut repeats_capacity, needed)?;
                    repeats.push(RepeatInstance {
                        node: budget.node(&mut memory, &node.inspection.id)?,''')
body=body.replace('''        Ok(AudioSignalSpan {
            definition: self.definition.clone(),''','''        let fields = FinishFields {
            definition: budget.definition(&mut memory, &self.definition)?,
            samples: allocated_samples.clone(),
            allocated_samples,
            signal_extent: extent,
            instance: InstancePath {
                node: budget.node(&mut memory, &self.plan.nodes[current].inspection.id)?,
                repeats,
            },
            gap_after,
            transform,
            grid,
            sampling,
            retimes,
        };
        let mut fields = Owned { value: fields, memory };
        budget.check_memory(&fields.memory)?;
        budget.check_memory(&repeats_capacity)?;
        budget.check_memory(&retimes_capacity)?;
        budget.merge_checked(&mut fields.memory, &mut repeats_capacity);
        budget.check_memory(&fields.memory)?;
        budget.merge_checked(&mut fields.memory, &mut retimes_capacity);
        finish(content, fields, budget)
    }''')
# Drop original final struct tail now that finish replaced beginning.
mark='''        finish(content, fields, budget)
    }'''
pos=body.index(mark)+len(mark)
body=body[:pos]
# Every explicit PlanError return must convert to QueryResult error.
body=body.replace('''                    ));''','''                    ).into());''')
body=body.replace('''            ));''','''            ).into());''')
header='''//! Actual Root structural traversal shared by ordinary and admitted spans.
use super::*;
use crate::plan::audio::capture::storage;
use crate::plan::audio_bound::query::GuardedBound;
use crate::plan::audio_owners::admission::Memory;

type Content<'plan, I, L> = GuardedBound<AudioSignalContent<'plan>, I, L>;

struct FinishFields {
    definition: Option<AudioDefinitionSelector>,
    samples: Range<SignalSample>,
    allocated_samples: Range<SignalSample>,
    signal_extent: Range<ExactRatio>,
    instance: InstancePath,
    gap_after: Option<IterationId>,
    transform: SignalTransform,
    grid: AudioSampleGrid<SignalSample>,
    sampling: AudioSampleMap<SignalSample>,
    retimes: Vec<AudioRetimeStage>,
}

fn stage_content<'plan, A: AudioSoundContextAdmission>(
    stage: Owned<AudioStage<'plan>, A::Issuer, A::Lease>,
    budget: &mut QueryBudget<'_, A>,
) -> QueryResult<Content<'plan, A::Issuer, A::Lease>, A> {
    let Owned { value, mut memory } = stage;
    let mut result = Content::plain(AudioSignalContent::Stage(value), budget.issuer);
    result.merge_memory(&mut memory, budget)?;
    Ok(result)
}

fn finish<'plan, A: AudioSoundContextAdmission>(
    content: Content<'plan, A::Issuer, A::Lease>,
    fields: Owned<FinishFields, A::Issuer, A::Lease>,
    budget: &mut QueryBudget<'_, A>,
) -> QueryResult<GuardedBound<AudioSignalSpan<'plan>, A::Issuer, A::Lease>, A> {
    struct Mapping<C, F, I, L> {
        content: C,
        fields: F,
        memory: Memory<I, L>,
    }
    let mut pending = Mapping {
        content,
        fields: fields.value,
        memory: fields.memory,
    };
    budget.check_memory(&pending.memory)?;
    // Keep all Plan fields ahead of their charge while Core validates/maps.
    let mut result = pending.content.map(budget, |content| {
        let FinishFields {
            definition, samples, allocated_samples, signal_extent, instance,
            gap_after, transform, grid, sampling, retimes,
        } = pending.fields;
        AudioSignalSpan {
            definition, samples, allocated_samples, signal_extent, instance,
            gap_after, transform, grid, sampling, retimes, content,
        }
    })?;
    result.merge_memory(&mut pending.memory, budget)?;
    budget.check_memory(&result._memory)?;
    Ok(result)
}

impl<'plan> AudioSignal<'plan> {
'''
(out/'audio_signal_query.rs').write_text(header+body+'\n}\n')
wrapper='''    fn span(
        &self,
        sample: SignalSample,
        grid: AudioSampleGrid<SignalSample>,
        stop_at_preserve: bool,
        stop_at_bindings: bool,
        budget: &mut Budget,
    ) -> Result<AudioSignalSpan<'plan>, PlanError> {
        let mut admission = Unmetered;
        outer::<_, Unmetered>(self.span_admitted(
            sample,
            grid,
            stop_at_preserve,
            stop_at_bindings,
            &mut QueryBudget::new(budget, &mut admission),
        ))
        .map(super::audio_bound::query::GuardedBound::unmetered)
    }'''
updated=src[:start]+wrapper+src[end:]
anchor='#[path = "audio_source_voice.rs"]'
updated=updated.replace(anchor,'#[path = "audio_signal_query.rs"]\nmod query;\n\n'+anchor,1)
(out/'audio_signal.rs').write_text(updated)
(out/'pins.json').write_text(json.dumps({'before':{'path':str(root/'audio_signal.rs'),'sha256':hashlib.sha256(src.encode()).hexdigest()},'candidate':{f:hashlib.sha256((out/f).read_bytes()).hexdigest() for f in ['audio_signal.rs','audio_signal_query.rs']}},indent=2)+'\n')
(out/'audio_signal.patch').write_text(''.join(difflib.unified_diff(src.splitlines(True),updated.splitlines(True),fromfile='a/crates/deadpan-plan/src/audio_signal.rs',tofile='b/crates/deadpan-plan/src/audio_signal.rs')))
