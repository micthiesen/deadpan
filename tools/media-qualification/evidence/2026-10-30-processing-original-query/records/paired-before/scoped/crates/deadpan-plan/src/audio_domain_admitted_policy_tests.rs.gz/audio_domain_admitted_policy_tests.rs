use super::*;
use crate::AudioSoundContextAdmission;
use std::{alloc::Layout, cell::RefCell, rc::Rc};

#[derive(Default)]
struct State {
    live: usize,
    work: usize,
    reservations: usize,
}
struct Admission(Rc<RefCell<State>>);
struct Lease {
    state: Rc<RefCell<State>>,
    bytes: usize,
}
impl Drop for Lease {
    fn drop(&mut self) {
        self.state.borrow_mut().live -= self.bytes;
    }
}
impl Admission {
    fn new() -> Self {
        Self(Rc::new(RefCell::new(State::default())))
    }
}
impl AudioSoundContextAdmission for Admission {
    type Error = PlanError;
    type Issuer = usize;
    type Lease = Lease;
    fn issuer(&self) -> usize {
        Rc::as_ptr(&self.0) as usize
    }
    fn spend(&mut self, units: usize) -> Result<(), PlanError> {
        self.0.borrow_mut().work += units;
        Ok(())
    }
    fn reserve(&mut self, layout: Layout) -> Result<Lease, PlanError> {
        let mut state = self.0.borrow_mut();
        state.reservations += 1;
        state.live += layout.size();
        Ok(Lease {
            state: Rc::clone(&self.0),
            bytes: layout.size(),
        })
    }
    fn merge(&mut self, into: &mut Lease, from: &mut Lease) {
        assert!(Rc::ptr_eq(&into.state, &self.0));
        assert!(Rc::ptr_eq(&from.state, &self.0));
        into.bytes += from.bytes;
        from.bytes = 0;
    }
}
fn counters(admission: &Admission) -> (usize, usize, usize) {
    let state = admission.0.borrow();
    (state.live, state.work, state.reservations)
}

#[test]
fn admitted_policy_keeps_ordinary_exact_work_success_and_empty_refusal() {
    let mut checked = 0;
    let mut refusals = 0;
    visit(|domain, case| {
        let samples = window(&case["request"]);
        let mut admission = Admission::new();
        let first = domain
            .processing_for_policy_admitted(samples.clone(), Default::default(), &mut admission)
            .unwrap();
        let before = counters(&admission);
        let needed = expected_policy(case)["work"].as_u64().unwrap() as usize;
        let exact = AudioQueryLimits { maximum_work: needed, ..Default::default() };
        let ordinary = domain
            .processing_for_policy(samples.clone(), Default::default())
            .unwrap()
            .finish_policy(domain, samples.clone(), exact);
        let admitted = first.finish_policy(domain, samples, exact);
        match (ordinary, admitted) {
            (Ok(ordinary), Ok(admitted)) => {
                let (_, expected) = ordinary.into_queries();
                let (query, actual) = admitted.into_queries();
                assert_eq!(policy(&actual), policy(&expected));
                assert_eq!(policy(&actual), expected_policy(case));
                assert_eq!(counters(&admission), before);
                drop(query);
            }
            (Err(expected), Err(actual)) => {
                assert_eq!(error(&actual), error(&expected));
                refusals += 1;
            }
            _ => panic!("exact fresh policy behavior changed: {}", case["name"]),
        }
        assert_eq!(counters(&admission), (0, before.1, before.2));
        checked += 1;
    });
    assert_eq!(checked, 26);
    assert!(refusals > 0, "empty ordinary policy needs a positive query allowance after enter");
}

#[test]
fn admitted_first_policy_witness_preserves_reuse_fallback_and_the_live_carrier() {
    let mut eligible = 0;
    let mut fallback = 0;
    visit(|domain, case| {
        let samples = window(&case["request"]);
        let mut admission = Admission::new();
        let first = domain
            .processing_for_policy_admitted(samples.clone(), Default::default(), &mut admission)
            .unwrap();
        let query = first.query();
        let observed = processing(domain, query.query());
        let old = &case["first_processing_true"]["query"];
        assert_eq!(
            observed.as_object().unwrap().len(),
            old.as_object().unwrap().len()
        );
        for (key, expected) in old.as_object().unwrap() {
            if key == "work" {
                assert_eq!(query.canonical_units(), expected.as_u64().unwrap() as usize);
                assert_eq!(observed[key].as_u64().unwrap() as usize, query.work());
            } else {
                assert_eq!(&observed[key], expected, "{} field {key}", case["name"]);
            }
        }
        assert_eq!(
            query.work(),
            query.canonical_units() + query.additional_units()
        );
        assert!(query.was_forwarded());
        let before = counters(&admission);
        assert!(before.0 > 0);
        assert_eq!(before.1, query.work());
        let span_buffer = query.query().spans.as_ptr();
        let first_work = query.work();
        let reuse = first.stops.permits_binding_reuse();
        assert_eq!(
            reuse,
            case["first_tape_eligibility"]["content_only_eligible"] == true
        );
        eligible += usize::from(reuse);
        fallback += usize::from(!reuse);
        let expected = expected_policy(case);
        let needed = expected["work"].as_u64().unwrap() as usize;
        let limits = if removed_second(case).is_some() {
            AudioQueryLimits {
                maximum_work: needed,
                ..Default::default()
            }
        } else {
            AudioQueryLimits::default()
        };
        let (returned, actual) = first
            .finish_policy(domain, samples, limits)
            .unwrap()
            .into_queries();
        assert_eq!(policy(&actual), expected);
        assert_eq!(returned.query().spans.as_ptr(), span_buffer);
        assert_eq!(returned.work(), first_work);
        assert_eq!(
            counters(&admission),
            before,
            "finish must not rebill the first query"
        );
        drop(returned);
        assert_eq!(admission.0.borrow().live, 0);
        assert_eq!(admission.0.borrow().work, before.1);
    });
    assert_eq!(eligible, 22);
    assert_eq!(fallback, 4);
}

#[test]
fn admitted_policy_identity_and_range_refusal_precede_invalid_fresh_limits_and_release() {
    let mut checked = 0;
    visit(|domain, case| {
        let samples = window(&case["request"]);
        for changed_domain in [false, true] {
            let mut admission = Admission::new();
            let first = domain
                .processing_for_policy_admitted(samples.clone(), Default::default(), &mut admission)
                .unwrap();
            let before = counters(&admission);
            assert!(before.0 > 0);
            let cloned = domain.clone();
            let changed_range = if samples.is_empty() {
                AudioSample(samples.start.0.checked_sub(1).unwrap())..samples.end
            } else {
                samples.start..samples.start
            };
            let (caller, requested) = if changed_domain {
                (&cloned, samples.clone())
            } else {
                (domain, changed_range)
            };
            assert!(matches!(
                first.finish_policy(
                    caller,
                    requested,
                    AudioQueryLimits {
                        maximum_work: 0,
                        maximum_spans: 0
                    }
                ),
                Err(PlanError::InvalidPlan(
                    "processing policy identity mismatch"
                ))
            ));
            assert_eq!(counters(&admission), (0, before.1, before.2));
            checked += 1;
        }
    });
    assert_eq!(checked, 52);
}

#[test]
fn admitted_policy_uses_fresh_span_limits_after_a_wider_admitted_first_query() {
    let mut checked = 0;
    visit(|domain, case| {
        let samples = window(&case["request"]);
        let mut admission = Admission::new();
        let first = domain
            .processing_for_policy_admitted(samples.clone(), Default::default(), &mut admission)
            .unwrap();
        if first.query().query().spans.len() <= 1 {
            drop(first);
            assert_eq!(admission.0.borrow().live, 0);
            return;
        }
        let before = counters(&admission);
        assert!(before.0 > 0);
        let fresh = AudioQueryLimits {
            maximum_spans: 1,
            ..Default::default()
        };
        let ordinary = domain
            .processing_for_policy(samples.clone(), Default::default())
            .unwrap()
            .finish_policy(domain, samples.clone(), fresh);
        let admitted = first.finish_policy(domain, samples, fresh);
        match (ordinary, admitted) {
            (Ok(ordinary), Ok(admitted)) => {
                let (_, expected) = ordinary.into_queries();
                let (query, actual) = admitted.into_queries();
                assert_eq!(policy(&actual), policy(&expected));
                assert_eq!(counters(&admission), before);
                drop(query);
            }
            (Err(expected), Err(actual)) => assert_eq!(error(&actual), error(&expected)),
            _ => panic!("admitted fresh span behavior changed: {}", case["name"]),
        }
        assert_eq!(counters(&admission), (0, before.1, before.2));
        checked += 1;
    });
    assert_eq!(checked, 6);
}
