# Next contract: actual Original policy, then creative fades

Planning only against the current Main source. No implementation, repo edits, Git, Cargo, native execution, cap changes or expected-file generation. The current processing checkpoint must be published before starting this work. Navigation used ripwire with the exact policy/fade/finish-policy symbols, followed by bounded source reads. This extends the earlier cold-query design only where the now-reviewed processing composition seam changes the concrete path.

## Preferred bounded unit

Admit the actual Root and physical-Domain policy constructors, including the sealed admitted processing-to-policy finish, and retain the policy carrier through actual Original prediction/read. This is one complete returned product and its recursive constructor closure. Creative fades are the following independent product, mapped below; they have a separate conditional request field and different boundary semantics. After policy alone, conditional fade construction remains explicitly open. Neither a host-only final-size reservation nor successful processing admission closes either construction peak.

The actual Root/Domain policy recursion reaches structural signals and checked retained Root/Point operands. Source-voice, projected/tape and arbitrary public AudioSignal policy entrypoints remain ordinary compatibility APIs unless separately admitted. This boundary follows factories: raw_domain_admitted constructs Point's signal through AudioSignal::for_placed_definition_admitted, whose provider is Structural. Do not add a new content refusal for reachable Bound/Stage cases, and preserve ordinary behavior of every shared helper's other callers.

## Current real policy storage and debit sites

`audio_policy.rs`:

| Symbol/site | Actual owned storage or lifetime | Existing canonical work |
| --- | --- | --- |
| PolicyWork:24, new:33 | Aggregate contents Vec; maximum/remaining/spans and lookup scalars | limits.validate first |
| spend:44, limits:51, observed:60 | Child limits share remaining allowance; child query lives before its aggregate debit/lookup fold | recursive-policy-work subtraction; observed spends returned child work once |
| content:66 | Source/RoomTone/Reverse AudioContent owning asset edges move into growing inventory | spend(1) before push; inventory is bounded by work, NOT maximum_spans |
| signal_policy:253 | Actual current AudioSignalQuery with stop flags false/false; per-call suppressed Vec | enter(depth) spends 1, query work/lookup observed; selected endpoints spend retimes.len |
| signal_policy:297 | Independent binding query with flags false/true, held through Bound recursion | whole returned query work/lookup once; no first-tape reuse at Root |
| domain_policy_inner:334 | Actual current flattened AudioQuery; per-call suppressed Vec; optional first processing binding tape | same enter/current-work/content/endpoint rules; add_outside itself has no debit |
| domain_policy_inner:372-449 | Borrow sealed first binding tape if allowed and tape.len <= fresh maximum_spans; otherwise actual second processing_inner(..., false) | reused first query is NOT billed again; fallback second query is billed once |
| bound_policy:461 | Owned raw Root/Point Domain; recursive child ranges; Point-domain.signal() owning clone; Point offset-conversion Vec; mapped parent ranges | enter 1; each returned retained range spends 1 before inverse mapping; raw_domain currently canonical zero |
| result:81 | Sort suppressed in place, consume it into a separate merged Vec, then collect a separately labeled output Vec; contents remains live throughout | result/sort/merge/label conversion currently have no canonical debit |

Final AudioPolicyQuery owns only suppressed capacity and contents capacity/payload; it has no project/revision header. A Source owning edge already admitted by a temporary current query must remain charged when moved into the inventory. Conversely, a dropped independent binding query/raw Domain must not require detaching a Core value to free its temporary charge. Current inventory includes independent retained history and current explicit Holds; it cannot be inferred from delivered PCM, flattened support alone, or the first processing tape.

Root signal temporary queries still own project/revision/definition headers and all span paths. Domain current flattened temporary queries own their headers, boundary/origin vectors and retimes. Raw Root/Point domains add definition, gap, repeats, constraints, embedded signal/selector ownership. Point `signal()` clones the complete embedded signal at audio_point_domain.rs:211; borrowing it instead would silently remove an old real copy from the shared ordinary implementation. Admit that actual clone or use an explicit compatibility backend preserving the old copy.

### Canonical/error-order constraints

PolicyWork::new validates limits first. Then enter(depth) occurs BEFORE child query validation: depth > MAX_DOCUMENT_DEPTH errors before its debit; a positive tiny allowance can exhaust at limits() and return `recursive policy work` before an otherwise invalid range is checked. Root's child query uses RoundEven; recursive retained Point uses PointCeil. Domain uses signed physical samples. Empty policy requests still enter and normally have canonical work 1, unlike empty fades. With maximum_work=1, the post-enter limits() check can fail even for an empty request.

Keep `recursive policy work`, `policy depth`, child structural/binding errors, invalid-limit/range precedence and lookup folding literal. QueryBudget's backing Budget::spend labels exhaustion `structural work`; therefore outer policy debits need the original checked precondition/error label before forwarding canonical units, rather than blindly substituting every PolicyWork::spend. Child structural debits retain their existing labels.

When children share the actual QueryBudget, their units and lookup mutations are already included. Do not call old observed(child.total) as a second bill or fold child lookup twice. Ordinary false mode must prove identical successful canonical work and typed error order against OLD. Preserve allocation-free sort and its old zero canonical weight; do not invent a sort estimate or charge comparisons afterward. Additional units cover real admission inspections/reservations and actual replacement/conversion moves, with no unused allowance charged or refunded.

## Reviewed seams available now

- audio_owner_query_admission.rs: QueryBudget, Memory, Owned, identity/source/path helpers and grow. Plain workspace vectors can use grow only while their values and all capacity/payload guards remain in one named owned state.
- audio_processing_query.rs: Collected/empty/push pre-admit a full replacement while prior elements, old buffer and current guarded value remain live. Copy/move one old element at a time with actual additional work outside infallible map. This is reusable for policy inventories, suppressed ranges and fade collections; do not fork a second accounting framework.
- audio_bound_query.rs: GuardedBound::zip checks both Plan lanes and consumed Core receipt/mode/transfer state; map moves a whole guarded value through allocation-free assembly. Its validated Core zip is already available. No new Core detach, unchecked unwrap, public mutable query or policy-free escape token is needed.
- audio_signal_processing_query.rs: the actual Structural signal assembler already accepts both stop flags and generic QueryBudget, but SignalBuffer/SignalValue and structural_grid/query_admitted are private. Add a narrow within-Plan adapter exposing a guarded actual signal product or a consuming map seam; do not generalize arbitrary Source/Projected providers merely to gain visibility.
- audio_flattened_query.rs / audio_capture.rs: actual admitted flattened assembly and actual generic physical walk exist. Use their internal guarded products under the same policy budget; public carrier fields should stay sealed. The existing type-specific flattened_leaf extractor is valid only for actual false/false Leaf results.
- AudioBound::raw_domain_admitted (audio_bound_probe.rs:37) admits the actual Root/Point domain and has canonical zero. AudioPointDomain::new_admitted and placed signal construction already admit their real copies. Old raw_domain's private 65,536 workspace budget must not become an invented canonical debit.
- BoundaryOwner::capture_admitted and AdmittedExtent already admit occurrence paths and start/end capacities; old capture prepays repeats.len+1 canonical work.

For policy result conversion, keep suppressed, merged, inventory and all corresponding capacities owned. Metered labeling prepares its complete output Vec while merged input remains live, then maps one range without allocation. False mode retains literal original push/collect backends. A result carrier can conservatively retain proven temporary charge, but any early release must follow actual value/buffer destruction; final heap measurement cannot establish construction peak or justify a refund.

## Sealed Domain finish is part of policy admission

Current audio_domain.rs:172-234 stores exact Domain pointer, original range, actual admitted first query and co-produced ProcessingStops. finish_policy first checks pointer/range, then chooses domain_policy_with_processing only if no exposed Stage/ProjectedStage; the policy implementation additionally falls back when fresh maximum_spans is below first-tape length. First-query work remains separate and fresh limits cover policy only. Opaque Bound bodies still recurse independently. Stage fallback preserves complete current processing history.

Add a separate admitted finish taking `&mut A` with the first carrier's Issuer/Lease types and returning admitted processing plus admitted policy. Preserve current ordinary finish APIs as compatibility. Keep pointer/range identity-error priority before policy validation, then validate the existing carrier against A before any new allocation/callback. Existing checked composition with an empty same-issuer guarded value, followed by map, can validate all retained Plan/Core lanes without a new Core API. Do not use transfer-to-Graph machinery for this validation.

The first query and its leases must remain owned across both policy reuse and ordinary fallback, all fresh-limit failures, and any new policy reservation failure. Do not replace the first successful query or its witness with another walk, inspect a partial tape, cache eligibility, or broaden the witness to Root/arbitrary callers. Policy errors retain actual accepted policy prefixes and leave no live caller lease after the consumed capability drops.

Suggested public shape: immutable sealed AdmittedAudioPolicyQuery with query/work/canonical_units/additional_units/was_forwarded, Root audio_policy_admitted, Domain policy_admitted, and admitted sealed finish. Root/Domain produce AudioSample labels; do not promise arbitrary sample types own no heap. The actual internal recursion may use i64/SignalSample wrappers with the existing scalar-only contract.

## Creative fade contract

`audio_fades.rs` real sites:

- audio_fades:49 / Domain::fades:67 validate limits then their actual Root/nonnegative or signed-Domain range before fade_query. Empty fades perform no walk, allocate no spans/headers, and have work 0.
- fade_query:83 checks output span count, spends 1, owns EditorialCapture and actual first walk with flags true/true. Prior output spans remain live. A Stage result causes a second false/false flattened walk while the first processing result still lives; clipping uses the opaque output's allocated end. Bound follows retained_bound_fade.
- retained:349 allocates the actual one-edge start Vec, then computes fallible opposite-side distance and allocates the end Vec. Preserve this field/error order. Boundary origins move from the walked Leaf; their guards must move with them. Empty retained support uses two zero-capacity vectors.
- retained_bound_fade:193 keeps the initial Bound span guard, creates the actual admitted envelope Domain via envelope_domain_query, transforms and moves outer editorial markers into its growing seed, and performs another false/false walk plus EditorialCapture. It preserves reference phase, floor/inverse-ceil mapping, signed origins, independent virtual width and resume beyond the current delivery seam.
- Existing canonical sites are outer editorial.len; each matching repeat prefix length; captured editorial.len+constraints.len before transforms; per marker 1; append_origins per constraint 1 plus BoundaryOwner capture and output.len dedup; merge_edge edges.len+1 and new.origins.len+origin.repeats.len+1 for each old-origin merge. Keep them exactly, including comparisons prepaid by aggregate lengths.
- add_editorial:375 owns a fresh origins Vec per active incident side; append_origins:459 constructs real captured origins and pushes only unique values. merge_edge:498 can grow a new origins Vec while the complete old edge/origins and the new edge remain live, then replace the old edge or append to side Vec. Origin clone copies instance node/repeats and gap iteration; use existing path helpers or a narrow exact origin copier, not a shallow byte estimate.
- Actual containers: query.spans; each span.start/end; each edge.origins; each origin.instance.repeats and identity edges; outer/retained capture constraints/editorial/repeats/retimes; envelope Domain seed.editorial and its capacity; first/second walk values and their Core/Plan lanes.

Use actual admitted physical walker with the same capture tuple and flags, envelope_domain_query and capture_admitted. In a Bound branch, borrow the guarded Bound to build an independently guarded envelope Domain; never extract it unmetered. False/false walkers can use the existing narrow Leaf extraction. Admit original/new side buffers and origin replacement overlap before allocation. Preserve ordinary vec!, push and clone backends in false mode. Sorting/dedup semantics, coincident Hard policy, minimum edge gain rather than multiplication, and Separate Raw endpoint/silent-Hold policy remain unchanged.

Fade's shared retained_bound_fade also serves AudioOwnerRetainedInput::fades (audio_owner_input.rs:308), whose caller has its own prepaid canonical aggregate and wider-history range semantics. Retain its ordinary wrapper and tests. That standalone retained factory is not silently claimed admitted by adding Root/Domain APIs.

Suggested public shape: sealed immutable AdmittedAudioFadeQuery, Root audio_fades_admitted and Domain fades_admitted. Final products have no project/revision header; their retained identities are inside origins. No generic edge callback may move values outside their guards or mutate an external unguarded output.

## Independent OLD evidence required before changes

Existing policy-binding-baseline-v1 freezes prior ordinary Domain policy/second-query observations before reuse, and processing-query-baseline-v1 freezes processing output. Neither is a complete current Root/Domain policy+fade constructor oracle. Final-storage tests already know query owning edges, but are not allocation-site/peak witnesses.

Freeze a new current-checkpoint policy/fade body independently on Main/Scope BEFORE modifying either algorithm or host preparation. Reuse the checked 33-parent processing visitor, then add the real documents in tests/audio_fades.rs, gap_bindings.rs, audio_bindings/source_endpoints.rs, hold_policy.rs and dense_bound_repeat_inventory_uses_shared_work_not_output_span_capacity. Record exact source documents/selectors/placements and parent identity/provenance. No synthetic invalid Vec/Layout fixture.

Capture complete returned policy suppressed ranges, contents, lookup, work; complete fade spans, both edge lists and all origin paths/policies/iterations; typed errors with existing labels. Cover full/crop/empty, signed/fractional grids, current+retained policy, hidden histories/resume/reanchor/gap binding, SilentHold vs outside selection vs raw emptiness, nonunity Preserve/shift-at-unity fallback, coincident/Hard/editorial edges, repeat overrides, one-sample incident voice, paged seams and fractional length parity. Freeze exact canonical work and one-short, exact/insufficient positive span caps, invalid limits mixed with invalid ranges and tiny positive policy work. Assert no OLD partial receipt is exposed on failure.

Separately freeze current sealed finish outputs/fresh-work limits for both reuse and Stage fallback, tight fresh spans forcing fallback, exact pointer/range mismatch precedence and complete-history policy. Keep first-query receipt/work out of policy's own canonical bill. Existing 26 paired sealed tests are regression inputs, not permission to regenerate older fixtures.

## Verification and host lifetime obligations

Plan false mode must match every complete OLD field/work/error and invoke no metered callbacks. True mode must independently reconcile canonical OLD work, actual additional, forwarded accepted units and query total. Final policy/fade outputs have no nested Core work counters; intermediate actual Core resolutions still require the existing paired proof where used. Exercise every meaningful reservation/work refusal and issuer rotation, exact/one-short actual total and requested-Layout peak, old/new buffers with current values live, inventory > maximum_spans valid density, merge/label overlap and old/new fade origins. Empty policy may have temporary-query peak but zero final bytes; empty fades legitimately have zero peak/live charge. Never require every empty carrier to have positive retained bytes.

Host original_request currently builds flat, processing, ordinary policy, conditional fades, billing successful policy/fade work after return. Replace only each newly admitted product's successful rebill with its actual forwarded receipt; keep real failed prefixes. Store private immutable Policy/Fades carriers, retain all prior products while later products construct, validate each present issuer at actual consuming boundaries and release all metadata before returned PCM. The Domain finish adapter must overlap the first query through policy allocation/fallback.

Extend product-specific constructor traces without absorbing real host eviction work into Plan additional. Use the reviewed explicit accepted eviction debit receipt and paired OLD/current global differences; do not erase changed cache/residency/error behavior. Real WAV tests need positive policy/fade charge at prediction callbacks and source/DSP boundaries, unused/error/late-hit cleanup, foreign new-product rejection with earlier products in explicit legacy modes, combined four-product PCM room, successful/failed policy finish, and early warm Probe constructing none of the products. Keep fresh source admission and exact same-source output/masks/dependencies/depth. Adapt fee-derived fixture pressure rather than raising global caps.

No DSP/semantic conflict was found with admitting these products. The conflicts to avoid are semantic optimizations disguised as accounting: replacing complete retained policy by delivery masks, reusing an unsealed first tape, applying input-clock fades after Preserve, treating zero PCM as silent policy, changing independent owning-edge accounting to graph deduplication, or claiming standalone voice/tape/retained factories are closed. The current AudioSoundContextAdmission module header still says processing peaks remain separate; publishing the present checkpoint should update that scope accurately, and the next unit should leave only its genuinely open products named.

## Read pins

- crates/deadpan-plan/src/audio_policy.rs: 9e28f3dc9061e2fbe64911bb8288720fd7ba81f48b3215a583e4f1781dd9a7ed
- crates/deadpan-plan/src/audio_fades.rs: a59a08eee74ed6e2f6f4d6afa1f5ffcff467ecb08278da71306461ed1e91e118
- crates/deadpan-plan/src/audio_domain.rs: 05ff57f77357cc0f65da701d9b125db24c9ce39b95ab25f91c96db136b9fd1a4
- crates/deadpan-plan/src/audio_signal_processing_query.rs: da2b9cf7e108beea86c7ec647b919585de503ef92d367d073917e2f0dc3c08eb
- crates/deadpan-plan/src/audio_bound_query.rs: 01a5b56b65a373e422620d14371a222e33c0394310262c14887b45f29f66e040
- crates/deadpan-plan/src/audio_bound_probe.rs: 4a1cb5629c4934bf6c05dfc595af2f4bb5b16c1f2fe7bfb5777e67c098519555
- crates/deadpan-plan/src/audio_boundary.rs: 50bdefa0e2c9646b859b197a579dd044498b471a3c998a88ad6d7f9b768a701b
- crates/deadpan-plan/src/audio_owner_query_admission.rs: 43b8dab2975e9313cba34ec5059b1fd55f28e22ccc0be53bc3d03774cb4a34c2
- crates/deadpan-plan/src/audio_processing_query.rs: f11d562f043df25b2ed097fdfba137f740a2e4256bdda4899b8f6b5e0f926c2e
- crates/deadpan-plan/src/audio_point_domain.rs: 6213b39cd0452b39e95ba8df592a33bdbb9a2627e22a1a1df95efab0e5be83ab
- crates/deadpan-plan/src/audio_owner_input.rs: 39236727cb8a7c9af7ae1b29982a9c6ada991f8c2c47ca96e1996dd1b41bc5f3
- crates/deadpan-audio/src/original_request.rs: ba7e11a30c6d57c4991270021419625a15afc8318c2e14685b6dec012fa18b17
- crates/deadpan-audio/src/original_request/flattened_work_trace.rs: 23d1bccd11652758c9cdd0a918b5f6ea3afc8aca3bce84dd75ce1560c674881e
