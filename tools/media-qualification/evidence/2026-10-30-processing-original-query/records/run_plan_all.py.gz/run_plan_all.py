from pathlib import Path
import json,subprocess,sys
s=Path(__file__).resolve().parent
build,variant,label=sys.argv[1:]
pins=json.loads((s/(build+'-pins.json')).read_text())
for row in pins:
 assert row['package']=='plan'
 name=row['name'].replace('_','-')
 r=subprocess.run(['python',str(s/'run_logic_target.py'),build,variant,'plan',row['name'],label+'-'+name,'--test-threads=1'])
 if r.returncode:raise SystemExit(r.returncode)
