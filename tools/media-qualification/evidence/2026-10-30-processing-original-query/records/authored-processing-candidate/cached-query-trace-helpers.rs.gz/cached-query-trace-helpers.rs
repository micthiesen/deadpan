fn receipt_number(value: &Value, field: &str) -> u64 {
    value[field].as_u64().unwrap_or_else(|| panic!("missing {field} receipt: {value}"))
}

fn assert_query_trace(trace: &Value, product: &str, ordinary: bool) {
    for field in ["nested", "invalid", "overflow"] {
        assert_eq!(trace[field], false, "invalid {product} trace: {trace}");
    }
    assert_eq!(receipt_number(trace, "active_depth"), 0);
    assert!(receipt_number(trace, "max_active_depth") <= 1);
    if ordinary {
        assert_eq!(receipt_number(trace, "max_active_depth"), 0);
    }
    for lane in ["plan", "cache"] {
        let value = &trace[lane];
        assert_eq!(receipt_number(value, "constructor_calls"),
            receipt_number(value, "completed_queries").checked_add(receipt_number(value, "failed_queries")).unwrap());
        assert_eq!(receipt_number(value, "accepted_work"),
            receipt_number(value, "canonical_units").checked_add(receipt_number(value, "additional_units")).unwrap()
                .checked_add(receipt_number(value, "partial_work")).unwrap());
        assert_eq!(receipt_number(value, "issuer_checks"), receipt_number(value, "issuer_work"));
        assert_eq!(receipt_number(value, "partial_work"), 0,
            "{product} partial construction needs separate OLD-work qualification: {trace}");
        if ordinary {
            for count in value.as_object().unwrap().values() {
                assert_eq!(count.as_u64(), Some(0), "ordinary {product} trace: {trace}");
            }
        }
    }
}

fn query_trace_delta(before: &Value, after: &Value, trace: &str, lane: &str, field: &str) -> i128 {
    let result = integer(&after[trace][lane][field]) - integer(&before[trace][lane][field]);
    assert!(result >= 0, "{trace}/{lane}/{field} must remain cumulative inside a read");
    result
}

fn query_receipts(before: &Value, after: &Value, lane: &str) -> Value {
    let mut result = serde_json::Map::new();
    for (field, product) in [("flattened_work_trace", "flattened"), ("processing_work_trace", "processing")] {
        assert_query_trace(&before[field], product, false);
        assert_query_trace(&after[field], product, false);
        let mut counts = serde_json::Map::new();
        for name in ["constructor_calls", "completed_queries", "failed_queries", "accepted_work",
            "canonical_units", "additional_units", "partial_work", "issuer_checks", "issuer_work"] {
            counts.insert(name.into(), json!(query_trace_delta(before, after, field, lane, name)));
        }
        result.insert(product.into(), Value::Object(counts));
    }
    Value::Object(result)
}

fn without_query_traces(mut value: Value) -> Value {
    let strip = |counter: &mut Value| {
        for (field, product) in [("flattened_work_trace", "flattened"), ("processing_work_trace", "processing")] {
            let trace = counter.as_object_mut().unwrap().remove(field)
                .unwrap_or_else(|| panic!("missing explicit {field} instrumentation"));
            assert_query_trace(&trace, product, true);
        }
    };
    for case in value["cases"].as_array_mut().unwrap() {
        for field in ["before", "after_first", "before_second", "after_second", "after_arc_verification"] {
            strip(&mut case["result"][field]);
        }
        strip(&mut case["cleanup"]);
    }
    value
}
