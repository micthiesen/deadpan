fn compare_domain_policy_counter(actual: &mut Value, old: &Value, imposed: bool) -> u64 {
    let trace = actual.as_object_mut().unwrap().remove("domain_policy_trace").unwrap();
    let mut old = old.clone();
    let old_trace = old.as_object_mut().unwrap().remove("domain_policy_trace").unwrap();
    let processing = take_query_trace(actual, "processing_work_trace");
    let old_processing = take_query_trace(&mut old, "processing_work_trace");
    let fees = query_fees(&processing, "processing");
    let old_fees = query_fees(&old_processing, "processing reference");
    let removed = reconcile_domain_policy_receipts(&trace, &old_trace);
    for (lane, field) in ["old_total_controller_work", "cache_plan_work"].into_iter().enumerate() {
        let difference = i128::from(fees[lane]) - i128::from(old_fees[lane]);
        let removed = if lane == 0 { i128::from(removed) } else { 0 };
        let adjustment = if imposed && lane == 0 { 0 } else { difference - removed };
        assert_eq!(i128::from(number(actual, field)), i128::from(number(&old, field)) + adjustment,
            "only actual policy savings and separately witnessed processing fees differ: {field}");
        actual[field] = old[field].clone();
    }
    assert_eq!(actual, &old, "all other controller/resource/cache fields remain literal");
    removed
}
