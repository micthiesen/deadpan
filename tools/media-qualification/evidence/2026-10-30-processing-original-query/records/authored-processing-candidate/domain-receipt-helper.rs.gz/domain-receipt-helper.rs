fn reconcile_domain_policy_receipts(actual: &Value, old: &Value) -> u64 {
    let rows = actual.as_array().unwrap();
    let old_rows = old.as_array().unwrap();
    assert_eq!(rows.len(), old_rows.len(), "actual Domain request sequence");
    let mut saved = 0_u64;
    for (row, old_row) in rows.iter().zip(old_rows) {
        for value in [row, old_row] {
            assert_eq!(number(value, "processing_work"),
                number(value, "processing_canonical_work").checked_add(number(value, "processing_additional_work")).unwrap(),
                "actual Domain first processing receipt categories");
        }
        assert_eq!(row["processing_canonical_work"], old_row["processing_canonical_work"],
            "Domain first-query canonical work remains literal");
        let removed = number(old_row, "policy_work").checked_sub(number(row, "policy_work")).unwrap();
        if removed != 0 {
            assert_eq!(row["content_only_eligible"], true);
            assert!(row["samples"]["start"].as_i64().unwrap() < row["samples"]["end"].as_i64().unwrap());
            assert_eq!(removed, number(row, "processing_canonical_work"),
                "only the actual already-paid first canonical processing receipt is removed");
        }
        for field in ["visited_nodes", "sequence_comparisons", "iteration_run_comparisons"] {
            assert_eq!(number(&old_row["policy_lookup"], field).checked_sub(number(&row["policy_lookup"], field)).unwrap(),
                if removed == 0 { 0 } else { number(&row["processing_lookup"], field) },
                "literal actual lookup receipt delta: {field}");
        }
        assert_eq!(
            i128::from(number(row, "processing_work")) - i128::from(number(old_row, "processing_work")),
            i128::from(number(row, "processing_additional_work")) - i128::from(number(old_row, "processing_additional_work")),
            "changed total first-query work is exactly its separately recorded additional work");
        let mut checked = row.clone();
        for field in ["policy_work", "policy_lookup", "processing_work", "processing_additional_work"] {
            checked[field] = old_row[field].clone();
        }
        assert_eq!(&checked, old_row,
            "Domain identity, signed ranges, canonical first query and request order remain literal");
        saved = saved.checked_add(removed).unwrap();
    }
    saved
}
