fn query_fees(trace: &Value, product: &str) -> [u64; 2] {
    for field in ["nested", "invalid", "overflow"] {
        assert_eq!(trace[field], false, "invalid {product} receipt: {trace}");
    }
    assert_eq!(number(trace, "active_depth"), 0);
    assert!(number(trace, "max_active_depth") <= 1);
    ["plan", "cache"].map(|name| {
        let lane = &trace[name];
        assert_eq!(number(lane, "constructor_calls"),
            number(lane, "completed_queries").checked_add(number(lane, "failed_queries")).unwrap());
        assert_eq!(number(lane, "accepted_work"),
            number(lane, "canonical_units").checked_add(number(lane, "additional_units")).unwrap()
                .checked_add(number(lane, "partial_work")).unwrap(),
            "actual {product} forwarded deltas retain successful and failed construction work");
        assert_eq!(number(lane, "issuer_checks"), number(lane, "issuer_work"));
        assert_eq!(number(lane, "partial_work"), 0,
            "{product} partial constructor refusal needs separate OLD-work qualification: {trace}");
        number(lane, "additional_units").checked_add(number(lane, "issuer_work")).unwrap()
    })
}

fn assert_ordinary_query_trace(trace: &Value, product: &str) {
    assert_eq!(query_fees(trace, product), [0, 0]);
    assert_eq!(number(trace, "max_active_depth"), 0);
    for name in ["plan", "cache"] {
        for value in trace[name].as_object().unwrap().values() {
            assert_eq!(value.as_u64(), Some(0), "ordinary {product} trace: {trace}");
        }
    }
}

fn take_query_trace(value: &mut Value, field: &str) -> Value {
    value.as_object_mut().unwrap().remove(field)
        .unwrap_or_else(|| panic!("missing explicit {field} instrumentation"))
}

fn compare_flattened_counter(actual: &mut Value, ordinary: &Value, imposed: bool) -> [u64; 2] {
    let mut ordinary = ordinary.clone();
    let mut fees = [0_u64; 2];
    for (field, product) in [("flattened_work_trace", "flattened"), ("processing_work_trace", "processing")] {
        let trace = take_query_trace(actual, field);
        let old_trace = take_query_trace(&mut ordinary, field);
        assert_ordinary_query_trace(&old_trace, product);
        let product_fees = query_fees(&trace, product);
        for lane in 0..2 {
            fees[lane] = fees[lane].checked_add(product_fees[lane]).unwrap();
        }
    }
    for (index, field) in ["old_total_controller_work", "cache_plan_work"].into_iter().enumerate() {
        let additional = if imposed && index == 0 { 0 } else { fees[index] };
        assert_eq!(number(actual, field), number(&ordinary, field).checked_add(additional).unwrap(),
            "only independently observed flattened/processing additional and issuer receipts differ: {field}");
        actual[field] = ordinary[field].clone();
    }
    assert_eq!(actual, &ordinary, "all other Original-query observations remain literal");
    fees
}

fn remove_flattened_traces(observed: &mut Value) {
    for field in ["flattened_work_trace", "processing_work_trace"] {
        for phase in ["before", "after"] {
            take_query_trace(&mut observed["setup"][phase], field);
        }
        for operation in observed["operations"].as_array_mut().unwrap() {
            for phase in ["before", "after_return_drop"] {
                take_query_trace(&mut operation[phase], field);
            }
        }
        take_query_trace(&mut observed["final"], field);
    }
}
