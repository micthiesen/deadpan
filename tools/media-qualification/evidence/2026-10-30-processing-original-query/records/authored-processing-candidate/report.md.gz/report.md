# Authored processing comparison candidate

Primary deliverable: patches/tile_admission_tests.patch. Apply only its helper hunks to current source. Do not copy an after/ file over the shared checkout. The patch leaves the four full-legacy routing sites, authored baseline instrumentation, production functions, fixtures and expected bodies to parent.

## Exact reconciliation

Each flattened and processing trace independently proves constructor calls = completed + failed; accepted work = canonical + additional + actual partial work; issuer checks = issuer work; no active, nested, invalid or overflowed scope. Controller comparison permits only each product's separately observed additional + issuer units. Product canonical work never becomes fake OLD work or another product's fee.

Domain rows use literal processing_canonical_work and processing_additional_work. Both rows prove processing_work = canonical + additional; canonical work and all identity/range/order/lookup facts remain literal. Only successful nonempty eligible policy reuse may remove its already-paid canonical first-query work from ordinary policy work. The reported 34 versus 7 row is accounted as canonical 7 plus independently recorded additional 27. No offset comes from expected subtraction.

Across Domain policy variants, each plan/cache lane separately accounts the processing fee difference. The existing corpus's policy canonical saving remains in the plan lane. A real cache-lane policy saving would fail this candidate and need a true lane receipt. Certified versus direct paths require both product traces literally equal before the existing independently measured one-sample query savings apply.

Full OLD requires every product lane field zero, maximum depth zero and clear flags. Only then are the two explicit instrumentation keys removed for the complete OLD comparison. Unknown keys or arbitrary work fields are not removed. Source admission, failures, output bits, dependencies, cache and resources remain literal.

## Pending failures

Nonzero partial_work remains in accepted-work conservation and then fails explicitly. It is not zero-normalized, classified as additional or subtracted from OLD totals. If actual execution reaches this refusal, it needs a separately witnessed OLD failed-construction receipt at the same input. This candidate intentionally does not manufacture it. Resource/error changes or certified receipt sequence changes remain failures.

Imposed controller exhaustion keeps the existing imposed-plan override, while requiring both product traces identical across the call.

## Cached candidate is optional

Parent reports cached prediction currently passes. Its existing helper already proves every actual debit delta equals its four observed phase deltas and requires repeat plan Queries/OriginalRead work zero. No cached change is required to fix authored failures.

Optional patches/cached_prediction_baseline.patch adds exactly two product snapshot fields and two product resets at existing case reset sites. It preserves inherited module declarations and oracle routing. Optional patches/cached_prediction_tests.patch consumes those snapshots, requires full-legacy traces zero before OLD comparison, records the products separately, and strengthens warm zero checks to both lanes and scope calls. It proves cold delta equals separate flat fees + processing fees + actual Probe delta, without assuming a constant processing fee or hard-coding Probe +6. Existing phase conservation remains. Apply these two patches together only for parent's next actual capture after full-legacy routing, not to repair an already passing test.

## Verification and pins

All writes are within this scratch directory. No actual repo edits, Git, Cargo/native tests, expected generation/hash changes or cap increases.

- Read current authored/cached helpers, product trace and Domain trace source.
- Rustfmt edition 2024 with skip_children parsed/formatted all three candidate Rust files.
- All three patches passed patch --dry-run -p1 against frozen scratch before/ copies.
- Reviewed full authored diff and all cached baseline hunks; baseline contains only snapshot/reset additions.
- Type checking and actual optimized variant execution remain with parent.

input-pins.json pins initial source. output-pins.json pins scratch sources, fragments and patches. Primary authored patch does not touch parent's concurrent routing/instrumentation. Raw helper files are convenience fragments; use reviewed patches.
