//! Warm predictions compared with immutable query-derived native witnesses.

use super::*;
use serde_json::{Value, json};

fn integer(value: &Value) -> i128 {
    i128::from(value.as_u64().expect("nonnegative observed work"))
}

fn delta(before: &Value, after: &Value, field: &str) -> i128 {
    integer(&after[field]) - integer(&before[field])
}

fn phase_delta(before: &Value, after: &Value, phase: usize, field: &str) -> i128 {
    integer(&after["phase_work"]["work"][phase][field])
        - integer(&before["phase_work"]["work"][phase][field])
}

fn receipt_number(value: &Value, field: &str) -> u64 {
    value[field]
        .as_u64()
        .unwrap_or_else(|| panic!("missing {field} receipt: {value}"))
}

fn assert_query_trace(trace: &Value, product: &str, ordinary: bool) {
    for field in ["nested", "invalid", "overflow"] {
        assert_eq!(trace[field], false, "invalid {product} trace: {trace}");
    }
    assert_eq!(receipt_number(trace, "active_depth"), 0);
    assert!(receipt_number(trace, "max_active_depth") <= 1);
    if ordinary {
        assert_eq!(receipt_number(trace, "max_active_depth"), 0);
    }
    for lane in ["plan", "cache"] {
        let value = &trace[lane];
        assert_eq!(
            receipt_number(value, "constructor_calls"),
            receipt_number(value, "completed_queries")
                .checked_add(receipt_number(value, "failed_queries"))
                .unwrap()
        );
        assert_eq!(
            receipt_number(value, "accepted_work"),
            receipt_number(value, "canonical_units")
                .checked_add(receipt_number(value, "additional_units"))
                .unwrap()
                .checked_add(receipt_number(value, "partial_work"))
                .unwrap()
        );
        assert_eq!(
            receipt_number(value, "issuer_checks"),
            receipt_number(value, "issuer_work")
        );
        assert_eq!(
            receipt_number(value, "partial_work"),
            0,
            "{product} partial construction needs separate OLD-work qualification: {trace}"
        );
        if ordinary {
            for count in value.as_object().unwrap().values() {
                assert_eq!(count.as_u64(), Some(0), "ordinary {product} trace: {trace}");
            }
        }
    }
}

fn query_trace_delta(before: &Value, after: &Value, trace: &str, lane: &str, field: &str) -> i128 {
    let result = integer(&after[trace][lane][field]) - integer(&before[trace][lane][field]);
    assert!(
        result >= 0,
        "{trace}/{lane}/{field} must remain cumulative inside a read"
    );
    result
}

fn query_receipts(before: &Value, after: &Value, lane: &str) -> Value {
    let mut result = serde_json::Map::new();
    for (field, product) in [
        ("flattened_work_trace", "flattened"),
        ("processing_work_trace", "processing"),
    ] {
        assert_query_trace(&before[field], product, false);
        assert_query_trace(&after[field], product, false);
        let mut counts = serde_json::Map::new();
        for name in [
            "constructor_calls",
            "completed_queries",
            "failed_queries",
            "accepted_work",
            "canonical_units",
            "additional_units",
            "partial_work",
            "issuer_checks",
            "issuer_work",
        ] {
            counts.insert(
                name.into(),
                json!(query_trace_delta(before, after, field, lane, name)),
            );
        }
        result.insert(product.into(), Value::Object(counts));
    }
    Value::Object(result)
}

fn without_query_traces(mut value: Value) -> Value {
    let strip = |counter: &mut Value| {
        for (field, product) in [
            ("flattened_work_trace", "flattened"),
            ("processing_work_trace", "processing"),
        ] {
            let trace = counter
                .as_object_mut()
                .unwrap()
                .remove(field)
                .unwrap_or_else(|| panic!("missing explicit {field} instrumentation"));
            assert_query_trace(&trace, product, true);
        }
    };
    for case in value["cases"].as_array_mut().unwrap() {
        for field in [
            "before",
            "after_first",
            "before_second",
            "after_second",
            "after_arc_verification",
        ] {
            strip(&mut case["result"][field]);
        }
        strip(&mut case["cleanup"]);
    }
    value
}

fn without_work(mut value: Value) -> Value {
    if let Value::Object(fields) = &mut value {
        fields.remove("plan_work");
        fields.remove("cache_plan_work");
        fields.remove("phase_work");
        for (field, product) in [
            ("flattened_work_trace", "flattened"),
            ("processing_work_trace", "processing"),
        ] {
            let trace = fields
                .remove(field)
                .unwrap_or_else(|| panic!("missing explicit {field} instrumentation"));
            assert_query_trace(&trace, product, false);
        }
    }
    value
}

fn compare(legacy: &Value, warm: &Value) -> Value {
    assert_eq!(legacy["legacy_query_mode"], true);
    assert_eq!(warm["legacy_query_mode"], false);
    let old = legacy["cases"].as_array().unwrap();
    let new = warm["cases"].as_array().unwrap();
    assert_eq!(old.len(), new.len());
    let mut records = Vec::new();
    for (old, new) in old.iter().zip(new) {
        let a = &old["result"];
        let b = &new["result"];
        for field in [
            "name",
            "context",
            "range",
            "prediction_enabled",
            "same_cached_arc",
            "fixed_graph_reservation",
            "first",
            "second",
            "independent_query_oracle",
            "wav_sha256",
            "declared_source_audio",
            "all_zero_pcm_permitted",
        ] {
            assert_eq!(a[field], b[field], "native semantic witness: {field}");
        }
        for field in [
            "before",
            "after_first",
            "before_second",
            "after_second",
            "after_arc_verification",
        ] {
            assert_eq!(
                without_work(a[field].clone()),
                without_work(b[field].clone()),
                "non-work accounting: {field}"
            );
        }
        assert_eq!(
            without_work(old["cleanup"].clone()),
            without_work(new["cleanup"].clone())
        );
        let mut intervals = Vec::new();
        for (name, before, after) in [
            ("cold", "before", "after_first"),
            ("repeat", "before_second", "after_second"),
        ] {
            let mut lanes = serde_json::Map::new();
            for (lane, field) in ["plan_work", "cache_plan_work"].into_iter().enumerate() {
                let receipts = query_receipts(
                    &b[before],
                    &b[after],
                    if lane == 0 { "plan" } else { "cache" },
                );
                let old_total = delta(&a[before], &a[after], field);
                let new_total = delta(&b[before], &b[after], field);
                let phases: Vec<_> = (0..4)
                    .map(|phase| {
                        phase_delta(&b[before], &b[after], phase, field)
                            - phase_delta(&a[before], &a[after], phase, field)
                    })
                    .collect();
                assert_eq!(
                    new_total - old_total,
                    phases.iter().sum::<i128>(),
                    "every changed actual debit belongs to its observed phase"
                );
                if name == "cold" {
                    let flattened = integer(&receipts["flattened"]["additional_units"])
                        + integer(&receipts["flattened"]["issuer_work"]);
                    let processing = integer(&receipts["processing"]["additional_units"])
                        + integer(&receipts["processing"]["issuer_work"]);
                    assert_eq!(
                        new_total - old_total,
                        flattened + processing + phases[3],
                        "cold delta is separately witnessed flattened/processing fees plus the actual Probe"
                    );
                }
                if name == "repeat" {
                    assert_eq!(
                        phase_delta(&b[before], &b[after], 0, field),
                        0,
                        "warm hit must skip query construction"
                    );
                    assert_eq!(
                        phase_delta(&b[before], &b[after], 2, field),
                        0,
                        "the admitted Arc must feed the later numerical read"
                    );
                    for product in ["flattened", "processing"] {
                        for value in receipts[product].as_object().unwrap().values() {
                            assert_eq!(
                                value.as_u64(),
                                Some(0),
                                "early warm hit performs no constructor/issuer work: {product}"
                            );
                        }
                    }
                    for phase in [0, 2] {
                        assert_eq!(
                            integer(&b[after]["phase_work"]["calls"][phase])
                                - integer(&b[before]["phase_work"]["calls"][phase]),
                            0,
                            "early warm hit enters no Queries or OriginalRead scope"
                        );
                    }
                    if lane == 0 {
                        assert!(phase_delta(&b[before], &b[after], 3, field) > 0);
                        assert!(new_total < old_total, "measured net warm work must improve");
                    }
                }
                lanes.insert(
                    field.into(),
                    json!({
                        "legacy": old_total, "warm": new_total,
                        "actual_delta": new_total - old_total,
                        "phase_deltas": phases,
                        "query_receipts": receipts,
                    }),
                );
            }
            intervals.push(json!({"interval": name, "lanes": lanes}));
        }
        records.push(json!({"name": a["name"], "context": a["context"], "intervals": intervals}));
    }
    json!(records)
}

fn observations() -> Value {
    let old: Value = serde_json::from_str(include_str!(
        "../../tests/fixtures/cached-original-prediction-baseline-v1/snapshot.json"
    ))
    .unwrap();
    let legacy = cached_prediction_trace::with_legacy(cached_prediction_baseline::matrix);
    assert_eq!(
        without_query_traces(legacy.clone()),
        old,
        "immutable pre-fast-path full observation witness"
    );
    let warm = cached_prediction_baseline::matrix();
    let reconciliation = compare(&legacy, &warm);
    let old_zero: Value = serde_json::from_str(include_str!(
        "../../tests/fixtures/cached-original-zero-prediction-baseline-v1/snapshot.json"
    ))
    .unwrap();
    let legacy_zero = cached_prediction_trace::with_legacy(cached_prediction_baseline::zero_matrix);
    assert_eq!(
        without_query_traces(legacy_zero.clone()),
        old_zero,
        "immutable pre-fast-path zero Source witness"
    );
    let warm_zero = cached_prediction_baseline::zero_matrix();
    let zero_reconciliation = compare(&legacy_zero, &warm_zero);
    json!({"legacy": legacy, "warm": warm, "reconciliation": reconciliation,
        "legacy_zero": legacy_zero, "warm_zero": warm_zero,
        "zero_reconciliation": zero_reconciliation})
}

#[test]
fn warm_cached_prediction_preserves_old_pcm_policy_admission_and_reconciles_actual_work() {
    observations();
}

#[test]
#[ignore = "writes the verified current warm/legacy native observations"]
fn produce_current_cached_prediction_observations() {
    use std::io::Write;
    let path = std::env::var_os("DEADPAN_CACHED_PREDICTION_CURRENT").expect("set new output path");
    let observed = observations();
    let mut file = std::fs::OpenOptions::new()
        .write(true)
        .create_new(true)
        .open(path)
        .unwrap();
    file.write_all(&serde_json::to_vec_pretty(&observed).unwrap())
        .unwrap();
    file.write_all(b"\n").unwrap();
}
