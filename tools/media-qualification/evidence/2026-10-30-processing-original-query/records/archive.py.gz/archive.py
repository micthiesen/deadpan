from pathlib import Path
import gzip
import hashlib
import json

s = Path(__file__).resolve().parent
repo = Path('/Users/michael/Code/deadpan')
dest = repo / 'tools/media-qualification/evidence/2026-10-30-processing-original-query'
assert not (dest / 'inventory.json').exists()
audit = json.loads((s / 'final-audit.json').read_text())
assert audit['all_terminal'] and audit['split']['passed'] == 3 and audit['split']['failed'] == 4
prior = repo / 'tools/media-qualification/evidence/2026-10-30-flattened-original-query/inventory.json'
prior_sha = 'da468abbc02564b401f386cd55b9e68171edc0bc6d4a20a887844a868550a2da'
assert hashlib.sha256(prior.read_bytes()).hexdigest() == prior_sha
rows = []
allowed = {'.rs', '.json', '.py', '.md', '.patch', '.stdout', '.stderr', '.txt', '.sha256', '.toml'}
for p in sorted(s.rglob('*')):
    if not p.is_file() or p.suffix not in allowed:
        continue
    rel = p.relative_to(s)
    if rel.name in {'qualification-draft.md', 'published-evidence.json'}:
        continue
    data = p.read_bytes()
    empty_new_file_baseline = not data and rel.parts[0] == 'published-before'
    if p.suffix == '.json' and not empty_new_file_baseline:
        obj = json.loads(data)
        if isinstance(obj, dict) and 'command' in obj and 'started_at' in obj:
            assert 'exit_code' in obj and obj['sources_unchanged'] and obj['binaries_unchanged'], str(p)
    target = (dest / 'records' / rel).with_name(rel.name + '.gz')
    target.parent.mkdir(parents=True, exist_ok=True)
    packed = gzip.compress(data, mtime=0)
    target.write_bytes(packed)
    rows.append({
        'path': str(target.relative_to(dest)), 'bytes': len(packed),
        'sha256': hashlib.sha256(packed).hexdigest(), 'expanded_bytes': len(data),
        'expanded_sha256': hashlib.sha256(data).hexdigest(),
    })
manifest = {
    'schema_version': 1,
    'base_revision': (s / 'base-revision.txt').read_text().strip(),
    'scope': 'Actual Root/physical-Domain Original processing-query construction admission, narrow guarded Core composition, sealed first-policy witness, paired independent OLD nested values, actual host lifetimes/debits and finite native pressure tests. Recursive policy/fade construction, remaining containers and full recursive admission remain open. General sound-bearing Split stays disabled; no requirement or gate closes.',
    'prior_flattened_inventory': {
        'path': '../2026-10-30-flattened-original-query/inventory.json', 'sha256': prior_sha,
    },
    'exclusions': 'Executables, nontext batch blobs and entire filesystem copies excluded. Exact assigned before/candidate/shipping sources, patch, source/executable/stream hashes, failed and passing receipts, actual observations and independent review reports retained. Main diagnostic overlay preserves only Rust sources differing from the published candidate; it is research context, not shipping feature code. Runtime implementation source matches the published candidate. One later module-scope documentation correction is separately byte-proved; strict checks run afterward. This checkpoint adds narrow Core composition.',
    'files': rows,
}
p = dest / 'inventory.json'
assert {str(x.relative_to(dest)) for x in dest.rglob('*') if x.is_file()} == {row['path'] for row in rows}
p.write_text(json.dumps(manifest, indent=2) + '\n')
for row in rows:
    packed = (dest / row['path']).read_bytes()
    plain = gzip.decompress(packed)
    assert len(packed) == row['bytes'] and hashlib.sha256(packed).hexdigest() == row['sha256']
    assert len(plain) == row['expanded_bytes'] and hashlib.sha256(plain).hexdigest() == row['expanded_sha256']
result = {
    'files': len(rows), 'stored_bytes': sum(row['bytes'] for row in rows),
    'expanded_bytes': sum(row['expanded_bytes'] for row in rows),
    'inventory_sha256': hashlib.sha256(p.read_bytes()).hexdigest(),
}
(s / 'published-evidence.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result))
