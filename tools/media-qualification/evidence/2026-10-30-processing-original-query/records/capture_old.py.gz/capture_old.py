from pathlib import Path
import hashlib
import json
import os
import subprocess
import sys

s = Path(__file__).resolve().parent
variant, build, label, output = sys.argv[1:]
assert variant in {'main', 'scoped'}
root = Path('/Users/michael/Code/deadpan') if variant == 'main' else Path('/tmp/deadpan-query-groundwork-2026-10-26/scoped')
pins = {}
for rel in json.loads((s / f'{variant}-logic-source-files.json').read_text()):
    data = (root / rel).read_bytes()
    pins[rel] = {'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}
manifest = s / f'{label}-runtime-sources.json'
assert not manifest.exists()
manifest.write_text(json.dumps(pins, indent=2) + '\n')
os.environ.update({
    'DEADPAN_PROCESSING_QUERY_OUTPUT': str(s / output),
    'DEADPAN_PROCESSING_QUERY_VARIANT': 'main-inherited' if variant == 'main' else 'scoped-published',
    'DEADPAN_PROCESSING_QUERY_SOURCE_SHA256': hashlib.sha256(manifest.read_bytes()).hexdigest(),
})
raise SystemExit(subprocess.run([
    'python', str(s / 'run_logic_target.py'), build, variant, 'plan', 'deadpan_plan', label,
    'plan::audio_owners::tests::legacy_snapshot_v1::processing_query_baseline::capture_old_processing_query_baseline_v1',
    '--ignored', '--exact', '--nocapture', '--test-threads=1',
]).returncode)
