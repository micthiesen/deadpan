# Current host processing lifecycle review

Read-only review of actual Scope sources. No repo edits, Git, Cargo, native execution or runtime verification. The author of the initial host integration performed this bounded follow-up review; it is not a fresh-context independent reviewer claim.

## Finding: completed constructor traces conflate actual host eviction debits with Plan receipt units

At sound_context_admission.rs:183 the real reserve adapter calls make_room. Its make_room_for loop (stages.rs:2494) may call evict_original_input. That real helper spends one existing host work unit per controller cache entry examined before evicting (shared_eq/original_inputs.rs:404 in this read). These cache entries occur in real authored/shared reads and are not hypothetical.

The processing/flat ScopeGuard spans each actual admitted constructor, including its reservation callbacks. flattened_work_trace.rs:186-189 requires the entire ReadWork lane delta to equal query.work. Under successful cache-pressure eviction, the delta contains query.work plus the separately performed host eviction scans. The trace therefore reports invalid=true despite correct production once-only billing. Failed constructor partial_work also currently includes those host scans as if they were Plan-forwarded partial units. This affects both products through the shared adapter. It is an evidence/conservation categorization defect, not a discovered production work refund or duplicate spend.

The requested fix is scratch-only in host-eviction-trace-candidate: record actual accepted eviction work at the existing debit site, keep product-local interleaved units separate from canonical/additional/partial Plan receipts, and compare paired OLD/current global eviction receipts before adjusting authored work counters. Do not infer the host amount merely as ledger delta minus Plan total or erase literal cache/residency differences.

## Remaining production lifecycle: no material findings in this bounded review

- prepare_processing_root forwards through the short Admission borrow and never successfully rebills processing.work. prepare_domain_policy uses the actual admitted sealed first query, closes its constructor trace before fresh remaining limits and finish_policy, and bills policy.work once afterward. Ordinary compatibility bills only exist under cfg(test).
- PreparedQueries owns both immutable carriers. query() exposes borrows only. The sealed Domain capability owns processing leases through complete-history reuse/fallback and releases them on finish failure. Later policy/fade/preparation errors drop previous carriers while accepted ReadWork units remain spent.
- read_prepared_original checks exact plan/domain origin and saved range/edge mode, then flat issuer and processing issuer before preflight/source access. Each comparison has its actual one-unit debit. On successful/error numeric return it drops the complete request before handing PCM to its caller. Earlier errors also drop the owned request.
- shared_original_input_mode validates the prepared request before cache lookup/touch or fresh source admission. A late hit returns with prepared still local, so its unused carriers drop on return. A cold prepared miss passes the owned request through the numeric boundary. Two issuer validations across this adapter and numeric read are separate actual boundaries; they do not re-forward constructor work.
- The policy population path borrows request.queries while prepared_original remains owned outside the closure. Its request is created locally using the same immutable control. No foreign externally supplied query can enter that producer path. Failure or unused branches retain the carrier until local cleanup.
- Early cached prediction probes occur before either actual constructor. A successful probe uses cached masks and fresh dependency admission and leaves prepared_original=None. The actual no-eviction reservation-fits check includes live sound_context_frames.
- Foreign issuer rejection occurs before query/source I/O in consuming boundaries. Under legacy flat with current processing only the processing comparison runs; under normal mode a foreign flat comparison short-circuits processing.
- Product-specific test scopes preserve cache/plan lane identity and close before unrelated policy/issuer work. Domain policy trace now records explicit canonical/additional fields and asserts their sum equals actual processing.work; recording does not change production bills. Legacy flags restore across nesting/unwind and do not enter production.

## Limits

Static source review only. No test execution was performed or inferred from test presence. Core/Plan allocation-site safety, native resource pressure behavior, paired Bound private work/history equivalence, all numeric DSP paths and authored golden equality remain their owners' verification. Existing cache/source validation and cap arithmetic were inspected only as needed to follow these host carriers. No claim about allocator/RSS peaks follows from requested Layout accounting.

## Input pins

- crates/deadpan-audio/src/original_request.rs: ba7e11a30c6d57c4991270021419625a15afc8318c2e14685b6dec012fa18b17
- crates/deadpan-audio/src/original_request/flattened_work_trace.rs: a0920e3baffdfbfb810ac8d827d46ea6fd724769af25274378a35d5e17c01160
- crates/deadpan-audio/src/original_request/domain_policy_trace.rs: 5b1de8fc39be693b60c9d13bf8c8b40de8ac7514a7bf4fe4f32987ab0eb76e56
- crates/deadpan-audio/src/shared_eq/original_inputs.rs: 5f956b4c2b054a62a2999f892b7436fdef088c584032a70faa1aefcb8a811475
- crates/deadpan-audio/src/shared_eq.rs: eeb3fadf3c4b241e5e52fb69e02850dfadbaad0ac8feb438d5df7a258eaa942e
- crates/deadpan-audio/src/shared_eq/policy_prediction.rs: 0813efabcc3ae641ea8435f55da42790e6222417063f22643c72db0a2314545b
- crates/deadpan-audio/src/sound_context_admission.rs: f15f6bba0ab8b4382f46dcf1ef369688a231b23f7f78855f7c14573f6df6884d
- crates/deadpan-plan/src/audio_domain.rs: 05ff57f77357cc0f65da701d9b125db24c9ce39b95ab25f91c96db136b9fd1a4
