# Shared query/Original pressure fixture candidate

## What changed

This scratch patch touches only copies of `cached_probe_tests.rs` and `original_inputs_tests.rs`.

- The cached-probe fixture first prepares a real admitted Root owner query and two real WAV-backed `Read::Cached` Original inputs at ample capacity. It then imposes the exact `cached + live metadata + 37` ceiling (or one frame less) immediately before the measured prediction probe. The 672-frame, two-entry warm state is still asserted before the ceiling is applied and the probe's existing hit/decline assertions remain unchanged.
- A separate cold-path subcase uses the exact ceiling from the original failure, constructs the query first, then seeds the two actual inputs and asserts the optional payload residency is below the 672-frame ample reference. This records the constructor/read-time eviction effect instead of weakening the warm-cache invariant.
- The optional-publication fixture separately asserts that cold query construction at `PCM payload + metadata` fails with `Limit("resident PCM or stage cache")` and leaves no sound-context residency. Its exact/one-short publication checks then hold the real Root query alive and the real WAV-backed candidate result is read only after imposing the target cap. They retain all sample/metadata equivalence and optional-cache-versus-fresh assertions, including aggregate retained residency checks.

The host run at `host-scoped-lib.stdout` supports the specific fixture diagnosis: the warm case failed at the two-payload equality (`336` actual, `672` reference), and the optional-input case failed in `owners_admitted` with `Limit("resident PCM or stage cache")`. The added cold assertions describe those as pressure behavior; they do not claim the target retained-state cap covers construction peaks.

## Scratch patch

- `cached.patch`
- `original_inputs.patch`

Both files are copies under this directory; no repository files were edited.

## Checks still owed

Run the two focused tests in the parent-owned build after integrating these patches:

- `stages::shared_eq::original_inputs::tests::cached_probe::early_probe_respects_exact_future_reservation_with_actual_live_owner_metadata`
- `stages::shared_eq::original_inputs::tests::original_input_optional_cache_respects_live_owner_query_metadata_budget`

Then rerun the host-scoped library suite, since the test fixture modifications only have static review here. In particular confirm (1) the cold cached-probe case retains less than the measured two-payload total and cleans to zero, (2) the cold-owner failure is exactly the stated resident-limit error with zero leaked lease, and (3) exact/one-short warm probe and optional publication still return the expected outcomes.

## Limits / uncertainty

No build or test was run for this scratch candidate. The two cold assertions are based on the parent-provided failures and exact test call sites, not a new execution. If a later query implementation changes the precise cold failure/eviction point, keep the warm publication checks separate and update only the cold-path observation to the actual behavior; do not raise the budget or relax the 672-frame warm expectation.
