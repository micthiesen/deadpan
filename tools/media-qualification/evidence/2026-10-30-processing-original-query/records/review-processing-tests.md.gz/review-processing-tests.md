# Processing-query admission test review

## Finding

1. **Minor** — crates/deadpan-plan/src/audio_owners/processing_query_admission_tests.rs:547-579, 581-647 — Add one narrow source-identity layout differential for actual Root and Domain queries. The empty-query test independently proves only project/revision headers. The input/output overlap test uses stable_repeat_plays_default_gap_and_overrides, whose fixture has no assets or SourceAudio, so it exercises vector overlap but not owning source edges. Source-containing cases are present in the broad matrix and retained-storage checks require measured heap bytes to be <= policy live bytes, but that inequality can pass when an omitted asset-identity lease is masked by other conservative/duplicate reservations. Use old ordinary query output to count source-asset owning edges, vary only the asset-id length in otherwise equivalent checked Root and physical-Domain inputs, and assert the admitted reserved-byte delta equals the count times the independent Arc-plus-string identity-layout delta. This would directly regress the specific edge omission without duplicating the wider admission matrix.

## Otherwise

The Root overlap assertion is substantive: it observes the exact output reserve while the input vector is live, then checks that only the exhausted eight-slot input buffer is released, and the selected fixture has five returned spans. The metered comparisons preserve all frozen fields except the two explicitly deferred Bound receipt work leaves, while checking those leaves are monotonic and confirming canonical/additional totals against actual forwarded work. Callback refusal, cancellation, issuer rotation, zero-query headers, exact/short work, byte caps, carrier drop, and positive span limits all have concrete ledger assertions.

## Limits

Read-only source review only. No Cargo/test run was performed. Existing test receipt was accepted as caller-provided context; this review verifies assertions and fixture/source wiring statically.
