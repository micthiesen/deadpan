# Scoped publication boundary review

Current extension: 48 paths, 33 existing and 15 new, after the late three-line Rustdoc correction described at the end. That extension supersedes the original 47-path counts and patch hash below. The original 47 runtime-pinned files remain byte-identical; no compile/run claim is made for the later comment.

No boundary finding. Reviewed shipping-source.patch and the supplied source inventories/snapshots without Git, Cargo, native execution or repository writes. All findings apply to the observed source snapshot; final docs/evidence publication and the live native batch remain parent-owned.

## Patch and inventory

- Published inventory has exactly 47 unique paths: 32 existing source files and 15 additions.
- Independently parsed every unified patch section and hunk, checked all old context/deleted lines and hunk counts, reconstructed results in memory, and compared all results byte-for-byte with published-source. All 47 match; no missing, duplicate or extra path.
- Every published-source file is byte-identical to current Scope at review time.
- All 32 existing before files equal their members in the supplied exact-checkpoint base-source.tar and equal scoped-initial-authority SHA pins. None of the 15 additions exists in that archive. published-before contains an empty placeholder for each addition; the patch correctly uses /dev/null for these files, not an overwrite of an existing baseline file.
- The supplied scoped-baseline-head-equality table contains 32 existing and 15 new entries, all true, consistent with this independent archive/hash check. Without running Git, this audit treats the owner's archive-to-0db3ccd89998513d01ed55109572445775a6b13f attribution as supplied provenance rather than separately querying commit storage.

shipping-source.patch SHA-256: 73ee0e6a0b72ddd9db235115156fc99000ed9aef83c20334dc0fcb91943d64e2.

## Main inherited work stays separate

Compared every initial authority input against its current root: 2,443 Scope entries and 2,771 Main entries. Both roots have exactly the 32 selected existing changes, no initial input removed, and no initial file changed outside the 47-path publication boundary. A separate rg Rust-file inventory finds no new .rs path outside that boundary in either root. This does not classify unpinned media, license or auxiliary fixture files as newly introduced files.

Main differs from the selected published Scope sources in exactly three files:

1. shared_eq/cached_prediction_baseline.rs retains selected_family_count and canonical_families Graph fields. The actual difference is these two fields, not a module declaration.
2. shared_eq/original_inputs_tests.rs retains the same two Graph family fields.
3. deadpan-plan/src/plan.rs retains the existing sound-clock correspondence/asset/delivery caches and their scope behavior.

For an independent preservation check, located scratch Main bodies whose complete SHA matches each file's main-initial-authority pin: baseline-routing-before/main/.../cached_prediction_baseline.rs, host-tests-integration-before/main/.../original_inputs_tests.rs and witness-before/main/.../plan.rs. Computed their textual additions/deletions relative to the frozen Scope before bodies, then compared with current Main versus published Scope. All three inherited delta sequences are unchanged. This proves the current shipping edits did not accidentally absorb, erase or rewrite those Main-only changes.

Other inherited Main/Core/family changes are outside the publication list and still match their own initial pins. In particular, the broad Main differences in audio_binding.rs, audio_reference.rs, sound clocks, shared_eq.rs and related files do not enter this patch. The scoped patch should remain applied to the clean checkpoint branch; copying Main files would destroy this separation.

## Core API and cap boundary

The only Core publication paths are audio_binding/admission.rs, audio_binding/admission/tests.rs and the new admission/composition_tests.rs. Production Core change is the narrow validated composition helper and private pending value/lease carrier. Existing map_value behavior and full resolver/clock/edit code are not changed by this patch. No new public raw-value extraction or unrestricted Core escape API appears. New Plan processing queries expose borrowed views/receipt scalars; their unmetered extraction remains crate::plan-private, and the completed Domain API returns an admitted carrier alongside ordinary policy.

Inspected changed production Rust declarations/assignments and publication inventory: no MAX_/LIMIT constant or numeric maximum_* cap is added/changed. Cargo manifests, Cargo.lock, toolchain, native code and build configuration are outside the 47 paths and remain initially pinned. Tests adjust remaining-work setup against actual preparation fees; they do not raise production caps. Ordinary API wrappers route through the shared false-admission path, with the frozen ordinary comparison still owed by actual tests rather than being excused by this review.

## Frozen body boundary

The new processing baseline snapshot body in published-source is byte-identical to processing-old-canonical-body.json from the earlier OLD capture. All previously existing fixture/expected inputs in the initial authorities remain unchanged outside the selected list. The three new baseline files are additions, not refreshed prior golden files. This audit generated no expected body or hash.

## Artifacts and limits

Detailed scratch observations: publication-audit-observations.json, publication-patch-reconstruction.json and publication-main-inherited-proofs.json. The first observations file's published-before extra list denotes the 15 expected empty new-file slots, not a publication leak; all were verified empty and /dev/null in the patch.

This is a publication boundary audit, not an independent comprehensive correctness review of all 47 implementations or a claim that current tests passed. Parent's native results and final docs/evidence still need their actual publication. If any source changes after the pinned shipping patch, regenerate/recheck publication snapshots and the boundary rather than claiming this report covers those later bytes.

## Final extension: late Rustdoc-only 48th path

Independently inspected post-native-doc-correction-proof.json and the regenerated published sources/patch. The only new selected path is crates/deadpan-plan/src/audio_sound_admission.rs, making 48 unique paths: 33 existing and 15 additions. Its exact original three-line module Rustdoc prefix describes flattened admission and separates Original processing; the new prefix correctly includes flattened and processing admission while keeping recursive policy/fades separate. It consists solely of //! comments, with no code, attributes or doctest block.

Verified the original prefix and replacement prefix literally, then compared the entire remaining file byte-for-byte. The remainder is unchanged. Original file SHA d6b412ae917e17d998247f80918f302795ad4042a2d99475370179c9920792f2 matches both initial authorities and its member in the supplied base-source archive. Final file SHA is e9fc2b9b4d83af8ad8442ccf03ec4fac432ac712608fd23fd91aac145e49fbe5 in both roots and published-source.

For both roots, runtime-source-pins still contains exactly the original 47 entries. Every one is identical in final-source-pins, which contains exactly those 47 plus the Rustdoc file. All 48 final pins match their actual root files. Rechecked all initial authority entries outside the final 48-path set: no change or removal in either root. The previously proved three inherited Main deltas are unaffected because none of their runtime-pinned bytes changed.

Independently parsed and reconstructed every hunk of the regenerated 48-section shipping-source.patch again. All results equal published-source exactly, and patch paths equal the final 48-path inventory with no duplicate/extra/missing path. Regenerated shipping patch SHA-256: ce86c0784c9bb732db1028f3d2ba82de5e19bdad8939ef74fc974a58582a37da. No new publication boundary finding.

Parent reports completed ordinary native coverage for Main/Scope (Audio 408/402, Stage 203/203 and Definition 171/171), exact current-eight body equality and the existing Split 3-pass/4-fail result. This review did not execute those runs and does not claim the later Rustdoc bytes were compiled. The preserved 47-file runtime pins and explicit comment-only proof keep that evidence boundary visible; no runtime rerun or behavior equivalence is inferred from an unexecuted compile.
