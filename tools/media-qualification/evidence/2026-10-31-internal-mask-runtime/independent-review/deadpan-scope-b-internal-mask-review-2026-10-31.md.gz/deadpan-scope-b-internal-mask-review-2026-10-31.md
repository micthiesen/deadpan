# Scope B internal suppression-mask production review

Reviewed source: /tmp/deadpan-query-groundwork-2026-10-26/scoped, published pin e8fcdb3 as supplied by parent. Read-only review; no build/test result.

Current production file SHA-256 pins:
signal_transfer_controlled.rs 9c1f29731e1277ce8ad91770c2d7d6dd38d6756c2ccd6a241dde601475ca49a6
mask_transfers.rs a330264b53b81b2bf5e34c50c75ce9ef939b7d057ad41c7074d5917e43ec9f8e
mask_context.rs ca66d52bd1489702745f1b26719846456ad51c8133d8d3090f76e490897b00b1
point_suppression.rs ca1799a145f7ae6eaf39ae025530cdbccef8e502688c1ec4679cbca979c7ec42
point_suppression/mutations.rs ab2f3680984d319e5c35400d815bbbd8061710e4e0f8b957617641cfc5d4975b
point_suppression/ops.rs 08932e4792060b2cb91e19b6ecc02f502519d7374b42c10138698924f0523d63
point_suppression/projections.rs df21ba252bebab1d4c59874a2e2de7e7ea73bddcf55a5f2de928716b5ae9dd10
stages.rs c9e1b1d2403f07aa7dfc17fcea65004a9dfa954c344a9f0406342a2fe8846cb4
authored_eq.rs 57c24cf1c5a4f469ff4bce2dae4cf99da9856be61197873e2ba8c1ed92848ac2
shared_eq.rs 18f9f2744f95f986d8b3b396e4f06b41dc5eb877f3372da28bf2becfffbef87c
shared_eq/original_inputs.rs dc0caf01de2dd7d869a71e03319f59d1c39a622dbc5db64174016477a1cd77eb
limited.rs 4224158fd38df95851131798ccaaa984b2cde77e5b441114890ec3c453882796
routed.rs 25438251bd81d7fca909d14f4346e1246cab95b418efbfa14c52f8a37e5b8b55
signal_mix.rs d4d9c7ad7f6a62ecde29aece573fab48d1e738b44ca0f786952e137790117ce0
voice_occurrence.rs 029d02ef0d7d841a272a80b9e034c8b1a372d2769ac5753ad1f92383c615cd83
voice_occurrences.rs 45a3388f7cec7d849575802d6f87a2c93be129b48ffda9f2d377d2e36fe3fa23
owner_equalizer.rs b83d0d41d4a11054d626f31574651e8dfb078410ed40b3ca4de668b2bbc7c5fa
projected_root.rs 0da2455a2b73a6e7fdc1e271a89d75335c3fa8a8e0d3e5a5df219f89311e312d
beat_sound_owner_input.rs 0543a24471bfecfa9867c9f2217d0bfa06583d2f7c92e1305953d6843ded7466
sound_events.rs ef8c8b278bad182104014ace85861df0d100c2863bc9b74fa329b1f1fb4a80da
retained_sound_input.rs 69556ade377a870adc81c4e503a0880204ff2112e9782f289eab7b96841567ce

## Findings

No material ownership, lifetime, double-accounting, cleanup, or numerical-parity defect found in reviewed paths.

Evidence:
- Admitted destination is Storage { ranges, charge } inside unique OwnedMask (point_suppression.rs:136-167). Custom Drop unboxes and destroys Vec before dropping ticket (154-161).
- RangeBuilder reserves before exact-capacity allocation, stores charge beside Vec, bounds pushes by capacity, and only publishes after checks (ops.rs:86-156). Error propagation drops builder/pending storage. begin_flags similarly holds charge beside scratch (ops.rs:42-83).
- Actual StageAudio controller admits account shell and payload before allocation (mask_context.rs:18-20, 64-75; stages.rs:334-356). make_room_for includes live account frames (stages.rs:2505-2547); each ticket subtracts its frame count on drop (point_suppression.rs:109-122), and last handle releases shell after Arc allocation (24-46).
- Controlled transfer keeps each input mask alive through validation, zeroing, and output marking; drops it before final output reservation (signal_transfer_controlled.rs:88-124, 154-179). Output is a separate admitted exact-capacity builder. Point-bound conversion maps through controlled context and moves the mask into SignalBlock (mask_transfers.rs:125-162).
- Owned map/try_map/extensions build charged destinations then release source only after checks (mutations.rs:62-116, 134-167, 202-245; projections.rs:21-105). In-place mutation only uses already reserved capacity. Owned merge sorts/compacts in place and truncates after successful checks (mutations.rs:305-355).
- Partial-progress error cases in append_exhausted, extend operations and owned merge propagate out of current render; no observed caller catches the error and reuses the mutated destination. append_clipped uses mem::take before merge, but production callers are local limited-result construction and propagate errors, so no published mask is silently lost (projections.rs:109-140; limited.rs:170, 271).
- Reviewed interval mapping, clipping, merge order and zeroing retained the expected boundaries; no math discrepancy found.

## Scope gaps

No build, tests, native executable, audio capture, Git command or source edit. Review followed the supplied owned-code-paths.json and focused on requested production paths. I did not audit every surrounding audio subsystem or independently verify the git object behind the supplied source pin.
