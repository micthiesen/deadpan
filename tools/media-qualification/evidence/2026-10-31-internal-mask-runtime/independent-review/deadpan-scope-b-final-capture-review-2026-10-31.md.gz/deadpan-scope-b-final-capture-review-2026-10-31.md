# Scope B final capture review (read-only)

Source: `/tmp/deadpan-query-groundwork-2026-10-26/scoped`; review date 2026-10-31. This is a mechanical review only; no build/native execution/Git.

## Finding

`bound_reads/retained_host_pairs.rs:62-69` returns early in after-capture mode after checking only `overflow` and `active_depth`. It also bypasses the existing `invalid == false` assertion at line 71. This does not alter receipt values, but it weakens validation of all active paired requests, including the invalid flag. The requested capture claim says prior invalid flags are preserved, which is true in serialized receipts; however the capture no longer fails if a request is newly marked invalid. Preserve the raw field and assert it remains false in active mode if valid-request invariance is intended. The accepted-work decomposition is reasonably skipped because native-mask work is now interleaved in the same top-level receipt and the per-query attribution fields do not include that lane.

## Confirmed capture/test properties

- `native_mask_after.rs:34-93` calls the same `captured_body_with_point(..., true)` request body and augments it with schema/scope and current internal observations. It does not rewrite per-request PCM, capacities, error flags, work fields, or prior captures. Capture output uses `create_new` and requires a `/tmp` parent.
- `raw_domain_host_baseline.rs` differs from its frozen before counterpart only by making `captured_body_with_point` `pub(super)` (signature/body otherwise equal). `retained_host_pairs.rs` additions are reset/receipt plumbing and after-mode assertions; its `invoke` keeps the legacy wrapper and scenario body unchanged.
- `internal_suppression_baseline.rs:769-799` emits ten actual internal scenarios plus four transfer observations and a whole-case trace. It explicitly limits its ownership claim and records public transfers separately. The native trace is a whole top-level request/case receipt, not falsely assigned to every nested query.
- `retained_owned_cache_tests.rs:223-329` compares real active retained read/map output to the legacy literal, and checks raw plus mapped mask ownership/drop lifetimes. Lines 331 onward verify actual Original cache publication, mask-excluded cache resident calculation, separately held account frames, Arc pinning, prediction ceiling at exact fit and one below, eviction/controller drop lifetimes. The `provider.calls > calls` cache-hit assertion is consistent with `original_inputs.rs:349-375`: hits still resolve and observe each source dependency fingerprint before returning, and do not reread audio or allocate a mask.
- `controlled_transfer_tests.rs` tests actual admitted controlled transfer paths, rejection/cleanup at admission and spend boundaries, numerical parity, and output surviving renderer destruction. Its synthetic callback drives real destination admission; the test does not claim WAV end-to-end coverage.
- `projections_tests.rs:169-176` places `clippy::vec_init_then_push` expectation on the literal Vec parity witness only; production mask code is outside that allow.

## Pins (SHA-256)

- `bound_reads/native_mask_after.rs` `5c48fd9589da42bd4acc31eda0ee8ac3cd3f7d08ad495acc8a37f03389d6fb72`
- `bound_reads/retained_host_pairs.rs` `41c029c8b84edd37796b225c305b6112372aaab7e53f4a070b64c07620fe8006`
- `bound_reads/raw_domain_host_baseline.rs` `09907ccc57a09d3f172618d3dc5f2e3ec6e6318353dca89e45e708cc5758920d`
- `bound_reads/internal_suppression_baseline.rs` `b3d697f5b5a416ab2e04831ccbc04759e7d71092ab221f1a2da0c184e522bbe2`
- `bound_reads/internal_mask_owned_tests.rs` `c5e6030acdaab6a3a56d558b7df369127ba8c411ee85103784fd5efd8160d9a0`
- `bound_reads/internal_transfer_entries.rs` `1a2e40edbc65bbad18111580068ad8e2a7174997e33f4955db83a003902dfde7`
- `point_suppression/controlled_transfer_tests.rs` `8f75d84fe5c5afb8ef6fc871c6660014d8d509ad978593f72759cad78acc7c4c`
- `shared_eq/retained_owned_cache_tests.rs` `33b516c5f642869c38fec60bb3f67fdb7b681ba50d217164e93dcfd1778967d9`
- `shared_eq/original_inputs_owned_masks_tests.rs` `88e1361f3622fd3f533598eac516e8c689f52627eb7379e699d5a292341e69b6`
- `point_suppression/projections_tests.rs` `c3f4d1e84447186a00262f1cd3fe266ac0f27a4cfe781a635e12ccefb0af3272`

## Scope

Reviewed the active-runtime capture additions and ownership/capacity/lifetime test paths named by the task. Did not execute tests or inspect unrelated production modules. Full native capture/lint status is parent-reported, not independently verified here.
