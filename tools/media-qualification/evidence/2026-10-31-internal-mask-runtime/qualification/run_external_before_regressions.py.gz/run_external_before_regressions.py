from pathlib import Path
import json,subprocess,os
s=Path(__file__).resolve().parent
for variant,root in [('scoped',Path('/tmp/deadpan-query-groundwork-2026-10-26/scoped')),('main',Path('/Users/michael/Code/deadpan'))]:
 build=f'internal-mask-{variant}-postlint-all-build'
 pin=next(p for p in json.loads((s/(build+'-pins.json')).read_text()) if p['name']=='deadpan_audio')
 runner=s/('run_qualified.py' if variant=='main' else 'run_scoped_qualified.py')
 for short,key,fixture,test in [
  ('internal','DEADPAN_INTERNAL_SUPPRESSION_EXPECTED','internal-suppression-paths-baseline-v1','internal_suppression_paths_match_external_old_v1'),
  ('transfer','DEADPAN_INTERNAL_TRANSFER_EXPECTED','internal-transfer-entries-baseline-v1','transfer_entries::internal_transfer_entries_match_external_old_v1')]:
  env=os.environ.copy();env[key]=str(root/'crates/deadpan-audio/tests/fixtures'/fixture/'snapshot.json')
  label=f'internal-mask-{variant}-external-before-{short}-postlint'
  subprocess.run(['python',str(runner),'--binary',pin['path'],label,'--',pin['path'],'--ignored','--exact','stages::bound_reads::retained_host_baseline::internal_suppression_baseline::'+test,'--test-threads=1'],env=env,check=True)
