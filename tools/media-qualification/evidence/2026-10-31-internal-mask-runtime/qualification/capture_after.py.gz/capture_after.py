from pathlib import Path
import hashlib,json,os,subprocess,sys
s=Path(__file__).resolve().parent
variant,build,label=sys.argv[1:];assert variant in ['main','scoped']
root=Path('/Users/michael/Code/deadpan') if variant=='main' else Path('/tmp/deadpan-query-groundwork-2026-10-26/scoped')
receipt=json.loads((s/(build+'.json')).read_text())
assert receipt['exit_code']==0 and receipt['sources_unchanged']
pin=next(p for p in json.loads((s/(build+'-pins.json')).read_text()) if p['name']=='deadpan_audio')
assert pin['artifact']['profile']['opt_level']=='2' and pin['artifact']['profile']['overflow_checks'] and pin['artifact']['profile']['debug_assertions']
assert hashlib.sha256(Path(pin['path']).read_bytes()).hexdigest()==pin['sha256']
manifest={}
for absolute,h in receipt['source_after'].items():
 b=Path(absolute).read_bytes();assert {'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}==h,absolute
 manifest[str(Path(absolute).relative_to(root))]=h
fixture_pins={row['path']:row for row in json.loads((s/'workspace-fixture-copy-proof.json').read_text())}
for rel in json.loads((s/('source-files.json' if variant=='main' else 'scoped-source-files.json')).read_text()):
 if rel in manifest:continue
 assert rel in fixture_pins,rel
 data=(root/rel).read_bytes();h={'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}
 assert all(h[k]==fixture_pins[rel][k]for k in h)
 manifest[rel]=h
data=(json.dumps(manifest,sort_keys=True,separators=(',',':'))+'\n').encode()
digest=hashlib.sha256(data).hexdigest()
out=s/(label+'-body.json');assert not out.exists()
(s/(label+'-source-manifest.json')).write_bytes(data)
keys={'DEADPAN_INTERNAL_MASK_AFTER_OUTPUT':str(out),'DEADPAN_INTERNAL_MASK_AFTER_VARIANT':'main-inherited' if variant=='main' else 'scoped-published','DEADPAN_INTERNAL_MASK_AFTER_SOURCE_SHA256':digest,'DEADPAN_INTERNAL_MASK_AFTER_PUBLISHED_CHECKPOINT':(s/'base-revision.txt').read_text().strip()}
env=os.environ.copy();env.update(keys)
runner=s/('run_qualified.py' if variant=='main' else 'run_scoped_qualified.py')
test='stages::bound_reads::retained_host_baseline::pairs::native_mask_after::capture_active_internal_mask_after_v1'
subprocess.run(['python',str(runner),'--binary',pin['path'],label,'--',pin['path'],'--ignored','--exact',test,'--nocapture','--test-threads=1'],env=env,check=True)
run=json.loads((s/(label+'.json')).read_text())
assert run['exit_code']==0 and run['sources_unchanged'] and run['binaries_unchanged']
for k,v in keys.items():assert run['environment'][k]==v
body=json.loads(out.read_text());assert body.pop('variant')==keys['DEADPAN_INTERNAL_MASK_AFTER_VARIANT'] and body.pop('source_sha256')==digest
native=body['native_requests'];assert native.pop('variant')==keys['DEADPAN_INTERNAL_MASK_AFTER_VARIANT'] and native.pop('source_sha256')==digest
data=(json.dumps(body,sort_keys=True,separators=(',',':'))+'\n').encode()
sha=hashlib.sha256(data).hexdigest()
(s/(label+'-canonical.json')).write_bytes(data)
proof={'base_revision':keys['DEADPAN_INTERNAL_MASK_AFTER_PUBLISHED_CHECKPOINT'],'variant':variant,'source_inputs':len(manifest),'source_manifest_sha256':digest,'binary_sha256':pin['sha256'],'bytes':len(data),'sha256':sha}
(s/(label+'-proof.json')).write_text(json.dumps(proof,indent=2)+'\n')
print(json.dumps(proof))
