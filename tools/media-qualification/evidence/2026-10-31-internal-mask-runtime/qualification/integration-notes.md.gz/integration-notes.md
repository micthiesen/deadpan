# Runtime closure integration decisions

Base e8fcdb3cb02f9682bef53f6ba2709e8a5ad692d0. B production wiring is applied in both roots; test qualification remains in progress.
Builders and controlled transfer are scratch candidates owned by separate
agents. Parent owns shared types, all root integration, builds/native/Git.

Mask construction remains sealed. Public aliases for Audio/Signal may be
exported only when their actual public result fields receive owned masks.
Do not add public Vec From/Clone/detach/owning IntoIterator.

Legacy modes need two separate boundaries:
- New test-only internal legacy scope preserves pre-B native Vec path while
  keeping the currently active public Reference owner. This is how exact
  before oracle29 (including36=26+10/invalidtrue) must be replayed.
- Existing with_legacy_point_suppression must also enter internal legacy mode
  to preserve pre-public-owner historical bodies27/28 and older chained
  point_content/raw ordinary lanes. It cannot consume an Owned input by
  detaching it. Historical Vec operations remain literal in Plain arms.

End of read_point_domain_controlled owns an actual admitted native copy of
its ordinary Signal policy output while that ordinary input remains alive.
The Plan policy itself is still unadmitted. read_signal_queries produces
policy masks independently and may legitimately drop consumed child masks
after numerical use. It does not inherit admission merely from child ownership.
Direct read_bound_at SilentHold/empty helpers also need context-aware native
owners when their nonempty mask escapes. Empty no-payload masks need no account.

All three transfer callsites use one StageTransferContext holding mutable
renderer/provider + original WorkControl + deps/depth. Controlled callback
gets &mut context. No captures borrow renderer/provider competitively.
Private controlled child in signal_transfer must use the same macos/linux
cfg as stages; public existing render remains portable and byte-exact.

Point public mapper accepts native mask. Plain old branch keeps exact
Vec into_iter/map/collect<Result<_,PlanError>> when existing public legacy
mode is selected. Owned branch allocates a separately charged Reference
destination while Signal source survives, no relabel/detach. Preserve actual
current public mapper trace phases independently; new native fees are new.

Direct destination operations:
- Plain+Plain extend executes old Vec.extend(Vec).
- Plain append exhausted executes old Vec.append(&mut Vec), preserving
  exhausted allocation/capacity lifetime.
- Plain merged_suppression executes its exact sort_unstable_by_key,
  Vec::with_capacity(ranges.len), consuming merge body.
- Plain fallible/infallible map and filter_map retain their exact
  Vec.into_iter/map/collect iterator and error type specializations.
- Owned map keeps source through separately funded destination finish/check.
- Owned append in spare capacity mutates only after per-range accepted work.
  Otherwise fund full replacement while old destination and source live.
- Owned merge uses fallible in-place heapsort+compact, keeps capacity charge.
  Do not use a comparator unable to stop after a refused callback.
- Arbitrary owned extend iterators must never create an unadmitted temporary
  Vec. Bound size_hint upper (real internal callers) or use fully admitted
  replacement growth; check every actual insertion/copy before operation.
- Routing for-loops that previously consumed child masks need explicit Plain
  loop arm and Owned charged mapped/extended destination, not borrowed clone
  then loss of charge.

ReadBlock::suppressed becomes opaque because direct sound Point label map
moves into ReadBlock. Its exhausted Vec is separate and may remain ordinary.
Receiving public block Clone derives must be removed as needed; no actual
production whole-block clones were found in prior surface study, but compiler
and exact caller search must verify.
Original cache resident formula keeps old mask capacity bytes for Plain;
Owned payload is already in controller account, so count zero there while
retaining outer block/Arc/PCM/dependency/exhausted charges.

Shared component mix creates an independent bus policy allocation through
Output.suppressed &mut Vec. Do not post-hoc tag that output as admitted simply
because it consumed an owned input. This independent product is outside this
unit unless separately adapted before its allocation and existing Graph
reservation ownership is handled without double billing.

Old whole744 native and eight-case frozen bodies must retain exact legacy
replays. Current B runs will intentionally have separate host work, residency,
possibly owned capacities/errors; preserve complete actual after bodies and
independent explicit assertions. Do not normalize before fields to claim
equality or inflate canonical Plan query weights. All30 before payload bytes fixed.

Additional actual surface discovered by exact search:
owner_equalizer.rs output/internal masks; limited.rs mask-bearing output/tiles;
signal_mix.rs direct moves; voice_occurrence.rs/voice_occurrences.rs outputs;
projected_root.rs; beat_sound_owner_input.rs; event_returns.rs fresh construction.
These may require opaque fields or explicit Plain wrappers. Do not silently
copy an owned mask into their old Vec. shared_eq::Block Graph bus destination
remains independent Vec and must be wrapped Plain at its actual boundary.

Two Main target files have inherited production WIP distinct from Scope:
shared_eq.rs and beat_sounds.rs. Per-root before snapshots/pins are captured in
before/ and runtime-target-before-pins.json. Do not overwrite them with Scope.
Apply only common owned mutation hunks to each variant separately, preserve
their permission-family and dormant-occurrence changes. Other initial11target
source files are byte-identical. Exclude full Main WIP snapshots from archives;
ship tested Scope blobs only and retain preservation hashes/narrow owned patches.

Old private consuming-Vec observer needs honest cfgtest Plain-only extraction:
a test-only closed method may match Plain and return its real Vec, but must
reject Owned rather than detach its charge or relabel borrowed iteration as
the old owning iterator. Only historical before replays should call it. New
actual owned observers must use borrowed immutable APIs and retain/drop owner.

Public mapper refinement: keep current admit_point_suppression(Vec,..) EXACT,
including its direct existing phase-prefix tests and original public legacy
Vec specialization. Add map_point_suppression(Mask<Signal>,..): Plain dispatches
to the qualified old method; Owned calls generic try_map<Reference,PlanError>
with actual context, retaining source through new funded destination. Public
read_point_domain uses this new dispatcher. Its Owned path uses independent
new native work trace; do not pretend it ran old public constructor phases.
Existing direct constructor tests stay meaningful without signature edits.
New actual Point-to-Reference tests must assert new overlap/phase/account data.

Additional adapter need from actual Arc caches:
limited.rs consumes CachedTile masks by shared borrow. Introduce a closed
borrowed-filter extension helper that checks source ownership BEFORE allocation,
keeps the actual source Arc/mask borrowed through completion, and funds a whole
replacement while old target+source remain live. Plain+Plain callers preserve
their literal old Vec loop/append or iterator expression. Do not clone an Owned
mask. For the limiter's Owned path, clipped filtered ranges may be appended to
a funded replacement and fallibly merged in place; all native owners are already
sorted by policy/controlled flags. Keep old Plain append_suppression exact.
PreparationBudget can provide a crate-private StageAudio mask context wrapper;
do not duplicate its WorkControl/deadline. No broad API exposing a mutable
owned Vec. Actual limited cache source/output/cached mask lifetimes need tests.

sound_events and voice_occurrences intersect masks. Preserve existing free
Vec intersect_suppression helper for exact Plain+Plain; Owned operands need
a separately funded typed destination while both borrowed sources stay live.
Bound upper capacity by checked left.len+right.len, per actual two-pointer
comparison/copy work; no unadmitted Vec from borrowed Owned ranges.

Diagnostic Resident byte metrics are not automatically the same as residency
caps. Original cache resident formula must omit globally accounted owned mask
payload from cap accounting; do not broadly remove true physical mask bytes
from unrelated diagnostics without proving they doublebill that same account.

Avoid changing unrelated independent producers merely to make every public
field opaque. ProjectedRootBlock creates an independent ordinary Plan policy
Vec and cannot receive an upstream Owned mask; keep its API/Clone as before,
wrap Plain only when its actual Vec moves into a generic ReadBlock.
OwnerEqualizer likewise consumes input masks numerically into its independent
admitted-bool product then generates a fresh ordinary policy Vec. Its public/
private masks need not become opaque just to reflect input ownership. That
independent derived policy/flag admission remains explicit later work, alongside
shared-components bus policy. Do not claim these independent outputs admitted.
Limited differs: it directly clips/copies masks borrowed from EdgeFadedBlock
under actual cache Arcs, so an Owned input requires separately funded copies.

ProjectedRoot owned edits were reversed using exact narrow patches; file should
match initial source fully. owner_equalizer is still unchanged. Prune unchanged
planned targets from owned-code-paths before final source/publication audit.

Seven pre-B library tests pin exact query work, eviction receipts, or old full bodies. They now enter the internal-only legacy scope around their unchanged bodies; old expectations and frozen data remain fixed. Active B tests separately assert the actual new native fees and account lifetime. First active held test failed because successful DSP caching can reduce the next read's peak; the corrected test retains every actual output until the unchanged cap refuses, asserts each real payload increment and failure cleanup, then drops all outputs and verifies recovery at that same cap.

Six controlled-transfer tests pass on the real Scope controller, including every small work prefix and cancellation/deadline gate. Initial three retained tests positively reached genuine retained Point and owned raw/Audio/cache outputs, but their assertions conflated raw PCM with EdgeFaded retained PCM and Original cache clear with DSP PCM cache clear. Parent retains the real boundary: compare EdgeFaded output with a separately executed literal legacy EdgeFaded read; after Original clear assert cached residency equals actual remaining prepared-DSP PCM. No production code/cap/weight changed for these test corrections.
