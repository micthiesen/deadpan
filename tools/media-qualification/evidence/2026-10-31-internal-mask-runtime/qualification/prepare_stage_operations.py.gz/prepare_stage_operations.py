from pathlib import Path
import difflib
p=Path('/tmp/deadpan-query-groundwork-2026-10-26/scoped/crates/deadpan-audio/src/stages.rs')
old=p.read_text();new=old
def replace(a,b,count=1):
 global new
 assert new.count(a)==count,(a,new.count(a),count)
 new=new.replace(a,b)
replace('let mut suppressed = Vec::new();','let mut suppressed = AudioSuppressionMask::default();')
replace('suppressed.extend(block.suppressed);','suppressed.extend(block.suppressed, &mut self.masks(control))?;')
replace('let suppressed = merged_suppression(suppressed);','let suppressed = suppressed.merge(&self.masks(control))?;')
replace('''        let mut block = self.read_domain_controlled(
            provider,
            domain,
            start,
            frames,
            WorkControl {
                cancelled,
                deadline: Instant::now() + timeout,
                work: &work,
            },
            0,
        )?;''','''        let control = WorkControl {
            cancelled,
            deadline: Instant::now() + timeout,
            work: &work,
        };
        let mut block =
            self.read_domain_controlled(provider, domain, start, frames, control, 0)?;''')
replace('block.suppressed.append(&mut block.exhausted);','block.suppressed.append_exhausted(&mut block.exhausted, &mut self.masks(control))?;',2)
replace('suppressed: merged_suppression(block.suppressed),','suppressed: block.suppressed.merge(&self.masks(control))?,',3)
replace('''            let suppressed = raw
                .suppressed
                .into_iter()
                .map(|range| {''','''            let suppressed = raw.suppressed.try_map(
                |range| {''')
replace('''                })
                .collect::<Result<Vec<_>, TimeError>>()?;
            let mut block = ReadBlock {''','''                },
                &mut self.masks(control),
            )?;
            let mut block = ReadBlock {''')
start=new.index('            let suppressed = raw.suppressed.try_map(')
end=new.index('            let mut block = ReadBlock {',start)
chunk=new[start:end];assert chunk.count('                    Ok(AudioSample(')==1
chunk=chunk.replace('                    Ok(AudioSample(','                    Ok::<_, TimeError>(AudioSample(')
new=new[:start]+chunk+new[end:]
s=Path('/tmp/deadpan-internal-suppression-runtime-2026-10-31')
(s/'stages-owned-operations-before.rs').write_text(old);(s/'stages-owned-operations-after.rs').write_text(new)
print('*** Begin Patch\n*** Update File: '+str(p))
for l in list(difflib.unified_diff(old.splitlines(True),new.splitlines(True)))[2:]:
 print('@@' if l.startswith('@@') else l,end='\n' if l.startswith('@@') else '')
print('*** End Patch')
