from pathlib import Path
import json,subprocess
s=Path(__file__).resolve().parent
for variant in ['scoped','main']:
 build=f'internal-mask-{variant}-postlint-all-build'
 pins=json.loads((s/(build+'-pins.json')).read_text())
 old={p['name']:p for p in json.loads((s/f'internal-mask-{variant}-all-target-build-v2-pins.json').read_text())}
 outcomes=[]
 for pin in pins:
  target=pin['name']
  if target=='deadpan_audio':
   label=f'internal-mask-{variant}-postlint-lib'
   record=json.loads((s/(label+'.json')).read_text());assert record['exit_code']==0
   outcomes.append({'target':target,'current_binary_sha256':pin['sha256'],'status':'current_library_pass','label':label});continue
  if pin['sha256']==old[target]['sha256']:
   label=f'internal-mask-{variant}-all-v1-'+target.replace('_','-')
   record=json.loads((s/(label+'.json')).read_text());assert record['exit_code']==0
   outcomes.append({'target':target,'current_binary_sha256':pin['sha256'],'status':'retained_identical_binary_pass','label':label});continue
  args=['--test-threads='+('4' if target in ['audio_definition','stages','composite_insert'] else '1')]
  if variant=='main' and target=='stages':args+=['--skip','general_split_sound::']
  label=f'internal-mask-{variant}-postlint-'+target.replace('_','-')
  result=subprocess.run(['python',str(s/'run_target.py'),build,variant,'audio',target,label,*args])
  record=json.loads((s/(label+'.json')).read_text())
  outcomes.append({'target':target,'current_binary_sha256':pin['sha256'],'status':'current_binary_pass' if result.returncode==0 else 'failed','label':label,'exit_code':result.returncode,'sources_unchanged':record['sources_unchanged'],'binaries_unchanged':record['binaries_unchanged'],'args':args})
  (s/f'internal-mask-{variant}-postlint-final-matrix.json').write_text(json.dumps(outcomes,indent=2)+'\n')
 (s/f'internal-mask-{variant}-postlint-final-matrix.json').write_text(json.dumps(outcomes,indent=2)+'\n')
