impl StageAudio {
    pub(super) fn map_point_suppression(
        &mut self,
        input: SuppressionMask<SignalSample>,
        domain: &AudioPointDomain<'_>,
        control: WorkControl<'_>,
    ) -> Result<PointSuppressionMask, StageAudioError> {
        match input.value {
            // Preserve the already qualified Reference destination and historical
            // Vec specialization when the input itself has no native owner.
            Value::Plain(ranges) => self.admit_point_suppression(ranges, domain, control),
            Value::Owned(owner) => SuppressionMask {
                value: Value::Owned(owner),
            }
            .try_map(
                |range| {
                    Ok::<_, PlanError>(
                        domain.reference_at_signal(range.start)?
                            ..domain.reference_at_signal(range.end)?,
                    )
                },
                &mut self.masks(control),
            ),
        }
    }
}
