from pathlib import Path
import json,subprocess,sys
s=Path(__file__).resolve().parent
for variant in ['scoped','main']:
 build=f'internal-mask-{variant}-all-target-build-v2'
 pins=json.loads((s/(build+'-pins.json')).read_text())
 outcomes=[]
 for pin in pins:
  target=pin['name']
  args=['--test-threads='+('4' if target in ['audio_definition','stages','composite_insert'] else '1')]
  if variant=='main' and target=='stages':args+=['--skip','general_split_sound::']
  label=f'internal-mask-{variant}-all-v1-'+target.replace('_','-')
  result=subprocess.run(['python',str(s/'run_target.py'),build,variant,'audio',target,label,*args])
  record=json.loads((s/(label+'.json')).read_text())
  outcomes.append({'target':target,'label':label,'exit_code':result.returncode,'sources_unchanged':record['sources_unchanged'],'binaries_unchanged':record['binaries_unchanged'],'sha256':pin['sha256'],'args':args})
  (s/f'internal-mask-{variant}-all-v1-matrix.json').write_text(json.dumps(outcomes,indent=2)+'\n')
