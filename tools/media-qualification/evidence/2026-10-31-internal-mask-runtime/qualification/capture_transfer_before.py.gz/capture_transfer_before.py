from pathlib import Path
import hashlib,json,os,subprocess,sys
s=Path(__file__).resolve().parent;v=sys.argv[1];assert v in ['main','scoped']
root=Path('/Users/michael/Code/deadpan') if v=='main' else Path('/tmp/deadpan-query-groundwork-2026-10-26/scoped')
build=f'internal-transfer-{v}-before-build-v2'
subprocess.run(['python3',str(s/'pin.py'),build],check=True)
r=json.loads((s/(build+'.json')).read_text());assert r['exit_code']==0 and r['sources_unchanged']
pin=next(p for p in json.loads((s/(build+'-pins.json')).read_text()) if p['name']=='deadpan_audio')
assert pin['artifact']['profile']['opt_level']=='2' and pin['artifact']['profile']['overflow_checks'] and pin['artifact']['profile']['debug_assertions']
assert hashlib.sha256(Path(pin['path']).read_bytes()).hexdigest()==pin['sha256']
manifest={}
for absolute,h in r['source_after'].items():
 b=Path(absolute).read_bytes();assert {'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}==h,absolute
 manifest[str(Path(absolute).relative_to(root))]=h
data=(json.dumps(manifest,sort_keys=True,separators=(',',':'))+'\n').encode();digest=hashlib.sha256(data).hexdigest()
label=f'internal-transfer-{v}-before-v2';out=s/(label+'-body.json');assert not out.exists()
(s/(label+'-source-manifest.json')).write_bytes(data)
keys={'DEADPAN_INTERNAL_TRANSFER_OUTPUT':str(out),'DEADPAN_INTERNAL_TRANSFER_VARIANT':'main-inherited' if v=='main' else 'scoped-published','DEADPAN_INTERNAL_TRANSFER_SOURCE_SHA256':digest,'DEADPAN_INTERNAL_TRANSFER_PUBLISHED_CHECKPOINT':(s/'base-revision.txt').read_text().strip()}
env=os.environ.copy();env.update(keys)
runner=s/('run_qualified.py' if v=='main' else 'run_scoped_qualified.py')
test='stages::bound_reads::retained_host_baseline::internal_suppression_baseline::transfer_entries::capture_old_internal_transfer_entries_v1'
subprocess.run(['python3',str(runner),'--binary',pin['path'],label,'--',pin['path'],'--ignored','--exact',test,'--nocapture','--test-threads=1'],env=env,check=True)
run=json.loads((s/(label+'.json')).read_text());assert run['exit_code']==0 and run['sources_unchanged'] and run['binaries_unchanged']
for k,value in keys.items():assert run['environment'][k]==value
body=json.loads(out.read_text());assert body.pop('variant')==keys['DEADPAN_INTERNAL_TRANSFER_VARIANT'] and body.pop('source_sha256')==digest
data=(json.dumps(body,sort_keys=True,separators=(',',':'))+'\n').encode();sha=hashlib.sha256(data).hexdigest()
(s/(label+'-canonical.json')).write_bytes(data)
proof={'base_revision':keys['DEADPAN_INTERNAL_TRANSFER_PUBLISHED_CHECKPOINT'],'variant':v,'source_inputs':len(manifest),'source_manifest_sha256':digest,'binary_sha256':pin['sha256'],'production_runtime_unchanged':True,'bytes':len(data),'sha256':sha}
(s/(label+'-proof.json')).write_text(json.dumps(proof,indent=2)+'\n');print(json.dumps(proof))
for row in body['cases']:
 value=row.get('result_after_public_method_local_work_drop',{})
 print(json.dumps({'case':row['name'],'setup':row['setup']['status'],'result':value.get('status'),'error':value.get('error'),'mask_len':value.get('suppressed',{}).get('len'),'mask_capacity':value.get('suppressed',{}).get('capacity'),'mask_values':value.get('suppressed',{}).get('values'),'provider_calls':row.get('provider_calls')},separators=(',',':')))
