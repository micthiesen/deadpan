from pathlib import Path
s=Path(__file__).resolve().parent
old=(s/'before/scoped/crates/deadpan-audio/src/stages.rs').read_text()
start=old.index('    fn read_domain_transferred_controlled<')
end=old.index('    /// Read a bound physical recipe',start)
domain=old[start:end].rstrip()
domain=domain.replace('fn read_domain_transferred_controlled<','fn read_domain_transferred_legacy<',1)
anchor='                block.suppressed.append(&mut block.exhausted);\n                let suppressed = block\n                    .suppressed\n                    .into_iter()'
assert domain.count(anchor)==1
domain=domain.replace(anchor,'                let mut input = block.suppressed.into_legacy_vector();\n                input.append(&mut block.exhausted);\n                let suppressed = input\n                    .into_iter()')
anchor='            suppressed: block.suppressed,'
assert domain.count(anchor)==1
domain=domain.replace(anchor,'            suppressed: SignalSuppressionMask::plain(block.suppressed),')
extra=r'''
    pub(super) fn read_point_bound_transferred_legacy(
        &mut self,
        provider: &mut impl AudioSourceProvider,
        domain: &AudioPointDomain<'_>,
        transfer: &RootSignalTransfer,
        frames: u32,
        control: WorkControl<'_>,
        depth: usize,
    ) -> Result<SignalBlock, StageAudioError> {
        let mut dependencies = Dependencies::new();
        let mut relative_depth = 0;
        let block = transfer.render::<StageAudioError>(
            SignalSample(0),
            frames,
            control.cancelled,
            |storage, count| {
                raw_domain_query_trace::nested_callback(raw_domain_query_trace::Product::Point);
                let reference = domain.reference_at_signal(SignalSample(storage.0))?;
                let block = self.read_point_domain_controlled(
                    provider, domain, reference, count, control, depth,
                )?;
                dependencies.extend(block.dependencies);
                relative_depth = relative_depth.max(block.relative_depth);
                Ok(RootSignalBlock {
                    start: storage,
                    samples: block.samples,
                    suppressed: block
                        .suppressed
                        .into_legacy_vector()
                        .into_iter()
                        .map(|range| AudioSample(range.start.0)..AudioSample(range.end.0))
                        .collect(),
                })
            },
        )?;
        control.check()?;
        Ok(SignalBlock {
            samples: block.samples,
            dependencies,
            suppressed: SignalSuppressionMask::plain(block.suppressed),
            relative_depth,
        })
    }

    pub(super) fn read_root_transferred_legacy(
        &mut self,
        provider: &mut impl AudioSourceProvider,
        transfer: &RootSignalTransfer,
        start: SignalSample,
        frames: u32,
        control: WorkControl<'_>,
    ) -> Result<crate::signal_transfer::ControlledTransferredBlock, StageAudioError> {
        let block = transfer.render::<StageAudioError>(
            start, frames, control.cancelled, |at, count| {
                let mut block = self.read_controlled(provider, at, count, control, false, 0)?;
                let mut suppressed = block.suppressed.into_legacy_vector();
                suppressed.append(&mut block.exhausted);
                Ok(RootSignalBlock {
                    start: block.start,
                    samples: block.samples,
                    suppressed,
                })
            },
        )?;
        Ok(crate::signal_transfer::ControlledTransferredBlock {
            start: block.start,
            samples: block.samples,
            suppressed: SignalSuppressionMask::plain(block.suppressed),
        })
    }
'''
text='//! Exact pre-ownership native transfer operations for frozen test replays.\nuse super::*;\n\nimpl StageAudio {\n'+domain+'\n'+extra+'}\n'
dest=s/'legacy_mask_transfers.rs';assert not dest.exists();dest.write_text(text)
print('Prepared historical concrete Vec transfers without an Owned detach.')
