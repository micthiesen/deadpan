import os
import subprocess

env = dict(os.environ, DEADPAN_CHECK_OUTPUT='/tmp/deadpan-native-trim-ui-20261001/checks')
recorder = '/tmp/deadpan-ripple-trim-20261001/run-check.py'
checks = [
 ('native-trim-audition-fmt', ['fmt', '--all', '--', '--check']),
 ('native-trim-audition-clippy', ['clippy', '-p', 'deadpan-app', '--all-targets', '--locked', '--features', 'ui-harness', '--', '-D', 'warnings']),
 ('native-trim-audition-ui-tests', ['test', '-p', 'deadpan-app', '--locked', '--features', 'ui-harness']),
 ('native-trim-release-performance-audition', ['run', '-p', 'deadpan-app', '--release', '--locked', '--features', 'ui-harness', '--', '--ui-check', '--mode', 'performance', '--output', '/tmp/deadpan-native-trim-ui-20261001/performance-audition', '--kestrel-source', '/Users/michael/.dotfiles/kestrel/Sources/Kestrel/Shortcuts.swift']),
 ('native-trim-release-native-build', ['build', '-p', 'deadpan-app', '--release', '--locked']),
]
for name, args in checks:
 result = subprocess.run(['python3', recorder, name, 'rustup', 'run', '1.97.1', 'cargo', *args], env=env)
 if result.returncode:
  raise SystemExit(result.returncode)
