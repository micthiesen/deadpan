import os
import subprocess

environment = dict(os.environ, DEADPAN_CHECK_OUTPUT='/tmp/deadpan-native-trim-ui-20261001/checks')
recorder = '/tmp/deadpan-ripple-trim-20261001/run-check.py'
prefix = ['rustup', 'run', '1.97.1', 'cargo']
checks = [
    ('native-trim-final-fmt', ['fmt', '--all', '--', '--check']),
    ('native-trim-final-harness-clippy', ['clippy', '-p', 'deadpan-app', '--all-targets', '--locked', '--features', 'ui-harness', '--', '-D', 'warnings']),
    ('native-trim-release-performance-corrected', ['run', '-p', 'deadpan-app', '--release', '--locked', '--features', 'ui-harness', '--', '--ui-check', '--mode', 'performance', '--output', '/tmp/deadpan-native-trim-ui-20261001/performance-corrected', '--kestrel-source', '/Users/michael/.dotfiles/kestrel/Sources/Kestrel/Shortcuts.swift']),
    ('native-trim-final-base-build', ['build', '-p', 'deadpan-app', '--locked']),
]
for name, args in checks:
    result = subprocess.run(['python3', recorder, name, *prefix, *args], env=environment)
    if result.returncode:
        raise SystemExit(result.returncode)
