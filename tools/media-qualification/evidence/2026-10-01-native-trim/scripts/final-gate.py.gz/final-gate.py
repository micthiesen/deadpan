import os
import subprocess

environment = dict(os.environ, DEADPAN_CHECK_OUTPUT='/tmp/deadpan-native-trim-ui-20261001/checks')
recorder = '/tmp/deadpan-ripple-trim-20261001/run-check.py'
prefix = ['rustup', 'run', '1.97.1', 'cargo']
checks = [
    ('native-trim-fmt-final', ['fmt', '--all', '--', '--check']),
    ('native-trim-workspace-clippy-final', ['clippy', '--workspace', '--all-targets', '--locked', '--', '-D', 'warnings']),
    ('native-trim-app-ui-clippy-final', ['clippy', '-p', 'deadpan-app', '--all-targets', '--locked', '--features', 'ui-harness', '--', '-D', 'warnings']),
    ('native-trim-workspace-tests-final', ['test', '--workspace', '--locked']),
]
for name, args in checks:
    result = subprocess.run(['python3', recorder, name, *prefix, *args], env=environment)
    if result.returncode:
        raise SystemExit(result.returncode)
