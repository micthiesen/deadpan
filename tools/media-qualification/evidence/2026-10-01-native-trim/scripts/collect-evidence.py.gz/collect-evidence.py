import gzip
import hashlib
import json
from pathlib import Path
import subprocess

scratch = Path(__file__).parent
repo = Path.cwd()
output = repo / 'tools/media-qualification/evidence/2026-10-01-native-trim'

def save(name, data):
    path = output / name
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(data)

def packed(name, data):
    save(name + '.gz', gzip.compress(data, mtime=0))

# Final admission is explicit; a newer failed diagnostic is never a final gate.
final_check_name = 'native-trim-reveal-wake-clippy'
visual_check_name = 'native-trim-reveal-wake-green'
final_check = json.loads((scratch / 'checks' / (final_check_name + '.json')).read_bytes())
visual_check = json.loads((scratch / 'checks' / (visual_check_name + '.json')).read_bytes())
for name, check in [(final_check_name, final_check), (visual_check_name, visual_check)]:
    if check.get('exit_code') != 0 or check.get('gate_exit_code') != 0 or not check.get('source_unchanged'):
        raise SystemExit('Final check not admitted: ' + name)
    if check['source_manifest_sha256'] != check['source_manifest_after_sha256']:
        raise SystemExit('Final check source changed: ' + name)
if final_check['source_manifest_sha256'] != visual_check['source_manifest_sha256']:
    raise SystemExit('Final lint and visual replay used different source inventories')
current_hash = final_check['source_manifest_sha256']
current = json.loads((scratch / 'checks' / ('source-' + current_hash + '.json')).read_bytes())
paths = subprocess.check_output(['git', '-c', 'core.fsmonitor=false', 'ls-files', '--cached', '--others', '--exclude-standard', '-z']).decode().split('\0')
actual = {name: hashlib.sha256((repo / name).read_bytes()).hexdigest() for name in sorted(set(paths))
          if name and (repo / name).is_file() and (Path(name).suffix in ('.rs', '.toml', '.lock', '.cpp', '.h', '.hpp', '.c', '.m', '.py') or name.startswith(('.cargo/', 'crates/', 'native/')))}
if actual != current:
    drift = [name for name in sorted(actual.keys() | current.keys()) if actual.get(name) != current.get(name)]
    raise SystemExit('Current complete source differs from final check: ' + repr(drift))
visual_command = visual_check['command']
final_visual = Path(visual_command[visual_command.index('--output') + 1])
if json.loads((final_visual / 'report.json').read_bytes())['failed']:
    raise SystemExit('Final visual report failed')
for source in (scratch / 'checks').glob('*.json'):
    if not source.name.startswith('source-') and 'exit_code' not in json.loads(source.read_bytes()):
        raise SystemExit('Unfinished check: ' + source.name)
output.mkdir()
checks = {}
for source in sorted((scratch / 'checks').iterdir()):
    if source.suffix not in {'.json', '.log'}:
        continue
    if source.name.startswith('source-') or source.suffix == '.log':
        packed('checks/' + source.name, source.read_bytes())
    else:
        report = json.loads(source.read_bytes())
        if 'exit_code' not in report:
            raise SystemExit('Unfinished check: ' + source.name)
        checks[source.stem] = report
        save('checks/' + source.name, source.read_bytes())

replays = []
directories = sorted(Path('/tmp').glob('deadpan-trim-visual-20261001-*'), key=lambda path: int(path.name.rsplit('-', 1)[1]))
directories.extend(scratch / name for name in ['performance-final', 'slip-investigation', 'performance-corrected', 'performance-audition', 'performance-error-priority'])
images = []
selected = {
    'Trim four accepted values under Overwrite': 'four-values',
    'Trim Before has the actual outgoing and incoming boundary frames': 'before-pair',
    'Trim measured stereo waveform and accepted status': 'waveform',
    'Trim feedback scrolled to handle details at minimum window size': 'feedback-details',
    'Trim current Proposed pair at minimum window size': 'minimum',
    'Zero audio context retains the exact picture proposal and usable Apply': 'audition-error',
    'Stopped Trim audition keeps its failure visible above the retained feedback': 'device-failure',
}
for directory in directories:
    source = directory / 'report.json'
    report = json.loads(source.read_bytes())
    packed('replays/' + directory.name + '.json', source.read_bytes())
    replays.append({
        'name': directory.name, 'failed': report['failed'], 'metadata': report['metadata'],
        'scenarios': [{
            'name': scenario['name'], 'checks': len(scenario['checks']),
            'failed': scenario['failed'], 'findings': scenario['findings'],
            'skipped': scenario['skipped'],
            'timings': [{'name': item['name'], 'summary': item['summary']} for item in scenario['timings']],
        } for scenario in report['scenarios']],
    })
    for scenario in report['scenarios']:
        captured = [step for step in scenario['steps'] if step.get('screenshot')]
        if scenario['failed'] and captured:
            step = captured[-1]
            name = 'images/' + directory.name + '-failure.png'
            save(name, (directory / step['screenshot']).read_bytes())
            images.append({'path': name, 'input': step['input'], 'semantic': step['semantic']})
        if directory == final_visual:
            # One final image for each selected state and viewport width.
            chosen = {}
            for step in captured:
                if step['input'] in selected:
                    width = int(step['semantic']['viewport_points'][0])
                    chosen[(selected[step['input']], width)] = step
            for (label, width), step in chosen.items():
                name = f'images/{label}-{width}.png'
                save(name, (directory / step['screenshot']).read_bytes())
                images.append({'path': name, 'input': step['input'], 'semantic': step['semantic']})
packed('replay-summary.json', (json.dumps(replays, indent=2) + '\n').encode())
packed('images/index.json', (json.dumps(images, indent=2) + '\n').encode())

for source in sorted((scratch / 'native').iterdir()):
    if not source.is_file():
        continue
    if source.suffix in {'.sqlite', '.log', '.py', '.txt'}:
        packed('native/' + source.name, source.read_bytes())
    elif source.suffix in {'.md', '.json', '.png'}:
        save('native/' + source.name, source.read_bytes())
for name in ['collect-evidence.py', 'prepare-native.py', 'snapshot-native.py', 'final-gate.py', 'after-focus-gate.py', 'performance-correction-gate.py', 'audition-correction-gate.py', 'error-priority-gate.py', 'scroll-guard-gate.py', 'reveal-wake-gate.py', 'inspect-slip-failure.py', 'integration-progress.md']:
    packed('scripts/' + name, (scratch / name).read_bytes())
packed('scripts/run-check.py', Path('/tmp/deadpan-ripple-trim-20261001/run-check.py').read_bytes())
packed('scripts/feedback-focus-root-v2.patch', Path('/tmp/deadpan-trim-feedback-focus-20261001/feedback-focus-root-v2.patch').read_bytes())
packed('scripts/reveal-wake.patch', Path('/tmp/deadpan-trim-reveal-wake-20261001/reveal-wake.patch').read_bytes())
packed('scripts/native-scroll-guard.patch', Path('/tmp/deadpan-trim-native-scroll-guard-20261001/native-scroll-guard.patch').read_bytes())
packed('scripts/error-priority.patch', Path('/tmp/deadpan-trim-error-priority-20261001/error-priority.patch').read_bytes())
save('replays/slip-wrapper-comparison.json', (scratch / 'slip-investigation/wrapper-comparison.json').read_bytes())

gate = checks['native-trim-workspace-tests-final']
workspace = json.loads((scratch / 'checks' / ('source-' + gate['source_manifest_sha256'] + '.json')).read_bytes())
changes = [name for name in sorted(current.keys() | workspace.keys()) if current.get(name) != workspace.get(name)]
environment = {
    'base_commit': final_check['base_commit'],
    'final_check': final_check_name,
    'final_visual_check': visual_check_name,
    'final_visual_directory': final_visual.name,
    'final_visual_source_manifest_sha256': visual_check['source_manifest_sha256'],
    'final_source_manifest_sha256': current_hash,
    'workspace_source_manifest_sha256': gate['source_manifest_sha256'],
    'changed_after_workspace_gate': changes,
    'source_files_rechecked': len(current),
    'os': subprocess.check_output(['sw_vers'], text=True).strip(),
    'chip': subprocess.check_output(['sysctl', '-n', 'machdep.cpu.brand_string'], text=True).strip(),
    'memory_bytes': int(subprocess.check_output(['sysctl', '-n', 'hw.memsize'], text=True)),
    'compiler': subprocess.check_output(['rustup', 'run', '1.97.1', 'rustc', '-Vv'], text=True).strip(),
}
save('environment.json', (json.dumps(environment, indent=2) + '\n').encode())
save('README.md', (scratch / 'evidence-readme.md').read_bytes())
inventory = {str(path.relative_to(output)): hashlib.sha256(path.read_bytes()).hexdigest()
             for path in sorted(output.rglob('*')) if path.is_file() and path.name != 'SHA256SUMS.json'}
save('SHA256SUMS.json', (json.dumps(inventory, indent=2) + '\n').encode())
print(json.dumps({'files': len(inventory), 'final_source': current_hash, 'changed_after_workspace': changes}))
