import os
import subprocess

environment = dict(os.environ, DEADPAN_CHECK_OUTPUT='/tmp/deadpan-native-trim-ui-20261001/checks')
recorder = '/tmp/deadpan-ripple-trim-20261001/run-check.py'
prefix = ['rustup', 'run', '1.97.1', 'cargo']
checks = [
    ('native-trim-focus-fmt', ['fmt', '--all', '--', '--check']),
    ('native-trim-focus-base-clippy', ['clippy', '-p', 'deadpan-app', '--all-targets', '--locked', '--', '-D', 'warnings']),
    ('native-trim-focus-ui-clippy', ['clippy', '-p', 'deadpan-app', '--all-targets', '--locked', '--features', 'ui-harness', '--', '-D', 'warnings']),
    ('native-trim-focus-base-tests', ['test', '-p', 'deadpan-app', '--locked']),
    ('native-trim-focus-ui-tests', ['test', '-p', 'deadpan-app', '--locked', '--features', 'ui-harness']),
    ('native-trim-release-performance', ['run', '-p', 'deadpan-app', '--release', '--locked', '--features', 'ui-harness', '--', '--ui-check', '--mode', 'performance', '--output', '/tmp/deadpan-native-trim-ui-20261001/performance-final', '--kestrel-source', '/Users/michael/.dotfiles/kestrel/Sources/Kestrel/Shortcuts.swift']),
    ('native-trim-final-base-build', ['build', '-p', 'deadpan-app', '--locked']),
]
for name, args in checks:
    result = subprocess.run(['python3', recorder, name, *prefix, *args], env=environment)
    if result.returncode:
        raise SystemExit(result.returncode)
