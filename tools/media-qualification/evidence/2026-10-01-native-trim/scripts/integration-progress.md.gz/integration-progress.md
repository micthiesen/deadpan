# Root integration progress

Backend base: `89f312429a4b4face407b3614bde47d0c0b12991`.
Native stages assembled with verified hashes using `assemble.py`.
Checkout holds subsequent corrections; original scratch stages remain frozen.

- First `cargo check -p deadpan-app --all-targets --locked --features ui-harness`
  passes (121.727 s). Its source inventory is in `checks/`.
- Removed unused JunctionVisual exterior/background raster storage and unused
  Input::issued / waveform Display::matches helpers. `gpu_work_pending` is
  feature-gated for pending harness drainage observations.
- Audition setup failures now use the visible app error notice; they cannot
  block structural Apply through Draft.error. Real replay regression is staged
  by the harness agent.
- First formatting found a nested playback test module path it could not
  resolve. Added explicit `#[path = "edit/admission.rs"]`; formatting passed.
- Audio waveform run: 11 library tests passed; 11/12 integration tests passed.
  Failure was the new root-sound fixture's missing qualified audio asset shape.
  Only that test fixture was corrected, with synthetic-provider scope explicit.
  Exact failed test then passed. All 23 focused tests are covered by these runs.
- All 20 playback waveform tests pass (44.981 s including compilation).
- Applied the amount-field correction from
  `/tmp/deadpan-trim-amount-accept-20261001/amount-accept.patch`; its four tests
  preserve pending intent, show acknowledged clamping and rebind accepted native
  text to the selected control. Root replaced its removed `issued()` assertion
  with the existing bounded `abandon_ids()` observation.
- App/harness suite: 532 passed, two failed. The modifier test exposed egui's
  Shift helper accepting an isolated mac_cmd flag; Trim now checks all four
  reserved modifier flags explicitly. The inspection test incorrectly required
  the shared non-looping Window type to reject empty intervals. Removed only
  that assertion; Trim's own audition method still rejects them. The real
  zero-context Space/Apply regression is being added to the production replay.
- Applied visible help and keyboard/native contract patch
  `/tmp/deadpan-native-trim-help-20261001/native-trim-help-v1.patch`.
- Corrected focused app/harness `trim` run passes all 60 selected tests
  (16.069 s including compilation). Initial full app and corrected run cover
  the 534-test suite, with exact changed source identities retained. Painted
  help/layout and production replay remain required.
- Production replay stage integrated and independently reviewed. Root fixed
  three false-pass witnesses: stale audio now differs from retained position;
  focused native controls get a single awaited H rather than cancelling H/L;
  waveform assertions compare actual descriptor revision/root/rate/duration.
- First visual replay reached 37 checks, then failed because its wait helper
  observed readiness before painting the restored viewport. Added an initial
  measurement step. Product Apply correctly refused the obsolete raster.
- Second rendered replay passes 92 Trim checks and 18,352 Kestrel cases, with
  the live 62-reservation registry matching. Source manifest bd0979db305c04da7b709f0fd6c946ede5d2f7ca65e9c81fd4a8bc46cb7ec4e5.
  PCM, decoder and Metal work are real; audio delivery is injected. Run retains
  bounded intermediate-capture allowance and linker warnings.
- Image review found minimum-size feedback overflow. Layout v1 now allocates
  bounded picture, waveform and scrollable feedback regions. Follow-up keyboard
  reachability and strict clipping replay are being staged by the layout agent.
- Root shortened picture captions to Before/Proposed, role, Edit and Original
  frame numbers. Exact boundary/source PTS remain on hover. Not visually checked
  after this text change yet.
- Full target validation was occurring repeatedly each UI frame. Under the
  immutable never-reused revision contract, context continuity now compares
  captured session/project/revision plus existing cursor/selection/scope fields.
  Initial/service/inspection/Apply validation remain. Independent review found
  no issue; large-project Trim latency has not been measured.
- Early strict affected-crate Clippy failed on four mechanical issues: redundant
  checked unwrap, large picture enum and two needless test Option dereferences.
  All corrected without suppressions. Corrected lint remains pending.
- Layout review found hidden zero-size pictures could gain Apply authority via
  GPU size clamping. show now requires both picture rects positive and fully
  inside the paint clip; otherwise authority clears and resources drain normally.
  Layout assertions added, production short-window regression being staged.
- Native QA fixture copied while holding its source writer lock. A SQLite backup
  records 8 revisions / 5 history entries before QA. No native window opened yet.
- Layout v1 focused tests pass 63; corrected affected-crate strict Clippy passes.
  Source e3bca4813fdcde9b492e6c7a14d76a2dba1750efd4ec89ae2c25ab821ade8cbf.
  Visual 3 passes 92 Trim checks. Root inspected its compact/default pair captures.
- Keyboard feedback v2 and strict visibility replay integrated. Root spelled
  Up/Down rather than arrow glyphs. Visual 4 passes 125 Trim checks and 18,352 live
  Kestrel cases. Min/default images inspected, including fully scrolled handles.
  Source 9291e1ead7429b00123743fbfc57a26891ac6f468fe066d5a4d63dd94b24fc24.
  Full ui-harness app suite on that source passes 539 app + 3 headless tests.
- Final gate is running through final-gate.py (one root Cargo owner): fmt,
  workspace base Clippy, app-feature Clippy, full base workspace tests.
  Fmt passed; base workspace Clippy passed in 936.43 s, app-feature Clippy passed
  in 19.01 s. Full base workspace tests are still compiling. Tool session 96239
  owns the gate; do not start another Cargo or edit checkout sources until done.
- New bounded review found immediate Tab→ArrowUp can leave feedback because egui
  refuses its focus filter on the pass focus is first gained. Frozen correction:
  /tmp/deadpan-trim-feedback-focus-20261001/feedback-focus.patch (not applied).
  IMPORTANT: also move show/show_retained from before waveform/feedback to just
  after feedback content-height storage, before trailing actions. This keeps
  focus's newly requested discard before any picture GPU submission; keep
  prepare and paint together. Fixed child rectangles and ordinary Tab order stay
  unchanged. Root may apply replay hunk first for a failing witness, then fix.
  Root staged that complete correction at
  /tmp/deadpan-trim-feedback-focus-20261001/feedback-focus-root-v2.patch,
  SHA ce63bbe93615c29819ace6b6d30cd56b80b4c679bf8688313f6e26c0bbb064d6.
  It is apply-checked against current checkout, not yet applied. Original agent
  patch/work remain frozen. Use this v2 (or its per-file include) for integration.
- Frozen five-file docs patch awaits integration after current gate:
  /tmp/deadpan-native-trim-docs-20261001/native-trim-docs.patch. Root owns actual
  qualification record, final counts/native evidence and COMBINED_TRIM updates.
- Scratch qualification-draft.md and collect-evidence.py prepared; collector
  has NOT run and requires final performance/native evidence first.

- Native before-focus run completed: four accepted values, Before/Proposed,
  amount clamping, ordinary Tab focus, feedback Home/End and Escape restoration.
  All 20 SQLite tables match the entry snapshot. Cmd+Q exited zero; no Deadpan
  process remains and the writer lock is available. Binary, command and limits
  are retained in native/before-focus-observations.md and checks. It ran during
  compilation and started no audio, so it establishes no latency/device result.
- Narrow independent review approved the exact root-v2 focus patch, including
  prepare/paint placement after the possible feedback discard. No runtime check
  was performed by the reviewer. Production red/green remains pending.
- Broad gate completed on source 9291e1: all 3,421 unit/integration tests and
  both documentation tests passed, none ignored. Workspace test invocation
  took 1,923.94 seconds including compilation. Full gate session 96239 exited 0.
- Applied the harness-only immediate-arrow witness first. Visual 5 failed the
  exact first ArrowUp-after-Tab assertion on source b260babc4f769870f9b0b397d9030bcfdff8881e7b429c5d1b90199d5830e078.
  Applied the root-v2 controls correction afterward. Visual 6 passed 126 Trim
  checks plus 18,352 live Kestrel cases on source
  b6bfc6870c44e97dfc95c5051b899133fab569f5d37b112f0a4d2d7e52e137ba.
  Root inspected final trim-081, trim-097 and trim-045 images; readable bounded
  controls, pair, waveform and feedback at both supported viewport sizes.
- Corrected source passes formatting, strict app all-target lint both base and
  ui-harness, 503 base app + 3 headless tests, and 539 ui-harness app + 3 headless
  tests. after-focus-gate.py session 79738 now owns release performance compile
  followed by the final normal app build. Do not start another Cargo or edit
  source while it runs. Docs-only changes are allowed; source manifest excludes
  those and each invocation retains its exact Git diff identity too.
- Five-file docs patch applied; architecture update independently verified
  DB52/core43, retained migrations 1..38 and refused unused schemas 39..51.
  Root added feedback keyboard notes. Final native save/history/reopen and
  qualification evidence remain outstanding.

Runtime reports retain full logs, source inventories and unchanged-source checks
in `checks/`. The full product goal and all existing requirement/gate statuses
remain open.

- Full release replay initially exposed an outdated Slip wrapper oracle: authoring
  correctly sets both audio_editorial_edges, already required by core tests/docs.
  The harness now expects those two fields and still compares the full wrapper.
  Corrected full release replay passes 3,779 checks across 23 workflows. Source
  f608d35ff211bd7d3b3bbef3f78ca1117a7a4f5242b0a56f02d3f212f5fd9f70.
- Native Trim audition on the debug binary repeatedly appeared not to pause.
  Temporary input logs proved heading Space was routed once correctly, but the
  transport had already stopped before it arrived. Native AX then reported
  `Audition stopped: audio output stopped: Starved`. The feedback message was
  below its paint clip. Do not claim ignored input or duplicate activation.
  All native runs were closed with Cmd+Q and exited 0. Diagnostic cancellation
  leaves all 20 SQLite tables unchanged; process absent and writer lock free.
- Temporary input logging has been removed. A replay witness now checks the
  intermediate keyboard/pointer paused state, then injects a matching Starved
  failure after scrolling feedback. Visual 7 fails exactly because failure text
  is not painted. Production fix prioritizes external errors, reveals changed
  errors at the top, and requests repaint after transport actions. Visual 8 is
  running. Independent review and real-output starvation investigation assigned.

- Audition correction gate passes: fmt, strict feature app all-target Clippy,
  all 539 feature app + 3 headless tests, full release replay 3,785 checks in
  23 workflows, and ordinary release build. Source 7f64e4fa0e11eba76243b24871529e7d6b8cb76a3cb500ce1cf22daab4ab4743.
- Independent review found same-frame focused End could override the new fault
  reveal. Split patches retained in /tmp/deadpan-trim-error-priority-20261001.
  Root applied witness first: visual 9 failed exactly that assertion (source
  0395c4e873ba405ea27215a4ae93ff3c9338eea4fb87b117333a9ae046b2b418).
  Moving the error offset reset after consumed keys makes visual 10 pass all
  134 Trim checks, plus live Kestrel cases. Source
  a51de6546df98588d032ba45789341d74f4b47e12bb99fee6932dca07d449f71.
  Formatting/strict lint pass; focused release Trim and normal release rebuild
  running in root session 92321. No native app open during these builds.

- Native normal release a51 succeeded: same short context loop stayed active
  across a recorded 12-second wait; heading Space paused/resumed, pointer Pause
  stopped it; pair and Original 7/Edit 3 remained fixed. Apply/Undo/Redo/reopen
  passed exact SQLite history verification. Both native sessions exited 0;
  release-shutdown-verification confirms no process and free writer lock.
  Details: native/release-observations.md. A feedback-only wheel/drag reveal
  guard is still being staged after pinned egui source showed delayed offset
  overwrite. Root will verify it with actual painted replay; no further native
  launch needed for that UI-only guard. No Cargo or Deadpan process active now.

- Native scroll guard witness (visual11/source75f227...) failed exactly its
  wheel impulse/smoothing visibility assertion. Production guard applied;
  visual12 passes155 Trim checks with18 smoothing frames and later deliberate
  scrolling. Source ec03e98f8276c7cf101dade0ee36b287b2af4f3a0147b0dc938b9d14ae19200e.
- Independent review found a smaller (<8pt) native impulse can settle without
  another repaint after egui's150ms scroll-idle timeout, leaving reveal pending.
  A bounded delayed-repaint follow-up is being staged by junction_review in
  /tmp/deadpan-trim-reveal-wake-20261001. Root must integrate and run its witness
  before final evidence/commit. Do not claim final completion yet.

- Final reveal-wake witness initially failed to compile because d.check expected
  Value and received Vec<Value>; root wrapped failure_paint in json!. Corrected
  visual13 then failed exactly the bounded repaint check, observing450.000001ms
  (not infinity). Applied six-line200ms wake. Visual14 passes164 Trim checks;
  observed wake sequence0ms,0ms,183.333332ms, then idle and later scrolling.
  Source ca88130583b3b8ca3a5de424ac6625fcef04c17a11456341c99bb5c80878bb13.
  Root inspected final Before-pair and visible-failure images.
- Collector independent review found and root fixed explicit-final-gate selection,
  newly added source-file detection and missing recorder retention. Follow-up
  review found no further issue. Collector still awaits final execution.
