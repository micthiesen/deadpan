import json
from pathlib import Path
import sqlite3

root = Path(__file__).parent / 'slip-investigation'
report = json.loads((root / 'report.json').read_text())
scenario = next(s for s in report['scenarios'] if s['name'] == 'slip')
check = next(c for c in scenario['checks'] if not c['passed'])
node = check['expected']['editor']['selected_beat']
path = root / 'projects/slip/Documents/Deadpan/cfr-bframes.deadpan/project.sqlite'
with sqlite3.connect('file:' + str(path) + '?mode=ro', uri=True) as db:
    current, parent, doc = db.execute('SELECT r.id, r.parent_id, r.document FROM revisions r JOIN state s ON r.id=s.head_revision').fetchone()
    previous = json.loads(db.execute('SELECT document FROM revisions WHERE id=?', (parent,)).fetchone()[0])
    current_doc = json.loads(doc)
result = {'before_revision': parent, 'after_revision': current, 'selected_node': node,
          'before_node': previous['nodes'][node], 'after_node': current_doc['nodes'][node]}
(root / 'wrapper-comparison.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result, indent=2))
