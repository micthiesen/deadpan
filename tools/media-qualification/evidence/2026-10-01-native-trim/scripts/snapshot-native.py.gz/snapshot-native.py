import json
import sqlite3
import sys
from pathlib import Path

root = Path(__file__).parent / 'native'
label = sys.argv[1]
assert label and all(c.isalnum() or c == '-' for c in label)
project = root / 'Trim QA.deadpan' / 'project.sqlite'
destination = root / (label + '.sqlite')
if destination.exists():
    raise SystemExit('Snapshot already exists')
with sqlite3.connect('file:' + str(project) + '?mode=ro', uri=True) as source:
    with sqlite3.connect(destination) as backup:
        source.backup(backup)
with sqlite3.connect(destination) as database:
    document = json.loads(database.execute('SELECT r.document FROM revisions r JOIN state s ON r.id=s.head_revision').fetchone()[0])
    summary = {
        'label': label,
        'revisions': database.execute('SELECT count(*) FROM revisions').fetchone()[0],
        'history': database.execute('SELECT count(*) FROM history').fetchone()[0],
        'revision': document['revision_id'],
        'root': document['root'],
        'nodes': document['nodes'],
    }
    (root / (label + '-document.json')).write_text(json.dumps(document, indent=2) + '\n')
    (root / (label + '-summary.json')).write_text(json.dumps(summary, indent=2) + '\n')
    print(json.dumps(summary, indent=2))
