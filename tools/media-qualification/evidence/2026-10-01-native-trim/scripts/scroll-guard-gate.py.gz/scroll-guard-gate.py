import os
import subprocess

env = dict(os.environ, DEADPAN_CHECK_OUTPUT='/tmp/deadpan-native-trim-ui-20261001/checks')
recorder = '/tmp/deadpan-ripple-trim-20261001/run-check.py'
for name, args in [
 ('native-trim-scroll-guard-fmt', ['fmt', '--all', '--', '--check']),
 ('native-trim-scroll-guard-clippy', ['clippy', '-p', 'deadpan-app', '--all-targets', '--locked', '--features', 'ui-harness', '--', '-D', 'warnings']),
]:
 result = subprocess.run(['python3', recorder, name, 'rustup', 'run', '1.97.1', 'cargo', *args], env=env)
 if result.returncode:
  raise SystemExit(result.returncode)
