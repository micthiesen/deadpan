import json
from pathlib import Path
import sqlite3

root = Path(__file__).parent
labels = ['before', 'applied', 'undone', 'redone', 'reopened']
documents = {label: json.loads((root / (label + '-document.json')).read_text()) for label in labels}
summaries = {}
tables = {}
for label in labels:
    with sqlite3.connect(root / (label + '.sqlite')) as db:
        names = [row[0] for row in db.execute("SELECT name FROM sqlite_master WHERE type='table' ORDER BY name")]
        tables[label] = {name: db.execute('SELECT * FROM "' + name.replace('"', '""') + '"').fetchall() for name in names}
        summaries[label] = {'revision': documents[label]['revision_id'], 'revisions': len(tables[label]['revisions']), 'history': len(tables[label]['history'])}
assert [(summaries[label]['revisions'], summaries[label]['history']) for label in labels] == [(8, 5), (9, 6), (10, 6), (11, 6), (11, 6)], summaries
assert len({documents[label]['revision_id'] for label in labels[:4]}) == 4
assert tables['redone'] == tables['reopened'], 'Reopening changed persisted state'

def authored(document):
    return {key: value for key, value in document.items() if key != 'revision_id'}

assert authored(documents['before']) == authored(documents['undone']), 'Undo did not restore exact authored data'
assert authored(documents['applied']) == authored(documents['redone']), 'Redo did not restore exact authored data'
for label in labels[1:]:
    assert tables[label]['history'][:5] == tables['before']['history']
    for name, rows in tables['before'].items():
        if name not in {'history', 'revisions', 'state', 'redo'}:
            assert tables[label][name] == rows, (label, name)

request = json.loads(tables['applied']['history'][-1][3])
command = request['command']
assert request['expected_revision'] == documents['before']['revision_id']
assert request['new_revision'] == documents['applied']['revision_id']
assert command['command'] == 'apply_source_trim', command
assert command['intent'] == {'in_frames': 0, 'out_frames': 0, 'slip_frames': 2, 'roll_frames': 0, 'policy': 'ripple'}
assert command['parent'] == 'trim-replay-group'
group = documents['before']['nodes']['trim-replay-group']['kind']['children']
assert command['node'] == group[0] and command['right'] == group[1]
source_before = documents['before']['nodes'][group[0]]['kind']['source']
source_after = documents['applied']['nodes'][group[0]]['kind']['source']
assert source_before['duration'] == source_after['duration'] == 14
assert source_before['edit_window'] == source_after['edit_window']
for kind in ['video_mapping', 'audio_mapping']:
    expected = dict(source_before[kind], start={'numerator': '-12', 'denominator': '1'})
    assert source_after[kind] == expected, (kind, source_after[kind])
assert documents['before']['nodes'][group[1]]['kind'] == documents['applied']['nodes'][group[1]]['kind']
assert documents['before']['nodes']['trim-replay-group'] == documents['applied']['nodes']['trim-replay-group']
result = {'snapshots': summaries, 'one_complete_trim_history_entry': request,
          'source_mapping_start_before': '-10', 'source_mapping_start_after': '-12',
          'selected_source_duration_frames': 14, 'unchanged_right_source_duration_frames': 120,
          'undo_authored_data_exact': True, 'redo_authored_data_exact': True,
          'reopen_all_tables_exact': True, 'operational_tables_unchanged': True}
(root / 'history-verification.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({'snapshots': summaries, 'history_verified': True}))
