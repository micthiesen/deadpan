import fcntl
import json
from pathlib import Path
import sqlite3
import subprocess

root = Path(__file__).parent
with sqlite3.connect(root / 'before.sqlite') as before, sqlite3.connect(root / 'cancelled-before-focus.sqlite') as after:
    tables = [row[0] for row in before.execute("SELECT name FROM sqlite_master WHERE type='table' ORDER BY name")]
    changed = []
    for table in tables:
        identifier = '"' + table.replace('"', '""') + '"'
        if before.execute('SELECT * FROM ' + identifier).fetchall() != after.execute('SELECT * FROM ' + identifier).fetchall():
            changed.append(table)
    assert not changed, changed
processes = subprocess.check_output(['ps', '-axo', 'pid=,comm='], text=True)
apps = [line.strip() for line in processes.splitlines() if line.rstrip().endswith('/deadpan-app')]
assert not apps, apps
with (root / 'Trim QA.deadpan' / '.writer.lock').open('rb') as lock:
    fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
    fcntl.flock(lock, fcntl.LOCK_UN)
report = {'all_tables_unchanged': tables, 'deadpan_app_processes': apps, 'writer_lock_available': True}
(root / 'cancel-verification.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps(report))
