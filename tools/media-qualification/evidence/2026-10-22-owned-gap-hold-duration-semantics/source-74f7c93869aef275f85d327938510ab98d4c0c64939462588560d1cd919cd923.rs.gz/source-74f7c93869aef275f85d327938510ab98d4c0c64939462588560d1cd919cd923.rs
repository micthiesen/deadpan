//! Captured decode evidence, separated from its durable metadata representation.
//!
//! Only live media sessions can produce `DecodedSourceQualification`. A loaded
//! snapshot validates retained evidence, but cannot mint that live token. Neither
//! type establishes original-file ownership, asset registration, or readiness.

pub use deadpan_source::VideoInterpretationSupport;
use std::io::Write;

use deadpan_core::{
    AssetId, DocumentError, ExactRatio, FrameRate, SourceFrameIndex, SourceTimeBase, TimeError,
};
use deadpan_source::{
    ColorMatrix, ColorMetadata, ColorPrimaries, ColorRange, ColorTransfer, ContentLight,
    IgnoredStaticMetadata, MasteringDisplay, SourceAudioStreamInfo, SourceStreamInfo,
};
use serde::{Deserialize, Serialize};

use crate::audio_index::{AudioChannelLayout, AudioIndexSnapshot, AudioLayoutInterpretation};
use crate::audio_session::AudioSession;
use crate::source_import_timing::{
    BasisCandidate, GeometryCandidate, ImportTiming, ImportTimingError, derive_import_timing,
    derive_presentation_basis, derive_presentation_geometry,
};
use crate::source_index::{
    MAX_SOURCE_INDEX_JSON_BYTES, SourceContentIdentity, SourceIndexError, SourceIndexSnapshot,
};
use crate::source_session::SourceSession;

pub const SOURCE_QUALIFICATION_VERSION: u32 = 1;
pub const SOURCE_QUALIFICATION_DECODER_CONTRACT: &str = "ffmpeg-8.0.3/source-decoded-v1";
pub const SOURCE_IMPORT_TIMING_POLICY_VERSION: u32 = 1;
pub const MAX_SOURCE_QUALIFICATION_JSON_BYTES: usize = 192 * 1024 * 1024;
pub const QUALIFIED_SOURCE_ASSET_ID: &str = "qualified-source";

#[derive(Debug, thiserror::Error)]
pub enum SourceQualificationError {
    #[error("unsupported source qualification schema, decoder or timing policy")]
    Version,
    #[error("source qualification metadata exceeds its byte or count limit")]
    Limit,
    #[error("invalid source qualification metadata: {0}")]
    Metadata(&'static str),
    #[error(transparent)]
    Timing(#[from] ImportTimingError),
    #[error(transparent)]
    Index(#[from] SourceIndexError),
    #[error(transparent)]
    Document(#[from] DocumentError),
    #[error(transparent)]
    Time(#[from] TimeError),
    #[error(transparent)]
    Json(#[from] serde_json::Error),
    /// A sound whose channels carry no declared speaker layout needs the
    /// registering person's explicit interpretation; the message says which.
    #[error("{0}")]
    AudioLayoutInterpretation(String),
}

/// Evidence captured from sessions that actually decoded the selected streams.
/// There is deliberately no arbitrary constructor or deserialization path.
///
/// ```compile_fail
/// use deadpan_media::source_qualification::DecodedSourceQualification;
/// let forged = serde_json::from_str::<DecodedSourceQualification>("{}");
/// ```
#[derive(Debug)]
pub struct DecodedSourceQualification {
    snapshot: SourceQualificationSnapshot,
}

impl DecodedSourceQualification {
    pub fn from_sessions(
        video: Option<&SourceSession>,
        audio: Option<&AudioSession>,
    ) -> Result<Self, SourceQualificationError> {
        // Reject oversized evidence before cloning either potentially large
        // index. Validation below also counts the final canonical envelope.
        let mut indexed_bytes = 0_usize;
        if let Some(session) = video {
            if session.interpretation() != deadpan_source::VideoInterpretation::SOURCE {
                return Err(SourceQualificationError::Metadata(
                    "source qualification requires the original interpretation",
                ));
            }
            let mut writer = BoundedWriter::new(MAX_SOURCE_INDEX_JSON_BYTES, false);
            write_json(session.index(), &mut writer)?;
            indexed_bytes = writer.length;
        }
        if let Some(session) = audio {
            let mut writer = BoundedWriter::new(MAX_SOURCE_INDEX_JSON_BYTES, false);
            write_json(session.index(), &mut writer)?;
            indexed_bytes = indexed_bytes
                .checked_add(writer.length)
                .ok_or(SourceQualificationError::Limit)?;
        }
        if indexed_bytes > MAX_SOURCE_QUALIFICATION_JSON_BYTES {
            return Err(SourceQualificationError::Limit);
        }
        let origin_seconds = derive_import_timing(
            video.map(SourceSession::index),
            audio.map(AudioSession::index),
            FrameRate::new(1, 1)?,
        )?
        .origin_seconds;
        let content = video
            .map(|session| session.index().content())
            .or_else(|| audio.map(|session| session.index().content()))
            .ok_or(ImportTimingError::NoStreams)?;
        let video = video
            .map(|session| {
                let index = session.index().index();
                Ok::<_, SourceQualificationError>(QualifiedVideoSnapshot {
                    index: SourceIndexSnapshot::new(
                        content,
                        session.index().stream_index(),
                        SourceFrameIndex::new(
                            AssetId::new(QUALIFIED_SOURCE_ASSET_ID)?,
                            index.time_base(),
                            index.frames().to_vec(),
                            index.terminal_end(),
                            index.terminal_provenance(),
                        )?,
                    )?,
                    interpretation: session.info().clone(),
                })
            })
            .transpose()?;
        let snapshot = SourceQualificationSnapshot {
            schema_version: SOURCE_QUALIFICATION_VERSION,
            decoder_contract: SOURCE_QUALIFICATION_DECODER_CONTRACT.into(),
            timing_policy_version: SOURCE_IMPORT_TIMING_POLICY_VERSION,
            content,
            origin_seconds,
            video,
            audio: audio.map(|session| session.index().clone()),
            audio_interpretation: None,
        };
        snapshot.validate()?;
        Ok(Self { snapshot })
    }

    /// Qualification for registration, with the registering person's explicit
    /// speaker interpretation. A declared native layout needs none, and a
    /// choice cannot override it, so the choice is not retained there. An
    /// audio-only registration (a sound) whose channels declare no layout is
    /// refused without a matching choice: audition and export could otherwise
    /// only fail later, and the channel count alone never decides speakers.
    /// An Original video keeps its existing audio admission when no choice is
    /// given.
    pub fn for_registration(
        video: Option<&SourceSession>,
        audio: Option<&AudioSession>,
        interpretation: Option<AudioLayoutInterpretation>,
    ) -> Result<Self, SourceQualificationError> {
        let layout = audio.map(|session| session.index().stream().channel_layout);
        let interpretation = match (layout, interpretation) {
            (Some(AudioChannelLayout::Unspecified { channels }), Some(choice)) => {
                if choice.channels() != channels {
                    return Err(SourceQualificationError::AudioLayoutInterpretation(
                        format!(
                            "This sound has {channels} channel(s) with no declared speaker layout, so {} ({} channel(s)) cannot describe it. {}",
                            choice.label(),
                            choice.channels(),
                            interpretation_guidance(channels)
                        ),
                    ));
                }
                Some(choice)
            }
            (Some(AudioChannelLayout::Unspecified { channels }), None) if video.is_none() => {
                return Err(SourceQualificationError::AudioLayoutInterpretation(
                    format!(
                        "This sound has {channels} channel(s) with no declared speaker layout. {}",
                        interpretation_guidance(channels)
                    ),
                ));
            }
            _ => None,
        };
        Self::from_sessions_interpreted(video, audio, interpretation)
    }

    /// Reproduce an existing receipt's qualification, including its retained
    /// explicit interpretation. Unlike [`Self::for_registration`], this does
    /// not refuse an undeclared layout without one; validation still rejects
    /// a choice for a declared layout or a different channel count.
    pub fn from_sessions_interpreted(
        video: Option<&SourceSession>,
        audio: Option<&AudioSession>,
        interpretation: Option<AudioLayoutInterpretation>,
    ) -> Result<Self, SourceQualificationError> {
        let mut decoded = Self::from_sessions(video, audio)?;
        if interpretation.is_some() {
            decoded.snapshot.audio_interpretation = interpretation;
            decoded.snapshot.validate()?;
        }
        Ok(decoded)
    }

    pub fn snapshot(&self) -> &SourceQualificationSnapshot {
        &self.snapshot
    }
}

/// Checked retained metadata. Loading this type never proves a fresh decode.
#[derive(Debug, Clone, PartialEq, Eq, Serialize)]
pub struct SourceQualificationSnapshot {
    schema_version: u32,
    decoder_contract: String,
    timing_policy_version: u32,
    content: SourceContentIdentity,
    /// The exact original-clock start chosen for normalization. Persist it
    /// explicitly, independently of later project frame-rate choices.
    origin_seconds: ExactRatio,
    video: Option<QualifiedVideoSnapshot>,
    audio: Option<AudioIndexSnapshot>,
    /// The registering person's explicit speaker interpretation of an audio
    /// stream that declares no layout. Absent for declared layouts, and absent
    /// from the canonical bytes then, so earlier receipts keep their identity.
    #[serde(skip_serializing_if = "Option::is_none")]
    audio_interpretation: Option<AudioLayoutInterpretation>,
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize)]
pub struct QualifiedVideoSnapshot {
    index: SourceIndexSnapshot,
    #[serde(with = "SourceStreamInfoWire")]
    interpretation: SourceStreamInfo,
}

impl QualifiedVideoSnapshot {
    pub fn interpretation_support(&self) -> VideoInterpretationSupport {
        VideoInterpretationSupport::for_qualified_stream(self.interpretation())
    }
    pub fn index(&self) -> &SourceIndexSnapshot {
        &self.index
    }

    /// Original source interpretation, independent of any project output policy.
    pub fn interpretation(&self) -> &SourceStreamInfo {
        &self.interpretation
    }
}

#[derive(Deserialize)]
#[serde(deny_unknown_fields)]
struct SnapshotWire {
    schema_version: u32,
    decoder_contract: String,
    timing_policy_version: u32,
    content: SourceContentIdentity,
    #[serde(deserialize_with = "normalization_origin")]
    origin_seconds: ExactRatio,
    #[serde(deserialize_with = "required_option")]
    video: Option<VideoWire>,
    #[serde(deserialize_with = "required_option")]
    audio: Option<AudioIndexSnapshot>,
    /// Omitted for declared layouts; never an explicit null.
    #[serde(default, deserialize_with = "present_interpretation")]
    audio_interpretation: Option<AudioLayoutInterpretation>,
}

fn present_interpretation<'de, D: serde::Deserializer<'de>>(
    deserializer: D,
) -> Result<Option<AudioLayoutInterpretation>, D::Error> {
    AudioLayoutInterpretation::deserialize(deserializer).map(Some)
}

#[derive(Deserialize)]
#[serde(deny_unknown_fields)]
struct VideoWire {
    index: SourceIndexSnapshot,
    #[serde(with = "SourceStreamInfoWire")]
    interpretation: SourceStreamInfo,
}

impl SourceQualificationSnapshot {
    pub fn content(&self) -> SourceContentIdentity {
        self.content
    }

    pub fn origin_seconds(&self) -> ExactRatio {
        self.origin_seconds
    }

    pub fn video(&self) -> Option<&QualifiedVideoSnapshot> {
        self.video.as_ref()
    }

    pub fn audio(&self) -> Option<&AudioIndexSnapshot> {
        self.audio.as_ref()
    }

    /// The registering person's explicit interpretation, when the stream
    /// declares no speaker layout.
    pub fn audio_interpretation(&self) -> Option<AudioLayoutInterpretation> {
        self.audio_interpretation
    }

    /// The speaker layout audio preparation must use: the explicit
    /// interpretation when one was chosen, otherwise the declared layout
    /// (which may still be unspecified and is then refused by preparation).
    pub fn audio_layout(&self) -> Option<AudioChannelLayout> {
        self.audio.as_ref().map(|audio| {
            self.audio_interpretation.map_or(
                audio.stream().channel_layout,
                AudioLayoutInterpretation::layout,
            )
        })
    }

    pub fn derive_timing(
        &self,
        project_rate: FrameRate,
    ) -> Result<ImportTiming, SourceQualificationError> {
        Ok(derive_import_timing(
            self.video.as_ref().map(QualifiedVideoSnapshot::index),
            self.audio.as_ref(),
            project_rate,
        )?)
    }

    pub fn basis_candidate(&self) -> Result<Option<BasisCandidate>, SourceQualificationError> {
        self.video
            .as_ref()
            .map(|video| {
                Ok(derive_presentation_basis(
                    &video.index,
                    &video.interpretation,
                )?)
            })
            .transpose()
    }

    pub fn geometry_candidate(
        &self,
    ) -> Result<Option<GeometryCandidate>, SourceQualificationError> {
        self.video
            .as_ref()
            .map(|video| {
                Ok(derive_presentation_geometry(
                    &video.index,
                    &video.interpretation,
                )?)
            })
            .transpose()
    }

    /// Validate bounded persisted metadata without creating live decode proof.
    pub fn from_json(bytes: &[u8]) -> Result<Self, SourceQualificationError> {
        if bytes.len() > MAX_SOURCE_QUALIFICATION_JSON_BYTES {
            return Err(SourceQualificationError::Limit);
        }
        let wire: SnapshotWire = serde_json::from_slice(bytes)?;
        let snapshot = Self {
            schema_version: wire.schema_version,
            decoder_contract: wire.decoder_contract,
            timing_policy_version: wire.timing_policy_version,
            content: wire.content,
            origin_seconds: wire.origin_seconds,
            video: wire.video.map(|video| QualifiedVideoSnapshot {
                index: video.index,
                interpretation: video.interpretation,
            }),
            audio: wire.audio,
            audio_interpretation: wire.audio_interpretation,
        };
        snapshot.validate()?;
        Ok(snapshot)
    }

    /// Stable struct field order, original observation order and a fixed video
    /// asset alias produce identical bytes independently of caller asset names.
    pub fn to_json(&self) -> Result<Vec<u8>, SourceQualificationError> {
        let mut writer = BoundedWriter::new(MAX_SOURCE_QUALIFICATION_JSON_BYTES, true);
        write_json(self, &mut writer)?;
        Ok(writer.bytes)
    }

    fn validate(&self) -> Result<(), SourceQualificationError> {
        if self.schema_version != SOURCE_QUALIFICATION_VERSION
            || self.decoder_contract != SOURCE_QUALIFICATION_DECODER_CONTRACT
            || self.timing_policy_version != SOURCE_IMPORT_TIMING_POLICY_VERSION
        {
            return Err(SourceQualificationError::Version);
        }
        if let Some(video) = &self.video {
            if video.index.content() != self.content
                || video.index.index().asset().as_str() != QUALIFIED_SOURCE_ASSET_ID
            {
                return Err(SourceQualificationError::Metadata(
                    "video content or canonical alias",
                ));
            }
            validate_video(video)?;
            write_json(
                &video.index,
                &mut BoundedWriter::new(MAX_SOURCE_INDEX_JSON_BYTES, false),
            )?;
        }
        if let Some(audio) = &self.audio {
            if audio.content() != self.content {
                return Err(SourceQualificationError::Metadata("audio content identity"));
            }
            validate_audio(audio)?;
            if let Some(video) = &self.video {
                validate_selected_audio(&video.interpretation, audio)?;
            }
            write_json(
                audio,
                &mut BoundedWriter::new(MAX_SOURCE_INDEX_JSON_BYTES, false),
            )?;
        }
        if let Some(choice) = self.audio_interpretation
            && !matches!(
                self.audio.as_ref().map(|audio| audio.stream().channel_layout),
                Some(AudioChannelLayout::Unspecified { channels }) if channels == choice.channels()
            )
        {
            return Err(SourceQualificationError::Metadata(
                "speaker interpretation needs an undeclared layout with matching channels",
            ));
        }
        // Timing validation requires measured video terminal duration and one
        // contiguous available audio span. It never invents priming trims.
        let measured_origin = self.derive_timing(FrameRate::new(1, 1)?)?.origin_seconds;
        if self.origin_seconds != measured_origin {
            return Err(SourceQualificationError::Metadata(
                "normalization origin disagrees with selected measured spans",
            ));
        }
        write_json(
            self,
            &mut BoundedWriter::new(MAX_SOURCE_QUALIFICATION_JSON_BYTES, false),
        )?;
        Ok(())
    }
}

/// Name the explicit choice that applies, or say that none does.
fn interpretation_guidance(channels: u32) -> String {
    let choices = AudioLayoutInterpretation::for_channels(channels)
        .map(|choice| format!("{} ({})", choice.label(), choice.wire_name()))
        .collect::<Vec<_>>();
    if choices.is_empty() {
        format!(
            "Deadpan offers no explicit interpretation for {channels} unlabelled channels; export the sound with a declared channel layout (for example WAVE_FORMAT_EXTENSIBLE or MP4) and add it again."
        )
    } else {
        format!(
            "Choose its speaker interpretation explicitly: {}. Then add it again; Deadpan never guesses speakers from the channel count.",
            choices.join(" or ")
        )
    }
}

/// The decoder's single HDR interpretation, rechecked on stored evidence:
/// PQ/HLG only as ten-bit 4:2:0 limited-range BT.2020 NCL HEVC, H.264, VP9 or AV1 with
/// BT.2020 primaries; static metadata only with it. Present values satisfy the
/// shared `deadpan_core` rule set; a declaration that failed it is recorded as
/// ignored and absent, never both.
fn validate_hdr(info: &SourceStreamInfo) -> Result<(), SourceQualificationError> {
    let color = &info.color;
    let hdr = matches!(color.transfer, ColorTransfer::Pq | ColorTransfer::Hlg);
    let valid = if hdr {
        matches!(info.codec.as_str(), "hevc" | "h264" | "vp9" | "av1")
            && info.pixel_format == "yuv420p10le"
            && color.range == ColorRange::Limited
            && color.matrix == ColorMatrix::Bt2020NonConstant
            && color.primaries == ColorPrimaries::Bt2020
            && color.mastering.is_none_or(|m| m.is_valid())
            && color.content_light.is_none_or(|light| light.is_valid())
            && !(color.ignored_static.mastering && color.mastering.is_some())
            && !(color.ignored_static.content_light && color.content_light.is_some())
    } else {
        (info.pixel_format != "yuv420p10le"
            || matches!(info.codec.as_str(), "hevc" | "h264" | "vp9" | "av1"))
            && (info.pixel_format != "yuv422p10le" || info.codec == "prores")
            && (info.codec != "prores"
                || (info.pixel_format == "yuv422p10le" && color.range == ColorRange::Limited))
            && (info.codec != "hevc"
                || matches!(
                    info.pixel_format.as_str(),
                    "yuv420p" | "yuvj420p" | "yuv420p10le"
                ))
            && (!matches!(info.codec.as_str(), "vp9" | "av1")
                || (!info.bwdif_fields
                    && matches!(info.pixel_format.as_str(), "yuv420p" | "yuv420p10le")))
            && color.mastering.is_none()
            && color.content_light.is_none()
            && color.ignored_static.is_empty()
    };
    if valid {
        Ok(())
    } else {
        Err(SourceQualificationError::Metadata(
            "HDR color interpretation",
        ))
    }
}

fn validate_video(video: &QualifiedVideoSnapshot) -> Result<(), SourceQualificationError> {
    let info = &video.interpretation;
    if !(1..=8192).contains(&info.width)
        || !(1..=8192).contains(&info.height)
        || info.stream_index >= 33
        || info.stream_index != video.index.stream_index()
        || source_clock(info.time_base_num, info.time_base_den)? != video.index.index().time_base()
        || info.sample_aspect_num == 0
        || info.sample_aspect_den == 0
        || info.sample_aspect_num > i32::MAX as u32
        || info.sample_aspect_den > i32::MAX as u32
        || info.rotation_quarter_turns > 3
        || (info.bwdif_fields && !info.time_base_den.is_multiple_of(6))
        || (matches!(info.codec.as_str(), "vp9" | "av1") && info.bwdif_fields)
        || (info.chroma_assumed_left && !matches!(info.codec.as_str(), "vp9" | "av1"))
        || (info.range_assumed
            && info.color.range
                != if info.color.matrix == ColorMatrix::Rgb {
                    ColorRange::Full
                } else {
                    ColorRange::Limited
                })
        || !matches!(
            info.codec.as_str(),
            "h264" | "ffv1" | "hevc" | "vp9" | "prores" | "av1"
        )
        || info
            .nominal_frame_duration_ns
            .is_some_and(|ns| ns == 0 || !matches!(info.codec.as_str(), "vp9" | "av1"))
    {
        return Err(SourceQualificationError::Metadata("video stream contract"));
    }
    info.visible_bounds()
        .map_err(|_| SourceQualificationError::Metadata("clean aperture"))?;
    if info.bwdif_fields {
        if !matches!(
            info.pixel_format.as_str(),
            "gbrp"
                | "yuv410p"
                | "yuv411p"
                | "yuv420p"
                | "yuv422p"
                | "yuv440p"
                | "yuv444p"
                | "yuvj411p"
                | "yuvj420p"
                | "yuvj422p"
                | "yuvj440p"
                | "yuvj444p"
                | "yuv420p10le"
                | "yuv422p10le"
        ) {
            return Err(SourceQualificationError::Metadata(
                "unqualified deinterlace pixel format",
            ));
        }
        let mut previous_key = None;
        let mut anchor = None;
        for frame in video.index.index().frames() {
            if frame.keyframe {
                anchor = previous_key.or(Some(frame.identity));
                previous_key = Some(frame.identity);
            }
            if frame.seek_from != anchor {
                return Err(SourceQualificationError::Metadata(
                    "missing deinterlace temporal context",
                ));
            }
        }
    }
    validate_hdr(info)?;
    validate_observations(info.stream_start, info.stream_duration)?;
    validate_observations(info.container_start, info.container_duration)?;
    if video
        .index
        .index()
        .frames()
        .iter()
        .any(|frame| frame.pts == i64::MIN || frame.decode_timestamp == Some(i64::MIN))
    {
        return Err(SourceQualificationError::Metadata(
            "missing native video timestamp",
        ));
    }
    let rgb = match info.pixel_format.as_str() {
        "gbrp" | "rgb24" | "bgr24" | "rgb0" | "bgr0" | "0rgb" | "0bgr" => true,
        // Codec/depth and HDR constraints are checked by validate_hdr.
        "yuv420p10le" | "yuv422p10le" => false,
        "yuv410p" | "yuv411p" | "yuv420p" | "yuv422p" | "yuv440p" | "yuv444p" | "yuvj411p"
        | "yuvj420p" | "yuvj422p" | "yuvj440p" | "yuvj444p" | "nv12" | "nv21" | "nv16" | "nv24"
        | "nv42" | "yuyv422" | "uyvy422" | "yvyu422" | "uyyvyy411" => false,
        _ => {
            return Err(SourceQualificationError::Metadata(
                "unqualified pixel format",
            ));
        }
    };
    if (rgb && (info.color.matrix != ColorMatrix::Rgb || info.color.range != ColorRange::Full))
        || (!rgb && info.color.matrix == ColorMatrix::Rgb)
    {
        return Err(SourceQualificationError::Metadata(
            "pixel format and color interpretation",
        ));
    }
    if info.audio_streams.len() > 32 {
        return Err(SourceQualificationError::Limit);
    }
    if info.stream_index as usize > info.audio_streams.len()
        || (info.codec == "ffv1" && !info.audio_streams.is_empty())
    {
        return Err(SourceQualificationError::Metadata(
            "complete admitted stream inventory",
        ));
    }
    let mut previous = None;
    for audio in &info.audio_streams {
        if audio.stream_index >= 33
            || audio.stream_index == info.stream_index
            || previous.is_some_and(|index| audio.stream_index <= index)
            || !matches!(audio.codec.as_str(), "aac" | "opus")
            || audio.stream_index as usize > info.audio_streams.len()
            || audio
                .sample_rate
                .is_some_and(|value| value == 0 || value > i32::MAX as u32)
            || audio
                .channel_count
                .is_some_and(|value| value == 0 || value > i32::MAX as u32)
        {
            return Err(SourceQualificationError::Metadata("audio inventory"));
        }
        source_clock(audio.time_base_num, audio.time_base_den)?;
        validate_observations(audio.stream_start, audio.stream_duration)?;
        previous = Some(audio.stream_index);
    }
    Ok(())
}

fn validate_audio(audio: &AudioIndexSnapshot) -> Result<(), SourceQualificationError> {
    let stream = audio.stream();
    source_clock(stream.time_base.numerator(), stream.time_base.denominator())?;
    validate_observations(stream.stream_start, stream.stream_duration)?;
    if [
        stream.initial_padding,
        stream.trailing_padding,
        stream.seek_preroll,
    ]
    .into_iter()
    .any(|value| value > i32::MAX as u32)
        || audio
            .observations()
            .iter()
            .any(|frame| frame.pts == i64::MIN || frame.decode_timestamp == Some(i64::MIN))
    {
        return Err(SourceQualificationError::Metadata(
            "native audio observations",
        ));
    }
    Ok(())
}

fn validate_selected_audio(
    info: &SourceStreamInfo,
    audio: &AudioIndexSnapshot,
) -> Result<(), SourceQualificationError> {
    let stream = audio.stream();
    let observed = info
        .audio_streams
        .iter()
        .find(|observed| observed.stream_index == stream.stream_index)
        .ok_or(SourceQualificationError::Metadata(
            "selected audio missing from video inventory",
        ))?;
    if observed.codec != stream.codec
        || source_clock(observed.time_base_num, observed.time_base_den)? != stream.time_base
        || observed
            .sample_rate
            .is_some_and(|rate| rate != stream.sample_rate)
        || observed
            .channel_count
            .is_some_and(|channels| channels != stream.channel_layout.channels())
        || observed.stream_start != stream.stream_start
        || observed.stream_duration != stream.stream_duration
    {
        return Err(SourceQualificationError::Metadata(
            "selected audio disagrees with inventory",
        ));
    }
    Ok(())
}

fn source_clock(
    numerator: u32,
    denominator: u32,
) -> Result<SourceTimeBase, SourceQualificationError> {
    if numerator > i32::MAX as u32 || denominator > i32::MAX as u32 {
        return Err(SourceQualificationError::Metadata("native clock bounds"));
    }
    Ok(SourceTimeBase::new(numerator, denominator)?)
}

fn validate_observations(
    start: Option<i64>,
    duration: Option<i64>,
) -> Result<(), SourceQualificationError> {
    if start == Some(i64::MIN) || duration.is_some_and(|value| value <= 0) {
        return Err(SourceQualificationError::Metadata(
            "native timestamp observation",
        ));
    }
    Ok(())
}

fn required_option<'de, D: serde::Deserializer<'de>, T: Deserialize<'de>>(
    deserializer: D,
) -> Result<Option<T>, D::Error> {
    Option::deserialize(deserializer)
}

fn normalization_origin<'de, D: serde::Deserializer<'de>>(
    deserializer: D,
) -> Result<ExactRatio, D::Error> {
    #[derive(Deserialize)]
    #[serde(deny_unknown_fields)]
    struct OriginWire {
        numerator: String,
        denominator: String,
    }
    let wire = OriginWire::deserialize(deserializer)?;
    ExactRatio::new(
        wire.numerator.parse().map_err(serde::de::Error::custom)?,
        wire.denominator.parse().map_err(serde::de::Error::custom)?,
    )
    .map_err(serde::de::Error::custom)
}

struct BoundedWriter {
    bytes: Vec<u8>,
    length: usize,
    limit: usize,
    retain: bool,
}

impl BoundedWriter {
    fn new(limit: usize, retain: bool) -> Self {
        Self {
            bytes: Vec::new(),
            length: 0,
            limit,
            retain,
        }
    }
}

impl Write for BoundedWriter {
    fn write(&mut self, bytes: &[u8]) -> std::io::Result<usize> {
        if bytes.len() > self.limit.saturating_sub(self.length) {
            return Err(std::io::Error::other("qualification metadata byte limit"));
        }
        if self.retain {
            self.bytes
                .try_reserve(bytes.len())
                .map_err(std::io::Error::other)?;
            self.bytes.extend_from_slice(bytes);
        }
        self.length += bytes.len();
        Ok(bytes.len())
    }
    fn flush(&mut self) -> std::io::Result<()> {
        Ok(())
    }
}

fn write_json(
    value: &impl Serialize,
    writer: &mut BoundedWriter,
) -> Result<(), SourceQualificationError> {
    serde_json::to_writer(writer, value).map_err(|error| {
        if error.is_io() {
            SourceQualificationError::Limit
        } else {
            SourceQualificationError::Json(error)
        }
    })
}

// Remote serde definitions preserve the complete native interpretation without
// giving the decoder crate a serialization or authored-document dependency.
#[derive(Serialize, Deserialize)]
#[serde(remote = "SourceStreamInfo", deny_unknown_fields)]
pub(crate) struct SourceStreamInfoWire {
    #[serde(default, rename = "bwdif_fields_v2", skip_serializing_if = "is_false")]
    bwdif_fields: bool,
    width: u32,
    height: u32,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    clean_aperture: Option<[ExactRatio; 4]>,
    stream_index: u32,
    time_base_num: u32,
    time_base_den: u32,
    sample_aspect_num: u32,
    sample_aspect_den: u32,
    rotation_quarter_turns: u8,
    #[serde(with = "ColorMetadataWire")]
    color: ColorMetadata,
    codec: String,
    pixel_format: String,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    nominal_frame_duration_ns: Option<u64>,
    #[serde(default, skip_serializing_if = "is_false")]
    chroma_assumed_left: bool,
    #[serde(default, skip_serializing_if = "is_false")]
    range_assumed: bool,
    #[serde(deserialize_with = "required_option")]
    stream_start: Option<i64>,
    #[serde(deserialize_with = "required_option")]
    stream_duration: Option<i64>,
    #[serde(deserialize_with = "required_option")]
    container_start: Option<i64>,
    #[serde(deserialize_with = "required_option")]
    container_duration: Option<i64>,
    #[serde(with = "audio_inventory")]
    audio_streams: Vec<SourceAudioStreamInfo>,
}

fn is_false(value: &bool) -> bool {
    !*value
}

#[derive(Serialize, Deserialize)]
#[serde(remote = "SourceAudioStreamInfo", deny_unknown_fields)]
struct SourceAudioStreamInfoWire {
    stream_index: u32,
    codec: String,
    time_base_num: u32,
    time_base_den: u32,
    #[serde(deserialize_with = "required_option")]
    stream_start: Option<i64>,
    #[serde(deserialize_with = "required_option")]
    stream_duration: Option<i64>,
    #[serde(deserialize_with = "required_option")]
    sample_rate: Option<u32>,
    #[serde(deserialize_with = "required_option")]
    channel_count: Option<u32>,
}

#[derive(Serialize, Deserialize)]
#[serde(remote = "ColorMetadata", deny_unknown_fields)]
struct ColorMetadataWire {
    #[serde(with = "ColorRangeWire")]
    range: ColorRange,
    #[serde(with = "ColorMatrixWire")]
    matrix: ColorMatrix,
    #[serde(with = "ColorTransferWire")]
    transfer: ColorTransfer,
    #[serde(with = "ColorPrimariesWire")]
    primaries: ColorPrimaries,
    // Absent for SDR, so existing receipts serialize byte-identically.
    #[serde(
        default,
        skip_serializing_if = "Option::is_none",
        with = "optional_mastering"
    )]
    mastering: Option<MasteringDisplay>,
    #[serde(
        default,
        skip_serializing_if = "Option::is_none",
        with = "optional_content_light"
    )]
    content_light: Option<ContentLight>,
    // A note that a declared value failed the shared rule set and is treated
    // as absent; omitted when nothing was ignored, so SDR bytes are unchanged.
    #[serde(
        default,
        skip_serializing_if = "IgnoredStaticMetadata::is_empty",
        with = "IgnoredStaticMetadataWire"
    )]
    ignored_static: IgnoredStaticMetadata,
}

#[derive(Serialize, Deserialize)]
#[serde(remote = "IgnoredStaticMetadata", deny_unknown_fields)]
struct IgnoredStaticMetadataWire {
    #[serde(default, skip_serializing_if = "std::ops::Not::not")]
    mastering: bool,
    #[serde(default, skip_serializing_if = "std::ops::Not::not")]
    content_light: bool,
}

#[derive(Serialize, Deserialize)]
#[serde(remote = "MasteringDisplay", deny_unknown_fields)]
struct MasteringDisplayWire {
    primaries: [[u16; 2]; 3],
    white_point: [u16; 2],
    max_luminance: u32,
    min_luminance: u32,
}
#[derive(Serialize, Deserialize)]
#[serde(remote = "ContentLight", deny_unknown_fields)]
struct ContentLightWire {
    max_cll: u16,
    max_fall: u16,
}
mod optional_mastering {
    use super::*;
    #[derive(Serialize, Deserialize)]
    struct Value(#[serde(with = "MasteringDisplayWire")] MasteringDisplay);
    pub(super) fn serialize<S: serde::Serializer>(
        value: &Option<MasteringDisplay>,
        serializer: S,
    ) -> Result<S::Ok, S::Error> {
        value.map(Value).serialize(serializer)
    }
    pub(super) fn deserialize<'de, D: serde::Deserializer<'de>>(
        deserializer: D,
    ) -> Result<Option<MasteringDisplay>, D::Error> {
        Ok(Option::<Value>::deserialize(deserializer)?.map(|Value(value)| value))
    }
}
mod optional_content_light {
    use super::*;
    #[derive(Serialize, Deserialize)]
    struct Value(#[serde(with = "ContentLightWire")] ContentLight);
    pub(super) fn serialize<S: serde::Serializer>(
        value: &Option<ContentLight>,
        serializer: S,
    ) -> Result<S::Ok, S::Error> {
        value.map(Value).serialize(serializer)
    }
    pub(super) fn deserialize<'de, D: serde::Deserializer<'de>>(
        deserializer: D,
    ) -> Result<Option<ContentLight>, D::Error> {
        Ok(Option::<Value>::deserialize(deserializer)?.map(|Value(value)| value))
    }
}

#[derive(Serialize, Deserialize)]
#[serde(remote = "ColorRange", rename_all = "snake_case")]
enum ColorRangeWire {
    Limited,
    Full,
}
#[derive(Serialize, Deserialize)]
#[serde(remote = "ColorMatrix", rename_all = "snake_case")]
enum ColorMatrixWire {
    Rgb,
    Bt709,
    Bt601,
    Bt2020NonConstant,
}
#[derive(Serialize, Deserialize)]
#[serde(remote = "ColorTransfer", rename_all = "snake_case")]
enum ColorTransferWire {
    Bt709,
    Srgb,
    Linear,
    Pq,
    Hlg,
}
#[derive(Serialize, Deserialize)]
#[serde(remote = "ColorPrimaries", rename_all = "snake_case")]
enum ColorPrimariesWire {
    Bt709,
    Bt2020,
    DisplayP3,
}

mod audio_inventory {
    use super::*;
    use serde::de::{Error, SeqAccess, Visitor};
    use serde::ser::SerializeSeq;

    #[derive(Serialize)]
    struct Borrowed<'a>(#[serde(with = "SourceAudioStreamInfoWire")] &'a SourceAudioStreamInfo);
    #[derive(Deserialize)]
    struct Owned(#[serde(with = "SourceAudioStreamInfoWire")] SourceAudioStreamInfo);

    pub(super) fn serialize<S: serde::Serializer>(
        value: &[SourceAudioStreamInfo],
        serializer: S,
    ) -> Result<S::Ok, S::Error> {
        let mut seq = serializer.serialize_seq(Some(value.len()))?;
        for info in value {
            seq.serialize_element(&Borrowed(info))?;
        }
        seq.end()
    }

    pub(super) fn deserialize<'de, D: serde::Deserializer<'de>>(
        deserializer: D,
    ) -> Result<Vec<SourceAudioStreamInfo>, D::Error> {
        struct BoundedInventory;
        impl<'de> Visitor<'de> for BoundedInventory {
            type Value = Vec<SourceAudioStreamInfo>;
            fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                formatter.write_str("at most 32 audio inventory entries")
            }
            fn visit_seq<A: SeqAccess<'de>>(self, mut seq: A) -> Result<Self::Value, A::Error> {
                if seq.size_hint().is_some_and(|count| count > 32) {
                    return Err(A::Error::custom("audio inventory count limit"));
                }
                let mut entries = Vec::new();
                while let Some(entry) = seq.next_element::<Owned>()? {
                    if entries.len() == 32 {
                        return Err(A::Error::custom("audio inventory count limit"));
                    }
                    entries.push(entry.0);
                }
                Ok(entries)
            }
        }
        deserializer.deserialize_seq(BoundedInventory)
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn metadata_writer_enforces_the_same_bound_with_and_without_retaining_bytes() {
        for retain in [false, true] {
            let mut writer = BoundedWriter::new(4, retain);
            writer.write_all(b"1234").unwrap();
            assert!(writer.write_all(b"5").is_err());
            assert_eq!(writer.length, 4);
            assert_eq!(writer.bytes.len(), if retain { 4 } else { 0 });
        }
    }
}
