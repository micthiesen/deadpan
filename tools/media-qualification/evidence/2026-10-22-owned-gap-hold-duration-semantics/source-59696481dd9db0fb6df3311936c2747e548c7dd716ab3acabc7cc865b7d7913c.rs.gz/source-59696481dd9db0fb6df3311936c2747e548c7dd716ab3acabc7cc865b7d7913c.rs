//! Linear source audio decoding through a persistent descriptor-only FFmpeg context.
//!
//! Supply an immutable host snapshot. Operations perform I/O and allocation and
//! belong on a worker, never the audio callback. Cancellation and deadlines are
//! cooperative. The decoder preserves source rate and channel order, performs no
//! resampling, downmix, additional gain, or clipping, and never derives a terminal endpoint
//! from a declared container duration.
//!
//! The default manual mode uses FFmpeg's `AV_CODEC_FLAG2_SKIP_MANUAL` to return
//! untrimmed frames with reported skip side data. Explicit ordinary mode lets
//! FFmpeg apply its skip handling. Neither mode realigns PCM or drops packets in
//! this adapter. Skip evidence is exposed separately from decoded sample counts.
//! A zero skip record, absent skip record, codec padding observation, or container
//! duration is not by itself proof that every decoded sample is presentation data.
//!
//! Repository fixtures qualify AAC-LC/MP4, raw MP3, mono/stereo Opus/WebM/Matroska,
//! and signed16 little-endian PCM/WAVE. Opus honors its declared header gain.
//! A strict container guard rejects unsafe size/table declarations before
//! FFmpeg allocation. Other container grammars require separate qualification.

use std::{fs::File, time::Instant};

use crate::{DecodeControl, SourceDecodeError, input};

/// Which FFmpeg skip-sample behavior the caller wants to observe.
#[derive(Clone, Copy, Debug, Default, PartialEq, Eq)]
pub enum AudioDecodeMode {
    /// Return physical decoded priming and padding with their skip side data.
    #[default]
    Manual,
    /// Let FFmpeg apply its ordinary skip handling, without host trimming.
    Ordinary,
}

/// Decoder and demuxer observations, distinct from the selected stream contract.
/// These identify the implementation and reported profile; they do not establish
/// finished-file timing or successful presentation of all authored samples.
#[derive(Clone, Debug, PartialEq, Eq)]
pub struct AudioDecoderEvidence {
    pub container_format: String,
    pub decoder_name: String,
    /// FFmpeg profile IDs. Unknown profiles remain absent, never inferred.
    pub container_profile: Option<i32>,
    pub decoder_profile: Option<i32>,
    /// FFmpeg's profile name, for example `LC` for observed AAC-LC.
    pub decoder_profile_name: Option<String>,
}

#[derive(Clone, Copy, Debug)]
pub struct AudioDecodeLimits {
    pub max_input_bytes: u64,
    pub max_frames: u64,
    pub max_packets: u64,
    /// Total returned samples per channel, including priming/padding in Manual.
    pub max_decoded_samples: u64,
    pub max_io_bytes_per_call: u64,
    pub max_samples_per_frame: u32,
    pub max_channels: u32,
    pub max_sample_rate: u32,
    pub max_packets_per_frame: u32,
    /// MP4 sample sizes are checked before demuxing; WAV packet sizes are capped.
    /// Returned payload plus side data is checked again before codec submission.
    pub max_packet_bytes: u32,
}

impl Default for AudioDecodeLimits {
    fn default() -> Self {
        Self {
            max_input_bytes: 64 * 1024 * 1024 * 1024,
            max_frames: 10_000_000,
            max_packets: 40_000_000,
            max_decoded_samples: 1_000_000_000_000,
            max_io_bytes_per_call: 256 * 1024 * 1024,
            max_samples_per_frame: 65_536,
            max_channels: 32,
            max_sample_rate: 384_000,
            max_packets_per_frame: 10_000,
            max_packet_bytes: 16 * 1024 * 1024,
        }
    }
}

impl AudioDecodeLimits {
    /// Validate hard bounds before copying a source snapshot or opening a decoder.
    pub fn validate(self) -> Result<(), SourceDecodeError> {
        if !(1..=64 * 1024 * 1024 * 1024).contains(&self.max_input_bytes)
            || !(1..=10_000_000).contains(&self.max_frames)
            || !(1..=40_000_000).contains(&self.max_packets)
            || !(1..=1_000_000_000_000).contains(&self.max_decoded_samples)
            || !(1..=1024 * 1024 * 1024).contains(&self.max_io_bytes_per_call)
            || !(1..=65_536).contains(&self.max_samples_per_frame)
            || !(1..=32).contains(&self.max_channels)
            || !(1..=384_000).contains(&self.max_sample_rate)
            || !(1..=10_000).contains(&self.max_packets_per_frame)
            || !(1..=16 * 1024 * 1024).contains(&self.max_packet_bytes)
        {
            return Err(SourceDecodeError::InvalidConfiguration(
                "audio decode limits exceed hard bounds",
            ));
        }
        Ok(())
    }
}

/// Source channel interpretation. An unspecified layout preserves channel slots
/// without assigning speakers. Native masks use FFmpeg's AVChannel speaker bits,
/// in ascending bit order. Custom and ambisonic orders are not qualified.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum AudioChannelLayout {
    Unspecified { channels: u32 },
    Native { channels: u32, mask: u64 },
}

impl AudioChannelLayout {
    pub fn channels(self) -> u32 {
        match self {
            Self::Unspecified { channels } | Self::Native { channels, .. } => channels,
        }
    }
}

#[derive(Clone, Debug, PartialEq, Eq)]
pub struct AudioStreamInfo {
    pub stream_index: u32,
    pub codec: String,
    pub time_base_num: u32,
    pub time_base_den: u32,
    pub sample_rate: u32,
    /// Opened decoder's layout, including AAC AudioSpecificConfig evidence.
    /// This may be more specific than the container's bare channel count.
    pub channel_layout: AudioChannelLayout,
    pub sample_format: AudioSampleFormat,
    /// Container header observations in the stream time base, not decoded bounds.
    pub stream_start: Option<i64>,
    pub stream_duration: Option<i64>,
    /// Codec parameter observations in samples per channel. Zero is reported
    /// faithfully and does not prove absence of priming, padding, or preroll.
    pub initial_padding: u32,
    pub trailing_padding: u32,
    pub seek_preroll: u32,
    /// Checked Matroska declarations before FFmpeg rounds CodecDelay to ticks.
    /// Raw frame PTS and skip observations remain unchanged.
    pub matroska_opus: Option<MatroskaOpusClock>,
    /// Exact MP4 packet inventory and presentation edit, before native decoding.
    pub mp4_opus: Option<Mp4OpusFraming>,
    /// Complete raw Layer III frame inventory and explicit encoder trim.
    pub mp3: Option<Mp3Framing>,
}

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub struct Mp4OpusFraming {
    pub channels: u32,
    pub pre_skip: u32,
    pub packet_count: u64,
    pub decoded_sample_count: u64,
    pub first_sample: i64,
    pub valid_samples: u64,
}

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub struct Mp3Framing {
    pub sample_rate: u32,
    pub channels: u32,
    pub samples_per_frame: u32,
    pub frame_count: u64,
    pub leading_skip: u32,
    pub trailing_skip: u32,
}

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub struct MatroskaOpusClock {
    pub pre_skip: u32,
    pub codec_delay_ns: u64,
    pub timestamp_scale_ns: u64,
    pub first_block_timestamp: i64,
    pub packet_count: u64,
    pub decoded_sample_count: u64,
}

/// Admit an immutable Matroska region without copying or decoding its audio.
/// Stream-copy workers use this for an audio input following a video input in
/// one descriptor. Offsets stay inside the region, including deferred Cues.
pub fn inspect_matroska_opus_region(
    file: &File,
    offset: u64,
    length: u64,
    limits: AudioDecodeLimits,
    control: DecodeControl<'_>,
) -> Result<MatroskaOpusClock, SourceDecodeError> {
    limits.validate()?;
    crate::matroska_input::validate_region(
        file,
        offset,
        length,
        crate::input::Selection::FirstAudio,
        limits.into(),
        control,
    )?
    .matroska_opus
    .ok_or_else(|| SourceDecodeError::Native {
        code: "invalid_input".into(),
        message: "Matroska region has no admitted Opus clock".into(),
    })
}

/// Actual decoder output representation, before the owned float copy.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum AudioSampleFormat {
    Unsigned8,
    Signed16,
    /// Includes signed24 decoded into left-aligned signed32 samples.
    Signed32,
    Float32Planar,
    Float32Interleaved,
}

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub struct AudioSkipSamples {
    pub leading: u32,
    pub trailing: u32,
    /// FFmpeg's raw reason byte: 0 is padding silence, 1 is convergence.
    pub leading_reason: u8,
    pub trailing_reason: u8,
}

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub struct AudioFrameMetadata {
    /// Original frame.pts in the selected stream time base. Missing PTS fails.
    pub pts: i64,
    pub decode_timestamp: Option<i64>,
    /// Positive original frame.duration, without sample-count substitution.
    pub reported_duration: Option<i64>,
    /// Returned samples per channel under the selected decode mode.
    pub nb_samples: u32,
    pub sample_rate: u32,
    pub sample_format: AudioSampleFormat,
    pub channel_layout: AudioChannelLayout,
    /// Exact returned frame skip side data. Manual mode leaves it unconsumed;
    /// ordinary mode may consume it inside FFmpeg before returning this frame.
    pub skip_samples: Option<AudioSkipSamples>,
    /// Original frame discard flag; manual AAC priming can carry this flag.
    pub discard: bool,
}

#[derive(Clone, Debug, PartialEq)]
pub struct DecodedAudioFrame {
    pub metadata: AudioFrameMetadata,
    /// Owned interleaved samples in original channel order. PCM16 is converted
    /// exactly as sample / 32768; AAC's decoded float amplitude is preserved.
    pub samples: Vec<f32>,
}

/// One persistent demuxer and one software decoder, movable but not `Sync`.
/// Decode failures poison the context. Invalid/pre-cancelled calls and copying
/// before a successful decode do not advance or poison it. There is no seek API:
/// sample-exact compressed-audio seeking is not established by this boundary.
pub struct AudioDecoder {
    inner: ffi::Decoder,
    info: AudioStreamInfo,
    mode: AudioDecodeMode,
    evidence: AudioDecoderEvidence,
    current: Option<AudioFrameMetadata>,
    decoded_frames: u64,
    decoded_samples: u64,
}

#[cfg(test)]
mod opening_budget_tests {
    use super::*;
    use std::{path::PathBuf, sync::atomic::AtomicBool, time::Duration};

    #[test]
    fn header_guard_and_ffmpeg_share_one_opening_io_allowance() {
        let file = File::open(
            PathBuf::from(env!("CARGO_MANIFEST_DIR"))
                .join("tests/audio-fixtures/pcm-stereo-48000.wav"),
        )
        .unwrap();
        let cancelled = AtomicBool::new(false);
        let control = DecodeControl {
            timeout: Duration::from_secs(2),
            cancelled: &cancelled,
        };
        let defaults = AudioDecodeLimits::default();
        let used =
            input::validate(&file, input::Selection::Audio(0), defaults.into(), control).unwrap();
        assert!(used > 0);
        // Find the measured minimum for FFmpeg alone, without depending on a
        // particular AVIO buffer fill strategy. These are trusted fixture bytes.
        let admitted = |bytes| {
            ffi::Decoder::open(
                file.try_clone().unwrap(),
                0,
                AudioDecodeMode::Manual,
                AudioDecodeLimits {
                    max_io_bytes_per_call: bytes,
                    ..defaults
                },
                0,
                control,
            )
            .is_ok()
        };
        let mut low = 1;
        let mut high = 1024 * 1024;
        assert!(admitted(high));
        while low < high {
            let middle = low + (high - low) / 2;
            if admitted(middle) {
                high = middle;
            } else {
                low = middle + 1;
            }
        }
        let limits = AudioDecodeLimits {
            max_io_bytes_per_call: low,
            ..defaults
        };
        assert!(admitted(low));
        assert_eq!(
            input::validate(&file, input::Selection::Audio(0), limits.into(), control).unwrap(),
            used
        );
        let error = AudioDecoder::open(file.try_clone().unwrap(), 0, limits, control)
            .err()
            .unwrap();
        assert!(matches!(error, SourceDecodeError::Native{code,..} if code=="resource_limit"));
        let first_error = AudioDecoder::open_first(file.try_clone().unwrap(), limits, control)
            .err()
            .unwrap();
        assert!(
            matches!(first_error, SourceDecodeError::Native{code,..} if code=="resource_limit")
        );
        let mut first = AudioDecoder::open_first(
            file.try_clone().unwrap(),
            AudioDecodeLimits {
                max_io_bytes_per_call: low + used,
                ..defaults
            },
            control,
        )
        .unwrap();
        assert_eq!(first.info().stream_index, 0);
        assert!(first.next_metadata(control).unwrap().is_some());
        let mut decoder = AudioDecoder::open(
            file,
            0,
            AudioDecodeLimits {
                max_io_bytes_per_call: low + used,
                ..defaults
            },
            control,
        )
        .unwrap();
        assert!(decoder.next_metadata(control).unwrap().is_some());
    }
}

impl AudioDecoder {
    /// Open in Manual mode, preserving the original physical-sample contract.
    pub fn open(
        file: File,
        selected_stream: u32,
        limits: AudioDecodeLimits,
        control: DecodeControl<'_>,
    ) -> Result<Self, SourceDecodeError> {
        Self::open_with_mode(
            file,
            selected_stream,
            AudioDecodeMode::Manual,
            limits,
            control,
        )
    }

    pub fn open_with_mode(
        file: File,
        selected_stream: u32,
        mode: AudioDecodeMode,
        limits: AudioDecodeLimits,
        control: DecodeControl<'_>,
    ) -> Result<Self, SourceDecodeError> {
        Self::open_selection(file, Some(selected_stream), mode, limits, control)
    }

    /// Select the first audio track in the fully admitted container inventory.
    /// A container without audio fails; metadata reports the actual stream ID.
    /// Preserves the original Manual-mode physical-sample contract.
    pub fn open_first(
        file: File,
        limits: AudioDecodeLimits,
        control: DecodeControl<'_>,
    ) -> Result<Self, SourceDecodeError> {
        Self::open_first_with_mode(file, AudioDecodeMode::Manual, limits, control)
    }

    pub fn open_first_with_mode(
        file: File,
        mode: AudioDecodeMode,
        limits: AudioDecodeLimits,
        control: DecodeControl<'_>,
    ) -> Result<Self, SourceDecodeError> {
        Self::open_selection(file, None, mode, limits, control)
    }

    fn open_selection(
        file: File,
        selected_stream: Option<u32>,
        mode: AudioDecodeMode,
        limits: AudioDecodeLimits,
        control: DecodeControl<'_>,
    ) -> Result<Self, SourceDecodeError> {
        let started = Instant::now();
        ffi::preflight(control)?;
        limits.validate()?;
        let admission = input::validate_audio(&file, selected_stream, limits.into(), control)?;
        let selected_stream = admission
            .audio
            .expect("audio admission has a selected stream");
        let matroska_opus = admission.matroska_opus;
        let timeout = control
            .timeout
            .checked_sub(started.elapsed())
            .filter(|timeout| !timeout.is_zero())
            .ok_or_else(|| SourceDecodeError::Native {
                code: "deadline_exceeded".into(),
                message: "audio header validation exhausted the opening budget".into(),
            })?;
        let (inner, mut info, evidence) = ffi::Decoder::open(
            file,
            selected_stream,
            mode,
            limits,
            admission.io_bytes,
            DecodeControl { timeout, ..control },
        )?;
        info.matroska_opus = matroska_opus;
        info.mp4_opus = admission.mp4_opus;
        info.mp3 = admission.mp3;
        if (info.codec == "mp3") != info.mp3.is_some()
            || info.mp3.is_some_and(|framing| {
                info.sample_rate != framing.sample_rate
                    || info.channel_layout.channels() != framing.channels
                    || info.time_base_num != 1
                    || info.time_base_den != 14_112_000
            })
        {
            return Err(SourceDecodeError::Native {
                code: "invalid_report".into(),
                message: "MP3 decoder disagrees with admitted frame inventory".into(),
            });
        }
        if (info.codec == "opus") != (matroska_opus.is_some() || info.mp4_opus.is_some())
            || (matroska_opus.is_some() && info.mp4_opus.is_some())
            || info.mp4_opus.is_some_and(|framing| {
                info.sample_rate != 48_000
                    || info.channel_layout.channels() != framing.channels
                    || info.initial_padding != framing.pre_skip
                    || info.seek_preroll != 3840
                    || info.time_base_num != 1
                    || info.time_base_den != 48_000
            })
            || matroska_opus.is_some_and(|clock| {
                info.sample_rate != 48_000
                    || info.initial_padding != clock.pre_skip
                    || info.seek_preroll != 3840
                    || u128::from(info.time_base_num) * 1_000_000_000
                        != u128::from(info.time_base_den) * u128::from(clock.timestamp_scale_ns)
            })
        {
            return Err(SourceDecodeError::Native {
                code: "invalid_report".into(),
                message: "Opus decoder disagrees with admitted container clock".into(),
            });
        }
        Ok(Self {
            inner,
            info,
            mode,
            evidence,
            current: None,
            decoded_frames: 0,
            decoded_samples: 0,
        })
    }

    pub fn info(&self) -> &AudioStreamInfo {
        &self.info
    }

    pub fn mode(&self) -> AudioDecodeMode {
        self.mode
    }

    /// Latest successfully admitted decoder observations. The profile may be
    /// unknown at open and become known after the first decoded frame.
    pub fn evidence(&self) -> &AudioDecoderEvidence {
        &self.evidence
    }

    /// Decode and retain one frame without allocating an owned PCM output.
    pub fn next_metadata(
        &mut self,
        control: DecodeControl<'_>,
    ) -> Result<Option<AudioFrameMetadata>, SourceDecodeError> {
        ffi::preflight(control)?;
        self.current = None;
        let (current, evidence) = self.inner.next(control)?;
        if let Some(frame) = current {
            self.decoded_frames += 1;
            self.decoded_samples += u64::from(frame.nb_samples);
        }
        if self.mode == AudioDecodeMode::Manual
            && self.info.mp3.is_some_and(|framing| {
                self.decoded_frames > framing.frame_count
                    || current.is_some_and(|frame| frame.nb_samples != framing.samples_per_frame)
                    || (current.is_none() && self.decoded_frames != framing.frame_count)
            })
        {
            return Err(SourceDecodeError::Native {
                code: "invalid_decode".into(),
                message: "MP3 decode did not preserve every admitted frame and sample".into(),
            });
        }
        if self.mode == AudioDecodeMode::Manual
            && self.info.mp4_opus.is_some_and(|framing| {
                self.decoded_frames > framing.packet_count
                    || self.decoded_samples > framing.decoded_sample_count
                    || (current.is_none()
                        && (self.decoded_frames != framing.packet_count
                            || self.decoded_samples != framing.decoded_sample_count))
            })
        {
            return Err(SourceDecodeError::Native {
                code: "invalid_decode".into(),
                message: "MP4 Opus decode did not preserve every admitted packet and sample".into(),
            });
        }
        if self.mode == AudioDecodeMode::Manual
            && self.info.matroska_opus.is_some_and(|clock| {
                self.decoded_frames > clock.packet_count
                    || self.decoded_samples > clock.decoded_sample_count
                    || (current.is_none()
                        && (self.decoded_frames != clock.packet_count
                            || self.decoded_samples != clock.decoded_sample_count))
            })
        {
            return Err(SourceDecodeError::Native {
                code: "invalid_decode".into(),
                message: "Opus decode did not preserve every admitted packet and sample".into(),
            });
        }
        self.current = current;
        self.evidence = evidence;
        Ok(self.current)
    }

    /// Copy retained samples without advancing the decoder. The returned buffer
    /// survives subsequent decode operations and destruction of the decoder.
    pub fn copy_current_interleaved_f32(
        &mut self,
        control: DecodeControl<'_>,
    ) -> Result<DecodedAudioFrame, SourceDecodeError> {
        let started = Instant::now();
        ffi::preflight(control)?;
        let expected = self.current.ok_or(SourceDecodeError::InvalidConfiguration(
            "no current audio frame",
        ))?;
        let length = usize::try_from(expected.nb_samples)
            .ok()
            .and_then(|count| count.checked_mul(expected.channel_layout.channels() as usize))
            .ok_or(SourceDecodeError::InvalidConfiguration(
                "audio output sample count overflow",
            ))?;
        let mut samples = Vec::new();
        samples.try_reserve_exact(length).map_err(|_| {
            SourceDecodeError::InvalidConfiguration("audio output allocation failed")
        })?;
        samples.resize(length, 0.0);
        // Allocation and conversion share the caller's one cooperative budget.
        let timeout = control
            .timeout
            .checked_sub(started.elapsed())
            .filter(|timeout| !timeout.is_zero())
            .ok_or_else(|| SourceDecodeError::Native {
                code: "deadline_exceeded".into(),
                message: "audio output allocation exhausted the call budget".into(),
            })?;
        let metadata = self.inner.copy(
            DecodeControl {
                timeout,
                cancelled: control.cancelled,
            },
            &mut samples,
        )?;
        if metadata != expected {
            return Err(SourceDecodeError::Native {
                code: "invalid_report".into(),
                message: "audio copy changed retained frame metadata".into(),
            });
        }
        Ok(DecodedAudioFrame { metadata, samples })
    }
}

// All unsafe ownership and synchronous callback lifetime handling lives here.
#[allow(unsafe_code)]
mod ffi {
    use super::*;
    use std::{
        cell::Cell,
        ffi::{c_char, c_int, c_void},
        marker::PhantomData,
        os::fd::AsRawFd,
        ptr::NonNull,
        sync::atomic::{AtomicBool, Ordering},
        time::Duration,
    };

    const PROFILE_UNKNOWN: i32 = -99;
    const PROFILE_AAC_LOW: i32 = 1;

    #[repr(C)]
    struct Limits {
        max_input_bytes: u64,
        max_frames: u64,
        max_packets: u64,
        max_decoded_samples: u64,
        max_io_bytes_per_call: u64,
        max_samples_per_frame: u32,
        max_channels: u32,
        max_sample_rate: u32,
        max_packets_per_frame: u32,
        max_packet_bytes: u32,
    }

    #[repr(C)]
    #[derive(Clone, Copy, Default)]
    struct Layout {
        channels: i32,
        order: i32,
        mask: u64,
    }

    #[repr(C)]
    #[derive(Default)]
    struct Info {
        stream_index: i32,
        time_base_num: i32,
        time_base_den: i32,
        sample_rate: i32,
        channel_layout: Layout,
        stream_start: i64,
        stream_duration: i64,
        initial_padding: i32,
        trailing_padding: i32,
        seek_preroll: i32,
        sample_format: i32,
        codec: [c_char; 32],
    }

    #[repr(C)]
    struct Evidence {
        mode: u32,
        container_profile: i32,
        decoder_profile: i32,
        container_format: [c_char; 64],
        decoder_name: [c_char; 32],
        decoder_profile_name: [c_char; 32],
    }

    impl Default for Evidence {
        fn default() -> Self {
            Self {
                mode: u32::MAX,
                container_profile: PROFILE_UNKNOWN,
                decoder_profile: PROFILE_UNKNOWN,
                container_format: [0; 64],
                decoder_name: [0; 32],
                decoder_profile_name: [0; 32],
            }
        }
    }

    #[repr(C)]
    #[derive(Default)]
    struct Frame {
        pts: i64,
        duration: i64,
        dts: i64,
        nb_samples: i32,
        sample_rate: i32,
        sample_format: i32,
        channel_layout: Layout,
        skip_present: u32,
        leading: u32,
        trailing: u32,
        leading_reason: u32,
        trailing_reason: u32,
        discard: u32,
    }

    #[repr(C)]
    struct Error {
        code: [c_char; 48],
        message: [c_char; 256],
    }

    impl Default for Error {
        fn default() -> Self {
            Self {
                code: [0; 48],
                message: [0; 256],
            }
        }
    }

    impl Error {
        fn into_error(self) -> SourceDecodeError {
            SourceDecodeError::Native {
                code: string(&self.code),
                message: string(&self.message),
            }
        }
    }

    type Cancel = extern "C" fn(*const c_void) -> c_int;
    unsafe extern "C" {
        fn deadpan_audio_open(
            fd: c_int,
            length: i64,
            selected_stream: u32,
            mode: u32,
            limits: *const Limits,
            preflight_io_bytes: u64,
            timeout_ms: u64,
            cancelled: Cancel,
            opaque: *const c_void,
            out: *mut *mut c_void,
            info: *mut Info,
            evidence: *mut Evidence,
            error: *mut Error,
        ) -> c_int;
        fn deadpan_audio_next(
            source: *mut c_void,
            timeout_ms: u64,
            cancelled: Cancel,
            opaque: *const c_void,
            frame: *mut Frame,
            evidence: *mut Evidence,
            error: *mut Error,
        ) -> c_int;
        fn deadpan_audio_copy(
            source: *mut c_void,
            timeout_ms: u64,
            cancelled: Cancel,
            opaque: *const c_void,
            frame: *mut Frame,
            samples: *mut f32,
            length: usize,
            error: *mut Error,
        ) -> c_int;
        fn deadpan_audio_io_bytes(source: *const c_void) -> u64;
        fn deadpan_audio_close(source: *mut c_void);
    }

    extern "C" fn cancelled(opaque: *const c_void) -> c_int {
        // SAFETY: every C entrypoint borrows this AtomicBool synchronously and
        // clears the callback and pointer before returning, including failures.
        i32::from(unsafe { &*opaque.cast::<AtomicBool>() }.load(Ordering::Relaxed))
    }

    fn control(value: DecodeControl<'_>) -> Result<(u64, *const c_void), SourceDecodeError> {
        if value.timeout.is_zero() || value.timeout > Duration::from_secs(60) {
            return Err(SourceDecodeError::InvalidConfiguration(
                "timeout must be positive and at most 60 seconds",
            ));
        }
        if value.cancelled.load(Ordering::Relaxed) {
            return Err(SourceDecodeError::Native {
                code: "cancelled".into(),
                message: "audio decode was cancelled before starting".into(),
            });
        }
        let millis = value.timeout.as_millis()
            + u128::from(!value.timeout.subsec_nanos().is_multiple_of(1_000_000));
        Ok((
            u64::try_from(millis).expect("bounded timeout"),
            std::ptr::from_ref(value.cancelled).cast(),
        ))
    }

    pub(super) fn preflight(value: DecodeControl<'_>) -> Result<(), SourceDecodeError> {
        control(value).map(|_| ())
    }

    pub(super) struct Decoder {
        pointer: NonNull<c_void>,
        _file: File,
        mode: AudioDecodeMode,
        _not_sync: PhantomData<Cell<()>>,
        /// Cumulative descriptor bytes already added to process diagnostics.
        published_io: u64,
    }

    // SAFETY: the instance exclusively owns its heap FFmpeg context and File,
    // installs no process-global callbacks, and requires &mut self for calls.
    unsafe impl Send for Decoder {}

    impl Drop for Decoder {
        fn drop(&mut self) {
            // SAFETY: successful open creates this unique context; its File is
            // still alive here and closes only after the C state is freed.
            unsafe { deadpan_audio_close(self.pointer.as_ptr()) };
        }
    }

    impl Decoder {
        /// Add descriptor reads since the last call to process diagnostics.
        /// One counted operation per decoder call, not per AVIO read.
        fn publish_io(&mut self) {
            // SAFETY: the live context is uniquely owned; this call reads one
            // counter and never performs I/O or decoding.
            let total = unsafe { deadpan_audio_io_bytes(self.pointer.as_ptr()) };
            let delta = total.saturating_sub(self.published_io);
            if delta != 0 {
                deadpan_diagnostics::IO.audio_decoder_input.read(delta);
                self.published_io = total;
            }
        }

        pub(super) fn open(
            file: File,
            selected_stream: u32,
            mode: AudioDecodeMode,
            limits: AudioDecodeLimits,
            preflight_io_bytes: u64,
            ctl: DecodeControl<'_>,
        ) -> Result<(Self, AudioStreamInfo, AudioDecoderEvidence), SourceDecodeError> {
            let (timeout, opaque) = control(ctl)?;
            limits.validate()?;
            let metadata = file.metadata()?;
            if !metadata.is_file() {
                return Err(SourceDecodeError::InvalidConfiguration(
                    "audio input must be a regular file",
                ));
            }
            let length = i64::try_from(metadata.len()).map_err(|_| {
                SourceDecodeError::InvalidConfiguration("audio input exceeds signed file offsets")
            })?;
            let limits = Limits {
                max_input_bytes: limits.max_input_bytes,
                max_frames: limits.max_frames,
                max_packets: limits.max_packets,
                max_decoded_samples: limits.max_decoded_samples,
                max_io_bytes_per_call: limits.max_io_bytes_per_call,
                max_samples_per_frame: limits.max_samples_per_frame,
                max_channels: limits.max_channels,
                max_sample_rate: limits.max_sample_rate,
                max_packets_per_frame: limits.max_packets_per_frame,
                max_packet_bytes: limits.max_packet_bytes,
            };
            let mut pointer = std::ptr::null_mut();
            let mut info = Info::default();
            let mut evidence = Evidence::default();
            let mut error = Error::default();
            // SAFETY: bounded live input/output structures, an owned regular
            // descriptor, and a synchronous cancellation callback. C frees its
            // allocations on failed open and never owns or reopens the File.
            let result = unsafe {
                deadpan_audio_open(
                    file.as_raw_fd(),
                    length,
                    selected_stream,
                    mode_id(mode),
                    &limits,
                    preflight_io_bytes,
                    timeout,
                    cancelled,
                    opaque,
                    &mut pointer,
                    &mut info,
                    &mut evidence,
                    &mut error,
                )
            };
            if result != 1 {
                return Err(error.into_error());
            }
            let mut inner = Self {
                pointer: NonNull::new(pointer).ok_or_else(invalid_report)?,
                _file: file,
                mode,
                _not_sync: PhantomData,
                published_io: 0,
            };
            inner.publish_io();
            let codec = string(&info.codec);
            if !matches!(
                codec.as_str(),
                "aac"
                    | "pcm_u8"
                    | "pcm_s16le"
                    | "pcm_s24le"
                    | "pcm_s32le"
                    | "pcm_f32le"
                    | "opus"
                    | "mp3"
            ) {
                return Err(invalid_report());
            }
            let value = AudioStreamInfo {
                mp3: None,
                matroska_opus: None,
                mp4_opus: None,
                stream_index: nonnegative(info.stream_index)?,
                codec,
                time_base_num: positive(info.time_base_num)?,
                time_base_den: positive(info.time_base_den)?,
                sample_rate: positive(info.sample_rate)?,
                channel_layout: info.channel_layout.convert()?,
                sample_format: sample_format(info.sample_format)?,
                stream_start: (info.stream_start != i64::MIN).then_some(info.stream_start),
                stream_duration: (info.stream_duration > 0).then_some(info.stream_duration),
                initial_padding: nonnegative(info.initial_padding)?,
                trailing_padding: nonnegative(info.trailing_padding)?,
                seek_preroll: nonnegative(info.seek_preroll)?,
            };
            if value.stream_index != selected_stream {
                return Err(invalid_report());
            }
            let evidence = evidence.convert(mode)?;
            if evidence.decoder_name
                != if value.codec == "opus" {
                    "libopus"
                } else if value.codec == "mp3" {
                    "mp3float"
                } else {
                    &value.codec
                }
            {
                return Err(invalid_report());
            }
            Ok((inner, value, evidence))
        }

        pub(super) fn next(
            &mut self,
            ctl: DecodeControl<'_>,
        ) -> Result<(Option<AudioFrameMetadata>, AudioDecoderEvidence), SourceDecodeError> {
            let (timeout, opaque) = control(ctl)?;
            let mut frame = Frame::default();
            let mut evidence = Evidence::default();
            let mut error = Error::default();
            // SAFETY: exclusive context ownership and synchronous live outputs
            // and cancellation state; next retains its own decoded AVFrame.
            let result = unsafe {
                deadpan_audio_next(
                    self.pointer.as_ptr(),
                    timeout,
                    cancelled,
                    opaque,
                    &mut frame,
                    &mut evidence,
                    &mut error,
                )
            };
            self.publish_io();
            match result {
                1 => Ok((Some(frame.convert()?), evidence.convert(self.mode)?)),
                0 => Ok((None, evidence.convert(self.mode)?)),
                _ => Err(error.into_error()),
            }
        }

        pub(super) fn copy(
            &mut self,
            ctl: DecodeControl<'_>,
            samples: &mut [f32],
        ) -> Result<AudioFrameMetadata, SourceDecodeError> {
            let (timeout, opaque) = control(ctl)?;
            let mut frame = Frame::default();
            let mut error = Error::default();
            // SAFETY: a valid uniquely borrowed output slice lives for this
            // call; C checks its exact sample count before writing any samples.
            let result = unsafe {
                deadpan_audio_copy(
                    self.pointer.as_ptr(),
                    timeout,
                    cancelled,
                    opaque,
                    &mut frame,
                    samples.as_mut_ptr(),
                    samples.len(),
                    &mut error,
                )
            };
            self.publish_io();
            if result != 1 {
                return Err(error.into_error());
            }
            frame.convert()
        }
    }

    fn mode_id(mode: AudioDecodeMode) -> u32 {
        match mode {
            AudioDecodeMode::Manual => 0,
            AudioDecodeMode::Ordinary => 1,
        }
    }

    impl Evidence {
        fn convert(self, mode: AudioDecodeMode) -> Result<AudioDecoderEvidence, SourceDecodeError> {
            let container_format = checked_string(&self.container_format)?;
            let decoder_name = checked_string(&self.decoder_name)?;
            let decoder_profile_name = checked_string(&self.decoder_profile_name)?;
            if self.mode != mode_id(mode)
                || !matches!(
                    container_format.as_str(),
                    "mov,mp4,m4a,3gp,3g2,mj2" | "wav" | "matroska,webm" | "mp3"
                )
                || !matches!(
                    decoder_name.as_str(),
                    "aac"
                        | "pcm_u8"
                        | "pcm_s16le"
                        | "pcm_s24le"
                        | "pcm_s32le"
                        | "pcm_f32le"
                        | "libopus"
                        | "mp3float"
                )
                || (decoder_name == "aac"
                    && (!matches!(self.container_profile, PROFILE_UNKNOWN | PROFILE_AAC_LOW)
                        || !matches!(self.decoder_profile, PROFILE_UNKNOWN | PROFILE_AAC_LOW)))
                || (self.decoder_profile == PROFILE_UNKNOWN && !decoder_profile_name.is_empty())
                || (decoder_name == "aac"
                    && self.decoder_profile == PROFILE_AAC_LOW
                    && decoder_profile_name != "LC")
            {
                return Err(invalid_report());
            }
            Ok(AudioDecoderEvidence {
                container_format,
                decoder_name,
                container_profile: (self.container_profile != PROFILE_UNKNOWN)
                    .then_some(self.container_profile),
                decoder_profile: (self.decoder_profile != PROFILE_UNKNOWN)
                    .then_some(self.decoder_profile),
                decoder_profile_name: (!decoder_profile_name.is_empty())
                    .then_some(decoder_profile_name),
            })
        }
    }

    fn checked_string(bytes: &[c_char]) -> Result<String, SourceDecodeError> {
        let end = bytes
            .iter()
            .position(|&value| value == 0)
            .ok_or_else(invalid_report)?;
        let bytes: Vec<_> = bytes[..end].iter().map(|&value| value as u8).collect();
        String::from_utf8(bytes).map_err(|_| invalid_report())
    }

    impl Layout {
        fn convert(self) -> Result<AudioChannelLayout, SourceDecodeError> {
            let channels = positive(self.channels)?;
            if channels > 32 {
                return Err(invalid_report());
            }
            match self.order {
                0 if self.mask == 0 => Ok(AudioChannelLayout::Unspecified { channels }),
                1 if self.mask.count_ones() == channels => Ok(AudioChannelLayout::Native {
                    channels,
                    mask: self.mask,
                }),
                _ => Err(invalid_report()),
            }
        }
    }

    impl Frame {
        fn convert(self) -> Result<AudioFrameMetadata, SourceDecodeError> {
            if self.pts == i64::MIN || self.skip_present > 1 || self.discard > 1 {
                return Err(invalid_report());
            }
            let nb_samples = positive(self.nb_samples)?;
            let sample_rate = positive(self.sample_rate)?;
            if nb_samples > 65_536 || sample_rate > 384_000 {
                return Err(invalid_report());
            }
            Ok(AudioFrameMetadata {
                pts: self.pts,
                decode_timestamp: (self.dts != i64::MIN).then_some(self.dts),
                reported_duration: (self.duration > 0).then_some(self.duration),
                nb_samples,
                sample_rate,
                sample_format: sample_format(self.sample_format)?,
                channel_layout: self.channel_layout.convert()?,
                discard: self.discard != 0,
                skip_samples: if self.skip_present == 0 {
                    None
                } else {
                    Some(AudioSkipSamples {
                        leading: self.leading,
                        trailing: self.trailing,
                        leading_reason: u8::try_from(self.leading_reason)
                            .map_err(|_| invalid_report())?,
                        trailing_reason: u8::try_from(self.trailing_reason)
                            .map_err(|_| invalid_report())?,
                    })
                },
            })
        }
    }

    fn sample_format(value: i32) -> Result<AudioSampleFormat, SourceDecodeError> {
        match value {
            0 => Ok(AudioSampleFormat::Unsigned8),
            1 => Ok(AudioSampleFormat::Signed16),
            2 => Ok(AudioSampleFormat::Signed32),
            8 => Ok(AudioSampleFormat::Float32Planar),
            3 => Ok(AudioSampleFormat::Float32Interleaved),
            _ => Err(invalid_report()),
        }
    }

    fn nonnegative(value: i32) -> Result<u32, SourceDecodeError> {
        u32::try_from(value).map_err(|_| invalid_report())
    }

    fn positive(value: i32) -> Result<u32, SourceDecodeError> {
        nonnegative(value)
            .ok()
            .filter(|value| *value > 0)
            .ok_or_else(invalid_report)
    }

    fn string(bytes: &[c_char]) -> String {
        String::from_utf8_lossy(
            &bytes
                .iter()
                .take_while(|&&value| value != 0)
                .map(|&value| value as u8)
                .collect::<Vec<_>>(),
        )
        .into_owned()
    }

    fn invalid_report() -> SourceDecodeError {
        SourceDecodeError::Native {
            code: "invalid_report".into(),
            message: "native audio decoder returned an invalid validated report".into(),
        }
    }

    #[cfg(test)]
    mod evidence_tests {
        use super::*;

        fn unknown_aac(mode: AudioDecodeMode) -> Evidence {
            let mut value = Evidence {
                mode: mode_id(mode),
                ..Evidence::default()
            };
            for (out, input) in value
                .container_format
                .iter_mut()
                .zip(b"mov,mp4,m4a,3gp,3g2,mj2")
            {
                *out = *input as c_char;
            }
            for (out, input) in value.decoder_name.iter_mut().zip(b"aac") {
                *out = *input as c_char;
            }
            value
        }

        #[test]
        fn unknown_profile_remains_unknown_and_malformed_evidence_is_rejected() {
            let actual = unknown_aac(AudioDecodeMode::Ordinary)
                .convert(AudioDecodeMode::Ordinary)
                .unwrap();
            assert_eq!(actual.container_profile, None);
            assert_eq!(actual.decoder_profile, None);
            assert_eq!(actual.decoder_profile_name, None);
            assert!(
                unknown_aac(AudioDecodeMode::Manual)
                    .convert(AudioDecodeMode::Ordinary)
                    .is_err()
            );

            let mut invalid = unknown_aac(AudioDecodeMode::Manual);
            invalid.mode = 2;
            assert!(invalid.convert(AudioDecodeMode::Manual).is_err());
            let mut invalid = unknown_aac(AudioDecodeMode::Manual);
            invalid.decoder_profile = 4;
            assert!(invalid.convert(AudioDecodeMode::Manual).is_err());
            let mut invalid = unknown_aac(AudioDecodeMode::Manual);
            invalid.decoder_profile_name[0] = b'L' as c_char;
            assert!(invalid.convert(AudioDecodeMode::Manual).is_err());
            let mut invalid = unknown_aac(AudioDecodeMode::Manual);
            invalid.container_format.fill(b'x' as c_char);
            assert!(invalid.convert(AudioDecodeMode::Manual).is_err());
        }
    }
}
