use std::collections::BTreeMap;
use std::error::Error;
use std::fs;
use std::path::{Path, PathBuf};
use std::process::{Command as ProcessCommand, Output};

use deadpan_core::{
    BeatNode, Command, FrameDuration, HoldAudio, HoldRecipe, HoldVideo, NodeId, ProjectDocument,
    Subtree,
};
use deadpan_store::{AccessMode, ProjectStore};
use serde_json::{Value, json};

type Result<T = ()> = std::result::Result<T, Box<dyn Error>>;

#[path = "project_commands/compound.rs"]
mod compound;

#[path = "project_commands/delete.rs"]
mod delete;
#[path = "project_commands/delete_range.rs"]
mod delete_range;
#[path = "project_commands/edited_slice.rs"]
mod edited_slice;
#[cfg(any(target_os = "macos", target_os = "linux"))]
#[path = "project_commands/macros.rs"]
mod macros;
#[path = "project_commands/mixed_pause.rs"]
mod mixed_pause;
#[path = "project_commands/move_range.rs"]
mod move_range;
#[path = "project_commands/nested_pause.rs"]
mod nested_pause;

fn cli(arguments: &[&str]) -> Result<Output> {
    Ok(ProcessCommand::new(env!("CARGO_BIN_EXE_deadpan-cli"))
        .args(arguments)
        .output()?)
}

fn success(arguments: &[&str]) -> Result<Value> {
    let output = cli(arguments)?;
    assert!(
        output.status.success(),
        "{}",
        String::from_utf8_lossy(&output.stderr)
    );
    Ok(serde_json::from_slice(&output.stdout)?)
}

#[test]
fn doctor_reports_sound_document_and_database_schemas() -> Result {
    let report = success(&["doctor"])?;
    assert_eq!(
        report["document_schema"],
        deadpan_core::DOCUMENT_SCHEMA_VERSION
    );
    assert_eq!(
        report["database_schema"],
        deadpan_store::DATABASE_SCHEMA_VERSION
    );
    let partial = report["partial"].as_array().unwrap();
    for capability in [
        "schema-1-through-57-development-format-refusal",
        "saved-beat-sound-commands",
        "persistent-copy-registers",
        "resolved-compound-transactions",
        "native-semantic-macros",
        "headless-semantic-macros",
        "hold-audio-policy-commands",
        "native-original-audition",
        "selection-loop-audition",
        "native-structural-speed-editing",
    ] {
        assert!(partial.contains(&json!(capability)), "{capability}");
    }
    assert!(!partial.contains(&json!("schema-1-through-38-migration")));
    let unimplemented = report["unimplemented"].as_array().unwrap();
    assert!(!unimplemented.contains(&json!("original-view-playback")));
    assert!(unimplemented.contains(&json!("full-device-and-acoustic-qualification")));
    Ok(())
}

fn create(root: &Path) -> Result<PathBuf> {
    let package = root.join("session.deadpan");
    let result = success(&[
        "project",
        "create",
        package.to_str().unwrap(),
        "--fps",
        "30000/1001",
        "--size",
        "1920x1080",
    ])?;
    assert_eq!(result["duration_frames"], 0);
    Ok(package)
}

fn request(document: &ProjectDocument) -> Result<Value> {
    let node = NodeId::new("hold")?;
    Ok(json!({
            "protocol": 1, "project_id": document.project_id(), "expected_revision": document.revision_id(), "new_revision": "after-hold",
            "command": Command::Insert {parent: document.root().clone(), index: 0, subtree: Subtree {
                    overrides: Default::default(),
                    gap_overrides: Default::default(),
                root: node.clone(), nodes: BTreeMap::from([(node, BeatNode::hold("Silence", HoldRecipe {
     picture_context: None,
    duration: FrameDuration::new(45)?, video: HoldVideo::Background, audio: HoldAudio::Silence,
                }))]),
            }},
        }))
}

#[test]
fn headless_captured_view_is_inspectable_reversible_and_validated_before_commit() -> Result {
    let scratch = tempfile::tempdir()?;
    let package = create(scratch.path())?;
    let path = package.to_str().unwrap();
    let input = scratch.path().join("capture.json");
    let file = input.to_str().unwrap();
    let empty = ProjectStore::open(&package, AccessMode::ReadOnly)?.snapshot()?;
    fs::write(&input, request(&empty)?.to_string())?;
    success(&["command", path, "--json", file])?;
    let before = ProjectStore::open(&package, AccessMode::ReadOnly)?.snapshot()?;
    let context = json!({"canvases": [{
        "width": 1920, "height": 1080, "fit": "fit",
        "layers": [{
            "center_x": {"numerator": "1", "denominator": "2"},
            "center_y": {"numerator": "1", "denominator": "2"},
            "scale": {"numerator": "27", "denominator": "20"}
        }, null]
    }]});
    let edit = json!({
        "protocol": 1, "project_id": before.project_id(),
        "expected_revision": before.revision_id(), "new_revision": "captured",
        "command": {"command": "set_hold_picture_context", "node": "hold", "context": context}
    });
    fs::write(&input, edit.to_string())?;
    let preview = success(&["command", path, "--json", file, "--dry-run"])?;
    assert_eq!(preview["edit"]["duration_delta"], 0);
    assert_eq!(
        ProjectStore::open(&package, AccessMode::ReadOnly)?.snapshot()?,
        before
    );
    let committed = success(&["command", path, "--json", file])?;
    assert_eq!(committed["outcome"]["edit"], preview["edit"]);
    let inspected = success(&["inspect-plan", path, "--frame", "17"])?;
    assert_eq!(inspected["sample"]["picture_context"], context);
    let captured = ProjectStore::open(&package, AccessMode::ReadOnly)?.snapshot()?;
    assert_eq!(captured.duration()?, before.duration()?);
    assert_eq!(captured.audio_bindings(), before.audio_bindings());
    let mut invalid = edit;
    invalid["expected_revision"] = json!(captured.revision_id());
    invalid["new_revision"] = json!("invalid-capture");
    invalid["command"]["context"]["canvases"][0]["width"] = json!(1919);
    fs::write(&input, invalid.to_string())?;
    assert!(!cli(&["command", path, "--json", file])?.status.success());
    assert_eq!(
        ProjectStore::open(&package, AccessMode::ReadOnly)?.snapshot()?,
        captured
    );
    invalid["new_revision"] = json!("clear-capture");
    invalid["command"]["context"] = Value::Null;
    fs::write(&input, invalid.to_string())?;
    success(&["command", path, "--json", file])?;
    let cleared = success(&["inspect-plan", path, "--frame", "17"])?;
    assert!(cleared["sample"]["picture_context"].is_null());
    success(&["project", "undo", path, "--expected", "clear-capture"])?;
    assert_eq!(
        ProjectStore::open(&package, AccessMode::ReadOnly)?
            .snapshot()?
            .nodes(),
        captured.nodes()
    );
    assert_eq!(
        success(&["inspect-plan", path, "--frame", "17"])?["sample"]["picture_context"],
        context
    );
    Ok(())
}

#[test]
fn headless_split_preview_commit_and_history_share_one_exact_command() -> Result {
    let scratch = tempfile::tempdir()?;
    let package = create(scratch.path())?;
    let path = package.to_str().unwrap();
    let input = scratch.path().join("split.json");
    let empty = ProjectStore::open(&package, AccessMode::ReadOnly)?.snapshot()?;
    fs::write(&input, request(&empty)?.to_string())?;
    success(&["command", path, "--json", input.to_str().unwrap()])?;
    let before = ProjectStore::open(&package, AccessMode::ReadOnly)?.snapshot()?;
    fs::write(
        &input,
        json!({
            "protocol":1, "project_id":before.project_id(),
            "expected_revision":before.revision_id(), "new_revision":"split-hold",
            "command":{"command":"split","node":"hold","at":17,
            "identities":{"nodes":["left","right","context"]}}
        })
        .to_string(),
    )?;
    let preview = success(&[
        "command",
        path,
        "--json",
        input.to_str().unwrap(),
        "--dry-run",
    ])?;
    assert_eq!(preview["edit"]["duration_delta"], 0);
    assert_eq!(
        ProjectStore::open(&package, AccessMode::ReadOnly)?.snapshot()?,
        before
    );
    let committed = success(&["command", path, "--json", input.to_str().unwrap()])?;
    assert_eq!(committed["outcome"]["edit"], preview["edit"]);
    let divided = ProjectStore::open(&package, AccessMode::ReadOnly)?.snapshot()?;
    assert_eq!(divided.duration()?, before.duration()?);
    let plan = deadpan_plan::RenderPlan::compile(&divided)?;
    assert_eq!(
        plan.node_duration(&NodeId::new("left")?).unwrap().frames(),
        17
    );
    assert_eq!(
        plan.node_duration(&NodeId::new("right")?).unwrap().frames(),
        28
    );
    let stale = cli(&["command", path, "--json", input.to_str().unwrap()])?;
    assert_eq!(
        serde_json::from_slice::<Value>(&stale.stderr)?["error"]["code"],
        "RevisionConflict"
    );
    let undone = success(&["project", "undo", path, "--expected", "split-hold"])?;
    assert_eq!(
        ProjectStore::open(&package, AccessMode::ReadOnly)?
            .snapshot()?
            .nodes(),
        before.nodes()
    );
    success(&[
        "project",
        "redo",
        path,
        "--expected",
        undone["outcome"]["revision_id"].as_str().unwrap(),
    ])?;
    assert_eq!(
        ProjectStore::open(&package, AccessMode::ReadOnly)?
            .snapshot()?
            .nodes(),
        divided.nodes()
    );
    Ok(())
}

fn current_repeat_fixture(root: &Path) -> Result<PathBuf> {
    let package = create(root)?;
    let mut store = ProjectStore::open(&package, AccessMode::ReadWrite)?;
    let initial = store.snapshot()?;
    let hold = NodeId::new("hold")?;
    let silent = |frames| -> Result<HoldRecipe> {
        Ok(HoldRecipe {
            picture_context: None,
            duration: FrameDuration::new(frames)?,
            video: HoldVideo::Background,
            audio: HoldAudio::Silence,
        })
    };
    store.commit(&deadpan_core::CommandRequest {
        project_id: initial.project_id().clone(),
        expected_revision: initial.revision_id().clone(),
        new_revision: deadpan_core::RevisionId::new("fixture-insert")?,
        command: Command::Insert {
            parent: initial.root().clone(),
            index: 0,
            subtree: Subtree {
                root: hold.clone(),
                nodes: BTreeMap::from([(hold.clone(), BeatNode::hold("Silence", silent(12)?))]),
                overrides: Default::default(),
                gap_overrides: Default::default(),
            },
        },
    })?;
    let before = store.snapshot()?;
    store.commit(&deadpan_core::CommandRequest {
        project_id: before.project_id().clone(),
        expected_revision: before.revision_id().clone(),
        new_revision: deadpan_core::RevisionId::new("fixture-wrap")?,
        command: Command::WrapRepeat {
            node: hold,
            id: NodeId::new("repeat")?,
            plays: 2,
            gap: Some(silent(2)?),
            anchor_policy: Default::default(),
        },
    })?;
    drop(store);
    Ok(package)
}

#[test]
fn headless_migration_and_plan_inspection_are_explicit_and_read_only() -> Result {
    let scratch = tempfile::tempdir()?;
    let package = current_repeat_fixture(scratch.path())?;
    let path = package.to_str().unwrap();
    // Full replay by default; `--quick` checks what opening checks.
    assert_eq!(
        success(&["project", "validate", path])?,
        success(&["project", "validate", path, "--quick"])?
    );
    let outcome = success(&["project", "migrate", path])?;
    assert_eq!(
        outcome["migration"]["from_schema"],
        deadpan_store::DATABASE_SCHEMA_VERSION
    );
    assert_eq!(
        outcome["migration"]["to_schema"],
        deadpan_store::DATABASE_SCHEMA_VERSION
    );
    assert!(outcome["migration"]["backup"].is_null());
    let writer = ProjectStore::open(&package, AccessMode::ReadWrite)?;
    let before = writer.snapshot()?;
    let plan = success(&["inspect-plan", path])?;
    assert_eq!(
        plan["plan"]["metadata"]["revision_id"],
        before.revision_id().as_str()
    );
    assert_eq!(plan["plan"]["metadata"]["duration"], 26);
    let first = success(&["inspect-plan", path, "--frame", "0"])?;
    assert_eq!(first["sample"]["picture"]["type"], "background");
    assert_eq!(
        first["sample"]["instance"]["repeats"][0]["iteration"]["ordinal"],
        0
    );
    let gap = success(&["inspect-plan", path, "--frame", "12"])?;
    assert_eq!(gap["sample"]["gap_after"]["allocation"], "fixture-wrap");
    let second = success(&["inspect-plan", path, "--frame", "14"])?;
    assert_eq!(
        second["sample"]["instance"]["repeats"][0]["iteration"]["ordinal"],
        1
    );
    for boundary in ["-1", "26"] {
        let error = cli(&["inspect-plan", path, "--frame", boundary])?;
        assert!(!error.status.success());
        assert_eq!(
            serde_json::from_slice::<Value>(&error.stderr)?["error"]["code"],
            "FrameOutOfRange"
        );
    }
    let mix_boundary = |frame| {
        before
            .presentation_basis()
            .frame_rate
            .audio_boundary(deadpan_core::ProjectFrame(frame))
            .unwrap()
            .0
    };
    let duration = mix_boundary(26).to_string();
    let audio = success(&["inspect-plan", path, "--audio-samples", "0", &duration])?;
    assert_eq!(audio["audio"]["revision_id"], before.revision_id().as_str());
    let spans = audio["audio"]["spans"].as_array().unwrap();
    assert_eq!(spans.len(), 3);
    assert_eq!(spans[0]["samples"]["end"], mix_boundary(12));
    assert_eq!(spans[1]["samples"]["start"], mix_boundary(12));
    assert_eq!(spans[1]["samples"]["end"], mix_boundary(14));
    assert_eq!(spans[1]["gap_after"]["allocation"], "fixture-wrap");
    assert_eq!(spans[2]["samples"]["end"], mix_boundary(26));
    assert_eq!(spans[0]["content"]["reason"], "silent_hold");
    for (start, end, code) in [
        ("-1", "1", "AudioRangeOutOfRange"),
        ("2", "1", "AudioRangeOutOfRange"),
        ("0", "invalid", "InvalidInput"),
    ] {
        let error = cli(&["inspect-plan", path, "--audio-samples", start, end])?;
        assert!(!error.status.success());
        assert_eq!(
            serde_json::from_slice::<Value>(&error.stderr)?["error"]["code"],
            code
        );
    }
    assert_eq!(writer.snapshot()?, before);
    Ok(())
}

#[test]
fn headless_edit_dry_run_conflict_and_durable_history() -> Result {
    let scratch = tempfile::tempdir()?;
    let package = create(scratch.path())?;
    let path = package.to_str().unwrap();
    let document = ProjectStore::open(&package, AccessMode::ReadOnly)?.snapshot()?;
    let input = scratch.path().join("command.json");
    fs::write(&input, serde_json::to_vec(&request(&document)?)?)?;
    let input = input.to_str().unwrap();
    let preview = success(&["command", path, "--json", input, "--dry-run"])?;
    assert_eq!(preview["committed"], false);
    assert_eq!(preview["edit"]["duration_delta"], 45);
    assert_eq!(
        ProjectStore::open(&package, AccessMode::ReadOnly)?.snapshot()?,
        document
    );

    let committed = success(&["command", path, "--json", input])?;
    assert_eq!(committed["committed"], true);
    assert_eq!(committed["outcome"]["edit"], preview["edit"]);
    let stale = cli(&["command", path, "--json", input])?;
    assert!(!stale.status.success());
    assert!(stale.stdout.is_empty());
    let error: Value = serde_json::from_slice(&stale.stderr)?;
    assert_eq!(error["error"]["code"], "RevisionConflict");
    assert_eq!(error["error"]["current_revision"], "after-hold");

    let undone = success(&["project", "undo", path, "--expected", "after-hold"])?;
    let undo_revision = undone["outcome"]["revision_id"].as_str().unwrap();
    assert_ne!(undo_revision, document.revision_id().as_str());
    let summary = success(&["project", "validate", path])?;
    assert_eq!(summary["duration_frames"], 0);
    success(&["project", "redo", path, "--expected", undo_revision])?;
    assert_eq!(
        success(&["project", "validate", path])?["duration_frames"],
        45
    );
    let dump_a = cli(&["project", "dump", path, "--json"])?;
    let dump_b = cli(&["project", "dump", path, "--json"])?;
    assert!(dump_a.status.success());
    assert_eq!(dump_a.stdout, dump_b.stdout, "dumps are deterministic");
    let checkpoint = success(&["project", "checkpoint", path])?;
    assert!(Path::new(checkpoint["database_checkpoint"].as_str().unwrap()).is_file());
    Ok(())
}

#[test]
fn independent_stream_mappings_use_headless_commands_and_durable_undo() -> Result {
    use deadpan_core::{
        AssetId, AssetRecord, AudioSample, EndpointPolicy, LinkRelation, NodeKind, SourceAudio,
        SourceAudioMapping, SourceNode, SourceSpan, SourceTimeBase, SourceTimestamp, SourceVideo,
        SourceVideoMapping,
    };

    let scratch = tempfile::tempdir()?;
    let package = create(scratch.path())?;
    let path = package.to_str().unwrap();
    let span = |start, end, denominator| {
        SourceSpan::new(
            SourceTimestamp {
                ticks: start,
                time_base: SourceTimeBase::new(1, denominator).unwrap(),
            },
            SourceTimestamp {
                ticks: end,
                time_base: SourceTimeBase::new(1, denominator).unwrap(),
            },
        )
        .unwrap()
    };
    let video = span(-90000, 90000, 90000);
    let audio = span(-48000, 0, 48000);
    let asset = AssetId::new("original")?;
    let source = NodeId::new("source")?;
    let input = scratch.path().join("audio-command.json");
    let write_command = |command: Command, new_revision: &str| -> Result {
        let document = ProjectStore::open(&package, AccessMode::ReadOnly)?.snapshot()?;
        fs::write(
            &input,
            json!({"protocol":1,"project_id":document.project_id(),
            "expected_revision":document.revision_id(),"new_revision":new_revision,
            "command":command})
            .to_string(),
        )?;
        Ok(())
    };
    write_command(
        Command::AddAsset {
            id: asset.clone(),
            asset: AssetRecord {
                source_qualification: None,
                label: "Timing fixture".into(),
                content_hash: "a".repeat(64),
                video: Some(video),
                audio: Some(audio),
                still_image: false,
                frame_count: None,
            },
        },
        "registered",
    )?;
    success(&["command", path, "--json", input.to_str().unwrap()])?;
    let root = ProjectStore::open(&package, AccessMode::ReadOnly)?
        .snapshot()?
        .root()
        .clone();
    write_command(
        Command::Insert {
            parent: root,
            index: 0,
            subtree: Subtree {
                root: source.clone(),
                overrides: Default::default(),
                gap_overrides: Default::default(),
                nodes: BTreeMap::from([(
                    source.clone(),
                    BeatNode {
                        audio_treatments: Default::default(),
                        framing: None,
                        audio_editorial_edges: Default::default(),
                        audio_edges: Default::default(),
                        label: "Two-second picture, one-second audio".into(),
                        kind: NodeKind::Source {
                            source: SourceNode {
                                edit_window: None,
                                duration: FrameDuration::new(60)?,
                                video: SourceVideo::Stream {
                                    asset: asset.clone(),
                                    span: video,
                                },
                                audio: Some(SourceAudio { asset, span: audio }),
                                audio_mapping: SourceAudioMapping::FitBeat,
                                video_mapping: SourceVideoMapping::FitBeat,
                                link: LinkRelation::Linked,
                                audio_offset: AudioSample(0),
                            },
                        },
                        cutaways: Vec::new(),
                        captions: Vec::new(),
                    },
                )]),
            },
        },
        "inserted",
    )?;
    success(&["command", path, "--json", input.to_str().unwrap()])?;
    let before = ProjectStore::open(&package, AccessMode::ReadOnly)?.snapshot()?;
    write_command(
        Command::SetSourceAudioMapping {
            node: source.clone(),
            mapping: SourceAudioMapping::natural_rate(
                audio,
                before.presentation_basis().frame_rate,
            )?,
            offset: AudioSample(16016),
        },
        "mapped",
    )?;
    let preview = success(&[
        "command",
        path,
        "--json",
        input.to_str().unwrap(),
        "--dry-run",
    ])?;
    assert_eq!(preview["edit"]["duration_delta"], 0);
    assert_eq!(
        ProjectStore::open(&package, AccessMode::ReadOnly)?.snapshot()?,
        before
    );
    success(&["command", path, "--json", input.to_str().unwrap()])?;
    let query = scratch.path().join("audio-boundary.json");
    let endpoint = || -> Result<Value> {
        let document = ProjectStore::open(&package, AccessMode::ReadOnly)?.snapshot()?;
        fs::write(&query, json!({"protocol":1,"request":{
            "project_id":document.project_id(),"expected_revision":document.revision_id(),"role":"audio",
            "selector":{"type":"point","target":{
                "boundary":{"coordinate":{"space":"source","asset":"original",
                    "moment":{"type":"audio_sample","sample":0,"sample_rate":48000}},"bias":"right"},
                "occurrence":{"node":"source","repeats":[]}
            }}
        }}).to_string())?;
        Ok(success(&["resolve-selection",path,"--json",query.to_str().unwrap()])?["resolved"]["selection"]["point"].clone())
    };
    assert_eq!(
        endpoint()?["exact_frame"],
        json!({"numerator":"40010","denominator":"1001"})
    );
    let stale = cli(&["command", path, "--json", input.to_str().unwrap()])?;
    assert_eq!(
        serde_json::from_slice::<Value>(&stale.stderr)?["error"]["code"],
        "RevisionConflict"
    );
    let undo = success(&["project", "undo", path, "--expected", "mapped"])?;
    assert_eq!(endpoint()?["frame"], 60);
    success(&[
        "project",
        "redo",
        path,
        "--expected",
        undo["outcome"]["revision_id"].as_str().unwrap(),
    ])?;
    assert_eq!(
        endpoint()?["exact_frame"],
        json!({"numerator":"40010","denominator":"1001"})
    );
    assert_eq!(
        success(&["project", "validate", path])?["duration_frames"],
        60
    );
    let before_video = ProjectStore::open(&package, AccessMode::ReadOnly)?.snapshot()?;
    write_command(
        Command::SetSourceVideoMapping {
            node: source,
            mapping: SourceVideoMapping::natural_rate(
                video,
                before_video.presentation_basis().frame_rate,
                EndpointPolicy::HoldAdjacent,
            )?,
        },
        "video-mapped",
    )?;
    let preview = success(&[
        "command",
        path,
        "--json",
        input.to_str().unwrap(),
        "--dry-run",
    ])?;
    assert_eq!(preview["edit"]["duration_delta"], 0);
    assert_eq!(
        ProjectStore::open(&package, AccessMode::ReadOnly)?.snapshot()?,
        before_video
    );
    success(&["command", path, "--json", input.to_str().unwrap()])?;
    let video_endpoint = || -> Result<Value> {
        let document = ProjectStore::open(&package, AccessMode::ReadOnly)?.snapshot()?;
        fs::write(&query, json!({"protocol":1,"request":{
            "project_id":document.project_id(),"expected_revision":document.revision_id(),"role":"video",
            "selector":{"type":"point","target":{
                "boundary":{"coordinate":{"space":"source","asset":"original",
                    "moment":{"type":"timestamp","stream":"video","timestamp":{
                        "ticks":90000,"time_base":{"numerator":1,"denominator":90000}
                    }}},"bias":"right"},
                "occurrence":{"node":"source","repeats":[]}
            }}
        }}).to_string())?;
        Ok(success(&["resolve-selection",path,"--json",query.to_str().unwrap()])?["resolved"]["selection"]["point"].clone())
    };
    assert_eq!(
        video_endpoint()?["exact_frame"],
        json!({"numerator":"60000","denominator":"1001"})
    );
    assert_eq!(
        endpoint()?["exact_frame"],
        json!({"numerator":"40010","denominator":"1001"})
    );
    let undo = success(&["project", "undo", path, "--expected", "video-mapped"])?;
    assert_eq!(video_endpoint()?["frame"], 60);
    success(&[
        "project",
        "redo",
        path,
        "--expected",
        undo["outcome"]["revision_id"].as_str().unwrap(),
    ])?;
    assert_eq!(
        video_endpoint()?["exact_frame"],
        json!({"numerator":"60000","denominator":"1001"})
    );
    assert_eq!(
        endpoint()?["exact_frame"],
        json!({"numerator":"40010","denominator":"1001"})
    );
    let stale = cli(&["command", path, "--json", input.to_str().unwrap()])?;
    assert_eq!(
        serde_json::from_slice::<Value>(&stale.stderr)?["error"]["code"],
        "RevisionConflict"
    );
    success(&["project", "validate", path])?;
    Ok(())
}

#[test]
fn current_generation_is_reconciled_by_cli_writes_and_preview_writes_nothing() -> Result {
    use deadpan_store::generation::GenerationRequestInput;

    let scratch = tempfile::tempdir()?;
    let package = create(scratch.path())?;
    let path = package.to_str().unwrap();
    let document = ProjectStore::open(&package, AccessMode::ReadOnly)?.snapshot()?;
    let input = scratch.path().join("command.json");
    fs::write(&input, serde_json::to_vec(&request(&document)?)?)?;
    success(&["command", path, "--json", input.to_str().unwrap()])?;

    let mut store = ProjectStore::open(&package, AccessMode::ReadWrite)?;
    let before = store.snapshot()?;
    let generation = store.allocate_generation_request(GenerationRequestInput {
        request_id: serde_json::from_value(json!("pending-generation"))?,
        expected_revision: before.revision_id().clone(),
        hold_id: NodeId::new("hold")?,
        context_sha256: serde_json::from_value(json!("a".repeat(64)))?,
        constraints: serde_json::from_value(json!({
            "video": {"frames": 45, "frame_rate": before.presentation_basis().frame_rate,
                      "width": 768, "height": 320},
            "conditioning": "bridge", "motion": "still"
        }))?,
        provider: serde_json::from_value(json!({
            "pack_id": "fixture", "pack_version": "1", "runtime_id": "fixture",
            "runtime_version": "1", "seed": 7
        }))?,
    })?;
    drop(store);
    fs::write(
        &input,
        serde_json::to_vec(&json!({
            "protocol": 1, "project_id": before.project_id(),
            "expected_revision": before.revision_id(), "new_revision": "renamed",
            "command": {"command": "rename", "node": "hold", "label": "Renamed"}
        }))?,
    )?;
    assert_eq!(
        success(&[
            "command",
            path,
            "--json",
            input.to_str().unwrap(),
            "--dry-run"
        ])?["committed"],
        false
    );
    // A rename leaves the Hold's boundary context unchanged, so the CLI
    // writer keeps the request current through commit and undo.
    success(&["command", path, "--json", input.to_str().unwrap()])?;
    success(&["project", "undo", path, "--expected", "renamed"])?;
    let reader = ProjectStore::open(&package, AccessMode::ReadOnly)?;
    assert_eq!(reader.current_generation_requests()?, vec![generation]);
    Ok(())
}

#[test]
fn current_migration_rejects_bad_history_without_writes_or_backup() -> Result {
    let scratch = tempfile::tempdir()?;
    let package = current_repeat_fixture(scratch.path())?;
    let database = package.join("project.sqlite");
    let connection = rusqlite::Connection::open(&database)?;
    connection.execute_batch(
        "UPDATE history SET edit=json_set(edit,'$.duration_delta',999) WHERE revision_id='fixture-wrap'",
    )?;
    drop(connection);
    let before = fs::read(&database)?;
    let output = cli(&["project", "migrate", package.to_str().unwrap()])?;
    assert!(!output.status.success());
    assert!(output.stdout.is_empty());
    let report: Value = serde_json::from_slice(&output.stderr)?;
    assert_eq!(report["error"]["code"], "ProjectFailure");
    // A longer stored edit also exceeds its revision's recorded size bound.
    let message = report["error"]["message"].as_str().unwrap();
    assert!(
        message.contains("stored command, patches, and revision disagree")
            || message.contains("revision keyframe metadata disagrees"),
        "{message}"
    );
    assert!(report["error"]["recovery_backup"].is_null());
    assert_eq!(fs::read(database)?, before);
    assert_eq!(fs::read_dir(package.join("Snapshots"))?.count(), 0);
    Ok(())
}

#[test]
fn writer_lock_is_enforced_between_processes_but_readers_and_dry_run_work() -> Result {
    let scratch = tempfile::tempdir()?;
    let package = create(scratch.path())?;
    let writer = ProjectStore::open(&package, AccessMode::ReadWrite)?;
    let document = writer.snapshot()?;
    let input = scratch.path().join("command.json");
    fs::write(&input, serde_json::to_vec(&request(&document)?)?)?;
    let path = package.to_str().unwrap();
    let input = input.to_str().unwrap();
    success(&["project", "validate", path])?;
    success(&["command", path, "--json", input, "--dry-run"])?;
    let output = cli(&["command", path, "--json", input])?;
    assert!(!output.status.success());
    assert_eq!(
        serde_json::from_slice::<Value>(&output.stderr)?["error"]["code"],
        "HostOwnerUnavailable"
    );
    assert_eq!(writer.snapshot()?, document);
    Ok(())
}

#[test]
fn malformed_or_future_protocol_is_rejected_before_mutation() -> Result {
    let scratch = tempfile::tempdir()?;
    let package = create(scratch.path())?;
    let document = ProjectStore::open(&package, AccessMode::ReadOnly)?.snapshot()?;
    let input = scratch.path().join("command.json");
    let mut request = request(&document)?;
    request["protocol"] = 999.into();
    fs::write(&input, serde_json::to_vec(&request)?)?;
    let output = cli(&[
        "command",
        package.to_str().unwrap(),
        "--json",
        input.to_str().unwrap(),
    ])?;
    assert!(!output.status.success());
    assert_eq!(
        serde_json::from_slice::<Value>(&output.stderr)?["error"]["code"],
        "ProtocolUnsupported"
    );
    request["protocol"] = 1.into();
    request["shell"] = "unexpected".into();
    fs::write(&input, serde_json::to_vec(&request)?)?;
    assert!(
        !cli(&[
            "command",
            package.to_str().unwrap(),
            "--json",
            input.to_str().unwrap()
        ])?
        .status
        .success()
    );
    assert_eq!(
        ProjectStore::open(&package, AccessMode::ReadOnly)?.snapshot()?,
        document
    );
    Ok(())
}

#[test]
fn history_dry_runs_work_with_a_writer_and_preserve_the_redo_path() -> Result {
    let scratch = tempfile::tempdir()?;
    let package = create(scratch.path())?;
    let path = package.to_str().unwrap();
    let document = ProjectStore::open(&package, AccessMode::ReadOnly)?.snapshot()?;
    let input = scratch.path().join("command.json");
    fs::write(&input, serde_json::to_vec(&request(&document)?)?)?;
    success(&["command", path, "--json", input.to_str().unwrap()])?;
    let writer = ProjectStore::open(&package, AccessMode::ReadWrite)?;
    let before = writer.snapshot()?;
    let preview = success(&[
        "project",
        "undo",
        path,
        "--expected",
        "after-hold",
        "--dry-run",
    ])?;
    assert_eq!(preview["committed"], false);
    assert_eq!(preview["outcome"]["edit"]["duration_delta"], -45);
    assert_eq!(writer.snapshot()?, before);
    let stale = cli(&["project", "undo", path, "--expected", "stale", "--dry-run"])?;
    assert!(!stale.status.success());
    assert_eq!(
        serde_json::from_slice::<Value>(&stale.stderr)?["error"]["code"],
        "RevisionConflict"
    );
    drop(writer);
    let undone = success(&["project", "undo", path, "--expected", "after-hold"])?;
    let revision = undone["outcome"]["revision_id"].as_str().unwrap();
    let writer = ProjectStore::open(&package, AccessMode::ReadWrite)?;
    let before = writer.snapshot()?;
    let preview = success(&["project", "redo", path, "--expected", revision, "--dry-run"])?;
    assert_eq!(preview["committed"], false);
    assert_eq!(preview["outcome"]["edit"]["duration_delta"], 45);
    assert_eq!(writer.snapshot()?, before);
    drop(writer);
    success(&["project", "redo", path, "--expected", revision])?;
    assert_eq!(
        success(&["project", "validate", path])?["duration_frames"],
        45
    );
    Ok(())
}

#[test]
fn dry_run_and_commit_preserve_actionable_domain_errors() -> Result {
    let scratch = tempfile::tempdir()?;
    let package = create(scratch.path())?;
    let document = ProjectStore::open(&package, AccessMode::ReadOnly)?.snapshot()?;
    let base = request(&document)?;
    let input = scratch.path().join("rejected.json");

    let mut zero = base.clone();
    zero["command"]["subtree"]["nodes"]["hold"]["kind"]["recipe"]["duration"] = json!(0);
    let mut range = base.clone();
    range["command"]["subtree"]["root"] = json!("retime");
    range["command"]["subtree"]["nodes"]["retime"] = json!({
        "label": "Invalid child range", "kind": {"type": "retime", "child": "hold", "duration": 12,
        "mapping": {"start": 0, "end": 46}, "pitch": "preserve"}
    });
    let mut overflow = base.clone();
    overflow["command"]["subtree"]["nodes"]["hold"]["kind"]["recipe"]["duration"] = json!(i64::MAX);
    overflow["command"]["subtree"]["root"] = json!("repeat");
    overflow["command"]["subtree"]["nodes"]["repeat"] = json!({
        "label": "Overflow", "kind": {"type": "repeat", "child": "hold", "iterations": {"runs": [{"allocation": "overflow", "first": 0, "count": 2}]}, "gap": null}
    });
    let mut limit = base;
    limit["command"]["subtree"]["nodes"]["hold"]["label"] = json!("x".repeat(1025));
    for (request, code) in [
        (zero, "InvalidDuration"),
        (range, "SourceRangeInvalid"),
        (overflow, "TimingOverflow"),
        (limit, "LimitExceeded"),
    ] {
        fs::write(&input, serde_json::to_vec(&request)?)?;
        for dry_run in [false, true] {
            let mut args = vec![
                "command",
                package.to_str().unwrap(),
                "--json",
                input.to_str().unwrap(),
            ];
            if dry_run {
                args.push("--dry-run");
            }
            let output = cli(&args)?;
            assert!(!output.status.success());
            assert!(output.stdout.is_empty());
            assert_eq!(
                serde_json::from_slice::<Value>(&output.stderr)?["error"]["code"],
                code
            );
            assert_eq!(
                ProjectStore::open(&package, AccessMode::ReadOnly)?.snapshot()?,
                document
            );
        }
    }
    Ok(())
}

#[test]
fn selection_resolution_is_revision_checked_exact_and_read_only() -> Result {
    let scratch = tempfile::tempdir()?;
    let package = create(scratch.path())?;
    let path = package.to_str().unwrap();
    let document = ProjectStore::open(&package, AccessMode::ReadOnly)?.snapshot()?;
    let insert_path = scratch.path().join("insert.json");
    fs::write(&insert_path, request(&document)?.to_string())?;
    success(&["command", path, "--json", insert_path.to_str().unwrap()])?;
    let writer = ProjectStore::open(&package, AccessMode::ReadWrite)?;
    let before = writer.snapshot()?;
    let selection_path = scratch.path().join("selection.json");
    let point = |numerator: &str| {
        json!({
            "boundary": { "coordinate": { "space": "local", "node": "hold", "position": { "numerator": numerator, "denominator": "2" } }, "bias": "right" }
        })
    };
    let mut envelope = json!({
        "protocol": 1,
        "request": {
            "project_id": before.project_id(), "expected_revision": before.revision_id(), "role": "audio",
            "selector": { "type": "range", "start": point("5"), "end": point("7") }
        }
    });
    fs::write(&selection_path, envelope.to_string())?;
    let args = [
        "resolve-selection",
        path,
        "--json",
        selection_path.to_str().unwrap(),
    ];
    let output = success(&args)?;
    assert_eq!(
        output["resolved"]["revision_id"],
        before.revision_id().as_str()
    );
    assert_eq!(output["resolved"]["role"], "audio");
    assert_eq!(
        output["resolved"]["selection"]["start"]["exact_frame"]["numerator"],
        "5"
    );
    assert_eq!(
        output["resolved"]["selection"]["frames"],
        json!({ "start": 2, "end": 4 })
    );
    envelope["request"]["expected_revision"] = json!("stale");
    fs::write(&selection_path, envelope.to_string())?;
    let output = cli(&args)?;
    assert!(!output.status.success());
    let error: Value = serde_json::from_slice(&output.stderr)?;
    assert_eq!(error["error"]["code"], "RevisionConflict");
    assert_eq!(
        error["error"]["current_revision"],
        before.revision_id().as_str()
    );
    envelope["request"]["expected_revision"] = json!(before.revision_id());
    envelope["request"]["selector"]["end"] = point("4");
    fs::write(&selection_path, envelope.to_string())?;
    let output = cli(&args)?;
    assert!(!output.status.success());
    assert_eq!(
        serde_json::from_slice::<Value>(&output.stderr)?["error"]["code"],
        "InvalidRange"
    );
    envelope["protocol"] = json!(2);
    fs::write(&selection_path, envelope.to_string())?;
    let output = cli(&args)?;
    assert!(!output.status.success());
    assert_eq!(
        serde_json::from_slice::<Value>(&output.stderr)?["error"]["code"],
        "ProtocolUnsupported"
    );
    assert_eq!(writer.snapshot()?, before);
    Ok(())
}

#[test]
fn persistent_mark_queries_and_loss_states_share_the_headless_command_path() -> Result {
    use deadpan_core::{
        Anchor, AnchorLossPolicy, BoundaryAnchor, ExactRatio, InsertionBias, MarkId, ProjectFrame,
    };
    let scratch = tempfile::tempdir()?;
    let package = create(scratch.path())?;
    let path = package.to_str().unwrap();
    let initial = ProjectStore::open(&package, AccessMode::ReadOnly)?.snapshot()?;
    let command_file = scratch.path().join("command.json");
    let command_path = command_file.to_str().unwrap();
    fs::write(&command_file, request(&initial)?.to_string())?;
    success(&["command", path, "--json", command_path])?;
    let write_command = |command: Command, revision: &str| -> Result {
        let document = ProjectStore::open(&package, AccessMode::ReadOnly)?.snapshot()?;
        fs::write(&command_file,json!({"protocol":1,"project_id":document.project_id(),"expected_revision":document.revision_id(),"new_revision":revision,"command":command}).to_string())?;
        Ok(())
    };
    let writer = ProjectStore::open(&package, AccessMode::ReadWrite)?;
    let before = writer.snapshot()?;
    write_command(
        Command::SetMark {
            id: MarkId::new("a")?,
            owner: before.root().clone(),
            label: "Start of the pause".into(),
            boundary: BoundaryAnchor {
                coordinate: Anchor::Local {
                    node: NodeId::new("hold")?,
                    position: ExactRatio::integer(12),
                },
                bias: InsertionBias::Right,
            },
            loss_policy: AnchorLossPolicy::KeepUnresolved,
        },
        "mark-a",
    )?;
    let dry = success(&["command", path, "--json", command_path, "--dry-run"])?;
    assert_eq!(
        dry["edit"]["forward"]["marks"]["a"]["after"]["state"]["type"],
        "bound"
    );
    assert_eq!(writer.snapshot()?, before);
    drop(writer);
    success(&["command", path, "--json", command_path])?;
    write_command(
        Command::SetMark {
            id: MarkId::new("b")?,
            owner: before.root().clone(),
            label: "Pinned end".into(),
            boundary: BoundaryAnchor {
                coordinate: Anchor::Sequence {
                    frame: ProjectFrame(20),
                },
                bias: InsertionBias::Left,
            },
            loss_policy: AnchorLossPolicy::KeepUnresolved,
        },
        "mark-b",
    )?;
    success(&["command", path, "--json", command_path])?;
    let selection_file = scratch.path().join("selection.json");
    let query = |selector: Value| -> Result<Output> {
        let document = ProjectStore::open(&package, AccessMode::ReadOnly)?.snapshot()?;
        fs::write(&selection_file,json!({"protocol":1,"request":{"project_id":document.project_id(),"expected_revision":document.revision_id(),"role":"linked","selector":selector}}).to_string())?;
        cli(&[
            "resolve-selection",
            path,
            "--json",
            selection_file.to_str().unwrap(),
        ])
    };
    let writer = ProjectStore::open(&package, AccessMode::ReadWrite)?;
    let output = query(json!({"type":"mark_range","start":{"id":"a"},"end":{"id":"b"}}))?;
    assert!(
        output.status.success(),
        "{}",
        String::from_utf8_lossy(&output.stderr)
    );
    assert_eq!(
        serde_json::from_slice::<Value>(&output.stdout)?["resolved"]["selection"]["frames"],
        json!({"start":12,"end":20})
    );
    drop(writer);
    write_command(
        Command::Delete {
            node: NodeId::new("hold")?,
        },
        "delete-hold",
    )?;
    success(&["command", path, "--json", command_path])?;
    let output = query(json!({"type":"mark","target":{"id":"a"}}))?;
    assert!(!output.status.success());
    assert_eq!(
        serde_json::from_slice::<Value>(&output.stderr)?["error"]["code"],
        "MarkUnresolved"
    );
    let document = ProjectStore::open(&package, AccessMode::ReadOnly)?.snapshot()?;
    success(&[
        "project",
        "undo",
        path,
        "--expected",
        document.revision_id().as_str(),
    ])?;
    let output = query(json!({"type":"mark","target":{"id":"a"}}))?;
    assert!(output.status.success());
    assert_eq!(
        serde_json::from_slice::<Value>(&output.stdout)?["resolved"]["selection"]["point"]["frame"],
        12
    );
    let output = query(json!({"type":"mark","target":{"id":"missing"}}))?;
    assert!(!output.status.success());
    assert_eq!(
        serde_json::from_slice::<Value>(&output.stderr)?["error"]["code"],
        "MarkMissing"
    );
    Ok(())
}

#[test]
fn sparse_override_commands_and_inspection_share_revision_and_dry_run_guards() -> Result {
    use deadpan_core::{NodeKind, WrapAnchorPolicy};
    let scratch = tempfile::tempdir()?;
    let package = create(scratch.path())?;
    let path = package.to_str().unwrap();
    let file = scratch.path().join("command.json");
    let file_path = file.to_str().unwrap();
    let snapshot = || -> Result<ProjectDocument> {
        Ok(ProjectStore::open(&package, AccessMode::ReadOnly)?.snapshot()?)
    };
    fs::write(&file, request(&snapshot()?)?.to_string())?;
    success(&["command", path, "--json", file_path])?;
    let write = |command: Command| -> Result {
        let current = snapshot()?;
        fs::write(&file, json!({
            "protocol":1,"project_id":current.project_id(),"expected_revision":current.revision_id(),"command":command
        }).to_string())?;
        Ok(())
    };
    write(Command::WrapRepeat {
        node: NodeId::new("hold")?,
        id: NodeId::new("repeat")?,
        plays: 3,
        gap: None,
        anchor_policy: WrapAnchorPolicy::First,
    })?;
    success(&["command", path, "--json", file_path])?;
    let before = snapshot()?;
    let NodeKind::Repeat { iterations, .. } = &before.nodes()[&NodeId::new("repeat")?].kind else {
        panic!()
    };
    let selected = iterations.at(1).unwrap();
    write(Command::SetPlayOverride {
        node: NodeId::new("repeat")?,
        iteration: selected.clone(),
        subtree: Subtree {
            root: NodeId::new("custom")?,
            overrides: BTreeMap::new(),
            gap_overrides: BTreeMap::new(),
            nodes: BTreeMap::from([(
                NodeId::new("custom")?,
                BeatNode::hold(
                    "Longer pause",
                    HoldRecipe {
                        picture_context: None,
                        duration: FrameDuration::new(60)?,
                        video: HoldVideo::Background,
                        audio: HoldAudio::Silence,
                    },
                ),
            )]),
        },
    })?;
    let writer = ProjectStore::open(&package, AccessMode::ReadWrite)?;
    let preview = success(&["command", path, "--json", file_path, "--dry-run"])?;
    assert_eq!(preview["edit"]["duration_delta"], 15);
    assert_eq!(
        preview["edit"]["forward"]["overrides"]["repeat"]["after"][0]["iteration"],
        serde_json::to_value(&selected)?
    );
    assert_eq!(writer.snapshot()?, before);
    drop(writer);
    success(&["command", path, "--json", file_path])?;
    // Replaying an already committed request must fail before allocating another subtree.
    let stale = cli(&["command", path, "--json", file_path])?;
    assert!(!stale.status.success());
    assert_eq!(
        serde_json::from_slice::<Value>(&stale.stderr)?["error"]["code"],
        "RevisionConflict"
    );
    let writer = ProjectStore::open(&package, AccessMode::ReadWrite)?;
    let after = writer.snapshot()?;
    assert_eq!(after.duration()?.frames(), 150);
    let inspected = success(&["inspect-plan", path, "--frame", "46"])?;
    assert_eq!(inspected["sample"]["instance"]["node"], "custom");
    assert_eq!(
        inspected["sample"]["instance"]["repeats"][0]["iteration"],
        serde_json::to_value(&selected)?
    );
    assert_eq!(writer.snapshot()?, after);
    drop(writer);
    write(Command::ClearPlayOverride {
        node: NodeId::new("repeat")?,
        iteration: selected,
    })?;
    success(&["command", path, "--json", file_path])?;
    let cleared = snapshot()?;
    assert_eq!(cleared.duration()?.frames(), 135);
    assert!(cleared.overrides().is_empty());
    success(&[
        "project",
        "undo",
        path,
        "--expected",
        cleared.revision_id().as_str(),
    ])?;
    assert_eq!(snapshot()?.overrides(), after.overrides());
    Ok(())
}

#[test]
fn nested_occurrence_command_is_atomic_and_uses_the_same_headless_plan() -> Result {
    use deadpan_core::{NodeKind, WrapAnchorPolicy};
    let scratch = tempfile::tempdir()?;
    let package = create(scratch.path())?;
    let path = package.to_str().unwrap();
    let file = scratch.path().join("command.json");
    let file_path = file.to_str().unwrap();
    let snapshot = || -> Result<ProjectDocument> {
        Ok(ProjectStore::open(&package, AccessMode::ReadOnly)?.snapshot()?)
    };
    fs::write(&file, request(&snapshot()?)?.to_string())?;
    success(&["command", path, "--json", file_path])?;
    for (child, id) in [("hold", "inner"), ("inner", "outer")] {
        let current = snapshot()?;
        fs::write(&file,json!({"protocol":1,"project_id":current.project_id(),"expected_revision":current.revision_id(),
            "command":Command::WrapRepeat {node:NodeId::new(child)?,id:NodeId::new(id)?,plays:2,gap:None,anchor_policy:WrapAnchorPolicy::First}
        }).to_string())?;
        success(&["command", path, "--json", file_path])?;
    }
    let before = snapshot()?;
    let play = |name: &str| -> Result<Value> {
        let NodeKind::Repeat { iterations, .. } = &before.nodes()[&NodeId::new(name)?].kind else {
            panic!()
        };
        Ok(serde_json::to_value(iterations.at(1).unwrap())?)
    };
    fs::write(&file,json!({"protocol":1,"project_id":before.project_id(),"expected_revision":before.revision_id(),
        "new_revision":"occurrence-change",
        "command":{"command":"edit_occurrence",
            "instance":{"node":"hold","repeats":[{"node":"outer","iteration":play("outer")?},{"node":"inner","iteration":play("inner")?}]},
            "edit":{"type":"set_hold_duration","duration":60},
            "identities":{"nodes":["outer-inner","outer-default","selected-hold"],"marks":[]}
        }
    }).to_string())?;
    let writer = ProjectStore::open(&package, AccessMode::ReadWrite)?;
    let preview = success(&["command", path, "--json", file_path, "--dry-run"])?;
    assert_eq!(preview["edit"]["duration_delta"], 15);
    assert_eq!(writer.snapshot()?, before);
    drop(writer);
    let committed = success(&["command", path, "--json", file_path])?;
    assert_eq!(committed["outcome"]["edit"], preview["edit"]);
    let after = snapshot()?;
    assert_eq!(after.duration()?.frames(), 195);
    assert_eq!(after.nodes().len(), before.nodes().len() + 3);
    let selected = success(&["inspect-plan", path, "--frame", "136"])?;
    assert_eq!(selected["sample"]["instance"]["node"], "selected-hold");
    assert_eq!(
        selected["sample"]["instance"]["repeats"][1]["node"],
        "outer-inner"
    );
    let other = success(&["inspect-plan", path, "--frame", "46"])?;
    assert_eq!(other["sample"]["instance"]["node"], "hold");
    success(&[
        "project",
        "undo",
        path,
        "--expected",
        after.revision_id().as_str(),
    ])?;
    let undone = snapshot()?;
    assert_eq!(undone.nodes(), before.nodes());
    assert_eq!(undone.overrides(), before.overrides());
    success(&[
        "project",
        "redo",
        path,
        "--expected",
        undone.revision_id().as_str(),
    ])?;
    let redone = snapshot()?;
    assert_eq!(redone.nodes(), after.nodes());
    assert_eq!(redone.overrides(), after.overrides());
    Ok(())
}

#[test]
fn obsolete_schema_cli_validation_and_migration_refuse_without_writes_or_backup() -> Result {
    for version in [1, 38, 52, 55] {
        let scratch = tempfile::tempdir()?;
        let package = scratch.path().join("obsolete.deadpan");
        fs::create_dir(&package)?;
        fs::create_dir(package.join("Snapshots"))?;
        let database_path = package.join("project.sqlite");
        let connection = rusqlite::Connection::open(&database_path)?;
        connection.execute_batch("PRAGMA application_id=1146113585; CREATE TABLE untouched(value); INSERT INTO untouched VALUES('unparsed old state');")?;
        connection.pragma_update(None, "user_version", version)?;
        drop(connection);
        let before = fs::read(&database_path)?;
        for verb in ["validate", "migrate"] {
            let output = cli(&["project", verb, package.to_str().unwrap()])?;
            assert!(!output.status.success());
            assert!(output.stdout.is_empty());
            let report: Value = serde_json::from_slice(&output.stderr)?;
            assert_eq!(report["error"]["code"], "SchemaUnsupported");
            assert!(report["error"]["recovery_backup"].is_null());
            assert_eq!(fs::read(&database_path)?, before);
            assert_eq!(fs::read_dir(package.join("Snapshots"))?.count(), 0);
            assert_eq!(fs::read_dir(&package)?.count(), 2);
        }
    }
    Ok(())
}

#[test]
fn storage_report_states_the_ai_variant_retention_policy() -> Result {
    let root = tempfile::tempdir()?;
    let package = create(root.path())?;
    let path = package.to_str().ok_or("UTF-8")?;
    let report = success(&["project", "storage", path])?;
    let retention = &report["project"]["variant_retention"];
    assert_eq!(retention["retention_seconds"], 7 * 24 * 60 * 60, "{report}");
    for field in [
        "offered",
        "kept",
        "selected",
        "accepted",
        "expiring",
        "due",
        "discarded",
        "expired",
        "evicted_awaiting_cleanup",
        "evicted_awaiting_cleanup_bytes",
    ] {
        assert_eq!(retention[field], 0, "{field}");
    }
    assert!(retention.get("soonest_expiry_unix_seconds").is_none());
    let cleanup = success(&["project", "storage", path, "--clean", "--dry-run"])?;
    assert_eq!(cleanup["variant_expiry"]["dry_run"], true);
    assert_eq!(cleanup["variant_expiry"]["expired"], json!([]));
    // Keeping names an offered variant; an unknown one is refused.
    let refused = cli(&[
        "keep-hold",
        path,
        "--request",
        "no-such-request",
        "--attempt",
        "no-such-attempt",
    ])?;
    assert!(!refused.status.success());
    let usage = cli(&["keep-hold", path, "--request", "r"])?;
    assert!(!usage.status.success());
    Ok(())
}

#[test]
fn dry_runs_report_warnings_and_required_jobs() -> Result {
    use deadpan_core::{
        Anchor, AnchorLossPolicy, AudioTimingId, BoundaryAnchor, ExactRatio, InsertionBias, MarkId,
        ProjectFrame, RevisionId, SplitIdentities,
    };
    let scratch = tempfile::tempdir()?;
    let package = create(scratch.path())?;
    let path = package.to_str().unwrap();
    let command_file = scratch.path().join("command.json");
    let command_path = command_file.to_str().unwrap();
    let initial = ProjectStore::open(&package, AccessMode::ReadOnly)?.snapshot()?;
    fs::write(&command_file, request(&initial)?.to_string())?;
    let plain = success(&["command", path, "--json", command_path, "--dry-run"])?;
    assert_eq!(plain["warnings"], json!([]));
    assert_eq!(plain["required_jobs"], json!([]));
    success(&["command", path, "--json", command_path])?;
    let write_command = |command: Command, revision: &str| -> Result {
        let document = ProjectStore::open(&package, AccessMode::ReadOnly)?.snapshot()?;
        fs::write(&command_file,json!({"protocol":1,"project_id":document.project_id(),"expected_revision":document.revision_id(),"new_revision":revision,"command":command}).to_string())?;
        Ok(())
    };
    write_command(
        Command::SetMark {
            id: MarkId::new("inside")?,
            owner: NodeId::new("hold")?,
            label: "Inside the pause".into(),
            boundary: BoundaryAnchor {
                coordinate: Anchor::Local {
                    node: NodeId::new("hold")?,
                    position: ExactRatio::integer(12),
                },
                bias: InsertionBias::Right,
            },
            loss_policy: AnchorLossPolicy::DeleteOwned,
        },
        "marked",
    )?;
    success(&["command", path, "--json", command_path])?;
    write_command(
        Command::DeleteRipple {
            node: NodeId::new("hold")?,
            timing: AudioTimingId {
                allocation: RevisionId::new("deleted")?,
                ordinal: 0,
            },
        },
        "deleted",
    )?;
    let deletion = success(&["command", path, "--json", command_path, "--dry-run"])?;
    assert_eq!(deletion["warnings"][0]["code"], "marks_removed");
    assert_eq!(deletion["warnings"][0]["ids"], json!(["inside"]));
    write_command(
        Command::InsertAiTime {
            at: ProjectFrame(0),
            hold: HoldRecipe {
                picture_context: None,
                duration: FrameDuration::new(15)?,
                video: HoldVideo::Background,
                audio: HoldAudio::Silence,
            },
            id: NodeId::new("ai-pause")?,
            identities: SplitIdentities::default(),
            timing: AudioTimingId {
                allocation: RevisionId::new("ai")?,
                ordinal: 0,
            },
        },
        "ai",
    )?;
    let ai = success(&["command", path, "--json", command_path, "--dry-run"])?;
    assert_eq!(
        ai["required_jobs"],
        json!([{"job": "ai_generation", "target": "ai-pause"}])
    );
    assert_eq!(
        ProjectStore::open(&package, AccessMode::ReadOnly)?
            .snapshot()?
            .revision_id(),
        &RevisionId::new("marked")?
    );
    Ok(())
}
