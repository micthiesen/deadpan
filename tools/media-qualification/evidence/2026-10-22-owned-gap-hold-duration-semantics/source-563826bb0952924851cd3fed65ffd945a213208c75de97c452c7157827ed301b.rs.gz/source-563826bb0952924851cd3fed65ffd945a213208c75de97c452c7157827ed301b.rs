use super::*;
use crate::*;

mod mixed;
mod scoped;

fn id(name: &str) -> NodeId {
    NodeId::new(name).unwrap()
}
fn revision(name: &str) -> RevisionId {
    RevisionId::new(name).unwrap()
}
fn hold(frames: i64) -> HoldRecipe {
    HoldRecipe {
        duration: FrameDuration::new(frames).unwrap(),
        video: HoldVideo::Background,
        audio: HoldAudio::Silence,
        picture_context: None,
    }
}
fn repeated(name: &str, child: &str, plays: u32, gap: i64) -> BeatNode {
    let mut result = BeatNode::sequence(name, vec![]);
    result.kind = NodeKind::Repeat {
        child: id(child),
        iterations: IterationOrder::new(revision(name), plays).unwrap(),
        gap: Some(hold(gap)),
        escalation: None,
    };
    result
}
fn fixture(nested: bool) -> ProjectDocument {
    let mut document = ProjectDocument::new(
        ProjectId::new("pause-plays").unwrap(),
        revision("before"),
        PresentationBasis {
            width: 64,
            height: 36,
            frame_rate: FrameRate::new(30_000, 1001).unwrap(),
            color_policy: ColorPolicy::SdrRec709,
        },
        id("root"),
    )
    .unwrap();
    document.nodes.extend([
        (
            id("root"),
            BeatNode::sequence("root", vec![id("outer"), id("tail")]),
        ),
        (
            id("outer"),
            repeated("outer", if nested { "body" } else { "a" }, 3, 2),
        ),
        (id("a"), BeatNode::hold("a", hold(4))),
        (id("tail"), BeatNode::hold("tail", hold(3))),
    ]);
    if nested {
        document.nodes.extend([
            (
                id("body"),
                BeatNode::sequence("body", vec![id("inner"), id("b")]),
            ),
            (id("inner"), repeated("inner", "a", 2, 1)),
            (id("b"), BeatNode::hold("b", hold(2))),
        ]);
    }
    document.validate().unwrap();
    document
}
fn request(document: &ProjectDocument, at: ProjectFrame, name: &str) -> CommandRequest {
    request_within(document, at, name, None)
}

fn request_within(
    document: &ProjectDocument,
    at: ProjectFrame,
    name: &str,
    within: Option<InstancePath>,
) -> CommandRequest {
    let target = if let Some(within) = &within {
        document.pause_insertion_within(at, within).unwrap()
    } else {
        let PauseInsertionTarget::Occurrence(target) = document.pause_insertion_target(at).unwrap()
        else {
            panic!()
        };
        target
    };
    CommandRequest {
        project_id: document.project_id().clone(),
        expected_revision: document.revision_id().clone(),
        new_revision: revision(name),
        command: Command::InsertOccurrenceTime {
            at,
            within,
            target: None,
            hold: hold(1),
            id: id(&format!("{name}-pause")),
            ai: false,
            all_plays: false,
            timing: AudioTimingId {
                allocation: revision(name),
                ordinal: 0,
            },
            identities: OccurrencePauseIdentities {
                isolation: OccurrenceIdentities {
                    nodes: (0..target.isolation_nodes)
                        .map(|n| id(&format!("{name}-clone-{n}")))
                        .collect(),
                    marks: (0..target.isolation_marks)
                        .map(|n| MarkId::new(format!("{name}-mark-{n}")).unwrap())
                        .collect(),
                },
                split: SplitIdentities {
                    nodes: (0..target.split_nodes)
                        .map(|n| id(&format!("{name}-split-{n}")))
                        .collect(),
                },
                container: target.container.then(|| id(&format!("{name}-container"))),
                gap: target.gap.then(|| id(&format!("{name}-gap"))),
            },
        },
    }
}

#[test]
fn occurrence_pause_all_play_and_gap_boundaries_are_one_reversible_frame() {
    for nested in [false, true] {
        let before = fixture(nested);
        let duration = before.duration().unwrap().frames();
        for at in 1..duration {
            if !matches!(
                before.pause_insertion_target(ProjectFrame(at)).unwrap(),
                PauseInsertionTarget::Occurrence(_)
            ) {
                continue;
            }
            let request = request(&before, ProjectFrame(at), "pause");
            let result = apply_with_result(&before, &request);
            let (transaction, after) =
                result.unwrap_or_else(|error| panic!("nested={nested} at={at}: {error}"));
            assert_eq!(after.duration().unwrap().frames(), duration + 1);
            assert_eq!(transaction.duration_delta, 1);
            assert_eq!(transaction.inverse.apply(&after).unwrap(), before);
            assert_eq!(transaction.forward.apply(&before).unwrap(), after);
            assert_eq!(
                ProjectDocument::from_json(&after.to_json().unwrap()).unwrap(),
                after
            );
            assert_eq!(after.nodes()[&id("a")], before.nodes()[&id("a")]);
            let proof = derive_scoped_isolation(&before, &request, &after).unwrap();
            proof.record().validate(&before, &request, &after).unwrap();
        }
    }
}

#[test]
fn occurrence_pause_reuses_owned_branches_on_later_insertions() {
    let before = fixture(true);
    let first = request(&before, ProjectFrame(3), "first");
    let (_, middle) = apply_with_result(&before, &first).unwrap();
    let next = request(&middle, ProjectFrame(3), "second");
    let Command::InsertOccurrenceTime { identities, .. } = &next.command else {
        panic!()
    };
    assert!(identities.isolation.nodes.is_empty());
    let (transaction, after) = apply_with_result(&middle, &next).unwrap();
    assert_eq!(
        after.duration().unwrap().frames(),
        before.duration().unwrap().frames() + 2
    );
    assert_eq!(transaction.inverse.apply(&after).unwrap(), middle);
}

#[test]
fn occurrence_pause_keeps_content_marks_in_selected_and_later_plays_and_gaps() {
    for nested in [false, true] {
        let mut before = fixture(nested);
        let total = before.duration().unwrap().frames();
        for frame in 1..total {
            before.marks.insert(
                MarkId::new(format!("frame-{frame}")).unwrap(),
                Mark {
                    owner: id("root"),
                    label: format!("frame {frame}"),
                    boundary: BoundaryAnchor {
                        coordinate: Anchor::Local {
                            node: id("root"),
                            position: ExactRatio::integer(frame),
                        },
                        bias: InsertionBias::Right,
                    },
                    loss_policy: AnchorLossPolicy::KeepUnresolved,
                    state: MarkState::Bound,
                    fragments: vec![],
                },
            );
        }
        before.marks.insert(
            MarkId::new("owned").unwrap(),
            Mark {
                owner: id("a"),
                label: "owned".into(),
                boundary: BoundaryAnchor {
                    coordinate: Anchor::Local {
                        node: id("a"),
                        position: ExactRatio::ONE,
                    },
                    bias: InsertionBias::Right,
                },
                loss_policy: AnchorLossPolicy::KeepUnresolved,
                state: MarkState::Bound,
                fragments: vec![],
            },
        );
        before.validate().unwrap();
        for at in [2, 5, 8] {
            let (_, after) =
                apply_with_result(&before, &request(&before, ProjectFrame(at), "marked")).unwrap();
            for frame in 1..total {
                let marked = &after.marks()[&MarkId::new(format!("frame-{frame}")).unwrap()];
                assert_eq!(
                    marked.state,
                    MarkState::Bound,
                    "nested={nested} at={at} mark={frame}"
                );
                assert_eq!(
                    marked.boundary.coordinate,
                    Anchor::Local {
                        node: id("root"),
                        position: ExactRatio::integer(frame + i64::from(frame >= at))
                    },
                    "nested={nested} at={at} mark={frame}"
                );
            }
            assert_eq!(
                after.marks()[&MarkId::new("owned").unwrap()],
                before.marks()[&MarkId::new("owned").unwrap()]
            );
        }
    }
}

#[test]
fn occurrence_pause_is_compact_at_maximum_repeat_count_and_rejects_bad_pools() {
    let mut before = fixture(false);
    let NodeKind::Repeat { iterations, .. } = &mut before.nodes.get_mut(&id("outer")).unwrap().kind
    else {
        panic!()
    };
    *iterations = IterationOrder::new(revision("many"), u32::MAX).unwrap();
    before.validate().unwrap();
    let at = ProjectFrame(6 * (i64::from(u32::MAX) - 2) + 2);
    let valid = request(&before, at, "bounded");
    let (transaction, after) = apply_with_result(&before, &valid).unwrap();
    assert!(after.nodes().len() < 16);
    assert_eq!(transaction.duration_delta, 1);
    assert_eq!(transaction.inverse.apply(&after).unwrap(), before);
    for case in 0..4 {
        let mut invalid = valid.clone();
        let Command::InsertOccurrenceTime {
            identities,
            timing,
            id: pause_id,
            hold,
            ..
        } = &mut invalid.command
        else {
            panic!()
        };
        match case {
            0 => {
                identities.isolation.nodes.pop();
            }
            1 => {
                *pause_id = identities.isolation.nodes[0].clone();
            }
            2 => {
                timing.ordinal = u32::MAX;
            }
            _ => {
                hold.duration = FrameDuration::ZERO;
            }
        }
        assert!(crate::apply(&before, &invalid).is_err(), "case {case}");
        assert_eq!(before, transaction.inverse.apply(&after).unwrap());
    }
}

#[test]
fn occurrence_pause_preserves_gap_permissions_without_granting_the_new_hold() {
    let mut before = fixture(false);
    let clock = SourceTimeBase::new(1, 48_000).unwrap();
    let span = SourceSpan::new(
        SourceTimestamp {
            ticks: 0,
            time_base: clock,
        },
        SourceTimestamp {
            ticks: 20_000,
            time_base: clock,
        },
    )
    .unwrap();
    let asset = AssetId::new("sound").unwrap();
    before.assets.insert(
        asset.clone(),
        AssetRecord {
            label: "sound".into(),
            content_hash: "a".repeat(64),
            video: None,
            audio: Some(span),
            still_image: false,
            frame_count: None,
            source_qualification: Some(SourceQualificationId::new("b".repeat(64)).unwrap()),
        },
    );
    let sound = SoundId::new("sound").unwrap();
    before.sounds.insert(
        sound.clone(),
        SoundEvent {
            owner: id("root"),
            label: "sound".into(),
            source: SourceAudio { asset, span },
            mapping: SourceAudioMapping::natural_rate(span, before.presentation_basis().frame_rate)
                .unwrap(),
            offset: AudioSample(137),
            treatments: AudioTreatments::default(),
            start_edge: AudioEdgePolicy::Hard,
            end_edge: AudioEdgePolicy::Hard,
            overflow: SoundOverflowPolicy::Reject,
        },
    );
    let NodeKind::Repeat { iterations, .. } = &before.nodes()[&id("outer")].kind else {
        panic!()
    };
    let issuers: Vec<_> = (0..2)
        .map(|play| SoundHoldIssuer::RepeatGap {
            instance: InstancePath {
                node: id("outer"),
                repeats: vec![],
            },
            gap_after: iterations.at(play).unwrap(),
        })
        .collect();
    before.sound_allowances.insert(
        sound.clone(),
        SoundHoldAllowances::try_from(issuers.clone()).unwrap(),
    );
    before.validate().unwrap();
    let (transaction, after) =
        apply_with_result(&before, &request(&before, ProjectFrame(5), "allowed")).unwrap();
    let permissions = &after.sound_allowances()[&sound];
    assert_eq!(
        permissions.len(),
        3,
        "two split Hold providers and the other default gap"
    );
    assert!(!permissions.contains(&issuers[0]));
    assert!(permissions.contains(&issuers[1]));
    assert!(
        permissions
            .iter()
            .all(|issuer| issuer.instance().node != id("allowed-pause"))
    );
    assert_eq!(
        permissions
            .iter()
            .filter(|issuer| matches!(issuer, SoundHoldIssuer::Node { .. }))
            .count(),
        2
    );
    assert_eq!(after.sounds()[&sound].offset, AudioSample(137));
    assert_eq!(transaction.inverse.apply(&after).unwrap(), before);
}

fn all_plays(document: &ProjectDocument, at: i64, name: &str) -> CommandRequest {
    let mut request = request(document, ProjectFrame(at), name);
    let Command::InsertOccurrenceTime {
        all_plays,
        identities,
        ..
    } = &mut request.command
    else {
        unreachable!()
    };
    *all_plays = true;
    identities.isolation = OccurrenceIdentities::default();
    request
}

#[test]
fn an_all_plays_pause_grows_every_default_play_once_and_reverts_exactly() {
    let before = fixture(false);
    // Plays 0..4, 6..10 and 12..16 with 2-frame gaps, then the tail.
    let request = all_plays(&before, 7, "all");
    let edit = crate::apply(&before, &request).unwrap();
    let after = edit.forward.apply(&before).unwrap();
    assert_eq!(edit.inverse.apply(&after).unwrap(), before);
    assert_eq!(after.duration().unwrap().frames(), 19 + 3);
    // One definition: the Repeat's child now holds the pause at local 1.
    let NodeKind::Repeat { child, .. } = &after.nodes()[&id("outer")].kind else {
        panic!()
    };
    let NodeKind::Sequence { children } = &after.nodes()[child].kind else {
        panic!("the definition became a Sequence")
    };
    assert_eq!(children.len(), 3);
    assert_eq!(children[1], id("all-pause"));
    assert_eq!(after.durations().unwrap()[child].frames(), 5);
    // Nested: the inner beat repeats twice in each of three outer plays, so
    // a pause in its shared definition appears six times.
    let nested = fixture(true);
    let edit = crate::apply(&nested, &all_plays(&nested, 1, "nested")).unwrap();
    let grown = edit.forward.apply(&nested).unwrap();
    assert_eq!(
        grown.duration().unwrap().frames(),
        nested.duration().unwrap().frames() + 6
    );
    assert_eq!(edit.inverse.apply(&grown).unwrap(), nested);
    // A gap is refused.
    let gap = all_plays(&before, 5, "gap");
    assert!(crate::apply(&before, &gap).is_err());
}

#[test]
fn an_all_plays_pause_leaves_an_isolated_play_unchanged() {
    let before = fixture(false);
    // Isolate the second play with an ordinary one-play pause first.
    let isolated = {
        let edit = crate::apply(&before, &request(&before, ProjectFrame(7), "one")).unwrap();
        edit.forward.apply(&before).unwrap()
    };
    assert_eq!(isolated.duration().unwrap().frames(), 20);
    // Now the first play is still a default play: the pause grows plays one
    // and three, not the isolated second play.
    let request = all_plays(&isolated, 2, "rest");
    let edit = crate::apply(&isolated, &request).unwrap();
    let after = edit.forward.apply(&isolated).unwrap();
    assert_eq!(after.duration().unwrap().frames(), 20 + 2);
    // Inside the isolated play itself, all plays is refused.
    assert!(crate::apply(&isolated, &all_plays(&isolated, 8, "own")).is_err());
}

fn with_root_sound(mut document: ProjectDocument) -> ProjectDocument {
    let time_base = SourceTimeBase::new(1, 48_000).unwrap();
    let span = SourceSpan::new(
        SourceTimestamp {
            ticks: 0,
            time_base,
        },
        SourceTimestamp {
            ticks: 1_600,
            time_base,
        },
    )
    .unwrap();
    let asset = AssetId::new("boing").unwrap();
    document.assets.insert(
        asset.clone(),
        AssetRecord {
            label: "Boing".into(),
            content_hash: "a".repeat(64),
            video: None,
            audio: Some(span),
            still_image: false,
            frame_count: None,
            source_qualification: Some(SourceQualificationId::new("b".repeat(64)).unwrap()),
        },
    );
    let rate = document.presentation_basis().frame_rate;
    document.sounds.insert(
        SoundId::new("after").unwrap(),
        SoundEvent {
            owner: id("root"),
            label: "After".into(),
            source: SourceAudio { asset, span },
            mapping: SourceAudioMapping::natural_rate(span, rate).unwrap(),
            offset: rate.audio_boundary(ProjectFrame(17)).unwrap(),
            treatments: AudioTreatments::default(),
            start_edge: AudioEdgePolicy::Automatic,
            end_edge: AudioEdgePolicy::Automatic,
            overflow: SoundOverflowPolicy::Reject,
        },
    );
    document.validate().unwrap();
    document
}

#[test]
fn an_all_plays_pause_moves_root_sounds_by_every_default_occurrence() {
    let before = with_root_sound(fixture(false));
    let edit = crate::apply(&before, &all_plays(&before, 7, "all")).unwrap();
    let after = edit.forward.apply(&before).unwrap();
    assert_eq!(edit.inverse.apply(&after).unwrap(), before);
    // The same routes as three frames inserted at the Repeat's end (16).
    let reference = crate::apply(
        &before,
        &CommandRequest {
            project_id: before.project_id().clone(),
            expected_revision: before.revision_id().clone(),
            new_revision: revision("reference"),
            command: Command::InsertTime {
                at: ProjectFrame(16),
                hold: hold(3),
                id: id("reference-pause"),
                identities: SplitIdentities::default(),
                timing: AudioTimingId {
                    allocation: revision("reference"),
                    ordinal: 0,
                },
            },
        },
    )
    .unwrap()
    .forward
    .apply(&before)
    .unwrap();
    assert!(!after.sound_routes().is_empty());
    assert_eq!(after.sound_routes(), reference.sound_routes());
}
