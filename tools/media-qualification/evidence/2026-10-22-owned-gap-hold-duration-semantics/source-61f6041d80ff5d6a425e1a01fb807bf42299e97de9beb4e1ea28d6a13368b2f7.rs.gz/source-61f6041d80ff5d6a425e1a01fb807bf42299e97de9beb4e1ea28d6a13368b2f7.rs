use std::collections::BTreeMap;

use deadpan_core::*;
use serde_json::json;

fn node(s: &str) -> NodeId {
    NodeId::new(s).unwrap()
}
fn sound() -> SoundId {
    SoundId::new("sound").unwrap()
}
fn frames(n: i64) -> FrameDuration {
    FrameDuration::new(n).unwrap()
}
fn range(a: i64, b: i64) -> ExactFrameRange {
    ExactFrameRange {
        start: ExactRatio::integer(a),
        end: ExactRatio::integer(b),
    }
}
fn request(doc: &ProjectDocument, command: Command) -> CommandRequest {
    CommandRequest {
        project_id: doc.project_id().clone(),
        expected_revision: doc.revision_id().clone(),
        new_revision: RevisionId::new(format!("{}x", doc.revision_id())).unwrap(),
        command,
    }
}
fn edit(doc: &ProjectDocument, command: Command) -> (ProjectDocument, EditTransaction) {
    let transaction = apply(doc, &request(doc, command)).unwrap();
    let result = transaction.forward.apply(doc).unwrap();
    assert_eq!(transaction.inverse.apply(&result).unwrap(), *doc);
    assert_eq!(
        ProjectDocument::from_json(&result.to_json().unwrap()).unwrap(),
        result
    );
    (result, transaction)
}
fn pause(n: i64) -> HoldRecipe {
    HoldRecipe {
        duration: frames(n),
        video: HoldVideo::Background,
        audio: HoldAudio::Silence,
        picture_context: None,
    }
}
fn fixture() -> ProjectDocument {
    let mut doc = ProjectDocument::new(
        ProjectId::new("routing").unwrap(),
        RevisionId::new("r").unwrap(),
        PresentationBasis {
            width: 640,
            height: 480,
            frame_rate: FrameRate::new(30_000, 1001).unwrap(),
            color_policy: ColorPolicy::SdrRec709,
        },
        node("root"),
    )
    .unwrap();
    let time_base = SourceTimeBase::new(1, 48_000).unwrap();
    let span = SourceSpan::new(
        SourceTimestamp {
            ticks: 0,
            time_base,
        },
        SourceTimestamp {
            ticks: 480_000,
            time_base,
        },
    )
    .unwrap();
    doc = edit(
        &doc,
        Command::AddAsset {
            id: AssetId::new("catalog").unwrap(),
            asset: AssetRecord {
                label: "catalog".into(),
                content_hash: "a".repeat(64),
                audio: Some(span),
                video: None,
                frame_count: None,
                still_image: false,
                source_qualification: Some(SourceQualificationId::new("b".repeat(64)).unwrap()),
            },
        },
    )
    .0;
    doc = edit(
        &doc,
        Command::Insert {
            parent: node("root"),
            index: 0,
            subtree: Subtree {
                root: node("group"),
                nodes: BTreeMap::from([
                    (
                        node("group"),
                        BeatNode::sequence("Group", vec![node("a"), node("b"), node("c")]),
                    ),
                    (node("a"), BeatNode::hold("a", pause(10))),
                    (node("b"), BeatNode::hold("b", pause(20))),
                    (node("c"), BeatNode::hold("c", pause(70))),
                ]),
                overrides: BTreeMap::new(),
                gap_overrides: BTreeMap::new(),
            },
        },
    )
    .0;
    let source = SourceAudio {
        asset: AssetId::new("catalog").unwrap(),
        span,
    };
    let duration = SourceAudioMapping::natural_rate(span, doc.presentation_basis().frame_rate)
        .unwrap()
        .duration_frames(frames(100))
        .unwrap();
    edit(
        &doc,
        Command::SetSound {
            id: sound(),
            event: SoundEvent {
                owner: node("root"),
                label: "Sound".into(),
                source,
                mapping: SourceAudioMapping::SelectedPlacement {
                    start: ExactRatio::ZERO,
                    frames: duration,
                    selection: range(0, 80),
                },
                offset: AudioSample(0),
                treatments: deadpan_core::AudioTreatments::default(),
                start_edge: AudioEdgePolicy::Automatic,
                end_edge: AudioEdgePolicy::Hard,
                overflow: SoundOverflowPolicy::Reject,
            },
        },
    )
    .0
}

#[test]
fn send_edits_preserve_routed_timing_and_are_exactly_reversible() {
    let original = fixture();
    let (routed, _) = edit(&original, insert(&original, 30, "send-pause"));
    assert!(!routed.sound_routes().is_empty());
    let mut event = routed.sounds()[&sound()].clone();
    event.treatments = event.treatments.clone().with_tail_sends(
        TailSends::default().with_level(TailEffect::Delay, Some(GainDb::new(-6000).unwrap())),
    );
    let (sent, transaction) = edit(
        &routed,
        Command::SetSound {
            id: sound(),
            event: event.clone(),
        },
    );
    assert_eq!(sent.sound_routes(), routed.sound_routes());
    assert_eq!(sent.sound_allowances(), routed.sound_allowances());
    assert_eq!(sent.sounds()[&sound()], event);
    assert_eq!(transaction.inverse.apply(&sent).unwrap(), routed);
    event.treatments = event
        .treatments
        .with_trim(deadpan_core::GainDb::new(-3000).unwrap())
        .unwrap();
    let (gained, _) = edit(&sent, Command::SetSound { id: sound(), event });
    assert_eq!(
        gained.sounds()[&sound()].treatments.tail_sends(),
        sent.sounds()[&sound()].treatments.tail_sends()
    );
    assert_eq!(gained.sound_routes(), routed.sound_routes());
}
fn insert(doc: &ProjectDocument, at: i64, name: &str) -> Command {
    Command::InsertTime {
        at: ProjectFrame(at),
        hold: pause(1),
        id: node(name),
        identities: SplitIdentities {
            nodes: (0..10).map(|i| node(&format!("{name}-{i}"))).collect(),
        },
        timing: AudioTimingId {
            allocation: request(doc, Command::DeleteSound { id: sound() }).new_revision,
            ordinal: 0,
        },
    }
}

#[test]
fn linked_move_preserves_the_root_sound_clock_routes_and_allowance_ownership() {
    let original = fixture();
    let (original, _) = edit(
        &original,
        Command::SetSoundAllowance {
            sound: sound(),
            issuer: SoundHoldIssuer::Node {
                instance: InstancePath {
                    node: node("a"),
                    repeats: vec![],
                },
            },
            allowed: true,
        },
    );
    let (routed, _) = edit(&original, insert(&original, 30, "pause"));
    assert!(!routed.sound_routes().is_empty());
    for before in [&original, &routed] {
        let parent = node("group");
        let NodeKind::Sequence { children } = &before.nodes()[&parent].kind else {
            panic!("ordinary Sequence")
        };
        let destination = MoveRangeDestination::Seam {
            parent: parent.clone(),
            index: children.len(),
        };
        let selected = FrameRange::new(ProjectFrame(0), ProjectFrame(10)).unwrap();
        let plan = before.range_move(&parent, selected, &destination).unwrap();
        assert_eq!(plan.required_ids, 0);
        let (after, transaction) = edit(
            before,
            Command::MoveRange {
                source_revision: before.revision_id().clone(),
                source_parent: parent,
                range: selected,
                destination,
                identities: SplitIdentities { nodes: vec![] },
                timing: AudioTimingId {
                    allocation: request(before, Command::DeleteSound { id: sound() }).new_revision,
                    ordinal: 0,
                },
            },
        );
        assert_eq!(transaction.duration_delta, 0);
        assert_eq!(after.sounds(), before.sounds());
        assert_eq!(after.sound_routes(), before.sound_routes());
        assert_eq!(after.sound_allowances(), before.sound_allowances());
        assert_eq!(after.nodes()[&node("a")], before.nodes()[&node("a")]);
        assert_eq!(after.sounds()[&sound()].owner, node("root"));
    }
}

fn replace_source(
    doc: &ProjectDocument,
    parent: &str,
    start: i64,
    end: i64,
    inserted: i64,
) -> Command {
    Command::ReplaceSource {
        parent: node(parent),
        range: FrameRange::new(ProjectFrame(start), ProjectFrame(end)).unwrap(),
        source: SourceNode {
            edit_window: None,
            duration: frames(inserted),
            video: SourceVideo::Blank,
            audio: Some(doc.sounds()[&sound()].source.clone()),
            video_mapping: SourceVideoMapping::FitBeat,
            audio_mapping: SourceAudioMapping::natural_rate(
                doc.sounds()[&sound()].source.span,
                doc.presentation_basis().frame_rate,
            )
            .unwrap(),
            link: LinkRelation::Independent,
            audio_offset: AudioSample(0),
        },
        id: node("replacement"),
        label: "Replacement".into(),
        identities: SplitIdentities {
            nodes: (0..12).map(|i| node(&format!("replacement-{i}"))).collect(),
        },
        timing: AudioTimingId {
            allocation: request(doc, Command::DeleteSound { id: sound() }).new_revision,
            ordinal: 0,
        },
    }
}

#[test]
fn replacement_transforms_root_bus_once_and_whole_project_removes_all_old_support() {
    let original = fixture();
    let event = original.sounds()[&sound()].clone();
    let (after, transaction) = edit(&original, replace_source(&original, "group", 5, 35, 12));
    assert_eq!(transaction.duration_delta, -18);
    assert_eq!(after.sounds()[&sound()], event);
    let journal = &after.sound_routes()[&sound()];
    assert_eq!(journal.edits.len(), 1);
    assert_eq!(
        journal.edits[0].operation,
        RootSoundOperation::Replace {
            range: FrameRange::new(ProjectFrame(5), ProjectFrame(35)).unwrap(),
            duration: frames(12),
        }
    );
    let (whole, _) = edit(&original, replace_source(&original, "root", 0, 100, 3));
    assert_eq!(whole.duration().unwrap(), frames(3));
    assert!(whole.sounds().is_empty());
    assert!(whole.sound_routes().is_empty());
    assert!(whole.sound_allowances().is_empty());
}

#[test]
fn equal_replacement_preserves_single_rounded_suffix_sample_4804() {
    let mut wire = json!(fixture());
    wire["nodes"] = json!({"root":BeatNode::sequence("Root",vec![node("whole")]),"whole":BeatNode::hold("Whole",pause(3))});
    // One old sample, immediately before B(3)=4805.
    wire["sounds"]["sound"]["mapping"]["selection"] = json!(ExactFrameRange {
        start: ExactRatio::new(4804 * 5, 8008).unwrap(),
        end: ExactRatio::integer(3),
    });
    let original = ProjectDocument::from_json(&wire.to_string()).unwrap();
    let (after, _) = edit(&original, replace_source(&original, "root", 1, 2, 1));
    assert!(after.sounds().contains_key(&sound()));
    assert_eq!(after.sound_routes()[&sound()].edits.len(), 1);
}

#[test]
fn sampleless_selection_survives_unrelated_replacement_and_disappears_when_replaced() {
    let original = sample_clock_fixture(ExactFrameRange {
        start: ExactRatio::new(21, 10).unwrap(),
        end: ExactRatio::new(11, 5).unwrap(),
    });
    let (retained, _) = edit(&original, replace_source(&original, "group", 0, 1, 2));
    assert_eq!(retained.sounds()[&sound()], original.sounds()[&sound()]);
    let (removed, _) = edit(&original, replace_source(&original, "group", 2, 3, 1));
    assert!(removed.sounds().is_empty());
}

#[test]
fn nested_pause_captures_once_and_more_than_twenty_one_edits_keep_the_recipe() {
    let original = fixture();
    let recipe = original.sounds()[&sound()].clone();
    let (mut doc, first) = edit(&original, insert(&original, 1, "pause0"));
    assert_eq!(
        doc.sound_routes()[&sound()].edits.len(),
        1,
        "internal Split must not route twice"
    );
    assert_eq!(first.duration_delta, 1);
    assert!(first.changed_ids.contains(&node("root")));
    for n in 1..32 {
        let at = doc.duration().unwrap().frames();
        doc = edit(&doc, insert(&doc, at, &format!("pause{n}"))).0;
    }
    let journal = &doc.sound_routes()[&sound()];
    assert_eq!(journal.edits.len(), 32);
    assert_eq!(journal.recipe_extent, frames(100));
    assert_eq!(doc.sounds()[&sound()], recipe);
    assert_eq!(
        journal.compile().unwrap().output_extent(),
        ExactRatio::integer(132)
    );
    assert!(FrozenAudioContext::capture(&doc).is_err());
    assert!(
        capture_unbound_audio_bindings(
            &doc,
            AudioTimingId {
                allocation: RevisionId::new("blocked").unwrap(),
                ordinal: 0
            }
        )
        .is_err()
    );
    let (removed, _) = edit(
        &doc,
        Command::Delete {
            node: node("group"),
        },
    );
    assert!(removed.sounds().is_empty());
    assert!(removed.sound_routes().is_empty());
    assert_eq!(removed.duration().unwrap(), frames(31));
}

#[test]
fn retained_delete_routes_the_root_bus_once_and_prunes_its_removed_issuer() {
    let original = fixture();
    let issuer = SoundHoldIssuer::Node {
        instance: InstancePath {
            node: node("a"),
            repeats: vec![],
        },
    };
    let (original, _) = edit(
        &original,
        Command::SetSoundAllowance {
            sound: sound(),
            issuer,
            allowed: true,
        },
    );
    let (historical, _) = edit(&original, Command::Delete { node: node("a") });
    let (retained, transaction) = edit(
        &original,
        Command::DeleteRipple {
            node: node("a"),
            timing: AudioTimingId {
                allocation: request(&original, Command::Delete { node: node("a") }).new_revision,
                ordinal: 0,
            },
        },
    );
    assert_eq!(transaction.duration_delta, -10);
    assert_eq!(retained.sounds(), historical.sounds());
    assert_eq!(retained.sound_routes(), historical.sound_routes());
    assert_eq!(retained.sound_routes()[&sound()].edits.len(), 1);
    assert!(retained.sound_allowances().is_empty());
    let (empty, _) = edit(
        &retained,
        Command::DeleteRipple {
            node: node("group"),
            timing: AudioTimingId {
                allocation: request(
                    &retained,
                    Command::Delete {
                        node: node("group"),
                    },
                )
                .new_revision,
                ordinal: 0,
            },
        },
    );
    assert_eq!(empty.duration().unwrap(), frames(0));
    assert!(empty.sounds().is_empty());
    assert!(empty.sound_routes().is_empty());
    assert!(empty.audio_bindings().is_empty());
}

#[test]
fn compound_delete_and_insert_preserve_sequential_sound_routes_and_one_inverse() {
    let original = fixture();
    let (before, _) = edit(
        &original,
        Command::SetSoundAllowance {
            sound: sound(),
            issuer: SoundHoldIssuer::Node {
                instance: InstancePath {
                    node: node("a"),
                    repeats: vec![],
                },
            },
            allowed: true,
        },
    );
    let first_revision = RevisionId::new("compound-delete").unwrap();
    let first = LeafEdit::new(
        first_revision.clone(),
        Command::DeleteRipple {
            node: node("a"),
            timing: AudioTimingId {
                allocation: first_revision,
                ordinal: 0,
            },
        },
    )
    .unwrap();
    let deleted = apply(&before, &first.request(&before))
        .unwrap()
        .forward
        .apply(&before)
        .unwrap();
    let insertion = request(&deleted, insert(&deleted, 20, "compound-pause"));
    let expected = apply(&deleted, &insertion)
        .unwrap()
        .forward
        .apply(&deleted)
        .unwrap();
    assert_eq!(expected.sound_routes()[&sound()].edits.len(), 2);
    assert!(expected.sound_allowances().is_empty());
    let transaction = ResolvedTransaction::new(
        0,
        BTreeMap::new(),
        vec![
            ResolvedStep::Edit { edit: first },
            ResolvedStep::Edit {
                edit: LeafEdit::new(insertion.new_revision, insertion.command).unwrap(),
            },
        ],
    )
    .unwrap();
    let edit = apply(
        &before,
        &CommandRequest {
            project_id: before.project_id().clone(),
            expected_revision: before.revision_id().clone(),
            new_revision: RevisionId::new("compound-routed").unwrap(),
            command: Command::Compound { transaction },
        },
    )
    .unwrap();
    let actual = edit.forward.apply(&before).unwrap();
    let mut expected_wire = json!(expected);
    expected_wire["revision_id"] = json!("compound-routed");
    assert_eq!(
        actual,
        ProjectDocument::from_json(&expected_wire.to_string()).unwrap()
    );
    assert_eq!(actual.duration().unwrap(), frames(91));
    assert_eq!(edit.inverse.apply(&actual).unwrap(), before);
}

#[test]
fn range_deletion_transforms_the_root_bus_once_and_splits_hold_allowances() {
    let original = fixture();
    let (before, _) = edit(
        &original,
        Command::SetSoundAllowance {
            sound: sound(),
            issuer: SoundHoldIssuer::Node {
                instance: InstancePath {
                    node: node("a"),
                    repeats: vec![],
                },
            },
            allowed: true,
        },
    );
    let target = FrameRange::new(ProjectFrame(2), ProjectFrame(5)).unwrap();
    let (after, transaction) = edit(
        &before,
        Command::DeleteRange {
            parent: node("group"),
            range: target,
            identities: SplitIdentities {
                nodes: (0..5).map(|i| node(&format!("range-{i}"))).collect(),
            },
            timing: AudioTimingId {
                allocation: request(&before, Command::DeleteSound { id: sound() }).new_revision,
                ordinal: 0,
            },
        },
    );
    assert_eq!(transaction.duration_delta, -3);
    assert_eq!(after.sounds(), before.sounds());
    let route = &after.sound_routes()[&sound()];
    assert_eq!(route.edits.len(), 1);
    assert_eq!(
        route.edits[0].operation,
        RootSoundOperation::Delete { range: target }
    );
    assert_eq!(
        route
            .compile()
            .unwrap()
            .query(range(2, 3), Default::default())
            .unwrap()
            .slices[0]
            .recipe,
        Some(range(5, 6))
    );
    // The old permission follows both retained physical fragments. The deleted
    // middle must not leave a dangling issuer or remove the surviving grant.
    assert_eq!(after.sound_allowances()[&sound()].len(), 2);
    let total = after.duration().unwrap().frames();
    let (empty, _) = edit(
        &after,
        Command::DeleteRange {
            parent: node("root"),
            range: FrameRange::new(ProjectFrame(0), ProjectFrame(total)).unwrap(),
            identities: SplitIdentities::default(),
            timing: AudioTimingId {
                allocation: request(&after, Command::DeleteSound { id: sound() }).new_revision,
                ordinal: 0,
            },
        },
    );
    assert!(empty.sounds().is_empty());
    assert!(empty.sound_routes().is_empty());
    assert!(empty.sound_allowances().is_empty());
    assert!(empty.audio_bindings().is_empty());
}

#[test]
fn delete_onset_keeps_recipe_suffix_and_whole_deletion_removes_bus() {
    let original = fixture();
    let (doc, transaction) = edit(&original, Command::Delete { node: node("a") });
    assert_eq!(transaction.duration_delta, -10);
    assert_eq!(doc.sounds(), original.sounds());
    let journal = &doc.sound_routes()[&sound()];
    let route = journal.compile().unwrap();
    let query = route.query(range(0, 1), Default::default()).unwrap();
    assert_eq!(query.slices[0].recipe, Some(range(10, 11)));
    assert_eq!(journal.edits[0].cuts, RootSoundCutEdges::default());
    let (empty, _) = edit(
        &doc,
        Command::Delete {
            node: node("group"),
        },
    );
    assert_eq!(empty.duration().unwrap(), frames(0));
    assert!(empty.sounds().is_empty());
    assert!(empty.sound_routes().is_empty());

    let mut event = original.sounds()[&sound()].clone();
    let SourceAudioMapping::SelectedPlacement { selection, .. } = &mut event.mapping else {
        unreachable!()
    };
    *selection = range(10, 30);
    let (selected, _) = edit(&original, Command::SetSound { id: sound(), event });
    let (removed, _) = edit(&selected, Command::Delete { node: node("b") });
    assert!(
        removed.sounds().is_empty(),
        "fully removed selected support must retire its event"
    );
}

fn sample_clock_fixture(selection: ExactFrameRange) -> ProjectDocument {
    let original = fixture();
    let rate = FrameRate::new(32_000, 1).unwrap();
    let mut wire = serde_json::to_value(&original).unwrap();
    wire["presentation_basis"]["frame_rate"] = json!(rate);
    wire["nodes"]["group"] = json!(BeatNode::sequence("Group", vec![node("a"), node("b")]));
    wire["nodes"]["a"] = json!(BeatNode::hold("a", pause(1)));
    wire["nodes"]["b"] = json!(BeatNode::hold("b", pause(2)));
    wire["nodes"].as_object_mut().unwrap().remove("c");
    let mut event = original.sounds()[&sound()].clone();
    event.mapping = SourceAudioMapping::SelectedPlacement {
        start: ExactRatio::ZERO,
        frames: SourceAudioMapping::natural_rate(event.source.span, rate)
            .unwrap()
            .duration_frames(FrameDuration::ZERO)
            .unwrap(),
        selection,
    };
    wire["sounds"]["sound"] = json!(event);
    ProjectDocument::from_json(&wire.to_string()).unwrap()
}

fn splice_one_frame(doc: &ProjectDocument, name: &str) -> Command {
    Command::SpliceSource {
        parent: node("group"),
        index: 1,
        id: node(name),
        label: name.into(),
        source: SourceNode {
            edit_window: None,
            duration: frames(1),
            video: SourceVideo::Blank,
            video_mapping: SourceVideoMapping::FitBeat,
            audio: Some(doc.sounds()[&sound()].source.clone()),
            audio_mapping: SourceAudioMapping::SelectedPlacement {
                start: ExactRatio::ZERO,
                frames: doc.sounds()[&sound()]
                    .mapping
                    .duration_frames(FrameDuration::ZERO)
                    .unwrap(),
                selection: range(0, 1),
            },
            audio_offset: AudioSample(0),
            link: LinkRelation::Independent,
        },
        timing: AudioTimingId {
            allocation: request(doc, Command::DeleteSound { id: sound() }).new_revision,
            ordinal: 0,
        },
    }
}

#[test]
fn nested_interior_source_splice_routes_the_absolute_boundary_once() {
    let original = fixture();
    let Command::SpliceSource { source, timing, .. } = splice_one_frame(&original, "moment") else {
        panic!("source recipe")
    };
    let (inserted, transaction) = edit(
        &original,
        Command::SpliceSourceAt {
            parent: node("group"),
            target: node("b"),
            at: frames(3),
            source,
            id: node("moment"),
            label: "Original moment".into(),
            identities: SplitIdentities {
                nodes: (0..3).map(|i| node(&format!("split-{i}"))).collect(),
            },
            timing,
        },
    );
    assert_eq!(transaction.duration_delta, 1);
    assert_eq!(inserted.sounds(), original.sounds());
    let journal = &inserted.sound_routes()[&sound()];
    assert_eq!(journal.edits.len(), 1);
    assert_eq!(
        journal.edits[0].operation,
        RootSoundOperation::Insert {
            at: ProjectFrame(13),
            duration: frames(1),
        }
    );
    assert_eq!(journal.recipe_extent, frames(100));
    assert_eq!(
        journal.compile().unwrap().output_extent(),
        ExactRatio::integer(101)
    );
}

#[test]
fn deletion_keeps_a_physical_sample_outside_its_transported_exact_selection() {
    // RoundEven at 32kfps allocates selection [2,8/3) as sample [3,4).
    // Each insert at frame1 moves that sample by B2-B1 = 3-2 = 1.
    let original = sample_clock_fixture(ExactFrameRange {
        start: ExactRatio::integer(2),
        end: ExactRatio::new(8, 3).unwrap(),
    });
    let event = original.sounds()[&sound()].clone();
    let mut doc = original;
    for index in 0..4 {
        doc = edit(&doc, splice_one_frame(&doc, &format!("splice{index}"))).0;
    }
    // The original b now occupies frames[5,7), physical samples[8,10).
    // Semantic selection[6,20/3) lies inside it, but retained sample7 does not.
    let (retained, _) = edit(&doc, Command::Delete { node: node("b") });
    assert_eq!(retained.duration().unwrap(), frames(5));
    assert_eq!(retained.sounds()[&sound()], event);
    assert_eq!(retained.sound_routes()[&sound()].edits.len(), 5);
    assert_eq!(
        retained.sound_routes()[&sound()].edits[4].operation,
        RootSoundOperation::Delete {
            range: FrameRange::new(ProjectFrame(5), ProjectFrame(7)).unwrap()
        }
    );
    let (removed, _) = edit(
        &retained,
        Command::Delete {
            node: node("group"),
        },
    );
    assert!(removed.sounds().is_empty());
}

#[test]
fn initially_sampleless_selection_keeps_intent_until_logically_deleted() {
    // Both endpoints round to sample3, but the exact nonempty event is accepted
    // authored intent. An unrelated splice must not remove it incidentally.
    let original = sample_clock_fixture(ExactFrameRange {
        start: ExactRatio::new(21, 10).unwrap(),
        end: ExactRatio::new(11, 5).unwrap(),
    });
    let event = original.sounds()[&sound()].clone();
    let (shifted, _) = edit(&original, splice_one_frame(&original, "splice"));
    assert_eq!(shifted.sounds()[&sound()], event);
    assert_eq!(shifted.sound_routes()[&sound()].edits.len(), 1);
    let (removed, _) = edit(&shifted, Command::Delete { node: node("b") });
    assert!(removed.sounds().is_empty());
    assert!(removed.sound_routes().is_empty());
}

#[test]
fn translated_support_clips_before_narrowing_extreme_sample_labels() {
    let rate = FrameRate::new(240_000, 7).unwrap();
    let end = 6_588_122_883_467_697_005;
    let old_end = end - 1;
    assert_eq!(
        rate.audio_boundary(ProjectFrame(end)).unwrap(),
        AudioSample(i64::MAX)
    );
    assert_eq!(
        rate.audio_boundary(ProjectFrame(old_end)).unwrap(),
        AudioSample(i64::MAX - 1)
    );
    let original = fixture();
    let mut wire = serde_json::to_value(&original).unwrap();
    wire["presentation_basis"]["frame_rate"] = json!(rate);
    wire["nodes"] = json!({
        "root": BeatNode::sequence("Root", vec![node("whole")]),
        "whole": BeatNode::hold("Whole", pause(end)),
    });
    let mut event = original.sounds()[&sound()].clone();
    event.mapping = SourceAudioMapping::SelectedPlacement {
        start: ExactRatio::integer(old_end - 1),
        frames: SourceAudioMapping::natural_rate(event.source.span, rate)
            .unwrap()
            .duration_frames(FrameDuration::ZERO)
            .unwrap(),
        selection: range(old_end - 1, old_end),
    };
    wire["sounds"]["sound"] = json!(event);
    wire["sound_routes"] = json!({"sound": RootSoundRoute {
        recipe_extent: frames(old_end),
        recipe_grid: RootSoundGrid::root(rate),
        edits: vec![RootSoundEdit {
            grid: RootSoundGrid::root(rate),
            operation: RootSoundOperation::Insert { at: ProjectFrame(1), duration: frames(1) },
            cuts: Default::default(),
        }],
    }});
    // The suffix shift is B2-B1 = 2 samples. Its selected endpoint becomes
    // i64::MAX+1 before clipping, but the surviving final sample is valid.
    let doc = ProjectDocument::from_json(&wire.to_string()).unwrap();
    assert_eq!(doc.duration().unwrap(), frames(end));
    assert!(doc.sounds().contains_key(&sound()));
    assert_eq!(
        ProjectDocument::from_json(&doc.to_json().unwrap()).unwrap(),
        doc
    );
}

#[test]
fn splice_and_nonroot_split_preserve_routing_while_root_split_stays_closed() {
    let original = fixture();
    let command = Command::SpliceSource {
        parent: node("group"),
        index: 1,
        id: node("pasted"),
        label: "Pasted".into(),
        source: SourceNode {
            edit_window: None,
            duration: frames(3),
            video: SourceVideo::Blank,
            video_mapping: SourceVideoMapping::FitBeat,
            audio: Some(original.sounds()[&sound()].source.clone()),
            audio_mapping: SourceAudioMapping::SelectedPlacement {
                start: ExactRatio::ZERO,
                frames: original.sounds()[&sound()]
                    .mapping
                    .duration_frames(frames(100))
                    .unwrap(),
                selection: range(0, 3),
            },
            audio_offset: AudioSample(0),
            link: LinkRelation::Independent,
        },
        timing: AudioTimingId {
            allocation: request(&original, Command::DeleteSound { id: sound() }).new_revision,
            ordinal: 0,
        },
    };
    let (doc, _) = edit(&original, command);
    assert_eq!(
        doc.sound_routes()[&sound()].edits[0].operation,
        RootSoundOperation::Insert {
            at: ProjectFrame(10),
            duration: frames(3)
        }
    );
    let (split, _) = edit(
        &doc,
        Command::Split {
            node: node("b"),
            at: frames(2),
            identities: SplitIdentities {
                nodes: vec![node("left"), node("right"), node("context")],
            },
        },
    );
    assert_eq!(split.sound_routes(), doc.sound_routes());
    assert_eq!(split.sounds(), doc.sounds());
    assert!(
        apply(
            &doc,
            &request(
                &doc,
                Command::Split {
                    node: node("root"),
                    at: frames(2),
                    identities: Default::default()
                }
            )
        )
        .is_err()
    );
}

#[test]
fn parameters_preserve_history_replacement_is_explicit_and_route_patches_are_guarded() {
    let original = fixture();
    let (doc, _) = edit(&original, insert(&original, 1, "pause"));
    let mut event = doc.sounds()[&sound()].clone();
    event.label = "Gain edit".into();
    event.treatments = event
        .treatments
        .with_trim(deadpan_core::GainDb::new(-3000).unwrap())
        .unwrap();
    event.start_edge = AudioEdgePolicy::Hard;
    let (changed, _) = edit(
        &doc,
        Command::SetSound {
            id: sound(),
            event: event.clone(),
        },
    );
    assert_eq!(changed.sound_routes(), doc.sound_routes());
    event.offset = AudioSample(1);
    assert!(
        apply(
            &changed,
            &request(
                &changed,
                Command::SetSound {
                    id: sound(),
                    event: event.clone()
                }
            )
        )
        .is_err()
    );
    let (replaced, transaction) = edit(&changed, Command::ReplaceSound { id: sound(), event });
    assert!(replaced.sound_routes().is_empty());
    assert!(transaction.forward.sound_routes.contains_key(&sound()));
    let mut bad = transaction.forward.clone();
    bad.sound_routes.get_mut(&sound()).unwrap().before = None;
    assert_eq!(
        bad.apply(&changed).unwrap_err().code,
        EditErrorCode::PatchConflict
    );
}

#[test]
fn routed_wire_admission_checks_clocks_ownership_and_capacity() {
    let original = fixture();
    let (doc, _) = edit(&original, insert(&original, 1, "pause"));
    for mutation in ["rate", "origin", "extent", "orphan"] {
        let mut wire = serde_json::to_value(&doc).unwrap();
        match mutation {
            "rate" => {
                wire["sound_routes"]["sound"]["edits"][0]["grid"]["frame_rate"] =
                    json!({"numerator": 24, "denominator": 1})
            }
            "origin" => {
                wire["sound_routes"]["sound"]["recipe_grid"]["frame_origin"] =
                    serde_json::to_value(ExactRatio::ONE).unwrap()
            }
            "extent" => {
                wire["sound_routes"]["sound"]["recipe_extent"] =
                    serde_json::to_value(frames(101)).unwrap()
            }
            "orphan" => {
                wire["sounds"].as_object_mut().unwrap().clear();
            }
            _ => unreachable!(),
        }
        assert!(
            ProjectDocument::from_json(&wire.to_string()).is_err(),
            "accepted {mutation}"
        );
    }
    let mut journal = doc.sound_routes()[&sound()].clone();
    journal
        .edits
        .resize(MAX_ROOT_SOUND_EDITS + 1, journal.edits[0]);
    assert!(journal.compile().is_err());
    assert!(
        serde_json::from_value::<RootSoundRoute>(serde_json::to_value(journal).unwrap()).is_err()
    );
}

#[test]
fn deep_history_and_large_repeat_queries_use_bounded_iterative_work() {
    std::thread::Builder::new()
        .stack_size(96 * 1024)
        .spawn(|| {
            let mut nodes = vec![SoundRouteNode::Recipe {}];
            for input in 0..2048 {
                nodes.push(SoundRouteNode::Window {
                    input,
                    selection: range(0, 1),
                });
            }
            let route = SoundRoute::new(ExactRatio::ONE, 2048, nodes).unwrap();
            assert_eq!(
                route.query(range(0, 1), Default::default()).unwrap().slices[0].recipe,
                Some(range(0, 1))
            );
            assert!(
                route
                    .query(
                        range(0, 1),
                        SoundRouteQueryLimits {
                            maximum_work: 100,
                            maximum_spans: 1
                        }
                    )
                    .is_err()
            );
            let map = SoundRippleMap::new(
                ExactRatio::integer(1_000_000_000),
                1,
                vec![
                    SoundRippleNode::Keep { range: range(0, 1) },
                    SoundRippleNode::Repeat {
                        body: 0,
                        count: 1_000_000_000,
                        input_stride: ExactRatio::ONE,
                    },
                ],
            )
            .unwrap();
            let route = SoundRoute::identity(ExactRatio::integer(1_000_000_000))
                .unwrap()
                .ripple(map)
                .unwrap();
            assert!(
                route
                    .query(
                        range(0, 1_000_000_000),
                        SoundRouteQueryLimits {
                            maximum_work: 50,
                            maximum_spans: 5
                        }
                    )
                    .is_err()
            );
            assert_eq!(
                route
                    .query(range(999_999_999, 1_000_000_000), Default::default())
                    .unwrap()
                    .slices[0]
                    .recipe,
                Some(range(999_999_999, 1_000_000_000))
            );
        })
        .unwrap()
        .join()
        .unwrap();
}

#[path = "sound_routing/trim.rs"]
mod trim;
