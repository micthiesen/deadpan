//! Checked complete providers for retained physical sound routes.

use std::{ops::Range, sync::Arc};

use deadpan_core::{AudioSample, ExactRatio, MIX_SAMPLE_RATE};

use crate::{
    AudioBoundaryRule, AudioProjectedRoot, AudioRootSource, AudioSampleGrid, AudioSoundRoute,
    AudioSourceOccurrence, AudioSourceVoice, AudioStageProjection, PlanError, RenderPlan,
    SignalSample,
};

/// The closed set of complete intrinsic providers that can retain sampled
/// routing. A source always means its input view, before current Hold gates.
/// Projection identity and its complete preparation history remain shared.
#[derive(Debug, Clone)]
pub enum AudioRoutedSignalInput<'plan> {
    Source(Box<AudioSourceVoice<'plan>>),
    Projected(Arc<AudioStageProjection<'plan>>),
}

/// One immutable provider captured on its original PointCeil Recipe grid.
/// Routes select its old physical output without narrowing source/DSP support.
/// This preparation handle does not apply current consuming Hold policy or
/// creative edges and does not persist or admit media.
#[derive(Debug, Clone)]
pub struct AudioRoutedSignal<'plan> {
    input: AudioRoutedSignalInput<'plan>,
    route: AudioSoundRoute<SignalSample>,
}

impl<'plan> AudioRoutedSignal<'plan> {
    pub fn source(
        voice: AudioSourceVoice<'plan>,
        route: AudioSoundRoute<SignalSample>,
    ) -> Result<Self, PlanError> {
        let grid = voice.route_grid()?;
        let support = voice.input_signal().support();
        validate_signal_capture(&route, grid, support.end)?;
        Ok(Self {
            input: AudioRoutedSignalInput::Source(Box::new(voice)),
            route,
        })
    }

    pub fn projected(
        projection: Arc<AudioStageProjection<'plan>>,
        route: AudioSoundRoute<SignalSample>,
    ) -> Result<Self, PlanError> {
        let rate = projection
            .stage()
            .plan()
            .metadata()
            .presentation_basis
            .frame_rate;
        let grid = AudioSampleGrid::new(
            ExactRatio::ZERO,
            ExactRatio::new(
                i128::from(rate.numerator()),
                i128::from(MIX_SAMPLE_RATE) * i128::from(rate.denominator()),
            )?,
            AudioBoundaryRule::PointCeil,
        )?;
        validate_signal_capture(
            &route,
            grid,
            ExactRatio::integer(projection.output_frames()),
        )?;
        Ok(Self {
            input: AudioRoutedSignalInput::Projected(projection),
            route,
        })
    }

    pub fn input(&self) -> &AudioRoutedSignalInput<'plan> {
        &self.input
    }

    pub fn route(&self) -> &AudioSoundRoute<SignalSample> {
        &self.route
    }

    pub fn samples(&self) -> Range<SignalSample> {
        self.route.samples()
    }

    pub fn plan(&self) -> &'plan RenderPlan {
        match &self.input {
            AudioRoutedSignalInput::Source(voice) => voice.plan(),
            AudioRoutedSignalInput::Projected(projection) => projection.stage().plan(),
        }
    }

    pub fn belongs_to(&self, plan: &RenderPlan) -> bool {
        std::ptr::eq(self.plan(), plan)
    }
}

fn validate_signal_capture(
    route: &AudioSoundRoute<SignalSample>,
    grid: AudioSampleGrid<SignalSample>,
    extent: ExactRatio,
) -> Result<(), PlanError> {
    if route.recipe_grid() != grid
        || route.route().recipe_extent() != extent
        || route.recipe_samples() != (grid.boundary(ExactRatio::ZERO)?..grid.boundary(extent)?)
    {
        return Err(PlanError::InvalidPlan(
            "sound route does not match its complete intrinsic provider capture",
        ));
    }
    Ok(())
}

/// A complete source, projected output or occurrence captured on its original absolute RoundEven
/// labels. The route's Recipe frames are relative to that output's start;
/// the retained root supplies the original phase, support and policy.
#[derive(Debug, Clone)]
pub struct AudioRoutedRoot<'plan> {
    input: AudioRoutedRootInput<'plan>,
    route: Arc<AudioSoundRoute<AudioSample>>,
}

#[derive(Debug, Clone)]
pub enum AudioRoutedRootInput<'plan> {
    Source(Box<AudioRootSource<'plan>>),
    Projected(Box<AudioProjectedRoot<'plan>>),
    Occurrence(Box<AudioSourceOccurrence<'plan>>),
}

impl<'plan> AudioRoutedRoot<'plan> {
    /// Retain one complete current owner occurrence on its absolute root
    /// RoundEven grid. The route's recipe coordinate is normalized to the
    /// occurrence extent; its grid origin preserves the occurrence's old
    /// integral sample labels exactly.
    pub fn occurrence(
        occurrence: AudioSourceOccurrence<'plan>,
        route: AudioSoundRoute<AudioSample>,
    ) -> Result<Self, PlanError> {
        let extent = occurrence.extent();
        let length = extent.end.checked_sub(extent.start)?;
        let rate = occurrence.plan().metadata().presentation_basis.frame_rate;
        let step = ExactRatio::new(
            i128::from(rate.numerator()),
            i128::from(MIX_SAMPLE_RATE) * i128::from(rate.denominator()),
        )?;
        let grid = AudioSampleGrid::new(
            ExactRatio::ZERO.checked_sub(extent.start)?,
            step,
            AudioBoundaryRule::RoundEven,
        )?;
        if route.recipe_grid() != grid
            || route.route().recipe_extent() != length
            || route.recipe_samples() != occurrence.samples()
            || route.identity_anchor() != occurrence.routing_anchor()?
        {
            return Err(PlanError::InvalidPlan(
                "sound route does not match its complete owner occurrence capture",
            ));
        }
        Ok(Self {
            input: AudioRoutedRootInput::Occurrence(Box::new(occurrence)),
            route: Arc::new(route),
        })
    }

    pub fn new(
        root: AudioProjectedRoot<'plan>,
        route: AudioSoundRoute<AudioSample>,
    ) -> Result<Self, PlanError> {
        let grid = root.route_grid()?;
        let extent = root.extent();
        if route.recipe_grid() != grid
            || route.route().recipe_extent() != extent.end.checked_sub(extent.start)?
            || route.recipe_samples() != root.samples()
            || route.identity_anchor() != ExactRatio::ZERO
        {
            return Err(PlanError::InvalidPlan(
                "sound route does not match its complete projected root capture",
            ));
        }
        Ok(Self {
            input: AudioRoutedRootInput::Projected(Box::new(root)),
            route: Arc::new(route),
        })
    }

    pub fn source(
        root: AudioRootSource<'plan>,
        route: AudioSoundRoute<AudioSample>,
    ) -> Result<Self, PlanError> {
        Self::source_shared(root, Arc::new(route))
    }

    pub(crate) fn source_shared(
        root: AudioRootSource<'plan>,
        route: Arc<AudioSoundRoute<AudioSample>>,
    ) -> Result<Self, PlanError> {
        if route.recipe_grid() != root.grid()
            || route.route().recipe_extent() != root.extent()
            || route.recipe_samples() != root.samples()?
            || route.identity_anchor() != ExactRatio::ZERO
        {
            return Err(PlanError::InvalidPlan(
                "sound route does not match its complete raw root capture",
            ));
        }
        Ok(Self {
            input: AudioRoutedRootInput::Source(Box::new(root)),
            route,
        })
    }

    pub fn input(&self) -> &AudioRoutedRootInput<'plan> {
        &self.input
    }

    pub fn root(&self) -> Option<&AudioProjectedRoot<'plan>> {
        match &self.input {
            AudioRoutedRootInput::Projected(root) => Some(root),
            AudioRoutedRootInput::Source(_) | AudioRoutedRootInput::Occurrence(_) => None,
        }
    }

    pub fn route(&self) -> &AudioSoundRoute<AudioSample> {
        &self.route
    }

    pub fn samples(&self) -> Range<AudioSample> {
        self.route.samples()
    }

    pub fn plan(&self) -> &'plan RenderPlan {
        match &self.input {
            AudioRoutedRootInput::Source(root) => root.plan(),
            AudioRoutedRootInput::Projected(root) => root.projection().stage().plan(),
            AudioRoutedRootInput::Occurrence(occurrence) => occurrence.plan(),
        }
    }

    pub fn belongs_to(&self, plan: &RenderPlan) -> bool {
        std::ptr::eq(self.plan(), plan)
    }
}
