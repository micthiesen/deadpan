//! Storage accounting and explicit cleanup for one project and for the
//! per-user caches, plus portable project copies.
//!
//! Project accounting and cleanup are [`deadpan_store::storage`]; portable
//! copies are [`deadpan_store::portable`]. This module adds the per-user
//! caches of specification Section 20.1 and the headless commands.
//!
//! Per-user storage falls into three groups:
//!
//! - **Rebuildable caches** that cleanup may remove: seek proxies
//!   (`~/Library/Caches/Deadpan/Proxies`, through the proxy cache's own
//!   locked cleanup, which never removes an entry a reader holds) and
//!   saved canonical stretches (`~/Library/Caches/Deadpan/Audio`, with
//!   independent reader/writer locks and a full checksum on restore), plus
//!   abandoned downloader-helper staging
//!   (`~/Library/Application Support/Deadpan/helpers/.staging`).
//! - **Reported only**: everything else under `~/Library/Caches/Deadpan`
//!   (development AI runtimes and qualification weights, build inputs) and
//!   installed model packs, which `models remove` manages. Cleanup never
//!   touches them.
//! - **Not on disk**: decoded PCM, picture and thumbnail caches live in
//!   process memory or anonymous temporary files that vanish with the process.

use std::path::{Path, PathBuf};
use std::sync::atomic::AtomicBool;
use std::time::{Duration, SystemTime};

use deadpan_store::generation_retention::{
    ClockAnomaly, DEFAULT_VARIANT_RETENTION, ExpiryMode, ExpiryPlan, VariantExpiry,
};
use deadpan_store::storage::{
    CleanupOutcome, CleanupPolicy, DEFAULT_GRACE, PlannedRemoval, RemovedEntry, StorageReport,
};
use deadpan_store::{AccessMode, ProjectStore};
use serde::{Deserialize, Serialize};
use serde_json::{Value, json};

use crate::live_project::{LiveError, ShortOperation};
use crate::proxy::cache::{DEFAULT_PROXY_BUDGET_BYTES, ProxyCache, ProxyCleanupPolicy};
use crate::{CliError, write_json};

/// The per-user directories this module accounts for.
#[derive(Debug, Clone)]
pub struct UserStorage {
    /// `~/Library/Caches/Deadpan`.
    pub caches: PathBuf,
    /// `~/Library/Application Support/Deadpan`.
    pub support: PathBuf,
}

impl UserStorage {
    /// The current user's directories, or None without an absolute HOME.
    pub fn current() -> Option<Self> {
        let home = std::env::var_os("HOME")
            .map(PathBuf::from)
            .filter(|home| home.is_absolute())?;
        Some(Self {
            caches: home.join("Library/Caches/Deadpan"),
            support: home.join("Library/Application Support/Deadpan"),
        })
    }

    fn proxies(&self) -> PathBuf {
        self.caches.join("Proxies")
    }

    fn helper_staging(&self) -> PathBuf {
        self.support.join("helpers/.staging")
    }
}

#[derive(Debug, Clone, Serialize)]
pub struct CacheDirectory {
    pub name: String,
    pub path: PathBuf,
    pub bytes: u64,
    /// What it holds and who manages it.
    pub kind: &'static str,
    /// Cleanup may remove some of it.
    pub cleanable: bool,
    /// Bytes cleanup would remove under the report's grace period.
    pub removable_bytes: u64,
}

#[derive(Debug, Clone, Serialize)]
pub struct UserStorageReport {
    pub schema_version: u32,
    pub grace_seconds: u64,
    pub directories: Vec<CacheDirectory>,
    pub total_bytes: u64,
    pub removable_bytes: u64,
    /// Caches that exist only in process memory or anonymous files.
    pub not_on_disk: Vec<&'static str>,
    pub saved_audio: Vec<deadpan_audio::persistent_pcm::CacheEntry>,
    pub saved_audio_error: Option<String>,
}

#[derive(Debug, Clone, Default, Serialize)]
pub struct UserCleanupOutcome {
    pub dry_run: bool,
    pub removed: Vec<PathBuf>,
    pub removed_bytes: u64,
    pub kept_in_use: Vec<String>,
}

const NOT_ON_DISK: [&str; 3] = [
    "decoded source PCM (bounded, per process, anonymous temporary files)",
    "decoded pictures and thumbnails (process memory)",
    "active prepared PCM and limited tiles (private memory/anonymous files; saved stretches are reported separately)",
];

fn age(metadata: &std::fs::Metadata) -> Duration {
    metadata
        .modified()
        .ok()
        .and_then(|modified| SystemTime::now().duration_since(modified).ok())
        .unwrap_or_default()
}

/// Bytes of a tree without following symbolic links.
pub fn tree_bytes(path: &Path) -> u64 {
    let Ok(metadata) = std::fs::symlink_metadata(path) else {
        return 0;
    };
    if metadata.is_file() {
        return metadata.len();
    }
    if !metadata.is_dir() {
        return 0;
    }
    std::fs::read_dir(path)
        .map(|entries| {
            entries
                .flatten()
                .map(|entry| tree_bytes(&entry.path()))
                .sum()
        })
        .unwrap_or(0)
}

/// Each published proxy entry's bytes and last use, without the cache lock.
fn proxy_entries(root: &Path) -> Vec<(String, u64, Duration)> {
    let Ok(entries) = std::fs::read_dir(root) else {
        return Vec::new();
    };
    entries
        .flatten()
        .filter_map(|entry| {
            let name = entry.file_name().into_string().ok()?;
            if name.starts_with('.') {
                return None;
            }
            let metadata = std::fs::symlink_metadata(entry.path()).ok()?;
            if !metadata.is_dir() {
                return None;
            }
            let used = std::fs::symlink_metadata(entry.path().join("used"))
                .map_or_else(|_| age(&metadata), |used| age(&used));
            Some((name, tree_bytes(&entry.path()), used))
        })
        .collect()
}

/// The time since anything in a tree last changed: its newest modification
/// time, without following symbolic links. A running download keeps
/// writing its file, so the directory's own time is not enough.
fn newest_age(path: &Path) -> Duration {
    fn newest(path: &Path) -> Option<SystemTime> {
        let metadata = std::fs::symlink_metadata(path).ok()?;
        let own = metadata.modified().ok();
        if !metadata.is_dir() {
            return own;
        }
        std::fs::read_dir(path)
            .ok()?
            .flatten()
            .filter_map(|entry| newest(&entry.path()))
            .chain(own)
            .max()
    }
    newest(path)
        .and_then(|newest| SystemTime::now().duration_since(newest).ok())
        .unwrap_or_default()
}

/// What the proxy cache's own cleanup would remove, in its order: entries
/// unused for the grace period, then the least recently used while the rest
/// exceeds its budget. Entries a reader holds are kept by the real pass.
fn proxy_removals(
    mut entries: Vec<(String, u64, Duration)>,
    grace: Duration,
    retained: &[String],
    budget: u64,
) -> Vec<(String, u64)> {
    entries.retain(|(name, _, _)| !retained.contains(name));
    entries.sort_by(|a, b| b.2.cmp(&a.2).then_with(|| a.0.cmp(&b.0)));
    let mut total: u64 = entries.iter().map(|(_, bytes, _)| bytes).sum();
    let mut removed = Vec::new();
    for (name, bytes, used) in entries {
        if used >= grace || total > budget {
            total -= bytes;
            removed.push((name, bytes));
        }
    }
    removed
}

/// The smallest grace period per-user cache cleanup accepts: other Deadpan
/// processes write these caches without a lock this cleanup can observe.
pub const MIN_CACHE_GRACE: Duration = Duration::from_secs(3600);

/// Abandoned helper staging directories with nothing changed for `grace`.
fn stale_helper_staging(root: &Path, grace: Duration) -> Vec<(PathBuf, u64)> {
    let Ok(entries) = std::fs::read_dir(root) else {
        return Vec::new();
    };
    entries
        .flatten()
        .filter_map(|entry| {
            let metadata = std::fs::symlink_metadata(entry.path()).ok()?;
            (metadata.is_dir() && newest_age(&entry.path()) >= grace)
                .then(|| (entry.path(), tree_bytes(&entry.path())))
        })
        .collect()
}

impl UserStorage {
    /// Account for every per-user directory. Entries are unchanged; inspection
    /// of an existing audio cache may initialize its coordination lock.
    pub fn report(&self, grace: Duration) -> UserStorageReport {
        let mut directories = Vec::new();
        let audio_path = self.caches.join("Audio");
        let (saved_audio, saved_audio_error, audio_removable) = if audio_path.exists() {
            match deadpan_audio::persistent_pcm::PcmCache::at(&audio_path)
                .and_then(|cache| Ok((cache.entries()?, cache.cleanup(grace, true)?.removed_bytes)))
            {
                Ok((entries, removable)) => (entries, None, removable),
                Err(error) => (Vec::new(), Some(error.to_string()), 0),
            }
        } else {
            (Vec::new(), None, 0)
        };
        directories.push(CacheDirectory {
            name: "Saved audio".into(),
            path: audio_path.clone(),
            bytes: tree_bytes(&audio_path),
            kind: "rebuildable canonical stretches; active readers are retained",
            cleanable: true,
            removable_bytes: audio_removable,
        });
        let proxies = self.proxies();
        let proxy_entries = proxy_entries(&proxies);
        directories.push(CacheDirectory {
            name: "Proxies".into(),
            bytes: tree_bytes(&proxies),
            path: proxies,
            kind: "rebuildable seek proxies",
            cleanable: true,
            removable_bytes: proxy_removals(proxy_entries, grace, &[], DEFAULT_PROXY_BUDGET_BYTES)
                .iter()
                .map(|(_, bytes)| bytes)
                .sum(),
        });
        let staging = self.helper_staging();
        directories.push(CacheDirectory {
            name: "Downloader staging".into(),
            bytes: tree_bytes(&staging),
            removable_bytes: stale_helper_staging(&staging, grace)
                .iter()
                .map(|(_, bytes)| bytes)
                .sum(),
            path: staging,
            kind: "abandoned downloader-helper downloads",
            cleanable: true,
        });
        if let Ok(entries) = std::fs::read_dir(&self.caches) {
            let mut others: Vec<_> = entries
                .flatten()
                .filter(|entry| entry.file_name() != "Proxies" && entry.file_name() != "Audio")
                .collect();
            others.sort_by_key(std::fs::DirEntry::file_name);
            for entry in others {
                let name = entry.file_name().to_string_lossy().into_owned();
                let kind = if name.starts_with("ltx-") {
                    "AI runtime or qualification weights (never cleaned)"
                } else {
                    "other per-user cache (never cleaned)"
                };
                directories.push(CacheDirectory {
                    name,
                    bytes: tree_bytes(&entry.path()),
                    path: entry.path(),
                    kind,
                    cleanable: false,
                    removable_bytes: 0,
                });
            }
        }
        let models = self.support.join("Models");
        directories.push(CacheDirectory {
            name: "Model packs".into(),
            bytes: tree_bytes(&models),
            path: models,
            kind: "installed model packs (managed by `models remove`)",
            cleanable: false,
            removable_bytes: 0,
        });
        let total_bytes = directories.iter().map(|directory| directory.bytes).sum();
        let removable_bytes = directories
            .iter()
            .map(|directory| directory.removable_bytes)
            .sum();
        UserStorageReport {
            schema_version: 1,
            grace_seconds: grace.as_secs(),
            directories,
            total_bytes,
            removable_bytes,
            not_on_disk: NOT_ON_DISK.to_vec(),
            saved_audio,
            saved_audio_error,
        }
    }

    /// Remove proxies unused for `grace` and helper staging older than it.
    /// `retain` names proxy entries to keep regardless of age, such as the
    /// open project's Original. Readers' entries are always kept.
    pub fn clean(
        &self,
        grace: Duration,
        dry_run: bool,
        retain: &[crate::proxy::cache::ProxyKey],
    ) -> Result<UserCleanupOutcome, CliError> {
        let mut outcome = UserCleanupOutcome {
            dry_run,
            ..UserCleanupOutcome::default()
        };
        let proxies = self.proxies();
        let retained: Vec<String> = retain
            .iter()
            .map(crate::proxy::cache::ProxyKey::directory)
            .collect();
        if grace < MIN_CACHE_GRACE {
            return Err(CliError::Usage(
                "Cache cleanup needs a grace period of at least one hour; another Deadpan process may be writing these caches.".into(),
            ));
        }
        if dry_run {
            for (name, bytes) in proxy_removals(
                proxy_entries(&proxies),
                grace,
                &retained,
                DEFAULT_PROXY_BUDGET_BYTES,
            ) {
                outcome.removed_bytes += bytes;
                outcome.removed.push(proxies.join(name));
            }
            // Completed ranges of unfinished builds, unless retained.
            for (path, bytes) in stale_helper_staging(&proxies.join(".partial"), grace) {
                let name = path
                    .file_name()
                    .map(|name| name.to_string_lossy().into_owned());
                if name.is_some_and(|name| retained.contains(&name)) {
                    continue;
                }
                outcome.removed_bytes += bytes;
                outcome.removed.push(path);
            }
        } else if proxies.is_dir() {
            let before: Vec<_> = proxy_entries(&proxies);
            let cache = ProxyCache::at(&proxies)
                .map_err(|error| CliError::Usage(format!("proxy cache: {error}")))?;
            let report = cache
                .cleanup(
                    retain,
                    ProxyCleanupPolicy {
                        staging_grace: grace,
                        unused_grace: grace,
                        partial_grace: grace,
                        budget_bytes: DEFAULT_PROXY_BUDGET_BYTES,
                    },
                )
                .map_err(|error| CliError::Usage(format!("proxy cache: {error}")))?;
            // Completed ranges of unfinished builds.
            outcome.removed_bytes += report.removed_partial_bytes;
            for name in report.removed_partials {
                outcome.removed.push(proxies.join(".partial").join(name));
            }
            for name in report.removed_entries {
                outcome.removed_bytes += before
                    .iter()
                    .find(|(entry, _, _)| *entry == name)
                    .map_or(0, |(_, bytes, _)| *bytes);
                outcome.removed.push(proxies.join(name));
            }
            outcome.kept_in_use = report.kept_in_use;
        }
        let audio_path = self.caches.join("Audio");
        if audio_path.exists() {
            let cleanup = deadpan_audio::persistent_pcm::PcmCache::at(&audio_path)
                .and_then(|cache| cache.cleanup(grace, dry_run))?;
            outcome.removed_bytes += cleanup.removed_bytes;
            outcome.removed.extend(
                cleanup
                    .removed
                    .into_iter()
                    .map(|name| audio_path.join(name)),
            );
            outcome.kept_in_use.extend(
                cleanup
                    .kept_in_use
                    .into_iter()
                    .map(|name| format!("Audio/{name}")),
            );
        }
        for (path, bytes) in stale_helper_staging(&self.helper_staging(), grace) {
            if !dry_run {
                std::fs::remove_dir_all(&path)?;
            }
            outcome.removed_bytes += bytes;
            outcome.removed.push(path);
        }
        Ok(outcome)
    }
}

/// What an explicit expiry found to do, planned on any store (read-only
/// included) so that the reference scan never holds the writer.
#[derive(Debug, Clone)]
pub enum PlannedExpiry {
    /// `--files-only`: AI variants are left alone, as Storage P/R does.
    NotRequested,
    /// The clock is behind the project's records: nothing may expire.
    Skipped {
        reason: String,
        clock_anomaly: ClockAnomaly,
    },
    Planned(ExpiryPlan),
}

/// The typed `variant_expiry` of every cleanup and clock confirmation reply.
#[derive(Debug, Clone, Serialize)]
#[serde(tag = "status", rename_all = "snake_case")]
pub enum ExpiryStatus {
    NotRequested,
    Skipped {
        reason: String,
        clock_anomaly: ClockAnomaly,
    },
    /// A dry run: what applying the plan would expire.
    Previewed {
        #[serde(flatten)]
        expiry: VariantExpiry,
    },
    Applied {
        #[serde(flatten)]
        expiry: VariantExpiry,
    },
}

/// Plan an explicit expiry under the current clock, with the app's clock
/// check: a clock behind the project's records is never confirmed.
pub fn plan_expiry(store: &ProjectStore) -> Result<PlannedExpiry, LiveError> {
    if let Some(anomaly @ ClockAnomaly::Behind { .. }) = store
        .generation_retention_clock(SystemTime::now(), DEFAULT_VARIANT_RETENTION)
        .map_err(LiveError::store)?
    {
        return Ok(PlannedExpiry::Skipped {
            reason: "This computer's clock is earlier than times this project recorded; correct the date and time first".into(),
            clock_anomaly: anomaly,
        });
    }
    Ok(PlannedExpiry::Planned(
        store
            .plan_generation_expiry(
                SystemTime::now(),
                DEFAULT_VARIANT_RETENTION,
                ExpiryMode::Explicit,
            )
            .map_err(LiveError::store)?,
    ))
}

/// Preview `planned` (any store) or apply it on the writer, which rechecks
/// every planned row in one short transaction.
pub fn settle_expiry(
    store: &mut ProjectStore,
    planned: &PlannedExpiry,
    dry_run: bool,
) -> Result<ExpiryStatus, LiveError> {
    Ok(match planned {
        PlannedExpiry::NotRequested => ExpiryStatus::NotRequested,
        PlannedExpiry::Skipped {
            reason,
            clock_anomaly,
        } => ExpiryStatus::Skipped {
            reason: reason.clone(),
            clock_anomaly: *clock_anomaly,
        },
        PlannedExpiry::Planned(plan) if dry_run => ExpiryStatus::Previewed {
            expiry: plan.preview(),
        },
        PlannedExpiry::Planned(plan) => ExpiryStatus::Applied {
            expiry: store
                .apply_generation_expiry(plan, false)
                .map_err(LiveError::store)?,
        },
    })
}

/// A clock confirmation refuses, rather than skips, a clock behind the
/// project's records, including in a dry run.
pub fn require_planned(planned: &PlannedExpiry) -> Result<(), LiveError> {
    match planned {
        PlannedExpiry::Skipped { reason, .. } => {
            Err(LiveError::new("RetentionClockBehind", reason))
        }
        _ => Ok(()),
    }
}

/// The reply of `--confirm-clock`.
pub fn clock_output(status: &ExpiryStatus) -> Value {
    json!({ "protocol": 1, "variant_expiry": status })
}

/// Storage E on whichever process holds `store`.
pub fn confirm_clock(store: &mut ProjectStore, dry_run: bool) -> Result<Value, LiveError> {
    let planned = plan_expiry(store)?;
    require_planned(&planned)?;
    Ok(clock_output(&settle_expiry(store, &planned, dry_run)?))
}

/// Exactly the files a dry run listed, bound to the project, head revision
/// and grace period it was computed under. Removal goes through
/// [`ProjectStore::clean_previewed_storage`], which removes a listed file only
/// if a fresh scan still finds that same file removable: the Storage panel's
/// R after its P.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct CleanupPlan {
    pub project_id: deadpan_core::ProjectId,
    pub revision_id: deadpan_core::RevisionId,
    pub grace_seconds: u64,
    pub entries: Vec<PlannedRemoval>,
}

impl CleanupPlan {
    pub fn of(
        store: &ProjectStore,
        grace: Duration,
        preview: &CleanupOutcome,
    ) -> Result<Self, LiveError> {
        let document = store.snapshot().map_err(LiveError::store)?;
        Ok(Self {
            project_id: document.project_id().clone(),
            revision_id: document.revision_id().clone(),
            grace_seconds: grace.as_secs(),
            entries: preview.removed.iter().map(RemovedEntry::planned).collect(),
        })
    }

    /// The SHA-256 of the plan's canonical JSON, which names it.
    pub fn hash(&self) -> String {
        use sha2::Digest;
        let bytes = serde_json::to_vec(self).expect("plan serializes");
        sha2::Sha256::digest(bytes)
            .iter()
            .map(|byte| format!("{byte:02x}"))
            .collect()
    }

    /// Refuse a plan for another project or an older or newer head.
    pub fn check(&self, store: &ProjectStore) -> Result<Vec<RemovedEntry>, LiveError> {
        let document = store.snapshot().map_err(LiveError::store)?;
        if document.project_id() != &self.project_id || document.revision_id() != &self.revision_id
        {
            return Err(LiveError {
                current_revision: Some(document.revision_id().clone()),
                ..LiveError::new(
                    "StoragePlanStale",
                    "The cleanup plan was previewed for another project state; preview again",
                )
            });
        }
        self.entries
            .iter()
            .map(RemovedEntry::from_planned)
            .collect::<Result<_, _>>()
            .map_err(LiveError::store)
    }
}

/// The reply of `--clean`: the typed expiry, the file outcome and, for a
/// dry run, the plan a later `--plan` removes exactly.
pub fn clean_output(
    status: &ExpiryStatus,
    cleanup: &CleanupOutcome,
    plan: Option<&CleanupPlan>,
) -> Value {
    json!({
        "protocol": 1,
        "variant_expiry": status,
        "cleanup": cleanup,
        "plan": plan,
        "plan_hash": plan.map(CleanupPlan::hash),
    })
}

/// Explicit project cleanup on whichever process holds `store`.
///
/// - Dry run: preview expiry and files on any store and return the plan.
/// - `plan`: remove exactly the planned files still removable (Storage R).
/// - Otherwise (convenience): expire due variants first, so their masters go
///   in the same run, then remove what a fresh scan finds unreferenced now.
pub fn clean_project(
    store: &mut ProjectStore,
    grace: Duration,
    expire_variants: bool,
    dry_run: bool,
    plan: Option<&CleanupPlan>,
) -> Result<Value, LiveError> {
    if let Some(plan) = plan {
        if dry_run || expire_variants || plan.grace_seconds != grace.as_secs() {
            return Err(LiveError::new(
                "InvalidInput",
                "A cleanup plan removes files only: use --files-only without --dry-run and the plan's own grace period",
            ));
        }
        let previewed = plan.check(store)?;
        let cleanup = store
            .clean_previewed_storage(grace, &previewed)
            .map_err(LiveError::store)?;
        return Ok(clean_output(&ExpiryStatus::NotRequested, &cleanup, None));
    }
    let planned = if expire_variants {
        plan_expiry(store)?
    } else {
        PlannedExpiry::NotRequested
    };
    let status = settle_expiry(store, &planned, dry_run)?;
    if dry_run {
        let cleanup = store
            .preview_storage_cleanup(grace)
            .map_err(LiveError::store)?;
        let plan = CleanupPlan::of(store, grace, &cleanup)?;
        return Ok(clean_output(&status, &cleanup, Some(&plan)));
    }
    let cleanup = store
        .clean_storage(CleanupPolicy::everything(grace, false))
        .map_err(LiveError::store)?;
    Ok(clean_output(&status, &cleanup, None))
}

/// Read a `--plan` file: a dry run's whole output or just its plan. A given
/// `plan_hash` must match.
fn read_plan(path: &Path) -> Result<CleanupPlan, CliError> {
    let value: Value = serde_json::from_str(&crate::read_request(path)?)?;
    let (plan, hash) = match value.get("plan") {
        Some(plan) => (plan.clone(), value.get("plan_hash").cloned()),
        None => (value, None),
    };
    let plan: CleanupPlan = serde_json::from_value(plan)?;
    if let Some(hash) = hash
        && hash != json!(plan.hash())
    {
        return Err(LiveError::new(
            "StoragePlanInvalid",
            "The cleanup plan does not match its plan_hash",
        )
        .into());
    }
    Ok(plan)
}

const USAGE: &str = "usage: project storage <project.deadpan> [--grace-hours N] [--clean [--files-only] [--dry-run] [--plan <dry-run.json>] | --confirm-clock [--dry-run]]";

/// `--grace-hours N` (default 24) followed by the remaining flags.
fn grace<'a>(arguments: &[&'a str]) -> Result<(Duration, Vec<&'a str>), CliError> {
    let mut grace = DEFAULT_GRACE;
    let mut rest = Vec::new();
    let mut iter = arguments.iter();
    while let Some(argument) = iter.next() {
        if *argument == "--grace-hours" {
            let hours: u64 = iter
                .next()
                .and_then(|value| value.parse().ok())
                .filter(|hours| *hours <= 24 * 365)
                .ok_or_else(|| CliError::Usage("--grace-hours takes 0..8760".into()))?;
            grace = Duration::from_secs(hours * 3600);
        } else {
            rest.push(*argument);
        }
    }
    Ok((grace, rest))
}

#[derive(Serialize)]
struct ProjectStorage<'a> {
    protocol: u32,
    project: &'a StorageReport,
    user: &'a UserStorageReport,
}

/// `project storage <package> [--grace-hours N]` and
/// `project storage <package> --clean [--dry-run] [--grace-hours N]`.
pub(crate) fn run_project(arguments: &[&str]) -> Result<(), CliError> {
    let (grace, rest) = grace(arguments)?;
    let user = UserStorage::current();
    match rest.as_slice() {
        [package] => {
            let store = ProjectStore::open(Path::new(package), AccessMode::ReadOnly)?;
            let project = store.storage_report(grace)?;
            let user = user.map_or_else(
                || {
                    UserStorage {
                        caches: PathBuf::new(),
                        support: PathBuf::new(),
                    }
                    .report(grace)
                },
                |user| user.report(grace),
            );
            write_json(&ProjectStorage {
                protocol: 1,
                project: &project,
                user: &user,
            })
        }
        [package, "--clean", flags @ ..] => {
            let mut dry_run = false;
            let mut files_only = false;
            let mut plan = None;
            let mut flags = flags.iter();
            while let Some(flag) = flags.next() {
                match *flag {
                    "--dry-run" => dry_run = true,
                    "--files-only" => files_only = true,
                    "--plan" => {
                        let path = flags.next().ok_or_else(|| CliError::Usage(USAGE.into()))?;
                        plan = Some(read_plan(Path::new(path))?);
                    }
                    _ => return Err(CliError::Usage(USAGE.into())),
                }
            }
            write_json(&crate::live_project::dispatch_short(
                Path::new(package),
                None,
                ShortOperation::CleanStorage {
                    grace_seconds: grace.as_secs(),
                    expire_variants: !files_only,
                    dry_run,
                    plan: plan.map(Box::new),
                },
            )?)
        }
        [package, "--confirm-clock", flags @ ..]
            if flags.iter().all(|flag| *flag == "--dry-run") =>
        {
            write_json(&crate::live_project::dispatch_short(
                Path::new(package),
                None,
                ShortOperation::ConfirmVariantClock {
                    dry_run: !flags.is_empty(),
                },
            )?)
        }
        _ => Err(CliError::Usage(USAGE.into())),
    }
}

/// `project copy-portable <package> <destination.deadpan>`.
pub(crate) fn run_copy(arguments: &[&str]) -> Result<(), CliError> {
    let [package, destination] = arguments else {
        return Err(CliError::Usage(
            "usage: project copy-portable <project.deadpan> <new-copy.deadpan>".into(),
        ));
    };
    let report = deadpan_store::portable::copy_portable(
        Path::new(package),
        Path::new(destination),
        &AtomicBool::new(false),
    )?;
    write_json(&serde_json::json!({ "protocol": 1, "portable_copy": report }))
}

/// `cache status [--grace-hours N]` and
/// `cache clean [--dry-run] [--grace-hours N]`.
pub(crate) fn run_cache(arguments: &[&str]) -> Result<(), CliError> {
    let (grace, rest) = grace(arguments)?;
    let user = UserStorage::current()
        .ok_or_else(|| CliError::Usage("HOME is not set to an absolute directory".into()))?;
    match rest.as_slice() {
        ["status"] => write_json(&serde_json::json!({ "protocol": 1, "user": user.report(grace) })),
        ["clean", flags @ ..] if flags.iter().all(|flag| *flag == "--dry-run") => {
            let outcome = user.clean(grace, !flags.is_empty(), &[])?;
            write_json(&serde_json::json!({ "protocol": 1, "cleanup": outcome }))
        }
        _ => Err(CliError::Usage(
            "usage: cache status | cache clean [--dry-run]; both take [--grace-hours N]".into(),
        )),
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    fn backdate(path: &Path, seconds: u64) {
        let past = SystemTime::now() - Duration::from_secs(seconds);
        let file = std::fs::File::options()
            .read(true)
            .open(path)
            .or_else(|_| std::fs::File::open(path))
            .unwrap();
        file.set_modified(past).unwrap();
    }

    #[test]
    fn user_cleanup_removes_only_old_rebuildable_entries_under_its_own_roots() {
        let home = tempfile::tempdir().unwrap();
        let user = UserStorage {
            caches: home.path().join("Library/Caches/Deadpan"),
            support: home.path().join("Library/Application Support/Deadpan"),
        };
        // Weights and runtimes are reported, never cleaned.
        let weights = user.caches.join("ltx-qualification/model.safetensors");
        std::fs::create_dir_all(weights.parent().unwrap()).unwrap();
        std::fs::write(&weights, vec![0_u8; 4096]).unwrap();
        backdate(&weights, 400 * 24 * 3600);
        let models = user.support.join("Models/pack/weights.bin");
        std::fs::create_dir_all(models.parent().unwrap()).unwrap();
        std::fs::write(&models, vec![0_u8; 1024]).unwrap();
        // An old abandoned download, and a running one whose directory is
        // old but whose file is still being written.
        let old = user.helper_staging().join("yt-dlp-old");
        let fresh = user.helper_staging().join("yt-dlp-fresh");
        for directory in [&old, &fresh] {
            std::fs::create_dir_all(directory).unwrap();
            std::fs::write(directory.join("download"), b"partial").unwrap();
        }
        backdate(&old.join("download"), 3 * 24 * 3600);
        backdate(&old, 3 * 24 * 3600);
        backdate(&fresh, 3 * 24 * 3600);
        assert!(
            user.clean(Duration::from_secs(60), true, &[]).is_err(),
            "grace below an hour is refused"
        );

        let report = user.report(DEFAULT_GRACE);
        let named = |name: &str| {
            report
                .directories
                .iter()
                .find(|directory| directory.name == name)
                .unwrap()
                .clone()
        };
        assert_eq!(named("ltx-qualification").bytes, 4096);
        assert!(!named("ltx-qualification").cleanable);
        assert_eq!(named("Model packs").bytes, 1024);
        assert_eq!(named("Downloader staging").removable_bytes, 7);
        assert!(!report.not_on_disk.is_empty());

        let preview = user.clean(DEFAULT_GRACE, true, &[]).unwrap();
        assert_eq!(preview.removed, vec![old.clone()]);
        assert!(old.exists());
        let outcome = user.clean(DEFAULT_GRACE, false, &[]).unwrap();
        assert_eq!(outcome.removed, vec![old.clone()]);
        assert!(!old.exists());
        assert!(fresh.exists());
        assert!(weights.exists());
        assert!(models.exists());
        // No proxy cache was created by reporting or cleaning.
        assert!(!user.proxies().exists());
    }

    #[test]
    fn saved_audio_cleanup_obeys_grace_and_reader_locks() {
        use rustix::fs::{FlockOperation, flock};
        let root = tempfile::tempdir().unwrap();
        let user = UserStorage {
            caches: root.path().join("caches"),
            support: root.path().join("support"),
        };
        let cache =
            deadpan_audio::persistent_pcm::PcmCache::at(&user.caches.join("Audio")).unwrap();
        let old = cache.path().join(format!("b3-{}.pcm", "1".repeat(64)));
        let active = cache.path().join(format!("b3-{}.pcm", "2".repeat(64)));
        let fresh = cache.path().join(format!("b3-{}.pcm", "3".repeat(64)));
        for path in [&old, &active, &fresh] {
            std::fs::write(path, [0; 80]).unwrap();
        }
        backdate(&old, 3 * 24 * 3600);
        backdate(&active, 3 * 24 * 3600);
        let reader = std::fs::File::open(&active).unwrap();
        flock(&reader, FlockOperation::NonBlockingLockShared).unwrap();
        let report = user.report(DEFAULT_GRACE);
        assert_eq!(report.saved_audio.len(), 3);
        assert!(report.saved_audio_error.is_none());
        assert_eq!(report.removable_bytes, 80);
        let outcome = user.clean(DEFAULT_GRACE, false, &[]).unwrap();
        assert_eq!(outcome.removed, vec![old.clone()]);
        assert_eq!(outcome.kept_in_use.len(), 1);
        assert!(!old.exists());
        assert!(active.exists());
        assert!(fresh.exists());
        drop(reader);
        assert_eq!(
            user.clean(DEFAULT_GRACE, false, &[]).unwrap().removed,
            vec![active]
        );
        assert!(fresh.exists());
    }

    #[test]
    fn the_cache_preview_includes_the_budget_pass_in_least_recently_used_order() {
        let day = Duration::from_secs(86_400);
        let entries = vec![
            ("recent".to_owned(), 40, Duration::from_secs(60)),
            ("stale".to_owned(), 10, 40 * day),
            ("older".to_owned(), 30, 2 * day),
            ("kept".to_owned(), 30, 3 * day),
        ];
        // Stale goes for age; then the least recently used until 50 bytes fit.
        let removed = proxy_removals(entries, 30 * day, &["kept".to_owned()], 50);
        assert_eq!(
            removed,
            vec![("stale".to_owned(), 10), ("older".to_owned(), 30)]
        );
    }
}
