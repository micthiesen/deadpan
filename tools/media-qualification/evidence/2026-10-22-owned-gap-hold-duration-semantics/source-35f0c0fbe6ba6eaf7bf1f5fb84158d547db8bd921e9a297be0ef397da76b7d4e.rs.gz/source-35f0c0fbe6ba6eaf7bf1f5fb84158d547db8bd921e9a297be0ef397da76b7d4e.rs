use std::collections::BTreeMap;
use std::io::Read as _;
use std::path::PathBuf;

use deadpan_core::{
    BeatNode, ColorPolicy, Command, CommandRequest, FrameDuration, HoldAudio, HoldRecipe,
    HoldVideo, PresentationBasis, ProjectDocument, ProjectId, Subtree,
};
use deadpan_jobs::{
    BridgeGenerationPlan, ConditioningMode, FailureCode, HoldConstraints, MotionAmount, Relevance,
    VideoSpec, WorkerFailure,
};

use super::*;
use crate::generation::conditioning::{self, BridgeInputs};
use crate::generation::runtime::BridgeRuntime;

const FRAMES: i64 = 24;

mod extension;
mod extension_scheduling;
mod preparations;

fn fixture_rate(frames: i64) -> deadpan_core::FrameRate {
    // A single sampled frame must still request a native interval within the
    // real provider's minimum. At 2 fps its two boundaries span one second.
    deadpan_core::FrameRate::new(if frames == 1 { 2 } else { 24 }, 1).unwrap()
}

fn hold_id() -> NodeId {
    NodeId::new("pause").unwrap()
}

/// A project whose root Sequence holds one 24-frame silent Hold at 24 fps.
fn project(directory: &Path) -> ProjectStore {
    project_with_frames(directory, FRAMES)
}

fn project_with_frames(directory: &Path, frames: i64) -> ProjectStore {
    let root = NodeId::new("root").unwrap();
    let initial = ProjectDocument::new(
        ProjectId::new("ai-hold-test").unwrap(),
        RevisionId::new("initial").unwrap(),
        PresentationBasis {
            width: 768,
            height: 320,
            frame_rate: fixture_rate(frames),
            color_policy: ColorPolicy::SdrRec709,
        },
        root.clone(),
    )
    .unwrap();
    let edit = deadpan_core::apply(
        &initial,
        &CommandRequest {
            project_id: initial.project_id().clone(),
            expected_revision: initial.revision_id().clone(),
            new_revision: RevisionId::new("with-pause").unwrap(),
            command: Command::Insert {
                parent: root,
                index: 0,
                subtree: Subtree {
                    root: hold_id(),
                    nodes: BTreeMap::from([(
                        hold_id(),
                        BeatNode::hold(
                            "Pause",
                            HoldRecipe {
                                duration: FrameDuration::new(frames).unwrap(),
                                picture_context: None,
                                video: HoldVideo::Background,
                                audio: HoldAudio::Silence,
                            },
                        ),
                    )]),
                    overrides: BTreeMap::new(),
                    gap_overrides: BTreeMap::new(),
                },
            },
        },
    )
    .unwrap();
    let document = edit.forward.apply(&initial).unwrap();
    ProjectStore::create(&directory.join("test.deadpan"), &document).unwrap()
}

fn inputs() -> BridgeInputs {
    inputs_for_frames(FRAMES)
}

fn inputs_for_frames(frames: i64) -> BridgeInputs {
    let rate = fixture_rate(frames);
    let duration = FrameDuration::new(frames).unwrap();
    let plan = BridgeGenerationPlan::for_conditioning(
        ConditioningMode::Bridge,
        duration,
        rate,
        &crate::generation::development_capability(),
        crate::generation::native_dimensions(),
    )
    .unwrap();
    let constraints = HoldConstraints {
        video: VideoSpec::new(duration, rate, 768, 320).unwrap(),
        conditioning: ConditioningMode::Bridge,
        motion: MotionAmount::Still,
        instructions: None,
        region_target: None,
    };
    // Prepared pictures are opaque retained bytes to capture and the store.
    let (left, right) = conditioning::opaque_boundaries(&plan, b"left".to_vec(), b"right".to_vec());
    conditioning::assemble(plan, constraints, left, right, full_raster()).unwrap()
}

fn full_raster() -> deadpan_models::RasterRect {
    deadpan_models::RasterRect::new(0, 0, 768, 320).unwrap()
}

fn allocated(store: &mut ProjectStore) -> Allocated {
    let expected_revision = store.head_revision().unwrap();
    allocate(
        store,
        AllocateInput {
            hold: hold_id(),
            expected_revision,
            seed: 7,
            inputs: inputs().into(),
        },
    )
    .unwrap()
}

fn state(store: &ProjectStore, allocated: &Allocated) -> JobState {
    store
        .generation_attempt(&allocated.identity)
        .unwrap()
        .unwrap()
        .checkpoint
        .state
}

/// Every executable is a stand-in; `python` is what actually runs.
fn runtime(directory: &Path, python: &str) -> BridgeRuntime {
    let stand_in = PathBuf::from("/usr/bin/true");
    BridgeRuntime {
        python: PathBuf::from(python),
        runtime_source: directory.to_path_buf(),
        model_cache: directory.to_path_buf(),
        model_manifest: deadpan_models::packs::approved_pack("ltx-2.3-q4-bridge").unwrap(),
        ffmpeg: stand_in.clone(),
        ffprobe: stand_in.clone(),
        worker_script: stand_in.clone(),
        media_worker: stand_in.clone(),
        landmark_worker: stand_in,
    }
}

#[test]
fn allocation_records_a_current_bridge_request_and_a_queued_attempt() {
    let directory = tempfile::tempdir().unwrap();
    let mut store = project(directory.path());
    let first = allocated(&mut store);
    assert_eq!(first.request.relevance, Relevance::Current);
    assert_eq!(
        first.request.binding.context_sha256,
        inputs().manifest_sha256
    );
    assert_eq!(state(&store, &first), JobState::Queued);
    first.host_message.validate().unwrap();
    // A new request for the same Hold supersedes the first.
    let second = allocated(&mut store);
    assert_eq!(second.request.binding.request_version.get(), 2);
    let current = store.current_generation_requests().unwrap();
    assert_eq!(current.len(), 1);
    assert_eq!(current[0].request_id, second.identity.request_id);
}

#[test]
fn selected_pack_identity_is_durable_and_variants_keep_that_identity() {
    let directory = tempfile::tempdir().unwrap();
    let mut store = project(directory.path());
    let expected_revision = store.head_revision().unwrap();
    let selected: deadpan_jobs::ProviderSelection = serde_json::from_value(serde_json::json!({
        "pack_id": "ltx-2.3-q4-bridge",
        "pack_version": "2",
        "runtime_id": "ltx-mlx",
        "runtime_version": "0.15.8+deadpan5",
        "seed": 7,
    }))
    .unwrap();
    let first = allocate_with_provider(
        &mut store,
        AllocateInput {
            hold: hold_id(),
            expected_revision,
            seed: 7,
            inputs: inputs().into(),
        },
        selected,
    )
    .unwrap();
    assert_eq!(first.request.provider.pack_version.as_str(), "2");
    assert_eq!(first.provider().pack_version.as_str(), "2");

    let cancelled = run_worker(
        &first,
        &runtime(directory.path(), "/usr/bin/false"),
        |_| {},
        |_| Ok(()),
        &AtomicBool::new(true),
    );
    assert_eq!(
        finish(&mut store, &first, cancelled).unwrap().state,
        JobState::Cancelled
    );
    let second = allocate_variant(&mut store, first.request.clone(), inputs().into()).unwrap();
    assert_eq!(second.provider().pack_version.as_str(), "2");
    assert_eq!(second.provider().seed, 8);
    assert_eq!(second.request.provider.pack_version.as_str(), "2");
}

#[test]
fn cancellation_before_launch_is_recorded_as_cancelled() {
    let directory = tempfile::tempdir().unwrap();
    let mut store = project(directory.path());
    let allocated = allocated(&mut store);
    let mut records = Vec::new();
    let run = run_worker(
        &allocated,
        &runtime(directory.path(), "/usr/bin/false"),
        |_| {},
        |record| {
            records.push(record);
            Ok(())
        },
        &AtomicBool::new(true),
    );
    assert!(matches!(run.result, RunResult::Cancelled));
    assert_eq!(records, [AttemptRecord::CancelRequested]);
    for record in &records {
        super::record(&mut store, &allocated, record).unwrap();
    }
    assert_eq!(state(&store, &allocated), JobState::Cancelling);
    let finished = finish(&mut store, &allocated, run).unwrap();
    assert_eq!(finished.state, JobState::Cancelled);
    assert_eq!(state(&store, &allocated), JobState::Cancelled);
}

#[test]
fn a_cancelled_run_whose_cancel_record_was_lost_still_finishes_cancelled() {
    let directory = tempfile::tempdir().unwrap();
    let mut store = project(directory.path());
    let allocated = allocated(&mut store);
    let run = run_worker(
        &allocated,
        &runtime(directory.path(), "/usr/bin/false"),
        |_| {},
        |_| Err("writer unavailable".into()),
        &AtomicBool::new(true),
    );
    assert_eq!(
        finish(&mut store, &allocated, run).unwrap().state,
        JobState::Cancelled
    );
}

#[test]
fn sleep_before_or_during_cancel_finalization_remains_durably_interrupted() {
    use std::cell::Cell;
    for interrupt_check in [1, 3] {
        let directory = tempfile::tempdir().unwrap();
        let mut store = project(directory.path());
        let allocated = allocated(&mut store);
        let calls = Cell::new(0);
        let finished = finish_with_interruption(
            &mut store,
            &allocated,
            WorkerRun::without_workspace(RunResult::Cancelled, RunTimings::default()),
            || {
                calls.set(calls.get() + 1);
                calls.get() >= interrupt_check
            },
        )
        .unwrap();
        assert_eq!(finished.state, JobState::Failed);
        assert!(
            matches!(finished.failure, Some(JobFailure::Host(ref failure)) if failure.code == HostFailureCode::Interrupted)
        );
        let stored = store
            .generation_attempt(&allocated.identity)
            .unwrap()
            .unwrap();
        assert_eq!(stored.checkpoint.failure, finished.failure);
        assert!(stored.bundle_receipt.is_none());
        store.validate_full().unwrap();
    }
}

#[test]
fn independent_failure_observed_before_sleep_keeps_its_original_cause() {
    use std::cell::Cell;
    let directory = tempfile::tempdir().unwrap();
    let mut store = project(directory.path());
    let allocated = allocated(&mut store);
    let failure = JobFailure::Host(host_failure(
        HostFailureCode::WorkerExited,
        "worker exited before sleep",
    ));
    let calls = Cell::new(0);
    let finished = finish_with_interruption(
        &mut store,
        &allocated,
        WorkerRun::without_workspace(RunResult::Failed(failure.clone()), RunTimings::default()),
        || {
            calls.set(calls.get() + 1);
            true
        },
    )
    .unwrap();
    assert_eq!(calls.get(), 0, "sleep cannot replace a concrete failure");
    assert_eq!(finished.failure, Some(failure.clone()));
    assert_eq!(
        store
            .generation_attempt(&allocated.identity)
            .unwrap()
            .unwrap()
            .checkpoint
            .failure,
        Some(failure)
    );
    store.validate_full().unwrap();
}

#[test]
fn sleep_during_qualified_object_promotion_never_publishes_ready() {
    use std::cell::Cell;
    let Some(worker) = synthetic_tools() else {
        eprintln!("skipped: needs ffmpeg with libx264rgb and a built deadpan-media-worker");
        return;
    };
    let directory = tempfile::tempdir().unwrap();
    let mut store = project(directory.path());
    let expected_revision = store.head_revision().unwrap();
    let allocated = allocate(
        &mut store,
        AllocateInput {
            hold: hold_id(),
            expected_revision,
            seed: 7,
            inputs: picture_inputs().into(),
        },
    )
    .unwrap();
    let run = synthetic::run(
        &allocated,
        &worker,
        |_| {},
        |record| super::record(&mut store, &allocated, &record).map_err(|error| error.to_string()),
        &AtomicBool::new(false),
    );
    assert!(matches!(run.result, RunResult::Qualified(_)));
    let calls = Cell::new(0);
    let finished = finish_with_interruption(&mut store, &allocated, run, || {
        calls.set(calls.get() + 1);
        calls.get() >= 2
    })
    .unwrap();
    assert_eq!(calls.get(), 2);
    assert!(finished.receipt.is_none());
    assert!(
        matches!(finished.failure, Some(JobFailure::Host(ref failure)) if failure.code == HostFailureCode::Interrupted)
    );
    assert!(
        store
            .selected_generation_bundle(&allocated.identity.request_id)
            .unwrap()
            .is_none()
    );
    store.validate_full().unwrap();
}

#[test]
fn a_worker_that_exits_without_a_candidate_fails_truthfully() {
    let directory = tempfile::tempdir().unwrap();
    let mut store = project(directory.path());
    let allocated = allocated(&mut store);
    let mut stages = Vec::new();
    let mut records = Vec::new();
    let run = run_worker(
        &allocated,
        &runtime(directory.path(), "/usr/bin/false"),
        |progress| stages.push(progress),
        |record| {
            records.push(record);
            Ok(())
        },
        &AtomicBool::new(false),
    );
    assert_eq!(stages, [AttemptProgress::Preparing]);
    assert!(records.is_empty(), "no worker messages: {records:?}");
    let RunResult::Failed(JobFailure::Host(failure)) = &run.result else {
        panic!("expected a host failure");
    };
    assert_eq!(failure.code, HostFailureCode::WorkerExited);
    let finished = finish(&mut store, &allocated, run).unwrap();
    assert_eq!(finished.state, JobState::Failed);
    assert_eq!(state(&store, &allocated), JobState::Failed);
    // The request stays current for a retry with a new attempt.
    assert_eq!(store.current_generation_requests().unwrap().len(), 1);
}

#[cfg(target_os = "macos")]
#[test]
fn ai_network_inference_host_preserves_files_protocol_and_owned_group() {
    let directory = tempfile::tempdir().unwrap();
    let mut store = project(directory.path());
    let allocated = allocated(&mut store);
    let probe = crate::generation::runtime::network_tests::Probe::new();
    let mut stages = Vec::new();
    let run = run_worker(
        &allocated,
        &probe.runtime(),
        |progress| stages.push(progress),
        |entry| record(&mut store, &allocated, &entry).map_err(|error| error.to_string()),
        &AtomicBool::new(false),
    );
    assert!(
        matches!(&run.result, RunResult::Failed(JobFailure::Worker(failure))
        if failure.code == FailureCode::BackendFailure
            && failure.detail.as_str() == "network isolation probe finished"),
        "worker did not exchange its valid protocol: {}",
        run.worker_log
    );
    assert!(stages.contains(&AttemptProgress::Stage(WorkerStage::Preflight)));
    probe.assert_denied();
    assert_eq!(
        finish(&mut store, &allocated, run).unwrap().state,
        JobState::Failed
    );
}

#[test]
fn a_worker_failure_the_store_missed_is_recorded_as_a_host_failure() {
    let directory = tempfile::tempdir().unwrap();
    let mut store = project(directory.path());
    let allocated = allocated(&mut store);
    let run = WorkerRun::early(
        RunResult::Failed(JobFailure::Worker(WorkerFailure {
            code: FailureCode::BackendFailure,
            detail: diagnostic("out of memory"),
        })),
        RunTimings::default(),
    );
    let finished = finish(&mut store, &allocated, run).unwrap();
    assert_eq!(finished.state, JobState::Failed);
    let Some(JobFailure::Host(failure)) = finished.failure else {
        panic!("expected the recorded host failure");
    };
    assert!(failure.detail.as_str().contains("out of memory"));
}

#[test]
fn reaping_finishes_cancel_and_keeps_the_first_failure() {
    let directory = tempfile::tempdir().unwrap();
    let mut store = project(directory.path());
    let allocated = allocated(&mut store);
    let lifecycle = || {
        JobLifecycle::new_with_protocol(
            allocated.identity.clone(),
            allocated.cancellation_token.clone(),
            allocated.request.binding.clone(),
            ProtocolVersion::V2,
        )
    };
    for clean in [true, false] {
        let mut job = lifecycle();
        job.request_cancel(&allocated.identity, &allocated.cancellation_token)
            .unwrap();
        reaped(&mut job, clean);
        assert!(matches!(concluded(&job), RunResult::Cancelled));
    }
    let mut job = lifecycle();
    fail(
        &mut job,
        HostFailureCode::ProtocolViolation,
        "malformed payload",
    );
    fail(&mut job, HostFailureCode::WorkerExited, "later exit");
    reaped(&mut job, false);
    let RunResult::Failed(JobFailure::Host(failure)) = concluded(&job) else {
        panic!("expected failure");
    };
    assert_eq!(failure.code, HostFailureCode::ProtocolViolation);
    // A clean exit without a candidate is not success.
    let mut job = lifecycle();
    reaped(&mut job, true);
    assert!(matches!(concluded(&job), RunResult::Failed(_)));
}

/// The synthetic worker's required tools, when this machine has them.
fn synthetic_tools() -> Option<synthetic::SyntheticWorker> {
    let configured_ffmpeg = std::env::var_os("DEADPAN_BRIDGE_FFMPEG");
    let configured_media_worker = std::env::var_os("DEADPAN_MEDIA_WORKER");
    let ffmpeg = configured_ffmpeg
        .as_ref()
        .map(|value| PathBuf::from(value.as_os_str()))
        .unwrap_or_else(|| PathBuf::from("/opt/homebrew/bin/ffmpeg"));
    let media_worker = configured_media_worker
        .as_ref()
        .map(|value| PathBuf::from(value.as_os_str()))
        .unwrap_or_else(|| {
            Path::new(env!("CARGO_MANIFEST_DIR")).join("../../target/debug/deadpan-media-worker")
        });
    let landmark_worker = media_worker.with_file_name(crate::generation::runtime::LANDMARK_WORKER);
    if configured_ffmpeg.is_some() || configured_media_worker.is_some() {
        assert!(
            ffmpeg.is_file(),
            "configured DEADPAN_BRIDGE_FFMPEG does not name a file: {}",
            ffmpeg.display()
        );
        assert!(
            media_worker.is_file(),
            "configured DEADPAN_MEDIA_WORKER does not name a file: {}",
            media_worker.display()
        );
        assert!(
            landmark_worker.is_file(),
            "deadpan-track must be installed beside DEADPAN_MEDIA_WORKER: {}",
            landmark_worker.display()
        );
    }
    (ffmpeg.is_file() && media_worker.is_file() && landmark_worker.is_file()).then_some(
        synthetic::SyntheticWorker {
            ffmpeg,
            media_worker,
            landmark_worker,
        },
    )
}

/// Real PNG conditioning pictures at the native raster.
fn picture_inputs() -> BridgeInputs {
    picture_inputs_with([200, 40, 40], [40, 40, 200])
}

fn picture_inputs_with(left_rgb: [u8; 3], right_rgb: [u8; 3]) -> BridgeInputs {
    picture_inputs_for_frames(left_rgb, right_rgb, FRAMES)
}

fn picture_inputs_for_frames(left_rgb: [u8; 3], right_rgb: [u8; 3], frames: i64) -> BridgeInputs {
    let png = |rgb| {
        let image = image::RgbImage::from_pixel(768, 320, image::Rgb(rgb));
        let mut bytes = Vec::new();
        image
            .write_to(
                &mut std::io::Cursor::new(&mut bytes),
                image::ImageFormat::Png,
            )
            .unwrap();
        bytes
    };
    let template = inputs_for_frames(frames);
    let boundary = |rgb, side: &str, project_frame| {
        let png = png(rgb);
        conditioning::PreparedBoundary {
            picture: deadpan_models::BoundaryPicture::Original {
                clock: deadpan_models::BoundaryClock::Project {
                    frame: project_frame,
                },
                asset: deadpan_core::AssetId::new(format!("synthetic-{side}-png")).unwrap(),
                qualification: deadpan_core::SourceQualificationId::new(
                    conditioning::sha256(&png).unwrap().as_str().to_owned(),
                )
                .unwrap(),
                interpretation: None,
                picture: deadpan_models::DecodedBoundary {
                    source_frame: deadpan_core::SourceFrameId(0),
                    pts: deadpan_core::SourceTimestamp {
                        ticks: 0,
                        time_base: deadpan_core::SourceTimeBase::new(1, 24).unwrap(),
                    },
                    stream: deadpan_models::MeasuredStream {
                        codec: "png".into(),
                        pixel_format: "rgb24".into(),
                        width: 768,
                        height: 320,
                        clean_aperture: None,
                        sample_aspect: [1, 1],
                        rotation_quarter_turns: 0,
                        decoded_sample_bits: 8,
                        color: deadpan_models::CANONICAL_BRIDGE_COLOR,
                    },
                    model_input: deadpan_models::ModelInputConversion::SrgbCodesUnchanged,
                },
            },
            png,
            content_rect: Some(full_raster()),
        }
    };
    let left = boundary(left_rgb, "left", 14);
    let right = boundary(right_rgb, "right", 15 + frames);
    conditioning::assemble(
        template.plan,
        template.constraints,
        left,
        right,
        full_raster(),
    )
    .unwrap()
}

fn run_synthetic(
    store: &mut ProjectStore,
    allocated: &Allocated,
    worker: &synthetic::SyntheticWorker,
) -> Finished {
    let run = synthetic::run(
        allocated,
        worker,
        |_| {},
        |record| super::record(store, allocated, &record).map_err(|error| error.to_string()),
        &AtomicBool::new(false),
    );
    finish(store, allocated, run).unwrap()
}

/// Every attempt of one request is a seeded variant: each reaches Ready with
/// its own seed and pictures, the newest is selected, earlier ones stay
/// available, and a new request for the Hold makes them all stale.
#[test]
fn synthetic_variants_publish_distinct_ready_bundles_for_one_request() {
    let Some(worker) = synthetic_tools() else {
        eprintln!("skipped: needs ffmpeg with libx264rgb and a built deadpan-media-worker");
        return;
    };
    let directory = tempfile::tempdir().unwrap();
    let mut store = project(directory.path());
    let expected_revision = store.head_revision().unwrap();
    let first = allocate(
        &mut store,
        AllocateInput {
            hold: hold_id(),
            expected_revision,
            seed: 7,
            inputs: picture_inputs().into(),
        },
    )
    .unwrap();
    assert_eq!((first.ordinal(), first.provider().seed), (1, 7));
    let finished = run_synthetic(&mut store, &first, &worker);
    assert_eq!(finished.state, JobState::Ready, "{:?}", finished.failure);
    let first_receipt = finished.receipt.unwrap();
    let mut provenance_snapshot = store
        .generated_read_handle()
        .snapshot(
            first_receipt.provenance_object(),
            deadpan_store::generated_media::GeneratedReadLimits::new(
                first_receipt.provenance_object().byte_length(),
                Duration::from_secs(30),
            )
            .unwrap(),
            &AtomicBool::new(false),
        )
        .unwrap();
    let mut provenance_bytes = Vec::new();
    provenance_snapshot
        .read_to_end(&mut provenance_bytes)
        .unwrap();
    let stored = deadpan_models::StoredBridgeProvenance::from_bytes(
        &provenance_bytes,
        first_receipt.provenance_object(),
    )
    .unwrap();
    assert!(
        stored.quality().is_some(),
        "successful output uses schema 8"
    );
    assert!(
        stored.endpoints().is_some(),
        "successful output records both joins"
    );
    let geometry = stored
        .geometry()
        .expect("schema 8 retains native observations");
    assert_eq!(geometry.assessment().mouth.measured_tracks, 0);
    assert_eq!(geometry.assessment().geometry.measured_tracks, 0);
    assert_eq!(
        stored
            .region()
            .expect("explicit region evidence")
            .unavailable_reason(),
        Some("no selected region target")
    );

    let second =
        allocate_variant(&mut store, first.request.clone(), first.inputs().clone()).unwrap();
    assert_eq!(second.request.request_id, first.request.request_id);
    assert_eq!((second.ordinal(), second.provider().seed), (2, 8));
    let finished = run_synthetic(&mut store, &second, &worker);
    assert_eq!(finished.state, JobState::Ready, "{:?}", finished.failure);
    let second_receipt = finished.receipt.unwrap();
    assert_eq!(second_receipt.provider().seed, 8);
    assert_ne!(
        first_receipt.sampled_object(),
        second_receipt.sampled_object(),
        "each seed yields its own pictures"
    );
    let selected = store
        .selected_generation_bundle(&first.request.request_id)
        .unwrap()
        .unwrap();
    assert_eq!(selected.identity, second.identity);
    store
        .select_generation_bundle_variant(&first.identity)
        .unwrap();

    // Inputs from another context cannot extend this request.
    let mut changed = picture_inputs();
    changed.manifest_sha256 = deadpan_jobs::Sha256::new("f".repeat(64)).unwrap();
    assert!(allocate_variant(&mut store, first.request.clone(), changed.into()).is_err());

    let expected_revision = store.head_revision().unwrap();
    let replacement = allocate(
        &mut store,
        AllocateInput {
            hold: hold_id(),
            expected_revision,
            seed: 30,
            inputs: picture_inputs().into(),
        },
    )
    .unwrap();
    assert_eq!(state(&store, &replacement), JobState::Queued);
    assert!(
        store
            .selected_generation_bundle(&first.request.request_id)
            .unwrap()
            .is_none()
    );
    assert!(allocate_variant(&mut store, first.request.clone(), first.inputs().clone()).is_err());
}

#[test]
fn synthetic_middle_flash_fails_qualification_and_preserves_ready_fallback() {
    let Some(worker) = synthetic_tools() else {
        eprintln!("skipped: needs ffmpeg with libx264rgb and a built deadpan-media-worker");
        return;
    };
    let directory = tempfile::tempdir().unwrap();
    let mut store = project(directory.path());
    let fallback_document = store.snapshot().unwrap();
    let fallback_revision = store.head_revision().unwrap();
    let matching_inputs = picture_inputs_with([80, 80, 80], [80, 80, 80]);
    assert_eq!(matching_inputs.left_png, matching_inputs.right_png);
    let first = allocate(
        &mut store,
        AllocateInput {
            hold: hold_id(),
            expected_revision: fallback_revision.clone(),
            seed: 7,
            inputs: matching_inputs.into(),
        },
    )
    .unwrap();
    let ready = run_synthetic(&mut store, &first, &worker);
    assert_eq!(ready.state, JobState::Ready, "{:?}", ready.failure);
    let selected_before = store
        .selected_generation_bundle(&first.request.request_id)
        .unwrap()
        .expect("the successful first attempt is selected");
    assert_eq!(selected_before.identity, first.identity);

    let flash =
        allocate_variant(&mut store, first.request.clone(), first.inputs().clone()).unwrap();
    let expected_flash_frame = native_frame_count(&flash.inputs().plan()) / 2;
    let run = synthetic::run_with_mode(
        &flash,
        &worker,
        |_| {},
        |record| super::record(&mut store, &flash, &record).map_err(|error| error.to_string()),
        &AtomicBool::new(false),
        synthetic::SyntheticMode::LightingFlash,
    );
    let RunResult::Failed(JobFailure::Host(failure)) = &run.result else {
        panic!("a one-frame full-picture flash must fail host qualification");
    };
    assert_eq!(failure.code, HostFailureCode::OutputValidationFailed);
    assert!(
        failure.detail.as_str().contains(&format!(
            "abrupt lighting at native frame {expected_flash_frame}"
        )),
        "{}",
        failure.detail.as_str()
    );
    let rejected_failure = failure.clone();

    let finished = finish(&mut store, &flash, run).unwrap();
    assert_eq!(finished.state, JobState::Failed);
    assert!(finished.receipt.is_none());
    let failed_attempt = store.generation_attempt(&flash.identity).unwrap().unwrap();
    assert_eq!(failed_attempt.checkpoint.state, JobState::Failed);
    assert_eq!(
        failed_attempt.checkpoint.failure,
        Some(JobFailure::Host(rejected_failure))
    );
    assert!(failed_attempt.bundle_receipt.is_none());
    assert_eq!(store.head_revision().unwrap(), fallback_revision);
    assert_eq!(store.snapshot().unwrap(), fallback_document);
    assert_eq!(
        store
            .selected_generation_bundle(&first.request.request_id)
            .unwrap(),
        Some(selected_before)
    );
    store.validate_full().unwrap();
}

#[test]
fn missing_landmark_helper_fails_without_replacing_ready_or_fallback() {
    let Some(mut worker) = synthetic_tools() else {
        eprintln!("skipped: needs ffmpeg and built media/landmark workers");
        return;
    };
    let directory = tempfile::tempdir().unwrap();
    let mut store = project(directory.path());
    let fallback = store.snapshot().unwrap();
    let revision = store.head_revision().unwrap();
    let first = allocate(
        &mut store,
        AllocateInput {
            hold: hold_id(),
            expected_revision: revision.clone(),
            seed: 7,
            inputs: picture_inputs().into(),
        },
    )
    .unwrap();
    let ready = run_synthetic(&mut store, &first, &worker);
    assert_eq!(ready.state, JobState::Ready, "{:?}", ready.failure);
    let selected = store
        .selected_generation_bundle(&first.request.request_id)
        .unwrap();
    let second =
        allocate_variant(&mut store, first.request.clone(), first.inputs().clone()).unwrap();
    worker.landmark_worker = directory.path().join("missing-landmark-worker");
    let finished = run_synthetic(&mut store, &second, &worker);
    assert_eq!(finished.state, JobState::Failed);
    let Some(JobFailure::Host(failure)) = finished.failure else {
        panic!("missing helper must fail host qualification");
    };
    assert_eq!(failure.code, HostFailureCode::OutputValidationFailed);
    assert!(failure.detail.as_str().contains("landmark"), "{failure:?}");
    assert!(finished.receipt.is_none());
    assert_eq!(store.head_revision().unwrap(), revision);
    assert_eq!(store.snapshot().unwrap(), fallback);
    assert_eq!(
        store
            .selected_generation_bundle(&first.request.request_id)
            .unwrap(),
        selected
    );
    assert!(
        store
            .generation_attempt(&second.identity)
            .unwrap()
            .unwrap()
            .bundle_receipt
            .is_none()
    );
    store.validate_full().unwrap();
}

fn endpoint_rejection_preserves_ready(
    worker: &synthetic::SyntheticWorker,
    left: [u8; 3],
    right: [u8; 3],
    generated: [u8; 3],
    expected_side: &str,
    frames: i64,
) {
    let directory = tempfile::tempdir().unwrap();
    let mut store = project_with_frames(directory.path(), frames);
    let fallback_document = store.snapshot().unwrap();
    let fallback_revision = store.head_revision().unwrap();
    let first = allocate(
        &mut store,
        AllocateInput {
            hold: hold_id(),
            expected_revision: fallback_revision.clone(),
            seed: 7,
            inputs: picture_inputs_for_frames(left, right, frames).into(),
        },
    )
    .unwrap();
    let ready = run_synthetic(&mut store, &first, worker);
    assert_eq!(ready.state, JobState::Ready, "{:?}", ready.failure);
    let receipt = ready.receipt.unwrap();
    let selected = store
        .selected_generation_bundle(&first.request.request_id)
        .unwrap()
        .unwrap();
    assert_eq!(selected.identity, first.identity);
    if frames == 1 {
        let mut snapshot = store
            .generated_read_handle()
            .snapshot(
                receipt.provenance_object(),
                deadpan_store::generated_media::GeneratedReadLimits::new(
                    receipt.provenance_object().byte_length(),
                    Duration::from_secs(30),
                )
                .unwrap(),
                &AtomicBool::new(false),
            )
            .unwrap();
        let mut bytes = Vec::new();
        snapshot.read_to_end(&mut bytes).unwrap();
        let provenance =
            deadpan_models::StoredBridgeProvenance::from_bytes(&bytes, receipt.provenance_object())
                .unwrap();
        let endpoints = provenance.endpoints().unwrap();
        assert_eq!(
            (
                endpoints.entry().sampled_frame,
                endpoints.exit().sampled_frame
            ),
            (0, 0)
        );
        assert_eq!(
            (endpoints.entry().sampled_pts, endpoints.exit().sampled_pts),
            (0, 0)
        );
    }

    let bad = allocate_variant(&mut store, first.request.clone(), first.inputs().clone()).unwrap();
    let run = synthetic::run_with_mode(
        &bad,
        worker,
        |_| {},
        |record| super::record(&mut store, &bad, &record).map_err(|error| error.to_string()),
        &AtomicBool::new(false),
        synthetic::SyntheticMode::Uniform(generated),
    );
    let RunResult::Failed(JobFailure::Host(failure)) = &run.result else {
        panic!("uniform wrong pictures must fail the actual edit join");
    };
    assert_eq!(failure.code, HostFailureCode::OutputValidationFailed);
    // Every native picture is identical: pair motion/lighting cannot reveal
    // the wrong scene. Qualification reaches the separate endpoint guard.
    assert!(
        failure.detail.as_str().contains(&format!(
            "deadpan-endpoints-1: gross {expected_side} discontinuity"
        )),
        "{}",
        failure.detail.as_str()
    );
    let failed = failure.clone();
    let finished = finish(&mut store, &bad, run).unwrap();
    assert_eq!(finished.state, JobState::Failed);
    assert!(finished.receipt.is_none());
    let attempt = store.generation_attempt(&bad.identity).unwrap().unwrap();
    assert_eq!(attempt.checkpoint.state, JobState::Failed);
    assert_eq!(attempt.checkpoint.failure, Some(JobFailure::Host(failed)));
    assert!(attempt.bundle_receipt.is_none());
    assert_eq!(store.head_revision().unwrap(), fallback_revision);
    assert_eq!(store.snapshot().unwrap(), fallback_document);
    assert_eq!(
        store
            .selected_generation_bundle(&first.request.request_id)
            .unwrap(),
        Some(selected)
    );
    store.validate_full().unwrap();
}

#[test]
fn synthetic_wrong_uniform_endpoints_preserve_ready_and_fallback() {
    let Some(worker) = synthetic_tools() else {
        eprintln!("skipped: needs ffmpeg with libx264rgb and a built deadpan-media-worker");
        return;
    };
    endpoint_rejection_preserves_ready(&worker, [80; 3], [80; 3], [240; 3], "entry", FRAMES);
}

#[test]
fn synthetic_entry_and_exit_mismatches_are_checked_independently() {
    let Some(worker) = synthetic_tools() else {
        eprintln!("skipped: needs ffmpeg with libx264rgb and a built deadpan-media-worker");
        return;
    };
    endpoint_rejection_preserves_ready(&worker, [80; 3], [240; 3], [240; 3], "entry", FRAMES);
    endpoint_rejection_preserves_ready(&worker, [240; 3], [80; 3], [240; 3], "exit", FRAMES);
}

#[test]
fn synthetic_one_frame_hold_measures_both_joins_at_the_same_sample() {
    let Some(worker) = synthetic_tools() else {
        eprintln!("skipped: needs ffmpeg with libx264rgb and a built deadpan-media-worker");
        return;
    };
    endpoint_rejection_preserves_ready(&worker, [80; 3], [80; 3], [240; 3], "entry", 1);
}

// Hostile AI pause workers through the real attempt host
// (docs/ADVERSARIAL.md#hostile-workers). The trusted `python` and
// `worker_script` seam runs a hostile fixture instead of the bridge worker.

#[path = "../../../tests/hostile_workers/support.rs"]
mod hostile;

/// What one hostile attempt concluded, captured before `finish` consumes it.
struct HostileOutcome {
    record: hostile::Record,
    failure: Option<HostFailure>,
    cancelled: bool,
    qualified: bool,
    log_bytes: usize,
    discarded_bytes: u64,
    state: JobState,
    elapsed: Duration,
}

/// Run one hostile attempt through `run_worker`, record it as the app does,
/// and finish it durably.
fn hostile_attempt(name: &str, cancel_after: Option<Duration>) -> HostileOutcome {
    let directory = tempfile::tempdir().unwrap();
    let mut store = project(directory.path());
    let allocated = allocated(&mut store);
    let record = hostile::Record::new();
    let runtime = BridgeRuntime {
        python: hostile::python(),
        worker_script: record.wrapper(&hostile::fixture("analysis.py"), name),
        ..runtime(directory.path(), "/usr/bin/false")
    };
    let cancelled = AtomicBool::new(false);
    let mut records = Vec::new();
    let started = Instant::now();
    let run = thread::scope(|scope| {
        if let Some(delay) = cancel_after {
            let cancelled = &cancelled;
            scope.spawn(move || {
                thread::sleep(delay);
                cancelled.store(true, Ordering::Release);
            });
        }
        run_worker(
            &allocated,
            &runtime,
            |_| {},
            |record| {
                records.push(record);
                Ok(())
            },
            &cancelled,
        )
    });
    let elapsed = started.elapsed();
    for entry in &records {
        super::record(&mut store, &allocated, entry).unwrap();
    }
    let failure = match &run.result {
        RunResult::Failed(JobFailure::Host(failure)) => Some(failure.clone()),
        _ => None,
    };
    let cancelled = matches!(run.result, RunResult::Cancelled);
    let qualified = matches!(run.result, RunResult::Qualified(_));
    let (log_bytes, discarded_bytes) = (run.worker_log.len(), run.worker_log_discarded_bytes);
    let finished = finish(&mut store, &allocated, run).unwrap();
    assert_eq!(state(&store, &allocated), finished.state);
    HostileOutcome {
        record,
        failure,
        cancelled,
        qualified,
        log_bytes,
        discarded_bytes,
        state: finished.state,
        elapsed,
    }
}

#[test]
fn hostile_ai_provenance_claims_fail_before_media_qualification() {
    for name in [
        "symlink_outside",
        "hardlink_outside",
        "symlinked_scope",
        "fifo",
        "sparse",
        "directory",
    ] {
        let outcome = hostile_attempt(name, None);
        assert!(outcome.elapsed < Duration::from_secs(10), "{name}");
        let failure = outcome.failure.expect("artifact claim must fail");
        assert_eq!(
            failure.code,
            HostFailureCode::OutputValidationFailed,
            "{name}: {failure:?}"
        );
        assert!(
            failure.detail.as_str().contains("artifact"),
            "{name}: {failure:?}"
        );
        assert_eq!(outcome.state, JobState::Failed);
        assert!(!outcome.qualified);
        assert_eq!(
            std::fs::read(outcome.record.path().join("outside.bin")).unwrap(),
            b"{}"
        );
        outcome.record.assert_group_gone();
    }
    for name in ["absolute", "parent"] {
        let outcome = hostile_attempt(name, None);
        let failure = outcome.failure.expect("unsafe reference must fail");
        assert!(
            matches!(
                failure.code,
                HostFailureCode::WorkerExited | HostFailureCode::ProtocolViolation
            ),
            "{name}: {failure:?}"
        );
        assert!(
            !failure.detail.as_str().contains("exited"),
            "{name}: {failure:?}"
        );
        assert_eq!(outcome.state, JobState::Failed);
        assert!(!outcome.qualified);
        outcome.record.assert_group_gone();
    }
}

#[test]
fn hostile_ai_workers_fail_truthfully_and_leave_no_group_member() {
    for name in [
        "malformed",
        "invalid_utf8",
        "zero_length",
        "truncated",
        "oversized",
        "just_over",
        "wrong_attempt",
        "fork_spam_exit",
        "stderr_flood",
    ] {
        let outcome = hostile_attempt(name, None);
        assert!(
            outcome.elapsed < Duration::from_secs(20),
            "{name}: {:?}",
            outcome.elapsed
        );
        assert!(!outcome.qualified, "{name}");
        let failure = outcome
            .failure
            .unwrap_or_else(|| panic!("{name}: expected a host failure"));
        assert!(
            matches!(
                failure.code,
                HostFailureCode::WorkerExited | HostFailureCode::ProtocolViolation
            ),
            "{name}: {failure:?}"
        );
        hostile::assert_generic_cause(name, failure.detail.as_str());
        if name == "wrong_attempt" {
            assert!(!failure.detail.as_str().contains("exited"), "{failure:?}");
        }
        assert_eq!(outcome.state, JobState::Failed, "{name}");
        outcome.record.assert_group_gone();
        if name == "stderr_flood" {
            // The retained diagnostic is the bounded tail; the rest is counted.
            assert_eq!(outcome.log_bytes, 64 * 1024);
            assert_eq!(outcome.discarded_bytes, 16 * 1024 * 1024 - 64 * 1024);
        }
    }
}

#[test]
fn stalled_and_forking_ai_workers_are_stopped_by_cancellation() {
    // The attempt deadline is thirty minutes; cancellation is how a person
    // stops a dribbling or forking worker that ignores the cooperative cancel.
    for name in ["slow_loris", "fork_spam"] {
        let outcome = hostile_attempt(name, Some(Duration::from_millis(300)));
        assert!(
            outcome.elapsed < Duration::from_secs(20),
            "{name}: {:?}",
            outcome.elapsed
        );
        assert!(outcome.cancelled, "{name}: {:?}", outcome.failure);
        assert_eq!(outcome.state, JobState::Cancelled, "{name}");
        outcome.record.assert_group_gone();
    }
}

#[test]
fn an_escaped_ai_worker_descendant_fails_the_attempt_and_is_not_contained() {
    let outcome = hostile_attempt("escape", None);
    assert!(
        outcome.elapsed < Duration::from_secs(25),
        "{:?}",
        outcome.elapsed
    );
    let failure = outcome.failure.expect("expected a host failure");
    assert!(
        failure.detail.as_str().contains("pipes stayed open"),
        "{failure:?}"
    );
    assert_eq!(outcome.state, JobState::Failed);
    outcome.record.assert_group_gone();
    hostile::assert_alive(outcome.record.escaped(Duration::from_secs(5)));
}
