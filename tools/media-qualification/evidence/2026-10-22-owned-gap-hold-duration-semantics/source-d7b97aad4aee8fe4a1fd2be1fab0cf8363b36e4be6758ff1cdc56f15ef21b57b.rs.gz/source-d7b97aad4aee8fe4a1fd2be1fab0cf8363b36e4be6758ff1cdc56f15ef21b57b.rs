//! Headless application boundary, shared with the native host.

#[cfg(any(target_os = "macos", target_os = "linux"))]
pub mod activity;
#[cfg(all(test, any(target_os = "macos", target_os = "linux")))]
mod adversarial;
#[cfg(any(target_os = "macos", target_os = "linux"))]
pub mod audio;
#[cfg(any(target_os = "macos", target_os = "linux"))]
pub mod backup_settings;
#[cfg(any(target_os = "macos", target_os = "linux"))]
mod backups;
pub mod bundle;
#[cfg(any(target_os = "macos", target_os = "linux"))]
pub mod corrections;
#[cfg(any(target_os = "macos", target_os = "linux"))]
pub mod diagnostic_export;
mod doctor;
#[cfg(any(target_os = "macos", target_os = "linux"))]
pub mod dry_run;
#[cfg(any(target_os = "macos", target_os = "linux"))]
pub mod encoded_render;
#[cfg(any(target_os = "macos", target_os = "linux"))]
pub mod export_picture;
#[cfg(target_os = "macos")]
pub mod export_verification;
#[cfg(any(target_os = "macos", target_os = "linux"))]
pub mod faces;
#[cfg(any(target_os = "macos", target_os = "linux"))]
mod framing;
#[cfg(any(target_os = "macos", target_os = "linux"))]
pub mod gags;
pub mod generation;
pub mod generation_context;
#[cfg(any(target_os = "macos", target_os = "linux"))]
pub mod host;
#[cfg(any(target_os = "macos", target_os = "linux"))]
pub mod live_project;
#[cfg(any(target_os = "macos", target_os = "linux"))]
pub mod macros;
#[cfg(any(target_os = "macos", target_os = "linux"))]
pub mod models;
#[cfg(any(target_os = "macos", target_os = "linux"))]
mod originals;
pub mod pause;
#[cfg(any(target_os = "macos", target_os = "linux"))]
pub mod picture;
#[cfg(any(target_os = "macos", target_os = "linux"))]
pub mod proxy;
#[cfg(any(target_os = "macos", target_os = "linux"))]
pub mod render;
#[cfg(any(target_os = "macos", target_os = "linux"))]
pub mod render_worker;
#[cfg(any(target_os = "macos", target_os = "linux"))]
pub mod shots;
#[cfg(any(target_os = "macos", target_os = "linux"))]
pub mod single_original;
#[cfg(any(target_os = "macos", target_os = "linux"))]
pub mod sound_events;
#[cfg(any(target_os = "macos", target_os = "linux"))]
mod source_registration;
pub mod speech;
#[cfg(any(target_os = "macos", target_os = "linux"))]
pub mod storage;
pub mod system_conditions;
#[cfg(any(target_os = "macos", target_os = "linux"))]
mod takes;
#[cfg(any(target_os = "macos", target_os = "linux"))]
pub mod tracking;
#[cfg(any(target_os = "macos", target_os = "linux"))]
pub mod transcription;
#[cfg(any(target_os = "macos", target_os = "linux"))]
pub mod update_signing;
pub mod youtube;

use std::fs::File;
use std::io::{self, Read, Write};
use std::path::Path;
use std::process::ExitCode;

use deadpan_core::{
    ColorPolicy, Command, CommandRequest, FrameRate, NodeId, PresentationBasis, ProjectDocument,
    ProjectId, RevisionId,
};
use deadpan_store::{AccessMode, ProjectStore, StoreError};
use serde::{Deserialize, Serialize};

const HELP: &str = "Deadpan headless commands:
  doctor
  doctor --project <project.deadpan>   (macOS/Linux)
  diagnostics export <new-report.json> [--project <project.deadpan>]
  project create <project.deadpan> [--fps <N/D> --size <WIDTHxHEIGHT>]
  project create-original <project.deadpan> <absolute-video> [--linked]
  project create-from-url <project.deadpan> <https-youtube-url> [--cookies <file>] [--helpers <dir>]
  project validate <project.deadpan> [--quick]
  project dump <project.deadpan> --json
  project undo <project.deadpan> --expected <revision> [--dry-run]
  project redo <project.deadpan> --expected <revision> [--dry-run]
  project takes <project.deadpan>
  project take <project.deadpan> --json <request.json> [--dry-run]
  project checkpoint <project.deadpan>
  project migrate <project.deadpan>
  project view <project.deadpan>
  project backups <project.deadpan> [--verify]
  project backup <project.deadpan>
  backup-policy show | set --interval-minutes <1-1440> --max-count <8-256> --budget-mib <256-65536> | reset
  project restore <project.deadpan> <backup-id> [--expected <revision>] [--dry-run]
  project restore <project.deadpan> <backup-id> --damaged [--force-project <id>]
  project storage <project.deadpan> [--clean [--files-only] [--dry-run]] [--grace-hours N]
  project storage <project.deadpan> --confirm-clock [--dry-run]
  project copy-portable <project.deadpan> <new-copy.deadpan>
  cache status [--grace-hours N]
  cache clean [--dry-run] [--grace-hours N]
  project retain-original <project.deadpan> <absolute-source> [--linked]
  project register-source <project.deadpan> --request-json <request.json> [--dry-run]
  project insert-original <project.deadpan> --parent <node-id> --index <N> --expected <revision> [--dry-run]
  project adopt-primary-geometry <project.deadpan> --request-json <request.json> [--dry-run]
  project originals <project.deadpan> [--after <blake3-digest>]
  project original-provenance <project.deadpan> <blake3-digest>
  project verify-original <project.deadpan> <blake3-digest>
  project relink-original <project.deadpan> <blake3-digest> <absolute-source> --expected-version <N>
  project relink-moved <project.deadpan>
  inspect-plan <project.deadpan> [--frame <N>]
  inspect-plan <project.deadpan> --audio-samples <START> <END>
  inspect-audio <project.deadpan> --samples <START> <END> [--time-mapped | --edge-faded | --authored-bus | --limited]
  inspect-audio-domain <project.deadpan> --at <PROBE> --samples <START> <END>
  inspect-audio-definition <project.deadpan> (--node <ID> | --repeat-default <ID> | --repeat-gap <ID>) --samples <START> <END> [--revision <ID>]
  inspect-audio-placement <project.deadpan> (--node <ID> | --repeat-default <ID> | --repeat-gap <ID>) --clock <clock.json> --samples <START> <END> [--revision <ID>]
  resolve-selection <project.deadpan> --json <selection.json>
  locate-boundary <project.deadpan> --json <boundary.json>
  command <project.deadpan> --json <request.json> [--dry-run]
  macro inspect <project.deadpan> [--register a]
  macro <project.deadpan> --json <request.json> [--dry-run]
  sound <project.deadpan> --json <request.json> [--dry-run]
  sound --write-sting <new.wav>
  gag-inspect <project.deadpan> --json <recipe.json> [--visual]
  render <project.deadpan> --output <directory> [--name <movie.mp4>] [--expected <revision>]
  render <project.deadpan> --json <request.json>
  verify-export <project.deadpan> --movie <movie.mp4> [--revision <id>] [--frames <N,N,...> | --every <N>] [--samples <START:END,...> | --no-audio] [--report <new.json>]
  render retry <project.deadpan> --job <job> --checkpoint <encoding-attempt> --output <directory> [--name <movie.mp4>]
  render reencode <project.deadpan> --job <job> --output <directory> [--name <movie.mp4>]
  render reconcile <project.deadpan> --publication <publication>
  render status <project.deadpan> [--after <job>]
  render status <project.deadpan> --job <job> [--after-attempt <ordinal>]
  render status <project.deadpan> --publications [--after <publication>]
  render status <project.deadpan> --publication <publication>
  downloader install [--root <dir>]
  downloader status [--root <dir>] [--probe]
  models list [--root <dir>]
  models license <pack>
  models install <pack> [--accept-license] [--root <dir>]
  models import <pack> <folder-or-archive.tar> [--accept-license] [--root <dir>]
  models export <pack> <archive.tar> [--root <dir>]
  models remove <pack> [--partial] [--root <dir>]
  transcribe <project.deadpan> [--model <ggml.bin> --sha256 <hex>] [--vad-model <ggml-silero.bin> --vad-sha256 <hex>] [--language <auto|xx>] [--asset <id>] [--again <start_cs>:<end_cs>]
  transcript <project.deadpan> [--search <words>] [--asset <id>]
  corrections <project.deadpan> [--asset <id>]
  corrections <project.deadpan> --json <request.json> [--dry-run]
  pauses <project.deadpan> [--asset <id>]
  detect-shots <project.deadpan> [--asset <id>] [--decode-threads <1-16>]
  shots <project.deadpan> [--asset <id>]
  track <project.deadpan> --from <pts> --to <pts> --region <x,y,w,h> [--asset <id>] [--stride <n>] [--through-shots] [--save <target-id> [--label <text>] [--replace]]
  track-correct <project.deadpan> --target <id> --at <pts> --region <x,y,w,h> [--stride <n>]
  detect-faces <project.deadpan> --at <pts> [--asset <id>]
  generate-hold <project.deadpan> --hold <node-id> [--seed N] [--variants 1-4] [--another]
  accept-hold <project.deadpan> --request <request-id> [--attempt <attempt-id>]
  ai-variants <project.deadpan> [--hold <node-id>] [--joins]
  ai-replacements <project.deadpan> [--after <id> | --id <id> | --retry <id> --expected <revision> | --discard <id> --sequence <n> | --run [--limit 1-16]]
  select-hold <project.deadpan> --request <request-id> --attempt <attempt-id>
  discard-hold <project.deadpan> --request <request-id> --attempt <attempt-id>
  keep-hold <project.deadpan> --request <request-id> --attempt <attempt-id> [--off]
  dismiss-attempt <project.deadpan> --request <request-id> --attempt <attempt-id>

Generic project creation defaults to a provisional 1920x1080, 30 fps presentation basis.
Document dumps are inspection output; SQLite remains authoritative.
Rendering uses automatic project policy and emits bounded JSON lines on qualified macOS/APFS. An open app owns Render through its authenticated endpoint; otherwise the CLI owns it. SIGINT/SIGTERM requests cancellation and drain.
Original retention preserves complete bytes; stream qualification and authored import remain separate.
While Deadpan.app has the project open, writes (command, macro, sound, corrections, undo/redo, register-source, insert-original, the AI hold commands, storage cleanup and restore) run through its live endpoint and refresh the app.
create-original and create-from-url make a new one-Original project with its full-source baseline.
create-from-url uses the pinned yt-dlp/Deno helpers bundled in Deadpan.app, else from `downloader install` (docs/YOUTUBE_IMPORT.md);
cookies come only from an explicit file. You are responsible for having the rights to use imported videos.
Audio inspection returns at most 256 stereo samples at the explicitly selected processing stage.
Domain inspection reads raw physical context; signed START/END use its captured root grid.
Definition inspection reads a local-zero point grid, not final timeline allocation.
Offered AI variants that are neither kept (keep-hold), chosen nor accepted expire 7 days after they became Ready; project storage --clean applies that first.
AI pauses use Deadpan.app's bundled runtime and the installed ltx-2.3-q4-bridge model pack (development builds: DEADPAN_BRIDGE_* variables; docs/AI_HOLDS.md); generation proposes pictures and only accept-hold edits the project.
Placement inspection evaluates the selected revision's recipe on an explicit signed root clock.";

#[derive(Debug, thiserror::Error)]
pub enum CliError {
    #[cfg(any(target_os = "macos", target_os = "linux"))]
    #[error("{0}")]
    LiveProject(#[from] live_project::LiveError),
    #[cfg(any(target_os = "macos", target_os = "linux"))]
    #[error(transparent)]
    DiagnosticExport(#[from] diagnostic_export::ExportError),
    #[cfg(any(target_os = "macos", target_os = "linux"))]
    #[error("{0}")]
    Render(#[from] render::PublicRenderError),
    #[error("{0}")]
    Usage(String),
    #[error(transparent)]
    Import(#[from] youtube::ImportError),
    #[error("Unsupported command protocol {0}; expected 1")]
    Protocol(u32),
    #[error("{0}")]
    Store(#[from] StoreError),
    #[cfg(any(target_os = "macos", target_os = "linux"))]
    #[error(transparent)]
    Backup(#[from] deadpan_store::backups::BackupError),
    #[cfg(any(target_os = "macos", target_os = "linux"))]
    #[error(transparent)]
    BackupSettings(#[from] backup_settings::SettingsError),
    #[error(transparent)]
    Document(#[from] deadpan_core::DocumentError),
    #[error(transparent)]
    Timing(#[from] deadpan_core::TimeError),
    #[error(transparent)]
    Plan(#[from] deadpan_plan::PlanError),
    #[error(transparent)]
    Anchor(#[from] deadpan_core::AnchorError),
    #[error(transparent)]
    Json(#[from] serde_json::Error),
    #[error(transparent)]
    Io(#[from] std::io::Error),
    #[cfg(any(target_os = "macos", target_os = "linux"))]
    #[error(transparent)]
    SourceInput(#[from] deadpan_media::source_input::SourceInputError),
    #[cfg(any(target_os = "macos", target_os = "linux"))]
    #[error(transparent)]
    SourceVideo(#[from] deadpan_media::source_session::SourceSessionError),
    #[cfg(any(target_os = "macos", target_os = "linux"))]
    #[error(transparent)]
    SourceAudio(#[from] deadpan_media::audio_session::AudioSessionError),
    #[cfg(any(target_os = "macos", target_os = "linux"))]
    #[error(transparent)]
    ProjectAudio(#[from] audio::ProjectAudioError),
    #[cfg(any(target_os = "macos", target_os = "linux"))]
    #[error(transparent)]
    Transcription(#[from] transcription::TranscriptionError),
    #[cfg(any(target_os = "macos", target_os = "linux"))]
    #[error(transparent)]
    ModelPack(#[from] deadpan_models::packs::PackError),
    #[cfg(any(target_os = "macos", target_os = "linux"))]
    #[error(transparent)]
    Shots(#[from] shots::ShotScanError),
    #[cfg(any(target_os = "macos", target_os = "linux"))]
    #[error(transparent)]
    Tracking(#[from] tracking::TrackingError),
    #[cfg(any(target_os = "macos", target_os = "linux"))]
    #[error(transparent)]
    Faces(#[from] faces::FaceError),
    #[cfg(any(target_os = "macos", target_os = "linux"))]
    #[error(transparent)]
    Generation(#[from] generation::attempt::GenerationError),
    #[cfg(target_os = "macos")]
    #[error(transparent)]
    ExportVerification(#[from] export_verification::VerifyError),
}

impl CliError {
    fn code(&self) -> &str {
        match self {
            #[cfg(any(target_os = "macos", target_os = "linux"))]
            Self::LiveProject(error) => &error.code,
            #[cfg(any(target_os = "macos", target_os = "linux"))]
            Self::DiagnosticExport(error) => error.code(),
            #[cfg(any(target_os = "macos", target_os = "linux"))]
            Self::Render(error) => &error.code,
            Self::Usage(_) | Self::Timing(_) | Self::Json(_) => "InvalidInput",
            Self::Import(error) => error.code,
            Self::Protocol(_) => "ProtocolUnsupported",
            Self::Document(_) => "ProjectInvalid",
            Self::Plan(deadpan_plan::PlanError::FrameOutOfRange { .. }) => "FrameOutOfRange",
            Self::Plan(deadpan_plan::PlanError::AudioRangeOutOfRange) => "AudioRangeOutOfRange",
            Self::Plan(deadpan_plan::PlanError::AudioQueryLimit(_)) => "AudioQueryLimit",
            Self::Plan(deadpan_plan::PlanError::InvalidAudioDefinitionSelector(_)) => {
                "AudioDefinitionUnavailable"
            }
            Self::Plan(deadpan_plan::PlanError::InvalidAudioRootPlacement(_)) => {
                "AudioPlacementUnavailable"
            }
            Self::Plan(deadpan_plan::PlanError::Time(_)) => "TimingOverflow",
            Self::Plan(_) => "PlanInvalid",
            Self::Anchor(error) => error.code(),
            Self::Io(_) => "IoFailure",
            Self::Store(error) => error.code(),
            #[cfg(any(target_os = "macos", target_os = "linux"))]
            Self::Backup(error) => error.code(),
            #[cfg(any(target_os = "macos", target_os = "linux"))]
            Self::BackupSettings(_) => "BackupSettingsFailed",
            #[cfg(any(target_os = "macos", target_os = "linux"))]
            Self::SourceInput(_) => "SourceSnapshotFailed",
            #[cfg(any(target_os = "macos", target_os = "linux"))]
            Self::SourceVideo(_) => "SourceVideoDecodeFailed",
            #[cfg(any(target_os = "macos", target_os = "linux"))]
            Self::SourceAudio(_) => "SourceAudioDecodeFailed",
            #[cfg(any(target_os = "macos", target_os = "linux"))]
            Self::Transcription(transcription::TranscriptionError::Cancelled) => {
                "TranscriptionCancelled"
            }
            #[cfg(any(target_os = "macos", target_os = "linux"))]
            Self::Transcription(transcription::TranscriptionError::Configuration(_)) => {
                "TranscriptionUnavailable"
            }
            #[cfg(any(target_os = "macos", target_os = "linux"))]
            Self::Transcription(_) => "TranscriptionFailed",
            #[cfg(any(target_os = "macos", target_os = "linux"))]
            Self::ModelPack(deadpan_models::packs::PackError::Cancelled) => "ModelPackCancelled",
            #[cfg(any(target_os = "macos", target_os = "linux"))]
            Self::ModelPack(deadpan_models::packs::PackError::Busy) => "ModelPackBusy",
            #[cfg(any(target_os = "macos", target_os = "linux"))]
            Self::ModelPack(deadpan_models::packs::PackError::Space { .. }) => "ModelPackSpace",
            #[cfg(any(target_os = "macos", target_os = "linux"))]
            Self::ModelPack(deadpan_models::packs::PackError::LicenseNotAccepted { .. }) => {
                "ModelPackLicense"
            }
            #[cfg(any(target_os = "macos", target_os = "linux"))]
            Self::ModelPack(
                deadpan_models::packs::PackError::ImportIncomplete { .. }
                | deadpan_models::packs::PackError::Verification { .. },
            ) => "ModelPackVerification",
            #[cfg(any(target_os = "macos", target_os = "linux"))]
            Self::ModelPack(deadpan_models::packs::PackError::Update { code, .. }) => code,
            // A download the volume refused part way, as opposed to the
            // up-front space check (`ModelPackSpace`).
            #[cfg(any(target_os = "macos", target_os = "linux"))]
            Self::ModelPack(deadpan_models::packs::PackError::Io(error))
                if matches!(
                    error.kind(),
                    std::io::ErrorKind::StorageFull | std::io::ErrorKind::QuotaExceeded
                ) =>
            {
                "DiskFull"
            }
            #[cfg(any(target_os = "macos", target_os = "linux"))]
            Self::ModelPack(_) => "ModelPackFailed",
            #[cfg(any(target_os = "macos", target_os = "linux"))]
            Self::Shots(shots::ShotScanError::Cancelled) => "ShotDetectionCancelled",
            #[cfg(any(target_os = "macos", target_os = "linux"))]
            Self::Shots(shots::ShotScanError::Unavailable(_)) => "ShotDetectionUnavailable",
            #[cfg(any(target_os = "macos", target_os = "linux"))]
            Self::Shots(_) => "ShotDetectionFailed",
            #[cfg(any(target_os = "macos", target_os = "linux"))]
            Self::Tracking(tracking::TrackingError::Cancelled) => "TrackingCancelled",
            #[cfg(any(target_os = "macos", target_os = "linux"))]
            Self::Tracking(tracking::TrackingError::Request(_)) => "InvalidInput",
            #[cfg(any(target_os = "macos", target_os = "linux"))]
            Self::Tracking(tracking::TrackingError::Unavailable(_)) => "TrackingUnavailable",
            #[cfg(any(target_os = "macos", target_os = "linux"))]
            Self::Tracking(_) => "TrackingFailed",
            #[cfg(any(target_os = "macos", target_os = "linux"))]
            Self::Faces(faces::FaceError::Cancelled) => "FaceDetectionCancelled",
            #[cfg(any(target_os = "macos", target_os = "linux"))]
            Self::Faces(faces::FaceError::Request(_)) => "InvalidInput",
            #[cfg(any(target_os = "macos", target_os = "linux"))]
            Self::Faces(faces::FaceError::Unavailable(_)) => "FaceDetectionUnavailable",
            #[cfg(any(target_os = "macos", target_os = "linux"))]
            Self::Faces(_) => "FaceDetectionFailed",
            #[cfg(any(target_os = "macos", target_os = "linux"))]
            Self::Generation(error) => error.code(),
            #[cfg(target_os = "macos")]
            Self::ExportVerification(error) => error.code(),
            #[cfg(any(target_os = "macos", target_os = "linux"))]
            Self::ProjectAudio(error) => match error {
                audio::ProjectAudioError::Store(error) => error.code(),
                audio::ProjectAudioError::Sequence(deadpan_audio::SequenceAudioError::Range) => {
                    "AudioRangeOutOfRange"
                }
                audio::ProjectAudioError::Stage(deadpan_audio::StageAudioError::Range)
                | audio::ProjectAudioError::Stage(deadpan_audio::StageAudioError::Plan(
                    deadpan_plan::PlanError::AudioRangeOutOfRange,
                ))
                | audio::ProjectAudioError::Plan(deadpan_plan::PlanError::AudioRangeOutOfRange) => {
                    "AudioRangeOutOfRange"
                }
                audio::ProjectAudioError::Stage(deadpan_audio::StageAudioError::ForeignDomain) => {
                    "AudioDomainUnavailable"
                }
                audio::ProjectAudioError::Stage(
                    deadpan_audio::StageAudioError::ForeignDefinition,
                )
                | audio::ProjectAudioError::Plan(
                    deadpan_plan::PlanError::InvalidAudioDefinitionSelector(_),
                )
                | audio::ProjectAudioError::Stage(deadpan_audio::StageAudioError::Plan(
                    deadpan_plan::PlanError::InvalidAudioDefinitionSelector(_),
                )) => "AudioDefinitionUnavailable",
                audio::ProjectAudioError::Plan(
                    deadpan_plan::PlanError::InvalidAudioRootPlacement(_),
                )
                | audio::ProjectAudioError::Stage(deadpan_audio::StageAudioError::Plan(
                    deadpan_plan::PlanError::InvalidAudioRootPlacement(_),
                )) => "AudioPlacementUnavailable",
                audio::ProjectAudioError::Plan(deadpan_plan::PlanError::AudioQueryLimit(_))
                | audio::ProjectAudioError::Stage(deadpan_audio::StageAudioError::Plan(
                    deadpan_plan::PlanError::AudioQueryLimit(_),
                )) => "AudioQueryLimit",
                audio::ProjectAudioError::Stage(
                    deadpan_audio::StageAudioError::Limit(_)
                    | deadpan_audio::StageAudioError::InvalidLimits,
                ) => "AudioPreparationLimit",
                audio::ProjectAudioError::Stage(deadpan_audio::StageAudioError::Timeout) => {
                    "AudioPreparationTimeout"
                }
                audio::ProjectAudioError::Stage(deadpan_audio::StageAudioError::Cache(_)) => {
                    "AudioCacheFailed"
                }
                audio::ProjectAudioError::Stage(deadpan_audio::StageAudioError::Unsupported(_)) => {
                    "AudioOperationUnsupported"
                }
                audio::ProjectAudioError::Stage(deadpan_audio::StageAudioError::Preparation(
                    error,
                )) => match error {
                    deadpan_audio::PreparationError::UnsupportedLayout => "AudioLayoutUnsupported",
                    deadpan_audio::PreparationError::SourceUnavailable(_) => {
                        "SourceAudioUnavailable"
                    }
                    deadpan_audio::PreparationError::IndexMismatch => "SourceAudioIndexMismatch",
                    deadpan_audio::PreparationError::Cancelled => "Cancelled",
                    deadpan_audio::PreparationError::Time(_) => "TimingOverflow",
                    _ => "AudioInspectionFailed",
                },
                audio::ProjectAudioError::Stage(error @ deadpan_audio::StageAudioError::Dsp(_)) => {
                    if error.is_cancelled() {
                        "Cancelled"
                    } else {
                        "AudioProcessingFailed"
                    }
                }
                audio::ProjectAudioError::Stage(deadpan_audio::StageAudioError::Time(_)) => {
                    "TimingOverflow"
                }
                audio::ProjectAudioError::Sequence(
                    deadpan_audio::SequenceAudioError::Unsupported { .. },
                ) => "AudioOperationUnsupported",
                audio::ProjectAudioError::Sequence(
                    deadpan_audio::SequenceAudioError::Preparation(
                        deadpan_audio::PreparationError::UnsupportedLayout,
                    ),
                ) => "AudioLayoutUnsupported",
                audio::ProjectAudioError::Sequence(
                    deadpan_audio::SequenceAudioError::Preparation(
                        deadpan_audio::PreparationError::SourceUnavailable(_),
                    ),
                ) => "SourceAudioUnavailable",
                audio::ProjectAudioError::Sequence(
                    deadpan_audio::SequenceAudioError::Preparation(
                        deadpan_audio::PreparationError::IndexMismatch,
                    ),
                ) => "SourceAudioIndexMismatch",
                audio::ProjectAudioError::Sequence(
                    deadpan_audio::SequenceAudioError::Preparation(
                        deadpan_audio::PreparationError::Cancelled,
                    ),
                ) => "Cancelled",
                audio::ProjectAudioError::Sequence(deadpan_audio::SequenceAudioError::Time(_)) => {
                    "TimingOverflow"
                }
                _ => "AudioInspectionFailed",
            },
        }
    }
    fn current_revision(&self) -> Option<&str> {
        match self {
            #[cfg(any(target_os = "macos", target_os = "linux"))]
            Self::LiveProject(error) => error.current_revision.as_ref().map(RevisionId::as_str),
            #[cfg(any(target_os = "macos", target_os = "linux"))]
            Self::Render(error) => error.current_revision.as_ref().map(RevisionId::as_str),
            Self::Store(StoreError::RevisionConflict { current, .. }) => Some(current),
            Self::Store(StoreError::Edit(error)) => {
                error.current_revision.as_ref().map(RevisionId::as_str)
            }
            Self::Anchor(error) => error.current_revision.as_ref().map(RevisionId::as_str),
            _ => None,
        }
    }
    fn recovery_backup(&self) -> Option<&Path> {
        match self {
            Self::Store(StoreError::MigrationFailed { backup, .. }) => Some(backup),
            _ => None,
        }
    }
    fn committed_revision(&self) -> Option<&str> {
        match self {
            #[cfg(any(target_os = "macos", target_os = "linux"))]
            Self::LiveProject(error) => error.committed_revision.as_ref().map(RevisionId::as_str),
            _ => None,
        }
    }
}

#[derive(Deserialize)]
#[serde(deny_unknown_fields)]
struct CommandEnvelope {
    protocol: u32,
    project_id: ProjectId,
    expected_revision: RevisionId,
    #[serde(default)]
    new_revision: Option<RevisionId>,
    command: Command,
    #[serde(default)]
    dry_run: bool,
}

#[derive(Deserialize)]
#[serde(deny_unknown_fields)]
struct SelectionEnvelope {
    protocol: u32,
    request: deadpan_core::SelectionRequest,
}

#[derive(Deserialize)]
#[serde(deny_unknown_fields)]
struct BoundaryEnvelope {
    protocol: u32,
    request: deadpan_core::BoundaryLocationRequest,
    #[serde(default)]
    limits: Option<BoundaryLimits>,
}

#[derive(Deserialize)]
#[serde(deny_unknown_fields)]
struct BoundaryLimits {
    max_scopes: usize,
    max_comparisons: usize,
}

/// Shared process entrypoint for the CLI and `deadpan-app --headless`.
pub fn entry(arguments: impl IntoIterator<Item = String>) -> ExitCode {
    let arguments: Vec<String> = arguments.into_iter().collect();
    #[cfg(any(target_os = "macos", target_os = "linux"))]
    if let [operation, package] = arguments.as_slice()
        && operation == render_worker::PRIVATE_WORKER_ARGUMENT
    {
        return render_worker::worker::entry(Path::new(package));
    }
    #[cfg(any(target_os = "macos", target_os = "linux"))]
    if let [operation, package] = arguments.as_slice()
        && operation == encoded_render::PRIVATE_WORKER_ARGUMENT
    {
        return encoded_render::worker::entry(Path::new(package));
    }
    #[cfg(any(target_os = "macos", target_os = "linux"))]
    if let [operation] = arguments.as_slice()
        && operation == encoded_render::verification::PRIVATE_WORKER_ARGUMENT
    {
        return encoded_render::verification::worker::entry();
    }
    #[cfg(any(target_os = "macos", target_os = "linux"))]
    if let [operation] = arguments.as_slice()
        && operation == encoded_render::admission::PRIVATE_WORKER_ARGUMENT
    {
        return encoded_render::admission::worker::entry();
    }
    match run(&arguments) {
        Ok(()) => ExitCode::SUCCESS,
        #[cfg(any(target_os = "macos", target_os = "linux"))]
        Err(CliError::Render(error)) => {
            render::report_error(&error);
            ExitCode::FAILURE
        }
        Err(error) => {
            let mut report = serde_json::json!({ "schema_version": 1, "error": {
                "code": error.code(), "message": error.to_string(), "current_revision": error.current_revision(), "recovery_backup": error.recovery_backup()
            }});
            if let Some(revision) = error.committed_revision() {
                report["error"]["committed_revision"] = serde_json::Value::String(revision.into());
            }
            #[cfg(any(target_os = "macos", target_os = "linux"))]
            if let CliError::LiveProject(live) = &error
                && let Some(registers) = &live.committed_registers
            {
                report["error"]["committed_registers"] = serde_json::json!(registers);
            }
            let _ = writeln!(io::stderr().lock(), "{report}");
            ExitCode::FAILURE
        }
    }
}

fn run(arguments: &[String]) -> Result<(), CliError> {
    let arguments: Vec<&str> = arguments.iter().map(String::as_str).collect();
    match arguments.as_slice() {
        #[cfg(any(target_os = "macos", target_os = "linux"))]
        ["macro", rest @ ..] => macros::run(rest),
        #[cfg(any(target_os = "macos", target_os = "linux"))]
        ["render", rest @ ..] => render::run(rest).map_err(CliError::Render),
        #[cfg(target_os = "macos")]
        ["verify-export", rest @ ..] => export_verification::cli::run(rest),
        #[cfg(any(target_os = "macos", target_os = "linux"))]
        ["models", rest @ ..] => models::run(rest),
        #[cfg(any(target_os = "macos", target_os = "linux"))]
        ["downloader", rest @ ..] => youtube::helpers::run(rest),
        #[cfg(any(target_os = "macos", target_os = "linux"))]
        ["update-signing", rest @ ..] => update_signing::run(rest),
        #[cfg(any(target_os = "macos", target_os = "linux"))]
        ["project", "create-from-url", rest @ ..] => youtube::acquire::run(rest),
        #[cfg(any(target_os = "macos", target_os = "linux"))]
        ["project", "storage", rest @ ..] => storage::run_project(rest),
        #[cfg(any(target_os = "macos", target_os = "linux"))]
        ["project", "copy-portable", rest @ ..] => storage::run_copy(rest),
        #[cfg(any(target_os = "macos", target_os = "linux"))]
        ["project", "backups", rest @ ..] => backups::run_list(rest),
        #[cfg(any(target_os = "macos", target_os = "linux"))]
        ["project", "takes", rest @ ..] => takes::run_list(rest),
        #[cfg(any(target_os = "macos", target_os = "linux"))]
        ["project", "take", rest @ ..] => takes::run(rest),
        #[cfg(any(target_os = "macos", target_os = "linux"))]
        ["project", "backup", rest @ ..] => backups::run_create(rest),
        #[cfg(any(target_os = "macos", target_os = "linux"))]
        ["project", "restore", rest @ ..] => backups::run_restore(rest),
        #[cfg(any(target_os = "macos", target_os = "linux"))]
        ["project", "view", rest @ ..] => backups::run_view(rest),
        #[cfg(any(target_os = "macos", target_os = "linux"))]
        ["backup-policy", rest @ ..] => backups::run_policy(rest),
        #[cfg(any(target_os = "macos", target_os = "linux"))]
        ["cache", rest @ ..] => storage::run_cache(rest),
        #[cfg(any(target_os = "macos", target_os = "linux"))]
        ["transcribe", rest @ ..] => transcription::run_transcribe(rest),
        #[cfg(any(target_os = "macos", target_os = "linux"))]
        ["transcript", rest @ ..] => transcription::run_transcript(rest),
        #[cfg(any(target_os = "macos", target_os = "linux"))]
        ["corrections", rest @ ..] => corrections::run(rest),
        #[cfg(any(target_os = "macos", target_os = "linux"))]
        ["pauses", rest @ ..] => activity::run_pauses(rest),
        #[cfg(any(target_os = "macos", target_os = "linux"))]
        ["detect-shots", rest @ ..] => shots::run_detect_shots(rest),
        #[cfg(any(target_os = "macos", target_os = "linux"))]
        ["shots", rest @ ..] => shots::run_shots(rest),
        #[cfg(any(target_os = "macos", target_os = "linux"))]
        ["track", rest @ ..] => tracking::run_track(rest),
        #[cfg(any(target_os = "macos", target_os = "linux"))]
        ["track-correct", rest @ ..] => tracking::run_track_correct(rest),
        #[cfg(any(target_os = "macos", target_os = "linux"))]
        ["detect-faces", rest @ ..] => faces::run_detect_faces(rest),
        #[cfg(any(target_os = "macos", target_os = "linux"))]
        ["generate-hold", rest @ ..] => generation::command::run_generate(rest),
        #[cfg(any(target_os = "macos", target_os = "linux"))]
        ["accept-hold", rest @ ..] => generation::command::run_accept(rest),
        #[cfg(any(target_os = "macos", target_os = "linux"))]
        ["keep-hold", rest @ ..] => generation::variants::run_action(rest, "keep-hold"),
        #[cfg(any(target_os = "macos", target_os = "linux"))]
        ["select-hold", rest @ ..] => generation::variants::run_action(rest, "select-hold"),
        #[cfg(any(target_os = "macos", target_os = "linux"))]
        ["discard-hold", rest @ ..] => generation::variants::run_action(rest, "discard-hold"),
        #[cfg(any(target_os = "macos", target_os = "linux"))]
        ["dismiss-attempt", rest @ ..] => generation::variants::run_action(rest, "dismiss-attempt"),
        #[cfg(any(target_os = "macos", target_os = "linux"))]
        ["ai-variants", rest @ ..] => generation::variants::run_report(rest),
        #[cfg(any(target_os = "macos", target_os = "linux"))]
        ["ai-replacements", rest @ ..] => generation::preparations::run(rest),
        #[cfg(any(target_os = "macos", target_os = "linux"))]
        ["sound", rest @ ..] => sound_events::run(rest),
        #[cfg(any(target_os = "macos", target_os = "linux"))]
        ["gag-inspect", rest @ ..] => gags::run(rest),
        [] | ["--help"] | ["-h"] => {
            println!("{HELP}");
            Ok(())
        }
        ["doctor"] => write_json(&doctor::report()?),
        #[cfg(any(target_os = "macos", target_os = "linux"))]
        ["diagnostics", "export", destination] => {
            write_json(&diagnostic_export::capture(None).write(Path::new(destination))?)
        }
        #[cfg(any(target_os = "macos", target_os = "linux"))]
        ["diagnostics", "export", destination, "--project", package] => write_json(
            &diagnostic_export::capture(Some(Path::new(package))).write(Path::new(destination))?,
        ),
        #[cfg(any(target_os = "macos", target_os = "linux"))]
        ["doctor", "--project", package] => {
            write_json(&doctor::project_report(Path::new(package))?)
        }
        #[cfg(any(target_os = "macos", target_os = "linux"))]
        [
            "inspect-audio-domain",
            path,
            "--at",
            probe,
            "--samples",
            start,
            end,
        ] => {
            let probe = probe
                .parse::<i64>()
                .map_err(|_| CliError::Usage("invalid audio domain probe".into()))?;
            let start = start
                .parse::<i64>()
                .map_err(|_| CliError::Usage("invalid audio sample start".into()))?;
            let end = end
                .parse::<i64>()
                .map_err(|_| CliError::Usage("invalid audio sample end".into()))?;
            let frames = end
                .checked_sub(start)
                .and_then(|value| u32::try_from(value).ok())
                .filter(|frames| *frames > 0 && *frames <= deadpan_audio::MAX_OUTPUT_FRAMES)
                .ok_or(audio::ProjectAudioError::Stage(
                    deadpan_audio::StageAudioError::Range,
                ))?;
            let mut session = audio::ProjectAudioSession::open(Path::new(path))?;
            let block = session.read_domain(
                deadpan_core::AudioSample(probe),
                deadpan_core::AudioSample(start),
                frames,
                &std::sync::atomic::AtomicBool::new(false),
            )?;
            write_json(&serde_json::json!({ "protocol": 1, "audio": block }))
        }
        #[cfg(any(target_os = "macos", target_os = "linux"))]
        [
            "inspect-audio-definition",
            path,
            selector,
            id,
            "--samples",
            start,
            end,
            retained @ ..,
        ] if matches!(*selector, "--node" | "--repeat-default" | "--repeat-gap") => {
            let revision = inspection_revision(retained)?;
            let start = start
                .parse::<i64>()
                .map_err(|_| CliError::Usage("invalid definition sample start".into()))?;
            let end = end
                .parse::<i64>()
                .map_err(|_| CliError::Usage("invalid definition sample end".into()))?;
            let frames = end
                .checked_sub(start)
                .and_then(|count| u32::try_from(count).ok())
                .filter(|count| {
                    start >= 0 && *count > 0 && *count <= deadpan_audio::MAX_OUTPUT_FRAMES
                })
                .ok_or(audio::ProjectAudioError::Stage(
                    deadpan_audio::StageAudioError::Range,
                ))?;
            let selector = audio_definition_selector(selector, id)?;
            let mut session = match revision {
                Some(revision) => {
                    audio::ProjectAudioSession::open_revision(Path::new(path), &revision)?
                }
                None => audio::ProjectAudioSession::open(Path::new(path))?,
            };
            let block = session.read_definition(
                selector,
                deadpan_plan::SignalSample(start),
                frames,
                &std::sync::atomic::AtomicBool::new(false),
            )?;
            write_json(&serde_json::json!({ "protocol": 1, "audio": block }))
        }
        #[cfg(any(target_os = "macos", target_os = "linux"))]
        [
            "inspect-audio-placement",
            path,
            selector,
            id,
            "--clock",
            clock,
            "--samples",
            start,
            end,
            retained @ ..,
        ] if matches!(*selector, "--node" | "--repeat-default" | "--repeat-gap") => {
            let revision = inspection_revision(retained)?;
            let start = start
                .parse::<i64>()
                .map_err(|_| CliError::Usage("invalid placement sample start".into()))?;
            let end = end
                .parse::<i64>()
                .map_err(|_| CliError::Usage("invalid placement sample end".into()))?;
            let frames = end
                .checked_sub(start)
                .and_then(|count| u32::try_from(count).ok())
                .filter(|count| *count > 0 && *count <= deadpan_audio::MAX_OUTPUT_FRAMES)
                .ok_or(audio::ProjectAudioError::Stage(
                    deadpan_audio::StageAudioError::Range,
                ))?;
            let placement = read_audio_clock(Path::new(clock))?;
            let selector = audio_definition_selector(selector, id)?;
            let mut session = match revision {
                Some(revision) => {
                    audio::ProjectAudioSession::open_revision(Path::new(path), &revision)?
                }
                None => audio::ProjectAudioSession::open(Path::new(path))?,
            };
            let block = session.read_placement(
                selector,
                placement,
                deadpan_core::AudioSample(start),
                frames,
                &std::sync::atomic::AtomicBool::new(false),
            )?;
            write_json(&serde_json::json!({ "protocol": 1, "audio": block }))
        }
        #[cfg(any(target_os = "macos", target_os = "linux"))]
        ["inspect-audio", path, "--samples", start, end]
        | [
            "inspect-audio",
            path,
            "--samples",
            start,
            end,
            "--time-mapped",
        ]
        | [
            "inspect-audio",
            path,
            "--samples",
            start,
            end,
            "--edge-faded",
        ]
        | [
            "inspect-audio",
            path,
            "--samples",
            start,
            end,
            "--authored-bus",
        ]
        | ["inspect-audio", path, "--samples", start, end, "--limited"] => {
            let start = start
                .parse::<i64>()
                .map_err(|_| CliError::Usage("invalid audio sample start".into()))?;
            let end = end
                .parse::<i64>()
                .map_err(|_| CliError::Usage("invalid audio sample end".into()))?;
            let frames = end
                .checked_sub(start)
                .and_then(|value| u32::try_from(value).ok())
                .ok_or(audio::ProjectAudioError::Sequence(
                    deadpan_audio::SequenceAudioError::Range,
                ))?;
            let mut session = audio::ProjectAudioSession::open(Path::new(path))?;
            let cancelled = std::sync::atomic::AtomicBool::new(false);
            let block = if arguments.last() == Some(&"--limited") {
                serde_json::to_value(session.read_limited(
                    deadpan_core::AudioSample(start),
                    frames,
                    &cancelled,
                )?)?
            } else if arguments.last() == Some(&"--authored-bus") {
                serde_json::to_value(session.read_authored_bus(
                    deadpan_core::AudioSample(start),
                    frames,
                    &cancelled,
                )?)?
            } else if arguments.last() == Some(&"--edge-faded") {
                serde_json::to_value(session.read_edge_faded(
                    deadpan_core::AudioSample(start),
                    frames,
                    &cancelled,
                )?)?
            } else if arguments.last() == Some(&"--time-mapped") {
                serde_json::to_value(session.read_time_mapped(
                    deadpan_core::AudioSample(start),
                    frames,
                    &cancelled,
                )?)?
            } else {
                serde_json::to_value(session.read(
                    deadpan_core::AudioSample(start),
                    frames,
                    &cancelled,
                )?)?
            };
            write_json(&serde_json::json!({ "protocol": 1, "audio": block }))
        }
        #[cfg(any(target_os = "macos", target_os = "linux"))]
        [
            "project",
            action @ ("retain-original"
            | "originals"
            | "original-provenance"
            | "verify-original"
            | "relink-original"
            | "relink-moved"),
            rest @ ..,
        ] => originals::run(action, rest),
        #[cfg(any(target_os = "macos", target_os = "linux"))]
        ["project", "create-original", path, source] => {
            single_original::run(Path::new(path), Path::new(source), false)
        }
        #[cfg(any(target_os = "macos", target_os = "linux"))]
        ["project", "create-original", path, source, "--linked"] => {
            single_original::run(Path::new(path), Path::new(source), true)
        }
        #[cfg(any(target_os = "macos", target_os = "linux"))]
        ["project", "insert-original", rest @ ..] => source_registration::run_insert_original(rest),
        #[cfg(any(target_os = "macos", target_os = "linux"))]
        [
            "project",
            "register-source",
            path,
            "--request-json",
            request,
        ] => source_registration::run(Path::new(path), Path::new(request), false),
        #[cfg(any(target_os = "macos", target_os = "linux"))]
        [
            "project",
            "register-source",
            path,
            "--request-json",
            request,
            "--dry-run",
        ] => source_registration::run(Path::new(path), Path::new(request), true),
        #[cfg(any(target_os = "macos", target_os = "linux"))]
        [
            "project",
            "adopt-primary-geometry",
            path,
            "--request-json",
            request,
        ] => source_registration::adopt_geometry(Path::new(path), Path::new(request), false),
        #[cfg(any(target_os = "macos", target_os = "linux"))]
        [
            "project",
            "adopt-primary-geometry",
            path,
            "--request-json",
            request,
            "--dry-run",
        ] => source_registration::adopt_geometry(Path::new(path), Path::new(request), true),
        ["project", "create", path] => {
            let document = ProjectDocument::new_automatic(
                ProjectId::new(uuid::Uuid::new_v4().to_string())?,
                new_revision()?,
                NodeId::new(uuid::Uuid::new_v4().to_string())?,
            )?;
            let store = ProjectStore::create(Path::new(path), &document)?;
            summary(&store.snapshot()?)
        }
        ["project", "create", path, "--fps", fps, "--size", size] => {
            let (numerator, denominator) = pair(fps, '/')?;
            let (width, height) = pair(size, 'x')?;
            let document = ProjectDocument::new(
                ProjectId::new(uuid::Uuid::new_v4().to_string())?,
                new_revision()?,
                PresentationBasis {
                    width,
                    height,
                    frame_rate: FrameRate::new(numerator, denominator)?,
                    color_policy: ColorPolicy::SdrRec709,
                },
                NodeId::new(uuid::Uuid::new_v4().to_string())?,
            )?;
            let store = ProjectStore::create(Path::new(path), &document)?;
            summary(&store.snapshot()?)
        }
        ["project", "validate", path] => {
            // An explicit audit recomputes every command and revision.
            let store = ProjectStore::open(Path::new(path), AccessMode::ReadOnly)?;
            store.validate_full()?;
            summary(&store.snapshot()?)
        }
        ["project", "validate", path, "--quick"] => {
            // What opening checks: every stored row hashed against this
            // build's history receipt; only revisions after it recomputed.
            let store = ProjectStore::open(Path::new(path), AccessMode::ReadOnly)?;
            summary(&store.snapshot()?)
        }
        ["project", "dump", path, "--json"] => {
            let document = ProjectStore::open(Path::new(path), AccessMode::ReadOnly)?.snapshot()?;
            io::stdout()
                .lock()
                .write_all(document.to_json()?.as_bytes())?;
            Ok(())
        }
        [
            "project",
            action @ ("undo" | "redo"),
            path,
            "--expected",
            expected,
        ] => history(Path::new(path), action, expected, false),
        [
            "project",
            action @ ("undo" | "redo"),
            path,
            "--expected",
            expected,
            "--dry-run",
        ] => history(Path::new(path), action, expected, true),
        ["project", "checkpoint", path] => {
            let store = match ProjectStore::open(Path::new(path), AccessMode::ReadWrite) {
                Ok(store) => store,
                Err(StoreError::AlreadyOpen) => {
                    return live_project::preparation::run(
                        Path::new(path),
                        live_project::preparation::PreparationCommand::Checkpoint {},
                    );
                }
                Err(error) => return Err(error.into()),
            };
            write_json(
                &serde_json::json!({ "protocol": 1, "database_checkpoint": store.checkpoint()? }),
            )
        }
        ["project", "migrate", path] => match ProjectStore::migrate(Path::new(path)) {
            Ok(migration) => {
                write_json(&serde_json::json!({ "protocol":1, "migration": migration }))
            }
            Err(StoreError::AlreadyOpen) => write_json(&live_project::dispatch_short(
                Path::new(path),
                None,
                live_project::ShortOperation::Migrate,
            )?),
            Err(error) => Err(error.into()),
        },
        ["inspect-plan", path] => {
            let document = ProjectStore::open(Path::new(path), AccessMode::ReadOnly)?.snapshot()?;
            let plan = deadpan_plan::RenderPlan::compile(&document)?;
            write_json(&serde_json::json!({ "protocol": 1, "plan": plan.inspect() }))
        }
        ["inspect-plan", path, "--audio-samples", start, end] => {
            let parse = |value: &str| {
                value
                    .parse::<i64>()
                    .map(deadpan_core::AudioSample)
                    .map_err(|_| {
                        CliError::Usage(
                            "Audio boundaries must be signed 48 kHz sample integers".into(),
                        )
                    })
            };
            let samples = parse(start)?..parse(end)?;
            let document = ProjectStore::open(Path::new(path), AccessMode::ReadOnly)?.snapshot()?;
            let plan = deadpan_plan::RenderPlan::compile(&document)?;
            write_json(&serde_json::json!({
                "protocol": 1,
                "audio": plan.audio(samples, deadpan_plan::AudioQueryLimits::default())?,
            }))
        }
        ["inspect-plan", path, "--frame", frame] => {
            let frame = frame
                .parse::<i64>()
                .map_err(|_| CliError::Usage("Frame must be a signed integer".into()))?;
            let document = ProjectStore::open(Path::new(path), AccessMode::ReadOnly)?.snapshot()?;
            let plan = deadpan_plan::RenderPlan::compile(&document)?;
            write_json(
                &serde_json::json!({ "protocol": 1, "sample": plan.picture(deadpan_core::ProjectFrame(frame))? }),
            )
        }
        ["resolve-selection", path, "--json", request] => {
            let envelope: SelectionEnvelope =
                serde_json::from_str(&read_request(Path::new(request))?)?;
            if envelope.protocol != 1 {
                return Err(CliError::Protocol(envelope.protocol));
            }
            let document = ProjectStore::open(Path::new(path), AccessMode::ReadOnly)?.snapshot()?;
            let index = deadpan_core::AnchorIndex::new(&document)?;
            write_json(
                &serde_json::json!({ "protocol": 1, "resolved": index.resolve(&envelope.request)? }),
            )
        }
        ["locate-boundary", path, "--json", request] => {
            let envelope: BoundaryEnvelope =
                serde_json::from_str(&read_request(Path::new(request))?)?;
            if envelope.protocol != 1 {
                return Err(CliError::Protocol(envelope.protocol));
            }
            let limits =
                envelope
                    .limits
                    .map_or_else(deadpan_core::BoundaryQueryLimits::default, |limits| {
                        deadpan_core::BoundaryQueryLimits {
                            max_scopes: limits.max_scopes,
                            max_comparisons: limits.max_comparisons,
                        }
                    });
            let document = ProjectStore::open(Path::new(path), AccessMode::ReadOnly)?.snapshot()?;
            let index = deadpan_core::AnchorIndex::new(&document)?;
            write_json(
                &serde_json::json!({ "protocol": 1, "location": index.locate_boundary(&envelope.request, limits)? }),
            )
        }
        ["command", path, "--json", request] => command(Path::new(path), Path::new(request), false),
        ["command", path, "--json", request, "--dry-run"] => {
            command(Path::new(path), Path::new(request), true)
        }
        _ => Err(CliError::Usage(format!(
            "Unknown command or invalid arguments.\n{HELP}"
        ))),
    }
}

fn new_revision() -> Result<RevisionId, deadpan_core::DocumentError> {
    RevisionId::new(uuid::Uuid::new_v4().to_string())
}

fn history(package: &Path, action: &str, expected: &str, preview: bool) -> Result<(), CliError> {
    #[cfg(any(target_os = "macos", target_os = "linux"))]
    {
        let direction = if action == "undo" {
            live_project::HistoryDirection::Undo
        } else {
            live_project::HistoryDirection::Redo
        };
        write_json(&live_project::dispatch_short(
            package,
            None,
            live_project::ShortOperation::History {
                direction,
                expected_revision: RevisionId::new(expected)?,
                new_revision: new_revision()?,
                dry_run: preview,
            },
        )?)
    }
    #[cfg(not(any(target_os = "macos", target_os = "linux")))]
    {
        let mut store = ProjectStore::open(
            package,
            if preview {
                AccessMode::ReadOnly
            } else {
                AccessMode::ReadWrite
            },
        )?;
        store.set_generation_context_resolver(std::sync::Arc::new(
            generation_context::BoundaryContextResolver::default(),
        ));
        let expected = RevisionId::new(expected)?;
        let next = new_revision()?;
        let outcome = match (action, preview) {
            ("undo", true) => store.preview_undo(&expected, next)?,
            ("undo", false) => store.undo(&expected, next)?,
            (_, true) => store.preview_redo(&expected, next)?,
            (_, false) => store.redo(&expected, next)?,
        };
        write_json(&serde_json::json!({ "protocol": 1, "committed": !preview, "outcome": outcome }))
    }
}

fn pair(value: &str, separator: char) -> Result<(u32, u32), CliError> {
    let invalid = || {
        CliError::Usage(format!(
            "Expected two positive integers separated by '{separator}'"
        ))
    };
    let (first, second) = value.split_once(separator).ok_or_else(invalid)?;
    let first: u32 = first.parse().map_err(|_| invalid())?;
    let second: u32 = second.parse().map_err(|_| invalid())?;
    if first == 0 || second == 0 {
        return Err(invalid());
    }
    Ok((first, second))
}

fn read_request(request: &Path) -> Result<String, CliError> {
    let mut json = String::new();
    File::open(request)?
        .take(deadpan_core::MAX_DOCUMENT_JSON_BYTES as u64 + 1)
        .read_to_string(&mut json)?;
    if json.len() > deadpan_core::MAX_DOCUMENT_JSON_BYTES {
        return Err(CliError::Usage(
            "JSON request exceeds the 64 MiB limit".into(),
        ));
    }
    Ok(json)
}

#[cfg(any(target_os = "macos", target_os = "linux"))]
fn audio_definition_selector(
    flag: &str,
    id: &str,
) -> Result<deadpan_plan::AudioDefinitionSelector, CliError> {
    let id = NodeId::new(id)?;
    match flag {
        "--node" => Ok(deadpan_plan::AudioDefinitionSelector::Node { node: id }),
        "--repeat-default" => {
            Ok(deadpan_plan::AudioDefinitionSelector::RepeatDefault { repeat: id })
        }
        "--repeat-gap" => Ok(deadpan_plan::AudioDefinitionSelector::RepeatGap { repeat: id }),
        _ => Err(CliError::Usage("invalid audio definition selector".into())),
    }
}

#[cfg(any(target_os = "macos", target_os = "linux"))]
fn inspection_revision(arguments: &[&str]) -> Result<Option<RevisionId>, CliError> {
    match arguments {
        [] => Ok(None),
        ["--revision", id] => Ok(Some(RevisionId::new(*id)?)),
        _ => Err(CliError::Usage("expected optional --revision <ID>".into())),
    }
}

#[cfg(any(target_os = "macos", target_os = "linux"))]
fn read_audio_clock(path: &Path) -> Result<deadpan_plan::AudioRootPlacement, CliError> {
    let mut json = String::new();
    File::open(path)?.take(4097).read_to_string(&mut json)?;
    if json.len() > 4096 {
        return Err(CliError::Usage(
            "audio clock exceeds the 4 KiB limit".into(),
        ));
    }
    Ok(serde_json::from_str(&json)?)
}

fn command(package: &Path, request: &Path, dry_run: bool) -> Result<(), CliError> {
    let envelope: CommandEnvelope = serde_json::from_str(&read_request(request)?)?;
    if envelope.protocol != 1 {
        return Err(CliError::Protocol(envelope.protocol));
    }
    let preview = dry_run || envelope.dry_run;
    let new_revision = envelope.new_revision.map_or_else(new_revision, Ok)?;
    // The public editing verb retains current audio clocks. The old core tag
    // remains unchanged solely so stored histories replay their exact patches.
    let command = match envelope.command {
        Command::Delete { node } => Command::DeleteRipple {
            node,
            timing: deadpan_core::AudioTimingId {
                allocation: new_revision.clone(),
                ordinal: 0,
            },
        },
        command => command,
    };
    let request = CommandRequest {
        project_id: envelope.project_id,
        expected_revision: envelope.expected_revision,
        new_revision,
        command,
    };
    #[cfg(any(target_os = "macos", target_os = "linux"))]
    {
        write_json(&live_project::dispatch_short(
            package,
            Some(request.project_id.clone()),
            live_project::ShortOperation::Edit {
                request: Box::new(request),
                dry_run: preview,
            },
        )?)
    }
    #[cfg(not(any(target_os = "macos", target_os = "linux")))]
    {
        let mut store = ProjectStore::open(
            package,
            if preview {
                AccessMode::ReadOnly
            } else {
                AccessMode::ReadWrite
            },
        )?;
        store.set_generation_context_resolver(std::sync::Arc::new(
            generation_context::BoundaryContextResolver::default(),
        ));
        if preview {
            write_json(
                &serde_json::json!({ "protocol": 1, "committed": false, "edit": store.preview(&request)? }),
            )
        } else {
            write_json(
                &serde_json::json!({ "protocol": 1, "committed": true, "outcome": store.commit(&request)? }),
            )
        }
    }
}

fn summary(document: &ProjectDocument) -> Result<(), CliError> {
    write_json(&serde_json::json!({
        "protocol": 1, "valid": true, "project_id": document.project_id(), "revision_id": document.revision_id(),
        "root": document.root(), "duration_frames": document.duration()?.frames(), "node_count": document.nodes().len(), "mark_count": document.marks().len(),
        "presentation_basis": document.presentation_basis(), "basis_state": document.basis_state()
    }))
}

pub(crate) fn write_json(value: &impl Serialize) -> Result<(), CliError> {
    let mut output = io::stdout().lock();
    serde_json::to_writer_pretty(&mut output, value)?;
    writeln!(output)?;
    Ok(())
}
