//! Command-level PCM oracles share decoding helpers with the stage suite, but
//! derive cut/resume coordinates directly from the project frame clock.
use super::*;

#[path = "occurrence_pause.rs"]
mod occurrence_pause;

#[path = "ordinary_duration.rs"]
mod ordinary_duration;

#[path = "processing_hold_duration.rs"]
mod processing_hold_duration;

#[path = "rate_bound_pcm.rs"]
mod rate_bound_pcm;

#[path = "clocked_speed_update.rs"]
mod clocked_speed_update;

fn insert_pause(document: &ProjectDocument, at: i64, frames: i64, name: &str) -> ProjectDocument {
    let revision = RevisionId::new(name).unwrap();
    let request = CommandRequest {
        project_id: document.project_id().clone(),
        expected_revision: document.revision_id().clone(),
        new_revision: revision.clone(),
        command: Command::InsertTime {
            at: ProjectFrame(at),
            hold: HoldRecipe {
                picture_context: None,
                duration: duration(frames),
                video: HoldVideo::Background,
                audio: HoldAudio::Silence,
            },
            id: id(&format!("{name}-pause")),
            identities: SplitIdentities {
                nodes: (0..document.nodes().len() + 4)
                    .map(|index| id(&format!("{name}-split-{index}")))
                    .collect(),
            },
            timing: AudioTimingId {
                allocation: revision,
                ordinal: 0,
            },
        },
    };
    let before = document.clone();
    let transaction = apply(document, &request).unwrap();
    assert_eq!(transaction.duration_delta, frames);
    assert_eq!(*document, before);
    let changed = transaction.forward.apply(document).unwrap();
    assert_eq!(transaction.inverse.apply(&changed).unwrap(), before);
    changed
}

fn mono_original(frames: i64) -> (ProjectDocument, FixtureProvider) {
    let rate = FrameRate::new(30_000, 1001).unwrap();
    let selected = audio_at_rate(100, 20_100, 44_100);
    let mut leaf = source(rate, frames, 0..1);
    let NodeKind::Source { source } = &mut leaf.kind else {
        unreachable!()
    };
    source.audio_mapping = SourceAudioMapping::natural_rate(selected.span, rate).unwrap();
    source.audio = Some(selected);
    let document = document_with_asset(
        rate,
        &["source"],
        [("source", leaf)],
        BTreeMap::new(),
        audio_at_rate(0, 44_117, 44_100).span,
    );
    let provider = FixtureProvider::from_fixture(
        "pcm-mono-44100.wav",
        AudioChannelLayout::Native {
            channels: 1,
            mask: 4,
        },
    );
    (document, provider)
}

fn ntsc_boundary(frame: i64) -> usize {
    let samples = ratio(i128::from(frame) * 8008, 5).round_even().unwrap();
    usize::try_from(samples).unwrap()
}

#[derive(Debug, PartialEq)]
struct Recorded {
    samples: Vec<[f32; 2]>,
    suppressed: Vec<bool>,
}

fn record(
    document: &ProjectDocument,
    provider: &mut FixtureProvider,
    faded: bool,
    pieces: &[u32],
) -> Recorded {
    provider.revisions.insert(document.revision_id().clone());
    let mut renderer = StageAudio::new(Arc::new(RenderPlan::compile(document).unwrap()));
    let total = renderer.plan().audio_duration().unwrap().0 as usize;
    let mut result = Recorded {
        samples: Vec::with_capacity(total),
        suppressed: vec![false; total],
    };
    for requested in pieces.iter().copied().cycle() {
        if result.samples.len() == total {
            break;
        }
        let start = result.samples.len();
        let count = requested.min((total - start) as u32);
        let (samples, suppressed) = if faded {
            let block = renderer
                .read_edge_faded(
                    provider,
                    AudioSample(start as i64),
                    count,
                    TIMEOUT,
                    &AtomicBool::new(false),
                )
                .unwrap();
            (block.samples, block.suppressed)
        } else {
            let block = renderer
                .read(
                    provider,
                    AudioSample(start as i64),
                    count,
                    TIMEOUT,
                    &AtomicBool::new(false),
                )
                .unwrap();
            (block.samples, block.suppressed)
        };
        result.samples.extend(samples);
        for range in suppressed {
            result.suppressed[range.start.0 as usize..range.end.0 as usize].fill(true);
        }
    }
    result
}

fn assert_pause(recorded: &Recorded, samples: Range<usize>) {
    assert!(
        recorded.samples[samples.clone()]
            .iter()
            .all(|v| *v == [0.; 2])
    );
    assert!(recorded.suppressed[samples].iter().all(|v| *v));
}

fn assert_resumed(actual: &Recorded, old: &Recorded, new_samples: Range<usize>, old_start: usize) {
    for (offset, new_sample) in new_samples.enumerate() {
        let old_sample = old_start + offset;
        assert_eq!(
            actual.samples[new_sample],
            old.samples.get(old_sample).copied().unwrap_or([0.; 2]),
            "new sample {new_sample} must resume old sample {old_sample}"
        );
        assert_eq!(
            actual.suppressed[new_sample],
            old.suppressed.get(old_sample).copied().unwrap_or(true),
            "suppression at new {new_sample}, old {old_sample}"
        );
    }
}

#[test]
fn ntsc_44100_pause_at_an_existing_split_resumes_1602_and_exhausts_4804() {
    let (original, mut provider) = mono_original(2);
    let divided = split_command(&original, &id("source"), 1, "existing-cut");
    let inserted = insert_pause(&divided, 1, 1, "existing-seam-pause");
    let direct = insert_pause(&original, 1, 1, "interior-pause");
    // Original sample 1602 maps to source 100 + 1602 * 44100/48000.
    // This oracle uses the decoded WAV and canonical resampler, independently
    // of either the current plan or its retained placement/resume descriptors.
    let expected_resume = provider
        .source
        .prepare(
            ResampleRecipe::new(
                100..20_100,
                ratio(125_747, 80),
                AudioSample(0),
                ratio(147, 160),
                AudioSample(0)..AudioSample(128),
            )
            .unwrap(),
            AudioSample(0),
            128,
            TIMEOUT,
            &AtomicBool::new(false),
        )
        .unwrap()
        .samples;
    for faded in [false, true] {
        let old = record(&original, &mut provider, faded, &[256]);
        let before = record(&divided, &mut provider, faded, &[199, 7]);
        assert_eq!(before, old, "pure Split must not change the oracle");
        let actual = record(&inserted, &mut provider, faded, &[127, 3, 251]);
        assert_eq!(actual.samples.len(), 4805);
        assert_eq!(actual.samples[..1602], old.samples[..1602]);
        assert_eq!(actual.suppressed[..1602], old.suppressed[..1602]);
        assert_pause(&actual, 1602..3203);
        assert_resumed(&actual, &old, 3203..4805, 1602);
        if !faded {
            assert_eq!(actual.samples[3203..3331], expected_resume);
        }
        assert_eq!(actual.samples[4804], [0.; 2]);
        assert!(actual.suppressed[4804]);
        assert_eq!(record(&direct, &mut provider, faded, &[13, 256]), actual);
        assert_eq!(record(&inserted, &mut provider, faded, &[1, 239]), actual);
    }
}

#[test]
fn selected_original_window_survives_ntsc_split_pause_and_endpoint_exhaustion() {
    let (original, mut provider) = mono_original(2);
    let mut wire = serde_json::to_value(&original).unwrap();
    let NodeKind::Source { source } = &original.nodes()[&id("source")].kind else {
        unreachable!()
    };
    wire["nodes"]["source"]["kind"]["source"]["audio_mapping"] =
        serde_json::to_value(SourceAudioMapping::SelectedPlacement {
            start: ratio(-1, 7),
            frames: source
                .audio_mapping
                .duration_frames(source.duration)
                .unwrap(),
            selection: ExactFrameRange::new(ratio(1, 4), ratio(7, 4)).unwrap(),
        })
        .unwrap();
    wire["nodes"]["source"]["kind"]["source"]["audio_offset"] = serde_json::json!(-3);
    let original = ProjectDocument::from_json(&wire.to_string()).unwrap();
    let divided = split_command(&original, &id("source"), 1, "selected-split");
    let inserted = insert_pause(&divided, 1, 1, "selected-pause");
    for faded in [false, true] {
        let old = record(&original, &mut provider, faded, &[256]);
        assert_eq!(record(&divided, &mut provider, faded, &[7, 191]), old);
        let actual = record(&inserted, &mut provider, faded, &[3, 251]);
        assert_resumed(&actual, &old, 0..1602, 0);
        assert_pause(&actual, 1602..3203);
        assert_resumed(&actual, &old, 3203..4805, 1602);
        assert_eq!(record(&inserted, &mut provider, faded, &[127, 1]), actual);
    }
}

#[test]
fn inserting_before_several_split_fragments_reanchors_every_surviving_entry() {
    let (original, mut provider) = mono_original(5);
    let mut divided = split_command(&original, &id("source"), 1, "split-first");
    for (name, local) in [("split-second", 1), ("split-fourth", 2)] {
        let NodeKind::Sequence { children } = &divided.nodes()[divided.root()].kind else {
            unreachable!()
        };
        let target = children.last().unwrap().clone();
        divided = split_command(&divided, &target, local, name);
    }
    let inserted = insert_pause(&divided, 1, 1, "before-fragments");
    for faded in [false, true] {
        let old = record(&original, &mut provider, faded, &[256]);
        assert_eq!(record(&divided, &mut provider, faded, &[127]), old);
        let actual = record(&inserted, &mut provider, faded, &[251, 17]);
        assert_resumed(&actual, &old, 0..ntsc_boundary(1), 0);
        assert_pause(&actual, ntsc_boundary(1)..ntsc_boundary(2));
        for (start, end) in [(1, 2), (2, 4), (4, 5)] {
            assert_resumed(
                &actual,
                &old,
                ntsc_boundary(start + 1)..ntsc_boundary(end + 1),
                ntsc_boundary(start),
            );
        }
        assert_eq!(record(&inserted, &mut provider, faded, &[5, 256]), actual);
    }
}

#[test]
fn a_second_interior_pause_composes_the_current_resume_without_changing_its_prefix() {
    let (original, mut provider) = mono_original(6);
    let first = insert_pause(&original, 2, 1, "first-pause");
    let second = insert_pause(&first, 4, 2, "second-pause");
    for faded in [false, true] {
        let before = record(&first, &mut provider, faded, &[197, 256]);
        let actual = record(&second, &mut provider, faded, &[101, 13]);
        assert_resumed(&actual, &before, 0..ntsc_boundary(4), 0);
        assert_pause(&actual, ntsc_boundary(4)..ntsc_boundary(6));
        assert_resumed(
            &actual,
            &before,
            ntsc_boundary(6)..ntsc_boundary(9),
            ntsc_boundary(4),
        );
        assert_eq!(record(&second, &mut provider, faded, &[256, 1]), actual);
    }
}

#[test]
fn start_and_end_pauses_retain_hard_source_edges_room_tone_phase_and_silence() {
    let rate = FrameRate::new(48_000, 1).unwrap();
    let mut first = source(rate, 128, 0..128);
    first.audio_edges.node_start = AudioEdgePolicy::Hard;
    first.audio_edges.node_end = AudioEdgePolicy::Hard;
    let original = document_with_asset(
        rate,
        &["a", "room", "quiet", "b"],
        [
            ("a", first),
            ("room", room_tone(128, audio(512, 641))),
            ("quiet", hold(32)),
            ("b", source(rate, 128, 1024..1152)),
        ],
        BTreeMap::new(),
        audio(0, 8197).span,
    );
    let start = insert_pause(&original, 0, 17, "start-pause");
    let end = insert_pause(&start, 433, 13, "end-pause");
    let mut provider = FixtureProvider::new();
    for faded in [false, true] {
        let old = record(&original, &mut provider, faded, &[256]);
        let shifted = record(&start, &mut provider, faded, &[29, 199]);
        assert_pause(&shifted, 0..17);
        assert_resumed(&shifted, &old, 17..433, 0);
        let appended = record(&end, &mut provider, faded, &[37]);
        assert_resumed(&appended, &shifted, 0..433, 0);
        assert_pause(&appended, 433..446);
    }
}

#[test]
fn ntsc_pause_reanchors_room_tone_from_its_old_visible_entry() {
    let rate = FrameRate::new(30_000, 1001).unwrap();
    let original = document_with_asset(
        rate,
        &["quiet", "room"],
        [("quiet", hold(1)), ("room", room_tone(2, audio(512, 641)))],
        BTreeMap::new(),
        audio(0, 8197).span,
    );
    let inserted = insert_pause(&original, 1, 1, "room-pause");
    let mut provider = FixtureProvider::new();
    for faded in [false, true] {
        let old = record(&original, &mut provider, faded, &[256]);
        let actual = record(&inserted, &mut provider, faded, &[31, 223]);
        assert_resumed(&actual, &old, 0..1602, 0);
        assert_pause(&actual, 1602..3203);
        assert_resumed(&actual, &old, 3203..6406, 1602);
        assert_eq!(record(&inserted, &mut provider, faded, &[251, 7]), actual);
    }
}

#[test]
fn extending_moved_room_tone_retains_its_binding_and_uses_the_current_duration() {
    let rate = FrameRate::new(30_000, 1001).unwrap();
    let original = document_with_asset(
        rate,
        &["quiet", "room"],
        [("quiet", hold(1)), ("room", room_tone(2, audio(512, 641)))],
        BTreeMap::new(),
        audio(0, 8197).span,
    );
    let inserted = insert_pause(&original, 1, 1, "room-pause");
    let extend = |document: &ProjectDocument, name: &str| {
        let request = CommandRequest {
            project_id: document.project_id().clone(),
            expected_revision: document.revision_id().clone(),
            new_revision: RevisionId::new(name).unwrap(),
            command: Command::SetHoldDuration {
                node: id("room"),
                duration: duration(3),
            },
        };
        let edit = apply(document, &request).unwrap();
        let result = edit.forward.apply(document).unwrap();
        assert_eq!(edit.inverse.apply(&result).unwrap(), *document);
        result
    };
    let extended = extend(&inserted, "extend-moved-room");
    let reference = extend(&original, "extend-original-room");
    // The binding is a sampling clock, not a frozen copy of the old recipe.
    // Extending a Hold must not drop, recapture or mutate its historical clock.
    assert_eq!(extended.audio_bindings(), inserted.audio_bindings());
    let mut provider = FixtureProvider::new();
    for faded in [false, true] {
        let before = record(&inserted, &mut provider, faded, &[256]);
        let old_clock = record(&reference, &mut provider, faded, &[127]);
        let actual = record(&extended, &mut provider, faded, &[73, 199]);
        assert_resumed(&actual, &old_clock, 3203..8008, 1602);
        // New samples replace the old endpoint's zero extension in the
        // canonical 128-sample filter halo. Earlier raw PCM stays identical;
        // the shorter 96-sample creative end fade also relocates intentionally.
        let unchanged_end = 6406 - 128;
        for sample in 0..unchanged_end {
            assert_eq!(
                actual.samples[sample], before.samples[sample],
                "prefix sample {sample}, faded={faded}"
            );
        }
        assert!(
            actual.samples[6406..8007]
                .iter()
                .any(|sample| *sample != [0.; 2])
        );
        assert_eq!(actual.samples[8007], [0.; 2]);
        assert!(actual.suppressed[8007]);
    }
}

#[test]
fn extending_a_captured_repeat_hold_keeps_each_surviving_play_clock() {
    let rate = FrameRate::new(30_000, 1001).unwrap();
    let initial = document_with_asset(
        rate,
        &["quiet", "repeat"],
        [
            ("quiet", hold(1)),
            ("room", room_tone(2, audio(512, 641))),
            (
                "repeat",
                BeatNode {
                    framing: None,
                    label: "Twice".into(),
                    audio_treatments: Default::default(),
                    audio_editorial_edges: Default::default(),
                    audio_edges: Default::default(),
                    kind: NodeKind::Repeat {
                        child: id("room"),
                        iterations: IterationOrder::new(RevisionId::new("plays").unwrap(), 2)
                            .unwrap(),
                        gap: None,
                        escalation: None,
                    },
                    cutaways: Vec::new(),
                    captions: Vec::new(),
                },
            ),
        ],
        BTreeMap::new(),
        audio(0, 8197).span,
    );
    let bindings = capture_unbound_audio_bindings(
        &initial,
        AudioTimingId {
            allocation: RevisionId::new("repeat-capture").unwrap(),
            ordinal: 0,
        },
    )
    .unwrap();
    let mut wire = serde_json::to_value(&initial).unwrap();
    wire["audio_bindings"] = serde_json::to_value(bindings).unwrap();
    let captured = ProjectDocument::from_json(&wire.to_string()).unwrap();
    let request = CommandRequest {
        project_id: captured.project_id().clone(),
        expected_revision: captured.revision_id().clone(),
        new_revision: RevisionId::new("extend-repeat-room").unwrap(),
        command: Command::SetHoldDuration {
            node: id("room"),
            duration: duration(3),
        },
    };
    let edit = apply(&captured, &request).unwrap();
    let extended = edit.forward.apply(&captured).unwrap();
    assert_eq!(edit.inverse.apply(&extended).unwrap(), captured);
    // The new output placement may append a conservative Repeat reanchor,
    // while its sampling lattice and existing phase must remain unchanged.
    // The independent per-play PCM oracle below checks the audible result.
    let old_bindings = captured.audio_bindings();
    let new_bindings = extended.audio_bindings();
    assert_eq!(
        new_bindings.bindings()[&id("quiet")],
        old_bindings.bindings()[&id("quiet")]
    );
    let old_room = &old_bindings.bindings()[&id("room")];
    let new_room = &new_bindings.bindings()[&id("room")];
    assert_eq!(new_room.lattice, old_room.lattice);
    assert_eq!(new_room.resume, old_room.resume);
    assert!(new_room.reanchors.starts_with(&old_room.reanchors));
    for (timing, old_layout) in old_bindings.timings() {
        assert_eq!(&new_bindings.timings()[timing], old_layout);
    }
    let mut provider = FixtureProvider::new();
    for faded in [false, true] {
        let actual = record(&extended, &mut provider, faded, &[181, 23]);
        for (old_origin, current_start, current_end) in [(1, 1, 4), (3, 4, 7)] {
            let reference = document_with_asset(
                rate,
                &["quiet", "room"],
                [
                    ("quiet", hold(old_origin)),
                    ("room", room_tone(3, audio(512, 641))),
                ],
                BTreeMap::new(),
                audio(0, 8197).span,
            );
            let expected = record(&reference, &mut provider, faded, &[256]);
            assert_resumed(
                &actual,
                &expected,
                ntsc_boundary(current_start)..ntsc_boundary(current_end),
                ntsc_boundary(old_origin),
            );
        }
    }
}

#[test]
fn insertion_preserves_fractional_source_placement_offset_and_first_speech_sample() {
    for sign in [-1, 1] {
        let (original, mut provider) = mono_original(4);
        let mut wire = serde_json::to_value(&original).unwrap();
        let mut leaf = original.nodes()[&id("source")].clone();
        let NodeKind::Source { source } = &mut leaf.kind else {
            unreachable!()
        };
        source.audio_mapping = SourceAudioMapping::Placement {
            start: ratio(sign, 7),
            frames: source
                .audio_mapping
                .duration_frames(source.duration)
                .unwrap(),
        };
        source.audio_offset = AudioSample(3);
        wire["nodes"]["source"] = serde_json::to_value(leaf).unwrap();
        let original = ProjectDocument::from_json(&wire.to_string()).unwrap();
        let inserted = insert_pause(&original, 0, 1, "before-placed-source");
        for faded in [false, true] {
            let old = record(&original, &mut provider, faded, &[256]);
            let actual = record(&inserted, &mut provider, faded, &[37, 197]);
            assert_pause(&actual, 0..1602);
            assert_resumed(&actual, &old, 1602..8008, 0);
        }
    }
}

#[test]
fn a_pause_preserves_the_two_sample_creative_envelope_on_both_sides() {
    let rate = FrameRate::new(48_000, 1).unwrap();
    let original = document_with_asset(
        rate,
        &["source"],
        [("source", source(rate, 2, 0..2))],
        BTreeMap::new(),
        audio(0, 8197).span,
    );
    let inserted = insert_pause(&original, 1, 1, "tiny-pause");
    let mut provider = FixtureProvider::new();
    let old = record(&original, &mut provider, true, &[2]);
    let actual = record(&inserted, &mut provider, true, &[1]);
    assert_eq!(old.samples[0], fixture_sample(0).map(|v| v * 0.5));
    assert_eq!(old.samples[1], fixture_sample(1).map(|v| v * 0.5));
    assert_eq!(
        actual.samples,
        vec![old.samples[0], [0.; 2], old.samples[1]]
    );
    assert_eq!(actual.suppressed, vec![false, true, false]);
}

/// A 4-frame Original slowed to 8 project frames with tape-speed sound. A
/// pause inside it keeps the slope, so later audio resumes the old samples.
fn slowed_original() -> (ProjectDocument, FixtureProvider) {
    let (original, provider) = mono_original(4);
    let mut wire = serde_json::to_value(&original).unwrap();
    wire["nodes"]["slow"] =
        serde_json::to_value(retime("source", 8, 0..4, PitchPolicy::FollowSpeed)).unwrap();
    wire["nodes"]["root"]["kind"]["children"] = serde_json::json!(["slow"]);
    (
        ProjectDocument::from_json(&wire.to_string()).unwrap(),
        provider,
    )
}

fn nested_follow_speed_document(outer_frames: i64) -> (ProjectDocument, FixtureProvider) {
    let rate = FrameRate::new(30_000, 1001).unwrap();
    let selected = 100..20_100;
    let original = |frames| {
        let mut node = source(rate, frames, selected.clone());
        let NodeKind::Source { source } = &mut node.kind else {
            unreachable!()
        };
        let audio = audio_at_rate(selected.start, selected.end, 44_100);
        source.audio_mapping = SourceAudioMapping::natural_rate(audio.span, rate).unwrap();
        source.audio = Some(audio);
        node
    };
    let document = document_with_asset(
        rate,
        &["outer-speed", "root-tail"],
        [
            (
                "outer-speed",
                retime(
                    "outer-sequence",
                    outer_frames,
                    0..16,
                    PitchPolicy::FollowSpeed,
                ),
            ),
            (
                "outer-sequence",
                BeatNode::sequence(
                    "Outer",
                    vec![id("outer-before"), id("inner-speed"), id("outer-after")],
                ),
            ),
            ("outer-before", original(2)),
            (
                "inner-speed",
                retime("inner-sequence", 12, 0..18, PitchPolicy::FollowSpeed),
            ),
            (
                "inner-sequence",
                BeatNode::sequence(
                    "Inner",
                    vec![id("inner-before"), id("center"), id("inner-after")],
                ),
            ),
            ("inner-before", original(2)),
            ("center", original(14)),
            ("inner-after", original(2)),
            ("outer-after", original(2)),
            ("root-tail", original(4)),
        ],
        BTreeMap::new(),
        audio_at_rate(0, 44_117, 44_100).span,
    );
    let provider = FixtureProvider::from_fixture(
        "pcm-mono-44100.wav",
        AudioChannelLayout::Native {
            channels: 1,
            mask: 4,
        },
    );
    (document, provider)
}

#[test]
fn nested_follow_speed_pauses_keep_all_samples_across_unity_and_fractional_rate_products() {
    // Inner maps 18 child frames to 12. The outer stage maps 16 child frames
    // to 24 (the two stages' net rate is unity), 18 (net 4/3), or 12 (net twice).
    // Sequence siblings on both sides of both stages and after the outer
    // stage make the oracle cover every later owner clock, not just the crop.
    for (outer_frames, expected_frames, name) in [
        (24, 28, "nested-follow-unity"),
        (18, 22, "nested-follow-fractional"),
        (12, 16, "nested-follow-double"),
    ] {
        let (original, mut provider) = nested_follow_speed_document(outer_frames);
        for faded in [false, true] {
            let mut current = original.clone();
            // Physical Source entries have independent origin-rounded sample
            // clocks. In the unity case their root boundaries are 0,3,5,19,
            // 21,24,28. Scale only the outer subtree for the other two rates.
            let mut owners = [0, 3, 5, 19, 21, 24]
                .map(|frame| ratio(frame * i128::from(outer_frames), 24))
                .to_vec();
            owners.push(ExactRatio::integer(expected_frames));
            let mut pieces = owners
                .windows(2)
                .map(|window| RetainedPiece {
                    start: window[0],
                    end: window[1],
                    original: Some(exact_ntsc_boundary(window[0])..exact_ntsc_boundary(window[1])),
                })
                .collect::<Vec<_>>();
            let original_audio = record(&original, &mut provider, faded, &[127, 3, 251]);
            assert_eq!(original_audio.samples.len(), ntsc_boundary(expected_frames));
            assert!(original_audio.samples.iter().any(|sample| sample[0] != 0.));

            let mut inserted_frames = 0;
            for (at, frames, suffix) in [(7, 1, "first"), (9, 2, "second")] {
                let baseline = record(&current, &mut provider, faded, &[256]);
                let pause = insert_pause(&current, at, frames, &format!("{name}-{suffix}"));
                let actual = record(&pause, &mut provider, faded, &[127, 3, 251]);
                assert_eq!(
                    actual.samples.len(),
                    ntsc_boundary(expected_frames + inserted_frames + frames)
                );
                assert_resumed(&actual, &baseline, 0..ntsc_boundary(at), 0);
                assert_pause(&actual, ntsc_boundary(at)..ntsc_boundary(at + frames));
                pieces = insert_retained_pause(pieces, at, frames);
                assert_retained_pieces(&actual, &original_audio, &pieces);
                assert_eq!(record(&pause, &mut provider, faded, &[1, 239]), actual);
                current = pause;
                inserted_frames += frames;
            }

            // This pause is in the later root sibling, after the nested stages.
            // It catches a stale outer resume that might otherwise only show up
            // after leaving the retimed subtree.
            let at = outer_frames + inserted_frames + 1;
            let baseline = record(&current, &mut provider, faded, &[256]);
            let pause = insert_pause(&current, at, 1, &format!("{name}-root-tail"));
            let actual = record(&pause, &mut provider, faded, &[97, 256]);
            assert_resumed(&actual, &baseline, 0..ntsc_boundary(at), 0);
            assert_pause(&actual, ntsc_boundary(at)..ntsc_boundary(at + 1));
            pieces = insert_retained_pause(pieces, at, 1);
            assert_retained_pieces(&actual, &original_audio, &pieces);
            assert_eq!(
                actual.samples.len(),
                ntsc_boundary(expected_frames + inserted_frames + 1)
            );
            assert_eq!(record(&pause, &mut provider, faded, &[1, 239]), actual);
        }
    }
}

fn exact_ntsc_boundary(frame: ExactRatio) -> usize {
    usize::try_from(
        frame
            .checked_mul(ratio(8008, 5))
            .unwrap()
            .round_even()
            .unwrap(),
    )
    .unwrap()
}

#[derive(Clone)]
struct RetainedPiece {
    start: ExactRatio,
    end: ExactRatio,
    /// Immutable original render support, retained even when a current rounded
    /// owner endpoint temporarily hides its last sample.
    original: Option<Range<usize>>,
}

fn insert_retained_pause(pieces: Vec<RetainedPiece>, at: i64, frames: i64) -> Vec<RetainedPiece> {
    let cut = ExactRatio::integer(at);
    let delta = ExactRatio::integer(frames);
    let mut changed = Vec::new();
    for mut piece in pieces {
        if !piece.end.compare(cut).is_gt() {
            changed.push(piece);
        } else if !piece.start.compare(cut).is_lt() {
            piece.start = piece.start.checked_add(delta).unwrap();
            piece.end = piece.end.checked_add(delta).unwrap();
            changed.push(piece);
        } else {
            let offset = exact_ntsc_boundary(cut) - exact_ntsc_boundary(piece.start);
            let left_original = piece
                .original
                .as_ref()
                .map(|old| old.start..old.end.min(old.start + offset));
            let right_original = piece
                .original
                .map(|old| old.start.checked_add(offset).unwrap().min(old.end)..old.end);
            changed.push(RetainedPiece {
                start: piece.start,
                end: cut,
                original: left_original,
            });
            changed.push(RetainedPiece {
                start: cut.checked_add(delta).unwrap(),
                end: piece.end.checked_add(delta).unwrap(),
                original: right_original,
            });
        }
    }
    changed.push(RetainedPiece {
        start: cut,
        end: cut.checked_add(delta).unwrap(),
        original: None,
    });
    changed.sort_by(|a, b| a.start.compare(b.start));
    changed
}

fn assert_retained_pieces(actual: &Recorded, original: &Recorded, pieces: &[RetainedPiece]) {
    for piece in pieces {
        let current = exact_ntsc_boundary(piece.start)..exact_ntsc_boundary(piece.end);
        if let Some(support) = &piece.original {
            let retained = Recorded {
                samples: original.samples[support.clone()].to_vec(),
                suppressed: original.suppressed[support.clone()].to_vec(),
            };
            assert_resumed(actual, &retained, current, 0);
        } else {
            assert_pause(actual, current);
        }
    }
}

#[test]
fn pauses_inside_follow_speed_resume_the_old_samples_at_integral_and_fractional_cuts() {
    let (original, mut provider) = slowed_original();
    // Frame 3 cuts the child at 3/2. A two-frame pause spans one child frame;
    // a one-frame pause spans half of one and needs exact clocks throughout.
    for (frames, name) in [(2, "slow-pause-two"), (1, "slow-pause-one")] {
        let inserted = insert_pause(&original, 3, frames, name);
        // Frame 3 lands at child frame 3/2 in both cases.
        assert!(!inserted.derived_clocks().is_empty());
        for faded in [false, true] {
            let old = record(&original, &mut provider, faded, &[256]);
            assert!(old.samples[ntsc_boundary(3)..].iter().any(|v| v[0] != 0.));
            let actual = record(&inserted, &mut provider, faded, &[127, 3, 251]);
            let end = usize::try_from(8 + frames).unwrap();
            assert_eq!(actual.samples.len(), ntsc_boundary(end as i64));
            assert_resumed(&actual, &old, 0..ntsc_boundary(3), 0);
            assert_pause(&actual, ntsc_boundary(3)..ntsc_boundary(3 + frames));
            assert_resumed(
                &actual,
                &old,
                ntsc_boundary(3 + frames)..actual.samples.len(),
                ntsc_boundary(3),
            );
            assert_eq!(record(&inserted, &mut provider, faded, &[1, 239]), actual);
        }
        // A second pause after the first resumes on the composed clock.
        let twice = insert_pause(&inserted, 6 + frames, 1, &format!("{name}-again"));
        let first = record(&inserted, &mut provider, false, &[256]);
        let actual = record(&twice, &mut provider, false, &[64, 255]);
        let cut = ntsc_boundary(6 + frames);
        assert_resumed(&actual, &first, 0..cut, 0);
        assert_pause(&actual, cut..ntsc_boundary(7 + frames));
        assert_resumed(
            &actual,
            &first,
            ntsc_boundary(7 + frames)..actual.samples.len(),
            cut,
        );
    }
}

#[test]
fn a_pause_in_a_split_slowed_beat_and_at_root_seams_keeps_every_other_sample() {
    let (original, mut provider) = slowed_original();
    // Splitting at frame 4 copies the speed change beneath two windows; the
    // pause at frame 6 is inside the copy, at child frame 3.
    let divided = split_command(&original, &id("slow"), 4, "slow-cut");
    let old = record(&original, &mut provider, false, &[256]);
    assert_eq!(record(&divided, &mut provider, false, &[127]), old);
    let inserted = insert_pause(&divided, 6, 1, "split-pause");
    let actual = record(&inserted, &mut provider, false, &[64, 251]);
    assert_resumed(&actual, &old, 0..ntsc_boundary(6), 0);
    assert_pause(&actual, ntsc_boundary(6)..ntsc_boundary(7));
    assert_resumed(
        &actual,
        &old,
        ntsc_boundary(7)..actual.samples.len(),
        ntsc_boundary(6),
    );
    // With exact clocks present, a pause at the project start moves
    // everything, clocked speed changes included, on their own clocks.
    let clocked = insert_pause(&original, 3, 1, "clocked-pause");
    assert!(!clocked.derived_clocks().is_empty());
    let before = record(&clocked, &mut provider, false, &[256]);
    let shifted = insert_pause(&clocked, 0, 2, "start-pause");
    let actual = record(&shifted, &mut provider, false, &[99, 256]);
    assert_pause(&actual, 0..ntsc_boundary(2));
    // Each owner resumes on its own rounded boundary, not a common offset.
    assert_resumed(&actual, &before, ntsc_boundary(2)..ntsc_boundary(5), 0);
    assert_pause(&actual, ntsc_boundary(5)..ntsc_boundary(6));
    assert_resumed(
        &actual,
        &before,
        ntsc_boundary(6)..actual.samples.len(),
        ntsc_boundary(4),
    );
}

#[test]
fn lengthening_a_pause_inside_a_slowed_beat_resumes_the_same_later_samples() {
    let (original, mut provider) = slowed_original();
    let clocked = insert_pause(&original, 3, 1, "short-pause");
    let request = CommandRequest {
        project_id: clocked.project_id().clone(),
        expected_revision: clocked.revision_id().clone(),
        new_revision: RevisionId::new("longer-pause").unwrap(),
        command: Command::SetHoldDuration {
            node: id("short-pause-pause"),
            duration: duration(3),
        },
    };
    let transaction = apply(&clocked, &request).unwrap();
    assert_eq!(transaction.duration_delta, 2);
    let longer = transaction.forward.apply(&clocked).unwrap();
    assert_eq!(transaction.inverse.apply(&longer).unwrap(), clocked);
    let before = record(&clocked, &mut provider, false, &[256]);
    let actual = record(&longer, &mut provider, false, &[77, 256]);
    assert_resumed(&actual, &before, 0..ntsc_boundary(3), 0);
    assert_pause(&actual, ntsc_boundary(3)..ntsc_boundary(6));
    assert_resumed(
        &actual,
        &before,
        ntsc_boundary(6)..actual.samples.len(),
        ntsc_boundary(4),
    );
}

#[test]
fn a_pause_inside_a_pitch_preserving_speed_change_resumes_its_processed_output() {
    let (original, mut provider) = mono_original(4);
    let mut wire = serde_json::to_value(&original).unwrap();
    wire["nodes"]["slow"] =
        serde_json::to_value(retime("source", 8, 0..4, PitchPolicy::Preserve)).unwrap();
    wire["nodes"]["root"]["kind"]["children"] = serde_json::json!(["slow"]);
    let original = ProjectDocument::from_json(&wire.to_string()).unwrap();
    // With gain on the speed change, the pause lifts it to a group so it
    // applies once over both halves and the pause.
    let mut treated = wire.clone();
    treated["nodes"]["slow"]["audio_treatments"] =
        serde_json::to_value(AudioTreatments::from_clip_gain(
            ClipGain::new(GainDb::new(-6_000).unwrap(), false, vec![], vec![]).unwrap(),
        ))
        .unwrap();
    let treated = ProjectDocument::from_json(&treated.to_string()).unwrap();
    for (document, name) in [(original, "preserve-pause"), (treated, "treated-pause")] {
        let inserted = insert_pause(&document, 3, 2, name);
        assert!(inserted.derived_clocks().is_empty());
        for faded in [false, true] {
            let old = record(&document, &mut provider, faded, &[256]);
            assert!(old.samples[ntsc_boundary(3)..].iter().any(|v| v[0] != 0.));
            let actual = record(&inserted, &mut provider, faded, &[97, 256]);
            assert_eq!(actual.samples.len(), ntsc_boundary(10));
            assert_resumed(&actual, &old, 0..ntsc_boundary(3), 0);
            assert_pause(&actual, ntsc_boundary(3)..ntsc_boundary(5));
            assert_resumed(
                &actual,
                &old,
                ntsc_boundary(5)..actual.samples.len(),
                ntsc_boundary(3),
            );
        }
    }
}
