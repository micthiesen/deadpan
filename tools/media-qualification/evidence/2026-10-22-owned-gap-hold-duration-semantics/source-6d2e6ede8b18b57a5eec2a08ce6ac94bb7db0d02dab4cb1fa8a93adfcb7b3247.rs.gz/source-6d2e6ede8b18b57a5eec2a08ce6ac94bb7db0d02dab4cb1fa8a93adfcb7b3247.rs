#![cfg(any(target_os = "macos", target_os = "linux"))]

use std::{
    error::Error,
    fs,
    path::{Path, PathBuf},
    process::{Command, Output},
};

use deadpan_core::{
    AssetId, ExactRatio, FrameRate, FrameRateOrigin, GeometryOrigin, NodeId, NodeKind, SourceVideo,
};
use deadpan_media::audio_index::{AudioChannelLayout, AudioLayoutInterpretation};
use deadpan_store::{AccessMode, ProjectStore};
use rusqlite::Connection;
use serde_json::{Value, json};

type Result<T = ()> = std::result::Result<T, Box<dyn Error>>;

fn cli(arguments: &[&str]) -> Result<Output> {
    Ok(Command::new(env!("CARGO_BIN_EXE_deadpan-cli"))
        .args(arguments)
        .output()?)
}

fn success(arguments: &[&str]) -> Result<Value> {
    let output = cli(arguments)?;
    assert!(
        output.status.success(),
        "{}",
        String::from_utf8_lossy(&output.stderr)
    );
    Ok(serde_json::from_slice(&output.stdout)?)
}

fn failure(arguments: &[&str]) -> Result<Value> {
    let output = cli(arguments)?;
    assert!(!output.status.success());
    assert!(output.stdout.is_empty());
    Ok(serde_json::from_slice(&output.stderr)?)
}

fn create(package: &Path, fps: &str) -> Result<Value> {
    success(&[
        "project",
        "create",
        package.to_str().unwrap(),
        "--fps",
        fps,
        "--size",
        "320x180",
    ])
}

fn retain(package: &Path, source: &Path, bytes: &[u8], linked: bool) -> Result<Value> {
    fs::write(source, bytes)?;
    let mut arguments = vec![
        "project",
        "retain-original",
        package.to_str().unwrap(),
        source.to_str().unwrap(),
    ];
    if linked {
        arguments.push("--linked");
    }
    let value = success(&arguments)?;
    Ok(value["retained_original"]["record"]["object"]["content"].clone())
}

fn request(package: &Path, original: Value, streams: Value, next: &str) -> Result<Value> {
    let snapshot = ProjectStore::open(package, AccessMode::ReadOnly)?.snapshot()?;
    Ok(json!({
        "protocol": 1,
        "registration": {
            "expected_revision": snapshot.revision_id(), "new_revision": next,
            "original": original, "new_asset_id": "imported-asset", "label": "Qualified source",
            "insertion": {"parent": snapshot.root(), "index": 0, "node": "imported-source", "label": "Imported source"}
        },
        "streams": streams
    }))
}

fn save(directory: &Path, request: &Value) -> Result<PathBuf> {
    let path = directory.join("request.json");
    fs::write(&path, serde_json::to_vec(request)?)?;
    Ok(path)
}

fn registration(package: &Path, request: &Path, dry_run: bool, succeeds: bool) -> Result<Value> {
    let mut arguments = vec![
        "project",
        "register-source",
        package.to_str().unwrap(),
        "--request-json",
        request.to_str().unwrap(),
    ];
    if dry_run {
        arguments.push("--dry-run");
    }
    if succeeds {
        success(&arguments)
    } else {
        failure(&arguments)
    }
}

fn counts(package: &Path) -> Result<(u32, u32, u32)> {
    let connection = Connection::open(package.join("project.sqlite"))?;
    Ok(connection.query_row(
        "SELECT (SELECT count(*) FROM revisions), (SELECT count(*) FROM history), (SELECT count(*) FROM source_qualifications)",
        [], |row| Ok((row.get(0)?, row.get(1)?, row.get(2)?)),
    )?)
}

#[test]
fn cfr_registration_previews_beside_writer_commits_once_and_preserves_undo_receipt() -> Result {
    let scratch = tempfile::tempdir()?;
    let package = scratch.path().join("cfr.deadpan");
    create(&package, "30000/1001")?;
    let original = retain(
        &package,
        &scratch.path().join("source.mp4"),
        include_bytes!("../../../native/deadpan-source/tests/fixtures/cfr-bframes.mp4"),
        false,
    )?;
    let input = request(
        &package,
        original,
        json!({"type":"video_and_audio","audio_stream":1}),
        "registered",
    )?;
    let path = save(scratch.path(), &input)?;
    let writer = ProjectStore::open(&package, AccessMode::ReadWrite)?;
    let before = writer.snapshot()?;
    let preview = registration(&package, &path, true, true)?;
    assert_eq!(preview["protocol"], 1);
    assert_eq!(preview["committed"], false);
    assert_eq!(preview["preview"]["asset_id"], "imported-asset");
    assert!(preview["preview"]["edit"].is_object());
    assert!(preview.to_string().len() < 8192);
    assert_eq!(writer.snapshot()?, before);
    assert_eq!(counts(&package)?, (1, 0, 0));
    assert_eq!(
        registration(&package, &path, false, false)?["error"]["code"],
        "HostOwnerUnavailable"
    );
    drop(writer);
    fs::remove_file(scratch.path().join("source.mp4"))?;
    let outcome = registration(&package, &path, false, true)?;
    assert_eq!(outcome["committed"], true);
    assert_eq!(
        outcome["outcome"]["qualification"],
        preview["preview"]["qualification"]
    );
    assert_eq!(counts(&package)?, (2, 1, 1));
    let store = ProjectStore::open(&package, AccessMode::ReadOnly)?;
    let imported = store.snapshot()?;
    let asset = &imported.assets()[&AssetId::new("imported-asset")?];
    assert!(asset.video.is_some());
    assert!(asset.audio.is_some());
    let receipt = store.source_qualification(asset.source_qualification.as_ref().unwrap())?;
    assert_eq!(
        receipt
            .snapshot()
            .video()
            .unwrap()
            .index()
            .index()
            .frames()
            .len(),
        120
    );
    assert_eq!(receipt.snapshot().audio().unwrap().stream().stream_index, 1);
    assert_eq!(imported.presentation_basis(), before.presentation_basis());
    assert_eq!(imported.duration()?.frames(), 120);
    drop(store);

    let mut duplicate = input.clone();
    duplicate["registration"]["expected_revision"] = json!(imported.revision_id());
    duplicate["registration"]["new_revision"] = "unused-deduplicated-revision".into();
    duplicate["registration"]["new_asset_id"] = "unused-new-alias".into();
    duplicate["registration"]["insertion"] = Value::Null;
    let path = save(scratch.path(), &duplicate)?;
    let duplicate = registration(&package, &path, false, true)?;
    assert_eq!(duplicate["committed"], false);
    assert_eq!(duplicate["outcome"]["asset_id"], "imported-asset");
    assert!(duplicate["outcome"]["commit"].is_null());
    assert_eq!(counts(&package)?, (2, 1, 1));
    success(&[
        "project",
        "undo",
        package.to_str().unwrap(),
        "--expected",
        "registered",
    ])?;
    let undone = ProjectStore::open(&package, AccessMode::ReadOnly)?.snapshot()?;
    assert_eq!(undone.assets(), before.assets());
    assert_eq!(undone.nodes(), before.nodes());
    assert_eq!(counts(&package)?, (3, 1, 1));
    success(&[
        "project",
        "redo",
        package.to_str().unwrap(),
        "--expected",
        undone.revision_id().as_str(),
    ])?;
    let reopened = ProjectStore::open(&package, AccessMode::ReadOnly)?;
    reopened.validate()?;
    assert_eq!(reopened.snapshot()?.assets(), imported.assets());
    assert_eq!(reopened.snapshot()?.nodes(), imported.nodes());
    assert_eq!(counts(&package)?, (4, 1, 1));
    Ok(())
}

#[test]
fn offset_av_and_audio_only_register_exact_measured_placements() -> Result {
    for (name, bytes, streams, fps, expected_duration) in [
        (
            "offset",
            include_bytes!("../../../native/deadpan-source/tests/fixtures/offset-bframes.mp4")
                .as_slice(),
            json!({"type":"video_and_audio","audio_stream":1}),
            "30000/1001",
            121,
        ),
        (
            "audio",
            include_bytes!(
                "../../../native/deadpan-source/tests/audio-fixtures/pcm-mono-44100.wav"
            )
            .as_slice(),
            json!({"type":"audio_only","stream":0,"interpretation":"mono"}),
            "30/1",
            31,
        ),
    ] {
        let scratch = tempfile::tempdir()?;
        let package = scratch.path().join(format!("{name}.deadpan"));
        create(&package, fps)?;
        let original = retain(&package, &scratch.path().join("source.media"), bytes, false)?;
        let path = save(
            scratch.path(),
            &request(&package, original, streams, "registered")?,
        )?;
        registration(&package, &path, false, true)?;
        let store = ProjectStore::open(&package, AccessMode::ReadOnly)?;
        let document = store.snapshot()?;
        assert_eq!(document.duration()?.frames(), expected_duration);
        let NodeKind::Source { source } = &document.nodes()[&NodeId::new("imported-source")?].kind
        else {
            panic!()
        };
        let asset = &document.assets()[&AssetId::new("imported-asset")?];
        assert_eq!(source.audio_offset.0, 0);
        assert_eq!(source.audio_mapping.start_frames(), ExactRatio::ZERO);
        assert_eq!(source.audio.as_ref().unwrap().span, asset.audio.unwrap());
        if name == "offset" {
            assert_eq!(
                source.video_mapping.start_frames(),
                ExactRatio::new(640, 1001)?
            );
            assert_eq!(
                source.audio_mapping.duration_frames(source.duration)?,
                ExactRatio::new(120760, 1001)?
            );
            assert_eq!(asset.audio.unwrap().start().ticks, 95072);
            assert_eq!(asset.audio.unwrap().end().ticks, 288288);
            assert_eq!(asset.video.unwrap().start().ticks, 60060);
            assert_eq!(asset.video.unwrap().end().ticks, 180180);
        } else {
            assert!(matches!(source.video, SourceVideo::Blank));
            assert!(asset.video.is_none());
            assert_eq!(asset.audio.unwrap().end().ticks, 44117);
            assert_eq!(
                source.audio_mapping.duration_frames(source.duration)?,
                ExactRatio::new(44117, 1470)?
            );
            let receipt =
                store.source_qualification(asset.source_qualification.as_ref().unwrap())?;
            assert!(receipt.snapshot().video().is_none());
            assert_eq!(
                receipt.snapshot().audio().unwrap().stream().sample_rate,
                44100
            );
            assert_eq!(
                receipt.snapshot().audio_interpretation(),
                Some(AudioLayoutInterpretation::Mono)
            );
        }
        store.validate()?;
    }
    Ok(())
}

#[test]
fn protocol_is_required_and_rejected_before_opening_the_project() -> Result {
    let scratch = tempfile::tempdir()?;
    let package = scratch.path().join("protocol.deadpan");
    create(&package, "30000/1001")?;
    // Holding the writer proves malformed protocols never open a writable
    // store; the absent original also proves dry runs never reach decoding.
    let writer = ProjectStore::open(&package, AccessMode::ReadWrite)?;
    let valid = request(
        &package,
        json!({"algorithm":"blake3","digest":"a".repeat(64)}),
        json!({"type":"video_only"}),
        "never-committed",
    )?;
    for (protocol, expected) in [
        (Some(json!(999)), "ProtocolUnsupported"),
        (Some(json!(0)), "ProtocolUnsupported"),
        (Some(Value::Null), "InvalidInput"),
        (Some(json!("1")), "InvalidInput"),
        (None, "InvalidInput"),
    ] {
        let mut input = valid.clone();
        match protocol {
            Some(protocol) => input["protocol"] = protocol,
            None => {
                input.as_object_mut().unwrap().remove("protocol");
            }
        }
        let path = save(scratch.path(), &input)?;
        for dry_run in [false, true] {
            assert_eq!(
                registration(&package, &path, dry_run, false)?["error"]["code"],
                expected
            );
            assert_eq!(counts(&package)?, (1, 0, 0));
        }
    }
    assert!(writer.snapshot()?.assets().is_empty());
    Ok(())
}

#[test]
fn automatic_creation_adopts_first_inserted_picture_and_secondary_preserves_the_clock() -> Result {
    let scratch = tempfile::tempdir()?;
    for secondary in [false, true] {
        let package = scratch
            .path()
            .join(format!("automatic-{secondary}.deadpan"));
        let created = success(&["project", "create", package.to_str().unwrap()])?;
        assert_eq!(created["basis_state"]["rate_origin"], "provisional");
        let original = retain(
            &package,
            &scratch.path().join("source.mp4"),
            include_bytes!("../../../native/deadpan-source/tests/fixtures/cfr-bframes.mp4"),
            false,
        )?;
        let mut input = request(
            &package,
            original,
            json!({"type":"video_and_audio","audio_stream":1}),
            "inserted",
        )?;
        input["registration"]["insertion"]["purpose"] =
            json!(if secondary { "secondary" } else { "primary" });
        let file = save(scratch.path(), &input)?;
        let preview = registration(&package, &file, true, true)?;
        assert!(preview["preview"]["edit"]["forward"]["presentation"].is_object());
        registration(&package, &file, false, true)?;
        let store = ProjectStore::open(&package, AccessMode::ReadOnly)?;
        let current = store.snapshot()?;
        if secondary {
            assert_eq!(
                current.basis_state().rate_origin,
                FrameRateOrigin::TimedEdit
            );
            assert_eq!(
                current.presentation_basis().frame_rate,
                FrameRate::new(30, 1)?
            );
            assert!(current.basis_state().primary.is_none());
        } else {
            assert_eq!(
                current.basis_state().rate_origin,
                FrameRateOrigin::PrimarySource
            );
            assert_eq!(
                current.presentation_basis().frame_rate,
                FrameRate::new(30000, 1001)?
            );
            assert_eq!(current.duration()?.frames(), 120);
        }
    }
    Ok(())
}

#[test]
fn explicit_geometry_cli_previews_then_changes_only_canvas_and_keeps_version_guards() -> Result {
    let scratch = tempfile::tempdir()?;
    let package = scratch.path().join("geometry.deadpan");
    create(&package, "30000/1001")?;
    let original = retain(
        &package,
        &scratch.path().join("portrait.mp4"),
        include_bytes!("../../../native/deadpan-source/tests/fixtures/rotated90.mp4"),
        false,
    )?;
    let input = request(&package, original, json!({"type":"video_only"}), "picture")?;
    registration(&package, &save(scratch.path(), &input)?, false, true)?;
    let writer = ProjectStore::open(&package, AccessMode::ReadWrite)?;
    let before = writer.snapshot()?;
    assert_eq!(before.basis_state().rate_origin, FrameRateOrigin::Explicit);
    let mut input = json!({"protocol":1,"adoption":{"expected_revision":before.revision_id(),"new_revision":"geometry"}});
    let file = save(scratch.path(), &input)?;
    let mut args = vec![
        "project",
        "adopt-primary-geometry",
        package.to_str().unwrap(),
        "--request-json",
        file.to_str().unwrap(),
    ];
    assert_eq!(failure(&args)?["error"]["code"], "HostOwnerUnavailable");
    args.push("--dry-run");
    let preview = success(&args)?;
    assert_eq!(preview["committed"], false);
    assert!(
        preview["edit"]["forward"]["nodes"]
            .as_object()
            .unwrap()
            .is_empty()
    );
    assert_eq!(writer.snapshot()?, before);
    input["protocol"] = json!(999);
    save(scratch.path(), &input)?;
    assert_eq!(failure(&args)?["error"]["code"], "ProtocolUnsupported");
    input.as_object_mut().unwrap().remove("protocol");
    save(scratch.path(), &input)?;
    assert_eq!(failure(&args)?["error"]["code"], "InvalidInput");
    input["protocol"] = json!(1);
    save(scratch.path(), &input)?;
    drop(writer);
    args.pop();
    assert_eq!(success(&args)?["committed"], true);
    let after = ProjectStore::open(&package, AccessMode::ReadOnly)?.snapshot()?;
    assert_eq!(
        (
            after.presentation_basis().width,
            after.presentation_basis().height
        ),
        (2, 4)
    );
    assert_eq!(
        after.presentation_basis().frame_rate,
        before.presentation_basis().frame_rate
    );
    assert_eq!(
        after.basis_state().geometry_origin,
        GeometryOrigin::PrimarySource
    );
    assert_eq!(after.nodes(), before.nodes());
    assert_eq!(after.marks(), before.marks());
    assert_eq!(failure(&args)?["error"]["code"], "RevisionConflict");
    success(&[
        "project",
        "undo",
        package.to_str().unwrap(),
        "--expected",
        "geometry",
    ])?;
    assert_eq!(
        ProjectStore::open(&package, AccessMode::ReadOnly)?
            .snapshot()?
            .presentation_basis(),
        before.presentation_basis()
    );
    Ok(())
}

#[test]
fn unlabelled_wav_needs_an_explicit_interpretation_that_audio_preparation_then_uses() -> Result {
    let scratch = tempfile::tempdir()?;
    let package = scratch.path().join("plain-wav.deadpan");
    create(&package, "30/1")?;
    let original = retain(
        &package,
        &scratch.path().join("source.wav"),
        include_bytes!("../../../native/deadpan-source/tests/audio-fixtures/pcm-stereo-48000.wav"),
        false,
    )?;
    let mut input = request(
        &package,
        original,
        json!({"type":"audio_only","stream":0}),
        "registered",
    )?;
    // Without a choice, and with a choice for another channel count, nothing
    // is written and the refusal names the applicable choice.
    for (streams, chosen) in [
        (json!({"type":"audio_only","stream":0}), None),
        (
            json!({"type":"audio_only","stream":0,"interpretation":"mono"}),
            Some("Mono"),
        ),
    ] {
        input["streams"] = streams;
        let path = save(scratch.path(), &input)?;
        for dry_run in [true, false] {
            let error = registration(&package, &path, dry_run, false)?;
            assert_eq!(error["error"]["code"], "AudioLayoutInterpretationRequired");
            let message = error["error"]["message"].as_str().unwrap();
            assert!(message.contains("2 channel(s) with no declared speaker layout"));
            assert!(message.contains("Stereo L/R (stereo_left_right)"));
            assert_eq!(
                chosen.is_some(),
                message.contains("Mono (1 channel(s)) cannot")
            );
            assert_eq!(counts(&package)?, (1, 0, 0));
        }
    }
    input["streams"] = json!({"type":"invented"});
    let path = save(scratch.path(), &input)?;
    assert_eq!(
        registration(&package, &path, false, false)?["error"]["code"],
        "InvalidInput"
    );
    input["streams"] = json!({"type":"audio_only","stream":0,"interpretation":"surround"});
    let path = save(scratch.path(), &input)?;
    assert_eq!(
        registration(&package, &path, false, false)?["error"]["code"],
        "InvalidInput"
    );
    input["streams"] = json!({"type":"audio_only","stream":0,"interpretation":"stereo_left_right"});
    let path = save(scratch.path(), &input)?;
    registration(&package, &path, false, true)?;
    let store = ProjectStore::open(&package, AccessMode::ReadOnly)?;
    let document = store.snapshot()?;
    let asset = &document.assets()[&AssetId::new("imported-asset")?];
    let receipt = store.source_qualification(asset.source_qualification.as_ref().unwrap())?;
    // The measured stream still declares nothing; the choice is retained
    // beside it, never written over the measurement.
    assert_eq!(
        receipt.snapshot().audio().unwrap().stream().channel_layout,
        AudioChannelLayout::Unspecified { channels: 2 }
    );
    assert_eq!(
        receipt.snapshot().audio_interpretation(),
        Some(AudioLayoutInterpretation::StereoLeftRight)
    );
    assert_eq!(
        receipt.snapshot().audio_layout(),
        Some(AudioChannelLayout::Native {
            channels: 2,
            mask: 3
        })
    );
    drop(store);
    // Preparation reads the persisted interpretation instead of refusing the
    // undeclared layout (formerly AudioLayoutUnsupported).
    let audio = success(&[
        "inspect-audio",
        package.to_str().unwrap(),
        "--samples",
        "0",
        "256",
    ])?;
    assert_eq!(audio["protocol"], 1);
    // Stereo L/R keeps the two channels separate: the fixture's opening
    // left/right impulse pair stays on its own side.
    assert_eq!(audio["audio"]["samples"][0], json!([0.75, -1.0]));
    assert_eq!(
        audio["audio"]["samples"][1],
        json!([-0.75, 0.999969482421875])
    );
    Ok(())
}

#[test]
fn stream_selection_is_required_and_failed_audio_never_becomes_video_only() -> Result {
    let scratch = tempfile::tempdir()?;
    let package = scratch.path().join("streams.deadpan");
    create(&package, "30000/1001")?;
    let original = retain(
        &package,
        &scratch.path().join("source.mp4"),
        include_bytes!("../../../native/deadpan-source/tests/fixtures/cfr-bframes.mp4"),
        false,
    )?;
    let mut input = request(
        &package,
        original,
        json!({"type":"video_and_audio","audio_stream":0}),
        "registered",
    )?;
    let path = save(scratch.path(), &input)?;
    assert_eq!(
        registration(&package, &path, false, false)?["error"]["code"],
        "SourceAudioDecodeFailed"
    );
    assert_eq!(counts(&package)?, (1, 0, 0));
    for invalid in [
        Value::Null,
        json!({"type":"video_and_audio"}),
        json!({"type":"video_only","audio_stream":1}),
    ] {
        input["streams"] = invalid;
        let path = save(scratch.path(), &input)?;
        assert_eq!(
            registration(&package, &path, false, false)?["error"]["code"],
            "InvalidInput"
        );
        assert_eq!(counts(&package)?, (1, 0, 0));
    }
    input.as_object_mut().unwrap().remove("streams");
    let path = save(scratch.path(), &input)?;
    assert_eq!(
        registration(&package, &path, false, false)?["error"]["code"],
        "InvalidInput"
    );
    input["streams"] = json!({"type":"video_only"});
    let path = save(scratch.path(), &input)?;
    registration(&package, &path, false, true)?;
    let store = ProjectStore::open(&package, AccessMode::ReadOnly)?;
    let document = store.snapshot()?;
    let asset = &document.assets()[&AssetId::new("imported-asset")?];
    assert!(asset.video.is_some());
    assert!(asset.audio.is_none());
    let receipt = store.source_qualification(asset.source_qualification.as_ref().unwrap())?;
    assert_eq!(
        receipt
            .snapshot()
            .video()
            .unwrap()
            .interpretation()
            .audio_streams
            .len(),
        1
    );
    assert!(receipt.snapshot().audio().is_none());
    Ok(())
}

#[test]
fn stale_revision_is_checked_before_unavailable_original_bytes() -> Result {
    let scratch = tempfile::tempdir()?;
    let package = scratch.path().join("stale.deadpan");
    create(&package, "30000/1001")?;
    let source = scratch.path().join("source.mp4");
    let original = retain(
        &package,
        &source,
        include_bytes!("../../../native/deadpan-source/tests/fixtures/cfr-bframes.mp4"),
        true,
    )?;
    let mut input = request(
        &package,
        original,
        json!({"type":"video_and_audio","audio_stream":1}),
        "registered",
    )?;
    let current = input["registration"]["expected_revision"].clone();
    input["registration"]["expected_revision"] = "stale-revision".into();
    fs::remove_file(source)?;
    let path = save(scratch.path(), &input)?;
    for dry_run in [true, false] {
        let error = registration(&package, &path, dry_run, false)?;
        assert_eq!(error["error"]["code"], "RevisionConflict");
        assert_eq!(error["error"]["current_revision"], current);
    }
    input["registration"]["expected_revision"] = current;
    let path = save(scratch.path(), &input)?;
    assert_eq!(
        registration(&package, &path, true, false)?["error"]["code"],
        "OriginalOffline"
    );
    assert_eq!(counts(&package)?, (1, 0, 0));
    Ok(())
}

#[test]
fn pending_generation_is_reconciled_by_the_boundary_resolver_on_commit() -> Result {
    let scratch = tempfile::tempdir()?;
    let package = scratch.path().join("generation.deadpan");
    create(&package, "30000/1001")?;
    let mut store = ProjectStore::open(&package, AccessMode::ReadWrite)?;
    let initial = store.snapshot()?;
    let hold = NodeId::new("pending-hold")?;
    store.commit(&deadpan_core::CommandRequest {
        project_id: initial.project_id().clone(),
        expected_revision: initial.revision_id().clone(),
        new_revision: deadpan_core::RevisionId::new("insert-pending-hold")?,
        command: deadpan_core::Command::Insert {
            parent: initial.root().clone(),
            index: 0,
            subtree: deadpan_core::Subtree {
                root: hold.clone(),
                nodes: std::collections::BTreeMap::from([(
                    hold.clone(),
                    deadpan_core::BeatNode::hold(
                        "Pending Hold",
                        deadpan_core::HoldRecipe {
                            picture_context: None,
                            duration: deadpan_core::FrameDuration::new(12)?,
                            video: deadpan_core::HoldVideo::Background,
                            audio: deadpan_core::HoldAudio::Silence,
                        },
                    ),
                )]),
                overrides: Default::default(),
                gap_overrides: Default::default(),
            },
        },
    })?;
    let before_generation = store.snapshot()?;
    let generation = store.allocate_generation_request(
        deadpan_store::generation::GenerationRequestInput {
            request_id: serde_json::from_value(json!("pending-generation"))?,
            expected_revision: before_generation.revision_id().clone(),
            hold_id: hold,
            context_sha256: serde_json::from_value(json!("a".repeat(64)))?,
            constraints: serde_json::from_value(json!({
                "video": {"frames": 12, "frame_rate": before_generation.presentation_basis().frame_rate,
                          "width": 768, "height": 320},
                "conditioning": "bridge", "motion": "still"
            }))?,
            provider: serde_json::from_value(json!({
                "pack_id": "fixture", "pack_version": "1", "runtime_id": "fixture",
                "runtime_version": "1", "seed": 7
            }))?,
        },
    )?;
    drop(store);
    let original = retain(
        &package,
        &scratch.path().join("source.mp4"),
        include_bytes!("../../../native/deadpan-source/tests/fixtures/cfr-bframes.mp4"),
        false,
    )?;
    let input = request(
        &package,
        original,
        json!({"type":"video_and_audio","audio_stream":1}),
        "registered",
    )?;
    let path = save(scratch.path(), &input)?;
    let before = ProjectStore::open(&package, AccessMode::ReadOnly)?.snapshot()?;
    let before_counts = counts(&package)?;
    assert!(registration(&package, &path, true, true)?["preview"]["edit"].is_object());
    assert_eq!(counts(&package)?, before_counts, "a preview writes nothing");
    // The CLI writer reconciles the pending request through the boundary
    // context resolver instead of refusing the registration.
    let committed = registration(&package, &path, false, true)?;
    assert!(committed.get("error").is_none(), "{committed}");
    let reader = ProjectStore::open(&package, AccessMode::ReadOnly)?;
    assert_ne!(reader.snapshot()?, before);
    let after = reader.generation_request(&generation.request_id)?.unwrap();
    let unchanged =
        deadpan_cli::generation_context::context_identity(&before, &generation.binding.hold_id)
            == deadpan_cli::generation_context::context_identity(
                &reader.snapshot()?,
                &generation.binding.hold_id,
            );
    assert_eq!(
        after.relevance,
        if unchanged {
            deadpan_jobs::Relevance::Current
        } else {
            deadpan_jobs::Relevance::Stale
        },
        "relevance follows the Hold's boundary context"
    );
    Ok(())
}

#[path = "source_registration/roll.rs"]
mod roll;
#[path = "source_registration/slip.rs"]
mod slip;
#[path = "source_registration/trim.rs"]
mod trim;

#[path = "source_registration/beat_sounds.rs"]
mod beat_sounds;
#[path = "source_registration/combined_trim.rs"]
mod combined_trim;
#[path = "source_registration/mp3.rs"]
mod mp3;
#[path = "source_registration/wide_pcm.rs"]
mod wide_pcm;
