use std::io;
use std::panic::{AssertUnwindSafe, catch_unwind};
use std::sync::atomic::{AtomicBool, AtomicU64, Ordering};
use std::sync::{Arc, Condvar, Mutex, MutexGuard};
use std::thread;
use std::time::{Duration, Instant};

use deadpan_audio::{PreparationActivity, PreparationMonitor};
use deadpan_core::{AudioSample, ProjectId, RevisionId};
use deadpan_output::{
    ClockPosition, DeliveryClock, DeviceReport, Feed, FeedError, Generation, RenderStatus,
    StopToken,
};

use crate::preparation::{self, Batch, Reply};
use crate::{ContentIdentity, Snapshot, Target, Window};

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum Phase {
    Preparing,
    Playing,
    Stopped,
    Ended,
    Failed,
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Update {
    pub ticket: u64,
    pub session: u64,
    pub project_id: ProjectId,
    pub revision_id: RevisionId,
    pub content: ContentIdentity,
    pub phase: Phase,
    pub sample: Option<AudioSample>,
    pub generation: Option<Generation>,
    pub error: Option<String>,
    /// Current request's worker observation; never advances the heard clock.
    pub preparation: Option<Preparation>,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct Preparation {
    pub activity: PreparationActivity,
    /// Actual request age, rounded down to 100 ms, with no estimated completion.
    pub elapsed_millis: u64,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, thiserror::Error)]
pub enum RequestError {
    #[error("monitor gain must be finite and between zero and one")]
    InvalidGain,
    #[error("playback start must be nonnegative and inside the audition window")]
    InvalidStart,
    #[error("audition window must be nonnegative and ordered, with a nonempty loop")]
    InvalidWindow,
    #[error("playback engine has shut down")]
    Shutdown,
    #[error("playback request identities are exhausted")]
    Exhausted,
}

pub(crate) struct Job {
    pub epoch: u64,
    pub ticket: u64,
    pub snapshot: Arc<Snapshot>,
    pub target: Target,
    pub window: Option<Window>,
    pub start: AudioSample,
    pub gain: f32,
    pub cancelled: AtomicBool,
    pub monitor: Arc<PreparationMonitor>,
    warming: Option<Arc<crate::warming::Job>>,
    started: Instant,
}

impl Job {
    fn cancel(&self) {
        self.cancelled.store(true, Ordering::Release);
        if let Some(warming) = &self.warming {
            warming.cancelled.store(true, Ordering::Release);
        }
    }
    fn update(
        &self,
        phase: Phase,
        generation: Option<Generation>,
        sample: Option<AudioSample>,
        error: Option<String>,
    ) -> Update {
        Update {
            ticket: self.ticket,
            session: self.snapshot.session,
            project_id: self.snapshot.document.project_id().clone(),
            revision_id: self.snapshot.document.revision_id().clone(),
            content: self.snapshot.content.clone(),
            phase,
            sample,
            generation,
            error,
            preparation: (phase == Phase::Preparing).then(|| {
                let millis = u64::try_from(self.started.elapsed().as_millis()).unwrap_or(u64::MAX);
                Preparation {
                    activity: self.monitor.activity(),
                    elapsed_millis: millis / 100 * 100,
                }
            }),
        }
    }
}

enum Intent {
    Play(Arc<Job>),
    Stop,
}

pub(crate) struct State {
    epoch: u64,
    shutdown: bool,
    intent: Option<Intent>,
    current: Option<Arc<Job>>,
    token: Option<StopToken>,
    pub prep: Option<Arc<Job>>,
    pub reply: preparation::Queue,
    update: Option<Update>,
    output_quiescent: bool,
    pub waveform: crate::waveform::State,
    pub warming: crate::warming::State,
}
impl State {
    pub(crate) fn shutdown(&self) -> bool {
        self.shutdown
    }
    pub(crate) fn can_analyze(&self) -> bool {
        self.output_quiescent && self.intent.is_none() && self.prep.is_none() && !self.shutdown
    }
}

/// Cumulative device-delivery counters for diagnostics since the engine was
/// created. They are observations only: they never enter authored state and
/// never change a playback decision. A starved or faulted report still ends
/// its generation explicitly; these counts make that attributable.
#[derive(Debug, Clone, Copy, Default, PartialEq, Eq)]
pub struct Diagnostics {
    /// Output generations activated on the device.
    pub generations: u64,
    /// Device reports observed for an active generation.
    pub reports: u64,
    /// Reports whose queue ran dry while playing (audio underruns).
    pub starved: u64,
    /// Device faults: faulted reports, error flags or lost report records.
    pub faults: u64,
    /// Silent padding frames rendered for an active generation.
    pub silent_frames: u64,
    /// Largest measured kernel render cost of one device callback.
    pub max_render_cost_ns: u64,
}

#[derive(Default)]
struct Counters {
    generations: AtomicU64,
    reports: AtomicU64,
    starved: AtomicU64,
    faults: AtomicU64,
    silent_frames: AtomicU64,
    max_render_cost_ns: AtomicU64,
}

impl Counters {
    fn observe(&self, report: &DeviceReport) {
        self.reports.fetch_add(1, Ordering::Relaxed);
        match report.render.status {
            RenderStatus::Starved => {
                self.starved.fetch_add(1, Ordering::Relaxed);
            }
            RenderStatus::Fault => {
                self.faults.fetch_add(1, Ordering::Relaxed);
            }
            RenderStatus::Paused | RenderStatus::Playing | RenderStatus::Ended => {}
        }
        self.silent_frames.fetch_add(
            u64::try_from(report.render.silent_frames).unwrap_or(u64::MAX),
            Ordering::Relaxed,
        );
        self.max_render_cost_ns
            .fetch_max(report.render_cost_ns, Ordering::Relaxed);
    }
    fn snapshot(&self) -> Diagnostics {
        Diagnostics {
            generations: self.generations.load(Ordering::Relaxed),
            reports: self.reports.load(Ordering::Relaxed),
            starved: self.starved.load(Ordering::Relaxed),
            faults: self.faults.load(Ordering::Relaxed),
            silent_frames: self.silent_frames.load(Ordering::Relaxed),
            max_render_cost_ns: self.max_render_cost_ns.load(Ordering::Relaxed),
        }
    }
}

pub(crate) struct Shared {
    state: Mutex<State>,
    pub wake: Condvar,
    repaint: Arc<dyn Fn() + Send + Sync>,
    counters: Counters,
    pub(crate) warming_guard: Arc<dyn Fn() -> Option<String> + Send + Sync>,
    pub(crate) audio_cache_root: Option<std::path::PathBuf>,
    #[cfg(test)]
    pub preparation_observer: Mutex<Option<preparation::Observer>>,
    #[cfg(test)]
    pub controller_hooks: ControllerHooks,
}

/// Test-only controller instrumentation. `stall` parks the controller thread
/// at the top of its loop, standing in for descheduling under CPU load while
/// the device callback keeps running. `stall_at_activation` sets `stall` when
/// the controller starts the device, so it supplies nothing beyond the prefill.
#[cfg(test)]
#[derive(Default)]
pub(crate) struct ControllerHooks {
    pub stall: AtomicBool,
    pub stall_at_activation: AtomicBool,
    pub stalled: AtomicBool,
    pub submitted_frames: AtomicU64,
}

impl Shared {
    pub(crate) fn lock(&self) -> MutexGuard<'_, State> {
        self.state.lock().unwrap_or_else(|error| error.into_inner())
    }
    pub(crate) fn repaint(&self) {
        (self.repaint)();
    }
    #[cfg(test)]
    pub(crate) fn observe_preparation(
        &self,
        event: preparation::PreparationEvent,
        cancelled: &AtomicBool,
    ) {
        let observer = self
            .preparation_observer
            .lock()
            .unwrap_or_else(|error| error.into_inner())
            .clone();
        if let Some(observer) = observer {
            observer(event, cancelled);
        }
    }
    pub(crate) fn publish(&self, job: &Job, update: Update) {
        let mut state = self.lock();
        if state
            .current
            .as_ref()
            .is_some_and(|current| current.epoch == job.epoch)
            && !state.shutdown
            && !matches!(state.intent, Some(Intent::Stop))
        {
            let changed = state.update.as_ref() != Some(&update);
            state.update = Some(update);
            drop(state);
            if changed {
                (self.repaint)();
            }
        }
    }
    fn stop(&self, shutdown: bool, interrupt_analysis: bool) {
        let mut state = self.lock();
        if let Some(job) = &state.current {
            job.cancel();
        }
        if let Some(token) = &state.token {
            token.stop();
        }
        state.shutdown |= shutdown;
        state
            .warming
            .interrupt("Audio warming stopped by a lifecycle interruption");
        let analysis_changed = if shutdown {
            state.waveform.shutdown();
            false
        } else if interrupt_analysis {
            state
                .waveform
                .interrupt("Waveform analysis stopped by a lifecycle interruption")
        } else {
            false
        };
        state.output_quiescent = false;
        state.intent = Some(Intent::Stop);
        state.prep = None;
        state.reply.clear();
        drop(state);
        self.wake.notify_all();
        if analysis_changed {
            self.repaint();
        }
    }
    pub(crate) fn worker_failed(&self, worker: &str) {
        let mut state = self.lock();
        state
            .warming
            .interrupt("Audio preparation worker terminated unexpectedly");
        if let Some(token) = &state.token {
            token.stop();
        }
        if let Some(job) = &state.current {
            job.cancel();
            state.update = Some(job.update(
                Phase::Failed,
                state.token.as_ref().map(StopToken::generation),
                None,
                Some(format!("{worker} worker terminated unexpectedly")),
            ));
        }
        state
            .waveform
            .fail(&format!("{worker} worker terminated unexpectedly"));
        state.shutdown = true;
        state.output_quiescent = false;
        state.intent = Some(Intent::Stop);
        state.prep = None;
        state.reply.clear();
        drop(state);
        self.wake.notify_all();
        (self.repaint)();
    }
}

/// Bounded revocation for lifecycle callbacks. It keeps no device, SQLite
/// connection, or shutdown ownership and never waits for worker teardown.
#[derive(Clone)]
pub struct StopHandle {
    shared: Arc<Shared>,
}
impl StopHandle {
    pub fn stop(&self) {
        self.shared.stop(false, true);
    }
}

/// Owns two persistent threads. `stop`/`shutdown` revoke the current output
/// generation immediately; cooperative media teardown completes on its worker.
/// Dropping the engine requests shutdown without blocking a native UI thread.
pub struct Engine {
    pub(crate) shared: Arc<Shared>,
}

impl Engine {
    pub fn new(repaint: Arc<dyn Fn() + Send + Sync>) -> io::Result<Self> {
        Self::with_audio_cache(repaint, deadpan_audio::persistent_pcm::default_root())
    }

    /// Explicit cache location for isolated hosts and qualification runs.
    /// Opening the directory remains preparation-worker work.
    pub fn with_audio_cache(
        repaint: Arc<dyn Fn() + Send + Sync>,
        root: Option<std::path::PathBuf>,
    ) -> io::Result<Self> {
        Self::with_factory_guard_cache(repaint, Box::new(open_device), Arc::new(|| None), root)
    }

    /// Host policy for optional idle work, evaluated only on the preparation
    /// worker. Direct playback is not subject to this gate; the host must keep
    /// each check bounded so in-flight idle work can yield the worker promptly.
    pub fn with_warming_guard(
        repaint: Arc<dyn Fn() + Send + Sync>,
        guard: Arc<dyn Fn() -> Option<String> + Send + Sync>,
    ) -> io::Result<Self> {
        Self::with_factory_guard_cache(
            repaint,
            Box::new(open_device),
            guard,
            deadpan_audio::persistent_pcm::default_root(),
        )
    }

    #[cfg(test)]
    pub(crate) fn with_factory(
        repaint: Arc<dyn Fn() + Send + Sync>,
        factory: Factory,
    ) -> io::Result<Self> {
        Self::with_factory_and_guard(repaint, factory, Arc::new(|| None))
    }

    #[cfg(test)]
    pub(crate) fn with_factory_and_guard(
        repaint: Arc<dyn Fn() + Send + Sync>,
        factory: Factory,
        warming_guard: Arc<dyn Fn() -> Option<String> + Send + Sync>,
    ) -> io::Result<Self> {
        Self::with_factory_guard_cache(repaint, factory, warming_guard, None)
    }

    fn with_factory_guard_cache(
        repaint: Arc<dyn Fn() + Send + Sync>,
        factory: Factory,
        warming_guard: Arc<dyn Fn() -> Option<String> + Send + Sync>,
        audio_cache_root: Option<std::path::PathBuf>,
    ) -> io::Result<Self> {
        let shared = Arc::new(Shared {
            state: Mutex::new(State {
                epoch: 0,
                shutdown: false,
                intent: None,
                current: None,
                token: None,
                prep: None,
                reply: Default::default(),
                update: None,
                output_quiescent: true,
                waveform: Default::default(),
                warming: Default::default(),
            }),
            wake: Condvar::new(),
            repaint,
            counters: Counters::default(),
            warming_guard,
            audio_cache_root,
            #[cfg(test)]
            preparation_observer: Mutex::new(None),
            #[cfg(test)]
            controller_hooks: ControllerHooks::default(),
        });
        let prep_shared = shared.clone();
        thread::Builder::new()
            .name("deadpan-pcm-preparation".into())
            .spawn(move || {
                if catch_unwind(AssertUnwindSafe(|| preparation::run(prep_shared.clone()))).is_err()
                {
                    prep_shared.worker_failed("audio preparation");
                }
            })?;
        let control_shared = shared.clone();
        if let Err(error) = thread::Builder::new()
            .name("deadpan-playback-control".into())
            .spawn(move || {
                if catch_unwind(AssertUnwindSafe(|| run(control_shared.clone(), factory))).is_err()
                {
                    control_shared.worker_failed("audio device control");
                }
            })
        {
            shared.stop(true, true);
            return Err(error);
        }
        Ok(Self { shared })
    }

    pub fn play(
        &self,
        ticket: u64,
        snapshot: Arc<Snapshot>,
        start: AudioSample,
        monitor_gain: f32,
    ) -> Result<(), RequestError> {
        self.play_target(ticket, snapshot, Target::Sequence, start, monitor_gain)
    }

    pub fn play_target(
        &self,
        ticket: u64,
        snapshot: Arc<Snapshot>,
        target: Target,
        start: AudioSample,
        monitor_gain: f32,
    ) -> Result<(), RequestError> {
        self.request(ticket, snapshot, target, None, start, monitor_gain)
    }

    pub fn play_window(
        &self,
        ticket: u64,
        snapshot: Arc<Snapshot>,
        target: Target,
        window: Window,
        delivery_start: AudioSample,
        monitor_gain: f32,
    ) -> Result<(), RequestError> {
        if window.sample(delivery_start).is_none() {
            return Err(RequestError::InvalidStart);
        }
        self.request(
            ticket,
            snapshot,
            target,
            Some(window),
            delivery_start,
            monitor_gain,
        )
    }

    fn request(
        &self,
        ticket: u64,
        snapshot: Arc<Snapshot>,
        target: Target,
        window: Option<Window>,
        start: AudioSample,
        monitor_gain: f32,
    ) -> Result<(), RequestError> {
        if !monitor_gain.is_finite() || !(0.0..=1.0).contains(&monitor_gain) {
            return Err(RequestError::InvalidGain);
        }
        if start.0 < 0 {
            return Err(RequestError::InvalidStart);
        }
        let mut state = self.shared.lock();
        if state.shutdown {
            return Err(RequestError::Shutdown);
        }
        let epoch = state.epoch.checked_add(1).ok_or(RequestError::Exhausted)?;
        // Close the analysis gate before publishing the play intent. The
        // controller cannot reopen it until its device owner has gone away.
        state.output_quiescent = false;
        state
            .waveform
            .interrupt("Waveform analysis interrupted by audition");
        if let Some(job) = &state.current {
            job.cancel();
        }
        if let Some(token) = &state.token {
            token.stop();
        }
        let warming = state.warming.promote(&snapshot, &target, start);
        let monitor = warming.as_ref().map_or_else(
            || {
                Arc::new(PreparationMonitor::new(
                    PreparationActivity::PreparingOutput,
                ))
            },
            |warming| Arc::clone(&warming.monitor),
        );
        let job = Arc::new(Job {
            epoch,
            ticket,
            snapshot,
            target,
            window,
            start,
            gain: monitor_gain,
            cancelled: AtomicBool::new(false),
            monitor,
            warming,
            started: Instant::now(),
        });
        state.epoch = epoch;
        state.current = Some(job.clone());
        state.intent = Some(Intent::Play(job.clone()));
        state.prep = None;
        state.reply.clear();
        state.update = Some(job.update(Phase::Preparing, None, None, None));
        drop(state);
        self.shared.wake.notify_all();
        (self.shared.repaint)();
        Ok(())
    }
    pub fn stop(&self) {
        self.shared.stop(false, false);
    }
    pub fn stop_handle(&self) -> StopHandle {
        StopHandle {
            shared: self.shared.clone(),
        }
    }
    pub fn poll(&self) -> Option<Update> {
        self.shared.lock().update.take()
    }
    /// Cumulative delivery counters; cheap atomic loads, safe from any thread.
    pub fn diagnostics(&self) -> Diagnostics {
        self.shared.counters.snapshot()
    }
    pub fn saved_audio_status(&self) -> Option<deadpan_audio::SavedAudioStatus> {
        let state = self.shared.lock();
        state
            .current
            .as_ref()
            .and_then(|job| job.monitor.saved_audio_status())
            .or_else(|| state.warming.saved_audio_status())
    }
    pub fn shutdown(&self) {
        self.shared.stop(true, true);
    }
}
impl Drop for Engine {
    fn drop(&mut self) {
        self.shutdown();
    }
}

// The native stream is constructed, used, and dropped on this one thread. It
// need not implement Send. Tests inject a real queue with a headless callback.
pub(crate) trait Device {
    fn feed(&mut self) -> &mut Feed;
    fn start(&mut self) -> Result<(), String>;
    fn pause(&mut self) -> Result<(), String>;
    fn check_route(&self) -> Result<(), String>;
    fn pop_report(&mut self) -> Option<DeviceReport>;
    /// Reports already published and not yet popped.
    fn pending_reports(&self) -> usize;
    /// Fixed delivery-report ring capacity, for loss diagnostics.
    fn report_capacity(&self) -> usize;
    fn now_ns(&self) -> Option<u64>;
    fn dropped_reports(&self) -> u64;
    fn error_flags(&self) -> u64;
}
type Factory = Box<dyn FnMut() -> Result<Box<dyn Device>, String> + Send>;

#[cfg(target_os = "macos")]
impl Device for deadpan_output::DeviceOutput {
    fn feed(&mut self) -> &mut Feed {
        self.feed()
    }
    fn start(&mut self) -> Result<(), String> {
        self.start_device().map_err(|e| e.to_string())
    }
    fn pause(&mut self) -> Result<(), String> {
        self.pause_device().map_err(|e| e.to_string())
    }
    fn check_route(&self) -> Result<(), String> {
        self.check_route().map_err(|e| e.to_string())
    }
    fn pop_report(&mut self) -> Option<DeviceReport> {
        self.pop_report()
    }
    fn pending_reports(&self) -> usize {
        self.pending_reports()
    }
    fn report_capacity(&self) -> usize {
        self.report_capacity()
    }
    fn now_ns(&self) -> Option<u64> {
        self.clock_now_ns()
    }
    fn dropped_reports(&self) -> u64 {
        self.dropped_reports()
    }
    fn error_flags(&self) -> u64 {
        self.error_flags()
    }
}
#[cfg(target_os = "macos")]
fn open_device() -> Result<Box<dyn Device>, String> {
    // Prepared PCM and delivery telemetry both cover the documented controller
    // starvation window, so a descheduled controller neither starves the
    // device nor loses the reports that define the heard clock.
    deadpan_output::DeviceOutput::open_default_with_queue(deadpan_output::AUDITION_QUEUE_PACKETS)
        .map(|device| Box::new(device) as Box<dyn Device>)
        .map_err(|e| e.to_string())
}
#[cfg(not(target_os = "macos"))]
fn open_device() -> Result<Box<dyn Device>, String> {
    Err("native audition output requires macOS".into())
}

struct Active {
    job: Arc<Job>,
    device: Box<dyn Device>,
    generation: Generation,
    token: StopToken,
    batch: Option<Batch>,
    offset: usize,
    clock: Option<DeliveryClock>,
    activated: bool,
    queued: usize,
    /// This generation's device-queue depth in process diagnostics.
    device_queue: deadpan_diagnostics::Share,
    finished: bool,
    terminal_report: bool,
    last_sample: Option<AudioSample>,
    last_report: Instant,
    last_clock: Option<(u64, Instant)>,
    last_route: Instant,
    uncovered: Option<Instant>,
    last_preparation: Instant,
}

impl Active {
    fn open(job: Arc<Job>, device: Box<dyn Device>, shared: &Shared) -> Result<Self, String> {
        let mut device = device;
        let generation = device
            .feed()
            .restart(job.start.0)
            .map_err(|e| e.to_string())?;
        let token = device
            .feed()
            .stop_token(generation)
            .map_err(|e| e.to_string())?;
        let mut state = shared.lock();
        if job.cancelled.load(Ordering::Acquire)
            || state.shutdown
            || !state
                .current
                .as_ref()
                .is_some_and(|current| current.epoch == job.epoch)
        {
            token.stop();
            return Err("playback request was superseded".into());
        }
        state.token = Some(token.clone());
        state.prep = Some(job.clone());
        drop(state);
        shared.wake.notify_all();
        shared.publish(
            &job,
            job.update(Phase::Preparing, Some(generation), None, None),
        );
        let now = Instant::now();
        Ok(Self {
            job,
            device,
            generation,
            token,
            batch: None,
            offset: 0,
            clock: None,
            activated: false,
            queued: 0,
            device_queue: deadpan_diagnostics::Share::new(
                &deadpan_diagnostics::QUEUES.playback_device_packets,
            ),
            finished: false,
            terminal_report: false,
            last_sample: None,
            last_report: now,
            last_clock: None,
            last_route: now,
            uncovered: None,
            last_preparation: now,
        })
    }

    fn stop(&mut self) {
        self.job.cancel();
        self.token.stop();
        // Native pause failure is reported by the caller only when no stronger
        // failure already explains this terminated generation.
    }

    fn tick(&mut self, shared: &Shared) -> Result<Option<Phase>, String> {
        if self.token.is_stopped() {
            return Ok(Some(Phase::Stopped));
        }
        // This capability check reads only revocation atomics. Queued private
        // PCM cannot extend an edited proposal's owning store session.
        self.job
            .snapshot
            .check_media_live(&self.job.cancelled)
            .map_err(|error| error.to_string())?;
        if self.device.error_flags() != 0 {
            shared.counters.faults.fetch_add(1, Ordering::Relaxed);
            return Err("audio device faulted".into());
        }
        let dropped = self.device.dropped_reports();
        if dropped != 0 {
            shared.counters.faults.fetch_add(1, Ordering::Relaxed);
            return Err(format!(
                "audio delivery reports were lost: {dropped} dropped after the controller \
                 left all {} retained reports undrained (sized for {} ms of starvation)",
                self.device.report_capacity(),
                deadpan_output::STARVATION_WINDOW_FRAMES as u64 * 1000
                    / u64::from(deadpan_output::SAMPLE_RATE),
            ));
        }
        if self.last_route.elapsed() >= Duration::from_millis(250) {
            self.device.check_route()?;
            self.last_route = Instant::now();
        }
        // Always drain, including old preparation/paused and terminal records.
        // Only this active generation contributes to the heard-position clock.
        // Drain the complete inventory published before this tick, however
        // long the controller was descheduled. The bound is the ring capacity,
        // so the loop is finite while the callback keeps publishing; later
        // records stay queued in order for the next tick. Genuine overflow is
        // reported by the device's dropped-record counter above. Watchdogs
        // compare against instants captured with their observations, so
        // descheduling between draining and checking cannot fabricate a stall.
        let drained_at = Instant::now();
        for _ in 0..self.device.pending_reports() {
            let Some(report) = self.device.pop_report() else {
                break;
            };
            if report.render.generation != self.generation || !self.activated {
                continue;
            }
            shared.counters.observe(&report);
            if report.render.status == RenderStatus::Fault {
                return Err("audio output has faulted".into());
            }
            if self.terminal_report {
                continue;
            }
            self.last_report = drained_at;
            let terminal = matches!(
                report.render.status,
                RenderStatus::Ended | RenderStatus::Starved
            );
            let clock = self
                .clock
                .as_mut()
                .ok_or("active playback has no delivery clock")?;
            clock.observe(report).map_err(|e| e.to_string())?;
            if terminal {
                self.terminal_report = true;
                // Stop producing, but retain already submitted prefix timing.
                // This is separate from external generation revocation.
                shared.lock().prep = None;
                self.job.cancel();
                shared.wake.notify_all();
            }
        }
        if !self.terminal_report {
            self.supply(shared)?;
        }
        if !self.activated && self.last_preparation.elapsed() >= Duration::from_millis(100) {
            shared.publish(
                &self.job,
                self.job
                    .update(Phase::Preparing, Some(self.generation), None, None),
            );
            self.last_preparation = Instant::now();
        }
        self.device_queue
            .set(self.device.feed().queued_packets() as u64);
        #[cfg(test)]
        shared
            .controller_hooks
            .submitted_frames
            .store(self.queued as u64, Ordering::Release);
        if self.activated {
            let now = self
                .device
                .now_ns()
                .ok_or("audio stream clock is unavailable")?;
            let read_at = Instant::now();
            if let Some((previous, progressed)) = self.last_clock {
                if now < previous {
                    return Err("audio stream clock moved backwards".into());
                }
                if now == previous
                    && read_at.saturating_duration_since(progressed) > Duration::from_secs(1)
                {
                    return Err("audio stream clock stopped advancing".into());
                }
                if now > previous {
                    self.last_clock = Some((now, read_at));
                }
            } else {
                self.last_clock = Some((now, read_at));
            }
            if !self.terminal_report
                && drained_at.saturating_duration_since(self.last_report) > Duration::from_secs(1)
            {
                return Err("audio device stopped reporting delivery".into());
            }
            match self
                .clock
                .as_ref()
                .ok_or("missing delivery clock")?
                .position(now)
            {
                ClockPosition::Content { sample } => {
                    self.uncovered = None;
                    self.last_sample = Some(AudioSample(sample));
                    shared.publish(
                        &self.job,
                        self.job.update(
                            Phase::Playing,
                            Some(self.generation),
                            self.last_sample,
                            None,
                        ),
                    );
                }
                ClockPosition::Terminal {
                    status: RenderStatus::Ended,
                    end_sample,
                } => {
                    self.last_sample = Some(AudioSample(end_sample));
                    return Ok(Some(Phase::Ended));
                }
                ClockPosition::Terminal { status, end_sample } => {
                    self.last_sample = Some(AudioSample(end_sample));
                    return Err(format!("audio output stopped: {status:?}"));
                }
                position @ (ClockPosition::Gap { .. } | ClockPosition::Pending) => {
                    // No known delivered interval: hold picture position.
                    let limit = if matches!(position, ClockPosition::Pending) {
                        Duration::from_secs(2)
                    } else {
                        Duration::from_millis(250)
                    };
                    if self.uncovered.get_or_insert_with(Instant::now).elapsed() > limit {
                        return Err("audio delivery clock has no covering content interval".into());
                    }
                }
            }
        }
        Ok(None)
    }

    fn supply(&mut self, shared: &Shared) -> Result<(), String> {
        if self.batch.is_none() && !self.finished {
            // Pop in order, updating this engine's diagnostic shares under the
            // same lock. The native callback never touches this FIFO.
            let reply = {
                let mut state = shared.lock();
                state.reply.pop()
            };
            if let Some(reply) = reply {
                shared.wake.notify_all();
                match reply {
                    Reply::Batch(batch) if batch.epoch == self.job.epoch => {
                        if self.clock.is_none() {
                            self.clock = Some(
                                DeliveryClock::new(self.generation, self.job.start.0, batch.end.0)
                                    .map_err(|e| e.to_string())?,
                            );
                        }
                        if batch.start.0 != self.device.feed().next_sample() {
                            return Err("prepared PCM is discontinuous".into());
                        }
                        self.batch = Some(batch);
                        self.offset = 0;
                    }
                    Reply::Failed { epoch, error } if epoch == self.job.epoch => return Err(error),
                    _ => {}
                }
            }
        }
        if let Some(batch) = &self.batch {
            while self.offset < batch.samples.len() {
                let end = (self.offset + deadpan_output::PACKET_FRAMES).min(batch.samples.len());
                match self
                    .device
                    .feed()
                    .submit(self.generation, &batch.samples[self.offset..end])
                {
                    Ok(()) => {
                        self.queued += end - self.offset;
                        self.offset = end;
                    }
                    Err(FeedError::Full) => break,
                    Err(error) => return Err(error.to_string()),
                }
            }
            if self.offset == batch.samples.len() {
                if batch.eos {
                    match self.device.feed().finish(self.generation) {
                        Ok(()) => self.finished = true,
                        Err(FeedError::Full) => return Ok(()),
                        Err(error) => return Err(error.to_string()),
                    }
                }
                self.batch = None;
            }
        }
        if !self.activated && (self.queued >= preparation::BATCH_FRAMES || self.finished) {
            deadpan_diagnostics::QUEUES
                .playback_prefill_frames
                .set(self.queued as u64);
            self.device
                .feed()
                .activate(self.generation)
                .map_err(|e| e.to_string())?;
            self.device.start()?;
            self.activated = true;
            shared.counters.generations.fetch_add(1, Ordering::Relaxed);
            self.last_report = Instant::now();
            #[cfg(test)]
            if shared
                .controller_hooks
                .stall_at_activation
                .swap(false, Ordering::AcqRel)
            {
                shared.controller_hooks.stall.store(true, Ordering::Release);
            }
        }
        Ok(())
    }
}

fn run(shared: Arc<Shared>, mut factory: Factory) {
    let mut active: Option<Active> = None;
    loop {
        #[cfg(test)]
        while shared.controller_hooks.stall.load(Ordering::Acquire) {
            shared
                .controller_hooks
                .stalled
                .store(true, Ordering::Release);
            thread::sleep(Duration::from_millis(1));
        }
        #[cfg(test)]
        shared
            .controller_hooks
            .stalled
            .store(false, Ordering::Release);
        let (intent, shutdown) = {
            let mut state = shared.lock();
            (state.intent.take(), state.shutdown)
        };
        if shutdown {
            if let Some(mut old) = active.take() {
                old.stop();
                let _ = old.device.pause();
            }
            return;
        }
        if let Some(intent) = intent {
            if let Some(mut old) = active.take() {
                old.stop();
                let pause_error = old.device.pause().err();
                if matches!(intent, Intent::Stop) {
                    let phase = if pause_error.is_some() {
                        Phase::Failed
                    } else {
                        Phase::Stopped
                    };
                    shared.publish(
                        &old.job,
                        old.job
                            .update(phase, Some(old.generation), old.last_sample, pause_error),
                    );
                }
            } else if matches!(intent, Intent::Stop) {
                let job = shared.lock().current.clone();
                if let Some(job) = job {
                    shared.publish(&job, job.update(Phase::Stopped, None, None, None));
                }
            }
            if let Intent::Play(job) = intent {
                if job.cancelled.load(Ordering::Acquire) {
                    continue;
                }
                match factory().and_then(|device| Active::open(job.clone(), device, &shared)) {
                    Ok(new) => active = Some(new),
                    Err(error) => {
                        shared.publish(&job, job.update(Phase::Failed, None, None, Some(error)))
                    }
                }
            }
        }
        if let Some(current) = &mut active {
            let result = current.tick(&shared);
            match result {
                Ok(None) => {}
                result => {
                    current.stop();
                    shared.lock().reply.discard(current.job.epoch);
                    let pause_error = current.device.pause().err();
                    let (phase, error) = match result {
                        Ok(Some(phase)) if pause_error.is_none() => (phase, None),
                        Ok(_) => (Phase::Failed, pause_error),
                        Err(error) => (Phase::Failed, Some(error)),
                    };
                    shared.publish(
                        &current.job,
                        current.job.update(
                            phase,
                            Some(current.generation),
                            current.last_sample,
                            error,
                        ),
                    );
                    active = None;
                    shared.wake.notify_all();
                }
            }
        }
        let mut state = shared.lock();
        // `Active` survives terminal reports until the delivery clock reaches
        // their submitted prefix deadline. Only its actual teardown opens the
        // idle analysis lane. A newer play/stop intent closes it under this lock.
        let quiescent = active.is_none() && state.intent.is_none() && !state.shutdown;
        let changed = state.output_quiescent != quiescent;
        state.output_quiescent = quiescent;
        if changed {
            shared.wake.notify_all();
        }
        if state.intent.is_none() && !state.shutdown {
            let timeout = if active.is_some() {
                Duration::from_millis(2)
            } else {
                Duration::from_millis(20)
            };
            drop(
                shared
                    .wake
                    .wait_timeout(state, timeout)
                    .unwrap_or_else(|error| error.into_inner()),
            );
        }
    }
}
