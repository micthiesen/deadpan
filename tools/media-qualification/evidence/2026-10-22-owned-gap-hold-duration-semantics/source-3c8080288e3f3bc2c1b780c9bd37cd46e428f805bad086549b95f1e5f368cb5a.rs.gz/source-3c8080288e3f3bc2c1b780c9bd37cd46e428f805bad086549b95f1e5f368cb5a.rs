use std::path::PathBuf;

#[derive(Debug, thiserror::Error)]
pub enum StoreError {
    #[error("Named takes are invalid: {0}")]
    Takes(String),
    #[error("Project registers are invalid: {0}")]
    Registers(String),
    #[error("Publication journal is invalid: {0}")]
    Publication(String),
    #[error("Render job metadata is invalid: {0}")]
    RenderJob(String),
    #[cfg(any(target_os = "macos", target_os = "linux"))]
    #[error(transparent)]
    RenderMedia(#[from] crate::render_media::RenderMediaError),
    #[error("Project package must have a .deadpan extension")]
    PackageExtension,
    #[error("A project package already exists at {0}")]
    PackageAlreadyExists(PathBuf),
    #[error("Project storage entry is missing, has the wrong type, or is a symbolic link: {0}")]
    UnsafePath(PathBuf),
    #[error("Another process owns this project; close its writable session before editing")]
    AlreadyOpen,
    #[error("This project was opened read-only")]
    ReadOnly,
    #[error(
        "The project is on a read-only volume ({0}); copy it to a writable folder, such as Documents/Deadpan, to open it"
    )]
    ReadOnlyLocation(PathBuf),
    #[error("Project host ownership is unavailable: {0}")]
    HostOwner(&'static str),
    #[error("Unsupported database schema {0}; the project has not been rewritten")]
    UnsupportedSchema(u32),
    #[error(
        "This project was saved by a newer Deadpan (database schema {found}; this build supports {supported}). It can only be opened read-only; nothing in it has been changed"
    )]
    NewerSchema { found: u32, supported: u32 },
    #[error(
        "Project schema {0} requires migration; run `deadpan-cli project migrate <project.deadpan>` to back up and upgrade its complete history"
    )]
    MigrationRequired(u32),
    #[error(
        "Migration promotion could not acquire the SQLite write lock; the original project remains unchanged"
    )]
    MigrationBusy,
    #[error("Migration failed; retained backup at {backup}: {source}")]
    MigrationFailed {
        backup: PathBuf,
        #[source]
        source: Box<StoreError>,
    },
    #[error("This database is not a Deadpan project")]
    WrongApplication,
    #[error("Project revision {0} has already been used; supply a new revision ID")]
    RevisionReused(String),
    #[error("Revision conflict: expected {expected}, current revision is {current}")]
    RevisionConflict { expected: String, current: String },
    #[error("There is no edit to undo")]
    NothingToUndo,
    #[error("There is no edit to redo")]
    NothingToRedo,
    #[error("Generation request ID {0} has already been used")]
    GenerationRequestReused(String),
    #[error("Generation target is invalid: {0}")]
    GenerationTarget(String),
    #[error("Current generation requests require an explicit complete relevance plan")]
    GenerationRelevanceRequired,
    #[error("Generation relevance plan is invalid: {0}")]
    GenerationPlan(String),
    #[error("Generation input query failed: {0}")]
    GenerationInputQuery(deadpan_plan::PlanError),
    #[error("Generation input capture exceeded its {0} limit")]
    GenerationInputLimit(&'static str),
    #[error("Generation input mode is unavailable: {0}")]
    GenerationInputMode(deadpan_jobs::GenerationModeError),
    #[error("Generation request versions are exhausted for Hold {0}")]
    GenerationVersionExhausted(String),
    #[error("Generation attempt {attempt} has already been used for request {request}")]
    GenerationAttemptReused { request: String, attempt: String },
    #[error("Generation attempt {attempt} does not exist for request {request}")]
    GenerationAttemptNotFound { request: String, attempt: String },
    #[error("Generation attempt ordinals are exhausted for request {0}")]
    GenerationAttemptExhausted(String),
    #[error("Generation progress and scheduling are live data and are not persisted")]
    GenerationProgressNotPersistent,
    #[error("Generation attempt transition is invalid: {0}")]
    GenerationAttempt(String),
    #[error(
        "New generated providers require the dedicated qualified candidate acceptance transaction"
    )]
    GeneratedAcceptanceUnavailable,
    #[error("Generated bundle acceptance is invalid: {0}")]
    GenerationAcceptance(String),
    #[error("New source qualifications require decoded-source registration")]
    SourceAdmissionUnavailable,
    #[error("Source-derived presentation changes require the qualified source host")]
    SourceBasisAdmissionUnavailable,
    #[error("Source registration is invalid: {0}")]
    SourceRegistration(String),
    #[error("Single-source project workflow is invalid: {0}")]
    SingleSource(String),
    #[cfg(any(target_os = "macos", target_os = "linux"))]
    #[error(transparent)]
    SourceQualification(#[from] deadpan_media::source_qualification::SourceQualificationError),
    #[cfg(any(target_os = "macos", target_os = "linux"))]
    #[error(transparent)]
    GeneratedMedia(#[from] crate::generated_media::GeneratedMediaError),
    #[cfg(any(target_os = "macos", target_os = "linux"))]
    #[error(transparent)]
    OriginalMedia(#[from] crate::original_media::OriginalMediaError),
    #[error("The analysis corrections did not change: {0}")]
    AnalysisCorrections(String),
    #[error("Analysis was not saved: {0}")]
    AnalysisInterrupted(String),
    #[error("Project storage: {0}")]
    Storage(String),
    #[error("Project history is inconsistent: {0}")]
    History(String),
    #[error("Project integrity check failed: {0}")]
    Integrity(String),
    #[error(transparent)]
    Io(#[from] std::io::Error),
    #[error(transparent)]
    Database(#[from] rusqlite::Error),
    #[error(transparent)]
    Document(#[from] deadpan_core::DocumentError),
    #[error(transparent)]
    Edit(#[from] deadpan_core::EditError),
    #[error(transparent)]
    Json(#[from] serde_json::Error),
}

impl StoreError {
    /// Stable protocol codes shared by GUI and headless callers.
    pub fn code(&self) -> &'static str {
        match self {
            Self::Takes(_) => "TakesInvalid",
            Self::Registers(_) => "RegistersInvalid",
            Self::Publication(_) => "PublicationInvalid",
            Self::RenderJob(_) => "RenderJobInvalid",
            #[cfg(any(target_os = "macos", target_os = "linux"))]
            Self::RenderMedia(error) => error.code(),
            Self::PackageAlreadyExists(_) => "PackageAlreadyExists",
            Self::AlreadyOpen => "ProjectAlreadyOpen",
            Self::ReadOnly | Self::ReadOnlyLocation(_) => "ProjectReadOnly",
            Self::HostOwner(_) => "HostOwnerUnavailable",
            Self::UnsupportedSchema(_) => "SchemaUnsupported",
            Self::NewerSchema { .. } => "SchemaNewer",
            Self::MigrationRequired(_) => "MigrationRequired",
            Self::MigrationBusy => "ProjectBusy",
            Self::MigrationFailed { source, .. } => match source.code() {
                code @ ("DiskFull" | "PermissionDenied" | "ProjectBusy" | "ProjectReadOnly"
                | "IoFailure") => code,
                _ => "MigrationFailed",
            },
            Self::RevisionReused(_) => "RevisionReused",
            Self::RevisionConflict { .. } => "RevisionConflict",
            Self::NothingToUndo => "NothingToUndo",
            Self::NothingToRedo => "NothingToRedo",
            Self::AnalysisCorrections(_) => "AnalysisCorrectionsConflict",
            Self::AnalysisInterrupted(_) => "AnalysisInterrupted",
            Self::SingleSource(_) => "SingleSourceInvalid",
            Self::Storage(_) => "StorageFailure",
            Self::GenerationRequestReused(_) => "GenerationRequestReused",
            Self::GenerationTarget(_) => "GenerationTargetInvalid",
            Self::GenerationRelevanceRequired => "GenerationRelevanceRequired",
            Self::GenerationPlan(_) | Self::GenerationInputQuery(_) | Self::GenerationInputLimit(_) | Self::GenerationInputMode(_) => "GenerationPlanInvalid",
            Self::GenerationVersionExhausted(_) => "GenerationVersionExhausted",
            Self::GenerationAttemptReused { .. } => "GenerationAttemptReused",
            Self::GenerationAttemptNotFound { .. } => "GenerationAttemptNotFound",
            Self::GenerationAttemptExhausted(_) => "GenerationAttemptExhausted",
            Self::GenerationProgressNotPersistent => "GenerationProgressNotPersistent",
            Self::GenerationAttempt(_) => "GenerationAttemptInvalid",
            Self::GeneratedAcceptanceUnavailable => "GeneratedAcceptanceUnavailable",
            Self::GenerationAcceptance(_) => "GenerationAcceptanceInvalid",
            Self::SourceAdmissionUnavailable => "SourceAdmissionUnavailable",
            Self::SourceBasisAdmissionUnavailable => "SourceBasisAdmissionUnavailable",
            Self::SourceRegistration(_) => "SourceRegistrationInvalid",
            #[cfg(any(target_os = "macos", target_os = "linux"))]
            Self::SourceQualification(
                deadpan_media::source_qualification::SourceQualificationError::AudioLayoutInterpretation(_),
            ) => "AudioLayoutInterpretationRequired",
            #[cfg(any(target_os = "macos", target_os = "linux"))]
            Self::SourceQualification(_) => "SourceQualificationInvalid",
            #[cfg(any(target_os = "macos", target_os = "linux"))]
            Self::GeneratedMedia(error) => error.code(),
            #[cfg(any(target_os = "macos", target_os = "linux"))]
            Self::OriginalMedia(error) => error.code(),
            Self::Edit(error) => error.code.as_str(),
            Self::Database(rusqlite::Error::SqliteFailure(error, _)) => match error.code {
                rusqlite::ErrorCode::DiskFull => "DiskFull",
                rusqlite::ErrorCode::ReadOnly => "ProjectReadOnly",
                rusqlite::ErrorCode::PermissionDenied => "PermissionDenied",
                rusqlite::ErrorCode::DatabaseBusy | rusqlite::ErrorCode::DatabaseLocked => {
                    "ProjectBusy"
                }
                _ => "ProjectFailure",
            },
            Self::Io(error) => match error.kind() {
                std::io::ErrorKind::StorageFull | std::io::ErrorKind::QuotaExceeded => "DiskFull",
                std::io::ErrorKind::ReadOnlyFilesystem => "ProjectReadOnly",
                std::io::ErrorKind::PermissionDenied => "PermissionDenied",
                _ => "IoFailure",
            },
            _ => "ProjectFailure",
        }
    }
}
