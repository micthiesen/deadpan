use std::fs::File;
use std::io::{self, Read, Seek, SeekFrom, Write};
use std::os::unix::process::CommandExt;
use std::path::Path;
use std::process::{Child, Command, ExitStatus, Stdio};
use std::sync::atomic::{AtomicBool, Ordering};
use std::time::{Duration, Instant};

use deadpan_core::{BridgeSamplingMap, GeneratedContentId, GeneratedObjectRef};
use rustix::fs::{OFlags, fcntl_getfl, fcntl_setfl};
use rustix::process::{Pid, WaitId, WaitIdOptions, waitid};
use sha2::{Digest, Sha256};
use thiserror::Error;

use crate::protocol::{
    BridgeConversionRequest, ContractError, ConversionReport, ConversionRequest, MAX_REPLY_BYTES,
    MAX_REQUEST_BYTES, PROTOCOL_VERSION, WorkerReply, WorkerRequest,
};
use crate::source_index::SourceContentIdentity;
use crate::source_input::{SourceInputError, VerifiedSourceInput};

mod extension;
mod proxy;
mod remux;
pub use extension::{CanonicalExtension, canonicalize_extension, sample_extension};
pub use proxy::{
    PROXY_STALL_TIMEOUT, ProxyEncodeOptions, WORKER_TERMINATED, assemble_proxy, encode_proxy,
    encode_proxy_retrying, retryable,
};
pub use remux::{RemuxLimits, append_for_remux, remux_av, remux_joined};

const GROUP_CLEANUP_GRACE: Duration = Duration::from_millis(250);

/// SHA-256 of the closed worker artifact supplied by its declared manifest.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct InputIdentity {
    pub sha256: [u8; 32],
}

#[derive(Debug, Error)]
pub enum ConversionError {
    #[error(transparent)]
    Contract(#[from] ContractError),
    #[error("media conversion I/O: {0}")]
    Io(#[from] io::Error),
    #[error("input bytes do not match their declared length and SHA-256")]
    InputIdentity,
    #[error("media conversion was cancelled")]
    Cancelled,
    #[error("media conversion exceeded its deadline")]
    Deadline,
    /// The worker made no progress (output growth or heartbeat) for `stall`.
    /// `torn_down` is true only when its process group was confirmed gone
    /// and its leader reaped, so a retry cannot overlap it.
    #[error("media worker made no progress for {stall:?}")]
    Stalled { stall: Duration, torn_down: bool },
    #[error("invalid converter response: {0}")]
    Protocol(String),
    #[error("converter failed ({code}): {message}")]
    Worker { code: String, message: String },
}

/// Private validated output. No writable descriptor or filesystem path escapes.
/// Durable publication still requires the store's verified-object transaction.
pub struct CanonicalMedia {
    file: File,
    object: GeneratedObjectRef,
    source_sha256: [u8; 32],
    report: ConversionReport,
}

impl CanonicalMedia {
    pub fn object(&self) -> &GeneratedObjectRef {
        &self.object
    }

    pub fn report(&self) -> &ConversionReport {
        &self.report
    }

    /// Share this canonical output with the admitted source decoders without
    /// copying or reopening it. The SHA-256 and byte length were measured over
    /// the complete private output while its BLAKE3 object identity was
    /// established. The returned input holds only a cloned descriptor; it
    /// exposes neither the path nor a writable file handle.
    pub fn verified_source_input(&self) -> Result<VerifiedSourceInput, SourceInputError> {
        let identity = SourceContentIdentity::new(self.source_sha256, self.object.byte_length())
            .map_err(|_| SourceInputError::Limits)?;
        let file = self.file.try_clone().map_err(ConversionError::from)?;
        VerifiedSourceInput::from_verified_file(file, identity)
    }
}

impl Read for CanonicalMedia {
    fn read(&mut self, bytes: &mut [u8]) -> io::Result<usize> {
        self.file.read(bytes)
    }
}

impl Seek for CanonicalMedia {
    fn seek(&mut self, position: SeekFrom) -> io::Result<u64> {
        self.file.seek(position)
    }
}

/// Two verified private masters derived from one immutable native snapshot.
/// This is media validation, not a selected-Ready receipt or authored acceptance.
pub struct CanonicalBridge {
    native: CanonicalMedia,
    sampled: CanonicalMedia,
    sampling: BridgeSamplingMap,
    source_identity: InputIdentity,
}

impl CanonicalBridge {
    pub fn native(&self) -> &CanonicalMedia {
        &self.native
    }

    pub fn sampled(&self) -> &CanonicalMedia {
        &self.sampled
    }

    pub fn sampling(&self) -> &BridgeSamplingMap {
        &self.sampling
    }

    pub fn source_identity(&self) -> InputIdentity {
        self.source_identity
    }

    /// Consume the pair to copy its private readers into verified object storage.
    /// Publication callers still own relevance, cancellation, and acceptance.
    pub fn into_parts(self) -> (CanonicalMedia, CanonicalMedia, BridgeSamplingMap) {
        (self.native, self.sampled, self.sampling)
    }
}

/// Run on a background job service, never the UI or audio callback and never
/// inside a database transaction. `source` must be a finite local snapshot;
/// arbitrary blocking readers cannot be interrupted by this synchronous API.
///
/// `executable` is selected by the host's vetted installation, never by a
/// project, model, or worker. The child inherits no environment or media paths.
/// Process groups provide cleanup, not an operating-system security sandbox.
pub fn canonicalize(
    executable: &Path,
    source: &mut impl Read,
    identity: InputIdentity,
    request: &ConversionRequest,
    cancelled: &AtomicBool,
) -> Result<CanonicalMedia, ConversionError> {
    convert(
        executable,
        source,
        identity,
        &WorkerRequest::Convert(request.clone()),
        cancelled,
    )
}

/// Derive exactly the authored interior frames from the declared native video.
/// Uses the same private snapshot, process, deadline, and output guarantees as
/// [`canonicalize`]. The original sampling map must be retained with acceptance.
pub fn sample_bridge(
    executable: &Path,
    source: &mut impl Read,
    identity: InputIdentity,
    request: &BridgeConversionRequest,
    cancelled: &AtomicBool,
) -> Result<CanonicalMedia, ConversionError> {
    convert(
        executable,
        source,
        identity,
        &WorkerRequest::Bridge(request.clone()),
        cancelled,
    )
}

/// Preserve the native sequence and derive its exact interior sampled master.
/// Copies the input once and applies one hard deadline across copying, both
/// helper processes, independent decode verification, and final object hashing.
/// The byte limits apply per file; scratch files are used sequentially.
/// See [`canonicalize`] for the local-reader and trusted-executable contract.
pub fn canonicalize_bridge(
    executable: &Path,
    source: &mut impl Read,
    identity: InputIdentity,
    request: &BridgeConversionRequest,
    cancelled: &AtomicBool,
) -> Result<CanonicalBridge, ConversionError> {
    request.validate()?;
    let deadline = Deadline {
        end: Instant::now() + Duration::from_millis(request.limits.timeout_ms),
        cancelled,
    };
    deadline.check()?;
    let mut input = snapshot(source, identity, request.input_byte_length, &deadline)?;
    input.rewind()?;
    let native_request = WorkerRequest::Convert(ConversionRequest {
        protocol: PROTOCOL_VERSION,
        video: request.native,
        input_byte_length: request.input_byte_length,
        limits: request.limits,
    });
    let native = convert_snapshot(executable, input.try_clone()?, &native_request, &deadline)?;
    input.rewind()?;
    let sampled = convert_snapshot(
        executable,
        input,
        &WorkerRequest::Bridge(request.clone()),
        &deadline,
    )?;
    if native.report.output_rgb_sha256 != sampled.report.input_rgb_sha256 {
        return Err(ConversionError::Protocol(
            "native and sampled masters decoded different source pixels".into(),
        ));
    }
    deadline.check()?;
    Ok(CanonicalBridge {
        native,
        sampled,
        sampling: request.sampling.clone(),
        source_identity: identity,
    })
}

fn convert(
    executable: &Path,
    source: &mut impl Read,
    identity: InputIdentity,
    request: &WorkerRequest,
    cancelled: &AtomicBool,
) -> Result<CanonicalMedia, ConversionError> {
    request.validate()?;
    let deadline = Deadline {
        end: Instant::now() + Duration::from_millis(request.limits().timeout_ms),
        cancelled,
    };
    deadline.check()?;
    let mut input = snapshot(source, identity, request.input_byte_length(), &deadline)?;
    input.rewind()?;
    convert_snapshot(executable, input, request, &deadline)
}

fn convert_snapshot(
    executable: &Path,
    input: File,
    request: &WorkerRequest,
    deadline: &Deadline<'_>,
) -> Result<CanonicalMedia, ConversionError> {
    deadline.check()?;
    let serialized = serde_json::to_string(request)
        .map_err(|error| ConversionError::Protocol(error.to_string()))?;
    if serialized.len() > MAX_REQUEST_BYTES {
        return Err(ConversionError::Protocol(
            "request exceeded wire budget".into(),
        ));
    }
    let mut output = tempfile::tempfile()?;
    deadline.check()?;
    let child = deadpan_native_process::spawn(
        Command::new(executable)
            .arg(serialized)
            .env_clear()
            .current_dir(std::env::temp_dir())
            .stdin(Stdio::from(input))
            .stdout(Stdio::from(output.try_clone()?))
            .stderr(Stdio::piped())
            .process_group(0),
    )?;
    let mut process = OwnedProcess::new(child);
    let (status, reply) =
        process.collect(deadline, &output, request.limits().max_output_bytes, None)?;
    // Every failure discards the anonymous output. A well-formed success from a
    // nonzero exit or an unclosed control pipe cannot publish bytes.
    let reply: WorkerReply = serde_json::from_slice(&reply)
        .map_err(|error| ConversionError::Protocol(error.to_string()))?;
    let report = match reply {
        WorkerReply::Failure { code, message } => {
            if code.is_empty() || code.len() > 128 || message.is_empty() || message.len() > 2048 {
                return Err(ConversionError::Protocol(
                    "invalid failure diagnostic".into(),
                ));
            }
            return Err(ConversionError::Worker { code, message });
        }
        WorkerReply::Success { report } if status.success() => report,
        WorkerReply::Success { .. } => {
            return Err(ConversionError::Protocol(format!(
                "success followed by {status}"
            )));
        }
    };
    report.validate_worker(request)?;
    if output.metadata()?.len() != report.output_bytes {
        return Err(ConversionError::Protocol(
            "output length differs from report".into(),
        ));
    }
    output.rewind()?;
    let (digest, source_sha256) = hash_output(&mut output, report.output_bytes, deadline)?;
    output.rewind()?;
    let content = GeneratedContentId::new(digest)
        .map_err(|error| ConversionError::Protocol(error.to_string()))?;
    let object = GeneratedObjectRef::new(content, report.output_bytes)
        .map_err(|error| ConversionError::Protocol(error.to_string()))?;
    deadline.check()?;
    Ok(CanonicalMedia {
        file: output,
        object,
        source_sha256,
        report,
    })
}

pub(crate) struct Deadline<'a> {
    pub(crate) end: Instant,
    pub(crate) cancelled: &'a AtomicBool,
}

impl Deadline<'_> {
    pub(crate) fn check(&self) -> Result<(), ConversionError> {
        if self.cancelled.load(Ordering::Acquire) {
            return Err(ConversionError::Cancelled);
        }
        if Instant::now() >= self.end {
            return Err(ConversionError::Deadline);
        }
        Ok(())
    }
}

pub(crate) fn snapshot(
    source: &mut impl Read,
    identity: InputIdentity,
    length: u64,
    deadline: &Deadline<'_>,
) -> Result<File, ConversionError> {
    let mut file = tempfile::tempfile()?;
    let mut hash = Sha256::new();
    let mut remaining = length;
    let mut buffer = [0u8; 64 * 1024];
    while remaining != 0 {
        deadline.check()?;
        let capacity = usize::try_from(remaining.min(buffer.len() as u64))
            .map_err(|_| ConversionError::InputIdentity)?;
        let count = source.read(&mut buffer[..capacity])?;
        if count == 0 {
            return Err(ConversionError::InputIdentity);
        }
        deadpan_diagnostics::IO.media_snapshots.read(count as u64);
        file.write_all(&buffer[..count])?;
        deadpan_diagnostics::IO.media_snapshots.write(count as u64);
        hash.update(&buffer[..count]);
        remaining -= count as u64;
    }
    deadline.check()?;
    if source.read(&mut buffer[..1])? != 0 || <[u8; 32]>::from(hash.finalize()) != identity.sha256 {
        return Err(ConversionError::InputIdentity);
    }
    Ok(file)
}

fn hash_output(
    file: &mut File,
    length: u64,
    deadline: &Deadline<'_>,
) -> Result<(String, [u8; 32]), ConversionError> {
    let mut blake3_hash = blake3::Hasher::new();
    let mut sha256_hash = Sha256::new();
    let mut total = 0u64;
    let mut buffer = [0u8; 64 * 1024];
    loop {
        deadline.check()?;
        let count = file.read(&mut buffer)?;
        if count == 0 {
            break;
        }
        total = total
            .checked_add(count as u64)
            .filter(|total| *total <= length)
            .ok_or_else(|| ConversionError::Protocol("output grew during hashing".into()))?;
        blake3_hash.update(&buffer[..count]);
        sha256_hash.update(&buffer[..count]);
    }
    if total != length || file.metadata()?.len() != length {
        return Err(ConversionError::Protocol(
            "output changed during hashing".into(),
        ));
    }
    Ok((
        blake3_hash.finalize().to_hex().to_string(),
        <[u8; 32]>::from(sha256_hash.finalize()),
    ))
}

struct OwnedProcess {
    child: Child,
    pid: Pid,
    stopped: bool,
    reap_attempted: bool,
}

impl OwnedProcess {
    fn new(child: Child) -> Self {
        let pid = Pid::from_child(&child);
        Self {
            child,
            pid,
            stopped: false,
            reap_attempted: false,
        }
    }

    fn stop_group(&mut self) -> io::Result<()> {
        if self.stopped {
            return Ok(());
        }
        if self.pid == Pid::INIT {
            return Err(io::Error::other("invalid codec process-group identity"));
        }
        #[cfg(target_os = "macos")]
        deadpan_native_process::terminate_owned_group(
            &self.child,
            Instant::now() + GROUP_CLEANUP_GRACE,
        )?;
        #[cfg(target_os = "linux")]
        {
            deadpan_native_process::signal_owned_group(&self.child)?;
            deadpan_native_process::terminate_owned_leader(
                &self.child,
                Instant::now() + GROUP_CLEANUP_GRACE,
            )?;
        }
        self.stopped = true;
        Ok(())
    }

    fn reap_leader(&mut self) -> io::Result<ExitStatus> {
        if self.reap_attempted {
            return Err(io::Error::other("codec reaping was already attempted"));
        }
        self.reap_attempted = true;
        self.child.wait()
    }

    /// Wait for exit and the complete control reply. With a `watch`, a live
    /// worker that neither grows its output nor sends a heartbeat for its
    /// stall period is stopped: a hung platform encoder must not hold a
    /// background job until its deadline. The watch's pause flag suspends
    /// the whole group (SIGSTOP) and resumes it (SIGCONT); paused time never
    /// counts as a stall, and extends the deadline by the time suspended.
    fn collect(
        &mut self,
        deadline: &Deadline<'_>,
        output: &File,
        max_output_bytes: u64,
        watch: Option<&Watch<'_>>,
    ) -> Result<(ExitStatus, Vec<u8>), ConversionError> {
        let mut pipe = self
            .child
            .stderr
            .take()
            .ok_or_else(|| ConversionError::Protocol("missing control pipe".into()))?;
        let flags = fcntl_getfl(&pipe).map_err(io::Error::from)?;
        fcntl_setfl(&pipe, flags | OFlags::NONBLOCK).map_err(io::Error::from)?;
        let mut bytes = Vec::with_capacity(MAX_REPLY_BYTES);
        let mut eof = false;
        let mut exit = None;
        let mut exited_at = None;
        let mut progress = (0_u64, Instant::now());
        let mut suspended = false;
        // Suspended time, completed and current: a suspended worker makes no
        // progress, so its deadline moves by that much.
        let mut suspended_total = Duration::ZERO;
        let mut suspended_since: Option<Instant> = None;
        loop {
            let extended = Deadline {
                end: deadline.end
                    + suspended_total
                    + suspended_since.map_or(Duration::ZERO, |since| since.elapsed()),
                cancelled: deadline.cancelled,
            };
            let deadline = &extended;
            deadline.check()?;
            let mut heartbeat = false;
            if !eof {
                eof = drain_heartbeat(&mut pipe, &mut bytes, deadline, exited_at, &mut heartbeat)?;
            }
            let written = output.metadata()?.len();
            if written > max_output_bytes {
                return Err(ConversionError::Protocol(
                    "output exceeded byte budget".into(),
                ));
            }
            if let Some(watch) = watch
                && exit.is_none()
            {
                let pause = watch
                    .pause
                    .is_some_and(|pause| pause.load(Ordering::Acquire));
                if pause != suspended {
                    deadpan_native_process::suspend_owned_group(&self.child, pause)?;
                    suspended = pause;
                    progress.1 = Instant::now();
                    if pause {
                        suspended_since = Some(Instant::now());
                    } else if let Some(since) = suspended_since.take() {
                        suspended_total += since.elapsed();
                    }
                }
                if written != progress.0 || heartbeat || suspended {
                    progress = (written, Instant::now());
                } else if progress.1.elapsed() > watch.stall {
                    // Confirm teardown here, so the caller knows whether a
                    // retry could overlap a surviving process.
                    let torn_down = self.stop_group().is_ok() && self.reap_leader().is_ok();
                    return Err(ConversionError::Stalled {
                        stall: watch.stall,
                        torn_down,
                    });
                }
            }
            // Darwin's waitid can report a stopped (suspended) child even when
            // asked only for exits; only an exit or a fatal signal counts.
            if exit.is_none()
                && waitid(
                    WaitId::Pid(self.pid),
                    WaitIdOptions::EXITED | WaitIdOptions::NOHANG | WaitIdOptions::NOWAIT,
                )
                .map_err(io::Error::from)?
                .is_some_and(|status| status.exited() || status.killed() || status.dumped())
            {
                // Retain the unreaped leader until group cleanup to prevent PID
                // reuse from signalling an unrelated group. See jobs supervisor.
                let cleanup = self.stop_group();
                deadline.check()?;
                cleanup?;
                // A failed wait may mean ownership was lost. Never retry it
                // from Drop using only the cached successful group cleanup.
                exit = Some(self.reap_leader()?);
                exited_at = Some(Instant::now());
            }
            if let Some(status) = exit
                && eof
            {
                return Ok((status, bytes));
            }
            std::thread::park_timeout(Duration::from_millis(2));
        }
    }
}

/// Stall supervision of one worker run.
pub(crate) struct Watch<'a> {
    pub(crate) stall: Duration,
    pub(crate) pause: Option<&'a AtomicBool>,
}

#[cfg(test)]
fn drain_control(
    pipe: &mut impl Read,
    bytes: &mut Vec<u8>,
    deadline: &Deadline<'_>,
    exited_at: Option<Instant>,
) -> Result<bool, ConversionError> {
    drain_heartbeat(pipe, bytes, deadline, exited_at, &mut false)
}

/// Read available control bytes. Newlines before the reply are heartbeats:
/// they set `heartbeat` and are not retained, so they never consume the
/// reply budget. Replies start with `{`, so no worker mode is affected.
fn drain_heartbeat(
    pipe: &mut impl Read,
    bytes: &mut Vec<u8>,
    deadline: &Deadline<'_>,
    exited_at: Option<Instant>,
    heartbeat: &mut bool,
) -> Result<bool, ConversionError> {
    let mut buffer = [0u8; 4096];
    loop {
        deadline.check()?;
        match pipe.read(&mut buffer) {
            Ok(0) => return Ok(true),
            Ok(count) => {
                let mut start = 0;
                if bytes.is_empty() {
                    while start < count && buffer[start] == b'\n' {
                        start += 1;
                    }
                    *heartbeat |= start > 0;
                }
                let buffer = &buffer[start..count];
                let count = buffer.len();
                if count > MAX_REPLY_BYTES.saturating_sub(bytes.len()) {
                    return Err(ConversionError::Protocol(
                        "control reply exceeded byte budget".into(),
                    ));
                }
                bytes.extend_from_slice(&buffer[..count]);
            }
            Err(error) if error.kind() == io::ErrorKind::Interrupted => continue,
            Err(error) if error.kind() == io::ErrorKind::WouldBlock => {
                // Drain all available bytes and observe EOF before judging pipe
                // liveness. Host scheduling delay is not a surviving writer.
                if exited_at.is_some_and(|at| at.elapsed() > GROUP_CLEANUP_GRACE) {
                    return Err(ConversionError::Protocol(
                        "control pipe stayed open after worker exit".into(),
                    ));
                }
                return Ok(false);
            }
            Err(error) => return Err(error.into()),
        }
    }
}

impl Drop for OwnedProcess {
    fn drop(&mut self) {
        if self.reap_attempted {
            return;
        }
        let can_reap = self.stop_group().is_ok();
        // A failed group inspection must not strand an owned leader. The
        // fallback independently checks ownership and never signals on ECHILD.
        let can_reap = can_reap
            || deadpan_native_process::terminate_owned_leader(
                &self.child,
                Instant::now() + GROUP_CLEANUP_GRACE,
            )
            .is_ok();
        if can_reap {
            let _ = self.reap_leader();
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::io::Cursor;

    struct PendingPipe;

    #[test]
    fn canonical_output_shares_its_verified_descriptor_with_source_decoders() {
        let bytes = b"canonical media bytes";
        let mut file = tempfile::tempfile().unwrap();
        file.write_all(bytes).unwrap();
        file.rewind().unwrap();

        let cancelled = AtomicBool::new(false);
        let deadline = Deadline {
            end: Instant::now() + Duration::from_secs(1),
            cancelled: &cancelled,
        };
        let (blake3_digest, sha256) =
            hash_output(&mut file, bytes.len() as u64, &deadline).unwrap();
        file.rewind().unwrap();

        let object = GeneratedObjectRef::new(
            GeneratedContentId::new(blake3_digest).unwrap(),
            bytes.len() as u64,
        )
        .unwrap();
        let video = crate::protocol::VideoContract {
            width: 1,
            height: 1,
            frames: 1,
            rate_num: 24,
            rate_den: 1,
        };
        let media = CanonicalMedia {
            file,
            object,
            source_sha256: sha256,
            report: ConversionReport {
                protocol: 2,
                video,
                output_bytes: bytes.len() as u64,
                input_rgb_sha256: "a".repeat(64),
                output_rgb_sha256: "a".repeat(64),
                input_time_base_num: 1,
                input_time_base_den: 24,
                output_time_base_num: 1,
                output_time_base_den: 1000,
                first_output_pts: 0,
                last_output_pts: 0,
                last_output_duration: 1,
                ffv1_version: 3,
                slice_crc: true,
                discarded_audio_streams: 0,
            },
        };

        let input = media.verified_source_input().unwrap();
        assert_eq!(input.identity().byte_length(), bytes.len() as u64);
        assert_eq!(
            input.identity().sha256(),
            <[u8; 32]>::from(Sha256::digest(bytes))
        );
    }

    #[test]
    fn failed_reap_is_terminal_even_after_confirmed_group_cleanup() {
        let child = Command::new("/bin/sh")
            .args(["-c", "exit 0"])
            .process_group(0)
            .spawn()
            .unwrap();
        let mut process = OwnedProcess::new(child);
        process.stop_group().unwrap();
        // Simulate a competing reaper after group confirmation. Child's cached
        // status stays empty, so its next wait really receives ECHILD.
        waitid(WaitId::Pid(process.pid), WaitIdOptions::EXITED).unwrap();
        assert_eq!(
            process.reap_leader().unwrap_err().raw_os_error(),
            Some(rustix::io::Errno::CHILD.raw_os_error())
        );
        assert!(process.reap_attempted);
        assert_eq!(
            process.reap_leader().unwrap_err().to_string(),
            "codec reaping was already attempted"
        );
        drop(process);
    }

    #[test]
    fn a_live_worker_without_output_progress_is_stopped_as_stalled() {
        let output = tempfile::tempfile().unwrap();
        let child = Command::new("/bin/sleep")
            .arg("30")
            .stderr(Stdio::piped())
            .process_group(0)
            .spawn()
            .unwrap();
        let mut process = OwnedProcess::new(child);
        let cancelled = AtomicBool::new(false);
        let deadline = Deadline {
            end: Instant::now() + Duration::from_secs(20),
            cancelled: &cancelled,
        };
        let started = Instant::now();
        let stall = Duration::from_millis(200);
        let watch = Watch { stall, pause: None };
        assert!(matches!(
            process.collect(&deadline, &output, 1024, Some(&watch)),
            Err(ConversionError::Stalled { stall: observed, torn_down: true }) if observed == stall
        ));
        assert!(started.elapsed() < Duration::from_secs(5));
        assert!(process.reap_attempted, "the stalled leader was reaped");
        drop(process);
    }

    #[test]
    fn a_paused_worker_is_suspended_and_never_reported_as_stalled() {
        let output = tempfile::tempfile().unwrap();
        let child = Command::new("/bin/sh")
            .args(["-c", "sleep 1; exit 0"])
            .stderr(Stdio::piped())
            .process_group(0)
            .spawn()
            .unwrap();
        let mut process = OwnedProcess::new(child);
        let cancelled = AtomicBool::new(false);
        let deadline = Deadline {
            end: Instant::now() + Duration::from_secs(20),
            cancelled: &cancelled,
        };
        let pause = std::sync::Arc::new(AtomicBool::new(true));
        let release = std::sync::Arc::clone(&pause);
        let resumer = std::thread::spawn(move || {
            std::thread::sleep(Duration::from_millis(1500));
            release.store(false, Ordering::Release);
        });
        // Suspended for 1.5 s, then the one-second sleep runs: a run of at
        // least 1.5 s shows the group was stopped. The stall period exceeds
        // the shell's silent run, so only pausing is under test here.
        let watch = Watch {
            stall: Duration::from_secs(5),
            pause: Some(&pause),
        };
        let started = Instant::now();
        let (status, _) = process
            .collect(&deadline, &output, 1024, Some(&watch))
            .unwrap();
        resumer.join().unwrap();
        assert!(status.success());
        assert!(started.elapsed() >= Duration::from_millis(1500));
    }

    #[test]
    fn suspended_time_extends_the_deadline() {
        let output = tempfile::tempfile().unwrap();
        let child = Command::new("/bin/sh")
            .args(["-c", "sleep 0.5; exit 0"])
            .stderr(Stdio::piped())
            .process_group(0)
            .spawn()
            .unwrap();
        let mut process = OwnedProcess::new(child);
        let cancelled = AtomicBool::new(false);
        // The deadline alone (1.2 s) is shorter than the 1.5 s suspension
        // plus the 0.5 s run; suspended time must not count against it.
        let deadline = Deadline {
            end: Instant::now() + Duration::from_millis(1200),
            cancelled: &cancelled,
        };
        let pause = std::sync::Arc::new(AtomicBool::new(true));
        let release = std::sync::Arc::clone(&pause);
        let resumer = std::thread::spawn(move || {
            std::thread::sleep(Duration::from_millis(1500));
            release.store(false, Ordering::Release);
        });
        let watch = Watch {
            stall: Duration::from_secs(5),
            pause: Some(&pause),
        };
        let (status, _) = process
            .collect(&deadline, &output, 1024, Some(&watch))
            .unwrap();
        resumer.join().unwrap();
        assert!(status.success());
    }

    impl Read for PendingPipe {
        fn read(&mut self, _: &mut [u8]) -> io::Result<usize> {
            Err(io::ErrorKind::WouldBlock.into())
        }
    }

    #[test]
    fn buffered_reply_reaches_eof_before_expired_pipe_grace_is_judged() {
        let cancelled = AtomicBool::new(false);
        let deadline = Deadline {
            end: Instant::now() + Duration::from_secs(1),
            cancelled: &cancelled,
        };
        let reply = vec![b'x'; MAX_REPLY_BYTES];
        let mut bytes = Vec::new();
        assert!(
            drain_control(
                &mut Cursor::new(&reply),
                &mut bytes,
                &deadline,
                Some(Instant::now() - Duration::from_secs(1)),
            )
            .unwrap()
        );
        assert_eq!(bytes, reply);
    }

    #[test]
    fn actually_open_pipe_still_fails_after_grace() {
        let cancelled = AtomicBool::new(false);
        let deadline = Deadline {
            end: Instant::now() + Duration::from_secs(1),
            cancelled: &cancelled,
        };
        assert!(!drain_control(&mut PendingPipe, &mut Vec::new(), &deadline, None).unwrap());
        assert!(matches!(
            drain_control(
                &mut PendingPipe,
                &mut Vec::new(),
                &deadline,
                Some(Instant::now() - Duration::from_secs(1)),
            ),
            Err(ConversionError::Protocol(message)) if message == "control pipe stayed open after worker exit"
        ));
    }

    #[test]
    fn draining_keeps_reply_budget_and_hard_deadline() {
        let cancelled = AtomicBool::new(false);
        let mut deadline = Deadline {
            end: Instant::now() + Duration::from_secs(1),
            cancelled: &cancelled,
        };
        let mut bytes = Vec::new();
        assert!(matches!(
            drain_control(
                &mut Cursor::new(vec![0; MAX_REPLY_BYTES + 1]),
                &mut bytes,
                &deadline,
                None,
            ),
            Err(ConversionError::Protocol(message)) if message == "control reply exceeded byte budget"
        ));
        assert_eq!(bytes.len(), MAX_REPLY_BYTES);
        deadline.end = Instant::now();
        assert!(matches!(
            drain_control(&mut Cursor::new([]), &mut bytes, &deadline, None),
            Err(ConversionError::Deadline)
        ));
        cancelled.store(true, Ordering::Release);
        assert!(matches!(
            drain_control(&mut Cursor::new([]), &mut bytes, &deadline, None),
            Err(ConversionError::Cancelled)
        ));
    }
}
