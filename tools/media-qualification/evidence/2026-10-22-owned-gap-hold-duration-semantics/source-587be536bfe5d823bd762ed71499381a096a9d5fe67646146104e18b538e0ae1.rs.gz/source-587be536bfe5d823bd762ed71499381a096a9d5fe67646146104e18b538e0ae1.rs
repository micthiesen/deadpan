//! Authored clip gain after complete voice time/pitch mapping and edge fades.
//!
//! A treatment's owner supplies its evaluation clock and contribution scope.
//! These fixed owner-output coordinates are never normalized to an owner's
//! duration. Cropping or extending its allocation does not rewrite the curve.
//! Interior values use Q32 millidecibels; times and segment selection stay exact.
//! Amplitude conversion, PCM processing and aggregate voice mixing belong to DSP.

mod admission;
mod json;
mod numeric;
mod wire;

pub(crate) use admission::{
    MAX_ISOLATED_GAIN_RECORDS, NodeGainInventory, invalid, node_map, validate_command,
    validate_document, validate_nodes, validate_nodes_with_limit,
};

use std::{error::Error, fmt};

use serde::{Deserialize, Serialize};

use crate::ExactRatio;

pub const GAIN_NUMERIC_SCALE: u64 = 1 << 32;
pub const MIN_GAIN_MILLIDECIBELS: i32 = -96_000;
pub const MAX_GAIN_MILLIDECIBELS: i32 = 24_000;
/// Per-owner work is at most 16 curves of 64 segments and 64 mute tests.
pub const MAX_GAIN_ENVELOPES: usize = 16;
pub const MAX_GAIN_SEGMENTS: usize = 64;
pub const MAX_GAIN_MUTE_RANGES: usize = 64;
/// Document/plan integration must charge these independent aggregate limits.
pub const MAX_GAIN_LAYERS: usize = 16;
pub const MAX_GAIN_RECORDS: usize = 100_000;
pub const MAX_AUDIO_TREATMENT_STAGES: usize = 4;
/// Saturation drive is authored in exact millidecibels from 0 through 24 dB, the authored gain ceiling.
pub const MAX_SATURATION_DRIVE_MILLIDECIBELS: i32 = 24_000;
/// Standalone JSON input/output cap. Enclosing documents and commands must also
/// impose their own byte limit when they deserialize these types directly.
pub const MAX_AUDIO_TREATMENTS_JSON_BYTES: usize = 512 * 1024;

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum GainError {
    ValueRange,
    BalanceRange,
    TimeRange,
    Segments,
    StageOrder,
    Limit,
    Overflow,
}

impl fmt::Display for GainError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(match self {
            Self::ValueRange => "gain must be between -96000 and 24000 millidecibels",
            Self::BalanceRange => {
                "stereo balance must be an integer percent between -100 (left) and 100 (right)"
            }
            Self::TimeRange => "gain ranges require nonnegative increasing exact owner times",
            Self::Segments => "gain segments must increase from the range start to its exact end",
            Self::StageOrder => {
                "treatment order must list each present stage exactly once, with StereoBalance last"
            }
            Self::Limit => "gain exceeds its declared collection or aggregate record limit",
            Self::Overflow => "gain arithmetic exceeds its bounded numeric representation",
        })
    }
}
impl Error for GainError {}
impl From<crate::TimeError> for GainError {
    fn from(_: crate::TimeError) -> Self {
        Self::Overflow
    }
}

/// Finite authored gain, never a mute sentinel. Zero means unity.
#[derive(Debug, Clone, Copy, Default, PartialEq, Eq, Serialize, Deserialize)]
#[serde(try_from = "i32", into = "i32")]
pub struct GainDb(i32);

impl GainDb {
    pub const UNITY: Self = Self(0);

    pub fn new(millidecibels: i32) -> Result<Self, GainError> {
        if !(MIN_GAIN_MILLIDECIBELS..=MAX_GAIN_MILLIDECIBELS).contains(&millidecibels) {
            return Err(GainError::ValueRange);
        }
        Ok(Self(millidecibels))
    }

    pub const fn millidecibels(self) -> i32 {
        self.0
    }

    pub fn adjusted(self, delta_millidecibels: i32) -> Result<Self, GainError> {
        Self::new(
            self.0
                .checked_add(delta_millidecibels)
                .ok_or(GainError::Overflow)?,
        )
    }

    fn grid(self) -> i64 {
        i64::from(self.0) * GAIN_NUMERIC_SCALE as i64
    }
}
impl TryFrom<i32> for GainDb {
    type Error = GainError;
    fn try_from(value: i32) -> Result<Self, Self::Error> {
        Self::new(value)
    }
}
impl From<GainDb> for i32 {
    fn from(value: GainDb) -> Self {
        value.0
    }
}

/// A closed evaluation-space contract. No implicit source clock or normalization.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum GainClock {
    OwnerOutput,
}

/// Exact owner-local project-frame coordinates, including sample-derived ratios.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
#[serde(try_from = "wire::Range", into = "wire::Range")]
pub struct GainRange {
    start: ExactRatio,
    end: ExactRatio,
}

impl GainRange {
    pub fn new(start: ExactRatio, end: ExactRatio) -> Result<Self, GainError> {
        if start.compare_integer(0).is_lt() || !numeric::compare(start, end).is_lt() {
            return Err(GainError::TimeRange);
        }
        Ok(Self { start, end })
    }
    pub const fn start(self) -> ExactRatio {
        self.start
    }
    pub const fn end(self) -> ExactRatio {
        self.end
    }
    pub fn contains(self, local: ExactRatio) -> bool {
        !numeric::compare(local, self.start).is_lt() && numeric::compare(local, self.end).is_lt()
    }
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize)]
#[serde(tag = "type", rename_all = "snake_case")]
pub enum GainCurve {
    Step,
    Linear,
    Smoothstep,
    /// Bezier value controls in dB, with linear segment progress.
    Cubic {
        control1: GainDb,
        control2: GainDb,
    },
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
#[serde(try_from = "wire::Segment", into = "wire::Segment")]
pub struct GainSegment {
    end: ExactRatio,
    value: GainDb,
    curve: GainCurve,
}

impl GainSegment {
    pub fn new(end: ExactRatio, value: GainDb, curve: GainCurve) -> Result<Self, GainError> {
        if !end.compare_integer(0).is_gt() {
            return Err(GainError::TimeRange);
        }
        Ok(Self { end, value, curve })
    }
    pub const fn end(&self) -> ExactRatio {
        self.end
    }
    pub const fn value(&self) -> GainDb {
        self.value
    }
    pub const fn curve(&self) -> GainCurve {
        self.curve
    }
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
#[serde(try_from = "wire::Envelope", into = "wire::Envelope")]
pub struct GainEnvelope {
    clock: GainClock,
    range: GainRange,
    initial: GainDb,
    segments: Vec<GainSegment>,
}

impl GainEnvelope {
    pub fn new(
        clock: GainClock,
        range: GainRange,
        initial: GainDb,
        segments: Vec<GainSegment>,
    ) -> Result<Self, GainError> {
        let result = Self {
            clock,
            range,
            initial,
            segments,
        };
        result.validate()?;
        Ok(result)
    }

    pub const fn clock(&self) -> GainClock {
        self.clock
    }
    pub const fn range(&self) -> GainRange {
        self.range
    }
    pub const fn initial(&self) -> GainDb {
        self.initial
    }
    pub fn segments(&self) -> &[GainSegment] {
        &self.segments
    }

    pub fn validate(&self) -> Result<(), GainError> {
        if self.segments.is_empty() || self.segments.len() > MAX_GAIN_SEGMENTS {
            return Err(GainError::Limit);
        }
        let mut previous = self.range.start;
        for segment in &self.segments {
            if !numeric::compare(previous, segment.end).is_lt()
                || numeric::compare(segment.end, self.range.end).is_gt()
            {
                return Err(GainError::Segments);
            }
            previous = segment.end;
        }
        if previous != self.range.end {
            return Err(GainError::Segments);
        }
        Ok(())
    }

    /// Initial value plus segment targets and explicit cubic controls.
    pub fn record_count(&self) -> usize {
        1 + self
            .segments
            .iter()
            .map(|segment| 1 + 2 * usize::from(matches!(segment.curve, GainCurve::Cubic { .. })))
            .sum::<usize>()
    }

    /// Half-open range; outside it the envelope contributes exactly zero dB.
    pub fn evaluate(&self, local: ExactRatio) -> Result<ExactRatio, GainError> {
        numeric::millidecibels(self.evaluate_grid(local)?)
    }

    fn evaluate_grid(&self, local: ExactRatio) -> Result<i64, GainError> {
        if !self.range.contains(local) {
            return Ok(0);
        }
        let mut start = self.range.start;
        let mut from = self.initial;
        for segment in &self.segments {
            match numeric::compare(local, segment.end) {
                std::cmp::Ordering::Equal => return Ok(segment.value.grid()),
                std::cmp::Ordering::Greater => {
                    start = segment.end;
                    from = segment.value;
                }
                std::cmp::Ordering::Less => {
                    if local == start || matches!(segment.curve, GainCurve::Step) {
                        return Ok(from.grid());
                    }
                    let t = numeric::progress(local, start, segment.end)?;
                    return numeric::interpolate(from, segment.value, segment.curve, t);
                }
            }
        }
        Err(GainError::Segments)
    }
}

#[derive(Debug, Clone, Default, PartialEq, Eq, Serialize, Deserialize)]
#[serde(try_from = "wire::Clip", into = "wire::Clip")]
pub struct ClipGain {
    trim: GainDb,
    muted: bool,
    envelopes: Vec<GainEnvelope>,
    mute_ranges: Vec<GainRange>,
}

impl ClipGain {
    pub fn new(
        trim: GainDb,
        muted: bool,
        envelopes: Vec<GainEnvelope>,
        mute_ranges: Vec<GainRange>,
    ) -> Result<Self, GainError> {
        let result = Self {
            trim,
            muted,
            envelopes,
            mute_ranges,
        };
        result.validate()?;
        Ok(result)
    }
    pub const fn trim(&self) -> GainDb {
        self.trim
    }
    pub const fn muted(&self) -> bool {
        self.muted
    }
    pub fn envelopes(&self) -> &[GainEnvelope] {
        &self.envelopes
    }
    pub fn mute_ranges(&self) -> &[GainRange] {
        &self.mute_ranges
    }

    pub fn validate(&self) -> Result<(), GainError> {
        if self.envelopes.len() > MAX_GAIN_ENVELOPES
            || self.mute_ranges.len() > MAX_GAIN_MUTE_RANGES
        {
            return Err(GainError::Limit);
        }
        for envelope in &self.envelopes {
            envelope.validate()?;
        }
        Ok(())
    }

    /// Constant trim, whole-owner mute flag, curve values/controls and mute ranges.
    pub fn record_count(&self) -> usize {
        2 + self
            .envelopes
            .iter()
            .map(GainEnvelope::record_count)
            .sum::<usize>()
            + self.mute_ranges.len()
    }

    pub fn with_trim(&self, trim: GainDb) -> Self {
        Self {
            trim,
            ..self.clone()
        }
    }
    pub fn adjust_trim(&self, delta_millidecibels: i32) -> Result<Self, GainError> {
        Ok(self.with_trim(self.trim.adjusted(delta_millidecibels)?))
    }

    /// `+`/`-` over a range (specification §5 "selected audio gain"): a
    /// constant step envelope over exactly `range`, changed by the signed
    /// amount. Pressing again over the same range adjusts that envelope;
    /// reaching 0 dB removes it. Other envelopes, trim and mutes are kept;
    /// overlapping envelopes still add.
    pub fn adjust_range(
        &self,
        range: GainRange,
        delta_millidecibels: i32,
    ) -> Result<Self, GainError> {
        let constant = |envelope: &GainEnvelope| {
            envelope.range == range
                && envelope
                    .segments
                    .iter()
                    .all(|segment| segment.value == envelope.initial)
        };
        let mut next = self.clone();
        let existing = next.envelopes.iter().position(constant);
        let current = existing.map_or(GainDb::UNITY, |index| next.envelopes[index].initial);
        let value = current.adjusted(delta_millidecibels)?;
        if let Some(index) = existing {
            next.envelopes.remove(index);
        }
        if value != GainDb::UNITY {
            let envelope = GainEnvelope::new(
                GainClock::OwnerOutput,
                range,
                value,
                vec![GainSegment::new(range.end, value, GainCurve::Step)?],
            )?;
            next.envelopes
                .insert(existing.unwrap_or(next.envelopes.len()), envelope);
        }
        next.validate()?;
        Ok(next)
    }

    /// The constant step a range change left over exactly `range`, if any.
    pub fn range_step(&self, range: GainRange) -> Option<GainDb> {
        self.envelopes
            .iter()
            .find(|envelope| {
                envelope.range == range
                    && envelope
                        .segments
                        .iter()
                        .all(|segment| segment.value == envelope.initial)
            })
            .map(|envelope| envelope.initial)
    }

    /// The caller establishes the owner's allocation. Whole-owner trim/mute
    /// apply throughout that allocation; only range effects use `local`.
    /// Overlapping envelopes add dB without clamping or normalization.
    pub fn evaluate(&self, local: ExactRatio) -> Result<EvaluatedGain, GainError> {
        let mut sum = self.trim.grid();
        for envelope in &self.envelopes {
            sum = sum
                .checked_add(envelope.evaluate_grid(local)?)
                .ok_or(GainError::Overflow)?;
        }
        Ok(EvaluatedGain {
            millidecibels: numeric::millidecibels(sum)?,
            muted: self.muted || self.mute_ranges.iter().any(|range| range.contains(local)),
        })
    }
}

/// The admitted treatment stages. The order is serialized, never inferred
/// from a UI widget's position (specification §10.2); a future stage needs a
/// new closed vocabulary.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum AudioTreatmentStage {
    ClipGain,
    Equalizer,
    Saturation,
    StereoBalance,
}

/// Stereo channel balance in whole percent: -100 keeps only left, zero
/// preserves both channels, and +100 keeps only right. The favored channel
/// stays at unity; DSP linearly attenuates the opposite channel. No crossfeed,
/// normalization, timing change or implicit layout interpretation is involved.
#[derive(Debug, Clone, Copy, Default, PartialEq, Eq, Serialize, Deserialize)]
#[serde(try_from = "i16", into = "i16")]
pub struct StereoBalance(i16);

impl StereoBalance {
    pub const CENTER: Self = Self(0);

    pub fn new(percent: i16) -> Result<Self, GainError> {
        if !(-100..=100).contains(&percent) {
            return Err(GainError::BalanceRange);
        }
        Ok(Self(percent))
    }

    pub const fn percent(self) -> i16 {
        self.0
    }
}

impl TryFrom<i16> for StereoBalance {
    type Error = GainError;
    fn try_from(value: i16) -> Result<Self, Self::Error> {
        Self::new(value)
    }
}

impl From<StereoBalance> for i16 {
    fn from(value: StereoBalance) -> Self {
        value.0
    }
}

/// Intentional nonlinear drive (specification §8.3 "Saturation"): the signal
/// is multiplied by the drive and passed through `tanh`, a memoryless soft
/// clipper whose output stays within ±1 before later stages and the master
/// limiter. Being stateless, it evaluates identically at any read boundary.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
#[serde(try_from = "wire::SaturationWire", into = "wire::SaturationWire")]
pub struct Saturation {
    drive: GainDb,
}

impl Saturation {
    pub fn new(drive: GainDb) -> Result<Self, GainError> {
        if !(0..=MAX_SATURATION_DRIVE_MILLIDECIBELS).contains(&drive.millidecibels()) {
            return Err(GainError::ValueRange);
        }
        Ok(Self { drive })
    }
    pub const fn drive(self) -> GainDb {
        self.drive
    }
    /// The linear drive factor applied before the soft clipper.
    pub fn drive_factor(self) -> f64 {
        10_f64.powf(f64::from(self.drive.millidecibels()) / 20_000.0)
    }
    /// One sample through the stage.
    pub fn shape(self, sample: f64) -> f64 {
        (sample * self.drive_factor()).tanh()
    }
}

#[derive(Debug, Clone, Default, PartialEq, Eq, Serialize, Deserialize)]
#[serde(try_from = "wire::Treatments", into = "wire::Treatments")]
/// A bounded recipe. For standalone JSON use `from_json`; direct serde ingress
/// assumes a byte-bounded enclosing document/command. This also bounds inherited
/// ExactRatio decimal strings before those strings are allocated and parsed.
pub struct AudioTreatments {
    order: Vec<AudioTreatmentStage>,
    clip_gain: Option<ClipGain>,
    saturation: Option<Saturation>,
    balance: Option<StereoBalance>,
    equalizer: Option<crate::EqualizerRecipe>,
    tail_sends: crate::TailSends,
    wet_sends: crate::TailSends,
}

impl AudioTreatments {
    /// Constant voice trim, preserving any independently authored envelopes.
    pub fn trim(&self) -> GainDb {
        self.clip_gain
            .as_ref()
            .map_or(GainDb::UNITY, ClipGain::trim)
    }

    pub fn with_trim(&self, trim: GainDb) -> Result<Self, GainError> {
        self.with_clip_gain_or_none(self.clip_gain.clone().unwrap_or_default().with_trim(trim))
    }

    pub fn new(
        order: Vec<AudioTreatmentStage>,
        clip_gain: Option<ClipGain>,
    ) -> Result<Self, GainError> {
        Self::with_stages(order, clip_gain, None)
    }
    /// Every stage recipe with its explicit order: each present stage is
    /// listed exactly once and no absent stage is listed.
    pub fn with_stages(
        order: Vec<AudioTreatmentStage>,
        clip_gain: Option<ClipGain>,
        saturation: Option<Saturation>,
    ) -> Result<Self, GainError> {
        Self::with_all_stages(order, clip_gain, saturation, None)
    }

    pub fn with_all_stages(
        order: Vec<AudioTreatmentStage>,
        clip_gain: Option<ClipGain>,
        saturation: Option<Saturation>,
        balance: Option<StereoBalance>,
    ) -> Result<Self, GainError> {
        Self::with_equalizer_stages(order, clip_gain, saturation, balance, None)
    }

    /// Complete closed treatment vocabulary, including temporal EQ. Balance
    /// remains last; gain, EQ and saturation retain their explicitly stored order.
    pub fn with_equalizer_stages(
        order: Vec<AudioTreatmentStage>,
        clip_gain: Option<ClipGain>,
        saturation: Option<Saturation>,
        balance: Option<StereoBalance>,
        equalizer: Option<crate::EqualizerRecipe>,
    ) -> Result<Self, GainError> {
        let result = Self {
            order,
            clip_gain,
            saturation,
            balance,
            equalizer,
            tail_sends: crate::TailSends::default(),
            wet_sends: crate::TailSends::default(),
        };
        result.validate()?;
        Ok(result)
    }
    pub fn from_clip_gain(clip_gain: ClipGain) -> Self {
        Self {
            order: vec![AudioTreatmentStage::ClipGain],
            clip_gain: Some(clip_gain),
            saturation: None,
            balance: None,
            equalizer: None,
            tail_sends: crate::TailSends::default(),
            wet_sends: crate::TailSends::default(),
        }
    }
    pub fn order(&self) -> &[AudioTreatmentStage] {
        &self.order
    }
    pub fn clip_gain(&self) -> Option<&ClipGain> {
        self.clip_gain.as_ref()
    }
    pub fn saturation(&self) -> Option<Saturation> {
        self.saturation
    }
    pub fn balance(&self) -> Option<StereoBalance> {
        self.balance
    }
    pub fn equalizer(&self) -> Option<crate::EqualizerRecipe> {
        self.equalizer
    }
    /// Continuous wet returns follow this owner's complete treatment chain,
    /// before parent processing, within permitted authored allocation.
    pub fn wet_sends(&self) -> crate::TailSends {
        self.wet_sends
    }
    pub fn with_wet_sends(mut self, sends: crate::TailSends) -> Self {
        self.wet_sends = sends;
        self
    }
    pub fn tail_sends(&self) -> crate::TailSends {
        self.tail_sends
    }
    /// Sends always follow the explicitly ordered treatment chain. They are
    /// metadata for the wet input reader and never alter the dry program.
    pub fn with_tail_sends(mut self, sends: crate::TailSends) -> Self {
        self.tail_sends = sends;
        self
    }
    /// New EQ follows gain and precedes saturation/balance by default. Editing
    /// an existing EQ preserves its authored position; removing it closes only
    /// that stage and keeps all other parameters and ordering.
    pub fn with_equalizer(
        &self,
        equalizer: Option<crate::EqualizerRecipe>,
    ) -> Result<Self, GainError> {
        let mut order: Vec<_> = self
            .order
            .iter()
            .copied()
            .filter(|stage| *stage != AudioTreatmentStage::Equalizer || equalizer.is_some())
            .collect();
        if equalizer.is_some() && !order.contains(&AudioTreatmentStage::Equalizer) {
            let index = order
                .iter()
                .position(|stage| {
                    matches!(
                        stage,
                        AudioTreatmentStage::Saturation | AudioTreatmentStage::StereoBalance
                    )
                })
                .unwrap_or(order.len());
            order.insert(index, AudioTreatmentStage::Equalizer);
        }
        Self::with_equalizer_stages(
            order,
            self.clip_gain.clone(),
            self.saturation,
            self.balance,
            equalizer,
        )
        .map(|recipe| {
            recipe
                .with_tail_sends(self.tail_sends)
                .with_wet_sends(self.wet_sends)
        })
    }
    pub fn is_empty(&self) -> bool {
        self.clip_gain.is_none()
            && self.saturation.is_none()
            && self.balance.is_none()
            && self.equalizer.is_none()
            && self.tail_sends.is_empty()
            && self.wet_sends.is_empty()
    }
    /// Balance is the final per-owner treatment. Adding another treatment
    /// later keeps it before balance; removing balance preserves that order.
    pub fn with_balance(&self, balance: Option<StereoBalance>) -> Result<Self, GainError> {
        let mut order: Vec<_> = self
            .order
            .iter()
            .copied()
            .filter(|stage| *stage != AudioTreatmentStage::StereoBalance)
            .collect();
        if balance.is_some() {
            order.push(AudioTreatmentStage::StereoBalance);
        }
        Self::with_equalizer_stages(
            order,
            self.clip_gain.clone(),
            self.saturation,
            balance,
            self.equalizer,
        )
        .map(|recipe| {
            recipe
                .with_tail_sends(self.tail_sends)
                .with_wet_sends(self.wet_sends)
        })
    }
    /// The same recipe with `saturation` replaced or removed. A new stage is
    /// placed after clip gain and before balance by default (specification
    /// §10.2); removing it keeps the remaining order.
    pub fn with_saturation(&self, saturation: Option<Saturation>) -> Result<Self, GainError> {
        let mut order: Vec<_> = self
            .order
            .iter()
            .copied()
            .filter(|stage| *stage != AudioTreatmentStage::Saturation || saturation.is_some())
            .collect();
        if saturation.is_some() && !order.contains(&AudioTreatmentStage::Saturation) {
            let index = order
                .iter()
                .position(|stage| *stage == AudioTreatmentStage::StereoBalance)
                .unwrap_or(order.len());
            order.insert(index, AudioTreatmentStage::Saturation);
        }
        Self::with_equalizer_stages(
            order,
            self.clip_gain.clone(),
            saturation,
            self.balance,
            self.equalizer,
        )
        .map(|recipe| {
            recipe
                .with_tail_sends(self.tail_sends)
                .with_wet_sends(self.wet_sends)
        })
    }
    /// The same recipe with `clip_gain` replaced, keeping the existing order
    /// and placing a new clip-gain stage first.
    pub fn with_clip_gain(&self, clip_gain: ClipGain) -> Result<Self, GainError> {
        let mut order = self.order.clone();
        if !order.contains(&AudioTreatmentStage::ClipGain) {
            order.insert(0, AudioTreatmentStage::ClipGain);
        }
        Self::with_equalizer_stages(
            order,
            Some(clip_gain),
            self.saturation,
            self.balance,
            self.equalizer,
        )
        .map(|recipe| {
            recipe
                .with_tail_sends(self.tail_sends)
                .with_wet_sends(self.wet_sends)
        })
    }
    /// `with_clip_gain`, except that a unity, unmuted clip gain with no
    /// envelopes or mute ranges removes the stage, so undoing a change by
    /// another change restores the plain recipe instead of keeping an inert
    /// stage.
    pub fn with_clip_gain_or_none(&self, clip_gain: ClipGain) -> Result<Self, GainError> {
        if clip_gain != ClipGain::default() {
            return self.with_clip_gain(clip_gain);
        }
        let order = self
            .order
            .iter()
            .copied()
            .filter(|stage| *stage != AudioTreatmentStage::ClipGain)
            .collect();
        Self::with_equalizer_stages(order, None, self.saturation, self.balance, self.equalizer).map(
            |recipe| {
                recipe
                    .with_tail_sends(self.tail_sends)
                    .with_wet_sends(self.wet_sends)
            },
        )
    }
    pub fn validate(&self) -> Result<(), GainError> {
        if self.order.len() > MAX_AUDIO_TREATMENT_STAGES {
            return Err(GainError::Limit);
        }
        let listed = |stage| self.order.iter().filter(|value| **value == stage).count();
        if listed(AudioTreatmentStage::ClipGain) != usize::from(self.clip_gain.is_some())
            || listed(AudioTreatmentStage::Saturation) != usize::from(self.saturation.is_some())
            || listed(AudioTreatmentStage::StereoBalance) != usize::from(self.balance.is_some())
            || listed(AudioTreatmentStage::Equalizer) != usize::from(self.equalizer.is_some())
            || (self.balance.is_some()
                && self.order.last() != Some(&AudioTreatmentStage::StereoBalance))
        {
            return Err(GainError::StageOrder);
        }
        if let Some(gain) = &self.clip_gain {
            gain.validate()?;
        }
        if let Some(saturation) = self.saturation {
            Saturation::new(saturation.drive)?;
        }
        if let Some(balance) = self.balance {
            StereoBalance::new(balance.percent())?;
        }
        Ok(())
    }
    pub fn record_count(&self) -> usize {
        self.clip_gain.as_ref().map_or(0, ClipGain::record_count)
            + usize::from(self.saturation.is_some())
            + usize::from(self.balance.is_some())
            + usize::from(self.equalizer.is_some())
            + self.tail_sends.record_count()
            + self.wet_sends.record_count()
    }
    /// Preserve existing effects when a physical owner gains a nonnegative
    /// whole-frame prefix: old material and every authored key move together.
    /// New effects can then use the current owner coordinates directly.
    ///
    /// Cropping retains the complete owner behind a Partition and does not call
    /// this helper. Tail growth also leaves these absolute keys unchanged.
    /// This pure transform changes no sampling clock, gain value, or wire type;
    /// callers must atomically update media placement and retained bindings.
    pub fn with_owner_prefix(&self, prefix: crate::FrameDuration) -> Result<Self, GainError> {
        self.validate()?;
        let mut result = self.clone();
        let shift = ExactRatio::integer(prefix.frames());
        if let Some(gain) = &mut result.clip_gain {
            for envelope in &mut gain.envelopes {
                envelope.range = GainRange::new(
                    envelope.range.start.checked_add(shift)?,
                    envelope.range.end.checked_add(shift)?,
                )?;
                for segment in &mut envelope.segments {
                    segment.end = segment.end.checked_add(shift)?;
                }
            }
            for range in &mut gain.mute_ranges {
                *range = GainRange::new(
                    range.start.checked_add(shift)?,
                    range.end.checked_add(shift)?,
                )?;
            }
        }
        result.validate()?;
        Ok(result)
    }

    pub fn evaluate(&self, local: ExactRatio) -> Result<EvaluatedGain, GainError> {
        self.clip_gain
            .as_ref()
            .map_or(Ok(EvaluatedGain::UNITY), |gain| gain.evaluate(local))
    }
}

/// Evaluated finite dB and exact mute remain separate. Values may exceed one
/// authored factor's bounds because overlapping factors add without limiting.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize)]
pub struct EvaluatedGain {
    pub millidecibels: ExactRatio,
    pub muted: bool,
}

impl EvaluatedGain {
    pub const UNITY: Self = Self {
        millidecibels: ExactRatio::ZERO,
        muted: false,
    };
    pub fn decibels(self) -> Result<ExactRatio, GainError> {
        Ok(self.millidecibels.checked_div(ExactRatio::integer(1000))?)
    }
}

/// Charge a document, subtree or patch-side before cloning its gain records.
/// Structural path depth is a separate plan/document responsibility.
pub fn validate_audio_treatments<'a>(
    treatments: impl IntoIterator<Item = &'a AudioTreatments>,
) -> Result<usize, GainError> {
    validate_audio_treatments_with_limit(treatments, MAX_GAIN_RECORDS)
}

fn validate_audio_treatments_with_limit<'a>(
    treatments: impl IntoIterator<Item = &'a AudioTreatments>,
    limit: usize,
) -> Result<usize, GainError> {
    let mut records = 0usize;
    for treatment in treatments {
        treatment.validate()?;
        records = records
            .checked_add(treatment.record_count())
            .ok_or(GainError::Limit)?;
        if records > limit {
            return Err(GainError::Limit);
        }
    }
    Ok(records)
}

/// Charge one structural provider-to-root path independently of the document's
/// aggregate record inventory. Explicit unity recipes still own a layer.
pub fn validate_audio_treatment_layers<'a>(
    treatments: impl IntoIterator<Item = &'a AudioTreatments>,
) -> Result<usize, GainError> {
    let mut layers = 0usize;
    for treatment in treatments {
        treatment.validate()?;
        layers += usize::from(!treatment.is_empty());
        if layers > MAX_GAIN_LAYERS {
            return Err(GainError::Limit);
        }
    }
    Ok(layers)
}
