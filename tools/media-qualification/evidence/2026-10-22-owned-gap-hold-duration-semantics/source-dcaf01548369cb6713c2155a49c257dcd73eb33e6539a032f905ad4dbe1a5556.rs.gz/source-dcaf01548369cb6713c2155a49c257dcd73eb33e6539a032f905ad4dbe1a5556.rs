//! Durable ownership of complete original bytes, separate from media readiness.
//!
//! These records do not register an authored AssetRecord. A host must separately
//! qualify every selected stream before committing immutable editorial metadata.
//! Locations are operational: relinking identical bytes does not edit history.

use std::fs::{File, Metadata};
use std::io::{self, Read, Seek, SeekFrom, Write};
use std::os::unix::fs::{FileExt, MetadataExt};
use std::path::{Component, Path, PathBuf};
use std::sync::Arc;
use std::sync::atomic::{AtomicBool, Ordering};
use std::time::{Duration, Instant};

use deadpan_core::{GeneratedError, GeneratedObjectRef};
use rusqlite::{Connection, TransactionBehavior, params};
use rustix::fs::{CWD, Mode, OFlags, openat};
use serde::{Deserialize, Serialize};
use sha2::{Digest, Sha256};
use thiserror::Error;

use crate::object_storage::{
    ObjectControl, ObjectFreshnessGuard, ObjectIdentity, ObjectLimits, ObjectStorage,
    ObjectStorageError, PromotionMethod, VerifiedObject,
};
use crate::{AccessMode, ProjectStore, StoreError};

// The existing core checksum type has no generation/acceptance authority.
pub use deadpan_core::GeneratedContentId as OriginalContentId;

const MAX_RECORD_BYTES: usize = 128 * 1024;
const MAX_ORIGINALS: i64 = 100_000;
const MAX_PATH_BYTES: usize = 16 * 1024;
const MAX_BOOKMARK_BYTES: usize = 16 * 1024;
const MAX_ORIGINAL_BYTES: u64 = 64 * 1024 * 1024 * 1024;

/// Algorithm-tagged identity of the entire container, not just decoded video.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
#[serde(try_from = "GeneratedObjectRef")]
pub struct OriginalObjectRef(GeneratedObjectRef);

impl TryFrom<GeneratedObjectRef> for OriginalObjectRef {
    type Error = OriginalMediaError;
    fn try_from(value: GeneratedObjectRef) -> Result<Self, Self::Error> {
        Self::new(value.content().clone(), value.byte_length())
    }
}

impl OriginalObjectRef {
    pub fn new(content: OriginalContentId, byte_length: u64) -> Result<Self, OriginalMediaError> {
        if byte_length > MAX_ORIGINAL_BYTES {
            return Err(OriginalMediaError::InvalidLimits);
        }
        Ok(Self(GeneratedObjectRef::new(content, byte_length)?))
    }
    pub fn content(&self) -> &OriginalContentId {
        self.0.content()
    }
    pub fn byte_length(&self) -> u64 {
        self.0.byte_length()
    }
    fn identity(&self) -> Result<ObjectIdentity<'_>, OriginalMediaError> {
        Ok(ObjectIdentity::new(
            self.content().digest(),
            self.byte_length(),
        )?)
    }
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct LinkedOriginal {
    path: PathBuf,
    /// Opaque platform bookmark, retained without executing or interpreting it.
    bookmark: Option<Vec<u8>>,
}

impl LinkedOriginal {
    pub fn new(path: PathBuf, bookmark: Option<Vec<u8>>) -> Result<Self, OriginalMediaError> {
        let value = Self { path, bookmark };
        value.validate()?;
        Ok(value)
    }
    pub fn path(&self) -> &Path {
        &self.path
    }
    pub fn bookmark(&self) -> Option<&[u8]> {
        self.bookmark.as_deref()
    }
    /// `path` with a fresh system bookmark when one can be made.
    pub fn bookmarked(path: PathBuf) -> Result<Self, OriginalMediaError> {
        let bookmark = bookmark_for(&path);
        Self::new(path, bookmark)
    }
    fn validate(&self) -> Result<(), OriginalMediaError> {
        validate_path(&self.path)?;
        if self
            .bookmark
            .as_ref()
            .is_some_and(|b| b.len() > MAX_BOOKMARK_BYTES)
        {
            return Err(OriginalMediaError::InvalidRecord(
                "bookmark exceeds byte limit",
            ));
        }
        Ok(())
    }
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct OriginalMediaRecord {
    object: OriginalObjectRef,
    /// Whole-file checksum retained for source-index identity matching.
    sha256: [u8; 32],
    label: String,
    version: u64,
    managed: bool,
    linked: Option<LinkedOriginal>,
}

impl OriginalMediaRecord {
    pub fn object(&self) -> &OriginalObjectRef {
        &self.object
    }
    pub fn sha256(&self) -> [u8; 32] {
        self.sha256
    }
    pub fn label(&self) -> &str {
        &self.label
    }
    pub fn version(&self) -> u64 {
        self.version
    }
    pub fn managed(&self) -> bool {
        self.managed
    }
    pub fn linked(&self) -> Option<&LinkedOriginal> {
        self.linked.as_ref()
    }
    fn validate(&self) -> Result<(), OriginalMediaError> {
        if self.object.byte_length() == 0
            || self.object.byte_length() > MAX_ORIGINAL_BYTES
            || self.version == 0
            || self.version > i64::MAX as u64
            || self.label.is_empty()
            || self.label.len() > 4096
            || self.label.contains('\0')
            || (!self.managed && self.linked.is_none())
        {
            return Err(OriginalMediaError::InvalidRecord(
                "invalid original ownership record",
            ));
        }
        if let Some(link) = &self.linked {
            link.validate()?;
        }
        Ok(())
    }
}

/// Metadata-only presence of an original's bytes; see `original_availability`.
#[derive(Debug, Clone, PartialEq, Eq, Serialize)]
#[serde(tag = "state", rename_all = "snake_case")]
pub enum OriginalAvailability {
    /// A regular file of the registered length exists. Its bytes are verified
    /// only when a snapshot reads them.
    Present,
    /// Nothing exists where the bytes belong (moved, deleted or offline).
    Missing,
    /// Something exists but cannot be the registered content.
    Unreadable { reason: String },
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub enum OriginalOwnership {
    Managed,
    Linked { bookmark: Option<Vec<u8>> },
}

impl OriginalOwnership {
    /// Linked to `path`, with a system bookmark when one can be made, so a
    /// later move can be found (see [`moved_location`]).
    pub fn linked_at(path: &Path) -> Self {
        Self::Linked {
            bookmark: bookmark_for(path),
        }
    }
}

/// A fresh system bookmark of `path`, or `None` where bookmarks are
/// unavailable (another platform, a missing file, a non-UTF-8 path).
pub fn bookmark_for(path: &Path) -> Option<Vec<u8>> {
    #[cfg(target_os = "macos")]
    {
        deadpan_filesystem::bookmark::create(path)
            .ok()
            .filter(|bookmark| !bookmark.is_empty() && bookmark.len() <= MAX_BOOKMARK_BYTES)
    }
    #[cfg(not(target_os = "macos"))]
    {
        let _ = path;
        None
    }
}

/// Where a linked original went, when its recorded path no longer names a
/// file and its bookmark resolves to a different existing regular file.
/// This is only a candidate: relink it with `prepare_relink`, which accepts
/// it only if its bytes have the original's exact BLAKE3 identity, length
/// and SHA-256. Resolution touches the filesystem; call it off the UI.
pub fn moved_location(record: &OriginalMediaRecord) -> Option<LinkedOriginal> {
    let linked = record.linked()?;
    if std::fs::symlink_metadata(linked.path()).is_ok() {
        return None;
    }
    #[cfg(target_os = "macos")]
    {
        let resolved = deadpan_filesystem::bookmark::resolve(linked.bookmark()?).ok()?;
        if resolved.path == linked.path()
            || !std::fs::symlink_metadata(&resolved.path).is_ok_and(|metadata| metadata.is_file())
        {
            return None;
        }
        let bookmark = bookmark_for(&resolved.path).or_else(|| linked.bookmark.clone());
        LinkedOriginal::new(resolved.path, bookmark).ok()
    }
    #[cfg(not(target_os = "macos"))]
    None
}

#[derive(Debug, Clone, Copy)]
pub struct OriginalMediaLimits {
    maximum_bytes: u64,
    timeout: Duration,
}

impl Default for OriginalMediaLimits {
    fn default() -> Self {
        Self {
            maximum_bytes: MAX_ORIGINAL_BYTES,
            timeout: Duration::from_secs(300),
        }
    }
}

impl OriginalMediaLimits {
    pub fn new(maximum_bytes: u64, timeout: Duration) -> Result<Self, OriginalMediaError> {
        if maximum_bytes == 0
            || maximum_bytes > MAX_ORIGINAL_BYTES
            || timeout.is_zero()
            || timeout > Duration::from_secs(3600)
        {
            return Err(OriginalMediaError::InvalidLimits);
        }
        Ok(Self {
            maximum_bytes,
            timeout,
        })
    }
    fn control(self, cancelled: &AtomicBool) -> Result<Control<'_>, OriginalMediaError> {
        Self::new(self.maximum_bytes, self.timeout)?;
        let control = Control {
            deadline: Instant::now() + self.timeout,
            cancelled,
            closed: None,
        };
        control.check()?;
        Ok(control)
    }
}

#[derive(Debug, Serialize)]
pub struct OriginalRetentionOutcome {
    pub record: OriginalMediaRecord,
    pub method: OriginalRetentionMethod,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize)]
#[serde(rename_all = "snake_case")]
pub enum OriginalRetentionMethod {
    Existing,
    Cloned,
    Copied,
    Linked,
}

enum SnapshotBytes {
    Managed(VerifiedObject),
    Linked(File),
}

/// Frozen verified full-file bytes. No writable descriptor is exposed.
pub struct VerifiedOriginalObject {
    bytes: SnapshotBytes,
    record: OriginalMediaRecord,
}

impl VerifiedOriginalObject {
    pub fn record(&self) -> &OriginalMediaRecord {
        &self.record
    }

    /// These verified private bytes as a decoder input, without a second
    /// copy. The snapshot is an anonymous temporary file this store wrote
    /// while hashing what it copied: the copy's BLAKE3 identity, SHA-256 and
    /// length equal the record's (managed objects also recheck the package
    /// file's state around the read). The store keeps no other handle and
    /// this consumes the object, so nothing else can modify the bytes.
    /// `identity` must carry the record's SHA-256 and length, or this refuses.
    pub fn into_source_input(
        self,
        identity: deadpan_media::source_index::SourceContentIdentity,
    ) -> Result<deadpan_media::source_input::VerifiedSourceInput, StoreError> {
        if identity.sha256() != self.record.sha256
            || identity.byte_length() != self.record.object.byte_length()
        {
            return Err(OriginalMediaError::IdentityMismatch.into());
        }
        let mut file = match self.bytes {
            SnapshotBytes::Managed(object) => object.into_file(),
            SnapshotBytes::Linked(file) => file,
        };
        file.seek(SeekFrom::Start(0))?;
        deadpan_media::source_input::VerifiedSourceInput::from_store_verified_snapshot(
            file, identity,
        )
        .map_err(|_| OriginalMediaError::IdentityMismatch.into())
    }
}
impl Read for VerifiedOriginalObject {
    fn read(&mut self, buffer: &mut [u8]) -> io::Result<usize> {
        match &mut self.bytes {
            SnapshotBytes::Managed(file) => file.read(buffer),
            SnapshotBytes::Linked(file) => file.read(buffer),
        }
    }
}
impl Seek for VerifiedOriginalObject {
    fn seek(&mut self, position: SeekFrom) -> io::Result<u64> {
        match &mut self.bytes {
            SnapshotBytes::Managed(file) => file.seek(position),
            SnapshotBytes::Linked(file) => file.seek(position),
        }
    }
}

/// Connection-free authority for one writable store session. Clones neither
/// borrow SQLite nor retain the writer lock, and closing the store revokes them.
#[derive(Clone)]
pub struct OriginalImportHandle {
    storage: Arc<ObjectStorage>,
    closed: Arc<AtomicBool>,
    /// False for a viewing handle of a read-only store: it can snapshot and
    /// verify retained bytes but never prepares a write into the package.
    writable: bool,
}

enum OriginalFreshnessGuard {
    Managed(ObjectFreshnessGuard),
    Linked {
        path: PathBuf,
        file: File,
        state: Metadata,
    },
}

impl OriginalFreshnessGuard {
    fn recheck(&self, storage: &ObjectStorage) -> Result<(), OriginalMediaError> {
        match self {
            Self::Managed(guard) => Ok(storage.recheck_guard(guard)?),
            Self::Linked { path, file, state } => confirm_source_path(path, file, state),
        }
    }
}

/// Published or linked bytes awaiting the owning writer's inventory transaction.
/// This cannot be minted from a serialized ownership record.
pub struct PreparedOriginalRetention {
    handle: OriginalImportHandle,
    record: OriginalMediaRecord,
    method: OriginalRetentionMethod,
    guard: OriginalFreshnessGuard,
}

impl PreparedOriginalRetention {
    pub fn object(&self) -> &OriginalObjectRef {
        &self.record.object
    }

    fn recheck(&self, cancelled: &AtomicBool) -> Result<(), StoreError> {
        self.handle.check_live(cancelled)?;
        self.guard.recheck(&self.handle.storage)?;
        self.handle.check_live(cancelled)
    }
}

/// A verified managed copy awaiting the writer, plus the name a damaged copy
/// was moved to, if one was.
pub struct PreparedOriginalRestore {
    pub retention: PreparedOriginalRetention,
    pub quarantined: Option<String>,
}

/// Verified replacement location awaiting the owning writer's versioned update.
/// This cannot be minted from a serialized ownership record.
pub struct PreparedOriginalRelink {
    handle: OriginalImportHandle,
    record: OriginalMediaRecord,
    location: LinkedOriginal,
    guard: OriginalFreshnessGuard,
}

impl PreparedOriginalRelink {
    fn recheck(&self, cancelled: &AtomicBool) -> Result<(), StoreError> {
        self.handle.check_live(cancelled)?;
        self.guard.recheck(&self.handle.storage)?;
        self.handle.check_live(cancelled)
    }
}

/// Private verified bytes plus retained-original availability evidence. Reading
/// remains valid after store close; admission requires a live matching session.
pub struct PreparedOriginalSnapshot {
    handle: OriginalImportHandle,
    original: VerifiedOriginalObject,
    guard: OriginalFreshnessGuard,
}

impl PreparedOriginalSnapshot {
    pub fn record(&self) -> &OriginalMediaRecord {
        self.original.record()
    }

    /// See [`VerifiedOriginalObject::into_source_input`]. This consumes the
    /// snapshot and its freshness guard, so use it only for reading (preview,
    /// playback); store admission needs an unconsumed prepared snapshot. The
    /// returned bytes stay readable after the store closes.
    pub fn into_source_input(
        self,
        identity: deadpan_media::source_index::SourceContentIdentity,
    ) -> Result<deadpan_media::source_input::VerifiedSourceInput, StoreError> {
        self.original.into_source_input(identity)
    }

    pub(crate) fn validate_for(
        &self,
        store: &ProjectStore,
        cancelled: &AtomicBool,
    ) -> Result<(), StoreError> {
        self.handle.validate_for(store, cancelled)?;
        let current = read_record(&store.connection, self.record().object.content())?
            .ok_or(OriginalMediaError::MissingRecord)?;
        if current.version != self.record().version {
            return Err(OriginalMediaError::VersionConflict {
                current: current.version,
            }
            .into());
        }
        if current != *self.record() {
            return Err(OriginalMediaError::IdentityMismatch.into());
        }
        self.recheck(cancelled)
    }

    pub(crate) fn recheck(&self, cancelled: &AtomicBool) -> Result<(), StoreError> {
        self.handle.check_live(cancelled)?;
        self.guard.recheck(&self.handle.storage)?;
        self.handle.check_live(cancelled)
    }
}

impl Read for PreparedOriginalSnapshot {
    fn read(&mut self, buffer: &mut [u8]) -> io::Result<usize> {
        self.original.read(buffer)
    }
}

impl Seek for PreparedOriginalSnapshot {
    fn seek(&mut self, position: SeekFrom) -> io::Result<u64> {
        self.original.seek(position)
    }
}

impl OriginalImportHandle {
    /// Check revocation even when a consumer already owns decoded private bytes.
    pub fn check_live(&self, cancelled: &AtomicBool) -> Result<(), StoreError> {
        if self.closed.load(Ordering::Acquire) {
            return Err(OriginalMediaError::ImportSessionClosed.into());
        }
        if cancelled.load(Ordering::Acquire) {
            return Err(OriginalMediaError::Cancelled.into());
        }
        Ok(())
    }

    /// A viewing handle refuses every preparation that writes media.
    fn require_writable(&self) -> Result<(), StoreError> {
        if self.writable {
            Ok(())
        } else {
            Err(StoreError::ReadOnly)
        }
    }

    /// Pointer identity establishes the owning session, independently of liveness.
    pub fn same_session(&self, other: &Self) -> bool {
        Arc::ptr_eq(&self.storage, &other.storage) && Arc::ptr_eq(&self.closed, &other.closed)
    }

    fn validate_for(&self, store: &ProjectStore, cancelled: &AtomicBool) -> Result<(), StoreError> {
        require_writer(store)?;
        self.check_live(cancelled)?;
        if !Arc::ptr_eq(&self.storage, &store.original_storage)
            || !Arc::ptr_eq(&self.closed, &store.import_closed)
        {
            return Err(OriginalMediaError::ImportSessionMismatch.into());
        }
        Ok(())
    }

    /// Hashes, clones or copies, and publishes original bytes without SQLite.
    /// Publication survives later cancellation or inventory transaction failure.
    pub fn prepare_retention(
        &self,
        path: &Path,
        ownership: OriginalOwnership,
        limits: OriginalMediaLimits,
        cancelled: &AtomicBool,
    ) -> Result<PreparedOriginalRetention, StoreError> {
        self.require_writable()?;
        self.check_live(cancelled)?;
        let control = limits.control(cancelled)?.with_closed(&self.closed);
        validate_path(path)?;
        let linked = match &ownership {
            OriginalOwnership::Managed => None,
            OriginalOwnership::Linked { bookmark } => {
                Some(LinkedOriginal::new(path.to_owned(), bookmark.clone())?)
            }
        };
        let label = path
            .file_name()
            .and_then(|n| n.to_str())
            .ok_or(OriginalMediaError::InvalidRecord(
                "source filename is not valid UTF-8",
            ))?
            .to_owned();
        let file = open_source(path)?;
        let InspectedOriginal {
            object,
            sha256,
            state,
        } = inspect_original(&file, limits, &control, io::sink())?;
        let (method, guard) = match ownership {
            OriginalOwnership::Managed => {
                let object_limits =
                    ObjectLimits::new(limits.maximum_bytes).map_err(OriginalMediaError::from)?;
                let method = self
                    .storage
                    .promote_file_controlled(
                        &file,
                        object.identity()?,
                        object_limits,
                        control.object_control(),
                    )
                    .map_err(OriginalMediaError::from)?;
                let (guard, published_sha256) = self
                    .storage
                    .guard_controlled(object.identity()?, object_limits, control.object_control())
                    .map_err(OriginalMediaError::from)?;
                if published_sha256 != sha256 {
                    return Err(OriginalMediaError::IdentityMismatch.into());
                }
                let method = match method {
                    PromotionMethod::Existing => OriginalRetentionMethod::Existing,
                    PromotionMethod::Cloned => OriginalRetentionMethod::Cloned,
                    PromotionMethod::Copied => OriginalRetentionMethod::Copied,
                };
                (method, OriginalFreshnessGuard::Managed(guard))
            }
            OriginalOwnership::Linked { .. } => {
                confirm_source_path(path, &file, &state)?;
                (
                    OriginalRetentionMethod::Linked,
                    OriginalFreshnessGuard::Linked {
                        path: path.to_owned(),
                        file,
                        state,
                    },
                )
            }
        };
        control.check()?;
        self.check_live(cancelled)?;
        let record = OriginalMediaRecord {
            object,
            sha256,
            label,
            version: 1,
            managed: !matches!(method, OriginalRetentionMethod::Linked),
            linked,
        };
        record.validate()?;
        Ok(PreparedOriginalRetention {
            handle: self.clone(),
            record,
            method,
            guard,
        })
    }

    /// Verifies complete replacement bytes without SQLite. The captured record
    /// and expected location version are checked again by the owning writer.
    pub fn prepare_relink(
        &self,
        record: &OriginalMediaRecord,
        expected_version: u64,
        location: LinkedOriginal,
        limits: OriginalMediaLimits,
        cancelled: &AtomicBool,
    ) -> Result<PreparedOriginalRelink, StoreError> {
        self.require_writable()?;
        self.check_live(cancelled)?;
        record.validate()?;
        location.validate()?;
        let control = limits.control(cancelled)?.with_closed(&self.closed);
        if record.version != expected_version {
            return Err(OriginalMediaError::VersionConflict {
                current: record.version,
            }
            .into());
        }
        if record.object.byte_length() > limits.maximum_bytes {
            return Err(OriginalMediaError::ByteLimit.into());
        }
        let file = open_source(location.path())?;
        let InspectedOriginal {
            object,
            sha256,
            state,
        } = inspect_original(&file, limits, &control, io::sink())?;
        if object != record.object || sha256 != record.sha256 {
            return Err(OriginalMediaError::IdentityMismatch.into());
        }
        confirm_source_path(location.path(), &file, &state)?;
        control.check()?;
        Ok(PreparedOriginalRelink {
            handle: self.clone(),
            record: record.clone(),
            guard: OriginalFreshnessGuard::Linked {
                path: location.path().to_owned(),
                file,
                state,
            },
            location,
        })
    }

    /// Restores a missing or damaged project-managed copy from a file the
    /// person chose. The chosen file is hashed first and must match the
    /// registered BLAKE3 identity and SHA-256, so different media is refused
    /// before anything is written and the refusal names the chosen file. A
    /// retained copy that then fails its own verification is moved aside
    /// (`quarantine_damaged`) and replaced. Commit the result with
    /// `retain_prepared_original`, which keeps the record and its location
    /// version. A linked-only original uses `prepare_relink`.
    pub fn prepare_restore(
        &self,
        record: &OriginalMediaRecord,
        path: &Path,
        limits: OriginalMediaLimits,
        cancelled: &AtomicBool,
    ) -> Result<PreparedOriginalRestore, StoreError> {
        self.require_writable()?;
        self.check_live(cancelled)?;
        record.validate()?;
        if !record.managed {
            return Err(OriginalMediaError::InvalidRecord(
                "only a project-managed original copy can be restored; relink a linked original",
            )
            .into());
        }
        validate_path(path)?;
        let control = limits.control(cancelled)?.with_closed(&self.closed);
        if record.object.byte_length() > limits.maximum_bytes {
            return Err(OriginalMediaError::ByteLimit.into());
        }
        let file = open_source(path)?;
        let chosen = inspect_original(&file, limits, &control, io::sink())?;
        if chosen.object != record.object || chosen.sha256 != record.sha256 {
            return Err(OriginalMediaError::IdentityMismatch.into());
        }
        confirm_source_path(path, &file, &chosen.state)?;
        let object_limits =
            ObjectLimits::new(limits.maximum_bytes).map_err(OriginalMediaError::from)?;
        let quarantined = self
            .storage
            .quarantine_damaged(
                record.object.identity()?,
                object_limits,
                control.object_control(),
            )
            .map_err(OriginalMediaError::from)?;
        let method = self
            .storage
            .promote_file_controlled(
                &file,
                record.object.identity()?,
                object_limits,
                control.object_control(),
            )
            .map_err(OriginalMediaError::from)?;
        let (guard, published_sha256) = self
            .storage
            .guard_controlled(
                record.object.identity()?,
                object_limits,
                control.object_control(),
            )
            .map_err(OriginalMediaError::from)?;
        if published_sha256 != record.sha256 {
            return Err(OriginalMediaError::IdentityMismatch.into());
        }
        control.check()?;
        self.check_live(cancelled)?;
        Ok(PreparedOriginalRestore {
            retention: PreparedOriginalRetention {
                handle: self.clone(),
                record: record.clone(),
                method: match method {
                    PromotionMethod::Existing => OriginalRetentionMethod::Existing,
                    PromotionMethod::Cloned => OriginalRetentionMethod::Cloned,
                    PromotionMethod::Copied => OriginalRetentionMethod::Copied,
                },
                guard: OriginalFreshnessGuard::Managed(guard),
            },
            quarantined,
        })
    }

    /// Verifies retained bytes into an immutable snapshot on the worker. The
    /// supplied record is checked against SQLite only when the writer admits it.
    pub fn snapshot_original(
        &self,
        record: &OriginalMediaRecord,
        limits: OriginalMediaLimits,
        cancelled: &AtomicBool,
    ) -> Result<PreparedOriginalSnapshot, StoreError> {
        self.check_live(cancelled)?;
        record.validate()?;
        let control = limits.control(cancelled)?.with_closed(&self.closed);
        if record.object.byte_length() > limits.maximum_bytes {
            return Err(OriginalMediaError::ByteLimit.into());
        }
        let (bytes, guard) = if record.managed {
            let (snapshot, guard) = self
                .storage
                .guarded_snapshot_controlled(
                    record.object.identity()?,
                    ObjectLimits::new(limits.maximum_bytes).map_err(OriginalMediaError::from)?,
                    control.object_control(),
                )
                .map_err(OriginalMediaError::from)?;
            if snapshot.sha256() != record.sha256 {
                return Err(OriginalMediaError::IdentityMismatch.into());
            }
            (
                SnapshotBytes::Managed(snapshot),
                OriginalFreshnessGuard::Managed(guard),
            )
        } else {
            let link = record
                .linked
                .as_ref()
                .ok_or(OriginalMediaError::MissingRecord)?;
            let file = open_source(link.path())?;
            let mut copy = tempfile::tempfile()?;
            let InspectedOriginal {
                object,
                sha256,
                state,
            } = inspect_original(&file, limits, &control, &mut copy)?;
            if object != record.object || sha256 != record.sha256 {
                return Err(OriginalMediaError::IdentityMismatch.into());
            }
            confirm_source_path(link.path(), &file, &state)?;
            copy.seek(SeekFrom::Start(0))?;
            (
                SnapshotBytes::Linked(copy),
                OriginalFreshnessGuard::Linked {
                    path: link.path().to_owned(),
                    file,
                    state,
                },
            )
        };
        control.check()?;
        self.check_live(cancelled)?;
        Ok(PreparedOriginalSnapshot {
            handle: self.clone(),
            original: VerifiedOriginalObject {
                bytes,
                record: record.clone(),
            },
            guard,
        })
    }
}

impl ProjectStore {
    pub fn original_import_handle(&self) -> Result<OriginalImportHandle, StoreError> {
        require_writer(self)?;
        Ok(OriginalImportHandle {
            storage: Arc::clone(&self.original_storage),
            closed: Arc::clone(&self.import_closed),
            writable: true,
        })
    }

    /// A handle for reading retained originals from any store, including a
    /// read-only view of a newer package. It refuses every preparation that
    /// would write media.
    pub fn original_view_handle(&self) -> OriginalImportHandle {
        OriginalImportHandle {
            storage: Arc::clone(&self.original_storage),
            closed: Arc::clone(&self.import_closed),
            writable: self.mode == crate::AccessMode::ReadWrite,
        }
    }

    /// Retain complete original bytes or an explicit linked location. This does
    /// not assert decodability, audio readiness, or change authored history.
    pub fn retain_original(
        &mut self,
        path: &Path,
        ownership: OriginalOwnership,
        limits: OriginalMediaLimits,
        cancelled: &AtomicBool,
    ) -> Result<OriginalRetentionOutcome, StoreError> {
        let handle = self.original_import_handle()?;
        let control = limits.control(cancelled)?;
        let prepared = handle.prepare_retention(path, ownership, limits, cancelled)?;
        self.retain_prepared_original_controlled(&prepared, cancelled, Some(&control))
    }

    /// Performs only freshness checks and an atomic inventory merge. Complete
    /// byte verification and publication already ran on the preparation worker.
    pub fn retain_prepared_original(
        &mut self,
        prepared: &PreparedOriginalRetention,
        cancelled: &AtomicBool,
    ) -> Result<OriginalRetentionOutcome, StoreError> {
        self.retain_prepared_original_controlled(prepared, cancelled, None)
    }

    fn retain_prepared_original_controlled(
        &mut self,
        prepared: &PreparedOriginalRetention,
        cancelled: &AtomicBool,
        control: Option<&Control<'_>>,
    ) -> Result<OriginalRetentionOutcome, StoreError> {
        prepared.handle.validate_for(self, cancelled)?;
        prepared.recheck(cancelled)?;
        if let Some(control) = control {
            control.check()?;
        }
        let object = &prepared.record.object;
        let sha256 = prepared.record.sha256;
        let method = prepared.method;
        let transaction = self
            .connection
            .transaction_with_behavior(TransactionBehavior::Immediate)?;
        let old = read_record(&transaction, object.content())?;
        if let Some(old) = &old
            && (old.object != *object || old.sha256 != sha256)
        {
            return Err(OriginalMediaError::IdentityMismatch.into());
        }
        // Preparation cannot know which location the writer will retain by the
        // time it finishes. Merge new ownership, but never let a delayed import
        // replace an established link. Location changes use versioned relinking.
        if let Some(old) = &old
            && let (Some(current), Some(incoming)) = (&old.linked, &prepared.record.linked)
            && current != incoming
        {
            return Err(OriginalMediaError::VersionConflict {
                current: old.version,
            }
            .into());
        }
        let mut record = old.clone().unwrap_or_else(|| prepared.record.clone());
        record.managed |= prepared.record.managed;
        if prepared.record.linked.is_some() {
            record.linked = prepared.record.linked.clone();
        }
        if let Some(old) = &old {
            if record != *old {
                record.version = next_version(retired_floor(&transaction, old)?)?;
            }
        } else {
            let count: i64 =
                transaction.query_row("SELECT COUNT(*) FROM original_media", [], |r| r.get(0))?;
            if count >= MAX_ORIGINALS {
                return Err(OriginalMediaError::RecordLimit.into());
            }
            // Re-registered after a restore discarded its record: continue
            // past every location version that record ever had.
            let retired = crate::retired::floor(
                &transaction,
                "original_version",
                &record.object.content().to_string(),
            )?;
            if retired > 0 {
                record.version = next_version(retired_floor(&transaction, &record)?)?;
            }
        }
        write_record(&transaction, &record)?;
        prepared.recheck(cancelled)?;
        if let Some(control) = control {
            control.check()?;
        }
        transaction.commit()?;
        Ok(OriginalRetentionOutcome { record, method })
    }

    pub fn original_record(
        &self,
        content: &OriginalContentId,
    ) -> Result<Option<OriginalMediaRecord>, StoreError> {
        read_record(&self.connection, content)
    }

    /// Whether the bytes a snapshot would read are plausibly present, from
    /// metadata alone. Snapshots still verify every byte; this lets a host
    /// open a project with a missing Original and say so instead of failing
    /// later inside a decoder. A managed copy is what snapshots read, so a
    /// managed record reports that copy even when a link also exists.
    pub fn original_availability(
        &self,
        record: &OriginalMediaRecord,
    ) -> Result<OriginalAvailability, StoreError> {
        record.validate()?;
        let expected = record.object.byte_length();
        let found = if record.managed {
            self.original_storage
                .probe(record.object.identity()?)
                .map_err(OriginalMediaError::from)?
        } else {
            let link = record
                .linked
                .as_ref()
                .ok_or(OriginalMediaError::MissingRecord)?;
            match std::fs::symlink_metadata(link.path()) {
                Err(error) if error.kind() == io::ErrorKind::NotFound => None,
                Err(error) => {
                    return Ok(OriginalAvailability::Unreadable {
                        reason: error.to_string(),
                    });
                }
                Ok(metadata) if !metadata.file_type().is_file() => {
                    return Ok(OriginalAvailability::Unreadable {
                        reason: "the linked location is not a regular file".into(),
                    });
                }
                Ok(metadata) => Some(metadata.len()),
            }
        };
        Ok(match found {
            None => OriginalAvailability::Missing,
            Some(length) if length == expected => OriginalAvailability::Present,
            Some(length) => OriginalAvailability::Unreadable {
                reason: format!("the file has {length} bytes; the Original has {expected}"),
            },
        })
    }

    /// Drop the linked location of an original that also has a managed copy
    /// present in this package, so the package no longer refers outside
    /// itself. Used when building a portable copy; the managed copy has
    /// already been verified against the record's identity.
    pub(crate) fn detach_original_link(
        &mut self,
        content: &OriginalContentId,
    ) -> Result<OriginalMediaRecord, StoreError> {
        require_writer(self)?;
        let transaction = self
            .connection
            .transaction_with_behavior(TransactionBehavior::Immediate)?;
        let mut record =
            read_record(&transaction, content)?.ok_or(OriginalMediaError::MissingRecord)?;
        if record.linked.is_none() {
            return Ok(record);
        }
        if !record.managed
            || self
                .original_storage
                .probe(record.object.identity()?)
                .map_err(OriginalMediaError::from)?
                != Some(record.object.byte_length())
        {
            return Err(OriginalMediaError::InvalidRecord(
                "a link is dropped only after its managed copy is present",
            )
            .into());
        }
        record.linked = None;
        record.version = next_version(retired_floor(&transaction, &record)?)?;
        write_record(&transaction, &record)?;
        transaction.commit()?;
        Ok(record)
    }

    /// Keyset paging bounds UI/headless inventory memory independently of project size.
    pub fn original_records(
        &self,
        after: Option<&OriginalContentId>,
        limit: u32,
    ) -> Result<Vec<OriginalMediaRecord>, StoreError> {
        if limit == 0 || limit > 1000 {
            return Err(OriginalMediaError::InvalidRecord("page size must be 1..=1000").into());
        }
        let mut statement = self.connection.prepare(
            "SELECT content_id, version, record FROM original_media WHERE content_id > ?1 ORDER BY content_id LIMIT ?2")?;
        let mut rows = statement.query(params![
            after.map(ToString::to_string).unwrap_or_default(),
            limit
        ])?;
        let mut records = Vec::new();
        while let Some(row) = rows.next()? {
            records.push(decode_row(row)?);
        }
        Ok(records)
    }

    /// A matching name never authorizes replacement. Verify the complete new
    /// location, then compare the monotonic locator version in one transaction.
    pub fn relink_original(
        &mut self,
        content: &OriginalContentId,
        expected_version: u64,
        location: LinkedOriginal,
        limits: OriginalMediaLimits,
        cancelled: &AtomicBool,
    ) -> Result<OriginalMediaRecord, StoreError> {
        let handle = self.original_import_handle()?;
        location.validate()?;
        let control = limits.control(cancelled)?;
        let old =
            read_record(&self.connection, content)?.ok_or(OriginalMediaError::MissingRecord)?;
        let prepared =
            handle.prepare_relink(&old, expected_version, location, limits, cancelled)?;
        self.relink_prepared_original_controlled(&prepared, cancelled, Some(&control))
    }

    /// Performs only descriptor/path freshness checks and one versioned
    /// inventory transaction. Complete byte verification ran during preparation.
    pub fn relink_prepared_original(
        &mut self,
        prepared: &PreparedOriginalRelink,
        cancelled: &AtomicBool,
    ) -> Result<OriginalMediaRecord, StoreError> {
        self.relink_prepared_original_controlled(prepared, cancelled, None)
    }

    fn relink_prepared_original_controlled(
        &mut self,
        prepared: &PreparedOriginalRelink,
        cancelled: &AtomicBool,
        control: Option<&Control<'_>>,
    ) -> Result<OriginalMediaRecord, StoreError> {
        prepared.handle.validate_for(self, cancelled)?;
        prepared.recheck(cancelled)?;
        if let Some(control) = control {
            control.check()?;
        }
        let transaction = self
            .connection
            .transaction_with_behavior(TransactionBehavior::Immediate)?;
        let mut record = read_record(&transaction, prepared.record.object.content())?
            .ok_or(OriginalMediaError::MissingRecord)?;
        if record.version != prepared.record.version {
            return Err(OriginalMediaError::VersionConflict {
                current: record.version,
            }
            .into());
        }
        if record != prepared.record {
            return Err(OriginalMediaError::IdentityMismatch.into());
        }
        if record.linked.as_ref() != Some(&prepared.location) {
            record.linked = Some(prepared.location.clone());
            record.version = next_version(retired_floor(&transaction, &record)?)?;
            write_record(&transaction, &record)?;
        }
        prepared.recheck(cancelled)?;
        if let Some(control) = control {
            control.check()?;
        }
        transaction.commit()?;
        Ok(record)
    }

    /// Rechecks identity before every use and returns an independent snapshot.
    /// Missing/corrupt originals fail explicitly; no offline image is invented.
    pub fn snapshot_original(
        &self,
        content: &OriginalContentId,
        limits: OriginalMediaLimits,
        cancelled: &AtomicBool,
    ) -> Result<VerifiedOriginalObject, StoreError> {
        let control = limits.control(cancelled)?;
        let record =
            read_record(&self.connection, content)?.ok_or(OriginalMediaError::MissingRecord)?;
        if record.object.byte_length() > limits.maximum_bytes {
            return Err(OriginalMediaError::ByteLimit.into());
        }
        let bytes = if record.managed {
            let snapshot = self
                .original_storage
                .snapshot_controlled(
                    record.object.identity()?,
                    ObjectLimits::new(limits.maximum_bytes).map_err(OriginalMediaError::from)?,
                    control.object_control(),
                )
                .map_err(OriginalMediaError::from)?;
            if snapshot.sha256() != record.sha256 {
                return Err(OriginalMediaError::IdentityMismatch.into());
            }
            SnapshotBytes::Managed(snapshot)
        } else {
            let link = record
                .linked
                .as_ref()
                .ok_or(OriginalMediaError::MissingRecord)?;
            let file = open_source(link.path())?;
            let mut copy = tempfile::tempfile()?;
            let InspectedOriginal { object, sha256, .. } =
                inspect_original(&file, limits, &control, &mut copy)?;
            if object != record.object || sha256 != record.sha256 {
                return Err(OriginalMediaError::IdentityMismatch.into());
            }
            copy.seek(SeekFrom::Start(0))?;
            SnapshotBytes::Linked(copy)
        };
        control.check()?;
        Ok(VerifiedOriginalObject { bytes, record })
    }
}

fn require_writer(store: &ProjectStore) -> Result<(), StoreError> {
    if store.mode != AccessMode::ReadWrite {
        Err(StoreError::ReadOnly)
    } else {
        Ok(())
    }
}

fn validate_path(path: &Path) -> Result<(), OriginalMediaError> {
    let text = path.to_str().ok_or(OriginalMediaError::InvalidRecord(
        "source path is not valid UTF-8",
    ))?;
    if !path.is_absolute()
        || text.len() > MAX_PATH_BYTES
        || text.contains('\0')
        || path
            .components()
            .any(|part| matches!(part, Component::ParentDir))
    {
        return Err(OriginalMediaError::InvalidRecord(
            "source path must be absolute, bounded, and have no parent traversal",
        ));
    }
    Ok(())
}

fn open_source(path: &Path) -> Result<File, OriginalMediaError> {
    let file = File::from(
        openat(
            CWD,
            path,
            OFlags::RDONLY | OFlags::NONBLOCK | OFlags::NOFOLLOW | OFlags::CLOEXEC,
            Mode::empty(),
        )
        .map_err(|e| OriginalMediaError::Io(e.into()))?,
    );
    if !file.metadata()?.is_file() {
        return Err(OriginalMediaError::NotRegular);
    }
    Ok(file)
}

fn confirm_source_path(
    path: &Path,
    file: &File,
    inspected: &Metadata,
) -> Result<(), OriginalMediaError> {
    let named = open_source(path)?.metadata()?;
    let original = file.metadata()?;
    if !same_source_state(inspected, &named) || !same_source_state(inspected, &original) {
        return Err(OriginalMediaError::SourceChanged);
    }
    Ok(())
}

/// Identity, size and modification time. Change time is excluded because
/// File Provider domains (iCloud Drive Documents and Desktop) add extended
/// attributes to a chosen file around selection, changing ctime but not
/// content; the bytes are hashed in the same pass.
fn same_source_state(before: &Metadata, after: &Metadata) -> bool {
    before.dev() == after.dev()
        && before.ino() == after.ino()
        && before.len() == after.len()
        && before.mtime() == after.mtime()
        && before.mtime_nsec() == after.mtime_nsec()
}

struct Control<'a> {
    deadline: Instant,
    cancelled: &'a AtomicBool,
    closed: Option<&'a AtomicBool>,
}
impl<'a> Control<'a> {
    fn with_closed(mut self, closed: &'a AtomicBool) -> Self {
        self.closed = Some(closed);
        self
    }

    fn check(&self) -> Result<(), OriginalMediaError> {
        if self
            .closed
            .is_some_and(|closed| closed.load(Ordering::Acquire))
        {
            return Err(OriginalMediaError::ImportSessionClosed);
        }
        if self.cancelled.load(Ordering::Acquire) {
            return Err(OriginalMediaError::Cancelled);
        }
        if Instant::now() >= self.deadline {
            return Err(OriginalMediaError::Deadline);
        }
        Ok(())
    }
    fn object_control(&self) -> ObjectControl<'_> {
        let control = ObjectControl::bounded(self.deadline, self.cancelled);
        match self.closed {
            Some(closed) => control.with_closed(closed),
            None => control,
        }
    }
}

struct InspectedOriginal {
    object: OriginalObjectRef,
    sha256: [u8; 32],
    state: Metadata,
}

fn inspect_original(
    file: &File,
    limits: OriginalMediaLimits,
    control: &Control<'_>,
    mut copy: impl Write,
) -> Result<InspectedOriginal, OriginalMediaError> {
    control.check()?;
    let before = file.metadata()?;
    if !before.is_file() {
        return Err(OriginalMediaError::NotRegular);
    }
    if before.len() == 0 || before.len() > limits.maximum_bytes {
        return Err(OriginalMediaError::ByteLimit);
    }
    let mut blake3 = blake3::Hasher::new();
    let mut sha256 = Sha256::new();
    let mut offset = 0_u64;
    let mut buffer = [0_u8; 64 * 1024];
    loop {
        control.check()?;
        let count = file.read_at(&mut buffer, offset)?;
        if count == 0 {
            break;
        }
        offset = offset
            .checked_add(u64::try_from(count).expect("buffer size fits u64"))
            .ok_or(OriginalMediaError::ByteLimit)?;
        if offset > before.len() || offset > limits.maximum_bytes {
            return Err(OriginalMediaError::SourceChanged);
        }
        blake3.update(&buffer[..count]);
        sha256.update(&buffer[..count]);
        copy.write_all(&buffer[..count])?;
    }
    let after = file.metadata()?;
    if offset != before.len() || !same_source_state(&before, &after) {
        return Err(OriginalMediaError::SourceChanged);
    }
    control.check()?;
    Ok(InspectedOriginal {
        object: OriginalObjectRef::new(
            OriginalContentId::new(blake3.finalize().to_hex().to_string())?,
            offset,
        )?,
        sha256: sha256.finalize().into(),
        state: after,
    })
}

/// A record's version, raised to any location version a restore discarded.
fn retired_floor(connection: &Connection, record: &OriginalMediaRecord) -> Result<u64, StoreError> {
    let retired = crate::retired::floor(
        connection,
        "original_version",
        &record.object.content().to_string(),
    )?;
    Ok(record.version.max(u64::try_from(retired).unwrap_or(0)))
}

fn next_version(version: u64) -> Result<u64, OriginalMediaError> {
    version
        .checked_add(1)
        .filter(|v| *v <= i64::MAX as u64)
        .ok_or(OriginalMediaError::VersionExhausted)
}

pub(crate) fn create_tables(connection: &Connection) -> Result<(), StoreError> {
    connection.execute_batch(
        "CREATE TABLE original_media (
        content_id TEXT PRIMARY KEY,
        version INTEGER NOT NULL CHECK(version > 0),
        record TEXT NOT NULL CHECK(json_valid(record))
    ) STRICT;",
    )?;
    Ok(())
}

pub(crate) fn check_stored_sizes(connection: &Connection) -> Result<(), StoreError> {
    let oversized: bool = connection.query_row(
        "SELECT EXISTS(SELECT 1 FROM original_media WHERE length(CAST(record AS BLOB)) > ?1 OR length(CAST(content_id AS BLOB)) > 71)",
        [i64::try_from(MAX_RECORD_BYTES).expect("record limit fits SQLite")], |row| row.get(0))?;
    let count: i64 =
        connection.query_row("SELECT COUNT(*) FROM original_media", [], |row| row.get(0))?;
    if oversized || count > MAX_ORIGINALS {
        return Err(OriginalMediaError::RecordLimit.into());
    }
    Ok(())
}

pub(crate) fn validate_store(connection: &Connection) -> Result<(), StoreError> {
    check_stored_sizes(connection)?;
    let mut statement = connection
        .prepare("SELECT content_id, version, record FROM original_media ORDER BY content_id")?;
    let mut rows = statement.query([])?;
    while let Some(row) = rows.next()? {
        decode_row(row)?;
    }
    Ok(())
}

pub(crate) fn read_record(
    connection: &Connection,
    content: &OriginalContentId,
) -> Result<Option<OriginalMediaRecord>, StoreError> {
    let mut statement = connection
        .prepare("SELECT content_id, version, record FROM original_media WHERE content_id=?1")?;
    let mut rows = statement.query([content.to_string()])?;
    rows.next()?.map(decode_row).transpose()
}

fn decode_row(row: &rusqlite::Row<'_>) -> Result<OriginalMediaRecord, StoreError> {
    let content: String = row.get(0)?;
    let version = u64::try_from(row.get::<_, i64>(1)?)
        .map_err(|_| OriginalMediaError::InvalidRecord("negative location version"))?;
    let bytes = row
        .get_ref(2)?
        .as_str()
        .map_err(|_| OriginalMediaError::InvalidRecord("ownership record is not text"))?;
    if bytes.len() > MAX_RECORD_BYTES {
        return Err(OriginalMediaError::RecordLimit.into());
    }
    let record: OriginalMediaRecord = serde_json::from_str(bytes)?;
    record.validate()?;
    if record.object.content().to_string() != content || record.version != version {
        return Err(
            OriginalMediaError::InvalidRecord("ownership columns disagree with record").into(),
        );
    }
    Ok(record)
}

fn write_record(connection: &Connection, record: &OriginalMediaRecord) -> Result<(), StoreError> {
    record.validate()?;
    let json = serde_json::to_string(record)?;
    if json.len() > MAX_RECORD_BYTES {
        return Err(OriginalMediaError::RecordLimit.into());
    }
    connection.execute(
        "INSERT INTO original_media(content_id,version,record) VALUES(?1,?2,?3)
        ON CONFLICT(content_id) DO UPDATE SET version=excluded.version,record=excluded.record",
        params![
            record.object.content().to_string(),
            i64::try_from(record.version).map_err(|_| OriginalMediaError::VersionExhausted)?,
            json
        ],
    )?;
    Ok(())
}

#[derive(Debug, Error)]
pub enum OriginalMediaError {
    #[error("original-media byte or time limits are invalid")]
    InvalidLimits,
    #[error("original-media record is invalid: {0}")]
    InvalidRecord(&'static str),
    #[error("original-media record or inventory exceeds its limit")]
    RecordLimit,
    #[error("original content is not registered")]
    MissingRecord,
    #[error("original source is not a regular file")]
    NotRegular,
    #[error("original source is empty or exceeds the byte budget")]
    ByteLimit,
    #[error("original source changed during verification")]
    SourceChanged,
    #[error("source content does not match the registered original")]
    IdentityMismatch,
    #[error("original location conflicts with current inventory version {current}")]
    VersionConflict { current: u64 },
    #[error("original location versions are exhausted")]
    VersionExhausted,
    #[error("original-media operation cancelled")]
    Cancelled,
    #[error("original import belongs to a closed store session")]
    ImportSessionClosed,
    #[error("original import belongs to a different store session")]
    ImportSessionMismatch,
    #[error("original-media operation exceeded its deadline")]
    Deadline,
    #[error(transparent)]
    Identity(#[from] GeneratedError),
    #[error(transparent)]
    Storage(#[from] ObjectStorageError),
    #[error(transparent)]
    Io(#[from] io::Error),
}

impl OriginalMediaError {
    pub fn code(&self) -> &'static str {
        match self {
            Self::VersionConflict { .. } => "OriginalLocationConflict",
            Self::MissingRecord => "OriginalNotFound",
            Self::IdentityMismatch | Self::SourceChanged => "OriginalContentMismatch",
            Self::Cancelled => "OriginalCancelled",
            Self::ImportSessionClosed => "OriginalImportClosed",
            Self::ImportSessionMismatch => "OriginalImportSessionMismatch",
            Self::Deadline => "OriginalDeadline",
            Self::Io(e) if e.kind() == io::ErrorKind::NotFound => "OriginalOffline",
            Self::Io(e) if e.kind() == io::ErrorKind::PermissionDenied => "PermissionDenied",
            Self::Io(e) if e.kind() == io::ErrorKind::ReadOnlyFilesystem => "ProjectReadOnly",
            Self::Io(e)
                if matches!(
                    e.kind(),
                    io::ErrorKind::StorageFull | io::ErrorKind::QuotaExceeded
                ) =>
            {
                "DiskFull"
            }
            Self::Io(_) => "IoFailure",
            Self::Storage(e) => match e {
                ObjectStorageError::Cancelled => "OriginalCancelled",
                ObjectStorageError::SessionClosed => "OriginalImportClosed",
                ObjectStorageError::DeadlineExceeded => "OriginalDeadline",
                ObjectStorageError::MissingObject(_)
                | ObjectStorageError::MissingStorageComponent(_) => "OriginalOffline",
                ObjectStorageError::HashMismatch { .. }
                | ObjectStorageError::LengthMismatch { .. }
                | ObjectStorageError::SourceChanged => "OriginalContentMismatch",
                ObjectStorageError::Io { .. }
                | ObjectStorageError::System { .. }
                | ObjectStorageError::SourceRead { .. } => e.code(),
                _ => "OriginalStorageInvalid",
            },
            _ => "OriginalInvalid",
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::fs::{self, FileTimes};

    #[test]
    fn final_link_confirmation_rejects_same_inode_changes_after_hashing() {
        let scratch = tempfile::tempdir().unwrap();
        let path = scratch.path().join("linked.mov");
        fs::write(&path, b"original").unwrap();
        let file = open_source(&path).unwrap();
        let limits = OriginalMediaLimits::default();
        let cancelled = AtomicBool::new(false);
        let control = limits.control(&cancelled).unwrap();
        let inspected = inspect_original(&file, limits, &control, io::sink()).unwrap();
        confirm_source_path(&path, &file, &inspected.state).unwrap();

        fs::write(&path, b"modified").unwrap();
        // Force a distinct timestamp even on a filesystem with coarse clocks.
        file.set_times(
            FileTimes::new()
                .set_modified(inspected.state.modified().unwrap() + Duration::from_secs(2)),
        )
        .unwrap();
        assert_eq!(file.metadata().unwrap().ino(), inspected.state.ino());
        assert_eq!(file.metadata().unwrap().len(), inspected.state.len());
        assert!(matches!(
            confirm_source_path(&path, &file, &inspected.state),
            Err(OriginalMediaError::SourceChanged)
        ));
    }

    #[test]
    fn file_provider_attributes_change_ctime_without_counting_as_source_changes() {
        let scratch = tempfile::tempdir().unwrap();
        let path = scratch.path().join("chosen.mov");
        fs::write(&path, b"original").unwrap();
        let file = open_source(&path).unwrap();
        let limits = OriginalMediaLimits::default();
        let cancelled = AtomicBool::new(false);
        let control = limits.control(&cancelled).unwrap();
        let inspected = inspect_original(&file, limits, &control, io::sink()).unwrap();
        std::thread::sleep(Duration::from_millis(5));
        // What iCloud Drive's File Provider does to a selected file.
        rustix::fs::setxattr(
            &path,
            "com.apple.fileprovider.deadpan-test#P",
            b"1",
            rustix::fs::XattrFlags::empty(),
        )
        .unwrap();
        let changed = file.metadata().unwrap();
        assert!(
            (changed.ctime(), changed.ctime_nsec())
                != (inspected.state.ctime(), inspected.state.ctime_nsec())
        );
        confirm_source_path(&path, &file, &inspected.state).unwrap();
    }
}
