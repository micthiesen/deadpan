//! One explicit Play can resize a Hold under its fixed Edit Retime without
//! changing the other Repeat plays or the exterior audio owner.
use super::*;

fn repeated_fixed_fixture(prebound: bool) -> ProjectDocument {
    let mut wire =
        serde_json::to_value(super::super::fixture(PitchPolicy::Preserve, 1, false)).unwrap();
    let order = IterationOrder::new(RevisionId::new("this-play-fixed-outer").unwrap(), 3).unwrap();
    let mut outer = BeatNode::sequence("Three fixed-stage plays", vec![]);
    outer.kind = NodeKind::Repeat {
        child: id("processor"),
        iterations: order,
        gap: None,
        escalation: None,
    };
    wire["nodes"]["outer"] = serde_json::to_value(outer).unwrap();
    wire["nodes"]["exterior"] = serde_json::to_value(voice()).unwrap();
    wire["nodes"]["root"]["kind"]["children"] = serde_json::json!(["outer", "exterior"]);
    let document = ProjectDocument::from_json(&wire.to_string()).unwrap();
    document.validate().unwrap();
    if !prebound {
        return document;
    }
    // Capture clocks only after the actual Repeat and exterior audio owner
    // exist, so each binding is tied to the repeated physical owner it serves.
    let bindings = capture_unbound_audio_bindings(
        &document,
        AudioTimingId {
            allocation: RevisionId::new("this-play-fixed-audio-clocks").unwrap(),
            ordinal: 0,
        },
    )
    .unwrap();
    assert!(
        bindings.bindings().contains_key(&id("processor")),
        "the repeated Retime's actual audio owner receives its captured binding"
    );
    wire = serde_json::to_value(&document).unwrap();
    wire["audio_bindings"] = serde_json::to_value(bindings).unwrap();
    let document = ProjectDocument::from_json(&wire.to_string()).unwrap();
    document.validate().unwrap();
    document
}

fn occurrence(document: &ProjectDocument, play: u32, target: &str) -> InstancePath {
    let NodeKind::Repeat { iterations, .. } = &document.nodes()[&id("outer")].kind else {
        unreachable!()
    };
    InstancePath {
        node: id(target),
        repeats: vec![RepeatInstance {
            node: id("outer"),
            iteration: iterations.at(play).unwrap(),
        }],
    }
}

fn occurrence_resize(
    document: &ProjectDocument,
    instance: InstancePath,
    frames: i64,
    revision: &str,
) -> deadpan_core::PreparedOccurrenceHoldDuration {
    let length = duration(frames);
    let needs = document
        .occurrence_hold_duration_requirements(&instance, length)
        .unwrap();
    let request = CommandRequest {
        project_id: document.project_id().clone(),
        expected_revision: document.revision_id().clone(),
        new_revision: RevisionId::new(revision).unwrap(),
        command: Command::EditOccurrence {
            instance,
            edit: OccurrenceEdit::SetHoldDuration { duration: length },
            identities: OccurrenceIdentities {
                nodes: (0..needs.nodes)
                    .map(|index| id(&format!("this-play-clone-{revision}-{index}")))
                    .collect(),
                marks: (0..needs.marks)
                    .map(|index| MarkId::new(format!("this-play-mark-{revision}-{index}")).unwrap())
                    .collect(),
            },
        },
    };
    deadpan_core::prepare_occurrence_hold_duration(document, &request).unwrap()
}

fn stage_input(plan: &Arc<RenderPlan>, provider: &mut FixtureProvider, chunks: &[u32]) -> Recorded {
    super::super::super::input_record(plan, provider, ratio(1, 1)..ratio(8, 1), 0..11212, chunks)
}

#[test]
fn this_play_fixed_retime_duration_preserves_fractional_input_phase_and_other_owners() {
    for prebound in [false, true] {
        let before = repeated_fixed_fixture(prebound);
        let mut provider = mono_original(2).1;
        let before_plan = Arc::new(RenderPlan::compile(&before).unwrap());
        let old_input = stage_input(&before_plan, &mut provider, &[127, 3, 251]);
        same_recorded(
            &old_input,
            &super::super::super::direct_input_reference(&provider, 1, 2),
            0,
            "old fractional fixed-Retime input",
        );
        let old_output = record(&before, &mut provider, false, &[127, 3, 251]);
        let old_total = old_output.samples.len();
        let play1 = ntsc_boundary(4) as usize;
        let play2 = ntsc_boundary(8) as usize;
        let exterior = ntsc_boundary(12) as usize;
        assert_eq!(old_total, ntsc_boundary(16) as usize);

        // The selected default-body play needs the exact fresh isolation pool.
        let selected = occurrence(&before, 0, "pause");
        let needs = before
            .occurrence_hold_duration_requirements(&selected, duration(3))
            .unwrap();
        assert_eq!((needs.nodes, needs.marks), (5, 0));
        let grown = occurrence_resize(&before, selected, 3, "this-play-grow");
        assert_eq!(
            grown.fixed_visibility().unwrap().frames,
            FrameRange::new(ProjectFrame(1), ProjectFrame(3)).unwrap()
        );
        assert_ne!(grown.presentation.node, id("pause"));
        assert_ne!(grown.target.node, id("pause"));
        assert_eq!(
            grown.transaction.duration_delta, 0,
            "fixed Retime extent is stable"
        );
        assert_eq!(
            grown.document.duration().unwrap().frames(),
            before.duration().unwrap().frames()
        );

        let grown_plan = Arc::new(RenderPlan::compile(&grown.document).unwrap());
        let grown_input = stage_input(&grown_plan, &mut provider, &[127, 3, 251]);
        same_recorded(
            &grown_input,
            &super::super::super::direct_input_reference(&provider, 1, 3),
            0,
            "grown fixed-Retime PointCeil input",
        );
        assert_eq!(grown_input.samples[11211], [0.0; 2]);
        assert!(
            grown_input.suppressed[11211],
            "fractional crop exhaustion remains silent"
        );
        same_recorded(
            &stage_input(&grown_plan, &mut provider, &[1, 239]),
            &grown_input,
            0,
            "grown fixed-Retime chunk parity",
        );
        let grown_output = record(&grown.document, &mut provider, false, &[127, 3, 251]);
        assert_eq!(
            grown_output.samples.len(),
            old_total,
            "fixed stage output stays fixed"
        );
        assert_ne!(
            grown_output.samples[..play1],
            old_output.samples[..play1],
            "the selected Play's shifted Hold/Speech boundary changes its actual PCM"
        );
        assert_eq!(
            grown_output.samples[play1..play2],
            old_output.samples[play1..play2]
        );
        assert_eq!(
            grown_output.suppressed[play1..play2],
            old_output.suppressed[play1..play2]
        );
        assert_eq!(
            grown_output.samples[play2..exterior],
            old_output.samples[play2..exterior]
        );
        assert_eq!(
            grown_output.suppressed[play2..exterior],
            old_output.suppressed[play2..exterior]
        );
        assert_eq!(
            grown_output.samples[exterior..],
            old_output.samples[exterior..]
        );
        assert_eq!(
            grown_output.suppressed[exterior..],
            old_output.suppressed[exterior..]
        );
        assert_eq!(
            record(&grown.document, &mut provider, false, &[1, 239]),
            grown_output
        );

        // Once the selected Play owns its clone, the next duration edit uses
        // no identities, but still traverses the same fixed window.
        let already_owned = grown
            .document
            .occurrence_hold_duration_requirements(&grown.presentation, duration(1))
            .unwrap();
        assert_eq!((already_owned.nodes, already_owned.marks), (0, 0));
        let shrunk = occurrence_resize(
            &grown.document,
            grown.presentation.clone(),
            1,
            "this-play-shrink",
        );
        assert_eq!(
            shrunk.fixed_visibility().unwrap().frames,
            FrameRange::new(ProjectFrame(1), ProjectFrame(2)).unwrap()
        );
        assert_eq!(
            shrunk.document.duration().unwrap().frames(),
            before.duration().unwrap().frames()
        );
        let shrunk_plan = Arc::new(RenderPlan::compile(&shrunk.document).unwrap());
        let shrunk_input = stage_input(&shrunk_plan, &mut provider, &[251, 3, 127]);
        same_recorded(
            &shrunk_input,
            &super::super::super::direct_input_reference(&provider, 1, 1),
            0,
            "shrunk fixed-Retime PointCeil input",
        );
        assert_eq!(shrunk_input.samples[11211], [0.0; 2]);
        assert!(shrunk_input.suppressed[11211]);
        let shrunk_output = record(&shrunk.document, &mut provider, false, &[127, 3, 251]);
        assert_ne!(
            shrunk_output.samples[..play1],
            grown_output.samples[..play1],
            "the second duration edit changes the selected Play's PCM again"
        );
        assert_eq!(
            shrunk_output.samples[play1..],
            grown_output.samples[play1..]
        );
        assert_eq!(
            shrunk_output.suppressed[play1..],
            grown_output.suppressed[play1..]
        );
    }
}
