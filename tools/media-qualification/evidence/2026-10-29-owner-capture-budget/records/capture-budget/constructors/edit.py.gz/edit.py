from pathlib import Path
base=Path("/tmp/deadpan-owner-capture-budget-2026-10-29/constructors/candidate/crates/deadpan-plan/src")
p=base/"audio_boundary.rs"
s=p.read_text()
s=s.replace("use super::audio::Budget;\nuse crate::PlanError;","""use super::audio::Budget;
use super::audio_owners::admission::{
    Budget as QueryBudget, Memory, Owned, Result as QueryResult, Unmetered, outer,
};
use crate::{AudioSoundContextAdmission, PlanError};""")
start=s.index("impl BoundaryOwner<'_> {")
s=s[:start]+"""impl BoundaryOwner<'_> {
    pub(super) fn capture(
        self,
        kind: AudioBoundaryKind,
        budget: &mut Budget,
    ) -> Result<AudioBoundaryOrigin, PlanError> {
        let mut admission = Unmetered;
        outer::<_, Unmetered>(
            self.capture_admitted(kind, &mut QueryBudget::new(budget, &mut admission)),
        )
        .map(Owned::unmetered)
    }

    pub(in crate::plan) fn capture_admitted<A: AudioSoundContextAdmission>(
        self,
        kind: AudioBoundaryKind,
        budget: &mut QueryBudget<'_, A>,
    ) -> QueryResult<Owned<AudioBoundaryOrigin, A::Issuer, A::Lease>, A> {
        // This canonical debit already prepays the path copy. Helpers add
        // only actual metered layout/identity inspections before allocation.
        budget.canonical(self.repeats.len() + 1)?;
        let mut memory = budget.memory();
        let mut capacity = budget.memory();
        let node = budget.node(&mut memory, self.node)?;
        let repeats = budget.repeats(&mut memory, &mut capacity, self.repeats)?;
        let gap_after = self
            .gap_after
            .map(|gap| budget.iteration(&mut memory, gap))
            .transpose()?;
        let value = AudioBoundaryOrigin {
            instance: InstancePath { node, repeats },
            gap_after,
            kind,
            placement_support: self.placement_support,
            policy: self.policies.get(kind),
        };
        budget.check_memory(&memory)?;
        budget.check_memory(&capacity)?;
        budget.merge_checked(&mut memory, &mut capacity);
        Ok(Owned { value, memory })
    }
}

pub(super) struct AudioExtent {
    pub range: Range<ExactRatio>,
    pub boundaries: AudioBoundaries,
}

impl AudioExtent {
    pub fn new(range: Range<ExactRatio>) -> Self {
        Self {
            range,
            boundaries: AudioBoundaries::default(),
        }
    }

    pub fn clip_start(
        &mut self,
        value: ExactRatio,
        owner: BoundaryOwner<'_>,
        kind: AudioBoundaryKind,
        budget: &mut Budget,
    ) -> Result<(), PlanError> {
        let mut admission = Unmetered;
        let range = self.range.clone();
        let mut extent = AdmittedExtent::from_value(
            std::mem::replace(self, Self::new(range)),
            (),
        );
        let result = extent.clip_start(
            value,
            owner,
            kind,
            &mut QueryBudget::new(budget, &mut admission),
        );
        // Preserve the actual caller's state even if the shared body fails.
        *self = extent.into_unmetered();
        outer::<_, Unmetered>(result)
    }

    pub fn clip_end(
        &mut self,
        value: ExactRatio,
        owner: BoundaryOwner<'_>,
        kind: AudioBoundaryKind,
        budget: &mut Budget,
    ) -> Result<(), PlanError> {
        let mut admission = Unmetered;
        let range = self.range.clone();
        let mut extent = AdmittedExtent::from_value(
            std::mem::replace(self, Self::new(range)),
            (),
        );
        let result = extent.clip_end(
            value,
            owner,
            kind,
            &mut QueryBudget::new(budget, &mut admission),
        );
        *self = extent.into_unmetered();
        outer::<_, Unmetered>(result)
    }
}

struct ExtentMemory<I, L> {
    origins: Memory<I, L>,
    start: Memory<I, L>,
    end: Memory<I, L>,
}

/// Actual boundary storage and its independent payload/capacity charges.
/// Clearing origins retains vector capacity. Owning-edge charges may remain
/// conservatively held until this extent drops, including cleared origins.
pub(in crate::plan) struct AdmittedExtent<I, L> {
    value: AudioExtent,
    memory: ExtentMemory<I, L>,
}

impl<I: Copy + Eq, L> AdmittedExtent<I, L> {
    pub(in crate::plan) fn new(range: Range<ExactRatio>, issuer: I) -> Self {
        Self::from_value(AudioExtent::new(range), issuer)
    }

    fn from_value(value: AudioExtent, issuer: I) -> Self {
        Self {
            value,
            memory: ExtentMemory {
                origins: Memory::empty(issuer),
                start: Memory::empty(issuer),
                end: Memory::empty(issuer),
            },
        }
    }

    pub(in crate::plan) fn clip_start<
        A: AudioSoundContextAdmission<Issuer = I, Lease = L>,
    >(
        &mut self,
        value: ExactRatio,
        owner: BoundaryOwner<'_>,
        kind: AudioBoundaryKind,
        budget: &mut QueryBudget<'_, A>,
    ) -> QueryResult<(), A> {
        let comparison = self.value.range.start.checked_sub(value)?.compare_integer(0);
        if comparison.is_le() {
            let mut origin = owner.capture_admitted(kind, budget)?;
            if comparison.is_lt() {
                self.value.boundaries.start.clear();
                self.value.range.start = value;
            }
            let needed = self.value.boundaries.start.len() + 1;
            budget.grow(
                &mut self.value.boundaries.start,
                &mut self.memory.start,
                needed,
            )?;
            budget.check_memory(&self.memory.origins)?;
            budget.check_memory(&origin.memory)?;
            budget.merge_checked(&mut self.memory.origins, &mut origin.memory);
            self.value.boundaries.start.push(origin.value);
        }
        Ok(())
    }

    pub(in crate::plan) fn clip_end<
        A: AudioSoundContextAdmission<Issuer = I, Lease = L>,
    >(
        &mut self,
        value: ExactRatio,
        owner: BoundaryOwner<'_>,
        kind: AudioBoundaryKind,
        budget: &mut QueryBudget<'_, A>,
    ) -> QueryResult<(), A> {
        let comparison = self.value.range.end.checked_sub(value)?.compare_integer(0);
        if comparison.is_ge() {
            let mut origin = owner.capture_admitted(kind, budget)?;
            if comparison.is_gt() {
                self.value.boundaries.end.clear();
                self.value.range.end = value;
            }
            let needed = self.value.boundaries.end.len() + 1;
            budget.grow(
                &mut self.value.boundaries.end,
                &mut self.memory.end,
                needed,
            )?;
            budget.check_memory(&self.memory.origins)?;
            budget.check_memory(&origin.memory)?;
            budget.merge_checked(&mut self.memory.origins, &mut origin.memory);
            self.value.boundaries.end.push(origin.value);
        }
        Ok(())
    }

    pub(in crate::plan) fn finish<
        A: AudioSoundContextAdmission<Issuer = I, Lease = L>,
    >(
        mut self,
        budget: &mut QueryBudget<'_, A>,
    ) -> QueryResult<Owned<AudioExtent, I, L>, A> {
        budget.check_memory(&self.memory.origins)?;
        budget.check_memory(&self.memory.start)?;
        budget.check_memory(&self.memory.end)?;
        budget.merge_checked(&mut self.memory.origins, &mut self.memory.start);
        budget.merge_checked(&mut self.memory.origins, &mut self.memory.end);
        Ok(Owned {
            value: self.value,
            memory: self.memory.origins,
        })
    }
}

impl AdmittedExtent<(), ()> {
    pub(in crate::plan) fn into_unmetered(self) -> AudioExtent {
        self.value
    }
}

impl<I, L> std::ops::Deref for AdmittedExtent<I, L> {
    type Target = AudioExtent;
    fn deref(&self) -> &Self::Target {
        &self.value
    }
}

impl<I, L> std::ops::DerefMut for AdmittedExtent<I, L> {
    fn deref_mut(&mut self) -> &mut Self::Target {
        &mut self.value
    }
}

#[cfg(test)]
#[path = "audio_capture_constructor_tests.rs"]
mod tests;
"""
p.write_text(s)
p=base/"audio_signal.rs"
s=p.read_text()
needle="use super::audio_domain::DomainGap;"
assert s.count(needle)==1
s=s.replace(needle,needle+"""
use super::audio_owners::admission::{
    Budget as QueryBudget, Owned, Result as QueryResult, Unmetered, outer,
};""")
start=s.index("    pub(super) fn for_node(")
stop=s.index("\n    pub fn descriptor(",start)
s=s[:start]+"""    pub(super) fn for_node(
        plan: &'plan RenderPlan,
        node: usize,
        repeats: &[RepeatInstance],
        definition: Option<&AudioDefinitionSelector>,
        bypass_binding: Option<BindingTarget>,
    ) -> Result<Self, PlanError> {
        // This constructor had no local canonical debit; callers retain their
        // existing prepaid copy charge. False mode performs no additional work.
        let mut local = Budget {
            remaining: 0,
            lookup: LookupStats::default(),
        };
        let mut admission = Unmetered;
        outer::<_, Unmetered>(Self::for_node_admitted(
            plan,
            node,
            repeats,
            definition,
            bypass_binding,
            &mut QueryBudget::new(&mut local, &mut admission),
        ))
        .map(Owned::unmetered)
    }

    pub(in crate::plan) fn for_node_admitted<A: AudioSoundContextAdmission>(
        plan: &'plan RenderPlan,
        node: usize,
        repeats: &[RepeatInstance],
        definition: Option<&AudioDefinitionSelector>,
        bypass_binding: Option<BindingTarget>,
        budget: &mut QueryBudget<'_, A>,
    ) -> QueryResult<Owned<Self, A::Issuer, A::Lease>, A> {
        let compiled = &plan.nodes[node];
        if compiled.preserve_input.is_some() {
            return Err(PlanError::InvalidPlan(
                "owned Preserve input requires its compiled projection",
            ).into());
        }
        let CompiledKind::Retime {
            child,
            start,
            scale,
            pitch,
            ..
        } = &compiled.kind
        else {
            return Err(PlanError::InvalidPlan("audio stage is not a retime").into());
        };
        if !pitch.processes(*scale == ExactRatio::ONE) {
            return Err(PlanError::InvalidPlan(
                "audio stage is not nonunity Preserve",
            ).into());
        }
        if compiled.extent != ExactRatio::integer(compiled.inspection.duration.frames()) {
            return Err(PlanError::InvalidPlan(
                "derived Preserve allocation requires an owned processing route",
            ).into());
        }
        let mut memory = budget.memory();
        let mut capacity = budget.memory();
        // Field order matches the existing descriptor, including fallible
        // selection arithmetic AFTER every descriptor identity/path copy.
        let project_id = budget.project(&mut memory, &plan.metadata.project_id)?;
        let revision_id = budget.revision(&mut memory, &plan.metadata.revision_id)?;
        let definition = budget.definition_ref(&mut memory, definition)?;
        let instance = InstancePath {
            node: budget.node(&mut memory, &compiled.inspection.id)?,
            repeats: budget.repeats(&mut memory, &mut capacity, repeats)?,
        };
        let child_id = budget.node(&mut memory, &plan.nodes[*child].inspection.id)?;
        let selection = *start
            ..start.checked_add(scale.checked_mul(ExactRatio::integer(
                compiled.inspection.duration.frames(),
            ))?)?;
        let value = Self {
            plan,
            child: *child,
            node,
            descriptor: AudioStageDescriptor {
                project_id,
                revision_id,
                definition,
                instance,
                child: child_id,
                selection,
                duration: compiled.inspection.duration,
                rate: *scale,
                pitch: *pitch,
                bypass_binding: bypass_binding == Some(BindingTarget::Node(node)),
            },
        };
        budget.check_memory(&memory)?;
        budget.check_memory(&capacity)?;
        budget.merge_checked(&mut memory, &mut capacity);
        Ok(Owned { value, memory })
    }
""" +s[stop:]
p.write_text(s)
print("two scratch candidates written")
