# Capture constructor helpers, frozen scratch candidate

Only three candidate paths:
- crates/deadpan-plan/src/audio_boundary.rs
- crates/deadpan-plan/src/audio_signal.rs
- new crates/deadpan-plan/src/audio_capture_constructor_tests.rs

No live/scoped/index source edits, Cargo, rustc, provider/native calls or Git
operations. Only these scratch Rust files were rustfmt-parsed. The two live
owned source files still match before-pins.json. Full scratch patch reviewed;
audit.json and candidate-pins.json pin its exact contents. Parent owns all
compilation/qualification and integration. These tests have NOT been executed.

## Agreed private interface

Agreed with Plan owner constant_prefix_snapshot before patching:

BoundaryOwner::capture_admitted<A>(self, kind, &mut QueryBudget<A>)
 -> QueryResult<Owned<AudioBoundaryOrigin,A::Issuer,A::Lease>,A>.

AdmittedExtent<I,L> owns actual AudioExtent FIRST, then origins/start/end Memory.
- new(range,issuer) has no heap allocation.
- Deref/DerefMut exposes actual AudioExtent to the trusted private walker.
- clip_start/end(value,owner,kind,&mut QueryBudget<A>) -> QueryResult<(),A>.
- finish(self,&mut QueryBudget<A>) -> QueryResult<Owned<AudioExtent,I,L>,A>.
- into_unmetered only for unit issuer/lease in cfg(test).

AudioStage::for_node_admitted<A>(
 plan,node,repeats,definition,bypass_binding,&mut QueryBudget<A>
) -> QueryResult<Owned<AudioStage,A::Issuer,A::Lease>,A>.

Plan owner provides Budget::project and exposes revision pub(in crate::plan);
existing node/definition_ref/repeats/memory/check_memory/grow helpers are reused.
This task did NOT edit the shared Budget/admission source. Parent must apply
these helpers together with the actual walker consumer, not as unused hooks.

## Actual construction/order and work

Boundary capture is one shared body. The old capture wrapper remains used by
audio_fades::append_origins, borrows its SAME existing Budget, and calls that
body with Unmetered. Canonical repeats.len()+1 remains INSIDE capture before
copies. Helpers add only their real metered inspections/reservations.

The generic clipping body preserves comparison, capture, conditional clear and
range mutation, then push order. Actual Vec capacity is reserved through grow
before allocation/push. A new policy failure at grow may follow the already
performed old clear/range mutation. The caller must discard a failed walk;
no atomic extent mutation or published partial result is promised.

The Plan owner confirms the rewritten actual walker uses AdmittedExtent in
both modes. Old plain AudioExtent clip wrappers have no other production
callers and are cfg(test) parity adapters. They restore the actual value on
both success/error without cloning a graph. BoundaryOwner::capture is NOT
cfg(test), because the retained-probe fade path still needs it.

Stage for_node is a compatibility wrapper over the SAME generic constructor.
Its zero local canonical allowance cannot refresh any caller's work: this
constructor never had its own Budget or canonical debit, and false mode adds
none. Existing outer repeats.len()+1 stays where already paid by the walker.
True mode uses that caller's actual QueryBudget. The old four semantic guards
are unchanged and precede descriptor construction. Project, revision,
definition, instance node/repeats and child copies keep their old order;
selection arithmetic remains AFTER all those copies. for_owned_input and all
other AudioStage constructors are untouched.

All complete returned values precede their independent memory fields.
Origin/Stage temporary metadata stays alive until value construction and
postconstruction issuer checks complete; failures drop values before charges.
No Core APIs, source authority, PCM, query, cache, cap or weights change.

## Honest memory bound

Extent's origin owning-edge charge conservatively accumulates until extent
drop, including cleared origins. This is explicit per-container conservative
retention, NOT a claim that freed identity bytes remain physically live.
Clearing start/end Vec retains actual capacity, which remains separately
charged. Buffer growth admits full new plus live old capacity, uses the common
actual grow helper, and releases old capacity only after its old Vec drops.
finish merges already-checked live lanes only; it does not add a new reservation.

No per-entry BTree estimate, maximum-depth reserve, extra traversal, graph Arc,
processor or provider is introduced. This helper model does not establish
capture/query overlap peak, retained-probe admission, native/RSS bounds or cold
graph closure. Parent's full capture tests must cover those actual lifetimes.

## Eight focused tests authored, not run

1. capture_boundaries_keep_literal_coincidence_order_capacity_and_paid_work
   Literal outer/inner coincident order, exact narrower replacement, gap/
   edge policy and end range; clearing retains capacity; canonical12 for six
   accepted captures with one Repeat; legacy two captures exactly exhaust4.
2. capture_boundary_actual_peak_and_work_boundaries_release_every_lane
   Actual measured reservation peak, exact/one-byte-short repeat, exact/one-work
   short, all charges released. No dry-run product branch or allocator claim.
3. capture_boundary_ignores_nonintersections_before_work_and_allocation
   Already narrower interval refuses no owner, spends0, reserves0.
4. capture_boundary_refused_origin_does_not_publish_and_wrong_issuer_cleans_up
   Real allocation refusal/cancellation and post-reserve issuer change, no
   origin/range publication at this tested early point and zero final charge.
5. capture_stage_literal_descriptor_matches_legacy_with_only_outer_canonical_copy
   Validated ordinary Preserve plan, literal selection/rate/IDs/bypass/path;
   SAME plan brand and legacy descriptor, exactly2 outer canonical units.
6. capture_stage_actual_peak_and_cancel_failure_have_no_returned_value_or_charge
   Actual peak exact/one-byte-short, exact/one-work-short, cancellation cleanup;
   constructor itself canonical0. Policy logs are test-owned, not product heap.
7. capture_stage_preserves_semantic_failure_before_allocation_and_late_arithmetic
   Wrong-kind semantic error before allocation; private impossible compiled
   selection tests unchanged late overflow AFTER descriptor copy reservations.
   No product validation bypass or injection hook is added.
8. capture_stage_keeps_unity_shift_processing_and_follow_speed_refusal
   Validated unity nonzero Shift still processes, exact stage plan brand rejects
   equal foreign allocation; FollowSpeed refusal occurs before reservations.

Legacy-vs-new wrapper comparisons are bridge checks because both use the shared
body. Literal expectations and the parent's immutable16case/128event OLD
capture/discarded-span/probe oracle provide independent semantics evidence.
Neither the observer nor these helper tests proves source/native behavior.

## Applying

Apply constructors.patch to the captured two-file baselines and add the one
new test module. Parent Plan owner separately integrates its actual walker,
guarded Input/result/Box move bridge and shared helpers. Shared Plan barrels/
Audio remain parent-owned. Both variants must use their actual inherited source
authority; this candidate's two owned production before files were byte-equal
when captured, not a claim that the complete main/scoped runtime is equal.
