//! Exact provenance of the intersections that form a root audio allocation.
use std::ops::Range;

pub use deadpan_core::AudioBoundaryKind;
use deadpan_core::{
    AudioEdgePolicies, AudioEdgePolicy, ExactRatio, InstancePath, IterationId, NodeId,
    RepeatInstance,
};
use serde::Serialize;

use super::audio::Budget;
use crate::PlanError;

/// One constraint at an exact project boundary. Ancestor owners retain their
/// own occurrence path, excluding any descendant Repeat plays traversed later.
#[derive(Debug, Clone, PartialEq, Eq, Serialize)]
pub struct AudioBoundaryOrigin {
    pub instance: InstancePath,
    pub gap_after: Option<IterationId>,
    pub kind: AudioBoundaryKind,
    /// An explicit evaluation-support edge, not an authored node boundary.
    /// Its NodeStart/NodeEnd kind gives direction and its policy is Automatic.
    /// Real exactly coincident boundaries retain their independent policies.
    #[serde(skip_serializing_if = "std::ops::Not::not")]
    pub placement_support: bool,
    /// The owning node's choice for this original constraint in this revision.
    pub policy: AudioEdgePolicy,
}

/// Owners of `AudioSpan::envelope_extent` and its rounded `envelope_samples`.
/// Coincident exact constraints are retained in outer-to-inner descent order;
/// equal rounded samples alone never make different constraints coincident.
/// Any explicit Hard among coincident origins suppresses this edge's fade.
/// Interior boundaries do not inherit policies from noncoincident ancestors.
#[derive(Debug, Clone, PartialEq, Eq, Default, Serialize)]
pub struct AudioBoundaries {
    pub start: Vec<AudioBoundaryOrigin>,
    pub end: Vec<AudioBoundaryOrigin>,
}

#[derive(Clone, Copy)]
pub(super) struct BoundaryOwner<'a> {
    pub node: &'a NodeId,
    pub repeats: &'a [RepeatInstance],
    pub gap_after: Option<&'a IterationId>,
    pub policies: AudioEdgePolicies,
    pub placement_support: bool,
}

impl BoundaryOwner<'_> {
    pub(super) fn capture(
        self,
        kind: AudioBoundaryKind,
        budget: &mut Budget,
    ) -> Result<AudioBoundaryOrigin, PlanError> {
        // Charge before cloning. Coincident ancestor paths can otherwise add
        // quadratic storage to a deeply nested query's returned metadata.
        budget.spend(self.repeats.len() + 1)?;
        Ok(AudioBoundaryOrigin {
            instance: InstancePath {
                node: self.node.clone(),
                repeats: self.repeats.to_vec(),
            },
            gap_after: self.gap_after.cloned(),
            kind,
            placement_support: self.placement_support,
            policy: self.policies.get(kind),
        })
    }
}

pub(super) struct AudioExtent {
    pub range: Range<ExactRatio>,
    pub boundaries: AudioBoundaries,
}

impl AudioExtent {
    pub fn new(range: Range<ExactRatio>) -> Self {
        Self {
            range,
            boundaries: AudioBoundaries::default(),
        }
    }

    pub fn clip_start(
        &mut self,
        value: ExactRatio,
        owner: BoundaryOwner<'_>,
        kind: AudioBoundaryKind,
        budget: &mut Budget,
    ) -> Result<(), PlanError> {
        let comparison = self.range.start.checked_sub(value)?.compare_integer(0);
        if comparison.is_le() {
            let origin = owner.capture(kind, budget)?;
            if comparison.is_lt() {
                self.boundaries.start.clear();
                self.range.start = value;
            }
            self.boundaries.start.push(origin);
        }
        Ok(())
    }

    pub fn clip_end(
        &mut self,
        value: ExactRatio,
        owner: BoundaryOwner<'_>,
        kind: AudioBoundaryKind,
        budget: &mut Budget,
    ) -> Result<(), PlanError> {
        let comparison = self.range.end.checked_sub(value)?.compare_integer(0);
        if comparison.is_ge() {
            let origin = owner.capture(kind, budget)?;
            if comparison.is_gt() {
                self.boundaries.end.clear();
                self.range.end = value;
            }
            self.boundaries.end.push(origin);
        }
        Ok(())
    }
}
