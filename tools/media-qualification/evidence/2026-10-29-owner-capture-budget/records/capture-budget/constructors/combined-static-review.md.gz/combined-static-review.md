# Focused read-only combined capture guard review

Reviewed actual scratch candidate audio_capture.rs, audio_capture_storage.rs,
audio_bound_query.rs, and adjacent actual admitted Input/candidates helpers.
combined-review-pins.json identifies the three primary bodies at review end.
Plan owner was actively fixing a generic error conversion; these pins do not
freeze that owner's candidate. No code/Cargo/rustc/live/Git changes by reviewer.

## Findings

No guard/drop-order or actual newly allocated heap-site finding identified.
One compiler-level omission was sent to Plan owner: owned-Preserve rejection
in the generic walk needed PlanError.into() for QueryResult. Owner handles
that conversion in its own candidate. Not an execution/test result.

## Inspected lifetime obligations

- Local working metadata Memory is declared before actual constraints,
  editorial, Repeat/retime Vecs and content. Each capacity charge precedes
  its corresponding buffer. Partial copy failure drops returned/partial
  elements before the caller-held lease; fixed copies merge capacity only
  after all checks.
- Captured seed lives in caller-owned Owned<Option<AudioDomainSeed>>.
  Both early owner and fallback sites build a separate complete guarded
  next value and assign it only after field construction/checks. Failure
  after seed capture keeps this slot charged until outer capture unwinds.
- WalkResult owns GuardedBound<actual AudioWalkSpan> before its Plan Memory.
  The complete span remains constructed even for capture's discarded result.
  Final actual Stage drops computed envelope/boundary guard instead of
  retaining a nonexistent boundary field; actual Leaf moves those fields
  and their charge into its result.
- Content::finish constructs Mapping with content value, make closure, then
  Memory. The closure owns definition/path/Repeat/retime/boundary metadata.
  It therefore drops before its independent charge if pre-map checks fail.
  On map failure the closure/mapped result drops inside the call before the
  surrounding Mapping Memory unwinds. Post-map result fields also retain
  value-before-charge order.
- GuardedBound::map retains original Plan Memory while Core map_value
  owns the actual Core value. No allocation occurs inside the typed move
  callback. A mapped result is guarded before post-map issuer checking.
- boxed reserves the shell before Box::new_uninit. Its Owned shell remains
  in the caller while the callback borrows/takes only its value slot. Thus
  pre-map refusal drops the uninitialized box before shell charge. If the
  callback ran and a post-map check fails, the initialized actual Box drops
  within the failed result while the caller-held shell lease is still live.
  Success checks/merges shell charge beside that same mapped value.
- stage_content validates then transfers stage charge into working Memory
  immediately before allocation-free movement of the actual AudioStage.
  No intervening fallible constructor exposes a naked stage.
- Bound query continues using the existing real Core resolver and linear
  work accounting. It does not take naked value/lease parts or introduce
  an unadmitted large-enum Box to solve type size.

The exact source clone/descent checks, full boundary/envelope completion and
separate captured-slot/output-span lanes remain visible. Mutated range after
a newly refused later capacity admission is a private failed walk, not a
published partial result. Tests must verify cleanup and ample-resource
semantic equivalence against the frozen actual old observer.

## Allocation scope caveats

Repeat locate_bounded returns Arc-backed ID clones in a stack Location (Core
repeat_layout.rs in_segment); those clones do not allocate new identity heap
storage. The actual retained iteration edge is accounted before movement
into metadata storage. Vec/path growth, copied SourceAudio owning identities,
Hold RoomTone/Reverse identities, Preserve descriptor, captured seed and
returned Bound shell are all reached through the inspected admission helpers.
Owning-edge charges can remain conservatively held after working elements
drop; per-container buffers drop promptly, and discarded span charges do not
escape into the returned Input carrier.

This review is not allocator/RSS evidence, full capture peak qualification,
probe/Arc admission proof, whole-cold graph closure, or compilation. Parent
owns all required actual baseline, failure/drop, exact-peak and PCM tests.

## Known work provenance seam

ResolvedAudioBinding.work is the root Build used total, exactly described
by its existing linear child receipt. ResolvedAudioPlacement.work inside
lattice is a local used delta. That fork has no independent public receipt.
Plan cannot subtract outer additional work from lattice.work. The separate
Core-private work-witness candidate verifies local private used/extra delta
against old false lattice work with a nonzero outer prefix. Plan's allowed
work-scalar normalization must stay exact-path-only and describe nested
delta as bounded observation; every other semantic field and the complete
false-mode JSON remain exact.
