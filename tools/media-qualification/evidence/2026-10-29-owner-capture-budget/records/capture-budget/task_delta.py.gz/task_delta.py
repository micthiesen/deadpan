from pathlib import Path
import json,hashlib,difflib
s=Path(__file__).resolve().parent
main=Path('/Users/michael/Code/deadpan');scoped=Path('/tmp/deadpan-query-groundwork-2026-10-26/scoped')
rows=[];patch=[]
for n in json.loads((s/'task-files.json').read_text()):
 old=s/'apply/scoped-before'/n;b=old.read_bytes() if old.exists() else b'';new=(scoped/n).read_bytes();live=(main/n).read_bytes()
 assert b!=new,n
 patch.extend(difflib.unified_diff(b.decode().splitlines(True),new.decode().splitlines(True),fromfile='a/'+n if old.exists() else '/dev/null',tofile='b/'+n))
 rows.append({'path':n,'before_sha256':hashlib.sha256(b).hexdigest() if old.exists() else None,'sha256':hashlib.sha256(new).hexdigest(),'main_sha256':hashlib.sha256(live).hexdigest(),'main_equals_scoped':live==new})
(s/'task-scoped.patch').write_text(''.join(patch));(s/'task-source-pins.json').write_text(json.dumps(rows,indent=2)+'\n')
(s/'index-queries.txt').write_text(''.join(':'+r['path']+'\n' for r in rows))
print(json.dumps({'files':len(rows),'main_equal':sum(r['main_equals_scoped'] for r in rows),'patch_sha256':hashlib.sha256((s/'task-scoped.patch').read_bytes()).hexdigest()}))
