from pathlib import Path
import shutil,difflib,json,hashlib
s=Path(__file__).resolve().parent;repo=Path('/Users/michael/Code/deadpan');scoped=Path('/tmp/deadpan-query-groundwork-2026-10-26/scoped')
names=['crates/deadpan-plan/src/lib.rs','crates/deadpan-plan/src/plan.rs','crates/deadpan-audio/src/shared_eq/node_description.rs','crates/deadpan-audio/src/shared_eq/node_description_tests.rs']
for name in names:
 for base,root in [('before',repo),('scoped-before',scoped)]:
  dest=s/base/name;dest.parent.mkdir(parents=True,exist_ok=True);assert not dest.exists();shutil.copyfile(root/name,dest)
 dest=s/'candidate'/name;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(repo/name,dest)
for name in names[:2]:
 p=s/'candidate'/name;t=p.read_text();old='AdmittedAudioOwnerInputCandidates,'
 assert t.count(old)==1;p.write_text(t.replace(old,old+' AdmittedAudioOwnerInputCapture,',1))
p=s/'candidate'/names[2];t=p.read_text()
old='''        // The actual query stays charged while the same legacy capture runs.
        // Capture C is not forwarded by the query-only admission slice.
        let capture = candidates.capture(index, control.query_limits()?, admission)?;
        control.spend_plan_work(capture.capture_work())?;
'''
new='''        // Q stays charged through the actual full capture. Metered C has
        // already reached the controller at its real construction sites.
        let capture = candidates.capture(index, control.query_limits()?, admission)?;
        if capture.was_forwarded() != A::METERED {
            return Err(PlanError::InvalidPlan("owner capture accounting mode differs").into());
        }
        if !capture.was_forwarded() {
            control.spend_plan_work(capture.capture_work())?;
        }
'''
assert t.count(old)==1;t=t.replace(old,new,1)
old='''    if let Some(input) = capture.into_input() {
        let carrier = Context::finish_paid_owner_input_admitted(
            &input,
'''
new='''    // The source Input remains charged throughout the same probe and final
    // sharing decision; the returned context owns its independent storage.
    if let Some(input) = capture.input() {
        let carrier = Context::finish_paid_owner_input_admitted(
            input,
'''
assert t.count(old)==1;t=t.replace(old,new,1);p.write_text(t)
p=s/'candidate'/names[3]
with p.open('a') as f:f.write('\n#[path = "capture_admission_tests.rs"]\nmod capture_admission;\n')
print('Prepared four integration candidate files; no live edits.')
