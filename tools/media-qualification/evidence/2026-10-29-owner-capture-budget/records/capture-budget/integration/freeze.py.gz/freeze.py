from pathlib import Path
import hashlib,json,difflib
s=Path(__file__).resolve().parent;repo=Path('/Users/michael/Code/deadpan')
rows=[];patch=[]
for p in sorted((s/'candidate').rglob('*.rs')):
 name=str(p.relative_to(s/'candidate'));b=s/'before'/name
 old=b.read_bytes() if b.exists() else b'';new=p.read_bytes()
 if old==new:continue
 if b.exists():assert (repo/name).read_bytes()==old,name
 else:assert not (repo/name).exists(),name
 rows.append({'path':name,'new':not b.exists(),'before_sha256':hashlib.sha256(old).hexdigest() if b.exists() else None,'candidate_sha256':hashlib.sha256(new).hexdigest()})
 patch.extend(difflib.unified_diff(old.decode().splitlines(True),new.decode().splitlines(True),fromfile='a/'+name if b.exists() else '/dev/null',tofile='b/'+name))
(s/'integration.patch').write_text(''.join(patch));(s/'pins.json').write_text(json.dumps(rows,indent=2)+'\n')
print(json.dumps({'files':len(rows),'patch_sha256':hashlib.sha256((s/'integration.patch').read_bytes()).hexdigest()}))
