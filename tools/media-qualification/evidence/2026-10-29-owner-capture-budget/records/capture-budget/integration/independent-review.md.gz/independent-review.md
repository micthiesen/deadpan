# Capture integration review

Read-only review of `integration.patch` against the frozen capture contract and Plan candidate. No source changes or build performed.

No supported correctness finding.

The Root/Domain branch now checks the query and capture mode against `A::METERED`. Metered C is already forwarded from the Plan/Core construction sites, so it avoids a second `control.spend_plan_work`; unmetered C is charged once using the legacy capture receipt. The no-selection path retains the already-paid Q and does not ask for capture limits. The `Context::Retained` branch is unchanged and continues to perform its existing retained-grid query/clock clone path.

The selected capture carrier is retained in the local `capture` through the same `finish_paid_owner_input_admitted` call. That call performs the existing retained probe and final sharing decision once. The new Plan candidate carrier owns the `AudioOwnerInputCapture` before its independent memory; that value in turn owns `AudioOwnerInput` before its memory, so borrowing `capture.input()` preserves the Input charge throughout the call and drops the Input before the lease. The output carrier owns the separately admitted shared result after the source capture carrier leaves scope.

The refusal test compares the same first capture-reservation failure through a standalone sealed capture and the actual numerical Root path, including forwarded work receipts. The success test checks forwarded work once in metered mode and the old receipt total in unmetered mode, with the unchanged 9-unit `None` probe called out separately. These tests use unit leases, so they verify work and control flow, not the integration's peak-memory bound. The independently reviewed Plan constructor/walker guards and parent full capture tests must establish that bound.

This patch does not claim to meter the retained probe, key/container storage, or retained/sound branches; those existing scopes remain explicit. Parent reported only rustfmt parsing for this candidate, and the patch is uncompiled.
