from pathlib import Path
d=Path('/tmp/deadpan-owner-capture-budget-2026-10-29/plan/candidate/crates/deadpan-plan/src')
p=d/'audio_owner_query_admission.rs';s=p.read_text();anchor="impl<T> Owned<T, (), ()> {"
extra="""impl<T, I:Copy+Eq, L> Owned<T,I,L> {
    pub(in crate::plan) fn try_map<U,A:AudioSoundContextAdmission<Issuer=I,Lease=L>>(
        mut self,budget:&mut Budget<'_,A>,
        map:impl FnOnce(T,&mut Memory<I,L>,&mut Budget<'_,A>)->Result<U,A>,
    )->Result<Owned<U,I,L>,A>{
        budget.check_memory(&self.memory)?;
        let value=map(self.value,&mut self.memory,budget)?;
        let result=Owned{value,memory:self.memory};
        budget.check_memory(&result.memory)?;
        Ok(result)
    }
}
"""
assert s.count(anchor)==1;p.write_text(s.replace(anchor,extra+anchor))
p=d/'audio_owner_input.rs';s=p.read_text()
start=s.index("fn capture_observed<'plan>(");end=s.index('\n#[cfg(test)]\nmod capture_baseline_branding_tests',start)
old=s[start:end]
# This function is last production item, preserve appended tests.
sig=old[:old.index('    let before = budget.remaining;')]
wrapper=sig+'''    use super::audio_owners::admission::{self,Unmetered};
    let mut policy=Unmetered;
    let mut admitted=admission::Budget::new(budget,&mut policy);
    admission::outer::<_,Unmetered>(
        capture_observed_admitted(plan,observed,at,context,query_work,&mut admitted)
            .map(admission::Owned::unmetered))
}

fn capture_observed_admitted<'plan,A:crate::AudioSoundContextAdmission>(
    plan:&'plan RenderPlan,
    observed:&AudioOwnerClock<'plan>,
    at:AudioSample,
    context:Option<&super::audio_domain::AudioWalkSeed>,
    query_work:usize,
    budget:&mut super::audio_owners::admission::Budget<'_,A>,
)->super::audio_owners::admission::Result<
    super::audio_owners::admission::Owned<AudioOwnerInput<'plan>,A::Issuer,A::Lease>,A,
>{
    use super::audio_owners::admission::{Owned,Error};
    let before=budget.remaining;
    let mut captured=Owned{value:None,memory:budget.memory()};
    if A::METERED {
        let walked=plan.audio_walk_inner_admitted(at,budget,context,true,true,
            (Some(&mut captured),None,Some(observed)));
        #[cfg(test)]
        match &walked {
            Ok(value)=>super::audio_owners::tests::legacy_snapshot_v1::capture_baseline::capture_ref(
                plan,at,observed,captured.value.as_ref(),Ok(value.span()),
                (before,budget.remaining)),
            Err(Error::Plan(error))=>super::audio_owners::tests::legacy_snapshot_v1::capture_baseline::capture_ref(
                plan,at,observed,captured.value.as_ref(),Err(error),
                (before,budget.remaining)),
            Err(Error::Policy(_))=>{},
        }
        // The COMPLETE actual span and all workspace/Core/Box guards end at
        // the legacy discard, before the observed owner's unpaid old clone.
        drop(walked?);
    } else {
        plan.audio_walk_owner_input(at,budget,observed,&mut captured.value,context)?;
        budget.canonical_used=budget.canonical_used.checked_add(before-budget.remaining)
            .ok_or(deadpan_core::TimeError::Overflow)?;
    }
    captured.try_map(budget,|seed,memory,budget|{
        let seed=seed.ok_or(PlanError::InvalidPlan("owner input was not captured"))?;
        let kind=if seed.walk.gap.is_some(){AudioOwnerKind::DefaultGap}else{AudioOwnerKind::Node};
        let scope=if seed.instance==*observed.instance() && kind==observed.kind()
            && seed.walk.gap.as_ref().and_then(|gap|gap.after.as_ref())==observed.gap_after()
        {AudioOwnerInputScope::Owner}else{AudioOwnerInputScope::EnclosingProcessor};
        Ok(AudioOwnerInput {
            owner:budget.owner(memory,observed)?,
            observed_at:at,
            context:AudioDomain {
                plan,seed:seed.walk,samples:seed.samples,visible:seed.visible,
                instance:seed.instance,placement:None,
            },
            scope,
            work:query_work.checked_add(before-budget.remaining)
                .ok_or(deadpan_core::TimeError::Overflow)?,
        })
    })
}
'''
s=s[:start]+wrapper+s[end:]
# Error only used in the cfg(test) observation match.
s=s.replace('    use super::audio_owners::admission::{Owned,Error};','    use super::audio_owners::admission::Owned;\n    #[cfg(test)]\n    use super::audio_owners::admission::Error;')
p.write_text(s)
# Private observer accepts borrowed results without cloning/replaying the walk.
p=d/'audio_owners/legacy_snapshot_v1/capture_baseline.rs';s=p.read_text()
start=s.index('pub(in crate::plan) fn capture(')
at=s.index('    if !active() {',start)
sig=s[start:at]
delegate=sig+'''    capture_ref(plan,sample,owner,captured,walked.as_ref(),work);
}
pub(in crate::plan) fn capture_ref(
    plan:&RenderPlan,sample:AudioSample,owner:&AudioOwnerClock<'_>,
    captured:Option<&AudioDomainSeed>,walked:Result<&AudioWalkSpan<'_>,&PlanError>,
    work:(usize,usize),
) {
'''
s=s[:start]+delegate+s[at:]
p.write_text(s)
# Public carrier and admitted methods.
p=d/'audio_owner_input/candidates.rs';s=p.read_text()
anchor="// Query-only guard. Actual parent/query value drops before its independent lease."
extra="""/// Actual selected capture and its independent finite source-metadata charge.
/// Borrowing the Input keeps its charge alive through legacy probe/final sharing.
pub struct AdmittedAudioOwnerInputCapture<'plan,I,L> {
    value:AudioOwnerInputCapture<'plan>,
    query_canonical:usize,
    query_additional:usize,
    capture_canonical:usize,
    capture_additional:usize,
    forwarded:bool,
    memory:crate::plan::audio_owners::admission::Memory<I,L>,
}
impl<'plan,I,L> AdmittedAudioOwnerInputCapture<'plan,I,L> {
    pub fn input(&self)->Option<&AudioOwnerInput<'plan>>{self.value.input()}
    pub fn query_work(&self)->usize{self.value.query_work()}
    pub fn capture_work(&self)->usize{self.value.capture_work()}
    pub fn work(&self)->usize{self.value.work()}
    pub fn query_canonical_units(&self)->usize{self.query_canonical}
    pub fn query_additional_units(&self)->usize{self.query_additional}
    pub fn capture_canonical_units(&self)->usize{self.capture_canonical}
    pub fn capture_additional_units(&self)->usize{self.capture_additional}
    pub fn was_forwarded(&self)->bool{self.forwarded}
}
"""
assert s.count(anchor)==1;s=s.replace(anchor,extra+anchor)
start=s.index('    pub fn capture<A: crate::AudioSoundContextAdmission')
end=s.index('\n}\nimpl RenderPlan {',start)
s=s[:start]+'''    pub fn capture<A: crate::AudioSoundContextAdmission<Issuer = I, Lease = L>>(
        mut self,
        member: usize,
        limits: AudioQueryLimits,
        admission: &mut A,
    ) -> Result<AdmittedAudioOwnerInputCapture<'plan,I,L>, A::Error> {
        use crate::plan::audio_owners::admission::{self as tracked,outer};
        self.validate(admission)?;
        let candidates=self.value.take().expect("unconsumed query");
        limits.validate()?;
        let observed=candidates.query.spans().first()
            .filter(|span|span.samples().contains(&candidates.at))
            .and_then(|span|span.owners().get(member))
            .ok_or(PlanError::InvalidPlan("audio input candidate index out of range"))?;
        let query_work=candidates.query.work();
        let available=candidates.limits.maximum_work.checked_sub(query_work)
            .ok_or(PlanError::AudioQueryLimit("candidate query work"))?;
        let capture_limit=available.min(limits.maximum_work);
        let mut local=Budget{remaining:capture_limit,lookup:LookupStats::default()};
        let (input,canonical,additional)={
            let mut budget=tracked::Budget::new(&mut local,admission);
            let input=outer::<_,A>(match candidates.parent {
                Parent::Root(plan)=>capture_observed_admitted(
                    plan,observed,candidates.at,None,query_work,&mut budget),
                Parent::Domain(domain)=>capture_observed_admitted(
                    domain.plan,observed,candidates.at,Some(&domain.seed),query_work,&mut budget),
            })?;
            (input,budget.canonical_used,budget.additional_used)
        };
        let result=AdmittedAudioOwnerInputCapture {
            value:AudioOwnerInputCapture {
                input:Some(input.value),query_work,capture_work:capture_limit-local.remaining,
            },
            query_canonical:self.canonical,query_additional:self.additional,
            capture_canonical:canonical,capture_additional:additional,
            forwarded:A::METERED,memory:input.memory,
        };
        self.validate(admission)?;
        if result.memory.issuer!=admission.issuer() {
            return Err(PlanError::AudioMetadataIssuerMismatch.into());
        }
        Ok(result)
    }
    pub fn without_selection<A: crate::AudioSoundContextAdmission<Issuer = I, Lease = L>>(
        mut self,
        admission: &mut A,
    ) -> Result<AdmittedAudioOwnerInputCapture<'plan,I,L>, A::Error> {
        self.validate(admission)?;
        let value=self.value.take().expect("unconsumed query").without_selection();
        let result=AdmittedAudioOwnerInputCapture {
            value,query_canonical:self.canonical,query_additional:self.additional,
            capture_canonical:0,capture_additional:0,forwarded:A::METERED,
            memory:crate::plan::audio_owners::admission::Memory::empty(self.memory.issuer),
        };
        self.validate(admission)?;
        Ok(result)
    }
''' + s[end:]
p.write_text(s)
