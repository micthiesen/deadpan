from pathlib import Path
d=Path('/tmp/deadpan-owner-capture-budget-2026-10-29/plan/candidate/crates/deadpan-plan/src')
p=d/'audio_bound_query.rs';s=p.read_text();a='''impl<T, I: Copy + Eq, L> GuardedBound<T, I, L> {'''
b=a+'''
    pub(in crate::plan) fn plain(value:T,issuer:I)->Self {
        Self {value:BoundValue::Legacy(value),_memory:Memory::empty(issuer)}
    }
'''
assert s.count(a)==1
if 'fn plain(' not in s:p.write_text(s.replace(a,b))
p=d/'audio_capture.rs';s=p.read_text()
a=s.index("pub(in crate::plan) enum WalkValue")
b=s.index("fn stage_content",a)
header="""pub(in crate::plan) struct WalkResult<'plan,I,L> {
    value:GuardedBound<AudioWalkSpan<'plan>,I,L>,
    memory:Memory<I,L>,
}
#[cfg(test)]
impl<'plan,I:Copy+Eq,L> WalkResult<'plan,I,L> {
    pub(in crate::plan) fn span(&self)->&AudioWalkSpan<'plan>{&self.value}
}
impl<'plan> WalkResult<'plan,(),()> {
    pub(in crate::plan) fn unmetered(self)->AudioWalkSpan<'plan>{self.value.unmetered()}
}
type Content<'plan,I,L> = GuardedBound<AudioSignalContent<'plan>,I,L>;
impl<'plan,I:Copy+Eq,L> GuardedBound<AudioSignalContent<'plan>,I,L> {
    fn is_leaf(&self)->bool{matches!(&**self,AudioSignalContent::Leaf(_))}
    fn finish<A:AudioSoundContextAdmission<Issuer=I,Lease=L>>(
        self,memory:Memory<I,L>,budget:&mut QueryBudget<'_,A>,
        make:impl FnOnce(AudioSignalContent<'plan>)->AudioWalkSpan<'plan>,
    )->Result<WalkResult<'plan,I,L>,A>{
        struct Mapping<C,F,I,L>{value:C,make:F,memory:Memory<I,L>}
        let guarded=Mapping{value:self,make,memory};
        budget.check_memory(&guarded.memory)?;
        let value=guarded.value.map(budget,guarded.make)?;
        let result=WalkResult{value,memory:guarded.memory};
        budget.check_memory(&result.memory)?;
        Ok(result)
    }
}
"""
s=s[:a]+header+s[b:]
# Every plain content is sealed with the same current internal issuer.
token='Content::Plain('
cursor=0
while True:
 a=s.find(token,cursor)
 if a<0:break
 b=a+len(token);level=1
 while level:
  if s[b]=='(':level+=1
  elif s[b]==')':level-=1
  b+=1
 inner=s[a+len(token):b-1]
 new='Content::plain('+inner+',budget.issuer)'
 s=s[:a]+new+s[b:];cursor=a+len(new)
s=s.replace('Content::Bound(bound.boxed(budget)?)','bound.boxed(budget)?.map(budget, AudioSignalContent::Bound)?')
assert 'Content::Bound(bound.boxed' not in s
p.write_text(s)
