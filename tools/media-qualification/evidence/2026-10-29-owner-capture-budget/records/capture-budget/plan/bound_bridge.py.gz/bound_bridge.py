from pathlib import Path
import hashlib,json
r=Path('/Users/michael/Code/deadpan');s=Path('/tmp/deadpan-owner-capture-budget-2026-10-29/plan')
rel='crates/deadpan-plan/src/audio_bound.rs'
for part in ['before','candidate']:
 p=s/part/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes((r/rel).read_bytes())
p=s/'candidate'/rel;t=p.read_text();assert t.count('mod query;')==1;p.write_text(t.replace('mod query;','pub(in crate::plan) mod query;'))
p=s/'before-pins.json';pins=json.loads(p.read_text());pins[rel]=hashlib.sha256((r/rel).read_bytes()).hexdigest();p.write_text(json.dumps(pins,indent=2)+'\n')
p=s/'candidate/crates/deadpan-plan/src/audio_bound_query.rs';t=p.read_text()
start=t.index("enum BoundValue<'plan, I, L>")
end=t.index('impl RenderPlan {',start)
t=t[:start]+'''pub(in crate::plan) enum BoundValue<T, I, L> {
    Legacy(T),
    Metered(AudioBindingValue<T, I, L>),
}
pub(in crate::plan) struct GuardedBound<T, I, L> {
    value: BoundValue<T, I, L>,
    _memory: Memory<I, L>,
}
pub(in crate::plan) type QueryBound<'plan,I,L> = GuardedBound<AudioBound<'plan>,I,L>;
impl<T,I:Copy+Eq,L> std::ops::Deref for GuardedBound<T,I,L> {
    type Target=T;
    fn deref(&self)->&T {
        match &self.value {
            BoundValue::Legacy(v)=>v,
            BoundValue::Metered(v)=>v.value(),
        }
    }
}
impl<T> GuardedBound<T,(),()> {
    pub(in crate::plan) fn unmetered(self)->T {
        match self.value {
            BoundValue::Legacy(v)=>v,
            BoundValue::Metered(_)=>unreachable!("legacy binding backend"),
        }
    }
}
impl<T,I:Copy+Eq,L> GuardedBound<T,I,L> {
    /// The callback is allocation-free and all of its actual owning fields
    /// remain guarded by its caller through pre/post-map failure.
    pub(in crate::plan) fn map<U,A:AudioSoundContextAdmission<Issuer=I,Lease=L>>(
        self, budget:&mut QueryBudget<'_,A>, f:impl FnOnce(T)->U,
    )->Result<GuardedBound<U,I,L>,A>{
        budget.check_memory(&self._memory)?;
        let value=match self.value {
            BoundValue::Legacy(v)=>BoundValue::Legacy(f(v)),
            BoundValue::Metered(v)=>{
                let adapter=CoreAdmission{outer:budget.admission};
                BoundValue::Metered(core::<_,A>(v.map_value(&adapter,f))?)
            },
        };
        let result=GuardedBound{value,_memory:self._memory};
        budget.check_memory(&result._memory)?;
        Ok(result)
    }
}
impl<'plan,I:Copy+Eq,L> GuardedBound<AudioBound<'plan>,I,L> {
    pub(in crate::plan) fn boxed<A:AudioSoundContextAdmission<Issuer=I,Lease=L>>(
        self,budget:&mut QueryBudget<'_,A>,
    )->Result<GuardedBound<Box<AudioBound<'plan>>,I,L>,A>{
        budget.check_memory(&self._memory)?;
        if !A::METERED {
            let BoundValue::Legacy(value)=self.value else {
                return Err(PlanError::InvalidPlan("binding accounting mode mismatch").into());
            };
            return Ok(GuardedBound {
                value:BoundValue::Legacy(Box::new(value)),_memory:self._memory,
            });
        }
        let mut shell=Owned {value:None,memory:budget.memory()};
        budget.reserve(&mut shell.memory,std::alloc::Layout::new::<AudioBound<'plan>>())?;
        shell.value=Some(Box::<AudioBound<'plan>>::new_uninit());
        let mut result=self.map(budget,|value|
            Box::write(shell.value.take().expect("prepared Box shell"),value))?;
        budget.check_memory(&result._memory)?;
        budget.check_memory(&shell.memory)?;
        budget.merge_checked(&mut result._memory,&mut shell.memory);
        Ok(result)
    }
}
''' +t[end:]
p.write_text(t)
