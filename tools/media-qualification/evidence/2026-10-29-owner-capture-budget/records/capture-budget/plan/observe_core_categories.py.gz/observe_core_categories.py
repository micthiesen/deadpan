from pathlib import Path
d=Path('/tmp/deadpan-owner-capture-budget-2026-10-29/plan/candidate/crates/deadpan-plan/src')
p=d/'audio_bound_query.rs';s=p.read_text()
a='''                budget.account_core(work)?;'''
b='''                #[cfg(test)]
                super::super::audio_owners::tests::legacy_snapshot_v1::capture_baseline::core_receipt(
                    value.value().work, value.value().lattice.work, work.units(),
                    work.canonical_units(),work.additional_units(),work.was_forwarded(),
                );
                budget.account_core(work)?;'''
assert s.count(a)==1;p.write_text(s.replace(a,b))
p=d/'audio_owners/legacy_snapshot_v1/capture_baseline.rs';s=p.read_text()
a='''pub(in crate::plan) fn policy_failure('''
b='''pub(in crate::plan) fn core_receipt(
    resolved_work:usize,lattice_work:usize,total:usize,canonical:usize,additional:usize,forwarded:bool,
){
    if !active(){return;}
    record(json!({"kind":"actual_capture_core_receipt","resolved_work":resolved_work,
        "lattice_work":lattice_work,"total":total,"canonical":canonical,
        "additional":additional,"forwarded":forwarded}));
}
'''+a
assert s.count(a)==1;p.write_text(s.replace(a,b))
p=d/'audio_owners/owner_capture_admission_tests.rs';s=p.read_text()
a='''        admitted(parent, at, Default::default(), &mut p)
            .unwrap()
            .capture(member, Default::default(), &mut p)'''
b='''        let query=admitted(parent, at, Default::default(), &mut p).unwrap();
        capture_baseline::phase("actual_selected_capture");
        query.capture(member, Default::default(), &mut p)'''
assert s.count(a)==1;p.write_text(s.replace(a,b))
s=p.read_text();a='''    for key in ["at", "selected_observation", "capture_slot", "walk"] {
        assert_eq!(
            observed["observation"][key], old_event["observation"][key],
            "frozen complete actual discarded span and capture slot: {name}/{key}"
        );
    }'''
b='''    for key in ["at", "selected_observation", "capture_slot"] {
        assert_eq!(observed["observation"][key],old_event["observation"][key],
            "frozen actual captured slot and selected provenance: {name}/{key}");
    }
    let mut actual_walk=observed["observation"]["walk"].clone();
    let old_walk=&old_event["observation"]["walk"];
    let root="/discarded_span/value/content/value/resolved/work";
    let lattice="/discarded_span/value/content/value/resolved/lattice/work";
    if M && old_walk.pointer(root).is_some() {
        let receipts=events.iter().filter(|v|v["phase"]=="actual_selected_capture"
            &&v["observation"]["kind"]=="actual_capture_core_receipt").collect::<Vec<_>>();
        assert_eq!(receipts.len(),1,"one actual opaque Bound stops the capture walk");
        let receipt=&receipts[0]["observation"];
        let actual_root=number(actual_walk.pointer(root).unwrap());
        let old_root=number(old_walk.pointer(root).unwrap());
        let actual_lattice=number(actual_walk.pointer(lattice).unwrap());
        let old_lattice=number(old_walk.pointer(lattice).unwrap());
        assert_eq!(actual_root,number(&receipt["resolved_work"]));
        assert_eq!(actual_root,number(&receipt["total"]));
        assert_eq!(old_root,number(&receipt["canonical"]));
        let core_added=number(&receipt["additional"]);
        assert_eq!(old_root.checked_add(core_added),Some(actual_root));
        assert_eq!(receipt["forwarded"],true);
        assert!(core_added<=result.capture_additional_units());
        // The nested template fork has no separate receipt. This is an
        // observed bounded delta, not a fabricated per-lattice category split.
        assert_eq!(actual_lattice,number(&receipt["lattice_work"]));
        assert!(actual_lattice>=old_lattice);
        assert!(actual_lattice-old_lattice<=core_added);
        assert!(actual_lattice<=actual_root);
        *actual_walk.pointer_mut(root).unwrap()=json!(old_root);
        *actual_walk.pointer_mut(lattice).unwrap()=json!(old_lattice);
    }
    assert_eq!(actual_walk,*old_walk,
        "all actual complete discarded-span fields except checked total-work provenance: {name}");'''
assert s.count(a)==1;p.write_text(s.replace(a,b))
