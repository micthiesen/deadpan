from pathlib import Path
import json,hashlib
s=Path('/tmp/deadpan-owner-capture-budget-2026-10-29/plan')
c=s.parent/'constructors'
paths=(c/'owned-files.txt').read_text().splitlines() if (c/'owned-files.txt').exists() else [
'crates/deadpan-plan/src/audio_boundary.rs','crates/deadpan-plan/src/audio_signal.rs','crates/deadpan-plan/src/audio_capture_constructor_tests.rs']
pins=json.loads((s/'before-pins.json').read_text())
for rel in paths:
 p=c/'candidate'/rel
 assert p.exists(),rel
 dst=s/'candidate'/rel;dst.parent.mkdir(parents=True,exist_ok=True);dst.write_bytes(p.read_bytes())
 src=c/'before'/rel
 if src.exists():
  dst=s/'before'/rel;dst.parent.mkdir(parents=True,exist_ok=True);dst.write_bytes(src.read_bytes())
  pins[rel]=hashlib.sha256(src.read_bytes()).hexdigest()
(s/'before-pins.json').write_text(json.dumps(pins,indent=2)+'\n')
d=s/'candidate/crates/deadpan-plan/src'
p=d/'audio_owner_input.rs';t=p.read_text();a='''    AdmittedAudioOwnerInputCandidates, AudioOwnerInputCandidates, AudioOwnerInputCapture,''';b='''    AdmittedAudioOwnerInputCandidates, AdmittedAudioOwnerInputCapture,
    AudioOwnerInputCandidates, AudioOwnerInputCapture,''';assert t.count(a)==1;p.write_text(t.replace(a,b))
p=d/'audio_owners/owner_query_admission_tests.rs';t=p.read_text()
a=t.index('    let input = candidates\n        .capture(')
b=t.index('    if !M {',a)
t=t[:a]+'''    let capture = candidates.capture(member, Default::default(), &mut p).unwrap();
    let capture_added = capture.capture_additional_units();
    assert_eq!(capture.capture_canonical_units(),old_c);
    assert_eq!(capture.query_canonical_units(),old_q);
    assert_eq!(capture.query_additional_units(),added);
    assert_eq!(capture.was_forwarded(),M);
    let input = capture.input().unwrap();
    assert_eq!(input.work(),total+old_c+capture_added);
    let mut actual=super::input(input);
    actual["total_work"]=json!(old_q+old_c);
    assert_eq!(actual,case["legacy_input"],"full captured private Domain/seed is frozen");
    if M {assert!(p.0.borrow().live>0,"actual captured source Input stays charged");}
    assert_eq!(p.0.borrow().forwarded,if M{total+old_c+capture_added}else{0},
        "Q and C each forward exactly once");
    drop(capture);
    assert_eq!(p.0.borrow().live,0,"captured Input releases with its charge");
''' +t[b:]
t+='''\n#[path="owner_capture_admission_tests.rs"]\nmod capture;\n'''
p.write_text(t)
# Test-only observer access, with a None fast path and no query/clone.
p=d/'audio_owners/legacy_snapshot_v1/capture_baseline.rs';t=p.read_text()
anchor='''pub(in crate::plan) fn phase(value: &'static str) {'''
extra='''pub(in crate::plan) fn observe_case<T>(
    name:&str,label:&'static str,read:impl FnOnce()->T,
)->(T,Vec<Value>){
    let session=Session::start();
    let value={let _scope=case_scope(name);phase(label);read()};
    (value,session.finish())
}
pub(in crate::plan) fn policy_failure(
    plan:&RenderPlan,at:AudioSample,captured:Option<&AudioDomainSeed>,
    work:(usize,usize),
){
    if !active(){return;}
    record(json!({"kind":"actual_capture_policy_refusal","at":at.0,
        "capture_slot":captured.map(|v|seed(plan,v)),
        "actual_capture_work_spent":work.0-work.1}));
}
'''
assert t.count(anchor)==1;p.write_text(t.replace(anchor,extra+anchor))
p=d/'audio_owner_input.rs';t=p.read_text()
a='''            Err(Error::Policy(_)) => {}''';b='''            Err(Error::Policy(_)) =>
                super::audio_owners::tests::legacy_snapshot_v1::capture_baseline::policy_failure(
                    plan,at,captured.value.as_ref(),(before,budget.remaining)),
'''
assert t.count(a)==1;p.write_text(t.replace(a,b))
print(paths)
