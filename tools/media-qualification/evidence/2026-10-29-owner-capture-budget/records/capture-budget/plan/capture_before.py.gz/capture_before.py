from pathlib import Path
import json,hashlib
r=Path('/Users/michael/Code/deadpan');s=Path('/tmp/deadpan-owner-capture-budget-2026-10-29/plan')
paths=[
'crates/deadpan-plan/src/audio.rs',
'crates/deadpan-plan/src/audio_bound_query.rs',
'crates/deadpan-plan/src/audio_owner_input.rs',
'crates/deadpan-plan/src/audio_owner_input/candidates.rs',
'crates/deadpan-plan/src/audio_owner_query_admission.rs',
'crates/deadpan-plan/src/audio_owners/legacy_snapshot_v1/capture_baseline.rs',
'crates/deadpan-plan/src/audio_owners/owner_query_admission_tests.rs',
]
for p in paths:
 for part in ['before','candidate']:
  dst=s/part/p;dst.parent.mkdir(parents=True,exist_ok=True);dst.write_bytes((r/p).read_bytes())
(s/'before-pins.json').write_text(json.dumps({p:hashlib.sha256((r/p).read_bytes()).hexdigest() for p in paths},indent=2)+'\n')
print(len(paths))
