# Private captures type alias

Scratch-only delta against current live audio_capture.rs. No live/scoped/index
mutation, Cargo or rustc. The constructor compiler fix is untouched.

WalkCaptures has FOUR independent lifetimes: mutable seed-slot borrow, mutable
editorial borrow, shared observed-clock borrow, and that clock's Plan lifetime.
The function uses four independent inferred lifetime placeholders. None is tied
to the function's returned Plan lifetime or to another tuple member. This is
only a type-name extraction; argument order, tuple layout, bodies and call sites
are unchanged. No allow suppression, Box, allocator or new public API.

Scoped rustfmt parsing and patch dry-run passed. Parent owns compiler/lint
verification after the active pinned media receipt releases its source guard.
