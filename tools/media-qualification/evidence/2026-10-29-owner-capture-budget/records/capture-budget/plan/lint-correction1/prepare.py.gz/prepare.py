from pathlib import Path
import hashlib,json,difflib
root=Path('/Users/michael/Code/deadpan')
s=Path('/tmp/deadpan-owner-capture-budget-2026-10-29/plan/lint-correction1')
rel='crates/deadpan-plan/src/audio_capture.rs'
before=(root/rel).read_bytes()
for part in ['before','candidate']:
 p=s/part/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(before)
p=s/'candidate'/rel;text=p.read_text()
anchor='''impl RenderPlan {
    pub(in crate::plan) fn audio_walk_inner_admitted'''
alias='''// Preserve separate slot/editorial/clock borrows and the observed clock's
// independent Plan lifetime; this names only the existing argument tuple.
type WalkCaptures<'slot, 'editorial, 'clock, 'clock_plan, I, L> = (
    Option<&'slot mut Owned<Option<AudioDomainSeed>, I, L>>,
    Option<&'editorial mut EditorialCapture>,
    Option<&'clock super::super::AudioOwnerClock<'clock_plan>>,
);

'''
assert text.count(anchor)==1;text=text.replace(anchor,alias+anchor)
old='''        captures: (
            Option<&mut Owned<Option<AudioDomainSeed>, A::Issuer, A::Lease>>,
            Option<&mut EditorialCapture>,
            Option<&super::super::AudioOwnerClock<'_>>,
        ),'''
new='''        captures: WalkCaptures<'_, '_, '_, '_, A::Issuer, A::Lease>,'''
assert text.count(old)==1;text=text.replace(old,new)
p.write_text(text)
(s/'before-pins.json').write_text(json.dumps({rel:hashlib.sha256(before).hexdigest()},indent=2)+'\n')
