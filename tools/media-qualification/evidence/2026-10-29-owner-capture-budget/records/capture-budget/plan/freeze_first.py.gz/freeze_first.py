from pathlib import Path
import hashlib,json,difflib,shutil
r=Path('/Users/michael/Code/deadpan')
s=Path('/tmp/deadpan-owner-capture-budget-2026-10-29/plan')
out=s/'first-compile'
assert not out.exists(),'first compile snapshot immutable'
out.mkdir()
sha=lambda b:hashlib.sha256(b).hexdigest()
files=[str(p.relative_to(s/'candidate')) for p in sorted((s/'candidate').rglob('*.rs'))]
patch=[];before={};final={}
for rel in files:
 a=s/'before'/rel;b=s/'candidate'/rel
 old=a.read_text() if a.exists() else ''
 new=b.read_text()
 assert old!=new,rel
 if a.exists():
  assert a.read_bytes()==(r/rel).read_bytes(),'live drift '+rel
  before[rel]=sha(a.read_bytes())
  dst=out/'before'/rel;dst.parent.mkdir(parents=True,exist_ok=True);dst.write_bytes(a.read_bytes())
 dst=out/'candidate'/rel;dst.parent.mkdir(parents=True,exist_ok=True);dst.write_bytes(b.read_bytes())
 final[rel]=sha(b.read_bytes())
 patch+=difflib.unified_diff(old.splitlines(True),new.splitlines(True),
   fromfile='a/'+rel if a.exists() else '/dev/null',tofile='b/'+rel)
(out/'plan.patch').write_text(''.join(patch))
(out/'before-pins.json').write_text(json.dumps(before,indent=2)+'\n')
(out/'candidate-pins.json').write_text(json.dumps(final,indent=2)+'\n')
(out/'owned-files.txt').write_text('\n'.join(files)+'\n')
shutil.copyfile(s/'notes.md',out/'notes.md')
sources=[]
for crate in ['deadpan-core','deadpan-plan']:
 sources +=[str(p.relative_to(r)) for p in sorted((r/'crates'/crate/'src').rglob('*.rs'))]
 sources +=['crates/'+crate+'/Cargo.toml']
sources+=['Cargo.toml','Cargo.lock','rust-toolchain.toml',
 'crates/deadpan-plan/tests/fixtures/owner-query-baseline-v1/snapshot.json',
 'crates/deadpan-plan/tests/fixtures/owner-capture-baseline-v1/snapshot.json']
authority={p:sha((r/p).read_bytes()) for p in sorted(sources)}
(out/'source-authority-before.json').write_text(json.dumps(authority,indent=2)+'\n')
authority.update(final)
(out/'source-authority-candidate.json').write_text(json.dumps(authority,indent=2)+'\n')
manifest={p.name:sha(p.read_bytes()) for p in out.iterdir() if p.is_file()}
(out/'freeze-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps({'files':len(files),'new_files':len(files)-len(before),
 'patch':manifest['plan.patch'],'pins':manifest['candidate-pins.json'],
 'notes':manifest['notes.md']},indent=2))
