from pathlib import Path
import re
d=Path('/tmp/deadpan-owner-capture-budget-2026-10-29/plan/candidate/crates/deadpan-plan/src')
p=d/'audio.rs';s=Path('/tmp/deadpan-owner-capture-budget-2026-10-29/plan/before/crates/deadpan-plan/src/audio.rs').read_text()
start=s.index("    fn audio_walk_inner<'plan>(")
end=s.index('\n}\n\n/// A marker on an ancestor',start)
old=s[start:end]
body=old[old.index('        let (mut capture, editorial_capture, input_owner) = captures;'):]
body=body[:body.rfind('\n    }')]
# Keep original relative parent references meaningful in the extracted child.
body=body.replace('super::','super::super::')
body=body.replace('budget.spend(', 'budget.canonical(')
body=re.sub(r'return Err\((PlanError::\w+\([^;]+?)\)\);',r'return Err(\1).into());',body)
# Independent workspace ownership lanes, declared before every owning value.
body=body.replace('        let mut constraints = Vec::new();','''        let mut memory = budget.memory();
        let mut constraints_capacity = budget.memory();
        let mut constraints = Vec::new();''')
body=body.replace('        let mut editorial = Vec::new();','''        let mut editorial_capacity = budget.memory();
        let mut editorial = Vec::new();''')
body=body.replace('        let mut repeats = Vec::new();','''        let mut repeats_capacity = budget.memory();
        let mut repeats = Vec::new();''')
body=body.replace('        let mut retimes = Vec::new();','''        let mut retimes_capacity = budget.memory();
        let mut retimes = Vec::new();''')
body=body.replace('constraints = seed.constraints.clone();','constraints = storage::copy_vec(&seed.constraints, &mut memory, &mut constraints_capacity, budget, |v,m,b|b.constraint(m,v))?;')
body=body.replace('editorial = seed.editorial.clone();','editorial = storage::copy_vec(&seed.editorial, &mut memory, &mut editorial_capacity, budget, storage::editorial)?;')
body=body.replace('repeats = seed.repeats.clone();','repeats = budget.repeats(&mut memory, &mut repeats_capacity, &seed.repeats)?;')
body=body.replace('retimes = seed.retimes.clone();','retimes = storage::copy_vec(&seed.retimes, &mut memory, &mut retimes_capacity, budget, storage::retime)?;')
body=body.replace('seeded_gap = seed.gap.clone();','seeded_gap = budget.gap(&mut memory, &seed.gap)?;')
body=body.replace('gap_after: gap.after.clone(),','gap_after: gap.after.as_ref().map(|v|budget.iteration(&mut memory,v)).transpose()?,')
body=body.replace('let after = gap.after.clone();','let after = gap.after.as_ref().map(|v|budget.iteration(&mut memory,v)).transpose()?;')
body=body.replace('self.bound_at(', 'self.bound_at_query(')
body=body.replace('AudioSignalContent::Bound(Box::new(bound))','Content::Bound(bound.boxed(budget)?)')
body=body.replace('AudioSignalContent::Leaf(AudioContent::from_hold(audio, gap.duration))','Content::Plain(AudioSignalContent::Leaf(storage::hold(audio, gap.duration, &mut memory,budget)?))')
body=body.replace('break (AudioSignalContent::Leaf(content), None);','break (Content::Plain(AudioSignalContent::Leaf(content)), None);')
# Add Content wrapping for leaf constructors and old Hold call.
body=body.replace('''AudioSignalContent::Leaf(AudioContent::from_hold(
                            audio,
                            node.inspection.duration,
                        ))''','''Content::Plain(AudioSignalContent::Leaf(storage::hold(
                            audio, node.inspection.duration, &mut memory, budget,
                        )?))''')
for reason in ['NoSourceAudio','OutsideSourceSelection']:
 oldfrag='''AudioSignalContent::Leaf(AudioContent::Silence {
                            reason: SilenceReason::'''+reason+''',
                        })'''
 # OutsideSourceSelection has same indentation after rustfmt, NoSource differs.
 if oldfrag not in body:
  oldfrag='''AudioSignalContent::Leaf(AudioContent::Silence {
                            reason: SilenceReason::'''+reason+''',
                        })'''
# Structural balanced wrapper around all still-bare break Leaf(...) occurrences.
def wrap_call(text, token, replacement):
 at=0
 while True:
  i=text.find(token,at)
  if i<0: return text
  j=i+len(token); depth=1
  while depth:
   if text[j]=='(':depth+=1
   elif text[j]==')':depth-=1
   j+=1
  text=text[:i]+replacement+text[i:j]+')'+text[j:]
  at=j+len(replacement)+1
# Existing remaining bare Leaf constructors within break only.
body=body.replace('''                        AudioSignalContent::Leaf(AudioContent::Silence''','''                        Content::Plain(AudioSignalContent::Leaf(AudioContent::Silence''')
body=body.replace('''                            reason: SilenceReason::NoSourceAudio,
                        }),''','''                            reason: SilenceReason::NoSourceAudio,
                        })),''')
body=body.replace('''                                reason: SilenceReason::OutsideSourceSelection,
                            }),''','''                                reason: SilenceReason::OutsideSourceSelection,
                            })),''')
# Source's actual owning edge, no post-construction visitor.
body=body.replace('source: audio.source.clone(),','source: budget.source(&mut memory, &audio.source)?,')
# Stage constructor now returns guarded actual value; outer canonical stays.
oldstage='''AudioSignalContent::Stage(AudioStage::for_node(
                                self,
                                current,
                                &repeats,
                                definition,
                                bypass_binding,
                            )?)'''
newstage='''stage_content(AudioStage::for_node_admitted(
                                self, current, &repeats, definition, bypass_binding, budget,
                            )?, &mut memory, budget)?'''
assert oldstage in body
body=body.replace(oldstage,newstage)
body=body.replace('node: node.inspection.id.clone(),','node: budget.node(&mut memory, &node.inspection.id)?,')
# Retain actual iteration edge before moving it out of the Core location.
body=body.replace('''                    if location.in_gap {''','''                    budget.own_iteration(&mut memory, &location.play.iteration)?;
                    if location.in_gap {''')
body=body.replace('gap_after: Some(location.play.iteration.clone()),','gap_after: Some(budget.iteration(&mut memory, &location.play.iteration)?),')
# Wrap every growing workspace push at its actual site.
for vector in ['constraints','editorial','repeats','retimes']:
 token=vector+'.push('
 cursor=0
 while True:
  i=body.find(token,cursor)
  if i<0:break
  k=i+len(token);level=1
  while level:
   if body[k]=='(':level+=1
   if body[k]==')':level-=1
   k+=1
  inner=body[i+len(token):k-1]
  repl='push!('+vector+', '+vector+'_capacity, '+inner+')'
  body=body[:i]+repl+body[k:];cursor=i+len(repl)
# Each captured seed is independently charged while remaining walk continues.
cursor=0
while True:
 i=body.find('*capture = Some(AudioDomainSeed {',cursor)
 if i<0:break
 k=i+len('*capture = Some(');level=1
 while level:
  if body[k]=='(':level+=1
  elif body[k]==')':level-=1
  k+=1
 chunk=body[i:k+1]
 chunk=chunk.replace('*capture = Some(','''let mut next = Owned { value: None, memory: budget.memory() };
                next.value = Some(''')
 chunk=chunk.replace('definition: definition.cloned(),','definition: budget.definition_ref(&mut next.memory, definition)?,')
 chunk=chunk.replace('constraints: constraints[..inherited_constraints].to_vec(),','constraints: storage::fixed(&constraints[..inherited_constraints], &mut next.memory, budget, |v,m,b|b.constraint(m,v))?,')
 chunk=chunk.replace('editorial: editorial[..inherited_editorial].to_vec(),','editorial: storage::fixed(&editorial[..inherited_editorial], &mut next.memory, budget, storage::editorial)?,')
 chunk=chunk.replace('repeats: repeats.clone(),','repeats: storage::fixed(&repeats, &mut next.memory, budget, |v,m,b|b.repeat(m,v))?,')
 chunk=chunk.replace('retimes: retimes.clone(),','retimes: storage::fixed(&retimes, &mut next.memory, budget, storage::retime)?,')
 chunk=chunk.replace('instance: owner.instance().clone(),','instance: budget.instance_fixed(&mut next.memory, owner.instance())?,')
 chunk=chunk.replace('node: self.nodes[current].inspection.id.clone(),','node: budget.node(&mut next.memory, &self.nodes[current].inspection.id)?,')
 chunk=chunk.replace('gap: domain_gap,','gap: if A::METERED { budget.gap_ref(&mut next.memory, domain_gap.as_ref())? } else { domain_gap.take() },')
 chunk+='''\n                budget.check_memory(&next.memory)?;
                budget.check_memory(&capture.memory)?;
                *capture = next;'''
 body=body[:i]+chunk+body[k+1:];cursor=i+len(chunk)
# Probe/editorial lane is compatibility-only in this delivery.
body=body.replace('''        if let Some(capture) = editorial_capture {
            budget.canonical''','''        if let Some(capture) = editorial_capture {
            assert!(!A::METERED, "editorial output remains legacy-only");
            budget.canonical''')
body=body.replace('let mut envelope = AudioExtent::new(', 'let mut envelope = AdmittedExtent::new(')
body=body.replace('''            envelope.ok_or(PlanError::InvalidPlan("audio has no envelope domain"))?,
        );''','''            envelope.ok_or(PlanError::InvalidPlan("audio has no envelope domain"))?,
            budget.issuer,
        );''')
# Final branch replaced separately to keep fallible order and guarded mapping.
final=body.index('        let content = match content {')
body=body[:final]+'''        let mut envelope = envelope.finish(budget)?;
        budget.check_memory(&memory)?;
        budget.check_memory(&repeats_capacity)?;
        budget.check_memory(&retimes_capacity)?;
        budget.merge_checked(&mut memory, &mut repeats_capacity);
        budget.merge_checked(&mut memory, &mut retimes_capacity);
        let definition = budget.definition_ref(&mut memory, definition)?;
        if !content.is_leaf() {
            let node = budget.node(&mut memory, &self.nodes[current].inspection.id)?;
            return content.finish(memory, budget, move |content| {
                AudioWalkSpan::Stage(AudioProcessingSpan {
                    definition, samples: allocated_samples.clone(), allocated_samples,
                    project_extent: extent, instance: InstancePath {node,repeats},
                    gap_after,transform,grid,sampling,retimes,content,
                })
            });
        }
        let leaf_envelope = AudioEnvelope::from_samples(envelope_samples.clone())?;
        let node = budget.node(&mut memory, &self.nodes[current].inspection.id)?;
        budget.check_memory(&memory)?;
        budget.check_memory(&envelope.memory)?;
        budget.merge_checked(&mut memory, &mut envelope.memory);
        content.finish(memory, budget, move |content| {
            let AudioSignalContent::Leaf(content) = content else { unreachable!("checked leaf") };
            AudioWalkSpan::Leaf(AudioSpan {
                definition,samples:allocated_samples.clone(),allocated_samples,
                project_extent:extent,envelope_extent:envelope.value.range,
                envelope:leaf_envelope,envelope_samples,boundaries:envelope.value.boundaries,
                instance:InstancePath{node,repeats},gap_after,transform,grid,sampling,retimes,content,
            })
        })
'''
# The original Stage drops its computed boundaries before returning. Extent
# guard is still alive across mapping and only drops after actual temporary data.
header='''//! The single actual complete capture/legacy walk, with allocation-site guards.
use super::*;
use crate::AudioSoundContextAdmission;
use crate::plan::audio_boundary::AdmittedExtent;
use crate::plan::audio_owners::admission::{Budget as QueryBudget, Memory, Owned, Result};
use crate::plan::audio_bound::query::GuardedBound;
#[path="audio_capture_storage.rs"]
mod storage;

pub(in crate::plan) enum WalkValue<'plan,I,L> {
    Plain(AudioWalkSpan<'plan>),
    Bound(GuardedBound<AudioWalkSpan<'plan>,I,L>),
}
pub(in crate::plan) struct WalkResult<'plan,I,L> {
    value:WalkValue<'plan,I,L>,
    memory:Memory<I,L>,
}
impl<'plan,I:Copy+Eq,L> WalkResult<'plan,I,L> {
    pub(in crate::plan) fn span(&self)->&AudioWalkSpan<'plan> {
        match &self.value {WalkValue::Plain(v)=>v,WalkValue::Bound(v)=>v}
    }
}
impl<'plan> WalkResult<'plan,(),()> {
    pub(in crate::plan) fn unmetered(self)->AudioWalkSpan<'plan> {
        match self.value {WalkValue::Plain(v)=>v,WalkValue::Bound(v)=>v.unmetered()}
    }
}
enum Content<'plan,I,L> {
    Plain(AudioSignalContent<'plan>),
    Bound(GuardedBound<Box<super::super::AudioBound<'plan>>,I,L>),
}
impl<'plan,I:Copy+Eq,L> Content<'plan,I,L> {
    fn is_leaf(&self)->bool {matches!(self,Self::Plain(AudioSignalContent::Leaf(_)))}
    fn finish<A:AudioSoundContextAdmission<Issuer=I,Lease=L>>(
        self,memory:Memory<I,L>,budget:&mut QueryBudget<'_,A>,
        make:impl FnOnce(AudioSignalContent<'plan>)->AudioWalkSpan<'plan>,
    )->Result<WalkResult<'plan,I,L>,A>{
        struct Mapping<C,F,I,L>{value:C,make:F,memory:Memory<I,L>}
        let guarded=Mapping{value:self,make,memory};
        budget.check_memory(&guarded.memory)?;
        let value=match guarded.value {
            Self::Plain(v)=>WalkValue::Plain((guarded.make)(v)),
            Self::Bound(v)=>WalkValue::Bound(v.map(budget,|bound|
                (guarded.make)(AudioSignalContent::Bound(bound)))?),
        };
        let result=WalkResult{value,memory:guarded.memory};
        budget.check_memory(&result.memory)?;
        Ok(result)
    }
}
fn stage_content<'plan,A:AudioSoundContextAdmission>(
    mut stage:Owned<AudioStage<'plan>,A::Issuer,A::Lease>,
    memory:&mut Memory<A::Issuer,A::Lease>,budget:&mut QueryBudget<'_,A>,
)->Result<Content<'plan,A::Issuer,A::Lease>,A>{
    budget.check_memory(memory)?;
    budget.check_memory(&stage.memory)?;
    budget.merge_checked(memory,&mut stage.memory);
    Ok(Content::Plain(AudioSignalContent::Stage(stage.value)))
}
impl RenderPlan {
    pub(in crate::plan) fn audio_walk_inner_admitted<'plan,A:AudioSoundContextAdmission>(
        &'plan self,sample:AudioSample,budget:&mut QueryBudget<'_,A>,
        seed:Option<&AudioWalkSeed>,stop_at_preserve:bool,stop_at_bindings:bool,
        captures:(
            Option<&mut Owned<Option<AudioDomainSeed>,A::Issuer,A::Lease>>,
            Option<&mut EditorialCapture>,Option<&super::super::AudioOwnerClock<'_>>,
        ),
    )->Result<WalkResult<'plan,A::Issuer,A::Lease>,A>{
        macro_rules! push {
            ($data:ident,$capacity:ident,$value:expr)=>{
                {let needed=$data.len()+1;budget.grow(&mut $data,&mut $capacity,needed)?;
                $data.push($value);}
            };
        }
'''
# Retain exact no-allocation marker filtering body in the same shared kernel.
rs_start=s.index('fn retain_incident_editorial(')
rs_end=s.index('\npub(super) fn minimum',rs_start)
retain=s[rs_start:rs_end].replace('fn retain_incident_editorial(', 'fn retain_incident_editorial<A:AudioSoundContextAdmission>(').replace('budget: &mut Budget,','budget: &mut QueryBudget<\'_,A>,').replace('Result<(), PlanError>','Result<(),A>').replace('budget.spend(', 'budget.canonical(')
(d/'audio_capture.rs').write_text(header+body+'    }\n}\n\n'+retain)
# Same false wrapper, moving actual slot out and restoring it on all results.
sig=old[:old.index('        let (mut capture, editorial_capture, input_owner) = captures;')]
wrapper=sig+'''        use super::audio_owners::admission::{self, Owned, Memory, Unmetered};
        let (mut capture, editorial, owner) = captures;
        let mut slot=Owned {value:capture.as_deref_mut().and_then(Option::take),memory:Memory::empty(())};
        let mut policy=Unmetered;
        let mut admitted=admission::Budget::new(budget,&mut policy);
        let result=self.audio_walk_inner_admitted(sample,&mut admitted,seed,
            stop_at_preserve,stop_at_bindings,
            (if capture.is_some(){Some(&mut slot)}else{None},editorial,owner));
        if let Some(capture)=capture {*capture=slot.value;}
        admission::outer::<_,Unmetered>(result.map(capture::WalkResult::unmetered))
    }'''
s=s[:start]+wrapper+s[end:]
# Remove now-extracted marker filter from the original module.
a=s.index('/// A marker on an ancestor')
b=s.index('pub(super) fn minimum',a)
s=s[:a]+s[b:]
anchor='''/// Hard caps bound both returned occurrence paths and structural search work.'''
s=s.replace(anchor,'''#[path="audio_capture.rs"]
pub(in crate::plan) mod capture;

'''+anchor)
p.write_text(s)
