use std::ops::Range;

use deadpan_core::{
    AudioSample, ExactRatio, FrameDuration, HoldAudio, InsertionBias, InstancePath, IterationId,
    MIX_SAMPLE_RATE, NodeId, PitchPolicy, ProjectFrame, ProjectId, RepeatInstance, RetimePurpose,
    RevisionId, SourceAudio, SourcePoint, TailEffect, TimeError,
};
use serde::Serialize;

use super::audio_bound::BindingTarget;
use super::audio_boundary::{AudioExtent, BoundaryOwner};
use super::audio_domain::{AudioDomainSeed, AudioWalkSeed, DomainGap};
use super::{AudioBoundaries, AudioBoundaryKind, AudioDefinitionSelector};
use super::{AudioProcessingSpan, AudioSignalContent, AudioStage};
use super::{CompiledKind, LookupStats, RenderPlan};
use crate::{AudioBoundaryRule, AudioEnvelope, AudioSampleGrid, AudioSampleMap, PlanError};

/// Hard caps bound both returned occurrence paths and structural search work.
/// A caller needing more material pages through contiguous sample ranges.
#[derive(Debug, Clone, Copy)]
pub struct AudioQueryLimits {
    pub maximum_spans: usize,
    pub maximum_work: usize,
}

impl AudioQueryLimits {
    pub fn validate(self) -> Result<(), PlanError> {
        if self.maximum_spans == 0
            || self.maximum_spans > 4096
            || self.maximum_work == 0
            || self.maximum_work > 65_536
        {
            return Err(PlanError::InvalidAudioLimits);
        }
        Ok(())
    }
}

impl Default for AudioQueryLimits {
    fn default() -> Self {
        Self {
            maximum_spans: 4096,
            maximum_work: 65_536,
        }
    }
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize)]
#[serde(rename_all = "snake_case")]
pub enum SilenceReason {
    NoSourceAudio,
    OutsideSourcePlacement,
    /// An authored Source crop. Its endpoints constrain physical sampling,
    /// but do not suppress the decay of a downstream Preserve stage.
    OutsideSourceSelection,
    /// Unlike an absent source voice, an authored silent Hold suppresses tails.
    SilentHold,
}

/// Exact source-clock filter support. Transparent partitions crop allocation,
/// not this domain; ordinary authored crops continue to exclude outside taps.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize)]
pub struct SourceSamplingSupport {
    pub start: SourcePoint,
    pub end: SourcePoint,
}

impl SourceSamplingSupport {
    pub(super) fn from_local(
        source: &SourceAudio,
        start: ExactRatio,
        duration: ExactRatio,
        support: Range<ExactRatio>,
    ) -> Result<Self, TimeError> {
        Ok(Self {
            start: source_point_from_local(source, start, duration, support.start)?,
            end: source_point_from_local(source, start, duration, support.end)?,
        })
    }
}

pub(super) fn source_point_from_local(
    source: &SourceAudio,
    start: ExactRatio,
    duration: ExactRatio,
    local: ExactRatio,
) -> Result<SourcePoint, TimeError> {
    let fraction = local.checked_sub(start)?.checked_div(duration)?;
    let ticks =
        ExactRatio::integer(source.span.start().ticks).checked_add(fraction.checked_mul(
            ExactRatio::integer(source.span.end().ticks - source.span.start().ticks),
        )?)?;
    Ok(SourcePoint {
        ticks,
        time_base: source.span.start().time_base,
    })
}

/// Authored instructions, not decoded PCM or a claim of supported DSP effects.
#[derive(Debug, Clone, PartialEq, Eq, Serialize)]
#[serde(tag = "type", rename_all = "snake_case")]
pub enum AudioContent {
    Silence {
        reason: SilenceReason,
    },
    Source {
        source: SourceAudio,
        /// Full measured-stream affine origin after the independent 48 kHz
        /// offset. A selected audible window never restarts this phase.
        start: ExactRatio,
        duration: ExactRatio,
        support: SourceSamplingSupport,
    },
    /// Retained user-selected source range; looping/crossfades belong to DSP.
    RoomTone {
        source: SourceAudio,
        /// Full intrinsic Hold duration in its local clock, before any crop.
        duration: FrameDuration,
    },
    /// Retain the policy and maximum in the Hold's local clock. A renderer must
    /// implement this explicitly, never substitute ordinary speech or silence.
    /// Live: the renderer feeds the effect with the processed Original sound
    /// heard over two seconds before this occurrence's root position.
    Tail {
        maximum: FrameDuration,
        effect: TailEffect,
        input: deadpan_core::TailInput,
        /// Full intrinsic Hold duration in its local clock, before any crop.
        duration: FrameDuration,
    },
    /// The source span played backwards from the Hold's local start, then
    /// silence. `duration` is the full intrinsic Hold duration, before crops.
    Reverse {
        source: SourceAudio,
        duration: FrameDuration,
    },
    /// A synthesized sine for the whole intrinsic Hold duration.
    Tone {
        frequency_hz: u32,
        level: deadpan_core::GainDb,
        duration: FrameDuration,
    },
}

impl AudioContent {
    pub(super) fn from_hold(value: &HoldAudio, duration: FrameDuration) -> Self {
        match value {
            HoldAudio::Silence => Self::Silence {
                reason: SilenceReason::SilentHold,
            },
            HoldAudio::RoomTone { source } => Self::RoomTone {
                source: source.clone(),
                duration,
            },
            HoldAudio::Tail {
                maximum,
                effect,
                input,
            } => Self::Tail {
                maximum: *maximum,
                effect: *effect,
                input: *input,
                duration,
            },
            HoldAudio::Reverse { source } => Self::Reverse {
                source: source.clone(),
                duration,
            },
            HoldAudio::Tone {
                frequency_hz,
                level,
            } => Self::Tone {
                frequency_hz: *frequency_hz,
                level: *level,
                duration,
            },
        }
    }
}

/// Mapping from the leaf's local frame clock to absolute project frames.
/// It stays exact even when the allocated sample interval rounds either edge.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize)]
pub struct AudioTransform {
    pub project_origin: ExactRatio,
    pub project_frames_per_local_frame: ExactRatio,
    pub project_frames_per_sample: ExactRatio,
}

impl AudioTransform {
    fn project_at(self, local: ExactRatio) -> Result<ExactRatio, TimeError> {
        self.project_origin
            .checked_add(local.checked_mul(self.project_frames_per_local_frame)?)
    }

    pub fn local_at(self, sample: AudioSample) -> Result<ExactRatio, TimeError> {
        ExactRatio::integer(sample.0)
            .checked_mul(self.project_frames_per_sample)?
            .checked_sub(self.project_origin)?
            .checked_div(self.project_frames_per_local_frame)
    }

    fn child(self, start: ExactRatio, scale: ExactRatio) -> Result<Self, TimeError> {
        Ok(Self {
            project_origin: self.project_at(start)?,
            project_frames_per_local_frame: self
                .project_frames_per_local_frame
                .checked_mul(scale)?,
            ..self
        })
    }
}

/// Outer-to-inner authored stages. Mixed Preserve/FollowSpeed policies must not
/// disappear when the exact timing affine maps are composed.
#[derive(Debug, Clone, PartialEq, Eq, Serialize)]
pub struct AudioRetimeStage {
    pub node: NodeId,
    pub child_start: ExactRatio,
    pub child_frames_per_local_frame: ExactRatio,
    pub pitch: PitchPolicy,
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize)]
pub struct AudioSpan {
    /// Relative instance paths are scoped to this definition when present.
    #[serde(skip_serializing_if = "Option::is_none")]
    pub definition: Option<AudioDefinitionSelector>,
    /// Portion requested by this query. All spans partition the query exactly.
    pub samples: Range<AudioSample>,
    /// Full interval after structural/placement clipping, independent of query
    /// partitioning. Both endpoints are rounded once from the project origin.
    pub allocated_samples: Range<AudioSample>,
    pub project_extent: Range<ExactRatio>,
    /// Meaningful envelope domain, which can extend beyond a transparent
    /// partition's allocation. Its original length determines fade width.
    pub envelope_extent: Range<ExactRatio>,
    pub envelope_samples: Range<AudioSample>,
    /// Meaningful fade progress, independent of current allocation. A resumed
    /// fragment can exhaust this retained envelope before its new allocation ends.
    pub envelope: AudioEnvelope,
    /// Owners of the envelope edges, never of a query or transparent partition.
    pub boundaries: AudioBoundaries,
    pub instance: InstancePath,
    pub gap_after: Option<IterationId>,
    pub transform: AudioTransform,
    pub grid: AudioSampleGrid<AudioSample>,
    pub sampling: AudioSampleMap<AudioSample>,
    pub retimes: Vec<AudioRetimeStage>,
    pub content: AudioContent,
}

impl AudioSpan {
    /// Exact original source coordinate at an output sample boundary. Rounding
    /// can place an edge sample slightly outside the authored source interval;
    /// this method does not clamp it or authorize reading excluded source PCM.
    pub fn source_point(&self, sample: AudioSample) -> Result<SourcePoint, PlanError> {
        self.source_point_from_local(self.sampling.local_at(sample)?)
    }

    /// Exact source coordinate at a project-frame coordinate, including a
    /// fractional clipped edge. This is distinct from the rounded allocation
    /// of output samples and does not authorize reading excluded source PCM.
    pub fn source_point_at_project_frame(
        &self,
        frame: ExactRatio,
    ) -> Result<SourcePoint, PlanError> {
        self.source_point_from_local(
            frame
                .checked_sub(self.transform.project_origin)?
                .checked_div(self.transform.project_frames_per_local_frame)?,
        )
    }

    fn source_point_from_local(&self, local: ExactRatio) -> Result<SourcePoint, PlanError> {
        let AudioContent::Source {
            source,
            start,
            duration,
            ..
        } = &self.content
        else {
            return Err(PlanError::NoSourceAudio);
        };
        Ok(source_point_from_local(source, *start, *duration, local)?)
    }
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize)]
pub struct AudioQuery {
    pub project_id: ProjectId,
    pub revision_id: RevisionId,
    pub samples: Range<AudioSample>,
    pub spans: Vec<AudioSpan>,
    pub lookup: LookupStats,
    #[serde(skip)]
    pub work: usize,
}

pub(super) struct Budget {
    pub(super) remaining: usize,
    pub(super) lookup: LookupStats,
}

// Sequence/Repeat bounds describe derived allocation, not a new crop of a
// retained partition. Keep their policies only when a real envelope edge is
// exactly coincident. Capture paths after descent to avoid cloning every prefix.
#[derive(Debug, Clone, PartialEq, Eq)]
pub(super) struct EnvelopeConstraint {
    pub(super) placement_support: bool,
    pub(super) range: Range<ExactRatio>,
    pub(super) node: usize,
    pub(super) repeat_count: usize,
    pub(super) gap_after: Option<IterationId>,
    pub(super) kinds: (AudioBoundaryKind, AudioBoundaryKind),
}

/// Creative boundaries use the current output clock. They never restrict raw
/// support or the retained sampling/envelope domain.
#[derive(Debug, Clone)]
pub(super) struct EditorialConstraint {
    pub(super) boundary: EnvelopeConstraint,
    pub(super) edges: deadpan_core::AudioEditorialEdges,
    /// Only transported outer markers use sample probes. A resumed binding can
    /// deliver a different incident inner voice at the authored boundary.
    pub(super) incident_samples: Option<(ExactRatio, ExactRatio)>,
}

#[derive(Debug, Clone, Default)]
pub(super) struct EditorialCapture {
    pub(super) editorial: Vec<EditorialConstraint>,
    pub(super) constraints: Vec<EnvelopeConstraint>,
    pub(super) repeats: Vec<RepeatInstance>,
}

pub(super) enum AudioWalkSpan<'plan> {
    Leaf(AudioSpan),
    Stage(AudioProcessingSpan<'plan>),
}

impl<'plan> AudioWalkSpan<'plan> {
    pub(super) fn into_processing(self) -> AudioProcessingSpan<'plan> {
        match self {
            Self::Stage(span) => span,
            Self::Leaf(span) => AudioProcessingSpan {
                definition: span.definition,
                samples: span.samples,
                allocated_samples: span.allocated_samples,
                project_extent: span.project_extent,
                instance: span.instance,
                gap_after: span.gap_after,
                transform: span.transform,
                grid: span.grid,
                sampling: span.sampling,
                retimes: span.retimes,
                content: AudioSignalContent::Leaf(span.content),
            },
        }
    }
}

impl Budget {
    pub(super) fn spend(&mut self, amount: usize) -> Result<(), PlanError> {
        self.remaining = self
            .remaining
            .checked_sub(amount)
            .ok_or(PlanError::AudioQueryLimit("structural work"))?;
        Ok(())
    }
}

impl RenderPlan {
    pub fn audio_duration(&self) -> Result<AudioSample, PlanError> {
        Ok(self
            .metadata
            .presentation_basis
            .frame_rate
            .audio_boundary(ProjectFrame(self.duration().frames()))?)
    }

    /// Bounded interval lookup. Each returned span is resolved by indexed descent
    /// at the next unfilled sample, so skipped repeat plays are never expanded.
    /// No decoding, channel inference, DSP, or media I/O happens here.
    pub fn audio(
        &self,
        samples: Range<AudioSample>,
        limits: AudioQueryLimits,
    ) -> Result<AudioQuery, PlanError> {
        limits.validate()?;
        if samples.start.0 < 0
            || samples.end < samples.start
            || samples.end > self.audio_duration()?
        {
            return Err(PlanError::AudioRangeOutOfRange);
        }
        let mut budget = Budget {
            remaining: limits.maximum_work,
            lookup: LookupStats::default(),
        };
        let mut spans = Vec::new();
        let mut cursor = samples.start;
        while cursor < samples.end {
            if spans.len() == limits.maximum_spans {
                return Err(PlanError::AudioQueryLimit("span count"));
            }
            let mut span = self.audio_span(cursor, &mut budget)?;
            span.samples = cursor..span.allocated_samples.end.min(samples.end);
            cursor = span.samples.end;
            spans.push(span);
        }
        Ok(AudioQuery {
            project_id: self.metadata.project_id.clone(),
            revision_id: self.metadata.revision_id.clone(),
            samples,
            spans,
            lookup: budget.lookup,
            work: limits.maximum_work - budget.remaining,
        })
    }

    fn audio_span(&self, sample: AudioSample, budget: &mut Budget) -> Result<AudioSpan, PlanError> {
        match self.audio_walk(sample, budget, None, false, false, None)? {
            AudioWalkSpan::Leaf(span) => Ok(span),
            AudioWalkSpan::Stage(_) => {
                Err(PlanError::InvalidPlan("flattened audio retained a stage"))
            }
        }
    }

    pub(super) fn audio_walk<'plan>(
        &'plan self,
        sample: AudioSample,
        budget: &mut Budget,
        seed: Option<&AudioWalkSeed>,
        stop_at_preserve: bool,
        stop_at_bindings: bool,
        capture: Option<&mut Option<AudioDomainSeed>>,
    ) -> Result<AudioWalkSpan<'plan>, PlanError> {
        self.audio_walk_inner(
            sample,
            budget,
            seed,
            stop_at_preserve,
            stop_at_bindings,
            (capture, None, None),
        )
    }

    pub(super) fn audio_walk_editorial<'plan>(
        &'plan self,
        sample: AudioSample,
        budget: &mut Budget,
        seed: Option<&AudioWalkSeed>,
        stops: (bool, bool),
        editorial: &mut EditorialCapture,
    ) -> Result<AudioWalkSpan<'plan>, PlanError> {
        self.audio_walk_inner(
            sample,
            budget,
            seed,
            stops.0,
            stops.1,
            (None, Some(editorial), None),
        )
    }

    pub(super) fn audio_walk_owner_input(
        &self,
        sample: AudioSample,
        budget: &mut Budget,
        owner: &super::AudioOwnerClock<'_>,
        capture: &mut Option<AudioDomainSeed>,
        seed: Option<&AudioWalkSeed>,
    ) -> Result<(), PlanError> {
        #[cfg(test)]
        let before = budget.remaining;
        let walked = self.audio_walk_inner(
            sample,
            budget,
            seed,
            true,
            true,
            (Some(&mut *capture), None, Some(owner)),
        );
        #[cfg(test)]
        super::audio_owners::tests::legacy_snapshot_v1::capture_baseline::capture(
            self,
            sample,
            owner,
            capture.as_ref(),
            &walked,
            (before, budget.remaining),
        );
        // Preserve the actual complete walk and its original discard point.
        walked?;
        Ok(())
    }

    fn audio_walk_inner<'plan>(
        &'plan self,
        sample: AudioSample,
        budget: &mut Budget,
        seed: Option<&AudioWalkSeed>,
        stop_at_preserve: bool,
        stop_at_bindings: bool,
        captures: (
            Option<&mut Option<AudioDomainSeed>>,
            Option<&mut EditorialCapture>,
            Option<&super::AudioOwnerClock<'_>>,
        ),
    ) -> Result<AudioWalkSpan<'plan>, PlanError> {
        let (mut capture, editorial_capture, input_owner) = captures;
        let rate = self.metadata.presentation_basis.frame_rate;
        let mut transform = AudioTransform {
            project_origin: ExactRatio::ZERO,
            project_frames_per_local_frame: ExactRatio::integer(1),
            project_frames_per_sample: ExactRatio::new(
                i128::from(rate.numerator()),
                i128::from(MIX_SAMPLE_RATE) * i128::from(rate.denominator()),
            )?,
        };
        let grid = seed.map(|seed| seed.grid).map(Ok).unwrap_or_else(|| {
            AudioSampleGrid::<AudioSample>::new(
                ExactRatio::ZERO,
                transform.project_frames_per_sample,
                AudioBoundaryRule::RoundEven,
            )
        })?;
        // Search the allocated interval, not the PCM sample's coordinate.
        let (probe, bias) = grid.probe(sample)?;
        let mut extent = ExactRatio::ZERO..ExactRatio::integer(self.duration().frames());
        let mut envelope: Option<Range<ExactRatio>> = None;
        let mut constraints = Vec::new();
        let mut editorial = Vec::new();
        let mut current = self.root;
        let mut repeats = Vec::new();
        let mut retimes = Vec::new();
        let mut seeded_gap = None;
        let definition = seed.and_then(|seed| seed.definition.as_ref());
        let bypass_binding = seed.and_then(|seed| seed.bypass_binding);
        let mut suppress_entry_editorial =
            seed.map_or_else(Default::default, |seed| seed.suppress_entry_editorial);
        if let Some(seed) = seed {
            budget.spend(
                seed.constraints.len()
                    + seed.editorial.len()
                    + seed.repeats.len()
                    + seed.retimes.len(),
            )?;
            current = seed.node;
            transform = seed.transform;
            extent = seed.extent.clone();
            envelope = seed.envelope.clone();
            constraints = seed.constraints.clone();
            editorial = seed.editorial.clone();
            repeats = seed.repeats.clone();
            retimes = seed.retimes.clone();
            seeded_gap = seed.gap.clone();
        }
        let mut inherited_envelope;
        let mut inherited_constraints;
        let mut inherited_editorial;
        let mut domain_gap = None;
        let (content, gap_after) = loop {
            budget.spend(1)?;
            budget.lookup.visited_nodes += 1;
            let node = &self.nodes[current];
            inherited_envelope = envelope.clone();
            inherited_constraints = constraints.len();
            if let Some(gap) = seeded_gap.take() {
                let CompiledKind::Repeat {
                    gap_audio: Some(audio),
                    ..
                } = &node.kind
                else {
                    return Err(PlanError::InvalidPlan("audio domain gap is missing"));
                };
                let gap_extent = transform.project_origin
                    ..transform.project_at(ExactRatio::integer(gap.duration.frames()))?;
                retain_incident_editorial(&mut editorial, &gap_extent, grid, budget)?;
                inherited_editorial = editorial.len();
                extent = intersect(extent, gap_extent.clone())?;
                envelope = Some(match envelope {
                    Some(previous) => intersect(previous, gap_extent.clone())?,
                    None => gap_extent.clone(),
                });
                constraints.push(EnvelopeConstraint {
                    placement_support: false,
                    range: gap_extent,
                    node: current,
                    repeat_count: repeats.len(),
                    gap_after: gap.after.clone(),
                    kinds: (
                        AudioBoundaryKind::RepeatGapStart,
                        AudioBoundaryKind::RepeatGapEnd,
                    ),
                });
                let after = gap.after.clone();
                let content = if stop_at_bindings
                    && bypass_binding != Some(BindingTarget::Gap(current))
                    && let Some(bound) = self.bound_at(
                        current,
                        &repeats,
                        definition,
                        super::audio_bound::BoundPlacement {
                            transform: super::SignalTransform {
                                signal_origin: transform.project_origin,
                                signal_frames_per_local_frame: transform
                                    .project_frames_per_local_frame,
                                grid_origin: grid.frame_origin(),
                                signal_frames_per_sample: transform.project_frames_per_sample,
                            },
                            grid: AudioSampleGrid::new(
                                grid.frame_origin(),
                                transform.project_frames_per_sample,
                                grid.boundary_rule(),
                            )?,
                            allocated_start: super::SignalSample(grid.boundary(extent.start)?.0),
                            support: envelope.as_ref(),
                            constraints: &constraints,
                            gap: Some(&gap),
                        },
                        budget,
                    )? {
                    AudioSignalContent::Bound(Box::new(bound))
                } else {
                    AudioSignalContent::Leaf(AudioContent::from_hold(audio, gap.duration))
                };
                domain_gap = Some(gap);
                break (content, after);
            }
            let node_extent = transform.project_origin..transform.project_at(node.extent)?;
            retain_incident_editorial(&mut editorial, &node_extent, grid, budget)?;
            inherited_editorial = editorial.len();
            extent = intersect(extent, node_extent.clone())?;
            // Capture the whole owner before descending into its current
            // child. Transparent crops restrict delivery, not this context.
            // A Preserve or retained binding encountered earlier stops the
            // walk and is captured below instead: its DSP must stay intact.
            if let Some(owner) = input_owner
                && owner.kind() == super::AudioOwnerKind::Node
                && owner.definition() == definition
                && owner.instance().node == node.inspection.id
                && owner.instance().repeats == repeats
                && let Some(capture) = capture.as_deref_mut()
                && capture.is_none()
            {
                let support = match &inherited_envelope {
                    Some(envelope) => intersect(node_extent.clone(), envelope.clone())?,
                    None => node_extent.clone(),
                };
                budget.spend(
                    inherited_constraints + inherited_editorial + repeats.len() + retimes.len() + 1,
                )?;
                let samples = grid.boundary(support.start)?..grid.boundary(support.end)?;
                if !samples.contains(&sample) {
                    return Err(PlanError::InvalidPlan(
                        "owner input excludes its visible sample",
                    ));
                }
                *capture = Some(AudioDomainSeed {
                    walk: AudioWalkSeed {
                        definition: definition.cloned(),
                        bypass_binding,
                        node: current,
                        transform,
                        grid,
                        extent: support,
                        envelope: inherited_envelope.clone(),
                        constraints: constraints[..inherited_constraints].to_vec(),
                        editorial: editorial[..inherited_editorial].to_vec(),
                        suppress_entry_editorial,
                        repeats: repeats.clone(),
                        retimes: retimes.clone(),
                        gap: None,
                    },
                    samples,
                    visible: grid.boundary(extent.start)?..grid.boundary(extent.end)?,
                    instance: owner.instance().clone(),
                });
            }
            let suppressed = std::mem::take(&mut suppress_entry_editorial);
            let own_editorial = deadpan_core::AudioEditorialEdges {
                start: node.audio_editorial_edges.start && !suppressed.start,
                end: node.audio_editorial_edges.end && !suppressed.end,
            };
            if !own_editorial.is_empty() {
                budget.spend(1)?;
                editorial.push(EditorialConstraint {
                    boundary: EnvelopeConstraint {
                        placement_support: false,
                        range: node_extent.clone(),
                        node: current,
                        repeat_count: repeats.len(),
                        gap_after: None,
                        kinds: (AudioBoundaryKind::NodeStart, AudioBoundaryKind::NodeEnd),
                    },
                    edges: own_editorial,
                    incident_samples: None,
                });
            }
            if !matches!(
                node.kind,
                CompiledKind::Retime {
                    purpose: RetimePurpose::Partition,
                    ..
                }
            ) {
                constraints.push(EnvelopeConstraint {
                    placement_support: false,
                    range: node_extent.clone(),
                    node: current,
                    repeat_count: repeats.len(),
                    gap_after: None,
                    kinds: (AudioBoundaryKind::NodeStart, AudioBoundaryKind::NodeEnd),
                });
                if !matches!(
                    node.kind,
                    CompiledKind::Sequence { .. } | CompiledKind::Repeat { .. }
                ) {
                    envelope = Some(match envelope {
                        Some(previous) => intersect(previous, node_extent)?,
                        None => node_extent,
                    });
                }
            }
            if stop_at_bindings
                && bypass_binding != Some(BindingTarget::Node(current))
                && let Some(bound) = self.bound_at(
                    current,
                    &repeats,
                    definition,
                    super::audio_bound::BoundPlacement {
                        transform: super::SignalTransform {
                            signal_origin: transform.project_origin,
                            signal_frames_per_local_frame: transform.project_frames_per_local_frame,
                            grid_origin: grid.frame_origin(),
                            signal_frames_per_sample: transform.project_frames_per_sample,
                        },
                        grid: AudioSampleGrid::new(
                            grid.frame_origin(),
                            transform.project_frames_per_sample,
                            grid.boundary_rule(),
                        )?,
                        allocated_start: super::SignalSample(grid.boundary(extent.start)?.0),
                        support: envelope.as_ref(),
                        constraints: &constraints,
                        gap: None,
                    },
                    budget,
                )?
            {
                break (AudioSignalContent::Bound(Box::new(bound)), None);
            }
            let local = probe
                .checked_sub(transform.project_origin)?
                .checked_div(transform.project_frames_per_local_frame)?;
            match &node.kind {
                CompiledKind::Source { audio: None, .. } => {
                    break (
                        AudioSignalContent::Leaf(AudioContent::Silence {
                            reason: SilenceReason::NoSourceAudio,
                        }),
                        None,
                    );
                }
                CompiledKind::Source {
                    audio: Some(audio), ..
                } => {
                    if audio.selection.start == audio.selection.end {
                        break (
                            AudioSignalContent::Leaf(AudioContent::Silence {
                                reason: SilenceReason::OutsideSourceSelection,
                            }),
                            None,
                        );
                    }
                    let start = transform.project_at(audio.selection.start)?;
                    let end = transform.project_at(audio.selection.end)?;
                    let envelope = envelope
                        .as_mut()
                        .ok_or(PlanError::InvalidPlan("source has no envelope domain"))?;
                    let mut placement_constraint = EnvelopeConstraint {
                        placement_support: false,
                        range: start..end,
                        node: current,
                        repeat_count: repeats.len(),
                        gap_after: None,
                        kinds: (
                            AudioBoundaryKind::SourcePlacementStart,
                            AudioBoundaryKind::SourcePlacementEnd,
                        ),
                    };
                    let content = if sample < grid.boundary(start)? {
                        extent.end = minimum(extent.end, start)?;
                        envelope.end = minimum(envelope.end, start)?;
                        // Before placement, its incoming edge is this silence's
                        // outgoing edge, as in the original allocation model.
                        placement_constraint.range.end = start;
                        placement_constraint.kinds.1 = AudioBoundaryKind::SourcePlacementStart;
                        AudioContent::Silence {
                            reason: audio.outside_reason(),
                        }
                    } else if sample >= grid.boundary(end)? {
                        extent.start = maximum(extent.start, end)?;
                        envelope.start = maximum(envelope.start, end)?;
                        placement_constraint.range.start = end;
                        placement_constraint.kinds.0 = AudioBoundaryKind::SourcePlacementEnd;
                        AudioContent::Silence {
                            reason: audio.outside_reason(),
                        }
                    } else {
                        extent = intersect(extent, start..end)?;
                        *envelope = intersect(envelope.clone(), start..end)?;
                        AudioContent::Source {
                            source: audio.source.clone(),
                            start: audio.start,
                            duration: audio.duration,
                            support: SourceSamplingSupport::from_local(
                                &audio.source,
                                audio.start,
                                audio.duration,
                                envelope
                                    .start
                                    .checked_sub(transform.project_origin)?
                                    .checked_div(transform.project_frames_per_local_frame)?
                                    ..envelope
                                        .end
                                        .checked_sub(transform.project_origin)?
                                        .checked_div(transform.project_frames_per_local_frame)?,
                            )?,
                        }
                    };
                    constraints.push(placement_constraint);
                    break (AudioSignalContent::Leaf(content), None);
                }
                CompiledKind::Hold { audio, .. } => {
                    break (
                        AudioSignalContent::Leaf(AudioContent::from_hold(
                            audio,
                            node.inspection.duration,
                        )),
                        None,
                    );
                }
                CompiledKind::Sequence { entries } => {
                    let mut left = 0;
                    let mut right = entries.len();
                    while left < right {
                        budget.spend(1)?;
                        budget.lookup.sequence_comparisons += 1;
                        let middle = left + (right - left) / 2;
                        let comparison = local.compare(entries[middle].end);
                        let preceding = comparison.is_gt()
                            || (comparison.is_eq() && bias == InsertionBias::Right);
                        if preceding {
                            left = middle + 1;
                        } else {
                            right = middle;
                        }
                    }
                    let entry = entries
                        .get(left)
                        .ok_or(PlanError::InvalidPlan("audio sequence has no child"))?;
                    transform = transform.child(entry.start, ExactRatio::integer(1))?;
                    current = entry.child;
                }
                CompiledKind::Retime {
                    child,
                    start,
                    scale,
                    pitch,
                    purpose,
                } => {
                    if node.preserve_input.is_some() {
                        return Err(PlanError::InvalidPlan(
                            "owned Preserve output requires its splice placement; use the intrinsic projection for preparation",
                        ));
                    }
                    if stop_at_preserve && pitch.processes(*scale == ExactRatio::ONE) {
                        budget.spend(repeats.len() + 1)?;
                        break (
                            AudioSignalContent::Stage(AudioStage::for_node(
                                self,
                                current,
                                &repeats,
                                definition,
                                bypass_binding,
                            )?),
                            None,
                        );
                    }
                    if *purpose != RetimePurpose::Partition {
                        retimes.push(AudioRetimeStage {
                            node: node.inspection.id.clone(),
                            child_start: *start,
                            child_frames_per_local_frame: *scale,
                            pitch: *pitch,
                        });
                    }
                    let inverse = ExactRatio::integer(1).checked_div(*scale)?;
                    transform = transform.child(
                        ExactRatio::ZERO.checked_sub(start.checked_mul(inverse)?)?,
                        inverse,
                    )?;
                    current = *child;
                }
                CompiledKind::Repeat {
                    layout,
                    gap_duration,
                    ..
                } => {
                    let location = layout
                        .locate_bounded(local, bias, budget.remaining)
                        .map_err(|error| {
                            if error.code == deadpan_core::DocumentErrorCode::LimitExceeded {
                                PlanError::AudioQueryLimit("structural work")
                            } else {
                                error.into()
                            }
                        })?;
                    budget.spend(location.comparisons)?;
                    budget.lookup.iteration_run_comparisons += location.comparisons;
                    if location.in_gap {
                        let start = location.play.start.checked_add(location.play.duration)?;
                        transform = transform.child(start, ExactRatio::integer(1))?;
                        if let Some(child) = location.play.gap_child {
                            let gap_extent = transform.project_origin
                                ..transform.project_at(location.play.gap_after)?;
                            retain_incident_editorial(&mut editorial, &gap_extent, grid, budget)?;
                            constraints.push(EnvelopeConstraint {
                                placement_support: false,
                                range: gap_extent,
                                node: current,
                                repeat_count: repeats.len(),
                                gap_after: Some(location.play.iteration.clone()),
                                kinds: (
                                    AudioBoundaryKind::RepeatGapStart,
                                    AudioBoundaryKind::RepeatGapEnd,
                                ),
                            });
                            repeats.push(RepeatInstance {
                                node: node.inspection.id.clone(),
                                iteration: location.play.iteration,
                            });
                            current = self.by_id[&child];
                            continue;
                        }
                        seeded_gap = Some(DomainGap {
                            after: Some(location.play.iteration),
                            duration: *gap_duration,
                        });
                        continue;
                    }
                    transform = transform.child(location.play.start, ExactRatio::integer(1))?;
                    repeats.push(RepeatInstance {
                        node: node.inspection.id.clone(),
                        iteration: location.play.iteration,
                    });
                    current = self.by_id[&location.play.child];
                }
            }
        };
        let allocated_samples = grid.boundary(extent.start)?..grid.boundary(extent.end)?;
        if !allocated_samples.contains(&sample) {
            return Err(PlanError::InvalidPlan("audio interval did not advance"));
        }
        let mut envelope = AudioExtent::new(
            envelope.ok_or(PlanError::InvalidPlan("audio has no envelope domain"))?,
        );
        if let Some(capture) = capture
            && capture.is_none()
        {
            budget.spend(
                inherited_constraints + inherited_editorial + repeats.len() + retimes.len() + 1,
            )?;
            let samples =
                grid.boundary(envelope.range.start)?..grid.boundary(envelope.range.end)?;
            if !samples.contains(&sample) {
                return Err(PlanError::InvalidPlan(
                    "audio domain does not contain its visible sample",
                ));
            }
            *capture = Some(AudioDomainSeed {
                walk: AudioWalkSeed {
                    definition: definition.cloned(),
                    bypass_binding,
                    node: current,
                    transform,
                    grid,
                    extent: envelope.range.clone(),
                    envelope: inherited_envelope,
                    constraints: constraints[..inherited_constraints].to_vec(),
                    editorial: editorial[..inherited_editorial].to_vec(),
                    suppress_entry_editorial: Default::default(),
                    repeats: repeats.clone(),
                    retimes: retimes.clone(),
                    gap: domain_gap,
                },
                samples,
                visible: allocated_samples.clone(),
                instance: InstancePath {
                    node: self.nodes[current].inspection.id.clone(),
                    repeats: repeats.clone(),
                },
            });
        }
        if let Some(capture) = editorial_capture {
            budget.spend(editorial.len() + constraints.len() + repeats.len())?;
            *capture = EditorialCapture {
                editorial,
                constraints: constraints.clone(),
                repeats: repeats.clone(),
            };
        }
        for constraint in constraints {
            let node = &self.nodes[constraint.node];
            let owner = BoundaryOwner {
                node: &node.inspection.id,
                repeats: &repeats[..constraint.repeat_count],
                gap_after: constraint.gap_after.as_ref(),
                policies: if constraint.placement_support {
                    Default::default()
                } else {
                    node.audio_edges
                },
                placement_support: constraint.placement_support,
            };
            if constraint.range.start == envelope.range.start {
                envelope.clip_start(constraint.range.start, owner, constraint.kinds.0, budget)?;
            }
            if constraint.range.end == envelope.range.end {
                envelope.clip_end(constraint.range.end, owner, constraint.kinds.1, budget)?;
            }
        }
        let envelope_samples =
            grid.boundary(envelope.range.start)?..grid.boundary(envelope.range.end)?;
        let sampling = AudioSampleMap::new(
            allocated_samples.start,
            grid.at(allocated_samples.start)?
                .checked_sub(transform.project_origin)?
                .checked_div(transform.project_frames_per_local_frame)?,
            transform
                .project_frames_per_sample
                .checked_div(transform.project_frames_per_local_frame)?,
        )?;
        let content = match content {
            content @ (AudioSignalContent::Stage(_)
            | AudioSignalContent::ProjectedStage(_)
            | AudioSignalContent::Bound(_)) => {
                return Ok(AudioWalkSpan::Stage(AudioProcessingSpan {
                    definition: definition.cloned(),
                    samples: allocated_samples.clone(),
                    allocated_samples,
                    project_extent: extent,
                    instance: InstancePath {
                        node: self.nodes[current].inspection.id.clone(),
                        repeats,
                    },
                    gap_after,
                    transform,
                    grid,
                    sampling,
                    retimes,
                    content,
                }));
            }
            AudioSignalContent::Leaf(content) => content,
        };
        Ok(AudioWalkSpan::Leaf(AudioSpan {
            definition: definition.cloned(),
            samples: allocated_samples.clone(),
            allocated_samples,
            project_extent: extent,
            envelope_extent: envelope.range,
            envelope: AudioEnvelope::from_samples(envelope_samples.clone())?,
            envelope_samples,
            boundaries: envelope.boundaries,
            instance: InstancePath {
                node: self.nodes[current].inspection.id.clone(),
                repeats,
            },
            gap_after,
            transform,
            grid,
            sampling,
            retimes,
            content,
        }))
    }
}

/// A marker on an ancestor belongs only to the incident descendant allocation.
/// Filter before introducing this node's own markers: a full owner behind a
/// neutral Partition must retain its hidden fade progress, while an unrelated
/// later Partition cannot acquire an earlier sibling's edge through that same
/// hidden context. Start and end ownership are directionally half-open.
fn retain_incident_editorial(
    editorial: &mut Vec<EditorialConstraint>,
    allocation: &Range<ExactRatio>,
    grid: AudioSampleGrid<AudioSample>,
    budget: &mut Budget,
) -> Result<(), PlanError> {
    budget.spend(editorial.len())?;
    if editorial.is_empty() {
        return Ok(());
    }
    let samples = grid.boundary(allocation.start)?..grid.boundary(allocation.end)?;
    editorial.retain_mut(|marker| {
        if let Some((start, end)) = marker.incident_samples {
            let contains = |at: ExactRatio| {
                at.compare_integer(samples.start.0).is_ge()
                    && at.compare_integer(samples.end.0).is_lt()
            };
            marker.edges.start &= contains(start);
            marker.edges.end &= contains(end);
        } else {
            marker.edges.start &= marker
                .boundary
                .range
                .start
                .compare(allocation.start)
                .is_ge()
                && marker.boundary.range.start.compare(allocation.end).is_lt();
            marker.edges.end &= marker.boundary.range.end.compare(allocation.start).is_gt()
                && marker.boundary.range.end.compare(allocation.end).is_le();
        }
        !marker.edges.is_empty()
    });
    Ok(())
}

pub(super) fn minimum(a: ExactRatio, b: ExactRatio) -> Result<ExactRatio, TimeError> {
    Ok(if a.checked_sub(b)?.compare_integer(0).is_le() {
        a
    } else {
        b
    })
}
pub(super) fn maximum(a: ExactRatio, b: ExactRatio) -> Result<ExactRatio, TimeError> {
    Ok(if a.checked_sub(b)?.compare_integer(0).is_ge() {
        a
    } else {
        b
    })
}
pub(super) fn intersect(
    a: Range<ExactRatio>,
    b: Range<ExactRatio>,
) -> Result<Range<ExactRatio>, TimeError> {
    Ok(maximum(a.start, b.start)?..minimum(a.end, b.end)?)
}
