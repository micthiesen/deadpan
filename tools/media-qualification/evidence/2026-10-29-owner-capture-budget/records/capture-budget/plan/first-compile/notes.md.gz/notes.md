# Capture-only candidate, initial qualification boundary

Scratch implementation only. No Cargo/rustc/live/scoped/index/Git operations.
Parent owns compilation, runtime proof, integration and publication. Rustfmt
parsing is not a compiler result. Frozen old capture Golden remains unchanged:
32661e1a8abf59eb7d8146cd2898fd979415db3763685463df576d5e916d27c0.

## Scope and common kernel

The complete old audio_walk_inner body is extracted to audio_capture.rs as
audio_walk_inner_admitted; it remains the single actual structural walk.
audio.rs keeps its compatibility wrapper. That wrapper moves a caller's actual
optional capture slot into an unmetered guard, restores it on success AND error,
and returns the same actual unmetered span. The complete span is still computed.
The actual marker-filter body is extracted beside it, not replayed/replaced.

The admitted selected path uses that shared body with the actual caller's
QueryBudget, exact sealed parent/query/member and caller-owned guarded slot.
The false path keeps the old audio_walk_owner_input wrapper and test observer,
then records the already-spent legacy amount in the enclosing false counters
without forwarding or spending it again. Both paths share scope classification,
the observed owner copy, Input construction and guarded postvalidation.

Working vector buffer capacities have independent lanes. Their actual growing
sites use the existing grow implementation, which admits full new+old capacity,
drops the old Vec and only then releases the old capacity lease. Fixed prefix
copies reserve exact arrays before allocation and never add another canonical
copy len: the original aggregate debit remains at its old site. New identity,
field/layout, migration and reached Core sorted-scratch work is additional.

The captured seed is a separate Owned<Option<AudioDomainSeed>>. Its temporary
replacement is fully constructed and guarded before slot publication. It stays
charged when a later bound/boundary/span operation fails. The selected Input's
owner copy is admitted only AFTER dropping the complete successful walk result.
try_map keeps the old seed and all partially constructed fields covered on error,
then pairs the actual Input before issuer postvalidation.

## Bound/Box bridge

audio_bound_query uses generic private GuardedBound<T> with Legacy and Core
value alternatives. Values precede their Plan charge; Core retains its own value
and charge pairing. The actual bound_at_query and its linear child receipt remain
unchanged. The Box shell is reserved for exact Layout<AudioBound>, safely
allocated with Box::new_uninit, and paired with its lease before entering map.
The only metered initializer is allocation-free Box::write within map_value.
Pre/post-map failures keep both the uninitialized shell and initialized value
covered, and drop them before the shell charge. No new Core/product boxing API.

Content and complete spans use the same generic guard, avoiding an unadmitted
Box just to reduce a Rust enum's stack size. Plain Leaf/Stage and actual Core
Bound all retain their respective guards through the old discard point.

## Actual admitted public result and integration

AdmittedAudioOwnerInputCapture owns the plain actual capture FIRST and its
source-metadata Memory LAST. Its only Input access borrows. There is no Clone,
into_input, into_parts, independent lease take or public commit constructor.
It returns Q/C totals, separate canonical/additional categories and trusted C
forwarded mode. Query and capture provenance sums are checked after the actual
Input is already guarded; issuer/mode are checked before capture and afterward.
without_selection consumes Q with C0 and no new limits/spend/reserve.

The source charge is NOT transferred to Graph. Parent's Audio consumer borrows
through the existing legacy probe/final sharing and drops it afterward. Accepted
Retained probe internals remain unadmitted; the existing independently admitted
final sharing carrier/Graph handoff remains separate. No probe, raw_domain,
retained-owner-query, extra native state or cold/batch admission is claimed.

## Conservative bounds and exclusions

Workspace owning-edge charges can conservatively remain until the complete span
drops, including past consumed constraint/editorial edges. Growing actual Vec
capacities are separately tracked. The boundary helper likewise retains cleared
origin-edge charges until extent drop while charging retained Vec capacities.
These are explicit per-constructor conservative retention bounds, not minimum
physical heap or RSS claims. None of this workspace charge reaches the returned
Input carrier; only its captured seed and observed owner copy remain.

RepeatLayout::locate_bounded returns temporary Arc identity clones without new
backing buffers. The retained iteration edge is charged with own_iteration
before moving it into actual workspace, matching existing query admission.
No Core API, counting walk, owner-ID substitution, fake provider or graph cache.

No caps, weights, query replay, budget reset/refund, retry, pooling, source
admission or native bound changes. Accepted work is never released by Drop.

## Focused tests authored, not executed

The constructor agent's frozen three files are integrated exactly, including
eight focused literal/capacity/canonical/peak/refusal/cancel/issuer tests. Its
patch SHA is 4a2cd4eecc0d9f37067551f35cf54fdb40a71f44ef2db2abeb802e39b3edb1a0.

Four new full-capture tests cover:
- actual Root/hidden Domain and both modes across all14old cases+2supplements,
  exact captured seeds/Input and actual complete discarded Leaf/Stage;
- actual full Q+walk+seed/Box overlap reservation peak, exact limit and one-byte
  short with populated actual captured slot at late refusal, complete cleanup;
- cancellation after a paid actual Q, no Input publication, no work refund;
- exact/one-short C, zero internal C, no-selection with spending disabled.

Existing query-only tests now borrow the admitted Input and expect retained C
charge/work/categories instead of the obsolete plain into_input return.
Their independent old ordered Q/private seed oracle and query peak assertions
remain. The new observer extension only accepts borrowed actual results; its
inactive branch still returns before JSON allocation.

Runtime fixtures and all tests are UNVERIFIED. Parent must qualify exact peak
location/late-slot fixture assumptions rather than weakening them. The pinned
compiler must qualify Box::write and all generic/lifetime signatures.

### Reviewed oracle provenance view

The immutable full Bound JSON includes Core resolved.work and lattice.work.
Product fields and actual counters are NOT reset or mutated. A test-only
None-fastpath observer sees the actual EXISTING outer linear receipt immediately
before account_core, without a second take/spend. Capture phase is separate
from Q so the selected opaque Bound is unambiguous.

False mode compares the complete old discarded span literally. True mode
asserts actual resolved.work == receipt total, old resolved.work == receipt
canonical, and exact outer additional work, bounded by total capture additional.
Only the two explicit resolved/work and resolved/lattice/work scalar pointers
are normalized in the comparison view. Lattice's internal fork has no separate
Plan receipt: its observed nonnegative delta is bounded by the outer additional
and its total by the outer total. This is NOT an independently measured
per-lattice category split. Every other scalar/ordered Bound/span/seed field
compares literally. Parent and Core owner agreed this narrow view; a separate
Core-private witness is parent-owned and outside this patch.

A first focused Core-owner static review found map/Box/closure guard ownership
sound on pre/post-map failures and identified one missed generic error
conversion, now fixed before freeze. Review is not a compiler/runtime claim.

## Remaining qualification

No executable result, strict-lint result, numerical PCM/dependency/source/depth
equivalence, native overlap, allocator event/drop instrumentation, scoped media
or full resource closure is claimed here. Parent owns those checks and the Audio
consumer tests. Independent scratch review is in progress separately.
