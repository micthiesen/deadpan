from pathlib import Path
s=Path('/tmp/deadpan-owner-capture-budget-2026-10-29/plan/candidate/crates/deadpan-plan/src/audio_owner_query_admission.rs')
t=s.read_text().replace('    fn revision(\n','    pub(in crate::plan) fn revision(\n')
anchor='''    pub(in crate::plan) fn iteration(
'''
extra='''    pub(in crate::plan) fn project(
        &mut self,
        m: &mut Memory<A::Issuer, A::Lease>,
        id: &deadpan_core::ProjectId,
    ) -> Result<deadpan_core::ProjectId, A> {
        self.check_memory(m)?;
        if A::METERED {
            self.additional(1)?;
            self.reserve(m, identity(id.as_str())?)?;
        }
        Ok(id.clone())
    }
    pub(in crate::plan) fn source(
        &mut self,
        m: &mut Memory<A::Issuer, A::Lease>,
        source: &deadpan_core::SourceAudio,
    ) -> Result<deadpan_core::SourceAudio, A> {
        self.check_memory(m)?;
        let deadpan_core::SourceAudio { asset, span } = source;
        if A::METERED {
            self.additional(1)?;
            self.reserve(m, identity(asset.as_str())?)?;
        }
        Ok(deadpan_core::SourceAudio { asset: asset.clone(), span: *span })
    }
    pub(in crate::plan) fn instance_fixed(
        &mut self,
        m: &mut Memory<A::Issuer, A::Lease>,
        value: &InstancePath,
    ) -> Result<InstancePath, A> {
        let mut cap = self.memory();
        let result = self.instance(m, &mut cap, value)?;
        self.check_memory(m)?;
        self.check_memory(&cap)?;
        self.merge_checked(m, &mut cap);
        Ok(result)
    }
    pub(in crate::plan) fn owner<'plan>(
        &mut self,
        m: &mut Memory<A::Issuer, A::Lease>,
        value: &AudioOwnerClock<'plan>,
    ) -> Result<AudioOwnerClock<'plan>, A> {
        self.check_memory(m)?;
        if !A::METERED {
            return Ok(value.clone());
        }
        self.additional(1)?;
        Ok(AudioOwnerClock {
            plan: value.plan,
            definition: self.definition(m, &value.definition)?,
            instance: self.instance_fixed(m, &value.instance)?,
            kind: value.kind,
            gap_after: value.gap_after.as_ref().map(|v|self.iteration(m,v)).transpose()?,
            play: value.play,
            sampling: value.sampling,
            origin: self.origin(m,&value.origin)?,
        })
    }
'''
assert t.count(anchor)==1
s.write_text(t.replace(anchor,extra+anchor))
