from pathlib import Path
import subprocess,json
s=Path(__file__).resolve().parent
rows=[]
def run(command):
 result=subprocess.run(command)
 rows.append({'command':command,'exit_code':result.returncode})
 (s/'final-sequence-progress.json').write_text(json.dumps(rows,indent=2)+'\n')
 if result.returncode:raise SystemExit(result.returncode)
def tool(kind,label,tail):
 run(['python',str(s/('run.py' if kind=='main' else 'run_scoped.py')),label,'--',*tail])
def binary(kind,label,name,tail):
 p=s/name
 run(['python',str(s/('run.py' if kind=='main' else 'run_scoped.py')),'--binary',str(p),label,'--',str(p),*tail])
tool('main','capture-strict2',['cargo','xtask','check','--no-test'])
for kind,build in [('main','capture-final-build')]:
 tool(kind,build,['cargo','test','-p','deadpan-plan','-p','deadpan-audio','--locked','--no-run','--message-format=json'])
 run(['python',str(s/'pin.py'),build])
 run(['python',str(s/'start_plan.py'),build,'capture-'+('final-plan' if kind=='main' else 'scoped-final-plan'),kind])
 binary(kind,'capture-'+('final-audio' if kind=='main' else 'scoped-final-audio'),build+'-audio-deadpan-audio',['--test-threads=4'])
binary('main','capture-definition','capture-final-build-audio-audio-definition',['--test-threads=4'])
binary('scoped','capture-scoped-stages','capture-scoped-final-build-audio-stages',['--test-threads=4'])
binary('scoped','capture-scoped-birth','capture-scoped-final-build-audio-audio-definition',['new_group_birth::','--test-threads=1','--nocapture'])
print('Final scoped sequence terminal and positive.')
