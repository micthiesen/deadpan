# Core-private lattice work provenance witness

Frozen scratch-only append to audio_binding/admission/tests.rs.
No product source, Core API, work scalar, existing test or immutable golden
is changed. No Cargo/rustc or execution claim; scratch rustfmt parsing only.
Before and candidate hashes accompany work-witness.patch. Live test file
still equals the captured baseline.

Test:
audio_binding::admission::tests::lattice_work_is_local_category_delta_after_real_outer_prefix

It uses the existing validated Repeat binding fixture with two actual phase
terms and reanchors. The public legacy resolve_in supplies old complete
binding/lattice work. Actual environment.validate_build and the existing
repeats.len()+1 binding prefix execute before direct real template resolution.
They give positive canonical and additional prefix, independently asserted.

Private Build.used and Build.extra are sampled before/after the ONE real
resolve_with_build call. The returned lattice.work must equal ONLY that local
total delta; local total minus measured local extra must equal the public
false resolver's old lattice.work. This catches interpreting lattice.work as
the outer total or subtracting all outer extra. Its own additional delta is
positive. No lattice clone/reset or test-only production observer is needed.

The Build's final real linear receipt then reconciles full prefix plus local
categories and actual policy work, and refuses a second take. A separate
actual full admitted binding checks binding.work equals its complete receipt,
canonical equals old binding.work, and actual nested lattice delta is positive
and bounded by aggregate extra. All tracked leases end at zero.

## Truthful Plan oracle comparison

Existing root Core receipt classifies resolved.work exactly. Plan can record
that actual child receipt under cfg(test) before account_core consumes it,
using scalar observation only, and assert its total/canonical/additional.

No existing public receipt classifies lattice.work separately: its Build fork
sets receipt=false and outer work includes environment, phase and reanchors.
The Plan golden comparison may whitelist EXACT resolved.work and
resolved.lattice.work JSON locations, preserving every other field unchanged.
Assert root actual==receipt.units and root canonical==frozen root work.
For lattice assert actual>=frozen, actual-frozen<=root additional and
lattice<=root work; label the difference observed nested work delta, NOT an
independently obtained per-lattice category receipt. This Core-private test
supplies independent assignment/category witness for that known field scope.
METERED=false must still match the entire old JSON, including both fields.
Aggregate C canonical/added and controller totals reconcile separately.
Do not blanket-strip work keys, mutate actual fields, subtract all root extra
from lattice, or regenerate old golden work.

This test has not been compiled/executed by this worker. Parent owns pure-test
profile execution and later strict/all-target checks.
