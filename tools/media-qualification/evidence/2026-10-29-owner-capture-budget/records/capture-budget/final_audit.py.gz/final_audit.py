from pathlib import Path
import hashlib,json
s=Path(__file__).resolve().parent
main=Path('/Users/michael/Code/deadpan');scoped=Path('/tmp/deadpan-query-groundwork-2026-10-26/scoped')
receipts=[]
negative={'capture-build1':101,'capture-strict':1,'capture-split':101}
for p in sorted(s.glob('*.json')):
 x=json.loads(p.read_text())
 if not isinstance(x,dict) or 'started_at' not in x or 'command' not in x:continue
 assert x.get('exit_code')==negative.get(p.stem,0),(p.stem,x.get('exit_code'))
 assert x['sources_unchanged'] and x['binaries_unchanged'],p.stem
 receipts.append({'label':p.stem,'exit_code':x['exit_code'],'seconds':x['seconds'],'source_inputs':len(x['source_before']),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()})
for label in ['capture-final-build','capture-scoped-final-build','capture-strict2','capture-scoped-stages','capture-definition','capture-scoped-birth']:
 x=json.loads((s/(label+'.json')).read_text());assert x['exit_code']==0
 for n,h in x['source_after'].items():
  p=Path(n);data=p.read_bytes()
  assert len(data)==h['bytes'] and hashlib.sha256(data).hexdigest()==h['sha256'],(label,n)
rows=json.loads((s/'task-source-pins.json').read_text())
data=(s/'index-blobs.bin').read_bytes();off=0;equal=[]
for row in rows:
 end=data.index(b'\n',off);head=data[off:end].decode().split();assert head[1]=='blob'
 length=int(head[2]);body=data[end+1:end+1+length];off=end+2+length
 assert body==(scoped/row['path']).read_bytes()
 assert hashlib.sha256(body).hexdigest()==row['sha256']
 assert hashlib.sha256((main/row['path']).read_bytes()).hexdigest()==row['main_sha256']
 equal.append({'path':row['path'],'blob':head[0],'sha256':row['sha256'],'scoped_index_equal':True,'main_equal':row['main_equals_scoped']})
assert off==len(data) and len(rows)==20
(s/'index-source-equality.json').write_text(json.dumps(equal,indent=2)+'\n')
base=s/'plan/first-compile/source-authority-before.json'
authority=json.loads(base.read_text());owned={x['path'] for x in rows};unchanged=0
for n,h in authority.items():
 if n in owned:continue
 assert hashlib.sha256((main/n).read_bytes()).hexdigest()==h,n
 unchanged+=1
golden='crates/deadpan-plan/tests/fixtures/owner-capture-baseline-v1/snapshot.json'
for root in [main,scoped]:
 assert hashlib.sha256((root/golden).read_bytes()).hexdigest()=='32661e1a8abf59eb7d8146cd2898fd979415db3763685463df576d5e916d27c0'
# Real-media Split precedes only the private alias extraction. The exact
# executable and source receipt are preserved, not relabelled as final bytes.
old=s/'plan/lint-correction1/before/crates/deadpan-plan/src/audio_capture.rs'
new=s/'plan/lint-correction1/candidate/crates/deadpan-plan/src/audio_capture.rs'
assert (main/'crates/deadpan-plan/src/audio_capture.rs').read_bytes()==new.read_bytes()
for name in ['capture-build2','capture-split','capture-stages']:
 x=json.loads((s/(name+'.json')).read_text())
 assert x['source_after'][str(main/'crates/deadpan-plan/src/audio_capture.rs')]['sha256']==hashlib.sha256(old.read_bytes()).hexdigest()
result={'all_terminal':True,'receipts':receipts,'source_files':20,'scoped_index_source_equality':True,'main_equal_source_files':sum(x['main_equal'] for x in equal),'other_original_authority_inputs_unchanged':unchanged,'old_golden_unchanged':True,'final_compiles_and_final_scoped_media_match_current_sources':True,'split_and_main_stage_binary_precede_only_private_alias_extraction':True,'negative_results_retained':negative}
(s/'final-audit.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'terminal_receipts':len(receipts),'scoped_source_files':20,'other_authority_unchanged':unchanged,'all_terminal':True}))
