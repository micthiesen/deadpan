# Accounting and oracle review

No supported findings.

The selected capture computes its local limit as min(stored query maximum - Q, fresh capture maximum) and records actual capture spend separately from the already-paid query. In metered mode, the shared capture walk forwards its canonical and additional work at their operation sites; the consumed Core receipt is used only to account that work locally. In unmetered mode, additional accounting is disabled and the enclosing Root/Domain caller spends the legacy capture receipt once. The no-selection branch consumes Q without asking for fresh limits or forwarding capture work. The audio consumer checks the trusted mode and borrows the captured Input through its existing probe/final-sharing call.

The false-mode test view retains the complete frozen discarded-span comparison. The metered view validates the real consumed Core receipt, normalizes only the two documented resolved-work scalars, and checks the nested lattice delta against the outer receipt without asserting a separately measured category split. The Core test independently measures lattice-local work after an actual outer prefix. Root/Domain cases compare actual captured seeds, Inputs, and discarded spans with the frozen old capture oracle. The focused source also preserves the existing canonical copy aggregate and adds only explicit additional debits.

Review was static as requested. No tests or repository mutations were performed.
