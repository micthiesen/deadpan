from pathlib import Path
import hashlib
import json
import re

scratch = Path(__file__).resolve().parent
counts = {}
for label, expected in [('audio-lib', 217), ('wet-owners', 10), ('gain-stages', 19),
                        ('audio-definition', 171), ('scoped-audio-lib', 200),
                        ('scoped-birth-pcm', 8)]:
    receipt = json.loads((scratch / (label + '.json')).read_text())
    assert receipt['sources_unchanged'] and receipt['binaries_unchanged']
    assert receipt['exit_code'] == 0
    matches = re.findall(r'test result: .*? (\d+) passed; (\d+) failed; (\d+) ignored;',
                         (scratch / (label + '.stdout')).read_text())
    assert len(matches) == 1 and tuple(map(int, matches[0])) == (expected, 0, 0)
    counts[label] = dict(passed=expected, failed=0, ignored=0, seconds=receipt['seconds'])
for label in ['build', 'scoped-build', 'strict']:
    receipt = json.loads((scratch / (label + '.json')).read_text())
    assert receipt['sources_unchanged'] and receipt['binaries_unchanged']
    assert receipt['exit_code'] == 0
    counts[label] = dict(exit_code=0, seconds=receipt['seconds'])
for name in ['source-frozen.json', 'scoped-frozen.json']:
    for path, pin in json.loads((scratch / name).read_text()).items():
        data = Path(path).read_bytes()
        assert pin == dict(bytes=len(data), sha256=hashlib.sha256(data).hexdigest())
result = dict(counts=counts, all_sources_and_executed_binaries_stable=True,
              runtime_batching=False, production_demand_visitor=False,
              full_stages_and_split_matrix_rerun=False, acceptance_credit=False)
out = scratch / 'regression-summary.json'
assert not out.exists()
out.write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result, indent=2))
