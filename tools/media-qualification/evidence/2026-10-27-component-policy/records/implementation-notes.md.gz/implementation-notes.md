# Components structural decision extraction

SCRATCH-ONLY candidate, 2026-10-27. No repository writes, Cargo, rustc, build, test execution, commit or push. Main owns review, application and verification. This is the smaller independently useful groundwork permitted by the task, not a policy visitor.

## Scope and lineage

before.json pins eight copied inputs: the six Components runtime/test files plus shared_mix.rs and stages.rs for reading. before/ holds their exact baseline bytes; source/ is the scratch candidate. Main checkout bytes were compared to all eight pins after the candidate was written and remain unchanged. after.json includes those eight plus two new candidate files.

The patch changes only:
- shared_components.rs
- shared_components/block.rs
- shared_components/program.rs
- NEW shared_components/policy.rs
- NEW shared_components/policy_tests.rs

Existing outputs.rs, outputs_tests.rs, program/tests.rs, shared_mix.rs and stages.rs remain byte-identical in the scratch tree. The candidate uses no Graph fields, permission-family interner, Original cache API, source-occurrence cache or other inherited WIP interface. It depends only on the published Components output groundwork and existing private Route/Owner metadata. No visibility outside shared_components is broadened.

Exact patch: policy-extraction.patch. Runtime edits are mechanical call-site replacements, with allocation/PCM arithmetic and work/check calls left in place. New policy.rs is98 lines before any subsequent parent edits; tests are a separate focused module.

## Actual extraction

policy.rs owns:
- stable descending-depth owner order, preserving BTreeMap tie order and the exact existing Vec/sort allocation;
- EQ stage classification, reused by both numerical engines and Program checkpoint flushing;
- Route::wet_allowed, including the existing Original-only explicit Tail descendant exclusion;
- one permitted-member iterator over immutable route/owner metadata and an injected active(route_id) boolean lookup;
- permission-mask construction using route voice IDs, not route indices;
- first active clock selection in existing member order;
- the dynamic engine's combined wet permission/first-clock walk.

The runtime still supplies active from Sample.permitted. The helpers themselves never inspect PCM, gain values, Program state, providers or native processors. A caller can supply metadata flags while route.pcm is still empty, which the tests demonstrate. The helpers do not validate a media contract or grant permission independently of their caller.

No numeric stage, owner, sample, route or effect traversal moved. Constant stays owner->stage->sample->route for EQ, and owner->route->sample->effect for wet. Dynamic stays sample->owner->stage->route/effect. Constant retains its separate permission/clock walks at their old numerical boundaries; dynamic wet retains its combined single walk. Do not unify these orders incidentally.

## Work, cancellation, failure and storage

Every existing spend_plan_work and control.check call stays in its original numerical location. Their counts in all three modified production files are unchanged; new policy helpers contain no WorkControl, so they do not add artificial charges or refund old ones. The mechanical walk comparison is:
- permissions: visits all owner members, inserts each admitted route voice once;
- first_clock: visits through the first admitted member and clones that clock once;
- dynamic wet_context: visits all members, inserts each admitted wet voice, clones first wet clock once;
- wet exclusion: scans the same descendant layer suffix, only for Original;
- ordering/classification: same sort and short-circuit predicates.
No new native/gain/finite evaluation occurs. Existing earlier errors can still stop numerical processing at the same boundary. Call-site errors from Permissions::insert propagate unchanged.

There is no new owned policy bit carrier or persistent policy allocation. ordered_owners reuses the old Vec allocation. WetContext moves the old Permissions and optional clock locals into one returned value, with the same one clock clone; no new heap payload or retained state is introduced. Existing mix residency formulas are unchanged. This candidate therefore does not lower limits or need a new storage charge.

A future policy carrier is still owed and must reserve its actual route/flag capacities before allocation, including headers and any metadata needed beyond these borrowed helpers. Do not treat this extraction or test FLAGS as that carrier, and do not run numerical finish with zero/fake PCM to obtain a proof.

## Authored tests and their strength

All await parent compilation/execution. Filter prefix:
  stages::shared_components::policy::tests::

1. structural_decisions_match_both_numerical_callback_orders:
   256 pure-fixture cases across constant/dynamic recipe, gain order, mute, selected-send mode, root/inner skip, inner stop, final target and aliases. The test forms expected callback sequences from external FLAGS before PCM allocation, then populates real finite fixture values and runs the numerical engine with its existing numerical callback boundary. It compares exact instance/definition/kind/gap/origin, affine phase/slope, Repeat escalation, temporal kind/stage, sample, complete mask and selected voice.
   This comparison is a BRIDGE ORACLE sharing policy helpers, not independent proof those helpers implement the right semantics.
   Additional literal facts do not use the helper: four EQ callbacks unless inner skipped; four Delay callbacks unless inner skipped/stopped; no callbacks at inactive sample15; no callback for dormant route voice2. Muting does not reduce those counts.

2. metadata_masks_use_voice_ids_and_choose_the_first_active_clock:
   no PCM allocation; route indices0,1,2 map to distinct voices5,2,7. Literal masks are {5}, {2}, {5,2}, empty. Two checked clocks for the same whole inner Repeat owner have escalation3000 and0 from separate plays. First-active selection chooses3000,0,3000,None for the four samples. Original wins when both are active; the admitted sound clock wins when Original is inactive.

3. metadata_decisions_exclude_original_tail_returns_without_allocating_pcm:
   an explicit Tail descendant blocks root incoming wet for Original but not independent sound. Literal dry mask contains0+1, wet mask contains1 only; Original-only wet selection is empty with no clock. No PCM allocation/provider/native call occurs.

4. member_permissions_keep_the_existing_voice_limit_failure:
   active voice4096 is rejected with the existing shared EQ voice count error before any PCM allocation.

Existing independent dynamic scalar/render-selection and bitwise output/suppression/work/error fixture tests remain untouched. Their verification is necessary alongside these new bridge/literal tests. The new tests do not claim real source admission, retained scope authority, or a recursive resource fit.

## Explicitly remaining contract

No production metadata-only visitor exists in this candidate. No planner or batching path is enabled.

The next work must:
- provide an admitted bounded metadata permission carrier populated from the exact Original/sound/routed policy adapters before PCM allocation;
- share/qualify callback traversal ordering, including inactive event_gain semantics and constant-vs-dynamic execution eligibility, rather than copying the numerical mixer;
- preserve current gain/finite errors as earlier execution exits while an upper-demand visitor assumes success without evaluating them;
- account for skip/stop, sends, output aliases, intrinsic/Tail ineligibility and non-Components SharedMix paths;
- bill actual visitor work, cancellation/deadline checks, scratch storage and metadata reconstruction under existing limits;
- finish the cold temporal/intrinsic resource fold and actual failing-fixture bound before any runtime batch.

The extraction is real groundwork for those decisions only. It is not completion credit for that visitor, the resource proof, runtime batching, or general Split acceptance.
