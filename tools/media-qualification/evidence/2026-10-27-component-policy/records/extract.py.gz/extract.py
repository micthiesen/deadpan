from pathlib import Path
base=Path('/tmp/deadpan-component-policy-2026-10-27/source/crates/deadpan-audio/src')
def edit(name, pairs):
 p=base/name;s=p.read_text()
 for old,new in pairs:
  assert s.count(old)==1,(name,old[:70],s.count(old))
  s=s.replace(old,new,1)
 p.write_text(s)
edit('shared_components.rs', [
('mod block;\n','mod block;\n\n#[path = "shared_components/policy.rs"]\nmod policy;\n'),
('''    fn wet_allowed(&self, layer: usize) -> bool {
        !self.original
            || !self.layers[layer + 1..]
                .iter()
                .any(|(clock, _)| clock.is_explicit_tail_provider())
    }
''',''),
('''        let mut owners: Vec<_> = self.owners.values().collect();
        owners.sort_by_key(|owner| std::cmp::Reverse(owner.depth));''','''        let owners = policy::ordered_owners(&self.owners);'''),
('''                let mut permissions = Permissions::default();
                for &(id, _) in &owner.members {
                    if active(id) {
                        permissions.insert(self.routes[id].voice)?;
                    }
                }''','''                let permissions = policy::permissions(&self.routes, owner, active, false)?;'''),
('''                    let eq = kind == AudioTreatmentStage::Equalizer
                        && recipe
                            .and_then(|r| r.equalizer())
                            .is_some_and(|r| !r.is_unity());''','''                    let eq = policy::is_equalizer(kind, recipe);'''),
('''                            owner.members.iter().find_map(|&(id, layer)| {
                                self.routes[id].pcm[at]
                                    .permitted
                                    .then(|| self.routes[id].layers[layer].0.clone())
                            })''','''                            policy::first_clock(
                                &self.routes,
                                owner,
                                |id| self.routes[id].pcm[at].permitted,
                                false,
                            )'''),
('''                    let mut wet_permissions = Permissions::default();
                    let mut clock = None;
                    for &(id, layer) in &owner.members {
                        let route = &self.routes[id];
                        if route.pcm[at].permitted && route.wet_allowed(layer) {
                            wet_permissions.insert(route.voice)?;
                            clock.get_or_insert_with(|| route.layers[layer].0.clone());
                        }
                    }''','''                    let policy::WetContext {
                        permissions: wet_permissions,
                        clock,
                    } = policy::wet_context(&self.routes, owner, |id| {
                        self.routes[id].pcm[at].permitted
                    })?;''')
])
edit('shared_components/block.rs', [
('''fn permissions(
    routes: &[Route<'_>],
    owner: &Owner<'_>,
    at: usize,
    wet: bool,
) -> Result<Permissions, StageAudioError> {
    let mut permissions = Permissions::default();
    for &(id, layer) in &owner.members {
        let route = &routes[id];
        if route.pcm[at].permitted && (!wet || route.wet_allowed(layer)) {
            permissions.insert(route.voice)?;
        }
    }
    Ok(permissions)
}

''',''),
('''        let mut owners: Vec<_> = self.owners.values().collect();
        owners.sort_by_key(|owner| std::cmp::Reverse(owner.depth));''','''        let owners = policy::ordered_owners(&self.owners);'''),
('''                let eq = kind == AudioTreatmentStage::Equalizer
                    && recipe
                        .and_then(|recipe| recipe.equalizer())
                        .is_some_and(|recipe| !recipe.is_unity());''','''                let eq = policy::is_equalizer(kind, recipe);'''),
('''                    let permissions = permissions(&self.routes, owner, at, false)?;''','''                    let permissions = policy::permissions(
                        &self.routes,
                        owner,
                        |id| self.routes[id].pcm[at].permitted,
                        false,
                    )?;'''),
('''                        owner.members.iter().find_map(|&(id, layer)| {
                            self.routes[id].pcm[at]
                                .permitted
                                .then(|| self.routes[id].layers[layer].0.clone())
                        })''','''                        policy::first_clock(
                            &self.routes,
                            owner,
                            |id| self.routes[id].pcm[at].permitted,
                            false,
                        )'''),
('''                        let wet_permissions = permissions(&self.routes, owner, at, true)?;
                        let clock = owner.members.iter().find_map(|&(member, layer)| {
                            let route = &self.routes[member];
                            (route.pcm[at].permitted && route.wet_allowed(layer))
                                .then(|| route.layers[layer].0.clone())
                        });''','''                        let wet_permissions = policy::permissions(
                            &self.routes,
                            owner,
                            |member| self.routes[member].pcm[at].permitted,
                            true,
                        )?;
                        let clock = policy::first_clock(
                            &self.routes,
                            owner,
                            |member| self.routes[member].pcm[at].permitted,
                            true,
                        );''')
])
edit('shared_components/program.rs', [
('''        || (kind == AudioTreatmentStage::Equalizer
            && recipe
                .equalizer()
                .is_some_and(|equalizer| !equalizer.is_unity()))''','''        || policy::is_equalizer(kind, Some(recipe))''')
])
print('Extracted policy decisions in three scratch production files.')
