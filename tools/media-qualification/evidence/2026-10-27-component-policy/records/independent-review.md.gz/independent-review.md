# Independent review: Components structural policy extraction

Scope: `policy-extraction.patch` changes `shared_components.rs`, `shared_components/block.rs`, `shared_components/program.rs`, and adds `policy.rs` / `policy_tests.rs`. The frozen inputs also include `shared_mix.rs` and `stages.rs` for context. Unrelated worktree WIP was excluded.

## Findings

No supported correctness findings. The production edits preserve descending-depth owner ordering and stable tie behavior, the Saturation/non-unity-EQ classification used by both numerical traversal and Program checkpoint flushing, and the Original-only explicit-Tail descendant exclusion. Permission masks still insert route voice IDs for active owner members. `first_clock` retains member order and clones the first active eligible layer clock. Dynamic wet-context construction remains one combined pass; constant traversal retains separate permission and clock walks at the prior numerical locations. Numerical traversal loops, callback sites, existing `control.check` / `spend_plan_work` calls, PCM arithmetic, and error propagation remain at their prior call sites.

## Verification limits and test strength

- I did not run Cargo or edit source; the main session owns application and verification.
- The callback comparison test is explicitly a bridge oracle: expected calls use the extracted helpers and external literal activity flags, then compare against the numerical engine. It does not independently establish helper semantics. Separate assertions cover literal callback counts, inactive sample suppression, dormant voice exclusion, voice-ID masks, first-active clock choice, and Original Tail exclusion.
- This extraction adds no metadata visitor/carrier, no persistent policy state, and no batching/resource proof. Existing output groundwork and scalar comparison tests remain the relevant independent numerical regression coverage.
