from pathlib import Path
import json
import subprocess
import sys
import time

scratch = Path(__file__).resolve().parent

def terminal(label):
    deadline = time.monotonic() + 1200
    while True:
        try:
            receipt = json.loads((scratch / (label + '.json')).read_text())
        except (FileNotFoundError, json.JSONDecodeError):
            receipt = {}
        if 'exit_code' in receipt:
            assert receipt['sources_unchanged'] and receipt['binaries_unchanged']
            return receipt
        if time.monotonic() > deadline:
            raise SystemExit('Receipt did not become terminal: ' + label)
        time.sleep(1)

terminal('wet-owners')
commands = [
    [sys.executable, str(scratch / 'run.py'), '--binary', str(scratch / 'stages'),
     'gain-stages', '--', str(scratch / 'stages'), 'gain::', '--nocapture', '--test-threads=1'],
    [sys.executable, str(scratch / 'run.py'), '--binary', str(scratch / 'audio-definition'),
     'audio-definition', '--', str(scratch / 'audio-definition'), '--nocapture', '--test-threads=1'],
    [sys.executable, str(scratch / 'run_scoped.py'), '--binary',
     str(scratch / 'scoped-audio-definition'), 'scoped-birth-pcm', '--',
     str(scratch / 'scoped-audio-definition'), 'new_group_birth::', '--nocapture', '--test-threads=1'],
]
results = []
for index, command in enumerate(commands):
    if index == 2:
        terminal('scoped-build')
        assert (scratch / 'scoped-pins.json').exists()
    code = subprocess.run(command, check=False).returncode
    results.append(dict(command=command, exit_code=code))
(scratch / 'continuation-results.json').write_text(json.dumps(results, indent=2) + '\n')
raise SystemExit(any(row['exit_code'] != 0 for row in results))
