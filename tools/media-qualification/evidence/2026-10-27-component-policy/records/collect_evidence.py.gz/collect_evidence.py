from pathlib import Path
import gzip
import hashlib
import json

scratch = Path(__file__).resolve().parent
dest = Path('/Users/michael/Code/deadpan/tools/media-qualification/evidence/2026-10-27-component-policy')
assert not dest.exists(), 'refuse evidence overwrite'
summary = json.loads((scratch / 'regression-summary.json').read_text())
assert summary['all_sources_and_executed_binaries_stable']
for label in ['build', 'audio-lib', 'strict', 'wet-owners', 'gain-stages',
              'audio-definition', 'scoped-build', 'scoped-audio-lib', 'scoped-birth-pcm']:
    receipt = json.loads((scratch / (label + '.json')).read_text())
    assert receipt['exit_code'] == 0 and receipt['sources_unchanged'] and receipt['binaries_unchanged']
paths = [path for path in scratch.iterdir() if path.is_file() and path.suffix in
         {'.json', '.py', '.md', '.patch', '.rs', '.before', '.stdout', '.stderr', '.txt'}]
for relative in ['crates/deadpan-audio/src/shared_components.rs',
                 'crates/deadpan-audio/src/shared_components/block.rs',
                 'crates/deadpan-audio/src/shared_components/program.rs']:
    paths.append(scratch / 'before' / relative)
dest.mkdir(parents=True)
files = []
for path in sorted(paths):
    data = path.read_bytes()
    compressed = gzip.compress(data, mtime=0)
    out = dest / 'records' / (str(path.relative_to(scratch)) + '.gz')
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_bytes(compressed)
    files.append(dict(path=str(out.relative_to(dest)), bytes=len(compressed),
                      sha256=hashlib.sha256(compressed).hexdigest(), expanded_bytes=len(data),
                      expanded_sha256=hashlib.sha256(data).hexdigest()))
inventory = dict(schema_version=1, base_revision='053d31c2',
    scope='Five-file Components structural helper extraction shared by constant/dynamic numerical engines. Four new tests include 256 metadata/callback bridge cases and literal mask/clock/Tail/limit expectations. No production visitor, new policy storage, cold resource proof or batching. Main/isolated library, full definition, real-WAV wet/gain and isolated birth PCM pass; strict lint/review pass. Full stages/Split matrix not rerun and no product acceptance credit.',
    runtime_baseline_evidence=dict(path='../2026-10-27-wet-residency/inventory.json',
        inventory_sha256='e2430bc97098086250c7318f949ba37da408d70dba452b6f4f79e00d350fd216',
        note='Main retains inherited general-Split/index WIP; isolated lineage overlays only identical task files. Only changed-file before snapshots archived; no copied workspace or executable bytes.'), files=files)
out = dest / 'inventory.json'
out.write_text(json.dumps(inventory, indent=2) + '\n')
for row in files:
    data = (dest / row['path']).read_bytes()
    expanded = gzip.decompress(data)
    assert len(data) == row['bytes'] and hashlib.sha256(data).hexdigest() == row['sha256']
    assert len(expanded) == row['expanded_bytes'] and hashlib.sha256(expanded).hexdigest() == row['expanded_sha256']
print(json.dumps(dict(payloads=len(files), stored_bytes=sum(row['bytes'] for row in files),
                      expanded_bytes=sum(row['expanded_bytes'] for row in files),
                      inventory_sha256=hashlib.sha256(out.read_bytes()).hexdigest()), indent=2))
