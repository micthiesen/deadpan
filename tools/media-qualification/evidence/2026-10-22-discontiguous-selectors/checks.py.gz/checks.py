from pathlib import Path
import subprocess, os, json, time, hashlib, shutil
s=Path('/tmp/deadpan-discontiguous-selectors-2026-10-22')
env=dict(os.environ, DEADPAN_FFMPEG_PREFIX='/Users/michael/Library/Developer/Deadpan/ffmpeg-8.0.3-opus-1.6.1-dav1d-1.5.4-qualified-3/prefix', CARGO_PROFILE_DEV_OPT_LEVEL='2', DEADPAN_REQUIRE_PHYSICAL_MAC='1', DEADPAN_REQUIRE_SYNTHETIC_WORKER='1')
def guard(): subprocess.run(['python',str(s/'guard.py'),'broad-fourth'],env=env,check=True)
def run(name,args):
 start=time.monotonic()
 with(s/(name+'.log')).open('w') as log:r=subprocess.run(args,env=env,stdout=log,stderr=subprocess.STDOUT)
 row={'name':name,'command':args,'exit':r.returncode,'seconds':time.monotonic()-start}
 (s/(name+'-receipt.json')).write_text(json.dumps(row,indent=2)+'\n')
 print(json.dumps(row),flush=True)
 if r.returncode:raise SystemExit(r.returncode)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
assert json.loads((s/'broad-fourth-result.json').read_text())['exit']==0
guard()
archive=s/'ui-final.tar.zst';target=s/'ui-final-extracted';target.mkdir(exist_ok=True)
run('ui-final-build',['cargo','nextest','archive','--locked','-p','deadpan-app','--features','ui-harness','--bin','deadpan-app','--archive-file',str(archive),'--zstd-level=-1'])
with(s/'ui-final-extract.log').open('w')as log:
 subprocess.run(['cargo','nextest','list','--archive-file',str(archive),'--extract-to',str(target),'--extract-overwrite','--workspace-remap',str(Path.cwd())],env=env,stdout=log,stderr=subprocess.STDOUT,check=True)
helpers={}
for name in ['deadpan-app','deadpan-cli','deadpan-media-worker','deadpan-transcribe','deadpan-track']:
 source=Path('target/debug')/name;matches=list(target.rglob(name))
 if not matches:
  t=target/'target/debug'/name;t.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(source,t);matches=[t]
 assert len(matches)==1 and sha(matches[0])==sha(source),(name,matches)
 helpers[name]={'source':str(source),'path':str(matches[0]),'sha256':sha(source)}
(s/'ui-final-helpers.json').write_text(json.dumps(helpers,indent=2)+'\n')
guard()
run('ui-final-driver',['python',str(s/'run_archive.py'),'ui-final'])
guard()
for r in helpers.values():assert sha(Path(r['path']))==r['sha256']
commands=[
 ('strict-check',['cargo','xtask','check','--since','f4f7481ed804f8a5c25b39b76b7ecc8bc1529cc4','--no-test']),
 ('strict-ui-clippy',['cargo','clippy','--locked','-p','deadpan-app','--features','ui-harness','--all-targets','--','-D','warnings']),
 ('strict-format',['cargo','fmt','--all','--','--check'])]
for name,args in commands:
 run(name,args);guard()
