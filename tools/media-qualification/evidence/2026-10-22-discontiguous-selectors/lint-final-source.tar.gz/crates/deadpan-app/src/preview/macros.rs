//! Native semantic recording. Only completed commands enter a recorded body.

use std::num::NonZeroU32;

use deadpan_core::{RegisterName, SemanticContext, SemanticInstruction, SemanticProgram};

use super::*;
use crate::project::{macros as protocol, slice};

const PENDING_FRAMING: &str =
    "Wait for the pending framing action to finish, or press Esc to cancel it.";
const DURATION_RECORDING: &str = "This duration-only macro records pause lengths and named duration calls. Save or cancel recording before another action.";

fn duration_recording_action(action: &Action, can_open_length: bool) -> bool {
    matches!(
        action,
        Action::Edit(BeatEdit::HoldDuration(_))
            | Action::RepeatLast
            | Action::MacroExecute { .. }
            | Action::MacroStop
            | Action::MacroCancel
            | Action::Command
            | Action::Escape
            | Action::Invalid(_)
            | Action::OfferInsert
    ) || matches!(action, Action::EnterGroup) && can_open_length
}

fn duration_recording_draft(command: &navigation::command::Entry) -> bool {
    use navigation::command::Entry;
    matches!(
        command,
        Entry::RoomTone
            | Entry::HoldSilence
            | Entry::Gain(None)
            | Entry::EqualizerEdit
            | Entry::GainRange { .. }
    )
}

#[derive(Clone)]
pub(super) struct Capture {
    base: Arc<Workspace>,
    scope: SequenceScope,
    context: SemanticContext,
    bank_version: u64,
    pane: Pane,
    view: View,
    role: deadpan_core::MediaRole,
    sound_focused: bool,
    event_focused: bool,
    original_selection: Option<moment::Selection>,
    scoped: Option<crate::project::scoped::Target>,
}

impl Capture {
    fn has_scoped_continuation(&self) -> bool {
        self.context.scoped.is_some() || self.has_duration_authority()
    }

    fn has_duration_authority(&self) -> bool {
        self.context.hold_duration.is_some()
            || self.context.shared_hold_duration.is_some()
            || self.context.mixed_hold_duration.is_some()
            || self.context.selected_hold_duration.is_some()
    }

    /// Duration-only capture owns a continuation, but cannot authorize Zoom.
    pub(super) fn has_scoped_framing_authority(&self) -> bool {
        self.context.scoped.is_some()
    }

    pub(super) fn captures_scope(&self, target: &crate::project::scoped::Target) -> bool {
        self.has_scoped_continuation() && self.scoped.as_ref() == Some(target)
    }

    /// The selected direct child as it was when the command was entered.
    pub(super) fn selected_node(&self) -> Option<&deadpan_core::BeatNode> {
        self.context
            .selected_child
            .as_ref()
            .and_then(|node| self.base.document.nodes().get(node))
    }
    pub(super) fn frame_rate(&self) -> deadpan_core::FrameRate {
        self.base.document.presentation_basis().frame_rate
    }
    pub(super) fn check_pause(&self) -> Result<(), String> {
        if let Some(scoped) = &self.context.scoped {
            self.base
                .document
                .pause_insertion_scoped(self.context.cursor, &scoped.target, &scoped.presentation)
                .map(|_| ())
                .map_err(|error| error.to_string())
        } else {
            self.scope.check_pause(&self.base, self.context.cursor)
        }
    }
    fn check_fixed_duration(&self) -> Result<(), String> {
        if let Some(scoped) = &self.context.scoped
            && let Some(visible) = crate::project::scoped::fixed_duration_visibility(
                &self.base.document,
                &self.context.parent,
                scoped,
            )?
        {
            crate::project::scoped::verify_duration_pictures(
                &self.base.plan,
                &scoped.presentation,
                visible,
            )?;
        }
        Ok(())
    }
    fn object_selected(&self) -> bool {
        matches!(
            self.context.visual_selection,
            Some(
                deadpan_core::SemanticVisualSelection::Object { .. }
                    | deadpan_core::SemanticVisualSelection::MarkRange { .. }
                    | deadpan_core::SemanticVisualSelection::Node { .. }
                    | deadpan_core::SemanticVisualSelection::Nodes { .. }
            )
        )
    }
    pub(super) fn select_object(
        &self,
        object: deadpan_core::SemanticTextObject,
    ) -> Result<SemanticContext, String> {
        self.base
            .document
            .select_semantic_object(&self.context, object)
            .map_err(|error| error.to_string())
    }
    pub(super) fn select_mark_range(
        &self,
        start: deadpan_core::NamedMarkTarget,
        end: deadpan_core::NamedMarkTarget,
    ) -> Result<SemanticContext, String> {
        self.base
            .document
            .select_semantic_mark_range(&self.context, start, end)
            .map_err(|error| error.to_string())
    }
    pub(super) fn select_node(&self, node: NodeId) -> Result<SemanticContext, String> {
        self.base
            .document
            .select_semantic_node(&self.context, node)
            .map_err(|error| error.to_string())
    }
    pub(super) fn select_nodes(&self, nodes: Vec<NodeId>) -> Result<SemanticContext, String> {
        self.base
            .document
            .select_semantic_nodes(&self.context, nodes)
            .map_err(|error| error.to_string())
    }
    /// A word or sentence object at the captured cursor, as a Visual range.
    pub(super) fn select_speech(
        &self,
        speech: &deadpan_core::SpeechTimeline,
        bounds: (deadpan_core::ProjectFrame, deadpan_core::ProjectFrame),
        object: deadpan_core::SpeechObject,
    ) -> Result<SemanticContext, String> {
        speech
            .select_object(
                &self.context,
                bounds,
                object,
                self.base.document.presentation_basis().frame_rate,
            )
            .map_err(|error| error.message)
    }
    pub(super) fn group_instruction(
        &self,
        label: Option<String>,
    ) -> Result<SemanticInstruction, String> {
        if self.scope.resolve(&self.base)?.owner != &self.context.parent {
            return Err(
                "The captured Group target differs from its ordinary Sequence scope.".into(),
            );
        }
        groups::instruction(&self.base.document, &self.context, label)
    }

    /// `:explode` (true) or `:duplicate` (false) at the captured target.
    pub(super) fn structure_instruction(
        &self,
        explode: bool,
    ) -> Result<SemanticInstruction, String> {
        if self.scope.resolve(&self.base)?.owner != &self.context.parent {
            return Err("The captured target differs from its ordinary Sequence scope.".into());
        }
        groups::structure_instruction(&self.base.document, &self.context, explode)
    }

    pub(super) fn repeat_count_instruction(
        &self,
        plays: NonZeroU32,
    ) -> Result<SemanticInstruction, String> {
        if self.scope.resolve(&self.base)?.owner != &self.context.parent {
            return Err(
                "The captured Repeat target differs from its ordinary Sequence scope.".into(),
            );
        }
        repeats::repeat_count_instruction(&self.base.document, &self.context, plays)
    }

    pub(super) fn repeat_selector(&self) -> deadpan_core::SemanticSelector {
        if let Some(selection) = &self.context.visual_selection {
            selection.effective_selector()
        } else {
            deadpan_core::SemanticSelector::SelectedBeat
        }
    }

    pub(super) fn repeat_target(&self) -> Result<repeat_queue::Target, String> {
        if self.context.visual_selection.is_some() {
            return Err("Clear the Visual range before changing an existing Repeat count.".into());
        }
        Ok(repeat_queue::Target {
            session: self.base.session,
            revision: self.base.document.revision_id().clone(),
            scope: self.scope.clone(),
            node: self
                .context
                .selected_child
                .clone()
                .ok_or("Select a beat before repeating it.")?,
            cursor: self.context.cursor,
            pane: self.pane,
        })
    }

    pub(super) fn matches(&self, app: &DeadpanApp) -> bool {
        self.matches_without_selection(app) && app.selected_beat == self.context.selected_child
    }

    fn matches_without_selection(&self, app: &DeadpanApp) -> bool {
        app.copied.bank_version() == Some(self.bank_version)
            && self.matches_without_bank_or_selection(app)
    }

    fn matches_without_bank_or_selection(&self, app: &DeadpanApp) -> bool {
        self.matches_editor_state(app, false)
    }

    fn matches_editor_state(&self, app: &DeadpanApp, splice: bool) -> bool {
        app.workspace.as_ref().is_some_and(|workspace| {
            workspace.session == self.base.session
                && workspace.document.project_id() == self.base.document.project_id()
                && workspace.document.revision_id() == self.base.document.revision_id()
        }) && app.sequence_scope == self.scope
            && i64::try_from(app.sequence_cursor).ok() == Some(self.context.cursor.0)
            && app.pane == if splice { Pane::Viewer } else { self.pane }
            && app.view == self.view
            && app.edit_role == self.role
            && app.capture_visual_selection().as_ref() == Ok(&self.context.visual_selection)
            && app.sound_focused() == self.sound_focused
            && app.event_focused() == self.event_focused
            && app.scoped_target().as_ref() == Ok(&self.scoped)
            && self.context.original.as_ref().is_none_or(|original| {
                app.source_cursor == original.ordinal.0
                    && app.selected_source.as_ref() == Some(&original.asset)
                    && app.raw_source.is_none()
                    && self.original_selection.as_ref() == Some(&app.moment)
                    && app.workspace.as_ref().is_some_and(|workspace| {
                        workspace
                            .sources
                            .get(&original.asset)
                            .is_some_and(|source| source.receipt.id() == &original.qualification)
                    })
            })
            && if splice {
                app.splice.is_some()
                    && app.scoped.is_none()
                    && !app.close_pending
                    && !app.dialogs.is_open()
                    && !app.render.blocking()
                    && !app.help_open
                    && app.camera.is_none()
                    && app.trim.is_none()
                    && app.slip.is_none()
                    && app.gain.is_none()
                    && app.room_tone.is_none()
            } else {
                app.frame_delete_blocked().is_none()
            }
    }

    pub(super) fn matches_splice_entry(&self, app: &DeadpanApp) -> bool {
        app.copied.bank_version() == Some(self.bank_version)
            && app.selected_beat == self.context.selected_child
            && self.matches_editor_state(app, true)
            && app.macros.recording.as_ref().is_some_and(|recording| {
                let expected = &recording.expected;
                expected.id(0) == self.id(0)
                    && expected.scope == self.scope
                    && expected.context == self.context
                    && expected.pane == self.pane
                    && expected.view == self.view
                    && expected.sound_focused == self.sound_focused
                    && expected.event_focused == self.event_focused
                    && expected.original_selection == self.original_selection
                    && expected.scoped == self.scoped
            })
    }

    pub(super) fn splice_instruction(
        &self,
        proposal: &crate::project::splice::Proposal,
        initial_source: &crate::project::splice::Source,
        register: Option<char>,
    ) -> Result<SemanticInstruction, String> {
        if matches!(
            self.context.visual_selection,
            Some(deadpan_core::SemanticVisualSelection::Node { .. })
        ) {
            return Err("Use p/P to replace the complete selected node; Place slice does not expose node destinations.".into());
        }
        if self.context.original.is_some() || self.view != View::Sequence {
            return Err("Place slice can be recorded only in Your edit.".into());
        }
        if proposal.id.session != self.base.session
            || &proposal.id.project != self.base.document.project_id()
            || &proposal.id.base_revision != self.base.document.revision_id()
            || proposal.scope != self.scope
            || proposal.parent != self.context.parent
        {
            return Err(
                "The captured Place slice context changed. Cancel and open it again.".into(),
            );
        }
        let owner = self.scope.resolve(&self.base)?;
        if owner.owner != &self.context.parent {
            return Err(
                "The captured Place slice parent changed. Cancel and open it again.".into(),
            );
        }
        let captured_range = match &self.context.visual_selection {
            Some(deadpan_core::SemanticVisualSelection::Time { anchor, head, .. }) => Some(
                deadpan_core::FrameRange::new((*anchor).min(*head), (*anchor).max(*head))
                    .map_err(|error| error.to_string())?,
            ),
            Some(deadpan_core::SemanticVisualSelection::Object { selection, .. }) => Some(
                self.base
                    .document
                    .resolve_object_selection(&self.context.parent, selection)
                    .map_err(|error| error.to_string())?
                    .range,
            ),
            Some(deadpan_core::SemanticVisualSelection::Node { node }) => Some(
                self.base
                    .document
                    .resolve_semantic_node(&self.context, node)
                    .map_err(|error| error.to_string())?
                    .range,
            ),
            Some(deadpan_core::SemanticVisualSelection::MarkRange { start, end }) => Some(
                self.base
                    .document
                    .resolve_semantic_mark_range(&self.context, start, end)
                    .map_err(|error| error.to_string())?,
            ),
            Some(deadpan_core::SemanticVisualSelection::Nodes { .. }) => {
                return Err("Clear the node set before choosing a Place slice destination.".into());
            }
            None => None,
        };
        splice_instruction(
            &self.context,
            owner.children,
            proposal,
            initial_source,
            register_name(register)?,
            captured_range,
        )
    }

    fn id(&self, request: u64) -> protocol::Id {
        protocol::Id {
            session: self.base.session,
            project: self.base.document.project_id().clone(),
            revision: self.base.document.revision_id().clone(),
            bank_version: self.bank_version,
            request,
        }
    }
}

struct Recording {
    name: char,
    expected: Capture,
    instructions: Vec<SemanticInstruction>,
    cut: Option<(slice::CopyId, SemanticInstruction)>,
}

struct Pending {
    operation: protocol::Operation,
    capture: Capture,
    /// Recorded into the active macro on success.
    instruction: Option<SemanticInstruction>,
    /// The footer message on success.
    summary: Option<String>,
    owns_cursor: bool,
}

#[derive(Default)]
pub(super) struct State {
    recording: Option<Recording>,
    pending: Option<Pending>,
    command_recording: bool,
}

impl State {
    pub fn recording(&self) -> bool {
        self.recording.is_some()
    }

    pub fn recording_original(&self) -> bool {
        self.recording
            .as_ref()
            .is_some_and(|recording| recording.expected.context.original.is_some())
    }

    /// Navigation may abandon a queued scoped receipt without retargeting its
    /// authored edit. Recording and new project writes still wait for it.
    fn permits_scoped_navigation(&self) -> bool {
        !self.recording()
            && self
                .pending
                .as_ref()
                .is_some_and(|pending| pending.capture.has_scoped_continuation())
    }

    /// Replace the pending action's success message.
    pub fn set_summary(&mut self, summary: String) {
        if let Some(pending) = &mut self.pending {
            pending.summary = Some(summary);
        }
    }

    pub fn is_pending(&self) -> bool {
        self.pending.is_some()
            || self
                .recording
                .as_ref()
                .is_some_and(|recording| recording.cut.is_some())
    }

    /// Navigation permanently releases a queued edit's continuation, even if
    /// the user returns to the same address before its receipt arrives.
    pub fn revoke_cursor(&mut self) {
        if let Some(pending) = &mut self.pending {
            pending.owns_cursor = false;
        }
    }

    #[cfg(feature = "ui-harness")]
    pub fn pending_identity(&self) -> Option<protocol::Id> {
        self.pending
            .as_ref()
            .map(|pending| pending.operation.id().clone())
    }

    pub fn recording_name(&self) -> Option<char> {
        self.recording.as_ref().map(|recording| recording.name)
    }

    pub fn capture_command(&mut self) {
        self.command_recording = self.recording();
    }

    pub fn session_changed(&mut self) {
        // Command text can outlive an asynchronous project switch. Retain its
        // recording ownership so submission refuses instead of targeting it anew.
        self.recording = None;
        self.pending = None;
    }

    pub fn instruction_count(&self) -> usize {
        self.recording
            .as_ref()
            .map_or(0, |recording| recording.instructions.len())
    }

    pub fn label(&self) -> Option<String> {
        self.recording_name().map(|name| {
            format!(
                "RECORDING @{name} · {} instructions",
                self.instruction_count()
            )
        })
    }
}

impl DeadpanApp {
    pub(super) fn refuse_duration_recording_draft(&mut self) -> bool {
        if self
            .macros
            .recording
            .as_ref()
            .is_some_and(|recording| recording.expected.has_duration_authority())
        {
            self.error = Some(DURATION_RECORDING.into());
            true
        } else {
            false
        }
    }

    pub(super) fn capture_macro_target(&self) -> Result<Capture, String> {
        let mut captured = self.capture_edit_target(self.view != View::Source)?;
        if self.view == View::Source {
            if self.sound_focused() || self.event_focused() || self.pane == Pane::Sounds {
                return Err("Focus Original before recording its marks and motions.".into());
            }
            if self.moment.active {
                return Err(
                    "Finish the Original Visual selection before recording marks and motions."
                        .into(),
                );
            }
            captured.context.original =
                Some(self.capture_mark()?.original_context().ok_or(
                    "Choose a registered Original before recording its marks and motions.",
                )?);
            captured.original_selection = Some(self.moment.clone());
        }
        Ok(captured)
    }

    pub(super) fn capture_original_insert_target(&self) -> Result<Capture, String> {
        if self.scoped.is_some() {
            return Err("Return to the parent before reusing the Original.".into());
        }
        self.capture_edit_target(false)
    }

    fn capture_edit_target(&self, require_edit_focus: bool) -> Result<Capture, String> {
        if let Some(error) = self.frame_delete_blocked() {
            return Err(error.into());
        }
        if require_edit_focus
            && (self.view != View::Sequence
                || matches!(self.pane, Pane::Sources | Pane::Sounds)
                || self.sound_focused()
                || self.event_focused())
        {
            return Err("Focus Your edit before using this action.".into());
        }
        let base = self
            .workspace
            .clone()
            .ok_or("Open a project before using this action.")?;
        let scope = self.sequence_scope.clone();
        let owner = scope.resolve(&base)?;
        if !(owner.start..=owner.end).contains(&self.sequence_cursor) {
            return Err("The Edit cursor is outside this group.".into());
        }
        let context = SemanticContext {
            parent: owner.owner.clone(),
            cursor: ProjectFrame(
                i64::try_from(self.sequence_cursor).map_err(|error| error.to_string())?,
            ),
            selected_child: self.selected_beat.clone(),
            visual_selection: self.capture_visual_selection()?,
            original: None,
            scoped: None,
            hold_duration: None,
            shared_hold_duration: None,
            mixed_hold_duration: None,
            selected_hold_duration: None,
        };
        let scoped = self.scoped_target()?;
        let mut context = context;
        if let Some(target) = &scoped {
            if context.visual_selection.is_some() || self.view != View::Sequence {
                return Err(
                    "Clear the Visual selection and focus Your edit before using nested edit macros."
                        .into(),
                );
            }
            if !target.also.is_empty()
                && matches!(
                    base.document
                        .nodes()
                        .get(&target.target.node)
                        .map(|node| &node.kind),
                    Some(deadpan_core::NodeKind::Hold { .. })
                )
            {
                context.selected_hold_duration =
                    Some(Box::new(target.semantic_selected_hold_duration(&base)?));
            } else if target.target.repeats.is_empty() {
                context.hold_duration = Some(target.semantic_hold_duration(&base)?);
            } else if target
                .target
                .repeats
                .iter()
                .all(|step| step.branch == deadpan_core::RepeatEditBranch::Default)
                && matches!(
                    base.document
                        .nodes()
                        .get(&target.target.node)
                        .map(|node| &node.kind),
                    Some(deadpan_core::NodeKind::Hold { .. })
                )
            {
                context.shared_hold_duration = Some(target.semantic_shared_hold_duration(&base)?);
            } else if target
                .target
                .repeats
                .iter()
                .any(|step| step.branch == deadpan_core::RepeatEditBranch::Default)
                && matches!(
                    base.document
                        .nodes()
                        .get(&target.target.node)
                        .map(|node| &node.kind),
                    Some(deadpan_core::NodeKind::Hold { .. })
                )
            {
                context.mixed_hold_duration =
                    Some(Box::new(target.semantic_mixed_hold_duration(&base)?));
            } else {
                context.scoped = Some(target.semantic_framing(&base)?);
            }
        }
        Ok(Capture {
            base,
            scope,
            context,
            bank_version: self
                .copied
                .bank_version()
                .ok_or("The project registers are still loading.")?,
            pane: self.pane,
            view: self.view,
            role: self.edit_role,
            sound_focused: self.sound_focused(),
            event_focused: self.event_focused(),
            original_selection: None,
            scoped,
        })
    }

    pub(super) fn reconcile_macro_recording(&mut self) {
        let moved = self
            .macros
            .pending
            .as_ref()
            .is_some_and(|pending| !pending.capture.matches(self));
        if moved && let Some(pending) = &mut self.macros.pending {
            pending.owns_cursor = false;
        }
        // An open Trim, Slip, Place slice or room-tone draft owns the editor context and restores its entry
        // context when it closes; check the recording after that.
        if self.trim.is_none()
            && self.slip.is_none()
            && self.room_tone.is_none()
            && self.splice.is_none()
            && self
                .macros
                .recording
                .as_ref()
                .is_some_and(|recording| !recording.expected.matches(self))
        {
            self.macros.recording = None;
            self.bindings.set_macro_recording(false);
            self.message = Some("Macro recording cancelled because its project, registers or editing context changed. The previous macro is unchanged.".into());
        }
    }

    pub(super) fn cancel_macro_recording(&mut self) {
        if self
            .macros
            .pending
            .as_ref()
            .is_some_and(|pending| matches!(pending.operation, protocol::Operation::Save { .. }))
        {
            self.error = Some("The macro save is already queued. Wait for its result.".into());
            return;
        }
        if self.macros.recording.is_some() && self.camera_pending.is_some() {
            self.cancel_camera();
            if self.error.as_deref() == Some(PENDING_FRAMING) {
                self.error = None;
            }
        }
        if self.macros.recording.take().is_some() {
            self.message = Some("Macro recording cancelled. The previous macro is unchanged; completed edits remain undoable.".into());
        }
        self.bindings.set_macro_recording(false);
    }

    pub(super) fn macro_action_allowed(&mut self, action: Action) -> bool {
        self.reconcile_macro_recording();
        if self.edit_range.nodes().is_some()
            && matches!(action,
                Action::Edit(edit) if edit != BeatEdit::Delete
            )
        {
            self.error = Some(
                "This edit needs one beat or contiguous range. Clear the node set first.".into(),
            );
            return false;
        }
        if self.edit_range.nodes().is_some()
            && matches!(
                action,
                Action::Group
                    | Action::Ungroup
                    | Action::Explode
                    | Action::Duplicate
                    | Action::Repeat { .. }
                    | Action::EscalatingRepeat
                    | Action::RoleRepeat { .. }
                    | Action::GainStep(_)
                    | Action::Mute
                    | Action::Framing(_)
                    | Action::SaveFraming(_)
                    | Action::Gag(_)
                    | Action::Reverse { .. }
                    | Action::SplitEdit { .. }
                    | Action::Tail { .. }
                    | Action::Lift
                    | Action::Bleep { .. }
                    | Action::Trim
                    | Action::TailPicker
            )
        {
            self.error =
                Some("This operation does not support a node set. Clear the set first.".into());
            return false;
        }
        if self.macros.recording()
            && self.camera_pending.is_some()
            && !matches!(
                action,
                Action::Invalid(_) | Action::OfferInsert | Action::MacroCancel | Action::Escape
            )
        {
            self.error = Some(PENDING_FRAMING.into());
            return false;
        }
        if self.macros.permits_scoped_navigation()
            && matches!(
                action,
                Action::Command
                    | Action::Pane { .. }
                    | Action::Search
                    | Action::SearchStep { .. }
                    | Action::Word { .. }
                    | Action::Sentence { .. }
                    | Action::Pause { .. }
                    | Action::Shot { .. }
                    | Action::SelectSpeech(_)
                    | Action::Sound(crate::navigation::SoundAction::Focus)
                    | Action::Help
            )
        {
            return true;
        }
        if self.macros.is_pending()
            && !matches!(
                action,
                Action::Invalid(_) | Action::OfferInsert | Action::MacroCancel | Action::Escape
            )
        {
            self.error = Some("Wait for the pending macro action to finish.".into());
            return false;
        }
        if !self.macros.recording() {
            return true;
        }
        if self
            .macros
            .recording
            .as_ref()
            .is_some_and(|recording| recording.expected.has_duration_authority())
        {
            if duration_recording_action(&action, self.scoped_hold_parameter().is_some()) {
                return true;
            }
            self.error = Some(DURATION_RECORDING.into());
            return false;
        }
        if self.scoped.is_some()
            && !matches!(
                action,
                Action::Framing(
                    crate::navigation::FramingAction::PunchIn
                        | crate::navigation::FramingAction::Creep
                ) | Action::Edit(
                    BeatEdit::InsertHold(_) | BeatEdit::InsertBlack(_) | BeatEdit::HoldDuration(_)
                ) | Action::GainStep(_)
                    | Action::Mute
                    | Action::RepeatLast
                    | Action::MacroExecute { .. }
                    | Action::MacroStop
                    | Action::MacroCancel
                    | Action::Command
                    | Action::Escape
                    | Action::Invalid(_)
                    | Action::OfferInsert
            )
        {
            self.error = Some("A one-play macro records whole-beat gain, mute, saturation, balance and EQ, freeze and black pauses, pause lengths, silence and room tone, zooms, creeps and named calls. Save or cancel recording before another action.".into());
            return false;
        }
        if self.macros.recording_original()
            && !matches!(
                action,
                Action::Step { .. }
                    | Action::First
                    | Action::Last
                    | Action::SetMark(_)
                    | Action::JumpMark(_)
                    | Action::MacroExecute { .. }
                    | Action::MacroStop
                    | Action::MacroCancel
                    | Action::Command
                    | Action::Escape
                    | Action::Invalid(_)
                    | Action::OfferInsert
            )
        {
            self.error = Some("An Original macro records frame and boundary motions, marks, jumps and named calls. Save or cancel recording before another action.".into());
            return false;
        }
        if !matches!(
            action,
            Action::Step { .. }
                | Action::Insert
                | Action::Beat { .. }
                | Action::Word { .. }
                | Action::Sentence { .. }
                | Action::Pause { .. }
                | Action::Shot { .. }
                | Action::SelectSpeech(_)
                | Action::First
                | Action::Last
                | Action::VisualMoment
                | Action::SelectObject(_)
                | Action::DeleteSelection
                | Action::Edit(BeatEdit::Delete)
                | Action::DeleteFrames(_)
                | Action::Operator { .. }
                | Action::Repeat { .. }
                | Action::Group
                | Action::Ungroup
                | Action::Explode
                | Action::Duplicate
                | Action::EscalatingRepeat
                | Action::Gag(_)
                | Action::Reverse { .. }
                | Action::SplitEdit { .. }
                | Action::RoleRepeat { .. }
                | Action::Tail { .. }
                | Action::Lift
                | Action::Bleep { .. }
                | Action::GainStep(_)
                | Action::TailPicker
                | Action::Edit(BeatEdit::Cutaway(
                    crate::navigation::cutaway::CutawayInput::Place { .. }
                ))
                | Action::Edit(
                    BeatEdit::InsertHold(_)
                        | BeatEdit::InsertAiHold(_)
                        | BeatEdit::InsertBlack(_)
                        | BeatEdit::Retime(_)
                        | BeatEdit::Pitch(_)
                        | BeatEdit::HoldDuration(_)
                        | BeatEdit::AudioLag { .. }
                        | BeatEdit::Split
                )
                // The Trim draft records its accepted values on Apply.
                | Action::Trim
                | Action::SetMark(_)
                | Action::JumpMark(_)
                | Action::Sound(crate::navigation::SoundAction::Place)
                | Action::Mute
                | Action::Framing(
                    crate::navigation::FramingAction::PunchIn
                        | crate::navigation::FramingAction::Creep
                )
                | Action::Edit(BeatEdit::WrapRepeat(_))
                | Action::Edit(BeatEdit::Repeat(_))
                | Action::Edit(BeatEdit::Escalate(_))
                | Action::CopyMoment
                | Action::PasteMoment { .. }
                | Action::RepeatLast
                | Action::MacroExecute { .. }
                | Action::MacroStop
                | Action::MacroCancel
                | Action::SelectRegister(_)
                | Action::Command
                | Action::Escape
                | Action::Invalid(_)
                | Action::OfferInsert
        ) {
            self.error = Some("This action cannot be recorded yet. Macros support pauses and their lengths, reverses, J- and L-cuts, tails, gain and saturation changes, speed and pitch changes, splits, trims and slips, Edit marks and jumps, sound placement, pause silence and room tone, cutaways and captions, punch-ins and creeps, frame, beat, word, sentence, pause and shot motions, group boundaries, word, sentence, pause and shot objects, Visual selections, cuts, copies, Repeat wraps, count, gap and escalation changes, gags, grouping, ungrouping, exploding, duplicating, register pastes and named calls. Save or cancel recording first.".into());
            return false;
        }
        if matches!(
            action,
            Action::Step { .. }
                | Action::Beat { .. }
                | Action::Word { .. }
                | Action::Sentence { .. }
                | Action::Pause { .. }
                | Action::Shot { .. }
                | Action::SelectSpeech(_)
                | Action::First
                | Action::Last
                | Action::VisualMoment
                | Action::SelectObject(_)
                | Action::DeleteSelection
                | Action::Edit(BeatEdit::Delete)
                | Action::DeleteFrames(_)
                | Action::Operator { .. }
                | Action::Repeat { .. }
                | Action::Group
                | Action::Ungroup
                | Action::Explode
                | Action::Duplicate
                | Action::EscalatingRepeat
                | Action::Gag(_)
                | Action::Reverse { .. }
                | Action::SplitEdit { .. }
                | Action::RoleRepeat { .. }
                | Action::Tail { .. }
                | Action::Lift
                | Action::Bleep { .. }
                | Action::GainStep(_)
                | Action::Edit(BeatEdit::Cutaway(
                    crate::navigation::cutaway::CutawayInput::Place { .. }
                ))
                | Action::Edit(
                    BeatEdit::InsertHold(_) | BeatEdit::InsertBlack(_) | BeatEdit::InsertAiHold(_)
                )
                | Action::Framing(
                    crate::navigation::FramingAction::PunchIn
                        | crate::navigation::FramingAction::Creep
                )
                | Action::Edit(BeatEdit::WrapRepeat(_))
                | Action::Edit(BeatEdit::Repeat(_))
                | Action::Edit(BeatEdit::Escalate(_))
                | Action::CopyMoment
                | Action::PasteMoment { .. }
                | Action::RepeatLast
                | Action::MacroExecute { .. }
        ) || (action == Action::Escape
            && !self.macros.is_pending()
            && self.edit_selection() != navigation::EditSelection::None)
        {
            if self.macros.instruction_count() < deadpan_core::MAX_SEMANTIC_PROGRAM_INSTRUCTIONS {
                return true;
            }
            self.error = Some(
                "The macro has reached 1024 instructions. Save or cancel recording first.".into(),
            );
            return false;
        }
        true
    }

    pub(super) fn macro_command_allowed(
        &mut self,
        command: &Result<navigation::command::Entry, String>,
    ) -> bool {
        if self.edit_range.nodes().is_some() {
            use navigation::command::Entry;
            let supported = matches!(
                command,
                Err(_)
                    | Ok(Entry::Action(_)
                        | Entry::SelectNode { .. }
                        | Entry::SelectNodes { .. }
                        | Entry::SelectMarkRange { .. }
                        | Entry::Splice
                        | Entry::Source
                        | Entry::Sequence
                        | Entry::Help
                        | Entry::Empty,)
                    | Ok(Entry::SelectRole(deadpan_core::MediaRole::Linked))
            );
            if !supported {
                self.error = Some("This command does not support a node set. Clear the set first; y and d operate on its complete union.".into());
                return false;
            }
        }
        let was_recording = std::mem::take(&mut self.macros.command_recording);
        self.reconcile_macro_recording();
        if was_recording
            && !self.macros.recording()
            && !matches!(
                command,
                Ok(navigation::command::Entry::Action(Action::MacroCancel))
            )
        {
            self.error = Some("Recording stopped because its context changed. Start the command again; no action was performed.".into());
            return false;
        }
        if command.as_ref().is_ok_and(duration_recording_draft)
            && self.refuse_duration_recording_draft()
        {
            return false;
        }
        match command {
            Ok(
                navigation::command::Entry::Source
                | navigation::command::Entry::Sequence
                | navigation::command::Entry::Scope(_)
                | navigation::command::Entry::Help,
            ) if self.macros.permits_scoped_navigation() => true,
            Ok(navigation::command::Entry::Splice) => {
                self.macro_action_allowed(Action::PasteMoment { before: false })
            }
            Ok(navigation::command::Entry::Group { .. }) => {
                self.macro_action_allowed(Action::Group)
            }
            Ok(navigation::command::Entry::Action(action)) => {
                self.macro_action_allowed(action.clone())
            }
            // Recorded as the framing it commits, like ,z and ,c.
            Ok(navigation::command::Entry::Zoom(_)) => self
                .macro_action_allowed(Action::Framing(crate::navigation::FramingAction::PunchIn)),
            // Recorded as the whole-group copy and register paste they are.
            Ok(
                navigation::command::Entry::RecipeSave(_) | navigation::command::Entry::Recipe(_),
            ) => self.macro_action_allowed(Action::CopyMoment),
            Ok(
                navigation::command::Entry::RecipeInspect(_)
                | navigation::command::Entry::GagInspect(_),
            ) => true,
            // Recorded as one semantic recipe change.
            Ok(
                navigation::command::Entry::GagSet(_)
                | navigation::command::Entry::GagPreset { .. }
                | navigation::command::Entry::Edge { .. },
            ) => self.macro_action_allowed(Action::Group),
            // Library reads and writes change no project.
            Ok(navigation::command::Entry::GagSave(_) | navigation::command::Entry::GagPresets) => {
                true
            }
            Ok(navigation::command::Entry::DeleteRole(_)) => {
                self.macro_action_allowed(Action::DeleteSelection)
            }
            Ok(navigation::command::Entry::SelectRole(_)) => true,
            Ok(
                navigation::command::Entry::SelectMarkRange { .. }
                | navigation::command::Entry::SelectNode { .. }
                | navigation::command::Entry::SelectNodes { .. },
            ) => self.macro_action_allowed(Action::SelectObject(
                deadpan_core::SemanticTextObject::InnerGroup,
            )),
            Ok(navigation::command::Entry::Trim(_) | navigation::command::Entry::Slip(_)) => {
                self.macro_action_allowed(Action::Trim)
            }
            Ok(navigation::command::Entry::RoomTone | navigation::command::Entry::HoldSilence) => {
                self.hold_audio_entry_allowed()
            }
            // Relative Step and explicit Mute have one-play semantic admission.
            Ok(navigation::command::Entry::GainStep(_)) => {
                self.macro_action_allowed(Action::GainStep(0))
            }
            Ok(navigation::command::Entry::GainMute) => self.macro_action_allowed(Action::Mute),
            // Typed whole-owner setters retain literal invocation intent.
            Ok(
                navigation::command::Entry::Gain(Some(_))
                | navigation::command::Entry::Saturate(_)
                | navigation::command::Entry::Balance(_)
                | navigation::command::Entry::Equalizer(_),
            ) => self.macro_action_allowed(Action::GainStep(0)),
            // Sends still have a separate scoped timing lifecycle.
            Ok(
                navigation::command::Entry::TailSend { .. }
                | navigation::command::Entry::WetSend { .. },
            ) => {
                if !self.macro_action_allowed(Action::GainStep(0)) {
                    return false;
                }
                if self.macros.recording() && self.scoped.is_some() {
                    self.error = Some("A one-play macro cannot record sends. Save or cancel recording before changing a send.".into());
                    return false;
                }
                true
            }
            // Recorded as one semantic caption, checked like a whole-beat cutaway.
            Ok(navigation::command::Entry::Caption(_)) => self.macro_action_allowed(Action::Edit(
                BeatEdit::Cutaway(crate::navigation::cutaway::CutawayInput::Place {
                    register: None,
                    fit: deadpan_core::CutawayFit::Hold,
                }),
            )),
            Ok(_) if self.macros.recording() || self.macros.is_pending() => {
                self.error =
                    Some("This command cannot be recorded. Save or cancel the macro first.".into());
                false
            }
            _ => true,
        }
    }

    pub(super) fn macro_request_allowed(&mut self, request: &ProjectRequest) -> bool {
        if !self.macros.recording() && !self.macros.is_pending() {
            return true;
        }
        if !self.macros.is_pending()
            && matches!(
                request,
                ProjectRequest::CutFrames { .. }
                    | ProjectRequest::Macro(_)
                    | ProjectRequest::Generation(
                        crate::project::generation::GenerationOperation::Cancel { .. }
                    )
            )
        {
            return true;
        }
        self.error = Some("Finish the macro action, then save or cancel recording before another project command.".into());
        false
    }

    pub(super) fn macro_action(&mut self, action: Action, target: Option<Result<Capture, String>>) {
        if action == Action::MacroCancel {
            self.cancel_macro_recording();
            return;
        }
        if action == Action::MacroStop {
            self.save_recording();
            return;
        }
        let result = (|| {
            if self.macros.is_pending() || self.service.is_busy() || self.copied.is_pending() {
                return Err("Wait for the pending project action before using a macro.".into());
            }
            let captured =
                target.ok_or("Start the macro binding again to capture its context.")??;
            if !captured.matches(self) {
                return Err("The captured macro context changed. Start the command again; no macro was run.".into());
            }
            match action {
                Action::MacroRecord(name) => {
                    RegisterName::new(name).map_err(|error| error.to_string())?;
                    if self.macros.recording() {
                        return Err("Save or cancel the current recording first.".into());
                    }
                    self.stop_playback();
                    let duration_only = captured.has_duration_authority();
                    self.macros.recording = Some(Recording {
                        name,
                        expected: captured,
                        instructions: Vec::new(),
                        cut: None,
                    });
                    self.bindings.set_macro_recording(true);
                    self.message = Some(if self.view == View::Source {
                        format!(
                            "Recording @{name} on Original: frame and boundary motions, marks, jumps and named calls. {} saves; Esc cancels.",
                            self.editor_key(EditorKey::MacroRecord)
                        )
                    } else if duration_only {
                        format!(
                            "Recording @{name}: pause lengths and named duration calls only. {} saves; Esc cancels.",
                            self.editor_key(EditorKey::MacroRecord)
                        )
                    } else if self.scoped.is_some() {
                        format!(
                            "Recording @{name} in this play: gain, mute, saturation, balance and EQ, freeze/black pauses, pause lengths, zooms, creeps and named calls. {} saves; Esc cancels.",
                            self.editor_key(EditorKey::MacroRecord)
                        )
                    } else {
                        format!(
                            "Recording @{name}: motions, Visual selections, cuts, copies, pastes and named calls. {} saves; Esc clears a selection, otherwise cancels.",
                            self.editor_key(EditorKey::MacroRecord)
                        )
                    });
                }
                Action::MacroExecute { register, count } => {
                    let instruction = SemanticInstruction::Call {
                        register: RegisterName::new(register).map_err(|error| error.to_string())?,
                        count: NonZeroU32::new(count).ok_or("A macro count must be positive.")?,
                    };
                    let Some(serial) = self.next_serial() else {
                        return Ok(());
                    };
                    let operation = protocol::Operation::Run {
                        id: captured.id(serial),
                        register,
                        count,
                        scope: captured.scope.clone(),
                        context: captured.context.clone(),
                    };
                    if self.submit(ProjectRequest::Macro(operation.clone())) {
                        self.macros.pending = Some(Pending {
                            operation,
                            capture: captured,
                            instruction: self.macros.recording().then_some(instruction),
                            summary: None,
                            owns_cursor: true,
                        });
                        self.message = Some("Running macro…".into());
                    }
                }
                _ => unreachable!("only macro actions enter macro dispatch"),
            }
            Ok(())
        })();
        if let Err(error) = result {
            self.error = Some(error);
        }
    }

    fn save_recording(&mut self) {
        let result = (|| {
            if self.macros.is_pending() || self.service.is_busy() {
                return Err("Wait for the pending action before saving the macro.".into());
            }
            let recording = self
                .macros
                .recording
                .as_ref()
                .ok_or("No macro is being recorded.")?;
            if !recording.expected.matches(self) {
                return Err("The recording context changed. Cancel it and record again.".into());
            }
            if recording.instructions.is_empty() {
                return Err("The recording is empty. Record a motion, selection, cut, copy, paste or macro call before saving.".into());
            }
            let program = Arc::new(
                SemanticProgram::new(recording.instructions.clone())
                    .map_err(|error| error.to_string())?,
            );
            let capture = recording.expected.clone();
            let register = recording.name;
            let Some(serial) = self.next_serial() else {
                return Ok(());
            };
            let operation = protocol::Operation::Save {
                id: capture.id(serial),
                register,
                program,
            };
            if self.submit(ProjectRequest::Macro(operation.clone())) {
                self.macros.pending = Some(Pending {
                    operation,
                    capture,
                    instruction: None,
                    summary: None,
                    owns_cursor: true,
                });
                self.message = Some("Saving macro…".into());
            }
            Ok(())
        })();
        if let Err(error) = result {
            self.error = Some(error);
        }
    }

    /// `:framing-save a`: save the selected beat's framing as a one-step
    /// macro, so `@a` applies the same framing to another selected beat.
    pub(super) fn save_framing_preset(&mut self, name: char) {
        let result = (|| {
            if self.macros.recording() {
                return Err("Save or cancel the recording before saving a framing preset.".into());
            }
            if self.macros.is_pending() || self.service.is_busy() {
                return Err("Wait for the pending action before saving a framing preset.".into());
            }
            let register = RegisterName::new(name).map_err(|error| error.to_string())?;
            let workspace = self.workspace.as_ref().ok_or("Open a project first.")?;
            let node = self
                .selected_beat
                .as_ref()
                .ok_or("Select a framed beat in Your edit first.")?;
            let framing = workspace
                .document
                .nodes()
                .get(node)
                .and_then(|node| node.framing.clone())
                .ok_or(
                    "The selected beat has no framing to save. Frame it with ,f, ,z or ,c first.",
                )?;
            let capture = self.capture_macro_target()?;
            let program = Arc::new(
                SemanticProgram::new(vec![SemanticInstruction::SetFraming {
                    framing: Some(Box::new(framing)),
                }])
                .map_err(|error| error.to_string())?,
            );
            let Some(serial) = self.next_serial() else {
                return Ok(());
            };
            let operation = protocol::Operation::Save {
                id: capture.id(serial),
                register: register.as_char(),
                program,
            };
            if self.submit(ProjectRequest::Macro(operation.clone())) {
                self.macros.pending = Some(Pending {
                    operation,
                    capture,
                    instruction: None,
                    summary: None,
                    owns_cursor: true,
                });
                self.message = Some(format!(
                    "Saving framing preset @{}; apply it to another beat with @{}.",
                    register.as_char(),
                    register.as_char()
                ));
            }
            Ok(())
        })();
        if let Err(error) = result {
            self.error = Some(error);
        }
    }

    pub(super) fn record_macro_motion(&mut self, forward: bool, count: u32) {
        if !self.macros.recording() {
            return;
        }
        let Some(count) = NonZeroU32::new(count) else {
            return;
        };
        self.append_macro_instruction(SemanticInstruction::MoveFrames { forward, count });
    }

    pub(super) fn record_macro_local(&mut self, instruction: SemanticInstruction) {
        if self.macros.recording() {
            self.append_macro_instruction(instruction);
        }
    }

    pub(super) fn record_macro_escape(&mut self) {
        if !self.macros.recording() {
            if let Some(pending) = &mut self.macros.pending {
                pending.owns_cursor = false;
            }
            return;
        }
        if self.macros.recording_original() {
            self.cancel_macro_recording();
            if let Some(pending) = &mut self.macros.pending {
                pending.owns_cursor = false;
            }
            return;
        }
        if !self.macros.is_pending() && self.edit_selection() != navigation::EditSelection::None {
            self.edit_range.clear();
            self.record_macro_local(SemanticInstruction::ClearSelection);
            self.message =
                Some("Visual selection cleared and recorded. Esc now cancels recording.".into());
        } else {
            self.cancel_macro_recording();
            if let Some(pending) = &mut self.macros.pending {
                pending.owns_cursor = false;
            }
        }
    }

    /// Returns true when the recorder owns this copy, including a refused or
    /// still-pending request. Ordinary copies keep their existing route.
    pub(super) fn record_macro_yank(
        &mut self,
        destination: Option<char>,
        target: Option<Result<Capture, String>>,
    ) -> bool {
        let object = target.as_ref().map_or_else(
            || {
                matches!(
                    self.capture_visual_selection(),
                    Ok(Some(
                        deadpan_core::SemanticVisualSelection::Object { .. }
                            | deadpan_core::SemanticVisualSelection::MarkRange { .. }
                            | deadpan_core::SemanticVisualSelection::Node { .. }
                            | deadpan_core::SemanticVisualSelection::Nodes { .. }
                    ))
                )
            },
            |target| target.as_ref().is_ok_and(Capture::object_selected),
        );
        if !self.macros.recording() && !self.macros.is_pending() && !object {
            return false;
        }
        if self.macros.is_pending() {
            self.error = Some("Wait for the pending macro action to finish.".into());
            return true;
        }
        let target = target.unwrap_or_else(|| self.capture_macro_target());
        self.copied.begin_write();
        let instruction = target.as_ref().map_err(Clone::clone).and_then(|target| {
            let register = register_name(destination)?;
            Ok(if let Some(selection) = &target.context.visual_selection {
                if matches!(
                    selection,
                    deadpan_core::SemanticVisualSelection::MarkRange { .. }
                        | deadpan_core::SemanticVisualSelection::Node { .. }
                        | deadpan_core::SemanticVisualSelection::Nodes { .. }
                ) {
                    SemanticInstruction::Yank {
                        selector: selection.effective_selector(),
                        register,
                    }
                } else {
                    SemanticInstruction::YankSelection { register }
                }
            } else {
                SemanticInstruction::YankBeat { register }
            })
        });
        self.apply_recorded_instruction(target, instruction);
        true
    }

    pub(super) fn record_macro_delete(
        &mut self,
        destination: Option<char>,
        target: Option<Result<Capture, String>>,
    ) -> bool {
        let object = target.as_ref().map_or_else(
            || {
                matches!(
                    self.capture_visual_selection(),
                    Ok(Some(
                        deadpan_core::SemanticVisualSelection::Object { .. }
                            | deadpan_core::SemanticVisualSelection::MarkRange { .. }
                            | deadpan_core::SemanticVisualSelection::Node { .. }
                            | deadpan_core::SemanticVisualSelection::Nodes { .. }
                    ))
                )
            },
            |target| target.as_ref().is_ok_and(Capture::object_selected),
        );
        if !self.macros.recording() && !self.macros.is_pending() && !object {
            return false;
        }
        let target = target.unwrap_or_else(|| self.capture_macro_target());
        self.copied.begin_write();
        let instruction = target.as_ref().map_err(Clone::clone).and_then(|target| {
            let register = register_name(destination)?;
            Ok(if let Some(selection) = &target.context.visual_selection {
                if matches!(
                    selection,
                    deadpan_core::SemanticVisualSelection::MarkRange { .. }
                        | deadpan_core::SemanticVisualSelection::Node { .. }
                        | deadpan_core::SemanticVisualSelection::Nodes { .. }
                ) {
                    SemanticInstruction::Cut {
                        selector: selection.effective_selector(),
                        register,
                    }
                } else {
                    SemanticInstruction::CutSelection { register }
                }
            } else {
                SemanticInstruction::Cut {
                    selector: deadpan_core::SemanticSelector::SelectedBeat,
                    register,
                }
            })
        });
        self.apply_recorded_instruction(target, instruction);
        true
    }

    pub(super) fn record_macro_paste(
        &mut self,
        before: bool,
        target: &Result<moment::PlacementTarget, String>,
    ) -> bool {
        if target
            .as_ref()
            .is_ok_and(|target| target.selection.nodes().is_some())
        {
            self.error = Some("Node-set replacement is not supported. Clear the set and choose an insertion seam before pasting.".into());
            return true;
        }
        let union = target
            .as_ref()
            .is_ok_and(|target| matches!(target.copied, Some(copied::Content::EditedSet(_))));
        // A captured context error must refuse an Object paste, never route its
        // derived geometry through the ordinary time-range replacement path.
        let object = target.as_ref().is_ok_and(|target| {
            target.selection.object().is_some() || target.selection.node().is_some()
        });
        if !self.macros.recording() && !self.macros.is_pending() && !object && !union {
            return false;
        }
        if self.macros.is_pending() {
            self.error = Some("Wait for the pending macro action to finish.".into());
            return true;
        }
        self.copied.clear_selection();
        let captured = target
            .as_ref()
            .map_err(Clone::clone)
            .and_then(|target| target.macro_capture.clone());
        let instruction = target.as_ref().map_err(Clone::clone).and_then(|target| {
            target.check_nonempty_selection()?;
            match &target.copied {
                None => {
                    return Err(target.register.map_or_else(
                        || "Copy a beat or Original range before recording a paste.".into(),
                        |name| format!("Register {name} is empty. Copy or cut into it first; no edit was made."),
                    ));
                }
                Some(copied::Content::Macro(_)) => return Err(copied::MACRO_PASTE_ERROR.into()),
                Some(content) => content.check(&target.base)?,
            }
            let register = register_name(target.register)?;
            Ok(if target.selection.has_bounds() {
                SemanticInstruction::ReplaceSelection { register }
            } else {
                SemanticInstruction::Paste { register, before }
            })
        });
        self.apply_recorded_instruction(captured, instruction);
        true
    }

    /// The semantic instruction for a beat edit that has one, so a macro
    /// records it and `.` repeats it: speed, pitch, pause length, audio lag
    /// and placing a cutaway. Clearing cutaways keeps its direct edit.
    pub(super) fn semantic_beat_edit(
        &self,
        edit: &navigation::BeatEdit,
    ) -> Option<Result<SemanticInstruction, String>> {
        use navigation::BeatEdit;
        Some(match edit {
            BeatEdit::Retime(input) => Ok(SemanticInstruction::Retime {
                speed: input.speed,
                pitch: input.pitch,
                wrap: input.wrap,
            }),
            BeatEdit::Pitch(semitones) => Ok(SemanticInstruction::Pitch {
                semitones: *semitones,
            }),
            BeatEdit::Split => Ok(SemanticInstruction::Split),
            BeatEdit::AudioLag { earlier, amount } => self
                .workspace
                .as_ref()
                .ok_or_else(|| "Open a project first.".to_owned())
                .and_then(|workspace| {
                    let rate = workspace.document.presentation_basis().frame_rate;
                    let samples = amount
                        .map(|amount| amount.samples(rate))
                        .transpose()?
                        .map_or(0, |samples| samples.0);
                    Ok(SemanticInstruction::SetAudioLag {
                        offset: deadpan_core::AudioSample(if *earlier {
                            -samples
                        } else {
                            samples
                        }),
                    })
                }),
            BeatEdit::HoldDuration(duration) => u32::try_from(duration.frames())
                .ok()
                .and_then(NonZeroU32::new)
                .map(|frames| SemanticInstruction::SetHoldDuration {
                    length: deadpan_core::PauseLength::Frames { frames },
                })
                .ok_or_else(|| "A pause needs at least one frame.".to_owned()),
            BeatEdit::Cutaway(crate::navigation::cutaway::CutawayInput::Place {
                register,
                fit,
            }) => RegisterName::new(register.or_else(|| self.copied.selected()).unwrap_or('"'))
                .map(|register| SemanticInstruction::SetCutaway {
                    register,
                    fit: *fit,
                })
                .map_err(|error| error.message),
            _ => return None,
        })
    }

    /// A draft (Trim, Slip, room tone) that captured its own target records
    /// only when closing it restored exactly that context, so the recorded
    /// instruction cannot retarget another beat.
    pub(super) fn recorded_context(
        &self,
        session: u64,
        revision: &RevisionId,
        node: &NodeId,
        cursor: ProjectFrame,
    ) -> Result<(), String> {
        let restored = self.workspace.as_ref().is_some_and(|workspace| {
            workspace.session == session && workspace.document.revision_id() == revision
        }) && self.selected_beat.as_ref() == Some(node)
            && i64::try_from(self.sequence_cursor).ok() == Some(cursor.0);
        if restored {
            Ok(())
        } else {
            Err("The edited beat or cursor changed while the preview was open; nothing was recorded or saved. Open it again.".into())
        }
    }

    pub(super) fn apply_recorded_instruction(
        &mut self,
        target: Result<Capture, String>,
        instruction: Result<SemanticInstruction, String>,
    ) {
        self.apply_semantic_instruction(target, instruction, None);
    }

    pub(super) fn repeat_last_edit(&mut self) {
        let uses_register = self.last_edit_uses_register();
        let invocation = (|| {
            let captured = self.capture_macro_target()?;
            let snapshot = self
                .semantic
                .snapshot()
                .ok_or("Make a picture cut or Repeat before repeating an edit.")?;
            let edit = snapshot.edit_for(&captured.base)?;
            if matches!(
                edit.operation,
                crate::project::semantic::RepeatableEdit::Ungroup
            ) && captured.context.visual_selection.is_some()
            {
                return Err("Clear the Visual range before repeating Ungroup.".into());
            }
            if matches!(
                edit.operation,
                crate::project::semantic::RepeatableEdit::Explode
            ) && captured.context.visual_selection.is_some()
            {
                return Err("Clear the Visual range before repeating Explode.".into());
            }
            if matches!(
                edit.operation,
                crate::project::semantic::RepeatableEdit::SetRepeatPlays { .. }
            ) && captured.context.visual_selection.is_some()
            {
                return Err(
                    "Clear the Visual range before repeating a Repeat count change.".into(),
                );
            }
            match &captured.context.visual_selection {
                Some(deadpan_core::SemanticVisualSelection::Time { anchor, head, .. })
                    if anchor == head =>
                {
                    return Err(if edit.uses_register() {
                        "The Edit selection is empty. Move a boundary before repeating the cut."
                    } else {
                        "The Edit selection is empty. Move a boundary before repeating the edit."
                    }
                    .into());
                }
                None if matches!(
                    edit.operation,
                    crate::project::semantic::RepeatableEdit::Cut(
                        crate::project::semantic::RepeatableCut::Selector(
                            deadpan_core::SemanticSelector::VisualSelection
                        )
                    ) | crate::project::semantic::RepeatableEdit::Repeat {
                        selector: deadpan_core::SemanticSelector::VisualSelection,
                        ..
                    } | crate::project::semantic::RepeatableEdit::Group {
                        selector: deadpan_core::SemanticSelector::VisualSelection,
                        ..
                    } | crate::project::semantic::RepeatableEdit::Duplicate {
                        selector: deadpan_core::SemanticSelector::VisualSelection,
                    }
                ) =>
                {
                    return Err(if edit.uses_register() {
                        "Select a new Visual range before repeating this cut."
                    } else {
                        "Select a new Visual range before repeating this edit."
                    }
                    .into());
                }
                _ => {}
            }
            let register = register_name(self.copied.selected_override().unwrap_or(edit.register))?;
            let instruction = edit.instruction(&captured.context, register);
            Ok((captured, instruction, snapshot.version))
        })();
        self.cancel_repeats("semantic repetition was requested");
        self.bindings.clear();
        // The override belongs to this attempt, including refusals. A saved
        // result still arrives through the immutable request and durable bank.
        if uses_register {
            self.copied.begin_write();
        }
        match invocation {
            Ok((capture, instruction, version)) => {
                self.apply_semantic_instruction(Ok(capture), Ok(instruction), Some(version));
            }
            Err(error) => self.error = Some(error),
        }
    }

    fn apply_semantic_instruction(
        &mut self,
        target: Result<Capture, String>,
        instruction: Result<SemanticInstruction, String>,
        repeat_version: Option<u64>,
    ) {
        let result = (|| {
            if self.macros.is_pending() || self.service.is_busy() || self.copied.is_pending() {
                return Err("Wait for the pending project action before another edit.".into());
            }
            let captured = target?;
            let instruction = instruction?;
            if matches!(instruction, SemanticInstruction::SetHoldDuration { .. }) {
                captured.check_fixed_duration()?;
            }
            if captured.has_duration_authority()
                && !matches!(
                    instruction,
                    SemanticInstruction::SetHoldDuration { .. } | SemanticInstruction::Call { .. }
                )
            {
                return Err("This nested Hold supports pause length and named duration calls only. Return to the parent for other macro edits.".into());
            }
            if captured.context.scoped.is_some()
                && !matches!(
                    instruction,
                    SemanticInstruction::Zoom { .. }
                        | SemanticInstruction::InsertPause { .. }
                        | SemanticInstruction::SetHoldDuration { .. }
                        | SemanticInstruction::SetHoldAudio { .. }
                        | SemanticInstruction::SetRoomTone { .. }
                        | SemanticInstruction::Call { .. }
                )
                && !matches!(&instruction, SemanticInstruction::SetAudio { change } if gain::scoped_audio_change(change))
            {
                return Err("This play supports whole-beat gain, mute, saturation, balance and EQ, freeze and black pauses, pause lengths, silence and room tone, Zoom, Creep and named calls only. Return to the parent for other macro edits.".into());
            }
            if !captured.matches(self)
                || self
                    .macros
                    .recording
                    .as_ref()
                    .is_some_and(|recording| !recording.expected.matches(self))
            {
                return Err("The captured editing context changed. Start the command again; no edit was made.".into());
            }
            if self.macros.instruction_count() >= deadpan_core::MAX_SEMANTIC_PROGRAM_INSTRUCTIONS {
                return Err(
                    "The macro has reached 1024 instructions. Save or cancel recording first."
                        .into(),
                );
            }
            let Some(serial) = self.next_serial() else {
                return Ok(());
            };
            let operation = protocol::Operation::Apply {
                id: captured.id(serial),
                instruction: Box::new(instruction.clone()),
                scope: captured.scope.clone(),
                context: captured.context.clone(),
                repeat_version,
            };
            self.stop_playback();
            let summary = super::semantic::applied_summary(&instruction, &captured.context);
            if self.submit(ProjectRequest::Macro(operation.clone())) {
                self.macros.pending = Some(Pending {
                    operation,
                    capture: captured,
                    summary,
                    instruction: self.macros.recording().then_some(instruction),
                    owns_cursor: true,
                });
                self.message = Some("Saving action…".into());
            }
            Ok(())
        })();
        if let Err(error) = result {
            self.error = Some(error);
        }
    }

    fn append_macro_instruction(&mut self, instruction: SemanticInstruction) {
        let capture = self.capture_macro_target();
        if let Some(recording) = &mut self.macros.recording {
            match capture {
                Ok(capture) => {
                    recording.instructions.push(instruction);
                    recording.expected = capture;
                }
                Err(error) => {
                    self.macros.recording = None;
                    self.error = Some(format!("Recording stopped: {error}"));
                    self.bindings.set_macro_recording(false);
                }
            }
        }
    }

    pub(super) fn record_macro_cut(
        &mut self,
        request: &slice::CaptureRequest,
        attempt: Option<&crate::project::semantic::CutAttempt>,
    ) {
        if let (Some(recording), Some(attempt)) = (&mut self.macros.recording, attempt) {
            let register = request
                .register
                .map_or(Ok(RegisterName::unnamed()), RegisterName::new)
                .expect("captured register was validated");
            recording.cut = Some((request.id.clone(), attempt.operation.instruction(register)));
        }
    }

    /// Called before replacing the visible workspace. A delayed macro cannot
    /// retarget a cursor which the user has since moved with the pointer.
    pub(super) fn prepare_macro_update(&mut self, update: &mut crate::project::ProjectUpdate) {
        let owns_cursor = self
            .macros
            .pending
            .as_ref()
            .is_some_and(|pending| pending.capture.matches(self));
        if let Some(pending) = &mut self.macros.pending {
            pending.owns_cursor &= owns_cursor;
        }
        let saved = update.saved_macro.as_ref();
        if let Some(receipt) = saved {
            let owned = self.macros.pending.as_ref().is_some_and(|pending| {
                pending.operation.id() == &receipt.id && pending.owns_cursor
            });
            if let Some(commit) = receipt.committed() {
                let visible = update.workspace.as_ref().is_some_and(|workspace| {
                    selection::commit_matches_visible(
                        commit,
                        workspace.session,
                        workspace.document.project_id(),
                        workspace.document.revision_id(),
                    )
                });
                if owned && visible && receipt.original().is_none() {
                    let mut commit = commit.clone();
                    // The service reconstructs semantic authority without UI
                    // metadata. Restore only the exact owned runtime capture.
                    if let Some(scoped) = &mut commit.scoped
                        && let Some(captured) = self
                            .macros
                            .pending
                            .as_ref()
                            .and_then(|pending| pending.capture.scoped.as_ref())
                    {
                        scoped.before.navigation = captured.navigation;
                        if &scoped.before != captured {
                            update.committed = None;
                            return;
                        }
                    }
                    update.committed = Some(commit);
                } else if update
                    .committed
                    .as_ref()
                    .is_some_and(|current| current.revision == commit.revision)
                {
                    update.committed = None;
                }
            }
            if let protocol::Outcome::Executed {
                refresh_error: Some(error),
                ..
            }
            | protocol::Outcome::Applied {
                refresh_error: Some(error),
                ..
            } = &receipt.outcome
                && update.workspace.as_ref().is_some_and(|workspace| {
                    workspace.session == receipt.id.session
                        && workspace.document.revision_id() == &receipt.id.revision
                })
            {
                update.message = Some(error.clone());
            }
        }
    }

    pub(super) fn receive_macro_cut(
        &mut self,
        update: Option<&slice::CutUpdate>,
        saved: Option<&slice::CutReceipt>,
    ) {
        let Some((id, _)) = self
            .macros
            .recording
            .as_ref()
            .and_then(|recording| recording.cut.as_ref())
        else {
            return;
        };
        let result = saved
            .filter(|receipt| receipt.copied.id() == id)
            .map(Ok)
            .or_else(|| {
                update
                    .filter(|update| &update.request.id == id)
                    .map(|update| update.result.as_ref())
            });
        let Some(result) = result else {
            return;
        };
        let instruction = self
            .macros
            .recording
            .as_mut()
            .and_then(|recording| recording.cut.take())
            .expect("matching recorded cut")
            .1;
        match result {
            Ok(receipt)
                if receipt.refresh_error.is_none()
                    && self.workspace.as_ref().is_some_and(|workspace| {
                        workspace.document.revision_id() == &receipt.committed.revision
                    }) =>
            {
                self.append_macro_instruction(instruction)
            }
            Ok(_) => {
                self.cancel_macro_recording();
                self.message = Some("The cut was saved, but recording stopped because its refreshed edit is unavailable. Reopen the project before continuing. The previous macro is unchanged.".into());
            }
            Err(error) => self.error = Some(format!("Cut was not recorded: {error}")),
        }
    }

    pub(super) fn receive_macro(
        &mut self,
        update: Option<protocol::Update>,
        saved: Option<protocol::Receipt>,
    ) {
        let Some(pending) = self.macros.pending.as_ref() else {
            return;
        };
        let id = pending.operation.id();
        let result = saved
            .filter(|receipt| &receipt.id == id)
            .map(Ok)
            .or_else(|| {
                update
                    .filter(|update| &update.id == id)
                    .map(|update| update.result)
            });
        let Some(result) = result else {
            return;
        };
        let pending = self.macros.pending.take().expect("matched pending macro");
        match result {
            Err(error) => {
                // An ordinary refresh may fill an absent selection from the
                // cursor. A refused owned action preserves its captured absence.
                if pending.owns_cursor && pending.capture.matches_without_selection(self) {
                    self.selected_beat = pending.capture.context.selected_child.clone();
                }
                // A request that would change nothing is reported as a
                // message, like the direct edits' "No edit was made".
                if error.to_ascii_lowercase().ends_with("no edit was made") {
                    let text = error
                        .split_once(": ")
                        .map_or(error.as_str(), |(_, text)| text);
                    let mut chars = text.chars();
                    self.error = None;
                    self.message = Some(format!(
                        "{}{}.",
                        chars
                            .next()
                            .map(|first| first.to_uppercase().to_string())
                            .unwrap_or_default(),
                        chars
                            .as_str()
                            .replace("; no edit was made", ". No edit was made")
                            .trim_end_matches('.')
                    ));
                } else {
                    self.error = Some(error);
                }
            }
            Ok(receipt) => {
                let visible = completion_visible(
                    &receipt,
                    self.workspace.as_ref().map(|workspace| {
                        (
                            workspace.session,
                            workspace.document.project_id(),
                            workspace.document.revision_id(),
                        )
                    }),
                    self.copied.bank_version(),
                );
                let completed_message = match &receipt.outcome {
                    protocol::Outcome::Executed {
                        register,
                        count,
                        committed,
                        ..
                    } => format!(
                        "Ran Macro @{register} × {count}{}.",
                        if committed.is_some() {
                            " · one Undo"
                        } else if receipt.bank_version != receipt.id.bank_version {
                            " · registers saved"
                        } else {
                            " · cursor and selection only"
                        },
                    ),
                    protocol::Outcome::Applied { .. } => format!(
                        "{}{}.",
                        pending
                            .summary
                            .as_deref()
                            .unwrap_or("Action completed")
                            .trim_end_matches('.'),
                        if self.macros.recording() {
                            " and recorded"
                        } else {
                            ""
                        },
                    ),
                    protocol::Outcome::Saved { .. } => String::new(),
                };
                match receipt.outcome {
                    protocol::Outcome::Saved {
                        register,
                        instructions,
                    } => {
                        self.macros.recording = None;
                        self.bindings.set_macro_recording(false);
                        self.message = Some(format!(
                            "Saved Macro @{register} · {instructions} instructions. Use {}{register} to run it.",
                            self.editor_key(EditorKey::MacroExecute)
                        ));
                    }
                    protocol::Outcome::Executed {
                        scope,
                        cursor,
                        selected,
                        visual_selection,
                        original,
                        committed,
                        refresh_error,
                        ..
                    }
                    | protocol::Outcome::Applied {
                        scope,
                        cursor,
                        selected,
                        visual_selection,
                        original,
                        committed,
                        refresh_error,
                    } => {
                        if refresh_error.is_some() || !visible {
                            if pending.owns_cursor
                                && pending.capture.matches_without_bank_or_selection(self)
                            {
                                self.selected_beat = pending.capture.context.selected_child.clone();
                            }
                            self.cancel_macro_recording();
                            self.message = refresh_error.or_else(|| Some("The action completed, but its edit is no longer visible. Recording was stopped.".into()));
                            return;
                        }
                        if !pending.owns_cursor {
                            self.cancel_macro_recording();
                            self.message = Some("Action completed after the editing context changed. Its final cursor and selection were not applied.".into());
                            return;
                        }
                        if let Some(original) = original {
                            let admitted = self.workspace.as_ref().is_some_and(|workspace| {
                                workspace
                                    .sources
                                    .get(&original.asset)
                                    .is_some_and(|source| {
                                        source.receipt.id() == &original.qualification
                                            && source.video_index.as_ref().is_some_and(|index| {
                                                original.ordinal.0 <= index.frames().len() as u64
                                            })
                                    })
                            });
                            if self.view != View::Source
                                || self.selected_source.as_ref() != Some(&original.asset)
                                || !admitted
                            {
                                self.cancel_macro_recording();
                                self.message = Some("The Original macro completed, but its qualified source is no longer visible. Its cursor was not applied.".into());
                                return;
                            }
                            let moved = self.source_cursor != original.ordinal.0;
                            self.source_cursor = original.ordinal.0;
                            if moved {
                                self.request_picture(false);
                            }
                            if let Some(instruction) = pending.instruction {
                                self.append_macro_instruction(instruction);
                            }
                            self.message = Some(completed_message);
                            return;
                        }
                        // Ownership was captured before receive installed the bank.
                        // A successful yank changes that bank without a revision,
                        // so comparing against the entry bank here would reject it.
                        let cursor =
                            u64::try_from(cursor.0).expect("validated nonnegative macro cursor");
                        let picture_changed =
                            self.sequence_scope != scope || self.sequence_cursor != cursor;
                        let selection_changed = self.selected_beat != selected;
                        self.sequence_scope = scope;
                        self.sequence_cursor = cursor;
                        self.selected_beat = selected;
                        self.reveal_beat |= selection_changed;
                        if let Err(error) = self.restore_macro_visual_selection(visual_selection) {
                            self.cancel_macro_recording();
                            self.error = Some(error);
                            return;
                        }
                        if committed.is_none() && picture_changed {
                            self.request_picture(false);
                        }
                        if let Some(instruction) = pending.instruction {
                            self.append_macro_instruction(instruction);
                        }
                        self.message = Some(completed_message);
                    }
                }
            }
        }
    }
}

/// Recognize only placements with the same structural resolution as an existing
/// semantic instruction. Equal-time seams are distinguished by their child slot.
fn splice_instruction(
    context: &SemanticContext,
    children: &[NodeId],
    proposal: &crate::project::splice::Proposal,
    initial_source: &crate::project::splice::Source,
    register: RegisterName,
    captured_range: Option<deadpan_core::FrameRange>,
) -> Result<SemanticInstruction, String> {
    use crate::project::splice::{Destination, Operation};
    if proposal.operation != Operation::Copy {
        return Err("Macro recording supports Copy placement. Use m to return to Copy, or cancel recording before Move.".into());
    }
    if &proposal.source != initial_source {
        return Err("Macro recording uses the captured register's exact source. Restore its In and Out, or cancel recording before refining them.".into());
    }
    match &proposal.destination {
        Destination::Replace { range }
            if matches!(context.visual_selection, Some(deadpan_core::SemanticVisualSelection::Time { .. } | deadpan_core::SemanticVisualSelection::MarkRange { .. }))
                && captured_range == Some(*range)
                && range.start() < range.end() =>
        {
            Ok(SemanticInstruction::ReplaceSelection { register })
        }
        Destination::Object { selection }
            if matches!(&context.visual_selection, Some(deadpan_core::SemanticVisualSelection::Object { selection: captured, .. }) if captured == selection)
                && captured_range.is_some() =>
        {
            Ok(SemanticInstruction::ReplaceSelection { register })
        }
        Destination::Replace { .. } | Destination::Object { .. } => Err(
            "Macro recording can replace only the exact Edit selection captured when Place slice opened; a time range must be nonempty.".into(),
        ),
        Destination::Interior { .. } => Err(
            "Macro recording needs the seam immediately before or after the captured selected beat. Use j/k to choose that seam.".into(),
        ),
        Destination::Slot(slot) => {
            if matches!(context.visual_selection, Some(deadpan_core::SemanticVisualSelection::Object { .. })) {
                return Err("A macro paste with an Object selection replaces that object. Use r for the captured replacement, or cancel and clear the selection before inserting.".into());
            }
            let before = if children.is_empty() && *slot == 0 {
                true
            } else {
                let selected = context.selected_child.as_ref()
                    .and_then(|selected| children.iter().position(|child| child == selected))
                    .ok_or("Select a beat before recording Place slice insertion.")?;
                if *slot == selected {
                    true
                } else if selected.checked_add(1) == Some(*slot) {
                    false
                } else {
                    return Err("Macro recording needs the seam immediately before or after the captured selected beat. Use j/k to choose that seam.".into());
                }
            };
            Ok(SemanticInstruction::Paste { register, before })
        }
    }
}

fn register_name(register: Option<char>) -> Result<RegisterName, String> {
    register.map_or(Ok(RegisterName::unnamed()), |name| {
        RegisterName::new(name).map_err(|error| error.to_string())
    })
}

fn completion_visible(
    receipt: &protocol::Receipt,
    workspace: Option<(u64, &deadpan_core::ProjectId, &RevisionId)>,
    bank_version: Option<u64>,
) -> bool {
    let revision = receipt
        .committed()
        .map_or(&receipt.id.revision, |commit| &commit.revision);
    workspace.is_some_and(|(session, project, visible_revision)| {
        session == receipt.id.session
            && project == &receipt.id.project
            && visible_revision == revision
            && bank_version == Some(receipt.bank_version)
    })
}

#[cfg(test)]
mod tests;
