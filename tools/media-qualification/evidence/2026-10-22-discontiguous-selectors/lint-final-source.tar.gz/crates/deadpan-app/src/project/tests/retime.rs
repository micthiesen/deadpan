use super::*;
use deadpan_core::{ExactRatio, FrameRange, PitchPolicy, RetimePurpose};

fn change(target: &NodeId, speed: ExactRatio, pitch: PitchPolicy, wrap: bool) -> ProjectEdit {
    ProjectEdit::Retime {
        node: target.clone(),
        speed,
        pitch,
        wrap,
    }
}

#[test]
fn native_original_retime_adjusts_one_wrapper_and_has_durable_undo() {
    let scratch = tempfile::tempdir().unwrap();
    let service = ProjectService::start(
        Arc::new(|| {}),
        Some(ProjectLibrary::from_documents(scratch.path().join("Documents")).unwrap()),
    )
    .unwrap();
    service
        .submit(ProjectRequest::CreateFromSource {
            ownership: OriginalOwnership::Managed,
            path: fixture("cfr-bframes.mp4"),
        })
        .unwrap();
    let initialized = wait(&service, |update| {
        update.import.as_ref().is_some_and(|status| {
            matches!(status.stage, ImportStage::Complete | ImportStage::Failed)
        })
    });
    assert!(initialized.error.is_none(), "{:?}", initialized.error);
    let original = initialized.committed.unwrap().selected_node.unwrap();
    let before = initialized.workspace.unwrap();
    let expected = i64::try_from(
        ExactRatio::integer(before.plan.duration().frames())
            .checked_mul(ExactRatio::new(4, 3).unwrap())
            .unwrap()
            .round_even()
            .unwrap(),
    )
    .unwrap();
    let wrapped = edited(
        &service,
        &before,
        change(
            &original,
            ExactRatio::new(3, 4).unwrap(),
            PitchPolicy::Preserve,
            false,
        ),
    );
    let id = wrapped.committed.unwrap().selected_node.unwrap();
    let wrapped = wrapped.workspace.unwrap();
    assert_ne!(id, original);
    assert_eq!(wrapped.plan.duration().frames(), expected);
    assert_eq!(
        wrapped.document.nodes()[&original],
        before.document.nodes()[&original]
    );
    assert_eq!(wrapped.document.assets(), before.document.assets());
    assert_eq!(wrapped.single_source, before.single_source);
    assert!(
        matches!(&wrapped.document.nodes()[&id].kind, NodeKind::Retime { child, pitch: PitchPolicy::Preserve, purpose: RetimePurpose::Edit, .. } if child == &original)
    );
    let invalid = command(
        &service,
        edit_request(
            &before,
            change(&original, ExactRatio::ONE, PitchPolicy::Preserve, false),
        ),
    );
    assert!(invalid.error.unwrap().contains("changed"));
    assert_eq!(*invalid.workspace.unwrap().document, *wrapped.document);

    let updated = edited(
        &service,
        &wrapped,
        change(&id, ExactRatio::integer(2), PitchPolicy::FollowSpeed, false),
    );
    assert_eq!(updated.committed.unwrap().selected_node, Some(id.clone()));
    let updated = updated.workspace.unwrap();
    assert_eq!(
        updated.plan.duration().frames(),
        before.plan.duration().frames() / 2
    );
    assert_eq!(
        updated.document.nodes().len(),
        wrapped.document.nodes().len()
    );
    let same = command(
        &service,
        edit_request(
            &updated,
            change(&id, ExactRatio::integer(2), PitchPolicy::FollowSpeed, false),
        ),
    );
    assert!(same.committed.is_none());
    assert_eq!(*same.workspace.unwrap().document, *updated.document);
    let path = updated.path.clone();
    command(&service, ProjectRequest::Close);
    let opened = command(&service, ProjectRequest::Open(path))
        .workspace
        .unwrap();
    assert_eq!(*opened.document, *updated.document);
    let undone = command(
        &service,
        ProjectRequest::Undo {
            expected_revision: opened.document.revision_id().clone(),
        },
    )
    .workspace
    .unwrap();
    assert_eq!(undone.document.nodes(), wrapped.document.nodes());
    let undone_again = command(
        &service,
        ProjectRequest::Undo {
            expected_revision: undone.document.revision_id().clone(),
        },
    )
    .workspace
    .unwrap();
    assert_eq!(undone_again.document.nodes(), before.document.nodes());
    assert!(
        !undone_again.can_undo,
        "the pinned Original baseline remains protected"
    );
    let redone = command(
        &service,
        ProjectRequest::Redo {
            expected_revision: undone_again.document.revision_id().clone(),
        },
    )
    .workspace
    .unwrap();
    assert_eq!(redone.document.nodes(), wrapped.document.nodes());
}

#[test]
fn retime_resolves_once_and_rejects_empty_zero_and_overflow_without_commits() {
    let scratch = tempfile::tempdir().unwrap();
    let path = scratch.path().join("speed.deadpan");
    drop(seed_holds(&path, &["a"]));
    let service = ProjectService::new(Arc::new(|| {})).unwrap();
    let before = command(&service, ProjectRequest::Open(path))
        .workspace
        .unwrap();
    for speed in [
        ExactRatio::ZERO,
        ExactRatio::integer(-1),
        ExactRatio::integer(21),
        ExactRatio::new(1, i128::MAX).unwrap(),
    ] {
        let failed = command(
            &service,
            edit_request(
                &before,
                change(&node("a"), speed, PitchPolicy::Preserve, false),
            ),
        );
        assert!(failed.error.is_some(), "{speed:?}");
        assert!(failed.committed.is_none());
        assert_eq!(*failed.workspace.unwrap().document, *before.document);
    }
    let wrapped = edited(
        &service,
        &before,
        change(
            &node("a"),
            ExactRatio::integer(4),
            PitchPolicy::FollowSpeed,
            false,
        ),
    );
    let id = wrapped.committed.unwrap().selected_node.unwrap();
    let wrapped = wrapped.workspace.unwrap();
    assert_eq!(
        wrapped.plan.duration().frames(),
        2,
        "2.5 frames ties to even"
    );
    let updated = edited(
        &service,
        &wrapped,
        change(&id, ExactRatio::integer(2), PitchPolicy::FollowSpeed, false),
    );
    let updated = updated.workspace.unwrap();
    assert_eq!(
        updated.plan.duration().frames(),
        5,
        "speed is relative to the retained 10-frame input, not the previously rounded output"
    );
    let nested = edited(
        &service,
        &updated,
        change(&id, ExactRatio::integer(2), PitchPolicy::FollowSpeed, true),
    );
    let outer = nested.committed.unwrap().selected_node.unwrap();
    let nested = nested.workspace.unwrap();
    assert_ne!(outer, id);
    assert_eq!(nested.plan.duration().frames(), 2);
    assert_eq!(nested.document.nodes()[&id], updated.document.nodes()[&id]);
}

#[test]
fn nested_scope_and_split_partition_are_preserved_by_retime() {
    let scratch = tempfile::tempdir().unwrap();
    let path = scratch.path().join("fragment.deadpan");
    let mut store = seed_holds(&path, &[]);
    let fragment = BeatNode {
        audio_treatments: Default::default(),
        label: "Fragment".into(),
        audio_editorial_edges: Default::default(),
        audio_edges: Default::default(),
        framing: None,
        kind: NodeKind::Retime {
            child: node("a"),
            duration: FrameDuration::new(5).unwrap(),
            mapping: FrameRange::new(ProjectFrame(2), ProjectFrame(7)).unwrap(),
            pitch: PitchPolicy::FollowSpeed,
            purpose: RetimePurpose::Partition,
        },
        cutaways: Vec::new(),
        captions: Vec::new(),
    };
    seed_command(
        &mut store,
        Command::Insert {
            parent: node("root"),
            index: 0,
            subtree: Subtree {
                root: node("group"),
                nodes: BTreeMap::from([
                    (
                        node("group"),
                        BeatNode::sequence("Group", vec![node("fragment"), node("empty")]),
                    ),
                    (node("empty"), BeatNode::sequence("Empty", vec![])),
                    (node("fragment"), fragment.clone()),
                    (node("a"), BeatNode::hold("Input", hold(10))),
                ]),
                overrides: BTreeMap::new(),
                gap_overrides: BTreeMap::new(),
            },
        },
        "insert-fragment",
    );
    drop(store);
    let service = ProjectService::new(Arc::new(|| {})).unwrap();
    let before = command(&service, ProjectRequest::Open(path))
        .workspace
        .unwrap();
    let scope = SequenceScope::default()
        .descend(&before, &node("group"))
        .unwrap();
    for (target, attempted_scope) in [
        (node("fragment"), SequenceScope::default()),
        (node("a"), scope.clone()),
        (node("empty"), scope.clone()),
    ] {
        let rejected = command(
            &service,
            edit_request_in(
                &before,
                attempted_scope,
                ProjectFrame(0),
                change(
                    &target,
                    ExactRatio::new(1, 2).unwrap(),
                    PitchPolicy::Preserve,
                    false,
                ),
            ),
        );
        assert!(rejected.error.is_some());
        assert_eq!(*rejected.workspace.unwrap().document, *before.document);
    }
    let edited = command(
        &service,
        edit_request_in(
            &before,
            scope.clone(),
            ProjectFrame(3),
            change(
                &node("fragment"),
                ExactRatio::new(1, 2).unwrap(),
                PitchPolicy::Preserve,
                false,
            ),
        ),
    );
    assert!(edited.error.is_none(), "{:?}", edited.error);
    let commit = edited.committed.unwrap();
    assert_eq!(commit.scope, scope);
    assert_ne!(commit.selected_node.as_ref(), Some(&node("fragment")));
    let after = edited.workspace.unwrap();
    assert_eq!(after.document.nodes()[&node("fragment")], fragment);
    assert_eq!(after.plan.duration().frames(), 10);
}

#[test]
fn native_pause_inside_a_tape_speed_change_keeps_exact_clocks_and_one_undo() {
    let scratch = tempfile::tempdir().unwrap();
    let service = ProjectService::start(
        Arc::new(|| {}),
        Some(ProjectLibrary::from_documents(scratch.path().join("Documents")).unwrap()),
    )
    .unwrap();
    service
        .submit(ProjectRequest::CreateFromSource {
            ownership: OriginalOwnership::Managed,
            path: fixture("cfr-bframes.mp4"),
        })
        .unwrap();
    let initialized = wait(&service, |update| {
        update.import.as_ref().is_some_and(|status| {
            matches!(status.stage, ImportStage::Complete | ImportStage::Failed)
        })
    });
    assert!(initialized.error.is_none(), "{:?}", initialized.error);
    let original = initialized.committed.unwrap().selected_node.unwrap();
    let before = initialized.workspace.unwrap();
    let slowed = edited(
        &service,
        &before,
        change(
            &original,
            ExactRatio::new(1, 2).unwrap(),
            PitchPolicy::FollowSpeed,
            true,
        ),
    );
    assert!(slowed.error.is_none(), "{:?}", slowed.error);
    let slowed = slowed.workspace.unwrap();
    let total = slowed.plan.duration().frames();
    // Frame 31 lands half way through an Original frame; 3 frames span 3/2.
    let paused = edited(
        &service,
        &slowed,
        ProjectEdit::InsertBlack {
            at: ProjectFrame(31),
            duration: FrameDuration::new(3).unwrap(),
        },
    );
    assert!(paused.error.is_none(), "{:?}", paused.error);
    let after = paused.workspace.unwrap();
    assert!(!after.document.derived_clocks().is_empty());
    assert_eq!(after.plan.duration().frames(), total + 3);
    for (frame, black) in [(30, false), (31, true), (33, true), (34, false)] {
        let picture = after.plan.picture(ProjectFrame(frame)).unwrap().picture;
        assert_eq!(
            matches!(picture, deadpan_plan::Picture::Background),
            black,
            "frame {frame}"
        );
    }
    // Later pictures are the old ones three frames on.
    for frame in [34, 40, total + 2] {
        assert_eq!(
            after.plan.picture(ProjectFrame(frame)).unwrap().picture,
            slowed
                .plan
                .picture(ProjectFrame(frame - 3))
                .unwrap()
                .picture,
            "frame {frame}"
        );
    }
    let restored = command(
        &service,
        ProjectRequest::Undo {
            expected_revision: after.document.revision_id().clone(),
        },
    )
    .workspace
    .unwrap();
    assert_eq!(*restored.document.nodes(), *slowed.document.nodes());
    assert!(restored.document.derived_clocks().is_empty());
    // A freeze captures the picture before the cut, below the speed change,
    // which stays live over the pause.
    let frozen = edited(
        &service,
        &restored,
        ProjectEdit::InsertTime {
            at: ProjectFrame(31),
            duration: FrameDuration::new(3).unwrap(),
        },
    );
    assert!(frozen.error.is_none(), "{:?}", frozen.error);
    let frozen = frozen.workspace.unwrap();
    let held = frozen.plan.picture(ProjectFrame(32)).unwrap().picture;
    assert!(
        matches!(held, deadpan_plan::Picture::Freeze { .. }),
        "{held:?}"
    );
    let stage = slowed
        .document
        .nodes()
        .iter()
        .find_map(|(id, beat)| matches!(beat.kind, NodeKind::Retime { .. }).then_some(id))
        .unwrap();
    assert!(frozen.clocked_retimes.contains(stage));
    let second = edited(
        &service,
        &frozen,
        ProjectEdit::InsertBlack {
            at: ProjectFrame(40),
            duration: FrameDuration::new(1).unwrap(),
        },
    );
    assert!(second.error.is_none(), "{:?}", second.error);
    let second = second.workspace.unwrap();
    assert!(!second.document.derived_clocks().contains_key(stage));
    assert!(!second.document.derived_clocks().is_empty());
    assert!(second.clocked_retimes.contains(stage));
    let resolution = super::super::retime::resolve(
        &second,
        stage,
        ExactRatio::ONE,
        PitchPolicy::FollowSpeed,
        false,
    )
    .unwrap();
    assert!(resolution.update);
    let descendants = second.document.derived_clocks().clone();
    let updated = edited(
        &service,
        &second,
        change(stage, ExactRatio::ONE, PitchPolicy::FollowSpeed, false),
    )
    .workspace
    .unwrap();
    assert_eq!(updated.document.derived_clocks(), &descendants);
    assert_eq!(updated.plan.duration().frames(), resolution.after.frames());
    assert!(updated.clocked_retimes.contains(stage));
}

#[test]
fn native_clocked_speed_uses_exact_input_and_preserves_history_and_policy_guards() {
    let scratch = tempfile::tempdir().unwrap();
    let path = scratch.path().join("exact-speed.deadpan");
    let mut store = seed_holds(&path, &[]);
    let slow = node("slow");
    let stage = BeatNode {
        kind: NodeKind::Retime {
            child: node("input"),
            duration: FrameDuration::new(24).unwrap(),
            mapping: FrameRange::new(ProjectFrame(0), ProjectFrame(12)).unwrap(),
            pitch: PitchPolicy::FollowSpeed,
            purpose: RetimePurpose::Edit,
        },
        ..BeatNode::sequence("Slow", vec![])
    };
    seed_command(
        &mut store,
        Command::Insert {
            parent: node("root"),
            index: 0,
            subtree: Subtree {
                root: node("group"),
                nodes: BTreeMap::from([
                    (
                        node("group"),
                        BeatNode::sequence("Group", vec![node("a"), slow.clone(), node("b")]),
                    ),
                    (node("a"), BeatNode::hold("Before", hold(2))),
                    (slow.clone(), stage),
                    (node("input"), BeatNode::hold("Input", hold(12))),
                    (node("b"), BeatNode::hold("After", hold(2))),
                ]),
                overrides: BTreeMap::new(),
                gap_overrides: BTreeMap::new(),
            },
        },
        "insert-speed-fixture",
    );
    drop(store);
    let service = ProjectService::new(Arc::new(|| {})).unwrap();
    let initial = command(&service, ProjectRequest::Open(path.clone()))
        .workspace
        .unwrap();
    let scope = SequenceScope::default()
        .descend(&initial, &node("group"))
        .unwrap();
    let paused = command(
        &service,
        edit_request_in(
            &initial,
            scope.clone(),
            ProjectFrame(5),
            ProjectEdit::InsertBlack {
                at: ProjectFrame(5),
                duration: FrameDuration::new(3).unwrap(),
            },
        ),
    );
    assert!(paused.error.is_none(), "{:?}", paused.error);
    let paused = paused.workspace.unwrap();
    let resolution = super::super::retime::resolve(
        &paused,
        &slow,
        ExactRatio::new(7, 8).unwrap(),
        PitchPolicy::FollowSpeed,
        false,
    )
    .unwrap();
    assert_eq!(resolution.input, ExactRatio::new(27, 2).unwrap());
    assert_eq!(
        (resolution.before.frames(), resolution.after.frames()),
        (27, 15)
    );
    assert!(
        resolution
            .describe(PitchPolicy::FollowSpeed)
            .contains("9/10×")
    );
    for pitch in [PitchPolicy::Preserve, PitchPolicy::Shift { semitones: 3 }] {
        assert!(
            super::super::retime::resolve(
                &paused,
                &slow,
                ExactRatio::new(7, 8).unwrap(),
                pitch,
                false
            )
            .is_err()
        );
        let refused = command(
            &service,
            edit_request_in(
                &paused,
                scope.clone(),
                ProjectFrame(5),
                change(&slow, ExactRatio::new(7, 8).unwrap(), pitch, false),
            ),
        );
        assert!(refused.error.is_some());
        assert!(refused.committed.is_none());
        assert_eq!(*refused.workspace.unwrap().document, *paused.document);
    }
    let updated = command(
        &service,
        edit_request_in(
            &paused,
            scope.clone(),
            ProjectFrame(5),
            change(
                &slow,
                ExactRatio::new(7, 8).unwrap(),
                PitchPolicy::FollowSpeed,
                false,
            ),
        ),
    );
    assert!(updated.error.is_none(), "{:?}", updated.error);
    let receipt = updated.committed.unwrap();
    assert_eq!(receipt.scope, scope);
    assert_eq!(receipt.selected_node, Some(slow.clone()));
    let updated = updated.workspace.unwrap();
    assert_eq!(updated.plan.duration().frames(), 19);
    assert_eq!(
        updated.document.derived_clocks()[&slow].child_end,
        ExactRatio::new(27, 2).unwrap()
    );
    for (id, clock) in paused.document.derived_clocks() {
        if id != &slow {
            assert_eq!(updated.document.derived_clocks().get(id), Some(clock));
        }
    }
    let unchanged = command(
        &service,
        edit_request_in(
            &updated,
            scope.clone(),
            ProjectFrame(5),
            change(
                &slow,
                ExactRatio::new(9, 10).unwrap(),
                PitchPolicy::FollowSpeed,
                false,
            ),
        ),
    );
    assert!(unchanged.error.is_none(), "{:?}", unchanged.error);
    assert!(unchanged.committed.is_none());
    assert_eq!(*unchanged.workspace.unwrap().document, *updated.document);
    let stale = command(
        &service,
        edit_request_in(
            &paused,
            scope.clone(),
            ProjectFrame(5),
            change(&slow, ExactRatio::ONE, PitchPolicy::FollowSpeed, false),
        ),
    );
    assert!(stale.error.is_some());
    assert_eq!(*stale.workspace.unwrap().document, *updated.document);
    let wrapped = command(
        &service,
        edit_request_in(
            &updated,
            scope.clone(),
            ProjectFrame(5),
            change(&slow, ExactRatio::ONE, PitchPolicy::FollowSpeed, true),
        ),
    );
    assert!(wrapped.error.is_none(), "{:?}", wrapped.error);
    assert_ne!(wrapped.committed.unwrap().selected_node, Some(slow.clone()));
    let wrapped = wrapped.workspace.unwrap();
    assert_eq!(
        wrapped.document.nodes()[&slow],
        updated.document.nodes()[&slow]
    );
    let unwrapped = command(
        &service,
        ProjectRequest::Undo {
            expected_revision: wrapped.document.revision_id().clone(),
        },
    )
    .workspace
    .unwrap();
    assert_eq!(unwrapped.document.nodes(), updated.document.nodes());
    command(&service, ProjectRequest::Close);
    let reopened = command(&service, ProjectRequest::Open(path))
        .workspace
        .unwrap();
    assert_eq!(
        reopened.document.derived_clocks(),
        updated.document.derived_clocks()
    );
    let undone = command(
        &service,
        ProjectRequest::Undo {
            expected_revision: reopened.document.revision_id().clone(),
        },
    )
    .workspace
    .unwrap();
    assert_eq!(undone.document.nodes(), paused.document.nodes());
    assert_eq!(
        undone.document.derived_clocks(),
        paused.document.derived_clocks()
    );
    assert_eq!(
        undone.document.audio_bindings(),
        paused.document.audio_bindings()
    );
    let redone = command(
        &service,
        ProjectRequest::Redo {
            expected_revision: undone.document.revision_id().clone(),
        },
    )
    .workspace
    .unwrap();
    assert_eq!(redone.document.nodes(), updated.document.nodes());
    assert_eq!(
        redone.document.derived_clocks(),
        updated.document.derived_clocks()
    );
    assert_eq!(
        redone.document.audio_bindings(),
        updated.document.audio_bindings()
    );
}
