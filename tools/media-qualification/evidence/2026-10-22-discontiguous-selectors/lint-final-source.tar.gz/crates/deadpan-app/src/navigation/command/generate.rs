use deadpan_jobs::{
    GenerationModePreference, GenerationOptions, GenerationTarget, HoldInstructions,
};

use super::Entry;
use crate::navigation::{Action, AiAction};

pub(super) fn parse(argument: Option<&str>) -> Result<Entry, String> {
    let usage = "Use :generate [1-4] [mode=auto|bridge|extend-left|extend-right] [motion=still|subtle|moderate] [target=ID|none] [text=guidance]. Put text last. Omitted target retains the captured target.";
    let mut rest = argument.unwrap_or("").trim();
    let mut variants = 1;
    let mut controls = GenerationOptions::default();
    let mut count_seen = false;
    let mut mode_seen = false;
    let mut motion_seen = false;
    let mut target_seen = false;
    let mut explicit = false;
    while !rest.is_empty() {
        if let Some(text) = rest.strip_prefix("text=") {
            controls.instructions =
                Some(HoldInstructions::new(text).map_err(|error| error.to_string())?);
            explicit = true;
            break;
        }
        let (word, tail) = rest.split_once(char::is_whitespace).unwrap_or((rest, ""));
        if let Some(mode) = word.strip_prefix("mode=") {
            if mode_seen {
                return Err(usage.into());
            }
            controls.mode = match mode {
                "auto" => GenerationModePreference::Automatic,
                "bridge" => GenerationModePreference::Bridge,
                "extend-left" => GenerationModePreference::ExtendFromLeft,
                "extend-right" => GenerationModePreference::ExtendFromRight,
                _ => return Err(usage.into()),
            };
            mode_seen = true;
            explicit = true;
        } else if let Some(motion) = word.strip_prefix("motion=") {
            if motion_seen {
                return Err(usage.into());
            }
            controls.motion = motion.parse().map_err(str::to_owned)?;
            motion_seen = true;
            explicit = true;
        } else if let Some(target) = word.strip_prefix("target=") {
            if target_seen {
                return Err(usage.into());
            }
            controls.region_target = GenerationTarget::parse(target)?;
            target_seen = true;
            explicit = true;
        } else {
            if count_seen || explicit {
                return Err(usage.into());
            }
            variants = word
                .parse::<u8>()
                .ok()
                .filter(|count| (1..=crate::project::generation::MAX_VARIANTS).contains(count))
                .ok_or(usage)?;
            count_seen = true;
        }
        rest = tail.trim_start();
    }
    Ok(if explicit {
        Entry::Generate {
            variants,
            options: controls,
        }
    } else {
        Entry::Action(Action::Ai(AiAction::Generate { variants }))
    })
}

/// A complete, editable command. Omitting text clears old guidance when run.
pub(crate) fn command(options: &GenerationOptions) -> String {
    let mode = match options.mode {
        GenerationModePreference::Automatic => "auto",
        GenerationModePreference::Bridge => "bridge",
        GenerationModePreference::ExtendFromLeft => "extend-left",
        GenerationModePreference::ExtendFromRight => "extend-right",
    };
    let mut command = format!("generate mode={mode} motion={}", options.motion.name());
    match &options.region_target {
        // The controls editor captures the displayed absence explicitly.
        GenerationTarget::Inherit | GenerationTarget::None => command.push_str(" target=none"),
        GenerationTarget::Saved(target) => command.push_str(&format!(" target={target}")),
    }
    if let Some(text) = &options.instructions {
        command.push_str(" text=");
        command.push_str(text.as_str());
    }
    command
}

#[cfg(test)]
mod tests {
    use super::*;
    use deadpan_jobs::MotionAmount;

    #[test]
    fn controls_preserve_plain_text_and_round_trip_prefills() {
        let options = GenerationOptions {
            mode: deadpan_jobs::GenerationModePreference::Automatic,
            motion: MotionAmount::Subtle,
            instructions: Some(
                HoldInstructions::new("Keep eyes open, 目線 unchanged. motion=still is text")
                    .unwrap(),
            ),
            region_target: GenerationTarget::Saved(deadpan_core::TargetId::new("subject").unwrap()),
        };
        assert_eq!(
            super::super::parse(&command(&options)).unwrap(),
            Entry::Generate {
                variants: 1,
                options: options.clone()
            }
        );
        assert_eq!(
            parse(Some("3 motion=subtle text=Keep hands still.")).unwrap(),
            Entry::Generate {
                variants: 3,
                options: GenerationOptions {
                    mode: deadpan_jobs::GenerationModePreference::Automatic,
                    motion: MotionAmount::Subtle,
                    instructions: Some(HoldInstructions::new("Keep hands still.").unwrap()),
                    region_target: GenerationTarget::Inherit,
                }
            }
        );
        assert_eq!(
            parse(Some("motion=still")).unwrap(),
            Entry::Generate {
                variants: 1,
                options: GenerationOptions::default()
            }
        );
        for text in [
            "0",
            "5",
            "motion=fast",
            "motion=still motion=subtle",
            "mode=",
            "mode=automatic",
            "mode=extend",
            "mode=bridge mode=auto",
            "mode=auto 2",
            "text=",
            "2 3",
            "motion=still 2",
            "text=a\tb",
            "target=",
            "target=one target=two",
        ] {
            assert!(parse(Some(text)).is_err(), "{text}");
        }
        assert!(parse(Some(&format!("text={}", "界".repeat(171)))).is_err());
        assert_eq!(
            parse(None).unwrap(),
            Entry::Action(Action::Ai(AiAction::Generate { variants: 1 }))
        );
        assert_eq!(
            parse(Some("target=none")).unwrap(),
            Entry::Generate {
                variants: 1,
                options: GenerationOptions {
                    region_target: GenerationTarget::None,
                    ..GenerationOptions::default()
                }
            }
        );
    }

    #[test]
    fn every_mode_round_trips_without_consuming_guidance() {
        for (text, mode) in [
            ("auto", GenerationModePreference::Automatic),
            ("bridge", GenerationModePreference::Bridge),
            ("extend-left", GenerationModePreference::ExtendFromLeft),
            ("extend-right", GenerationModePreference::ExtendFromRight),
        ] {
            let options = GenerationOptions {
                mode,
                motion: MotionAmount::Moderate,
                instructions: Some(
                    HoldInstructions::new("Keep 手 still. mode=bridge is guidance.").unwrap(),
                ),
                region_target: GenerationTarget::None,
            };
            assert_eq!(
                parse(Some(&format!(
                    "4 target=none motion=moderate mode={text} text=Keep 手 still. mode=bridge is guidance."
                )))
                .unwrap(),
                Entry::Generate {
                    variants: 4,
                    options: options.clone(),
                },
            );
            assert_eq!(
                super::super::parse(&command(&options)).unwrap(),
                Entry::Generate {
                    variants: 1,
                    options,
                },
            );
            assert_eq!(
                parse(Some(&format!("mode={text}"))).unwrap(),
                Entry::Generate {
                    variants: 1,
                    options: GenerationOptions {
                        mode,
                        ..GenerationOptions::default()
                    },
                },
            );
        }
    }
}
