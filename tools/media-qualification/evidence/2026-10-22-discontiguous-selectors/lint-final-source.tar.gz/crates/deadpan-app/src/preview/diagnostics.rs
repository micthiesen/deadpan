//! The Diagnostics panel: live, process-local performance counters
//! (specification Section 25.3) beside the picture.
//!
//! `:diagnostics` opens it; Escape or Close closes it. It never pauses
//! playback, so delivery, queue and GPU counters keep moving while it is
//! open. Values are sampled twice a second, not every frame, and each row is
//! exposed to assistive technology as "label: value". Nothing shown here is
//! authored state, history or project data.

use std::sync::{Arc, mpsc};
use std::time::{Duration, Instant};

use deadpan_diagnostics::{
    CacheSnapshot, IoSnapshot, Level, ProcessMemorySnapshot, SqlitePageTotals, WorkerMemorySnapshot,
};

use super::*;

/// Sampling period while the panel is open.
pub(super) const REFRESH: Duration = Duration::from_millis(500);

/// One sampled moment of every counter the app process can observe.
#[derive(Clone, Copy)]
pub(super) struct Sample {
    pub(super) at: Instant,
    pub(super) counters: deadpan_diagnostics::Snapshot,
    pub(super) playback: deadpan_playback::Diagnostics,
    pub(super) saved_audio: Option<deadpan_audio::SavedAudioStatus>,
    /// Outer UI updates since the app started.
    pub(super) frames: u64,
}

/// One formatted row: section, label, value and its accessible text.
pub(super) type Row = (&'static str, &'static str, String, String);

#[derive(Default)]
pub(super) struct State {
    pub(super) open: bool,
    focus_pending: bool,
    return_focus: Option<(u64, Pane)>,
    /// Outer UI frames, counted once per frame (never per layout retry).
    frames: u64,
    pub(super) latest: Option<Sample>,
    previous: Option<Sample>,
    /// Samples taken since the panel opened.
    pub(super) refreshes: u64,
    /// Rows formatted once per sample, not on every painted frame.
    formatted: Vec<Row>,
    /// Capture the exact committed snapshot when the save action starts.
    export_document: Option<Option<Arc<deadpan_core::ProjectDocument>>>,
    exporting: Option<mpsc::Receiver<Result<deadpan_cli::diagnostic_export::Receipt, String>>>,
    pub(super) export_status: Option<String>,
}

impl State {
    pub(super) fn count_frame(&mut self) {
        self.frames += 1;
    }
}

fn binary_bytes(bytes: u64) -> String {
    const UNITS: [&str; 4] = ["KiB", "MiB", "GiB", "TiB"];
    if bytes < 1024 {
        return format!("{bytes} B");
    }
    let mut value = bytes as f64 / 1024.0;
    let mut unit = 0;
    while value >= 1024.0 && unit + 1 < UNITS.len() {
        value /= 1024.0;
        unit += 1;
    }
    format!("{value:.1} {}", UNITS[unit])
}

fn level(value: Level) -> String {
    format!("{} now · {} high", value.current, value.high)
}

fn io(value: IoSnapshot) -> String {
    if value == IoSnapshot::default() {
        return "none yet".into();
    }
    format!(
        "read {} in {} · wrote {} in {}",
        binary_bytes(value.read_bytes),
        value.read_ops,
        binary_bytes(value.write_bytes),
        value.write_ops
    )
}

fn cache(value: CacheSnapshot, bytes: bool) -> String {
    let mut text = format!(
        "{} ({} / {}) · {} evicted · {} resident ({} high)",
        rate(value.hits, value.hits + value.misses),
        value.hits,
        value.hits + value.misses,
        value.evictions,
        value.entries.current,
        value.entries.high
    );
    if bytes {
        text.push_str(&format!(
            " · {} ({} high)",
            binary_bytes(value.bytes.current),
            binary_bytes(value.bytes.high)
        ));
    }
    text
}

fn rate(hits: u64, lookups: u64) -> String {
    if lookups == 0 {
        "no lookups".to_owned()
    } else {
        format!("{:.0}% hits", hits as f64 * 100.0 / lookups as f64)
    }
}

/// A cache whose residency is not tracked here (the shared proxy cache).
fn lookups(value: CacheSnapshot) -> String {
    format!(
        "{} ({} / {}) · {} evicted",
        rate(value.hits, value.hits + value.misses),
        value.hits,
        value.hits + value.misses,
        value.evictions
    )
}

fn pages(value: SqlitePageTotals) -> String {
    if value == SqlitePageTotals::default() {
        return "none yet".into();
    }
    format!(
        "{} ({} / {}) · {} read · {} written",
        rate(value.hits, value.hits + value.misses),
        value.hits,
        value.hits + value.misses,
        value.misses,
        value.writes
    )
}

fn process(value: ProcessMemorySnapshot) -> String {
    if value.samples == 0 {
        return if value.failures == 0 {
            "not sampled".into()
        } else {
            format!("{} samples refused", value.failures)
        };
    }
    format!(
        "{} now · {} peak · includes Metal",
        binary_bytes(value.footprint_bytes.current),
        binary_bytes(value.footprint_bytes.high)
    )
}

fn workers(value: WorkerMemorySnapshot) -> String {
    if value.live.high == 0 {
        return "none has run in this session".into();
    }
    let mut text = format!(
        "{} live · {} now · {} peak",
        value.live.current,
        binary_bytes(value.footprint_bytes.current),
        binary_bytes(value.footprint_bytes.high)
    );
    if value.failures != 0 {
        text.push_str(&format!(" · {} samples refused", value.failures));
    }
    text
}

fn micros(value: u64) -> String {
    if value >= 1000 {
        format!("{:.1} ms", value as f64 / 1000.0)
    } else {
        format!("{value} µs")
    }
}

/// The panel's rows as (section, label, value).
pub(super) fn rows(
    sample: &Sample,
    previous: Option<&Sample>,
) -> Vec<(&'static str, &'static str, String)> {
    let counters = &sample.counters;
    let playback = &sample.playback;
    let gpu = counters.gpu;
    let mut rows = vec![
        (
            "PLAYBACK",
            "Underruns",
            format!(
                "{} starved of {} device reports",
                playback.starved, playback.reports
            ),
        ),
        ("PLAYBACK", "Device faults", playback.faults.to_string()),
        (
            "PLAYBACK",
            "Silent padding",
            format!("{} frames", playback.silent_frames),
        ),
        (
            "PLAYBACK",
            "Callback render cost",
            format!("{} max", micros(playback.max_render_cost_ns / 1000)),
        ),
        ("PLAYBACK", "Generations", playback.generations.to_string()),
        ("PLAYBACK", "Pictures", {
            let pictures = counters.playback_pictures;
            format!(
                "{} requested · {} dropped · {} exact · {} proxy",
                pictures.requested, pictures.skipped, pictures.exact, pictures.reduced
            )
        }),
        (
            "PLAYBACK",
            "Repositions",
            format!(
                "{} started · {} reached · {} failed",
                counters.playback_pictures.repositions,
                counters.playback_pictures.repositions_reached,
                counters.playback_pictures.repositions_failed
            ),
        ),
        (
            "PLAYBACK",
            "Look-ahead",
            format!(
                "{} started · {} reached · {} swapped at cuts · {} failed",
                counters.playback_pictures.lookahead_started,
                counters.playback_pictures.lookahead_reached,
                counters.playback_pictures.lookahead_swaps,
                counters.playback_pictures.lookahead_failed
            ),
        ),
        (
            "DECODE QUEUES",
            "Picture preview",
            level(counters.queues.picture_preview),
        ),
        (
            "DECODE QUEUES",
            "Card thumbnails",
            level(counters.queues.thumbnails),
        ),
        (
            "DECODE QUEUES",
            "Endpoint pictures",
            level(counters.queues.endpoint_pictures),
        ),
        (
            "DECODE QUEUES",
            "Waveforms",
            level(counters.queues.waveforms),
        ),
        (
            "DECODE QUEUES",
            "Prepared audio",
            level(counters.queues.playback_prepared),
        ),
        (
            "DECODE QUEUES",
            "Prepared audio frames",
            level(counters.queues.playback_prepared_frames),
        ),
        (
            "DECODE QUEUES",
            "Device packets",
            level(counters.queues.playback_device_packets),
        ),
        (
            "DECODE QUEUES",
            "Last prefill",
            format!("{} frames", counters.queues.playback_prefill_frames.current),
        ),
        (
            "GPU",
            "Submissions",
            format!(
                "{} submitted · {} completed",
                gpu.submissions, gpu.completions
            ),
        ),
        (
            "GPU",
            "Completion latency",
            match (gpu.p50_us, gpu.p95_us) {
                (Some(p50), Some(p95)) => format!(
                    "last {} · p50 {} · p95 {} · max {}",
                    micros(gpu.last_us),
                    micros(p50),
                    micros(p95),
                    micros(gpu.max_us)
                ),
                _ => "no completed submission".into(),
            },
        ),
        (
            "PCM CACHES",
            "Decoded sources",
            cache(counters.caches.decoded_pcm, true),
        ),
        (
            "PCM CACHES",
            "Limiter tiles",
            cache(counters.caches.limiter_tiles, false),
        ),
        (
            "PCM CACHES",
            "Limiter inputs",
            cache(counters.caches.limiter_inputs, true),
        ),
    ];
    rows.push((
        "PCM CACHES",
        "Saved stretch",
        sample.saved_audio.map_or_else(
            || "not requested in this transport".into(),
            |status| {
                let mut text = format!("{} · {}", status.event.label(), binary_bytes(status.bytes));
                if let Some(reason) = status.regenerated_from {
                    text.push_str(&format!(" · rebuilt: {}", reason.label()));
                }
                text
            },
        ),
    ));
    if let Some(key) = sample.saved_audio.and_then(|status| status.key) {
        let key: String = key.iter().map(|byte| format!("{byte:02x}")).collect();
        rows.push(("PCM CACHES", "Audio cache key", format!("blake3:{key}")));
    }
    rows.push((
        "PICTURE CACHES",
        "Thumbnail textures",
        cache(counters.caches.thumbnails, false),
    ));
    rows.push((
        "PICTURE CACHES",
        "Preview proxies",
        lookups(counters.caches.proxies),
    ));
    for (name, label) in [
        // Each row names exactly what it counts; other file I/O is not
        // counted (see docs/PERFORMANCE.md#diagnostics).
        ("store_revisions", "Store history rows"),
        ("objects", "Media objects"),
        ("media_snapshots", "Media snapshots"),
        ("decoder_input", "Video decoder reads"),
        ("audio_decoder_input", "Audio decoder reads"),
        ("pcm_cache_file", "PCM cache file"),
        ("proxy", "Proxy hashing reads"),
    ] {
        let value = counters
            .io
            .paths()
            .into_iter()
            .find(|(path, _)| *path == name)
            .map(|(_, value)| value)
            .unwrap_or_default();
        rows.push(("FILE I/O", label, io(value)));
    }
    rows.push(("FILE I/O", "SQLite pages", pages(counters.sqlite_pages)));
    rows.push(("MEMORY", "App process", process(counters.process_memory)));
    rows.push(("MEMORY", "Model workers", workers(counters.model_workers)));
    rows.push(("MEMORY", "Other workers", workers(counters.other_workers)));
    let rate = previous
        .map(|previous| {
            let seconds = sample
                .at
                .saturating_duration_since(previous.at)
                .as_secs_f64();
            if seconds > 0.0 {
                format!(
                    " · {:.1}/s",
                    (sample.frames - previous.frames) as f64 / seconds
                )
            } else {
                String::new()
            }
        })
        .unwrap_or_default();
    // Every outer update counts, including those this panel's own refresh
    // requests, so the rate while open is not an idle measurement.
    rows.push((
        "UI",
        "UI updates",
        format!("{} since start{rate} (includes this panel)", sample.frames),
    ));
    rows
}

/// [`rows`] with each row's accessible "label: value" text.
fn formatted(sample: &Sample, previous: Option<&Sample>) -> Vec<Row> {
    rows(sample, previous)
        .into_iter()
        .map(|(section, label, value)| {
            let spoken = format!("{label}: {value}");
            (section, label, value, spoken)
        })
        .collect()
}

impl DeadpanApp {
    pub(super) fn open_diagnostics(&mut self, context: &egui::Context) {
        self.bindings.clear();
        self.diagnostics.open = true;
        self.diagnostics.focus_pending = true;
        self.diagnostics.refreshes = 0;
        self.diagnostics.previous = None;
        self.diagnostics.latest = None;
        self.sample_diagnostics();
        context.request_repaint();
    }

    fn close_diagnostics(&mut self, context: &egui::Context) {
        self.diagnostics.open = false;
        self.diagnostics.focus_pending = false;
        self.diagnostics.return_focus = Some((context.cumulative_frame_nr(), self.pane));
        context.request_discard("diagnostics closed");
        context.request_repaint();
    }

    fn sample_diagnostics(&mut self) {
        deadpan_cli::diagnostic_export::sample_process_memory();
        let sample = Sample {
            at: Instant::now(),
            counters: deadpan_diagnostics::snapshot(),
            playback: self.playback.diagnostics(),
            saved_audio: self.playback.saved_audio_status(),
            frames: self.diagnostics.frames,
        };
        self.diagnostics.previous = self.diagnostics.latest.replace(sample);
        self.diagnostics.formatted = formatted(&sample, self.diagnostics.previous.as_ref());
        self.diagnostics.refreshes += 1;
    }

    /// Count the outer frame and, while open, resample at [`REFRESH`].
    /// Call once per outer frame, never on a layout retry.
    pub(super) fn reconcile_diagnostics(&mut self, context: &egui::Context) {
        self.diagnostics.count_frame();
        if let Some(receiver) = &self.diagnostics.exporting {
            let result = match receiver.try_recv() {
                Ok(result) => Some(result),
                Err(mpsc::TryRecvError::Empty) => None,
                Err(mpsc::TryRecvError::Disconnected) => Some(Err(
                    "Diagnostic export stopped before reporting a result.".into(),
                )),
            };
            if let Some(result) = result {
                self.diagnostics.exporting = None;
                let status = match result {
                    Ok(receipt) => format!(
                        "Saved {} bytes. No media or user content attached.",
                        receipt.byte_length
                    ),
                    Err(error) => error,
                };
                self.message = Some(status.clone());
                self.diagnostics.export_status = Some(status);
            }
        }
        if !self.diagnostics.open {
            return;
        }
        let due = self.diagnostics.latest.map_or(Duration::ZERO, |sample| {
            REFRESH.saturating_sub(sample.at.elapsed())
        });
        if due.is_zero() {
            self.sample_diagnostics();
            context.request_repaint_after(REFRESH);
        } else {
            context.request_repaint_after(due);
        }
    }

    /// The panel owns the keyboard while open: editor bindings never see keys,
    /// Tab and Space/Enter stay native, and Escape closes it.
    pub(super) fn diagnostics_keyboard(&mut self, context: &egui::Context) -> bool {
        if let Some((frame, pane)) = self.diagnostics.return_focus
            && context.cumulative_frame_nr() > frame
        {
            context.memory_mut(|memory| memory.request_focus(pane_id(pane)));
            self.diagnostics.return_focus = None;
        }
        if !self.diagnostics.open {
            return false;
        }
        let composing = &mut self.ime_composing;
        context.input(|input| help_scroll::observe_composition(&input.events, composing));
        self.bindings.clear();
        true
    }

    pub(super) fn diagnostics_window(&mut self, context: &egui::Context) {
        if !self.diagnostics.open {
            return;
        }
        if self.diagnostics.latest.is_none() {
            return;
        }
        // Borrow the rows formatted at the last sample; restored below.
        let rows = std::mem::take(&mut self.diagnostics.formatted);
        let content = context.content_rect();
        let width = (content.width() - 32.0).clamp(280.0, 380.0);
        // Header, sheet chrome and the footer stay outside the scroller, so
        // the sheet ends above the window's bottom edge.
        let height = (content.height() - 340.0).max(100.0);
        let mut close = false;
        let mut export = false;
        // Anchored beside the picture with no dimming: the picture stays
        // dominant and playback continues underneath.
        let modal = egui::Modal::new(egui::Id::new("diagnostics-window"))
            .backdrop_color(egui::Color32::TRANSPARENT)
            .area(
                egui::Modal::default_area(egui::Id::new("diagnostics-window"))
                    .anchor(egui::Align2::RIGHT_TOP, egui::vec2(-16.0, 56.0)),
            )
            .show(context, |ui| {
                accessibility::dialog(ui, "Diagnostics");
                ui.set_width(width);
                ui.label(style::section_title("DIAGNOSTICS", true));
                ui.label(
                    egui::RichText::new(
                        "Live counters for this app process only; file I/O rows cover the named paths, not all I/O. They are never saved with the project.",
                    )
                    .size(11.5)
                    .weak(),
                );
                ui.add_space(4.0);
                egui::ScrollArea::vertical()
                    .id_salt("diagnostics-rows")
                    .max_height(height)
                    .auto_shrink([false, true])
                    .show(ui, |ui| {
                        let mut start = 0;
                        while start < rows.len() {
                            let heading = rows[start].0;
                            let end = rows[start..]
                                .iter()
                                .position(|row| row.0 != heading)
                                .map_or(rows.len(), |offset| start + offset);
                            if start != 0 {
                                ui.add_space(6.0);
                            }
                            ui.label(style::section_title(heading, false));
                            egui::Grid::new(("diagnostics-section", heading))
                                .num_columns(2)
                                .min_col_width(118.0)
                                .spacing(egui::vec2(10.0, 3.0))
                                .min_row_height(16.0)
                                .show(ui, |ui| {
                                    for (_, label, value, spoken) in &rows[start..end] {
                                        ui.label(egui::RichText::new(*label).size(12.0).weak());
                                        let response = ui.add(
                                            egui::Label::new(
                                                egui::RichText::new(value).monospace().size(11.5),
                                            )
                                            .wrap(),
                                        );
                                        accessibility::full_text(response, spoken);
                                        ui.end_row();
                                    }
                                });
                            start = end;
                        }
                    });
                ui.add_space(6.0);
                ui.label(egui::RichText::new("Export versions, counters and structural error context. Excludes media, names, paths, URLs, transcripts and credentials.").size(11.0).weak());
                export = ui.add_enabled(
                    !self.dialogs.is_open() && self.diagnostics.exporting.is_none(),
                    egui::Button::new("Save diagnostic report…"),
                ).clicked();
                if let Some(status) = &self.diagnostics.export_status {
                    ui.label(egui::RichText::new(status).size(11.0));
                }
                ui.horizontal(|ui| {
                    let button = ui.add(style::action("Close", "Esc"));
                    if std::mem::take(&mut self.diagnostics.focus_pending) {
                        button.request_focus();
                    }
                    if button.clicked() {
                        close = true;
                    }
                    ui.label(
                        egui::RichText::new("Updates twice a second")
                            .size(11.0)
                            .weak(),
                    );
                });
            });
        self.diagnostics.formatted = rows;
        if export {
            self.diagnostics.export_document = Some(
                self.workspace
                    .as_ref()
                    .map(|workspace| Arc::clone(&workspace.document)),
            );
            match self.dialogs.start(DialogKind::DiagnosticReport, context) {
                Ok(()) => self.diagnostics.export_status = None,
                Err(error) => {
                    self.diagnostics.export_document = None;
                    self.diagnostics.export_status = Some(error);
                }
            }
        }
        close |= modal.should_close() && !self.ime_composing;
        if close {
            self.close_diagnostics(context);
        }
    }

    pub(super) fn receive_diagnostic_dialog(
        &mut self,
        path: Option<PathBuf>,
        error: Option<String>,
        context: &egui::Context,
    ) {
        let captured = self.diagnostics.export_document.take();
        if let Some(error) = error {
            self.diagnostics.export_status = Some(error);
            return;
        }
        let Some(path) = path else {
            return;
        };
        let Some(document) = captured else {
            self.diagnostics.export_status =
                Some("Diagnostic export has no captured snapshot; start the save again.".into());
            return;
        };
        let (sender, receiver) = mpsc::sync_channel(1);
        let context = context.clone();
        match std::thread::Builder::new()
            .name("deadpan-diagnostic-export".into())
            .spawn(move || {
                let result = deadpan_cli::diagnostic_export::DiagnosticReport::from_document(
                    document.as_deref(),
                )
                .write(&path)
                .map_err(|error| format!("{} ({})", error, error.code()));
                let _ = sender.send(result);
                context.request_repaint();
            }) {
            Ok(_) => {
                self.diagnostics.exporting = Some(receiver);
                self.diagnostics.export_status = Some("Saving diagnostic report…".into());
            }
            Err(_) => {
                self.diagnostics.export_status =
                    Some("Could not start diagnostic export; try again.".into())
            }
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn values_read_as_units_and_rates() {
        assert_eq!(binary_bytes(512), "512 B");
        assert_eq!(binary_bytes(1536), "1.5 KiB");
        assert_eq!(binary_bytes(3 * 1024 * 1024 * 1024), "3.0 GiB");
        assert_eq!(micros(850), "850 µs");
        assert_eq!(micros(2_500), "2.5 ms");
        assert_eq!(
            level(Level {
                current: 1,
                high: 2
            }),
            "1 now · 2 high"
        );
        assert_eq!(io(IoSnapshot::default()), "none yet");
        assert_eq!(
            io(IoSnapshot {
                read_ops: 2,
                read_bytes: 2048,
                write_ops: 1,
                write_bytes: 10
            }),
            "read 2.0 KiB in 2 · wrote 10 B in 1"
        );
        assert_eq!(
            workers(WorkerMemorySnapshot::default()),
            "none has run in this session"
        );
        let sample = Sample {
            at: Instant::now(),
            counters: deadpan_diagnostics::Snapshot::default(),
            playback: deadpan_playback::Diagnostics::default(),
            saved_audio: None,
            frames: 30,
        };
        let earlier = Sample {
            at: sample.at - Duration::from_secs(1),
            frames: 28,
            ..sample
        };
        let saved = Sample {
            saved_audio: Some(deadpan_audio::SavedAudioStatus {
                key: Some([0x12; 32]),
                bytes: 8192,
                event: deadpan_audio::SavedAudioEvent::Saved,
                regenerated_from: Some(deadpan_audio::SavedAudioEvent::Damaged),
            }),
            ..sample
        };
        let saved_rows = rows(&saved, None);
        assert!(
            saved_rows
                .iter()
                .any(|(_, label, value)| *label == "Saved stretch"
                    && value == "saved · 8.0 KiB · rebuilt: damaged cache")
        );
        assert!(
            saved_rows
                .iter()
                .any(|(_, label, value)| *label == "Audio cache key"
                    && value == &format!("blake3:{}", "12".repeat(32)))
        );
        let rows = rows(&sample, Some(&earlier));
        assert!(rows.iter().any(|(_, label, value)| *label == "UI updates"
            && value == "30 since start · 2.0/s (includes this panel)"));
        assert!(rows.iter().any(
            |(_, label, value)| *label == "Decoded sources" && value.starts_with("no lookups")
        ));
        assert!(
            rows.iter()
                .any(|(_, label, value)| *label == "Completion latency"
                    && value == "no completed submission")
        );
        for (label, value) in [
            ("SQLite pages", "none yet"),
            ("App process", "not sampled"),
            ("Preview proxies", "no lookups (0 / 0) · 0 evicted"),
            ("Endpoint pictures", "0 now · 0 high"),
            ("Waveforms", "0 now · 0 high"),
            ("Audio decoder reads", "none yet"),
        ] {
            assert!(
                rows.iter().any(|row| row.1 == label && row.2 == value),
                "{label}"
            );
        }
        let mut counters = deadpan_diagnostics::Snapshot {
            sqlite_pages: deadpan_diagnostics::SqlitePageTotals {
                hits: 3,
                misses: 1,
                writes: 2,
                spills: 0,
            },
            ..Default::default()
        };
        counters.process_memory.samples = 1;
        counters.process_memory.footprint_bytes = Level {
            current: 2048,
            high: 4096,
        };
        counters.caches.proxies.hits = 1;
        counters.caches.proxies.misses = 1;
        let active = rows_for(counters);
        for (label, value) in [
            ("SQLite pages", "75% hits (3 / 4) · 1 read · 2 written"),
            ("App process", "2.0 KiB now · 4.0 KiB peak · includes Metal"),
            ("Preview proxies", "50% hits (1 / 2) · 0 evicted"),
        ] {
            assert!(
                active.iter().any(|row| row.1 == label && row.2 == value),
                "{label}: {active:?}"
            );
        }
    }

    fn rows_for(
        counters: deadpan_diagnostics::Snapshot,
    ) -> Vec<(&'static str, &'static str, String)> {
        rows(
            &Sample {
                at: Instant::now(),
                counters,
                playback: deadpan_playback::Diagnostics::default(),
                saved_audio: None,
                frames: 0,
            },
            None,
        )
    }
}
