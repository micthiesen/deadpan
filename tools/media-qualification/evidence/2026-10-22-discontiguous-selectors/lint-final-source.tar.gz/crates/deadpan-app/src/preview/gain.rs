//! Captured, reversible native gain drafts and same-window comparisons.

use deadpan_core::{AudioSample, AudioTreatments, GainDb};
use deadpan_playback::{Snapshot, Window};

use super::*;
use crate::gain::GainEdit;
use crate::project::gain::{Proposal, ProposalId, ProposalUpdate, Target};
use crate::transport::Domain;

mod controls;
mod waveform;
use controls::FocusReveal;

const FOCUS_ID: &str = "gain-draft-focus";

#[derive(Clone, Copy, PartialEq, Eq)]
enum Choice {
    Before,
    Draft,
}

#[derive(Clone, Copy)]
enum DraftAction {
    Apply,
    Cancel,
    Play,
    Restart,
    Choose(Choice),
}

pub(super) struct Draft {
    target: Target,
    base: Arc<Snapshot>,
    token: u64,
    change: u64,
    edit: GainEdit,
    controls: controls::Controls,
    waveform: waveform::Display,
    pending: Option<ProposalId>,
    requested: Option<u64>,
    prepared: Option<Arc<Snapshot>>,
    error: Option<String>,
    domain: Domain,
    window: Window,
    pub(super) position: AudioSample,
    choice: Choice,
    label: String,
    source_cursor: u64,
    pane: Pane,
    key: Option<DraftAction>,
    focus_pending: bool,
    cancel_focus: Option<egui::Id>,
    applying: bool,
}

impl Draft {
    pub(super) fn editor_name(&self) -> &'static str {
        if self.controls.equalizer_mode {
            "EQ"
        } else {
            "Gain"
        }
    }

    #[cfg(feature = "ui-harness")]
    pub(super) fn prepared_snapshot(&self) -> Option<&Arc<Snapshot>> {
        self.prepared.as_ref()
    }

    #[cfg(feature = "ui-harness")]
    pub(super) fn window(&self) -> Window {
        self.window
    }

    #[cfg(feature = "ui-harness")]
    pub(super) fn waveform_state(
        &self,
    ) -> (
        Option<deadpan_playback::WaveformTicket>,
        deadpan_playback::WaveformStatus,
        Option<&Arc<deadpan_audio::DefinitionWaveform>>,
    ) {
        (
            self.waveform.ticket,
            self.waveform.status,
            self.waveform.data.as_ref(),
        )
    }

    #[cfg(feature = "ui-harness")]
    pub(super) fn receive_waveform_for_check(&mut self, update: deadpan_playback::WaveformUpdate) {
        self.waveform.receive(&self.target, update);
    }

    fn proposal(&self) -> Proposal {
        Proposal {
            target: self.target.clone(),
            draft: self.token,
            change: self.change,
            treatments: self.edit.recipe().clone(),
        }
    }

    fn receive(&mut self, update: ProposalUpdate) {
        if self.pending.as_ref() != Some(&update.id) {
            return;
        }
        self.pending = None;
        if update.id != self.proposal().id() {
            return;
        }
        match update.result {
            Ok(snapshot)
                if snapshot.session == self.target.session
                    && snapshot.document.project_id() == &self.target.project
                    && snapshot.content
                        == (deadpan_playback::ContentIdentity::Proposed {
                            base_revision: self.target.revision.clone(),
                            draft: self.token,
                            change: self.change,
                        }) =>
            {
                self.prepared = Some(snapshot);
                self.error = None;
            }
            Ok(_) => {
                self.prepared = None;
                self.error = Some("Prepared gain content did not match this draft.".into());
            }
            Err(error) => {
                self.prepared = None;
                self.error = Some(error);
            }
        }
    }

    fn changed(&mut self) -> Result<(), String> {
        self.change = self
            .change
            .checked_add(1)
            .ok_or("Gain draft change identities exhausted.")?;
        self.prepared = None;
        self.error = None;
        Ok(())
    }

    fn selected_snapshot(&self) -> Option<Arc<Snapshot>> {
        match self.choice {
            Choice::Before => Some(self.base.clone()),
            Choice::Draft => self.prepared.clone(),
        }
    }
}

/// A captured gain target that is a whole beat (or an Edit range inside it)
/// in the current group rather than one play inside a Repeat.
pub(super) fn whole_beat(target: &Option<Result<Target, String>>) -> bool {
    matches!(target, Some(Ok(target)) if target.scoped.is_none())
}

/// A whole-owner audio change may resolve one explicitly chosen play at
/// every Repeat level. Callers must also require no Visual selection.
pub(super) fn semantic_step_target(target: &Option<Result<Target, String>>) -> bool {
    matches!(target, Some(Ok(target)) if target.scoped.as_ref().is_none_or(|scope| scope.has_single_play_authority()))
}

/// Whole-owner setters share one-play authority; ranges and sends do not.
pub(super) fn scoped_audio_change(change: &deadpan_core::AudioChange) -> bool {
    matches!(
        change,
        deadpan_core::AudioChange::Step { .. }
            | deadpan_core::AudioChange::Mute { .. }
            | deadpan_core::AudioChange::Trim { .. }
            | deadpan_core::AudioChange::Saturation { .. }
            | deadpan_core::AudioChange::Balance { .. }
            | deadpan_core::AudioChange::Equalizer { .. }
    )
}

impl DeadpanApp {
    pub(super) fn gain_render_edit(&self) -> Result<Option<super::render::PreviewEdit>, String> {
        let draft = self
            .gain
            .as_ref()
            .ok_or("Audio preview is no longer open.")?;
        self.check_gain_target(&draft.target)?;
        if draft.applying || draft.prepared.is_none() || !draft.controls.ready(&draft.edit) {
            return Err(draft.error.clone().unwrap_or_else(|| {
                format!(
                    "Finish and prepare the {} preview before committing it.",
                    draft.editor_name()
                )
            }));
        }
        if draft.target.entry == *draft.edit.recipe() {
            return Ok(None);
        }
        Ok(Some(super::render::PreviewEdit {
            session: draft.target.session,
            revision: draft.target.revision.clone(),
            cursor: draft.target.cursor,
            scope: draft.target.scope.clone(),
            edit: draft.target.edit(draft.edit.recipe().clone()),
        }))
    }

    pub(super) fn capture_gain_target(&self) -> Result<Target, String> {
        if self.view != View::Sequence
            || matches!(self.pane, Pane::Sources | Pane::Sounds)
            || self.event_focused()
            || self.sound_focused()
        {
            return Err("Select a beat in Your edit before changing its gain. Placed sounds use :sound-gain.".into());
        }
        let workspace = self.workspace.as_ref().ok_or("Open a project first.")?;
        let scoped = self.scoped_target()?;
        let node = scoped
            .as_ref()
            .map(|target| &target.target.node)
            .or(self.selected_beat.as_ref())
            .ok_or("Select a beat first.")?;
        let owner = workspace
            .document
            .nodes()
            .get(node)
            .ok_or("The selected beat is unavailable.")?;
        let target = Target {
            session: workspace.session,
            project: workspace.document.project_id().clone(),
            revision: workspace.document.revision_id().clone(),
            scope: self.sequence_scope.clone(),
            node: node.clone(),
            cursor: ProjectFrame(i64::try_from(self.sequence_cursor).map_err(|e| e.to_string())?),
            entry: owner.audio_treatments.clone(),
            scoped,
        };
        if target.scoped.is_none() {
            target.validate(workspace)?;
        }
        Ok(target)
    }

    fn check_gain_target(&self, target: &Target) -> Result<(), String> {
        target.validate(self.workspace.as_ref().ok_or("The project was closed.")?)?;
        if !self.inspected_target_matches(&target.node, target.scoped.as_ref())
            || self.sequence_scope != target.scope
            || self.view != View::Sequence
            || i64::try_from(self.sequence_cursor).ok() != Some(target.cursor.0)
            || matches!(self.pane, Pane::Sources | Pane::Sounds)
            || self.event_focused()
            || self.sound_focused()
        {
            return Err(
                "The selected beat or Edit cursor changed. Reopen Gain; no edit was made.".into(),
            );
        }
        Ok(())
    }

    fn commit_gain(&mut self, target: Target, treatments: AudioTreatments) {
        if let Err(error) = self.check_gain_target(&target) {
            self.error = Some(error);
            return;
        }
        if treatments == target.entry {
            self.message = Some("Audio treatments unchanged. No edit was made.".into());
            return;
        }
        self.stop_playback();
        let edit = target.edit(treatments);
        self.submit(ProjectRequest::Edit {
            expected_session: target.session,
            expected_revision: target.revision,
            cursor: target.cursor,
            scope: target.scope,
            edit,
        });
    }

    /// An audio-treatment change of the captured whole beat as one
    /// semantic instruction: recorded while a macro records, repeatable
    /// with `.`, and one Undo either way.
    pub(super) fn record_audio_change(
        &mut self,
        target: Option<Result<Target, String>>,
        macro_target: Option<Result<super::macros::Capture, String>>,
        change: deadpan_core::AudioChange,
    ) {
        let checked = target
            .unwrap_or_else(|| Err("No beat was captured on command entry.".into()))
            .and_then(|target| {
                if let Some(scoped) = &target.scoped {
                    if !scoped_audio_change(&change)
                        || self.edit_selection() != navigation::EditSelection::None
                        || !scoped.has_single_play_authority()
                    {
                        return Err("A one-play macro records whole-beat gain, mute, saturation, balance and EQ. Clear Visual selection and choose This play at every Repeat level.".into());
                    }
                    self.check_gain_target(&target)?;
                    let capture = macro_target
                        .as_ref()
                        .ok_or("Open the command again to capture its selected play.")?
                        .as_ref()
                        .map_err(Clone::clone)?;
                    if !capture.captures_scope(scoped) {
                        return Err("The captured gain and macro plays differ. Start the command again; no edit was made.".into());
                    }
                }
                // A range step changes the beat containing the range, which
                // the planner resolves and checks exactly.
                if matches!(change, deadpan_core::AudioChange::RangeStep { .. }) {
                    return Ok(());
                }
                change
                    .apply(&target.entry)
                    .map_err(|error| error.to_string())
                    .and_then(|treatments| {
                        if treatments == target.entry {
                            Err("The beat already has those audio treatments. No edit was made."
                                .into())
                        } else {
                            Ok(())
                        }
                    })
            });
        if let Err(error) = checked {
            if error.ends_with("No edit was made.") {
                self.error = None;
                self.message = Some(error);
            } else {
                self.error = Some(error);
            }
            return;
        }
        let capture = macro_target
            .unwrap_or_else(|| Err("Open the command again to capture its selected beat.".into()));
        self.apply_recorded_instruction(
            capture,
            Ok(deadpan_core::SemanticInstruction::SetAudio { change }),
        );
    }

    pub(super) fn gain_step(&mut self, delta: i32, context: &egui::Context) {
        if self.pane == Pane::Sounds || self.event_focused() {
            self.sound_action(navigation::SoundAction::GainStep(delta), context);
            return;
        }
        // A beat (or the Edit range inside it) in the current group changes
        // through the semantic path, so `.` repeats it and a macro records it;
        // an explicit This-play step uses that same relative intent.
        let target = self.capture_gain_target();
        if self.macros.recording()
            || matches!(&target, Ok(target) if target.scoped.is_none()
                || (self.edit_selection() == navigation::EditSelection::None
                    && target.scoped.as_ref().is_some_and(|scope| scope.has_single_play_authority())))
        {
            let capture = Some(self.capture_macro_target());
            // A range step and a whole-beat step are different edits, so `.`
            // never turns one into the other.
            let change = if self.edit_selection() == navigation::EditSelection::None {
                deadpan_core::AudioChange::Step {
                    millidecibels: delta,
                }
            } else {
                deadpan_core::AudioChange::RangeStep {
                    millidecibels: delta,
                }
            };
            self.record_audio_change(Some(target), capture, change);
            return;
        }
        let result = target.and_then(|target| {
            let mut edit = GainEdit::new(target.entry.clone());
            edit.adjust_trim(delta)?;
            Ok((target, edit.recipe().clone()))
        });
        match result {
            Ok((target, recipe)) => self.commit_gain(target, recipe),
            Err(error) => self.error = Some(error),
        }
    }

    /// `,m`: mute the Visual range inside the selected beat, or toggle the
    /// whole beat's mute when no range is selected. One Undo either way.
    pub(super) fn mute_key(&mut self) {
        // A beat in the current group (or the Edit range inside it) mutes
        // through the semantic path, so `.` repeats it and a macro records
        // it: a range as the role-only sound delete it is, the whole beat as
        // an explicit mute state. An explicit This-play target captures that
        // same Boolean rather than recording a future toggle.
        let captured = self.capture_gain_target();
        if let Ok(target) = &captured
            && target
                .scoped
                .as_ref()
                .is_some_and(|scope| scope.has_single_play_authority())
            && self.edit_selection() == navigation::EditSelection::None
        {
            let muted = GainEdit::new(target.entry.clone()).muted();
            let capture = self.capture_macro_target();
            self.record_audio_change(
                Some(captured),
                Some(capture),
                deadpan_core::AudioChange::Mute { muted: !muted },
            );
            return;
        }
        if self.macros.recording() && matches!(&captured, Ok(target) if target.scoped.is_some()) {
            self.error = Some(
                "Clear Visual selection and choose This play at every Repeat level before recording mute."
                    .into(),
            );
            return;
        }
        if let Ok(target) = &captured
            && target.scoped.is_none()
        {
            let muted = GainEdit::new(target.entry.clone()).muted();
            let capture = self.capture_macro_target();
            let instruction = if self.selected_edit_range().is_some() {
                deadpan_core::SemanticInstruction::DeleteRole {
                    role: deadpan_core::MediaRole::Audio,
                }
            } else {
                deadpan_core::SemanticInstruction::SetAudio {
                    change: deadpan_core::AudioChange::Mute { muted: !muted },
                }
            };
            self.apply_recorded_instruction(capture, Ok(instruction));
            return;
        }
        let range = self.selected_edit_range();
        let rows = &self.beat_rows;
        let result = captured.and_then(|target| {
            let mut edit = GainEdit::new(target.entry.clone());
            let Some(range) = range else {
                edit.set_muted(!edit.muted())?;
                return Ok((target, edit.recipe().clone()));
            };
            if target.scoped.is_some() {
                return Err("Mute a range in the whole beat: leave the play scope with :scope all, or clear the Visual range to mute this play.".into());
            }
            let row = rows
                .iter()
                .find(|row| row.id == target.node)
                .ok_or("Select a beat in the current group first.")?;
            let (start, end) = (range.start().0, range.end().0);
            let (first, last) = (row.start as i64, (row.start + row.frames) as i64);
            if start < first || end > last || start == end {
                return Err("Select a range inside one beat to mute it; a mute range belongs to that beat.".into());
            }
            let local = deadpan_core::GainRange::new(
                deadpan_core::ExactRatio::integer(start - first),
                deadpan_core::ExactRatio::integer(end - first),
            )
            .map_err(|error| error.to_string())?;
            edit.add_mute_range(local)?;
            Ok((target, edit.recipe().clone()))
        });
        match result {
            Ok((target, recipe)) => self.commit_gain(target, recipe),
            Err(error) => self.error = Some(error),
        }
    }

    pub(super) fn gain_mute(
        &mut self,
        target: Option<Result<Target, String>>,
        macro_target: Option<Result<super::macros::Capture, String>>,
    ) {
        // With an Edit range, `:gain-mute` keeps toggling the whole beat as
        // it always has, through the direct edit.
        if let Some(Ok(captured)) = &target
            && ((captured.scoped.is_none() && self.selected_edit_range().is_none())
                || (captured
                    .scoped
                    .as_ref()
                    .is_some_and(|scope| scope.has_single_play_authority())
                    && self.edit_selection() == navigation::EditSelection::None)
                || (self.macros.recording() && captured.scoped.is_some()))
        {
            let muted = GainEdit::new(captured.entry.clone()).muted();
            self.record_audio_change(
                target,
                macro_target,
                deadpan_core::AudioChange::Mute { muted: !muted },
            );
            return;
        }
        let result = target
            .unwrap_or_else(|| Err("No gain target was captured on command entry.".into()))
            .and_then(|target| {
                let mut edit = GainEdit::new(target.entry.clone());
                edit.set_muted(!edit.muted())?;
                Ok((target, edit.recipe().clone()))
            });
        match result {
            Ok((target, recipe)) => self.commit_gain(target, recipe),
            Err(error) => self.error = Some(error),
        }
    }

    /// `:gain +=3dB`: a relative trim change on the captured beat.
    pub(super) fn gain_step_captured(
        &mut self,
        target: Option<Result<Target, String>>,
        delta: i32,
    ) {
        let result = target
            .unwrap_or_else(|| Err("No gain target was captured on command entry.".into()))
            .and_then(|target| {
                let mut edit = GainEdit::new(target.entry.clone());
                edit.adjust_trim(delta)?;
                Ok((target, edit.recipe().clone()))
            });
        match result {
            Ok((target, recipe)) => self.commit_gain(target, recipe),
            Err(error) => self.error = Some(error),
        }
    }

    /// `:gain +3dB range=4-10`: a constant step over exactly those local
    /// frames of the captured beat, keeping its other gain and saturation.
    /// Inside Repeat contents it changes only the selected play or plays.
    pub(super) fn gain_range_captured(
        &mut self,
        target: Option<Result<Target, String>>,
        millidecibels: i32,
        range: deadpan_core::GainRange,
    ) {
        let result = target
            .unwrap_or_else(|| Err("No gain target was captured on command entry.".into()))
            .and_then(|target| {
                let recipe = crate::gain::ranged_step(&target.entry, range, millidecibels)?;
                Ok((target, recipe))
            });
        match result {
            Ok((target, recipe)) => self.commit_gain(target, recipe),
            Err(error) => self.error = Some(error),
        }
    }

    /// `:saturate 12dB` / `:saturate off`: the captured beat's saturation
    /// stage, after its clip gain, as one Undo. A whole beat in the current
    /// group is changed through the semantic path, so `.` repeats it and a
    /// macro records it, including one explicitly chosen Repeat play.
    pub(super) fn saturate_command(
        &mut self,
        target: Option<Result<Target, String>>,
        macro_target: Option<Result<super::macros::Capture, String>>,
        stage: Option<deadpan_core::Saturation>,
    ) {
        if self.semantic_audio_target(&target) {
            self.record_audio_change(
                target,
                macro_target,
                deadpan_core::AudioChange::Saturation {
                    drive: stage.map(deadpan_core::Saturation::drive),
                },
            );
            return;
        }
        let result = target
            .unwrap_or_else(|| Err("No beat was captured on command entry.".into()))
            .and_then(|target| {
                let mut edit = GainEdit::new(target.entry.clone());
                if stage.is_none() && edit.saturation().is_none() {
                    return Err("This beat has no saturation. No edit was made.".into());
                }
                edit.set_saturation(stage)?;
                Ok((target, edit.recipe().clone()))
            });
        match result {
            Ok((target, recipe)) => self.commit_gain(target, recipe),
            Err(error) => self.error = Some(error),
        }
    }

    /// Captured balance follows the same revision and scope checks as gain.
    /// Whole-beat edits use the semantic path for dot and macro replay.
    pub(super) fn balance_command(
        &mut self,
        target: Option<Result<Target, String>>,
        macro_target: Option<Result<super::macros::Capture, String>>,
        balance: Option<deadpan_core::StereoBalance>,
    ) {
        if self.semantic_audio_target(&target) {
            self.record_audio_change(
                target,
                macro_target,
                deadpan_core::AudioChange::Balance { balance },
            );
            return;
        }
        let result = target
            .unwrap_or_else(|| Err("No beat was captured on command entry.".into()))
            .and_then(|target| {
                let recipe = target
                    .entry
                    .with_balance(balance)
                    .map_err(|error| error.to_string())?;
                Ok((target, recipe))
            });
        match result {
            Ok((target, recipe)) => self.commit_gain(target, recipe),
            Err(error) => self.error = Some(error),
        }
    }

    pub(super) fn gain_command(
        &mut self,
        target: Option<Result<Target, String>>,
        value: Option<GainDb>,
        context: &egui::Context,
    ) {
        self.audio_draft_command(target, value, false, context);
    }

    fn audio_draft_command(
        &mut self,
        target: Option<Result<Target, String>>,
        value: Option<GainDb>,
        equalizer: bool,
        context: &egui::Context,
    ) {
        let target =
            target.unwrap_or_else(|| Err("No gain target was captured on command entry.".into()));
        let target = match target.and_then(|target| {
            self.check_gain_target(&target)?;
            Ok(target)
        }) {
            Ok(target) => target,
            Err(error) => {
                self.error = Some(error);
                return;
            }
        };
        if let Some(value) = value {
            let mut edit = GainEdit::new(target.entry.clone());
            match edit.set_trim(value) {
                Ok(()) => self.commit_gain(target, edit.recipe().clone()),
                Err(error) => self.error = Some(error),
            }
            return;
        }
        let result = (|| {
            let workspace = self.workspace.as_ref().ok_or("Open a project first.")?;
            let range = if target.scoped.is_some() {
                self.scoped_presentation()?.ok_or("This definition has no visible play to audition. Use :gain with a value to change its gain.")?.frames
            } else {
                let row = self
                    .beat_rows
                    .iter()
                    .find(|row| row.id == target.node)
                    .ok_or("Selected beat has no visible span.")?;
                row.start
                    ..row
                        .start
                        .checked_add(row.frames)
                        .ok_or("Gain audition range overflowed.")?
            };
            let domain = Domain::Sequence {
                rate: workspace.document.presentation_basis().frame_rate,
                frames: workspace.plan.duration().frames(),
            };
            let window =
                domain.selection_window(range, AudioSample(24_000), AudioSample(36_000))?;
            let owner_frames = workspace
                .plan
                .node_duration(&target.node)
                .ok_or("Gain owner has no duration.")?
                .frames();
            Ok::<_, String>((
                Arc::new(workspace.playback_snapshot()),
                domain,
                window,
                owner_frames,
                workspace.document.nodes()[&target.node].label.clone(),
            ))
        })();
        let (base, domain, window, frames, label) = match result {
            Ok(value) => value,
            Err(error) => {
                self.error = Some(error);
                return;
            }
        };
        let Some(token) = self.next_serial() else {
            return;
        };
        self.stop_playback();
        self.cancel_camera();
        self.help_open = false;
        self.bindings.clear();
        self.error = None;
        let edit = GainEdit::new(target.entry.clone());
        let mut controls = controls::Controls::new(&edit, frames);
        controls.equalizer_mode = equalizer;
        let mut waveform = waveform::Display::default();
        if !equalizer {
            waveform.request(&self.playback, &base, &target.node);
        }
        self.service.set_preview_active(true);
        self.gain = Some(Draft {
            target,
            base,
            token,
            change: 1,
            edit,
            controls,
            waveform,
            pending: None,
            requested: None,
            prepared: None,
            error: None,
            domain,
            window,
            position: window.start(),
            choice: Choice::Draft,
            label,
            source_cursor: self.source_cursor,
            pane: self.pane,
            key: None,
            focus_pending: true,
            cancel_focus: None,
            applying: false,
        });
        context.request_repaint();
    }

    pub(super) fn open_equalizer(
        &mut self,
        target: Option<Result<Target, String>>,
        context: &egui::Context,
    ) {
        self.audio_draft_command(target, None, true, context);
    }

    pub(super) fn tail_send_command(
        &mut self,
        target: Option<Result<Target, String>>,
        macro_target: Option<Result<super::macros::Capture, String>>,
        effect: deadpan_core::TailEffect,
        level: Option<deadpan_core::GainDb>,
        wet: bool,
    ) {
        let change = if wet {
            deadpan_core::AudioChange::WetSend { effect, level }
        } else {
            deadpan_core::AudioChange::TailSend { effect, level }
        };
        if let Some(Ok(captured)) = &target
            && captured.scoped.is_none()
        {
            self.record_audio_change(target, macro_target, change);
            return;
        }
        if self.macros.recording() {
            self.error = Some(
                "Recording changes a whole beat's send; leave the play scope with :scope all."
                    .into(),
            );
            return;
        }
        let result = target
            .unwrap_or_else(|| Err("No beat was captured on command entry.".into()))
            .and_then(|target| {
                change
                    .apply(&target.entry)
                    .map(|treatments| (target, treatments))
                    .map_err(|e| e.to_string())
            });
        match result {
            Ok((target, treatments)) => self.commit_gain(target, treatments),
            Err(error) => self.error = Some(error),
        }
    }

    pub(super) fn equalizer_command(
        &mut self,
        target: Option<Result<Target, String>>,
        macro_target: Option<Result<super::macros::Capture, String>>,
        recipe: Option<deadpan_core::EqualizerRecipe>,
    ) {
        if self.semantic_audio_target(&target) {
            self.record_audio_change(
                target,
                macro_target,
                deadpan_core::AudioChange::Equalizer { recipe },
            );
            return;
        }
        let result = target
            .unwrap_or_else(|| Err("No beat was captured on command entry.".into()))
            .and_then(|target| {
                let treatments = target
                    .entry
                    .with_equalizer(recipe)
                    .map_err(|error| error.to_string())?;
                Ok((target, treatments))
            });
        match result {
            Ok((target, treatments)) => self.commit_gain(target, treatments),
            Err(error) => self.error = Some(error),
        }
    }

    fn semantic_audio_target(&self, target: &Option<Result<Target, String>>) -> bool {
        self.macros.recording()
            || matches!(target, Some(Ok(target)) if target.scoped.is_none()
                || (self.edit_selection() == navigation::EditSelection::None
                    && target.scoped.as_ref().is_some_and(|scope| scope.has_single_play_authority())))
    }

    pub(super) fn receive_gain(&mut self, update: Option<ProposalUpdate>) {
        if let (Some(draft), Some(update)) = (&mut self.gain, update) {
            draft.receive(update);
        }
    }

    pub(super) fn receive_gain_waveform(&mut self) {
        if let Some(update) = self.playback.poll_waveform()
            && let Some(draft) = &mut self.gain
        {
            draft.waveform.receive(&draft.target, update);
        }
    }

    pub(super) fn cancel_gain_waveform(&mut self) {
        if let Some(draft) = &mut self.gain {
            draft.waveform.cancel(&self.playback);
        }
    }

    pub(super) fn finish_gain_commit(&mut self, update: &crate::project::ProjectUpdate) {
        let Some(draft) = &mut self.gain else {
            return;
        };
        if !draft.applying {
            return;
        }
        if update
            .committed
            .as_ref()
            .is_some_and(|committed| match &draft.target.scoped {
                Some(target) => committed
                    .scoped
                    .as_ref()
                    .is_some_and(|receipt| &receipt.before == target),
                None => {
                    committed.scoped.is_none()
                        && committed.selected_node.as_ref() == Some(&draft.target.node)
                }
            })
        {
            draft.waveform.cancel(&self.playback);
            self.gain = None;
        } else if let Some(error) = &update.error {
            draft.applying = false;
            draft.error = Some(error.clone());
        }
    }

    pub(super) fn dispatch_gain_proposal(&mut self, context: &egui::Context) {
        let Some(draft) = &mut self.gain else {
            return;
        };
        if draft.applying || draft.pending.is_some() || draft.requested == Some(draft.change) {
            return;
        }
        if self.service.is_busy() {
            context.request_repaint_after(Duration::from_millis(16));
            return;
        }
        let proposal = draft.proposal();
        let id = proposal.id();
        match self
            .service
            .submit(ProjectRequest::PrepareGain(Box::new(proposal)))
        {
            Ok(()) => {
                draft.pending = Some(id);
                draft.requested = Some(draft.change);
            }
            Err(error) => {
                draft.error = Some(error);
                draft.requested = Some(draft.change);
            }
        }
    }

    pub(super) fn reconcile_gain(&mut self, context: &egui::Context) {
        let failure = self
            .gain
            .as_ref()
            .and_then(|draft| self.check_gain_target(&draft.target).err());
        if let Some(error) = failure {
            self.stop_playback();
            self.cancel_gain_waveform();
            self.gain = None;
            self.error = Some(error);
            context.request_repaint();
        }
    }

    pub(super) fn close_gain(&mut self, context: &egui::Context) {
        self.stop_playback();
        self.cancel_gain_waveform();
        if let Some(draft) = self.gain.take()
            && self
                .workspace
                .as_ref()
                .is_some_and(|workspace| draft.target.validate(workspace).is_ok())
        {
            self.source_cursor = draft.source_cursor;
            self.sequence_cursor = draft.target.cursor.0 as u64;
            self.selected_beat = Some(
                draft
                    .target
                    .scoped
                    .as_ref()
                    .map_or(draft.target.node, |target| target.root.clone()),
            );
            self.sequence_scope = draft.target.scope;
            self.view = View::Sequence;
            self.pane = draft.pane;
            context.memory_mut(|memory| memory.request_focus(pane_id(self.pane)));
            self.request_picture(false);
        }
        self.bindings.clear();
        context.request_repaint();
    }

    pub(super) fn gain_keyboard(&mut self, context: &egui::Context) {
        if help_scroll::defer_popup_input(
            context,
            self.dialogs.is_open(),
            &mut self.ime_composing,
            &mut self.bindings,
        ) {
            return;
        }
        let events = context.input(|input| input.events.clone());
        help_scroll::observe_composition(&events, &mut self.ime_composing);
        self.bindings.clear();
        if self.ime_composing
            || events
                .iter()
                .any(|event| matches!(event, egui::Event::Ime(_)))
            || pointer_focus_transition(&events)
        {
            return;
        }
        let background = context.memory(|memory| {
            memory
                .focused()
                .is_none_or(|id| id == egui::Id::new(FOCUS_ID) || id == pane_id(self.pane))
        });
        for event in events {
            let egui::Event::Key {
                key,
                physical_key,
                modifiers,
                pressed: true,
                repeat,
                ..
            } = event
            else {
                continue;
            };
            if key == egui::Key::Tab
                && (modifiers.is_none() || modifiers.shift_only())
                && let Some(draft) = &self.gain
                && !draft.applying
            {
                let focused = context.memory(|memory| memory.focused());
                let heading = egui::Id::new(FOCUS_ID);
                let destination = if modifiers.shift && focused == Some(heading) {
                    draft.cancel_focus
                } else if !modifiers.shift
                    && draft.cancel_focus.is_some()
                    && focused == draft.cancel_focus
                {
                    Some(heading)
                } else {
                    None
                };
                if let Some(destination) = destination {
                    context.memory_mut(|memory| {
                        memory.move_focus(egui::FocusDirection::None);
                        memory.request_focus(destination);
                    });
                    context.input_mut(|input| {
                        input.consume_key(modifiers, key);
                    });
                    context.request_repaint();
                    break;
                }
            }
            if repeat {
                continue;
            }
            if self.bindings.clone().route_event(
                key,
                physical_key,
                modifiers,
                controls::Controls::text_focused(context),
                false,
                false,
                true,
                navigation::EditSelection::None,
            ) == Some(Action::Render)
            {
                self.render.requested = true;
                context.input_mut(|input| {
                    input.consume_key(modifiers, key);
                });
                break;
            }
            let action = navigation::gain::route_key(
                key,
                modifiers,
                controls::Controls::text_focused(context),
                background,
                false,
                false,
            )
            .map(|action| match action {
                navigation::gain::GainKey::Cancel => DraftAction::Cancel,
                navigation::gain::GainKey::Apply => DraftAction::Apply,
                navigation::gain::GainKey::Play => DraftAction::Play,
            });
            if let Some(action) = action {
                if let Some(draft) = &mut self.gain {
                    draft.key = Some(action);
                }
                context.input_mut(|input| {
                    input.consume_key(modifiers, key);
                });
                break;
            }
        }
    }

    pub(super) fn gain_panel(&mut self, ui: &mut egui::Ui) {
        let panel = egui::Panel::bottom("gain-draft-panel")
            .resizable(false)
            .show_separator_line(true)
            .frame(style::panel());
        let Some(mut draft) = self.gain.take() else {
            // Keep its widget ID without letting frame margins move the
            // remaining workspace over the footer when no draft is open.
            panel
                .exact_size(0.0)
                .frame(egui::Frame::NONE)
                .show_separator_line(false)
                .show(ui, |_| {});
            return;
        };
        let mut action = draft.key.take();
        let mut changed = false;
        let mut retry_waveform = false;
        // Below 700 points the panel keeps room for the measured waveform's
        // heading and complete graph together in its scroller.
        let compact = ui.ctx().content_rect().height() < 700.0;
        let height = (ui.ctx().content_rect().height() * 0.34)
            .clamp(if compact { 248.0 } else { 224.0 }, 300.0);
        let playing = self.transport.as_ref().map_or("Paused", |run| {
            if run.phase == deadpan_playback::Phase::Preparing {
                "Preparing audio"
            } else if run.phase == deadpan_playback::Phase::Ended {
                "Finishing picture"
            } else {
                "Playing"
            }
        });
        let status = format!(
            "{} · {playing} · {} · loop {}–{}",
            if draft.choice == Choice::Before {
                "Before"
            } else {
                "Draft"
            },
            playback::sound_time(draft.position.0.max(0) as u64),
            playback::sound_time(draft.window.start().0 as u64),
            playback::sound_time(draft.window.end().0 as u64)
        );
        panel.exact_size(height).show(ui, |ui| {
            let title_width = (ui.available_width() - 350.0).clamp(120.0, 480.0);
            let heading = ui
                .horizontal(|ui| {
                    ui.allocate_ui_with_layout(
                        egui::vec2(title_width, 20.0),
                        egui::Layout::left_to_right(egui::Align::Center),
                        |ui| {
                            let title = format!("{} · {}", draft.editor_name(), draft.label);
                            accessibility::full_text(
                                ui.add(
                                    egui::Label::new(egui::RichText::new(&title).strong())
                                        .truncate(),
                                ),
                                &title,
                            )
                            .on_hover_text(&draft.label);
                        },
                    );
                    ui.colored_label(style::LAVENDER, "UNSAVED DRAFT");
                    ui.weak(if draft.controls.equalizer_mode {
                        "Whole captured beat · time unchanged"
                    } else {
                        "Owner-output frames · Out excluded"
                    });
                })
                .response;
            let focus = ui.interact(heading.rect, egui::Id::new(FOCUS_ID), egui::Sense::click());
            focus.widget_info(|| {
                egui::WidgetInfo::labeled(
                    egui::WidgetType::Button,
                    !draft.applying,
                    if draft.controls.equalizer_mode {
                        "EQ draft keyboard focus"
                    } else {
                        "Gain draft keyboard focus"
                    },
                )
            });
            if std::mem::take(&mut draft.focus_pending) || focus.clicked() {
                focus.request_focus();
            }
            if focus.has_focus() {
                ui.painter().hline(
                    heading.rect.x_range(),
                    heading.rect.bottom(),
                    egui::Stroke::new(1.0, style::LAVENDER),
                );
            }
            // A fixed outer panel and one bounded scroller keep the
            // comparison/Apply row painted and reachable after resize.
            egui::ScrollArea::vertical()
                .id_salt("gain-draft-scroll")
                // Focus reveals apply at once; see the inspector scroller.
                .animated(false)
                .max_height((ui.available_height() - 54.0).max(30.0))
                .auto_shrink([false, false])
                .show(ui, |ui| {
                    if draft.pending.is_some() || draft.requested != Some(draft.change) {
                        ui.weak("Preparing the latest draft…");
                    }
                    ui.add_enabled_ui(!draft.applying, |ui| {
                        changed = draft
                            .controls
                            .show(ui, &mut draft.edit, |ui, owner_frames| {
                                retry_waveform |= draft.waveform.show(ui, owner_frames);
                            });
                    });
                    if let Some(error) = &draft.error {
                        ui.colored_label(ui.visuals().error_fg_color, error);
                    }
                });
            ui.separator();
            ui.horizontal_wrapped(|ui| {
                for (choice, label) in [(Choice::Before, "Before"), (Choice::Draft, "Draft")] {
                    if ui.selectable_label(draft.choice == choice, label).clicked() {
                        action = Some(DraftAction::Choose(choice));
                    }
                }
                let playing = self.transport.is_some();
                if ui
                    .add_enabled(
                        !draft.applying
                            && (playing
                                || (draft.selected_snapshot().is_some()
                                    && draft.controls.ready(&draft.edit))),
                        egui::Button::new(
                            if self
                                .transport
                                .as_ref()
                                .is_some_and(|run| run.phase == deadpan_playback::Phase::Ended)
                            {
                                "Stop · Space"
                            } else if playing {
                                "Pause · Space"
                            } else {
                                "Audition · Space"
                            },
                        ),
                    )
                    .clicked()
                {
                    action = Some(DraftAction::Play);
                }
                if ui
                    .add_enabled(
                        !draft.applying
                            && draft.selected_snapshot().is_some()
                            && draft.controls.ready(&draft.edit),
                        egui::Button::new("Restart loop"),
                    )
                    .clicked()
                {
                    action = Some(DraftAction::Restart);
                }
                if ui
                    .add_enabled(
                        !draft.applying
                            && !self.service.is_busy()
                            && draft.prepared.is_some()
                            && draft.controls.ready(&draft.edit)
                            && !changed,
                        style::action("Apply", "Enter").fill(style::SELECTED),
                    )
                    .clicked()
                {
                    action = Some(DraftAction::Apply);
                }
                let cancel = ui.add_enabled(!draft.applying, style::action("Cancel", "Esc"));
                draft.cancel_focus = Some(cancel.id);
                if cancel.clicked() {
                    action = Some(DraftAction::Cancel);
                }
                // The comparison and heard position follow the commands on
                // their row, eliding rather than wrapping so the row's
                // reserve stays exact.
                let galley = egui::WidgetText::from(egui::RichText::new(&status).weak())
                    .into_galley_impl(
                        ui.ctx(),
                        ui.style(),
                        egui::text::TextWrapping {
                            max_width: (ui.available_size_before_wrap().x - 8.0).max(1.0),
                            max_rows: 1,
                            break_anywhere: true,
                            overflow_character: Some('…'),
                        },
                        egui::TextStyle::Body.into(),
                        egui::Align::Center,
                    );
                ui.add_space(8.0);
                accessibility::full_text(ui.add(egui::Label::new(galley)), &status)
                    .on_hover_text(&status);
            });
        });
        if retry_waveform && !draft.applying {
            draft
                .waveform
                .request(&self.playback, &draft.base, &draft.target.node);
            draft.focus_pending = true;
        }
        if changed {
            if let Some(run) = &self.transport
                && let Ok(position) = run.content_sample()
            {
                draft.position = position;
            }
            self.stop_playback();
            if let Err(error) = draft.changed() {
                draft.error = Some(error);
            }
        }
        self.service.set_preview_active(true);
        self.gain = Some(draft);
        if let Some(action) = action {
            self.gain_action(action, ui.ctx());
        }
    }

    fn gain_action(&mut self, action: DraftAction, context: &egui::Context) {
        if self.gain.as_ref().is_some_and(|draft| draft.applying) {
            return;
        }
        if matches!(action, DraftAction::Cancel) {
            self.close_gain(context);
            return;
        }
        let Some(draft) = &self.gain else {
            return;
        };
        if matches!(action, DraftAction::Choose(choice) if choice == draft.choice) {
            return;
        }
        if let Err(error) = self.check_gain_target(&draft.target) {
            self.error = Some(error);
            return;
        }
        if matches!(action, DraftAction::Restart) && !draft.controls.ready(&draft.edit) {
            return;
        }
        if matches!(action, DraftAction::Apply) {
            if self.service.is_busy()
                || draft.prepared.is_none()
                || !draft.controls.ready(&draft.edit)
            {
                return;
            }
            let target = draft.target.clone();
            let recipe = draft.edit.recipe().clone();
            if target.entry == recipe {
                let name = draft.editor_name();
                self.close_gain(context);
                self.message = Some(format!("{name} unchanged. No edit was made."));
                return;
            }
            let edit = target.edit(recipe);
            if self.submit(ProjectRequest::Edit {
                expected_session: target.session,
                expected_revision: target.revision,
                cursor: target.cursor,
                scope: target.scope,
                edit,
            }) && let Some(draft) = &mut self.gain
            {
                draft.waveform.cancel(&self.playback);
                draft.applying = true;
            }
            return;
        }
        let running = self.transport.is_some();
        let heard = self
            .transport
            .as_ref()
            .and_then(|run| run.content_sample().ok());
        let Some(draft) = &mut self.gain else {
            return;
        };
        if let Some(position) = heard {
            draft.position = position;
        }
        if let DraftAction::Choose(choice) = action {
            draft.choice = choice;
        }
        if matches!(action, DraftAction::Restart) {
            draft.position = draft.window.start();
        }
        let start = if draft.position >= draft.window.end() {
            draft.window.start()
        } else {
            draft.position
        };
        let snapshot = draft.selected_snapshot();
        let domain = draft.domain.clone();
        let window = draft.window;
        let ready = draft.controls.ready(&draft.edit);
        self.stop_playback();
        let should_play = matches!(action, DraftAction::Restart)
            || matches!(action, DraftAction::Play) && !running
            || matches!(action, DraftAction::Choose(_)) && running;
        if should_play
            && ready
            && let Some(snapshot) = snapshot
        {
            self.start_snapshot_playback(snapshot, domain, window, start);
        }
    }

    pub(super) fn gain_inspector(&mut self, ui: &mut egui::Ui, ready: bool) {
        let Ok(target) = self.capture_gain_target() else {
            return;
        };
        let proposed = self
            .gain
            .as_ref()
            .filter(|draft| draft.target.node == target.node);
        let edit = GainEdit::new(
            proposed
                .map_or(&target.entry, |draft| draft.edit.recipe())
                .clone(),
        );
        let previewing = proposed.is_some();
        ui.add_space(8.0);
        ui.label(style::section_title("GAIN", false));
        ui.horizontal(|ui| {
            ui.label(
                style::semibold(format!("{} dB", crate::gain::format_db(edit.trim()))).size(20.0),
            );
            ui.weak(if previewing { "unsaved" } else { "this beat" });
        });
        ui.add_enabled_ui(ready && self.gain.is_none(), |ui| {
            ui.horizontal_wrapped(|ui| {
                ui.spacing_mut().item_spacing.x = 4.0;
                if ui
                    .add(style::action("−3 dB", self.editor_key(EditorKey::GainDown)))
                    .reveal_on_focus()
                    .clicked()
                {
                    self.gain_step(-3000, ui.ctx());
                }
                if ui
                    .add(style::action("+3 dB", self.editor_key(EditorKey::GainUp)))
                    .reveal_on_focus()
                    .clicked()
                {
                    self.gain_step(3000, ui.ctx());
                }
                if ui
                    .add(style::action(
                        if edit.muted() { "Unmute" } else { "Mute" },
                        self.editor_key(EditorKey::Mute),
                    ))
                    .on_hover_text(":gain-mute · true silence")
                    .reveal_on_focus()
                    .clicked()
                {
                    let capture = Some(self.capture_macro_target());
                    self.gain_mute(Some(Ok(target.clone())), capture);
                }
            });
            if ui
                .add(style::row_action(ui, "Edit envelope…", ":gain"))
                .reveal_on_focus()
                .clicked()
            {
                self.gain_command(Some(Ok(target.clone())), None, ui.ctx());
            }
        });
        ui.weak(format!(
            "{} envelopes · {} mute ranges. Placed sounds keep their own gain.",
            edit.envelopes().len(),
            edit.mute_ranges().len()
        ));
        ui.weak(match edit.saturation() {
            Some(saturation) => format!(
                "Saturation {} dB drive · :saturate off removes it",
                crate::gain::format_db(saturation.drive())
            ),
            None => "No saturation · :saturate 12dB drives a soft clipper".into(),
        });
        ui.weak(format!(
            "Balance {} · :balance -50% left / +50% right / center",
            crate::gain::format_balance(edit.recipe().balance())
        ));
        if ui
            .add_enabled(
                ready && self.gain.is_none(),
                style::row_action(ui, "EQ and filters…", ":eq"),
            )
            .reveal_on_focus()
            .clicked()
        {
            self.open_equalizer(Some(Ok(target)), ui.ctx());
        }
        ui.label("Continuous effects");
        for effect in [
            deadpan_core::TailEffect::Reverb,
            deadpan_core::TailEffect::Delay,
        ] {
            let level = edit.recipe().wet_sends().level(effect).map_or_else(
                || "off".into(),
                |gain| format!("{}dB", crate::gain::format_db(gain)),
            );
            if ui
                .add_enabled(
                    ready && self.gain.is_none(),
                    style::row_action(
                        ui,
                        format!("{} return: {level}", effect.name()),
                        ":wet-send",
                    ),
                )
                .reveal_on_focus()
                .clicked()
            {
                self.open_command(format!("wet-send {} {level}", effect.name()), ui.ctx());
            }
        }
        ui.weak("Wet sound follows this beat's treatments; silent Holds suppress it.");
        ui.label("Tail sends");
        for effect in [
            deadpan_core::TailEffect::Reverb,
            deadpan_core::TailEffect::Delay,
        ] {
            let level = edit.recipe().tail_sends().level(effect).map_or_else(
                || "off".into(),
                |gain| format!("{}dB", crate::gain::format_db(gain)),
            );
            let command = format!("tail-send {} {level}", effect.name());
            if ui
                .add_enabled(
                    ready && self.gain.is_none(),
                    style::row_action(ui, format!("{}: {level}", effect.name()), ":tail-send"),
                )
                .reveal_on_focus()
                .clicked()
            {
                self.open_command(command, ui.ctx());
            }
        }
        ui.weak("Rings only in a later :tail input=sends pause.");
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use deadpan_core::{Command, CommandRequest, FrameRate, ProjectDocument, ProjectId};
    use deadpan_store::ProjectStore;
    use std::collections::BTreeMap;

    fn fixture() -> (tempfile::TempDir, ProjectStore, Draft) {
        let scratch = tempfile::tempdir().unwrap();
        let document = Arc::new(
            ProjectDocument::new_automatic(
                ProjectId::new("gain-ui").unwrap(),
                RevisionId::new("base").unwrap(),
                NodeId::new("root").unwrap(),
            )
            .unwrap(),
        );
        let store = ProjectStore::create(&scratch.path().join("gain.deadpan"), &document).unwrap();
        let base = Arc::new(Snapshot::committed(
            7,
            document.clone(),
            BTreeMap::new(),
            store.original_import_handle().unwrap(),
        ));
        let edit = GainEdit::new(AudioTreatments::default());
        let draft = Draft {
            target: Target {
                session: 7,
                project: document.project_id().clone(),
                revision: document.revision_id().clone(),
                scope: SequenceScope::default(),
                node: document.root().clone(),
                cursor: ProjectFrame(0),
                entry: edit.recipe().clone(),
                scoped: None,
            },
            base,
            token: 10,
            change: 1,
            controls: controls::Controls::new(&edit, 10),
            waveform: waveform::Display::default(),
            edit,
            pending: None,
            requested: None,
            prepared: None,
            error: None,
            domain: Domain::Sequence {
                rate: FrameRate::new(30, 1).unwrap(),
                frames: 10,
            },
            window: Window::new(AudioSample(0), AudioSample(16000), true).unwrap(),
            position: AudioSample(137),
            choice: Choice::Draft,
            label: "Fixture".into(),
            source_cursor: 4,
            pane: Pane::Sequence,
            key: None,
            focus_pending: false,
            cancel_focus: None,
            applying: false,
        };
        (scratch, store, draft)
    }

    #[test]
    fn replaced_gain_proposals_coalesce_and_stale_errors_cannot_consume_new_request() {
        let (_scratch, _store, mut draft) = fixture();
        let old = draft.proposal().id();
        draft.pending = Some(old.clone());
        draft.requested = Some(1);
        draft.edit.adjust_trim(3000).unwrap();
        draft.changed().unwrap();
        draft.edit.adjust_trim(3000).unwrap();
        draft.changed().unwrap();
        assert_eq!(draft.change, 3);
        assert_eq!(draft.pending, Some(old.clone()));
        draft.receive(ProposalUpdate {
            id: old.clone(),
            result: Err("old failure".into()),
        });
        assert!(draft.pending.is_none());
        assert!(draft.error.is_none());
        assert!(draft.prepared.is_none());
        let current = draft.proposal().id();
        draft.pending = Some(current.clone());
        for case in 0..5 {
            let mut stale = current.clone();
            match case {
                0 => stale = old.clone(),
                1 => stale.session += 1,
                2 => stale.project = ProjectId::new("stale-project").unwrap(),
                3 => stale.revision = RevisionId::new("stale-revision").unwrap(),
                _ => stale.draft += 1,
            }
            draft.receive(ProposalUpdate {
                id: stale,
                result: Err("stale".into()),
            });
            assert_eq!(draft.pending, Some(current.clone()));
            assert!(draft.error.is_none());
        }
        draft.receive(ProposalUpdate {
            id: current,
            result: Err("current failure".into()),
        });
        assert!(draft.pending.is_none());
        assert_eq!(draft.error.as_deref(), Some("current failure"));
        assert_eq!(draft.edit.trim().millidecibels(), 6000);
        assert_eq!(draft.position, AudioSample(137));
    }

    #[test]
    fn tagged_gain_success_admits_only_current_proposed_content() {
        let (_scratch, store, mut draft) = fixture();
        let id = draft.proposal().id();
        draft.pending = Some(id.clone());
        draft.receive(ProposalUpdate {
            id: id.clone(),
            result: Ok(draft.base.clone()),
        });
        assert!(draft.prepared.is_none());
        assert!(draft.error.is_some());
        let request = CommandRequest {
            project_id: draft.target.project.clone(),
            expected_revision: draft.target.revision.clone(),
            new_revision: RevisionId::new("proposal").unwrap(),
            command: Command::SetAudioTreatments {
                node: draft.target.node.clone(),
                treatments: AudioTreatments::from_clip_gain(deadpan_core::ClipGain::default()),
            },
        };
        let document = Arc::new(
            store
                .preview(&request)
                .unwrap()
                .forward
                .apply(&draft.base.document)
                .unwrap(),
        );
        let proposal =
            Arc::new(Snapshot::proposed(&draft.base, document, draft.token, draft.change).unwrap());
        draft.pending = Some(id.clone());
        draft.receive(ProposalUpdate {
            id,
            result: Ok(proposal.clone()),
        });
        assert!(draft.error.is_none());
        assert!(Arc::ptr_eq(&draft.selected_snapshot().unwrap(), &proposal));
        draft.choice = Choice::Before;
        assert!(Arc::ptr_eq(
            &draft.selected_snapshot().unwrap(),
            &draft.base
        ));
        draft.choice = Choice::Draft;
        draft.changed().unwrap();
        assert!(draft.selected_snapshot().is_none());
        assert_eq!(*draft.base.document, store.snapshot().unwrap());
    }
}
