//! The Original transcript rail: model prompt, stored words, search and jumps.
//!
//! Replay never downloads a model. It checks the install prompt, then saves a
//! synthetic transcript of the fixture's audio through the real project
//! service and drives search, Enter and word clicks against exact frames.

use super::*;
use deadpan_analysis::{
    ActivityAudio, AnalysedAudio, SpeechActivity, Transcript, Word, picture_at,
};
use egui::Key;
use egui_kittest::kittest::Queryable as _;

pub(super) fn model_offer_visible(d: &mut Driver<'_>) -> Result<(), String> {
    d.wait_for("Transcript status checked", |app| {
        app.transcription.status_name() != "unchecked"
    })?;
    let prompt = scenarios::text_paint_visibility(d, "Install model…");
    let license = scenarios::text_paint_visibility(d, "MIT license");
    let install = d.rect("Install model…  :models").ok();
    let complete_button = install.is_some_and(|rect| {
        d.harness.ctx.content_rect().contains_rect(rect)
            && d.harness.output().shapes.iter().any(|clipped| {
                matches!(&clipped.shape, egui::Shape::Text(text) if text.galley.text().contains("Install model…"))
                    && clipped.clip_rect.contains_rect(rect)
            })
    });
    d.check(
        "Without an installed pack the rail offers the model with its size and license",
        d.app().transcription.status_name() == "needs_model"
            && complete_button
            && !prompt.is_empty()
            && prompt.iter().all(|paint| paint["fully_visible"] == true)
            && !license.is_empty()
            && license.iter().all(|paint| paint["fully_visible"] == true),
        json!({"status":"needs_model","prompt":"Install model…"}),
        json!({"status":d.app().transcription.status_name(),"prompt":prompt,"license":license,"complete_button":complete_button,"button":install.map(|r| [r.min.x,r.min.y,r.max.x,r.max.y])}),
    )?;
    d.capture("Complete transcript model offer beside the interpretation control")
}

/// UI-only queued state, followed by production sleep observation and retry input.
/// No model or successful recognition is fabricated by this check.
fn interrupted_retry(d: &mut Driver<'_>) -> Result<(), String> {
    let revision = d.revision();
    let lifecycle = d.app().service.jobs().lifecycle();
    d.app_mut()
        .transcription
        .replay_queued_recognition(lifecycle.clone());
    lifecycle.will_sleep();
    lifecycle.did_wake();
    // settled() may return without rendering: queued transcription is not a
    // project/picture busy flag. Wait for the actual outer-frame observation.
    d.wait_for("Transcription observes coalesced sleep and wake", |app| {
        app.transcription.status_name() == "interrupted"
    })?;
    d.step(
        "Wake alone must not restart interrupted transcription",
        true,
    )?;
    let message = scenarios::text_paint_visibility(d, "Transcription interrupted by system sleep.");
    // row_action retains its two-space key separator even with no shortcut.
    let retry_label = "Try again  ";
    let retry = d.rect(retry_label).ok();
    d.check(
        "Sleep and wake leave transcription interrupted with an explicit visible retry",
        d.app().transcription.status_name() == "interrupted"
            && d.revision() == revision
            && retry.is_some()
            && !message.is_empty()
            && message.iter().all(|paint| paint["fully_visible"] == true),
        json!({"status":"interrupted","retry":"Try again","revision":revision}),
        json!({"status":d.app().transcription.status_name(),"message":message,"retry":retry.map(|r| [r.min.x,r.min.y,r.max.x,r.max.y]),"revision":d.revision()}),
    )?;
    focus_interrupted_retry(d, "Transcription interrupted by system sleep.")?;
    d.wait_for("Explicit retry checks model availability again", |app| {
        app.transcription.status_name() == "needs_model"
    })?;
    d.check(
        "Retry returns to the real missing-model offer without changing the edit",
        d.revision() == revision,
        json!({"revision":revision}),
        json!({"revision":d.revision()}),
    )
}

fn focus_interrupted_retry(d: &mut Driver<'_>, message_text: &str) -> Result<(), String> {
    let retry_label = "Try again  ";
    d.harness.get_by_label(retry_label).focus();
    d.step("Focus explicit transcription retry", true)?;
    // AccessKit focus, scroll offset and the resulting paint can settle in
    // separate frames. Bound the wait on the actual complete painted control.
    for _ in 0..6 {
        let hits = super::sound_placement::control_hits(d, &[retry_label]);
        let message = scenarios::text_paint_visibility(d, message_text);
        let label = scenarios::text_paint_visibility(d, retry_label);
        if hits[0]["complete_hit"] == true
            && !message.is_empty()
            && message.iter().all(|paint| paint["fully_visible"] == true)
            && !label.is_empty()
            && label.iter().all(|paint| paint["fully_visible"] == true)
        {
            break;
        }
        d.step("Wait for fully painted transcription retry", true)?;
    }
    let focused = d.harness.root().children_recursive().any(|node| {
        let access = node.accesskit_node();
        access.role() == egui::accesskit::Role::Button
            && access.label().as_deref() == Some(retry_label)
            && access.is_focused()
            && !access.is_disabled()
            && !access.is_hidden()
    });
    let revealed_message = scenarios::text_paint_visibility(d, message_text);
    let retry_paint = scenarios::text_paint_visibility(d, retry_label);
    let retry_hits = super::sound_placement::control_hits(d, &[retry_label]);
    d.check(
        "Focused transcription retry is fully painted and keyboard accessible",
        focused
            && retry_hits[0]["complete_hit"] == true
            && retry_hits[0]["enabled"] == true
            && !revealed_message.is_empty()
            && revealed_message.iter().all(|paint| paint["fully_visible"] == true)
            && !retry_paint.is_empty()
            && retry_paint
                .iter()
                .all(|paint| paint["fully_visible"] == true),
        json!({"focused":true,"complete_hit":true,"fully_visible":true}),
        json!({"focused":focused,"controls":retry_hits,"paint":retry_paint,"message":revealed_message}),
    )?;
    d.capture(if message_text.starts_with("Pause") {
        "Sleep-interrupted pause detection with focused explicit retry"
    } else {
        "Sleep-interrupted transcription with focused explicit retry"
    })?;
    d.key(Key::Enter)?;
    Ok(())
}

fn interrupted_activity_retry(d: &mut Driver<'_>) -> Result<(), String> {
    d.command("source")?;
    d.wait_for("Pause model availability checked", |app| {
        app.transcription.activity_status_name() == "needs_model" && !app.service.annotation_busy()
    })?;
    let revision = d.revision();
    let workspace = d.app().workspace.as_ref().ok_or("No project")?;
    let words = workspace.transcript.clone().ok_or("No stored words")?;
    let corrections = workspace.corrections.clone();
    let lifecycle = d.app().service.jobs().lifecycle();
    d.app_mut()
        .transcription
        .replay_queued_activity(lifecycle.clone());
    lifecycle.will_sleep();
    lifecycle.did_wake();
    d.wait_for("Standalone pause detection observes sleep", |app| {
        app.transcription.activity_status_name() == "interrupted"
    })?;
    d.step("Wake does not restart standalone pause detection", true)?;
    focus_interrupted_retry(d, "Pause detection interrupted by system sleep.")?;
    d.wait_for("Explicit pause retry checks model availability", |app| {
        app.transcription.activity_status_name() == "needs_model"
    })?;
    let workspace = d.app().workspace.as_ref().ok_or("No project")?;
    let words_unchanged = workspace
        .transcript
        .as_ref()
        .is_some_and(|current| Arc::ptr_eq(current, &words));
    let corrections_unchanged = match (&corrections, &workspace.corrections) {
        (None, None) => true,
        (Some(before), Some(after)) => Arc::ptr_eq(before, after),
        _ => false,
    };
    d.check("Standalone pause interruption and retry preserve stored words, corrections and edit",
        words_unchanged && corrections_unchanged && d.revision() == revision,
        json!({"words_unchanged":true,"corrections_unchanged":true,"revision":revision}),
        json!({"words_unchanged":words_unchanged,"corrections_unchanged":corrections_unchanged,"revision":d.revision()}))
}

pub(super) fn run(d: &mut Driver<'_>) -> Result<(), String> {
    model_offer_visible(d)?;
    interrupted_retry(d)?;
    let revision = d.revision();
    let (key, transcript, index) = synthetic(d)?;
    let session = d.app().workspace.as_ref().ok_or("No project")?.session;
    // Returning to the model offer does not imply that sibling annotation
    // saves have drained from the shared bounded service lane.
    d.wait_for("Annotation lane ready for synthetic transcript", |app| {
        !app.service.annotation_busy()
    })?;
    let submitted = d.app_mut().submit(ProjectRequest::SaveTranscript {
        expected_session: session,
        lifecycle_epoch: None,
        attempt: 0,
        key,
        transcript: Arc::new(transcript.clone()),
    });
    d.check(
        "Synthetic transcript admitted by the available annotation lane",
        submitted,
        json!({"submitted":true}),
        json!({"submitted":submitted,"error":d.app().error}),
    )?;
    d.wait_for("Transcript saved and shown", |app| {
        app.workspace
            .as_ref()
            .is_some_and(|workspace| workspace.transcript.is_some())
            && app.transcription.status_name() == "ready"
    })?;
    d.command("source")?;
    d.settled()?;
    let sentence = scenarios::text_paint_visibility(d, "alpha beta");
    d.check(
        "A saved transcript appears in the rail without changing the edit",
        submitted
            && d.revision() == revision
            && !sentence.is_empty()
            && sentence.iter().all(|paint| paint["fully_visible"] == true),
        json!({"revision":revision,"sentence":"alpha beta"}),
        json!({"revision":d.revision(),"sentence":sentence}),
    )?;
    d.capture("Transcript words in the Original rail")?;

    let expected = |word: usize| -> Result<u64, String> {
        let seconds = transcript
            .seconds(transcript.words()[word].start_cs)
            .map_err(|e| e.to_string())?;
        picture_at(&index, seconds)
            .map(|frame| frame as u64)
            .ok_or_else(|| "synthetic word lies outside the picture".to_owned())
    };
    let search = d.rect("transcript-search").ok();
    let field = d
        .harness
        .root()
        .children_recursive()
        .find(|node| {
            node.accesskit_node().role() == egui::accesskit::Role::TextInput
                && node.accesskit_node().placeholder() == Some("Find words")
        })
        .map(|node| node.rect())
        .or(search)
        .ok_or("Missing transcript search field")?;
    d.click_at("Transcript search field", field.center())?;
    // Real key presses with their text: editor bindings such as `g` must
    // not see keys typed into the field.
    let cursor = d.app().source_cursor;
    let typed = ["g", "a", "m"]
        .into_iter()
        .zip([Key::G, Key::A, Key::M])
        .flat_map(|(text, key)| {
            [
                egui::Event::Key {
                    key,
                    physical_key: Some(key),
                    pressed: true,
                    repeat: false,
                    modifiers: egui::Modifiers::NONE,
                },
                egui::Event::Text(text.into()),
                egui::Event::Key {
                    key,
                    physical_key: Some(key),
                    pressed: false,
                    repeat: false,
                    modifiers: egui::Modifiers::NONE,
                },
            ]
        })
        .collect();
    d.events("Type a transcript search", typed)?;
    d.check(
        "Keys typed into Find words reach the field, not editor bindings",
        d.app().transcription.search_text() == "gam"
            && d.app().bindings.pending().is_empty()
            && d.app().source_cursor == cursor,
        json!({"search":"gam","pending":"","source_cursor":cursor}),
        json!({"search":d.app().transcription.search_text(),"pending":format!("{:?}",d.app().bindings.pending()),"source_cursor":d.app().source_cursor}),
    )?;
    d.key(Key::Enter)?;
    d.settled()?;
    let gamma = expected(2)?;
    d.check(
        "Enter jumps the Original cursor to the first match's exact picture",
        d.app().view == View::Source
            && d.app().source_cursor == gamma
            && d.app().current_word() == Some(2)
            && d.revision() == revision,
        json!({"source_cursor":gamma,"current_word":2}),
        json!({"source_cursor":d.app().source_cursor,"current_word":d.app().current_word(),"view":format!("{:?}",d.app().view)}),
    )?;
    d.capture("Search match and current word")?;

    let text = d
        .harness
        .output()
        .shapes
        .iter()
        .find_map(|clipped| match &clipped.shape {
            egui::Shape::Text(text) if text.galley.text().starts_with("alpha beta") => {
                Some(text.visual_bounding_rect())
            }
            _ => None,
        })
        .ok_or("Missing painted sentence")?;
    d.click_at(
        "First transcript word",
        egui::pos2(text.left() + 4.0, text.center().y),
    )?;
    d.settled()?;
    let alpha = expected(0)?;
    d.check(
        "Clicking a word moves the Original cursor to the picture where it begins",
        d.app().source_cursor == alpha && d.revision() == revision,
        json!({"source_cursor":alpha}),
        json!({"source_cursor":d.app().source_cursor}),
    )?;
    words_in_your_edit(d, &expected)?;
    interrupted_activity_retry(d)?;
    pauses_in_your_edit(d)?;
    repetition_loop_warning(d)?;
    d.report.skipped.push("Replay saves a synthetic transcript; real recognition is covered by the worker tests and transcription qualification. No model is downloaded.".into());
    Ok(())
}

/// A three-word transcript over the fixture's real audio clock.
pub(super) fn synthetic(
    d: &Driver<'_>,
) -> Result<
    (
        deadpan_store::TranscriptKey,
        Transcript,
        deadpan_core::SourceFrameIndex,
    ),
    String,
> {
    let workspace = d.app().workspace.as_ref().ok_or("No project")?;
    let asset = original_asset(workspace).ok_or("No Original")?;
    let source = workspace
        .sources
        .get(asset)
        .ok_or("Missing Original source")?;
    let snapshot = source.receipt.snapshot();
    let audio = snapshot.audio().ok_or("Fixture has no audio")?;
    let video = snapshot.video().ok_or("Fixture has no picture")?;
    let origin = audio
        .frames()
        .first()
        .ok_or("Empty audio index")?
        .valid_start;
    let rate = audio.stream().sample_rate;
    let word = |text: &str, start_cs, end_cs, probability, segment| Word {
        text: text.into(),
        start_cs,
        end_cs,
        probability,
        segment,
    };
    let transcript = Transcript::new(
        AnalysedAudio {
            origin,
            sample_rate: rate,
            duration_cs: 380,
        },
        vec![
            word("alpha", 10, 50, 0.95, 0),
            word("beta", 100, 150, 0.40, 0),
            word("gamma", 200, 260, 0.90, 1),
        ],
    )
    .map_err(|e| e.to_string())?;
    Ok((
        deadpan_store::TranscriptKey {
            content: source.receipt.original().content().to_string(),
            audio_stream: audio.stream().stream_index,
            model_sha256: "a03779c86df3323075f5e796cb2ce5029f00ec8869eee3fdfb897afe36c6d002".into(),
            language: "en".into(),
            engine: "replay".into(),
        },
        transcript,
        video.index().index().clone(),
    ))
}

/// `w` and `diw` in Your edit: motions land on word starts, the cut removes
/// exactly the word's frames, and words follow the edit.
fn words_in_your_edit(
    d: &mut Driver<'_>,
    expected: &dyn Fn(usize) -> Result<u64, String>,
) -> Result<(), String> {
    d.command("sequence")?;
    focus_your_edit(d)?;
    d.chord(&[Key::G, Key::G])?;
    d.settled()?;
    // The baseline presents Original picture k at project frame k.
    let (alpha, beta) = (expected(0)?, expected(1)?);
    d.key(Key::W)?;
    d.settled()?;
    let first = d.app().sequence_cursor;
    d.key(Key::W)?;
    d.settled()?;
    d.check(
        "w moves the Edit cursor to each word's first picture",
        first == alpha && d.app().sequence_cursor == beta,
        json!({"first":alpha,"second":beta}),
        json!({"first":first,"second":d.app().sequence_cursor,"message":d.app().message}),
    )?;
    let before = d.app_mut().edit_speech()?;
    let word = before
        .runs()
        .iter()
        .find(|run| run.word == 1)
        .copied()
        .ok_or("beta has no run in Your edit")?;
    let duration = d
        .app()
        .workspace
        .as_ref()
        .ok_or("No project")?
        .plan
        .duration()
        .frames();
    let revision = d.revision();
    d.chord(&[Key::D, Key::I, Key::W])?;
    d.changed(&revision)?;
    d.settled()?;
    let after = d.app_mut().edit_speech()?;
    let remaining: Vec<u32> = after.runs().iter().map(|run| run.word).collect();
    let shortened = d
        .app()
        .workspace
        .as_ref()
        .ok_or("No project")?
        .plan
        .duration()
        .frames();
    d.check(
        "diw cuts exactly the word's frames and the transcript follows the edit",
        duration - shortened == word.range.duration().frames()
            && remaining == [0, 2]
            && after.runs()[1].range.start().0
                == before.runs()[2].range.start().0 - word.range.duration().frames(),
        json!({"removed":word.range.duration().frames(),"words":[0,2]}),
        json!({"removed":duration - shortened,"words":remaining}),
    )?;
    scenarios::reveal_original_rail(d, "Your edit · 2 of 3 words kept", false)?;
    let alpha_paint = scenarios::text_paint_visibility(d, "alpha");
    let beta_paint = scenarios::text_paint_visibility(d, "beta");
    let caption = scenarios::text_paint_visibility(d, "Your edit · 2 of 3 words kept");
    d.check(
        "In Your edit the rail lists the edit's words, without the cut one",
        !alpha_paint.is_empty()
            && alpha_paint.iter().all(|item| item["fully_visible"] == true)
            && beta_paint.is_empty()
            && !caption.is_empty()
            && caption.iter().all(|item| item["fully_visible"] == true),
        json!({"alpha":"painted","beta":"absent","caption":"2 of 3 words kept"}),
        json!({"alpha":alpha_paint,"beta":beta_paint,"caption":caption}),
    )?;
    d.capture("Word cut from Your edit")?;
    let cut = d.revision();
    d.key(Key::U)?;
    d.changed(&cut)?;
    d.settled()?;

    // A split inside a word changes beats, not words.
    d.chord(&[Key::G, Key::G])?;
    d.chord(&[Key::W, Key::W, Key::L, Key::L])?;
    let revision = d.revision();
    d.key(Key::S)?;
    d.changed(&revision)?;
    d.settled()?;
    let split = d.app_mut().edit_speech()?;
    let runs: Vec<(u32, i64, i64)> = split
        .runs()
        .iter()
        .map(|run| (run.word, run.range.start().0, run.range.end().0))
        .collect();
    let unchanged: Vec<(u32, i64, i64)> = before
        .runs()
        .iter()
        .map(|run| (run.word, run.range.start().0, run.range.end().0))
        .collect();
    d.check(
        "Splitting inside a word keeps one word occurrence",
        runs == unchanged,
        json!(unchanged),
        json!(runs),
    )?;
    let split_revision = d.revision();
    d.key(Key::U)?;
    d.changed(&split_revision)?;
    d.settled()?;

    // The rail search ("gam") steps through its occurrences in Your edit.
    focus_your_edit(d)?;
    d.chord(&[Key::G, Key::G])?;
    let gamma = d
        .app_mut()
        .edit_speech()?
        .runs()
        .iter()
        .find(|run| run.word == 2)
        .map(|run| run.range.start().0 as u64)
        .ok_or("gamma has no run in Your edit")?;
    d.key(Key::N)?;
    d.settled()?;
    let next = d.app().sequence_cursor;
    d.key_modified(Key::N, egui::Modifiers::SHIFT)?;
    d.settled()?;
    d.check(
        "n and N move the Edit cursor to matching words in Your edit, wrapping",
        next == gamma
            && d.app().sequence_cursor == gamma
            && d.app()
                .message
                .as_deref()
                .is_some_and(|message| message.contains("wrapped")),
        json!({"next":gamma,"previous":gamma,"wrapped":true}),
        json!({"next":next,"previous":d.app().sequence_cursor,"message":d.app().message}),
    )?;
    d.events(
        "Slash focuses Find words",
        vec![
            egui::Event::Key {
                key: Key::Slash,
                physical_key: Some(Key::Slash),
                pressed: true,
                repeat: false,
                modifiers: egui::Modifiers::NONE,
            },
            egui::Event::Text("/".into()),
        ],
    )?;
    d.settled()?;
    let focused = d
        .harness
        .ctx
        .memory(|memory| memory.has_focus(egui::Id::new(TRANSCRIPT_SEARCH_ID)));
    d.check(
        "/ focuses the transcript search without typing a slash",
        focused && d.app().transcription.search_text() == "gam",
        json!({"focused":true,"search":"gam"}),
        json!({"focused":focused,"search":d.app().transcription.search_text()}),
    )?;
    d.key(Key::Escape)?;
    d.settled()?;
    Ok(())
}

pub(super) fn focus_your_edit(d: &mut Driver<'_>) -> Result<(), String> {
    for _ in 0..6 {
        if d.app().pane == Pane::Sequence
            && d.harness
                .ctx
                .memory(|memory| memory.has_focus(pane_id(Pane::Sequence)))
        {
            return Ok(());
        }
        d.key(Key::Tab)?;
    }
    Err("Keyboard focus could not reach Your edit".into())
}

/// `]p`, `[p` and `dip` in Your edit against synthetic speech activity:
/// quiet from 0.60 to 0.95 s and from 1.60 to 1.95 s of the fixture's audio.
fn pauses_in_your_edit(d: &mut Driver<'_>) -> Result<(), String> {
    let workspace = d.app().workspace.as_ref().ok_or("No project")?;
    let asset = original_asset(workspace).ok_or("No Original")?;
    let source = workspace
        .sources
        .get(asset)
        .ok_or("Missing Original source")?;
    let audio = source
        .receipt
        .snapshot()
        .audio()
        .ok_or("Fixture has no audio")?;
    let origin = audio
        .frames()
        .first()
        .ok_or("Empty audio index")?
        .valid_start;
    let samples: u64 = 60_800;
    let quiet =
        |sample: u64| (9_600..15_200).contains(&sample) || (25_600..31_200).contains(&sample);
    let speech = (0..samples.div_ceil(deadpan_analysis::VAD_HOP))
        .map(|hop| {
            if quiet(hop * deadpan_analysis::VAD_HOP + 256) {
                0
            } else {
                240
            }
        })
        .collect();
    let energy = (0..samples.div_ceil(deadpan_analysis::ENERGY_HOP))
        .map(|frame| {
            if quiet(frame * deadpan_analysis::ENERGY_HOP + 80) {
                20
            } else {
                200
            }
        })
        .collect();
    let activity = SpeechActivity::new(
        ActivityAudio {
            origin,
            sample_rate: audio.stream().sample_rate,
            samples,
        },
        speech,
        energy,
    )
    .map_err(|e| e.to_string())?;
    let key = deadpan_store::SpeechActivityKey {
        content: source.receipt.original().content().to_string(),
        audio_stream: audio.stream().stream_index,
        model_sha256: "2aa269b785eeb53a82983a20501ddf7c1d9c48e33ab63a41391ac6c9f7fb6987".into(),
        engine: "replay".into(),
    };
    let session = workspace.session;
    let revision = d.revision();
    let submitted = d.app_mut().submit(ProjectRequest::SaveSpeechActivity {
        expected_session: session,
        lifecycle_epoch: None,
        attempt: 0,
        key,
        activity: Arc::new(activity),
    });
    d.wait_for("Speech activity saved", |app| {
        app.workspace
            .as_ref()
            .is_some_and(|workspace| workspace.speech_activity.is_some())
    })?;
    focus_your_edit(d)?;
    d.chord(&[Key::G, Key::G])?;
    d.settled()?;
    let pauses: Vec<(i64, i64)> = d
        .app_mut()
        .edit_analysis()?
        .pauses()
        .ok_or("pauses are not projected")?
        .iter()
        .map(|pause| (pause.start().0, pause.end().0))
        .collect();
    d.chord(&[Key::CloseBracket, Key::P])?;
    d.settled()?;
    let first = d.app().sequence_cursor;
    d.chord(&[Key::CloseBracket, Key::P])?;
    d.settled()?;
    let second = d.app().sequence_cursor;
    d.chord(&[Key::OpenBracket, Key::P])?;
    d.settled()?;
    let back = d.app().sequence_cursor;
    d.check(
        "]p and [p move the Edit cursor between pause starts without editing",
        submitted
            && d.revision() == revision
            && pauses.len() == 2
            && first == pauses[0].0 as u64
            && second == pauses[1].0 as u64
            && back == pauses[0].0 as u64,
        json!({"pauses":2,"first":pauses.first().map(|p| p.0),"second":pauses.get(1).map(|p| p.0)}),
        json!({"pauses":pauses,"first":first,"second":second,"back":back,"message":d.app().message}),
    )?;
    d.chord(&[Key::G, Key::G])?;
    d.settled()?;
    d.chord(&[Key::CloseBracket, Key::P])?;
    d.settled()?;
    let duration = |d: &Driver<'_>| -> Result<i64, String> {
        Ok(d.app()
            .workspace
            .as_ref()
            .ok_or("No project")?
            .plan
            .duration()
            .frames())
    };
    let before = duration(d)?;
    let revision = d.revision();
    d.chord(&[Key::D, Key::I, Key::P])?;
    d.changed(&revision)?;
    d.settled()?;
    let after: Vec<(i64, i64)> = d
        .app_mut()
        .edit_analysis()?
        .pauses()
        .ok_or("pauses are not projected")?
        .iter()
        .map(|pause| (pause.start().0, pause.end().0))
        .collect();
    let removed = pauses[0].1 - pauses[0].0;
    d.check(
        "dip cuts exactly the pause's frames and the later pause follows the edit",
        before - duration(d)? == removed
            && after == [(pauses[1].0 - removed, pauses[1].1 - removed)],
        json!({"removed":removed,"pauses":[(pauses[1].0 - removed, pauses[1].1 - removed)]}),
        json!({"removed":before - duration(d)?,"pauses":after}),
    )?;
    d.capture("Pause cut from Your edit")?;
    let cut = d.revision();
    d.key(Key::U)?;
    d.changed(&cut)?;
    d.settled()?;
    d.chord(&[Key::G, Key::G])?;
    d.key_modified(Key::G, egui::Modifiers::SHIFT)?;
    d.settled()?;
    let end = d.app().sequence_cursor;
    d.chord(&[Key::CloseBracket, Key::P])?;
    d.settled()?;
    d.check(
        "]p after the last pause stays put and says why",
        d.app().sequence_cursor == end
            && d.app()
                .message
                .as_deref()
                .is_some_and(|message| message.contains("no later pause")),
        json!({"cursor":end,"message":"no later pause"}),
        json!({"cursor":d.app().sequence_cursor,"message":d.app().message}),
    )?;
    Ok(())
}

/// A transcript whose words fall into a repetition loop shows the recognizer
/// failure warning with a link to the passage and an explicit offer to
/// recognize it again. The words themselves are kept as recognized.
fn repetition_loop_warning(d: &mut Driver<'_>) -> Result<(), String> {
    let (key, plain, index) = synthetic(d)?;
    let audio = plain.audio();
    let mut words = vec![Word {
        text: "Hello.".into(),
        start_cs: 10,
        end_cs: 40,
        probability: 0.95,
        segment: 0,
    }];
    // "I was here." eight times: a 24-word loop of a 3-word phrase.
    for copy in 0..8_u32 {
        for (offset, text) in ["I", "was", "here."].into_iter().enumerate() {
            let start = 50 + copy * 36 + offset as u32 * 12;
            words.push(Word {
                text: text.into(),
                start_cs: start,
                end_cs: start + 10,
                probability: 0.97,
                segment: 1 + copy,
            });
        }
    }
    let looped = Transcript::new(audio, words).map_err(|e| e.to_string())?;
    let session = d.app().workspace.as_ref().ok_or("No project")?.session;
    let revision = d.revision();
    d.app_mut().submit(ProjectRequest::SaveTranscript {
        expected_session: session,
        lifecycle_epoch: None,
        attempt: 0,
        key,
        transcript: Arc::new(looped.clone()),
    });
    d.wait_for("Looping transcript published", |app| {
        app.workspace
            .as_ref()
            .and_then(|workspace| workspace.transcript.as_ref())
            .is_some_and(|transcript| transcript.proposal.words().len() == 25)
    })?;
    d.command("source")?;
    d.settled()?;
    scenarios::reveal_original_rail(d, "Recognize again", false)?;
    let warning = scenarios::text_paint_visibility(d, "Recognition may have failed in 1 passage");
    let passage = scenarios::text_paint_visibility(d, "“I was here.” repeats 8×");
    let offer = scenarios::text_paint_visibility(d, "Recognize again");
    let kept = d
        .app()
        .workspace
        .as_ref()
        .and_then(|workspace| workspace.transcript.as_ref())
        .is_some_and(|transcript| transcript.transcript == looped);
    d.check(
        "A repetition loop is flagged with its passage and an explicit offer, and no word changes",
        kept && d.revision() == revision
            && [&warning, &passage, &offer]
                .iter()
                .all(|paints| !paints.is_empty() && paints.iter().all(|paint| paint["fully_visible"] == true)),
        json!({"warning":"Recognition may have failed in 1 passage","passage":"“I was here.” repeats 8×","offer":"Recognize again","words_kept":true}),
        json!({"warning":warning,"passage":passage,"offer":offer,"words_kept":kept,"revision":d.revision()}),
    )?;
    d.capture("Repetition loop flagged in the transcript rail")?;
    let link = d
        .harness
        .output()
        .shapes
        .iter()
        .find_map(|clipped| match &clipped.shape {
            egui::Shape::Text(text) if text.galley.text().starts_with("“I was here.”") => {
                Some(text.visual_bounding_rect())
            }
            _ => None,
        })
        .ok_or("Missing passage link")?;
    d.click_at("Flagged passage", link.center())?;
    d.settled()?;
    let seconds = looped
        .seconds(looped.words()[1].start_cs)
        .map_err(|e| e.to_string())?;
    let first = picture_at(&index, seconds).ok_or("loop outside the picture")? as u64;
    d.check(
        "Clicking a flagged passage moves the Original cursor to where it begins",
        d.app().source_cursor == first,
        json!({"source_cursor":first}),
        json!({"source_cursor":d.app().source_cursor}),
    )?;
    Ok(())
}
