//! Authored sound placement through production import, input and project services.

use super::*;
use deadpan_core::{AudioEdgePolicy, AudioSample, ExactRatio, FrameDuration, SoundEvent, SoundId};
use egui::{Key, Modifiers};

mod allowances;

pub(super) fn run(d: &mut Driver<'_>) -> Result<(), String> {
    d.report.skipped.push(
        "Sound placement uses real source qualification and durable project commands. This scenario does not start audio output or establish PCM, device timing, or listening evidence.".into(),
    );
    let fixture = Path::new(env!("CARGO_MANIFEST_DIR"))
        .join("../../native/deadpan-source/tests/audio-fixtures/pcm-stereo-48000.wav")
        .canonicalize()
        .map_err(|error| error.to_string())?;
    d.app_mut().dialogs = Dialogs::scripted(vec![(DialogKind::ImportSound, Some(fixture))]);
    scenarios::choose_sound_interpretation(
        d,
        Some(crate::project::AudioLayoutInterpretation::StereoLeftRight),
    )?;
    d.click("Add sound…  ⌘I")?;
    d.wait_for("Sound is qualified in the real catalog", |app| {
        app.sound_rows.len() == 1 && !app.service.is_busy() && !app.importing()
    })?;
    d.command("sequence")?;
    d.chord(&[Key::G, Key::G, Key::Num2, Key::L])?;
    d.settled()?;
    let catalog = d.app().sound_rows[0].clone();
    let baseline = targets(d);
    let nodes = document(d)?.nodes().clone();
    let initial_sounds = document(d)?.sounds().clone();
    let rate = document(d)?.presentation_basis().frame_rate;
    let onset = rate
        .audio_boundary(ProjectFrame(2))
        .map_err(|error| error.to_string())?;
    d.check(
        "Placement starts from an explicit edit cursor and retained beat",
        d.app().sequence_cursor == 2 && d.app().selected_beat.is_some(),
        json!({"edit_frame":2,"selected_beat":true}),
        d.snapshot(),
    )?;
    resize(d, 960.0, 640.0)?;
    d.step("Paint compact empty Sounds after resize", true)?;
    d.settled()?;
    empty_heading(d)?;
    let revision = d.revision();
    d.command("source")?;
    d.settled()?;
    d.wait_for(
        "Picture renderer is idle before compact pane entry",
        |app| app.renderer.is_idle().is_ok_and(|idle| idle),
    )?;
    let picture = d.app().presentation.diagnostic_snapshot()["displayed"].clone();
    d.click("Placed sounds pane")?;
    final_picture_submission(d, &picture)?;
    empty_heading(d)?;
    d.check(
        "Pointer entry from Original moves the empty Sounds target on the release frame",
        d.app().view == View::Sequence
            && d.app().pane == Pane::Sounds
            && d.revision() == revision
            && targets(d) == baseline,
        json!({"view":"Sequence","pane":"Sounds","revision":revision,"targets":baseline}),
        d.snapshot(),
    )?;
    for (label, view) in [("Original", View::Source), ("Your edit", View::Sequence)] {
        d.settled()?;
        d.wait_for("Picture renderer is idle before viewer tab entry", |app| {
            app.renderer.is_idle().is_ok_and(|idle| idle)
        })?;
        d.click(label)?;
        cleared_picture_transition(d, view)?;
    }
    d.command("source")?;
    d.settled()?;
    d.key(Key::Colon)?;
    d.wait_for(
        "Picture renderer is idle before command and resize",
        |app| app.renderer.is_idle().is_ok_and(|idle| idle),
    )?;
    resize(d, 1000.0, 660.0)?;
    d.events(
        "Submit Sequence native text together with a compact resize",
        vec![
            egui::Event::Text("sequence".into()),
            key_event(Key::Enter, Modifiers::NONE, true),
            key_event(Key::Enter, Modifiers::NONE, false),
        ],
    )?;
    cleared_picture_transition(d, View::Sequence)?;
    resize(d, 960.0, 640.0)?;
    d.step(
        "Restore minimum viewport after combined command and resize",
        true,
    )?;
    d.settled()?;
    d.click("Current group beat outline pane")?;
    d.key(Key::Tab)?;
    empty_heading(d)?;
    d.check(
        "Normal Tab reaches the visible empty Sounds heading without changing editor targets",
        d.app().pane == Pane::Sounds
            && d.harness
                .ctx
                .memory(|memory| memory.has_focus(pane_id(Pane::Sounds)))
            && d.revision() == revision
            && targets(d) == baseline,
        json!({"pane":"Sounds","revision":revision,"targets":baseline}),
        d.snapshot(),
    )?;
    d.key_modified(Key::Tab, Modifiers::SHIFT)?;
    scenarios::reveal_original_rail(d, &catalog.1, false)?;
    d.click(&catalog.1)?;
    // The catalog click changes selection on release; its dependent controls
    // enter the UI tree on the next paint, as in the native event loop.
    d.step("Paint controls for the selected catalog sound", true)?;
    let before = d.revision();
    d.click("Place at edit cursor  ,s")?;
    d.changed(&before)?;
    let first = selected(d)?;
    let first_recipe = event(d, &first)?;
    d.check(
        "Placement authors one root sound without changing picture duration or editor targets",
        document(d)?.sounds().len() == initial_sounds.len() + 1
            && first_recipe.owner == *document(d)?.root()
            && first_recipe.source.asset == catalog.0
            && first_recipe.offset == onset
            && document(d)?.nodes() == &nodes
            && targets(d) == baseline,
        json!({"offset":onset,"targets":baseline,"unchanged_picture_nodes":true}),
        d.snapshot(),
    )?;
    visible(d, "PLACED SOUNDS")?;
    d.check(
        "First placement restores the full Sounds pane below Beats",
        d.rect("Placed sounds pane")?.top() > d.rect("Current group beat outline pane")?.bottom()
            && scenarios::text_paint_visibility(d, "PLACED SOUNDS 0 · ,s place").is_empty(),
        json!("Populated Sounds panel, with no compact empty entry"),
        d.widgets(),
    )?;

    let before = d.revision();
    d.key(Key::U)?;
    d.changed(&before)?;
    d.check(
        "One undo removes only the placed sound",
        document(d)?.sounds() == &initial_sounds
            && document(d)?.nodes() == &nodes
            && targets(d) == baseline,
        json!({"sounds":initial_sounds,"targets":baseline}),
        d.snapshot(),
    )?;
    d.command("sounds")?;
    empty_heading(d)?;
    d.check(
        "Undo returns the empty Sounds pane with its existing focus identity",
        d.app().pane == Pane::Sounds
            && d.harness
                .ctx
                .memory(|memory| memory.has_focus(pane_id(Pane::Sounds)))
            && targets(d) == baseline,
        json!({"pane":"Sounds","targets":baseline}),
        d.snapshot(),
    )?;
    let before = d.revision();
    d.key_modified(Key::R, Modifiers::CTRL)?;
    d.changed(&before)?;
    d.command("sounds")?;
    d.check(
        "Redo restores the same sound identity and recipe",
        event(d, &first)? == first_recipe && targets(d) == baseline,
        json!({"sound":first,"recipe":first_recipe}),
        d.snapshot(),
    )?;
    resize(d, 1280.0, 820.0)?;
    d.step("Restore default sound-placement workspace", true)?;
    d.settled()?;
    focus_entry(d, &first, &baseline)?;

    // Exercise the actual text widget, including final native text and closing
    // keys in one frame. Neither cancellation nor text letters may edit a beat.
    d.key(Key::Enter)?;
    d.check(
        "Enter offers an exact sample position in the native command footer",
        d.app().command_open && d.app().command == format!("sound-at {}", onset.0),
        json!(format!("sound-at {}", onset.0)),
        d.snapshot(),
    )?;
    d.key_modified(Key::A, Modifiers::COMMAND)?;
    let before = d.revision();
    d.events(
        "Native command text and Escape cancel sound editing in one frame",
        vec![
            key_event(Key::D, Modifiers::NONE, true),
            key_event(Key::D, Modifiers::NONE, false),
            key_event(Key::D, Modifiers::NONE, true),
            key_event(Key::D, Modifiers::NONE, false),
            egui::Event::Text("sound-at 999 dd ".into()),
            key_event(Key::Escape, Modifiers::NONE, true),
            key_event(Key::Escape, Modifiers::NONE, false),
        ],
    )?;
    scenarios::footer_anchored(d, "Cancelled sound position footer remains anchored")?;
    d.check(
        "Cancellation retains native text and performs no sound or beat command",
        !d.app().command_open
            && d.app().command == "sound-at 999 dd "
            && d.revision() == before
            && event(d, &first)? == first_recipe
            && document(d)?.nodes() == &nodes,
        json!("Closed command with final text; unchanged revision and recipe"),
        d.snapshot(),
    )?;
    d.key(Key::Enter)?;
    d.key_modified(Key::A, Modifiers::COMMAND)?;
    d.events(
        "Commit exact sample 137 from final native text and Enter",
        vec![
            egui::Event::Text("sound-at 137".into()),
            key_event(Key::Enter, Modifiers::NONE, true),
            key_event(Key::Enter, Modifiers::NONE, false),
        ],
    )?;
    d.changed(&before)?;
    check_offset(
        d,
        &first,
        137,
        "Fine positioning retains sample 137 without frame rounding",
    )?;
    d.key(Key::Enter)?;
    d.key_modified(Key::A, Modifiers::COMMAND)?;
    d.events(
        "Native sound command hints accept a leading colon and uppercase verb",
        vec![egui::Event::Text(":SOUND-AT 137".into())],
    )?;
    visible(d, "Position: whole 48 kHz samples · 48,000 = 1 second")?;
    d.key(Key::Escape)?;

    d.command("sounds")?;
    let before = d.revision();
    d.key(Key::L)?;
    d.changed(&before)?;
    let frame_samples = rate
        .audio_boundary(ProjectFrame(1))
        .map_err(|error| error.to_string())?
        .0;
    check_onset(
        d,
        &first,
        137 + frame_samples,
        "Sound l moves one project frame on the sample clock",
    )?;
    d.check(
        "Frame nudges translate the exact recipe without changing its sample offset",
        event(d, &first)?.offset == AudioSample(137)
            && event(d, &first)?.mapping.start_frames() == ExactRatio::integer(1),
        json!({"offset":137,"mapping_start_frames":1}),
        json!(event(d, &first)?),
    )?;
    let exact_revision = d.revision();
    let exact_recipe = event(d, &first)?;
    let rounded_onset = audible(d, &first)?.start.0;
    d.key(Key::Enter)?;
    d.check(
        "The exact-phase sound opens a rounded sample label without editing its recipe",
        d.app().command_open && d.app().command == format!("sound-at {rounded_onset}"),
        json!(format!("sound-at {rounded_onset}")),
        d.snapshot(),
    )?;
    d.key(Key::Enter)?;
    d.wait_for(
        "Unchanged sound position entry finishes without work",
        |app| !app.service.is_busy(),
    )?;
    d.step(
        "Observe any completion after accepting an unchanged sound position",
        false,
    )?;
    d.check(
        "Accepting the unchanged rounded position preserves exact phase and creates no history",
        !d.app().command_open
            && d.revision() == exact_revision
            && event(d, &first)? == exact_recipe,
        json!({"revision":exact_revision,"recipe":exact_recipe}),
        d.snapshot(),
    )?;
    let before = d.revision();
    d.key(Key::L)?;
    d.changed(&before)?;
    let twice = event(d, &first)?;
    let twice_audible = audible(d, &first)?;
    let before = d.revision();
    d.chord(&[Key::Num2, Key::H])?;
    d.changed(&before)?;
    check_onset(
        d,
        &first,
        137,
        "A two-frame reverse nudge restores the exact onset",
    )?;
    let before = d.revision();
    d.chord(&[Key::Num2, Key::L])?;
    d.changed(&before)?;
    d.check(
        "Two single-frame sound nudges equal one counted two-frame nudge",
        event(d, &first)? == twice && audible(d, &first)? == twice_audible,
        json!({"recipe":twice,"audible":twice_audible}),
        json!({"recipe":event(d, &first)?,"audible":audible(d, &first)?}),
    )?;
    for _ in 0..2 {
        let before = d.revision();
        d.key(Key::H)?;
        d.changed(&before)?;
    }
    check_onset(
        d,
        &first,
        137,
        "Sound h reverses the frame step without moving the edit cursor",
    )?;
    commit(d, "sound-gain -3")?;
    check_gain(d, &first, -3_000)?;
    d.command("sounds")?;
    let before = d.revision();
    d.key(Key::Plus)?;
    d.changed(&before)?;
    check_gain(d, &first, 0)?;
    let before = d.revision();
    d.key(Key::Minus)?;
    d.changed(&before)?;
    check_gain(d, &first, -3_000)?;
    for (command, expected) in [
        ("sound-edges hard", AudioEdgePolicy::Hard),
        ("sound-edges soft", AudioEdgePolicy::Automatic),
    ] {
        commit(d, command)?;
        let recipe = event(d, &first)?;
        d.check(
            "Edge commands set both sound endpoints without replacing the recipe",
            recipe.start_edge == expected
                && recipe.end_edge == expected
                && recipe.source == first_recipe.source
                && same_mapping(&recipe, &first_recipe)?
                && recipe.offset == AudioSample(137),
            json!({"edge":expected,"offset":137}),
            json!(recipe),
        )?;
    }
    d.check(
        "Sound parameters retain the Original, picture nodes, cursors and selected beat",
        targets(d) == baseline && document(d)?.nodes() == &nodes,
        baseline.clone(),
        d.snapshot(),
    )?;
    command_targets(d, &first, &baseline)?;

    rejected(
        d,
        "sound-at 9223372036854775807",
        "Overflowing placement reports an error without an edit",
    )?;
    // A valid command also proves recovery from the rejected edit.
    commit(d, "sound-gain -6")?;
    scenarios::reveal_original_rail(d, &catalog.1, false)?;
    d.click(&catalog.1)?;
    let before = d.revision();
    d.chord(&[Key::Comma, Key::S])?;
    d.changed(&before)?;
    let second = selected(d)?;
    d.check(
        "Comma s places a separate event from the same catalog asset",
        second != first && document(d)?.sounds().len() == 2,
        json!("Two independently authored sound events"),
        d.snapshot(),
    )?;
    d.command("sounds")?;
    let ordered = document(d)?.sounds().keys().cloned().collect::<Vec<_>>();
    d.chord(&[Key::Num6, Key::Num4, Key::K])?;
    d.check(
        "Placed-sound k selects the first displayed event without selecting a beat",
        d.app().selected_event.as_ref() == Some(&ordered[0]) && targets(d) == baseline,
        json!({"selected_event":ordered[0],"targets":baseline}),
        d.snapshot(),
    )?;
    d.key(Key::J)?;
    d.check(
        "Placed-sound j selects the next event and retains beat selection",
        d.app().selected_event.as_ref() == Some(&ordered[1]) && targets(d) == baseline,
        json!({"selected_event":ordered[1],"targets":baseline}),
        d.snapshot(),
    )?;
    for (width, height) in [(960.0, 640.0), (1280.0, 820.0)] {
        resize(d, width, height)?;
        d.capture(&format!(
            "Placed sounds and exact inspector at {width}x{height}"
        ))?;
        visible(d, "PLACED SOUNDS")?;
        reveal(d, "Start", 240.0)?;
        d.settled()?;
        d.capture(&format!("Settled sound workspace at {width}x{height}"))?;
        scenarios::viewer_visible(d)?;
        let label = d
            .app()
            .presentation
            .displayed_label()
            .ok_or("Missing picture label")?;
        let viewer = d.rect(&label)?;
        // The compact viewer applies with a populated Placed sounds panel:
        // its caption shares the clock row (145 points before 2026-10-15).
        let minimum = if width <= 960.0 { 185.0 } else { 120.0 };
        d.check(
            "Sound editing retains useful picture height at the minimum viewport",
            viewer.height() >= minimum,
            json!({"minimum_picture_height":minimum}),
            json!({"viewer_height":viewer.height(),"viewport":[width,height]}),
        )?;
        if width == 960.0 {
            compact_playback(d)?;
        }
        reveal(d, "Fine position · 48 kHz samples", 240.0)?;
        visible(d, "Fine position · 48 kHz samples")?;
        reveal(d, "Change gain  + / -", -240.0)?;
        visible(d, "Change gain  + / -")?;
        reveal(d, "Remove sound  dd", -240.0)?;
        visible(d, "Remove sound  dd")?;
        d.capture(&format!("Sound removal is reachable at {width}x{height}"))?;
        retained_fixture_picture(d)?;
        d.check(
            "Placed sounds keep a distinct pane focus at both window sizes",
            d.app().pane == Pane::Sounds,
            json!("Sounds"),
            d.snapshot(),
        )?;
        d.key(Key::Enter)?;
        scenarios::footer_anchored(
            d,
            "Exact sound position footer remains visible after resize",
        )?;
        d.capture(&format!("Exact sound command footer at {width}x{height}"))?;
        visible(d, "Position: whole 48 kHz samples · 48,000 = 1 second")?;
        d.key(Key::Escape)?;
        d.command("sounds")?;
    }
    choose(d, &second)?;
    reveal(d, "Change gain  + / -", 240.0)?;
    d.click("Change gain  + / -")?;
    d.key(Key::Escape)?;
    d.check(
        "The sound inspector owns destructive shortcuts while the picture beat stays selected",
        d.app().pane == Pane::Inspector
            && d.app().selected_event.as_ref() == Some(&second)
            && targets(d) == baseline,
        json!({"pane":"Inspector","selected_event":second,"targets":baseline}),
        d.snapshot(),
    )?;
    let before = d.revision();
    d.chord(&[Key::D, Key::D])?;
    d.changed(&before)?;
    d.check(
        "Sound dd removes its event while preserving the selected picture beat",
        !document(d)?.sounds().contains_key(&second)
            && document(d)?.sounds().contains_key(&first)
            && document(d)?.nodes() == &nodes
            && targets(d) == baseline,
        json!({"removed_sound":second,"retained_sound":first,"targets":baseline}),
        d.snapshot(),
    )?;
    let before = d.revision();
    d.key(Key::U)?;
    d.changed(&before)?;
    // Undo need not resurrect ephemeral selection. Select the second event using
    // the same bounded row navigation as a user before its pointer removal.
    choose(d, &second)?;
    d.check(
        "Undo restores the removable second event",
        document(d)?.sounds().contains_key(&second)
            && d.app().selected_event.as_ref() == Some(&second),
        json!(second),
        d.snapshot(),
    )?;
    let before = d.revision();
    reveal(d, "Remove sound  dd", -240.0)?;
    d.click("Remove sound  dd")?;
    d.changed(&before)?;
    d.check(
        "Pointer removal shares sound deletion and never deletes the retained beat",
        document(d)?.sounds().len() == 1
            && document(d)?.sounds().contains_key(&first)
            && document(d)?.nodes() == &nodes
            && targets(d) == baseline,
        json!({"remaining_sound":first,"targets":baseline}),
        d.snapshot(),
    )?;

    d.command("sequence")?;
    d.check(
        "The sequence command leaves sound focus before an immediate structural edit",
        d.app().pane == Pane::Sequence
            && !d.app().event_focused()
            && d.app().selected_event.is_none()
            && d.app().sound_inspection.is_none()
            && targets(d) == baseline,
        json!({"pane":"Sequence","selected_event":null,"targets":baseline}),
        d.snapshot(),
    )?;
    let before = d.revision();
    d.command("hold 2f")?;
    d.changed(&before)?;
    let routes = document(d)?.sound_routes().clone();
    let routed = event(d, &first)?;
    d.check(
        "Inserting a pause through the sound creates retained root routing",
        routes
            .get(&first)
            .is_some_and(|route| !route.edits.is_empty())
            && routed.offset == AudioSample(137)
            && same_mapping(&routed, &first_recipe)?,
        json!("A nonempty sound route with the original recipe phase and offset"),
        d.snapshot(),
    )?;
    d.command("sounds")?;
    commit(d, "sound-gain -9")?;
    check_gain(d, &first, -9_000)?;
    d.check(
        "Changing a routed sound's gain preserves the exact edit journal",
        document(d)?.sound_routes() == &routes,
        json!(routes),
        d.snapshot(),
    )?;
    rejected(
        d,
        "sound-at 200",
        "Moving a routed sound rejects without losing its journal",
    )?;
    d.capture("Routed sound retains its journal after rejected repositioning")?;
    allowances::run(d, &first, &catalog.1)?;
    recorded_placement(d, &catalog.1)
}

/// While a macro records, `,s` in Your edit places the selected catalog sound
/// through one recorded `PlaceSound`; running the macro places it again at
/// the new cursor.
fn recorded_placement(d: &mut Driver<'_>, label: &str) -> Result<(), String> {
    scenarios::reveal_original_rail(d, label, false)?;
    d.click(label)?;
    d.settled()?;
    let asset = d
        .app()
        .selected_sound
        .clone()
        .ok_or("No catalog sound is selected")?;
    let rate = document(d)?.presentation_basis().frame_rate;
    // Selecting in the catalog retains the sound while Your edit takes focus.
    d.click("Current group beat outline pane")?;
    d.chord(&[Key::G, Key::G, Key::Num4, Key::L])?;
    d.settled()?;
    if d.app().selected_sound.as_ref() != Some(&asset) {
        return Err("Focusing Your edit dropped the catalog sound".into());
    }
    let count = document(d)?.sounds().len();
    d.command("record p")?;
    let before = d.revision();
    d.chord(&[Key::Comma, Key::S])?;
    d.changed(&before)?;
    d.wait_for("The recorded placement is acknowledged", |app| {
        !app.service.is_busy() && !app.macros.is_pending()
    })?;
    d.command("record-stop")?;
    d.wait_for("Macro p is saved", |app| {
        !app.service.is_busy()
            && !app.macros.recording()
            && app.copied.entries().any(|(slot, value)| {
                slot == 'p' && matches!(value, crate::preview::copied::Content::Macro(_))
            })
    })?;
    let recorded = d
        .app()
        .copied
        .entries()
        .find_map(|(slot, value)| match value {
            crate::preview::copied::Content::Macro(program) if slot == 'p' => {
                Some(program.instructions().to_vec())
            }
            _ => None,
        });
    let expected = deadpan_core::SemanticInstruction::PlaceSound {
        asset: asset.clone(),
    };
    let onset = |frame| {
        rate.audio_boundary(ProjectFrame(frame))
            .map_err(|e| e.to_string())
    };
    let at_four = onset(4)?;
    d.check(
        "Recording ,s saves one PlaceSound and places the sound at the cursor",
        recorded.as_deref() == Some(std::slice::from_ref(&expected))
            && document(d)?.sounds().len() == count + 1
            && document(d)?
                .sounds()
                .values()
                .any(|event| event.source.asset == asset && event.offset == at_four),
        json!({"instructions":[expected],"sounds":count + 1,"onset":at_four}),
        json!({"recorded":recorded,"sounds":document(d)?.sounds().len()}),
    )?;
    d.chord(&[Key::G, Key::G, Key::Num6, Key::L])?;
    d.settled()?;
    let before = d.revision();
    d.command("macro p")?;
    d.changed(&before)?;
    d.wait_for("The macro run is acknowledged", |app| {
        !app.service.is_busy() && !app.macros.is_pending()
    })?;
    let at_six = onset(6)?;
    d.check(
        "Running the macro places the same catalog sound at the new cursor",
        document(d)?.sounds().len() == count + 2
            && document(d)?
                .sounds()
                .values()
                .any(|event| event.source.asset == asset && event.offset == at_six),
        json!({"sounds":count + 2,"onset":at_six}),
        json!({"sounds":document(d)?.sounds().len()}),
    )
}

fn document<'a>(d: &'a Driver<'_>) -> Result<&'a deadpan_core::ProjectDocument, String> {
    d.app()
        .workspace
        .as_ref()
        .map(|workspace| workspace.document.as_ref())
        .ok_or_else(|| "Sound-placement replay lost its workspace".into())
}

fn release_picture_submissions(d: &Driver<'_>) -> Result<usize, String> {
    let stages = &d
        .report
        .steps
        .last()
        .ok_or("Missing transition release frame")?
        .semantic["stages"];
    Ok(stages
        .as_array()
        .ok_or("Missing release-frame stages")?
        .iter()
        .filter(|stage| stage["stage"] == "picture_submitted")
        .count())
}

fn cleared_picture_transition(d: &mut Driver<'_>, view: View) -> Result<(), String> {
    let submissions = release_picture_submissions(d)?;
    let app = d.app();
    let workspace = app
        .workspace
        .as_ref()
        .cloned()
        .ok_or("Missing transition workspace")?;
    let expected_view = match view {
        View::Source => ProjectView::Source {
            asset: app
                .selected_source
                .clone()
                .ok_or("Missing transition Original")?,
            frame: SourceFrameId(app.source_cursor),
        },
        View::Sequence => ProjectView::Sequence {
            frame: ProjectFrame(
                i64::try_from(app.sequence_cursor).map_err(|error| error.to_string())?,
            ),
        },
    };
    let expected_label = match view {
        View::Source => format!("Showing source frame {}", u128::from(app.source_cursor) + 1),
        View::Sequence => format!(
            "Showing sequence frame {}",
            u128::from(app.sequence_cursor) + 1
        ),
    };
    let picture = app.presentation.diagnostic_snapshot();
    d.check(
        "A replacing view transition submits no discarded picture and requests the new view",
        submissions == 0
            && app.view == view
            && app.target.is_none()
            && picture["decoded"].is_null()
            && picture["displayed"].is_null()
            && picture["loading"] == true
            && picture["requested"]["label"] == expected_label,
        json!({"submissions":0,"requested_label":expected_label,"displayed":null}),
        json!({"submissions":submissions,"picture":picture}),
    )?;
    d.settled()?;
    let label = d
        .app()
        .presentation
        .displayed_label()
        .ok_or("Replacement picture was not displayed")?;
    let viewer = d.rect(&label)?;
    let canvas = d
        .app()
        .presentation
        .canvas()
        .map_or(viewer, |(width, height)| {
            fit_rect(viewer, width as f32 / height as f32)
        });
    let expected = target_size(canvas.size(), d.harness.ctx.pixels_per_point());
    let actual = d
        .app()
        .target
        .as_ref()
        .map(|target| (target.target.width(), target.target.height()));
    d.check(
        "The replacement picture settles at its exact view identity and final target size",
        actual == Some(expected)
            && d.app().presentation.displayed_matches(
                workspace.session,
                workspace.document.project_id(),
                workspace.document.revision_id(),
                &expected_view,
            ),
        json!({"target":expected,"view":format!("{expected_view:?}")}),
        json!({"target":actual,"picture":d.app().presentation.diagnostic_snapshot()}),
    )
}

fn final_picture_submission(d: &mut Driver<'_>, retained: &Value) -> Result<(), String> {
    let submissions = release_picture_submissions(d)?;
    let picture = d.app().presentation.diagnostic_snapshot();
    let label = d
        .app()
        .presentation
        .displayed_label()
        .ok_or("Transition lost its picture label")?;
    let viewer = d.rect(&label)?;
    let canvas = d
        .app()
        .presentation
        .canvas()
        .map_or(viewer, |(width, height)| {
            fit_rect(viewer, width as f32 / height as f32)
        });
    let expected = target_size(canvas.size(), d.harness.ctx.pixels_per_point());
    let actual = d
        .app()
        .target
        .as_ref()
        .map(|target| (target.target.width(), target.target.height()));
    d.check(
        "The transition release frame submits only its final viewer size and retains picture identity",
        submissions <= 1 && (submissions == 0 || actual == Some(expected))
            && picture["displayed"] == *retained,
        json!({"maximum_submissions":1,"submitted_target":expected,"retained":retained}),
        json!({"submissions":submissions,"actual_target":actual,"picture":picture}),
    )
}

pub(super) fn empty_heading(d: &mut Driver<'_>) -> Result<(), String> {
    let sounds = d.rect("Placed sounds pane")?;
    let beats = d.rect("Current group beat outline pane")?;
    let paint = scenarios::text_paint_visibility(d, "PLACED SOUNDS 0 · ,s place");
    let complete_hit = d.harness.output().shapes.iter().any(|clipped| {
        matches!(&clipped.shape, egui::Shape::Text(text)
            if text.galley.text().contains("PLACED SOUNDS 0 · ,s place"))
            && clipped.clip_rect.contains_rect(sounds)
    });
    d.check(
        "Empty Sounds has a fully painted separate focus target beside Beats",
        document(d)?.sounds().is_empty()
            && !sounds.intersects(beats)
            && (sounds.center().y - beats.center().y).abs() <= 14.0
            && complete_hit
            && !paint.is_empty()
            && paint.iter().all(|item| item["fully_visible"] == true)
            && d.harness
                .ctx
                .input(|input| input.content_rect().contains_rect(sounds)),
        json!("Separate visible Sounds and Beats headings on one row"),
        json!({"sounds":format!("{sounds:?}"),"beats":format!("{beats:?}"),"paint":paint}),
    )
}

pub(super) fn control_hits(d: &Driver<'_>, labels: &[&str]) -> Vec<Value> {
    labels.iter().map(|label| {
        let controls = d.harness.root().children_recursive().filter_map(|node| {
            let access = node.accesskit_node();
            (matches!(access.role(), egui::accesskit::Role::Button | egui::accesskit::Role::Slider)
                && access.label().as_deref() == Some(*label)
                && !access.is_hidden() && access.bounding_box().is_some())
                .then(|| (node.rect(), !access.is_disabled()))
        }).collect::<Vec<_>>();
        let visible = match controls.as_slice() {
            [(rect, _)] => rect.is_positive() && d.harness.ctx.content_rect().contains_rect(*rect)
                && d.harness.output().shapes.iter().any(|clipped| {
                    matches!(&clipped.shape, egui::Shape::Text(text) if text.galley.text() == *label)
                        && clipped.clip_rect.contains_rect(*rect)
                }),
            _ => false,
        };
        let enabled = match controls.as_slice() { [(_, enabled)] => Some(*enabled), _ => None };
        json!({"label":label,"complete_hit":visible,"enabled":enabled,"rects":format!("{controls:?}")})
    }).collect()
}

fn retained_fixture_picture(d: &mut Driver<'_>) -> Result<(), String> {
    scenarios::viewer_visible(d)?;
    let label = d
        .app()
        .presentation
        .displayed_label()
        .ok_or("Missing picture label")?;
    visible(d, &label)?;
    if d.options.mode == RunMode::Visual {
        let viewer = d.rect(&label)?;
        let scale = d.harness.ctx.pixels_per_point();
        let image = d.harness.render()?;
        let mut colors = [0usize; 3];
        for (x, y, pixel) in image.enumerate_pixels() {
            if !viewer.contains(egui::pos2(x as f32 / scale, y as f32 / scale)) {
                continue;
            }
            for channel in 0..3 {
                if pixel[3] >= 250
                    && pixel[channel] > 200
                    && pixel[(channel + 1) % 3] < 80
                    && pixel[(channel + 2) % 3] < 80
                {
                    colors[channel] += 1;
                }
            }
        }
        d.check(
            "The retained fixture's red, green and blue bars survive inspector scrolling",
            colors.iter().all(|count| *count > 10),
            json!("More than ten composed pixels of each primary color inside the viewer"),
            json!({"primary_pixels":colors,"picture":d.app().presentation.diagnostic_snapshot()}),
        )?;
    }
    Ok(())
}

fn compact_playback(d: &mut Driver<'_>) -> Result<(), String> {
    d.report.skipped.push(
        "Preparing/Playing at 960 pixels uses the real transport controls with simulated delivery reports only. It does not start a device or prepare PCM.".into(),
    );
    let before = targets(d);
    let revision = d.revision();
    let selected = selected(d)?;
    let sounds = document(d)?.sounds().clone();
    d.click("Play edit  Space")?;
    d.check(
        "Pointer Play from Sounds starts the edit transport in Preparing",
        d.app().transport.as_ref().is_some_and(|run| {
            run.phase == deadpan_playback::Phase::Preparing && !run.domain().is_sound()
        }) && d.app().pane == Pane::Sounds,
        json!("Preparing edit playback with placed sound focus"),
        d.snapshot(),
    )?;
    // Inspect the click-release frame itself. An extra frame could conceal a
    // control painted after the old stopped-state reservation was allocated.
    playback_layout(d, "Cancel preparation  Space", "Preparing ·")?;
    d.capture("Preparing edit playback with sound inspector at 960x640")?;

    let (mut feed, _callback) = deadpan_output::channel().map_err(|error| error.to_string())?;
    let run = d
        .app()
        .transport
        .as_ref()
        .ok_or("Missing preparing transport")?;
    let generation = feed
        .restart(run.sample.0)
        .map_err(|error| error.to_string())?;
    let playing = deadpan_playback::Update {
        preparation: None,
        ticket: run.ticket,
        session: run.session,
        project_id: run.project.clone(),
        revision_id: run.revision.clone(),
        content: run.content.clone(),
        phase: deadpan_playback::Phase::Playing,
        sample: Some(run.sample),
        generation: Some(generation),
        error: None,
    };
    d.app_mut().feedback.playback_updates.push_back(playing);
    d.capture("Simulated Playing feedback with sound inspector at 960x640")?;
    d.check(
        "Simulated delivery starts Playing without advancing either editor cursor",
        d.app()
            .transport
            .as_ref()
            .is_some_and(|run| run.phase == deadpan_playback::Phase::Playing)
            && targets(d) == before,
        before.clone(),
        d.snapshot(),
    )?;
    playback_layout(d, "Pause  Space", "Playing ·")?;
    d.click("Pause  Space")?;
    visible(d, "Play edit  Space")?;
    visible(d, "Monitor · :monitor")?;
    scenarios::footer_anchored(
        d,
        "Pointer Pause paints the stopped controls on its release frame",
    )?;
    d.settled()?;
    d.check(
        "Pausing the compact playback check retains authored state and sound selection",
        d.app().transport.is_none()
            && d.app().selected_event.as_ref() == Some(&selected)
            && d.app().pane == Pane::Sounds
            && targets(d) == before
            && d.revision() == revision
            && document(d)?.sounds() == &sounds,
        json!({"revision":revision,"selected_event":selected,"targets":before}),
        d.snapshot(),
    )?;
    Ok(())
}

fn playback_layout(d: &mut Driver<'_>, button: &str, status: &str) -> Result<(), String> {
    visible(d, button)?;
    visible(d, status)?;
    visible(d, "Monitor · :monitor")?;
    visible(d, "SOUND EVENT")?;
    let label = d
        .app()
        .presentation
        .displayed_label()
        .ok_or("Playback lost its picture label")?;
    let viewer = d.rect(&label)?;
    let sounds = d.rect("Placed sounds pane")?;
    for label in [button, status, "Monitor · :monitor"] {
        let paint = scenarios::text_paint_visibility(d, label);
        let positioned = paint.iter().all(|item| {
            let Some(bounds) = item["bounds"].as_array() else {
                return false;
            };
            let coordinates = bounds.iter().filter_map(Value::as_f64).collect::<Vec<_>>();
            coordinates.len() == 4
                && coordinates[0] >= f64::from(viewer.min.x)
                && coordinates[2] <= f64::from(viewer.max.x)
                && coordinates[1] >= f64::from(viewer.max.y)
                && coordinates[3] <= f64::from(sounds.min.y)
        });
        d.check(
            "Live playback controls fit below the picture and above placed sounds",
            positioned,
            json!({"label":label,"viewer":format!("{viewer:?}"),"sounds_top":sounds.min.y}),
            json!(paint),
        )?;
    }
    scenarios::footer_anchored(
        d,
        "Live playback keeps the compact workspace footer anchored",
    )
}

fn selected(d: &Driver<'_>) -> Result<SoundId, String> {
    d.app()
        .selected_event
        .clone()
        .ok_or_else(|| "No placed sound selected".into())
}

fn focus_entry(d: &mut Driver<'_>, id: &SoundId, baseline: &Value) -> Result<(), String> {
    for pointer in [false, true] {
        browse_original(d)?;
        d.settled()?;
        d.check(
            "Sound-pane entry starts with Original and no selected event",
            d.app().view == View::Source
                && d.app().pane == Pane::Sources
                && d.app().selected_event.is_none(),
            json!({"context":"Source","pane":"Sources","selected_event":null}),
            d.snapshot(),
        )?;
        if pointer {
            d.click("Placed sounds pane")?;
        } else {
            d.key_modified(Key::Tab, Modifiers::SHIFT)?;
        }
        d.check(
            "Tab and heading entry activate placed sounds without changing either cursor or beat",
            d.app().pane == Pane::Sounds
                && d.app().view == View::Sequence
                && d.app().event_focused()
                && d.app().selected_event.as_ref() == Some(id)
                && targets(d) == *baseline,
            json!({"entry":if pointer {"heading"} else {"Shift Tab"},"targets":baseline}),
            d.snapshot(),
        )?;
        d.key(Key::Enter)?;
        d.check(
            "The first Enter after entering Sounds edits the selected sound",
            d.app().command_open && d.app().command.starts_with("sound-at "),
            json!("Open exact sound position command"),
            d.snapshot(),
        )?;
        d.key(Key::Escape)?;
        d.settled()?;
    }
    let revision = d.revision();
    let sounds = document(d)?.sounds().clone();
    let source_cursor = d.app().source_cursor;
    d.command("source")?;
    d.check(
        "The source command clears sound selection and moves focus to Original",
        d.app().view == View::Source
            && d.app().pane == Pane::Sources
            && !d.app().event_focused()
            && d.app().selected_event.is_none()
            && d.app().sound_inspection.is_none(),
        json!({"context":"Source","pane":"Sources","selected_event":null}),
        d.snapshot(),
    )?;
    d.key(Key::L)?;
    let mut advanced = baseline.clone();
    advanced["context"] = json!("Source");
    advanced["source_cursor"] = json!(source_cursor + 1);
    d.check(
        "The first l after source advances Original instead of nudging a retained sound",
        targets(d) == advanced
            && d.revision() == revision
            && document(d)?.sounds() == &sounds
            && !d.app().service.is_busy(),
        advanced,
        d.snapshot(),
    )?;
    d.key(Key::H)?;
    d.command("sounds")?;
    d.settled()?;
    d.check(
        "Original h reverses navigation without history or sound changes",
        targets(d) == *baseline && d.revision() == revision && document(d)?.sounds() == &sounds,
        json!({"revision":revision,"sounds":sounds,"targets":baseline}),
        d.snapshot(),
    )?;
    let edit_cursor = d.app().sequence_cursor;
    d.click("Next  l")?;
    let mut next_picture = baseline.clone();
    next_picture["sequence_cursor"] = json!(edit_cursor + 1);
    d.check(
        "Picture Next leaves sound focus and moves the edit cursor without nudging a sound",
        d.app().pane == Pane::Viewer
            && d.app().selected_event.is_none()
            && d.app().sound_inspection.is_none()
            && targets(d) == next_picture
            && d.revision() == revision
            && document(d)?.sounds() == &sounds
            && !d.app().service.is_busy(),
        next_picture,
        d.snapshot(),
    )?;
    d.click("Previous  h")?;
    d.command("sounds")?;
    d.settled()?;
    d.check(
        "Picture Previous restores the edit cursor and sounds can be focused again",
        targets(d) == *baseline
            && d.app().event_focused()
            && d.app().selected_event.as_ref() == Some(id)
            && d.revision() == revision
            && document(d)?.sounds() == &sounds,
        json!({"revision":revision,"sounds":sounds,"targets":baseline}),
        d.snapshot(),
    )?;
    Ok(())
}

fn command_targets(d: &mut Driver<'_>, id: &SoundId, baseline: &Value) -> Result<(), String> {
    choose(d, id)?;
    rejected(
        d,
        "delete",
        "The delete command cannot alias deletion of a focused sound",
    )?;
    d.check(
        "The ambiguous delete command directs users to sound-delete",
        d.app()
            .error
            .as_deref()
            .is_some_and(|error| error.contains(":sound-delete")),
        json!("Explicit :sound-delete guidance"),
        d.snapshot(),
    )?;
    for (captured, mutation) in [
        (false, "sound-delete"),
        (false, "delete"),
        (true, "sound-gain -9"),
        (false, "sound-wet-send delay -6dB"),
        (true, "sound-wet-send delay -6dB"),
        (false, "sound-eq bass=3dB middle=0dB treble=0dB"),
        (true, "sound-saturate 9dB"),
        (false, "sound-envelope 0f 30f -12dB 0dB linear"),
        (true, "sound-balance left"),
        (false, "sound-mute on"),
    ] {
        choose(d, id)?;
        let before = d.revision();
        d.app_mut().feedback.hold_project_updates = true;
        d.command(if captured {
            "sound-gain -6"
        } else {
            "sound-gain 0"
        })?;
        d.wait_for(
            "Sound writer finishes while its UI completion is held",
            |app| !app.service.is_busy(),
        )?;
        if !captured {
            browse_original(d)?;
        }
        d.key(Key::Colon)?;
        d.events(
            "Type a sound mutation before the held revision arrives",
            vec![egui::Event::Text(mutation.into())],
        )?;
        d.check(
            "Command entry captures sound focus before the late completion",
            d.app().command_open && d.app().sound_command_target.is_some() == captured,
            json!({"captured_sound":captured,"revision":before}),
            d.snapshot(),
        )?;
        d.app_mut().feedback.hold_project_updates = false;
        d.changed(&before)?;
        d.check(
            "Late sound completion leaves the open command's original target intact",
            d.app().command_open
                && d.app().sound_command_target.is_some() == captured
                && d.app().selected_event.as_ref() == Some(id),
            json!({"captured_sound":captured,"selected_event":id}),
            d.snapshot(),
        )?;
        let committed_revision = d.revision();
        let sounds = document(d)?.sounds().clone();
        d.key(Key::Enter)?;
        d.wait_for(
            "Changed or absent sound command target rejects explicitly",
            |app| !app.service.is_busy() && app.error.is_some(),
        )?;
        d.check(
            if captured {
                "A captured sound command rejects the newly committed revision"
            } else if mutation == "delete" {
                "The delete alias cannot adopt a late selected event or cut the retained beat"
            } else {
                "A command opened without sound focus cannot adopt a late selected event"
            },
            !d.app().command_open
                && d.revision() == committed_revision
                && document(d)?.sounds() == &sounds
                && targets(d) == *baseline,
            json!({"revision":committed_revision,"sounds":sounds,"targets":baseline}),
            d.snapshot(),
        )?;
        if mutation == "delete" {
            d.check(
                "Late delete alias rejection retains explicit sound-delete guidance",
                d.app()
                    .error
                    .as_deref()
                    .is_some_and(|error| error.contains(":sound-delete")),
                json!("Explicit :sound-delete guidance"),
                d.snapshot(),
            )?;
        }
        commit(d, "sound-gain -3")?;
    }
    Ok(())
}

fn choose(d: &mut Driver<'_>, id: &SoundId) -> Result<(), String> {
    let index = document(d)?
        .sounds()
        .keys()
        .position(|candidate| candidate == id)
        .ok_or("Cannot select an absent sound event")?;
    d.command("sounds")?;
    d.chord(&[Key::Num6, Key::Num4, Key::K])?;
    for _ in 0..index {
        d.key(Key::J)?;
    }
    Ok(())
}

fn event(d: &Driver<'_>, id: &SoundId) -> Result<SoundEvent, String> {
    document(d)?
        .sounds()
        .get(id)
        .cloned()
        .ok_or_else(|| format!("Missing placed sound {id:?}"))
}

fn targets(d: &Driver<'_>) -> Value {
    let snapshot = d.snapshot();
    json!({
        "context":snapshot["context"],"selected_source":snapshot["selected_source"],
        "source_cursor":snapshot["source_cursor"],"sequence_cursor":snapshot["sequence_cursor"],
        "selected_beat":snapshot["selected_beat"],"sequence_scope":snapshot["sequence_scope"],
        "original_selection":snapshot["original_selection"],"visual_selection":snapshot["visual_selection"],
        "duration":snapshot["duration"],
    })
}

fn commit(d: &mut Driver<'_>, command: &str) -> Result<(), String> {
    let before = d.revision();
    d.command(command)?;
    d.changed(&before)
}

fn check_offset(d: &mut Driver<'_>, id: &SoundId, offset: i64, label: &str) -> Result<(), String> {
    let recipe = event(d, id)?;
    d.check(
        label,
        recipe.offset == AudioSample(offset),
        json!(offset),
        json!(recipe),
    )
}

fn audible(d: &Driver<'_>, id: &SoundId) -> Result<std::ops::Range<AudioSample>, String> {
    d.app()
        .workspace
        .as_ref()
        .ok_or("No workspace for sound onset")?
        .plan
        .root_sound(id)
        .map(|sound| sound.audible_samples())
        .map_err(|error| error.to_string())
}

fn check_onset(d: &mut Driver<'_>, id: &SoundId, onset: i64, label: &str) -> Result<(), String> {
    let samples = audible(d, id)?;
    d.check(
        label,
        samples.start == AudioSample(onset),
        json!(onset),
        json!(samples),
    )
}

fn same_mapping(left: &SoundEvent, right: &SoundEvent) -> Result<bool, String> {
    Ok(left.mapping.start_frames() == right.mapping.start_frames()
        && left
            .mapping
            .duration_frames(FrameDuration::ZERO)
            .map_err(|error| error.to_string())?
            == right
                .mapping
                .duration_frames(FrameDuration::ZERO)
                .map_err(|error| error.to_string())?
        && left
            .mapping
            .selection_frames(FrameDuration::ZERO)
            .map_err(|error| error.to_string())?
            == right
                .mapping
                .selection_frames(FrameDuration::ZERO)
                .map_err(|error| error.to_string())?)
}

fn check_gain(d: &mut Driver<'_>, id: &SoundId, gain: i32) -> Result<(), String> {
    let recipe = event(d, id)?;
    d.check(
        "Authored sound gain is exact in millidecibels",
        recipe.treatments.trim().millidecibels() == gain,
        json!(gain),
        json!(recipe),
    )
}

fn rejected(d: &mut Driver<'_>, command: &str, label: &str) -> Result<(), String> {
    let before = d.revision();
    let sounds = document(d)?.sounds().clone();
    let routes = document(d)?.sound_routes().clone();
    let nodes = document(d)?.nodes().clone();
    d.command(command)?;
    d.wait_for("Rejected sound edit reports its failure", |app| {
        !app.service.is_busy() && (app.project_error.is_some() || app.error.is_some())
    })?;
    d.check(
        label,
        d.revision() == before
            && document(d)?.sounds() == &sounds
            && document(d)?.sound_routes() == &routes
            && document(d)?.nodes() == &nodes,
        json!({"revision":before,"sounds":sounds,"routes":routes}),
        d.snapshot(),
    )
}

fn resize(d: &mut Driver<'_>, width: f32, height: f32) -> Result<(), String> {
    let rect = egui::Rect::from_min_size(egui::Pos2::ZERO, egui::vec2(width, height));
    let input = d.harness.input_mut();
    input.screen_rect = Some(rect);
    input
        .viewports
        .get_mut(&egui::ViewportId::ROOT)
        .ok_or("Sound-placement resize has no root viewport")?
        .inner_rect = Some(rect);
    Ok(())
}

fn visible(d: &mut Driver<'_>, label: &str) -> Result<(), String> {
    let paint = scenarios::text_paint_visibility(d, label);
    d.check(
        "Placed-sound controls paint fully inside their clip and viewport",
        !paint.is_empty() && paint.iter().all(|item| item["fully_visible"] == true),
        json!(label),
        json!(paint),
    )
}

fn browse_original(d: &mut Driver<'_>) -> Result<(), String> {
    const LABEL: &str = "Browse  :source";
    for attempt in 0..=3 {
        let paint = scenarios::text_paint_visibility(d, LABEL);
        let hits = control_hits(d, &[LABEL]);
        if !paint.is_empty()
            && paint.iter().all(|item| item["fully_visible"] == true)
            && hits[0]["complete_hit"] == true
            && hits[0]["enabled"] == true
        {
            let before = d.rect(LABEL)?;
            for _ in 0..8 {
                d.step("Visible Original Browse geometry settles", false)?;
            }
            let paint = scenarios::text_paint_visibility(d, LABEL);
            let hits = control_hits(d, &[LABEL]);
            if d.rect(LABEL)? == before
                && !paint.is_empty()
                && paint.iter().all(|item| item["fully_visible"] == true)
                && hits[0]["complete_hit"] == true
                && hits[0]["enabled"] == true
            {
                return d.click(LABEL);
            }
        }
        if attempt == 3 {
            return Err(format!(
                "Original Browse did not settle visibly after bounded scrolling: paint={paint:?}, hits={hits:?}"
            ));
        }
        let point = d.rect("Original and sounds pane")?.center() + egui::vec2(0.0, 100.0);
        d.events(
            "Scroll Original rail to reveal its Browse action",
            vec![
                egui::Event::PointerMoved(point),
                egui::Event::MouseWheel {
                    unit: egui::MouseWheelUnit::Point,
                    delta: egui::vec2(0.0, 2_048.0),
                    phase: egui::TouchPhase::Move,
                    modifiers: Modifiers::NONE,
                },
            ],
        )?;
        for _ in 0..8 {
            d.step("Original rail scroll settles", false)?;
        }
    }
    unreachable!("bounded reveal returns at its final attempt")
}

fn reveal(d: &mut Driver<'_>, label: &str, direction: f32) -> Result<(), String> {
    // Complete event treatments make the minimum-size inspector taller. Keep
    // real wheel input and paint checks, but allow enough travel for its ends.
    for attempt in 0..=8 {
        let paint = scenarios::text_paint_visibility(d, label);
        if !paint.is_empty() && paint.iter().all(|item| item["fully_visible"] == true) {
            return Ok(());
        }
        if attempt == 8 {
            break;
        }
        let heading = d.rect("Selected sound inspector pane")?;
        let point = heading.center() + egui::vec2(0.0, 100.0);
        d.events(
            &format!("Scroll sound inspector to reveal {label}"),
            vec![
                egui::Event::PointerMoved(point),
                egui::Event::MouseWheel {
                    unit: egui::MouseWheelUnit::Point,
                    delta: egui::vec2(0.0, direction),
                    phase: egui::TouchPhase::Move,
                    modifiers: Modifiers::NONE,
                },
            ],
        )?;
        for _ in 0..8 {
            d.step("Sound inspector scroll settles", false)?;
        }
    }
    visible(d, label)
}
