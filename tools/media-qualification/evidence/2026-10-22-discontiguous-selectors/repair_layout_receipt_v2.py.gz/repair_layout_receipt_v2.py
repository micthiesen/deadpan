from pathlib import Path
import json
p=Path('/tmp/deadpan-discontiguous-selectors-2026-10-22/test-layout-delta.json')
def decode(raw):
 suffix=chr(92)+'n'
 return json.loads(raw[:-len(suffix)] if raw.endswith(suffix) else raw)
raw=p.read_text()
rows=decode(raw)
assert decode(json.dumps(rows)+chr(92)+'n')==rows
assert decode(json.dumps(rows)+chr(10))==rows
assert len(rows['debug_eighth_changed_files'])==2 and rows['all_other_frozen_rust_identical']
p.write_text(json.dumps(rows,indent=2)+chr(10))
assert p.read_text()==raw
print(json.dumps({'receipt_unchanged':True,'literal_terminator_and_valid_json_cases_pass':True}))
