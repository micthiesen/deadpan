from pathlib import Path
import json
p=Path('/tmp/deadpan-discontiguous-selectors-2026-10-22/test-layout-delta.json')
raw=p.read_text()
# The executed driver appended a literal backslash-n. Repair only that JSON
# terminator; preserve the two validated changed paths and truth value.
rows=json.loads(raw[:-2] if raw.endswith('\\\\n') else raw)
p.write_text(json.dumps(rows,indent=2)+'\\n')
assert len(rows['debug_eighth_changed_files'])==2 and rows['all_other_frozen_rust_identical']
