from pathlib import Path
import subprocess,json,os,time,shutil,hashlib
s=Path('/tmp/deadpan-discontiguous-selectors-2026-10-22')
env=dict(os.environ,DEADPAN_FFMPEG_PREFIX='/Users/michael/Library/Developer/Deadpan/ffmpeg-8.0.3-opus-1.6.1-dav1d-1.5.4-qualified-3/prefix',CARGO_PROFILE_DEV_OPT_LEVEL='2',DEADPAN_REQUIRE_PHYSICAL_MAC='1',DEADPAN_REQUIRE_SYNTHETIC_WORKER='1')
def guard():subprocess.run(['python',str(s/'guard.py'),'strict-second'],env=env,check=True)
def run(name,args):
 start=time.monotonic()
 with(s/(name+'.log')).open('w')as log:r=subprocess.run(args,env=env,stdout=log,stderr=subprocess.STDOUT)
 row={'command':args,'exit':r.returncode,'seconds':time.monotonic()-start}
 (s/(name+'-receipt.json')).write_text(json.dumps(row,indent=2)+'\n');print(name,json.dumps(row),flush=True)
 if r.returncode:raise SystemExit(r.returncode)
old=json.loads((s/'broad-fourth-source-identities.json').read_text())
changed=[n for n,d in old.items()if hashlib.sha256(Path(n).read_bytes()).hexdigest()!=d]
assert changed==['crates/deadpan-store/tests/node_sets.rs'],changed
(s/'clippy-test-delta.json').write_text(json.dumps({'changed_files':changed,'all_production_rust_and_other_tests_unchanged':True,'change':'Replace one needless clone with std::slice::from_ref in a test.'},indent=2)+'\n')
guard()
archive=s/'store-final.tar.zst'
run('store-final-build',['cargo','nextest','archive','--locked','-p','deadpan-store','--test','node_sets','--archive-file',str(archive),'--zstd-level=-1'])
run('store-final-driver',['python',str(s/'run_archive.py'),'store-final'])
guard()
for name,args in [
 ('strict-final-check',['cargo','xtask','check','--since','f4f7481ed804f8a5c25b39b76b7ecc8bc1529cc4','--no-test']),
 ('strict-final-ui-clippy',['cargo','clippy','--locked','-p','deadpan-app','--features','ui-harness','--all-targets','--','-D','warnings']),
 ('strict-final-format',['cargo','fmt','--all','--','--check'])]:
 run(name,args);guard()
