from pathlib import Path
import subprocess,json,os,time,shutil,hashlib
s=Path('/tmp/deadpan-discontiguous-selectors-2026-10-22')
env=dict(os.environ,DEADPAN_FFMPEG_PREFIX='/Users/michael/Library/Developer/Deadpan/ffmpeg-8.0.3-opus-1.6.1-dav1d-1.5.4-qualified-3/prefix',CARGO_PROFILE_DEV_OPT_LEVEL='2',DEADPAN_REQUIRE_PHYSICAL_MAC='1',DEADPAN_REQUIRE_SYNTHETIC_WORKER='1')
def guard():subprocess.run(['python',str(s/'guard.py'),'lint-final'],env=env,check=True)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def run(name,args):
 start=time.monotonic()
 with(s/(name+'.log')).open('w')as log:r=subprocess.run(args,env=env,stdout=log,stderr=subprocess.STDOUT)
 row={'command':args,'exit':r.returncode,'seconds':time.monotonic()-start}
 (s/(name+'-receipt.json')).write_text(json.dumps(row,indent=2)+'\n');print(name,json.dumps(row),flush=True)
 if r.returncode:raise SystemExit(r.returncode)
old=json.loads((s/'broad-fourth-source-identities.json').read_text())
changed=[n for n,d in old.items()if sha(Path(n))!=d]
assert sorted(changed)==sorted(['crates/deadpan-store/tests/node_sets.rs','crates/deadpan-app/src/preview/macros.rs']),changed
(s/'final-lint-delta.json').write_text(json.dumps({'changed_files':changed,'changes':['test-only borrowed slice cleanup','Equivalent boolean match converted to matches! for Clippy.'],'other_rust_and_six_inputs_unchanged':True},indent=2)+'\n')
guard()
for name,args in [
 ('strict-passed-check',['cargo','xtask','check','--since','f4f7481ed804f8a5c25b39b76b7ecc8bc1529cc4','--no-test']),
 ('strict-passed-ui-clippy',['cargo','clippy','--locked','-p','deadpan-app','--features','ui-harness','--all-targets','--','-D','warnings']),
 ('strict-passed-format',['cargo','fmt','--all','--','--check'])]:
 run(name,args);guard()
selected=json.loads((s/'app-second-binaries.json').read_text())
cases=next(iter(selected.values()))['tests'];assert len(cases)==46
expression=' | '.join('test(='+case+')'for case in cases)
for name,args,expr in [
 ('app-lint-final',['--bin','deadpan-app'],expression),
 ('ui-complete-final',['--features','ui-harness'],None)]:
 archive=s/(name+'.tar.zst');target=s/(name+'-extracted');target.mkdir(exist_ok=True)
 run(name+'-build',['cargo','nextest','archive','--locked','-p','deadpan-app',*args,'--archive-file',str(archive),'--zstd-level=-1'])
 with(s/(name+'-extract.log')).open('w')as log:
  subprocess.run(['cargo','nextest','list','--archive-file',str(archive),'--extract-to',str(target),'--extract-overwrite','--workspace-remap',str(Path.cwd())],env=env,stdout=log,stderr=subprocess.STDOUT,check=True)
 helpers={}
 for helper in ['deadpan-app','deadpan-cli','deadpan-media-worker','deadpan-transcribe','deadpan-track']:
  p=Path('target/debug')/helper;matches=list(target.rglob(helper))
  if not matches:
   t=target/'target/debug'/helper;t.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,t);matches=[t]
  assert len(matches)==1 and sha(matches[0])==sha(p),(helper,matches)
  helpers[helper]={'path':str(matches[0]),'sha256':sha(p)}
 (s/(name+'-helpers.json')).write_text(json.dumps(helpers,indent=2)+'\n');guard()
 run(name+'-driver',['python',str(s/'run_archive.py'),name,*([expr]if expr else[])])
 guard()
 for r in helpers.values():assert sha(Path(r['path']))==r['sha256']
 result=json.loads((s/(name+'-result.json')).read_text())
 if expr:assert result['tests']==46
 else:
  listing=json.loads((s/(name+'-binaries.json')).read_text())
  assert sorted(listing)==['deadpan-app::bin/deadpan-app','deadpan-app::headless']
  assert len(listing['deadpan-app::headless']['tests'])==4
