from pathlib import Path
import subprocess,json,os,time,hashlib,sys
s=Path('/tmp/deadpan-discontiguous-selectors-2026-10-22')
env=dict(os.environ,DEADPAN_FFMPEG_PREFIX='/Users/michael/Library/Developer/Deadpan/ffmpeg-8.0.3-opus-1.6.1-dav1d-1.5.4-qualified-3/prefix',CARGO_PROFILE_DEV_OPT_LEVEL='2',DEADPAN_REQUIRE_PHYSICAL_MAC='1',DEADPAN_REQUIRE_SYNTHETIC_WORKER='1')
phase=sys.argv[1]
subprocess.run(['python',str(s/'freeze.py'),phase],check=True)
jobs=[
 ('core',['-p','deadpan-core','--test','edit_set','--test','node_set_counterfactual','--test','node_set_shared_mark'],None),
 ('store',['-p','deadpan-store','--test','node_sets'],None),
 ('cli',['-p','deadpan-cli','--test','node_sets'],None),
 ('app',['-p','deadpan-app','--features','ui-harness','--bin','deadpan-app'],'test(nodes) | test(node_set) | test(node_selection) | test(project::semantic::tests) | test(preview::edit_range::tests) | test(navigation::command::tests)')]
if len(sys.argv)>2:jobs=[job for job in jobs if job[0]==sys.argv[2]]
results=[]
for name,targets,expression in jobs:
 archive=s/(phase+'-'+name+'.tar.zst')
 start=time.monotonic()
 with (s/(phase+'-'+name+'-build.log')).open('w') as log:
  build=subprocess.run(['cargo','nextest','archive','--locked',*targets,'--archive-file',str(archive),'--zstd-level=-1'],stdout=log,stderr=subprocess.STDOUT,env=env)
 if build.returncode:raise SystemExit(build.returncode)
 (s/(phase+'-'+name+'-extracted')).mkdir(exist_ok=True)
 reuse=['--archive-file',str(archive),'--extract-to',str(s/(phase+'-'+name+'-extracted')),'--extract-overwrite','--workspace-remap',str(Path.cwd())]
 filters=['-E',expression]if expression else[]
 with (s/(phase+'-'+name+'-list.json')).open('w') as out,(s/(phase+'-'+name+'-list.log')).open('w') as err:
  subprocess.run(['cargo','nextest','list',*reuse,*filters,'--message-format','json'],stdout=out,stderr=err,env=env,check=True)
 identities={}
 for key,row in json.loads((s/(phase+'-'+name+'-list.json')).read_text())['rust-suites'].items():
  tests=[n for n,c in row.get('testcases',{}).items()if c.get('filter-match',{}).get('status')=='matches']
  if not tests:continue
  p=Path(row['binary-path'])
  identities[key]={'path':str(p),'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'tests':tests}
 (s/(phase+'-'+name+'-binaries.json')).write_text(json.dumps(identities,indent=2)+'\n')
 subprocess.run(['python',str(s/'guard.py'),phase],check=True)
 started=time.monotonic()
 with (s/(phase+'-'+name+'.log')).open('w') as log:
  run=subprocess.run(['cargo','nextest','run',*reuse,*filters,'--test-threads','8','--no-fail-fast'],stdout=log,stderr=subprocess.STDOUT,env=env)
 subprocess.run(['python',str(s/'guard.py'),phase],check=True)
 for row in identities.values():assert hashlib.sha256(Path(row['path']).read_bytes()).hexdigest()==row['sha256']
 result={'phase':name,'exit':run.returncode,'tests':sum(len(i['tests'])for i in identities.values()),'run_seconds':time.monotonic()-started,'total_seconds':time.monotonic()-start,'source_inputs_binaries_unchanged':True}
 results.append(result);(s/(phase+'-results.json')).write_text(json.dumps(results,indent=2)+'\n');print(json.dumps(result),flush=True)
 if run.returncode:raise SystemExit(run.returncode)
