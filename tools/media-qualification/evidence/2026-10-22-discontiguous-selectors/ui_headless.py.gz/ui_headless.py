from pathlib import Path
import subprocess, json, os, shutil, hashlib
s=Path('/tmp/deadpan-discontiguous-selectors-2026-10-22')
env=dict(os.environ,DEADPAN_FFMPEG_PREFIX='/Users/michael/Library/Developer/Deadpan/ffmpeg-8.0.3-opus-1.6.1-dav1d-1.5.4-qualified-3/prefix',CARGO_PROFILE_DEV_OPT_LEVEL='2',DEADPAN_REQUIRE_PHYSICAL_MAC='1',DEADPAN_REQUIRE_SYNTHETIC_WORKER='1')
def guard():subprocess.run(['python',str(s/'guard.py'),'strict-second'],env=env,check=True)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
guard()
archive=s/'ui-headless.tar.zst';target=s/'ui-headless-extracted';target.mkdir(exist_ok=True)
with(s/'ui-headless-build.log').open('w')as log:
 subprocess.run(['cargo','nextest','archive','--locked','-p','deadpan-app','--features','ui-harness','--test','headless','--archive-file',str(archive),'--zstd-level=-1'],env=env,stdout=log,stderr=subprocess.STDOUT,check=True)
with(s/'ui-headless-extract.log').open('w')as log:
 subprocess.run(['cargo','nextest','list','--archive-file',str(archive),'--extract-to',str(target),'--extract-overwrite','--workspace-remap',str(Path.cwd())],env=env,stdout=log,stderr=subprocess.STDOUT,check=True)
helpers={}
for name in ['deadpan-app','deadpan-cli','deadpan-media-worker','deadpan-transcribe','deadpan-track']:
 p=Path('target/debug')/name;matches=list(target.rglob(name))
 if not matches:
  t=target/'target/debug'/name;t.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,t);matches=[t]
 assert len(matches)==1 and sha(matches[0])==sha(p)
 helpers[name]={'path':str(matches[0]),'sha256':sha(p)}
(s/'ui-headless-helpers.json').write_text(json.dumps(helpers,indent=2)+'\n')
subprocess.run(['python',str(s/'run_archive.py'),'ui-headless'],env=env,check=True)
guard()
for r in helpers.values():assert sha(Path(r['path']))==r['sha256']
with(s/'ui-complete-list.json').open('w')as out,(s/'ui-complete-list.log').open('w')as err:
 subprocess.run(['cargo','nextest','list','--locked','-p','deadpan-app','--features','ui-harness','--message-format','json'],env=env,stdout=out,stderr=err,check=True)
executed={}
for name in ['ui-final','ui-headless']:
 r=json.loads((s/(name+'-result.json')).read_text());assert r['exit']==0
 for key,row in json.loads((s/(name+'-binaries.json')).read_text()).items():
  assert key not in executed;executed[key]=row
current={}
for key,row in json.loads((s/'ui-complete-list.json').read_text())['rust-suites'].items():
 tests=[n for n,c in row.get('testcases',{}).items()if c.get('filter-match',{}).get('status')=='matches']
 if not tests:continue
 assert sorted(tests)==sorted(executed[key]['tests'])
 assert sha(Path(row['binary-path']))==executed[key]['sha256']
 current[key]={'tests':len(tests),'sha256':executed[key]['sha256']}
assert current.keys()==executed.keys()
guard()
receipt={'exit':0,'tests':sum(r['tests']for r in current.values()),'all_feature_cases_and_current_executables_match_executed_archives':True,'suites':current,'source_inputs_and_helpers_unchanged':True}
(s/'ui-complete-result.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt),flush=True)
