from pathlib import Path
import hashlib,json
d=Path('/tmp/deadpan-shared-mix-mask-candidate-2026-10-31')
root=Path('/tmp/deadpan-query-groundwork-2026-10-26/scoped')
files=['shared_mix.rs','shared_components.rs','shared_eq.rs','event_returns.rs']
def replace(s,old,new,count=1):
 assert s.count(old)==count,(old[:100],s.count(old),count)
 return s.replace(old,new)
pins={}
for name in files:
 rel=Path('crates/deadpan-audio/src')/name
 source=root/rel;b=source.read_bytes()
 pins[str(source)]={'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
 before=d/'before'/rel;after=d/'new'/rel
 before.parent.mkdir(parents=True,exist_ok=True);after.parent.mkdir(parents=True,exist_ok=True)
 before.write_bytes(b)
 s=b.decode()
 if name=='shared_mix.rs':
  s=replace(s,'use deadpan_plan::AudioOwnerClock;','use deadpan_plan::AudioOwnerClock;\nuse super::point_suppression::ops::{MaskContext, MaskWorkPhase, begin_ranges};')
  s=replace(s,'''pub(super) struct MixedBlock {
    pub(super) samples: Vec<[f64; 2]>,
    pub(super) suppressed: Vec<Range<AudioSample>>,
}''','''pub(super) struct MixedBlock {
    pub(super) samples: Vec<[f64; 2]>,
    pub(super) suppressed: MixedSuppression,
}

pub(super) enum MixedSuppression {
    Ordinary(Vec<Range<AudioSample>>),
    Pending {
        start: AudioSample,
        permissions: Vec<Permissions>,
    },
}

impl MixedSuppression {
    // The caller must retain the permission grid's existing source reservation
    // until this finishes, including disposal on every failure.
    pub(super) fn finish<C: MaskContext>(
        self,
        context: &mut C,
    ) -> Result<AudioSuppressionMask, StageAudioError> {
        match self {
            Self::Ordinary(ranges) => Ok(AudioSuppressionMask::plain(ranges)),
            Self::Pending { start, permissions } => {
                let result = (|| {
                    let mut capacity = 0_usize;
                    for mask in &permissions {
                        context.check()?;
                        // One bounded permission entry, at most 64 bitset words.
                        context.spend(MaskWorkPhase::Scan, 1)?;
                        if mask.is_empty() {
                            capacity = capacity.checked_add(1).ok_or(StageAudioError::Range)?;
                        }
                    }
                    if capacity == 0 {
                        context.check()?;
                        return Ok(AudioSuppressionMask::default());
                    }

                    let mut ranges = begin_ranges::<AudioSample, C>(context, capacity)?;
                    for (index, mask) in permissions.iter().enumerate() {
                        context.check()?;
                        context.spend(MaskWorkPhase::Scan, 1)?;
                        let at = AudioSample(start.0 + index as i64);
                        let range = at..AudioSample(at.0 + 1);
                        if mask.is_empty() {
                            ranges.push(range, context)?;
                        }
                    }
                    ranges.finish(context)?.merge(context)
                })();
                drop(permissions);
                result
            }
        }
    }
}''')
  old='''        let suppressed = self
            .permissions
            .iter()
            .enumerate()
            .filter_map(|(index, mask)| {
                let at = AudioSample(self.start.0 + index as i64);
                mask.is_empty().then_some(at..AudioSample(at.0 + 1))
            })
            .collect();
        Ok(MixedBlock {
            samples: self.sum,
            suppressed: merged_suppression(suppressed),
        })'''
  new='''        #[cfg(test)]
        if super::shared_mix_mask_request::legacy() {
            let suppressed = self
                .permissions
                .iter()
                .enumerate()
                .filter_map(|(index, mask)| {
                    let at = AudioSample(self.start.0 + index as i64);
                    mask.is_empty().then_some(at..AudioSample(at.0 + 1))
                })
                .collect();
            return Ok(MixedBlock {
                samples: self.sum,
                suppressed: MixedSuppression::Ordinary(merged_suppression(suppressed)),
            });
        }
        Ok(MixedBlock {
            samples: self.sum,
            suppressed: MixedSuppression::Pending {
                start: self.start,
                permissions: self.permissions,
            },
        })'''
  s=replace(s,old,new)
 elif name=='shared_components.rs':
  s=replace(s,'use super::shared_mix::{Contribution, MixedBlock, OwnerKey, Permissions, Temporal};','use super::shared_mix::{Contribution, MixedBlock, MixedSuppression, OwnerKey, Permissions, Temporal};')
  s=replace(s,'            suppressed: merged_suppression(suppressed),','            suppressed: MixedSuppression::Ordinary(merged_suppression(suppressed)),')
 elif name=='shared_eq.rs':
  s=replace(s,'''struct WideBlock {
    samples: Vec<[f64; 2]>,
    suppressed: Vec<Range<AudioSample>>,''','''struct WideBlock {
    samples: Vec<[f64; 2]>,
    suppressed: AudioSuppressionMask,''')
  s=replace(s,'''                result.suppressed.extend(
                    AudioSuppressionMask::plain(block.suppressed),
                    &mut self.masks(control),
                )?;''','''                result
                    .suppressed
                    .extend(block.suppressed, &mut self.masks(control))?;''')
  s=replace(s,'''            Ok(WideBlock {
                samples: mixed.samples,
                suppressed: mixed.suppressed,''','''            // Keep the moved permission grid funded until projection drops it.
            let suppressed = mixed.suppressed.finish(&mut self.masks(control))?;
            Ok(WideBlock {
                samples: mixed.samples,
                suppressed,''')
  s=replace(s,'                    suppressed: Vec::new(),','                    suppressed: AudioSuppressionMask::default(),')
 else:
  s=replace(s,'            suppressed: Vec::new(),','            suppressed: AudioSuppressionMask::default(),',4)
 after.write_text(s)
(d/'source-pins.json').write_text(json.dumps(pins,indent=2)+'\n')
