from pathlib import Path
import json,hashlib,difflib
d=Path('/tmp/deadpan-shared-mix-mask-candidate-2026-10-31')
root=Path('/tmp/deadpan-query-groundwork-2026-10-26/scoped')
files=['shared_mix.rs','shared_components/program/tests.rs','shared_components/prediction_tests.rs','shared_components/member_phases_tests.rs','shared_components/outputs_tests.rs','shared_eq/policy_prediction_tests.rs','shared_eq/cached_policy_tests.rs']
pins={}
for name in files:
 rel=Path('crates/deadpan-audio/src')/name
 source=(d/'new'/rel) if name=='shared_mix.rs' else root/rel
 raw=source.read_bytes()
 before=d/'test-before'/rel;after=d/'test-new'/rel
 before.parent.mkdir(parents=True,exist_ok=True);after.parent.mkdir(parents=True,exist_ok=True)
 before.write_bytes(raw);s=raw.decode()
 if name!='shared_mix.rs':
  pins[str(root/rel)]={'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}
 if name=='shared_mix.rs':
  old='impl MixedSuppression {\n'
  new='''impl MixedSuppression {
    #[cfg(test)]
    pub(super) fn ordinary_for_test(&self) -> &[Range<AudioSample>] {
        match self {
            Self::Ordinary(ranges) => ranges,
            Self::Pending { .. } => panic!("component fixture must retain its ordinary producer"),
        }
    }

'''
  assert s.count(old)==1;s=s.replace(old,new)
 elif name=='shared_components/program/tests.rs':
  assert s.count('assert_eq!(actual.suppressed, expected.suppressed);')==2
  s=s.replace('assert_eq!(actual.suppressed, expected.suppressed);','assert_eq!(actual.suppressed.ordinary_for_test(), expected.suppressed.ordinary_for_test());')
  s=s.replace('assert_eq!(block.suppressed, vec![AudioSample(12)..AudioSample(16)]);','assert_eq!(block.suppressed.ordinary_for_test(), &[AudioSample(12)..AudioSample(16)]);')
  s=s.replace('assert!(actual.suppressed.is_empty());','assert!(actual.suppressed.ordinary_for_test().is_empty());')
 elif name=='shared_components/prediction_tests.rs':
  old='''        result.suppressed,
        vec![
            AudioSample(-2)..AudioSample(-1),
            AudioSample(0)..AudioSample(1)
        ]'''
  new='''        result.suppressed.ordinary_for_test(),
        &[
            AudioSample(-2)..AudioSample(-1),
            AudioSample(0)..AudioSample(1)
        ]'''
  assert s.count(old)==1;s=s.replace(old,new)
 elif name=='shared_components/member_phases_tests.rs':
  assert s.count('assert!(output.suppressed.is_empty());')==1
  s=s.replace('assert!(output.suppressed.is_empty());','assert!(output.suppressed.ordinary_for_test().is_empty());')
 elif name=='shared_components/outputs_tests.rs':
  old='''                                merged_suppression(suppressed[index].clone()),
                                expected.suppressed'''
  new='''                                merged_suppression(suppressed[index].clone()).as_slice(),
                                expected.suppressed.ordinary_for_test()'''
  assert s.count(old)==1;s=s.replace(old,new)
 elif name=='shared_eq/policy_prediction_tests.rs':
  assert s.count('assert!(result.suppressed.is_empty());')==1
  s=s.replace('assert!(result.suppressed.is_empty());','assert!(result.suppressed.ordinary_for_test().is_empty());')
  assert s.count('assert_eq!(result.suppressed, vec![range]);')==1
  s=s.replace('assert_eq!(result.suppressed, vec![range]);','assert_eq!(result.suppressed.ordinary_for_test(), &[range]);')
 else:
  old='''        Ok((result.samples, result.suppressed))'''
  new='''        let crate::stages::shared_mix::MixedSuppression::Ordinary(suppressed) =
            result.suppressed
        else {
            panic!("separate prediction fixture must retain its ordinary producer");
        };
        Ok((result.samples, suppressed))'''
  assert s.count(old)==1;s=s.replace(old,new)
 after.write_text(s)
(d/'test-source-pins.json').write_text(json.dumps(pins,indent=2)+'\n')
