# E non-separate SharedMix mask producer

Scratch production candidate against Scope only. D published checkpoint supplied by parent: 6458e9b989172147e0844fcb251c89ce8c479aaf. Parent has frozen E-before33 before production edits. No root edits, Cargo, native/compiler execution, Git, expected-body generation, cap/weight changes, or broad Main snapshots. Main shared_eq.rs inherited WIP was not used as authority or copied.

rustfmt --edition 2024 --config skip_children=true passed on candidate and optional test-adapter files. Compilation and runtime qualification are owed to the parent.

## Integration

candidate.patch contains four production source files, with exact Scope before/new trees and independent per-file patches:

- shared_mix.rs: inline Ordinary versus Pending permission carrier, exact native projection, and literal pre-E projection under the parent-owned cfg(test) legacy flag.
- shared_components.rs: wraps its existing finished ordinary Vec in Ordinary; its algorithm/allocation/work are untouched and remain outside E ownership.
- shared_eq.rs: WideBlock mask becomes AudioSuppressionMask; direct ownership propagation to read_shared_input; projection after equalizer callbacks and depth validation, inside the source reservation closure; its empty cached-tile constructor becomes default.
- event_returns.rs: four existing empty WideBlock mask constructors become default; no new event mask producer is introduced.

Apply reviewed hunks to fresh sources, preserving Main WIP. Do not replace Main shared_eq.rs wholesale.

Required parent-owned test-only Stage declaration:

    #[cfg(test)]
    #[path = "shared_mix_mask_request.rs"]
    mod shared_mix_mask_request;

hook-proposal/shared_mix_mask_request.rs is only a suggested flag module. Production candidate calls its legacy() selector under cfg(test); parent owns integrating the flag, older wrapper chaining, producer receipts and capture glue. E-only replay must select this flag without disabling D Root or C Point. Older Root/compound wrapper chaining is parent-owned.

optional-tests.patch applies AFTER candidate.patch. It adds a cfg(test) borrowed ordinary_for_test slice accessor and mechanically adapts six existing test files. No ownership API is exposed: Pending panics in that accessor, which also verifies those tests still exercise the separate Components branch. Cached-policy's helper locally matches Ordinary and moves its already ordinary Vec into its existing fixture return type; it introduces no generic mask extraction/detach method and no new buffer copy.

test-before/new hold these exact test diffs. Their shared_mix.rs before is the new production candidate, while the other before files are current Scope. No expected assertions, budgets, callbacks, capacity checks, or old numerical work expectations are removed.

## Source custody and order

MixedBlock.suppressed is MixedSuppression::Ordinary(Vec<Range<AudioSample>>) or Pending { start, permissions: Vec<Permissions> }. The latter moves the exact existing final permissions Vec header from SharedMix. It neither copies the bitsets nor makes a new source buffer.

Non-separate read_shared_program already reserves frames*12 + mix.resident_frames. Its non-separate prediction adjustment releases zero. That existing complete scalar reservation remains in active_frames across mix.finish, every equalizer callback, the nested-depth check, and the new projection. No reservation formula, retirement count, or stage/dependency/PCM work changes.

The caller invokes MixedSuppression::finish only after mix.finish and depth validation succeed, before its existing reservation-release tail. The source grid stays in a local binding outside a bounded Result closure. Both success and every Result error finish that closure, dispose any pending target first, explicitly drop the source permissions Vec, and only then return. The caller cannot return a grid-bearing WideBlock. Rust ownership therefore closes source disposal before the scalar source-reservation tail, including all resource refusals. The external mutable mask context is never stored in a result.

For positive output, count scans each real permission entry with check/Scan before is_empty, reserves the actual empty-entry count through begin_ranges<AudioSample>, scans/emits the exact old [start+index, start+index+1) intervals, finishes the already-funded Box and merges the same Vec in place. The source grid remains live throughout destination reservation/allocation/merge. One Scan means one bounded Permissions::is_empty check, which inspects at most64 u64 words; no per-word receipt is claimed.

Every empty final permission entry counts, including adjacent entries. This preserves the old collector's event-count final capacity. Merge can compact length but keeps the full funded capacity. No source policy masks or PCM zeros are used to infer these intervals. The original absolute AudioSample arithmetic is retained, without Point/Signal conversion or invalid-range normalization.

An all-permitted grid pays its actual count Scan work, drops the grid, and returns default without destination account/payload allocation. Earlier D producers may already have initialized the account; this unit must report no new allocation at its own boundary, not infer no account for the whole request.

The ordinary Components and E-legacy carrier arms simply wrap their exact existing Vec as Plain, adding no work, merge, allocation or reinterpretation. Deferred Components outputs therefore remain explicit ordinary data. For E legacy, the original permissions.iter().enumerate().filter_map(...).collect() followed by merged_suppression is retained after all existing bus/equalizer work; no native projection is run in that lane.

New budget/cancellation/quota errors follow existing numeric/equalizer/depth failures. No WideBlock is published if projection fails. Accepted work remains literal; a retained initialized account shell is not refunded.

## Complete relevant carrier/consumer inventory

The separate authored_eq::WideBlock is a different private type and is untouched.

shared_eq.rs:
- WideBlock at81 has samples, suppressed, dependencies, relative_depth. Only suppressed's type changes.
- Node.tiles at99 and Graph.event_tiles at107 hold Arc<WideBlock>. These never clone mask storage; Arc sharing remains intact.
- read_shared_program at391 is the only producer of the selected derived permission mask. Its return at923 now contains only final mask+PCM/dependencies/depth; it cannot carry the permission Vec past the reservation tail.
- read_shared_input at348 consumes returned masks directly into actual SuppressionMask::extend. Its old Plain rewrap is removed. Positive chunks therefore trigger the existing genuine owned target/replacement path, with old source/target owners live during growth. Its final owned merge retains charge/capacity.
- shared_eq_tile at1223 consumes nested program PCM/dependencies and naturally disposes each temporary mask. Its Arc cached output constructor at1278 always uses an empty mask and remains empty. Its existing resident = output*2 reservation counts PCM only; no mask payload/capacity was in that formula.
- Graph release continues retiring graph.resident as before. No new owned payload is added to that scalar ledger, because the actual mask account already owns it.

event_returns.rs:
- EventOutput.returned at46 carries this same WideBlock.
- read_event_returns at98, event_return_tile cached Arc at406, event_prefix at440, and source-prefix output at514 all create empty masks and remain empty.
- Event tile residency at402 is width*2 PCM only. No range capacity expression or existing range payload debit exists to subtract. These empty masks add no account storage.
- Event processing methods use samples/dependencies/depth; no suppressed mutation/detach or deep mask clone was found.

MixedBlock:
- SharedMix::finish and Components::finish are the only production constructors. Components gets only an Ordinary wrapper.
- read_shared_program is the only production consumer of MixedBlock.suppressed.
- Existing direct SharedMix tests in processing_original_admission_tests and flattened_original_admission_tests build separate=true and do not read the changed field; they continue returning Ordinary.
- Optional mechanical adapters cover shared_components/program/tests, prediction_tests, member_phases_tests, outputs_tests, shared_eq/policy_prediction_tests, and cached_policy_tests. All reach Components/separate=true. Their old values/work/order assertions remain.
- cached_prediction_baseline::wide serializes WideBlock through a borrowed range slice. AudioSuppressionMask's existing Deref/borrowed iteration preserve that interface; no test detach or new baseline serializer is needed.
- Existing original-input tests comparing ReadBlock masks already use the opaque type and require no type adaptation.

No current WideBlock cache-resident formula counts suppressed.capacity. Therefore no speculative unaccounted-capacity subtraction was added. Existing ReadBlock/Original cache accounting already uses unaccounted_capacity and naturally avoids double-billing a now-owned result.

The opaque mask has the same Vec-sized representation by its existing layout contract. Parent should still compare actual qualified shallow WideBlock size/alignment against the pre-E four-field type, and preserve cached metadata evidence. No ABI size was guessed or used to change a reservation.

## Qualification owed and boundaries

Parent-owned receipts should borrow Pending's start, permission pointer/len/capacity before finish, observe the unchanged active source reservation during actual target reserve, and close the projection before the existing active_frames tail. The explicit drop(permissions) anchor is the physical disposal boundary on both success/error. No test-only production telemetry is added here.

Actual checked aggregate514, Source-only all-permitted, and real reached-projection resource refusals still need evidence. Capture every real 0/256,256/256,512/2 producer invocation rather than attributing whole-case counters by residual. Preserve the exact final ranges/capacity, PCM bits, dependencies/depth/errors, original query invalid flags and before33 bodies. Work-prefix refusal has to reach this producer, not an earlier D Root/metadata/equalizer refusal.

Compile both variants after parent integrates the flag/test adapters, verify Scope/Main WIP-aware hunks, run appropriate library/native/replay gates, and pin actual source copies. No passing test or numerical peak is claimed here.

Components masks, projected tape/Plan policy, exhausted storage, whole PCM/dependency preparation, generic graph accounting and wider cache closure remain outside E. Existing 3/12-frame reservation weights/caps and all canonical Plan query weights are unchanged.
