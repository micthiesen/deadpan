from pathlib import Path
from collections import Counter
import hashlib, json

root = Path('/tmp/deadpan-shared-mix-mask-qualification-2026-10-31')
out = Path('/tmp/deadpan-shared-mix-final-capture-review-2026-10-31')


def read(label, variant='main'):
    path = root / f'shared-mix-final3-{label}-{variant}-canonical.json'
    data = path.read_bytes()
    return path, data, json.loads(data)


def producer_traces(value, path=''):
    if isinstance(value, dict):
        trace = value.get('shared_mix_mask_producers')
        if isinstance(trace, dict):
            yield path, trace
        for key, item in value.items():
            yield from producer_traces(item, f'{path}/{key}')
    elif isinstance(value, list):
        for index, item in enumerate(value):
            yield from producer_traces(item, f'{path}/{index}')


def native_output_pairs(body):
    for case_index, case in enumerate(body['native_requests']['cases']):
        for operation_index, operation in enumerate(case['operations']):
            paired = operation['paired']
            yield case_index, operation_index, paired['new']['read']['output']


def work_sum(row):
    return sum(phase['attempted_units'] for phase in row['work_by_phase'].values())


def main():
    counts = Counter()
    active_path, active_bytes, active = read('active')
    prior_path, prior_bytes, prior = read('before-root')
    assert len(active['native_requests']['cases']) == 5
    assert active['native_requests']['operations'] == 744

    # The final active body is byte-identical in both roots and all three captures.
    active_sha = hashlib.sha256(active_bytes).hexdigest()
    assert active_sha == '9d6f3c67d9d611f46e75360006845a1b9419b30168a983db1ca9e4cf79c8be0a'
    for label in ['active', 'active2', 'active3']:
        for variant in ['main', 'scoped']:
            path, data, _ = read(label, variant)
            assert data == active_bytes, path
            counts['identical_active_captures'] += 1

    # All frozen E-before historical bodies are unchanged, cross-root exact, and
    # have no E observer fields. Their SHA values are the pinned D/C checkpoints.
    historical = {
        'before-off': 'af7a292718365c34fa03692e2cbe58a2cfb3c6d444b5ae29d52647e1fdbbff14',
        'before-interval': 'f64d3a00a10967cc3822083d21705bd454f2d33ff2198da30e25671092ab5a53',
        'before-policy': 'afa6038a02c959c7192c09c08a89266c7d52151a5e59a4f69828fbdf67e7414e',
        'before-root': '596d738a53f6ef4cbf7870d74b3025504f6289f735ea91f4a38ed45c6661f44a',
    }
    for label, expected in historical.items():
        data_by_variant = []
        for variant in ['main', 'scoped']:
            _, data, body = read(label, variant)
            assert hashlib.sha256(data).hexdigest() == expected
            assert not list(producer_traces(body)), (label, variant, 'E observer leaked into before body')
            data_by_variant.append(data)
            counts['historical_bodies'] += 1
        assert data_by_variant[0] == data_by_variant[1]

    # Active output values match the pre-E, post-D current output for every actual
    # native operation. This compares literal statuses, PCM, dependencies, masks,
    # capacities, and typed errors in the serialized output object.
    before_outputs = list(native_output_pairs(prior))
    after_outputs = list(native_output_pairs(active))
    assert len(before_outputs) == len(after_outputs) == 744
    changed = []
    for before, after in zip(before_outputs, after_outputs):
        assert before[:2] == after[:2]
        if before[2] != after[2]:
            changed.append((before[0], before[1]))
    assert not changed, changed[:10]
    counts['native_outputs_exact_pre_e'] = 744

    traces = list(producer_traces(active))
    assert len(traces) == 758, len(traces)
    rows = []
    row_paths = Counter()
    for path, trace in traces:
        assert trace['enabled'] is True, path
        assert trace['unfinished'] is False and trace['active_row'] is None, path
        assert trace['truncated_rows'] is False and trace['truncated_events'] is False, path
        counts['trace_snapshots'] += 1
        for row in trace['rows']:
            row_paths[path] += 1
            rows.append((path, row))
    assert len(rows) == 9, len(rows)
    assert all(path.startswith('/internal_and_transfer_paths/cases/') for path, _ in rows)
    grouped = Counter(path.split('/')[-1] for path, _ in rows)
    assert grouped == Counter({'4': 3, '5': 3, '9': 3}), grouped

    for path, row in rows:
        counts['producer_rows'] += 1
        length = row['source_len']
        source_capacity = row['source_capacity']
        source_reservation = row['source_reservation_frames']
        assert length == source_capacity and length > 0, (path, row)
        assert row['source_element_bytes'] == 512
        assert row['source_disposed'] is True
        assert row['source_identity_preserved'] is True
        assert row['source_disposed_len'] == length
        assert row['source_disposed_capacity'] == source_capacity

        # The same live source admission spans target admission and source disposal.
        assert row['active_frames_at_entry'] >= source_reservation
        assert row['result']['active_frames_after_disposal'] >= source_reservation
        reserve_before = next(event['value'] for event in row['events'] if event['kind'] == 'reserve_before')
        reserve_after = next(event['value'] for event in row['events'] if event['kind'] == 'reserve_after')
        assert reserve_before['active_frames'] >= source_reservation
        assert reserve_after['active_frames'] >= source_reservation
        assert reserve_after['active_frames'] == reserve_before['active_frames']
        assert reserve_after['accepted'] is True
        assert reserve_after['requested_frames'] == row['destination_reservation']['frames']
        assert row['destination_reservation']['accepted'] is True
        assert row['destination_storage']['capacity'] == row['result']['mask_capacity']
        assert row['result']['mask_len'] <= row['result']['mask_capacity']
        assert row['result']['owned'] is True
        assert row['result']['destination_identity_preserved'] is True
        assert row['result']['source_destination_allocations_distinct'] is True
        assert row['result']['success'] is True and row['result']['error'] is None

        # Both allocation/work receipts are from the actual call sites. Phase
        # accounting includes every existing native debit; the reserve delta
        # accounts for any reserve-path work not represented by a phase counter.
        phase_work = work_sum(row)
        account_phase = row['work_by_phase'].get('Account', {}).get('attempted_units', 0)
        for phase, values in row['work_by_phase'].items():
            assert values['attempted_units'] == values['accepted_units'], (path, phase, values)
            assert values['failed_calls'] == 0, (path, phase, values)
        plan_reserve_delta = reserve_after['plan_work'] - reserve_before['plan_work']
        cache_reserve_delta = reserve_after['cache_plan_work'] - reserve_before['cache_plan_work']
        plan_delta = row['result']['plan_work_after'] - row['plan_work_at_entry']
        cache_delta = row['result']['cache_plan_work_after'] - row['cache_plan_work_at_entry']
        assert plan_delta + cache_delta == phase_work + plan_reserve_delta + cache_reserve_delta - account_phase, (
            path, row['start'], phase_work, plan_reserve_delta,
            cache_reserve_delta, account_phase, plan_delta, cache_delta
        )
        before_native = row['native_work_before']
        after_native = row['result']['native_work_after']
        assert before_native['enabled'] and after_native['enabled']
        assert not before_native['overflow'] and not after_native['overflow']
        assert before_native['reset_epoch'] == after_native['reset_epoch']
        for left, right in zip(before_native['lanes'], after_native['lanes']):
            assert all(b >= a for a, b in zip(left, right)), (path, row['start'])
        assert row['host_boundary_before'][1] is False
        assert row['result']['host_boundary_after'][1] is False

    assert [row['start'] for _, row in rows if row['source_len'] == 256] == [0, 256, 0, 256, 64, 320]
    assert [row['start'] for _, row in rows if row['source_len'] == 2] == [512, 512, 576]

    # Account witnesses capture the payload delta while the result remains live
    # after the renderer goes away, then restoration after the result itself drops.
    internal = active['internal_and_transfer_paths']['cases']
    witnesses = {
        4: (522, 3),
        5: (522, 3),
        9: (529, 10),
    }
    for index, expected in witnesses.items():
        case = internal[index]
        live = case['account_after_controller_drop_internal_result_alive']['live_frames']
        released = case['account_after_internal_result_drop']['live_frames']
        assert (live, released) == expected
        counts['lifetime_witnesses'] += 1
    for index in [4, 5]:
        assert internal[index]['account_after_controller_drop_internal_result_alive']['live_frames'] - 3 == 519
    assert internal[9]['account_after_controller_drop_internal_result_alive']['live_frames'] - 10 == 519

    # Internal semantic result fields remain exact against pre-E; account fields
    # are the expected changed dimension. No broad whole-preparation claim follows.
    old_internal = prior['internal_and_transfer_paths']['cases']
    for index, current in enumerate(internal):
        old = old_internal[index]
        for key in old:
            if key.startswith('result_'):
                assert current[key] == old[key], (index, key)
                counts['internal_result_fields_exact'] += 1

    proof = {
        'active_capture_sha256': active_sha,
        'active_capture_bytes': len(active_bytes),
        'active_cross_root_and_repeat_exact': True,
        'historical_before_bodies_cross_root_exact': historical,
        'producer_trace_snapshots': counts['trace_snapshots'],
        'producer_rows': counts['producer_rows'],
        'positive_rows_by_internal_case': dict(grouped),
        'native_outputs_exact_pre_e': counts['native_outputs_exact_pre_e'],
        'internal_result_fields_exact': counts['internal_result_fields_exact'],
        'lifetime_witnesses': witnesses,
        'source_reservation_active_through_target_reserve_and_grid_disposal': True,
        'owned_destination_and_distinct_allocation_identity': True,
        'bounded_trace_complete_no_truncation': True,
        'work_delta_reconciles_to_phases_plus_actual_reserve_delta': True,
        'scope_limit': 'Producer-local SharedMix permission-grid to AudioSample output only. These rows do not attribute global operations to each nested query or establish whole-preparation resource claims.',
    }
    (out / 'analysis.json').write_text(json.dumps(proof, indent=2, sort_keys=True) + '\n')
    print(json.dumps(proof, indent=2, sort_keys=True))

if __name__ == '__main__':
    main()
