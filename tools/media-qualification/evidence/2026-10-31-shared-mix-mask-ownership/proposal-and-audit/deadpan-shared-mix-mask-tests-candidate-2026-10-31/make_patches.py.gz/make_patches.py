from pathlib import Path
import difflib

scope = Path("/tmp/deadpan-query-groundwork-2026-10-26/scoped/crates/deadpan-audio/src")
out = Path("/tmp/deadpan-shared-mix-mask-tests-candidate-2026-10-31/per-file-patches")
out.mkdir(exist_ok=True)

def patch(name, rel, transform):
    source = scope / rel
    before = source.read_text()
    after = transform(before)
    if before == after:
        raise RuntimeError(f"no changes for {rel}")
    (out / rel.name).write_text(after)
    diff = difflib.unified_diff(
        before.splitlines(True), after.splitlines(True),
        fromfile=f"a/crates/deadpan-audio/src/{rel.as_posix()}",
        tofile=f"b/crates/deadpan-audio/src/{rel.as_posix()}",
        n=3,
    )
    (out / f"{name}.patch").write_text("".join(diff))

def replace_once(text, old, new, label):
    if text.count(old) == 0 or (label != "actual mask reserve" and text.count(old) != 1):
        raise RuntimeError(f"{label}: expected one anchor, got {text.count(old)}")
    return text.replace(old, new, 1)

def stages(text):
    return replace_once(text,
'''#[cfg(test)]
#[path = "native_query_interval_trace.rs"]
mod native_query_interval_trace;
''',
'''#[cfg(test)]
#[path = "native_query_interval_trace.rs"]
mod native_query_interval_trace;
#[cfg(test)]
#[path = "shared_mix_mask_trace.rs"]
mod shared_mix_mask_trace;
''', "stages declaration")

def shared_mix(text):
    text = replace_once(text,
'''    pub(super) fn finish<C: MaskContext>(
        self,
        context: &mut C,
    ) -> Result<AudioSuppressionMask, StageAudioError> {
''',
'''    pub(super) fn finish<C: MaskContext>(
        self,
        context: &mut C,
        #[cfg(test)] receipt: Option<super::shared_mix_mask_trace::Receipt>,
    ) -> Result<AudioSuppressionMask, StageAudioError> {
''', "finish signature")
    text = replace_once(text,
'''            Self::Pending { start, permissions } => {
                let result = (|| {
''',
'''            Self::Pending { start, permissions } => {
                #[cfg(test)]
                let source_pointer = permissions.as_ptr() as usize;
                #[cfg(test)]
                let source_len = permissions.len();
                #[cfg(test)]
                let source_capacity = permissions.capacity();
                let result = (|| {
''', "pending entry")
    text = replace_once(text,
'''                    let mut ranges = begin_ranges::<AudioSample, C>(context, capacity)?;
                    for (index, mask) in permissions.iter().enumerate() {
''',
'''                    let mut ranges = begin_ranges::<AudioSample, C>(context, capacity)?;
                    #[cfg(test)]
                    super::shared_mix_mask_trace::destination_storage(
                        ranges.as_slice().as_ptr() as usize,
                        ranges.capacity(),
                    );
                    for (index, mask) in permissions.iter().enumerate() {
''', "destination builder")
    text = replace_once(text,
'''                drop(permissions);
                result
''',
'''                drop(permissions);
                #[cfg(test)]
                if let Some(receipt) = receipt {
                    super::shared_mix_mask_trace::source_disposed(
                        receipt,
                        source_pointer,
                        source_len,
                        source_capacity,
                    );
                }
                result
''', "source disposal")
    return text

def shared_eq(text):
    text = replace_once(text,
'''    AdmittedStop, Boundary, Contribution, OwnerKey, Permissions, SharedMix, Temporal,
''',
'''    AdmittedStop, Boundary, Contribution, OwnerKey, Permissions, SharedMix, Temporal,
''', "shared mix imports")
    text = replace_once(text,
'''use super::shared_mix::{
''',
'''#[cfg(test)]
use super::shared_mix::MixedSuppression;
use super::shared_mix::{
''', "test-only mixed suppression import")
    text = replace_once(text,
'''            // Keep the moved permission grid funded until projection drops it.
            let suppressed = mixed.suppressed.finish(&mut self.masks(control))?;
            Ok(WideBlock {
''',
'''            // Keep the moved permission grid funded until projection drops it.
            #[cfg(test)]
            let pending_source = match &mixed.suppressed {
                MixedSuppression::Pending { start, permissions } => Some(
                    super::shared_mix_mask_trace::pending_source(*start, permissions),
                ),
                MixedSuppression::Ordinary(_) => None,
            };
            #[cfg(test)]
            let receipt = pending_source.and_then(|source| {
                super::shared_mix_mask_trace::begin(
                    source,
                    reservation,
                    self.active_frames,
                    self.owned_suppression.live_frames(),
                    control,
                )
            });
            let projection = {
                #[cfg(test)]
                {
                    mixed.suppressed.finish(&mut self.masks(control), receipt)
                }
                #[cfg(not(test))]
                {
                    mixed.suppressed.finish(&mut self.masks(control))
                }
            };
            #[cfg(test)]
            if let Some(receipt) = receipt {
                super::shared_mix_mask_trace::complete(
                    receipt,
                    &projection,
                    self.active_frames,
                    self.owned_suppression.live_frames(),
                    control,
                );
            }
            let suppressed = projection?;
            Ok(WideBlock {
''', "producer callsite")
    return text

def ops(text):
    return replace_once(text,
'''    control.spend_plan_work(units)?;
    #[cfg(test)]
    crate::stages::native_query_interval_trace::accepted_work(control);
    #[cfg(test)]
    trace::spend_accepted(control.work.borrow().cache_key_scopes > 0, phase, units);
    #[cfg(not(test))]
    let _ = phase;
    Ok(())
''',
'''    let result = control.spend_plan_work(units);
    #[cfg(test)]
    crate::stages::shared_mix_mask_trace::work(phase, units, result.is_ok());
    result?;
    #[cfg(test)]
    crate::stages::native_query_interval_trace::accepted_work(control);
    #[cfg(test)]
    trace::spend_accepted(control.work.borrow().cache_key_scopes > 0, phase, units);
    #[cfg(not(test))]
    let _ = phase;
    Ok(())
''', "central actual work debit")

def mask_context(text):
    return replace_once(text,
'''    fn reserve(&mut self, frames: u64) -> Result<point_suppression::Charge, StageAudioError> {
        self.renderer.reserve_mask_storage(frames, self.control)
    }
''',
'''    fn reserve(&mut self, frames: u64) -> Result<point_suppression::Charge, StageAudioError> {
        #[cfg(test)]
        super::shared_mix_mask_trace::reserve_before(
            frames,
            self.renderer.active_frames,
            self.renderer.owned_suppression.live_frames(),
            self.control,
        );
        let result = self.renderer.reserve_mask_storage(frames, self.control);
        #[cfg(test)]
        super::shared_mix_mask_trace::reserve_after(
            frames,
            result.is_ok(),
            self.renderer.active_frames,
            self.renderer.owned_suppression.live_frames(),
            self.control,
        );
        result
    }
''', "actual mask reserve")

def baseline_module(text):
    return replace_once(text,
'''#[path = "native_query_interval_tests.rs"]
mod native_intervals;
''',
'''#[path = "native_query_interval_tests.rs"]
mod native_intervals;
#[path = "internal_suppression_shared_mix_tests.rs"]
mod internal_suppression_shared_mix_tests;
''', "baseline test module")

patch("stages", Path("stages.rs"), stages)
patch("shared_mix", Path("shared_mix.rs"), shared_mix)
patch("shared_eq", Path("shared_eq.rs"), shared_eq)
patch("ops", Path("point_suppression/ops.rs"), ops)
patch("mask_context", Path("mask_context.rs"), mask_context)
patch("baseline", Path("bound_reads/internal_suppression_baseline.rs"), baseline_module)
