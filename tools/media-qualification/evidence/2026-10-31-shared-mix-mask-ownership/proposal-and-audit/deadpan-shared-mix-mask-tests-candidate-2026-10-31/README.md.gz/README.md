# E SharedMix native mask test and capture contract

Scratch-only proposal, 2026-10-31. No repository edits, builds, native runs, or Git. Production authority is Scope `/tmp/deadpan-query-groundwork-2026-10-26/scoped`; current Main `shared_eq.rs` contains unrelated WIP.

## Frozen before / variants

Published D is remote revision `6458e9b989172147e0844fcb251c89ce8c479aaf`, exact published paths 643, all 2599 scoped inputs exact. The E-before fixture is `/tmp/deadpan-query-groundwork-2026-10-26/scoped/crates/deadpan-audio/tests/fixtures/shared-mix-mask-baseline-v1/snapshot.json`, SHA-256 `596d738a53f6ef4cbf7870d74b3025504f6289f735ea91f4a38ed45c6661f44a`; archive proof is `/tmp/deadpan-shared-mix-mask-qualification-2026-10-31/before-freeze-proof.json`. Freeze the complete 33-row/fixture before body before E edits. E legacy mode must disable only E's SharedMix output-mask ownership producer; C and D remain active. Preserve exact preexisting body bytes for all unchanged rows and all old raw fields. Active E appends producer receipts / E-only cases and does not rewrite D's already-frozen body.

## Real positive source

Reuse `bound_reads/internal_suppression_baseline.rs::aggregate(false)` and its `aggregate-514-shared-input` case. It builds a checked public document with 514 alternating one-frame SilentHold and Source nodes (`:284-305`); the internal case directly calls shared input (`:378-386`). The actual `case_internal` path builds `cases::prepared(cases::Wav::Stereo48000)` (`:532-535`) and dispatches the fixture through a real `StageAudio` and public provider. The 514-frame read splits into real `read_shared_program` requests of 256, 256, and 2 (`shared_eq.rs:344-355`). Expected old mask is 257 distinct singleton ranges at even offsets across the 514 frames, subject to exact E-before body parity, with real WAV data and dependencies.

## Observer and tests

`shared_mix_mask_trace.rs` is a default-off, thread-local receipt buffer capped at 128 rows and 64 events per row. It records only the active producer. Pointer values remain private integers used for in-process equality checks; serialized receipts contain no address. `per-file-patches/` contains anchor-checked unified patches against the current E-integrated Scope sources: stages root declares the trace module; `shared_eq.rs` captures a borrowed Pending descriptor and actual reservation/work/native/host boundaries before finish, then completes on both Ok and Err before the existing reservation tail; `shared_mix.rs` records destination slice identity after the real reserve/Vec allocation and observes source Vec identity from inside the explicit drop; `mask_context.rs` surrounds the real reserve; `point_suppression/ops.rs` instruments the one central existing debit without duplicating it. No owning accessor or fake admission is introduced. `module-hook.patch` adds the test module to `internal_suppression_baseline.rs`.

The tests use the checked 514-frame alternating graph and actual `StageAudio::read_shared_input` with the prepared WAV provider. They compare E-only legacy and active snapshots, check real 256/256/2 producer receipts and returned-mask lifetime after renderer drop, exercise a checked Source-only all-permitted path, and derive a native-work seed from the measured first producer prefix. No caps/work weights are raised, and no synthetic mask/accounting state is injected. These are uncompiled and unexecuted candidates; parent owns qualification and must reconcile assertions with actual receipts.

`layout-test.patch` compares current private `WideBlock` size/alignment with a source-reconstructed pre-E four-field layout. This is an in-process structural assertion, not a before-binary experiment. Keep it E-only and out of the frozen D capture.

The observer is not called on ordinary or E-legacy output. Source-disposal metadata is captured from the actual moved Vec immediately after its `drop`, then post-drop active/account values are captured by the caller before the outer reservation decrement. Actual native work is observed centrally in `spend_work`, including lazy `Account` work inside `reserve_mask_storage`; reserve before/after receipts come only from the actual `Context::reserve` method. Global operations are not attributed to producer intervals.

## Three production-path tests

### 1. Positive mask, chunk merge, and output lifetime

In the existing `internal_suppression_baseline.rs` module, invoke the actual `aggregate-514-shared-input` checked fixture with its real WAV provider. Assert the E-only legacy and active E results have identical returned `ReadBlock` PCM bits, dependencies, depth, and exact 257 singleton AudioSample ranges/capacity. Assert receipts show three real producer entries (starts 0/256/512, counts 256/256/2), source grid pointer and source `active_frames` unchanged through each destination admission and source disposal, destination capacities equal their actual accepted charges, and each owned chunk owner survives until the final `extend`/merge. Hold the final returned block, drop provider, graph/controller/renderer, inspect its independent observer, then drop the block and confirm payload releases to the prior baseline. Keep account shell separate from payload.

### 2. Genuine zero-emission non-separate case

Use an actual checked Source-only public document and real WAV provider with the same private SharedInput path. The receipt must prove the non-separate producer ran, no destination reservation or storage constructor happened in that producer, and the final mask is empty. Check a producer-local account delta rather than assuming the whole read has no earlier C/D mask account activity. A final empty mask without this producer receipt is insufficient.

### 3. Real destination-admission refusal and cleanup

Use the same checked alternating 514 fixture and real WAV. The candidate below exercises the existing work limit with a seed derived from the measured first producer work entry, the real plan/cache work delta across the reserve call (including lazy account and host residency debits), the actual vector admission, and one real emitted entry. The receipt must show destination admission succeeded, the producer entered Map work, and a later existing Scan debit failed. It then confirms error propagation and cleanup. This establishes genuine partial-producer cleanup without an injected cap, but it does not test refusal of the new destination admission itself; that remains an evidence gap unless a real default-limit input reaches that boundary.

## Existing case / capture changes

Add a D/E after capture file only; never overwrite D's frozen fixture. Preserve all 33 prior cases exactly and add scoped SharedMix producer receipt to the actual aggregate row plus the Source-only zero case if it is not in the original 33. E-only legacy should gate only this producer, with C/D still active; keep before/legacy and active outputs serialized from actual execution, not normalized oracle expectations. Record actual native operations, account observations, capacities, error prefixes, and explicit attribution scope. Do not claim global NativeOps totals identify every nested SharedMix producer call.

## Scope limits

This proves only non-separate SharedMix permission-grid projection to an owned AudioSample mask and its existing `read_shared_input` chunk receiver. Components-path mask producers, projected provider/tape masks, Plan policy allocations, exhausted Vec reuse, PCM/dependency ownership, and whole preparation remain out of scope. No new caps, canonical weights, normalized source charging, or work credit is proposed.

## Source pins

- D published revision `6458e9b989172147e0844fcb251c89ce8c479aaf`; E-before fixture SHA above.
- `shared_mix.rs`: `09c5d7553def3fdb0bb0d5850cd635b3d2eaaf76533f26525e458c9ce0b20220`
- `shared_eq.rs`: `18f9f2744f95f986d8b3b396e4f06b41dc5eb877f3372da28bf2becfffbef87c`
- Those two are E-before pins from `/tmp/deadpan-shared-mix-mask-candidate-2026-10-31/before`; current integrated Scope versions observed for hook placement were `shared_mix.rs` `37d87f1d1294759c827665e13176f86982074885cc41f23b2abbb76664bfab16` and `shared_eq.rs` `cf82ebc90c23d70296196be90fa188ddf524d9fa2b3213beb2705e74f2481275`. Re-pin before parent integrates these scratch hooks.
- `point_suppression.rs`: `ea7c967d2e6a9d19e60901fbdfcd6849e0b4450aba441fc2b156c05b6ea6ffd1`
- `bound_reads/internal_suppression_baseline.rs`: `a2fb05dffb8e2eafe2fa095b69249038be5e28e3c4ffb6d1961d098a58e388ea`
- `shared_eq/original_inputs_tests.rs`: `cdf731464ace660f62c8010332636fdba78be372fa90591f25e6f634dd371a80`
- Current integrated Scope hook targets observed while drafting: `stages.rs` `5979d53c2cdc0d57fa60a658d7c63549017a06074c9ac52dcd96f4b7ea797598`; `shared_mix.rs` `37d87f1d1294759c827665e13176f86982074885cc41f23b2abbb76664bfab16`; `shared_eq.rs` `cf82ebc90c23d70296196be90fa188ddf524d9fa2b3213beb2705e74f2481275`; `mask_context.rs` `ca66d52bd1489702745f1b26719846456ad51c8133d8d3090f76e490897b00b1`; `point_suppression/ops.rs` `69ae0914fdb9e3fa814c346b5bae63568f2802677cf5f48ac65da99d326ce440`.
- `point_suppression.rs`: pinned above; current `reserve_mask_storage` is lines 342-363.
- `mask_context.rs`: E selected path uses `Context::reserve` (lines 16-20); its separate `TransferContext::reserve` is not patched because this SharedMix caller uses `Context`.
- `point_suppression/ops.rs`: `spend_work` at lines 22-35 is the central actual Plan debit, including lazy-account debit; `RangeBuilder::as_slice` at lines 85-89 is cfg(test) and borrowed only.
- Scratch Rust pins after formatting: trace `31427ccbe5648a367128dc36a409f55311c1729cb0186353cfad1495edf2a7d7`; test module `76c6b0d93f542a381afcd0783e6e595c7cad0e61d1559c5c2f5972b645a122ea`.
