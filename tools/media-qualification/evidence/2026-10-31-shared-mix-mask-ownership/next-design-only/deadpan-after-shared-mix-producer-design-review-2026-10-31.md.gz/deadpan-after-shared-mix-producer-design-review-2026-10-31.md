# Components single-output producer design review

**GO for the bounded design. No material blocker found.** Reviewed the final design SHA-256 6d212e9e47e6a98f5a578d142f44aad047b173bf85cd4b7c3adc57361faeeda4, replacing the initially assigned 83ab768f... revision. All 12 source hashes declared by that final design match current Scope. This is a static design review, not implementation, compilation, native execution, E publication, or Gate evidence.

## Literal behavior and boundary

Current Components::finish is the sole production caller of finish_into; other direct callers are tests. SharedMix::finish selects it only for separate == true. The old wrapper allocates PCM, collects one-sample suppression ranges in an ordinary Vec, then calls merged_suppression. Closing this wrapper is a concrete producer closure. Keeping the ordinary multi-output destination contract explicit is honest.

The three actual mark sites support the design's capacity argument:

- Dynamic single-output: shared_components.rs sets PCM after validating sum and applicable send finiteness, then calls mark_suppressed once if final permitted is false.
- Dynamic multi-output: same relative finite-check/set/mark order; remains the ordinary deferred path.
- Constant driver: block.rs validates the sum and captured send, sets PCM, then marks once if final permitted is false.

Both single-output drivers iterate every frame once. Each frame has at most one mark. Thus recording true at the original frame index preserves actual mark count and order, without inferring policy from numerical zero. The old final merge uses Vec::with_capacity(ranges.len()), so successful final capacity is the mark count, not coalesced run count. Endpoint arithmetic remains valid because the common driver checks start plus full frame count before processing.

The controlled sink must preserve these exact sites and make the new Mark refusal occur after the same PCM write. Keep literal ordinary/None behavior and ordinary validation order. A flag sink needs its own exact-length validation; an initialized nonempty bool slice must not accidentally inherit the ordinary Vec's “suppression is not empty” rejection. Its false initialization comes from the owning constructor, not a second policy replay.

## Admission, custody and callbacks

The strengthened reservation explanation is correct. Separate Components::resident_frames covers route Sample PCM, gain/program storage, permitted/predicted matrices and output PCM. It excludes the new bool Vec and the old ordinary mask Vec. The existing scalar source reservation, after prediction retirement, must remain unchanged and live; native FlagBuffer and final range storage are additional real allocations.

begin_flags currently reserves the actual bool Layout before Vec::with_capacity, verifies capacity, and checks/bills each initialization before push. Its result owns its charge and contains no context borrow. FlagBuffer field order physically drops the Vec before Charge. Calling it through a temporary self.masks(control) before mix.finish is therefore compatible with the equalizer closure borrowing mutable StageAudio afterward. No StageAudio or mutable MaskContext may be captured in the output sink.

A concrete feasible boundary is to pass an owning optional FlagBuffer into the private SharedMix finish dispatch, selecting a controlled Components wrapper only for the production separate arm. That wrapper borrows the flags for finish_into, ends the borrow, then moves the same owner plus AudioSample start into the pending result. It can retain the existing ordinary wrapper for direct fixtures and the independent legacy lane. No consuming public iterator, clone, or mask detach is required.

At mark sites, use the existing centralized native ops::spend_work(control, MaskWorkPhase::Mark, 1) after control.check(), then write true. This preserves one actual debit and the existing native interval/phase attribution without retaining a renderer borrow.

The current read_shared_program closure holds its source active reservation through mix.finish, the old nested-depth check, and the E projection call. Its release tail runs only after the closure returns. Extend that same finalizer with the owning flags arm: retain flags through count, destination admission, fill, Box finish and owned merge; physically drop flags before returning either result and before the tail. Numeric/callback failure before returning the pending result must also drop the owner within this closure. These are concrete owners and disposal points, not retroactive source accounting.

## Limits and required proof

No new canonical Plan fee, cap, old source reservation, or refund is needed. New scratch/Mark/projection resource refusals can precede later old numeric failures. Adequate-resource validation, callback, finite-check and write order must remain literal. Do not promise universal downstream capacity parity after owned aggregation.

PreserveTape remains an actual ordinary source gap: signal_input::policy calls AudioSignalTape::policy_after_preserve; policy_inner performs recursive override/per-run policy construction and ordinary Vec aggregation. Funding its final native copy alone would not close that producer. Deferring it is justified.

The proposed evidence requirements are appropriate, especially a real checked separate path for both constant and dynamic drivers, callbacks while flags are live, actual scratch-to-destination overlap, every reached resource refusal, and retained output/cache lifecycle. Mark failures must be attributed to this producer, not inferred from whole-invoke residuals. Existing E rows must remain separately identifiable; a new pending variant must not accidentally activate the permission-grid observer or ordinary fixture panic arm.

E qualification/publication and a fresh post-E before capture remain prerequisites. Preserve all old replay modes independently. An unreachable numeric/depth failure should be disclosed as missing evidence rather than synthesized. No source, build, native execution, Git, or root state was changed by this review.

## Pins

Exact source paths, byte sizes and SHA-256 values: /tmp/deadpan-after-shared-mix-producer-design-review-2026-10-31/source-pins.json (17 files; SHA-256 7b47103f0768f305e538f4170f324e5c6a9f3aa49e21de931a50d0e62eda2aa4). Navigation evidence is the adjacent ripwire.txt. Scope alone supplied implementation authority; Main inherited shared_eq WIP was not read.
