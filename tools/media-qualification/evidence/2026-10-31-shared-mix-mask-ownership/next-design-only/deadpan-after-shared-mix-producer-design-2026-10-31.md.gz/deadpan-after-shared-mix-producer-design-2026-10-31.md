# Next producer after non-separate SharedMix

Recommendation: close the **current production single-output Components wrapper**, not PreserveTape policy. Read-only design against current Scope. Published base: 6458e9b989172147e0844fcb251c89ce8c479aaf. E code is integrated but remains in parent-owned qualification; this note does not call E published, freeze a future before body, award a Gate, or authorize its implementation before E qualifies. No roots, builds, native runs or Git were changed. Main shared_eq.rs WIP was not used.

## Why this is the smaller meaningful closure

Components::finish is the only production caller of finish_into. Other finish_into callers are tests. The production wrapper creates a fresh ordinary suppression Vec, passes it as Output.suppressed, then merged_suppression allocates its final Vec. SharedMix's separate branch returns this as MixedSuppression::Ordinary; E's WideBlock carrier/receiver can already carry an owned replacement. This is an actual native producer, not a copy of already returned policy metadata.

There is **no final Components permission grid to move as in E**. The per-route SamplePermissions matrix is not the final output permission: selection/aliases and the actual final permitted decision matter. The dynamic driver marks after finite validation and PCM set at shared_components.rs:519 and556; the constant/block driver marks after the same final checks/set at block.rs:158. A per-output decision exists only locally at those sites. Reconstructing it afterward from PCM or replaying route/gain/equalizer logic would be incorrect.

A new, explicitly funded scratch FlagBuffer records those actual decisions and survives numeric finish. Existing begin_flags already reserves its actual bool Vec before allocation, checks/bills initialization, owns its native charge and retains no StageAudio borrow. That makes the new source grid honest rather than pretending the old mix reservation included an extra allocation.

PreserveTape's native final wrapper is smaller in lines but not in full ownership scope. routed.rs::read_projected_signal_controlled prepares/caches projected PCM, samples it, then suppress_signal obtains an ordinary AudioSignalTape::policy_after_preserve query. Plan audio_tape::policy_inner performs run lookup, recursive policy_override, per-run policy_on_grid, Vec aggregation/sort/merge. No admitted tape policy carrier was found. Funding only a final native copy would leave that actual Plan producer ordinary. Full closure requires the tape recursion/grid/override inventory and dedicated admission/lease design, not C's direct PointCeil carrier.

## Bounded implementation contract

Scope only the existing single-output production wrapper. Leave ordinary multi-output finish_into destinations and their pre-admitted-capacity API explicit/deferred. Keep a literal old wrapper/Vec sink selectable for independent before replay. Do not implement both producers.

1. In read_shared_program, after the existing prediction verification/reservation adjustment and before the separate numeric finish, admit a FlagBuffer of the actual mix frame count only for the separate path. Use the real temporary StageAudio mask context; drop that mutable context borrow before any equalizer callback. Keep all existing request checks and the exact frames*12 + mix.resident_frames reservation, including its existing prediction-retirement adjustment, unchanged. Do not fold guessed flag bytes into that scalar reservation or invent a ticket for old buffers.

2. Give Output.suppressed a private sink capable of the literal ordinary Vec destination or a borrowed slice of that actual funded FlagBuffer. None remains no observation. Ordinary Vec validation, empty/capacity checks, push order and work remain literal. The new controlled wrapper supplies exactly one correctly sized false-initialized flag slice. Preserve the existing predicted-state, output-count, start+frames and shape validation at driver entry before processing any output. Do not replay Program::prepare or the numeric visitor to count output.

3. At the three existing mark_suppressed sites, retain finite checks and samples.set before marking. Pass the existing frame index and exact sample label; record true for suppression at that same index, with actual WorkControl check/Mark debit before writing the flag. Legacy/None sinks add no new bill. Use a fallible mark result and stop immediately on refusal. No StageAudio borrow or generic reservation callback is needed at these sites, so the existing mutable equalizer callback remains valid.

Each single-output driver visits every frame once and reaches at most one mark per frame. Therefore true-count equals the old emission count, including adjacent decisions. False means no old mark, not nonzero PCM. Keep sends, aliases, zero-gain permission, unselected voices and temporal phase order exactly as now.

4. After callbacks complete, return the exact owning FlagBuffer with its AudioSample start as a new pending MixedSuppression variant. Do not copy it into an ordinary Vec or return borrowed scratch. The ordinary Components wrapper remains the explicit legacy/deferred arm. Existing component source matrices/programs/PCM follow their old disposal; the flags have their own separate native charge.

5. After the existing nested-depth check, inside the current read_shared_program closure, scan actual flags to count true entries, then reserve begin_ranges<AudioSample> for exactly that count. Check/bill both scans, emit the old [start+i,start+i+1) intervals, finish and merge in place. Keep flags alive throughout target admission/construction/merge. Use a bounded Result closure and unconditionally drop the owning flags before returning success/error, before the unchanged active_frames release tail. No source or target charge is refunded early.

If no flags are true, return the allocation-free empty final mask and dispose the scratch flags. Scratch allocation may already have initialized the account shell; do not claim the whole call allocated nothing. Positive masks retain full actual emission-count capacity/charge after merge, with no gratuitous shrink.

New scratch admission/Mark/scan failures are resource prefixes. They can preempt later old numeric failures; preserve actual typed errors and partial work. With sufficient resources retain the old relative validation, callback, finite-check, PCM write and suppression order. Do not move depth checks, waive input validation, or claim every old error precedence is unchanged.

## Sources, carriers, caches and ownership

The current source budget is not just the outer frames*12 transient allowance. E's non-separate mix.resident_frames includes (buses.len()+1)*frames*(2+WORDS), covering sum/bus PCM and every permission-bitset buffer. The separate branch instead delegates to Components::resident_frames, which covers route Sample PCM, prepared gains/programs, permitted/predicted matrices and its output PCM. Neither existing branch is repriced here. Components::resident_frames does not cover the fresh suppression Vec or a new flags allocation. Keep that existing source reservation live exactly as it is; new flags and ranges use the native account. No invented transfer of per-route permissions is needed.

SharedMix::finish is the production entry to Components::finish; read_shared_program is the only production MixedBlock receiver. Extend the existing pending carrier/finish mechanism rather than returning flags past its reservation tail. E already changed WideBlock.suppressed to AudioSuppressionMask and read_shared_input directly extends that owner. No further public type change or mask detach/clone API is needed.

Nested shared_eq_tile reads consume transient WideBlock PCM/dependencies and drop masks; their cached outputs, and event-return cached outputs, construct empty masks. Preserve their existing reservation formulas. Original ReadBlock cache already uses unaccounted_capacity and must not re-debit owned payload. The new flags are transient source scratch, never cached. Do not claim graph headers, PCM/dependency allocations or whole preparation are closed.

Expected production edits are shared_eq.rs, shared_mix.rs, shared_components.rs, shared_components/outputs.rs and block.rs, plus the parent-owned legacy/test hooks. Existing direct Components/multi-output tests need a literal ordinary path or mechanical sink adaptation, not a fake native context. Actual selected-production tests must exercise the funded flag path.

The old single-output final capacity is count(mark_suppressed), because the final ordinary merge allocates with_capacity(input.len()). The proposed final owner keeps that same capacity at this producer. Downstream repeated merges/growth can retain a funded capacity where old Plain logic made a shorter allocation, as D demonstrated. Preserve actual capacity changes in evidence rather than promising universal capacity parity.

## Deferred PreserveTape contract

The routed ordinary policy source is not native-account-funded merely because projected PCM is cached. suppress_signal computes checked end, constructs the ordinary policy, charges its returned work, preflights every content, checks cancellation, validates/applies suppression, then merges. Its other production callers in stages.rs and stage_cache.rs would be broadened by rewriting the generic helper.

Any later tape policy admission must preserve self.grid.boundary_rule(), route/sample bounds, run coverage/progress errors, remaining-work checks, recursive override order, lookup/work, after-Preserve endpoints=false, and actual nested content inventory. Stage-projection preparation itself caches samples/dependencies rather than a returned mask; its policy preflights are also ordinary and discarded. An independently scoped final-copy unit is possible, but must explicitly retain these ordinary source gaps and cannot claim producer closure.

## Evidence required after E publishes

Freeze a fresh actual post-E before body first. Keep E-only and older literal replay independently selectable. The current integrated hashes below are source authority only, not published E authority.

- Prove production separate=true with actual checked gain/selection and real WAV/provider cases, including constant and dynamic driver branches, unselected/alias, sends and temporal callbacks. The 514 alternating fixture alone may select E's non-separate branch and is insufficient.
- Capture actual scratch ptr/len/capacity, accepted flag initialization/marks, existing source reservation/ledger, target count/capacity/charge and flags disposal before the tail. Distinguish these real producer intervals from earlier C/D/E work; no global residual attribution.
- Compare complete PCM bits, mask values/capacity, dependencies/depth and errors to fresh before. Include allowed numerical zero, no-mark final result and every small reached native prefix. A failure in earlier metadata, E projection or an equalizer does not prove new marking/projection cleanup.
- Refuse during scratch admission, an actual mark, range admission, emission and merge; verify no returned block, active/source cleanup and native payload back to the prior live baseline plus any real retained shell. Exercise callback/numeric/depth errors with flags genuinely live.
- Retain successful output beyond request/controller/work and actual cache pin/hit/eviction. Preserve old receipt invalid flags and all resource/capacity differences. No cap/weight/refund adjustment or expected-body regeneration.

## Source pins

All source hashes are for current Scope. Complete paths/sizes/hashes are in the adjacent source-pins.json; ripwire output is retained beside it.

| Scope source | SHA-256 |
| --- | --- |
| /tmp/deadpan-query-groundwork-2026-10-26/scoped/crates/deadpan-audio/src/shared_components.rs | bb8b1fa8dcd4643a46da4c64de3d8c13c7fa456e09ac42468c6a17640359f9fd |
| /tmp/deadpan-query-groundwork-2026-10-26/scoped/crates/deadpan-audio/src/shared_components/outputs.rs | 010256b3875e0232a2bd3e1ac6be9288d5437fd89ba6f29a2a5e710a0d62a135 |
| /tmp/deadpan-query-groundwork-2026-10-26/scoped/crates/deadpan-audio/src/shared_components/block.rs | b6e86a2c9dca575d27ffe56da8e67875141956dec1163ef9e5eb893138281fd0 |
| /tmp/deadpan-query-groundwork-2026-10-26/scoped/crates/deadpan-audio/src/shared_mix.rs | 6febdc603d938135b80ab044d5a35b5d782e0f9feea7ccb117c852a2663fb946 |
| /tmp/deadpan-query-groundwork-2026-10-26/scoped/crates/deadpan-audio/src/shared_eq.rs | cb4debedc5e8557a2bd4a20beb25fc551f0ab2837f1344ebb5f3315a8b385220 |
| /tmp/deadpan-query-groundwork-2026-10-26/scoped/crates/deadpan-audio/src/point_suppression/ops.rs | 688f1f18689d9f59f3459b06a2ab0229113fda8d63e602cb662759bb4d5f24be |
| /tmp/deadpan-query-groundwork-2026-10-26/scoped/crates/deadpan-audio/src/routed.rs | 25438251bd81d7fca909d14f4346e1246cab95b418efbfa14c52f8a37e5b8b55 |
| /tmp/deadpan-query-groundwork-2026-10-26/scoped/crates/deadpan-audio/src/signal_input.rs | e1b9782f8730a19ce2fc46e393033f642d666d6109466b045146d747b8a08085 |
| /tmp/deadpan-query-groundwork-2026-10-26/scoped/crates/deadpan-audio/src/stages.rs | 285aadc9273d4e8dd799a4b4e835d5926c1397d550f61e622bc957d86e2aab69 |
| /tmp/deadpan-query-groundwork-2026-10-26/scoped/crates/deadpan-audio/src/stage_projection.rs | a5f08ab39c0f3b24538f69d0ce8560bc00544ca262fb6340bd92298a9a03f2c6 |
| /tmp/deadpan-query-groundwork-2026-10-26/scoped/crates/deadpan-audio/src/stage_cache.rs | 0b4ef0910835c8b080647faae76a296883ababe1b8a9aad7fc6dd46bc671de3f |
| /tmp/deadpan-query-groundwork-2026-10-26/scoped/crates/deadpan-plan/src/audio_tape.rs | 8a2359dcf69be1eeb1961697b722032d8b36d3ab009adb3c2c3fe1ed8363540e |
