from pathlib import Path
import json,hashlib
s=Path(__file__).parent
rev=(s/'published-revision.txt').read_text().strip()
assert (s/'remote-main.txt').read_text().split()[0]==rev
tree={}
for raw in (s/'published-tree.bin').read_bytes().split(b'\0')[:-1]:
 meta,path=raw.split(b'\t',1);mode,kind,oid=meta.decode().split()
 tree[path.decode()]=(mode,kind,oid)
rows=json.loads((s/'publication-inputs.json').read_text())
for r in rows:assert tree[r['path']]==('100644','blob',r['git_blob'])
inputs=json.loads((s/'scoped-source-files.json').read_text())
scope=Path('/tmp/deadpan-query-groundwork-2026-10-26/scoped')
for rel in inputs:
 data=(scope/rel).read_bytes()
 oid=hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()
 assert tree[rel][1:]==('blob',oid),rel
idx=json.loads((s/'index-publication-audit.json').read_text())
proof={'revision':rev,'remote_main_exact':True,'published_paths_exact':len(rows),'all_scoped_inputs_exact_in_tree':idx['scoped_code_inputs_exact'],'archive_sha256':idx['archive_sha256'],'preserved_unowned_main':True}
(s/'publication-proof.json').write_text(json.dumps(proof,indent=2)+'\n');print(json.dumps(proof))
