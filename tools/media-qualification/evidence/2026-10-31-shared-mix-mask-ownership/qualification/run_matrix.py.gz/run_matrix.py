from pathlib import Path
import hashlib,json,subprocess,sys
s=Path(__file__).parent
build,variant,label=sys.argv[1:]
pins=json.loads((s/(build+'-pins.json')).read_text())
assert len(pins)==21 and all(p['package']=='audio'for p in pins)
matrix=[]
for pin in pins:
 assert hashlib.sha256(Path(pin['path']).read_bytes()).hexdigest()==pin['sha256']
 args=['--test-threads='+('1'if pin['name']=='deadpan_audio'else'4')]
 if variant=='main'and pin['name']=='stages':args+=['--skip','general_split_sound::']
 name=label+'-'+pin['name'].replace('_','-')
 result=subprocess.run(['python',str(s/'run_target.py'),build,variant,'audio',pin['name'],name,*args])
 matrix.append({'target':pin['name'],'sha256':pin['sha256'],'run':name,'exit_code':result.returncode})
(s/(label+'-matrix.json')).write_text(json.dumps(matrix,indent=2)+'\n')
print(json.dumps({'targets':len(matrix),'failed':[r['target']for r in matrix if r['exit_code']],'retained':sum('retained_exact_binary_run'in r for r in matrix)}))
assert all(r['exit_code']==0 for r in matrix)
