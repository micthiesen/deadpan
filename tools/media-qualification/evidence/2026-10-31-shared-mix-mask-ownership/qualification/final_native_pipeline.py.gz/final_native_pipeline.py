from pathlib import Path
import subprocess
s=Path(__file__).resolve().parent
for variant in ['main','scoped']:
 subprocess.run(['python',str(s/'pin.py'),'shared-mix-build3-'+variant],check=True)
for variant in ['main','scoped']:
 subprocess.run(['python',str(s/'run_matrix.py'),'shared-mix-build3-'+variant,variant,'shared-mix-matrix-'+variant],check=True)
subprocess.run(['python',str(s/'summarize_matrix.py')],check=True)
subprocess.run(['python',str(s/'run_captures.py'),'shared-mix-build3','shared-mix-final3'],check=True)
subprocess.run(['python',str(s/'analyze_final_capture.py'),'shared-mix-final3','final3-capture-analysis.json'],check=True)
