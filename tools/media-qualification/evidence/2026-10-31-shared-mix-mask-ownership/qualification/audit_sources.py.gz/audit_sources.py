from pathlib import Path
import hashlib,json,difflib
s=Path(__file__).resolve().parent
owned=set(json.loads((s/'owned-code-paths.json').read_text()))
roots={'main':Path('/Users/michael/Code/deadpan'),'scoped':Path('/tmp/deadpan-query-groundwork-2026-10-26/scoped')}
result={}
for variant,root in roots.items():
 initial=json.loads((s/f'{variant}-initial-authority.json').read_text());unchanged={}
 for rel,h in initial.items():
  if rel in owned:continue
  data=(root/rel).read_bytes();assert {'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}==h,rel
  unchanged[rel]=h
 result[variant]={'initial_named_inputs':len(initial),'unowned_inputs_exact':len(unchanged),'unowned_manifest_sha256':hashlib.sha256((json.dumps(unchanged,sort_keys=True,separators=(',',':'))+'\n').encode()).hexdigest()}
 for pin in json.loads((s/'immutable-oracle-pins.json').read_text()):
  assert hashlib.sha256((root/pin['path']).read_bytes()).hexdigest()==pin['sha256'],pin['path']
rows=[];rebased=[]
for rel in sorted(owned):
 a=(roots['main']/rel).read_bytes();b=(roots['scoped']/rel).read_bytes()
 before_a=s/'before/main'/rel;before_b=s/'before/scoped'/rel
 if a!=b:
  assert before_a.exists() and before_b.exists(),rel
  old=before_b.read_text().splitlines(True);main=before_a.read_text().splitlines(True);new=b.decode().splitlines(True)
  maps=difflib.SequenceMatcher(a=old,b=main,autojunk=False).get_matching_blocks();patches=[]
  for kind,i,j,k,l in difflib.SequenceMatcher(a=old,b=new,autojunk=False).get_opcodes():
   if kind=='equal':continue
   blocks=[m for m in maps if m.a<=i and j<=m.a+m.size and(m.size or i==len(old))]
   assert blocks,(rel,kind,i,j)
   m=blocks[0];mi=i+m.b-m.a;mj=j+m.b-m.a;assert main[mi:mj]==old[i:j]
   patches.append((mi,mj,new[k:l]))
  for i,j,replacement in reversed(patches):main[i:j]=replacement
  assert ''.join(main).encode()==a,rel
  rebased.append({'path':rel,'exact_scope_patch_rebased_on_unchanged_line_regions_matches_main':True,'patches':len(patches),'before_main_sha256':hashlib.sha256(before_a.read_bytes()).hexdigest(),'before_scoped_sha256':hashlib.sha256(before_b.read_bytes()).hexdigest()})
 rows.append({'path':rel,'scoped_bytes':len(b),'scoped_sha256':hashlib.sha256(b).hexdigest(),'main_bytes':len(a),'main_sha256':hashlib.sha256(a).hexdigest(),'main_scope_exact':a==b})
result.update({'owned_paths':rows,'inherited_main_differences_preserved':rebased,'shipping_authority':'scoped','immutable_payloads_exact':len(json.loads((s/'immutable-oracle-pins.json').read_text()))})
(s/'final-source-audit.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({v:result[v] for v in roots}))
