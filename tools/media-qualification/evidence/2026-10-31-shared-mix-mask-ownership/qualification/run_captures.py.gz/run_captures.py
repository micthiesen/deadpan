from pathlib import Path
import subprocess,sys
s=Path(__file__).parent
build_prefix=sys.argv[1]
output_prefix=sys.argv[2]if len(sys.argv)>2 else 'shared-mix-final3'
for mode,name in [('old','before-off'),('intervals','before-interval'),('policy','before-policy'),('root','before-root'),('shared','active'),('shared','active2'),('shared','active3')]:
 for variant in ['main','scoped']:
  subprocess.run(['python',str(s/'capture_after.py'),variant,build_prefix+'-'+variant,mode,output_prefix+'-'+name+'-'+variant],check=True)
