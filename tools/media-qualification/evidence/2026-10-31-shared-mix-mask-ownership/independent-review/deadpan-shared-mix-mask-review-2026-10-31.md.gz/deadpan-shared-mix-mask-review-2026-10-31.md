# E production candidate review

GO. No actionable correctness or accounting finding in the reviewed production candidate or optional test adaptations. This is static review, not compilation or native qualification. Parent-owned flag/capture glue, runtime overlap/failure evidence and before33 replay remain required.

Reviewed:

- candidate.patch:8,123 bytes, SHA bd8871a6fe8b5b63f538c607b0fdf23415a50a96678cd68d6bc669b5dcf1284f.
- optional-tests.patch:5,566 bytes, SHA bc72788fe5635431d873ecdbea9560eaa584c5955bccfa46647de3e0c6d9db0a.
- README: SHA a8f4607b33a21c0208e3b89c329ca453c0423904fe98f919c3edc4fdadc3f70e.

All36 candidate-manifest entries match; all4 Scope source pins,6 test source pins and12 dependency pins match current files. Detailed review pins/checks: /tmp/deadpan-shared-mix-mask-review-2026-10-31/{source-pins.json,static-checks.json,ripwire.txt}. Main shared_eq.rs was not used as source authority or copied.

## Funding and disposal

The real source reservation remains frames*12 + mix.resident_frames(), admitted before buffers allocate and retained in active_frames. Non-separate verify_prediction returns zero, so it releases none of that reservation. The new finish call is inside the existing read_shared_program result closure, after the equalizer callback and nested-depth check and before its reservation-release tail.

Pending moves the exact final permissions Vec; no bitsets or source buffer are copied. Its inner Result closure borrows that Vec while reserving, filling, boxing and merging the actual destination. On every Result error, target locals are disposed before the inner closure returns. The outer binding then explicitly drops permissions before finish returns. On success the final native mask is the real destination owner and the grid is likewise physically dropped before the caller releases source funding. No grid-bearing WideBlock can escape that tail.

The existing MaskContext reserves through the real controller, including active source frames and existing native-account residency. Existing RangeBuilder/OwnedMask rules retain the complete Vec/future-Box charge and physically dispose Box/Vec before retiring it. E changes none of those rules or any cap/reservation formula.

## Producer semantics

Count and emission scan the same immutable grid. Each count is an actual empty entry, not a merged run or PCM-zero inference. Scan1 is explicitly one bounded bitset check of at most64 words. The positive destination reserves the exact count; push cannot grow beyond it; finish boxes it once; owned merge uses the same Vec.

The original absolute AudioSample start+index, at+1 arithmetic is retained. The sole production caller has already checked start+frames, frames<=MAX_OUTPUT_FRAMES and the grid shape, so moving this projection introduces no reachable arithmetic/validation error. Negative temporal-history starts retain their existing clock.

The entire existing numeric finish prefix, including separate-Components delegation, bus order, transfer/equalizer work and callbacks, is literal. New count/admission/cancellation/merge failures occur only after the old numeric/depth failures. All-permitted input performs count work and returns the empty default without creating a destination account/payload; prior upstream D account activity remains independent.

The pre-E non-separate iterator/enumerate/filter_map/collect body is literal modulo its new conditional-block indentation. The legacy arm retains the same merged_suppression call, wrapped Ordinary. Ordinary finish adds no check, work, allocation or merge. With correct independent E-only flag glue, this preserves the D before33 lane without disabling D/C.

## Complete carrier/cache check

WideBlock now carries AudioSuppressionMask directly into read_shared_input::extend. This removes the old Plain rewrap and invokes the genuine owned replacement path while sources remain alive. Final owned merge retains capacity/charge; no detach or unadmitted intermediate mask is introduced.

The only shared_eq cached tile constructor and all four event_returns constructors remain empty defaults. EventOutput.returned and cached Arc sharing keep the same ownership behavior; no deep mask clone or suppressed mutation was found. Nested shared_eq_tile reads consume PCM/dependencies and dispose temporary masks naturally. This is distinct from authored_eq::WideBlock, which is untouched.

These cached WideBlocks have no range payload debit to subtract: their existing resident calculations count PCM and their masks remain empty. No cache-capacity expression or retirement count changes. The existing Vec-sized opaque-mask representation supports the shallow-layout argument; parent should still retain its qualified WideBlock size/alignment/legacy metadata check. This review does not invent a new cache reservation.

## Optional adapters

All six adapted test files exercise Components directly or explicitly construct SharedMix with separate=true. The other direct SharedMix users in completion/processing/flattened tests also select the separate path; the latter do not inspect the changed MixedBlock field.

ordinary_for_test borrows a slice and panics on Pending rather than silently converting or bypassing it. Its adapted assertions preserve old range values/order, work, callbacks and existing capacity checks. cached_policy locally moves only the already Ordinary Vec into its unchanged fixture result type. No owned extraction or extra copy is added. No existing non-separate assertion was rerouted through this accessor or forced into legacy by these optional patches.

## Qualification boundary

The patches require the documented parent-owned cfg(test) shared_mix_mask_request declaration/selector and independent legacy/capture chaining. No claim is made about unreviewed glue or an executable built without it.

Still owed: real reached-producer positive/zero/refusal cases, source-grid pointer/capacity and uninterrupted active-frame observations, destination pointer through finish/merge, disposal before source retirement, final output/account lifetimes, actual layout and complete frozen-body replay. Ordinary Components outputs, projected tape/Plan policy, exhausted storage, PCM/dependencies and whole preparation remain outside E.

D publication6458e9b and E-before33 are parent-supplied checkpoint context; this review does not substitute older84f evidence or preliminary D evidence for the new before authority. No shared source edits, build, native command or Git operation was performed.
