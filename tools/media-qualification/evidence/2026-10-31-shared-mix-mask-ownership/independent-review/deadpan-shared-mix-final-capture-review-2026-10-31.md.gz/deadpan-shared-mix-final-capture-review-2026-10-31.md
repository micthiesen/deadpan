# E SharedMix producer receipt audit

**Verdict:** Producer-local capture is internally consistent for the claimed non-separate SharedMix mask path. The active canonical body is byte-identical across Main/Scope and across all three active captures: 35,593,716 bytes, SHA-256 `9d6f3c67d9d611f46e75360006845a1b9419b30168a983db1ca9e4cf79c8be0a`.

## Evidence checked

- Inputs: `shared-mix-final3-active-{main,scoped}-canonical.json`, `active2-{main,scoped}-canonical.json`, `active3-{main,scoped}-canonical.json`.
- All eight E-before historical bodies are unchanged and identical across roots: before-off `af7a2927…bff14`, before-interval `f64d3a00…b5a53`, before-policy `afa6038a…7414e`, before-root `596d738a…1f44a`. No E producer trace field appears in these bodies.
- Active snapshots contain 758 producer-observer receipts. Every snapshot is enabled, finished (`unfinished=false`, `active_row=null`) and untruncated. Nine producer rows have content, all in internal cases `aggregate-514-shared-equalizers`, `aggregate-514-shared-input`, and `held-public-mask-then-aggregate`; each case has three rows. All other snapshots are valid empty traces.
- Each positive source grid is 256, 256, then 2 entries. Its recorded Vec capacity equals its length; each `Permissions` element is 512 bytes. The source disposal receipt preserves the captured pointer/length/capacity metadata.
- The source reservation remains reflected in `active_frames` at producer entry, both sides of the real destination reserve, and after the source Vec is dropped but before the outer reservation tail. Every positive destination reserve succeeds. The destination builder capacity matches the returned mask capacity, the final mask is owned, its pointer matches the builder allocation, and the source and destination allocation pointers differ.
- Work deltas reconcile per row: total plan-plus-cache work change equals accepted native phase units plus the measured work-counter delta around the actual reserve, subtracting any Account phase already counted in that reserve. All emitted rows have no failed phase calls. Native work epoch is stable without overflow; host boundary receipts report no overflow.
- The 744 serialized current outputs match the pre-E, post-D current outputs exactly, including literal status, samples, dependencies, masks, capacities, and errors. Thirty captured internal `result_*` fields also match. This is output parity evidence, not a claim that every account or temporary allocation stays identical.
- Lifetime witnesses show the added 519-frame payload remains charged after renderer/controller drop while the returned result lives: aggregate cases go from 3 shell frames before E to 522, then return to 3 after result drop. The held-public-mask aggregate goes from its prior 10 to 529, then returns to 10 after the internal result drops.

## Limits

The complete captured body has no zero-emission or partial-work-failure producer rows. Those are separate actual native assertion tests, not serialized row evidence. The captures also do not prove destination-admission refusal or attribute whole-case native operations to individual nested calls. The positive rows establish the ownership/reservation sequence only for non-separate SharedMix permission-grid projection into an AudioSample mask and its observed chunk receiver. They do not support whole-preparation resource claims or claims about other mask producers.

## Pins

- Published D checkpoint: `6458e9b989172147e0844fcb251c89ce8c479aaf`.
- Frozen E-before fixture: `tests/fixtures/shared-mix-mask-baseline-v1/snapshot.json`, SHA-256 `596d738a53f6ef4cbf7870d74b3025504f6289f735ea91f4a38ed45c6661f44a`.
- Active Scope source manifest: SHA-256 `6788915cb1b46ed6c9f55affa6d7e4af75c64156d5cc3f3eeb03e0c63f38eb87`; active Main inherited manifest: `6d4212f3d4229af54ac6f0e43d2e4b6d2b8380fc786972299099d088c60b943c`.
- Active binaries: Main `b045f256fba79e58cb52b9493f881aa5ea9ae70359ee141e1efc4db5c1464802`; Scope `72dae8e94b6d7fcce4396d8c11d6fe781ac7b77ae0d2052ab20a3aed95a15f39`.
- Scope source hashes from the active manifest: `shared_mix_mask_trace.rs` `4e4f407d747fc2fccf2a24a44759133913d238c4a559c6723186153f6514c2d5`; `shared_mix.rs` `6febdc603d938135b80ab044d5a35b5d782e0f9feea7ccb117c852a2663fb946`; `shared_eq.rs` `cb4debedc5e8557a2bd4a20beb25fc551f0ab2837f1344ebb5f3315a8b385220`; `mask_context.rs` `c8e05749f68842aa43d0a77bceeb2427a32f5ff8d2ac8650f43c6e13831f7a20`; `point_suppression/ops.rs` `688f1f18689d9f59f3459b06a2ab0229113fda8d63e602cb662759bb4d5f24be`; `point_suppression.rs` `ea7c967d2e6a9d19e60901fbdfcd6849e0b4450aba441fc2b156c05b6ea6ffd1`; `stages.rs` `285aadc9273d4e8dd799a4b4e835d5926c1397d550f61e622bc957d86e2aab69`.
- Analysis script: `analyze_shared_mix_producers.py`; generated summary: `analysis.json`.
