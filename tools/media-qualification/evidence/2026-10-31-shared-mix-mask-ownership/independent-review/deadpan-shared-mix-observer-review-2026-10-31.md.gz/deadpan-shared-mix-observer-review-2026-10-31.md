# Integrated E observer/native-test review

GO. No remaining actionable observer or test-source finding. This reviews current integrated Scope source only, separately from production-candidate GO b5875026.... No source edit, build, native execution or Git operation was performed.

Exact current sources: /tmp/deadpan-shared-mix-observer-review-2026-10-31/source-pins.json. Main inherited WIP was not used as authority or copied.

## Truth and lifetime

- The caller obtains PendingSource from the actual pending Vec, passing the actual current reservation, active_frames, account reading and WorkControl immediately before finish. These are observations of the real controller; no lease, frame counter or source charge is reconstructed or mutated.
- The source grid remains in the real read_shared_program reservation. The destination pointer/capacity is read from the allocated RangeBuilder while the grid is alive. Finish/merge returns that same Vec; only pointer-equality/distinctness booleans are serialized. Raw pointer integers stay private in Row and are never serialized by snapshot.
- The explicit source_disposed marker runs after drop(permissions). The caller completes the row for both Ok and Err before projection? can leave the result closure and before the reservation-release tail. Failure target locals have already dropped. The resulting active_frames observation intentionally still includes source funding; it is not a claimed dedicated source lease.
- No recursive projection can begin inside this closed projection operation: equalizer callbacks have finished, and reservation/count/emission/merge invoke no SharedMix callback. The single-current-row observer matches the real caller protocol. New rows do not claim to measure all nested numerical work.

## Work and default-off behavior

The central spend_work hook invokes control.spend_plan_work exactly once, records that actual Result, then preserves the existing accepted native/interval hooks. Refusal does not acquire a second debit. Observer functions only read WorkControl counters/account atomics and mutate their separate test-only state.

Reserve before/after hooks bracket the actual reserve_mask_storage call. Thus their work deltas include account work, native host-residency reads and any real host eviction, rather than estimating the reserve from vector fees. The measured partial-prefix test includes both actual lane deltas in that reserve plus the actual allocation and one scan/push.

When disabled, begin/work/destination/disposal/complete return before observer-state or ReadWork borrows/allocations. Reserve hooks short-circuit recording before those borrows/JSON allocations as well. Their evaluated scalar/atomic arguments are observations, not ledger operations. The production build removes all these hooks.

Rows are bounded at128 and events at64, with explicit truncation flags. Snapshot also exposes unfinished/current-row state. A bounded observation is not evidence for omitted rows; final capture analysis must reject these flags when claiming complete producer coverage.

E capture alone enables PROJECTIONS and adds shared_mix_mask_producers. Reset occurs at each of744 operations and each10+4 internal/transfer cases. D/before33 replay selects E legacy with projection tracing off, so no new JSON field or reset is added there. Capture cleanup disables tracing. Existing receipts, native counters and invalid flags remain independent.

## Meaningful tests

The three native tests use checked real documents, actual prepared WAV/provider data and actual read_shared_input, not a manufactured Pending mask, private Bound or ticket:

- The514 alternating Hold/Source case compares complete PCM bits, ranges/capacity, dependencies, depth and exhausted data against E-only legacy. It verifies real256/256/2 rows, source identity/funding at actual reserve, destination identity through merge, explicit source disposal, final output charge after controller disposal and payload release when that result drops.
- Source-only64 reaches the selected producer and proves zero output with no destination storage/reservation. It does not infer permissions from zero PCM or assume upstream D never initializes an account.
- The failure case measures a real successful first producer, then seeds only the work budget on a fresh controller. Its actual count/reserve/allocation/one-emission prefix must reach accepted admission and a later Scan refusal. No residency/account/source ledger is fabricated. It observes partial cleanup to the actual account shell.

The pre-E WideBlock layout fixture reconstructs the exact four old field types and compares actual size/alignment with the new private type. It is a real shallow-layout check, not a new cache-capacity formula.

Three initially missing assertions were reported and are now present: sound_context_frames==0 immediately after every helper request; no unfinished/current row or truncation in active_mask_rows for all three paths; and Some account required after the partial case's accepted destination. No current test-source gap remains from those findings.

## Evidence limits

Parent reports build2 passed the three native tests and layout test in both roots. The stronger assertions were added afterward; build3 is in progress. This static review does not certify that later build/run, final captures, before33 replay or the full matrix. Producer-local receipts must remain separate from whole-invocation and inclusive query-interval accounting.

Separate Components masks, projected PreserveTape/Plan masks, exhausted storage, PCM/dependencies and whole preparation remain outside E ownership. This review awards no product or Gate credit.
