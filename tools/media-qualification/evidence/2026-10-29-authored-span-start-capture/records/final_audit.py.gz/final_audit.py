from pathlib import Path
import hashlib,json,re
s=Path(__file__).resolve().parent
main=Path("/Users/michael/Code/deadpan");scope=Path("/tmp/deadpan-query-groundwork-2026-10-26/scoped")
sha=lambda b:hashlib.sha256(b).hexdigest()
negative={"span-plan-lib1":101,"span-stages":101}
receipts=[]
for p in sorted(s.glob("*.json")):
 r=json.loads(p.read_text())
 if not isinstance(r,dict)or "started_at"not in r or "command"not in r:continue
 assert r.get("exit_code")==negative.get(p.stem,0),(p.stem,r.get("exit_code"))
 assert r["sources_unchanged"]and r["binaries_unchanged"],p.stem
 for name,h in r["streams"].items():
  data=Path(name).read_bytes();assert len(data)==h["bytes"]and sha(data)==h["sha256"]
 receipts.append({"label":p.stem,"exit_code":r["exit_code"],"seconds":r["seconds"],"sha256":sha(p.read_bytes()),"source_inputs":len(r["source_before"])})
final=["span-strict2","span-plan-build2","span-plan-main","span-scoped-build1","span-plan-scoped","span-scoped-audio","span-stages","span-scoped-stages","span-definition","span-scoped-birth","span-doctests"]
for label in final:
 r=json.loads((s/(label+".json")).read_text())
 for name,h in r["source_after"].items():
  data=Path(name).read_bytes();assert len(data)==h["bytes"]and sha(data)==h["sha256"],(label,name)
rows=json.loads((s/"task-source-pins.json").read_text());raw=(s/"index-blobs.bin").read_bytes();offset=0;equality=[]
for row in rows:
 end=raw.index(b"\n",offset);header=raw[offset:end].decode().split();assert header[1]=="blob"
 n=int(header[2]);data=raw[end+1:end+1+n];offset=end+2+n
 assert data==(scope/row["path"]).read_bytes()and sha(data)==row["sha256"]
 if row["path"]!="crates/deadpan-plan/src/plan.rs":assert data==(main/row["path"]).read_bytes()
 equality.append({"path":row["path"],"blob":header[0],"sha256":row["sha256"],"scoped_index_equal":True,"main_equal":data==(main/row["path"]).read_bytes()})
assert offset==len(raw)and len(rows)==18 and sum(row["main_equal"]for row in equality)==17
(s/"index-source-equality.json").write_text(json.dumps(equality,indent=2)+"\n")
owned={r["path"]for r in rows};unchanged={}
for variant,root in [("main",main),("scoped",scope)]:
 initial=json.loads((s/(variant+"-initial-authority.json")).read_text());count=0
 for name,h in initial.items():
  if name in owned:continue
  assert sha((root/name).read_bytes())==h,(variant,name)
  count+=1
 unchanged[variant]=count
assert unchanged=={"main":1488,"scoped":1259}
for row in json.loads((s/"immutable-oracle-pins.json").read_text()):
 for root in [main,scope]:assert sha((root/row["path"]).read_bytes())==row["sha256"]
for names in [("span-old-main-snapshot.json","span-old-scoped-snapshot.json"),("span-old-cost-main-snapshot.json","span-old-cost-scoped-snapshot.json")]:
 a,b=[json.loads((s/name).read_text())for name in names]
 for obj in [a,b]:
  for key in ["variant","source_sha256"]:obj.pop(key)
 assert a==b
tests={}
for label,count in {"span-audio1":372,"span-scoped-audio":353,"span-scoped-stages":203,"span-definition":171,"span-scoped-birth":8}.items():
 matches=re.findall(r"test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;",(s/(label+".stdout")).read_text())
 assert len(matches)==1 and int(matches[0][0])==count and int(matches[0][1])==0,(label,matches)
 tests[label]={"passed":count,"ignored":int(matches[0][2]),"seconds":json.loads((s/(label+".json")).read_text())["seconds"]}
plan=[]
for label,count in [("span-plan-build2",635),("span-scoped-build1",622)]:
 rr=json.loads((s/"plan-results"/label/"results.json").read_text());assert len(rr)==29 and all(r["exit_code"]==0 for r in rr)
 passed=sum(int(m[1])for r in rr for m in r["test_results"]);ignored=sum(int(m[3])for r in rr for m in r["test_results"])
 assert passed==count and ignored==8
 plan.append({"build":label,"targets":29,"passed":passed,"ignored":ignored})
stage=(s/"span-stages.stdout").read_text()
split=re.findall(r"^test (general_split_sound::[\w:]+) \.\.\. (ok|FAILED|ignored)",stage,re.M)
ordinary=re.findall(r"^test ((?!general_split_sound::)[\w:]+) \.\.\. (ok|FAILED|ignored)",stage,re.M)
assert len(split)==7 and sum(v=="FAILED"for _,v in split)==4 and sum(v=="ok"for _,v in split)==3
assert len(ordinary)==203 and all(v=="ok"for _,v in ordinary),(len(ordinary),[r for r in ordinary if r[1]!="ok"])
reuse=json.loads((s/"main-native-source-reuse.json").read_text());assert reuse["production_source_inputs_current"]
preserve=json.loads((s/"source-preservation-preaudit.json").read_text());assert preserve["plan_export_only_in_both_variants"]and preserve["main_inherited_plan_preserved"]
result={"all_terminal":True,"receipts":receipts,"negative_results_retained":negative,"source_files":18,"rust_files":15,"all_scoped_index_equal":True,"seventeen_main_files_equal_with_plan_export_delta_equal_over_preserved_distinct_baselines":True,"other_initial_inputs_unchanged":unchanged,"production_compiled_sources_current":True,"tests":tests,"plan":plan,"immutable_oracles_unchanged":10,"old_span_and_metered_point_matrices_literal_cross_variant_equal":True,"main_native_source_reuse":reuse,"split_and_ordinary":{"ordinary_passed":203,"split_passed":3,"split_failed":4,"cases":split,"seconds":json.loads((s/"span-stages.json").read_text())["seconds"]},"scoped_patch_sha256":sha((s/"task-scoped.patch").read_bytes())}
(s/"final-audit.json").write_text(json.dumps(result,indent=2)+"\n")
print(json.dumps({k:v for k,v in result.items()if k not in ["receipts","main_native_source_reuse"]}))
