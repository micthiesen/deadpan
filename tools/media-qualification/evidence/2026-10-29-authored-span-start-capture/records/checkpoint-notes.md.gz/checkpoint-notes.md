# Active START capture checkpoint, incomplete

Base main: 810b2b739222b2f175e1e73ef9addb5944decba2.
Scope: only actual Authored Root/physical Domain successful wide span START captures.
General sound-bearing Split remains disabled; no requirement or gate closes.

Independent old query/input fixture: snapshot.json, 1555568 bytes,
SHA256 9ca2248a54ddff226da794e243e019ba609d8d7695f0c8a1042205f3c9d52181.
14 physical parents, 27 active START spans, 73 actual direct captures,
51 full output/events crosschecks with direct258, 3 inactive and 1 ownerless.
All 27 complete ordered private clock vectors equal separately observed
point query first spans including support/silence; no duplicate observed,
which is not a uniqueness proof.

Independent metered old point-Q annex: metered-point-costs.json, 301212 bytes,
SHA256 ab4d26227514ea952190d6e4893fb537dead27814e0b78a5635a902686430099.
Both variants matched completely except variant/source_sha256.
Real finite 1 MiB Layout cap, default finite work cap. One actual old
admitted point query per parent/span START, no Input captures. Records full
private query facts, forwarded canonical/additional work and RAII memory ledgers.

Design GO_WITH_CHANGES after restriction/budget review. False-mode additional
selection cost is zero. Shared Qwide attribution is not summable per-node cost.
Input layout stays unchanged; its new work is only actual new selection/capture.
Keep direct APIs and incoming Retained behavior unchanged.
