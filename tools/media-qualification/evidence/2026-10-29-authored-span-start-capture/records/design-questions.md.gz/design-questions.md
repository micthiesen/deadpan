# Before any production change

Base810b2b739. Full goal active; GeneralSplit disabled3pass4work failures. Preserve all WIP and caps/priorweights/refunds/coldactivation. Parent sole Cargo/native/Git; bothsourcevariants and guarded runs required.

Prefer new sealed Root/Domain span-start input-candidate factory, leaving existing public direct APIs unchanged. Retained incoming no-query path unchanged. Existing actual wide query remains live; no extra Arc/owner clone merely for handoff.

Resolve:
1 Exact restriction proof at span start, full private fields/order and same physical seed; handle first same_at duplicates by real scan, no assumed uniqueness. Skip inactive before selection. At should be derived from actual span start, or explicitly checked equal; no arbitrary interior At promise.
2 Parent identity: a certificate issued from Domain B must never be accepted as Context A merely because same plan/key. Factory owns immutable actual parent borrow. Audio must preserve/check actual incoming parent pairing; no arbitrary query+parent constructor.
3 Work: Qwide already billed once by renderer. Qpoint actually removed by certificate, not hidden. Selection/C remain actual new work. Decide truthful source Input.work and receipt type with shared-Q provenance, no per-node Qwide rebilling, and explicit local C limits vs global remaining. Current QueryLimits may cap local work below global remaining, so mechanically subtracting entire Qwide for every C can falsely shrink budget.
4 Ordering: cache hits and count limit before capture metadata, context then EQ recipe then boundary, no changed existing direct-API validation. New capability invalid/foreign/mode/issuer cases explicit.
5 Lifetime/peak: actual Q guard through C and independent source Input through final probe/sharing; source values before leases; no naked extraction. New metadata/certificate should borrow stack data where possible; account any actual heap copies.
6 Frozen OLD differential producer bothvariants before production; old whole private serializers reused, no new self-consistency oracle. New tests prove removed actual query work and semantic equivalence/resource refusal, no source/PCM changes.

Resolved reviewer conditions:
- Semantic critic accepts with high-confidence caveat: only actual ACTIVE span START, same physical Root/Domain, allow_inactive=true, successful query, and first private same_at match. No valid-document counterexample found; OLD differential execution still required.
- Budget critic requires a correction: Budget::additional does not spend in false mode. Selection S is additional, hence false nominal scan work bills zero. New capture billable units are Ccanonical in false mode, or Ccanonical + Cadditional + S in true mode. Do not bill a nominal S in false mode.
- Keep AudioOwnerInput layout and ordinary APIs unchanged. New receipt carries shared-Q attribution explicitly. Never expose Qwide+Ci as a summable unique-request cost across multiple captures. Input.work for the new path is only actual new S+C according to existing mode accounting; ordinary direct Input.work stays Qpoint+S+C.
- Capture walker currently calls its prior-work argument query_work. For a certified capture that prior work is only already-performed selection S (zero false), not Qwide. Receipt must check Input.work == actual canonical+additional new units. Any private naming cleanup must not change old direct orchestration.
