from pathlib import Path
import hashlib,json,os,subprocess,sys
s=Path(__file__).resolve().parent
label,build,variant=sys.argv[1:];assert variant in ['main','scoped']
root=Path('/Users/michael/Code/deadpan')if variant=='main'else Path('/tmp/deadpan-query-groundwork-2026-10-26/scoped')
paths=json.loads((s/('source-files.json'if variant=='main'else'scoped-source-files.json')).read_text())
manifest={n:{'bytes':(root/n).stat().st_size,'sha256':hashlib.sha256((root/n).read_bytes()).hexdigest()}for n in paths}
p=s/(label+'-source-manifest.json')
with p.open('x')as f:f.write(json.dumps(manifest,indent=2)+'\n')
binary=next(r['path']for r in json.loads((s/(build+'-pins.json')).read_text())if r['package']=='plan'and r['name']=='deadpan_plan')
env=os.environ.copy();env.update({'DEADPAN_SPAN_START_OUTPUT':str(s/(label+'-snapshot.json')),'DEADPAN_SPAN_START_VARIANT':'main-inherited'if variant=='main'else'scoped-published','DEADPAN_SPAN_START_SOURCE_SHA256':hashlib.sha256(p.read_bytes()).hexdigest()})
runner='run_qualified.py'if variant=='main'else'run_scoped_qualified.py'
raise SystemExit(subprocess.run(['python',str(s/runner),'--binary',binary,label,'--',binary,'capture_old_span_start_input_baseline_v1','--ignored','--nocapture','--test-threads=1'],env=env).returncode)
