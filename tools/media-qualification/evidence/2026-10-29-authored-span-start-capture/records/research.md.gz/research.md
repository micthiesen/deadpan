# Read-only finding from wide_capture_certificate_research

Conditionally viable only for Authored Root/Domain span START. Existing wide query alone lacks physical parent/original limits and isn't a capture certificate. Do not remove membership merely from overlap.

Actual read_eq_program selects a member from a guarded query span and calls eq_node at span.samples().start. Root/Domain wide gain queries and one-sample candidates invoke query_tracked with the same physical seed, retained=None and allow_inactive=true. query_tracked restarts seed.copy at each span cursor; requested end caps output.end and map_owner anchors its affine map at cursor. This is the restriction-proof seam, not permission for arbitrary interior at.

Need exact first same_at match including plan/definition/instance/kind/gap/play/origin/affine sampling and order. matches_treatment_owner omits play/sampling. Domain factory must preserve actual seed (bypass/grid/extents/envelope/repeats/definition); root requery fails on hidden support. Retained-origin members inside Root/Domain still use original Root/Domain capture walk. Inactive spans can retain outer owners before exhausted/empty support; Authored currently skips them before EQ selection, preserve that. Incoming Context::Retained retains same Arc with no input-membership query, unchanged. Shared EQ coarse-key/sound fallback is out of scope.

New sealed factory must couple actual Root/Domain parent and query from CONSTRUCTION; no constructor from arbitrary query+parent. Actual lease stays alive through capture. Validate issuer/accounting mode and exact caller Context parent identity, not merely plan identity. Cache hits/owner-count check stay before new capture metadata. Reuse capture_in_parent/capture_observed_admitted; never reconstruct hidden provider/play fields in Audio.

Work receipts are unresolved design requirement: existing direct source input.work includes Qpoint+selection+C; new shared Qwide must not be silently omitted, rebilled per node or represented as old Qpoint. Specify shared query provenance and per-capture work/limits explicitly, including local query cap vs remaining global budget. Global caps, prior weights and no refunds unchanged. Old direct API behavior/error order unchanged. New API may support only active span starts; no generic interior containment shortcut.

Need bounded differential OLD observations and restriction proof: full wide member/vector vs current one-sample first private same_at member at span start, full captured Input/seed/slot, downstream probe/sharing/boundary and PCM. Root/physicalDomain, phase/retained/exhausted/repeat/default-gap edge cases, duplicate first-match ordering (scan to first same_at if needed), short/exact work+memory, every callback refusal/cancel/issuer rotation and cleanup. Existing frozen wide14/direct258/nativeNode13/tile7 fixtures support but do not alone prove a new certificate.

No source changes or tests by explorer.
