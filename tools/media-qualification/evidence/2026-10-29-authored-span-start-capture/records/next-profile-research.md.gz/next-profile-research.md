# Measure the next Split work failure

Read-only research. No Cargo, native execution, Git writes or repository edits.

## Preferred first measurement

Profile exactly:
general_split_sound::one_explicit_play_split_keeps_both_selected_and_other_plays_in_the_shared_sound_bus

Use the current inherited Main source, including its existing general_split_sound test and sound-clock WIP, in a separate diagnostic filesystem copy owned by the parent. Do not change or temporarily roll back the shared checkout. The isolated published copy lacks this inherited test/behavior and is not a substitute for this witness.

After one optimized build of the stages integration target in that diagnostic copy, run only the pinned target with:
--exact general_split_sound::one_explicit_play_split_keeps_both_selected_and_other_plays_in_the_shared_sound_bus --nocapture --test-threads=1

This test is the smallest existing selected-play witness, with one explicit fixture rather than the all-owner test's 15 shape/parent combinations. The historical October 26 exact-filter run took 15.99 seconds; that timing and its cost distribution are historical, not a current measurement. The parent has now completed the fresh 530.31-second combined run: 203 ordinary tests plus seven Split cases, 206 pass/four fail. The exact selected-play failure is now Stage(Plan(Document LimitExceeded: audio binding work exhausted)) at prefix-two limited 0+4096. Nested selected play is Stage(Plan(Document LimitExceeded: frozen projection work exhausted)) at root_sound=false prefix-two limited 0+4096. Source/Sequence cut-three limited 0+511 and processed root-sound-refinement limited 0+511 still report global plan work per read. This is not a timing improvement claim. The first profile must therefore include Core local budgets and their error-time counters, not just the shared WorkControl cap.

## Existing diagnostic that can be adapted

/tmp/deadpan-constant-block-2026-10-26/trace-install.patch
/tmp/deadpan-constant-block-2026-10-26/stages-with-trace.rs
/tmp/deadpan-constant-block-2026-10-26/selected-work-trace.json
/tmp/deadpan-constant-block-2026-10-26/selected-work-trace.stdout
/tmp/deadpan-constant-block-2026-10-26/selected-work-trace.stderr

That scratch patch added track_caller to WorkControl::spend_plan_work, keyed TLS tables by ledger address/cachelane/deadline, and printed ranked caller totals near exhaustion. Its recorded command already uses the exact filter above.

Do not copy that patch unchanged:
- It adds attempted amount to its site total before checking whether the global charge succeeds. Thus its sums are attempted, not strictly accepted, work.
- Its BTreeMap/Vec diagnostic allocations and table resets do not give a clean bounded trace.
- Current metered Plan/Core calls converge on sound_context_admission::Admission::spend, so WorkControl caller alone collapses much of the newly admitted work into that adapter.
- An address/deadline heuristic is weaker than owning the trace with the actual request ledger.

No such full work-by-site trace remains in current source. The existing authored_eq/span_start.rs CaptureTrace and tile_index.rs with_fee_trace are cfg(test) unit-test helpers for narrow actual point-query/index fees. They do not profile the complete integration request.

## Exact current seams

crates/deadpan-audio/src/stages.rs:
- ReadWork, around line 461: one request's authoritative canonical and cache work counters.
- PreparationBudget::control and WorkControl, around lines 526-541: all nested preparation shares this ledger/deadline.
- WorkControl::spend_plan_work, line 555: checks cancellation/deadline, picks canonical or cache lane, checked-adds amount under MAX_PLAN_WORK_PER_READ (16*1024*1024), then commits.
- WorkControl::query_limits, line 577: default local work cap reduced to remaining global allowance.

crates/deadpan-audio/src/sound_context_admission.rs:
- Admission::new, line 151: a useful place to retain a diagnostic-only construction callsite/category on the actual adapter.
- Admission::spend, line 168: forwards actual charges to WorkControl::spend_plan_work.

crates/deadpan-plan/src/audio_owner_query_admission.rs:
- Budget::canonical, line 170: local charge/canonical tally, then forwards only when METERED.
- Budget::additional, line 184: zero in false mode; local/additional tally and forward in true mode.
- Budget::account_core, line 198: accounts an ALREADY FORWARDED Core receipt locally; counting it as fresh global work would duplicate charges.
- CoreAdmission::spend, line 77: another forwarding adapter.

crates/deadpan-core/src/audio_binding/admission.rs:
- Build::spend, line 273; Build::additional, line 283: canonical/additional Core attribution before policy forwarding.
- account_child consumes an already forwarded child receipt; never count it again as new global work.

crates/deadpan-plan/src/audio_policy.rs:
- PolicyWork::spend, line 43, and limits, line 50: local recursive-policy exhaustion can precede an outer global charge.

crates/deadpan-plan/src/audio_owner_occurrences.rs:
- owner_occurrences ancestry loop, lines 143-153: returns owner occurrence ancestry when ancestry length reaches the supplied local maximum_work or document depth. Record the supplied cap, ancestry count and global remaining at this failure. These are local diagnostic facts, not additional global charges.

## Bounded trace design

For the first pass, preserve every existing charge expression, cap, result, deadline and error. Add trace state only in the diagnostic copy, or use an explicit disabled-by-default diagnostic feature. A plain cfg(test) hook in deadpan-audio will NOT reach this integration test: Cargo compiles the library dependency without cfg(test). A cfg(test) reproduction would require a separate unit fixture; prefer the existing exact integration witness to avoid changing the reproduction.

Own a fixed-size trace with ReadWork, so identity, lifetime and reset are the actual preparation request's identity, lifetime and reset. Keep separate canonical and cache lanes. Store fixed open-addressed slots keyed by static file/line/column plus an optional coarse adapter category; each slot has accepted_calls and accepted_units. A 512-slot table with explicit overflow_calls/overflow_units is bounded and avoids per-charge allocations. Do not print, format backtraces, create strings or sort during a charge. Capture one rejected attempt separately from accepted totals.

Record accepted work ONLY after the original checked-add and assignment succeed. If the charge is refused, record a rejected-attempt diagnostic without adding units/calls to the accepted sum. If cancellation/deadline refuses before the charge, likewise add no accepted work. Dump once when the preparation request returns an error, after releasing the RefCell borrow. The sums, including overflow, must equal that request's actual plan_work/cache_plan_work counters. Overflow must be zero before interpreting every detailed site as complete. Do not claim wall-clock or allocation improvements from an instrumented run.

Use track_caller for direct Audio calls. For forwarded admission costs, capture the construction callsite once in a diagnostic-only Admission::new field (track_caller), and let Admission::spend attribute its successful forwarded amount to that immutable category. This identifies the actual Audio operation which requested the Plan work without modifying public admission traits. Keep the sum in WorkControl as the one authoritative accepted total; adapter labels are attribution, not a second charge.

If that coarse forwarded category dominates, add a second diagnostic view around Plan Budget canonical/additional and Core Build spend/additional, recording only successful forwarding. Label Core forwarding separately and avoid re-adding account_core/account_child receipts. Correlate operation/request attribution rather than summing this second view with WorkControl. This can distinguish actual canonical traversal from additional admission/copy work without changing either.

For local policy/ancestry errors, emit the error plus local supplied limit/used/remaining and the enclosing request's global counter. Local work refused before normal forwarding stays a separate view; do not silently rebill it.

## Evidence contract

Freeze diagnostic source deltas and source/executable hashes, exact invocation and environment, full stdout/stderr, result and elapsed time. Compare the error/window with the uninstrumented current witness. If tracing changes a work refusal into a timeout, that run is not a valid cost diagnosis; reduce trace overhead and rerun only that witness. Preserve all unchanged numerical output assertions. No current dominant cost is established by this read-only research.

## Required update after the parent's fresh final run

The current selected-play error is a Core local binding failure, so include these probes in the FIRST diagnostic build:

- crates/deadpan-core/src/audio_binding.rs Work::spend, line 548, and Work::remaining, line 559. Preserve their exact behavior: spend currently assigns used = used + count BEFORE checking used > maximum, so on a non-overflow limit failure the raw local used counter includes the refused attempt. Record used_before, attempted, used_after and maximum separately, plus the error/track_caller site. Do not rewrite this to projection-style checked-filter assignment and do not call that refused local increment globally accepted work.
- crates/deadpan-core/src/audio_binding/admission.rs Build::local, line 231, has a distinct projection branch. Its checked-add/filter leaves raw used unchanged on refusal and labels the error frozen projection work exhausted. Record the before/after values as they actually are, projection=true, attempt and maximum.
- crates/deadpan-core/src/audio_reference.rs spend, line 3333, is another frozen-projection exhaustion site. Instrument it too so the same error string identifies the actual code path rather than guessing.
- In Core Build::spend/additional, record successful policy forwarding separately from local raw spending. The local budget is charged before the policy callback; an error may prevent that amount from reaching WorkControl. Core account_child and Plan account_core remain receipt attribution only, not fresh charges.

Give each actual Core Work its own fixed bounded trace in the diagnostic copy, initialized with that local query's maximum and dropped with the Work. Build forks share the same Work, so they must share that trace. Use immutable operation/category identity plus static caller locations. Capture the error-time record immediately at the precise failing local check; dump summaries only after those checks/borrows unwind. Also include the contemporaneous enclosing WorkControl accepted total, remaining global allowance, and last supplied Plan query cap. Keep the local-used and global-forwarded tables separate and reconcile only amounts that actually passed forwarding.

For the selected witness, the diagnostic success condition is the same audio binding work exhausted error and exact prefix-two limited 0+4096 window as the uninstrumented final run, with a complete bounded local binding prefix, the precise refused amount/site, and the shared global prefix. The nested witness can follow using its one exact test filter if the binding profile does not explain the projection case. Do not rerun the full 530-second combined suite for this measurement.
