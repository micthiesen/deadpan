from pathlib import Path
import gzip,hashlib,json
s=Path(__file__).resolve().parent;repo=Path('/Users/michael/Code/deadpan')
dest=repo/'tools/media-qualification/evidence/2026-10-29-authored-dependency-borrow'
assert not dest.exists()
audit=json.loads((s/'final-audit.json').read_text());assert audit['all_terminal']
prior=repo/'tools/media-qualification/evidence/2026-10-29-authored-tile-index/inventory.json'
prior_sha='8992240893ed4f6e189df552717d321da38b5d310b4918f8a887eb561a251d3f'
assert hashlib.sha256(prior.read_bytes()).hexdigest()==prior_sha
rows=[];allowed={'.rs','.json','.py','.md','.patch','.stdout','.stderr','.txt','.sha256'}
for p in sorted(s.rglob('*')):
 if not p.is_file()or p.suffix not in allowed:continue
 data=p.read_bytes()
 if p.suffix=='.json':
  if p.name=='direct-oracle-main-snapshot.json':
   assert data==b''
   obj=None
  else:
   obj=json.loads(data)
  if isinstance(obj,dict)and 'command'in obj and 'started_at'in obj:
   assert 'exit_code'in obj,str(p)
   assert obj['sources_unchanged']and obj['binaries_unchanged'],str(p)
 target=dest/'records'/p.relative_to(s)
 target=target.with_name(target.name+'.gz');target.parent.mkdir(parents=True,exist_ok=True)
 packed=gzip.compress(data,mtime=0);target.write_bytes(packed)
 rows.append({'path':str(target.relative_to(dest)),'bytes':len(packed),'sha256':hashlib.sha256(packed).hexdigest(),'expanded_bytes':len(data),'expanded_sha256':hashlib.sha256(data).hexdigest()})
manifest={'schema_version':1,'base_revision':(s/'base-revision.txt').read_text().strip(),'scope':'Mechanical Authored dependency-map clone removal through borrowed iteration. Same ordered AssetId clones and copied fingerprints; no new allocation bound or speed claim. Main/isolated libraries and full old native matrices pass; prior integration/Split results historical and not rerun. GeneralSplit disabled, no cap/weight/refund/coldactivation changes.','prior_tile_inventory':{'path':'../2026-10-29-authored-tile-index/inventory.json','sha256':prior_sha},'files':rows}
p=dest/'inventory.json';p.write_text(json.dumps(manifest,indent=2)+'\n')
for row in rows:
 packed=(dest/row['path']).read_bytes();plain=gzip.decompress(packed)
 assert len(packed)==row['bytes']and hashlib.sha256(packed).hexdigest()==row['sha256']
 assert len(plain)==row['expanded_bytes']and hashlib.sha256(plain).hexdigest()==row['expanded_sha256']
print(json.dumps({'files':len(rows),'stored_bytes':sum(x['bytes']for x in rows),'expanded_bytes':sum(x['expanded_bytes']for x in rows),'inventory_sha256':hashlib.sha256(p.read_bytes()).hexdigest()}))
