from pathlib import Path
import hashlib,json,re
s=Path(__file__).resolve().parent
roots={'main':Path('/Users/michael/Code/deadpan'),'scoped':Path('/tmp/deadpan-query-groundwork-2026-10-26/scoped')}
sha=lambda b:hashlib.sha256(b).hexdigest()
receipts=[]
for label in ['borrow-strict','borrow-build','borrow-audio','borrow-scoped-build','borrow-scoped-audio']:
 r=json.loads((s/(label+'.json')).read_text())
 assert r['exit_code']==0 and r['sources_unchanged']and r['binaries_unchanged']
 for name,h in r['streams'].items():
  data=Path(name).read_bytes();assert len(data)==h['bytes']and sha(data)==h['sha256']
 for name,h in r['source_after'].items():
  data=Path(name).read_bytes();assert len(data)==h['bytes']and sha(data)==h['sha256']
 receipts.append({'label':label,'seconds':r['seconds'],'sha256':sha((s/(label+'.json')).read_bytes())})
rel='crates/deadpan-audio/src/authored_eq.rs'
data=(roots['main']/rel).read_bytes();assert data==(roots['scoped']/rel).read_bytes()
raw=(s/'index-blobs.bin').read_bytes();end=raw.index(b'\n');head=raw[:end].decode().split();n=int(head[2]);assert raw[end+1:end+1+n]==data and end+2+n==len(raw)
for variant,root in roots.items():
 authority=json.loads((s/(variant+'-initial-authority.json')).read_text())
 for name,h in authority.items():
  if name!=rel:assert sha((root/name).read_bytes())==h,(variant,name)
 for row in json.loads((s/'immutable-oracle-pins.json').read_text()):assert sha((root/row['path']).read_bytes())==row['sha256']
for label,count in [('borrow-audio',370),('borrow-scoped-audio',351)]:
 assert f'test result: ok. {count} passed; 0 failed; 3 ignored;'in(s/(label+'.stdout')).read_text()
result={'all_terminal':True,'all_checks_passed':True,'receipts':receipts,'source_files':1,'main_scope_index_equal':True,'source_sha256':sha(data),'other_initial_inputs_unchanged':{'main':1496,'scoped':1267},'immutable_oracles_unchanged':8,'review':'Parent inspected complete six-line collection-expression diff. BTreeMap iteration yields the same ordered owned AssetId clones and copied [u8;32] values; destination extension semantics unchanged. Explicit temporary BTreeMap construction removed; no allocator-call/peak or speed claim.','checks_not_rerun':'Prior ordinary Stage/definitions/history and failed Split matrix are historical evidence, not new executions for this mechanical change. Modeled work/residency formulas are unchanged; both complete recursive old-native matrices and all current library tests pass.','scoped_patch_sha256':sha((s/'task-scoped.patch').read_bytes())}
(s/'final-audit.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result))
