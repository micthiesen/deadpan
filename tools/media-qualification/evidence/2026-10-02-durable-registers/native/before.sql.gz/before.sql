BEGIN TRANSACTION;
CREATE TABLE generation_attempt_heads (
    request_id TEXT PRIMARY KEY REFERENCES generation_requests(request_id),
    high_water INTEGER NOT NULL CHECK (high_water BETWEEN 1 AND 9223372036854775807),
    latest_attempt_id TEXT NOT NULL,
    selected_ready_attempt_id TEXT,
    FOREIGN KEY (request_id,latest_attempt_id)
        REFERENCES generation_attempts(request_id,attempt_id),
    FOREIGN KEY (request_id,selected_ready_attempt_id)
        REFERENCES generation_attempts(request_id,attempt_id)
) STRICT;
CREATE TABLE generation_attempts (
    request_id TEXT NOT NULL REFERENCES generation_requests(request_id),
    attempt_id TEXT NOT NULL,
    ordinal INTEGER NOT NULL CHECK (ordinal BETWEEN 1 AND 9223372036854775807),
    cancellation_token TEXT NOT NULL,
    state TEXT NOT NULL CHECK (state IN (
        'queued','preflight','loading','running','validating','ready','failed','cancelling','cancelled'
    )),
    worker_stage TEXT CHECK (worker_stage IS NULL OR worker_stage IN (
        'preflight','runtime_loading','model_loading','conditioning','inference',
        'decoding','encoding','worker_validation'
    )),
    transition_sequence INTEGER NOT NULL
        CHECK (transition_sequence BETWEEN 1 AND 9223372036854775807),
    cancel_response TEXT CHECK (cancel_response IS NULL OR cancel_response IN ('cancelled','completed')),
    worker_candidate TEXT CHECK (worker_candidate IS NULL OR json_valid(worker_candidate)),
    failure_origin TEXT CHECK (failure_origin IS NULL OR failure_origin IN ('worker','host')),
    failure_code TEXT,
    failure_detail TEXT,
    PRIMARY KEY (request_id,attempt_id),
    UNIQUE (request_id,ordinal),
    CHECK ((failure_origin IS NULL) = (failure_code IS NULL)),
    CHECK ((failure_origin IS NULL) = (failure_detail IS NULL)),
    CHECK (cancel_response!='completed' OR worker_candidate IS NOT NULL)
) STRICT;
CREATE TABLE generation_bundle_receipts (
    request_id TEXT NOT NULL,
    attempt_id TEXT NOT NULL,
    bundle TEXT NOT NULL CHECK (json_valid(bundle)),
    availability TEXT NOT NULL CHECK (availability IN ('present','evicted')),
    PRIMARY KEY (request_id,attempt_id),
    FOREIGN KEY (request_id,attempt_id)
        REFERENCES generation_attempts(request_id,attempt_id)
) STRICT;
CREATE TABLE generation_candidate_receipts (
    request_id TEXT NOT NULL,
    attempt_id TEXT NOT NULL,
    staged_ref TEXT NOT NULL UNIQUE,
    sha256 TEXT NOT NULL,
    byte_length INTEGER NOT NULL CHECK (byte_length BETWEEN 1 AND 9223372036854775807),
    video TEXT NOT NULL CHECK (json_valid(video)),
    provider TEXT NOT NULL CHECK (json_valid(provider)),
    validator_id TEXT NOT NULL,
    validator_version TEXT NOT NULL,
    availability TEXT NOT NULL CHECK (availability IN ('present','evicted')),
    PRIMARY KEY (request_id,attempt_id),
    FOREIGN KEY (request_id,attempt_id)
        REFERENCES generation_attempts(request_id,attempt_id)
) STRICT;
CREATE TABLE generation_requests (
    request_id TEXT PRIMARY KEY,
    project_id TEXT NOT NULL,
    hold_id TEXT NOT NULL,
    request_version INTEGER NOT NULL
        CHECK (request_version BETWEEN 1 AND 9223372036854775807),
    origin_revision TEXT NOT NULL REFERENCES revisions(id),
    context_sha256 TEXT NOT NULL,
    constraints TEXT NOT NULL CHECK (json_valid(constraints)),
    provider TEXT NOT NULL CHECK (json_valid(provider)),
    bridge_plan TEXT CHECK (bridge_plan IS NULL OR json_valid(bridge_plan)),
    relevance TEXT NOT NULL CHECK (relevance IN ('current','stale','detached')),
    UNIQUE (hold_id, request_version)
) STRICT;
CREATE TABLE history (
            id INTEGER PRIMARY KEY,
            parent_id INTEGER REFERENCES history(id),
            revision_id TEXT NOT NULL REFERENCES revisions(id),
            request TEXT NOT NULL CHECK (json_valid(request)),
            edit TEXT NOT NULL CHECK (json_valid(edit))
        ) STRICT;
INSERT INTO "history" VALUES(1,NULL,'540b434e-34b2-4b43-ae68-1084ee80e450','{"project_id":"e6d1ba97-2db0-4119-9e5d-e4a4bef3e078","expected_revision":"d9750054-772e-482e-9b29-ebf2da2cb0e2","new_revision":"540b434e-34b2-4b43-ae68-1084ee80e450","command":{"command":"import_source","id":"b2868a97-5094-4eb8-9ccd-4a5c904983e0","asset":{"label":"cfr-bframes.mp4","content_hash":"blake3:16614ec12d06396d3c0f0e7b91cc902c6dc30ad89c28d74b805cf64dc60d8aa1","video":{"start":{"ticks":0,"time_base":{"numerator":1,"denominator":30000}},"end":{"ticks":120120,"time_base":{"numerator":1,"denominator":30000}}},"audio":{"start":{"ticks":0,"time_base":{"numerator":1,"denominator":48000}},"end":{"ticks":192192,"time_base":{"numerator":1,"denominator":48000}}},"still_image":false,"frame_count":120,"source_qualification":"c6bc3e81ab69906267164469d11739cf1363eea546436761ddd219069ed496b6"},"insertion":{"parent":"44425a05-dc69-45ff-aedd-26c2356c963a","index":0,"node":"2edb85c2-83ff-4e7d-894a-bbc001fa8f88","label":"cfr-bframes.mp4","source":{"duration":120,"edit_window":{"start":{"numerator":"0","denominator":"1"},"end":{"numerator":"120","denominator":"1"}},"video":{"type":"stream","asset":"b2868a97-5094-4eb8-9ccd-4a5c904983e0","span":{"start":{"ticks":0,"time_base":{"numerator":1,"denominator":30000}},"end":{"ticks":120120,"time_base":{"numerator":1,"denominator":30000}}}},"video_mapping":{"type":"placement","start":{"numerator":"0","denominator":"1"},"frames":{"numerator":"120","denominator":"1"},"endpoints":"hold_adjacent"},"audio":{"asset":"b2868a97-5094-4eb8-9ccd-4a5c904983e0","span":{"start":{"ticks":0,"time_base":{"numerator":1,"denominator":48000}},"end":{"ticks":192192,"time_base":{"numerator":1,"denominator":48000}}}},"audio_mapping":{"type":"placement","start":{"numerator":"0","denominator":"1"},"frames":{"numerator":"120","denominator":"1"}},"link":"linked","audio_offset":0}},"primary":{"type":"adopt","basis":{"width":320,"height":180,"frame_rate":{"numerator":30000,"denominator":1001},"color_policy":"sdr_rec709"}}}}','{"forward":{"project_id":"e6d1ba97-2db0-4119-9e5d-e4a4bef3e078","from_revision":"d9750054-772e-482e-9b29-ebf2da2cb0e2","to_revision":"540b434e-34b2-4b43-ae68-1084ee80e450","presentation":{"before":{"basis":{"width":1920,"height":1080,"frame_rate":{"numerator":30,"denominator":1},"color_policy":"sdr_rec709"},"state":{"rate_origin":"provisional","geometry_origin":"default","primary":null}},"after":{"basis":{"width":320,"height":180,"frame_rate":{"numerator":30000,"denominator":1001},"color_policy":"sdr_rec709"},"state":{"rate_origin":"primary_source","geometry_origin":"primary_source","primary":{"asset":"b2868a97-5094-4eb8-9ccd-4a5c904983e0","qualification":"c6bc3e81ab69906267164469d11739cf1363eea546436761ddd219069ed496b6"}}}},"nodes":{"2edb85c2-83ff-4e7d-894a-bbc001fa8f88":{"before":null,"after":{"label":"cfr-bframes.mp4","kind":{"type":"source","source":{"duration":120,"edit_window":{"start":{"numerator":"0","denominator":"1"},"end":{"numerator":"120","denominator":"1"}},"video":{"type":"stream","asset":"b2868a97-5094-4eb8-9ccd-4a5c904983e0","span":{"start":{"ticks":0,"time_base":{"numerator":1,"denominator":30000}},"end":{"ticks":120120,"time_base":{"numerator":1,"denominator":30000}}}},"video_mapping":{"type":"placement","start":{"numerator":"0","denominator":"1"},"frames":{"numerator":"120","denominator":"1"},"endpoints":"hold_adjacent"},"audio":{"asset":"b2868a97-5094-4eb8-9ccd-4a5c904983e0","span":{"start":{"ticks":0,"time_base":{"numerator":1,"denominator":48000}},"end":{"ticks":192192,"time_base":{"numerator":1,"denominator":48000}}}},"audio_mapping":{"type":"placement","start":{"numerator":"0","denominator":"1"},"frames":{"numerator":"120","denominator":"1"}},"link":"linked","audio_offset":0}}}},"44425a05-dc69-45ff-aedd-26c2356c963a":{"before":{"label":"Sequence","kind":{"type":"sequence","children":[]}},"after":{"label":"Sequence","kind":{"type":"sequence","children":["2edb85c2-83ff-4e7d-894a-bbc001fa8f88"]}}}},"assets":{"b2868a97-5094-4eb8-9ccd-4a5c904983e0":{"before":null,"after":{"label":"cfr-bframes.mp4","content_hash":"blake3:16614ec12d06396d3c0f0e7b91cc902c6dc30ad89c28d74b805cf64dc60d8aa1","video":{"start":{"ticks":0,"time_base":{"numerator":1,"denominator":30000}},"end":{"ticks":120120,"time_base":{"numerator":1,"denominator":30000}}},"audio":{"start":{"ticks":0,"time_base":{"numerator":1,"denominator":48000}},"end":{"ticks":192192,"time_base":{"numerator":1,"denominator":48000}}},"still_image":false,"frame_count":120,"source_qualification":"c6bc3e81ab69906267164469d11739cf1363eea546436761ddd219069ed496b6"}}},"marks":{},"overrides":{}},"inverse":{"project_id":"e6d1ba97-2db0-4119-9e5d-e4a4bef3e078","from_revision":"540b434e-34b2-4b43-ae68-1084ee80e450","to_revision":"d9750054-772e-482e-9b29-ebf2da2cb0e2","presentation":{"before":{"basis":{"width":320,"height":180,"frame_rate":{"numerator":30000,"denominator":1001},"color_policy":"sdr_rec709"},"state":{"rate_origin":"primary_source","geometry_origin":"primary_source","primary":{"asset":"b2868a97-5094-4eb8-9ccd-4a5c904983e0","qualification":"c6bc3e81ab69906267164469d11739cf1363eea546436761ddd219069ed496b6"}}},"after":{"basis":{"width":1920,"height":1080,"frame_rate":{"numerator":30,"denominator":1},"color_policy":"sdr_rec709"},"state":{"rate_origin":"provisional","geometry_origin":"default","primary":null}}},"nodes":{"2edb85c2-83ff-4e7d-894a-bbc001fa8f88":{"before":{"label":"cfr-bframes.mp4","kind":{"type":"source","source":{"duration":120,"edit_window":{"start":{"numerator":"0","denominator":"1"},"end":{"numerator":"120","denominator":"1"}},"video":{"type":"stream","asset":"b2868a97-5094-4eb8-9ccd-4a5c904983e0","span":{"start":{"ticks":0,"time_base":{"numerator":1,"denominator":30000}},"end":{"ticks":120120,"time_base":{"numerator":1,"denominator":30000}}}},"video_mapping":{"type":"placement","start":{"numerator":"0","denominator":"1"},"frames":{"numerator":"120","denominator":"1"},"endpoints":"hold_adjacent"},"audio":{"asset":"b2868a97-5094-4eb8-9ccd-4a5c904983e0","span":{"start":{"ticks":0,"time_base":{"numerator":1,"denominator":48000}},"end":{"ticks":192192,"time_base":{"numerator":1,"denominator":48000}}}},"audio_mapping":{"type":"placement","start":{"numerator":"0","denominator":"1"},"frames":{"numerator":"120","denominator":"1"}},"link":"linked","audio_offset":0}}},"after":null},"44425a05-dc69-45ff-aedd-26c2356c963a":{"before":{"label":"Sequence","kind":{"type":"sequence","children":["2edb85c2-83ff-4e7d-894a-bbc001fa8f88"]}},"after":{"label":"Sequence","kind":{"type":"sequence","children":[]}}}},"assets":{"b2868a97-5094-4eb8-9ccd-4a5c904983e0":{"before":{"label":"cfr-bframes.mp4","content_hash":"blake3:16614ec12d06396d3c0f0e7b91cc902c6dc30ad89c28d74b805cf64dc60d8aa1","video":{"start":{"ticks":0,"time_base":{"numerator":1,"denominator":30000}},"end":{"ticks":120120,"time_base":{"numerator":1,"denominator":30000}}},"audio":{"start":{"ticks":0,"time_base":{"numerator":1,"denominator":48000}},"end":{"ticks":192192,"time_base":{"numerator":1,"denominator":48000}}},"still_image":false,"frame_count":120,"source_qualification":"c6bc3e81ab69906267164469d11739cf1363eea546436761ddd219069ed496b6"},"after":null}},"marks":{},"overrides":{}},"changed_ids":["2edb85c2-83ff-4e7d-894a-bbc001fa8f88","44425a05-dc69-45ff-aedd-26c2356c963a"],"duration_delta":120,"description":"Import source media"}');
INSERT INTO "history" VALUES(2,1,'d2b9e481-1dbe-43be-a305-5150879171a2','{"project_id":"e6d1ba97-2db0-4119-9e5d-e4a4bef3e078","expected_revision":"540b434e-34b2-4b43-ae68-1084ee80e450","new_revision":"d2b9e481-1dbe-43be-a305-5150879171a2","command":{"command":"splice_source","parent":"44425a05-dc69-45ff-aedd-26c2356c963a","index":1,"source":{"duration":8,"edit_window":{"start":{"numerator":"0","denominator":"1"},"end":{"numerator":"8","denominator":"1"}},"video":{"type":"stream","asset":"b2868a97-5094-4eb8-9ccd-4a5c904983e0","span":{"start":{"ticks":0,"time_base":{"numerator":1,"denominator":30000}},"end":{"ticks":120120,"time_base":{"numerator":1,"denominator":30000}}}},"video_mapping":{"type":"selected_placement","start":{"numerator":"-5","denominator":"1"},"frames":{"numerator":"120","denominator":"1"},"selection":{"start":{"numerator":"0","denominator":"1"},"end":{"numerator":"8","denominator":"1"}},"endpoints":"hold_adjacent"},"audio":{"asset":"b2868a97-5094-4eb8-9ccd-4a5c904983e0","span":{"start":{"ticks":0,"time_base":{"numerator":1,"denominator":48000}},"end":{"ticks":192192,"time_base":{"numerator":1,"denominator":48000}}}},"audio_mapping":{"type":"selected_placement","start":{"numerator":"-5","denominator":"1"},"frames":{"numerator":"120","denominator":"1"},"selection":{"start":{"numerator":"0","denominator":"1"},"end":{"numerator":"8","denominator":"1"}}},"link":"linked","audio_offset":0},"id":"143d5f08-97cc-41cc-a0e4-baa8277ffb23","label":"cfr-bframes.mp4 [5..13)","timing":{"allocation":"d2b9e481-1dbe-43be-a305-5150879171a2","ordinal":0}}}','{"forward":{"project_id":"e6d1ba97-2db0-4119-9e5d-e4a4bef3e078","from_revision":"540b434e-34b2-4b43-ae68-1084ee80e450","to_revision":"d2b9e481-1dbe-43be-a305-5150879171a2","nodes":{"143d5f08-97cc-41cc-a0e4-baa8277ffb23":{"before":null,"after":{"label":"cfr-bframes.mp4 [5..13)","kind":{"type":"source","source":{"duration":8,"edit_window":{"start":{"numerator":"0","denominator":"1"},"end":{"numerator":"8","denominator":"1"}},"video":{"type":"stream","asset":"b2868a97-5094-4eb8-9ccd-4a5c904983e0","span":{"start":{"ticks":0,"time_base":{"numerator":1,"denominator":30000}},"end":{"ticks":120120,"time_base":{"numerator":1,"denominator":30000}}}},"video_mapping":{"type":"selected_placement","start":{"numerator":"-5","denominator":"1"},"frames":{"numerator":"120","denominator":"1"},"selection":{"start":{"numerator":"0","denominator":"1"},"end":{"numerator":"8","denominator":"1"}},"endpoints":"hold_adjacent"},"audio":{"asset":"b2868a97-5094-4eb8-9ccd-4a5c904983e0","span":{"start":{"ticks":0,"time_base":{"numerator":1,"denominator":48000}},"end":{"ticks":192192,"time_base":{"numerator":1,"denominator":48000}}}},"audio_mapping":{"type":"selected_placement","start":{"numerator":"-5","denominator":"1"},"frames":{"numerator":"120","denominator":"1"},"selection":{"start":{"numerator":"0","denominator":"1"},"end":{"numerator":"8","denominator":"1"}}},"link":"linked","audio_offset":0}}}},"44425a05-dc69-45ff-aedd-26c2356c963a":{"before":{"label":"Sequence","kind":{"type":"sequence","children":["2edb85c2-83ff-4e7d-894a-bbc001fa8f88"]}},"after":{"label":"Sequence","kind":{"type":"sequence","children":["2edb85c2-83ff-4e7d-894a-bbc001fa8f88","143d5f08-97cc-41cc-a0e4-baa8277ffb23"]}}}},"assets":{},"marks":{},"overrides":{},"audio_bindings":{"before":{"timings":[],"bindings":{}},"after":{"timings":[{"id":{"allocation":"d2b9e481-1dbe-43be-a305-5150879171a2","ordinal":0},"layout":{"root":"44425a05-dc69-45ff-aedd-26c2356c963a","rate":{"numerator":30000,"denominator":1001},"nodes":{"2edb85c2-83ff-4e7d-894a-bbc001fa8f88":{"duration":120,"edges":{"node_start":"automatic","node_end":"automatic","source_placement_start":"automatic","source_placement_end":"automatic","repeat_gap_start":"automatic","repeat_gap_end":"automatic"},"kind":{"type":"source","placement":{"start":{"numerator":"0","denominator":"1"},"end":{"numerator":"120","denominator":"1"}}}},"44425a05-dc69-45ff-aedd-26c2356c963a":{"duration":120,"edges":{"node_start":"automatic","node_end":"automatic","source_placement_start":"automatic","source_placement_end":"automatic","repeat_gap_start":"automatic","repeat_gap_end":"automatic"},"kind":{"type":"sequence","children":["2edb85c2-83ff-4e7d-894a-bbc001fa8f88"]}}},"overrides":{}}}],"bindings":{"2edb85c2-83ff-4e7d-894a-bbc001fa8f88":{"lattice":{"reference":{"timing":{"allocation":"d2b9e481-1dbe-43be-a305-5150879171a2","ordinal":0},"root":{"type":"project_root_round_even"},"physical":"2edb85c2-83ff-4e7d-894a-bbc001fa8f88"},"arguments":[],"births":[]},"resume":null}}}}},"inverse":{"project_id":"e6d1ba97-2db0-4119-9e5d-e4a4bef3e078","from_revision":"d2b9e481-1dbe-43be-a305-5150879171a2","to_revision":"540b434e-34b2-4b43-ae68-1084ee80e450","nodes":{"143d5f08-97cc-41cc-a0e4-baa8277ffb23":{"before":{"label":"cfr-bframes.mp4 [5..13)","kind":{"type":"source","source":{"duration":8,"edit_window":{"start":{"numerator":"0","denominator":"1"},"end":{"numerator":"8","denominator":"1"}},"video":{"type":"stream","asset":"b2868a97-5094-4eb8-9ccd-4a5c904983e0","span":{"start":{"ticks":0,"time_base":{"numerator":1,"denominator":30000}},"end":{"ticks":120120,"time_base":{"numerator":1,"denominator":30000}}}},"video_mapping":{"type":"selected_placement","start":{"numerator":"-5","denominator":"1"},"frames":{"numerator":"120","denominator":"1"},"selection":{"start":{"numerator":"0","denominator":"1"},"end":{"numerator":"8","denominator":"1"}},"endpoints":"hold_adjacent"},"audio":{"asset":"b2868a97-5094-4eb8-9ccd-4a5c904983e0","span":{"start":{"ticks":0,"time_base":{"numerator":1,"denominator":48000}},"end":{"ticks":192192,"time_base":{"numerator":1,"denominator":48000}}}},"audio_mapping":{"type":"selected_placement","start":{"numerator":"-5","denominator":"1"},"frames":{"numerator":"120","denominator":"1"},"selection":{"start":{"numerator":"0","denominator":"1"},"end":{"numerator":"8","denominator":"1"}}},"link":"linked","audio_offset":0}}},"after":null},"44425a05-dc69-45ff-aedd-26c2356c963a":{"before":{"label":"Sequence","kind":{"type":"sequence","children":["2edb85c2-83ff-4e7d-894a-bbc001fa8f88","143d5f08-97cc-41cc-a0e4-baa8277ffb23"]}},"after":{"label":"Sequence","kind":{"type":"sequence","children":["2edb85c2-83ff-4e7d-894a-bbc001fa8f88"]}}}},"assets":{},"marks":{},"overrides":{},"audio_bindings":{"before":{"timings":[{"id":{"allocation":"d2b9e481-1dbe-43be-a305-5150879171a2","ordinal":0},"layout":{"root":"44425a05-dc69-45ff-aedd-26c2356c963a","rate":{"numerator":30000,"denominator":1001},"nodes":{"2edb85c2-83ff-4e7d-894a-bbc001fa8f88":{"duration":120,"edges":{"node_start":"automatic","node_end":"automatic","source_placement_start":"automatic","source_placement_end":"automatic","repeat_gap_start":"automatic","repeat_gap_end":"automatic"},"kind":{"type":"source","placement":{"start":{"numerator":"0","denominator":"1"},"end":{"numerator":"120","denominator":"1"}}}},"44425a05-dc69-45ff-aedd-26c2356c963a":{"duration":120,"edges":{"node_start":"automatic","node_end":"automatic","source_placement_start":"automatic","source_placement_end":"automatic","repeat_gap_start":"automatic","repeat_gap_end":"automatic"},"kind":{"type":"sequence","children":["2edb85c2-83ff-4e7d-894a-bbc001fa8f88"]}}},"overrides":{}}}],"bindings":{"2edb85c2-83ff-4e7d-894a-bbc001fa8f88":{"lattice":{"reference":{"timing":{"allocation":"d2b9e481-1dbe-43be-a305-5150879171a2","ordinal":0},"root":{"type":"project_root_round_even"},"physical":"2edb85c2-83ff-4e7d-894a-bbc001fa8f88"},"arguments":[],"births":[]},"resume":null}}},"after":{"timings":[],"bindings":{}}}},"changed_ids":["143d5f08-97cc-41cc-a0e4-baa8277ffb23","2edb85c2-83ff-4e7d-894a-bbc001fa8f88","44425a05-dc69-45ff-aedd-26c2356c963a"],"duration_delta":8,"description":"Paste source moment"}');
INSERT INTO "history" VALUES(3,1,'ca5eb43d-d34f-47ea-97de-6dd4d576fda3','{"project_id":"e6d1ba97-2db0-4119-9e5d-e4a4bef3e078","expected_revision":"a25b3890-6c4f-47aa-a0fa-0757d24149dc","new_revision":"ca5eb43d-d34f-47ea-97de-6dd4d576fda3","command":{"command":"splice_source","parent":"44425a05-dc69-45ff-aedd-26c2356c963a","index":0,"source":{"duration":5,"edit_window":{"start":{"numerator":"0","denominator":"1"},"end":{"numerator":"5","denominator":"1"}},"video":{"type":"stream","asset":"b2868a97-5094-4eb8-9ccd-4a5c904983e0","span":{"start":{"ticks":0,"time_base":{"numerator":1,"denominator":30000}},"end":{"ticks":120120,"time_base":{"numerator":1,"denominator":30000}}}},"video_mapping":{"type":"selected_placement","start":{"numerator":"-30","denominator":"1"},"frames":{"numerator":"120","denominator":"1"},"selection":{"start":{"numerator":"0","denominator":"1"},"end":{"numerator":"5","denominator":"1"}},"endpoints":"hold_adjacent"},"audio":{"asset":"b2868a97-5094-4eb8-9ccd-4a5c904983e0","span":{"start":{"ticks":0,"time_base":{"numerator":1,"denominator":48000}},"end":{"ticks":192192,"time_base":{"numerator":1,"denominator":48000}}}},"audio_mapping":{"type":"selected_placement","start":{"numerator":"-30","denominator":"1"},"frames":{"numerator":"120","denominator":"1"},"selection":{"start":{"numerator":"0","denominator":"1"},"end":{"numerator":"5","denominator":"1"}}},"link":"linked","audio_offset":0},"id":"cad6b366-1ce5-4dd0-8f92-6ece27313751","label":"cfr-bframes.mp4 [30..35)","timing":{"allocation":"ca5eb43d-d34f-47ea-97de-6dd4d576fda3","ordinal":0}}}','{"forward":{"project_id":"e6d1ba97-2db0-4119-9e5d-e4a4bef3e078","from_revision":"a25b3890-6c4f-47aa-a0fa-0757d24149dc","to_revision":"ca5eb43d-d34f-47ea-97de-6dd4d576fda3","nodes":{"44425a05-dc69-45ff-aedd-26c2356c963a":{"before":{"label":"Sequence","kind":{"type":"sequence","children":["2edb85c2-83ff-4e7d-894a-bbc001fa8f88"]}},"after":{"label":"Sequence","kind":{"type":"sequence","children":["cad6b366-1ce5-4dd0-8f92-6ece27313751","2edb85c2-83ff-4e7d-894a-bbc001fa8f88"]}}},"cad6b366-1ce5-4dd0-8f92-6ece27313751":{"before":null,"after":{"label":"cfr-bframes.mp4 [30..35)","kind":{"type":"source","source":{"duration":5,"edit_window":{"start":{"numerator":"0","denominator":"1"},"end":{"numerator":"5","denominator":"1"}},"video":{"type":"stream","asset":"b2868a97-5094-4eb8-9ccd-4a5c904983e0","span":{"start":{"ticks":0,"time_base":{"numerator":1,"denominator":30000}},"end":{"ticks":120120,"time_base":{"numerator":1,"denominator":30000}}}},"video_mapping":{"type":"selected_placement","start":{"numerator":"-30","denominator":"1"},"frames":{"numerator":"120","denominator":"1"},"selection":{"start":{"numerator":"0","denominator":"1"},"end":{"numerator":"5","denominator":"1"}},"endpoints":"hold_adjacent"},"audio":{"asset":"b2868a97-5094-4eb8-9ccd-4a5c904983e0","span":{"start":{"ticks":0,"time_base":{"numerator":1,"denominator":48000}},"end":{"ticks":192192,"time_base":{"numerator":1,"denominator":48000}}}},"audio_mapping":{"type":"selected_placement","start":{"numerator":"-30","denominator":"1"},"frames":{"numerator":"120","denominator":"1"},"selection":{"start":{"numerator":"0","denominator":"1"},"end":{"numerator":"5","denominator":"1"}}},"link":"linked","audio_offset":0}}}}},"assets":{},"marks":{},"overrides":{},"audio_bindings":{"before":{"timings":[],"bindings":{}},"after":{"timings":[{"id":{"allocation":"ca5eb43d-d34f-47ea-97de-6dd4d576fda3","ordinal":0},"layout":{"root":"44425a05-dc69-45ff-aedd-26c2356c963a","rate":{"numerator":30000,"denominator":1001},"nodes":{"2edb85c2-83ff-4e7d-894a-bbc001fa8f88":{"duration":120,"edges":{"node_start":"automatic","node_end":"automatic","source_placement_start":"automatic","source_placement_end":"automatic","repeat_gap_start":"automatic","repeat_gap_end":"automatic"},"kind":{"type":"source","placement":{"start":{"numerator":"0","denominator":"1"},"end":{"numerator":"120","denominator":"1"}}}},"44425a05-dc69-45ff-aedd-26c2356c963a":{"duration":120,"edges":{"node_start":"automatic","node_end":"automatic","source_placement_start":"automatic","source_placement_end":"automatic","repeat_gap_start":"automatic","repeat_gap_end":"automatic"},"kind":{"type":"sequence","children":["2edb85c2-83ff-4e7d-894a-bbc001fa8f88"]}}},"overrides":{}}}],"bindings":{"2edb85c2-83ff-4e7d-894a-bbc001fa8f88":{"lattice":{"reference":{"timing":{"allocation":"ca5eb43d-d34f-47ea-97de-6dd4d576fda3","ordinal":0},"root":{"type":"project_root_round_even"},"physical":"2edb85c2-83ff-4e7d-894a-bbc001fa8f88"},"arguments":[],"births":[]},"resume":null,"reanchors":[{"placement":{"reference":{"timing":{"allocation":"ca5eb43d-d34f-47ea-97de-6dd4d576fda3","ordinal":0},"root":{"type":"project_root_round_even"},"physical":"2edb85c2-83ff-4e7d-894a-bbc001fa8f88"},"arguments":[],"births":[]},"window":{"start":{"numerator":"0","denominator":"1"},"end":{"numerator":"120","denominator":"1"}}}]}}}}},"inverse":{"project_id":"e6d1ba97-2db0-4119-9e5d-e4a4bef3e078","from_revision":"ca5eb43d-d34f-47ea-97de-6dd4d576fda3","to_revision":"a25b3890-6c4f-47aa-a0fa-0757d24149dc","nodes":{"44425a05-dc69-45ff-aedd-26c2356c963a":{"before":{"label":"Sequence","kind":{"type":"sequence","children":["cad6b366-1ce5-4dd0-8f92-6ece27313751","2edb85c2-83ff-4e7d-894a-bbc001fa8f88"]}},"after":{"label":"Sequence","kind":{"type":"sequence","children":["2edb85c2-83ff-4e7d-894a-bbc001fa8f88"]}}},"cad6b366-1ce5-4dd0-8f92-6ece27313751":{"before":{"label":"cfr-bframes.mp4 [30..35)","kind":{"type":"source","source":{"duration":5,"edit_window":{"start":{"numerator":"0","denominator":"1"},"end":{"numerator":"5","denominator":"1"}},"video":{"type":"stream","asset":"b2868a97-5094-4eb8-9ccd-4a5c904983e0","span":{"start":{"ticks":0,"time_base":{"numerator":1,"denominator":30000}},"end":{"ticks":120120,"time_base":{"numerator":1,"denominator":30000}}}},"video_mapping":{"type":"selected_placement","start":{"numerator":"-30","denominator":"1"},"frames":{"numerator":"120","denominator":"1"},"selection":{"start":{"numerator":"0","denominator":"1"},"end":{"numerator":"5","denominator":"1"}},"endpoints":"hold_adjacent"},"audio":{"asset":"b2868a97-5094-4eb8-9ccd-4a5c904983e0","span":{"start":{"ticks":0,"time_base":{"numerator":1,"denominator":48000}},"end":{"ticks":192192,"time_base":{"numerator":1,"denominator":48000}}}},"audio_mapping":{"type":"selected_placement","start":{"numerator":"-30","denominator":"1"},"frames":{"numerator":"120","denominator":"1"},"selection":{"start":{"numerator":"0","denominator":"1"},"end":{"numerator":"5","denominator":"1"}}},"link":"linked","audio_offset":0}}},"after":null}},"assets":{},"marks":{},"overrides":{},"audio_bindings":{"before":{"timings":[{"id":{"allocation":"ca5eb43d-d34f-47ea-97de-6dd4d576fda3","ordinal":0},"layout":{"root":"44425a05-dc69-45ff-aedd-26c2356c963a","rate":{"numerator":30000,"denominator":1001},"nodes":{"2edb85c2-83ff-4e7d-894a-bbc001fa8f88":{"duration":120,"edges":{"node_start":"automatic","node_end":"automatic","source_placement_start":"automatic","source_placement_end":"automatic","repeat_gap_start":"automatic","repeat_gap_end":"automatic"},"kind":{"type":"source","placement":{"start":{"numerator":"0","denominator":"1"},"end":{"numerator":"120","denominator":"1"}}}},"44425a05-dc69-45ff-aedd-26c2356c963a":{"duration":120,"edges":{"node_start":"automatic","node_end":"automatic","source_placement_start":"automatic","source_placement_end":"automatic","repeat_gap_start":"automatic","repeat_gap_end":"automatic"},"kind":{"type":"sequence","children":["2edb85c2-83ff-4e7d-894a-bbc001fa8f88"]}}},"overrides":{}}}],"bindings":{"2edb85c2-83ff-4e7d-894a-bbc001fa8f88":{"lattice":{"reference":{"timing":{"allocation":"ca5eb43d-d34f-47ea-97de-6dd4d576fda3","ordinal":0},"root":{"type":"project_root_round_even"},"physical":"2edb85c2-83ff-4e7d-894a-bbc001fa8f88"},"arguments":[],"births":[]},"resume":null,"reanchors":[{"placement":{"reference":{"timing":{"allocation":"ca5eb43d-d34f-47ea-97de-6dd4d576fda3","ordinal":0},"root":{"type":"project_root_round_even"},"physical":"2edb85c2-83ff-4e7d-894a-bbc001fa8f88"},"arguments":[],"births":[]},"window":{"start":{"numerator":"0","denominator":"1"},"end":{"numerator":"120","denominator":"1"}}}]}}},"after":{"timings":[],"bindings":{}}}},"changed_ids":["2edb85c2-83ff-4e7d-894a-bbc001fa8f88","44425a05-dc69-45ff-aedd-26c2356c963a","cad6b366-1ce5-4dd0-8f92-6ece27313751"],"duration_delta":5,"description":"Paste source moment"}');
INSERT INTO "history" VALUES(4,1,'ed903801-af9a-4875-a6d0-2ffb76eb830f','{"project_id":"e6d1ba97-2db0-4119-9e5d-e4a4bef3e078","expected_revision":"01a31893-138e-4642-b20e-02a2e82c7228","new_revision":"ed903801-af9a-4875-a6d0-2ffb76eb830f","command":{"command":"insert_time","at":10,"hold":{"picture_context":{"canvases":[{"width":320,"height":180,"fit":"fit","layers":[]}]},"duration":11,"video":{"type":"freeze","asset":"b2868a97-5094-4eb8-9ccd-4a5c904983e0","timestamp":{"ticks":9009,"time_base":{"numerator":1,"denominator":30000}}},"audio":{"type":"silence"}},"id":"b0131c13-21a8-452e-80f8-03b53f60f52e","identities":{"nodes":["4de01272-0476-425e-9ba1-c63b46aa4012","6d77dc13-c463-476e-ad1c-948bf919538b","73b09e6c-178d-48c1-9f43-54960c553afd"]},"timing":{"allocation":"ed903801-af9a-4875-a6d0-2ffb76eb830f","ordinal":0}}}','{"forward":{"project_id":"e6d1ba97-2db0-4119-9e5d-e4a4bef3e078","from_revision":"01a31893-138e-4642-b20e-02a2e82c7228","to_revision":"ed903801-af9a-4875-a6d0-2ffb76eb830f","nodes":{"44425a05-dc69-45ff-aedd-26c2356c963a":{"before":{"label":"Sequence","kind":{"type":"sequence","children":["2edb85c2-83ff-4e7d-894a-bbc001fa8f88"]}},"after":{"label":"Sequence","kind":{"type":"sequence","children":["4de01272-0476-425e-9ba1-c63b46aa4012","b0131c13-21a8-452e-80f8-03b53f60f52e","6d77dc13-c463-476e-ad1c-948bf919538b"]}}},"4de01272-0476-425e-9ba1-c63b46aa4012":{"before":null,"after":{"label":"cfr-bframes.mp4","kind":{"type":"retime","child":"2edb85c2-83ff-4e7d-894a-bbc001fa8f88","duration":10,"mapping":{"start":0,"end":10},"pitch":"preserve","purpose":"partition"}}},"6d77dc13-c463-476e-ad1c-948bf919538b":{"before":null,"after":{"label":"cfr-bframes.mp4","kind":{"type":"retime","child":"73b09e6c-178d-48c1-9f43-54960c553afd","duration":110,"mapping":{"start":10,"end":120},"pitch":"preserve","purpose":"partition"}}},"73b09e6c-178d-48c1-9f43-54960c553afd":{"before":null,"after":{"label":"cfr-bframes.mp4","kind":{"type":"source","source":{"duration":120,"edit_window":{"start":{"numerator":"0","denominator":"1"},"end":{"numerator":"120","denominator":"1"}},"video":{"type":"stream","asset":"b2868a97-5094-4eb8-9ccd-4a5c904983e0","span":{"start":{"ticks":0,"time_base":{"numerator":1,"denominator":30000}},"end":{"ticks":120120,"time_base":{"numerator":1,"denominator":30000}}}},"video_mapping":{"type":"placement","start":{"numerator":"0","denominator":"1"},"frames":{"numerator":"120","denominator":"1"},"endpoints":"hold_adjacent"},"audio":{"asset":"b2868a97-5094-4eb8-9ccd-4a5c904983e0","span":{"start":{"ticks":0,"time_base":{"numerator":1,"denominator":48000}},"end":{"ticks":192192,"time_base":{"numerator":1,"denominator":48000}}}},"audio_mapping":{"type":"placement","start":{"numerator":"0","denominator":"1"},"frames":{"numerator":"120","denominator":"1"}},"link":"linked","audio_offset":0}}}},"b0131c13-21a8-452e-80f8-03b53f60f52e":{"before":null,"after":{"label":"Pause","kind":{"type":"hold","recipe":{"picture_context":{"canvases":[{"width":320,"height":180,"fit":"fit","layers":[]}]},"duration":11,"video":{"type":"freeze","asset":"b2868a97-5094-4eb8-9ccd-4a5c904983e0","timestamp":{"ticks":9009,"time_base":{"numerator":1,"denominator":30000}}},"audio":{"type":"silence"}}}}}},"assets":{},"marks":{},"overrides":{},"audio_lineage":{"2edb85c2-83ff-4e7d-894a-bbc001fa8f88":{"before":null,"after":{"allocation":"ed903801-af9a-4875-a6d0-2ffb76eb830f","origin":"2edb85c2-83ff-4e7d-894a-bbc001fa8f88"}},"73b09e6c-178d-48c1-9f43-54960c553afd":{"before":null,"after":{"allocation":"ed903801-af9a-4875-a6d0-2ffb76eb830f","origin":"2edb85c2-83ff-4e7d-894a-bbc001fa8f88"}}},"audio_bindings":{"before":{"timings":[],"bindings":{}},"after":{"timings":[{"id":{"allocation":"ed903801-af9a-4875-a6d0-2ffb76eb830f","ordinal":0},"layout":{"root":"44425a05-dc69-45ff-aedd-26c2356c963a","rate":{"numerator":30000,"denominator":1001},"nodes":{"2edb85c2-83ff-4e7d-894a-bbc001fa8f88":{"duration":120,"edges":{"node_start":"automatic","node_end":"automatic","source_placement_start":"automatic","source_placement_end":"automatic","repeat_gap_start":"automatic","repeat_gap_end":"automatic"},"kind":{"type":"source","placement":{"start":{"numerator":"0","denominator":"1"},"end":{"numerator":"120","denominator":"1"}}}},"44425a05-dc69-45ff-aedd-26c2356c963a":{"duration":120,"edges":{"node_start":"automatic","node_end":"automatic","source_placement_start":"automatic","source_placement_end":"automatic","repeat_gap_start":"automatic","repeat_gap_end":"automatic"},"kind":{"type":"sequence","children":["2edb85c2-83ff-4e7d-894a-bbc001fa8f88"]}}},"overrides":{}}}],"bindings":{"2edb85c2-83ff-4e7d-894a-bbc001fa8f88":{"lattice":{"reference":{"timing":{"allocation":"ed903801-af9a-4875-a6d0-2ffb76eb830f","ordinal":0},"root":{"type":"project_root_round_even"},"physical":"2edb85c2-83ff-4e7d-894a-bbc001fa8f88"},"arguments":[],"births":[]},"resume":null},"73b09e6c-178d-48c1-9f43-54960c553afd":{"lattice":{"reference":{"timing":{"allocation":"ed903801-af9a-4875-a6d0-2ffb76eb830f","ordinal":0},"root":{"type":"project_root_round_even"},"physical":"2edb85c2-83ff-4e7d-894a-bbc001fa8f88"},"arguments":[],"births":[]},"resume":{"local_boundary":{"numerator":"10","denominator":"1"},"phase":{"constant":{"numerator":"0","denominator":"1"},"terms":[{"placement":{"reference":{"timing":{"allocation":"ed903801-af9a-4875-a6d0-2ffb76eb830f","ordinal":0},"root":{"type":"project_root_round_even"},"physical":"2edb85c2-83ff-4e7d-894a-bbc001fa8f88"},"arguments":[],"births":[]},"from_local":{"numerator":"0","denominator":"1"},"to_local":{"numerator":"10","denominator":"1"}}]}}}}}}},"inverse":{"project_id":"e6d1ba97-2db0-4119-9e5d-e4a4bef3e078","from_revision":"ed903801-af9a-4875-a6d0-2ffb76eb830f","to_revision":"01a31893-138e-4642-b20e-02a2e82c7228","nodes":{"44425a05-dc69-45ff-aedd-26c2356c963a":{"before":{"label":"Sequence","kind":{"type":"sequence","children":["4de01272-0476-425e-9ba1-c63b46aa4012","b0131c13-21a8-452e-80f8-03b53f60f52e","6d77dc13-c463-476e-ad1c-948bf919538b"]}},"after":{"label":"Sequence","kind":{"type":"sequence","children":["2edb85c2-83ff-4e7d-894a-bbc001fa8f88"]}}},"4de01272-0476-425e-9ba1-c63b46aa4012":{"before":{"label":"cfr-bframes.mp4","kind":{"type":"retime","child":"2edb85c2-83ff-4e7d-894a-bbc001fa8f88","duration":10,"mapping":{"start":0,"end":10},"pitch":"preserve","purpose":"partition"}},"after":null},"6d77dc13-c463-476e-ad1c-948bf919538b":{"before":{"label":"cfr-bframes.mp4","kind":{"type":"retime","child":"73b09e6c-178d-48c1-9f43-54960c553afd","duration":110,"mapping":{"start":10,"end":120},"pitch":"preserve","purpose":"partition"}},"after":null},"73b09e6c-178d-48c1-9f43-54960c553afd":{"before":{"label":"cfr-bframes.mp4","kind":{"type":"source","source":{"duration":120,"edit_window":{"start":{"numerator":"0","denominator":"1"},"end":{"numerator":"120","denominator":"1"}},"video":{"type":"stream","asset":"b2868a97-5094-4eb8-9ccd-4a5c904983e0","span":{"start":{"ticks":0,"time_base":{"numerator":1,"denominator":30000}},"end":{"ticks":120120,"time_base":{"numerator":1,"denominator":30000}}}},"video_mapping":{"type":"placement","start":{"numerator":"0","denominator":"1"},"frames":{"numerator":"120","denominator":"1"},"endpoints":"hold_adjacent"},"audio":{"asset":"b2868a97-5094-4eb8-9ccd-4a5c904983e0","span":{"start":{"ticks":0,"time_base":{"numerator":1,"denominator":48000}},"end":{"ticks":192192,"time_base":{"numerator":1,"denominator":48000}}}},"audio_mapping":{"type":"placement","start":{"numerator":"0","denominator":"1"},"frames":{"numerator":"120","denominator":"1"}},"link":"linked","audio_offset":0}}},"after":null},"b0131c13-21a8-452e-80f8-03b53f60f52e":{"before":{"label":"Pause","kind":{"type":"hold","recipe":{"picture_context":{"canvases":[{"width":320,"height":180,"fit":"fit","layers":[]}]},"duration":11,"video":{"type":"freeze","asset":"b2868a97-5094-4eb8-9ccd-4a5c904983e0","timestamp":{"ticks":9009,"time_base":{"numerator":1,"denominator":30000}}},"audio":{"type":"silence"}}}},"after":null}},"assets":{},"marks":{},"overrides":{},"audio_lineage":{"2edb85c2-83ff-4e7d-894a-bbc001fa8f88":{"before":{"allocation":"ed903801-af9a-4875-a6d0-2ffb76eb830f","origin":"2edb85c2-83ff-4e7d-894a-bbc001fa8f88"},"after":null},"73b09e6c-178d-48c1-9f43-54960c553afd":{"before":{"allocation":"ed903801-af9a-4875-a6d0-2ffb76eb830f","origin":"2edb85c2-83ff-4e7d-894a-bbc001fa8f88"},"after":null}},"audio_bindings":{"before":{"timings":[{"id":{"allocation":"ed903801-af9a-4875-a6d0-2ffb76eb830f","ordinal":0},"layout":{"root":"44425a05-dc69-45ff-aedd-26c2356c963a","rate":{"numerator":30000,"denominator":1001},"nodes":{"2edb85c2-83ff-4e7d-894a-bbc001fa8f88":{"duration":120,"edges":{"node_start":"automatic","node_end":"automatic","source_placement_start":"automatic","source_placement_end":"automatic","repeat_gap_start":"automatic","repeat_gap_end":"automatic"},"kind":{"type":"source","placement":{"start":{"numerator":"0","denominator":"1"},"end":{"numerator":"120","denominator":"1"}}}},"44425a05-dc69-45ff-aedd-26c2356c963a":{"duration":120,"edges":{"node_start":"automatic","node_end":"automatic","source_placement_start":"automatic","source_placement_end":"automatic","repeat_gap_start":"automatic","repeat_gap_end":"automatic"},"kind":{"type":"sequence","children":["2edb85c2-83ff-4e7d-894a-bbc001fa8f88"]}}},"overrides":{}}}],"bindings":{"2edb85c2-83ff-4e7d-894a-bbc001fa8f88":{"lattice":{"reference":{"timing":{"allocation":"ed903801-af9a-4875-a6d0-2ffb76eb830f","ordinal":0},"root":{"type":"project_root_round_even"},"physical":"2edb85c2-83ff-4e7d-894a-bbc001fa8f88"},"arguments":[],"births":[]},"resume":null},"73b09e6c-178d-48c1-9f43-54960c553afd":{"lattice":{"reference":{"timing":{"allocation":"ed903801-af9a-4875-a6d0-2ffb76eb830f","ordinal":0},"root":{"type":"project_root_round_even"},"physical":"2edb85c2-83ff-4e7d-894a-bbc001fa8f88"},"arguments":[],"births":[]},"resume":{"local_boundary":{"numerator":"10","denominator":"1"},"phase":{"constant":{"numerator":"0","denominator":"1"},"terms":[{"placement":{"reference":{"timing":{"allocation":"ed903801-af9a-4875-a6d0-2ffb76eb830f","ordinal":0},"root":{"type":"project_root_round_even"},"physical":"2edb85c2-83ff-4e7d-894a-bbc001fa8f88"},"arguments":[],"births":[]},"from_local":{"numerator":"0","denominator":"1"},"to_local":{"numerator":"10","denominator":"1"}}]}}}}},"after":{"timings":[],"bindings":{}}}},"changed_ids":["2edb85c2-83ff-4e7d-894a-bbc001fa8f88","44425a05-dc69-45ff-aedd-26c2356c963a","4de01272-0476-425e-9ba1-c63b46aa4012","6d77dc13-c463-476e-ad1c-948bf919538b","73b09e6c-178d-48c1-9f43-54960c553afd","b0131c13-21a8-452e-80f8-03b53f60f52e"],"duration_delta":11,"description":"Insert pause"}');
INSERT INTO "history" VALUES(5,1,'d520ef8e-cf47-45a7-8adb-003d9f5422b6','{"project_id":"e6d1ba97-2db0-4119-9e5d-e4a4bef3e078","expected_revision":"1d20a800-7630-447c-8919-9d8c2e80f7e1","new_revision":"d520ef8e-cf47-45a7-8adb-003d9f5422b6","command":{"command":"splice_slice","parent":"44425a05-dc69-45ff-aedd-26c2356c963a","index":1,"slice":{"project_id":"e6d1ba97-2db0-4119-9e5d-e4a4bef3e078","revision_id":"ed903801-af9a-4875-a6d0-2ffb76eb830f","capture_timing":{"allocation":"1fc4c43f-6c56-4450-857a-0fb258ce2a86","ordinal":0},"presentation_basis":{"width":320,"height":180,"frame_rate":{"numerator":30000,"denominator":1001},"color_policy":"sdr_rec709"},"parent":"44425a05-dc69-45ff-aedd-26c2356c963a","range":{"start":8,"end":25},"source_duration":131,"parts":[{"root":"4de01272-0476-425e-9ba1-c63b46aa4012","mapping":{"start":8,"end":10},"source_start":0},{"root":"b0131c13-21a8-452e-80f8-03b53f60f52e","mapping":{"start":0,"end":11},"source_start":10},{"root":"6d77dc13-c463-476e-ad1c-948bf919538b","mapping":{"start":0,"end":4},"source_start":21}],"nodes":{"2edb85c2-83ff-4e7d-894a-bbc001fa8f88":{"label":"cfr-bframes.mp4","kind":{"type":"source","source":{"duration":120,"edit_window":{"start":{"numerator":"0","denominator":"1"},"end":{"numerator":"120","denominator":"1"}},"video":{"type":"stream","asset":"b2868a97-5094-4eb8-9ccd-4a5c904983e0","span":{"start":{"ticks":0,"time_base":{"numerator":1,"denominator":30000}},"end":{"ticks":120120,"time_base":{"numerator":1,"denominator":30000}}}},"video_mapping":{"type":"placement","start":{"numerator":"0","denominator":"1"},"frames":{"numerator":"120","denominator":"1"},"endpoints":"hold_adjacent"},"audio":{"asset":"b2868a97-5094-4eb8-9ccd-4a5c904983e0","span":{"start":{"ticks":0,"time_base":{"numerator":1,"denominator":48000}},"end":{"ticks":192192,"time_base":{"numerator":1,"denominator":48000}}}},"audio_mapping":{"type":"placement","start":{"numerator":"0","denominator":"1"},"frames":{"numerator":"120","denominator":"1"}},"link":"linked","audio_offset":0}}},"4de01272-0476-425e-9ba1-c63b46aa4012":{"label":"cfr-bframes.mp4","kind":{"type":"retime","child":"2edb85c2-83ff-4e7d-894a-bbc001fa8f88","duration":10,"mapping":{"start":0,"end":10},"pitch":"preserve","purpose":"partition"}},"6d77dc13-c463-476e-ad1c-948bf919538b":{"label":"cfr-bframes.mp4","kind":{"type":"retime","child":"73b09e6c-178d-48c1-9f43-54960c553afd","duration":110,"mapping":{"start":10,"end":120},"pitch":"preserve","purpose":"partition"}},"73b09e6c-178d-48c1-9f43-54960c553afd":{"label":"cfr-bframes.mp4","kind":{"type":"source","source":{"duration":120,"edit_window":{"start":{"numerator":"0","denominator":"1"},"end":{"numerator":"120","denominator":"1"}},"video":{"type":"stream","asset":"b2868a97-5094-4eb8-9ccd-4a5c904983e0","span":{"start":{"ticks":0,"time_base":{"numerator":1,"denominator":30000}},"end":{"ticks":120120,"time_base":{"numerator":1,"denominator":30000}}}},"video_mapping":{"type":"placement","start":{"numerator":"0","denominator":"1"},"frames":{"numerator":"120","denominator":"1"},"endpoints":"hold_adjacent"},"audio":{"asset":"b2868a97-5094-4eb8-9ccd-4a5c904983e0","span":{"start":{"ticks":0,"time_base":{"numerator":1,"denominator":48000}},"end":{"ticks":192192,"time_base":{"numerator":1,"denominator":48000}}}},"audio_mapping":{"type":"placement","start":{"numerator":"0","denominator":"1"},"frames":{"numerator":"120","denominator":"1"}},"link":"linked","audio_offset":0}}},"b0131c13-21a8-452e-80f8-03b53f60f52e":{"label":"Pause","kind":{"type":"hold","recipe":{"picture_context":{"canvases":[{"width":320,"height":180,"fit":"fit","layers":[]}]},"duration":11,"video":{"type":"freeze","asset":"b2868a97-5094-4eb8-9ccd-4a5c904983e0","timestamp":{"ticks":9009,"time_base":{"numerator":1,"denominator":30000}}},"audio":{"type":"silence"}}}}},"assets":{"b2868a97-5094-4eb8-9ccd-4a5c904983e0":{"label":"cfr-bframes.mp4","content_hash":"blake3:16614ec12d06396d3c0f0e7b91cc902c6dc30ad89c28d74b805cf64dc60d8aa1","video":{"start":{"ticks":0,"time_base":{"numerator":1,"denominator":30000}},"end":{"ticks":120120,"time_base":{"numerator":1,"denominator":30000}}},"audio":{"start":{"ticks":0,"time_base":{"numerator":1,"denominator":48000}},"end":{"ticks":192192,"time_base":{"numerator":1,"denominator":48000}}},"still_image":false,"frame_count":120,"source_qualification":"c6bc3e81ab69906267164469d11739cf1363eea546436761ddd219069ed496b6"}},"marks":{},"overrides":{},"gap_overrides":{},"audio_lineage":{"2edb85c2-83ff-4e7d-894a-bbc001fa8f88":{"allocation":"ed903801-af9a-4875-a6d0-2ffb76eb830f","origin":"2edb85c2-83ff-4e7d-894a-bbc001fa8f88"},"73b09e6c-178d-48c1-9f43-54960c553afd":{"allocation":"ed903801-af9a-4875-a6d0-2ffb76eb830f","origin":"2edb85c2-83ff-4e7d-894a-bbc001fa8f88"}},"audio_bindings":{"timings":[{"id":{"allocation":"1fc4c43f-6c56-4450-857a-0fb258ce2a86","ordinal":0},"layout":{"root":"44425a05-dc69-45ff-aedd-26c2356c963a","rate":{"numerator":30000,"denominator":1001},"nodes":{"2edb85c2-83ff-4e7d-894a-bbc001fa8f88":{"duration":120,"edges":{"node_start":"automatic","node_end":"automatic","source_placement_start":"automatic","source_placement_end":"automatic","repeat_gap_start":"automatic","repeat_gap_end":"automatic"},"kind":{"type":"source","placement":{"start":{"numerator":"0","denominator":"1"},"end":{"numerator":"120","denominator":"1"}}}},"44425a05-dc69-45ff-aedd-26c2356c963a":{"duration":131,"edges":{"node_start":"automatic","node_end":"automatic","source_placement_start":"automatic","source_placement_end":"automatic","repeat_gap_start":"automatic","repeat_gap_end":"automatic"},"kind":{"type":"sequence","children":["4de01272-0476-425e-9ba1-c63b46aa4012","b0131c13-21a8-452e-80f8-03b53f60f52e","6d77dc13-c463-476e-ad1c-948bf919538b"]}},"4de01272-0476-425e-9ba1-c63b46aa4012":{"duration":10,"edges":{"node_start":"automatic","node_end":"automatic","source_placement_start":"automatic","source_placement_end":"automatic","repeat_gap_start":"automatic","repeat_gap_end":"automatic"},"kind":{"type":"retime","child":"2edb85c2-83ff-4e7d-894a-bbc001fa8f88","mapping":{"start":0,"end":10},"pitch":"preserve","purpose":"partition"}},"6d77dc13-c463-476e-ad1c-948bf919538b":{"duration":110,"edges":{"node_start":"automatic","node_end":"automatic","source_placement_start":"automatic","source_placement_end":"automatic","repeat_gap_start":"automatic","repeat_gap_end":"automatic"},"kind":{"type":"retime","child":"73b09e6c-178d-48c1-9f43-54960c553afd","mapping":{"start":10,"end":120},"pitch":"preserve","purpose":"partition"}},"73b09e6c-178d-48c1-9f43-54960c553afd":{"duration":120,"edges":{"node_start":"automatic","node_end":"automatic","source_placement_start":"automatic","source_placement_end":"automatic","repeat_gap_start":"automatic","repeat_gap_end":"automatic"},"kind":{"type":"source","placement":{"start":{"numerator":"0","denominator":"1"},"end":{"numerator":"120","denominator":"1"}}}},"b0131c13-21a8-452e-80f8-03b53f60f52e":{"duration":11,"edges":{"node_start":"automatic","node_end":"automatic","source_placement_start":"automatic","source_placement_end":"automatic","repeat_gap_start":"automatic","repeat_gap_end":"automatic"},"kind":{"type":"hold","audio":{"type":"silence"}}}},"overrides":{},"audio_lineage":{"2edb85c2-83ff-4e7d-894a-bbc001fa8f88":{"allocation":"ed903801-af9a-4875-a6d0-2ffb76eb830f","origin":"2edb85c2-83ff-4e7d-894a-bbc001fa8f88"},"73b09e6c-178d-48c1-9f43-54960c553afd":{"allocation":"ed903801-af9a-4875-a6d0-2ffb76eb830f","origin":"2edb85c2-83ff-4e7d-894a-bbc001fa8f88"}}}},{"id":{"allocation":"ed903801-af9a-4875-a6d0-2ffb76eb830f","ordinal":0},"layout":{"root":"44425a05-dc69-45ff-aedd-26c2356c963a","rate":{"numerator":30000,"denominator":1001},"nodes":{"2edb85c2-83ff-4e7d-894a-bbc001fa8f88":{"duration":120,"edges":{"node_start":"automatic","node_end":"automatic","source_placement_start":"automatic","source_placement_end":"automatic","repeat_gap_start":"automatic","repeat_gap_end":"automatic"},"kind":{"type":"source","placement":{"start":{"numerator":"0","denominator":"1"},"end":{"numerator":"120","denominator":"1"}}}},"44425a05-dc69-45ff-aedd-26c2356c963a":{"duration":120,"edges":{"node_start":"automatic","node_end":"automatic","source_placement_start":"automatic","source_placement_end":"automatic","repeat_gap_start":"automatic","repeat_gap_end":"automatic"},"kind":{"type":"sequence","children":["2edb85c2-83ff-4e7d-894a-bbc001fa8f88"]}}},"overrides":{}}}],"bindings":{"2edb85c2-83ff-4e7d-894a-bbc001fa8f88":{"lattice":{"reference":{"timing":{"allocation":"ed903801-af9a-4875-a6d0-2ffb76eb830f","ordinal":0},"root":{"type":"project_root_round_even"},"physical":"2edb85c2-83ff-4e7d-894a-bbc001fa8f88"},"arguments":[],"births":[]},"resume":null,"reanchors":[{"placement":{"reference":{"timing":{"allocation":"1fc4c43f-6c56-4450-857a-0fb258ce2a86","ordinal":0},"root":{"type":"project_root_round_even"},"physical":"2edb85c2-83ff-4e7d-894a-bbc001fa8f88"},"arguments":[],"births":[]},"window":{"start":{"numerator":"8","denominator":"1"},"end":{"numerator":"25","denominator":"1"}}}]},"73b09e6c-178d-48c1-9f43-54960c553afd":{"lattice":{"reference":{"timing":{"allocation":"ed903801-af9a-4875-a6d0-2ffb76eb830f","ordinal":0},"root":{"type":"project_root_round_even"},"physical":"2edb85c2-83ff-4e7d-894a-bbc001fa8f88"},"arguments":[],"births":[]},"resume":{"local_boundary":{"numerator":"10","denominator":"1"},"phase":{"constant":{"numerator":"0","denominator":"1"},"terms":[{"placement":{"reference":{"timing":{"allocation":"ed903801-af9a-4875-a6d0-2ffb76eb830f","ordinal":0},"root":{"type":"project_root_round_even"},"physical":"2edb85c2-83ff-4e7d-894a-bbc001fa8f88"},"arguments":[],"births":[]},"from_local":{"numerator":"0","denominator":"1"},"to_local":{"numerator":"10","denominator":"1"}}]}},"reanchors":[{"placement":{"reference":{"timing":{"allocation":"1fc4c43f-6c56-4450-857a-0fb258ce2a86","ordinal":0},"root":{"type":"project_root_round_even"},"physical":"73b09e6c-178d-48c1-9f43-54960c553afd"},"arguments":[],"births":[]},"window":{"start":{"numerator":"8","denominator":"1"},"end":{"numerator":"25","denominator":"1"}}}]},"b0131c13-21a8-452e-80f8-03b53f60f52e":{"lattice":{"reference":{"timing":{"allocation":"1fc4c43f-6c56-4450-857a-0fb258ce2a86","ordinal":0},"root":{"type":"project_root_round_even"},"physical":"b0131c13-21a8-452e-80f8-03b53f60f52e"},"arguments":[],"births":[]},"resume":null,"reanchors":[{"placement":{"reference":{"timing":{"allocation":"1fc4c43f-6c56-4450-857a-0fb258ce2a86","ordinal":0},"root":{"type":"project_root_round_even"},"physical":"b0131c13-21a8-452e-80f8-03b53f60f52e"},"arguments":[],"births":[]},"window":{"start":{"numerator":"8","denominator":"1"},"end":{"numerator":"25","denominator":"1"}}}]}}}},"identities":{"authored":{"nodes":["7459517b-a5ea-470f-be8d-e441d3c67fc5","76aeaee7-bfeb-4a0a-a391-eb4d7c56db99","6e2031ed-997e-494f-aaaf-7a6d062eae3f","abbfc3e8-9429-495a-b888-b83ad57b4e7d","4fd9d4c4-40fd-455b-a7cd-c3339c1eb5c5","61cc923a-da53-4959-803c-ffc6abff742d","920058f6-2462-4645-93cf-400baf3230cd","b4b61067-f870-4b1a-a5f8-5bfbb4810576"],"marks":[]},"aliases":["1a4c5485-9fcf-4bff-8257-e7ba9792ee4f","777fd7c5-3356-4dd0-b297-252425ccb260","cf654917-686b-415c-9619-6ca5dad8ccb1","f5f78dc9-00a3-414c-a005-ab5b0326dd8e","903535fb-d6d6-4ef4-a7f8-ea937f9d7233","de1b8bc5-07f0-476a-94ae-75587fff648a","d8b5f5ee-b1b0-4d33-9ee9-9cf5c5781709","6ce2fb3a-ac78-4297-b384-aa2c3250d05c","5008d98f-9f8c-4aec-b0ba-990897f605d8"]},"timing":{"allocation":"d520ef8e-cf47-45a7-8adb-003d9f5422b6","ordinal":0}}}','{"forward":{"project_id":"e6d1ba97-2db0-4119-9e5d-e4a4bef3e078","from_revision":"1d20a800-7630-447c-8919-9d8c2e80f7e1","to_revision":"d520ef8e-cf47-45a7-8adb-003d9f5422b6","nodes":{"44425a05-dc69-45ff-aedd-26c2356c963a":{"before":{"label":"Sequence","kind":{"type":"sequence","children":["2edb85c2-83ff-4e7d-894a-bbc001fa8f88"]}},"after":{"label":"Sequence","kind":{"type":"sequence","children":["2edb85c2-83ff-4e7d-894a-bbc001fa8f88","7459517b-a5ea-470f-be8d-e441d3c67fc5"]}}},"4fd9d4c4-40fd-455b-a7cd-c3339c1eb5c5":{"before":null,"after":{"label":"cfr-bframes.mp4","kind":{"type":"source","source":{"duration":120,"edit_window":{"start":{"numerator":"0","denominator":"1"},"end":{"numerator":"120","denominator":"1"}},"video":{"type":"stream","asset":"b2868a97-5094-4eb8-9ccd-4a5c904983e0","span":{"start":{"ticks":0,"time_base":{"numerator":1,"denominator":30000}},"end":{"ticks":120120,"time_base":{"numerator":1,"denominator":30000}}}},"video_mapping":{"type":"placement","start":{"numerator":"0","denominator":"1"},"frames":{"numerator":"120","denominator":"1"},"endpoints":"hold_adjacent"},"audio":{"asset":"b2868a97-5094-4eb8-9ccd-4a5c904983e0","span":{"start":{"ticks":0,"time_base":{"numerator":1,"denominator":48000}},"end":{"ticks":192192,"time_base":{"numerator":1,"denominator":48000}}}},"audio_mapping":{"type":"placement","start":{"numerator":"0","denominator":"1"},"frames":{"numerator":"120","denominator":"1"}},"link":"linked","audio_offset":0}}}},"61cc923a-da53-4959-803c-ffc6abff742d":{"before":null,"after":{"label":"Pause","kind":{"type":"hold","recipe":{"picture_context":{"canvases":[{"width":320,"height":180,"fit":"fit","layers":[]}]},"duration":11,"video":{"type":"freeze","asset":"b2868a97-5094-4eb8-9ccd-4a5c904983e0","timestamp":{"ticks":9009,"time_base":{"numerator":1,"denominator":30000}}},"audio":{"type":"silence"}}}}},"6e2031ed-997e-494f-aaaf-7a6d062eae3f":{"before":null,"after":{"label":"cfr-bframes.mp4","kind":{"type":"retime","child":"76aeaee7-bfeb-4a0a-a391-eb4d7c56db99","duration":10,"mapping":{"start":0,"end":10},"pitch":"preserve","purpose":"partition"}}},"7459517b-a5ea-470f-be8d-e441d3c67fc5":{"before":null,"after":{"label":"Copied contents","kind":{"type":"sequence","children":["920058f6-2462-4645-93cf-400baf3230cd","61cc923a-da53-4959-803c-ffc6abff742d","b4b61067-f870-4b1a-a5f8-5bfbb4810576"]}}},"76aeaee7-bfeb-4a0a-a391-eb4d7c56db99":{"before":null,"after":{"label":"cfr-bframes.mp4","kind":{"type":"source","source":{"duration":120,"edit_window":{"start":{"numerator":"0","denominator":"1"},"end":{"numerator":"120","denominator":"1"}},"video":{"type":"stream","asset":"b2868a97-5094-4eb8-9ccd-4a5c904983e0","span":{"start":{"ticks":0,"time_base":{"numerator":1,"denominator":30000}},"end":{"ticks":120120,"time_base":{"numerator":1,"denominator":30000}}}},"video_mapping":{"type":"placement","start":{"numerator":"0","denominator":"1"},"frames":{"numerator":"120","denominator":"1"},"endpoints":"hold_adjacent"},"audio":{"asset":"b2868a97-5094-4eb8-9ccd-4a5c904983e0","span":{"start":{"ticks":0,"time_base":{"numerator":1,"denominator":48000}},"end":{"ticks":192192,"time_base":{"numerator":1,"denominator":48000}}}},"audio_mapping":{"type":"placement","start":{"numerator":"0","denominator":"1"},"frames":{"numerator":"120","denominator":"1"}},"link":"linked","audio_offset":0}}}},"920058f6-2462-4645-93cf-400baf3230cd":{"before":null,"after":{"label":"Copied interval","kind":{"type":"retime","child":"6e2031ed-997e-494f-aaaf-7a6d062eae3f","duration":2,"mapping":{"start":8,"end":10},"pitch":"preserve","purpose":"partition"}}},"abbfc3e8-9429-495a-b888-b83ad57b4e7d":{"before":null,"after":{"label":"cfr-bframes.mp4","kind":{"type":"retime","child":"4fd9d4c4-40fd-455b-a7cd-c3339c1eb5c5","duration":110,"mapping":{"start":10,"end":120},"pitch":"preserve","purpose":"partition"}}},"b4b61067-f870-4b1a-a5f8-5bfbb4810576":{"before":null,"after":{"label":"Copied interval","kind":{"type":"retime","child":"abbfc3e8-9429-495a-b888-b83ad57b4e7d","duration":4,"mapping":{"start":0,"end":4},"pitch":"preserve","purpose":"partition"}}}},"assets":{},"marks":{},"overrides":{},"audio_lineage":{"4fd9d4c4-40fd-455b-a7cd-c3339c1eb5c5":{"before":null,"after":{"allocation":"d520ef8e-cf47-45a7-8adb-003d9f5422b6","origin":"5008d98f-9f8c-4aec-b0ba-990897f605d8"}},"76aeaee7-bfeb-4a0a-a391-eb4d7c56db99":{"before":null,"after":{"allocation":"d520ef8e-cf47-45a7-8adb-003d9f5422b6","origin":"5008d98f-9f8c-4aec-b0ba-990897f605d8"}}},"audio_bindings":{"before":{"timings":[],"bindings":{}},"after":{"timings":[{"id":{"allocation":"d520ef8e-cf47-45a7-8adb-003d9f5422b6","ordinal":0},"layout":{"root":"44425a05-dc69-45ff-aedd-26c2356c963a","rate":{"numerator":30000,"denominator":1001},"nodes":{"2edb85c2-83ff-4e7d-894a-bbc001fa8f88":{"duration":120,"edges":{"node_start":"automatic","node_end":"automatic","source_placement_start":"automatic","source_placement_end":"automatic","repeat_gap_start":"automatic","repeat_gap_end":"automatic"},"kind":{"type":"source","placement":{"start":{"numerator":"0","denominator":"1"},"end":{"numerator":"120","denominator":"1"}}}},"44425a05-dc69-45ff-aedd-26c2356c963a":{"duration":120,"edges":{"node_start":"automatic","node_end":"automatic","source_placement_start":"automatic","source_placement_end":"automatic","repeat_gap_start":"automatic","repeat_gap_end":"automatic"},"kind":{"type":"sequence","children":["2edb85c2-83ff-4e7d-894a-bbc001fa8f88"]}}},"overrides":{}}},{"id":{"allocation":"d520ef8e-cf47-45a7-8adb-003d9f5422b6","ordinal":1},"layout":{"root":"777fd7c5-3356-4dd0-b297-252425ccb260","rate":{"numerator":30000,"denominator":1001},"nodes":{"1a4c5485-9fcf-4bff-8257-e7ba9792ee4f":{"duration":120,"edges":{"node_start":"automatic","node_end":"automatic","source_placement_start":"automatic","source_placement_end":"automatic","repeat_gap_start":"automatic","repeat_gap_end":"automatic"},"kind":{"type":"source","placement":{"start":{"numerator":"0","denominator":"1"},"end":{"numerator":"120","denominator":"1"}}}},"777fd7c5-3356-4dd0-b297-252425ccb260":{"duration":131,"edges":{"node_start":"automatic","node_end":"automatic","source_placement_start":"automatic","source_placement_end":"automatic","repeat_gap_start":"automatic","repeat_gap_end":"automatic"},"kind":{"type":"sequence","children":["cf654917-686b-415c-9619-6ca5dad8ccb1","de1b8bc5-07f0-476a-94ae-75587fff648a","f5f78dc9-00a3-414c-a005-ab5b0326dd8e"]}},"903535fb-d6d6-4ef4-a7f8-ea937f9d7233":{"duration":120,"edges":{"node_start":"automatic","node_end":"automatic","source_placement_start":"automatic","source_placement_end":"automatic","repeat_gap_start":"automatic","repeat_gap_end":"automatic"},"kind":{"type":"source","placement":{"start":{"numerator":"0","denominator":"1"},"end":{"numerator":"120","denominator":"1"}}}},"cf654917-686b-415c-9619-6ca5dad8ccb1":{"duration":10,"edges":{"node_start":"automatic","node_end":"automatic","source_placement_start":"automatic","source_placement_end":"automatic","repeat_gap_start":"automatic","repeat_gap_end":"automatic"},"kind":{"type":"retime","child":"1a4c5485-9fcf-4bff-8257-e7ba9792ee4f","mapping":{"start":0,"end":10},"pitch":"preserve","purpose":"partition"}},"de1b8bc5-07f0-476a-94ae-75587fff648a":{"duration":11,"edges":{"node_start":"automatic","node_end":"automatic","source_placement_start":"automatic","source_placement_end":"automatic","repeat_gap_start":"automatic","repeat_gap_end":"automatic"},"kind":{"type":"hold","audio":{"type":"silence"}}},"f5f78dc9-00a3-414c-a005-ab5b0326dd8e":{"duration":110,"edges":{"node_start":"automatic","node_end":"automatic","source_placement_start":"automatic","source_placement_end":"automatic","repeat_gap_start":"automatic","repeat_gap_end":"automatic"},"kind":{"type":"retime","child":"903535fb-d6d6-4ef4-a7f8-ea937f9d7233","mapping":{"start":10,"end":120},"pitch":"preserve","purpose":"partition"}}},"overrides":{},"audio_lineage":{"1a4c5485-9fcf-4bff-8257-e7ba9792ee4f":{"allocation":"d520ef8e-cf47-45a7-8adb-003d9f5422b6","origin":"5008d98f-9f8c-4aec-b0ba-990897f605d8"},"903535fb-d6d6-4ef4-a7f8-ea937f9d7233":{"allocation":"d520ef8e-cf47-45a7-8adb-003d9f5422b6","origin":"5008d98f-9f8c-4aec-b0ba-990897f605d8"}}}},{"id":{"allocation":"d520ef8e-cf47-45a7-8adb-003d9f5422b6","ordinal":2},"layout":{"root":"6ce2fb3a-ac78-4297-b384-aa2c3250d05c","rate":{"numerator":30000,"denominator":1001},"nodes":{"6ce2fb3a-ac78-4297-b384-aa2c3250d05c":{"duration":120,"edges":{"node_start":"automatic","node_end":"automatic","source_placement_start":"automatic","source_placement_end":"automatic","repeat_gap_start":"automatic","repeat_gap_end":"automatic"},"kind":{"type":"sequence","children":["d8b5f5ee-b1b0-4d33-9ee9-9cf5c5781709"]}},"d8b5f5ee-b1b0-4d33-9ee9-9cf5c5781709":{"duration":120,"edges":{"node_start":"automatic","node_end":"automatic","source_placement_start":"automatic","source_placement_end":"automatic","repeat_gap_start":"automatic","repeat_gap_end":"automatic"},"kind":{"type":"source","placement":{"start":{"numerator":"0","denominator":"1"},"end":{"numerator":"120","denominator":"1"}}}}},"overrides":{}}}],"bindings":{"2edb85c2-83ff-4e7d-894a-bbc001fa8f88":{"lattice":{"reference":{"timing":{"allocation":"d520ef8e-cf47-45a7-8adb-003d9f5422b6","ordinal":0},"root":{"type":"project_root_round_even"},"physical":"2edb85c2-83ff-4e7d-894a-bbc001fa8f88"},"arguments":[],"births":[]},"resume":null},"4fd9d4c4-40fd-455b-a7cd-c3339c1eb5c5":{"lattice":{"reference":{"timing":{"allocation":"d520ef8e-cf47-45a7-8adb-003d9f5422b6","ordinal":2},"root":{"type":"project_root_round_even"},"physical":"d8b5f5ee-b1b0-4d33-9ee9-9cf5c5781709"},"arguments":[],"births":[]},"resume":{"local_boundary":{"numerator":"10","denominator":"1"},"phase":{"constant":{"numerator":"0","denominator":"1"},"terms":[{"placement":{"reference":{"timing":{"allocation":"d520ef8e-cf47-45a7-8adb-003d9f5422b6","ordinal":2},"root":{"type":"project_root_round_even"},"physical":"d8b5f5ee-b1b0-4d33-9ee9-9cf5c5781709"},"arguments":[],"births":[]},"from_local":{"numerator":"0","denominator":"1"},"to_local":{"numerator":"10","denominator":"1"}}]}},"reanchors":[{"placement":{"reference":{"timing":{"allocation":"d520ef8e-cf47-45a7-8adb-003d9f5422b6","ordinal":1},"root":{"type":"project_root_round_even"},"physical":"903535fb-d6d6-4ef4-a7f8-ea937f9d7233"},"arguments":[],"births":[]},"window":{"start":{"numerator":"8","denominator":"1"},"end":{"numerator":"25","denominator":"1"}}}]},"61cc923a-da53-4959-803c-ffc6abff742d":{"lattice":{"reference":{"timing":{"allocation":"d520ef8e-cf47-45a7-8adb-003d9f5422b6","ordinal":1},"root":{"type":"project_root_round_even"},"physical":"de1b8bc5-07f0-476a-94ae-75587fff648a"},"arguments":[],"births":[]},"resume":null,"reanchors":[{"placement":{"reference":{"timing":{"allocation":"d520ef8e-cf47-45a7-8adb-003d9f5422b6","ordinal":1},"root":{"type":"project_root_round_even"},"physical":"de1b8bc5-07f0-476a-94ae-75587fff648a"},"arguments":[],"births":[]},"window":{"start":{"numerator":"8","denominator":"1"},"end":{"numerator":"25","denominator":"1"}}}]},"76aeaee7-bfeb-4a0a-a391-eb4d7c56db99":{"lattice":{"reference":{"timing":{"allocation":"d520ef8e-cf47-45a7-8adb-003d9f5422b6","ordinal":2},"root":{"type":"project_root_round_even"},"physical":"d8b5f5ee-b1b0-4d33-9ee9-9cf5c5781709"},"arguments":[],"births":[]},"resume":null,"reanchors":[{"placement":{"reference":{"timing":{"allocation":"d520ef8e-cf47-45a7-8adb-003d9f5422b6","ordinal":1},"root":{"type":"project_root_round_even"},"physical":"1a4c5485-9fcf-4bff-8257-e7ba9792ee4f"},"arguments":[],"births":[]},"window":{"start":{"numerator":"8","denominator":"1"},"end":{"numerator":"25","denominator":"1"}}}]}}}}},"inverse":{"project_id":"e6d1ba97-2db0-4119-9e5d-e4a4bef3e078","from_revision":"d520ef8e-cf47-45a7-8adb-003d9f5422b6","to_revision":"1d20a800-7630-447c-8919-9d8c2e80f7e1","nodes":{"44425a05-dc69-45ff-aedd-26c2356c963a":{"before":{"label":"Sequence","kind":{"type":"sequence","children":["2edb85c2-83ff-4e7d-894a-bbc001fa8f88","7459517b-a5ea-470f-be8d-e441d3c67fc5"]}},"after":{"label":"Sequence","kind":{"type":"sequence","children":["2edb85c2-83ff-4e7d-894a-bbc001fa8f88"]}}},"4fd9d4c4-40fd-455b-a7cd-c3339c1eb5c5":{"before":{"label":"cfr-bframes.mp4","kind":{"type":"source","source":{"duration":120,"edit_window":{"start":{"numerator":"0","denominator":"1"},"end":{"numerator":"120","denominator":"1"}},"video":{"type":"stream","asset":"b2868a97-5094-4eb8-9ccd-4a5c904983e0","span":{"start":{"ticks":0,"time_base":{"numerator":1,"denominator":30000}},"end":{"ticks":120120,"time_base":{"numerator":1,"denominator":30000}}}},"video_mapping":{"type":"placement","start":{"numerator":"0","denominator":"1"},"frames":{"numerator":"120","denominator":"1"},"endpoints":"hold_adjacent"},"audio":{"asset":"b2868a97-5094-4eb8-9ccd-4a5c904983e0","span":{"start":{"ticks":0,"time_base":{"numerator":1,"denominator":48000}},"end":{"ticks":192192,"time_base":{"numerator":1,"denominator":48000}}}},"audio_mapping":{"type":"placement","start":{"numerator":"0","denominator":"1"},"frames":{"numerator":"120","denominator":"1"}},"link":"linked","audio_offset":0}}},"after":null},"61cc923a-da53-4959-803c-ffc6abff742d":{"before":{"label":"Pause","kind":{"type":"hold","recipe":{"picture_context":{"canvases":[{"width":320,"height":180,"fit":"fit","layers":[]}]},"duration":11,"video":{"type":"freeze","asset":"b2868a97-5094-4eb8-9ccd-4a5c904983e0","timestamp":{"ticks":9009,"time_base":{"numerator":1,"denominator":30000}}},"audio":{"type":"silence"}}}},"after":null},"6e2031ed-997e-494f-aaaf-7a6d062eae3f":{"before":{"label":"cfr-bframes.mp4","kind":{"type":"retime","child":"76aeaee7-bfeb-4a0a-a391-eb4d7c56db99","duration":10,"mapping":{"start":0,"end":10},"pitch":"preserve","purpose":"partition"}},"after":null},"7459517b-a5ea-470f-be8d-e441d3c67fc5":{"before":{"label":"Copied contents","kind":{"type":"sequence","children":["920058f6-2462-4645-93cf-400baf3230cd","61cc923a-da53-4959-803c-ffc6abff742d","b4b61067-f870-4b1a-a5f8-5bfbb4810576"]}},"after":null},"76aeaee7-bfeb-4a0a-a391-eb4d7c56db99":{"before":{"label":"cfr-bframes.mp4","kind":{"type":"source","source":{"duration":120,"edit_window":{"start":{"numerator":"0","denominator":"1"},"end":{"numerator":"120","denominator":"1"}},"video":{"type":"stream","asset":"b2868a97-5094-4eb8-9ccd-4a5c904983e0","span":{"start":{"ticks":0,"time_base":{"numerator":1,"denominator":30000}},"end":{"ticks":120120,"time_base":{"numerator":1,"denominator":30000}}}},"video_mapping":{"type":"placement","start":{"numerator":"0","denominator":"1"},"frames":{"numerator":"120","denominator":"1"},"endpoints":"hold_adjacent"},"audio":{"asset":"b2868a97-5094-4eb8-9ccd-4a5c904983e0","span":{"start":{"ticks":0,"time_base":{"numerator":1,"denominator":48000}},"end":{"ticks":192192,"time_base":{"numerator":1,"denominator":48000}}}},"audio_mapping":{"type":"placement","start":{"numerator":"0","denominator":"1"},"frames":{"numerator":"120","denominator":"1"}},"link":"linked","audio_offset":0}}},"after":null},"920058f6-2462-4645-93cf-400baf3230cd":{"before":{"label":"Copied interval","kind":{"type":"retime","child":"6e2031ed-997e-494f-aaaf-7a6d062eae3f","duration":2,"mapping":{"start":8,"end":10},"pitch":"preserve","purpose":"partition"}},"after":null},"abbfc3e8-9429-495a-b888-b83ad57b4e7d":{"before":{"label":"cfr-bframes.mp4","kind":{"type":"retime","child":"4fd9d4c4-40fd-455b-a7cd-c3339c1eb5c5","duration":110,"mapping":{"start":10,"end":120},"pitch":"preserve","purpose":"partition"}},"after":null},"b4b61067-f870-4b1a-a5f8-5bfbb4810576":{"before":{"label":"Copied interval","kind":{"type":"retime","child":"abbfc3e8-9429-495a-b888-b83ad57b4e7d","duration":4,"mapping":{"start":0,"end":4},"pitch":"preserve","purpose":"partition"}},"after":null}},"assets":{},"marks":{},"overrides":{},"audio_lineage":{"4fd9d4c4-40fd-455b-a7cd-c3339c1eb5c5":{"before":{"allocation":"d520ef8e-cf47-45a7-8adb-003d9f5422b6","origin":"5008d98f-9f8c-4aec-b0ba-990897f605d8"},"after":null},"76aeaee7-bfeb-4a0a-a391-eb4d7c56db99":{"before":{"allocation":"d520ef8e-cf47-45a7-8adb-003d9f5422b6","origin":"5008d98f-9f8c-4aec-b0ba-990897f605d8"},"after":null}},"audio_bindings":{"before":{"timings":[{"id":{"allocation":"d520ef8e-cf47-45a7-8adb-003d9f5422b6","ordinal":0},"layout":{"root":"44425a05-dc69-45ff-aedd-26c2356c963a","rate":{"numerator":30000,"denominator":1001},"nodes":{"2edb85c2-83ff-4e7d-894a-bbc001fa8f88":{"duration":120,"edges":{"node_start":"automatic","node_end":"automatic","source_placement_start":"automatic","source_placement_end":"automatic","repeat_gap_start":"automatic","repeat_gap_end":"automatic"},"kind":{"type":"source","placement":{"start":{"numerator":"0","denominator":"1"},"end":{"numerator":"120","denominator":"1"}}}},"44425a05-dc69-45ff-aedd-26c2356c963a":{"duration":120,"edges":{"node_start":"automatic","node_end":"automatic","source_placement_start":"automatic","source_placement_end":"automatic","repeat_gap_start":"automatic","repeat_gap_end":"automatic"},"kind":{"type":"sequence","children":["2edb85c2-83ff-4e7d-894a-bbc001fa8f88"]}}},"overrides":{}}},{"id":{"allocation":"d520ef8e-cf47-45a7-8adb-003d9f5422b6","ordinal":1},"layout":{"root":"777fd7c5-3356-4dd0-b297-252425ccb260","rate":{"numerator":30000,"denominator":1001},"nodes":{"1a4c5485-9fcf-4bff-8257-e7ba9792ee4f":{"duration":120,"edges":{"node_start":"automatic","node_end":"automatic","source_placement_start":"automatic","source_placement_end":"automatic","repeat_gap_start":"automatic","repeat_gap_end":"automatic"},"kind":{"type":"source","placement":{"start":{"numerator":"0","denominator":"1"},"end":{"numerator":"120","denominator":"1"}}}},"777fd7c5-3356-4dd0-b297-252425ccb260":{"duration":131,"edges":{"node_start":"automatic","node_end":"automatic","source_placement_start":"automatic","source_placement_end":"automatic","repeat_gap_start":"automatic","repeat_gap_end":"automatic"},"kind":{"type":"sequence","children":["cf654917-686b-415c-9619-6ca5dad8ccb1","de1b8bc5-07f0-476a-94ae-75587fff648a","f5f78dc9-00a3-414c-a005-ab5b0326dd8e"]}},"903535fb-d6d6-4ef4-a7f8-ea937f9d7233":{"duration":120,"edges":{"node_start":"automatic","node_end":"automatic","source_placement_start":"automatic","source_placement_end":"automatic","repeat_gap_start":"automatic","repeat_gap_end":"automatic"},"kind":{"type":"source","placement":{"start":{"numerator":"0","denominator":"1"},"end":{"numerator":"120","denominator":"1"}}}},"cf654917-686b-415c-9619-6ca5dad8ccb1":{"duration":10,"edges":{"node_start":"automatic","node_end":"automatic","source_placement_start":"automatic","source_placement_end":"automatic","repeat_gap_start":"automatic","repeat_gap_end":"automatic"},"kind":{"type":"retime","child":"1a4c5485-9fcf-4bff-8257-e7ba9792ee4f","mapping":{"start":0,"end":10},"pitch":"preserve","purpose":"partition"}},"de1b8bc5-07f0-476a-94ae-75587fff648a":{"duration":11,"edges":{"node_start":"automatic","node_end":"automatic","source_placement_start":"automatic","source_placement_end":"automatic","repeat_gap_start":"automatic","repeat_gap_end":"automatic"},"kind":{"type":"hold","audio":{"type":"silence"}}},"f5f78dc9-00a3-414c-a005-ab5b0326dd8e":{"duration":110,"edges":{"node_start":"automatic","node_end":"automatic","source_placement_start":"automatic","source_placement_end":"automatic","repeat_gap_start":"automatic","repeat_gap_end":"automatic"},"kind":{"type":"retime","child":"903535fb-d6d6-4ef4-a7f8-ea937f9d7233","mapping":{"start":10,"end":120},"pitch":"preserve","purpose":"partition"}}},"overrides":{},"audio_lineage":{"1a4c5485-9fcf-4bff-8257-e7ba9792ee4f":{"allocation":"d520ef8e-cf47-45a7-8adb-003d9f5422b6","origin":"5008d98f-9f8c-4aec-b0ba-990897f605d8"},"903535fb-d6d6-4ef4-a7f8-ea937f9d7233":{"allocation":"d520ef8e-cf47-45a7-8adb-003d9f5422b6","origin":"5008d98f-9f8c-4aec-b0ba-990897f605d8"}}}},{"id":{"allocation":"d520ef8e-cf47-45a7-8adb-003d9f5422b6","ordinal":2},"layout":{"root":"6ce2fb3a-ac78-4297-b384-aa2c3250d05c","rate":{"numerator":30000,"denominator":1001},"nodes":{"6ce2fb3a-ac78-4297-b384-aa2c3250d05c":{"duration":120,"edges":{"node_start":"automatic","node_end":"automatic","source_placement_start":"automatic","source_placement_end":"automatic","repeat_gap_start":"automatic","repeat_gap_end":"automatic"},"kind":{"type":"sequence","children":["d8b5f5ee-b1b0-4d33-9ee9-9cf5c5781709"]}},"d8b5f5ee-b1b0-4d33-9ee9-9cf5c5781709":{"duration":120,"edges":{"node_start":"automatic","node_end":"automatic","source_placement_start":"automatic","source_placement_end":"automatic","repeat_gap_start":"automatic","repeat_gap_end":"automatic"},"kind":{"type":"source","placement":{"start":{"numerator":"0","denominator":"1"},"end":{"numerator":"120","denominator":"1"}}}}},"overrides":{}}}],"bindings":{"2edb85c2-83ff-4e7d-894a-bbc001fa8f88":{"lattice":{"reference":{"timing":{"allocation":"d520ef8e-cf47-45a7-8adb-003d9f5422b6","ordinal":0},"root":{"type":"project_root_round_even"},"physical":"2edb85c2-83ff-4e7d-894a-bbc001fa8f88"},"arguments":[],"births":[]},"resume":null},"4fd9d4c4-40fd-455b-a7cd-c3339c1eb5c5":{"lattice":{"reference":{"timing":{"allocation":"d520ef8e-cf47-45a7-8adb-003d9f5422b6","ordinal":2},"root":{"type":"project_root_round_even"},"physical":"d8b5f5ee-b1b0-4d33-9ee9-9cf5c5781709"},"arguments":[],"births":[]},"resume":{"local_boundary":{"numerator":"10","denominator":"1"},"phase":{"constant":{"numerator":"0","denominator":"1"},"terms":[{"placement":{"reference":{"timing":{"allocation":"d520ef8e-cf47-45a7-8adb-003d9f5422b6","ordinal":2},"root":{"type":"project_root_round_even"},"physical":"d8b5f5ee-b1b0-4d33-9ee9-9cf5c5781709"},"arguments":[],"births":[]},"from_local":{"numerator":"0","denominator":"1"},"to_local":{"numerator":"10","denominator":"1"}}]}},"reanchors":[{"placement":{"reference":{"timing":{"allocation":"d520ef8e-cf47-45a7-8adb-003d9f5422b6","ordinal":1},"root":{"type":"project_root_round_even"},"physical":"903535fb-d6d6-4ef4-a7f8-ea937f9d7233"},"arguments":[],"births":[]},"window":{"start":{"numerator":"8","denominator":"1"},"end":{"numerator":"25","denominator":"1"}}}]},"61cc923a-da53-4959-803c-ffc6abff742d":{"lattice":{"reference":{"timing":{"allocation":"d520ef8e-cf47-45a7-8adb-003d9f5422b6","ordinal":1},"root":{"type":"project_root_round_even"},"physical":"de1b8bc5-07f0-476a-94ae-75587fff648a"},"arguments":[],"births":[]},"resume":null,"reanchors":[{"placement":{"reference":{"timing":{"allocation":"d520ef8e-cf47-45a7-8adb-003d9f5422b6","ordinal":1},"root":{"type":"project_root_round_even"},"physical":"de1b8bc5-07f0-476a-94ae-75587fff648a"},"arguments":[],"births":[]},"window":{"start":{"numerator":"8","denominator":"1"},"end":{"numerator":"25","denominator":"1"}}}]},"76aeaee7-bfeb-4a0a-a391-eb4d7c56db99":{"lattice":{"reference":{"timing":{"allocation":"d520ef8e-cf47-45a7-8adb-003d9f5422b6","ordinal":2},"root":{"type":"project_root_round_even"},"physical":"d8b5f5ee-b1b0-4d33-9ee9-9cf5c5781709"},"arguments":[],"births":[]},"resume":null,"reanchors":[{"placement":{"reference":{"timing":{"allocation":"d520ef8e-cf47-45a7-8adb-003d9f5422b6","ordinal":1},"root":{"type":"project_root_round_even"},"physical":"1a4c5485-9fcf-4bff-8257-e7ba9792ee4f"},"arguments":[],"births":[]},"window":{"start":{"numerator":"8","denominator":"1"},"end":{"numerator":"25","denominator":"1"}}}]}}},"after":{"timings":[],"bindings":{}}}},"changed_ids":["2edb85c2-83ff-4e7d-894a-bbc001fa8f88","44425a05-dc69-45ff-aedd-26c2356c963a","4fd9d4c4-40fd-455b-a7cd-c3339c1eb5c5","61cc923a-da53-4959-803c-ffc6abff742d","6e2031ed-997e-494f-aaaf-7a6d062eae3f","7459517b-a5ea-470f-be8d-e441d3c67fc5","76aeaee7-bfeb-4a0a-a391-eb4d7c56db99","920058f6-2462-4645-93cf-400baf3230cd","abbfc3e8-9429-495a-b888-b83ad57b4e7d","b4b61067-f870-4b1a-a5f8-5bfbb4810576"],"duration_delta":17,"description":"Paste edited slice"}');
INSERT INTO "history" VALUES(6,1,'0b67ab02-5441-4678-961c-2fcea036a113','{"project_id":"e6d1ba97-2db0-4119-9e5d-e4a4bef3e078","expected_revision":"b5c2fe56-b4d6-42ce-9243-90a7976b1b46","new_revision":"0b67ab02-5441-4678-961c-2fcea036a113","command":{"command":"delete_range","parent":"44425a05-dc69-45ff-aedd-26c2356c963a","range":{"start":20,"end":30},"identities":{"nodes":["7dd5a588-d539-46aa-9868-1bdcf84cefd4","f6586eb2-456d-4936-b238-23c51261abd2","9c665126-cea5-414d-bf18-8dd77ab0ff87","5b713f47-554f-4437-80dd-dd996488a5ce","4c685d21-bde0-48c3-ab42-a50742c23c13"]},"timing":{"allocation":"0b67ab02-5441-4678-961c-2fcea036a113","ordinal":0}}}','{"forward":{"project_id":"e6d1ba97-2db0-4119-9e5d-e4a4bef3e078","from_revision":"b5c2fe56-b4d6-42ce-9243-90a7976b1b46","to_revision":"0b67ab02-5441-4678-961c-2fcea036a113","nodes":{"44425a05-dc69-45ff-aedd-26c2356c963a":{"before":{"label":"Sequence","kind":{"type":"sequence","children":["2edb85c2-83ff-4e7d-894a-bbc001fa8f88"]}},"after":{"label":"Sequence","kind":{"type":"sequence","children":["7dd5a588-d539-46aa-9868-1bdcf84cefd4","5b713f47-554f-4437-80dd-dd996488a5ce"]}}},"4c685d21-bde0-48c3-ab42-a50742c23c13":{"before":null,"after":{"label":"cfr-bframes.mp4","kind":{"type":"source","source":{"duration":120,"edit_window":{"start":{"numerator":"0","denominator":"1"},"end":{"numerator":"120","denominator":"1"}},"video":{"type":"stream","asset":"b2868a97-5094-4eb8-9ccd-4a5c904983e0","span":{"start":{"ticks":0,"time_base":{"numerator":1,"denominator":30000}},"end":{"ticks":120120,"time_base":{"numerator":1,"denominator":30000}}}},"video_mapping":{"type":"placement","start":{"numerator":"0","denominator":"1"},"frames":{"numerator":"120","denominator":"1"},"endpoints":"hold_adjacent"},"audio":{"asset":"b2868a97-5094-4eb8-9ccd-4a5c904983e0","span":{"start":{"ticks":0,"time_base":{"numerator":1,"denominator":48000}},"end":{"ticks":192192,"time_base":{"numerator":1,"denominator":48000}}}},"audio_mapping":{"type":"placement","start":{"numerator":"0","denominator":"1"},"frames":{"numerator":"120","denominator":"1"}},"link":"linked","audio_offset":0}}}},"5b713f47-554f-4437-80dd-dd996488a5ce":{"before":null,"after":{"label":"cfr-bframes.mp4","kind":{"type":"retime","child":"4c685d21-bde0-48c3-ab42-a50742c23c13","duration":90,"mapping":{"start":30,"end":120},"pitch":"preserve","purpose":"partition"}}},"7dd5a588-d539-46aa-9868-1bdcf84cefd4":{"before":null,"after":{"label":"cfr-bframes.mp4","kind":{"type":"retime","child":"2edb85c2-83ff-4e7d-894a-bbc001fa8f88","duration":20,"mapping":{"start":0,"end":20},"pitch":"preserve","purpose":"partition"}}}},"assets":{},"marks":{},"overrides":{},"audio_lineage":{"2edb85c2-83ff-4e7d-894a-bbc001fa8f88":{"before":null,"after":{"allocation":"0b67ab02-5441-4678-961c-2fcea036a113","origin":"2edb85c2-83ff-4e7d-894a-bbc001fa8f88"}},"4c685d21-bde0-48c3-ab42-a50742c23c13":{"before":null,"after":{"allocation":"0b67ab02-5441-4678-961c-2fcea036a113","origin":"2edb85c2-83ff-4e7d-894a-bbc001fa8f88"}}},"audio_bindings":{"before":{"timings":[],"bindings":{}},"after":{"timings":[{"id":{"allocation":"0b67ab02-5441-4678-961c-2fcea036a113","ordinal":0},"layout":{"root":"44425a05-dc69-45ff-aedd-26c2356c963a","rate":{"numerator":30000,"denominator":1001},"nodes":{"2edb85c2-83ff-4e7d-894a-bbc001fa8f88":{"duration":120,"edges":{"node_start":"automatic","node_end":"automatic","source_placement_start":"automatic","source_placement_end":"automatic","repeat_gap_start":"automatic","repeat_gap_end":"automatic"},"kind":{"type":"source","placement":{"start":{"numerator":"0","denominator":"1"},"end":{"numerator":"120","denominator":"1"}}}},"44425a05-dc69-45ff-aedd-26c2356c963a":{"duration":120,"edges":{"node_start":"automatic","node_end":"automatic","source_placement_start":"automatic","source_placement_end":"automatic","repeat_gap_start":"automatic","repeat_gap_end":"automatic"},"kind":{"type":"sequence","children":["2edb85c2-83ff-4e7d-894a-bbc001fa8f88"]}}},"overrides":{}}},{"id":{"allocation":"0b67ab02-5441-4678-961c-2fcea036a113","ordinal":1},"layout":{"root":"44425a05-dc69-45ff-aedd-26c2356c963a","rate":{"numerator":30000,"denominator":1001},"nodes":{"2edb85c2-83ff-4e7d-894a-bbc001fa8f88":{"duration":120,"edges":{"node_start":"automatic","node_end":"automatic","source_placement_start":"automatic","source_placement_end":"automatic","repeat_gap_start":"automatic","repeat_gap_end":"automatic"},"kind":{"type":"source","placement":{"start":{"numerator":"0","denominator":"1"},"end":{"numerator":"120","denominator":"1"}}}},"44425a05-dc69-45ff-aedd-26c2356c963a":{"duration":120,"edges":{"node_start":"automatic","node_end":"automatic","source_placement_start":"automatic","source_placement_end":"automatic","repeat_gap_start":"automatic","repeat_gap_end":"automatic"},"kind":{"type":"sequence","children":["7dd5a588-d539-46aa-9868-1bdcf84cefd4","f6586eb2-456d-4936-b238-23c51261abd2","5b713f47-554f-4437-80dd-dd996488a5ce"]}},"4c685d21-bde0-48c3-ab42-a50742c23c13":{"duration":120,"edges":{"node_start":"automatic","node_end":"automatic","source_placement_start":"automatic","source_placement_end":"automatic","repeat_gap_start":"automatic","repeat_gap_end":"automatic"},"kind":{"type":"source","placement":{"start":{"numerator":"0","denominator":"1"},"end":{"numerator":"120","denominator":"1"}}}},"5b713f47-554f-4437-80dd-dd996488a5ce":{"duration":90,"edges":{"node_start":"automatic","node_end":"automatic","source_placement_start":"automatic","source_placement_end":"automatic","repeat_gap_start":"automatic","repeat_gap_end":"automatic"},"kind":{"type":"retime","child":"4c685d21-bde0-48c3-ab42-a50742c23c13","mapping":{"start":30,"end":120},"pitch":"preserve","purpose":"partition"}},"7dd5a588-d539-46aa-9868-1bdcf84cefd4":{"duration":20,"edges":{"node_start":"automatic","node_end":"automatic","source_placement_start":"automatic","source_placement_end":"automatic","repeat_gap_start":"automatic","repeat_gap_end":"automatic"},"kind":{"type":"retime","child":"2edb85c2-83ff-4e7d-894a-bbc001fa8f88","mapping":{"start":0,"end":20},"pitch":"preserve","purpose":"partition"}},"9c665126-cea5-414d-bf18-8dd77ab0ff87":{"duration":120,"edges":{"node_start":"automatic","node_end":"automatic","source_placement_start":"automatic","source_placement_end":"automatic","repeat_gap_start":"automatic","repeat_gap_end":"automatic"},"kind":{"type":"source","placement":{"start":{"numerator":"0","denominator":"1"},"end":{"numerator":"120","denominator":"1"}}}},"f6586eb2-456d-4936-b238-23c51261abd2":{"duration":10,"edges":{"node_start":"automatic","node_end":"automatic","source_placement_start":"automatic","source_placement_end":"automatic","repeat_gap_start":"automatic","repeat_gap_end":"automatic"},"kind":{"type":"retime","child":"9c665126-cea5-414d-bf18-8dd77ab0ff87","mapping":{"start":20,"end":30},"pitch":"preserve","purpose":"partition"}}},"overrides":{},"audio_lineage":{"2edb85c2-83ff-4e7d-894a-bbc001fa8f88":{"allocation":"0b67ab02-5441-4678-961c-2fcea036a113","origin":"2edb85c2-83ff-4e7d-894a-bbc001fa8f88"},"4c685d21-bde0-48c3-ab42-a50742c23c13":{"allocation":"0b67ab02-5441-4678-961c-2fcea036a113","origin":"2edb85c2-83ff-4e7d-894a-bbc001fa8f88"},"9c665126-cea5-414d-bf18-8dd77ab0ff87":{"allocation":"0b67ab02-5441-4678-961c-2fcea036a113","origin":"2edb85c2-83ff-4e7d-894a-bbc001fa8f88"}}}}],"bindings":{"2edb85c2-83ff-4e7d-894a-bbc001fa8f88":{"lattice":{"reference":{"timing":{"allocation":"0b67ab02-5441-4678-961c-2fcea036a113","ordinal":0},"root":{"type":"project_root_round_even"},"physical":"2edb85c2-83ff-4e7d-894a-bbc001fa8f88"},"arguments":[],"births":[]},"resume":null},"4c685d21-bde0-48c3-ab42-a50742c23c13":{"lattice":{"reference":{"timing":{"allocation":"0b67ab02-5441-4678-961c-2fcea036a113","ordinal":0},"root":{"type":"project_root_round_even"},"physical":"2edb85c2-83ff-4e7d-894a-bbc001fa8f88"},"arguments":[],"births":[]},"resume":null,"reanchors":[{"placement":{"reference":{"timing":{"allocation":"0b67ab02-5441-4678-961c-2fcea036a113","ordinal":1},"root":{"type":"project_root_round_even"},"physical":"4c685d21-bde0-48c3-ab42-a50742c23c13"},"arguments":[],"births":[]},"window":{"start":{"numerator":"30","denominator":"1"},"end":{"numerator":"120","denominator":"1"}}}]}}}}},"inverse":{"project_id":"e6d1ba97-2db0-4119-9e5d-e4a4bef3e078","from_revision":"0b67ab02-5441-4678-961c-2fcea036a113","to_revision":"b5c2fe56-b4d6-42ce-9243-90a7976b1b46","nodes":{"44425a05-dc69-45ff-aedd-26c2356c963a":{"before":{"label":"Sequence","kind":{"type":"sequence","children":["7dd5a588-d539-46aa-9868-1bdcf84cefd4","5b713f47-554f-4437-80dd-dd996488a5ce"]}},"after":{"label":"Sequence","kind":{"type":"sequence","children":["2edb85c2-83ff-4e7d-894a-bbc001fa8f88"]}}},"4c685d21-bde0-48c3-ab42-a50742c23c13":{"before":{"label":"cfr-bframes.mp4","kind":{"type":"source","source":{"duration":120,"edit_window":{"start":{"numerator":"0","denominator":"1"},"end":{"numerator":"120","denominator":"1"}},"video":{"type":"stream","asset":"b2868a97-5094-4eb8-9ccd-4a5c904983e0","span":{"start":{"ticks":0,"time_base":{"numerator":1,"denominator":30000}},"end":{"ticks":120120,"time_base":{"numerator":1,"denominator":30000}}}},"video_mapping":{"type":"placement","start":{"numerator":"0","denominator":"1"},"frames":{"numerator":"120","denominator":"1"},"endpoints":"hold_adjacent"},"audio":{"asset":"b2868a97-5094-4eb8-9ccd-4a5c904983e0","span":{"start":{"ticks":0,"time_base":{"numerator":1,"denominator":48000}},"end":{"ticks":192192,"time_base":{"numerator":1,"denominator":48000}}}},"audio_mapping":{"type":"placement","start":{"numerator":"0","denominator":"1"},"frames":{"numerator":"120","denominator":"1"}},"link":"linked","audio_offset":0}}},"after":null},"5b713f47-554f-4437-80dd-dd996488a5ce":{"before":{"label":"cfr-bframes.mp4","kind":{"type":"retime","child":"4c685d21-bde0-48c3-ab42-a50742c23c13","duration":90,"mapping":{"start":30,"end":120},"pitch":"preserve","purpose":"partition"}},"after":null},"7dd5a588-d539-46aa-9868-1bdcf84cefd4":{"before":{"label":"cfr-bframes.mp4","kind":{"type":"retime","child":"2edb85c2-83ff-4e7d-894a-bbc001fa8f88","duration":20,"mapping":{"start":0,"end":20},"pitch":"preserve","purpose":"partition"}},"after":null}},"assets":{},"marks":{},"overrides":{},"audio_lineage":{"2edb85c2-83ff-4e7d-894a-bbc001fa8f88":{"before":{"allocation":"0b67ab02-5441-4678-961c-2fcea036a113","origin":"2edb85c2-83ff-4e7d-894a-bbc001fa8f88"},"after":null},"4c685d21-bde0-48c3-ab42-a50742c23c13":{"before":{"allocation":"0b67ab02-5441-4678-961c-2fcea036a113","origin":"2edb85c2-83ff-4e7d-894a-bbc001fa8f88"},"after":null}},"audio_bindings":{"before":{"timings":[{"id":{"allocation":"0b67ab02-5441-4678-961c-2fcea036a113","ordinal":0},"layout":{"root":"44425a05-dc69-45ff-aedd-26c2356c963a","rate":{"numerator":30000,"denominator":1001},"nodes":{"2edb85c2-83ff-4e7d-894a-bbc001fa8f88":{"duration":120,"edges":{"node_start":"automatic","node_end":"automatic","source_placement_start":"automatic","source_placement_end":"automatic","repeat_gap_start":"automatic","repeat_gap_end":"automatic"},"kind":{"type":"source","placement":{"start":{"numerator":"0","denominator":"1"},"end":{"numerator":"120","denominator":"1"}}}},"44425a05-dc69-45ff-aedd-26c2356c963a":{"duration":120,"edges":{"node_start":"automatic","node_end":"automatic","source_placement_start":"automatic","source_placement_end":"automatic","repeat_gap_start":"automatic","repeat_gap_end":"automatic"},"kind":{"type":"sequence","children":["2edb85c2-83ff-4e7d-894a-bbc001fa8f88"]}}},"overrides":{}}},{"id":{"allocation":"0b67ab02-5441-4678-961c-2fcea036a113","ordinal":1},"layout":{"root":"44425a05-dc69-45ff-aedd-26c2356c963a","rate":{"numerator":30000,"denominator":1001},"nodes":{"2edb85c2-83ff-4e7d-894a-bbc001fa8f88":{"duration":120,"edges":{"node_start":"automatic","node_end":"automatic","source_placement_start":"automatic","source_placement_end":"automatic","repeat_gap_start":"automatic","repeat_gap_end":"automatic"},"kind":{"type":"source","placement":{"start":{"numerator":"0","denominator":"1"},"end":{"numerator":"120","denominator":"1"}}}},"44425a05-dc69-45ff-aedd-26c2356c963a":{"duration":120,"edges":{"node_start":"automatic","node_end":"automatic","source_placement_start":"automatic","source_placement_end":"automatic","repeat_gap_start":"automatic","repeat_gap_end":"automatic"},"kind":{"type":"sequence","children":["7dd5a588-d539-46aa-9868-1bdcf84cefd4","f6586eb2-456d-4936-b238-23c51261abd2","5b713f47-554f-4437-80dd-dd996488a5ce"]}},"4c685d21-bde0-48c3-ab42-a50742c23c13":{"duration":120,"edges":{"node_start":"automatic","node_end":"automatic","source_placement_start":"automatic","source_placement_end":"automatic","repeat_gap_start":"automatic","repeat_gap_end":"automatic"},"kind":{"type":"source","placement":{"start":{"numerator":"0","denominator":"1"},"end":{"numerator":"120","denominator":"1"}}}},"5b713f47-554f-4437-80dd-dd996488a5ce":{"duration":90,"edges":{"node_start":"automatic","node_end":"automatic","source_placement_start":"automatic","source_placement_end":"automatic","repeat_gap_start":"automatic","repeat_gap_end":"automatic"},"kind":{"type":"retime","child":"4c685d21-bde0-48c3-ab42-a50742c23c13","mapping":{"start":30,"end":120},"pitch":"preserve","purpose":"partition"}},"7dd5a588-d539-46aa-9868-1bdcf84cefd4":{"duration":20,"edges":{"node_start":"automatic","node_end":"automatic","source_placement_start":"automatic","source_placement_end":"automatic","repeat_gap_start":"automatic","repeat_gap_end":"automatic"},"kind":{"type":"retime","child":"2edb85c2-83ff-4e7d-894a-bbc001fa8f88","mapping":{"start":0,"end":20},"pitch":"preserve","purpose":"partition"}},"9c665126-cea5-414d-bf18-8dd77ab0ff87":{"duration":120,"edges":{"node_start":"automatic","node_end":"automatic","source_placement_start":"automatic","source_placement_end":"automatic","repeat_gap_start":"automatic","repeat_gap_end":"automatic"},"kind":{"type":"source","placement":{"start":{"numerator":"0","denominator":"1"},"end":{"numerator":"120","denominator":"1"}}}},"f6586eb2-456d-4936-b238-23c51261abd2":{"duration":10,"edges":{"node_start":"automatic","node_end":"automatic","source_placement_start":"automatic","source_placement_end":"automatic","repeat_gap_start":"automatic","repeat_gap_end":"automatic"},"kind":{"type":"retime","child":"9c665126-cea5-414d-bf18-8dd77ab0ff87","mapping":{"start":20,"end":30},"pitch":"preserve","purpose":"partition"}}},"overrides":{},"audio_lineage":{"2edb85c2-83ff-4e7d-894a-bbc001fa8f88":{"allocation":"0b67ab02-5441-4678-961c-2fcea036a113","origin":"2edb85c2-83ff-4e7d-894a-bbc001fa8f88"},"4c685d21-bde0-48c3-ab42-a50742c23c13":{"allocation":"0b67ab02-5441-4678-961c-2fcea036a113","origin":"2edb85c2-83ff-4e7d-894a-bbc001fa8f88"},"9c665126-cea5-414d-bf18-8dd77ab0ff87":{"allocation":"0b67ab02-5441-4678-961c-2fcea036a113","origin":"2edb85c2-83ff-4e7d-894a-bbc001fa8f88"}}}}],"bindings":{"2edb85c2-83ff-4e7d-894a-bbc001fa8f88":{"lattice":{"reference":{"timing":{"allocation":"0b67ab02-5441-4678-961c-2fcea036a113","ordinal":0},"root":{"type":"project_root_round_even"},"physical":"2edb85c2-83ff-4e7d-894a-bbc001fa8f88"},"arguments":[],"births":[]},"resume":null},"4c685d21-bde0-48c3-ab42-a50742c23c13":{"lattice":{"reference":{"timing":{"allocation":"0b67ab02-5441-4678-961c-2fcea036a113","ordinal":0},"root":{"type":"project_root_round_even"},"physical":"2edb85c2-83ff-4e7d-894a-bbc001fa8f88"},"arguments":[],"births":[]},"resume":null,"reanchors":[{"placement":{"reference":{"timing":{"allocation":"0b67ab02-5441-4678-961c-2fcea036a113","ordinal":1},"root":{"type":"project_root_round_even"},"physical":"4c685d21-bde0-48c3-ab42-a50742c23c13"},"arguments":[],"births":[]},"window":{"start":{"numerator":"30","denominator":"1"},"end":{"numerator":"120","denominator":"1"}}}]}}},"after":{"timings":[],"bindings":{}}}},"changed_ids":["2edb85c2-83ff-4e7d-894a-bbc001fa8f88","44425a05-dc69-45ff-aedd-26c2356c963a","4c685d21-bde0-48c3-ab42-a50742c23c13","5b713f47-554f-4437-80dd-dd996488a5ce","7dd5a588-d539-46aa-9868-1bdcf84cefd4"],"duration_delta":-10,"description":"Delete selected range"}');
INSERT INTO "history" VALUES(7,1,'ad26a1cc-4ede-4f67-a9d0-9635054584e9','{"project_id":"e6d1ba97-2db0-4119-9e5d-e4a4bef3e078","expected_revision":"8eec44f6-1120-4904-8760-1f4ae33aa95c","new_revision":"ad26a1cc-4ede-4f67-a9d0-9635054584e9","command":{"command":"splice_slice","parent":"44425a05-dc69-45ff-aedd-26c2356c963a","index":0,"slice":{"project_id":"e6d1ba97-2db0-4119-9e5d-e4a4bef3e078","revision_id":"b5c2fe56-b4d6-42ce-9243-90a7976b1b46","capture_timing":{"allocation":"042f6ab8-938c-4857-9bf8-49206030d853","ordinal":0},"presentation_basis":{"width":320,"height":180,"frame_rate":{"numerator":30000,"denominator":1001},"color_policy":"sdr_rec709"},"parent":"44425a05-dc69-45ff-aedd-26c2356c963a","range":{"start":20,"end":30},"source_duration":120,"parts":[{"root":"2edb85c2-83ff-4e7d-894a-bbc001fa8f88","mapping":{"start":20,"end":30},"source_start":0}],"nodes":{"2edb85c2-83ff-4e7d-894a-bbc001fa8f88":{"label":"cfr-bframes.mp4","kind":{"type":"source","source":{"duration":120,"edit_window":{"start":{"numerator":"0","denominator":"1"},"end":{"numerator":"120","denominator":"1"}},"video":{"type":"stream","asset":"b2868a97-5094-4eb8-9ccd-4a5c904983e0","span":{"start":{"ticks":0,"time_base":{"numerator":1,"denominator":30000}},"end":{"ticks":120120,"time_base":{"numerator":1,"denominator":30000}}}},"video_mapping":{"type":"placement","start":{"numerator":"0","denominator":"1"},"frames":{"numerator":"120","denominator":"1"},"endpoints":"hold_adjacent"},"audio":{"asset":"b2868a97-5094-4eb8-9ccd-4a5c904983e0","span":{"start":{"ticks":0,"time_base":{"numerator":1,"denominator":48000}},"end":{"ticks":192192,"time_base":{"numerator":1,"denominator":48000}}}},"audio_mapping":{"type":"placement","start":{"numerator":"0","denominator":"1"},"frames":{"numerator":"120","denominator":"1"}},"link":"linked","audio_offset":0}}}},"assets":{"b2868a97-5094-4eb8-9ccd-4a5c904983e0":{"label":"cfr-bframes.mp4","content_hash":"blake3:16614ec12d06396d3c0f0e7b91cc902c6dc30ad89c28d74b805cf64dc60d8aa1","video":{"start":{"ticks":0,"time_base":{"numerator":1,"denominator":30000}},"end":{"ticks":120120,"time_base":{"numerator":1,"denominator":30000}}},"audio":{"start":{"ticks":0,"time_base":{"numerator":1,"denominator":48000}},"end":{"ticks":192192,"time_base":{"numerator":1,"denominator":48000}}},"still_image":false,"frame_count":120,"source_qualification":"c6bc3e81ab69906267164469d11739cf1363eea546436761ddd219069ed496b6"}},"marks":{},"overrides":{},"gap_overrides":{},"audio_lineage":{},"audio_bindings":{"timings":[{"id":{"allocation":"042f6ab8-938c-4857-9bf8-49206030d853","ordinal":0},"layout":{"root":"44425a05-dc69-45ff-aedd-26c2356c963a","rate":{"numerator":30000,"denominator":1001},"nodes":{"2edb85c2-83ff-4e7d-894a-bbc001fa8f88":{"duration":120,"edges":{"node_start":"automatic","node_end":"automatic","source_placement_start":"automatic","source_placement_end":"automatic","repeat_gap_start":"automatic","repeat_gap_end":"automatic"},"kind":{"type":"source","placement":{"start":{"numerator":"0","denominator":"1"},"end":{"numerator":"120","denominator":"1"}}}},"44425a05-dc69-45ff-aedd-26c2356c963a":{"duration":120,"edges":{"node_start":"automatic","node_end":"automatic","source_placement_start":"automatic","source_placement_end":"automatic","repeat_gap_start":"automatic","repeat_gap_end":"automatic"},"kind":{"type":"sequence","children":["2edb85c2-83ff-4e7d-894a-bbc001fa8f88"]}}},"overrides":{}}}],"bindings":{"2edb85c2-83ff-4e7d-894a-bbc001fa8f88":{"lattice":{"reference":{"timing":{"allocation":"042f6ab8-938c-4857-9bf8-49206030d853","ordinal":0},"root":{"type":"project_root_round_even"},"physical":"2edb85c2-83ff-4e7d-894a-bbc001fa8f88"},"arguments":[],"births":[]},"resume":null,"reanchors":[{"placement":{"reference":{"timing":{"allocation":"042f6ab8-938c-4857-9bf8-49206030d853","ordinal":0},"root":{"type":"project_root_round_even"},"physical":"2edb85c2-83ff-4e7d-894a-bbc001fa8f88"},"arguments":[],"births":[]},"window":{"start":{"numerator":"20","denominator":"1"},"end":{"numerator":"30","denominator":"1"}}}]}}}},"identities":{"authored":{"nodes":["39d1ddee-af11-4088-9c7b-383275c1c4e0","3aa355cf-47af-43bb-80a4-fd291886ee4d","ae5c2f25-2c7b-4164-bee1-98adaff7e920"],"marks":[]},"aliases":["4030aab6-bc63-441a-b300-baac4e446e2e","8d8a7a6e-b7b8-4ab9-91f4-4dd95c2cafbe"]},"timing":{"allocation":"ad26a1cc-4ede-4f67-a9d0-9635054584e9","ordinal":0}}}','{"forward":{"project_id":"e6d1ba97-2db0-4119-9e5d-e4a4bef3e078","from_revision":"8eec44f6-1120-4904-8760-1f4ae33aa95c","to_revision":"ad26a1cc-4ede-4f67-a9d0-9635054584e9","nodes":{"39d1ddee-af11-4088-9c7b-383275c1c4e0":{"before":null,"after":{"label":"Copied contents","kind":{"type":"sequence","children":["ae5c2f25-2c7b-4164-bee1-98adaff7e920"]}}},"3aa355cf-47af-43bb-80a4-fd291886ee4d":{"before":null,"after":{"label":"cfr-bframes.mp4","kind":{"type":"source","source":{"duration":120,"edit_window":{"start":{"numerator":"0","denominator":"1"},"end":{"numerator":"120","denominator":"1"}},"video":{"type":"stream","asset":"b2868a97-5094-4eb8-9ccd-4a5c904983e0","span":{"start":{"ticks":0,"time_base":{"numerator":1,"denominator":30000}},"end":{"ticks":120120,"time_base":{"numerator":1,"denominator":30000}}}},"video_mapping":{"type":"placement","start":{"numerator":"0","denominator":"1"},"frames":{"numerator":"120","denominator":"1"},"endpoints":"hold_adjacent"},"audio":{"asset":"b2868a97-5094-4eb8-9ccd-4a5c904983e0","span":{"start":{"ticks":0,"time_base":{"numerator":1,"denominator":48000}},"end":{"ticks":192192,"time_base":{"numerator":1,"denominator":48000}}}},"audio_mapping":{"type":"placement","start":{"numerator":"0","denominator":"1"},"frames":{"numerator":"120","denominator":"1"}},"link":"linked","audio_offset":0}}}},"44425a05-dc69-45ff-aedd-26c2356c963a":{"before":{"label":"Sequence","kind":{"type":"sequence","children":["2edb85c2-83ff-4e7d-894a-bbc001fa8f88"]}},"after":{"label":"Sequence","kind":{"type":"sequence","children":["39d1ddee-af11-4088-9c7b-383275c1c4e0","2edb85c2-83ff-4e7d-894a-bbc001fa8f88"]}}},"ae5c2f25-2c7b-4164-bee1-98adaff7e920":{"before":null,"after":{"label":"Copied interval","kind":{"type":"retime","child":"3aa355cf-47af-43bb-80a4-fd291886ee4d","duration":10,"mapping":{"start":20,"end":30},"pitch":"preserve","purpose":"partition"}}}},"assets":{},"marks":{},"overrides":{},"audio_bindings":{"before":{"timings":[],"bindings":{}},"after":{"timings":[{"id":{"allocation":"ad26a1cc-4ede-4f67-a9d0-9635054584e9","ordinal":0},"layout":{"root":"44425a05-dc69-45ff-aedd-26c2356c963a","rate":{"numerator":30000,"denominator":1001},"nodes":{"2edb85c2-83ff-4e7d-894a-bbc001fa8f88":{"duration":120,"edges":{"node_start":"automatic","node_end":"automatic","source_placement_start":"automatic","source_placement_end":"automatic","repeat_gap_start":"automatic","repeat_gap_end":"automatic"},"kind":{"type":"source","placement":{"start":{"numerator":"0","denominator":"1"},"end":{"numerator":"120","denominator":"1"}}}},"44425a05-dc69-45ff-aedd-26c2356c963a":{"duration":120,"edges":{"node_start":"automatic","node_end":"automatic","source_placement_start":"automatic","source_placement_end":"automatic","repeat_gap_start":"automatic","repeat_gap_end":"automatic"},"kind":{"type":"sequence","children":["2edb85c2-83ff-4e7d-894a-bbc001fa8f88"]}}},"overrides":{}}},{"id":{"allocation":"ad26a1cc-4ede-4f67-a9d0-9635054584e9","ordinal":1},"layout":{"root":"8d8a7a6e-b7b8-4ab9-91f4-4dd95c2cafbe","rate":{"numerator":30000,"denominator":1001},"nodes":{"4030aab6-bc63-441a-b300-baac4e446e2e":{"duration":120,"edges":{"node_start":"automatic","node_end":"automatic","source_placement_start":"automatic","source_placement_end":"automatic","repeat_gap_start":"automatic","repeat_gap_end":"automatic"},"kind":{"type":"source","placement":{"start":{"numerator":"0","denominator":"1"},"end":{"numerator":"120","denominator":"1"}}}},"8d8a7a6e-b7b8-4ab9-91f4-4dd95c2cafbe":{"duration":120,"edges":{"node_start":"automatic","node_end":"automatic","source_placement_start":"automatic","source_placement_end":"automatic","repeat_gap_start":"automatic","repeat_gap_end":"automatic"},"kind":{"type":"sequence","children":["4030aab6-bc63-441a-b300-baac4e446e2e"]}}},"overrides":{}}}],"bindings":{"2edb85c2-83ff-4e7d-894a-bbc001fa8f88":{"lattice":{"reference":{"timing":{"allocation":"ad26a1cc-4ede-4f67-a9d0-9635054584e9","ordinal":0},"root":{"type":"project_root_round_even"},"physical":"2edb85c2-83ff-4e7d-894a-bbc001fa8f88"},"arguments":[],"births":[]},"resume":null,"reanchors":[{"placement":{"reference":{"timing":{"allocation":"ad26a1cc-4ede-4f67-a9d0-9635054584e9","ordinal":0},"root":{"type":"project_root_round_even"},"physical":"2edb85c2-83ff-4e7d-894a-bbc001fa8f88"},"arguments":[],"births":[]},"window":{"start":{"numerator":"0","denominator":"1"},"end":{"numerator":"120","denominator":"1"}}}]},"3aa355cf-47af-43bb-80a4-fd291886ee4d":{"lattice":{"reference":{"timing":{"allocation":"ad26a1cc-4ede-4f67-a9d0-9635054584e9","ordinal":1},"root":{"type":"project_root_round_even"},"physical":"4030aab6-bc63-441a-b300-baac4e446e2e"},"arguments":[],"births":[]},"resume":null,"reanchors":[{"placement":{"reference":{"timing":{"allocation":"ad26a1cc-4ede-4f67-a9d0-9635054584e9","ordinal":1},"root":{"type":"project_root_round_even"},"physical":"4030aab6-bc63-441a-b300-baac4e446e2e"},"arguments":[],"births":[]},"window":{"start":{"numerator":"20","denominator":"1"},"end":{"numerator":"30","denominator":"1"}}}]}}}}},"inverse":{"project_id":"e6d1ba97-2db0-4119-9e5d-e4a4bef3e078","from_revision":"ad26a1cc-4ede-4f67-a9d0-9635054584e9","to_revision":"8eec44f6-1120-4904-8760-1f4ae33aa95c","nodes":{"39d1ddee-af11-4088-9c7b-383275c1c4e0":{"before":{"label":"Copied contents","kind":{"type":"sequence","children":["ae5c2f25-2c7b-4164-bee1-98adaff7e920"]}},"after":null},"3aa355cf-47af-43bb-80a4-fd291886ee4d":{"before":{"label":"cfr-bframes.mp4","kind":{"type":"source","source":{"duration":120,"edit_window":{"start":{"numerator":"0","denominator":"1"},"end":{"numerator":"120","denominator":"1"}},"video":{"type":"stream","asset":"b2868a97-5094-4eb8-9ccd-4a5c904983e0","span":{"start":{"ticks":0,"time_base":{"numerator":1,"denominator":30000}},"end":{"ticks":120120,"time_base":{"numerator":1,"denominator":30000}}}},"video_mapping":{"type":"placement","start":{"numerator":"0","denominator":"1"},"frames":{"numerator":"120","denominator":"1"},"endpoints":"hold_adjacent"},"audio":{"asset":"b2868a97-5094-4eb8-9ccd-4a5c904983e0","span":{"start":{"ticks":0,"time_base":{"numerator":1,"denominator":48000}},"end":{"ticks":192192,"time_base":{"numerator":1,"denominator":48000}}}},"audio_mapping":{"type":"placement","start":{"numerator":"0","denominator":"1"},"frames":{"numerator":"120","denominator":"1"}},"link":"linked","audio_offset":0}}},"after":null},"44425a05-dc69-45ff-aedd-26c2356c963a":{"before":{"label":"Sequence","kind":{"type":"sequence","children":["39d1ddee-af11-4088-9c7b-383275c1c4e0","2edb85c2-83ff-4e7d-894a-bbc001fa8f88"]}},"after":{"label":"Sequence","kind":{"type":"sequence","children":["2edb85c2-83ff-4e7d-894a-bbc001fa8f88"]}}},"ae5c2f25-2c7b-4164-bee1-98adaff7e920":{"before":{"label":"Copied interval","kind":{"type":"retime","child":"3aa355cf-47af-43bb-80a4-fd291886ee4d","duration":10,"mapping":{"start":20,"end":30},"pitch":"preserve","purpose":"partition"}},"after":null}},"assets":{},"marks":{},"overrides":{},"audio_bindings":{"before":{"timings":[{"id":{"allocation":"ad26a1cc-4ede-4f67-a9d0-9635054584e9","ordinal":0},"layout":{"root":"44425a05-dc69-45ff-aedd-26c2356c963a","rate":{"numerator":30000,"denominator":1001},"nodes":{"2edb85c2-83ff-4e7d-894a-bbc001fa8f88":{"duration":120,"edges":{"node_start":"automatic","node_end":"automatic","source_placement_start":"automatic","source_placement_end":"automatic","repeat_gap_start":"automatic","repeat_gap_end":"automatic"},"kind":{"type":"source","placement":{"start":{"numerator":"0","denominator":"1"},"end":{"numerator":"120","denominator":"1"}}}},"44425a05-dc69-45ff-aedd-26c2356c963a":{"duration":120,"edges":{"node_start":"automatic","node_end":"automatic","source_placement_start":"automatic","source_placement_end":"automatic","repeat_gap_start":"automatic","repeat_gap_end":"automatic"},"kind":{"type":"sequence","children":["2edb85c2-83ff-4e7d-894a-bbc001fa8f88"]}}},"overrides":{}}},{"id":{"allocation":"ad26a1cc-4ede-4f67-a9d0-9635054584e9","ordinal":1},"layout":{"root":"8d8a7a6e-b7b8-4ab9-91f4-4dd95c2cafbe","rate":{"numerator":30000,"denominator":1001},"nodes":{"4030aab6-bc63-441a-b300-baac4e446e2e":{"duration":120,"edges":{"node_start":"automatic","node_end":"automatic","source_placement_start":"automatic","source_placement_end":"automatic","repeat_gap_start":"automatic","repeat_gap_end":"automatic"},"kind":{"type":"source","placement":{"start":{"numerator":"0","denominator":"1"},"end":{"numerator":"120","denominator":"1"}}}},"8d8a7a6e-b7b8-4ab9-91f4-4dd95c2cafbe":{"duration":120,"edges":{"node_start":"automatic","node_end":"automatic","source_placement_start":"automatic","source_placement_end":"automatic","repeat_gap_start":"automatic","repeat_gap_end":"automatic"},"kind":{"type":"sequence","children":["4030aab6-bc63-441a-b300-baac4e446e2e"]}}},"overrides":{}}}],"bindings":{"2edb85c2-83ff-4e7d-894a-bbc001fa8f88":{"lattice":{"reference":{"timing":{"allocation":"ad26a1cc-4ede-4f67-a9d0-9635054584e9","ordinal":0},"root":{"type":"project_root_round_even"},"physical":"2edb85c2-83ff-4e7d-894a-bbc001fa8f88"},"arguments":[],"births":[]},"resume":null,"reanchors":[{"placement":{"reference":{"timing":{"allocation":"ad26a1cc-4ede-4f67-a9d0-9635054584e9","ordinal":0},"root":{"type":"project_root_round_even"},"physical":"2edb85c2-83ff-4e7d-894a-bbc001fa8f88"},"arguments":[],"births":[]},"window":{"start":{"numerator":"0","denominator":"1"},"end":{"numerator":"120","denominator":"1"}}}]},"3aa355cf-47af-43bb-80a4-fd291886ee4d":{"lattice":{"reference":{"timing":{"allocation":"ad26a1cc-4ede-4f67-a9d0-9635054584e9","ordinal":1},"root":{"type":"project_root_round_even"},"physical":"4030aab6-bc63-441a-b300-baac4e446e2e"},"arguments":[],"births":[]},"resume":null,"reanchors":[{"placement":{"reference":{"timing":{"allocation":"ad26a1cc-4ede-4f67-a9d0-9635054584e9","ordinal":1},"root":{"type":"project_root_round_even"},"physical":"4030aab6-bc63-441a-b300-baac4e446e2e"},"arguments":[],"births":[]},"window":{"start":{"numerator":"20","denominator":"1"},"end":{"numerator":"30","denominator":"1"}}}]}}},"after":{"timings":[],"bindings":{}}}},"changed_ids":["2edb85c2-83ff-4e7d-894a-bbc001fa8f88","39d1ddee-af11-4088-9c7b-383275c1c4e0","3aa355cf-47af-43bb-80a4-fd291886ee4d","44425a05-dc69-45ff-aedd-26c2356c963a","ae5c2f25-2c7b-4164-bee1-98adaff7e920"],"duration_delta":10,"description":"Paste edited slice"}');
INSERT INTO "history" VALUES(8,1,'2ef18e3d-a9e1-43e6-a42a-15920840b224','{"project_id":"e6d1ba97-2db0-4119-9e5d-e4a4bef3e078","expected_revision":"ab2073bb-c82a-43c8-95aa-0dfa8f49275d","new_revision":"2ef18e3d-a9e1-43e6-a42a-15920840b224","command":{"command":"splice_source","parent":"44425a05-dc69-45ff-aedd-26c2356c963a","index":0,"source":{"duration":4,"edit_window":{"start":{"numerator":"0","denominator":"1"},"end":{"numerator":"4","denominator":"1"}},"video":{"type":"stream","asset":"b2868a97-5094-4eb8-9ccd-4a5c904983e0","span":{"start":{"ticks":0,"time_base":{"numerator":1,"denominator":30000}},"end":{"ticks":120120,"time_base":{"numerator":1,"denominator":30000}}}},"video_mapping":{"type":"selected_placement","start":{"numerator":"-90","denominator":"1"},"frames":{"numerator":"120","denominator":"1"},"selection":{"start":{"numerator":"0","denominator":"1"},"end":{"numerator":"4","denominator":"1"}},"endpoints":"hold_adjacent"},"audio":{"asset":"b2868a97-5094-4eb8-9ccd-4a5c904983e0","span":{"start":{"ticks":0,"time_base":{"numerator":1,"denominator":48000}},"end":{"ticks":192192,"time_base":{"numerator":1,"denominator":48000}}}},"audio_mapping":{"type":"selected_placement","start":{"numerator":"-90","denominator":"1"},"frames":{"numerator":"120","denominator":"1"},"selection":{"start":{"numerator":"0","denominator":"1"},"end":{"numerator":"4","denominator":"1"}}},"link":"linked","audio_offset":0},"id":"d248ce93-60f7-4824-ba52-5da57322438c","label":"cfr-bframes.mp4 [90..94)","timing":{"allocation":"2ef18e3d-a9e1-43e6-a42a-15920840b224","ordinal":0}}}','{"forward":{"project_id":"e6d1ba97-2db0-4119-9e5d-e4a4bef3e078","from_revision":"ab2073bb-c82a-43c8-95aa-0dfa8f49275d","to_revision":"2ef18e3d-a9e1-43e6-a42a-15920840b224","nodes":{"44425a05-dc69-45ff-aedd-26c2356c963a":{"before":{"label":"Sequence","kind":{"type":"sequence","children":["2edb85c2-83ff-4e7d-894a-bbc001fa8f88"]}},"after":{"label":"Sequence","kind":{"type":"sequence","children":["d248ce93-60f7-4824-ba52-5da57322438c","2edb85c2-83ff-4e7d-894a-bbc001fa8f88"]}}},"d248ce93-60f7-4824-ba52-5da57322438c":{"before":null,"after":{"label":"cfr-bframes.mp4 [90..94)","kind":{"type":"source","source":{"duration":4,"edit_window":{"start":{"numerator":"0","denominator":"1"},"end":{"numerator":"4","denominator":"1"}},"video":{"type":"stream","asset":"b2868a97-5094-4eb8-9ccd-4a5c904983e0","span":{"start":{"ticks":0,"time_base":{"numerator":1,"denominator":30000}},"end":{"ticks":120120,"time_base":{"numerator":1,"denominator":30000}}}},"video_mapping":{"type":"selected_placement","start":{"numerator":"-90","denominator":"1"},"frames":{"numerator":"120","denominator":"1"},"selection":{"start":{"numerator":"0","denominator":"1"},"end":{"numerator":"4","denominator":"1"}},"endpoints":"hold_adjacent"},"audio":{"asset":"b2868a97-5094-4eb8-9ccd-4a5c904983e0","span":{"start":{"ticks":0,"time_base":{"numerator":1,"denominator":48000}},"end":{"ticks":192192,"time_base":{"numerator":1,"denominator":48000}}}},"audio_mapping":{"type":"selected_placement","start":{"numerator":"-90","denominator":"1"},"frames":{"numerator":"120","denominator":"1"},"selection":{"start":{"numerator":"0","denominator":"1"},"end":{"numerator":"4","denominator":"1"}}},"link":"linked","audio_offset":0}}}}},"assets":{},"marks":{},"overrides":{},"audio_bindings":{"before":{"timings":[],"bindings":{}},"after":{"timings":[{"id":{"allocation":"2ef18e3d-a9e1-43e6-a42a-15920840b224","ordinal":0},"layout":{"root":"44425a05-dc69-45ff-aedd-26c2356c963a","rate":{"numerator":30000,"denominator":1001},"nodes":{"2edb85c2-83ff-4e7d-894a-bbc001fa8f88":{"duration":120,"edges":{"node_start":"automatic","node_end":"automatic","source_placement_start":"automatic","source_placement_end":"automatic","repeat_gap_start":"automatic","repeat_gap_end":"automatic"},"kind":{"type":"source","placement":{"start":{"numerator":"0","denominator":"1"},"end":{"numerator":"120","denominator":"1"}}}},"44425a05-dc69-45ff-aedd-26c2356c963a":{"duration":120,"edges":{"node_start":"automatic","node_end":"automatic","source_placement_start":"automatic","source_placement_end":"automatic","repeat_gap_start":"automatic","repeat_gap_end":"automatic"},"kind":{"type":"sequence","children":["2edb85c2-83ff-4e7d-894a-bbc001fa8f88"]}}},"overrides":{}}}],"bindings":{"2edb85c2-83ff-4e7d-894a-bbc001fa8f88":{"lattice":{"reference":{"timing":{"allocation":"2ef18e3d-a9e1-43e6-a42a-15920840b224","ordinal":0},"root":{"type":"project_root_round_even"},"physical":"2edb85c2-83ff-4e7d-894a-bbc001fa8f88"},"arguments":[],"births":[]},"resume":null,"reanchors":[{"placement":{"reference":{"timing":{"allocation":"2ef18e3d-a9e1-43e6-a42a-15920840b224","ordinal":0},"root":{"type":"project_root_round_even"},"physical":"2edb85c2-83ff-4e7d-894a-bbc001fa8f88"},"arguments":[],"births":[]},"window":{"start":{"numerator":"0","denominator":"1"},"end":{"numerator":"120","denominator":"1"}}}]}}}}},"inverse":{"project_id":"e6d1ba97-2db0-4119-9e5d-e4a4bef3e078","from_revision":"2ef18e3d-a9e1-43e6-a42a-15920840b224","to_revision":"ab2073bb-c82a-43c8-95aa-0dfa8f49275d","nodes":{"44425a05-dc69-45ff-aedd-26c2356c963a":{"before":{"label":"Sequence","kind":{"type":"sequence","children":["d248ce93-60f7-4824-ba52-5da57322438c","2edb85c2-83ff-4e7d-894a-bbc001fa8f88"]}},"after":{"label":"Sequence","kind":{"type":"sequence","children":["2edb85c2-83ff-4e7d-894a-bbc001fa8f88"]}}},"d248ce93-60f7-4824-ba52-5da57322438c":{"before":{"label":"cfr-bframes.mp4 [90..94)","kind":{"type":"source","source":{"duration":4,"edit_window":{"start":{"numerator":"0","denominator":"1"},"end":{"numerator":"4","denominator":"1"}},"video":{"type":"stream","asset":"b2868a97-5094-4eb8-9ccd-4a5c904983e0","span":{"start":{"ticks":0,"time_base":{"numerator":1,"denominator":30000}},"end":{"ticks":120120,"time_base":{"numerator":1,"denominator":30000}}}},"video_mapping":{"type":"selected_placement","start":{"numerator":"-90","denominator":"1"},"frames":{"numerator":"120","denominator":"1"},"selection":{"start":{"numerator":"0","denominator":"1"},"end":{"numerator":"4","denominator":"1"}},"endpoints":"hold_adjacent"},"audio":{"asset":"b2868a97-5094-4eb8-9ccd-4a5c904983e0","span":{"start":{"ticks":0,"time_base":{"numerator":1,"denominator":48000}},"end":{"ticks":192192,"time_base":{"numerator":1,"denominator":48000}}}},"audio_mapping":{"type":"selected_placement","start":{"numerator":"-90","denominator":"1"},"frames":{"numerator":"120","denominator":"1"},"selection":{"start":{"numerator":"0","denominator":"1"},"end":{"numerator":"4","denominator":"1"}}},"link":"linked","audio_offset":0}}},"after":null}},"assets":{},"marks":{},"overrides":{},"audio_bindings":{"before":{"timings":[{"id":{"allocation":"2ef18e3d-a9e1-43e6-a42a-15920840b224","ordinal":0},"layout":{"root":"44425a05-dc69-45ff-aedd-26c2356c963a","rate":{"numerator":30000,"denominator":1001},"nodes":{"2edb85c2-83ff-4e7d-894a-bbc001fa8f88":{"duration":120,"edges":{"node_start":"automatic","node_end":"automatic","source_placement_start":"automatic","source_placement_end":"automatic","repeat_gap_start":"automatic","repeat_gap_end":"automatic"},"kind":{"type":"source","placement":{"start":{"numerator":"0","denominator":"1"},"end":{"numerator":"120","denominator":"1"}}}},"44425a05-dc69-45ff-aedd-26c2356c963a":{"duration":120,"edges":{"node_start":"automatic","node_end":"automatic","source_placement_start":"automatic","source_placement_end":"automatic","repeat_gap_start":"automatic","repeat_gap_end":"automatic"},"kind":{"type":"sequence","children":["2edb85c2-83ff-4e7d-894a-bbc001fa8f88"]}}},"overrides":{}}}],"bindings":{"2edb85c2-83ff-4e7d-894a-bbc001fa8f88":{"lattice":{"reference":{"timing":{"allocation":"2ef18e3d-a9e1-43e6-a42a-15920840b224","ordinal":0},"root":{"type":"project_root_round_even"},"physical":"2edb85c2-83ff-4e7d-894a-bbc001fa8f88"},"arguments":[],"births":[]},"resume":null,"reanchors":[{"placement":{"reference":{"timing":{"allocation":"2ef18e3d-a9e1-43e6-a42a-15920840b224","ordinal":0},"root":{"type":"project_root_round_even"},"physical":"2edb85c2-83ff-4e7d-894a-bbc001fa8f88"},"arguments":[],"births":[]},"window":{"start":{"numerator":"0","denominator":"1"},"end":{"numerator":"120","denominator":"1"}}}]}}},"after":{"timings":[],"bindings":{}}}},"changed_ids":["2edb85c2-83ff-4e7d-894a-bbc001fa8f88","44425a05-dc69-45ff-aedd-26c2356c963a","d248ce93-60f7-4824-ba52-5da57322438c"],"duration_delta":4,"description":"Paste source moment"}');
INSERT INTO "history" VALUES(9,1,'ae514e2e-07c3-4748-b856-ba85dae44577','{"project_id":"e6d1ba97-2db0-4119-9e5d-e4a4bef3e078","expected_revision":"1b253125-e462-4cac-af80-f1dcc0a3938c","new_revision":"ae514e2e-07c3-4748-b856-ba85dae44577","command":{"command":"splice_source","parent":"44425a05-dc69-45ff-aedd-26c2356c963a","index":0,"source":{"duration":4,"edit_window":{"start":{"numerator":"0","denominator":"1"},"end":{"numerator":"4","denominator":"1"}},"video":{"type":"stream","asset":"b2868a97-5094-4eb8-9ccd-4a5c904983e0","span":{"start":{"ticks":0,"time_base":{"numerator":1,"denominator":30000}},"end":{"ticks":120120,"time_base":{"numerator":1,"denominator":30000}}}},"video_mapping":{"type":"selected_placement","start":{"numerator":"-70","denominator":"1"},"frames":{"numerator":"120","denominator":"1"},"selection":{"start":{"numerator":"0","denominator":"1"},"end":{"numerator":"4","denominator":"1"}},"endpoints":"hold_adjacent"},"audio":{"asset":"b2868a97-5094-4eb8-9ccd-4a5c904983e0","span":{"start":{"ticks":0,"time_base":{"numerator":1,"denominator":48000}},"end":{"ticks":192192,"time_base":{"numerator":1,"denominator":48000}}}},"audio_mapping":{"type":"selected_placement","start":{"numerator":"-70","denominator":"1"},"frames":{"numerator":"120","denominator":"1"},"selection":{"start":{"numerator":"0","denominator":"1"},"end":{"numerator":"4","denominator":"1"}}},"link":"linked","audio_offset":0},"id":"ee7d5556-659b-461e-95f6-b93773a5d7e7","label":"cfr-bframes.mp4 [70..74)","timing":{"allocation":"ae514e2e-07c3-4748-b856-ba85dae44577","ordinal":0}}}','{"forward":{"project_id":"e6d1ba97-2db0-4119-9e5d-e4a4bef3e078","from_revision":"1b253125-e462-4cac-af80-f1dcc0a3938c","to_revision":"ae514e2e-07c3-4748-b856-ba85dae44577","nodes":{"44425a05-dc69-45ff-aedd-26c2356c963a":{"before":{"label":"Sequence","kind":{"type":"sequence","children":["2edb85c2-83ff-4e7d-894a-bbc001fa8f88"]}},"after":{"label":"Sequence","kind":{"type":"sequence","children":["ee7d5556-659b-461e-95f6-b93773a5d7e7","2edb85c2-83ff-4e7d-894a-bbc001fa8f88"]}}},"ee7d5556-659b-461e-95f6-b93773a5d7e7":{"before":null,"after":{"label":"cfr-bframes.mp4 [70..74)","kind":{"type":"source","source":{"duration":4,"edit_window":{"start":{"numerator":"0","denominator":"1"},"end":{"numerator":"4","denominator":"1"}},"video":{"type":"stream","asset":"b2868a97-5094-4eb8-9ccd-4a5c904983e0","span":{"start":{"ticks":0,"time_base":{"numerator":1,"denominator":30000}},"end":{"ticks":120120,"time_base":{"numerator":1,"denominator":30000}}}},"video_mapping":{"type":"selected_placement","start":{"numerator":"-70","denominator":"1"},"frames":{"numerator":"120","denominator":"1"},"selection":{"start":{"numerator":"0","denominator":"1"},"end":{"numerator":"4","denominator":"1"}},"endpoints":"hold_adjacent"},"audio":{"asset":"b2868a97-5094-4eb8-9ccd-4a5c904983e0","span":{"start":{"ticks":0,"time_base":{"numerator":1,"denominator":48000}},"end":{"ticks":192192,"time_base":{"numerator":1,"denominator":48000}}}},"audio_mapping":{"type":"selected_placement","start":{"numerator":"-70","denominator":"1"},"frames":{"numerator":"120","denominator":"1"},"selection":{"start":{"numerator":"0","denominator":"1"},"end":{"numerator":"4","denominator":"1"}}},"link":"linked","audio_offset":0}}}}},"assets":{},"marks":{},"overrides":{},"audio_bindings":{"before":{"timings":[],"bindings":{}},"after":{"timings":[{"id":{"allocation":"ae514e2e-07c3-4748-b856-ba85dae44577","ordinal":0},"layout":{"root":"44425a05-dc69-45ff-aedd-26c2356c963a","rate":{"numerator":30000,"denominator":1001},"nodes":{"2edb85c2-83ff-4e7d-894a-bbc001fa8f88":{"duration":120,"edges":{"node_start":"automatic","node_end":"automatic","source_placement_start":"automatic","source_placement_end":"automatic","repeat_gap_start":"automatic","repeat_gap_end":"automatic"},"kind":{"type":"source","placement":{"start":{"numerator":"0","denominator":"1"},"end":{"numerator":"120","denominator":"1"}}}},"44425a05-dc69-45ff-aedd-26c2356c963a":{"duration":120,"edges":{"node_start":"automatic","node_end":"automatic","source_placement_start":"automatic","source_placement_end":"automatic","repeat_gap_start":"automatic","repeat_gap_end":"automatic"},"kind":{"type":"sequence","children":["2edb85c2-83ff-4e7d-894a-bbc001fa8f88"]}}},"overrides":{}}}],"bindings":{"2edb85c2-83ff-4e7d-894a-bbc001fa8f88":{"lattice":{"reference":{"timing":{"allocation":"ae514e2e-07c3-4748-b856-ba85dae44577","ordinal":0},"root":{"type":"project_root_round_even"},"physical":"2edb85c2-83ff-4e7d-894a-bbc001fa8f88"},"arguments":[],"births":[]},"resume":null,"reanchors":[{"placement":{"reference":{"timing":{"allocation":"ae514e2e-07c3-4748-b856-ba85dae44577","ordinal":0},"root":{"type":"project_root_round_even"},"physical":"2edb85c2-83ff-4e7d-894a-bbc001fa8f88"},"arguments":[],"births":[]},"window":{"start":{"numerator":"0","denominator":"1"},"end":{"numerator":"120","denominator":"1"}}}]}}}}},"inverse":{"project_id":"e6d1ba97-2db0-4119-9e5d-e4a4bef3e078","from_revision":"ae514e2e-07c3-4748-b856-ba85dae44577","to_revision":"1b253125-e462-4cac-af80-f1dcc0a3938c","nodes":{"44425a05-dc69-45ff-aedd-26c2356c963a":{"before":{"label":"Sequence","kind":{"type":"sequence","children":["ee7d5556-659b-461e-95f6-b93773a5d7e7","2edb85c2-83ff-4e7d-894a-bbc001fa8f88"]}},"after":{"label":"Sequence","kind":{"type":"sequence","children":["2edb85c2-83ff-4e7d-894a-bbc001fa8f88"]}}},"ee7d5556-659b-461e-95f6-b93773a5d7e7":{"before":{"label":"cfr-bframes.mp4 [70..74)","kind":{"type":"source","source":{"duration":4,"edit_window":{"start":{"numerator":"0","denominator":"1"},"end":{"numerator":"4","denominator":"1"}},"video":{"type":"stream","asset":"b2868a97-5094-4eb8-9ccd-4a5c904983e0","span":{"start":{"ticks":0,"time_base":{"numerator":1,"denominator":30000}},"end":{"ticks":120120,"time_base":{"numerator":1,"denominator":30000}}}},"video_mapping":{"type":"selected_placement","start":{"numerator":"-70","denominator":"1"},"frames":{"numerator":"120","denominator":"1"},"selection":{"start":{"numerator":"0","denominator":"1"},"end":{"numerator":"4","denominator":"1"}},"endpoints":"hold_adjacent"},"audio":{"asset":"b2868a97-5094-4eb8-9ccd-4a5c904983e0","span":{"start":{"ticks":0,"time_base":{"numerator":1,"denominator":48000}},"end":{"ticks":192192,"time_base":{"numerator":1,"denominator":48000}}}},"audio_mapping":{"type":"selected_placement","start":{"numerator":"-70","denominator":"1"},"frames":{"numerator":"120","denominator":"1"},"selection":{"start":{"numerator":"0","denominator":"1"},"end":{"numerator":"4","denominator":"1"}}},"link":"linked","audio_offset":0}}},"after":null}},"assets":{},"marks":{},"overrides":{},"audio_bindings":{"before":{"timings":[{"id":{"allocation":"ae514e2e-07c3-4748-b856-ba85dae44577","ordinal":0},"layout":{"root":"44425a05-dc69-45ff-aedd-26c2356c963a","rate":{"numerator":30000,"denominator":1001},"nodes":{"2edb85c2-83ff-4e7d-894a-bbc001fa8f88":{"duration":120,"edges":{"node_start":"automatic","node_end":"automatic","source_placement_start":"automatic","source_placement_end":"automatic","repeat_gap_start":"automatic","repeat_gap_end":"automatic"},"kind":{"type":"source","placement":{"start":{"numerator":"0","denominator":"1"},"end":{"numerator":"120","denominator":"1"}}}},"44425a05-dc69-45ff-aedd-26c2356c963a":{"duration":120,"edges":{"node_start":"automatic","node_end":"automatic","source_placement_start":"automatic","source_placement_end":"automatic","repeat_gap_start":"automatic","repeat_gap_end":"automatic"},"kind":{"type":"sequence","children":["2edb85c2-83ff-4e7d-894a-bbc001fa8f88"]}}},"overrides":{}}}],"bindings":{"2edb85c2-83ff-4e7d-894a-bbc001fa8f88":{"lattice":{"reference":{"timing":{"allocation":"ae514e2e-07c3-4748-b856-ba85dae44577","ordinal":0},"root":{"type":"project_root_round_even"},"physical":"2edb85c2-83ff-4e7d-894a-bbc001fa8f88"},"arguments":[],"births":[]},"resume":null,"reanchors":[{"placement":{"reference":{"timing":{"allocation":"ae514e2e-07c3-4748-b856-ba85dae44577","ordinal":0},"root":{"type":"project_root_round_even"},"physical":"2edb85c2-83ff-4e7d-894a-bbc001fa8f88"},"arguments":[],"births":[]},"window":{"start":{"numerator":"0","denominator":"1"},"end":{"numerator":"120","denominator":"1"}}}]}}},"after":{"timings":[],"bindings":{}}}},"changed_ids":["2edb85c2-83ff-4e7d-894a-bbc001fa8f88","44425a05-dc69-45ff-aedd-26c2356c963a","ee7d5556-659b-461e-95f6-b93773a5d7e7"],"duration_delta":4,"description":"Paste source moment"}');
INSERT INTO "history" VALUES(10,1,'c52caa09-1169-4d26-a7e1-4b1184a76833','{"project_id":"e6d1ba97-2db0-4119-9e5d-e4a4bef3e078","expected_revision":"3e0ccec9-2254-4c86-9bfa-20db395535fa","new_revision":"c52caa09-1169-4d26-a7e1-4b1184a76833","command":{"command":"splice_slice","parent":"44425a05-dc69-45ff-aedd-26c2356c963a","index":0,"slice":{"project_id":"e6d1ba97-2db0-4119-9e5d-e4a4bef3e078","revision_id":"ed903801-af9a-4875-a6d0-2ffb76eb830f","capture_timing":{"allocation":"1fc4c43f-6c56-4450-857a-0fb258ce2a86","ordinal":0},"presentation_basis":{"width":320,"height":180,"frame_rate":{"numerator":30000,"denominator":1001},"color_policy":"sdr_rec709"},"parent":"44425a05-dc69-45ff-aedd-26c2356c963a","range":{"start":8,"end":25},"source_duration":131,"parts":[{"root":"4de01272-0476-425e-9ba1-c63b46aa4012","mapping":{"start":8,"end":10},"source_start":0},{"root":"b0131c13-21a8-452e-80f8-03b53f60f52e","mapping":{"start":0,"end":11},"source_start":10},{"root":"6d77dc13-c463-476e-ad1c-948bf919538b","mapping":{"start":0,"end":4},"source_start":21}],"nodes":{"2edb85c2-83ff-4e7d-894a-bbc001fa8f88":{"label":"cfr-bframes.mp4","kind":{"type":"source","source":{"duration":120,"edit_window":{"start":{"numerator":"0","denominator":"1"},"end":{"numerator":"120","denominator":"1"}},"video":{"type":"stream","asset":"b2868a97-5094-4eb8-9ccd-4a5c904983e0","span":{"start":{"ticks":0,"time_base":{"numerator":1,"denominator":30000}},"end":{"ticks":120120,"time_base":{"numerator":1,"denominator":30000}}}},"video_mapping":{"type":"placement","start":{"numerator":"0","denominator":"1"},"frames":{"numerator":"120","denominator":"1"},"endpoints":"hold_adjacent"},"audio":{"asset":"b2868a97-5094-4eb8-9ccd-4a5c904983e0","span":{"start":{"ticks":0,"time_base":{"numerator":1,"denominator":48000}},"end":{"ticks":192192,"time_base":{"numerator":1,"denominator":48000}}}},"audio_mapping":{"type":"placement","start":{"numerator":"0","denominator":"1"},"frames":{"numerator":"120","denominator":"1"}},"link":"linked","audio_offset":0}}},"4de01272-0476-425e-9ba1-c63b46aa4012":{"label":"cfr-bframes.mp4","kind":{"type":"retime","child":"2edb85c2-83ff-4e7d-894a-bbc001fa8f88","duration":10,"mapping":{"start":0,"end":10},"pitch":"preserve","purpose":"partition"}},"6d77dc13-c463-476e-ad1c-948bf919538b":{"label":"cfr-bframes.mp4","kind":{"type":"retime","child":"73b09e6c-178d-48c1-9f43-54960c553afd","duration":110,"mapping":{"start":10,"end":120},"pitch":"preserve","purpose":"partition"}},"73b09e6c-178d-48c1-9f43-54960c553afd":{"label":"cfr-bframes.mp4","kind":{"type":"source","source":{"duration":120,"edit_window":{"start":{"numerator":"0","denominator":"1"},"end":{"numerator":"120","denominator":"1"}},"video":{"type":"stream","asset":"b2868a97-5094-4eb8-9ccd-4a5c904983e0","span":{"start":{"ticks":0,"time_base":{"numerator":1,"denominator":30000}},"end":{"ticks":120120,"time_base":{"numerator":1,"denominator":30000}}}},"video_mapping":{"type":"placement","start":{"numerator":"0","denominator":"1"},"frames":{"numerator":"120","denominator":"1"},"endpoints":"hold_adjacent"},"audio":{"asset":"b2868a97-5094-4eb8-9ccd-4a5c904983e0","span":{"start":{"ticks":0,"time_base":{"numerator":1,"denominator":48000}},"end":{"ticks":192192,"time_base":{"numerator":1,"denominator":48000}}}},"audio_mapping":{"type":"placement","start":{"numerator":"0","denominator":"1"},"frames":{"numerator":"120","denominator":"1"}},"link":"linked","audio_offset":0}}},"b0131c13-21a8-452e-80f8-03b53f60f52e":{"label":"Pause","kind":{"type":"hold","recipe":{"picture_context":{"canvases":[{"width":320,"height":180,"fit":"fit","layers":[]}]},"duration":11,"video":{"type":"freeze","asset":"b2868a97-5094-4eb8-9ccd-4a5c904983e0","timestamp":{"ticks":9009,"time_base":{"numerator":1,"denominator":30000}}},"audio":{"type":"silence"}}}}},"assets":{"b2868a97-5094-4eb8-9ccd-4a5c904983e0":{"label":"cfr-bframes.mp4","content_hash":"blake3:16614ec12d06396d3c0f0e7b91cc902c6dc30ad89c28d74b805cf64dc60d8aa1","video":{"start":{"ticks":0,"time_base":{"numerator":1,"denominator":30000}},"end":{"ticks":120120,"time_base":{"numerator":1,"denominator":30000}}},"audio":{"start":{"ticks":0,"time_base":{"numerator":1,"denominator":48000}},"end":{"ticks":192192,"time_base":{"numerator":1,"denominator":48000}}},"still_image":false,"frame_count":120,"source_qualification":"c6bc3e81ab69906267164469d11739cf1363eea546436761ddd219069ed496b6"}},"marks":{},"overrides":{},"gap_overrides":{},"audio_lineage":{"2edb85c2-83ff-4e7d-894a-bbc001fa8f88":{"allocation":"ed903801-af9a-4875-a6d0-2ffb76eb830f","origin":"2edb85c2-83ff-4e7d-894a-bbc001fa8f88"},"73b09e6c-178d-48c1-9f43-54960c553afd":{"allocation":"ed903801-af9a-4875-a6d0-2ffb76eb830f","origin":"2edb85c2-83ff-4e7d-894a-bbc001fa8f88"}},"audio_bindings":{"timings":[{"id":{"allocation":"1fc4c43f-6c56-4450-857a-0fb258ce2a86","ordinal":0},"layout":{"root":"44425a05-dc69-45ff-aedd-26c2356c963a","rate":{"numerator":30000,"denominator":1001},"nodes":{"2edb85c2-83ff-4e7d-894a-bbc001fa8f88":{"duration":120,"edges":{"node_start":"automatic","node_end":"automatic","source_placement_start":"automatic","source_placement_end":"automatic","repeat_gap_start":"automatic","repeat_gap_end":"automatic"},"kind":{"type":"source","placement":{"start":{"numerator":"0","denominator":"1"},"end":{"numerator":"120","denominator":"1"}}}},"44425a05-dc69-45ff-aedd-26c2356c963a":{"duration":131,"edges":{"node_start":"automatic","node_end":"automatic","source_placement_start":"automatic","source_placement_end":"automatic","repeat_gap_start":"automatic","repeat_gap_end":"automatic"},"kind":{"type":"sequence","children":["4de01272-0476-425e-9ba1-c63b46aa4012","b0131c13-21a8-452e-80f8-03b53f60f52e","6d77dc13-c463-476e-ad1c-948bf919538b"]}},"4de01272-0476-425e-9ba1-c63b46aa4012":{"duration":10,"edges":{"node_start":"automatic","node_end":"automatic","source_placement_start":"automatic","source_placement_end":"automatic","repeat_gap_start":"automatic","repeat_gap_end":"automatic"},"kind":{"type":"retime","child":"2edb85c2-83ff-4e7d-894a-bbc001fa8f88","mapping":{"start":0,"end":10},"pitch":"preserve","purpose":"partition"}},"6d77dc13-c463-476e-ad1c-948bf919538b":{"duration":110,"edges":{"node_start":"automatic","node_end":"automatic","source_placement_start":"automatic","source_placement_end":"automatic","repeat_gap_start":"automatic","repeat_gap_end":"automatic"},"kind":{"type":"retime","child":"73b09e6c-178d-48c1-9f43-54960c553afd","mapping":{"start":10,"end":120},"pitch":"preserve","purpose":"partition"}},"73b09e6c-178d-48c1-9f43-54960c553afd":{"duration":120,"edges":{"node_start":"automatic","node_end":"automatic","source_placement_start":"automatic","source_placement_end":"automatic","repeat_gap_start":"automatic","repeat_gap_end":"automatic"},"kind":{"type":"source","placement":{"start":{"numerator":"0","denominator":"1"},"end":{"numerator":"120","denominator":"1"}}}},"b0131c13-21a8-452e-80f8-03b53f60f52e":{"duration":11,"edges":{"node_start":"automatic","node_end":"automatic","source_placement_start":"automatic","source_placement_end":"automatic","repeat_gap_start":"automatic","repeat_gap_end":"automatic"},"kind":{"type":"hold","audio":{"type":"silence"}}}},"overrides":{},"audio_lineage":{"2edb85c2-83ff-4e7d-894a-bbc001fa8f88":{"allocation":"ed903801-af9a-4875-a6d0-2ffb76eb830f","origin":"2edb85c2-83ff-4e7d-894a-bbc001fa8f88"},"73b09e6c-178d-48c1-9f43-54960c553afd":{"allocation":"ed903801-af9a-4875-a6d0-2ffb76eb830f","origin":"2edb85c2-83ff-4e7d-894a-bbc001fa8f88"}}}},{"id":{"allocation":"ed903801-af9a-4875-a6d0-2ffb76eb830f","ordinal":0},"layout":{"root":"44425a05-dc69-45ff-aedd-26c2356c963a","rate":{"numerator":30000,"denominator":1001},"nodes":{"2edb85c2-83ff-4e7d-894a-bbc001fa8f88":{"duration":120,"edges":{"node_start":"automatic","node_end":"automatic","source_placement_start":"automatic","source_placement_end":"automatic","repeat_gap_start":"automatic","repeat_gap_end":"automatic"},"kind":{"type":"source","placement":{"start":{"numerator":"0","denominator":"1"},"end":{"numerator":"120","denominator":"1"}}}},"44425a05-dc69-45ff-aedd-26c2356c963a":{"duration":120,"edges":{"node_start":"automatic","node_end":"automatic","source_placement_start":"automatic","source_placement_end":"automatic","repeat_gap_start":"automatic","repeat_gap_end":"automatic"},"kind":{"type":"sequence","children":["2edb85c2-83ff-4e7d-894a-bbc001fa8f88"]}}},"overrides":{}}}],"bindings":{"2edb85c2-83ff-4e7d-894a-bbc001fa8f88":{"lattice":{"reference":{"timing":{"allocation":"ed903801-af9a-4875-a6d0-2ffb76eb830f","ordinal":0},"root":{"type":"project_root_round_even"},"physical":"2edb85c2-83ff-4e7d-894a-bbc001fa8f88"},"arguments":[],"births":[]},"resume":null,"reanchors":[{"placement":{"reference":{"timing":{"allocation":"1fc4c43f-6c56-4450-857a-0fb258ce2a86","ordinal":0},"root":{"type":"project_root_round_even"},"physical":"2edb85c2-83ff-4e7d-894a-bbc001fa8f88"},"arguments":[],"births":[]},"window":{"start":{"numerator":"8","denominator":"1"},"end":{"numerator":"25","denominator":"1"}}}]},"73b09e6c-178d-48c1-9f43-54960c553afd":{"lattice":{"reference":{"timing":{"allocation":"ed903801-af9a-4875-a6d0-2ffb76eb830f","ordinal":0},"root":{"type":"project_root_round_even"},"physical":"2edb85c2-83ff-4e7d-894a-bbc001fa8f88"},"arguments":[],"births":[]},"resume":{"local_boundary":{"numerator":"10","denominator":"1"},"phase":{"constant":{"numerator":"0","denominator":"1"},"terms":[{"placement":{"reference":{"timing":{"allocation":"ed903801-af9a-4875-a6d0-2ffb76eb830f","ordinal":0},"root":{"type":"project_root_round_even"},"physical":"2edb85c2-83ff-4e7d-894a-bbc001fa8f88"},"arguments":[],"births":[]},"from_local":{"numerator":"0","denominator":"1"},"to_local":{"numerator":"10","denominator":"1"}}]}},"reanchors":[{"placement":{"reference":{"timing":{"allocation":"1fc4c43f-6c56-4450-857a-0fb258ce2a86","ordinal":0},"root":{"type":"project_root_round_even"},"physical":"73b09e6c-178d-48c1-9f43-54960c553afd"},"arguments":[],"births":[]},"window":{"start":{"numerator":"8","denominator":"1"},"end":{"numerator":"25","denominator":"1"}}}]},"b0131c13-21a8-452e-80f8-03b53f60f52e":{"lattice":{"reference":{"timing":{"allocation":"1fc4c43f-6c56-4450-857a-0fb258ce2a86","ordinal":0},"root":{"type":"project_root_round_even"},"physical":"b0131c13-21a8-452e-80f8-03b53f60f52e"},"arguments":[],"births":[]},"resume":null,"reanchors":[{"placement":{"reference":{"timing":{"allocation":"1fc4c43f-6c56-4450-857a-0fb258ce2a86","ordinal":0},"root":{"type":"project_root_round_even"},"physical":"b0131c13-21a8-452e-80f8-03b53f60f52e"},"arguments":[],"births":[]},"window":{"start":{"numerator":"8","denominator":"1"},"end":{"numerator":"25","denominator":"1"}}}]}}}},"identities":{"authored":{"nodes":["bda72595-0561-4467-a29d-4e7684909bdf","d6d89b66-6a83-4eb0-887d-aa96431b3a25","bb001118-8614-4a89-a971-0be003f8e061","f8193895-1d1b-4397-a441-c7f0db498540","b1d7fa9c-dce6-42ad-a964-c35cf58ac892","31704863-ffbc-4c7b-9a5f-0899b1627738","e81420db-1058-45dc-88f1-8a07b43421b1","642dc857-a76e-449e-a5ca-af72ce102ccf"],"marks":[]},"aliases":["1e811fcd-77a3-428c-b95d-1beb2614b135","d77e5c47-0d28-4ed0-8518-5fd7c6c28e69","9bcb11cc-cdd9-4f02-8bb3-3a329db633d5","36e72813-0b9f-4a8d-b475-f577588b48f4","48f70037-69d6-430e-ac05-f1261afb9bd3","9ea46bdd-a0fe-4d29-a0d6-1afab61d0a9c","cf2a92a0-f48f-452a-b93e-e24f7587c5cd","7d19c497-b987-4b24-817b-719dfe43b165","de846a30-5306-4090-8df3-3740176bc808"]},"timing":{"allocation":"c52caa09-1169-4d26-a7e1-4b1184a76833","ordinal":0}}}','{"forward":{"project_id":"e6d1ba97-2db0-4119-9e5d-e4a4bef3e078","from_revision":"3e0ccec9-2254-4c86-9bfa-20db395535fa","to_revision":"c52caa09-1169-4d26-a7e1-4b1184a76833","nodes":{"31704863-ffbc-4c7b-9a5f-0899b1627738":{"before":null,"after":{"label":"Pause","kind":{"type":"hold","recipe":{"picture_context":{"canvases":[{"width":320,"height":180,"fit":"fit","layers":[]}]},"duration":11,"video":{"type":"freeze","asset":"b2868a97-5094-4eb8-9ccd-4a5c904983e0","timestamp":{"ticks":9009,"time_base":{"numerator":1,"denominator":30000}}},"audio":{"type":"silence"}}}}},"44425a05-dc69-45ff-aedd-26c2356c963a":{"before":{"label":"Sequence","kind":{"type":"sequence","children":["2edb85c2-83ff-4e7d-894a-bbc001fa8f88"]}},"after":{"label":"Sequence","kind":{"type":"sequence","children":["bda72595-0561-4467-a29d-4e7684909bdf","2edb85c2-83ff-4e7d-894a-bbc001fa8f88"]}}},"642dc857-a76e-449e-a5ca-af72ce102ccf":{"before":null,"after":{"label":"Copied interval","kind":{"type":"retime","child":"f8193895-1d1b-4397-a441-c7f0db498540","duration":4,"mapping":{"start":0,"end":4},"pitch":"preserve","purpose":"partition"}}},"b1d7fa9c-dce6-42ad-a964-c35cf58ac892":{"before":null,"after":{"label":"cfr-bframes.mp4","kind":{"type":"source","source":{"duration":120,"edit_window":{"start":{"numerator":"0","denominator":"1"},"end":{"numerator":"120","denominator":"1"}},"video":{"type":"stream","asset":"b2868a97-5094-4eb8-9ccd-4a5c904983e0","span":{"start":{"ticks":0,"time_base":{"numerator":1,"denominator":30000}},"end":{"ticks":120120,"time_base":{"numerator":1,"denominator":30000}}}},"video_mapping":{"type":"placement","start":{"numerator":"0","denominator":"1"},"frames":{"numerator":"120","denominator":"1"},"endpoints":"hold_adjacent"},"audio":{"asset":"b2868a97-5094-4eb8-9ccd-4a5c904983e0","span":{"start":{"ticks":0,"time_base":{"numerator":1,"denominator":48000}},"end":{"ticks":192192,"time_base":{"numerator":1,"denominator":48000}}}},"audio_mapping":{"type":"placement","start":{"numerator":"0","denominator":"1"},"frames":{"numerator":"120","denominator":"1"}},"link":"linked","audio_offset":0}}}},"bb001118-8614-4a89-a971-0be003f8e061":{"before":null,"after":{"label":"cfr-bframes.mp4","kind":{"type":"retime","child":"d6d89b66-6a83-4eb0-887d-aa96431b3a25","duration":10,"mapping":{"start":0,"end":10},"pitch":"preserve","purpose":"partition"}}},"bda72595-0561-4467-a29d-4e7684909bdf":{"before":null,"after":{"label":"Copied contents","kind":{"type":"sequence","children":["e81420db-1058-45dc-88f1-8a07b43421b1","31704863-ffbc-4c7b-9a5f-0899b1627738","642dc857-a76e-449e-a5ca-af72ce102ccf"]}}},"d6d89b66-6a83-4eb0-887d-aa96431b3a25":{"before":null,"after":{"label":"cfr-bframes.mp4","kind":{"type":"source","source":{"duration":120,"edit_window":{"start":{"numerator":"0","denominator":"1"},"end":{"numerator":"120","denominator":"1"}},"video":{"type":"stream","asset":"b2868a97-5094-4eb8-9ccd-4a5c904983e0","span":{"start":{"ticks":0,"time_base":{"numerator":1,"denominator":30000}},"end":{"ticks":120120,"time_base":{"numerator":1,"denominator":30000}}}},"video_mapping":{"type":"placement","start":{"numerator":"0","denominator":"1"},"frames":{"numerator":"120","denominator":"1"},"endpoints":"hold_adjacent"},"audio":{"asset":"b2868a97-5094-4eb8-9ccd-4a5c904983e0","span":{"start":{"ticks":0,"time_base":{"numerator":1,"denominator":48000}},"end":{"ticks":192192,"time_base":{"numerator":1,"denominator":48000}}}},"audio_mapping":{"type":"placement","start":{"numerator":"0","denominator":"1"},"frames":{"numerator":"120","denominator":"1"}},"link":"linked","audio_offset":0}}}},"e81420db-1058-45dc-88f1-8a07b43421b1":{"before":null,"after":{"label":"Copied interval","kind":{"type":"retime","child":"bb001118-8614-4a89-a971-0be003f8e061","duration":2,"mapping":{"start":8,"end":10},"pitch":"preserve","purpose":"partition"}}},"f8193895-1d1b-4397-a441-c7f0db498540":{"before":null,"after":{"label":"cfr-bframes.mp4","kind":{"type":"retime","child":"b1d7fa9c-dce6-42ad-a964-c35cf58ac892","duration":110,"mapping":{"start":10,"end":120},"pitch":"preserve","purpose":"partition"}}}},"assets":{},"marks":{},"overrides":{},"audio_lineage":{"b1d7fa9c-dce6-42ad-a964-c35cf58ac892":{"before":null,"after":{"allocation":"c52caa09-1169-4d26-a7e1-4b1184a76833","origin":"de846a30-5306-4090-8df3-3740176bc808"}},"d6d89b66-6a83-4eb0-887d-aa96431b3a25":{"before":null,"after":{"allocation":"c52caa09-1169-4d26-a7e1-4b1184a76833","origin":"de846a30-5306-4090-8df3-3740176bc808"}}},"audio_bindings":{"before":{"timings":[],"bindings":{}},"after":{"timings":[{"id":{"allocation":"c52caa09-1169-4d26-a7e1-4b1184a76833","ordinal":0},"layout":{"root":"44425a05-dc69-45ff-aedd-26c2356c963a","rate":{"numerator":30000,"denominator":1001},"nodes":{"2edb85c2-83ff-4e7d-894a-bbc001fa8f88":{"duration":120,"edges":{"node_start":"automatic","node_end":"automatic","source_placement_start":"automatic","source_placement_end":"automatic","repeat_gap_start":"automatic","repeat_gap_end":"automatic"},"kind":{"type":"source","placement":{"start":{"numerator":"0","denominator":"1"},"end":{"numerator":"120","denominator":"1"}}}},"44425a05-dc69-45ff-aedd-26c2356c963a":{"duration":120,"edges":{"node_start":"automatic","node_end":"automatic","source_placement_start":"automatic","source_placement_end":"automatic","repeat_gap_start":"automatic","repeat_gap_end":"automatic"},"kind":{"type":"sequence","children":["2edb85c2-83ff-4e7d-894a-bbc001fa8f88"]}}},"overrides":{}}},{"id":{"allocation":"c52caa09-1169-4d26-a7e1-4b1184a76833","ordinal":1},"layout":{"root":"d77e5c47-0d28-4ed0-8518-5fd7c6c28e69","rate":{"numerator":30000,"denominator":1001},"nodes":{"1e811fcd-77a3-428c-b95d-1beb2614b135":{"duration":120,"edges":{"node_start":"automatic","node_end":"automatic","source_placement_start":"automatic","source_placement_end":"automatic","repeat_gap_start":"automatic","repeat_gap_end":"automatic"},"kind":{"type":"source","placement":{"start":{"numerator":"0","denominator":"1"},"end":{"numerator":"120","denominator":"1"}}}},"36e72813-0b9f-4a8d-b475-f577588b48f4":{"duration":110,"edges":{"node_start":"automatic","node_end":"automatic","source_placement_start":"automatic","source_placement_end":"automatic","repeat_gap_start":"automatic","repeat_gap_end":"automatic"},"kind":{"type":"retime","child":"48f70037-69d6-430e-ac05-f1261afb9bd3","mapping":{"start":10,"end":120},"pitch":"preserve","purpose":"partition"}},"48f70037-69d6-430e-ac05-f1261afb9bd3":{"duration":120,"edges":{"node_start":"automatic","node_end":"automatic","source_placement_start":"automatic","source_placement_end":"automatic","repeat_gap_start":"automatic","repeat_gap_end":"automatic"},"kind":{"type":"source","placement":{"start":{"numerator":"0","denominator":"1"},"end":{"numerator":"120","denominator":"1"}}}},"9bcb11cc-cdd9-4f02-8bb3-3a329db633d5":{"duration":10,"edges":{"node_start":"automatic","node_end":"automatic","source_placement_start":"automatic","source_placement_end":"automatic","repeat_gap_start":"automatic","repeat_gap_end":"automatic"},"kind":{"type":"retime","child":"1e811fcd-77a3-428c-b95d-1beb2614b135","mapping":{"start":0,"end":10},"pitch":"preserve","purpose":"partition"}},"9ea46bdd-a0fe-4d29-a0d6-1afab61d0a9c":{"duration":11,"edges":{"node_start":"automatic","node_end":"automatic","source_placement_start":"automatic","source_placement_end":"automatic","repeat_gap_start":"automatic","repeat_gap_end":"automatic"},"kind":{"type":"hold","audio":{"type":"silence"}}},"d77e5c47-0d28-4ed0-8518-5fd7c6c28e69":{"duration":131,"edges":{"node_start":"automatic","node_end":"automatic","source_placement_start":"automatic","source_placement_end":"automatic","repeat_gap_start":"automatic","repeat_gap_end":"automatic"},"kind":{"type":"sequence","children":["9bcb11cc-cdd9-4f02-8bb3-3a329db633d5","9ea46bdd-a0fe-4d29-a0d6-1afab61d0a9c","36e72813-0b9f-4a8d-b475-f577588b48f4"]}}},"overrides":{},"audio_lineage":{"1e811fcd-77a3-428c-b95d-1beb2614b135":{"allocation":"c52caa09-1169-4d26-a7e1-4b1184a76833","origin":"de846a30-5306-4090-8df3-3740176bc808"},"48f70037-69d6-430e-ac05-f1261afb9bd3":{"allocation":"c52caa09-1169-4d26-a7e1-4b1184a76833","origin":"de846a30-5306-4090-8df3-3740176bc808"}}}},{"id":{"allocation":"c52caa09-1169-4d26-a7e1-4b1184a76833","ordinal":2},"layout":{"root":"7d19c497-b987-4b24-817b-719dfe43b165","rate":{"numerator":30000,"denominator":1001},"nodes":{"7d19c497-b987-4b24-817b-719dfe43b165":{"duration":120,"edges":{"node_start":"automatic","node_end":"automatic","source_placement_start":"automatic","source_placement_end":"automatic","repeat_gap_start":"automatic","repeat_gap_end":"automatic"},"kind":{"type":"sequence","children":["cf2a92a0-f48f-452a-b93e-e24f7587c5cd"]}},"cf2a92a0-f48f-452a-b93e-e24f7587c5cd":{"duration":120,"edges":{"node_start":"automatic","node_end":"automatic","source_placement_start":"automatic","source_placement_end":"automatic","repeat_gap_start":"automatic","repeat_gap_end":"automatic"},"kind":{"type":"source","placement":{"start":{"numerator":"0","denominator":"1"},"end":{"numerator":"120","denominator":"1"}}}}},"overrides":{}}}],"bindings":{"2edb85c2-83ff-4e7d-894a-bbc001fa8f88":{"lattice":{"reference":{"timing":{"allocation":"c52caa09-1169-4d26-a7e1-4b1184a76833","ordinal":0},"root":{"type":"project_root_round_even"},"physical":"2edb85c2-83ff-4e7d-894a-bbc001fa8f88"},"arguments":[],"births":[]},"resume":null,"reanchors":[{"placement":{"reference":{"timing":{"allocation":"c52caa09-1169-4d26-a7e1-4b1184a76833","ordinal":0},"root":{"type":"project_root_round_even"},"physical":"2edb85c2-83ff-4e7d-894a-bbc001fa8f88"},"arguments":[],"births":[]},"window":{"start":{"numerator":"0","denominator":"1"},"end":{"numerator":"120","denominator":"1"}}}]},"31704863-ffbc-4c7b-9a5f-0899b1627738":{"lattice":{"reference":{"timing":{"allocation":"c52caa09-1169-4d26-a7e1-4b1184a76833","ordinal":1},"root":{"type":"project_root_round_even"},"physical":"9ea46bdd-a0fe-4d29-a0d6-1afab61d0a9c"},"arguments":[],"births":[]},"resume":null,"reanchors":[{"placement":{"reference":{"timing":{"allocation":"c52caa09-1169-4d26-a7e1-4b1184a76833","ordinal":1},"root":{"type":"project_root_round_even"},"physical":"9ea46bdd-a0fe-4d29-a0d6-1afab61d0a9c"},"arguments":[],"births":[]},"window":{"start":{"numerator":"8","denominator":"1"},"end":{"numerator":"25","denominator":"1"}}}]},"b1d7fa9c-dce6-42ad-a964-c35cf58ac892":{"lattice":{"reference":{"timing":{"allocation":"c52caa09-1169-4d26-a7e1-4b1184a76833","ordinal":2},"root":{"type":"project_root_round_even"},"physical":"cf2a92a0-f48f-452a-b93e-e24f7587c5cd"},"arguments":[],"births":[]},"resume":{"local_boundary":{"numerator":"10","denominator":"1"},"phase":{"constant":{"numerator":"0","denominator":"1"},"terms":[{"placement":{"reference":{"timing":{"allocation":"c52caa09-1169-4d26-a7e1-4b1184a76833","ordinal":2},"root":{"type":"project_root_round_even"},"physical":"cf2a92a0-f48f-452a-b93e-e24f7587c5cd"},"arguments":[],"births":[]},"from_local":{"numerator":"0","denominator":"1"},"to_local":{"numerator":"10","denominator":"1"}}]}},"reanchors":[{"placement":{"reference":{"timing":{"allocation":"c52caa09-1169-4d26-a7e1-4b1184a76833","ordinal":1},"root":{"type":"project_root_round_even"},"physical":"48f70037-69d6-430e-ac05-f1261afb9bd3"},"arguments":[],"births":[]},"window":{"start":{"numerator":"8","denominator":"1"},"end":{"numerator":"25","denominator":"1"}}}]},"d6d89b66-6a83-4eb0-887d-aa96431b3a25":{"lattice":{"reference":{"timing":{"allocation":"c52caa09-1169-4d26-a7e1-4b1184a76833","ordinal":2},"root":{"type":"project_root_round_even"},"physical":"cf2a92a0-f48f-452a-b93e-e24f7587c5cd"},"arguments":[],"births":[]},"resume":null,"reanchors":[{"placement":{"reference":{"timing":{"allocation":"c52caa09-1169-4d26-a7e1-4b1184a76833","ordinal":1},"root":{"type":"project_root_round_even"},"physical":"1e811fcd-77a3-428c-b95d-1beb2614b135"},"arguments":[],"births":[]},"window":{"start":{"numerator":"8","denominator":"1"},"end":{"numerator":"25","denominator":"1"}}}]}}}}},"inverse":{"project_id":"e6d1ba97-2db0-4119-9e5d-e4a4bef3e078","from_revision":"c52caa09-1169-4d26-a7e1-4b1184a76833","to_revision":"3e0ccec9-2254-4c86-9bfa-20db395535fa","nodes":{"31704863-ffbc-4c7b-9a5f-0899b1627738":{"before":{"label":"Pause","kind":{"type":"hold","recipe":{"picture_context":{"canvases":[{"width":320,"height":180,"fit":"fit","layers":[]}]},"duration":11,"video":{"type":"freeze","asset":"b2868a97-5094-4eb8-9ccd-4a5c904983e0","timestamp":{"ticks":9009,"time_base":{"numerator":1,"denominator":30000}}},"audio":{"type":"silence"}}}},"after":null},"44425a05-dc69-45ff-aedd-26c2356c963a":{"before":{"label":"Sequence","kind":{"type":"sequence","children":["bda72595-0561-4467-a29d-4e7684909bdf","2edb85c2-83ff-4e7d-894a-bbc001fa8f88"]}},"after":{"label":"Sequence","kind":{"type":"sequence","children":["2edb85c2-83ff-4e7d-894a-bbc001fa8f88"]}}},"642dc857-a76e-449e-a5ca-af72ce102ccf":{"before":{"label":"Copied interval","kind":{"type":"retime","child":"f8193895-1d1b-4397-a441-c7f0db498540","duration":4,"mapping":{"start":0,"end":4},"pitch":"preserve","purpose":"partition"}},"after":null},"b1d7fa9c-dce6-42ad-a964-c35cf58ac892":{"before":{"label":"cfr-bframes.mp4","kind":{"type":"source","source":{"duration":120,"edit_window":{"start":{"numerator":"0","denominator":"1"},"end":{"numerator":"120","denominator":"1"}},"video":{"type":"stream","asset":"b2868a97-5094-4eb8-9ccd-4a5c904983e0","span":{"start":{"ticks":0,"time_base":{"numerator":1,"denominator":30000}},"end":{"ticks":120120,"time_base":{"numerator":1,"denominator":30000}}}},"video_mapping":{"type":"placement","start":{"numerator":"0","denominator":"1"},"frames":{"numerator":"120","denominator":"1"},"endpoints":"hold_adjacent"},"audio":{"asset":"b2868a97-5094-4eb8-9ccd-4a5c904983e0","span":{"start":{"ticks":0,"time_base":{"numerator":1,"denominator":48000}},"end":{"ticks":192192,"time_base":{"numerator":1,"denominator":48000}}}},"audio_mapping":{"type":"placement","start":{"numerator":"0","denominator":"1"},"frames":{"numerator":"120","denominator":"1"}},"link":"linked","audio_offset":0}}},"after":null},"bb001118-8614-4a89-a971-0be003f8e061":{"before":{"label":"cfr-bframes.mp4","kind":{"type":"retime","child":"d6d89b66-6a83-4eb0-887d-aa96431b3a25","duration":10,"mapping":{"start":0,"end":10},"pitch":"preserve","purpose":"partition"}},"after":null},"bda72595-0561-4467-a29d-4e7684909bdf":{"before":{"label":"Copied contents","kind":{"type":"sequence","children":["e81420db-1058-45dc-88f1-8a07b43421b1","31704863-ffbc-4c7b-9a5f-0899b1627738","642dc857-a76e-449e-a5ca-af72ce102ccf"]}},"after":null},"d6d89b66-6a83-4eb0-887d-aa96431b3a25":{"before":{"label":"cfr-bframes.mp4","kind":{"type":"source","source":{"duration":120,"edit_window":{"start":{"numerator":"0","denominator":"1"},"end":{"numerator":"120","denominator":"1"}},"video":{"type":"stream","asset":"b2868a97-5094-4eb8-9ccd-4a5c904983e0","span":{"start":{"ticks":0,"time_base":{"numerator":1,"denominator":30000}},"end":{"ticks":120120,"time_base":{"numerator":1,"denominator":30000}}}},"video_mapping":{"type":"placement","start":{"numerator":"0","denominator":"1"},"frames":{"numerator":"120","denominator":"1"},"endpoints":"hold_adjacent"},"audio":{"asset":"b2868a97-5094-4eb8-9ccd-4a5c904983e0","span":{"start":{"ticks":0,"time_base":{"numerator":1,"denominator":48000}},"end":{"ticks":192192,"time_base":{"numerator":1,"denominator":48000}}}},"audio_mapping":{"type":"placement","start":{"numerator":"0","denominator":"1"},"frames":{"numerator":"120","denominator":"1"}},"link":"linked","audio_offset":0}}},"after":null},"e81420db-1058-45dc-88f1-8a07b43421b1":{"before":{"label":"Copied interval","kind":{"type":"retime","child":"bb001118-8614-4a89-a971-0be003f8e061","duration":2,"mapping":{"start":8,"end":10},"pitch":"preserve","purpose":"partition"}},"after":null},"f8193895-1d1b-4397-a441-c7f0db498540":{"before":{"label":"cfr-bframes.mp4","kind":{"type":"retime","child":"b1d7fa9c-dce6-42ad-a964-c35cf58ac892","duration":110,"mapping":{"start":10,"end":120},"pitch":"preserve","purpose":"partition"}},"after":null}},"assets":{},"marks":{},"overrides":{},"audio_lineage":{"b1d7fa9c-dce6-42ad-a964-c35cf58ac892":{"before":{"allocation":"c52caa09-1169-4d26-a7e1-4b1184a76833","origin":"de846a30-5306-4090-8df3-3740176bc808"},"after":null},"d6d89b66-6a83-4eb0-887d-aa96431b3a25":{"before":{"allocation":"c52caa09-1169-4d26-a7e1-4b1184a76833","origin":"de846a30-5306-4090-8df3-3740176bc808"},"after":null}},"audio_bindings":{"before":{"timings":[{"id":{"allocation":"c52caa09-1169-4d26-a7e1-4b1184a76833","ordinal":0},"layout":{"root":"44425a05-dc69-45ff-aedd-26c2356c963a","rate":{"numerator":30000,"denominator":1001},"nodes":{"2edb85c2-83ff-4e7d-894a-bbc001fa8f88":{"duration":120,"edges":{"node_start":"automatic","node_end":"automatic","source_placement_start":"automatic","source_placement_end":"automatic","repeat_gap_start":"automatic","repeat_gap_end":"automatic"},"kind":{"type":"source","placement":{"start":{"numerator":"0","denominator":"1"},"end":{"numerator":"120","denominator":"1"}}}},"44425a05-dc69-45ff-aedd-26c2356c963a":{"duration":120,"edges":{"node_start":"automatic","node_end":"automatic","source_placement_start":"automatic","source_placement_end":"automatic","repeat_gap_start":"automatic","repeat_gap_end":"automatic"},"kind":{"type":"sequence","children":["2edb85c2-83ff-4e7d-894a-bbc001fa8f88"]}}},"overrides":{}}},{"id":{"allocation":"c52caa09-1169-4d26-a7e1-4b1184a76833","ordinal":1},"layout":{"root":"d77e5c47-0d28-4ed0-8518-5fd7c6c28e69","rate":{"numerator":30000,"denominator":1001},"nodes":{"1e811fcd-77a3-428c-b95d-1beb2614b135":{"duration":120,"edges":{"node_start":"automatic","node_end":"automatic","source_placement_start":"automatic","source_placement_end":"automatic","repeat_gap_start":"automatic","repeat_gap_end":"automatic"},"kind":{"type":"source","placement":{"start":{"numerator":"0","denominator":"1"},"end":{"numerator":"120","denominator":"1"}}}},"36e72813-0b9f-4a8d-b475-f577588b48f4":{"duration":110,"edges":{"node_start":"automatic","node_end":"automatic","source_placement_start":"automatic","source_placement_end":"automatic","repeat_gap_start":"automatic","repeat_gap_end":"automatic"},"kind":{"type":"retime","child":"48f70037-69d6-430e-ac05-f1261afb9bd3","mapping":{"start":10,"end":120},"pitch":"preserve","purpose":"partition"}},"48f70037-69d6-430e-ac05-f1261afb9bd3":{"duration":120,"edges":{"node_start":"automatic","node_end":"automatic","source_placement_start":"automatic","source_placement_end":"automatic","repeat_gap_start":"automatic","repeat_gap_end":"automatic"},"kind":{"type":"source","placement":{"start":{"numerator":"0","denominator":"1"},"end":{"numerator":"120","denominator":"1"}}}},"9bcb11cc-cdd9-4f02-8bb3-3a329db633d5":{"duration":10,"edges":{"node_start":"automatic","node_end":"automatic","source_placement_start":"automatic","source_placement_end":"automatic","repeat_gap_start":"automatic","repeat_gap_end":"automatic"},"kind":{"type":"retime","child":"1e811fcd-77a3-428c-b95d-1beb2614b135","mapping":{"start":0,"end":10},"pitch":"preserve","purpose":"partition"}},"9ea46bdd-a0fe-4d29-a0d6-1afab61d0a9c":{"duration":11,"edges":{"node_start":"automatic","node_end":"automatic","source_placement_start":"automatic","source_placement_end":"automatic","repeat_gap_start":"automatic","repeat_gap_end":"automatic"},"kind":{"type":"hold","audio":{"type":"silence"}}},"d77e5c47-0d28-4ed0-8518-5fd7c6c28e69":{"duration":131,"edges":{"node_start":"automatic","node_end":"automatic","source_placement_start":"automatic","source_placement_end":"automatic","repeat_gap_start":"automatic","repeat_gap_end":"automatic"},"kind":{"type":"sequence","children":["9bcb11cc-cdd9-4f02-8bb3-3a329db633d5","9ea46bdd-a0fe-4d29-a0d6-1afab61d0a9c","36e72813-0b9f-4a8d-b475-f577588b48f4"]}}},"overrides":{},"audio_lineage":{"1e811fcd-77a3-428c-b95d-1beb2614b135":{"allocation":"c52caa09-1169-4d26-a7e1-4b1184a76833","origin":"de846a30-5306-4090-8df3-3740176bc808"},"48f70037-69d6-430e-ac05-f1261afb9bd3":{"allocation":"c52caa09-1169-4d26-a7e1-4b1184a76833","origin":"de846a30-5306-4090-8df3-3740176bc808"}}}},{"id":{"allocation":"c52caa09-1169-4d26-a7e1-4b1184a76833","ordinal":2},"layout":{"root":"7d19c497-b987-4b24-817b-719dfe43b165","rate":{"numerator":30000,"denominator":1001},"nodes":{"7d19c497-b987-4b24-817b-719dfe43b165":{"duration":120,"edges":{"node_start":"automatic","node_end":"automatic","source_placement_start":"automatic","source_placement_end":"automatic","repeat_gap_start":"automatic","repeat_gap_end":"automatic"},"kind":{"type":"sequence","children":["cf2a92a0-f48f-452a-b93e-e24f7587c5cd"]}},"cf2a92a0-f48f-452a-b93e-e24f7587c5cd":{"duration":120,"edges":{"node_start":"automatic","node_end":"automatic","source_placement_start":"automatic","source_placement_end":"automatic","repeat_gap_start":"automatic","repeat_gap_end":"automatic"},"kind":{"type":"source","placement":{"start":{"numerator":"0","denominator":"1"},"end":{"numerator":"120","denominator":"1"}}}}},"overrides":{}}}],"bindings":{"2edb85c2-83ff-4e7d-894a-bbc001fa8f88":{"lattice":{"reference":{"timing":{"allocation":"c52caa09-1169-4d26-a7e1-4b1184a76833","ordinal":0},"root":{"type":"project_root_round_even"},"physical":"2edb85c2-83ff-4e7d-894a-bbc001fa8f88"},"arguments":[],"births":[]},"resume":null,"reanchors":[{"placement":{"reference":{"timing":{"allocation":"c52caa09-1169-4d26-a7e1-4b1184a76833","ordinal":0},"root":{"type":"project_root_round_even"},"physical":"2edb85c2-83ff-4e7d-894a-bbc001fa8f88"},"arguments":[],"births":[]},"window":{"start":{"numerator":"0","denominator":"1"},"end":{"numerator":"120","denominator":"1"}}}]},"31704863-ffbc-4c7b-9a5f-0899b1627738":{"lattice":{"reference":{"timing":{"allocation":"c52caa09-1169-4d26-a7e1-4b1184a76833","ordinal":1},"root":{"type":"project_root_round_even"},"physical":"9ea46bdd-a0fe-4d29-a0d6-1afab61d0a9c"},"arguments":[],"births":[]},"resume":null,"reanchors":[{"placement":{"reference":{"timing":{"allocation":"c52caa09-1169-4d26-a7e1-4b1184a76833","ordinal":1},"root":{"type":"project_root_round_even"},"physical":"9ea46bdd-a0fe-4d29-a0d6-1afab61d0a9c"},"arguments":[],"births":[]},"window":{"start":{"numerator":"8","denominator":"1"},"end":{"numerator":"25","denominator":"1"}}}]},"b1d7fa9c-dce6-42ad-a964-c35cf58ac892":{"lattice":{"reference":{"timing":{"allocation":"c52caa09-1169-4d26-a7e1-4b1184a76833","ordinal":2},"root":{"type":"project_root_round_even"},"physical":"cf2a92a0-f48f-452a-b93e-e24f7587c5cd"},"arguments":[],"births":[]},"resume":{"local_boundary":{"numerator":"10","denominator":"1"},"phase":{"constant":{"numerator":"0","denominator":"1"},"terms":[{"placement":{"reference":{"timing":{"allocation":"c52caa09-1169-4d26-a7e1-4b1184a76833","ordinal":2},"root":{"type":"project_root_round_even"},"physical":"cf2a92a0-f48f-452a-b93e-e24f7587c5cd"},"arguments":[],"births":[]},"from_local":{"numerator":"0","denominator":"1"},"to_local":{"numerator":"10","denominator":"1"}}]}},"reanchors":[{"placement":{"reference":{"timing":{"allocation":"c52caa09-1169-4d26-a7e1-4b1184a76833","ordinal":1},"root":{"type":"project_root_round_even"},"physical":"48f70037-69d6-430e-ac05-f1261afb9bd3"},"arguments":[],"births":[]},"window":{"start":{"numerator":"8","denominator":"1"},"end":{"numerator":"25","denominator":"1"}}}]},"d6d89b66-6a83-4eb0-887d-aa96431b3a25":{"lattice":{"reference":{"timing":{"allocation":"c52caa09-1169-4d26-a7e1-4b1184a76833","ordinal":2},"root":{"type":"project_root_round_even"},"physical":"cf2a92a0-f48f-452a-b93e-e24f7587c5cd"},"arguments":[],"births":[]},"resume":null,"reanchors":[{"placement":{"reference":{"timing":{"allocation":"c52caa09-1169-4d26-a7e1-4b1184a76833","ordinal":1},"root":{"type":"project_root_round_even"},"physical":"1e811fcd-77a3-428c-b95d-1beb2614b135"},"arguments":[],"births":[]},"window":{"start":{"numerator":"8","denominator":"1"},"end":{"numerator":"25","denominator":"1"}}}]}}},"after":{"timings":[],"bindings":{}}}},"changed_ids":["2edb85c2-83ff-4e7d-894a-bbc001fa8f88","31704863-ffbc-4c7b-9a5f-0899b1627738","44425a05-dc69-45ff-aedd-26c2356c963a","642dc857-a76e-449e-a5ca-af72ce102ccf","b1d7fa9c-dce6-42ad-a964-c35cf58ac892","bb001118-8614-4a89-a971-0be003f8e061","bda72595-0561-4467-a29d-4e7684909bdf","d6d89b66-6a83-4eb0-887d-aa96431b3a25","e81420db-1058-45dc-88f1-8a07b43421b1","f8193895-1d1b-4397-a441-c7f0db498540"],"duration_delta":17,"description":"Paste edited slice"}');
CREATE TABLE hold_request_clocks (
    hold_id TEXT PRIMARY KEY,
    high_water INTEGER NOT NULL
        CHECK (high_water BETWEEN 1 AND 9223372036854775807)
) STRICT;
CREATE TABLE original_media (
        content_id TEXT PRIMARY KEY,
        version INTEGER NOT NULL CHECK(version > 0),
        record TEXT NOT NULL CHECK(json_valid(record))
    ) STRICT;
INSERT INTO "original_media" VALUES('blake3:16614ec12d06396d3c0f0e7b91cc902c6dc30ad89c28d74b805cf64dc60d8aa1',1,'{"object":{"content":{"algorithm":"blake3","digest":"16614ec12d06396d3c0f0e7b91cc902c6dc30ad89c28d74b805cf64dc60d8aa1"},"byte_length":39157},"sha256":[90,130,10,121,191,85,13,72,77,142,203,55,255,221,208,72,208,99,103,148,235,206,93,184,62,79,92,229,245,230,73,24],"label":"cfr-bframes.mp4","version":1,"managed":true,"linked":null}');
CREATE TABLE redo (
            position INTEGER PRIMARY KEY,
            history_id INTEGER NOT NULL REFERENCES history(id)
        ) STRICT;
INSERT INTO "redo" VALUES(1,10);
CREATE TABLE register_contents (
            id TEXT PRIMARY KEY,
            capture_revision TEXT NOT NULL REFERENCES revisions(id),
            value TEXT NOT NULL CHECK(json_valid(value))
        ) STRICT;
INSERT INTO "register_contents" VALUES('32f73960277f32c42e54626e2d87780f7c3ebe5c67cdcb150e7d495b7d10075e','ed903801-af9a-4875-a6d0-2ffb76eb830f','{"type":"edited","slice":{"project_id":"e6d1ba97-2db0-4119-9e5d-e4a4bef3e078","revision_id":"ed903801-af9a-4875-a6d0-2ffb76eb830f","capture_timing":{"allocation":"1fc4c43f-6c56-4450-857a-0fb258ce2a86","ordinal":0},"presentation_basis":{"width":320,"height":180,"frame_rate":{"numerator":30000,"denominator":1001},"color_policy":"sdr_rec709"},"parent":"44425a05-dc69-45ff-aedd-26c2356c963a","range":{"start":8,"end":25},"source_duration":131,"parts":[{"root":"4de01272-0476-425e-9ba1-c63b46aa4012","mapping":{"start":8,"end":10},"source_start":0},{"root":"b0131c13-21a8-452e-80f8-03b53f60f52e","mapping":{"start":0,"end":11},"source_start":10},{"root":"6d77dc13-c463-476e-ad1c-948bf919538b","mapping":{"start":0,"end":4},"source_start":21}],"nodes":{"2edb85c2-83ff-4e7d-894a-bbc001fa8f88":{"label":"cfr-bframes.mp4","kind":{"type":"source","source":{"duration":120,"edit_window":{"start":{"numerator":"0","denominator":"1"},"end":{"numerator":"120","denominator":"1"}},"video":{"type":"stream","asset":"b2868a97-5094-4eb8-9ccd-4a5c904983e0","span":{"start":{"ticks":0,"time_base":{"numerator":1,"denominator":30000}},"end":{"ticks":120120,"time_base":{"numerator":1,"denominator":30000}}}},"video_mapping":{"type":"placement","start":{"numerator":"0","denominator":"1"},"frames":{"numerator":"120","denominator":"1"},"endpoints":"hold_adjacent"},"audio":{"asset":"b2868a97-5094-4eb8-9ccd-4a5c904983e0","span":{"start":{"ticks":0,"time_base":{"numerator":1,"denominator":48000}},"end":{"ticks":192192,"time_base":{"numerator":1,"denominator":48000}}}},"audio_mapping":{"type":"placement","start":{"numerator":"0","denominator":"1"},"frames":{"numerator":"120","denominator":"1"}},"link":"linked","audio_offset":0}}},"4de01272-0476-425e-9ba1-c63b46aa4012":{"label":"cfr-bframes.mp4","kind":{"type":"retime","child":"2edb85c2-83ff-4e7d-894a-bbc001fa8f88","duration":10,"mapping":{"start":0,"end":10},"pitch":"preserve","purpose":"partition"}},"6d77dc13-c463-476e-ad1c-948bf919538b":{"label":"cfr-bframes.mp4","kind":{"type":"retime","child":"73b09e6c-178d-48c1-9f43-54960c553afd","duration":110,"mapping":{"start":10,"end":120},"pitch":"preserve","purpose":"partition"}},"73b09e6c-178d-48c1-9f43-54960c553afd":{"label":"cfr-bframes.mp4","kind":{"type":"source","source":{"duration":120,"edit_window":{"start":{"numerator":"0","denominator":"1"},"end":{"numerator":"120","denominator":"1"}},"video":{"type":"stream","asset":"b2868a97-5094-4eb8-9ccd-4a5c904983e0","span":{"start":{"ticks":0,"time_base":{"numerator":1,"denominator":30000}},"end":{"ticks":120120,"time_base":{"numerator":1,"denominator":30000}}}},"video_mapping":{"type":"placement","start":{"numerator":"0","denominator":"1"},"frames":{"numerator":"120","denominator":"1"},"endpoints":"hold_adjacent"},"audio":{"asset":"b2868a97-5094-4eb8-9ccd-4a5c904983e0","span":{"start":{"ticks":0,"time_base":{"numerator":1,"denominator":48000}},"end":{"ticks":192192,"time_base":{"numerator":1,"denominator":48000}}}},"audio_mapping":{"type":"placement","start":{"numerator":"0","denominator":"1"},"frames":{"numerator":"120","denominator":"1"}},"link":"linked","audio_offset":0}}},"b0131c13-21a8-452e-80f8-03b53f60f52e":{"label":"Pause","kind":{"type":"hold","recipe":{"picture_context":{"canvases":[{"width":320,"height":180,"fit":"fit","layers":[]}]},"duration":11,"video":{"type":"freeze","asset":"b2868a97-5094-4eb8-9ccd-4a5c904983e0","timestamp":{"ticks":9009,"time_base":{"numerator":1,"denominator":30000}}},"audio":{"type":"silence"}}}}},"assets":{"b2868a97-5094-4eb8-9ccd-4a5c904983e0":{"label":"cfr-bframes.mp4","content_hash":"blake3:16614ec12d06396d3c0f0e7b91cc902c6dc30ad89c28d74b805cf64dc60d8aa1","video":{"start":{"ticks":0,"time_base":{"numerator":1,"denominator":30000}},"end":{"ticks":120120,"time_base":{"numerator":1,"denominator":30000}}},"audio":{"start":{"ticks":0,"time_base":{"numerator":1,"denominator":48000}},"end":{"ticks":192192,"time_base":{"numerator":1,"denominator":48000}}},"still_image":false,"frame_count":120,"source_qualification":"c6bc3e81ab69906267164469d11739cf1363eea546436761ddd219069ed496b6"}},"marks":{},"overrides":{},"gap_overrides":{},"audio_lineage":{"2edb85c2-83ff-4e7d-894a-bbc001fa8f88":{"allocation":"ed903801-af9a-4875-a6d0-2ffb76eb830f","origin":"2edb85c2-83ff-4e7d-894a-bbc001fa8f88"},"73b09e6c-178d-48c1-9f43-54960c553afd":{"allocation":"ed903801-af9a-4875-a6d0-2ffb76eb830f","origin":"2edb85c2-83ff-4e7d-894a-bbc001fa8f88"}},"audio_bindings":{"timings":[{"id":{"allocation":"1fc4c43f-6c56-4450-857a-0fb258ce2a86","ordinal":0},"layout":{"root":"44425a05-dc69-45ff-aedd-26c2356c963a","rate":{"numerator":30000,"denominator":1001},"nodes":{"2edb85c2-83ff-4e7d-894a-bbc001fa8f88":{"duration":120,"edges":{"node_start":"automatic","node_end":"automatic","source_placement_start":"automatic","source_placement_end":"automatic","repeat_gap_start":"automatic","repeat_gap_end":"automatic"},"kind":{"type":"source","placement":{"start":{"numerator":"0","denominator":"1"},"end":{"numerator":"120","denominator":"1"}}}},"44425a05-dc69-45ff-aedd-26c2356c963a":{"duration":131,"edges":{"node_start":"automatic","node_end":"automatic","source_placement_start":"automatic","source_placement_end":"automatic","repeat_gap_start":"automatic","repeat_gap_end":"automatic"},"kind":{"type":"sequence","children":["4de01272-0476-425e-9ba1-c63b46aa4012","b0131c13-21a8-452e-80f8-03b53f60f52e","6d77dc13-c463-476e-ad1c-948bf919538b"]}},"4de01272-0476-425e-9ba1-c63b46aa4012":{"duration":10,"edges":{"node_start":"automatic","node_end":"automatic","source_placement_start":"automatic","source_placement_end":"automatic","repeat_gap_start":"automatic","repeat_gap_end":"automatic"},"kind":{"type":"retime","child":"2edb85c2-83ff-4e7d-894a-bbc001fa8f88","mapping":{"start":0,"end":10},"pitch":"preserve","purpose":"partition"}},"6d77dc13-c463-476e-ad1c-948bf919538b":{"duration":110,"edges":{"node_start":"automatic","node_end":"automatic","source_placement_start":"automatic","source_placement_end":"automatic","repeat_gap_start":"automatic","repeat_gap_end":"automatic"},"kind":{"type":"retime","child":"73b09e6c-178d-48c1-9f43-54960c553afd","mapping":{"start":10,"end":120},"pitch":"preserve","purpose":"partition"}},"73b09e6c-178d-48c1-9f43-54960c553afd":{"duration":120,"edges":{"node_start":"automatic","node_end":"automatic","source_placement_start":"automatic","source_placement_end":"automatic","repeat_gap_start":"automatic","repeat_gap_end":"automatic"},"kind":{"type":"source","placement":{"start":{"numerator":"0","denominator":"1"},"end":{"numerator":"120","denominator":"1"}}}},"b0131c13-21a8-452e-80f8-03b53f60f52e":{"duration":11,"edges":{"node_start":"automatic","node_end":"automatic","source_placement_start":"automatic","source_placement_end":"automatic","repeat_gap_start":"automatic","repeat_gap_end":"automatic"},"kind":{"type":"hold","audio":{"type":"silence"}}}},"overrides":{},"audio_lineage":{"2edb85c2-83ff-4e7d-894a-bbc001fa8f88":{"allocation":"ed903801-af9a-4875-a6d0-2ffb76eb830f","origin":"2edb85c2-83ff-4e7d-894a-bbc001fa8f88"},"73b09e6c-178d-48c1-9f43-54960c553afd":{"allocation":"ed903801-af9a-4875-a6d0-2ffb76eb830f","origin":"2edb85c2-83ff-4e7d-894a-bbc001fa8f88"}}}},{"id":{"allocation":"ed903801-af9a-4875-a6d0-2ffb76eb830f","ordinal":0},"layout":{"root":"44425a05-dc69-45ff-aedd-26c2356c963a","rate":{"numerator":30000,"denominator":1001},"nodes":{"2edb85c2-83ff-4e7d-894a-bbc001fa8f88":{"duration":120,"edges":{"node_start":"automatic","node_end":"automatic","source_placement_start":"automatic","source_placement_end":"automatic","repeat_gap_start":"automatic","repeat_gap_end":"automatic"},"kind":{"type":"source","placement":{"start":{"numerator":"0","denominator":"1"},"end":{"numerator":"120","denominator":"1"}}}},"44425a05-dc69-45ff-aedd-26c2356c963a":{"duration":120,"edges":{"node_start":"automatic","node_end":"automatic","source_placement_start":"automatic","source_placement_end":"automatic","repeat_gap_start":"automatic","repeat_gap_end":"automatic"},"kind":{"type":"sequence","children":["2edb85c2-83ff-4e7d-894a-bbc001fa8f88"]}}},"overrides":{}}}],"bindings":{"2edb85c2-83ff-4e7d-894a-bbc001fa8f88":{"lattice":{"reference":{"timing":{"allocation":"ed903801-af9a-4875-a6d0-2ffb76eb830f","ordinal":0},"root":{"type":"project_root_round_even"},"physical":"2edb85c2-83ff-4e7d-894a-bbc001fa8f88"},"arguments":[],"births":[]},"resume":null,"reanchors":[{"placement":{"reference":{"timing":{"allocation":"1fc4c43f-6c56-4450-857a-0fb258ce2a86","ordinal":0},"root":{"type":"project_root_round_even"},"physical":"2edb85c2-83ff-4e7d-894a-bbc001fa8f88"},"arguments":[],"births":[]},"window":{"start":{"numerator":"8","denominator":"1"},"end":{"numerator":"25","denominator":"1"}}}]},"73b09e6c-178d-48c1-9f43-54960c553afd":{"lattice":{"reference":{"timing":{"allocation":"ed903801-af9a-4875-a6d0-2ffb76eb830f","ordinal":0},"root":{"type":"project_root_round_even"},"physical":"2edb85c2-83ff-4e7d-894a-bbc001fa8f88"},"arguments":[],"births":[]},"resume":{"local_boundary":{"numerator":"10","denominator":"1"},"phase":{"constant":{"numerator":"0","denominator":"1"},"terms":[{"placement":{"reference":{"timing":{"allocation":"ed903801-af9a-4875-a6d0-2ffb76eb830f","ordinal":0},"root":{"type":"project_root_round_even"},"physical":"2edb85c2-83ff-4e7d-894a-bbc001fa8f88"},"arguments":[],"births":[]},"from_local":{"numerator":"0","denominator":"1"},"to_local":{"numerator":"10","denominator":"1"}}]}},"reanchors":[{"placement":{"reference":{"timing":{"allocation":"1fc4c43f-6c56-4450-857a-0fb258ce2a86","ordinal":0},"root":{"type":"project_root_round_even"},"physical":"73b09e6c-178d-48c1-9f43-54960c553afd"},"arguments":[],"births":[]},"window":{"start":{"numerator":"8","denominator":"1"},"end":{"numerator":"25","denominator":"1"}}}]},"b0131c13-21a8-452e-80f8-03b53f60f52e":{"lattice":{"reference":{"timing":{"allocation":"1fc4c43f-6c56-4450-857a-0fb258ce2a86","ordinal":0},"root":{"type":"project_root_round_even"},"physical":"b0131c13-21a8-452e-80f8-03b53f60f52e"},"arguments":[],"births":[]},"resume":null,"reanchors":[{"placement":{"reference":{"timing":{"allocation":"1fc4c43f-6c56-4450-857a-0fb258ce2a86","ordinal":0},"root":{"type":"project_root_round_even"},"physical":"b0131c13-21a8-452e-80f8-03b53f60f52e"},"arguments":[],"births":[]},"window":{"start":{"numerator":"8","denominator":"1"},"end":{"numerator":"25","denominator":"1"}}}]}}}}}');
INSERT INTO "register_contents" VALUES('5158f240c9869a63785909e9917e4ca028648761838d337aefdef5eb0c74f93a','b5c2fe56-b4d6-42ce-9243-90a7976b1b46','{"type":"edited","slice":{"project_id":"e6d1ba97-2db0-4119-9e5d-e4a4bef3e078","revision_id":"b5c2fe56-b4d6-42ce-9243-90a7976b1b46","capture_timing":{"allocation":"042f6ab8-938c-4857-9bf8-49206030d853","ordinal":0},"presentation_basis":{"width":320,"height":180,"frame_rate":{"numerator":30000,"denominator":1001},"color_policy":"sdr_rec709"},"parent":"44425a05-dc69-45ff-aedd-26c2356c963a","range":{"start":20,"end":30},"source_duration":120,"parts":[{"root":"2edb85c2-83ff-4e7d-894a-bbc001fa8f88","mapping":{"start":20,"end":30},"source_start":0}],"nodes":{"2edb85c2-83ff-4e7d-894a-bbc001fa8f88":{"label":"cfr-bframes.mp4","kind":{"type":"source","source":{"duration":120,"edit_window":{"start":{"numerator":"0","denominator":"1"},"end":{"numerator":"120","denominator":"1"}},"video":{"type":"stream","asset":"b2868a97-5094-4eb8-9ccd-4a5c904983e0","span":{"start":{"ticks":0,"time_base":{"numerator":1,"denominator":30000}},"end":{"ticks":120120,"time_base":{"numerator":1,"denominator":30000}}}},"video_mapping":{"type":"placement","start":{"numerator":"0","denominator":"1"},"frames":{"numerator":"120","denominator":"1"},"endpoints":"hold_adjacent"},"audio":{"asset":"b2868a97-5094-4eb8-9ccd-4a5c904983e0","span":{"start":{"ticks":0,"time_base":{"numerator":1,"denominator":48000}},"end":{"ticks":192192,"time_base":{"numerator":1,"denominator":48000}}}},"audio_mapping":{"type":"placement","start":{"numerator":"0","denominator":"1"},"frames":{"numerator":"120","denominator":"1"}},"link":"linked","audio_offset":0}}}},"assets":{"b2868a97-5094-4eb8-9ccd-4a5c904983e0":{"label":"cfr-bframes.mp4","content_hash":"blake3:16614ec12d06396d3c0f0e7b91cc902c6dc30ad89c28d74b805cf64dc60d8aa1","video":{"start":{"ticks":0,"time_base":{"numerator":1,"denominator":30000}},"end":{"ticks":120120,"time_base":{"numerator":1,"denominator":30000}}},"audio":{"start":{"ticks":0,"time_base":{"numerator":1,"denominator":48000}},"end":{"ticks":192192,"time_base":{"numerator":1,"denominator":48000}}},"still_image":false,"frame_count":120,"source_qualification":"c6bc3e81ab69906267164469d11739cf1363eea546436761ddd219069ed496b6"}},"marks":{},"overrides":{},"gap_overrides":{},"audio_lineage":{},"audio_bindings":{"timings":[{"id":{"allocation":"042f6ab8-938c-4857-9bf8-49206030d853","ordinal":0},"layout":{"root":"44425a05-dc69-45ff-aedd-26c2356c963a","rate":{"numerator":30000,"denominator":1001},"nodes":{"2edb85c2-83ff-4e7d-894a-bbc001fa8f88":{"duration":120,"edges":{"node_start":"automatic","node_end":"automatic","source_placement_start":"automatic","source_placement_end":"automatic","repeat_gap_start":"automatic","repeat_gap_end":"automatic"},"kind":{"type":"source","placement":{"start":{"numerator":"0","denominator":"1"},"end":{"numerator":"120","denominator":"1"}}}},"44425a05-dc69-45ff-aedd-26c2356c963a":{"duration":120,"edges":{"node_start":"automatic","node_end":"automatic","source_placement_start":"automatic","source_placement_end":"automatic","repeat_gap_start":"automatic","repeat_gap_end":"automatic"},"kind":{"type":"sequence","children":["2edb85c2-83ff-4e7d-894a-bbc001fa8f88"]}}},"overrides":{}}}],"bindings":{"2edb85c2-83ff-4e7d-894a-bbc001fa8f88":{"lattice":{"reference":{"timing":{"allocation":"042f6ab8-938c-4857-9bf8-49206030d853","ordinal":0},"root":{"type":"project_root_round_even"},"physical":"2edb85c2-83ff-4e7d-894a-bbc001fa8f88"},"arguments":[],"births":[]},"resume":null,"reanchors":[{"placement":{"reference":{"timing":{"allocation":"042f6ab8-938c-4857-9bf8-49206030d853","ordinal":0},"root":{"type":"project_root_round_even"},"physical":"2edb85c2-83ff-4e7d-894a-bbc001fa8f88"},"arguments":[],"births":[]},"window":{"start":{"numerator":"20","denominator":"1"},"end":{"numerator":"30","denominator":"1"}}}]}}}}}');
INSERT INTO "register_contents" VALUES('5beda2f2464f2d33eb6275faa87b0ceb1a290a88f1ebd9140af9bd09ab29d3cf','8eec44f6-1120-4904-8760-1f4ae33aa95c','{"type":"original","revision":"8eec44f6-1120-4904-8760-1f4ae33aa95c","asset":"b2868a97-5094-4eb8-9ccd-4a5c904983e0","qualification":"c6bc3e81ab69906267164469d11739cf1363eea546436761ddd219069ed496b6","ordinals":{"start":40,"end":43}}');
INSERT INTO "register_contents" VALUES('2e934c0d5afd4939b4ac2c18eb162ee2302ac0d49d84a1f1502c3ee0bddd7230','ab2073bb-c82a-43c8-95aa-0dfa8f49275d','{"type":"edited","slice":{"project_id":"e6d1ba97-2db0-4119-9e5d-e4a4bef3e078","revision_id":"ab2073bb-c82a-43c8-95aa-0dfa8f49275d","capture_timing":{"allocation":"ceee903b-00d5-4df6-93b7-9d57cc0b733d","ordinal":0},"presentation_basis":{"width":320,"height":180,"frame_rate":{"numerator":30000,"denominator":1001},"color_policy":"sdr_rec709"},"parent":"44425a05-dc69-45ff-aedd-26c2356c963a","range":{"start":45,"end":51},"source_duration":120,"parts":[{"root":"2edb85c2-83ff-4e7d-894a-bbc001fa8f88","mapping":{"start":45,"end":51},"source_start":0}],"nodes":{"2edb85c2-83ff-4e7d-894a-bbc001fa8f88":{"label":"cfr-bframes.mp4","kind":{"type":"source","source":{"duration":120,"edit_window":{"start":{"numerator":"0","denominator":"1"},"end":{"numerator":"120","denominator":"1"}},"video":{"type":"stream","asset":"b2868a97-5094-4eb8-9ccd-4a5c904983e0","span":{"start":{"ticks":0,"time_base":{"numerator":1,"denominator":30000}},"end":{"ticks":120120,"time_base":{"numerator":1,"denominator":30000}}}},"video_mapping":{"type":"placement","start":{"numerator":"0","denominator":"1"},"frames":{"numerator":"120","denominator":"1"},"endpoints":"hold_adjacent"},"audio":{"asset":"b2868a97-5094-4eb8-9ccd-4a5c904983e0","span":{"start":{"ticks":0,"time_base":{"numerator":1,"denominator":48000}},"end":{"ticks":192192,"time_base":{"numerator":1,"denominator":48000}}}},"audio_mapping":{"type":"placement","start":{"numerator":"0","denominator":"1"},"frames":{"numerator":"120","denominator":"1"}},"link":"linked","audio_offset":0}}}},"assets":{"b2868a97-5094-4eb8-9ccd-4a5c904983e0":{"label":"cfr-bframes.mp4","content_hash":"blake3:16614ec12d06396d3c0f0e7b91cc902c6dc30ad89c28d74b805cf64dc60d8aa1","video":{"start":{"ticks":0,"time_base":{"numerator":1,"denominator":30000}},"end":{"ticks":120120,"time_base":{"numerator":1,"denominator":30000}}},"audio":{"start":{"ticks":0,"time_base":{"numerator":1,"denominator":48000}},"end":{"ticks":192192,"time_base":{"numerator":1,"denominator":48000}}},"still_image":false,"frame_count":120,"source_qualification":"c6bc3e81ab69906267164469d11739cf1363eea546436761ddd219069ed496b6"}},"marks":{},"overrides":{},"gap_overrides":{},"audio_lineage":{},"audio_bindings":{"timings":[{"id":{"allocation":"ceee903b-00d5-4df6-93b7-9d57cc0b733d","ordinal":0},"layout":{"root":"44425a05-dc69-45ff-aedd-26c2356c963a","rate":{"numerator":30000,"denominator":1001},"nodes":{"2edb85c2-83ff-4e7d-894a-bbc001fa8f88":{"duration":120,"edges":{"node_start":"automatic","node_end":"automatic","source_placement_start":"automatic","source_placement_end":"automatic","repeat_gap_start":"automatic","repeat_gap_end":"automatic"},"kind":{"type":"source","placement":{"start":{"numerator":"0","denominator":"1"},"end":{"numerator":"120","denominator":"1"}}}},"44425a05-dc69-45ff-aedd-26c2356c963a":{"duration":120,"edges":{"node_start":"automatic","node_end":"automatic","source_placement_start":"automatic","source_placement_end":"automatic","repeat_gap_start":"automatic","repeat_gap_end":"automatic"},"kind":{"type":"sequence","children":["2edb85c2-83ff-4e7d-894a-bbc001fa8f88"]}}},"overrides":{}}}],"bindings":{"2edb85c2-83ff-4e7d-894a-bbc001fa8f88":{"lattice":{"reference":{"timing":{"allocation":"ceee903b-00d5-4df6-93b7-9d57cc0b733d","ordinal":0},"root":{"type":"project_root_round_even"},"physical":"2edb85c2-83ff-4e7d-894a-bbc001fa8f88"},"arguments":[],"births":[]},"resume":null,"reanchors":[{"placement":{"reference":{"timing":{"allocation":"ceee903b-00d5-4df6-93b7-9d57cc0b733d","ordinal":0},"root":{"type":"project_root_round_even"},"physical":"2edb85c2-83ff-4e7d-894a-bbc001fa8f88"},"arguments":[],"births":[]},"window":{"start":{"numerator":"45","denominator":"1"},"end":{"numerator":"51","denominator":"1"}}}]}}}}}');
INSERT INTO "register_contents" VALUES('0382549fc9c580361095dd1352f5f25d017ffbe38d7b2dea5e0f8fd44ec75ae4','ab2073bb-c82a-43c8-95aa-0dfa8f49275d','{"type":"edited","slice":{"project_id":"e6d1ba97-2db0-4119-9e5d-e4a4bef3e078","revision_id":"ab2073bb-c82a-43c8-95aa-0dfa8f49275d","capture_timing":{"allocation":"b4b0eb1e-fb16-4d33-9395-b05f81e28bb1","ordinal":0},"presentation_basis":{"width":320,"height":180,"frame_rate":{"numerator":30000,"denominator":1001},"color_policy":"sdr_rec709"},"parent":"44425a05-dc69-45ff-aedd-26c2356c963a","range":{"start":55,"end":61},"source_duration":120,"parts":[{"root":"2edb85c2-83ff-4e7d-894a-bbc001fa8f88","mapping":{"start":55,"end":61},"source_start":0}],"nodes":{"2edb85c2-83ff-4e7d-894a-bbc001fa8f88":{"label":"cfr-bframes.mp4","kind":{"type":"source","source":{"duration":120,"edit_window":{"start":{"numerator":"0","denominator":"1"},"end":{"numerator":"120","denominator":"1"}},"video":{"type":"stream","asset":"b2868a97-5094-4eb8-9ccd-4a5c904983e0","span":{"start":{"ticks":0,"time_base":{"numerator":1,"denominator":30000}},"end":{"ticks":120120,"time_base":{"numerator":1,"denominator":30000}}}},"video_mapping":{"type":"placement","start":{"numerator":"0","denominator":"1"},"frames":{"numerator":"120","denominator":"1"},"endpoints":"hold_adjacent"},"audio":{"asset":"b2868a97-5094-4eb8-9ccd-4a5c904983e0","span":{"start":{"ticks":0,"time_base":{"numerator":1,"denominator":48000}},"end":{"ticks":192192,"time_base":{"numerator":1,"denominator":48000}}}},"audio_mapping":{"type":"placement","start":{"numerator":"0","denominator":"1"},"frames":{"numerator":"120","denominator":"1"}},"link":"linked","audio_offset":0}}}},"assets":{"b2868a97-5094-4eb8-9ccd-4a5c904983e0":{"label":"cfr-bframes.mp4","content_hash":"blake3:16614ec12d06396d3c0f0e7b91cc902c6dc30ad89c28d74b805cf64dc60d8aa1","video":{"start":{"ticks":0,"time_base":{"numerator":1,"denominator":30000}},"end":{"ticks":120120,"time_base":{"numerator":1,"denominator":30000}}},"audio":{"start":{"ticks":0,"time_base":{"numerator":1,"denominator":48000}},"end":{"ticks":192192,"time_base":{"numerator":1,"denominator":48000}}},"still_image":false,"frame_count":120,"source_qualification":"c6bc3e81ab69906267164469d11739cf1363eea546436761ddd219069ed496b6"}},"marks":{},"overrides":{},"gap_overrides":{},"audio_lineage":{},"audio_bindings":{"timings":[{"id":{"allocation":"b4b0eb1e-fb16-4d33-9395-b05f81e28bb1","ordinal":0},"layout":{"root":"44425a05-dc69-45ff-aedd-26c2356c963a","rate":{"numerator":30000,"denominator":1001},"nodes":{"2edb85c2-83ff-4e7d-894a-bbc001fa8f88":{"duration":120,"edges":{"node_start":"automatic","node_end":"automatic","source_placement_start":"automatic","source_placement_end":"automatic","repeat_gap_start":"automatic","repeat_gap_end":"automatic"},"kind":{"type":"source","placement":{"start":{"numerator":"0","denominator":"1"},"end":{"numerator":"120","denominator":"1"}}}},"44425a05-dc69-45ff-aedd-26c2356c963a":{"duration":120,"edges":{"node_start":"automatic","node_end":"automatic","source_placement_start":"automatic","source_placement_end":"automatic","repeat_gap_start":"automatic","repeat_gap_end":"automatic"},"kind":{"type":"sequence","children":["2edb85c2-83ff-4e7d-894a-bbc001fa8f88"]}}},"overrides":{}}}],"bindings":{"2edb85c2-83ff-4e7d-894a-bbc001fa8f88":{"lattice":{"reference":{"timing":{"allocation":"b4b0eb1e-fb16-4d33-9395-b05f81e28bb1","ordinal":0},"root":{"type":"project_root_round_even"},"physical":"2edb85c2-83ff-4e7d-894a-bbc001fa8f88"},"arguments":[],"births":[]},"resume":null,"reanchors":[{"placement":{"reference":{"timing":{"allocation":"b4b0eb1e-fb16-4d33-9395-b05f81e28bb1","ordinal":0},"root":{"type":"project_root_round_even"},"physical":"2edb85c2-83ff-4e7d-894a-bbc001fa8f88"},"arguments":[],"births":[]},"window":{"start":{"numerator":"55","denominator":"1"},"end":{"numerator":"61","denominator":"1"}}}]}}}}}');
INSERT INTO "register_contents" VALUES('3b46f4628097dc5577eca524c2485d86ed6bb66db8bcb372249f16f20c1aa93d','ab2073bb-c82a-43c8-95aa-0dfa8f49275d','{"type":"edited","slice":{"project_id":"e6d1ba97-2db0-4119-9e5d-e4a4bef3e078","revision_id":"ab2073bb-c82a-43c8-95aa-0dfa8f49275d","capture_timing":{"allocation":"8362d427-bb6b-4d5f-b40c-e00ad4c49ec6","ordinal":0},"presentation_basis":{"width":320,"height":180,"frame_rate":{"numerator":30000,"denominator":1001},"color_policy":"sdr_rec709"},"parent":"44425a05-dc69-45ff-aedd-26c2356c963a","range":{"start":75,"end":81},"source_duration":120,"parts":[{"root":"2edb85c2-83ff-4e7d-894a-bbc001fa8f88","mapping":{"start":75,"end":81},"source_start":0}],"nodes":{"2edb85c2-83ff-4e7d-894a-bbc001fa8f88":{"label":"cfr-bframes.mp4","kind":{"type":"source","source":{"duration":120,"edit_window":{"start":{"numerator":"0","denominator":"1"},"end":{"numerator":"120","denominator":"1"}},"video":{"type":"stream","asset":"b2868a97-5094-4eb8-9ccd-4a5c904983e0","span":{"start":{"ticks":0,"time_base":{"numerator":1,"denominator":30000}},"end":{"ticks":120120,"time_base":{"numerator":1,"denominator":30000}}}},"video_mapping":{"type":"placement","start":{"numerator":"0","denominator":"1"},"frames":{"numerator":"120","denominator":"1"},"endpoints":"hold_adjacent"},"audio":{"asset":"b2868a97-5094-4eb8-9ccd-4a5c904983e0","span":{"start":{"ticks":0,"time_base":{"numerator":1,"denominator":48000}},"end":{"ticks":192192,"time_base":{"numerator":1,"denominator":48000}}}},"audio_mapping":{"type":"placement","start":{"numerator":"0","denominator":"1"},"frames":{"numerator":"120","denominator":"1"}},"link":"linked","audio_offset":0}}}},"assets":{"b2868a97-5094-4eb8-9ccd-4a5c904983e0":{"label":"cfr-bframes.mp4","content_hash":"blake3:16614ec12d06396d3c0f0e7b91cc902c6dc30ad89c28d74b805cf64dc60d8aa1","video":{"start":{"ticks":0,"time_base":{"numerator":1,"denominator":30000}},"end":{"ticks":120120,"time_base":{"numerator":1,"denominator":30000}}},"audio":{"start":{"ticks":0,"time_base":{"numerator":1,"denominator":48000}},"end":{"ticks":192192,"time_base":{"numerator":1,"denominator":48000}}},"still_image":false,"frame_count":120,"source_qualification":"c6bc3e81ab69906267164469d11739cf1363eea546436761ddd219069ed496b6"}},"marks":{},"overrides":{},"gap_overrides":{},"audio_lineage":{},"audio_bindings":{"timings":[{"id":{"allocation":"8362d427-bb6b-4d5f-b40c-e00ad4c49ec6","ordinal":0},"layout":{"root":"44425a05-dc69-45ff-aedd-26c2356c963a","rate":{"numerator":30000,"denominator":1001},"nodes":{"2edb85c2-83ff-4e7d-894a-bbc001fa8f88":{"duration":120,"edges":{"node_start":"automatic","node_end":"automatic","source_placement_start":"automatic","source_placement_end":"automatic","repeat_gap_start":"automatic","repeat_gap_end":"automatic"},"kind":{"type":"source","placement":{"start":{"numerator":"0","denominator":"1"},"end":{"numerator":"120","denominator":"1"}}}},"44425a05-dc69-45ff-aedd-26c2356c963a":{"duration":120,"edges":{"node_start":"automatic","node_end":"automatic","source_placement_start":"automatic","source_placement_end":"automatic","repeat_gap_start":"automatic","repeat_gap_end":"automatic"},"kind":{"type":"sequence","children":["2edb85c2-83ff-4e7d-894a-bbc001fa8f88"]}}},"overrides":{}}}],"bindings":{"2edb85c2-83ff-4e7d-894a-bbc001fa8f88":{"lattice":{"reference":{"timing":{"allocation":"8362d427-bb6b-4d5f-b40c-e00ad4c49ec6","ordinal":0},"root":{"type":"project_root_round_even"},"physical":"2edb85c2-83ff-4e7d-894a-bbc001fa8f88"},"arguments":[],"births":[]},"resume":null,"reanchors":[{"placement":{"reference":{"timing":{"allocation":"8362d427-bb6b-4d5f-b40c-e00ad4c49ec6","ordinal":0},"root":{"type":"project_root_round_even"},"physical":"2edb85c2-83ff-4e7d-894a-bbc001fa8f88"},"arguments":[],"births":[]},"window":{"start":{"numerator":"75","denominator":"1"},"end":{"numerator":"81","denominator":"1"}}}]}}}}}');
INSERT INTO "register_contents" VALUES('57c4315ee10452b33d65464cba291e3e232d5d875fc83ddfce810a8961c6c037','ab2073bb-c82a-43c8-95aa-0dfa8f49275d','{"type":"edited","slice":{"project_id":"e6d1ba97-2db0-4119-9e5d-e4a4bef3e078","revision_id":"ab2073bb-c82a-43c8-95aa-0dfa8f49275d","capture_timing":{"allocation":"3a246480-e04b-434c-adb6-44f6814fa200","ordinal":0},"presentation_basis":{"width":320,"height":180,"frame_rate":{"numerator":30000,"denominator":1001},"color_policy":"sdr_rec709"},"parent":"44425a05-dc69-45ff-aedd-26c2356c963a","range":{"start":65,"end":70},"source_duration":120,"parts":[{"root":"2edb85c2-83ff-4e7d-894a-bbc001fa8f88","mapping":{"start":65,"end":70},"source_start":0}],"nodes":{"2edb85c2-83ff-4e7d-894a-bbc001fa8f88":{"label":"cfr-bframes.mp4","kind":{"type":"source","source":{"duration":120,"edit_window":{"start":{"numerator":"0","denominator":"1"},"end":{"numerator":"120","denominator":"1"}},"video":{"type":"stream","asset":"b2868a97-5094-4eb8-9ccd-4a5c904983e0","span":{"start":{"ticks":0,"time_base":{"numerator":1,"denominator":30000}},"end":{"ticks":120120,"time_base":{"numerator":1,"denominator":30000}}}},"video_mapping":{"type":"placement","start":{"numerator":"0","denominator":"1"},"frames":{"numerator":"120","denominator":"1"},"endpoints":"hold_adjacent"},"audio":{"asset":"b2868a97-5094-4eb8-9ccd-4a5c904983e0","span":{"start":{"ticks":0,"time_base":{"numerator":1,"denominator":48000}},"end":{"ticks":192192,"time_base":{"numerator":1,"denominator":48000}}}},"audio_mapping":{"type":"placement","start":{"numerator":"0","denominator":"1"},"frames":{"numerator":"120","denominator":"1"}},"link":"linked","audio_offset":0}}}},"assets":{"b2868a97-5094-4eb8-9ccd-4a5c904983e0":{"label":"cfr-bframes.mp4","content_hash":"blake3:16614ec12d06396d3c0f0e7b91cc902c6dc30ad89c28d74b805cf64dc60d8aa1","video":{"start":{"ticks":0,"time_base":{"numerator":1,"denominator":30000}},"end":{"ticks":120120,"time_base":{"numerator":1,"denominator":30000}}},"audio":{"start":{"ticks":0,"time_base":{"numerator":1,"denominator":48000}},"end":{"ticks":192192,"time_base":{"numerator":1,"denominator":48000}}},"still_image":false,"frame_count":120,"source_qualification":"c6bc3e81ab69906267164469d11739cf1363eea546436761ddd219069ed496b6"}},"marks":{},"overrides":{},"gap_overrides":{},"audio_lineage":{},"audio_bindings":{"timings":[{"id":{"allocation":"3a246480-e04b-434c-adb6-44f6814fa200","ordinal":0},"layout":{"root":"44425a05-dc69-45ff-aedd-26c2356c963a","rate":{"numerator":30000,"denominator":1001},"nodes":{"2edb85c2-83ff-4e7d-894a-bbc001fa8f88":{"duration":120,"edges":{"node_start":"automatic","node_end":"automatic","source_placement_start":"automatic","source_placement_end":"automatic","repeat_gap_start":"automatic","repeat_gap_end":"automatic"},"kind":{"type":"source","placement":{"start":{"numerator":"0","denominator":"1"},"end":{"numerator":"120","denominator":"1"}}}},"44425a05-dc69-45ff-aedd-26c2356c963a":{"duration":120,"edges":{"node_start":"automatic","node_end":"automatic","source_placement_start":"automatic","source_placement_end":"automatic","repeat_gap_start":"automatic","repeat_gap_end":"automatic"},"kind":{"type":"sequence","children":["2edb85c2-83ff-4e7d-894a-bbc001fa8f88"]}}},"overrides":{}}}],"bindings":{"2edb85c2-83ff-4e7d-894a-bbc001fa8f88":{"lattice":{"reference":{"timing":{"allocation":"3a246480-e04b-434c-adb6-44f6814fa200","ordinal":0},"root":{"type":"project_root_round_even"},"physical":"2edb85c2-83ff-4e7d-894a-bbc001fa8f88"},"arguments":[],"births":[]},"resume":null,"reanchors":[{"placement":{"reference":{"timing":{"allocation":"3a246480-e04b-434c-adb6-44f6814fa200","ordinal":0},"root":{"type":"project_root_round_even"},"physical":"2edb85c2-83ff-4e7d-894a-bbc001fa8f88"},"arguments":[],"births":[]},"window":{"start":{"numerator":"65","denominator":"1"},"end":{"numerator":"70","denominator":"1"}}}]}}}}}');
INSERT INTO "register_contents" VALUES('09e05466ccca7bf827e19d651ba065875128ac8dfd432bd1f378478252d38f1d','ab2073bb-c82a-43c8-95aa-0dfa8f49275d','{"type":"original","revision":"ab2073bb-c82a-43c8-95aa-0dfa8f49275d","asset":"b2868a97-5094-4eb8-9ccd-4a5c904983e0","qualification":"c6bc3e81ab69906267164469d11739cf1363eea546436761ddd219069ed496b6","ordinals":{"start":70,"end":74}}');
INSERT INTO "register_contents" VALUES('27ea38de4cf805831539f41cc8da83a549455ac851a6334135d200509e565006','ab2073bb-c82a-43c8-95aa-0dfa8f49275d','{"type":"original","revision":"ab2073bb-c82a-43c8-95aa-0dfa8f49275d","asset":"b2868a97-5094-4eb8-9ccd-4a5c904983e0","qualification":"c6bc3e81ab69906267164469d11739cf1363eea546436761ddd219069ed496b6","ordinals":{"start":90,"end":94}}');
INSERT INTO "register_contents" VALUES('eafbe6a0f2301154b90de88f2d5b6db800899289eec71fc0459ae61ce99ff497','1b253125-e462-4cac-af80-f1dcc0a3938c','{"type":"edited","slice":{"project_id":"e6d1ba97-2db0-4119-9e5d-e4a4bef3e078","revision_id":"1b253125-e462-4cac-af80-f1dcc0a3938c","capture_timing":{"allocation":"79b2c6eb-f220-4029-b223-29d1ae048633","ordinal":0},"presentation_basis":{"width":320,"height":180,"frame_rate":{"numerator":30000,"denominator":1001},"color_policy":"sdr_rec709"},"parent":"44425a05-dc69-45ff-aedd-26c2356c963a","range":{"start":0,"end":120},"selection":{"type":"child","node":"2edb85c2-83ff-4e7d-894a-bbc001fa8f88"},"source_duration":120,"parts":[{"root":"2edb85c2-83ff-4e7d-894a-bbc001fa8f88","mapping":{"start":0,"end":120},"source_start":0}],"nodes":{"2edb85c2-83ff-4e7d-894a-bbc001fa8f88":{"label":"cfr-bframes.mp4","kind":{"type":"source","source":{"duration":120,"edit_window":{"start":{"numerator":"0","denominator":"1"},"end":{"numerator":"120","denominator":"1"}},"video":{"type":"stream","asset":"b2868a97-5094-4eb8-9ccd-4a5c904983e0","span":{"start":{"ticks":0,"time_base":{"numerator":1,"denominator":30000}},"end":{"ticks":120120,"time_base":{"numerator":1,"denominator":30000}}}},"video_mapping":{"type":"placement","start":{"numerator":"0","denominator":"1"},"frames":{"numerator":"120","denominator":"1"},"endpoints":"hold_adjacent"},"audio":{"asset":"b2868a97-5094-4eb8-9ccd-4a5c904983e0","span":{"start":{"ticks":0,"time_base":{"numerator":1,"denominator":48000}},"end":{"ticks":192192,"time_base":{"numerator":1,"denominator":48000}}}},"audio_mapping":{"type":"placement","start":{"numerator":"0","denominator":"1"},"frames":{"numerator":"120","denominator":"1"}},"link":"linked","audio_offset":0}}}},"assets":{"b2868a97-5094-4eb8-9ccd-4a5c904983e0":{"label":"cfr-bframes.mp4","content_hash":"blake3:16614ec12d06396d3c0f0e7b91cc902c6dc30ad89c28d74b805cf64dc60d8aa1","video":{"start":{"ticks":0,"time_base":{"numerator":1,"denominator":30000}},"end":{"ticks":120120,"time_base":{"numerator":1,"denominator":30000}}},"audio":{"start":{"ticks":0,"time_base":{"numerator":1,"denominator":48000}},"end":{"ticks":192192,"time_base":{"numerator":1,"denominator":48000}}},"still_image":false,"frame_count":120,"source_qualification":"c6bc3e81ab69906267164469d11739cf1363eea546436761ddd219069ed496b6"}},"marks":{},"overrides":{},"gap_overrides":{},"audio_lineage":{},"audio_bindings":{"timings":[{"id":{"allocation":"79b2c6eb-f220-4029-b223-29d1ae048633","ordinal":0},"layout":{"root":"44425a05-dc69-45ff-aedd-26c2356c963a","rate":{"numerator":30000,"denominator":1001},"nodes":{"2edb85c2-83ff-4e7d-894a-bbc001fa8f88":{"duration":120,"edges":{"node_start":"automatic","node_end":"automatic","source_placement_start":"automatic","source_placement_end":"automatic","repeat_gap_start":"automatic","repeat_gap_end":"automatic"},"kind":{"type":"source","placement":{"start":{"numerator":"0","denominator":"1"},"end":{"numerator":"120","denominator":"1"}}}},"44425a05-dc69-45ff-aedd-26c2356c963a":{"duration":120,"edges":{"node_start":"automatic","node_end":"automatic","source_placement_start":"automatic","source_placement_end":"automatic","repeat_gap_start":"automatic","repeat_gap_end":"automatic"},"kind":{"type":"sequence","children":["2edb85c2-83ff-4e7d-894a-bbc001fa8f88"]}}},"overrides":{}}}],"bindings":{"2edb85c2-83ff-4e7d-894a-bbc001fa8f88":{"lattice":{"reference":{"timing":{"allocation":"79b2c6eb-f220-4029-b223-29d1ae048633","ordinal":0},"root":{"type":"project_root_round_even"},"physical":"2edb85c2-83ff-4e7d-894a-bbc001fa8f88"},"arguments":[],"births":[]},"resume":null,"reanchors":[{"placement":{"reference":{"timing":{"allocation":"79b2c6eb-f220-4029-b223-29d1ae048633","ordinal":0},"root":{"type":"project_root_round_even"},"physical":"2edb85c2-83ff-4e7d-894a-bbc001fa8f88"},"arguments":[],"births":[]},"window":{"start":{"numerator":"0","denominator":"1"},"end":{"numerator":"120","denominator":"1"}}}]}}}}}');
CREATE TABLE register_state (
            singleton INTEGER PRIMARY KEY CHECK(singleton=1),
            version INTEGER NOT NULL CHECK(version>=0)
        ) STRICT;
INSERT INTO "register_state" VALUES(1,12);
CREATE TABLE registers (
            name TEXT PRIMARY KEY CHECK(length(CAST(name AS BLOB))=1 AND (name='"' OR name GLOB '[a-z]')),
            content_id TEXT NOT NULL REFERENCES register_contents(id)
        ) STRICT;
INSERT INTO "registers" VALUES('"','eafbe6a0f2301154b90de88f2d5b6db800899289eec71fc0459ae61ce99ff497');
INSERT INTO "registers" VALUES('a','09e05466ccca7bf827e19d651ba065875128ac8dfd432bd1f378478252d38f1d');
INSERT INTO "registers" VALUES('b','5beda2f2464f2d33eb6275faa87b0ceb1a290a88f1ebd9140af9bd09ab29d3cf');
INSERT INTO "registers" VALUES('c','32f73960277f32c42e54626e2d87780f7c3ebe5c67cdcb150e7d495b7d10075e');
INSERT INTO "registers" VALUES('d','5158f240c9869a63785909e9917e4ca028648761838d337aefdef5eb0c74f93a');
INSERT INTO "registers" VALUES('f','2e934c0d5afd4939b4ac2c18eb162ee2302ac0d49d84a1f1502c3ee0bddd7230');
INSERT INTO "registers" VALUES('e','0382549fc9c580361095dd1352f5f25d017ffbe38d7b2dea5e0f8fd44ec75ae4');
INSERT INTO "registers" VALUES('k','3b46f4628097dc5577eca524c2485d86ed6bb66db8bcb372249f16f20c1aa93d');
INSERT INTO "registers" VALUES('h','57c4315ee10452b33d65464cba291e3e232d5d875fc83ddfce810a8961c6c037');
INSERT INTO "registers" VALUES('j','27ea38de4cf805831539f41cc8da83a549455ac851a6334135d200509e565006');
CREATE TABLE render_attempts (
        job_id TEXT NOT NULL REFERENCES render_jobs(job_id), attempt_id TEXT PRIMARY KEY,
        ordinal INTEGER NOT NULL CHECK(ordinal BETWEEN 1 AND 9223372036854775807),
        cancellation_token TEXT NOT NULL, state TEXT NOT NULL,
        transition_sequence INTEGER NOT NULL CHECK(transition_sequence BETWEEN 1 AND 9223372036854775807),
        body TEXT NOT NULL CHECK(json_valid(body)), UNIQUE(job_id,ordinal), UNIQUE(job_id,attempt_id)
    ) STRICT;
CREATE TABLE render_candidate_checkpoints (
        job_id TEXT NOT NULL, attempt_id TEXT PRIMARY KEY,
        media TEXT NOT NULL CHECK(json_valid(media)),
        FOREIGN KEY(job_id,attempt_id) REFERENCES render_attempts(job_id,attempt_id)
    ) STRICT;
CREATE TABLE render_encoding_decisions (
        job_id TEXT NOT NULL, attempt_id TEXT PRIMARY KEY,
        body TEXT NOT NULL CHECK(json_valid(body)),
        FOREIGN KEY(job_id,attempt_id) REFERENCES render_attempts(job_id,attempt_id)
    ) STRICT;
CREATE TABLE render_job_heads (
        job_id TEXT PRIMARY KEY REFERENCES render_jobs(job_id),
        high_water INTEGER NOT NULL CHECK(high_water BETWEEN 1 AND 9223372036854775807),
        latest_attempt_id TEXT NOT NULL,
        FOREIGN KEY(job_id,latest_attempt_id) REFERENCES render_attempts(job_id,attempt_id)
    ) STRICT;
CREATE TABLE render_jobs (
        job_id TEXT PRIMARY KEY, revision_id TEXT NOT NULL REFERENCES revisions(id),
        intent TEXT NOT NULL CHECK(json_valid(intent))
    ) STRICT;
CREATE TABLE render_publication_operations (
        operation_id TEXT PRIMARY KEY, publication_id TEXT NOT NULL REFERENCES render_publications(publication_id),
        ordinal INTEGER NOT NULL CHECK(ordinal BETWEEN 1 AND 9223372036854775807),
        cancellation_token TEXT NOT NULL UNIQUE, active INTEGER NOT NULL CHECK(active IN (0,1)),
        body TEXT NOT NULL CHECK(json_valid(body)), UNIQUE(publication_id,ordinal)
    ) STRICT;
CREATE TABLE render_publications (
        publication_id TEXT PRIMARY KEY, job_id TEXT NOT NULL REFERENCES render_jobs(job_id),
        sequence INTEGER NOT NULL CHECK(sequence BETWEEN 1 AND 9223372036854775807),
        body TEXT NOT NULL CHECK(json_valid(body))
    ) STRICT;
CREATE TABLE revisions (
            id TEXT PRIMARY KEY,
            parent_id TEXT REFERENCES revisions(id),
            kind TEXT NOT NULL CHECK (kind IN ('initial','edit','undo','redo')),
            document TEXT NOT NULL CHECK (json_valid(document))
        ) STRICT;
INSERT INTO "revisions" VALUES('d9750054-772e-482e-9b29-ebf2da2cb0e2',NULL,'initial','{
  "schema_version": 43,
  "project_id": "e6d1ba97-2db0-4119-9e5d-e4a4bef3e078",
  "revision_id": "d9750054-772e-482e-9b29-ebf2da2cb0e2",
  "presentation_basis": {
    "width": 1920,
    "height": 1080,
    "frame_rate": {
      "numerator": 30,
      "denominator": 1
    },
    "color_policy": "sdr_rec709"
  },
  "basis_state": {
    "rate_origin": "provisional",
    "geometry_origin": "default",
    "primary": null
  },
  "root": "44425a05-dc69-45ff-aedd-26c2356c963a",
  "nodes": {
    "44425a05-dc69-45ff-aedd-26c2356c963a": {
      "label": "Sequence",
      "kind": {
        "type": "sequence",
        "children": []
      }
    }
  },
  "assets": {},
  "marks": {},
  "overrides": {}
}
');
INSERT INTO "revisions" VALUES('540b434e-34b2-4b43-ae68-1084ee80e450','d9750054-772e-482e-9b29-ebf2da2cb0e2','edit','{
  "schema_version": 43,
  "project_id": "e6d1ba97-2db0-4119-9e5d-e4a4bef3e078",
  "revision_id": "540b434e-34b2-4b43-ae68-1084ee80e450",
  "presentation_basis": {
    "width": 320,
    "height": 180,
    "frame_rate": {
      "numerator": 30000,
      "denominator": 1001
    },
    "color_policy": "sdr_rec709"
  },
  "basis_state": {
    "rate_origin": "primary_source",
    "geometry_origin": "primary_source",
    "primary": {
      "asset": "b2868a97-5094-4eb8-9ccd-4a5c904983e0",
      "qualification": "c6bc3e81ab69906267164469d11739cf1363eea546436761ddd219069ed496b6"
    }
  },
  "root": "44425a05-dc69-45ff-aedd-26c2356c963a",
  "nodes": {
    "2edb85c2-83ff-4e7d-894a-bbc001fa8f88": {
      "label": "cfr-bframes.mp4",
      "kind": {
        "type": "source",
        "source": {
          "duration": 120,
          "edit_window": {
            "start": {
              "numerator": "0",
              "denominator": "1"
            },
            "end": {
              "numerator": "120",
              "denominator": "1"
            }
          },
          "video": {
            "type": "stream",
            "asset": "b2868a97-5094-4eb8-9ccd-4a5c904983e0",
            "span": {
              "start": {
                "ticks": 0,
                "time_base": {
                  "numerator": 1,
                  "denominator": 30000
                }
              },
              "end": {
                "ticks": 120120,
                "time_base": {
                  "numerator": 1,
                  "denominator": 30000
                }
              }
            }
          },
          "video_mapping": {
            "type": "placement",
            "start": {
              "numerator": "0",
              "denominator": "1"
            },
            "frames": {
              "numerator": "120",
              "denominator": "1"
            },
            "endpoints": "hold_adjacent"
          },
          "audio": {
            "asset": "b2868a97-5094-4eb8-9ccd-4a5c904983e0",
            "span": {
              "start": {
                "ticks": 0,
                "time_base": {
                  "numerator": 1,
                  "denominator": 48000
                }
              },
              "end": {
                "ticks": 192192,
                "time_base": {
                  "numerator": 1,
                  "denominator": 48000
                }
              }
            }
          },
          "audio_mapping": {
            "type": "placement",
            "start": {
              "numerator": "0",
              "denominator": "1"
            },
            "frames": {
              "numerator": "120",
              "denominator": "1"
            }
          },
          "link": "linked",
          "audio_offset": 0
        }
      }
    },
    "44425a05-dc69-45ff-aedd-26c2356c963a": {
      "label": "Sequence",
      "kind": {
        "type": "sequence",
        "children": [
          "2edb85c2-83ff-4e7d-894a-bbc001fa8f88"
        ]
      }
    }
  },
  "assets": {
    "b2868a97-5094-4eb8-9ccd-4a5c904983e0": {
      "label": "cfr-bframes.mp4",
      "content_hash": "blake3:16614ec12d06396d3c0f0e7b91cc902c6dc30ad89c28d74b805cf64dc60d8aa1",
      "video": {
        "start": {
          "ticks": 0,
          "time_base": {
            "numerator": 1,
            "denominator": 30000
          }
        },
        "end": {
          "ticks": 120120,
          "time_base": {
            "numerator": 1,
            "denominator": 30000
          }
        }
      },
      "audio": {
        "start": {
          "ticks": 0,
          "time_base": {
            "numerator": 1,
            "denominator": 48000
          }
        },
        "end": {
          "ticks": 192192,
          "time_base": {
            "numerator": 1,
            "denominator": 48000
          }
        }
      },
      "still_image": false,
      "frame_count": 120,
      "source_qualification": "c6bc3e81ab69906267164469d11739cf1363eea546436761ddd219069ed496b6"
    }
  },
  "marks": {},
  "overrides": {}
}
');
INSERT INTO "revisions" VALUES('d2b9e481-1dbe-43be-a305-5150879171a2','540b434e-34b2-4b43-ae68-1084ee80e450','edit','{
  "schema_version": 43,
  "project_id": "e6d1ba97-2db0-4119-9e5d-e4a4bef3e078",
  "revision_id": "d2b9e481-1dbe-43be-a305-5150879171a2",
  "presentation_basis": {
    "width": 320,
    "height": 180,
    "frame_rate": {
      "numerator": 30000,
      "denominator": 1001
    },
    "color_policy": "sdr_rec709"
  },
  "basis_state": {
    "rate_origin": "primary_source",
    "geometry_origin": "primary_source",
    "primary": {
      "asset": "b2868a97-5094-4eb8-9ccd-4a5c904983e0",
      "qualification": "c6bc3e81ab69906267164469d11739cf1363eea546436761ddd219069ed496b6"
    }
  },
  "root": "44425a05-dc69-45ff-aedd-26c2356c963a",
  "nodes": {
    "143d5f08-97cc-41cc-a0e4-baa8277ffb23": {
      "label": "cfr-bframes.mp4 [5..13)",
      "kind": {
        "type": "source",
        "source": {
          "duration": 8,
          "edit_window": {
            "start": {
              "numerator": "0",
              "denominator": "1"
            },
            "end": {
              "numerator": "8",
              "denominator": "1"
            }
          },
          "video": {
            "type": "stream",
            "asset": "b2868a97-5094-4eb8-9ccd-4a5c904983e0",
            "span": {
              "start": {
                "ticks": 0,
                "time_base": {
                  "numerator": 1,
                  "denominator": 30000
                }
              },
              "end": {
                "ticks": 120120,
                "time_base": {
                  "numerator": 1,
                  "denominator": 30000
                }
              }
            }
          },
          "video_mapping": {
            "type": "selected_placement",
            "start": {
              "numerator": "-5",
              "denominator": "1"
            },
            "frames": {
              "numerator": "120",
              "denominator": "1"
            },
            "selection": {
              "start": {
                "numerator": "0",
                "denominator": "1"
              },
              "end": {
                "numerator": "8",
                "denominator": "1"
              }
            },
            "endpoints": "hold_adjacent"
          },
          "audio": {
            "asset": "b2868a97-5094-4eb8-9ccd-4a5c904983e0",
            "span": {
              "start": {
                "ticks": 0,
                "time_base": {
                  "numerator": 1,
                  "denominator": 48000
                }
              },
              "end": {
                "ticks": 192192,
                "time_base": {
                  "numerator": 1,
                  "denominator": 48000
                }
              }
            }
          },
          "audio_mapping": {
            "type": "selected_placement",
            "start": {
              "numerator": "-5",
              "denominator": "1"
            },
            "frames": {
              "numerator": "120",
              "denominator": "1"
            },
            "selection": {
              "start": {
                "numerator": "0",
                "denominator": "1"
              },
              "end": {
                "numerator": "8",
                "denominator": "1"
              }
            }
          },
          "link": "linked",
          "audio_offset": 0
        }
      }
    },
    "2edb85c2-83ff-4e7d-894a-bbc001fa8f88": {
      "label": "cfr-bframes.mp4",
      "kind": {
        "type": "source",
        "source": {
          "duration": 120,
          "edit_window": {
            "start": {
              "numerator": "0",
              "denominator": "1"
            },
            "end": {
              "numerator": "120",
              "denominator": "1"
            }
          },
          "video": {
            "type": "stream",
            "asset": "b2868a97-5094-4eb8-9ccd-4a5c904983e0",
            "span": {
              "start": {
                "ticks": 0,
                "time_base": {
                  "numerator": 1,
                  "denominator": 30000
                }
              },
              "end": {
                "ticks": 120120,
                "time_base": {
                  "numerator": 1,
                  "denominator": 30000
                }
              }
            }
          },
          "video_mapping": {
            "type": "placement",
            "start": {
              "numerator": "0",
              "denominator": "1"
            },
            "frames": {
              "numerator": "120",
              "denominator": "1"
            },
            "endpoints": "hold_adjacent"
          },
          "audio": {
            "asset": "b2868a97-5094-4eb8-9ccd-4a5c904983e0",
            "span": {
              "start": {
                "ticks": 0,
                "time_base": {
                  "numerator": 1,
                  "denominator": 48000
                }
              },
              "end": {
                "ticks": 192192,
                "time_base": {
                  "numerator": 1,
                  "denominator": 48000
                }
              }
            }
          },
          "audio_mapping": {
            "type": "placement",
            "start": {
              "numerator": "0",
              "denominator": "1"
            },
            "frames": {
              "numerator": "120",
              "denominator": "1"
            }
          },
          "link": "linked",
          "audio_offset": 0
        }
      }
    },
    "44425a05-dc69-45ff-aedd-26c2356c963a": {
      "label": "Sequence",
      "kind": {
        "type": "sequence",
        "children": [
          "2edb85c2-83ff-4e7d-894a-bbc001fa8f88",
          "143d5f08-97cc-41cc-a0e4-baa8277ffb23"
        ]
      }
    }
  },
  "assets": {
    "b2868a97-5094-4eb8-9ccd-4a5c904983e0": {
      "label": "cfr-bframes.mp4",
      "content_hash": "blake3:16614ec12d06396d3c0f0e7b91cc902c6dc30ad89c28d74b805cf64dc60d8aa1",
      "video": {
        "start": {
          "ticks": 0,
          "time_base": {
            "numerator": 1,
            "denominator": 30000
          }
        },
        "end": {
          "ticks": 120120,
          "time_base": {
            "numerator": 1,
            "denominator": 30000
          }
        }
      },
      "audio": {
        "start": {
          "ticks": 0,
          "time_base": {
            "numerator": 1,
            "denominator": 48000
          }
        },
        "end": {
          "ticks": 192192,
          "time_base": {
            "numerator": 1,
            "denominator": 48000
          }
        }
      },
      "still_image": false,
      "frame_count": 120,
      "source_qualification": "c6bc3e81ab69906267164469d11739cf1363eea546436761ddd219069ed496b6"
    }
  },
  "marks": {},
  "overrides": {},
  "audio_bindings": {
    "timings": [
      {
        "id": {
          "allocation": "d2b9e481-1dbe-43be-a305-5150879171a2",
          "ordinal": 0
        },
        "layout": {
          "root": "44425a05-dc69-45ff-aedd-26c2356c963a",
          "rate": {
            "numerator": 30000,
            "denominator": 1001
          },
          "nodes": {
            "2edb85c2-83ff-4e7d-894a-bbc001fa8f88": {
              "duration": 120,
              "edges": {
                "node_start": "automatic",
                "node_end": "automatic",
                "source_placement_start": "automatic",
                "source_placement_end": "automatic",
                "repeat_gap_start": "automatic",
                "repeat_gap_end": "automatic"
              },
              "kind": {
                "type": "source",
                "placement": {
                  "start": {
                    "numerator": "0",
                    "denominator": "1"
                  },
                  "end": {
                    "numerator": "120",
                    "denominator": "1"
                  }
                }
              }
            },
            "44425a05-dc69-45ff-aedd-26c2356c963a": {
              "duration": 120,
              "edges": {
                "node_start": "automatic",
                "node_end": "automatic",
                "source_placement_start": "automatic",
                "source_placement_end": "automatic",
                "repeat_gap_start": "automatic",
                "repeat_gap_end": "automatic"
              },
              "kind": {
                "type": "sequence",
                "children": [
                  "2edb85c2-83ff-4e7d-894a-bbc001fa8f88"
                ]
              }
            }
          },
          "overrides": {}
        }
      }
    ],
    "bindings": {
      "2edb85c2-83ff-4e7d-894a-bbc001fa8f88": {
        "lattice": {
          "reference": {
            "timing": {
              "allocation": "d2b9e481-1dbe-43be-a305-5150879171a2",
              "ordinal": 0
            },
            "root": {
              "type": "project_root_round_even"
            },
            "physical": "2edb85c2-83ff-4e7d-894a-bbc001fa8f88"
          },
          "arguments": [],
          "births": []
        },
        "resume": null
      }
    }
  }
}
');
INSERT INTO "revisions" VALUES('a25b3890-6c4f-47aa-a0fa-0757d24149dc','d2b9e481-1dbe-43be-a305-5150879171a2','undo','{
  "schema_version": 43,
  "project_id": "e6d1ba97-2db0-4119-9e5d-e4a4bef3e078",
  "revision_id": "a25b3890-6c4f-47aa-a0fa-0757d24149dc",
  "presentation_basis": {
    "width": 320,
    "height": 180,
    "frame_rate": {
      "numerator": 30000,
      "denominator": 1001
    },
    "color_policy": "sdr_rec709"
  },
  "basis_state": {
    "rate_origin": "primary_source",
    "geometry_origin": "primary_source",
    "primary": {
      "asset": "b2868a97-5094-4eb8-9ccd-4a5c904983e0",
      "qualification": "c6bc3e81ab69906267164469d11739cf1363eea546436761ddd219069ed496b6"
    }
  },
  "root": "44425a05-dc69-45ff-aedd-26c2356c963a",
  "nodes": {
    "2edb85c2-83ff-4e7d-894a-bbc001fa8f88": {
      "label": "cfr-bframes.mp4",
      "kind": {
        "type": "source",
        "source": {
          "duration": 120,
          "edit_window": {
            "start": {
              "numerator": "0",
              "denominator": "1"
            },
            "end": {
              "numerator": "120",
              "denominator": "1"
            }
          },
          "video": {
            "type": "stream",
            "asset": "b2868a97-5094-4eb8-9ccd-4a5c904983e0",
            "span": {
              "start": {
                "ticks": 0,
                "time_base": {
                  "numerator": 1,
                  "denominator": 30000
                }
              },
              "end": {
                "ticks": 120120,
                "time_base": {
                  "numerator": 1,
                  "denominator": 30000
                }
              }
            }
          },
          "video_mapping": {
            "type": "placement",
            "start": {
              "numerator": "0",
              "denominator": "1"
            },
            "frames": {
              "numerator": "120",
              "denominator": "1"
            },
            "endpoints": "hold_adjacent"
          },
          "audio": {
            "asset": "b2868a97-5094-4eb8-9ccd-4a5c904983e0",
            "span": {
              "start": {
                "ticks": 0,
                "time_base": {
                  "numerator": 1,
                  "denominator": 48000
                }
              },
              "end": {
                "ticks": 192192,
                "time_base": {
                  "numerator": 1,
                  "denominator": 48000
                }
              }
            }
          },
          "audio_mapping": {
            "type": "placement",
            "start": {
              "numerator": "0",
              "denominator": "1"
            },
            "frames": {
              "numerator": "120",
              "denominator": "1"
            }
          },
          "link": "linked",
          "audio_offset": 0
        }
      }
    },
    "44425a05-dc69-45ff-aedd-26c2356c963a": {
      "label": "Sequence",
      "kind": {
        "type": "sequence",
        "children": [
          "2edb85c2-83ff-4e7d-894a-bbc001fa8f88"
        ]
      }
    }
  },
  "assets": {
    "b2868a97-5094-4eb8-9ccd-4a5c904983e0": {
      "label": "cfr-bframes.mp4",
      "content_hash": "blake3:16614ec12d06396d3c0f0e7b91cc902c6dc30ad89c28d74b805cf64dc60d8aa1",
      "video": {
        "start": {
          "ticks": 0,
          "time_base": {
            "numerator": 1,
            "denominator": 30000
          }
        },
        "end": {
          "ticks": 120120,
          "time_base": {
            "numerator": 1,
            "denominator": 30000
          }
        }
      },
      "audio": {
        "start": {
          "ticks": 0,
          "time_base": {
            "numerator": 1,
            "denominator": 48000
          }
        },
        "end": {
          "ticks": 192192,
          "time_base": {
            "numerator": 1,
            "denominator": 48000
          }
        }
      },
      "still_image": false,
      "frame_count": 120,
      "source_qualification": "c6bc3e81ab69906267164469d11739cf1363eea546436761ddd219069ed496b6"
    }
  },
  "marks": {},
  "overrides": {}
}
');
INSERT INTO "revisions" VALUES('ca5eb43d-d34f-47ea-97de-6dd4d576fda3','a25b3890-6c4f-47aa-a0fa-0757d24149dc','edit','{
  "schema_version": 43,
  "project_id": "e6d1ba97-2db0-4119-9e5d-e4a4bef3e078",
  "revision_id": "ca5eb43d-d34f-47ea-97de-6dd4d576fda3",
  "presentation_basis": {
    "width": 320,
    "height": 180,
    "frame_rate": {
      "numerator": 30000,
      "denominator": 1001
    },
    "color_policy": "sdr_rec709"
  },
  "basis_state": {
    "rate_origin": "primary_source",
    "geometry_origin": "primary_source",
    "primary": {
      "asset": "b2868a97-5094-4eb8-9ccd-4a5c904983e0",
      "qualification": "c6bc3e81ab69906267164469d11739cf1363eea546436761ddd219069ed496b6"
    }
  },
  "root": "44425a05-dc69-45ff-aedd-26c2356c963a",
  "nodes": {
    "2edb85c2-83ff-4e7d-894a-bbc001fa8f88": {
      "label": "cfr-bframes.mp4",
      "kind": {
        "type": "source",
        "source": {
          "duration": 120,
          "edit_window": {
            "start": {
              "numerator": "0",
              "denominator": "1"
            },
            "end": {
              "numerator": "120",
              "denominator": "1"
            }
          },
          "video": {
            "type": "stream",
            "asset": "b2868a97-5094-4eb8-9ccd-4a5c904983e0",
            "span": {
              "start": {
                "ticks": 0,
                "time_base": {
                  "numerator": 1,
                  "denominator": 30000
                }
              },
              "end": {
                "ticks": 120120,
                "time_base": {
                  "numerator": 1,
                  "denominator": 30000
                }
              }
            }
          },
          "video_mapping": {
            "type": "placement",
            "start": {
              "numerator": "0",
              "denominator": "1"
            },
            "frames": {
              "numerator": "120",
              "denominator": "1"
            },
            "endpoints": "hold_adjacent"
          },
          "audio": {
            "asset": "b2868a97-5094-4eb8-9ccd-4a5c904983e0",
            "span": {
              "start": {
                "ticks": 0,
                "time_base": {
                  "numerator": 1,
                  "denominator": 48000
                }
              },
              "end": {
                "ticks": 192192,
                "time_base": {
                  "numerator": 1,
                  "denominator": 48000
                }
              }
            }
          },
          "audio_mapping": {
            "type": "placement",
            "start": {
              "numerator": "0",
              "denominator": "1"
            },
            "frames": {
              "numerator": "120",
              "denominator": "1"
            }
          },
          "link": "linked",
          "audio_offset": 0
        }
      }
    },
    "44425a05-dc69-45ff-aedd-26c2356c963a": {
      "label": "Sequence",
      "kind": {
        "type": "sequence",
        "children": [
          "cad6b366-1ce5-4dd0-8f92-6ece27313751",
          "2edb85c2-83ff-4e7d-894a-bbc001fa8f88"
        ]
      }
    },
    "cad6b366-1ce5-4dd0-8f92-6ece27313751": {
      "label": "cfr-bframes.mp4 [30..35)",
      "kind": {
        "type": "source",
        "source": {
          "duration": 5,
          "edit_window": {
            "start": {
              "numerator": "0",
              "denominator": "1"
            },
            "end": {
              "numerator": "5",
              "denominator": "1"
            }
          },
          "video": {
            "type": "stream",
            "asset": "b2868a97-5094-4eb8-9ccd-4a5c904983e0",
            "span": {
              "start": {
                "ticks": 0,
                "time_base": {
                  "numerator": 1,
                  "denominator": 30000
                }
              },
              "end": {
                "ticks": 120120,
                "time_base": {
                  "numerator": 1,
                  "denominator": 30000
                }
              }
            }
          },
          "video_mapping": {
            "type": "selected_placement",
            "start": {
              "numerator": "-30",
              "denominator": "1"
            },
            "frames": {
              "numerator": "120",
              "denominator": "1"
            },
            "selection": {
              "start": {
                "numerator": "0",
                "denominator": "1"
              },
              "end": {
                "numerator": "5",
                "denominator": "1"
              }
            },
            "endpoints": "hold_adjacent"
          },
          "audio": {
            "asset": "b2868a97-5094-4eb8-9ccd-4a5c904983e0",
            "span": {
              "start": {
                "ticks": 0,
                "time_base": {
                  "numerator": 1,
                  "denominator": 48000
                }
              },
              "end": {
                "ticks": 192192,
                "time_base": {
                  "numerator": 1,
                  "denominator": 48000
                }
              }
            }
          },
          "audio_mapping": {
            "type": "selected_placement",
            "start": {
              "numerator": "-30",
              "denominator": "1"
            },
            "frames": {
              "numerator": "120",
              "denominator": "1"
            },
            "selection": {
              "start": {
                "numerator": "0",
                "denominator": "1"
              },
              "end": {
                "numerator": "5",
                "denominator": "1"
              }
            }
          },
          "link": "linked",
          "audio_offset": 0
        }
      }
    }
  },
  "assets": {
    "b2868a97-5094-4eb8-9ccd-4a5c904983e0": {
      "label": "cfr-bframes.mp4",
      "content_hash": "blake3:16614ec12d06396d3c0f0e7b91cc902c6dc30ad89c28d74b805cf64dc60d8aa1",
      "video": {
        "start": {
          "ticks": 0,
          "time_base": {
            "numerator": 1,
            "denominator": 30000
          }
        },
        "end": {
          "ticks": 120120,
          "time_base": {
            "numerator": 1,
            "denominator": 30000
          }
        }
      },
      "audio": {
        "start": {
          "ticks": 0,
          "time_base": {
            "numerator": 1,
            "denominator": 48000
          }
        },
        "end": {
          "ticks": 192192,
          "time_base": {
            "numerator": 1,
            "denominator": 48000
          }
        }
      },
      "still_image": false,
      "frame_count": 120,
      "source_qualification": "c6bc3e81ab69906267164469d11739cf1363eea546436761ddd219069ed496b6"
    }
  },
  "marks": {},
  "overrides": {},
  "audio_bindings": {
    "timings": [
      {
        "id": {
          "allocation": "ca5eb43d-d34f-47ea-97de-6dd4d576fda3",
          "ordinal": 0
        },
        "layout": {
          "root": "44425a05-dc69-45ff-aedd-26c2356c963a",
          "rate": {
            "numerator": 30000,
            "denominator": 1001
          },
          "nodes": {
            "2edb85c2-83ff-4e7d-894a-bbc001fa8f88": {
              "duration": 120,
              "edges": {
                "node_start": "automatic",
                "node_end": "automatic",
                "source_placement_start": "automatic",
                "source_placement_end": "automatic",
                "repeat_gap_start": "automatic",
                "repeat_gap_end": "automatic"
              },
              "kind": {
                "type": "source",
                "placement": {
                  "start": {
                    "numerator": "0",
                    "denominator": "1"
                  },
                  "end": {
                    "numerator": "120",
                    "denominator": "1"
                  }
                }
              }
            },
            "44425a05-dc69-45ff-aedd-26c2356c963a": {
              "duration": 120,
              "edges": {
                "node_start": "automatic",
                "node_end": "automatic",
                "source_placement_start": "automatic",
                "source_placement_end": "automatic",
                "repeat_gap_start": "automatic",
                "repeat_gap_end": "automatic"
              },
              "kind": {
                "type": "sequence",
                "children": [
                  "2edb85c2-83ff-4e7d-894a-bbc001fa8f88"
                ]
              }
            }
          },
          "overrides": {}
        }
      }
    ],
    "bindings": {
      "2edb85c2-83ff-4e7d-894a-bbc001fa8f88": {
        "lattice": {
          "reference": {
            "timing": {
              "allocation": "ca5eb43d-d34f-47ea-97de-6dd4d576fda3",
              "ordinal": 0
            },
            "root": {
              "type": "project_root_round_even"
            },
            "physical": "2edb85c2-83ff-4e7d-894a-bbc001fa8f88"
          },
          "arguments": [],
          "births": []
        },
        "resume": null,
        "reanchors": [
          {
            "placement": {
              "reference": {
                "timing": {
                  "allocation": "ca5eb43d-d34f-47ea-97de-6dd4d576fda3",
                  "ordinal": 0
                },
                "root": {
                  "type": "project_root_round_even"
                },
                "physical": "2edb85c2-83ff-4e7d-894a-bbc001fa8f88"
              },
              "arguments": [],
              "births": []
            },
            "window": {
              "start": {
                "numerator": "0",
                "denominator": "1"
              },
              "end": {
                "numerator": "120",
                "denominator": "1"
              }
            }
          }
        ]
      }
    }
  }
}
');
INSERT INTO "revisions" VALUES('01a31893-138e-4642-b20e-02a2e82c7228','ca5eb43d-d34f-47ea-97de-6dd4d576fda3','undo','{
  "schema_version": 43,
  "project_id": "e6d1ba97-2db0-4119-9e5d-e4a4bef3e078",
  "revision_id": "01a31893-138e-4642-b20e-02a2e82c7228",
  "presentation_basis": {
    "width": 320,
    "height": 180,
    "frame_rate": {
      "numerator": 30000,
      "denominator": 1001
    },
    "color_policy": "sdr_rec709"
  },
  "basis_state": {
    "rate_origin": "primary_source",
    "geometry_origin": "primary_source",
    "primary": {
      "asset": "b2868a97-5094-4eb8-9ccd-4a5c904983e0",
      "qualification": "c6bc3e81ab69906267164469d11739cf1363eea546436761ddd219069ed496b6"
    }
  },
  "root": "44425a05-dc69-45ff-aedd-26c2356c963a",
  "nodes": {
    "2edb85c2-83ff-4e7d-894a-bbc001fa8f88": {
      "label": "cfr-bframes.mp4",
      "kind": {
        "type": "source",
        "source": {
          "duration": 120,
          "edit_window": {
            "start": {
              "numerator": "0",
              "denominator": "1"
            },
            "end": {
              "numerator": "120",
              "denominator": "1"
            }
          },
          "video": {
            "type": "stream",
            "asset": "b2868a97-5094-4eb8-9ccd-4a5c904983e0",
            "span": {
              "start": {
                "ticks": 0,
                "time_base": {
                  "numerator": 1,
                  "denominator": 30000
                }
              },
              "end": {
                "ticks": 120120,
                "time_base": {
                  "numerator": 1,
                  "denominator": 30000
                }
              }
            }
          },
          "video_mapping": {
            "type": "placement",
            "start": {
              "numerator": "0",
              "denominator": "1"
            },
            "frames": {
              "numerator": "120",
              "denominator": "1"
            },
            "endpoints": "hold_adjacent"
          },
          "audio": {
            "asset": "b2868a97-5094-4eb8-9ccd-4a5c904983e0",
            "span": {
              "start": {
                "ticks": 0,
                "time_base": {
                  "numerator": 1,
                  "denominator": 48000
                }
              },
              "end": {
                "ticks": 192192,
                "time_base": {
                  "numerator": 1,
                  "denominator": 48000
                }
              }
            }
          },
          "audio_mapping": {
            "type": "placement",
            "start": {
              "numerator": "0",
              "denominator": "1"
            },
            "frames": {
              "numerator": "120",
              "denominator": "1"
            }
          },
          "link": "linked",
          "audio_offset": 0
        }
      }
    },
    "44425a05-dc69-45ff-aedd-26c2356c963a": {
      "label": "Sequence",
      "kind": {
        "type": "sequence",
        "children": [
          "2edb85c2-83ff-4e7d-894a-bbc001fa8f88"
        ]
      }
    }
  },
  "assets": {
    "b2868a97-5094-4eb8-9ccd-4a5c904983e0": {
      "label": "cfr-bframes.mp4",
      "content_hash": "blake3:16614ec12d06396d3c0f0e7b91cc902c6dc30ad89c28d74b805cf64dc60d8aa1",
      "video": {
        "start": {
          "ticks": 0,
          "time_base": {
            "numerator": 1,
            "denominator": 30000
          }
        },
        "end": {
          "ticks": 120120,
          "time_base": {
            "numerator": 1,
            "denominator": 30000
          }
        }
      },
      "audio": {
        "start": {
          "ticks": 0,
          "time_base": {
            "numerator": 1,
            "denominator": 48000
          }
        },
        "end": {
          "ticks": 192192,
          "time_base": {
            "numerator": 1,
            "denominator": 48000
          }
        }
      },
      "still_image": false,
      "frame_count": 120,
      "source_qualification": "c6bc3e81ab69906267164469d11739cf1363eea546436761ddd219069ed496b6"
    }
  },
  "marks": {},
  "overrides": {}
}
');
INSERT INTO "revisions" VALUES('ed903801-af9a-4875-a6d0-2ffb76eb830f','01a31893-138e-4642-b20e-02a2e82c7228','edit','{
  "schema_version": 43,
  "project_id": "e6d1ba97-2db0-4119-9e5d-e4a4bef3e078",
  "revision_id": "ed903801-af9a-4875-a6d0-2ffb76eb830f",
  "presentation_basis": {
    "width": 320,
    "height": 180,
    "frame_rate": {
      "numerator": 30000,
      "denominator": 1001
    },
    "color_policy": "sdr_rec709"
  },
  "basis_state": {
    "rate_origin": "primary_source",
    "geometry_origin": "primary_source",
    "primary": {
      "asset": "b2868a97-5094-4eb8-9ccd-4a5c904983e0",
      "qualification": "c6bc3e81ab69906267164469d11739cf1363eea546436761ddd219069ed496b6"
    }
  },
  "root": "44425a05-dc69-45ff-aedd-26c2356c963a",
  "nodes": {
    "2edb85c2-83ff-4e7d-894a-bbc001fa8f88": {
      "label": "cfr-bframes.mp4",
      "kind": {
        "type": "source",
        "source": {
          "duration": 120,
          "edit_window": {
            "start": {
              "numerator": "0",
              "denominator": "1"
            },
            "end": {
              "numerator": "120",
              "denominator": "1"
            }
          },
          "video": {
            "type": "stream",
            "asset": "b2868a97-5094-4eb8-9ccd-4a5c904983e0",
            "span": {
              "start": {
                "ticks": 0,
                "time_base": {
                  "numerator": 1,
                  "denominator": 30000
                }
              },
              "end": {
                "ticks": 120120,
                "time_base": {
                  "numerator": 1,
                  "denominator": 30000
                }
              }
            }
          },
          "video_mapping": {
            "type": "placement",
            "start": {
              "numerator": "0",
              "denominator": "1"
            },
            "frames": {
              "numerator": "120",
              "denominator": "1"
            },
            "endpoints": "hold_adjacent"
          },
          "audio": {
            "asset": "b2868a97-5094-4eb8-9ccd-4a5c904983e0",
            "span": {
              "start": {
                "ticks": 0,
                "time_base": {
                  "numerator": 1,
                  "denominator": 48000
                }
              },
              "end": {
                "ticks": 192192,
                "time_base": {
                  "numerator": 1,
                  "denominator": 48000
                }
              }
            }
          },
          "audio_mapping": {
            "type": "placement",
            "start": {
              "numerator": "0",
              "denominator": "1"
            },
            "frames": {
              "numerator": "120",
              "denominator": "1"
            }
          },
          "link": "linked",
          "audio_offset": 0
        }
      }
    },
    "44425a05-dc69-45ff-aedd-26c2356c963a": {
      "label": "Sequence",
      "kind": {
        "type": "sequence",
        "children": [
          "4de01272-0476-425e-9ba1-c63b46aa4012",
          "b0131c13-21a8-452e-80f8-03b53f60f52e",
          "6d77dc13-c463-476e-ad1c-948bf919538b"
        ]
      }
    },
    "4de01272-0476-425e-9ba1-c63b46aa4012": {
      "label": "cfr-bframes.mp4",
      "kind": {
        "type": "retime",
        "child": "2edb85c2-83ff-4e7d-894a-bbc001fa8f88",
        "duration": 10,
        "mapping": {
          "start": 0,
          "end": 10
        },
        "pitch": "preserve",
        "purpose": "partition"
      }
    },
    "6d77dc13-c463-476e-ad1c-948bf919538b": {
      "label": "cfr-bframes.mp4",
      "kind": {
        "type": "retime",
        "child": "73b09e6c-178d-48c1-9f43-54960c553afd",
        "duration": 110,
        "mapping": {
          "start": 10,
          "end": 120
        },
        "pitch": "preserve",
        "purpose": "partition"
      }
    },
    "73b09e6c-178d-48c1-9f43-54960c553afd": {
      "label": "cfr-bframes.mp4",
      "kind": {
        "type": "source",
        "source": {
          "duration": 120,
          "edit_window": {
            "start": {
              "numerator": "0",
              "denominator": "1"
            },
            "end": {
              "numerator": "120",
              "denominator": "1"
            }
          },
          "video": {
            "type": "stream",
            "asset": "b2868a97-5094-4eb8-9ccd-4a5c904983e0",
            "span": {
              "start": {
                "ticks": 0,
                "time_base": {
                  "numerator": 1,
                  "denominator": 30000
                }
              },
              "end": {
                "ticks": 120120,
                "time_base": {
                  "numerator": 1,
                  "denominator": 30000
                }
              }
            }
          },
          "video_mapping": {
            "type": "placement",
            "start": {
              "numerator": "0",
              "denominator": "1"
            },
            "frames": {
              "numerator": "120",
              "denominator": "1"
            },
            "endpoints": "hold_adjacent"
          },
          "audio": {
            "asset": "b2868a97-5094-4eb8-9ccd-4a5c904983e0",
            "span": {
              "start": {
                "ticks": 0,
                "time_base": {
                  "numerator": 1,
                  "denominator": 48000
                }
              },
              "end": {
                "ticks": 192192,
                "time_base": {
                  "numerator": 1,
                  "denominator": 48000
                }
              }
            }
          },
          "audio_mapping": {
            "type": "placement",
            "start": {
              "numerator": "0",
              "denominator": "1"
            },
            "frames": {
              "numerator": "120",
              "denominator": "1"
            }
          },
          "link": "linked",
          "audio_offset": 0
        }
      }
    },
    "b0131c13-21a8-452e-80f8-03b53f60f52e": {
      "label": "Pause",
      "kind": {
        "type": "hold",
        "recipe": {
          "picture_context": {
            "canvases": [
              {
                "width": 320,
                "height": 180,
                "fit": "fit",
                "layers": []
              }
            ]
          },
          "duration": 11,
          "video": {
            "type": "freeze",
            "asset": "b2868a97-5094-4eb8-9ccd-4a5c904983e0",
            "timestamp": {
              "ticks": 9009,
              "time_base": {
                "numerator": 1,
                "denominator": 30000
              }
            }
          },
          "audio": {
            "type": "silence"
          }
        }
      }
    }
  },
  "assets": {
    "b2868a97-5094-4eb8-9ccd-4a5c904983e0": {
      "label": "cfr-bframes.mp4",
      "content_hash": "blake3:16614ec12d06396d3c0f0e7b91cc902c6dc30ad89c28d74b805cf64dc60d8aa1",
      "video": {
        "start": {
          "ticks": 0,
          "time_base": {
            "numerator": 1,
            "denominator": 30000
          }
        },
        "end": {
          "ticks": 120120,
          "time_base": {
            "numerator": 1,
            "denominator": 30000
          }
        }
      },
      "audio": {
        "start": {
          "ticks": 0,
          "time_base": {
            "numerator": 1,
            "denominator": 48000
          }
        },
        "end": {
          "ticks": 192192,
          "time_base": {
            "numerator": 1,
            "denominator": 48000
          }
        }
      },
      "still_image": false,
      "frame_count": 120,
      "source_qualification": "c6bc3e81ab69906267164469d11739cf1363eea546436761ddd219069ed496b6"
    }
  },
  "marks": {},
  "overrides": {},
  "audio_lineage": {
    "2edb85c2-83ff-4e7d-894a-bbc001fa8f88": {
      "allocation": "ed903801-af9a-4875-a6d0-2ffb76eb830f",
      "origin": "2edb85c2-83ff-4e7d-894a-bbc001fa8f88"
    },
    "73b09e6c-178d-48c1-9f43-54960c553afd": {
      "allocation": "ed903801-af9a-4875-a6d0-2ffb76eb830f",
      "origin": "2edb85c2-83ff-4e7d-894a-bbc001fa8f88"
    }
  },
  "audio_bindings": {
    "timings": [
      {
        "id": {
          "allocation": "ed903801-af9a-4875-a6d0-2ffb76eb830f",
          "ordinal": 0
        },
        "layout": {
          "root": "44425a05-dc69-45ff-aedd-26c2356c963a",
          "rate": {
            "numerator": 30000,
            "denominator": 1001
          },
          "nodes": {
            "2edb85c2-83ff-4e7d-894a-bbc001fa8f88": {
              "duration": 120,
              "edges": {
                "node_start": "automatic",
                "node_end": "automatic",
                "source_placement_start": "automatic",
                "source_placement_end": "automatic",
                "repeat_gap_start": "automatic",
                "repeat_gap_end": "automatic"
              },
              "kind": {
                "type": "source",
                "placement": {
                  "start": {
                    "numerator": "0",
                    "denominator": "1"
                  },
                  "end": {
                    "numerator": "120",
                    "denominator": "1"
                  }
                }
              }
            },
            "44425a05-dc69-45ff-aedd-26c2356c963a": {
              "duration": 120,
              "edges": {
                "node_start": "automatic",
                "node_end": "automatic",
                "source_placement_start": "automatic",
                "source_placement_end": "automatic",
                "repeat_gap_start": "automatic",
                "repeat_gap_end": "automatic"
              },
              "kind": {
                "type": "sequence",
                "children": [
                  "2edb85c2-83ff-4e7d-894a-bbc001fa8f88"
                ]
              }
            }
          },
          "overrides": {}
        }
      }
    ],
    "bindings": {
      "2edb85c2-83ff-4e7d-894a-bbc001fa8f88": {
        "lattice": {
          "reference": {
            "timing": {
              "allocation": "ed903801-af9a-4875-a6d0-2ffb76eb830f",
              "ordinal": 0
            },
            "root": {
              "type": "project_root_round_even"
            },
            "physical": "2edb85c2-83ff-4e7d-894a-bbc001fa8f88"
          },
          "arguments": [],
          "births": []
        },
        "resume": null
      },
      "73b09e6c-178d-48c1-9f43-54960c553afd": {
        "lattice": {
          "reference": {
            "timing": {
              "allocation": "ed903801-af9a-4875-a6d0-2ffb76eb830f",
              "ordinal": 0
            },
            "root": {
              "type": "project_root_round_even"
            },
            "physical": "2edb85c2-83ff-4e7d-894a-bbc001fa8f88"
          },
          "arguments": [],
          "births": []
        },
        "resume": {
          "local_boundary": {
            "numerator": "10",
            "denominator": "1"
          },
          "phase": {
            "constant": {
              "numerator": "0",
              "denominator": "1"
            },
            "terms": [
              {
                "placement": {
                  "reference": {
                    "timing": {
                      "allocation": "ed903801-af9a-4875-a6d0-2ffb76eb830f",
                      "ordinal": 0
                    },
                    "root": {
                      "type": "project_root_round_even"
                    },
                    "physical": "2edb85c2-83ff-4e7d-894a-bbc001fa8f88"
                  },
                  "arguments": [],
                  "births": []
                },
                "from_local": {
                  "numerator": "0",
                  "denominator": "1"
                },
                "to_local": {
                  "numerator": "10",
                  "denominator": "1"
                }
              }
            ]
          }
        }
      }
    }
  }
}
');
INSERT INTO "revisions" VALUES('1d20a800-7630-447c-8919-9d8c2e80f7e1','ed903801-af9a-4875-a6d0-2ffb76eb830f','undo','{
  "schema_version": 43,
  "project_id": "e6d1ba97-2db0-4119-9e5d-e4a4bef3e078",
  "revision_id": "1d20a800-7630-447c-8919-9d8c2e80f7e1",
  "presentation_basis": {
    "width": 320,
    "height": 180,
    "frame_rate": {
      "numerator": 30000,
      "denominator": 1001
    },
    "color_policy": "sdr_rec709"
  },
  "basis_state": {
    "rate_origin": "primary_source",
    "geometry_origin": "primary_source",
    "primary": {
      "asset": "b2868a97-5094-4eb8-9ccd-4a5c904983e0",
      "qualification": "c6bc3e81ab69906267164469d11739cf1363eea546436761ddd219069ed496b6"
    }
  },
  "root": "44425a05-dc69-45ff-aedd-26c2356c963a",
  "nodes": {
    "2edb85c2-83ff-4e7d-894a-bbc001fa8f88": {
      "label": "cfr-bframes.mp4",
      "kind": {
        "type": "source",
        "source": {
          "duration": 120,
          "edit_window": {
            "start": {
              "numerator": "0",
              "denominator": "1"
            },
            "end": {
              "numerator": "120",
              "denominator": "1"
            }
          },
          "video": {
            "type": "stream",
            "asset": "b2868a97-5094-4eb8-9ccd-4a5c904983e0",
            "span": {
              "start": {
                "ticks": 0,
                "time_base": {
                  "numerator": 1,
                  "denominator": 30000
                }
              },
              "end": {
                "ticks": 120120,
                "time_base": {
                  "numerator": 1,
                  "denominator": 30000
                }
              }
            }
          },
          "video_mapping": {
            "type": "placement",
            "start": {
              "numerator": "0",
              "denominator": "1"
            },
            "frames": {
              "numerator": "120",
              "denominator": "1"
            },
            "endpoints": "hold_adjacent"
          },
          "audio": {
            "asset": "b2868a97-5094-4eb8-9ccd-4a5c904983e0",
            "span": {
              "start": {
                "ticks": 0,
                "time_base": {
                  "numerator": 1,
                  "denominator": 48000
                }
              },
              "end": {
                "ticks": 192192,
                "time_base": {
                  "numerator": 1,
                  "denominator": 48000
                }
              }
            }
          },
          "audio_mapping": {
            "type": "placement",
            "start": {
              "numerator": "0",
              "denominator": "1"
            },
            "frames": {
              "numerator": "120",
              "denominator": "1"
            }
          },
          "link": "linked",
          "audio_offset": 0
        }
      }
    },
    "44425a05-dc69-45ff-aedd-26c2356c963a": {
      "label": "Sequence",
      "kind": {
        "type": "sequence",
        "children": [
          "2edb85c2-83ff-4e7d-894a-bbc001fa8f88"
        ]
      }
    }
  },
  "assets": {
    "b2868a97-5094-4eb8-9ccd-4a5c904983e0": {
      "label": "cfr-bframes.mp4",
      "content_hash": "blake3:16614ec12d06396d3c0f0e7b91cc902c6dc30ad89c28d74b805cf64dc60d8aa1",
      "video": {
        "start": {
          "ticks": 0,
          "time_base": {
            "numerator": 1,
            "denominator": 30000
          }
        },
        "end": {
          "ticks": 120120,
          "time_base": {
            "numerator": 1,
            "denominator": 30000
          }
        }
      },
      "audio": {
        "start": {
          "ticks": 0,
          "time_base": {
            "numerator": 1,
            "denominator": 48000
          }
        },
        "end": {
          "ticks": 192192,
          "time_base": {
            "numerator": 1,
            "denominator": 48000
          }
        }
      },
      "still_image": false,
      "frame_count": 120,
      "source_qualification": "c6bc3e81ab69906267164469d11739cf1363eea546436761ddd219069ed496b6"
    }
  },
  "marks": {},
  "overrides": {}
}
');
INSERT INTO "revisions" VALUES('d520ef8e-cf47-45a7-8adb-003d9f5422b6','1d20a800-7630-447c-8919-9d8c2e80f7e1','edit','{
  "schema_version": 43,
  "project_id": "e6d1ba97-2db0-4119-9e5d-e4a4bef3e078",
  "revision_id": "d520ef8e-cf47-45a7-8adb-003d9f5422b6",
  "presentation_basis": {
    "width": 320,
    "height": 180,
    "frame_rate": {
      "numerator": 30000,
      "denominator": 1001
    },
    "color_policy": "sdr_rec709"
  },
  "basis_state": {
    "rate_origin": "primary_source",
    "geometry_origin": "primary_source",
    "primary": {
      "asset": "b2868a97-5094-4eb8-9ccd-4a5c904983e0",
      "qualification": "c6bc3e81ab69906267164469d11739cf1363eea546436761ddd219069ed496b6"
    }
  },
  "root": "44425a05-dc69-45ff-aedd-26c2356c963a",
  "nodes": {
    "2edb85c2-83ff-4e7d-894a-bbc001fa8f88": {
      "label": "cfr-bframes.mp4",
      "kind": {
        "type": "source",
        "source": {
          "duration": 120,
          "edit_window": {
            "start": {
              "numerator": "0",
              "denominator": "1"
            },
            "end": {
              "numerator": "120",
              "denominator": "1"
            }
          },
          "video": {
            "type": "stream",
            "asset": "b2868a97-5094-4eb8-9ccd-4a5c904983e0",
            "span": {
              "start": {
                "ticks": 0,
                "time_base": {
                  "numerator": 1,
                  "denominator": 30000
                }
              },
              "end": {
                "ticks": 120120,
                "time_base": {
                  "numerator": 1,
                  "denominator": 30000
                }
              }
            }
          },
          "video_mapping": {
            "type": "placement",
            "start": {
              "numerator": "0",
              "denominator": "1"
            },
            "frames": {
              "numerator": "120",
              "denominator": "1"
            },
            "endpoints": "hold_adjacent"
          },
          "audio": {
            "asset": "b2868a97-5094-4eb8-9ccd-4a5c904983e0",
            "span": {
              "start": {
                "ticks": 0,
                "time_base": {
                  "numerator": 1,
                  "denominator": 48000
                }
              },
              "end": {
                "ticks": 192192,
                "time_base": {
                  "numerator": 1,
                  "denominator": 48000
                }
              }
            }
          },
          "audio_mapping": {
            "type": "placement",
            "start": {
              "numerator": "0",
              "denominator": "1"
            },
            "frames": {
              "numerator": "120",
              "denominator": "1"
            }
          },
          "link": "linked",
          "audio_offset": 0
        }
      }
    },
    "44425a05-dc69-45ff-aedd-26c2356c963a": {
      "label": "Sequence",
      "kind": {
        "type": "sequence",
        "children": [
          "2edb85c2-83ff-4e7d-894a-bbc001fa8f88",
          "7459517b-a5ea-470f-be8d-e441d3c67fc5"
        ]
      }
    },
    "4fd9d4c4-40fd-455b-a7cd-c3339c1eb5c5": {
      "label": "cfr-bframes.mp4",
      "kind": {
        "type": "source",
        "source": {
          "duration": 120,
          "edit_window": {
            "start": {
              "numerator": "0",
              "denominator": "1"
            },
            "end": {
              "numerator": "120",
              "denominator": "1"
            }
          },
          "video": {
            "type": "stream",
            "asset": "b2868a97-5094-4eb8-9ccd-4a5c904983e0",
            "span": {
              "start": {
                "ticks": 0,
                "time_base": {
                  "numerator": 1,
                  "denominator": 30000
                }
              },
              "end": {
                "ticks": 120120,
                "time_base": {
                  "numerator": 1,
                  "denominator": 30000
                }
              }
            }
          },
          "video_mapping": {
            "type": "placement",
            "start": {
              "numerator": "0",
              "denominator": "1"
            },
            "frames": {
              "numerator": "120",
              "denominator": "1"
            },
            "endpoints": "hold_adjacent"
          },
          "audio": {
            "asset": "b2868a97-5094-4eb8-9ccd-4a5c904983e0",
            "span": {
              "start": {
                "ticks": 0,
                "time_base": {
                  "numerator": 1,
                  "denominator": 48000
                }
              },
              "end": {
                "ticks": 192192,
                "time_base": {
                  "numerator": 1,
                  "denominator": 48000
                }
              }
            }
          },
          "audio_mapping": {
            "type": "placement",
            "start": {
              "numerator": "0",
              "denominator": "1"
            },
            "frames": {
              "numerator": "120",
              "denominator": "1"
            }
          },
          "link": "linked",
          "audio_offset": 0
        }
      }
    },
    "61cc923a-da53-4959-803c-ffc6abff742d": {
      "label": "Pause",
      "kind": {
        "type": "hold",
        "recipe": {
          "picture_context": {
            "canvases": [
              {
                "width": 320,
                "height": 180,
                "fit": "fit",
                "layers": []
              }
            ]
          },
          "duration": 11,
          "video": {
            "type": "freeze",
            "asset": "b2868a97-5094-4eb8-9ccd-4a5c904983e0",
            "timestamp": {
              "ticks": 9009,
              "time_base": {
                "numerator": 1,
                "denominator": 30000
              }
            }
          },
          "audio": {
            "type": "silence"
          }
        }
      }
    },
    "6e2031ed-997e-494f-aaaf-7a6d062eae3f": {
      "label": "cfr-bframes.mp4",
      "kind": {
        "type": "retime",
        "child": "76aeaee7-bfeb-4a0a-a391-eb4d7c56db99",
        "duration": 10,
        "mapping": {
          "start": 0,
          "end": 10
        },
        "pitch": "preserve",
        "purpose": "partition"
      }
    },
    "7459517b-a5ea-470f-be8d-e441d3c67fc5": {
      "label": "Copied contents",
      "kind": {
        "type": "sequence",
        "children": [
          "920058f6-2462-4645-93cf-400baf3230cd",
          "61cc923a-da53-4959-803c-ffc6abff742d",
          "b4b61067-f870-4b1a-a5f8-5bfbb4810576"
        ]
      }
    },
    "76aeaee7-bfeb-4a0a-a391-eb4d7c56db99": {
      "label": "cfr-bframes.mp4",
      "kind": {
        "type": "source",
        "source": {
          "duration": 120,
          "edit_window": {
            "start": {
              "numerator": "0",
              "denominator": "1"
            },
            "end": {
              "numerator": "120",
              "denominator": "1"
            }
          },
          "video": {
            "type": "stream",
            "asset": "b2868a97-5094-4eb8-9ccd-4a5c904983e0",
            "span": {
              "start": {
                "ticks": 0,
                "time_base": {
                  "numerator": 1,
                  "denominator": 30000
                }
              },
              "end": {
                "ticks": 120120,
                "time_base": {
                  "numerator": 1,
                  "denominator": 30000
                }
              }
            }
          },
          "video_mapping": {
            "type": "placement",
            "start": {
              "numerator": "0",
              "denominator": "1"
            },
            "frames": {
              "numerator": "120",
              "denominator": "1"
            },
            "endpoints": "hold_adjacent"
          },
          "audio": {
            "asset": "b2868a97-5094-4eb8-9ccd-4a5c904983e0",
            "span": {
              "start": {
                "ticks": 0,
                "time_base": {
                  "numerator": 1,
                  "denominator": 48000
                }
              },
              "end": {
                "ticks": 192192,
                "time_base": {
                  "numerator": 1,
                  "denominator": 48000
                }
              }
            }
          },
          "audio_mapping": {
            "type": "placement",
            "start": {
              "numerator": "0",
              "denominator": "1"
            },
            "frames": {
              "numerator": "120",
              "denominator": "1"
            }
          },
          "link": "linked",
          "audio_offset": 0
        }
      }
    },
    "920058f6-2462-4645-93cf-400baf3230cd": {
      "label": "Copied interval",
      "kind": {
        "type": "retime",
        "child": "6e2031ed-997e-494f-aaaf-7a6d062eae3f",
        "duration": 2,
        "mapping": {
          "start": 8,
          "end": 10
        },
        "pitch": "preserve",
        "purpose": "partition"
      }
    },
    "abbfc3e8-9429-495a-b888-b83ad57b4e7d": {
      "label": "cfr-bframes.mp4",
      "kind": {
        "type": "retime",
        "child": "4fd9d4c4-40fd-455b-a7cd-c3339c1eb5c5",
        "duration": 110,
        "mapping": {
          "start": 10,
          "end": 120
        },
        "pitch": "preserve",
        "purpose": "partition"
      }
    },
    "b4b61067-f870-4b1a-a5f8-5bfbb4810576": {
      "label": "Copied interval",
      "kind": {
        "type": "retime",
        "child": "abbfc3e8-9429-495a-b888-b83ad57b4e7d",
        "duration": 4,
        "mapping": {
          "start": 0,
          "end": 4
        },
        "pitch": "preserve",
        "purpose": "partition"
      }
    }
  },
  "assets": {
    "b2868a97-5094-4eb8-9ccd-4a5c904983e0": {
      "label": "cfr-bframes.mp4",
      "content_hash": "blake3:16614ec12d06396d3c0f0e7b91cc902c6dc30ad89c28d74b805cf64dc60d8aa1",
      "video": {
        "start": {
          "ticks": 0,
          "time_base": {
            "numerator": 1,
            "denominator": 30000
          }
        },
        "end": {
          "ticks": 120120,
          "time_base": {
            "numerator": 1,
            "denominator": 30000
          }
        }
      },
      "audio": {
        "start": {
          "ticks": 0,
          "time_base": {
            "numerator": 1,
            "denominator": 48000
          }
        },
        "end": {
          "ticks": 192192,
          "time_base": {
            "numerator": 1,
            "denominator": 48000
          }
        }
      },
      "still_image": false,
      "frame_count": 120,
      "source_qualification": "c6bc3e81ab69906267164469d11739cf1363eea546436761ddd219069ed496b6"
    }
  },
  "marks": {},
  "overrides": {},
  "audio_lineage": {
    "4fd9d4c4-40fd-455b-a7cd-c3339c1eb5c5": {
      "allocation": "d520ef8e-cf47-45a7-8adb-003d9f5422b6",
      "origin": "5008d98f-9f8c-4aec-b0ba-990897f605d8"
    },
    "76aeaee7-bfeb-4a0a-a391-eb4d7c56db99": {
      "allocation": "d520ef8e-cf47-45a7-8adb-003d9f5422b6",
      "origin": "5008d98f-9f8c-4aec-b0ba-990897f605d8"
    }
  },
  "audio_bindings": {
    "timings": [
      {
        "id": {
          "allocation": "d520ef8e-cf47-45a7-8adb-003d9f5422b6",
          "ordinal": 0
        },
        "layout": {
          "root": "44425a05-dc69-45ff-aedd-26c2356c963a",
          "rate": {
            "numerator": 30000,
            "denominator": 1001
          },
          "nodes": {
            "2edb85c2-83ff-4e7d-894a-bbc001fa8f88": {
              "duration": 120,
              "edges": {
                "node_start": "automatic",
                "node_end": "automatic",
                "source_placement_start": "automatic",
                "source_placement_end": "automatic",
                "repeat_gap_start": "automatic",
                "repeat_gap_end": "automatic"
              },
              "kind": {
                "type": "source",
                "placement": {
                  "start": {
                    "numerator": "0",
                    "denominator": "1"
                  },
                  "end": {
                    "numerator": "120",
                    "denominator": "1"
                  }
                }
              }
            },
            "44425a05-dc69-45ff-aedd-26c2356c963a": {
              "duration": 120,
              "edges": {
                "node_start": "automatic",
                "node_end": "automatic",
                "source_placement_start": "automatic",
                "source_placement_end": "automatic",
                "repeat_gap_start": "automatic",
                "repeat_gap_end": "automatic"
              },
              "kind": {
                "type": "sequence",
                "children": [
                  "2edb85c2-83ff-4e7d-894a-bbc001fa8f88"
                ]
              }
            }
          },
          "overrides": {}
        }
      },
      {
        "id": {
          "allocation": "d520ef8e-cf47-45a7-8adb-003d9f5422b6",
          "ordinal": 1
        },
        "layout": {
          "root": "777fd7c5-3356-4dd0-b297-252425ccb260",
          "rate": {
            "numerator": 30000,
            "denominator": 1001
          },
          "nodes": {
            "1a4c5485-9fcf-4bff-8257-e7ba9792ee4f": {
              "duration": 120,
              "edges": {
                "node_start": "automatic",
                "node_end": "automatic",
                "source_placement_start": "automatic",
                "source_placement_end": "automatic",
                "repeat_gap_start": "automatic",
                "repeat_gap_end": "automatic"
              },
              "kind": {
                "type": "source",
                "placement": {
                  "start": {
                    "numerator": "0",
                    "denominator": "1"
                  },
                  "end": {
                    "numerator": "120",
                    "denominator": "1"
                  }
                }
              }
            },
            "777fd7c5-3356-4dd0-b297-252425ccb260": {
              "duration": 131,
              "edges": {
                "node_start": "automatic",
                "node_end": "automatic",
                "source_placement_start": "automatic",
                "source_placement_end": "automatic",
                "repeat_gap_start": "automatic",
                "repeat_gap_end": "automatic"
              },
              "kind": {
                "type": "sequence",
                "children": [
                  "cf654917-686b-415c-9619-6ca5dad8ccb1",
                  "de1b8bc5-07f0-476a-94ae-75587fff648a",
                  "f5f78dc9-00a3-414c-a005-ab5b0326dd8e"
                ]
              }
            },
            "903535fb-d6d6-4ef4-a7f8-ea937f9d7233": {
              "duration": 120,
              "edges": {
                "node_start": "automatic",
                "node_end": "automatic",
                "source_placement_start": "automatic",
                "source_placement_end": "automatic",
                "repeat_gap_start": "automatic",
                "repeat_gap_end": "automatic"
              },
              "kind": {
                "type": "source",
                "placement": {
                  "start": {
                    "numerator": "0",
                    "denominator": "1"
                  },
                  "end": {
                    "numerator": "120",
                    "denominator": "1"
                  }
                }
              }
            },
            "cf654917-686b-415c-9619-6ca5dad8ccb1": {
              "duration": 10,
              "edges": {
                "node_start": "automatic",
                "node_end": "automatic",
                "source_placement_start": "automatic",
                "source_placement_end": "automatic",
                "repeat_gap_start": "automatic",
                "repeat_gap_end": "automatic"
              },
              "kind": {
                "type": "retime",
                "child": "1a4c5485-9fcf-4bff-8257-e7ba9792ee4f",
                "mapping": {
                  "start": 0,
                  "end": 10
                },
                "pitch": "preserve",
                "purpose": "partition"
              }
            },
            "de1b8bc5-07f0-476a-94ae-75587fff648a": {
              "duration": 11,
              "edges": {
                "node_start": "automatic",
                "node_end": "automatic",
                "source_placement_start": "automatic",
                "source_placement_end": "automatic",
                "repeat_gap_start": "automatic",
                "repeat_gap_end": "automatic"
              },
              "kind": {
                "type": "hold",
                "audio": {
                  "type": "silence"
                }
              }
            },
            "f5f78dc9-00a3-414c-a005-ab5b0326dd8e": {
              "duration": 110,
              "edges": {
                "node_start": "automatic",
                "node_end": "automatic",
                "source_placement_start": "automatic",
                "source_placement_end": "automatic",
                "repeat_gap_start": "automatic",
                "repeat_gap_end": "automatic"
              },
              "kind": {
                "type": "retime",
                "child": "903535fb-d6d6-4ef4-a7f8-ea937f9d7233",
                "mapping": {
                  "start": 10,
                  "end": 120
                },
                "pitch": "preserve",
                "purpose": "partition"
              }
            }
          },
          "overrides": {},
          "audio_lineage": {
            "1a4c5485-9fcf-4bff-8257-e7ba9792ee4f": {
              "allocation": "d520ef8e-cf47-45a7-8adb-003d9f5422b6",
              "origin": "5008d98f-9f8c-4aec-b0ba-990897f605d8"
            },
            "903535fb-d6d6-4ef4-a7f8-ea937f9d7233": {
              "allocation": "d520ef8e-cf47-45a7-8adb-003d9f5422b6",
              "origin": "5008d98f-9f8c-4aec-b0ba-990897f605d8"
            }
          }
        }
      },
      {
        "id": {
          "allocation": "d520ef8e-cf47-45a7-8adb-003d9f5422b6",
          "ordinal": 2
        },
        "layout": {
          "root": "6ce2fb3a-ac78-4297-b384-aa2c3250d05c",
          "rate": {
            "numerator": 30000,
            "denominator": 1001
          },
          "nodes": {
            "6ce2fb3a-ac78-4297-b384-aa2c3250d05c": {
              "duration": 120,
              "edges": {
                "node_start": "automatic",
                "node_end": "automatic",
                "source_placement_start": "automatic",
                "source_placement_end": "automatic",
                "repeat_gap_start": "automatic",
                "repeat_gap_end": "automatic"
              },
              "kind": {
                "type": "sequence",
                "children": [
                  "d8b5f5ee-b1b0-4d33-9ee9-9cf5c5781709"
                ]
              }
            },
            "d8b5f5ee-b1b0-4d33-9ee9-9cf5c5781709": {
              "duration": 120,
              "edges": {
                "node_start": "automatic",
                "node_end": "automatic",
                "source_placement_start": "automatic",
                "source_placement_end": "automatic",
                "repeat_gap_start": "automatic",
                "repeat_gap_end": "automatic"
              },
              "kind": {
                "type": "source",
                "placement": {
                  "start": {
                    "numerator": "0",
                    "denominator": "1"
                  },
                  "end": {
                    "numerator": "120",
                    "denominator": "1"
                  }
                }
              }
            }
          },
          "overrides": {}
        }
      }
    ],
    "bindings": {
      "2edb85c2-83ff-4e7d-894a-bbc001fa8f88": {
        "lattice": {
          "reference": {
            "timing": {
              "allocation": "d520ef8e-cf47-45a7-8adb-003d9f5422b6",
              "ordinal": 0
            },
            "root": {
              "type": "project_root_round_even"
            },
            "physical": "2edb85c2-83ff-4e7d-894a-bbc001fa8f88"
          },
          "arguments": [],
          "births": []
        },
        "resume": null
      },
      "4fd9d4c4-40fd-455b-a7cd-c3339c1eb5c5": {
        "lattice": {
          "reference": {
            "timing": {
              "allocation": "d520ef8e-cf47-45a7-8adb-003d9f5422b6",
              "ordinal": 2
            },
            "root": {
              "type": "project_root_round_even"
            },
            "physical": "d8b5f5ee-b1b0-4d33-9ee9-9cf5c5781709"
          },
          "arguments": [],
          "births": []
        },
        "resume": {
          "local_boundary": {
            "numerator": "10",
            "denominator": "1"
          },
          "phase": {
            "constant": {
              "numerator": "0",
              "denominator": "1"
            },
            "terms": [
              {
                "placement": {
                  "reference": {
                    "timing": {
                      "allocation": "d520ef8e-cf47-45a7-8adb-003d9f5422b6",
                      "ordinal": 2
                    },
                    "root": {
                      "type": "project_root_round_even"
                    },
                    "physical": "d8b5f5ee-b1b0-4d33-9ee9-9cf5c5781709"
                  },
                  "arguments": [],
                  "births": []
                },
                "from_local": {
                  "numerator": "0",
                  "denominator": "1"
                },
                "to_local": {
                  "numerator": "10",
                  "denominator": "1"
                }
              }
            ]
          }
        },
        "reanchors": [
          {
            "placement": {
              "reference": {
                "timing": {
                  "allocation": "d520ef8e-cf47-45a7-8adb-003d9f5422b6",
                  "ordinal": 1
                },
                "root": {
                  "type": "project_root_round_even"
                },
                "physical": "903535fb-d6d6-4ef4-a7f8-ea937f9d7233"
              },
              "arguments": [],
              "births": []
            },
            "window": {
              "start": {
                "numerator": "8",
                "denominator": "1"
              },
              "end": {
                "numerator": "25",
                "denominator": "1"
              }
            }
          }
        ]
      },
      "61cc923a-da53-4959-803c-ffc6abff742d": {
        "lattice": {
          "reference": {
            "timing": {
              "allocation": "d520ef8e-cf47-45a7-8adb-003d9f5422b6",
              "ordinal": 1
            },
            "root": {
              "type": "project_root_round_even"
            },
            "physical": "de1b8bc5-07f0-476a-94ae-75587fff648a"
          },
          "arguments": [],
          "births": []
        },
        "resume": null,
        "reanchors": [
          {
            "placement": {
              "reference": {
                "timing": {
                  "allocation": "d520ef8e-cf47-45a7-8adb-003d9f5422b6",
                  "ordinal": 1
                },
                "root": {
                  "type": "project_root_round_even"
                },
                "physical": "de1b8bc5-07f0-476a-94ae-75587fff648a"
              },
              "arguments": [],
              "births": []
            },
            "window": {
              "start": {
                "numerator": "8",
                "denominator": "1"
              },
              "end": {
                "numerator": "25",
                "denominator": "1"
              }
            }
          }
        ]
      },
      "76aeaee7-bfeb-4a0a-a391-eb4d7c56db99": {
        "lattice": {
          "reference": {
            "timing": {
              "allocation": "d520ef8e-cf47-45a7-8adb-003d9f5422b6",
              "ordinal": 2
            },
            "root": {
              "type": "project_root_round_even"
            },
            "physical": "d8b5f5ee-b1b0-4d33-9ee9-9cf5c5781709"
          },
          "arguments": [],
          "births": []
        },
        "resume": null,
        "reanchors": [
          {
            "placement": {
              "reference": {
                "timing": {
                  "allocation": "d520ef8e-cf47-45a7-8adb-003d9f5422b6",
                  "ordinal": 1
                },
                "root": {
                  "type": "project_root_round_even"
                },
                "physical": "1a4c5485-9fcf-4bff-8257-e7ba9792ee4f"
              },
              "arguments": [],
              "births": []
            },
            "window": {
              "start": {
                "numerator": "8",
                "denominator": "1"
              },
              "end": {
                "numerator": "25",
                "denominator": "1"
              }
            }
          }
        ]
      }
    }
  }
}
');
INSERT INTO "revisions" VALUES('b5c2fe56-b4d6-42ce-9243-90a7976b1b46','d520ef8e-cf47-45a7-8adb-003d9f5422b6','undo','{
  "schema_version": 43,
  "project_id": "e6d1ba97-2db0-4119-9e5d-e4a4bef3e078",
  "revision_id": "b5c2fe56-b4d6-42ce-9243-90a7976b1b46",
  "presentation_basis": {
    "width": 320,
    "height": 180,
    "frame_rate": {
      "numerator": 30000,
      "denominator": 1001
    },
    "color_policy": "sdr_rec709"
  },
  "basis_state": {
    "rate_origin": "primary_source",
    "geometry_origin": "primary_source",
    "primary": {
      "asset": "b2868a97-5094-4eb8-9ccd-4a5c904983e0",
      "qualification": "c6bc3e81ab69906267164469d11739cf1363eea546436761ddd219069ed496b6"
    }
  },
  "root": "44425a05-dc69-45ff-aedd-26c2356c963a",
  "nodes": {
    "2edb85c2-83ff-4e7d-894a-bbc001fa8f88": {
      "label": "cfr-bframes.mp4",
      "kind": {
        "type": "source",
        "source": {
          "duration": 120,
          "edit_window": {
            "start": {
              "numerator": "0",
              "denominator": "1"
            },
            "end": {
              "numerator": "120",
              "denominator": "1"
            }
          },
          "video": {
            "type": "stream",
            "asset": "b2868a97-5094-4eb8-9ccd-4a5c904983e0",
            "span": {
              "start": {
                "ticks": 0,
                "time_base": {
                  "numerator": 1,
                  "denominator": 30000
                }
              },
              "end": {
                "ticks": 120120,
                "time_base": {
                  "numerator": 1,
                  "denominator": 30000
                }
              }
            }
          },
          "video_mapping": {
            "type": "placement",
            "start": {
              "numerator": "0",
              "denominator": "1"
            },
            "frames": {
              "numerator": "120",
              "denominator": "1"
            },
            "endpoints": "hold_adjacent"
          },
          "audio": {
            "asset": "b2868a97-5094-4eb8-9ccd-4a5c904983e0",
            "span": {
              "start": {
                "ticks": 0,
                "time_base": {
                  "numerator": 1,
                  "denominator": 48000
                }
              },
              "end": {
                "ticks": 192192,
                "time_base": {
                  "numerator": 1,
                  "denominator": 48000
                }
              }
            }
          },
          "audio_mapping": {
            "type": "placement",
            "start": {
              "numerator": "0",
              "denominator": "1"
            },
            "frames": {
              "numerator": "120",
              "denominator": "1"
            }
          },
          "link": "linked",
          "audio_offset": 0
        }
      }
    },
    "44425a05-dc69-45ff-aedd-26c2356c963a": {
      "label": "Sequence",
      "kind": {
        "type": "sequence",
        "children": [
          "2edb85c2-83ff-4e7d-894a-bbc001fa8f88"
        ]
      }
    }
  },
  "assets": {
    "b2868a97-5094-4eb8-9ccd-4a5c904983e0": {
      "label": "cfr-bframes.mp4",
      "content_hash": "blake3:16614ec12d06396d3c0f0e7b91cc902c6dc30ad89c28d74b805cf64dc60d8aa1",
      "video": {
        "start": {
          "ticks": 0,
          "time_base": {
            "numerator": 1,
            "denominator": 30000
          }
        },
        "end": {
          "ticks": 120120,
          "time_base": {
            "numerator": 1,
            "denominator": 30000
          }
        }
      },
      "audio": {
        "start": {
          "ticks": 0,
          "time_base": {
            "numerator": 1,
            "denominator": 48000
          }
        },
        "end": {
          "ticks": 192192,
          "time_base": {
            "numerator": 1,
            "denominator": 48000
          }
        }
      },
      "still_image": false,
      "frame_count": 120,
      "source_qualification": "c6bc3e81ab69906267164469d11739cf1363eea546436761ddd219069ed496b6"
    }
  },
  "marks": {},
  "overrides": {}
}
');
INSERT INTO "revisions" VALUES('0b67ab02-5441-4678-961c-2fcea036a113','b5c2fe56-b4d6-42ce-9243-90a7976b1b46','edit','{
  "schema_version": 43,
  "project_id": "e6d1ba97-2db0-4119-9e5d-e4a4bef3e078",
  "revision_id": "0b67ab02-5441-4678-961c-2fcea036a113",
  "presentation_basis": {
    "width": 320,
    "height": 180,
    "frame_rate": {
      "numerator": 30000,
      "denominator": 1001
    },
    "color_policy": "sdr_rec709"
  },
  "basis_state": {
    "rate_origin": "primary_source",
    "geometry_origin": "primary_source",
    "primary": {
      "asset": "b2868a97-5094-4eb8-9ccd-4a5c904983e0",
      "qualification": "c6bc3e81ab69906267164469d11739cf1363eea546436761ddd219069ed496b6"
    }
  },
  "root": "44425a05-dc69-45ff-aedd-26c2356c963a",
  "nodes": {
    "2edb85c2-83ff-4e7d-894a-bbc001fa8f88": {
      "label": "cfr-bframes.mp4",
      "kind": {
        "type": "source",
        "source": {
          "duration": 120,
          "edit_window": {
            "start": {
              "numerator": "0",
              "denominator": "1"
            },
            "end": {
              "numerator": "120",
              "denominator": "1"
            }
          },
          "video": {
            "type": "stream",
            "asset": "b2868a97-5094-4eb8-9ccd-4a5c904983e0",
            "span": {
              "start": {
                "ticks": 0,
                "time_base": {
                  "numerator": 1,
                  "denominator": 30000
                }
              },
              "end": {
                "ticks": 120120,
                "time_base": {
                  "numerator": 1,
                  "denominator": 30000
                }
              }
            }
          },
          "video_mapping": {
            "type": "placement",
            "start": {
              "numerator": "0",
              "denominator": "1"
            },
            "frames": {
              "numerator": "120",
              "denominator": "1"
            },
            "endpoints": "hold_adjacent"
          },
          "audio": {
            "asset": "b2868a97-5094-4eb8-9ccd-4a5c904983e0",
            "span": {
              "start": {
                "ticks": 0,
                "time_base": {
                  "numerator": 1,
                  "denominator": 48000
                }
              },
              "end": {
                "ticks": 192192,
                "time_base": {
                  "numerator": 1,
                  "denominator": 48000
                }
              }
            }
          },
          "audio_mapping": {
            "type": "placement",
            "start": {
              "numerator": "0",
              "denominator": "1"
            },
            "frames": {
              "numerator": "120",
              "denominator": "1"
            }
          },
          "link": "linked",
          "audio_offset": 0
        }
      }
    },
    "44425a05-dc69-45ff-aedd-26c2356c963a": {
      "label": "Sequence",
      "kind": {
        "type": "sequence",
        "children": [
          "7dd5a588-d539-46aa-9868-1bdcf84cefd4",
          "5b713f47-554f-4437-80dd-dd996488a5ce"
        ]
      }
    },
    "4c685d21-bde0-48c3-ab42-a50742c23c13": {
      "label": "cfr-bframes.mp4",
      "kind": {
        "type": "source",
        "source": {
          "duration": 120,
          "edit_window": {
            "start": {
              "numerator": "0",
              "denominator": "1"
            },
            "end": {
              "numerator": "120",
              "denominator": "1"
            }
          },
          "video": {
            "type": "stream",
            "asset": "b2868a97-5094-4eb8-9ccd-4a5c904983e0",
            "span": {
              "start": {
                "ticks": 0,
                "time_base": {
                  "numerator": 1,
                  "denominator": 30000
                }
              },
              "end": {
                "ticks": 120120,
                "time_base": {
                  "numerator": 1,
                  "denominator": 30000
                }
              }
            }
          },
          "video_mapping": {
            "type": "placement",
            "start": {
              "numerator": "0",
              "denominator": "1"
            },
            "frames": {
              "numerator": "120",
              "denominator": "1"
            },
            "endpoints": "hold_adjacent"
          },
          "audio": {
            "asset": "b2868a97-5094-4eb8-9ccd-4a5c904983e0",
            "span": {
              "start": {
                "ticks": 0,
                "time_base": {
                  "numerator": 1,
                  "denominator": 48000
                }
              },
              "end": {
                "ticks": 192192,
                "time_base": {
                  "numerator": 1,
                  "denominator": 48000
                }
              }
            }
          },
          "audio_mapping": {
            "type": "placement",
            "start": {
              "numerator": "0",
              "denominator": "1"
            },
            "frames": {
              "numerator": "120",
              "denominator": "1"
            }
          },
          "link": "linked",
          "audio_offset": 0
        }
      }
    },
    "5b713f47-554f-4437-80dd-dd996488a5ce": {
      "label": "cfr-bframes.mp4",
      "kind": {
        "type": "retime",
        "child": "4c685d21-bde0-48c3-ab42-a50742c23c13",
        "duration": 90,
        "mapping": {
          "start": 30,
          "end": 120
        },
        "pitch": "preserve",
        "purpose": "partition"
      }
    },
    "7dd5a588-d539-46aa-9868-1bdcf84cefd4": {
      "label": "cfr-bframes.mp4",
      "kind": {
        "type": "retime",
        "child": "2edb85c2-83ff-4e7d-894a-bbc001fa8f88",
        "duration": 20,
        "mapping": {
          "start": 0,
          "end": 20
        },
        "pitch": "preserve",
        "purpose": "partition"
      }
    }
  },
  "assets": {
    "b2868a97-5094-4eb8-9ccd-4a5c904983e0": {
      "label": "cfr-bframes.mp4",
      "content_hash": "blake3:16614ec12d06396d3c0f0e7b91cc902c6dc30ad89c28d74b805cf64dc60d8aa1",
      "video": {
        "start": {
          "ticks": 0,
          "time_base": {
            "numerator": 1,
            "denominator": 30000
          }
        },
        "end": {
          "ticks": 120120,
          "time_base": {
            "numerator": 1,
            "denominator": 30000
          }
        }
      },
      "audio": {
        "start": {
          "ticks": 0,
          "time_base": {
            "numerator": 1,
            "denominator": 48000
          }
        },
        "end": {
          "ticks": 192192,
          "time_base": {
            "numerator": 1,
            "denominator": 48000
          }
        }
      },
      "still_image": false,
      "frame_count": 120,
      "source_qualification": "c6bc3e81ab69906267164469d11739cf1363eea546436761ddd219069ed496b6"
    }
  },
  "marks": {},
  "overrides": {},
  "audio_lineage": {
    "2edb85c2-83ff-4e7d-894a-bbc001fa8f88": {
      "allocation": "0b67ab02-5441-4678-961c-2fcea036a113",
      "origin": "2edb85c2-83ff-4e7d-894a-bbc001fa8f88"
    },
    "4c685d21-bde0-48c3-ab42-a50742c23c13": {
      "allocation": "0b67ab02-5441-4678-961c-2fcea036a113",
      "origin": "2edb85c2-83ff-4e7d-894a-bbc001fa8f88"
    }
  },
  "audio_bindings": {
    "timings": [
      {
        "id": {
          "allocation": "0b67ab02-5441-4678-961c-2fcea036a113",
          "ordinal": 0
        },
        "layout": {
          "root": "44425a05-dc69-45ff-aedd-26c2356c963a",
          "rate": {
            "numerator": 30000,
            "denominator": 1001
          },
          "nodes": {
            "2edb85c2-83ff-4e7d-894a-bbc001fa8f88": {
              "duration": 120,
              "edges": {
                "node_start": "automatic",
                "node_end": "automatic",
                "source_placement_start": "automatic",
                "source_placement_end": "automatic",
                "repeat_gap_start": "automatic",
                "repeat_gap_end": "automatic"
              },
              "kind": {
                "type": "source",
                "placement": {
                  "start": {
                    "numerator": "0",
                    "denominator": "1"
                  },
                  "end": {
                    "numerator": "120",
                    "denominator": "1"
                  }
                }
              }
            },
            "44425a05-dc69-45ff-aedd-26c2356c963a": {
              "duration": 120,
              "edges": {
                "node_start": "automatic",
                "node_end": "automatic",
                "source_placement_start": "automatic",
                "source_placement_end": "automatic",
                "repeat_gap_start": "automatic",
                "repeat_gap_end": "automatic"
              },
              "kind": {
                "type": "sequence",
                "children": [
                  "2edb85c2-83ff-4e7d-894a-bbc001fa8f88"
                ]
              }
            }
          },
          "overrides": {}
        }
      },
      {
        "id": {
          "allocation": "0b67ab02-5441-4678-961c-2fcea036a113",
          "ordinal": 1
        },
        "layout": {
          "root": "44425a05-dc69-45ff-aedd-26c2356c963a",
          "rate": {
            "numerator": 30000,
            "denominator": 1001
          },
          "nodes": {
            "2edb85c2-83ff-4e7d-894a-bbc001fa8f88": {
              "duration": 120,
              "edges": {
                "node_start": "automatic",
                "node_end": "automatic",
                "source_placement_start": "automatic",
                "source_placement_end": "automatic",
                "repeat_gap_start": "automatic",
                "repeat_gap_end": "automatic"
              },
              "kind": {
                "type": "source",
                "placement": {
                  "start": {
                    "numerator": "0",
                    "denominator": "1"
                  },
                  "end": {
                    "numerator": "120",
                    "denominator": "1"
                  }
                }
              }
            },
            "44425a05-dc69-45ff-aedd-26c2356c963a": {
              "duration": 120,
              "edges": {
                "node_start": "automatic",
                "node_end": "automatic",
                "source_placement_start": "automatic",
                "source_placement_end": "automatic",
                "repeat_gap_start": "automatic",
                "repeat_gap_end": "automatic"
              },
              "kind": {
                "type": "sequence",
                "children": [
                  "7dd5a588-d539-46aa-9868-1bdcf84cefd4",
                  "f6586eb2-456d-4936-b238-23c51261abd2",
                  "5b713f47-554f-4437-80dd-dd996488a5ce"
                ]
              }
            },
            "4c685d21-bde0-48c3-ab42-a50742c23c13": {
              "duration": 120,
              "edges": {
                "node_start": "automatic",
                "node_end": "automatic",
                "source_placement_start": "automatic",
                "source_placement_end": "automatic",
                "repeat_gap_start": "automatic",
                "repeat_gap_end": "automatic"
              },
              "kind": {
                "type": "source",
                "placement": {
                  "start": {
                    "numerator": "0",
                    "denominator": "1"
                  },
                  "end": {
                    "numerator": "120",
                    "denominator": "1"
                  }
                }
              }
            },
            "5b713f47-554f-4437-80dd-dd996488a5ce": {
              "duration": 90,
              "edges": {
                "node_start": "automatic",
                "node_end": "automatic",
                "source_placement_start": "automatic",
                "source_placement_end": "automatic",
                "repeat_gap_start": "automatic",
                "repeat_gap_end": "automatic"
              },
              "kind": {
                "type": "retime",
                "child": "4c685d21-bde0-48c3-ab42-a50742c23c13",
                "mapping": {
                  "start": 30,
                  "end": 120
                },
                "pitch": "preserve",
                "purpose": "partition"
              }
            },
            "7dd5a588-d539-46aa-9868-1bdcf84cefd4": {
              "duration": 20,
              "edges": {
                "node_start": "automatic",
                "node_end": "automatic",
                "source_placement_start": "automatic",
                "source_placement_end": "automatic",
                "repeat_gap_start": "automatic",
                "repeat_gap_end": "automatic"
              },
              "kind": {
                "type": "retime",
                "child": "2edb85c2-83ff-4e7d-894a-bbc001fa8f88",
                "mapping": {
                  "start": 0,
                  "end": 20
                },
                "pitch": "preserve",
                "purpose": "partition"
              }
            },
            "9c665126-cea5-414d-bf18-8dd77ab0ff87": {
              "duration": 120,
              "edges": {
                "node_start": "automatic",
                "node_end": "automatic",
                "source_placement_start": "automatic",
                "source_placement_end": "automatic",
                "repeat_gap_start": "automatic",
                "repeat_gap_end": "automatic"
              },
              "kind": {
                "type": "source",
                "placement": {
                  "start": {
                    "numerator": "0",
                    "denominator": "1"
                  },
                  "end": {
                    "numerator": "120",
                    "denominator": "1"
                  }
                }
              }
            },
            "f6586eb2-456d-4936-b238-23c51261abd2": {
              "duration": 10,
              "edges": {
                "node_start": "automatic",
                "node_end": "automatic",
                "source_placement_start": "automatic",
                "source_placement_end": "automatic",
                "repeat_gap_start": "automatic",
                "repeat_gap_end": "automatic"
              },
              "kind": {
                "type": "retime",
                "child": "9c665126-cea5-414d-bf18-8dd77ab0ff87",
                "mapping": {
                  "start": 20,
                  "end": 30
                },
                "pitch": "preserve",
                "purpose": "partition"
              }
            }
          },
          "overrides": {},
          "audio_lineage": {
            "2edb85c2-83ff-4e7d-894a-bbc001fa8f88": {
              "allocation": "0b67ab02-5441-4678-961c-2fcea036a113",
              "origin": "2edb85c2-83ff-4e7d-894a-bbc001fa8f88"
            },
            "4c685d21-bde0-48c3-ab42-a50742c23c13": {
              "allocation": "0b67ab02-5441-4678-961c-2fcea036a113",
              "origin": "2edb85c2-83ff-4e7d-894a-bbc001fa8f88"
            },
            "9c665126-cea5-414d-bf18-8dd77ab0ff87": {
              "allocation": "0b67ab02-5441-4678-961c-2fcea036a113",
              "origin": "2edb85c2-83ff-4e7d-894a-bbc001fa8f88"
            }
          }
        }
      }
    ],
    "bindings": {
      "2edb85c2-83ff-4e7d-894a-bbc001fa8f88": {
        "lattice": {
          "reference": {
            "timing": {
              "allocation": "0b67ab02-5441-4678-961c-2fcea036a113",
              "ordinal": 0
            },
            "root": {
              "type": "project_root_round_even"
            },
            "physical": "2edb85c2-83ff-4e7d-894a-bbc001fa8f88"
          },
          "arguments": [],
          "births": []
        },
        "resume": null
      },
      "4c685d21-bde0-48c3-ab42-a50742c23c13": {
        "lattice": {
          "reference": {
            "timing": {
              "allocation": "0b67ab02-5441-4678-961c-2fcea036a113",
              "ordinal": 0
            },
            "root": {
              "type": "project_root_round_even"
            },
            "physical": "2edb85c2-83ff-4e7d-894a-bbc001fa8f88"
          },
          "arguments": [],
          "births": []
        },
        "resume": null,
        "reanchors": [
          {
            "placement": {
              "reference": {
                "timing": {
                  "allocation": "0b67ab02-5441-4678-961c-2fcea036a113",
                  "ordinal": 1
                },
                "root": {
                  "type": "project_root_round_even"
                },
                "physical": "4c685d21-bde0-48c3-ab42-a50742c23c13"
              },
              "arguments": [],
              "births": []
            },
            "window": {
              "start": {
                "numerator": "30",
                "denominator": "1"
              },
              "end": {
                "numerator": "120",
                "denominator": "1"
              }
            }
          }
        ]
      }
    }
  }
}
');
INSERT INTO "revisions" VALUES('8eec44f6-1120-4904-8760-1f4ae33aa95c','0b67ab02-5441-4678-961c-2fcea036a113','undo','{
  "schema_version": 43,
  "project_id": "e6d1ba97-2db0-4119-9e5d-e4a4bef3e078",
  "revision_id": "8eec44f6-1120-4904-8760-1f4ae33aa95c",
  "presentation_basis": {
    "width": 320,
    "height": 180,
    "frame_rate": {
      "numerator": 30000,
      "denominator": 1001
    },
    "color_policy": "sdr_rec709"
  },
  "basis_state": {
    "rate_origin": "primary_source",
    "geometry_origin": "primary_source",
    "primary": {
      "asset": "b2868a97-5094-4eb8-9ccd-4a5c904983e0",
      "qualification": "c6bc3e81ab69906267164469d11739cf1363eea546436761ddd219069ed496b6"
    }
  },
  "root": "44425a05-dc69-45ff-aedd-26c2356c963a",
  "nodes": {
    "2edb85c2-83ff-4e7d-894a-bbc001fa8f88": {
      "label": "cfr-bframes.mp4",
      "kind": {
        "type": "source",
        "source": {
          "duration": 120,
          "edit_window": {
            "start": {
              "numerator": "0",
              "denominator": "1"
            },
            "end": {
              "numerator": "120",
              "denominator": "1"
            }
          },
          "video": {
            "type": "stream",
            "asset": "b2868a97-5094-4eb8-9ccd-4a5c904983e0",
            "span": {
              "start": {
                "ticks": 0,
                "time_base": {
                  "numerator": 1,
                  "denominator": 30000
                }
              },
              "end": {
                "ticks": 120120,
                "time_base": {
                  "numerator": 1,
                  "denominator": 30000
                }
              }
            }
          },
          "video_mapping": {
            "type": "placement",
            "start": {
              "numerator": "0",
              "denominator": "1"
            },
            "frames": {
              "numerator": "120",
              "denominator": "1"
            },
            "endpoints": "hold_adjacent"
          },
          "audio": {
            "asset": "b2868a97-5094-4eb8-9ccd-4a5c904983e0",
            "span": {
              "start": {
                "ticks": 0,
                "time_base": {
                  "numerator": 1,
                  "denominator": 48000
                }
              },
              "end": {
                "ticks": 192192,
                "time_base": {
                  "numerator": 1,
                  "denominator": 48000
                }
              }
            }
          },
          "audio_mapping": {
            "type": "placement",
            "start": {
              "numerator": "0",
              "denominator": "1"
            },
            "frames": {
              "numerator": "120",
              "denominator": "1"
            }
          },
          "link": "linked",
          "audio_offset": 0
        }
      }
    },
    "44425a05-dc69-45ff-aedd-26c2356c963a": {
      "label": "Sequence",
      "kind": {
        "type": "sequence",
        "children": [
          "2edb85c2-83ff-4e7d-894a-bbc001fa8f88"
        ]
      }
    }
  },
  "assets": {
    "b2868a97-5094-4eb8-9ccd-4a5c904983e0": {
      "label": "cfr-bframes.mp4",
      "content_hash": "blake3:16614ec12d06396d3c0f0e7b91cc902c6dc30ad89c28d74b805cf64dc60d8aa1",
      "video": {
        "start": {
          "ticks": 0,
          "time_base": {
            "numerator": 1,
            "denominator": 30000
          }
        },
        "end": {
          "ticks": 120120,
          "time_base": {
            "numerator": 1,
            "denominator": 30000
          }
        }
      },
      "audio": {
        "start": {
          "ticks": 0,
          "time_base": {
            "numerator": 1,
            "denominator": 48000
          }
        },
        "end": {
          "ticks": 192192,
          "time_base": {
            "numerator": 1,
            "denominator": 48000
          }
        }
      },
      "still_image": false,
      "frame_count": 120,
      "source_qualification": "c6bc3e81ab69906267164469d11739cf1363eea546436761ddd219069ed496b6"
    }
  },
  "marks": {},
  "overrides": {}
}
');
INSERT INTO "revisions" VALUES('ad26a1cc-4ede-4f67-a9d0-9635054584e9','8eec44f6-1120-4904-8760-1f4ae33aa95c','edit','{
  "schema_version": 43,
  "project_id": "e6d1ba97-2db0-4119-9e5d-e4a4bef3e078",
  "revision_id": "ad26a1cc-4ede-4f67-a9d0-9635054584e9",
  "presentation_basis": {
    "width": 320,
    "height": 180,
    "frame_rate": {
      "numerator": 30000,
      "denominator": 1001
    },
    "color_policy": "sdr_rec709"
  },
  "basis_state": {
    "rate_origin": "primary_source",
    "geometry_origin": "primary_source",
    "primary": {
      "asset": "b2868a97-5094-4eb8-9ccd-4a5c904983e0",
      "qualification": "c6bc3e81ab69906267164469d11739cf1363eea546436761ddd219069ed496b6"
    }
  },
  "root": "44425a05-dc69-45ff-aedd-26c2356c963a",
  "nodes": {
    "2edb85c2-83ff-4e7d-894a-bbc001fa8f88": {
      "label": "cfr-bframes.mp4",
      "kind": {
        "type": "source",
        "source": {
          "duration": 120,
          "edit_window": {
            "start": {
              "numerator": "0",
              "denominator": "1"
            },
            "end": {
              "numerator": "120",
              "denominator": "1"
            }
          },
          "video": {
            "type": "stream",
            "asset": "b2868a97-5094-4eb8-9ccd-4a5c904983e0",
            "span": {
              "start": {
                "ticks": 0,
                "time_base": {
                  "numerator": 1,
                  "denominator": 30000
                }
              },
              "end": {
                "ticks": 120120,
                "time_base": {
                  "numerator": 1,
                  "denominator": 30000
                }
              }
            }
          },
          "video_mapping": {
            "type": "placement",
            "start": {
              "numerator": "0",
              "denominator": "1"
            },
            "frames": {
              "numerator": "120",
              "denominator": "1"
            },
            "endpoints": "hold_adjacent"
          },
          "audio": {
            "asset": "b2868a97-5094-4eb8-9ccd-4a5c904983e0",
            "span": {
              "start": {
                "ticks": 0,
                "time_base": {
                  "numerator": 1,
                  "denominator": 48000
                }
              },
              "end": {
                "ticks": 192192,
                "time_base": {
                  "numerator": 1,
                  "denominator": 48000
                }
              }
            }
          },
          "audio_mapping": {
            "type": "placement",
            "start": {
              "numerator": "0",
              "denominator": "1"
            },
            "frames": {
              "numerator": "120",
              "denominator": "1"
            }
          },
          "link": "linked",
          "audio_offset": 0
        }
      }
    },
    "39d1ddee-af11-4088-9c7b-383275c1c4e0": {
      "label": "Copied contents",
      "kind": {
        "type": "sequence",
        "children": [
          "ae5c2f25-2c7b-4164-bee1-98adaff7e920"
        ]
      }
    },
    "3aa355cf-47af-43bb-80a4-fd291886ee4d": {
      "label": "cfr-bframes.mp4",
      "kind": {
        "type": "source",
        "source": {
          "duration": 120,
          "edit_window": {
            "start": {
              "numerator": "0",
              "denominator": "1"
            },
            "end": {
              "numerator": "120",
              "denominator": "1"
            }
          },
          "video": {
            "type": "stream",
            "asset": "b2868a97-5094-4eb8-9ccd-4a5c904983e0",
            "span": {
              "start": {
                "ticks": 0,
                "time_base": {
                  "numerator": 1,
                  "denominator": 30000
                }
              },
              "end": {
                "ticks": 120120,
                "time_base": {
                  "numerator": 1,
                  "denominator": 30000
                }
              }
            }
          },
          "video_mapping": {
            "type": "placement",
            "start": {
              "numerator": "0",
              "denominator": "1"
            },
            "frames": {
              "numerator": "120",
              "denominator": "1"
            },
            "endpoints": "hold_adjacent"
          },
          "audio": {
            "asset": "b2868a97-5094-4eb8-9ccd-4a5c904983e0",
            "span": {
              "start": {
                "ticks": 0,
                "time_base": {
                  "numerator": 1,
                  "denominator": 48000
                }
              },
              "end": {
                "ticks": 192192,
                "time_base": {
                  "numerator": 1,
                  "denominator": 48000
                }
              }
            }
          },
          "audio_mapping": {
            "type": "placement",
            "start": {
              "numerator": "0",
              "denominator": "1"
            },
            "frames": {
              "numerator": "120",
              "denominator": "1"
            }
          },
          "link": "linked",
          "audio_offset": 0
        }
      }
    },
    "44425a05-dc69-45ff-aedd-26c2356c963a": {
      "label": "Sequence",
      "kind": {
        "type": "sequence",
        "children": [
          "39d1ddee-af11-4088-9c7b-383275c1c4e0",
          "2edb85c2-83ff-4e7d-894a-bbc001fa8f88"
        ]
      }
    },
    "ae5c2f25-2c7b-4164-bee1-98adaff7e920": {
      "label": "Copied interval",
      "kind": {
        "type": "retime",
        "child": "3aa355cf-47af-43bb-80a4-fd291886ee4d",
        "duration": 10,
        "mapping": {
          "start": 20,
          "end": 30
        },
        "pitch": "preserve",
        "purpose": "partition"
      }
    }
  },
  "assets": {
    "b2868a97-5094-4eb8-9ccd-4a5c904983e0": {
      "label": "cfr-bframes.mp4",
      "content_hash": "blake3:16614ec12d06396d3c0f0e7b91cc902c6dc30ad89c28d74b805cf64dc60d8aa1",
      "video": {
        "start": {
          "ticks": 0,
          "time_base": {
            "numerator": 1,
            "denominator": 30000
          }
        },
        "end": {
          "ticks": 120120,
          "time_base": {
            "numerator": 1,
            "denominator": 30000
          }
        }
      },
      "audio": {
        "start": {
          "ticks": 0,
          "time_base": {
            "numerator": 1,
            "denominator": 48000
          }
        },
        "end": {
          "ticks": 192192,
          "time_base": {
            "numerator": 1,
            "denominator": 48000
          }
        }
      },
      "still_image": false,
      "frame_count": 120,
      "source_qualification": "c6bc3e81ab69906267164469d11739cf1363eea546436761ddd219069ed496b6"
    }
  },
  "marks": {},
  "overrides": {},
  "audio_bindings": {
    "timings": [
      {
        "id": {
          "allocation": "ad26a1cc-4ede-4f67-a9d0-9635054584e9",
          "ordinal": 0
        },
        "layout": {
          "root": "44425a05-dc69-45ff-aedd-26c2356c963a",
          "rate": {
            "numerator": 30000,
            "denominator": 1001
          },
          "nodes": {
            "2edb85c2-83ff-4e7d-894a-bbc001fa8f88": {
              "duration": 120,
              "edges": {
                "node_start": "automatic",
                "node_end": "automatic",
                "source_placement_start": "automatic",
                "source_placement_end": "automatic",
                "repeat_gap_start": "automatic",
                "repeat_gap_end": "automatic"
              },
              "kind": {
                "type": "source",
                "placement": {
                  "start": {
                    "numerator": "0",
                    "denominator": "1"
                  },
                  "end": {
                    "numerator": "120",
                    "denominator": "1"
                  }
                }
              }
            },
            "44425a05-dc69-45ff-aedd-26c2356c963a": {
              "duration": 120,
              "edges": {
                "node_start": "automatic",
                "node_end": "automatic",
                "source_placement_start": "automatic",
                "source_placement_end": "automatic",
                "repeat_gap_start": "automatic",
                "repeat_gap_end": "automatic"
              },
              "kind": {
                "type": "sequence",
                "children": [
                  "2edb85c2-83ff-4e7d-894a-bbc001fa8f88"
                ]
              }
            }
          },
          "overrides": {}
        }
      },
      {
        "id": {
          "allocation": "ad26a1cc-4ede-4f67-a9d0-9635054584e9",
          "ordinal": 1
        },
        "layout": {
          "root": "8d8a7a6e-b7b8-4ab9-91f4-4dd95c2cafbe",
          "rate": {
            "numerator": 30000,
            "denominator": 1001
          },
          "nodes": {
            "4030aab6-bc63-441a-b300-baac4e446e2e": {
              "duration": 120,
              "edges": {
                "node_start": "automatic",
                "node_end": "automatic",
                "source_placement_start": "automatic",
                "source_placement_end": "automatic",
                "repeat_gap_start": "automatic",
                "repeat_gap_end": "automatic"
              },
              "kind": {
                "type": "source",
                "placement": {
                  "start": {
                    "numerator": "0",
                    "denominator": "1"
                  },
                  "end": {
                    "numerator": "120",
                    "denominator": "1"
                  }
                }
              }
            },
            "8d8a7a6e-b7b8-4ab9-91f4-4dd95c2cafbe": {
              "duration": 120,
              "edges": {
                "node_start": "automatic",
                "node_end": "automatic",
                "source_placement_start": "automatic",
                "source_placement_end": "automatic",
                "repeat_gap_start": "automatic",
                "repeat_gap_end": "automatic"
              },
              "kind": {
                "type": "sequence",
                "children": [
                  "4030aab6-bc63-441a-b300-baac4e446e2e"
                ]
              }
            }
          },
          "overrides": {}
        }
      }
    ],
    "bindings": {
      "2edb85c2-83ff-4e7d-894a-bbc001fa8f88": {
        "lattice": {
          "reference": {
            "timing": {
              "allocation": "ad26a1cc-4ede-4f67-a9d0-9635054584e9",
              "ordinal": 0
            },
            "root": {
              "type": "project_root_round_even"
            },
            "physical": "2edb85c2-83ff-4e7d-894a-bbc001fa8f88"
          },
          "arguments": [],
          "births": []
        },
        "resume": null,
        "reanchors": [
          {
            "placement": {
              "reference": {
                "timing": {
                  "allocation": "ad26a1cc-4ede-4f67-a9d0-9635054584e9",
                  "ordinal": 0
                },
                "root": {
                  "type": "project_root_round_even"
                },
                "physical": "2edb85c2-83ff-4e7d-894a-bbc001fa8f88"
              },
              "arguments": [],
              "births": []
            },
            "window": {
              "start": {
                "numerator": "0",
                "denominator": "1"
              },
              "end": {
                "numerator": "120",
                "denominator": "1"
              }
            }
          }
        ]
      },
      "3aa355cf-47af-43bb-80a4-fd291886ee4d": {
        "lattice": {
          "reference": {
            "timing": {
              "allocation": "ad26a1cc-4ede-4f67-a9d0-9635054584e9",
              "ordinal": 1
            },
            "root": {
              "type": "project_root_round_even"
            },
            "physical": "4030aab6-bc63-441a-b300-baac4e446e2e"
          },
          "arguments": [],
          "births": []
        },
        "resume": null,
        "reanchors": [
          {
            "placement": {
              "reference": {
                "timing": {
                  "allocation": "ad26a1cc-4ede-4f67-a9d0-9635054584e9",
                  "ordinal": 1
                },
                "root": {
                  "type": "project_root_round_even"
                },
                "physical": "4030aab6-bc63-441a-b300-baac4e446e2e"
              },
              "arguments": [],
              "births": []
            },
            "window": {
              "start": {
                "numerator": "20",
                "denominator": "1"
              },
              "end": {
                "numerator": "30",
                "denominator": "1"
              }
            }
          }
        ]
      }
    }
  }
}
');
INSERT INTO "revisions" VALUES('ab2073bb-c82a-43c8-95aa-0dfa8f49275d','ad26a1cc-4ede-4f67-a9d0-9635054584e9','undo','{
  "schema_version": 43,
  "project_id": "e6d1ba97-2db0-4119-9e5d-e4a4bef3e078",
  "revision_id": "ab2073bb-c82a-43c8-95aa-0dfa8f49275d",
  "presentation_basis": {
    "width": 320,
    "height": 180,
    "frame_rate": {
      "numerator": 30000,
      "denominator": 1001
    },
    "color_policy": "sdr_rec709"
  },
  "basis_state": {
    "rate_origin": "primary_source",
    "geometry_origin": "primary_source",
    "primary": {
      "asset": "b2868a97-5094-4eb8-9ccd-4a5c904983e0",
      "qualification": "c6bc3e81ab69906267164469d11739cf1363eea546436761ddd219069ed496b6"
    }
  },
  "root": "44425a05-dc69-45ff-aedd-26c2356c963a",
  "nodes": {
    "2edb85c2-83ff-4e7d-894a-bbc001fa8f88": {
      "label": "cfr-bframes.mp4",
      "kind": {
        "type": "source",
        "source": {
          "duration": 120,
          "edit_window": {
            "start": {
              "numerator": "0",
              "denominator": "1"
            },
            "end": {
              "numerator": "120",
              "denominator": "1"
            }
          },
          "video": {
            "type": "stream",
            "asset": "b2868a97-5094-4eb8-9ccd-4a5c904983e0",
            "span": {
              "start": {
                "ticks": 0,
                "time_base": {
                  "numerator": 1,
                  "denominator": 30000
                }
              },
              "end": {
                "ticks": 120120,
                "time_base": {
                  "numerator": 1,
                  "denominator": 30000
                }
              }
            }
          },
          "video_mapping": {
            "type": "placement",
            "start": {
              "numerator": "0",
              "denominator": "1"
            },
            "frames": {
              "numerator": "120",
              "denominator": "1"
            },
            "endpoints": "hold_adjacent"
          },
          "audio": {
            "asset": "b2868a97-5094-4eb8-9ccd-4a5c904983e0",
            "span": {
              "start": {
                "ticks": 0,
                "time_base": {
                  "numerator": 1,
                  "denominator": 48000
                }
              },
              "end": {
                "ticks": 192192,
                "time_base": {
                  "numerator": 1,
                  "denominator": 48000
                }
              }
            }
          },
          "audio_mapping": {
            "type": "placement",
            "start": {
              "numerator": "0",
              "denominator": "1"
            },
            "frames": {
              "numerator": "120",
              "denominator": "1"
            }
          },
          "link": "linked",
          "audio_offset": 0
        }
      }
    },
    "44425a05-dc69-45ff-aedd-26c2356c963a": {
      "label": "Sequence",
      "kind": {
        "type": "sequence",
        "children": [
          "2edb85c2-83ff-4e7d-894a-bbc001fa8f88"
        ]
      }
    }
  },
  "assets": {
    "b2868a97-5094-4eb8-9ccd-4a5c904983e0": {
      "label": "cfr-bframes.mp4",
      "content_hash": "blake3:16614ec12d06396d3c0f0e7b91cc902c6dc30ad89c28d74b805cf64dc60d8aa1",
      "video": {
        "start": {
          "ticks": 0,
          "time_base": {
            "numerator": 1,
            "denominator": 30000
          }
        },
        "end": {
          "ticks": 120120,
          "time_base": {
            "numerator": 1,
            "denominator": 30000
          }
        }
      },
      "audio": {
        "start": {
          "ticks": 0,
          "time_base": {
            "numerator": 1,
            "denominator": 48000
          }
        },
        "end": {
          "ticks": 192192,
          "time_base": {
            "numerator": 1,
            "denominator": 48000
          }
        }
      },
      "still_image": false,
      "frame_count": 120,
      "source_qualification": "c6bc3e81ab69906267164469d11739cf1363eea546436761ddd219069ed496b6"
    }
  },
  "marks": {},
  "overrides": {}
}
');
INSERT INTO "revisions" VALUES('2ef18e3d-a9e1-43e6-a42a-15920840b224','ab2073bb-c82a-43c8-95aa-0dfa8f49275d','edit','{
  "schema_version": 43,
  "project_id": "e6d1ba97-2db0-4119-9e5d-e4a4bef3e078",
  "revision_id": "2ef18e3d-a9e1-43e6-a42a-15920840b224",
  "presentation_basis": {
    "width": 320,
    "height": 180,
    "frame_rate": {
      "numerator": 30000,
      "denominator": 1001
    },
    "color_policy": "sdr_rec709"
  },
  "basis_state": {
    "rate_origin": "primary_source",
    "geometry_origin": "primary_source",
    "primary": {
      "asset": "b2868a97-5094-4eb8-9ccd-4a5c904983e0",
      "qualification": "c6bc3e81ab69906267164469d11739cf1363eea546436761ddd219069ed496b6"
    }
  },
  "root": "44425a05-dc69-45ff-aedd-26c2356c963a",
  "nodes": {
    "2edb85c2-83ff-4e7d-894a-bbc001fa8f88": {
      "label": "cfr-bframes.mp4",
      "kind": {
        "type": "source",
        "source": {
          "duration": 120,
          "edit_window": {
            "start": {
              "numerator": "0",
              "denominator": "1"
            },
            "end": {
              "numerator": "120",
              "denominator": "1"
            }
          },
          "video": {
            "type": "stream",
            "asset": "b2868a97-5094-4eb8-9ccd-4a5c904983e0",
            "span": {
              "start": {
                "ticks": 0,
                "time_base": {
                  "numerator": 1,
                  "denominator": 30000
                }
              },
              "end": {
                "ticks": 120120,
                "time_base": {
                  "numerator": 1,
                  "denominator": 30000
                }
              }
            }
          },
          "video_mapping": {
            "type": "placement",
            "start": {
              "numerator": "0",
              "denominator": "1"
            },
            "frames": {
              "numerator": "120",
              "denominator": "1"
            },
            "endpoints": "hold_adjacent"
          },
          "audio": {
            "asset": "b2868a97-5094-4eb8-9ccd-4a5c904983e0",
            "span": {
              "start": {
                "ticks": 0,
                "time_base": {
                  "numerator": 1,
                  "denominator": 48000
                }
              },
              "end": {
                "ticks": 192192,
                "time_base": {
                  "numerator": 1,
                  "denominator": 48000
                }
              }
            }
          },
          "audio_mapping": {
            "type": "placement",
            "start": {
              "numerator": "0",
              "denominator": "1"
            },
            "frames": {
              "numerator": "120",
              "denominator": "1"
            }
          },
          "link": "linked",
          "audio_offset": 0
        }
      }
    },
    "44425a05-dc69-45ff-aedd-26c2356c963a": {
      "label": "Sequence",
      "kind": {
        "type": "sequence",
        "children": [
          "d248ce93-60f7-4824-ba52-5da57322438c",
          "2edb85c2-83ff-4e7d-894a-bbc001fa8f88"
        ]
      }
    },
    "d248ce93-60f7-4824-ba52-5da57322438c": {
      "label": "cfr-bframes.mp4 [90..94)",
      "kind": {
        "type": "source",
        "source": {
          "duration": 4,
          "edit_window": {
            "start": {
              "numerator": "0",
              "denominator": "1"
            },
            "end": {
              "numerator": "4",
              "denominator": "1"
            }
          },
          "video": {
            "type": "stream",
            "asset": "b2868a97-5094-4eb8-9ccd-4a5c904983e0",
            "span": {
              "start": {
                "ticks": 0,
                "time_base": {
                  "numerator": 1,
                  "denominator": 30000
                }
              },
              "end": {
                "ticks": 120120,
                "time_base": {
                  "numerator": 1,
                  "denominator": 30000
                }
              }
            }
          },
          "video_mapping": {
            "type": "selected_placement",
            "start": {
              "numerator": "-90",
              "denominator": "1"
            },
            "frames": {
              "numerator": "120",
              "denominator": "1"
            },
            "selection": {
              "start": {
                "numerator": "0",
                "denominator": "1"
              },
              "end": {
                "numerator": "4",
                "denominator": "1"
              }
            },
            "endpoints": "hold_adjacent"
          },
          "audio": {
            "asset": "b2868a97-5094-4eb8-9ccd-4a5c904983e0",
            "span": {
              "start": {
                "ticks": 0,
                "time_base": {
                  "numerator": 1,
                  "denominator": 48000
                }
              },
              "end": {
                "ticks": 192192,
                "time_base": {
                  "numerator": 1,
                  "denominator": 48000
                }
              }
            }
          },
          "audio_mapping": {
            "type": "selected_placement",
            "start": {
              "numerator": "-90",
              "denominator": "1"
            },
            "frames": {
              "numerator": "120",
              "denominator": "1"
            },
            "selection": {
              "start": {
                "numerator": "0",
                "denominator": "1"
              },
              "end": {
                "numerator": "4",
                "denominator": "1"
              }
            }
          },
          "link": "linked",
          "audio_offset": 0
        }
      }
    }
  },
  "assets": {
    "b2868a97-5094-4eb8-9ccd-4a5c904983e0": {
      "label": "cfr-bframes.mp4",
      "content_hash": "blake3:16614ec12d06396d3c0f0e7b91cc902c6dc30ad89c28d74b805cf64dc60d8aa1",
      "video": {
        "start": {
          "ticks": 0,
          "time_base": {
            "numerator": 1,
            "denominator": 30000
          }
        },
        "end": {
          "ticks": 120120,
          "time_base": {
            "numerator": 1,
            "denominator": 30000
          }
        }
      },
      "audio": {
        "start": {
          "ticks": 0,
          "time_base": {
            "numerator": 1,
            "denominator": 48000
          }
        },
        "end": {
          "ticks": 192192,
          "time_base": {
            "numerator": 1,
            "denominator": 48000
          }
        }
      },
      "still_image": false,
      "frame_count": 120,
      "source_qualification": "c6bc3e81ab69906267164469d11739cf1363eea546436761ddd219069ed496b6"
    }
  },
  "marks": {},
  "overrides": {},
  "audio_bindings": {
    "timings": [
      {
        "id": {
          "allocation": "2ef18e3d-a9e1-43e6-a42a-15920840b224",
          "ordinal": 0
        },
        "layout": {
          "root": "44425a05-dc69-45ff-aedd-26c2356c963a",
          "rate": {
            "numerator": 30000,
            "denominator": 1001
          },
          "nodes": {
            "2edb85c2-83ff-4e7d-894a-bbc001fa8f88": {
              "duration": 120,
              "edges": {
                "node_start": "automatic",
                "node_end": "automatic",
                "source_placement_start": "automatic",
                "source_placement_end": "automatic",
                "repeat_gap_start": "automatic",
                "repeat_gap_end": "automatic"
              },
              "kind": {
                "type": "source",
                "placement": {
                  "start": {
                    "numerator": "0",
                    "denominator": "1"
                  },
                  "end": {
                    "numerator": "120",
                    "denominator": "1"
                  }
                }
              }
            },
            "44425a05-dc69-45ff-aedd-26c2356c963a": {
              "duration": 120,
              "edges": {
                "node_start": "automatic",
                "node_end": "automatic",
                "source_placement_start": "automatic",
                "source_placement_end": "automatic",
                "repeat_gap_start": "automatic",
                "repeat_gap_end": "automatic"
              },
              "kind": {
                "type": "sequence",
                "children": [
                  "2edb85c2-83ff-4e7d-894a-bbc001fa8f88"
                ]
              }
            }
          },
          "overrides": {}
        }
      }
    ],
    "bindings": {
      "2edb85c2-83ff-4e7d-894a-bbc001fa8f88": {
        "lattice": {
          "reference": {
            "timing": {
              "allocation": "2ef18e3d-a9e1-43e6-a42a-15920840b224",
              "ordinal": 0
            },
            "root": {
              "type": "project_root_round_even"
            },
            "physical": "2edb85c2-83ff-4e7d-894a-bbc001fa8f88"
          },
          "arguments": [],
          "births": []
        },
        "resume": null,
        "reanchors": [
          {
            "placement": {
              "reference": {
                "timing": {
                  "allocation": "2ef18e3d-a9e1-43e6-a42a-15920840b224",
                  "ordinal": 0
                },
                "root": {
                  "type": "project_root_round_even"
                },
                "physical": "2edb85c2-83ff-4e7d-894a-bbc001fa8f88"
              },
              "arguments": [],
              "births": []
            },
            "window": {
              "start": {
                "numerator": "0",
                "denominator": "1"
              },
              "end": {
                "numerator": "120",
                "denominator": "1"
              }
            }
          }
        ]
      }
    }
  }
}
');
INSERT INTO "revisions" VALUES('1b253125-e462-4cac-af80-f1dcc0a3938c','2ef18e3d-a9e1-43e6-a42a-15920840b224','undo','{
  "schema_version": 43,
  "project_id": "e6d1ba97-2db0-4119-9e5d-e4a4bef3e078",
  "revision_id": "1b253125-e462-4cac-af80-f1dcc0a3938c",
  "presentation_basis": {
    "width": 320,
    "height": 180,
    "frame_rate": {
      "numerator": 30000,
      "denominator": 1001
    },
    "color_policy": "sdr_rec709"
  },
  "basis_state": {
    "rate_origin": "primary_source",
    "geometry_origin": "primary_source",
    "primary": {
      "asset": "b2868a97-5094-4eb8-9ccd-4a5c904983e0",
      "qualification": "c6bc3e81ab69906267164469d11739cf1363eea546436761ddd219069ed496b6"
    }
  },
  "root": "44425a05-dc69-45ff-aedd-26c2356c963a",
  "nodes": {
    "2edb85c2-83ff-4e7d-894a-bbc001fa8f88": {
      "label": "cfr-bframes.mp4",
      "kind": {
        "type": "source",
        "source": {
          "duration": 120,
          "edit_window": {
            "start": {
              "numerator": "0",
              "denominator": "1"
            },
            "end": {
              "numerator": "120",
              "denominator": "1"
            }
          },
          "video": {
            "type": "stream",
            "asset": "b2868a97-5094-4eb8-9ccd-4a5c904983e0",
            "span": {
              "start": {
                "ticks": 0,
                "time_base": {
                  "numerator": 1,
                  "denominator": 30000
                }
              },
              "end": {
                "ticks": 120120,
                "time_base": {
                  "numerator": 1,
                  "denominator": 30000
                }
              }
            }
          },
          "video_mapping": {
            "type": "placement",
            "start": {
              "numerator": "0",
              "denominator": "1"
            },
            "frames": {
              "numerator": "120",
              "denominator": "1"
            },
            "endpoints": "hold_adjacent"
          },
          "audio": {
            "asset": "b2868a97-5094-4eb8-9ccd-4a5c904983e0",
            "span": {
              "start": {
                "ticks": 0,
                "time_base": {
                  "numerator": 1,
                  "denominator": 48000
                }
              },
              "end": {
                "ticks": 192192,
                "time_base": {
                  "numerator": 1,
                  "denominator": 48000
                }
              }
            }
          },
          "audio_mapping": {
            "type": "placement",
            "start": {
              "numerator": "0",
              "denominator": "1"
            },
            "frames": {
              "numerator": "120",
              "denominator": "1"
            }
          },
          "link": "linked",
          "audio_offset": 0
        }
      }
    },
    "44425a05-dc69-45ff-aedd-26c2356c963a": {
      "label": "Sequence",
      "kind": {
        "type": "sequence",
        "children": [
          "2edb85c2-83ff-4e7d-894a-bbc001fa8f88"
        ]
      }
    }
  },
  "assets": {
    "b2868a97-5094-4eb8-9ccd-4a5c904983e0": {
      "label": "cfr-bframes.mp4",
      "content_hash": "blake3:16614ec12d06396d3c0f0e7b91cc902c6dc30ad89c28d74b805cf64dc60d8aa1",
      "video": {
        "start": {
          "ticks": 0,
          "time_base": {
            "numerator": 1,
            "denominator": 30000
          }
        },
        "end": {
          "ticks": 120120,
          "time_base": {
            "numerator": 1,
            "denominator": 30000
          }
        }
      },
      "audio": {
        "start": {
          "ticks": 0,
          "time_base": {
            "numerator": 1,
            "denominator": 48000
          }
        },
        "end": {
          "ticks": 192192,
          "time_base": {
            "numerator": 1,
            "denominator": 48000
          }
        }
      },
      "still_image": false,
      "frame_count": 120,
      "source_qualification": "c6bc3e81ab69906267164469d11739cf1363eea546436761ddd219069ed496b6"
    }
  },
  "marks": {},
  "overrides": {}
}
');
INSERT INTO "revisions" VALUES('ae514e2e-07c3-4748-b856-ba85dae44577','1b253125-e462-4cac-af80-f1dcc0a3938c','edit','{
  "schema_version": 43,
  "project_id": "e6d1ba97-2db0-4119-9e5d-e4a4bef3e078",
  "revision_id": "ae514e2e-07c3-4748-b856-ba85dae44577",
  "presentation_basis": {
    "width": 320,
    "height": 180,
    "frame_rate": {
      "numerator": 30000,
      "denominator": 1001
    },
    "color_policy": "sdr_rec709"
  },
  "basis_state": {
    "rate_origin": "primary_source",
    "geometry_origin": "primary_source",
    "primary": {
      "asset": "b2868a97-5094-4eb8-9ccd-4a5c904983e0",
      "qualification": "c6bc3e81ab69906267164469d11739cf1363eea546436761ddd219069ed496b6"
    }
  },
  "root": "44425a05-dc69-45ff-aedd-26c2356c963a",
  "nodes": {
    "2edb85c2-83ff-4e7d-894a-bbc001fa8f88": {
      "label": "cfr-bframes.mp4",
      "kind": {
        "type": "source",
        "source": {
          "duration": 120,
          "edit_window": {
            "start": {
              "numerator": "0",
              "denominator": "1"
            },
            "end": {
              "numerator": "120",
              "denominator": "1"
            }
          },
          "video": {
            "type": "stream",
            "asset": "b2868a97-5094-4eb8-9ccd-4a5c904983e0",
            "span": {
              "start": {
                "ticks": 0,
                "time_base": {
                  "numerator": 1,
                  "denominator": 30000
                }
              },
              "end": {
                "ticks": 120120,
                "time_base": {
                  "numerator": 1,
                  "denominator": 30000
                }
              }
            }
          },
          "video_mapping": {
            "type": "placement",
            "start": {
              "numerator": "0",
              "denominator": "1"
            },
            "frames": {
              "numerator": "120",
              "denominator": "1"
            },
            "endpoints": "hold_adjacent"
          },
          "audio": {
            "asset": "b2868a97-5094-4eb8-9ccd-4a5c904983e0",
            "span": {
              "start": {
                "ticks": 0,
                "time_base": {
                  "numerator": 1,
                  "denominator": 48000
                }
              },
              "end": {
                "ticks": 192192,
                "time_base": {
                  "numerator": 1,
                  "denominator": 48000
                }
              }
            }
          },
          "audio_mapping": {
            "type": "placement",
            "start": {
              "numerator": "0",
              "denominator": "1"
            },
            "frames": {
              "numerator": "120",
              "denominator": "1"
            }
          },
          "link": "linked",
          "audio_offset": 0
        }
      }
    },
    "44425a05-dc69-45ff-aedd-26c2356c963a": {
      "label": "Sequence",
      "kind": {
        "type": "sequence",
        "children": [
          "ee7d5556-659b-461e-95f6-b93773a5d7e7",
          "2edb85c2-83ff-4e7d-894a-bbc001fa8f88"
        ]
      }
    },
    "ee7d5556-659b-461e-95f6-b93773a5d7e7": {
      "label": "cfr-bframes.mp4 [70..74)",
      "kind": {
        "type": "source",
        "source": {
          "duration": 4,
          "edit_window": {
            "start": {
              "numerator": "0",
              "denominator": "1"
            },
            "end": {
              "numerator": "4",
              "denominator": "1"
            }
          },
          "video": {
            "type": "stream",
            "asset": "b2868a97-5094-4eb8-9ccd-4a5c904983e0",
            "span": {
              "start": {
                "ticks": 0,
                "time_base": {
                  "numerator": 1,
                  "denominator": 30000
                }
              },
              "end": {
                "ticks": 120120,
                "time_base": {
                  "numerator": 1,
                  "denominator": 30000
                }
              }
            }
          },
          "video_mapping": {
            "type": "selected_placement",
            "start": {
              "numerator": "-70",
              "denominator": "1"
            },
            "frames": {
              "numerator": "120",
              "denominator": "1"
            },
            "selection": {
              "start": {
                "numerator": "0",
                "denominator": "1"
              },
              "end": {
                "numerator": "4",
                "denominator": "1"
              }
            },
            "endpoints": "hold_adjacent"
          },
          "audio": {
            "asset": "b2868a97-5094-4eb8-9ccd-4a5c904983e0",
            "span": {
              "start": {
                "ticks": 0,
                "time_base": {
                  "numerator": 1,
                  "denominator": 48000
                }
              },
              "end": {
                "ticks": 192192,
                "time_base": {
                  "numerator": 1,
                  "denominator": 48000
                }
              }
            }
          },
          "audio_mapping": {
            "type": "selected_placement",
            "start": {
              "numerator": "-70",
              "denominator": "1"
            },
            "frames": {
              "numerator": "120",
              "denominator": "1"
            },
            "selection": {
              "start": {
                "numerator": "0",
                "denominator": "1"
              },
              "end": {
                "numerator": "4",
                "denominator": "1"
              }
            }
          },
          "link": "linked",
          "audio_offset": 0
        }
      }
    }
  },
  "assets": {
    "b2868a97-5094-4eb8-9ccd-4a5c904983e0": {
      "label": "cfr-bframes.mp4",
      "content_hash": "blake3:16614ec12d06396d3c0f0e7b91cc902c6dc30ad89c28d74b805cf64dc60d8aa1",
      "video": {
        "start": {
          "ticks": 0,
          "time_base": {
            "numerator": 1,
            "denominator": 30000
          }
        },
        "end": {
          "ticks": 120120,
          "time_base": {
            "numerator": 1,
            "denominator": 30000
          }
        }
      },
      "audio": {
        "start": {
          "ticks": 0,
          "time_base": {
            "numerator": 1,
            "denominator": 48000
          }
        },
        "end": {
          "ticks": 192192,
          "time_base": {
            "numerator": 1,
            "denominator": 48000
          }
        }
      },
      "still_image": false,
      "frame_count": 120,
      "source_qualification": "c6bc3e81ab69906267164469d11739cf1363eea546436761ddd219069ed496b6"
    }
  },
  "marks": {},
  "overrides": {},
  "audio_bindings": {
    "timings": [
      {
        "id": {
          "allocation": "ae514e2e-07c3-4748-b856-ba85dae44577",
          "ordinal": 0
        },
        "layout": {
          "root": "44425a05-dc69-45ff-aedd-26c2356c963a",
          "rate": {
            "numerator": 30000,
            "denominator": 1001
          },
          "nodes": {
            "2edb85c2-83ff-4e7d-894a-bbc001fa8f88": {
              "duration": 120,
              "edges": {
                "node_start": "automatic",
                "node_end": "automatic",
                "source_placement_start": "automatic",
                "source_placement_end": "automatic",
                "repeat_gap_start": "automatic",
                "repeat_gap_end": "automatic"
              },
              "kind": {
                "type": "source",
                "placement": {
                  "start": {
                    "numerator": "0",
                    "denominator": "1"
                  },
                  "end": {
                    "numerator": "120",
                    "denominator": "1"
                  }
                }
              }
            },
            "44425a05-dc69-45ff-aedd-26c2356c963a": {
              "duration": 120,
              "edges": {
                "node_start": "automatic",
                "node_end": "automatic",
                "source_placement_start": "automatic",
                "source_placement_end": "automatic",
                "repeat_gap_start": "automatic",
                "repeat_gap_end": "automatic"
              },
              "kind": {
                "type": "sequence",
                "children": [
                  "2edb85c2-83ff-4e7d-894a-bbc001fa8f88"
                ]
              }
            }
          },
          "overrides": {}
        }
      }
    ],
    "bindings": {
      "2edb85c2-83ff-4e7d-894a-bbc001fa8f88": {
        "lattice": {
          "reference": {
            "timing": {
              "allocation": "ae514e2e-07c3-4748-b856-ba85dae44577",
              "ordinal": 0
            },
            "root": {
              "type": "project_root_round_even"
            },
            "physical": "2edb85c2-83ff-4e7d-894a-bbc001fa8f88"
          },
          "arguments": [],
          "births": []
        },
        "resume": null,
        "reanchors": [
          {
            "placement": {
              "reference": {
                "timing": {
                  "allocation": "ae514e2e-07c3-4748-b856-ba85dae44577",
                  "ordinal": 0
                },
                "root": {
                  "type": "project_root_round_even"
                },
                "physical": "2edb85c2-83ff-4e7d-894a-bbc001fa8f88"
              },
              "arguments": [],
              "births": []
            },
            "window": {
              "start": {
                "numerator": "0",
                "denominator": "1"
              },
              "end": {
                "numerator": "120",
                "denominator": "1"
              }
            }
          }
        ]
      }
    }
  }
}
');
INSERT INTO "revisions" VALUES('3e0ccec9-2254-4c86-9bfa-20db395535fa','ae514e2e-07c3-4748-b856-ba85dae44577','undo','{
  "schema_version": 43,
  "project_id": "e6d1ba97-2db0-4119-9e5d-e4a4bef3e078",
  "revision_id": "3e0ccec9-2254-4c86-9bfa-20db395535fa",
  "presentation_basis": {
    "width": 320,
    "height": 180,
    "frame_rate": {
      "numerator": 30000,
      "denominator": 1001
    },
    "color_policy": "sdr_rec709"
  },
  "basis_state": {
    "rate_origin": "primary_source",
    "geometry_origin": "primary_source",
    "primary": {
      "asset": "b2868a97-5094-4eb8-9ccd-4a5c904983e0",
      "qualification": "c6bc3e81ab69906267164469d11739cf1363eea546436761ddd219069ed496b6"
    }
  },
  "root": "44425a05-dc69-45ff-aedd-26c2356c963a",
  "nodes": {
    "2edb85c2-83ff-4e7d-894a-bbc001fa8f88": {
      "label": "cfr-bframes.mp4",
      "kind": {
        "type": "source",
        "source": {
          "duration": 120,
          "edit_window": {
            "start": {
              "numerator": "0",
              "denominator": "1"
            },
            "end": {
              "numerator": "120",
              "denominator": "1"
            }
          },
          "video": {
            "type": "stream",
            "asset": "b2868a97-5094-4eb8-9ccd-4a5c904983e0",
            "span": {
              "start": {
                "ticks": 0,
                "time_base": {
                  "numerator": 1,
                  "denominator": 30000
                }
              },
              "end": {
                "ticks": 120120,
                "time_base": {
                  "numerator": 1,
                  "denominator": 30000
                }
              }
            }
          },
          "video_mapping": {
            "type": "placement",
            "start": {
              "numerator": "0",
              "denominator": "1"
            },
            "frames": {
              "numerator": "120",
              "denominator": "1"
            },
            "endpoints": "hold_adjacent"
          },
          "audio": {
            "asset": "b2868a97-5094-4eb8-9ccd-4a5c904983e0",
            "span": {
              "start": {
                "ticks": 0,
                "time_base": {
                  "numerator": 1,
                  "denominator": 48000
                }
              },
              "end": {
                "ticks": 192192,
                "time_base": {
                  "numerator": 1,
                  "denominator": 48000
                }
              }
            }
          },
          "audio_mapping": {
            "type": "placement",
            "start": {
              "numerator": "0",
              "denominator": "1"
            },
            "frames": {
              "numerator": "120",
              "denominator": "1"
            }
          },
          "link": "linked",
          "audio_offset": 0
        }
      }
    },
    "44425a05-dc69-45ff-aedd-26c2356c963a": {
      "label": "Sequence",
      "kind": {
        "type": "sequence",
        "children": [
          "2edb85c2-83ff-4e7d-894a-bbc001fa8f88"
        ]
      }
    }
  },
  "assets": {
    "b2868a97-5094-4eb8-9ccd-4a5c904983e0": {
      "label": "cfr-bframes.mp4",
      "content_hash": "blake3:16614ec12d06396d3c0f0e7b91cc902c6dc30ad89c28d74b805cf64dc60d8aa1",
      "video": {
        "start": {
          "ticks": 0,
          "time_base": {
            "numerator": 1,
            "denominator": 30000
          }
        },
        "end": {
          "ticks": 120120,
          "time_base": {
            "numerator": 1,
            "denominator": 30000
          }
        }
      },
      "audio": {
        "start": {
          "ticks": 0,
          "time_base": {
            "numerator": 1,
            "denominator": 48000
          }
        },
        "end": {
          "ticks": 192192,
          "time_base": {
            "numerator": 1,
            "denominator": 48000
          }
        }
      },
      "still_image": false,
      "frame_count": 120,
      "source_qualification": "c6bc3e81ab69906267164469d11739cf1363eea546436761ddd219069ed496b6"
    }
  },
  "marks": {},
  "overrides": {}
}
');
INSERT INTO "revisions" VALUES('c52caa09-1169-4d26-a7e1-4b1184a76833','3e0ccec9-2254-4c86-9bfa-20db395535fa','edit','{
  "schema_version": 43,
  "project_id": "e6d1ba97-2db0-4119-9e5d-e4a4bef3e078",
  "revision_id": "c52caa09-1169-4d26-a7e1-4b1184a76833",
  "presentation_basis": {
    "width": 320,
    "height": 180,
    "frame_rate": {
      "numerator": 30000,
      "denominator": 1001
    },
    "color_policy": "sdr_rec709"
  },
  "basis_state": {
    "rate_origin": "primary_source",
    "geometry_origin": "primary_source",
    "primary": {
      "asset": "b2868a97-5094-4eb8-9ccd-4a5c904983e0",
      "qualification": "c6bc3e81ab69906267164469d11739cf1363eea546436761ddd219069ed496b6"
    }
  },
  "root": "44425a05-dc69-45ff-aedd-26c2356c963a",
  "nodes": {
    "2edb85c2-83ff-4e7d-894a-bbc001fa8f88": {
      "label": "cfr-bframes.mp4",
      "kind": {
        "type": "source",
        "source": {
          "duration": 120,
          "edit_window": {
            "start": {
              "numerator": "0",
              "denominator": "1"
            },
            "end": {
              "numerator": "120",
              "denominator": "1"
            }
          },
          "video": {
            "type": "stream",
            "asset": "b2868a97-5094-4eb8-9ccd-4a5c904983e0",
            "span": {
              "start": {
                "ticks": 0,
                "time_base": {
                  "numerator": 1,
                  "denominator": 30000
                }
              },
              "end": {
                "ticks": 120120,
                "time_base": {
                  "numerator": 1,
                  "denominator": 30000
                }
              }
            }
          },
          "video_mapping": {
            "type": "placement",
            "start": {
              "numerator": "0",
              "denominator": "1"
            },
            "frames": {
              "numerator": "120",
              "denominator": "1"
            },
            "endpoints": "hold_adjacent"
          },
          "audio": {
            "asset": "b2868a97-5094-4eb8-9ccd-4a5c904983e0",
            "span": {
              "start": {
                "ticks": 0,
                "time_base": {
                  "numerator": 1,
                  "denominator": 48000
                }
              },
              "end": {
                "ticks": 192192,
                "time_base": {
                  "numerator": 1,
                  "denominator": 48000
                }
              }
            }
          },
          "audio_mapping": {
            "type": "placement",
            "start": {
              "numerator": "0",
              "denominator": "1"
            },
            "frames": {
              "numerator": "120",
              "denominator": "1"
            }
          },
          "link": "linked",
          "audio_offset": 0
        }
      }
    },
    "31704863-ffbc-4c7b-9a5f-0899b1627738": {
      "label": "Pause",
      "kind": {
        "type": "hold",
        "recipe": {
          "picture_context": {
            "canvases": [
              {
                "width": 320,
                "height": 180,
                "fit": "fit",
                "layers": []
              }
            ]
          },
          "duration": 11,
          "video": {
            "type": "freeze",
            "asset": "b2868a97-5094-4eb8-9ccd-4a5c904983e0",
            "timestamp": {
              "ticks": 9009,
              "time_base": {
                "numerator": 1,
                "denominator": 30000
              }
            }
          },
          "audio": {
            "type": "silence"
          }
        }
      }
    },
    "44425a05-dc69-45ff-aedd-26c2356c963a": {
      "label": "Sequence",
      "kind": {
        "type": "sequence",
        "children": [
          "bda72595-0561-4467-a29d-4e7684909bdf",
          "2edb85c2-83ff-4e7d-894a-bbc001fa8f88"
        ]
      }
    },
    "642dc857-a76e-449e-a5ca-af72ce102ccf": {
      "label": "Copied interval",
      "kind": {
        "type": "retime",
        "child": "f8193895-1d1b-4397-a441-c7f0db498540",
        "duration": 4,
        "mapping": {
          "start": 0,
          "end": 4
        },
        "pitch": "preserve",
        "purpose": "partition"
      }
    },
    "b1d7fa9c-dce6-42ad-a964-c35cf58ac892": {
      "label": "cfr-bframes.mp4",
      "kind": {
        "type": "source",
        "source": {
          "duration": 120,
          "edit_window": {
            "start": {
              "numerator": "0",
              "denominator": "1"
            },
            "end": {
              "numerator": "120",
              "denominator": "1"
            }
          },
          "video": {
            "type": "stream",
            "asset": "b2868a97-5094-4eb8-9ccd-4a5c904983e0",
            "span": {
              "start": {
                "ticks": 0,
                "time_base": {
                  "numerator": 1,
                  "denominator": 30000
                }
              },
              "end": {
                "ticks": 120120,
                "time_base": {
                  "numerator": 1,
                  "denominator": 30000
                }
              }
            }
          },
          "video_mapping": {
            "type": "placement",
            "start": {
              "numerator": "0",
              "denominator": "1"
            },
            "frames": {
              "numerator": "120",
              "denominator": "1"
            },
            "endpoints": "hold_adjacent"
          },
          "audio": {
            "asset": "b2868a97-5094-4eb8-9ccd-4a5c904983e0",
            "span": {
              "start": {
                "ticks": 0,
                "time_base": {
                  "numerator": 1,
                  "denominator": 48000
                }
              },
              "end": {
                "ticks": 192192,
                "time_base": {
                  "numerator": 1,
                  "denominator": 48000
                }
              }
            }
          },
          "audio_mapping": {
            "type": "placement",
            "start": {
              "numerator": "0",
              "denominator": "1"
            },
            "frames": {
              "numerator": "120",
              "denominator": "1"
            }
          },
          "link": "linked",
          "audio_offset": 0
        }
      }
    },
    "bb001118-8614-4a89-a971-0be003f8e061": {
      "label": "cfr-bframes.mp4",
      "kind": {
        "type": "retime",
        "child": "d6d89b66-6a83-4eb0-887d-aa96431b3a25",
        "duration": 10,
        "mapping": {
          "start": 0,
          "end": 10
        },
        "pitch": "preserve",
        "purpose": "partition"
      }
    },
    "bda72595-0561-4467-a29d-4e7684909bdf": {
      "label": "Copied contents",
      "kind": {
        "type": "sequence",
        "children": [
          "e81420db-1058-45dc-88f1-8a07b43421b1",
          "31704863-ffbc-4c7b-9a5f-0899b1627738",
          "642dc857-a76e-449e-a5ca-af72ce102ccf"
        ]
      }
    },
    "d6d89b66-6a83-4eb0-887d-aa96431b3a25": {
      "label": "cfr-bframes.mp4",
      "kind": {
        "type": "source",
        "source": {
          "duration": 120,
          "edit_window": {
            "start": {
              "numerator": "0",
              "denominator": "1"
            },
            "end": {
              "numerator": "120",
              "denominator": "1"
            }
          },
          "video": {
            "type": "stream",
            "asset": "b2868a97-5094-4eb8-9ccd-4a5c904983e0",
            "span": {
              "start": {
                "ticks": 0,
                "time_base": {
                  "numerator": 1,
                  "denominator": 30000
                }
              },
              "end": {
                "ticks": 120120,
                "time_base": {
                  "numerator": 1,
                  "denominator": 30000
                }
              }
            }
          },
          "video_mapping": {
            "type": "placement",
            "start": {
              "numerator": "0",
              "denominator": "1"
            },
            "frames": {
              "numerator": "120",
              "denominator": "1"
            },
            "endpoints": "hold_adjacent"
          },
          "audio": {
            "asset": "b2868a97-5094-4eb8-9ccd-4a5c904983e0",
            "span": {
              "start": {
                "ticks": 0,
                "time_base": {
                  "numerator": 1,
                  "denominator": 48000
                }
              },
              "end": {
                "ticks": 192192,
                "time_base": {
                  "numerator": 1,
                  "denominator": 48000
                }
              }
            }
          },
          "audio_mapping": {
            "type": "placement",
            "start": {
              "numerator": "0",
              "denominator": "1"
            },
            "frames": {
              "numerator": "120",
              "denominator": "1"
            }
          },
          "link": "linked",
          "audio_offset": 0
        }
      }
    },
    "e81420db-1058-45dc-88f1-8a07b43421b1": {
      "label": "Copied interval",
      "kind": {
        "type": "retime",
        "child": "bb001118-8614-4a89-a971-0be003f8e061",
        "duration": 2,
        "mapping": {
          "start": 8,
          "end": 10
        },
        "pitch": "preserve",
        "purpose": "partition"
      }
    },
    "f8193895-1d1b-4397-a441-c7f0db498540": {
      "label": "cfr-bframes.mp4",
      "kind": {
        "type": "retime",
        "child": "b1d7fa9c-dce6-42ad-a964-c35cf58ac892",
        "duration": 110,
        "mapping": {
          "start": 10,
          "end": 120
        },
        "pitch": "preserve",
        "purpose": "partition"
      }
    }
  },
  "assets": {
    "b2868a97-5094-4eb8-9ccd-4a5c904983e0": {
      "label": "cfr-bframes.mp4",
      "content_hash": "blake3:16614ec12d06396d3c0f0e7b91cc902c6dc30ad89c28d74b805cf64dc60d8aa1",
      "video": {
        "start": {
          "ticks": 0,
          "time_base": {
            "numerator": 1,
            "denominator": 30000
          }
        },
        "end": {
          "ticks": 120120,
          "time_base": {
            "numerator": 1,
            "denominator": 30000
          }
        }
      },
      "audio": {
        "start": {
          "ticks": 0,
          "time_base": {
            "numerator": 1,
            "denominator": 48000
          }
        },
        "end": {
          "ticks": 192192,
          "time_base": {
            "numerator": 1,
            "denominator": 48000
          }
        }
      },
      "still_image": false,
      "frame_count": 120,
      "source_qualification": "c6bc3e81ab69906267164469d11739cf1363eea546436761ddd219069ed496b6"
    }
  },
  "marks": {},
  "overrides": {},
  "audio_lineage": {
    "b1d7fa9c-dce6-42ad-a964-c35cf58ac892": {
      "allocation": "c52caa09-1169-4d26-a7e1-4b1184a76833",
      "origin": "de846a30-5306-4090-8df3-3740176bc808"
    },
    "d6d89b66-6a83-4eb0-887d-aa96431b3a25": {
      "allocation": "c52caa09-1169-4d26-a7e1-4b1184a76833",
      "origin": "de846a30-5306-4090-8df3-3740176bc808"
    }
  },
  "audio_bindings": {
    "timings": [
      {
        "id": {
          "allocation": "c52caa09-1169-4d26-a7e1-4b1184a76833",
          "ordinal": 0
        },
        "layout": {
          "root": "44425a05-dc69-45ff-aedd-26c2356c963a",
          "rate": {
            "numerator": 30000,
            "denominator": 1001
          },
          "nodes": {
            "2edb85c2-83ff-4e7d-894a-bbc001fa8f88": {
              "duration": 120,
              "edges": {
                "node_start": "automatic",
                "node_end": "automatic",
                "source_placement_start": "automatic",
                "source_placement_end": "automatic",
                "repeat_gap_start": "automatic",
                "repeat_gap_end": "automatic"
              },
              "kind": {
                "type": "source",
                "placement": {
                  "start": {
                    "numerator": "0",
                    "denominator": "1"
                  },
                  "end": {
                    "numerator": "120",
                    "denominator": "1"
                  }
                }
              }
            },
            "44425a05-dc69-45ff-aedd-26c2356c963a": {
              "duration": 120,
              "edges": {
                "node_start": "automatic",
                "node_end": "automatic",
                "source_placement_start": "automatic",
                "source_placement_end": "automatic",
                "repeat_gap_start": "automatic",
                "repeat_gap_end": "automatic"
              },
              "kind": {
                "type": "sequence",
                "children": [
                  "2edb85c2-83ff-4e7d-894a-bbc001fa8f88"
                ]
              }
            }
          },
          "overrides": {}
        }
      },
      {
        "id": {
          "allocation": "c52caa09-1169-4d26-a7e1-4b1184a76833",
          "ordinal": 1
        },
        "layout": {
          "root": "d77e5c47-0d28-4ed0-8518-5fd7c6c28e69",
          "rate": {
            "numerator": 30000,
            "denominator": 1001
          },
          "nodes": {
            "1e811fcd-77a3-428c-b95d-1beb2614b135": {
              "duration": 120,
              "edges": {
                "node_start": "automatic",
                "node_end": "automatic",
                "source_placement_start": "automatic",
                "source_placement_end": "automatic",
                "repeat_gap_start": "automatic",
                "repeat_gap_end": "automatic"
              },
              "kind": {
                "type": "source",
                "placement": {
                  "start": {
                    "numerator": "0",
                    "denominator": "1"
                  },
                  "end": {
                    "numerator": "120",
                    "denominator": "1"
                  }
                }
              }
            },
            "36e72813-0b9f-4a8d-b475-f577588b48f4": {
              "duration": 110,
              "edges": {
                "node_start": "automatic",
                "node_end": "automatic",
                "source_placement_start": "automatic",
                "source_placement_end": "automatic",
                "repeat_gap_start": "automatic",
                "repeat_gap_end": "automatic"
              },
              "kind": {
                "type": "retime",
                "child": "48f70037-69d6-430e-ac05-f1261afb9bd3",
                "mapping": {
                  "start": 10,
                  "end": 120
                },
                "pitch": "preserve",
                "purpose": "partition"
              }
            },
            "48f70037-69d6-430e-ac05-f1261afb9bd3": {
              "duration": 120,
              "edges": {
                "node_start": "automatic",
                "node_end": "automatic",
                "source_placement_start": "automatic",
                "source_placement_end": "automatic",
                "repeat_gap_start": "automatic",
                "repeat_gap_end": "automatic"
              },
              "kind": {
                "type": "source",
                "placement": {
                  "start": {
                    "numerator": "0",
                    "denominator": "1"
                  },
                  "end": {
                    "numerator": "120",
                    "denominator": "1"
                  }
                }
              }
            },
            "9bcb11cc-cdd9-4f02-8bb3-3a329db633d5": {
              "duration": 10,
              "edges": {
                "node_start": "automatic",
                "node_end": "automatic",
                "source_placement_start": "automatic",
                "source_placement_end": "automatic",
                "repeat_gap_start": "automatic",
                "repeat_gap_end": "automatic"
              },
              "kind": {
                "type": "retime",
                "child": "1e811fcd-77a3-428c-b95d-1beb2614b135",
                "mapping": {
                  "start": 0,
                  "end": 10
                },
                "pitch": "preserve",
                "purpose": "partition"
              }
            },
            "9ea46bdd-a0fe-4d29-a0d6-1afab61d0a9c": {
              "duration": 11,
              "edges": {
                "node_start": "automatic",
                "node_end": "automatic",
                "source_placement_start": "automatic",
                "source_placement_end": "automatic",
                "repeat_gap_start": "automatic",
                "repeat_gap_end": "automatic"
              },
              "kind": {
                "type": "hold",
                "audio": {
                  "type": "silence"
                }
              }
            },
            "d77e5c47-0d28-4ed0-8518-5fd7c6c28e69": {
              "duration": 131,
              "edges": {
                "node_start": "automatic",
                "node_end": "automatic",
                "source_placement_start": "automatic",
                "source_placement_end": "automatic",
                "repeat_gap_start": "automatic",
                "repeat_gap_end": "automatic"
              },
              "kind": {
                "type": "sequence",
                "children": [
                  "9bcb11cc-cdd9-4f02-8bb3-3a329db633d5",
                  "9ea46bdd-a0fe-4d29-a0d6-1afab61d0a9c",
                  "36e72813-0b9f-4a8d-b475-f577588b48f4"
                ]
              }
            }
          },
          "overrides": {},
          "audio_lineage": {
            "1e811fcd-77a3-428c-b95d-1beb2614b135": {
              "allocation": "c52caa09-1169-4d26-a7e1-4b1184a76833",
              "origin": "de846a30-5306-4090-8df3-3740176bc808"
            },
            "48f70037-69d6-430e-ac05-f1261afb9bd3": {
              "allocation": "c52caa09-1169-4d26-a7e1-4b1184a76833",
              "origin": "de846a30-5306-4090-8df3-3740176bc808"
            }
          }
        }
      },
      {
        "id": {
          "allocation": "c52caa09-1169-4d26-a7e1-4b1184a76833",
          "ordinal": 2
        },
        "layout": {
          "root": "7d19c497-b987-4b24-817b-719dfe43b165",
          "rate": {
            "numerator": 30000,
            "denominator": 1001
          },
          "nodes": {
            "7d19c497-b987-4b24-817b-719dfe43b165": {
              "duration": 120,
              "edges": {
                "node_start": "automatic",
                "node_end": "automatic",
                "source_placement_start": "automatic",
                "source_placement_end": "automatic",
                "repeat_gap_start": "automatic",
                "repeat_gap_end": "automatic"
              },
              "kind": {
                "type": "sequence",
                "children": [
                  "cf2a92a0-f48f-452a-b93e-e24f7587c5cd"
                ]
              }
            },
            "cf2a92a0-f48f-452a-b93e-e24f7587c5cd": {
              "duration": 120,
              "edges": {
                "node_start": "automatic",
                "node_end": "automatic",
                "source_placement_start": "automatic",
                "source_placement_end": "automatic",
                "repeat_gap_start": "automatic",
                "repeat_gap_end": "automatic"
              },
              "kind": {
                "type": "source",
                "placement": {
                  "start": {
                    "numerator": "0",
                    "denominator": "1"
                  },
                  "end": {
                    "numerator": "120",
                    "denominator": "1"
                  }
                }
              }
            }
          },
          "overrides": {}
        }
      }
    ],
    "bindings": {
      "2edb85c2-83ff-4e7d-894a-bbc001fa8f88": {
        "lattice": {
          "reference": {
            "timing": {
              "allocation": "c52caa09-1169-4d26-a7e1-4b1184a76833",
              "ordinal": 0
            },
            "root": {
              "type": "project_root_round_even"
            },
            "physical": "2edb85c2-83ff-4e7d-894a-bbc001fa8f88"
          },
          "arguments": [],
          "births": []
        },
        "resume": null,
        "reanchors": [
          {
            "placement": {
              "reference": {
                "timing": {
                  "allocation": "c52caa09-1169-4d26-a7e1-4b1184a76833",
                  "ordinal": 0
                },
                "root": {
                  "type": "project_root_round_even"
                },
                "physical": "2edb85c2-83ff-4e7d-894a-bbc001fa8f88"
              },
              "arguments": [],
              "births": []
            },
            "window": {
              "start": {
                "numerator": "0",
                "denominator": "1"
              },
              "end": {
                "numerator": "120",
                "denominator": "1"
              }
            }
          }
        ]
      },
      "31704863-ffbc-4c7b-9a5f-0899b1627738": {
        "lattice": {
          "reference": {
            "timing": {
              "allocation": "c52caa09-1169-4d26-a7e1-4b1184a76833",
              "ordinal": 1
            },
            "root": {
              "type": "project_root_round_even"
            },
            "physical": "9ea46bdd-a0fe-4d29-a0d6-1afab61d0a9c"
          },
          "arguments": [],
          "births": []
        },
        "resume": null,
        "reanchors": [
          {
            "placement": {
              "reference": {
                "timing": {
                  "allocation": "c52caa09-1169-4d26-a7e1-4b1184a76833",
                  "ordinal": 1
                },
                "root": {
                  "type": "project_root_round_even"
                },
                "physical": "9ea46bdd-a0fe-4d29-a0d6-1afab61d0a9c"
              },
              "arguments": [],
              "births": []
            },
            "window": {
              "start": {
                "numerator": "8",
                "denominator": "1"
              },
              "end": {
                "numerator": "25",
                "denominator": "1"
              }
            }
          }
        ]
      },
      "b1d7fa9c-dce6-42ad-a964-c35cf58ac892": {
        "lattice": {
          "reference": {
            "timing": {
              "allocation": "c52caa09-1169-4d26-a7e1-4b1184a76833",
              "ordinal": 2
            },
            "root": {
              "type": "project_root_round_even"
            },
            "physical": "cf2a92a0-f48f-452a-b93e-e24f7587c5cd"
          },
          "arguments": [],
          "births": []
        },
        "resume": {
          "local_boundary": {
            "numerator": "10",
            "denominator": "1"
          },
          "phase": {
            "constant": {
              "numerator": "0",
              "denominator": "1"
            },
            "terms": [
              {
                "placement": {
                  "reference": {
                    "timing": {
                      "allocation": "c52caa09-1169-4d26-a7e1-4b1184a76833",
                      "ordinal": 2
                    },
                    "root": {
                      "type": "project_root_round_even"
                    },
                    "physical": "cf2a92a0-f48f-452a-b93e-e24f7587c5cd"
                  },
                  "arguments": [],
                  "births": []
                },
                "from_local": {
                  "numerator": "0",
                  "denominator": "1"
                },
                "to_local": {
                  "numerator": "10",
                  "denominator": "1"
                }
              }
            ]
          }
        },
        "reanchors": [
          {
            "placement": {
              "reference": {
                "timing": {
                  "allocation": "c52caa09-1169-4d26-a7e1-4b1184a76833",
                  "ordinal": 1
                },
                "root": {
                  "type": "project_root_round_even"
                },
                "physical": "48f70037-69d6-430e-ac05-f1261afb9bd3"
              },
              "arguments": [],
              "births": []
            },
            "window": {
              "start": {
                "numerator": "8",
                "denominator": "1"
              },
              "end": {
                "numerator": "25",
                "denominator": "1"
              }
            }
          }
        ]
      },
      "d6d89b66-6a83-4eb0-887d-aa96431b3a25": {
        "lattice": {
          "reference": {
            "timing": {
              "allocation": "c52caa09-1169-4d26-a7e1-4b1184a76833",
              "ordinal": 2
            },
            "root": {
              "type": "project_root_round_even"
            },
            "physical": "cf2a92a0-f48f-452a-b93e-e24f7587c5cd"
          },
          "arguments": [],
          "births": []
        },
        "resume": null,
        "reanchors": [
          {
            "placement": {
              "reference": {
                "timing": {
                  "allocation": "c52caa09-1169-4d26-a7e1-4b1184a76833",
                  "ordinal": 1
                },
                "root": {
                  "type": "project_root_round_even"
                },
                "physical": "1e811fcd-77a3-428c-b95d-1beb2614b135"
              },
              "arguments": [],
              "births": []
            },
            "window": {
              "start": {
                "numerator": "8",
                "denominator": "1"
              },
              "end": {
                "numerator": "25",
                "denominator": "1"
              }
            }
          }
        ]
      }
    }
  }
}
');
INSERT INTO "revisions" VALUES('bbd2c663-50ce-4c79-aaad-7ee112879b9f','c52caa09-1169-4d26-a7e1-4b1184a76833','undo','{
  "schema_version": 43,
  "project_id": "e6d1ba97-2db0-4119-9e5d-e4a4bef3e078",
  "revision_id": "bbd2c663-50ce-4c79-aaad-7ee112879b9f",
  "presentation_basis": {
    "width": 320,
    "height": 180,
    "frame_rate": {
      "numerator": 30000,
      "denominator": 1001
    },
    "color_policy": "sdr_rec709"
  },
  "basis_state": {
    "rate_origin": "primary_source",
    "geometry_origin": "primary_source",
    "primary": {
      "asset": "b2868a97-5094-4eb8-9ccd-4a5c904983e0",
      "qualification": "c6bc3e81ab69906267164469d11739cf1363eea546436761ddd219069ed496b6"
    }
  },
  "root": "44425a05-dc69-45ff-aedd-26c2356c963a",
  "nodes": {
    "2edb85c2-83ff-4e7d-894a-bbc001fa8f88": {
      "label": "cfr-bframes.mp4",
      "kind": {
        "type": "source",
        "source": {
          "duration": 120,
          "edit_window": {
            "start": {
              "numerator": "0",
              "denominator": "1"
            },
            "end": {
              "numerator": "120",
              "denominator": "1"
            }
          },
          "video": {
            "type": "stream",
            "asset": "b2868a97-5094-4eb8-9ccd-4a5c904983e0",
            "span": {
              "start": {
                "ticks": 0,
                "time_base": {
                  "numerator": 1,
                  "denominator": 30000
                }
              },
              "end": {
                "ticks": 120120,
                "time_base": {
                  "numerator": 1,
                  "denominator": 30000
                }
              }
            }
          },
          "video_mapping": {
            "type": "placement",
            "start": {
              "numerator": "0",
              "denominator": "1"
            },
            "frames": {
              "numerator": "120",
              "denominator": "1"
            },
            "endpoints": "hold_adjacent"
          },
          "audio": {
            "asset": "b2868a97-5094-4eb8-9ccd-4a5c904983e0",
            "span": {
              "start": {
                "ticks": 0,
                "time_base": {
                  "numerator": 1,
                  "denominator": 48000
                }
              },
              "end": {
                "ticks": 192192,
                "time_base": {
                  "numerator": 1,
                  "denominator": 48000
                }
              }
            }
          },
          "audio_mapping": {
            "type": "placement",
            "start": {
              "numerator": "0",
              "denominator": "1"
            },
            "frames": {
              "numerator": "120",
              "denominator": "1"
            }
          },
          "link": "linked",
          "audio_offset": 0
        }
      }
    },
    "44425a05-dc69-45ff-aedd-26c2356c963a": {
      "label": "Sequence",
      "kind": {
        "type": "sequence",
        "children": [
          "2edb85c2-83ff-4e7d-894a-bbc001fa8f88"
        ]
      }
    }
  },
  "assets": {
    "b2868a97-5094-4eb8-9ccd-4a5c904983e0": {
      "label": "cfr-bframes.mp4",
      "content_hash": "blake3:16614ec12d06396d3c0f0e7b91cc902c6dc30ad89c28d74b805cf64dc60d8aa1",
      "video": {
        "start": {
          "ticks": 0,
          "time_base": {
            "numerator": 1,
            "denominator": 30000
          }
        },
        "end": {
          "ticks": 120120,
          "time_base": {
            "numerator": 1,
            "denominator": 30000
          }
        }
      },
      "audio": {
        "start": {
          "ticks": 0,
          "time_base": {
            "numerator": 1,
            "denominator": 48000
          }
        },
        "end": {
          "ticks": 192192,
          "time_base": {
            "numerator": 1,
            "denominator": 48000
          }
        }
      },
      "still_image": false,
      "frame_count": 120,
      "source_qualification": "c6bc3e81ab69906267164469d11739cf1363eea546436761ddd219069ed496b6"
    }
  },
  "marks": {},
  "overrides": {}
}
');
CREATE TABLE single_source (
            singleton INTEGER PRIMARY KEY CHECK(singleton=1),
            profile TEXT NOT NULL CHECK(json_valid(profile)),
            baseline_history INTEGER REFERENCES history(id)
        ) STRICT;
INSERT INTO "single_source" VALUES(1,'{"state":"ready","initial_revision":"d9750054-772e-482e-9b29-ebf2da2cb0e2","asset":"b2868a97-5094-4eb8-9ccd-4a5c904983e0","qualification":"c6bc3e81ab69906267164469d11739cf1363eea546436761ddd219069ed496b6","node":"2edb85c2-83ff-4e7d-894a-bbc001fa8f88","baseline_revision":"540b434e-34b2-4b43-ae68-1084ee80e450"}',1);
CREATE TABLE source_qualifications (
            id TEXT PRIMARY KEY,
            original_content_id TEXT NOT NULL REFERENCES original_media(content_id),
            original_ref TEXT NOT NULL CHECK(json_valid(original_ref)),
            snapshot BLOB NOT NULL
        ) STRICT;
INSERT INTO "source_qualifications" VALUES('c6bc3e81ab69906267164469d11739cf1363eea546436761ddd219069ed496b6','blake3:16614ec12d06396d3c0f0e7b91cc902c6dc30ad89c28d74b805cf64dc60d8aa1','{"content":{"algorithm":"blake3","digest":"16614ec12d06396d3c0f0e7b91cc902c6dc30ad89c28d74b805cf64dc60d8aa1"},"byte_length":39157}',X'7B22736368656D615F76657273696F6E223A312C226465636F6465725F636F6E7472616374223A2266666D7065672D382E302E332F736F757263652D6465636F6465642D7631222C2274696D696E675F706F6C6963795F76657273696F6E223A312C22636F6E74656E74223A7B22736861323536223A5B39302C3133302C31302C3132312C3139312C38352C31332C37322C37372C3134322C3230332C35352C3235352C3232312C3230382C37322C3230382C39392C3130332C3134382C3233352C3230362C39332C3138342C36322C37392C39322C3232392C3234352C3233302C37332C32345D2C22627974655F6C656E677468223A33393135377D2C226F726967696E5F7365636F6E6473223A7B226E756D657261746F72223A2230222C2264656E6F6D696E61746F72223A2231227D2C22766964656F223A7B22696E646578223A7B22736368656D615F76657273696F6E223A312C22636F6E74656E74223A7B22736861323536223A5B39302C3133302C31302C3132312C3139312C38352C31332C37322C37372C3134322C3230332C35352C3235352C3232312C3230382C37322C3230382C39392C3130332C3134382C3233352C3230362C39332C3138342C36322C37392C39322C3232392C3234352C3233302C37332C32345D2C22627974655F6C656E677468223A33393135377D2C2273747265616D5F696E646578223A302C22696E646578223A7B226173736574223A227175616C69666965642D736F75726365222C2274696D655F62617365223A7B226E756D657261746F72223A312C2264656E6F6D696E61746F72223A33303030307D2C226672616D6573223A5B7B226964656E74697479223A302C22707473223A302C227265706F727465645F6475726174696F6E223A313030312C226B65796672616D65223A747275652C227365656B5F66726F6D223A302C226465636F64655F74696D657374616D70223A307D2C7B226964656E74697479223A312C22707473223A313030312C227265706F727465645F6475726174696F6E223A313030312C226B65796672616D65223A66616C73652C227365656B5F66726F6D223A302C226465636F64655F74696D657374616D70223A313030317D2C7B226964656E74697479223A322C22707473223A323030322C227265706F727465645F6475726174696F6E223A313030312C226B65796672616D65223A66616C73652C227365656B5F66726F6D223A302C226465636F64655F74696D657374616D70223A323030327D2C7B226964656E74697479223A332C22707473223A333030332C227265706F727465645F6475726174696F6E223A313030312C226B65796672616D65223A66616C73652C227365656B5F66726F6D223A302C226465636F64655F74696D657374616D70223A333030337D2C7B226964656E74697479223A342C22707473223A343030342C227265706F727465645F6475726174696F6E223A313030312C226B65796672616D65223A66616C73652C227365656B5F66726F6D223A302C226465636F64655F74696D657374616D70223A343030347D2C7B226964656E74697479223A352C22707473223A353030352C227265706F727465645F6475726174696F6E223A313030312C226B65796672616D65223A66616C73652C227365656B5F66726F6D223A302C226465636F64655F74696D657374616D70223A353030357D2C7B226964656E74697479223A362C22707473223A363030362C227265706F727465645F6475726174696F6E223A313030312C226B65796672616D65223A66616C73652C227365656B5F66726F6D223A302C226465636F64655F74696D657374616D70223A363030367D2C7B226964656E74697479223A372C22707473223A373030372C227265706F727465645F6475726174696F6E223A313030312C226B65796672616D65223A66616C73652C227365656B5F66726F6D223A302C226465636F64655F74696D657374616D70223A373030377D2C7B226964656E74697479223A382C22707473223A383030382C227265706F727465645F6475726174696F6E223A313030312C226B65796672616D65223A66616C73652C227365656B5F66726F6D223A302C226465636F64655F74696D657374616D70223A383030387D2C7B226964656E74697479223A392C22707473223A393030392C227265706F727465645F6475726174696F6E223A313030312C226B65796672616D65223A66616C73652C227365656B5F66726F6D223A302C226465636F64655F74696D657374616D70223A393030397D2C7B226964656E74697479223A31302C22707473223A31303031302C227265706F727465645F6475726174696F6E223A313030312C226B65796672616D65223A66616C73652C227365656B5F66726F6D223A302C226465636F64655F74696D657374616D70223A31303031307D2C7B226964656E74697479223A31312C22707473223A31313031312C227265706F727465645F6475726174696F6E223A313030312C226B65796672616D65223A66616C73652C227365656B5F66726F6D223A302C226465636F64655F74696D657374616D70223A31313031317D2C7B226964656E74697479223A31322C22707473223A31323031322C227265706F727465645F6475726174696F6E223A313030312C226B65796672616D65223A66616C73652C227365656B5F66726F6D223A302C226465636F64655F74696D657374616D70223A31323031327D2C7B226964656E74697479223A31332C22707473223A31333031332C227265706F727465645F6475726174696F6E223A313030312C226B65796672616D65223A66616C73652C227365656B5F66726F6D223A302C226465636F64655F74696D657374616D70223A31333031337D2C7B226964656E74697479223A31342C22707473223A31343031342C227265706F727465645F6475726174696F6E223A313030312C226B65796672616D65223A66616C73652C227365656B5F66726F6D223A302C226465636F64655F74696D657374616D70223A31343031347D2C7B226964656E74697479223A31352C22707473223A31353031352C227265706F727465645F6475726174696F6E223A313030312C226B65796672616D65223A747275652C227365656B5F66726F6D223A31352C226465636F64655F74696D657374616D70223A31353031357D2C7B226964656E74697479223A31362C22707473223A31363031362C227265706F727465645F6475726174696F6E223A313030312C226B65796672616D65223A66616C73652C227365656B5F66726F6D223A31352C226465636F64655F74696D657374616D70223A31363031367D2C7B226964656E74697479223A31372C22707473223A31373031372C227265706F727465645F6475726174696F6E223A313030312C226B65796672616D65223A66616C73652C227365656B5F66726F6D223A31352C226465636F64655F74696D657374616D70223A31373031377D2C7B226964656E74697479223A31382C22707473223A31383031382C227265706F727465645F6475726174696F6E223A313030312C226B65796672616D65223A66616C73652C227365656B5F66726F6D223A31352C226465636F64655F74696D657374616D70223A31383031387D2C7B226964656E74697479223A31392C22707473223A31393031392C227265706F727465645F6475726174696F6E223A313030312C226B65796672616D65223A66616C73652C227365656B5F66726F6D223A31352C226465636F64655F74696D657374616D70223A31393031397D2C7B226964656E74697479223A32302C22707473223A32303032302C227265706F727465645F6475726174696F6E223A313030312C226B65796672616D65223A66616C73652C227365656B5F66726F6D223A31352C226465636F64655F74696D657374616D70223A32303032307D2C7B226964656E74697479223A32312C22707473223A32313032312C227265706F727465645F6475726174696F6E223A313030312C226B65796672616D65223A66616C73652C227365656B5F66726F6D223A31352C226465636F64655F74696D657374616D70223A32313032317D2C7B226964656E74697479223A32322C22707473223A32323032322C227265706F727465645F6475726174696F6E223A313030312C226B65796672616D65223A66616C73652C227365656B5F66726F6D223A31352C226465636F64655F74696D657374616D70223A32323032327D2C7B226964656E74697479223A32332C22707473223A32333032332C227265706F727465645F6475726174696F6E223A313030312C226B65796672616D65223A66616C73652C227365656B5F66726F6D223A31352C226465636F64655F74696D657374616D70223A32333032337D2C7B226964656E74697479223A32342C22707473223A32343032342C227265706F727465645F6475726174696F6E223A313030312C226B65796672616D65223A66616C73652C227365656B5F66726F6D223A31352C226465636F64655F74696D657374616D70223A32343032347D2C7B226964656E74697479223A32352C22707473223A32353032352C227265706F727465645F6475726174696F6E223A313030312C226B65796672616D65223A66616C73652C227365656B5F66726F6D223A31352C226465636F64655F74696D657374616D70223A32353032357D2C7B226964656E74697479223A32362C22707473223A32363032362C227265706F727465645F6475726174696F6E223A313030312C226B65796672616D65223A66616C73652C227365656B5F66726F6D223A31352C226465636F64655F74696D657374616D70223A32363032367D2C7B226964656E74697479223A32372C22707473223A32373032372C227265706F727465645F6475726174696F6E223A313030312C226B65796672616D65223A66616C73652C227365656B5F66726F6D223A31352C226465636F64655F74696D657374616D70223A32373032377D2C7B226964656E74697479223A32382C22707473223A32383032382C227265706F727465645F6475726174696F6E223A313030312C226B65796672616D65223A66616C73652C227365656B5F66726F6D223A31352C226465636F64655F74696D657374616D70223A32383032387D2C7B226964656E74697479223A32392C22707473223A32393032392C227265706F727465645F6475726174696F6E223A313030312C226B65796672616D65223A66616C73652C227365656B5F66726F6D223A31352C226465636F64655F74696D657374616D70223A32393032397D2C7B226964656E74697479223A33302C22707473223A33303033302C227265706F727465645F6475726174696F6E223A313030312C226B65796672616D65223A747275652C227365656B5F66726F6D223A33302C226465636F64655F74696D657374616D70223A33303033307D2C7B226964656E74697479223A33312C22707473223A33313033312C227265706F727465645F6475726174696F6E223A313030312C226B65796672616D65223A66616C73652C227365656B5F66726F6D223A33302C226465636F64655F74696D657374616D70223A33313033317D2C7B226964656E74697479223A33322C22707473223A33323033322C227265706F727465645F6475726174696F6E223A313030312C226B65796672616D65223A66616C73652C227365656B5F66726F6D223A33302C226465636F64655F74696D657374616D70223A33323033327D2C7B226964656E74697479223A33332C22707473223A33333033332C227265706F727465645F6475726174696F6E223A313030312C226B65796672616D65223A66616C73652C227365656B5F66726F6D223A33302C226465636F64655F74696D657374616D70223A33333033337D2C7B226964656E74697479223A33342C22707473223A33343033342C227265706F727465645F6475726174696F6E223A313030312C226B65796672616D65223A66616C73652C227365656B5F66726F6D223A33302C226465636F64655F74696D657374616D70223A33343033347D2C7B226964656E74697479223A33352C22707473223A33353033352C227265706F727465645F6475726174696F6E223A313030312C226B65796672616D65223A66616C73652C227365656B5F66726F6D223A33302C226465636F64655F74696D657374616D70223A33353033357D2C7B226964656E74697479223A33362C22707473223A33363033362C227265706F727465645F6475726174696F6E223A313030312C226B65796672616D65223A66616C73652C227365656B5F66726F6D223A33302C226465636F64655F74696D657374616D70223A33363033367D2C7B226964656E74697479223A33372C22707473223A33373033372C227265706F727465645F6475726174696F6E223A313030312C226B65796672616D65223A66616C73652C227365656B5F66726F6D223A33302C226465636F64655F74696D657374616D70223A33373033377D2C7B226964656E74697479223A33382C22707473223A33383033382C227265706F727465645F6475726174696F6E223A313030312C226B65796672616D65223A66616C73652C227365656B5F66726F6D223A33302C226465636F64655F74696D657374616D70223A33383033387D2C7B226964656E74697479223A33392C22707473223A33393033392C227265706F727465645F6475726174696F6E223A313030312C226B65796672616D65223A66616C73652C227365656B5F66726F6D223A33302C226465636F64655F74696D657374616D70223A33393033397D2C7B226964656E74697479223A34302C22707473223A34303034302C227265706F727465645F6475726174696F6E223A313030312C226B65796672616D65223A66616C73652C227365656B5F66726F6D223A33302C226465636F64655F74696D657374616D70223A34303034307D2C7B226964656E74697479223A34312C22707473223A34313034312C227265706F727465645F6475726174696F6E223A313030312C226B65796672616D65223A66616C73652C227365656B5F66726F6D223A33302C226465636F64655F74696D657374616D70223A34313034317D2C7B226964656E74697479223A34322C22707473223A34323034322C227265706F727465645F6475726174696F6E223A313030312C226B65796672616D65223A66616C73652C227365656B5F66726F6D223A33302C226465636F64655F74696D657374616D70223A34323034327D2C7B226964656E74697479223A34332C22707473223A34333034332C227265706F727465645F6475726174696F6E223A313030312C226B65796672616D65223A66616C73652C227365656B5F66726F6D223A33302C226465636F64655F74696D657374616D70223A34333034337D2C7B226964656E74697479223A34342C22707473223A34343034342C227265706F727465645F6475726174696F6E223A313030312C226B65796672616D65223A66616C73652C227365656B5F66726F6D223A33302C226465636F64655F74696D657374616D70223A34343034347D2C7B226964656E74697479223A34352C22707473223A34353034352C227265706F727465645F6475726174696F6E223A313030312C226B65796672616D65223A747275652C227365656B5F66726F6D223A34352C226465636F64655F74696D657374616D70223A34353034357D2C7B226964656E74697479223A34362C22707473223A34363034362C227265706F727465645F6475726174696F6E223A313030312C226B65796672616D65223A66616C73652C227365656B5F66726F6D223A34352C226465636F64655F74696D657374616D70223A34363034367D2C7B226964656E74697479223A34372C22707473223A34373034372C227265706F727465645F6475726174696F6E223A313030312C226B65796672616D65223A66616C73652C227365656B5F66726F6D223A34352C226465636F64655F74696D657374616D70223A34373034377D2C7B226964656E74697479223A34382C22707473223A34383034382C227265706F727465645F6475726174696F6E223A313030312C226B65796672616D65223A66616C73652C227365656B5F66726F6D223A34352C226465636F64655F74696D657374616D70223A34383034387D2C7B226964656E74697479223A34392C22707473223A34393034392C227265706F727465645F6475726174696F6E223A313030312C226B65796672616D65223A66616C73652C227365656B5F66726F6D223A34352C226465636F64655F74696D657374616D70223A34393034397D2C7B226964656E74697479223A35302C22707473223A35303035302C227265706F727465645F6475726174696F6E223A313030312C226B65796672616D65223A66616C73652C227365656B5F66726F6D223A34352C226465636F64655F74696D657374616D70223A35303035307D2C7B226964656E74697479223A35312C22707473223A35313035312C227265706F727465645F6475726174696F6E223A313030312C226B65796672616D65223A66616C73652C227365656B5F66726F6D223A34352C226465636F64655F74696D657374616D70223A35313035317D2C7B226964656E74697479223A35322C22707473223A35323035322C227265706F727465645F6475726174696F6E223A313030312C226B65796672616D65223A66616C73652C227365656B5F66726F6D223A34352C226465636F64655F74696D657374616D70223A35323035327D2C7B226964656E74697479223A35332C22707473223A35333035332C227265706F727465645F6475726174696F6E223A313030312C226B65796672616D65223A66616C73652C227365656B5F66726F6D223A34352C226465636F64655F74696D657374616D70223A35333035337D2C7B226964656E74697479223A35342C22707473223A35343035342C227265706F727465645F6475726174696F6E223A313030312C226B65796672616D65223A66616C73652C227365656B5F66726F6D223A34352C226465636F64655F74696D657374616D70223A35343035347D2C7B226964656E74697479223A35352C22707473223A35353035352C227265706F727465645F6475726174696F6E223A313030312C226B65796672616D65223A66616C73652C227365656B5F66726F6D223A34352C226465636F64655F74696D657374616D70223A35353035357D2C7B226964656E74697479223A35362C22707473223A35363035362C227265706F727465645F6475726174696F6E223A313030312C226B65796672616D65223A66616C73652C227365656B5F66726F6D223A34352C226465636F64655F74696D657374616D70223A35363035367D2C7B226964656E74697479223A35372C22707473223A35373035372C227265706F727465645F6475726174696F6E223A313030312C226B65796672616D65223A66616C73652C227365656B5F66726F6D223A34352C226465636F64655F74696D657374616D70223A35373035377D2C7B226964656E74697479223A35382C22707473223A35383035382C227265706F727465645F6475726174696F6E223A313030312C226B65796672616D65223A66616C73652C227365656B5F66726F6D223A34352C226465636F64655F74696D657374616D70223A35383035387D2C7B226964656E74697479223A35392C22707473223A35393035392C227265706F727465645F6475726174696F6E223A313030312C226B65796672616D65223A66616C73652C227365656B5F66726F6D223A34352C226465636F64655F74696D657374616D70223A35393035397D2C7B226964656E74697479223A36302C22707473223A36303036302C227265706F727465645F6475726174696F6E223A313030312C226B65796672616D65223A747275652C227365656B5F66726F6D223A36302C226465636F64655F74696D657374616D70223A36303036307D2C7B226964656E74697479223A36312C22707473223A36313036312C227265706F727465645F6475726174696F6E223A313030312C226B65796672616D65223A66616C73652C227365656B5F66726F6D223A36302C226465636F64655F74696D657374616D70223A36313036317D2C7B226964656E74697479223A36322C22707473223A36323036322C227265706F727465645F6475726174696F6E223A313030312C226B65796672616D65223A66616C73652C227365656B5F66726F6D223A36302C226465636F64655F74696D657374616D70223A36323036327D2C7B226964656E74697479223A36332C22707473223A36333036332C227265706F727465645F6475726174696F6E223A313030312C226B65796672616D65223A66616C73652C227365656B5F66726F6D223A36302C226465636F64655F74696D657374616D70223A36333036337D2C7B226964656E74697479223A36342C22707473223A36343036342C227265706F727465645F6475726174696F6E223A313030312C226B65796672616D65223A66616C73652C227365656B5F66726F6D223A36302C226465636F64655F74696D657374616D70223A36343036347D2C7B226964656E74697479223A36352C22707473223A36353036352C227265706F727465645F6475726174696F6E223A313030312C226B65796672616D65223A66616C73652C227365656B5F66726F6D223A36302C226465636F64655F74696D657374616D70223A36353036357D2C7B226964656E74697479223A36362C22707473223A36363036362C227265706F727465645F6475726174696F6E223A313030312C226B65796672616D65223A66616C73652C227365656B5F66726F6D223A36302C226465636F64655F74696D657374616D70223A36363036367D2C7B226964656E74697479223A36372C22707473223A36373036372C227265706F727465645F6475726174696F6E223A313030312C226B65796672616D65223A66616C73652C227365656B5F66726F6D223A36302C226465636F64655F74696D657374616D70223A36373036377D2C7B226964656E74697479223A36382C22707473223A36383036382C227265706F727465645F6475726174696F6E223A313030312C226B65796672616D65223A66616C73652C227365656B5F66726F6D223A36302C226465636F64655F74696D657374616D70223A36383036387D2C7B226964656E74697479223A36392C22707473223A36393036392C227265706F727465645F6475726174696F6E223A313030312C226B65796672616D65223A66616C73652C227365656B5F66726F6D223A36302C226465636F64655F74696D657374616D70223A36393036397D2C7B226964656E74697479223A37302C22707473223A37303037302C227265706F727465645F6475726174696F6E223A313030312C226B65796672616D65223A66616C73652C227365656B5F66726F6D223A36302C226465636F64655F74696D657374616D70223A37303037307D2C7B226964656E74697479223A37312C22707473223A37313037312C227265706F727465645F6475726174696F6E223A313030312C226B65796672616D65223A66616C73652C227365656B5F66726F6D223A36302C226465636F64655F74696D657374616D70223A37313037317D2C7B226964656E74697479223A37322C22707473223A37323037322C227265706F727465645F6475726174696F6E223A313030312C226B65796672616D65223A66616C73652C227365656B5F66726F6D223A36302C226465636F64655F74696D657374616D70223A37323037327D2C7B226964656E74697479223A37332C22707473223A37333037332C227265706F727465645F6475726174696F6E223A313030312C226B65796672616D65223A66616C73652C227365656B5F66726F6D223A36302C226465636F64655F74696D657374616D70223A37333037337D2C7B226964656E74697479223A37342C22707473223A37343037342C227265706F727465645F6475726174696F6E223A313030312C226B65796672616D65223A66616C73652C227365656B5F66726F6D223A36302C226465636F64655F74696D657374616D70223A37343037347D2C7B226964656E74697479223A37352C22707473223A37353037352C227265706F727465645F6475726174696F6E223A313030312C226B65796672616D65223A747275652C227365656B5F66726F6D223A37352C226465636F64655F74696D657374616D70223A37353037357D2C7B226964656E74697479223A37362C22707473223A37363037362C227265706F727465645F6475726174696F6E223A313030312C226B65796672616D65223A66616C73652C227365656B5F66726F6D223A37352C226465636F64655F74696D657374616D70223A37363037367D2C7B226964656E74697479223A37372C22707473223A37373037372C227265706F727465645F6475726174696F6E223A313030312C226B65796672616D65223A66616C73652C227365656B5F66726F6D223A37352C226465636F64655F74696D657374616D70223A37373037377D2C7B226964656E74697479223A37382C22707473223A37383037382C227265706F727465645F6475726174696F6E223A313030312C226B65796672616D65223A66616C73652C227365656B5F66726F6D223A37352C226465636F64655F74696D657374616D70223A37383037387D2C7B226964656E74697479223A37392C22707473223A37393037392C227265706F727465645F6475726174696F6E223A313030312C226B65796672616D65223A66616C73652C227365656B5F66726F6D223A37352C226465636F64655F74696D657374616D70223A37393037397D2C7B226964656E74697479223A38302C22707473223A38303038302C227265706F727465645F6475726174696F6E223A313030312C226B65796672616D65223A66616C73652C227365656B5F66726F6D223A37352C226465636F64655F74696D657374616D70223A38303038307D2C7B226964656E74697479223A38312C22707473223A38313038312C227265706F727465645F6475726174696F6E223A313030312C226B65796672616D65223A66616C73652C227365656B5F66726F6D223A37352C226465636F64655F74696D657374616D70223A38313038317D2C7B226964656E74697479223A38322C22707473223A38323038322C227265706F727465645F6475726174696F6E223A313030312C226B65796672616D65223A66616C73652C227365656B5F66726F6D223A37352C226465636F64655F74696D657374616D70223A38323038327D2C7B226964656E74697479223A38332C22707473223A38333038332C227265706F727465645F6475726174696F6E223A313030312C226B65796672616D65223A66616C73652C227365656B5F66726F6D223A37352C226465636F64655F74696D657374616D70223A38333038337D2C7B226964656E74697479223A38342C22707473223A38343038342C227265706F727465645F6475726174696F6E223A313030312C226B65796672616D65223A66616C73652C227365656B5F66726F6D223A37352C226465636F64655F74696D657374616D70223A38343038347D2C7B226964656E74697479223A38352C22707473223A38353038352C227265706F727465645F6475726174696F6E223A313030312C226B65796672616D65223A66616C73652C227365656B5F66726F6D223A37352C226465636F64655F74696D657374616D70223A38353038357D2C7B226964656E74697479223A38362C22707473223A38363038362C227265706F727465645F6475726174696F6E223A313030312C226B65796672616D65223A66616C73652C227365656B5F66726F6D223A37352C226465636F64655F74696D657374616D70223A38363038367D2C7B226964656E74697479223A38372C22707473223A38373038372C227265706F727465645F6475726174696F6E223A313030312C226B65796672616D65223A66616C73652C227365656B5F66726F6D223A37352C226465636F64655F74696D657374616D70223A38373038377D2C7B226964656E74697479223A38382C22707473223A38383038382C227265706F727465645F6475726174696F6E223A313030312C226B65796672616D65223A66616C73652C227365656B5F66726F6D223A37352C226465636F64655F74696D657374616D70223A38383038387D2C7B226964656E74697479223A38392C22707473223A38393038392C227265706F727465645F6475726174696F6E223A313030312C226B65796672616D65223A66616C73652C227365656B5F66726F6D223A37352C226465636F64655F74696D657374616D70223A38393038397D2C7B226964656E74697479223A39302C22707473223A39303039302C227265706F727465645F6475726174696F6E223A313030312C226B65796672616D65223A747275652C227365656B5F66726F6D223A39302C226465636F64655F74696D657374616D70223A39303039307D2C7B226964656E74697479223A39312C22707473223A39313039312C227265706F727465645F6475726174696F6E223A313030312C226B65796672616D65223A66616C73652C227365656B5F66726F6D223A39302C226465636F64655F74696D657374616D70223A39313039317D2C7B226964656E74697479223A39322C22707473223A39323039322C227265706F727465645F6475726174696F6E223A313030312C226B65796672616D65223A66616C73652C227365656B5F66726F6D223A39302C226465636F64655F74696D657374616D70223A39323039327D2C7B226964656E74697479223A39332C22707473223A39333039332C227265706F727465645F6475726174696F6E223A313030312C226B65796672616D65223A66616C73652C227365656B5F66726F6D223A39302C226465636F64655F74696D657374616D70223A39333039337D2C7B226964656E74697479223A39342C22707473223A39343039342C227265706F727465645F6475726174696F6E223A313030312C226B65796672616D65223A66616C73652C227365656B5F66726F6D223A39302C226465636F64655F74696D657374616D70223A39343039347D2C7B226964656E74697479223A39352C22707473223A39353039352C227265706F727465645F6475726174696F6E223A313030312C226B65796672616D65223A66616C73652C227365656B5F66726F6D223A39302C226465636F64655F74696D657374616D70223A39353039357D2C7B226964656E74697479223A39362C22707473223A39363039362C227265706F727465645F6475726174696F6E223A313030312C226B65796672616D65223A66616C73652C227365656B5F66726F6D223A39302C226465636F64655F74696D657374616D70223A39363039367D2C7B226964656E74697479223A39372C22707473223A39373039372C227265706F727465645F6475726174696F6E223A313030312C226B65796672616D65223A66616C73652C227365656B5F66726F6D223A39302C226465636F64655F74696D657374616D70223A39373039377D2C7B226964656E74697479223A39382C22707473223A39383039382C227265706F727465645F6475726174696F6E223A313030312C226B65796672616D65223A66616C73652C227365656B5F66726F6D223A39302C226465636F64655F74696D657374616D70223A39383039387D2C7B226964656E74697479223A39392C22707473223A39393039392C227265706F727465645F6475726174696F6E223A313030312C226B65796672616D65223A66616C73652C227365656B5F66726F6D223A39302C226465636F64655F74696D657374616D70223A39393039397D2C7B226964656E74697479223A3130302C22707473223A3130303130302C227265706F727465645F6475726174696F6E223A313030312C226B65796672616D65223A66616C73652C227365656B5F66726F6D223A39302C226465636F64655F74696D657374616D70223A3130303130307D2C7B226964656E74697479223A3130312C22707473223A3130313130312C227265706F727465645F6475726174696F6E223A313030312C226B65796672616D65223A66616C73652C227365656B5F66726F6D223A39302C226465636F64655F74696D657374616D70223A3130313130317D2C7B226964656E74697479223A3130322C22707473223A3130323130322C227265706F727465645F6475726174696F6E223A313030312C226B65796672616D65223A66616C73652C227365656B5F66726F6D223A39302C226465636F64655F74696D657374616D70223A3130323130327D2C7B226964656E74697479223A3130332C22707473223A3130333130332C227265706F727465645F6475726174696F6E223A313030312C226B65796672616D65223A66616C73652C227365656B5F66726F6D223A39302C226465636F64655F74696D657374616D70223A3130333130337D2C7B226964656E74697479223A3130342C22707473223A3130343130342C227265706F727465645F6475726174696F6E223A313030312C226B65796672616D65223A66616C73652C227365656B5F66726F6D223A39302C226465636F64655F74696D657374616D70223A3130343130347D2C7B226964656E74697479223A3130352C22707473223A3130353130352C227265706F727465645F6475726174696F6E223A313030312C226B65796672616D65223A747275652C227365656B5F66726F6D223A3130352C226465636F64655F74696D657374616D70223A3130353130357D2C7B226964656E74697479223A3130362C22707473223A3130363130362C227265706F727465645F6475726174696F6E223A313030312C226B65796672616D65223A66616C73652C227365656B5F66726F6D223A3130352C226465636F64655F74696D657374616D70223A3130363130367D2C7B226964656E74697479223A3130372C22707473223A3130373130372C227265706F727465645F6475726174696F6E223A313030312C226B65796672616D65223A66616C73652C227365656B5F66726F6D223A3130352C226465636F64655F74696D657374616D70223A3130373130377D2C7B226964656E74697479223A3130382C22707473223A3130383130382C227265706F727465645F6475726174696F6E223A313030312C226B65796672616D65223A66616C73652C227365656B5F66726F6D223A3130352C226465636F64655F74696D657374616D70223A3130383130387D2C7B226964656E74697479223A3130392C22707473223A3130393130392C227265706F727465645F6475726174696F6E223A313030312C226B65796672616D65223A66616C73652C227365656B5F66726F6D223A3130352C226465636F64655F74696D657374616D70223A3130393130397D2C7B226964656E74697479223A3131302C22707473223A3131303131302C227265706F727465645F6475726174696F6E223A313030312C226B65796672616D65223A66616C73652C227365656B5F66726F6D223A3130352C226465636F64655F74696D657374616D70223A3131303131307D2C7B226964656E74697479223A3131312C22707473223A3131313131312C227265706F727465645F6475726174696F6E223A313030312C226B65796672616D65223A66616C73652C227365656B5F66726F6D223A3130352C226465636F64655F74696D657374616D70223A3131313131317D2C7B226964656E74697479223A3131322C22707473223A3131323131322C227265706F727465645F6475726174696F6E223A313030312C226B65796672616D65223A66616C73652C227365656B5F66726F6D223A3130352C226465636F64655F74696D657374616D70223A3131323131327D2C7B226964656E74697479223A3131332C22707473223A3131333131332C227265706F727465645F6475726174696F6E223A313030312C226B65796672616D65223A66616C73652C227365656B5F66726F6D223A3130352C226465636F64655F74696D657374616D70223A3131333131337D2C7B226964656E74697479223A3131342C22707473223A3131343131342C227265706F727465645F6475726174696F6E223A313030312C226B65796672616D65223A66616C73652C227365656B5F66726F6D223A3130352C226465636F64655F74696D657374616D70223A3131343131347D2C7B226964656E74697479223A3131352C22707473223A3131353131352C227265706F727465645F6475726174696F6E223A313030312C226B65796672616D65223A66616C73652C227365656B5F66726F6D223A3130352C226465636F64655F74696D657374616D70223A3131353131357D2C7B226964656E74697479223A3131362C22707473223A3131363131362C227265706F727465645F6475726174696F6E223A313030312C226B65796672616D65223A66616C73652C227365656B5F66726F6D223A3130352C226465636F64655F74696D657374616D70223A3131363131367D2C7B226964656E74697479223A3131372C22707473223A3131373131372C227265706F727465645F6475726174696F6E223A313030312C226B65796672616D65223A66616C73652C227365656B5F66726F6D223A3130352C226465636F64655F74696D657374616D70223A3131373131377D2C7B226964656E74697479223A3131382C22707473223A3131383131382C227265706F727465645F6475726174696F6E223A313030312C226B65796672616D65223A66616C73652C227365656B5F66726F6D223A3130352C226465636F64655F74696D657374616D70223A3131383131387D2C7B226964656E74697479223A3131392C22707473223A3131393131392C227265706F727465645F6475726174696F6E223A313030312C226B65796672616D65223A66616C73652C227365656B5F66726F6D223A3130352C226465636F64655F74696D657374616D70223A6E756C6C7D5D2C227465726D696E616C5F656E64223A3132303132302C227465726D696E616C5F70726F76656E616E6365223A226465636F6465645F6672616D655F6475726174696F6E227D7D2C22696E746572707265746174696F6E223A7B227769647468223A3332302C22686569676874223A3138302C2273747265616D5F696E646578223A302C2274696D655F626173655F6E756D223A312C2274696D655F626173655F64656E223A33303030302C2273616D706C655F6173706563745F6E756D223A312C2273616D706C655F6173706563745F64656E223A312C22726F746174696F6E5F717561727465725F7475726E73223A302C22636F6C6F72223A7B2272616E6765223A226C696D69746564222C226D6174726978223A226274373039222C227472616E73666572223A226274373039222C227072696D6172696573223A226274373039227D2C22636F646563223A2268323634222C22706978656C5F666F726D6174223A2279757634323070222C2273747265616D5F7374617274223A302C2273747265616D5F6475726174696F6E223A3132303132302C22636F6E7461696E65725F7374617274223A6E756C6C2C22636F6E7461696E65725F6475726174696F6E223A6E756C6C2C22617564696F5F73747265616D73223A5B7B2273747265616D5F696E646578223A312C22636F646563223A22616163222C2274696D655F626173655F6E756D223A312C2274696D655F626173655F64656E223A34383030302C2273747265616D5F7374617274223A302C2273747265616D5F6475726174696F6E223A3139323139322C2273616D706C655F72617465223A34383030302C226368616E6E656C5F636F756E74223A327D5D7D7D2C22617564696F223A7B22736368656D615F76657273696F6E223A312C226465636F6465725F636F6E7472616374223A2266666D7065672D382E302E332F617564696F2D6D616E75616C2D736B69702D7631222C22636F6E74656E74223A7B22736861323536223A5B39302C3133302C31302C3132312C3139312C38352C31332C37322C37372C3134322C3230332C35352C3235352C3232312C3230382C37322C3230382C39392C3130332C3134382C3233352C3230362C39332C3138342C36322C37392C39322C3232392C3234352C3233302C37332C32345D2C22627974655F6C656E677468223A33393135377D2C2273747265616D223A7B2273747265616D5F696E646578223A312C22636F646563223A22616163222C2274696D655F62617365223A7B226E756D657261746F72223A312C2264656E6F6D696E61746F72223A34383030307D2C2273616D706C655F72617465223A34383030302C226368616E6E656C5F6C61796F7574223A7B226F72646572223A226E6174697665222C226368616E6E656C73223A322C226D61736B223A337D2C2273747265616D5F7374617274223A302C2273747265616D5F6475726174696F6E223A3139323139322C22696E697469616C5F70616464696E67223A302C22747261696C696E675F70616464696E67223A302C227365656B5F707265726F6C6C223A307D2C226F62736572766174696F6E73223A5B7B22707473223A2D313032342C2264697363617264223A747275652C226465636F64655F74696D657374616D70223A2D313032342C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A7B226C656164696E67223A313032342C22747261696C696E67223A302C226C656164696E675F726561736F6E223A302C22747261696C696E675F726561736F6E223A307D7D2C7B22707473223A302C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A302C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A313032342C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A313032342C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A323034382C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A323034382C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A333037322C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A333037322C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A343039362C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A343039362C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A353132302C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A353132302C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A363134342C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A363134342C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A373136382C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A373136382C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A383139322C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A383139322C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A393231362C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A393231362C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A31303234302C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A31303234302C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A31313236342C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A31313236342C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A31323238382C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A31323238382C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A31333331322C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A31333331322C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A31343333362C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A31343333362C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A31353336302C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A31353336302C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A31363338342C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A31363338342C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A31373430382C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A31373430382C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A31383433322C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A31383433322C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A31393435362C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A31393435362C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A32303438302C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A32303438302C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A32313530342C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A32313530342C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A32323532382C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A32323532382C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A32333535322C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A32333535322C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A32343537362C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A32343537362C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A32353630302C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A32353630302C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A32363632342C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A32363632342C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A32373634382C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A32373634382C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A32383637322C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A32383637322C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A32393639362C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A32393639362C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A33303732302C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A33303732302C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A33313734342C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A33313734342C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A33323736382C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A33323736382C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A33333739322C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A33333739322C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A33343831362C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A33343831362C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A33353834302C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A33353834302C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A33363836342C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A33363836342C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A33373838382C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A33373838382C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A33383931322C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A33383931322C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A33393933362C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A33393933362C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A34303936302C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A34303936302C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A34313938342C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A34313938342C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A34333030382C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A34333030382C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A34343033322C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A34343033322C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A34353035362C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A34353035362C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A34363038302C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A34363038302C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A34373130342C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A34373130342C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A34383132382C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A34383132382C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A34393135322C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A34393135322C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A35303137362C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A35303137362C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A35313230302C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A35313230302C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A35323232342C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A35323232342C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A35333234382C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A35333234382C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A35343237322C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A35343237322C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A35353239362C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A35353239362C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A35363332302C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A35363332302C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A35373334342C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A35373334342C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A35383336382C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A35383336382C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A35393339322C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A35393339322C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A36303431362C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A36303431362C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A36313434302C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A36313434302C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A36323436342C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A36323436342C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A36333438382C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A36333438382C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A36343531322C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A36343531322C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A36353533362C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A36353533362C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A36363536302C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A36363536302C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A36373538342C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A36373538342C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A36383630382C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A36383630382C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A36393633322C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A36393633322C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A37303635362C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A37303635362C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A37313638302C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A37313638302C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A37323730342C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A37323730342C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A37333732382C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A37333732382C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A37343735322C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A37343735322C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A37353737362C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A37353737362C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A37363830302C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A37363830302C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A37373832342C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A37373832342C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A37383834382C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A37383834382C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A37393837322C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A37393837322C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A38303839362C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A38303839362C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A38313932302C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A38313932302C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A38323934342C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A38323934342C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A38333936382C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A38333936382C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A38343939322C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A38343939322C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A38363031362C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A38363031362C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A38373034302C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A38373034302C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A38383036342C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A38383036342C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A38393038382C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A38393038382C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A39303131322C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A39303131322C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A39313133362C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A39313133362C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A39323136302C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A39323136302C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A39333138342C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A39333138342C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A39343230382C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A39343230382C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A39353233322C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A39353233322C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A39363235362C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A39363235362C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A39373238302C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A39373238302C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A39383330342C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A39383330342C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A39393332382C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A39393332382C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A3130303335322C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A3130303335322C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A3130313337362C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A3130313337362C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A3130323430302C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A3130323430302C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A3130333432342C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A3130333432342C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A3130343434382C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A3130343434382C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A3130353437322C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A3130353437322C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A3130363439362C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A3130363439362C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A3130373532302C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A3130373532302C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A3130383534342C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A3130383534342C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A3130393536382C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A3130393536382C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A3131303539322C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A3131303539322C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A3131313631362C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A3131313631362C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A3131323634302C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A3131323634302C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A3131333636342C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A3131333636342C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A3131343638382C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A3131343638382C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A3131353731322C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A3131353731322C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A3131363733362C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A3131363733362C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A3131373736302C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A3131373736302C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A3131383738342C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A3131383738342C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A3131393830382C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A3131393830382C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A3132303833322C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A3132303833322C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A3132313835362C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A3132313835362C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A3132323838302C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A3132323838302C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A3132333930342C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A3132333930342C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A3132343932382C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A3132343932382C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A3132353935322C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A3132353935322C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A3132363937362C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A3132363937362C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A3132383030302C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A3132383030302C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A3132393032342C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A3132393032342C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A3133303034382C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A3133303034382C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A3133313037322C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A3133313037322C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A3133323039362C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A3133323039362C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A3133333132302C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A3133333132302C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A3133343134342C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A3133343134342C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A3133353136382C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A3133353136382C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A3133363139322C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A3133363139322C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A3133373231362C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A3133373231362C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A3133383234302C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A3133383234302C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A3133393236342C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A3133393236342C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A3134303238382C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A3134303238382C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A3134313331322C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A3134313331322C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A3134323333362C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A3134323333362C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A3134333336302C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A3134333336302C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A3134343338342C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A3134343338342C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A3134353430382C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A3134353430382C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A3134363433322C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A3134363433322C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A3134373435362C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A3134373435362C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A3134383438302C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A3134383438302C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A3134393530342C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A3134393530342C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A3135303532382C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A3135303532382C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A3135313535322C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A3135313535322C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A3135323537362C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A3135323537362C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A3135333630302C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A3135333630302C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A3135343632342C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A3135343632342C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A3135353634382C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A3135353634382C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A3135363637322C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A3135363637322C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A3135373639362C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A3135373639362C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A3135383732302C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A3135383732302C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A3135393734342C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A3135393734342C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A3136303736382C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A3136303736382C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A3136313739322C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A3136313739322C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A3136323831362C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A3136323831362C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A3136333834302C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A3136333834302C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A3136343836342C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A3136343836342C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A3136353838382C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A3136353838382C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A3136363931322C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A3136363931322C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A3136373933362C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A3136373933362C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A3136383936302C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A3136383936302C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A3136393938342C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A3136393938342C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A3137313030382C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A3137313030382C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A3137323033322C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A3137323033322C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A3137333035362C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A3137333035362C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A3137343038302C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A3137343038302C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A3137353130342C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A3137353130342C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A3137363132382C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A3137363132382C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A3137373135322C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A3137373135322C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A3137383137362C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A3137383137362C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A3137393230302C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A3137393230302C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A3138303232342C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A3138303232342C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A3138313234382C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A3138313234382C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A3138323237322C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A3138323237322C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A3138333239362C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A3138333239362C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A3138343332302C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A3138343332302C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A3138353334342C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A3138353334342C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A3138363336382C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A3138363336382C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A3138373339322C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A3138373339322C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A3138383431362C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A3138383431362C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A3138393434302C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A3138393434302C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A3139303436342C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A3139303436342C227265706F727465645F6475726174696F6E223A313032342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D2C7B22707473223A3139313438382C2264697363617264223A66616C73652C226465636F64655F74696D657374616D70223A3139313438382C227265706F727465645F6475726174696F6E223A3730342C2273616D706C655F636F756E74223A313032342C2273616D706C655F666F726D6174223A22666C7470222C22736B69705F73616D706C6573223A6E756C6C7D5D7D7D');
CREATE TABLE state (
            singleton INTEGER PRIMARY KEY CHECK (singleton=1),
            head_revision TEXT NOT NULL REFERENCES revisions(id),
            cursor INTEGER REFERENCES history(id),
            workflow TEXT NOT NULL DEFAULT 'generic' CHECK(workflow IN ('generic','single_source_v1'))
        ) STRICT;
INSERT INTO "state" VALUES(1,'bbd2c663-50ce-4c79-aaad-7ee112879b9f',1,'single_source_v1');
CREATE INDEX revision_parent ON revisions(parent_id);
CREATE INDEX history_revision ON history(revision_id);
CREATE UNIQUE INDEX one_current_generation_per_hold
    ON generation_requests(hold_id) WHERE relevance='current';
CREATE UNIQUE INDEX one_nonterminal_generation_attempt_per_request
    ON generation_attempts(request_id)
    WHERE state IN ('queued','preflight','loading','running','validating','cancelling');
CREATE UNIQUE INDEX one_active_render_attempt ON render_attempts((1)) WHERE state IN ('queued','encoding','encoded_retained','verifying','cancelling');
CREATE UNIQUE INDEX unique_render_cancellation_token ON render_attempts(cancellation_token);
CREATE UNIQUE INDEX one_active_publication_operation ON render_publication_operations(publication_id) WHERE active=1;
COMMIT;
