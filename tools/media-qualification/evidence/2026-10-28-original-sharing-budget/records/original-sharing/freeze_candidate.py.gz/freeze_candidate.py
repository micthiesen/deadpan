from pathlib import Path
import hashlib,json,difflib,shutil,subprocess
r=Path('/tmp/deadpan-original-sharing-budget-2026-10-28')
repo=Path('/Users/michael/Code/deadpan')
scoped=Path('/tmp/deadpan-query-groundwork-2026-10-26/scoped')
sha=lambda b:hashlib.sha256(b).hexdigest()
manifest=[]
patch=[]
for target in sorted((r/'candidate').rglob('*.rs')):
    path=target.relative_to(r/'candidate')
    before=r/'before'/path
    data=target.read_bytes()
    old=before.read_bytes() if before.exists() else b''
    live=repo/path
    if before.exists():
        assert live.read_bytes()==old, f'live baseline drift: {path}'
    else:
        assert not live.exists(), f'new path exists live: {path}'
    manifest.append({'path':str(path),'before_sha256':sha(old) if before.exists() else None,'candidate_sha256':sha(data),'bytes':len(data),'new':not before.exists()})
    patch.extend(difflib.unified_diff(old.decode().splitlines(True),data.decode().splitlines(True),fromfile='a/'+str(path) if before.exists() else '/dev/null',tofile='b/'+str(path)))
    for name,base in [('main-check',repo),('scoped-check',scoped)]:
        dest=r/name/path;dest.parent.mkdir(parents=True,exist_ok=True)
        if (base/path).exists(): shutil.copyfile(base/path,dest)
(r/'candidate-pins.json').write_text(json.dumps(manifest,indent=2)+'\n')
text=''.join(patch)
(r/'task.patch').write_text(text)
for name in ['main-check','scoped-check']:
    p=subprocess.run(['patch','-p1','--batch','-i',str(r/'task.patch')],cwd=r/name,capture_output=True,text=True)
    (r/(name+'-patch.txt')).write_text(p.stdout+p.stderr)
    assert p.returncode==0,(name,p.stdout,p.stderr)
audit=[]
for item in manifest:
    path=Path(item['path']); candidate=(r/'candidate'/path).read_bytes()
    assert candidate==(r/'main-check'/path).read_bytes(),path
    published=(r/'scoped-check'/path).read_bytes()
    audit.append({'path':str(path),'main_sha256':sha(candidate),'scoped_sha256':sha(published),'same':candidate==published})
(r/'overlay-audit.json').write_text(json.dumps(audit,indent=2)+'\n')
for name in ['candidate-pins.json','task.patch','overlay-audit.json']:
    print(name,sha((r/name).read_bytes()))
print('files',len(manifest),'new',sum(i['new'] for i in manifest))
print('main/scoped retained WIP differences',[i['path'] for i in audit if not i['same']])
