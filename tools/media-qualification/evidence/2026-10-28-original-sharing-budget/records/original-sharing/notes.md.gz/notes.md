# Original final-sharing admission candidate

Frozen first compile candidate, 2026-10-28. Base parent-reported HEAD is
02cd21afc219e8235d0ab8229f0f1a821c2754c5. No live/scoped source, Git/index,
Cargo/rustc, provider or native probe was run by this worker.

## Concrete scope

The actual shared numerical descriptor calls one admitted finish operation at
the two existing return sites of Context::finish_paid_owner_input. One common
decision helper retains the actual retained probe (including None work), optional
retained owners query and boundary match. Legacy owner_context still selects its
original unmetered Arc/clone callback. The fused Root/Domain Q/C capture remains.

Accepted Retained moves its already constructed graph into one admitted Arc
shell. Domain fallthrough exhaustively copies all AudioDomain/AudioWalkSeed
fields, five known-length Vec buffers, every owning identity edge and its Arc
shell. Definition, gap, repeat, retime, transported editorial and signed placement
fields remain supported. Source Input, membership query/capture and retained
inner-graph allocations are explicitly outside this slice.

The private existing sound_context_frames lane accounts BOTH sound and Original
charges. Public sound admission policy names remain unchanged. Five existing
layout/issuer/reserve primitives move to one private accounting kernel.

## Allocation and work recipe

Each Vec uses checked Layout::array<T>(len), reservation before with_capacity,
capacity == len assertion, then ordered pushes. Rust is pinned to 1.97.1;
Vec::with_capacity's documented contract requests exactly its argument elements
and reports allocator-granted logical capacity, with no geometric push growth
because len never exceeds that bound. If this pinned contract changes the release
assertion rejects it. Empty Vecs have zero bound/allocation. Arc layout is the
existing checked counters + aligned T layout; identity owning edges use the same
conservative counters + exact text + padding convention as sound admission.
Per-allocation reservation rounds separately to eight-byte frame units.

New field/element/identity inspections bill actual admission.spend(1) before
inspection, bounded by the normal query limit. The unmetered compatibility
callback keeps old work receipts; it performs no new metered walk. Earlier
queries retain their original work/order; there is no refund or reset.

## Failure and publication boundary

Partial owned values reside before leases in Scope/opaque carrier. Copied
buffers or newly shared Arcs drop before their leases on errors. Description
owns Context values first, then Original carrier, then sound carrier.

Both public carrier issuers and concrete lease ledger pointer identities are
checked before publication. Metadata addition, native+metadata total, new
active/Graph totals and request-lane subtraction are all checked before Node
publication. The Node Vec slot is reserved once. One joint callback pushes Node
and assigns active/resident, then commits both lease balances in an infallible,
arithmetic-free tail. Optional carrier absence is supported independently for
incoming Retained, original_only and sound fallback. No fallible second transfer
can follow an already committed first transfer. Existing graph value-drop before
active counter release remains.

## Tests prepared; not run by worker

- Actual Domain and accepted-Retained finish branches: exact byte cap succeeds,
  one byte short refuses, new inspection work only, signed/root-grid/query parity,
  accepted Retained one Arc allocation only, weak-Arc drop-before-lease assertions.
- Actual finite Repeat/Preserve/gap and signed definition Domain contexts:
  exact/new retained charge, one-short error cleanup, interruption cleanup, query
  and sample-grid parity, exhaustive clone shape.
- Joint issuer mismatch checks both sides before callback/counter/cache calls;
  missing Original or sound or both carriers.
- Actual EQ node exact native+Original frame cap via independent final-sharing
  constructor oracle; unchanged native bound independently asserted 266241.
  Filter temporary takes remain charged; graph teardown now drops graph before
  subtracting the saved resident in the common test.
- Existing nested native test now includes positive Original metadata separately
  from the outstanding external sound token.
- Actual PCM cache eviction precedes Original-copy reservations; real-WAV cold
  read again re-admits sources and compares exact bits/dependencies/depth.
- Descriptor both-charge retention, boundary failure and cancellation release.

No frequency or whole-Original/Root/Domain/Core transient closure claim. No
persistent cache, cold driver, batching, cap/weight change, fake planner, source
probe, native probe, retry or refund was added.

## Frozen deliverables

task.patch applies to both scratch snapshots without changing real sources.
candidate-pins.json pins all18 candidate files (4 new), before-pins.json records
initial source pins, and overlay-audit.json pins both resulting main/scoped copies.
main-check and scoped-check are scratch-only applied copies. The task patch
preserves inherited main/scoped differences rather than copying main WIP into
the published baseline. Their differing resulting files are listed in the audit;
these are inherited differences, not task-only changes.
