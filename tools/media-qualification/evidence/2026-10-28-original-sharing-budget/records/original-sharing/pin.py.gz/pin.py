from pathlib import Path
import sys,json,shutil,hashlib
s=Path(__file__).resolve().parent
label=sys.argv[1]
receipt=json.loads((s/(label+'.json')).read_text())
assert receipt['exit_code']==0 and receipt['sources_unchanged']
artifacts=[]
for line in (s/(label+'.stdout')).read_text().splitlines():
 try:a=json.loads(line)
 except ValueError:continue
 if a.get('reason')!='compiler-artifact' or not a.get('executable') or not a.get('profile',{}).get('test'):continue
 package='audio' if 'deadpan-audio#' in a['package_id'] else 'plan' if 'deadpan-plan#' in a['package_id'] else None
 if package=='audio' and a['target']['name'] not in ['deadpan_audio','audio_definition','stages']:continue
 if package:artifacts.append((package,a))
assert sum(p=='audio' for p,a in artifacts)==3
assert sum(p=='plan' for p,a in artifacts)==29
destinations=[s/(label+'-'+p+'-'+a['target']['name'].replace('_','-')) for p,a in artifacts]
assert len(set(destinations))==32
assert all(not p.exists() for p in destinations)
pins=[]
for (package,a),dest in zip(artifacts,destinations):
 shutil.copy2(a['executable'],dest)
 pins.append(dict(package=package,name=a['target']['name'],path=str(dest),sha256=hashlib.sha256(dest.read_bytes()).hexdigest(),bytes=dest.stat().st_size,artifact=a))
(s/(label+'-pins.json')).write_text(json.dumps(pins,indent=2)+'\n')
print(json.dumps({'binaries':len(pins),'pins_file':str(s/(label+'-pins.json'))}))
