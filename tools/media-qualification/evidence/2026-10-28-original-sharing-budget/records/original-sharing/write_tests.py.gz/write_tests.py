from pathlib import Path
root=Path('/tmp/deadpan-original-sharing-budget-2026-10-28')
repo=Path('/Users/michael/Code/deadpan')
def own(path):
    text=(repo/path).read_text()
    target=root/'before'/path; target.parent.mkdir(parents=True,exist_ok=True); target.write_text(text)
    target=root/'candidate'/path; target.parent.mkdir(parents=True,exist_ok=True); target.write_text(text)
for path in ['crates/deadpan-audio/src/eq_admission/checks.rs','crates/deadpan-audio/src/shared_eq/admission_tests.rs','crates/deadpan-audio/src/shared_eq/sound_admission_tests.rs','crates/deadpan-audio/src/sound_context_admission_tests.rs']:
    own(path)
source=(repo/'crates/deadpan-plan/src/audio_sound_admission_tests.rs').read_text()
fixture=source[source.index('fn fixture('):source.index('#[derive(Default)]')]
fixture=fixture.replace('gap: None,','gap: Some(HoldRecipe { duration: FrameDuration::new(8).unwrap(), picture_context: None, video: HoldVideo::Background, audio: HoldAudio::Silence }),')
# Existing validated Hold/Repeat/Preserve constructor, with actual editorial markers.
fixture=fixture.replace('let tone = BeatNode::hold(', 'let mut tone = BeatNode::hold(')
fixture=fixture.replace('let mut nodes = BTreeMap', 'tone.audio_editorial_edges = AudioEditorialEdges { start: true, end: true };\n    let mut nodes = BTreeMap')
out='''use super::*;
use deadpan_core::*;
use std::{alloc::Layout,cell::RefCell,collections::BTreeMap,rc::Rc,sync::{Arc,Weak}};

'''+fixture+'''
#[derive(Default)]
struct State<'plan> {
    cap: usize, live: usize, peak: usize, calls: usize, work: usize,
    fail_after: Option<usize>,
    domain: Option<Weak<AudioDomain<'plan>>>,
    retained: Option<Weak<AudioOwnerRetainedInput<'plan>>>,
}
struct Policy<'plan>(Rc<RefCell<State<'plan>>>);
struct Token<'plan> { state: Rc<RefCell<State<'plan>>>, bytes: usize }
impl Drop for Token<'_> {
    fn drop(&mut self) {
        if self.bytes == 0 { return; }
        let mut state=self.state.borrow_mut();
        if let Some(value)=&state.domain { assert!(value.upgrade().is_none(),"Domain before lease"); }
        if let Some(value)=&state.retained { assert!(value.upgrade().is_none(),"Retained before lease"); }
        state.live-=self.bytes;
    }
}
impl<'plan> AudioSoundContextAdmission for Policy<'plan> {
    type Error=PlanError;
    type Issuer=usize;
    type Lease=Token<'plan>;
    fn issuer(&self)->usize { Rc::as_ptr(&self.0) as usize }
    fn spend(&mut self,n:usize)->Result<(),PlanError> {
        let mut state=self.0.borrow_mut();
        if state.fail_after.is_some_and(|limit|state.work>=limit) { return Err(PlanError::AudioQueryLimit("test cancellation")); }
        state.work+=n; Ok(())
    }
    fn reserve(&mut self,layout:Layout)->Result<Token<'plan>,PlanError> {
        let mut state=self.0.borrow_mut(); state.calls+=1;
        let next=state.live.checked_add(layout.size()).unwrap();
        if next>state.cap { return Err(PlanError::AudioQueryLimit("test heap bytes")); }
        state.live=next; state.peak=state.peak.max(next);
        Ok(Token{state:Rc::clone(&self.0),bytes:layout.size()})
    }
    fn merge(&mut self,a:&mut Token<'plan>,b:&mut Token<'plan>) {
        assert!(Rc::ptr_eq(&a.state,&self.0)&&Rc::ptr_eq(&b.state,&self.0));
        a.bytes+=b.bytes; b.bytes=0;
    }
}
fn policy<'plan>(cap:usize)->Policy<'plan> {
    Policy(Rc::new(RefCell::new(State{cap,..Default::default()})))
}
fn parity(source:&AudioDomain<'_>,target:&AudioDomain<'_>) {
    assert_eq!(source.root_samples(),target.root_samples());
    assert_eq!(source.visible_samples(),target.visible_samples());
    assert_eq!(source.instance(),target.instance());
    assert_eq!(source.definition(),target.definition());
    assert_eq!(source.placement(),target.placement());
    assert_eq!(source.sample_grid(),target.sample_grid());
    assert_eq!(serde_json::to_value(source.audio(source.root_samples(),Default::default()).unwrap().spans).unwrap(),
               serde_json::to_value(target.audio(target.root_samples(),Default::default()).unwrap().spans).unwrap());
}
#[test]
fn finite_domain_actual_repeat_gap_preserve_definition_exact_bytes_and_drop_order() {
    for preserve in [false,true] {
        let plan=fixture(preserve);
        let mut domains=vec![plan.audio_domain_at(AudioSample(1),Default::default()).unwrap()];
        if !preserve {
            domains.push(plan.audio_domain_at(AudioSample(130),Default::default()).unwrap());
        }
        for selector in [AudioDefinitionSelector::Node{node:NodeId::new("tone").unwrap()},
                         AudioDefinitionSelector::RepeatGap{repeat:NodeId::new("repeat").unwrap()}] {
            let definition=plan.audio_definition(selector).unwrap();
            domains.push(definition.in_root_clock(AudioRootPlacement::new(ExactRatio::integer(-3),ExactRatio::integer(2),ExactRatio::ZERO..definition.exact_duration()).unwrap()).unwrap());
        }
        for source in domains {
            let mut admitted=policy(usize::MAX);
            let value=source.clone_shared_admitted(Default::default(),&mut admitted).unwrap();
            parity(&source,value.domain().unwrap());
            let peak=admitted.0.borrow().peak;
            assert!(peak>0&&admitted.0.borrow().work>0);
            assert_eq!(admitted.0.borrow().live,peak,"new copy has no hidden transient buffer");
            admitted.0.borrow_mut().domain=Some(Arc::downgrade(value.domain().unwrap()));
            drop(value); assert_eq!(admitted.0.borrow().live,0);
            let mut exact=policy(peak);
            let value=source.clone_shared_admitted(Default::default(),&mut exact).unwrap();
            assert_eq!(exact.0.borrow().peak,peak); drop(value);
            assert_eq!(exact.0.borrow().live,0);
            let mut short=policy(peak-1);
            assert!(source.clone_shared_admitted(Default::default(),&mut short).is_err());
            assert_eq!(short.0.borrow().live,0);
            let mut cancelled=policy(usize::MAX);
            cancelled.0.borrow_mut().fail_after=Some(3);
            assert!(source.clone_shared_admitted(Default::default(),&mut cancelled).is_err());
            assert_eq!(cancelled.0.borrow().live,0);
        }
    }
}
#[test]
fn joint_carriers_validate_every_issuer_before_callback_or_counter_change() {
    let plan=fixture(false);
    let domain=plan.audio_domain_at(AudioSample(1),Default::default()).unwrap();
    let owner=domain.instance().clone();
    let mut a=policy(usize::MAX);
    let mut b=policy(usize::MAX);
    let mut original=domain.clone_shared_admitted(Default::default(),&mut a).unwrap();
    let mut sound=plan.audio_sound_instance_context_admitted(&owner,Default::default(),&mut b).unwrap().into_shared(&mut b).unwrap();
    let before=(a.0.borrow().live,b.0.borrow().live,a.0.borrow().calls,b.0.borrow().calls);
    for issuer in [a.issuer(),b.issuer()] {
        let mut called=false;
        assert!(matches!(transfer_context_charges(issuer,Some(&mut original),Some(&mut sound),|_,_|called=true),Err(PlanError::AudioMetadataIssuerMismatch)));
        assert!(!called);
        assert_eq!((a.0.borrow().live,b.0.borrow().live,a.0.borrow().calls,b.0.borrow().calls),before);
    }
    let mut called=false;
    transfer_context_charges(a.issuer(),Some(&mut original),None,|left,right|{assert!(left.is_some()&&right.is_none());called=true;}).unwrap();
    assert!(called);
    transfer_context_charges(a.issuer(),None,None::<&mut AdmittedSoundContext<'_,usize,Token<'_>>>,|left,right|assert!(left.is_none()&&right.is_none())).unwrap();
    drop((original,sound)); assert_eq!(a.0.borrow().live,0); assert_eq!(b.0.borrow().live,0);
}
'''
(root/'candidate/crates/deadpan-plan/src/audio_context_sharing_tests.rs').write_text(out)
# Generic exact native tests gain an independent actual metadata oracle.
p=root/'candidate/crates/deadpan-audio/src/eq_admission/checks.rs'
s=p.read_text().replace('    type Graph;','    type Graph;\n\n    fn metadata_units(_plan: &\'plan RenderPlan) -> u64 { 0 }')
s=s.replace('    for headroom in [native - 1, native] {','    let metadata = H::metadata_units(plan);\n    let combined = native.checked_add(metadata).unwrap();\n    for headroom in [combined - 1, combined] {')
s=s.replace('if headroom < native {','if headroom < combined {')
s=s.replace('.resident, native)', '.resident, combined)')
s=s.replace('BASE + native)', 'BASE + combined)')
s=s.replace('        renderer.active_frames -= H::state(&graph, None).resident;\n        drop(graph);','        let retained = H::state(&graph, None).resident;\n        drop(graph);\n        renderer.active_frames -= retained;')
p.write_text(s)
p=root/'candidate/crates/deadpan-audio/src/shared_eq/admission_tests.rs'
s=p.read_text().replace('    type Graph = Graph<\'plan>;','''    type Graph = Graph<'plan>;

    fn metadata_units(plan: &'plan RenderPlan) -> u64 {
        original_metadata_units(plan)
    }''')
s+='''

// Actual final-sharing constructor, independent of numerical Node publication.
// It measures only newly admitted Original metadata, with the full native bound
// independently asserted by the common Harness.
pub(super) fn original_metadata_units(plan: &RenderPlan) -> u64 {
    let owner = crate::stages::authored_eq::eq_admission_fixture::owner(plan);
    let input = plan.audio_owner_input(&owner, AudioSample(128), Default::default()).unwrap();
    let cancelled = AtomicBool::new(false);
    let work = RefCell::new(ReadWork::default());
    let control = crate::stages::authored_eq::eq_admission_fixture::control(&cancelled, &work);
    let mut renderer = StageAudio::new(Arc::new(plan.clone()));
    let carrier = {
        let mut admission = sound_context_admission::Admission::new(&mut renderer, control);
        Context::finish_paid_owner_input_admitted(&input, input.owner(), AudioSample(128), control, &mut admission).unwrap()
    };
    let metadata = carrier.lease().unwrap().frames();
    assert!(metadata > 0);
    assert_eq!(work.borrow().sound_context_frames, metadata);
    drop(carrier);
    assert_eq!(work.borrow().sound_context_frames, 0);
    metadata
}
'''
# RenderPlan clone supported? Avoid need: StageAudio needs Arc<RenderPlan>, oracle signature Arc reference instead.
s=s.replace("fn metadata_units(plan: &'plan RenderPlan)", "fn metadata_units(plan: &'plan Arc<RenderPlan>)")
s=s.replace('pub(super) fn original_metadata_units(plan: &RenderPlan)', 'pub(super) fn original_metadata_units(plan: &Arc<RenderPlan>)')
s=s.replace('StageAudio::new(Arc::new(plan.clone()))','StageAudio::new(Arc::clone(plan))')
p.write_text(s)
# Keep common trait matching Arc oracle.
p=root/'candidate/crates/deadpan-audio/src/eq_admission/checks.rs';s=p.read_text().replace("fn metadata_units(_plan: &'plan RenderPlan)", "fn metadata_units(_plan: &'plan Arc<RenderPlan>)");p.write_text(s)
p=root/'candidate/crates/deadpan-audio/src/shared_eq/sound_admission_tests.rs';s=p.read_text()
s=s.replace('    let m = work.borrow().sound_context_frames;','    let original = super::admission_tests::original_metadata_units(&plan);\n    let m = work.borrow().sound_context_frames;')
s=s.replace('eq::BASE + eq::units() + m - 1','eq::BASE + eq::units() + original + m - 1')
s=s.replace('assert_eq!(renderer.active_frames, eq::BASE + eq::units());','assert_eq!(renderer.active_frames, eq::BASE + eq::units() + original);\n    assert_eq!(graph.resident, eq::units() + original);')
p.write_text(s)
