from pathlib import Path
import gzip
import hashlib
import json

scratch = Path(__file__).resolve().parent
repo = Path('/Users/michael/Code/deadpan')
destination = repo / 'tools/media-qualification/evidence/2026-10-28-original-sharing-budget'
assert not destination.exists(), 'Archive only once all runtime/media receipts are terminal'
prior = repo / 'tools/media-qualification/evidence/2026-10-28-sound-context-budget/inventory.json'
prior_sha256 = 'f6ed4675b8e8482961ff984da162c1848a620005014db989358478131fe9d18c'
assert hashlib.sha256(prior.read_bytes()).hexdigest() == prior_sha256
positive = ['sharing-build2', 'sharing-audio', 'sharing-plan', 'sharing-strict2',
            'sharing-final-build', 'sharing-final-audio', 'sharing-final-plan',
            'sharing-scoped-build', 'sharing-scoped-audio', 'sharing-scoped-plan',
            'sharing-stages', 'sharing-definition', 'sharing-scoped-stages', 'sharing-scoped-birth']
for label in positive:
    receipt = json.loads((scratch / (label + '.json')).read_text())
    assert receipt['exit_code'] == 0 and receipt['sources_unchanged'] and receipt['binaries_unchanged'], label
split = json.loads((scratch / 'sharing-split.json').read_text())
assert split['exit_code'] == 101 and split['sources_unchanged'] and split['binaries_unchanged']
assert '4 passed; 3 failed; 0 ignored' in (scratch / 'sharing-split.stdout').read_text()

allowed = {'.rs', '.json', '.py', '.md', '.patch', '.stdout', '.stderr', '.txt'}
excluded_names = {'qualification-draft.md'}
entries = []

# Archive task source, pins, review, and receipts, excluding binary copies and drafts.
for path in sorted(scratch.rglob('*')):
    if not path.is_file() or path.suffix not in allowed or path.name in excluded_names:
        continue
    relative = path.relative_to(scratch)
    data = path.read_bytes()
    if path.suffix == '.json':
        value = json.loads(data)
        if isinstance(value, dict) and 'command' in value and 'started_at' in value:
            assert 'exit_code' in value and value['sources_unchanged'] and value['binaries_unchanged'], str(path)
    record = destination / 'records/original-sharing' / relative
    record = record.with_name(record.name + '.gz')
    record.parent.mkdir(parents=True, exist_ok=True)
    compressed = gzip.compress(data, mtime=0)
    record.write_bytes(compressed)
    entries.append({
        'path': str(record.relative_to(destination)),
        'bytes': len(compressed),
        'sha256': hashlib.sha256(compressed).hexdigest(),
        'expanded_bytes': len(data),
        'expanded_sha256': hashlib.sha256(data).hexdigest(),
    })

# Include the bounded related design/review only; do not archive the later query implementation.
related = Path('/tmp/deadpan-original-admission-next-2026-10-28')
for path in sorted(related.rglob('*')):
    if not path.is_file() or path.suffix not in allowed:
        continue
    relative = path.relative_to(related)
    data = path.read_bytes()
    record = destination / 'records/original-admission-design' / relative
    record = record.with_name(record.name + '.gz')
    record.parent.mkdir(parents=True, exist_ok=True)
    compressed = gzip.compress(data, mtime=0)
    record.write_bytes(compressed)
    entries.append({
        'path': str(record.relative_to(destination)),
        'bytes': len(compressed),
        'sha256': hashlib.sha256(compressed).hexdigest(),
        'expanded_bytes': len(data),
        'expanded_sha256': hashlib.sha256(data).hexdigest(),
    })

manifest = {
    'schema_version': 1,
    'base_revision': (scratch / 'base-revision.txt').read_text().strip(),
    'scope': (
        'Final Original-sharing metadata copy and retained Arc-shell admission, '
        'plus joint Original/current-sound lease publication. Includes strategy-trait '
        'lint correction and full AudioBlock parity-test correction. Source query/capture, '
        'retained inner graph, full Root/Domain/Core transient closure, batching, and cold proof remain out of scope.'
    ),
    'prior_current_sound_inventory': {
        'inventory_sha256': prior_sha256,
        'path': '../2026-10-28-sound-context-budget/inventory.json',
        'note': 'Reference by hash only; do not duplicate the prior inventory.'
    },
    'related_design': 'Original admission through final sharing; excludes subsequent query/capture implementation.',
    'files': entries,
}
manifest_path = destination / 'inventory.json'
manifest_path.write_text(json.dumps(manifest, indent=2) + '\n')

# Verification is part of the eventual archive run; this script is intentionally not run during review.

stored = expanded = 0
for row in entries:
    packed = (destination / row['path']).read_bytes()
    plain = gzip.decompress(packed)
    assert len(packed) == row['bytes'] and hashlib.sha256(packed).hexdigest() == row['sha256']
    assert len(plain) == row['expanded_bytes'] and hashlib.sha256(plain).hexdigest() == row['expanded_sha256']
    stored += len(packed)
    expanded += len(plain)
print(json.dumps({'files': len(entries), 'stored_bytes': stored, 'expanded_bytes': expanded,
                  'inventory_sha256': hashlib.sha256(manifest_path.read_bytes()).hexdigest()}))
