from pathlib import Path
import json,hashlib
s=Path(__file__).resolve().parent
labels=['sharing-build','sharing-build2','sharing-audio','sharing-plan','sharing-strict','sharing-strict2','sharing-final-build','sharing-final-audio','sharing-final-plan','sharing-scoped-build','sharing-scoped-audio','sharing-scoped-plan','sharing-stages','sharing-split','sharing-definition','sharing-scoped-stages','sharing-scoped-birth']
rows=[]
for label in labels:
 a=json.loads((s/(label+'.json')).read_text())
 assert a['sources_unchanged'] and a['binaries_unchanged'],label
 assert a['exit_code']==({'sharing-build':101,'sharing-strict':1,'sharing-split':101}.get(label,0)),label
 rows.append({'label':label,'exit_code':a['exit_code'],'seconds':a['seconds'],'source_inputs':len(a['source_before']),'receipt_sha256':hashlib.sha256((s/(label+'.json')).read_bytes()).hexdigest()})
for label in ['sharing-final-build','sharing-scoped-build']:
 a=json.loads((s/(label+'.json')).read_text())
 for p,pin in a['source_after'].items():
  b=Path(p).read_bytes()
  assert len(b)==pin['bytes'] and hashlib.sha256(b).hexdigest()==pin['sha256'],p
for label,expected in [('sharing-final-plan',566),('sharing-scoped-plan',553)]:
 data=[json.loads(x) for x in (s/(label+'.stdout')).read_text().splitlines()]
 assert len(data)==29 and all(x['exit_code']==0 for x in data)
 results=[r for a in data for r in a['test_results']]
 assert sum(int(x[1]) for x in results)==expected
 assert all(all(int(x[i])==0 for i in [2,3,5]) for x in results)
(s/'final-audit.json').write_text(json.dumps({'all17_terminal':True,'final_sources_unchanged_now':True,'receipts':rows},indent=2)+'\n')
print('17 terminal receipts; final main/scoped source pins still match.')
