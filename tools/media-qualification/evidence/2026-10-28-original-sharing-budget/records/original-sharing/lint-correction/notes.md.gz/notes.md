# Lint-only structural correction

The private FinalOriginal enum is replaced by a typed, allocation-free final
sharing strategy. LegacyOriginalSharing is a unit value; admitted strategy stores
only the existing WorkControl and mutable admission reference. Associated Output
keeps the actual retained/domain callback returns strongly typed.

The common finish_paid_owner_input_with body retains the same probe/query/
boundary order and invokes retained(self,value) or domain(self,&Domain) at the
same final return position. Admitted query_limits is still acquired only at that
selected final position, with the same unmetered default behavior. No Box, heap
allocation, extra query, inspection charge, early transfer or numeric change.

ResolvedOriginal's unnecessary generic parameter bounds move out of the struct;
the named OriginalResult alias describes the same return type. This alias
requires no unenforced type-alias bounds or lint suppression.

Scoped rustfmt parsed both candidates. No Cargo/rustc/live/scoped/index writes.
Before snapshots are current live bytes after parent's first runtime correction.
The initial candidate/pins/task.patch are unchanged.
