from pathlib import Path
import hashlib,json,difflib,shutil
r=Path('/tmp/deadpan-original-sharing-budget-2026-10-28')
a=r/'staging-audit'
repo=Path('/Users/michael/Code/deadpan')
scope=Path('/tmp/deadpan-query-groundwork-2026-10-26/scoped')
sha=lambda b:hashlib.sha256(b).hexdigest()
owned=json.loads((r/'candidate-pins.json').read_text())
parts=[];manifest=[]
for item in owned:
 path=Path(item['path']);main=(repo/path).read_bytes();scoped=(scope/path).read_bytes()
 head=(a/'head'/path).read_bytes() if not item['new'] else b''
 for name,data in [('main',main),('proposed-index',scoped)]:
  p=a/name/path;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data)
 if not item['new']:
  p=a/'apply-check'/path;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(head)
 manifest.append({'path':str(path),'new':item['new'],'HEAD_sha256':None if item['new'] else sha(head),'main_sha256':sha(main),'scoped_sha256':sha(scoped),'proposed_index_sha256':sha(scoped),'main_equals_scoped':main==scoped,'main_bytes':len(main),'scoped_bytes':len(scoped)})
 parts.extend(difflib.unified_diff(head.decode().splitlines(True),scoped.decode().splitlines(True),fromfile='/dev/null' if item['new'] else 'a/'+str(path),tofile='b/'+str(path)))
(a/'task-staging.patch').write_text(''.join(parts))
(a/'task-file-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
mainfiles=set(json.loads((r/'source-files.json').read_text()))
scopefiles=set(json.loads((r/'scoped-source-files.json').read_text()))
assert len(mainfiles)==1438 and len(scopefiles)==1209
common=sorted(mainfiles&scopefiles);differing=[];allpins=[]
taskpaths={item['path'] for item in owned}
for name in common:
 mb=(repo/name).read_bytes();sb=(scope/name).read_bytes()
 entry={'path':name,'main_sha256':sha(mb),'scoped_sha256':sha(sb),'equal':mb==sb,'task_owned':name in taskpaths}
 allpins.append(entry)
 if mb!=sb:
  differing.append(entry)
  p=a/'inherited-overlay-diffs'/Path(name+'.diff');p.parent.mkdir(parents=True,exist_ok=True)
  p.write_text(''.join(difflib.unified_diff(sb.decode().splitlines(True),mb.decode().splitlines(True),fromfile='scoped/'+name,tofile='main/'+name)))
(a/'all-common-source-pins.json').write_text(json.dumps(allpins,indent=2)+'\n')
(a/'full-source-overlays.json').write_text(json.dumps({'main_source_count':len(mainfiles),'scoped_source_count':len(scopefiles),'common_count':len(common),'main_only':sorted(mainfiles-scopefiles),'scoped_only':sorted(scopefiles-mainfiles),'common_differences':differing},indent=2)+'\n')
strict=json.loads((r/'sharing-strict2.json').read_text())
drift=[]
for path,entry in strict['source_after'].items():
 p=Path(path)
 if sha(p.read_bytes())!=entry['sha256']: drift.append(str(p))
assert not drift,drift
(a/'strict-source-drift.json').write_text(json.dumps({'reference':'sharing-strict2.json source_after','reference_exit_code':strict['exit_code'],'checked':len(strict['source_after']),'drift':drift},indent=2)+'\n')
# Verify inherited source overlays outside this task match the first corrected build.
earlier=json.loads((r/'sharing-build2.json').read_text())['source_after']
outside=[]
for path,entry in earlier.items():
 rel=str(Path(path).relative_to(repo))
 if rel in taskpaths: continue
 if sha(Path(path).read_bytes())!=entry['sha256']:outside.append(rel)
assert not outside,outside
(a/'outside-task-source-drift.json').write_text(json.dumps({'reference':'sharing-build2.json source_after','excluded_task_files':len(taskpaths),'outside_task_drift':outside},indent=2)+'\n')
for name in ['task-staging.patch','task-file-manifest.json','full-source-overlays.json','all-common-source-pins.json']:
 print(name,sha((a/name).read_bytes()))
print('task overlay differences',[i['path'] for i in manifest if not i['main_equals_scoped']])
print('other common overlay differences',[i['path'] for i in differing if not i['task_owned']])
