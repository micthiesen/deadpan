# Task-only staging audit

Base HEAD 02cd21afc219e8235d0ab8229f0f1a821c2754c5, confirmed by read-only
git rev-parse. All snapshots and writes here are scratch only. Real main/scoped
sources and real Git index were untouched.

task-staging.patch is generated from the exact14 HEAD blobs to final scoped
bytes plus4 new paths confirmed absent from HEAD. It includes parent's
DomainAudioBlock full-equality test correction, corrected docs newline and the
typed-sharing strategy/return-alias lint delta. It contains18 task files only.

git apply --check passed in the scratch apply-check directory containing the
HEAD blobs. A following scratch git apply passed; every resulting file exactly
matches both proposed-index and scoped-final SHA. No actual Git repository or
index was created/modified for this check. apply-receipt.json records the result.

The proposed index equals scoped final for ALL18 files. Four task files retain
different inherited main overlays:
- shared_eq.rs: existing Original memo/cache and family Graph fields/logic,
  including main-only original_inputs.clear(self) in ordered cleanup.
- shared_eq/admission_tests.rs and shared_eq/sound_admission_tests.rs: existing
  three extra main Graph initializer fields.
- plan.rs: existing sound correspondence/assets/delivery forest and related code.

These are removed from the staging representation by taking the final scoped
bytes against HEAD, rather than by manually deleting lines from main. No task
hunk was dropped. Main final bytes are separately pinned for every task file.

Full source sets: main1438, scoped1209. full-source-overlays.json records all
common differences and each side-only path. all-common-source-pins.json records
every common path's SHA and whether task-owned. inherited-overlay-diffs contains
the literal text difference of every differing common source.28 other inherited
common files differ; they are outside this patch. Their live bytes are unchanged
since the first corrected build, per outside-task-source-drift.json.

All1438 main source inputs still match sharing-strict2.json source_after
(strict2 exit0), per strict-source-drift.json. Initial task.patch and
candidate-pins.json remain byte-identical to first freeze; corrections have their
own artifacts and this final staging snapshot.

Key hashes:
- task-staging.patch:
  bdedd2f4d4ab3b5b5c7ccdc27a445bbf41b2f1306f3db7955e6afad81163e32d
- task-file-manifest.json:
  f9dae615a74880ab5055d3e781041b92927661bc7b4178c6d689b8877f78f632
- full-source-overlays.json:
  0bf11e80eadc3a8052b072ef8a53449fa1685a975adf2f2d748f0a0814f33b9e
- all-common-source-pins.json:
  915f428f5c5f235fc7962d99b58e36d2e84e3d7d160facbbc005f97fc8aacb0a
