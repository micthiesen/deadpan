from pathlib import Path
import json,subprocess,sys
s=Path(__file__).resolve().parent
receipt=json.loads((s/'sharing-stages.json').read_text())
assert receipt['exit_code']==0 and receipt['sources_unchanged'] and receipt['binaries_unchanged']
steps=[
 ('main','sharing-split','sharing-final-build-audio-stages',['general_split_sound','--test-threads=1','--nocapture'],101),
 ('main','sharing-definition','sharing-final-build-audio-audio-definition',['--test-threads=4'],0),
 ('scoped','sharing-scoped-stages','sharing-scoped-build-audio-stages',['--test-threads=4'],0),
 ('scoped','sharing-scoped-birth','sharing-scoped-build-audio-audio-definition',['new_group_birth::','--test-threads=1','--nocapture'],0),
]
results=[]
for kind,label,binary,args,expected in steps:
 runner=s/('run.py' if kind=='main' else 'run_scoped.py')
 executable=s/binary
 command=['python',str(runner),'--binary',str(executable),'--binary',str(Path(__file__).resolve()),label,'--',str(executable),*args]
 code=subprocess.run(command).returncode
 receipt=json.loads((s/(label+'.json')).read_text())
 assert receipt['exit_code']==code and receipt['sources_unchanged'] and receipt['binaries_unchanged']
 results.append({'label':label,'exit_code':code,'expected_exit':expected})
 print(json.dumps({'completed':label,'exit_code':code,'expected_exit':expected}),flush=True)
(s/'media-sequence.json').write_text(json.dumps({'all_terminal':True,'results':results},indent=2)+'\n')
raise SystemExit(0 if all(r['exit_code']==r['expected_exit'] for r in results) else 1)
