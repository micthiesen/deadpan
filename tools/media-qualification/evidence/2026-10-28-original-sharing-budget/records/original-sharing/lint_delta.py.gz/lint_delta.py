from pathlib import Path
import hashlib,json,difflib
r=Path('/tmp/deadpan-original-sharing-budget-2026-10-28/lint-correction')
repo=Path('/Users/michael/Code/deadpan')
paths=['crates/deadpan-audio/src/authored_eq.rs','crates/deadpan-audio/src/shared_eq/node_description.rs']
for path in paths:
    s=(repo/path).read_text()
    for d in ['before','candidate']:
        p=r/d/path;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(s)
p=r/'candidate'/paths[0];s=p.read_text()
old="""enum FinalOriginal<'input, 'plan> {
    Retained(deadpan_plan::AudioOwnerRetainedInput<'plan>),
    Domain(&'input deadpan_plan::AudioDomain<'plan>),
}
"""
new="""trait FinalOriginalSharing<'plan> {
    type Output;

    fn retained(self, value: AudioOwnerRetainedInput<'plan>) -> Result<Self::Output, StageAudioError>;
    fn domain(self, value: &AudioDomain<'plan>) -> Result<Self::Output, StageAudioError>;
}

struct LegacyOriginalSharing;

impl<'plan> FinalOriginalSharing<'plan> for LegacyOriginalSharing {
    type Output = Context<'plan>;

    fn retained(self, value: AudioOwnerRetainedInput<'plan>) -> Result<Self::Output, StageAudioError> {
        Ok(Context::Retained(Arc::new(value)))
    }

    fn domain(self, value: &AudioDomain<'plan>) -> Result<Self::Output, StageAudioError> {
        Ok(Context::Domain(Arc::new(value.clone())))
    }
}

struct AdmittedOriginalSharing<'admission, 'work, A> {
    control: WorkControl<'work>,
    admission: &'admission mut A,
}

impl<A> AdmittedOriginalSharing<'_, '_, A>
where
    A: deadpan_plan::AudioSoundContextAdmission<Error = StageAudioError>,
{
    fn limits(&self) -> Result<deadpan_plan::AudioQueryLimits, StageAudioError> {
        if A::METERED {
            self.control.query_limits()
        } else {
            Ok(deadpan_plan::AudioQueryLimits::default())
        }
    }
}

impl<'plan, A> FinalOriginalSharing<'plan> for AdmittedOriginalSharing<'_, '_, A>
where
    A: deadpan_plan::AudioSoundContextAdmission<Error = StageAudioError>,
{
    type Output = deadpan_plan::AdmittedOriginalContext<'plan, A::Issuer, A::Lease>;

    fn retained(self, value: AudioOwnerRetainedInput<'plan>) -> Result<Self::Output, StageAudioError> {
        value.into_shared_admitted(self.limits()?, self.admission)
    }

    fn domain(self, value: &AudioDomain<'plan>) -> Result<Self::Output, StageAudioError> {
        value.clone_shared_admitted(self.limits()?, self.admission)
    }
}
"""
assert old in s;s=s.replace(old,new)
old="""        Self::finish_paid_owner_input_with(input, owner, at, control, |value| {
            Ok(match value {
                FinalOriginal::Retained(value) => Self::Retained(Arc::new(value)),
                FinalOriginal::Domain(value) => Self::Domain(Arc::new(value.clone())),
            })
        })"""
new="""        Self::finish_paid_owner_input_with(input, owner, at, control, LegacyOriginalSharing)"""
assert old in s;s=s.replace(old,new)
old="""        Self::finish_paid_owner_input_with(input, owner, at, control, |value| {
            let limits = if A::METERED {
                control.query_limits()?
            } else {
                deadpan_plan::AudioQueryLimits::default()
            };
            match value {
                FinalOriginal::Retained(value) => value.into_shared_admitted(limits, admission),
                FinalOriginal::Domain(value) => value.clone_shared_admitted(limits, admission),
            }
        })"""
new="""        Self::finish_paid_owner_input_with(
            input,
            owner,
            at,
            control,
            AdmittedOriginalSharing { control, admission },
        )"""
assert old in s;s=s.replace(old,new)
s=s.replace("fn finish_paid_owner_input_with<'input, T>(\n        input: &'input deadpan_plan::AudioOwnerInput<'plan>,","fn finish_paid_owner_input_with<S: FinalOriginalSharing<'plan>>(\n        input: &deadpan_plan::AudioOwnerInput<'plan>,")
s=s.replace("share: impl FnOnce(FinalOriginal<'input, 'plan>) -> Result<T, StageAudioError>,\n    ) -> Result<T, StageAudioError>","share: S,\n    ) -> Result<S::Output, StageAudioError>")
s=s.replace("share(FinalOriginal::Retained(retained))","share.retained(retained)")
s=s.replace("share(FinalOriginal::Domain(input.context()))","share.domain(input.context())")
p.write_text(s)
p=r/'candidate'/paths[1];s=p.read_text()
s=s.replace("struct ResolvedOriginal<'plan, I: Copy + Eq, L>", "struct ResolvedOriginal<'plan, I, L>")
anchor="""    carrier: Option<deadpan_plan::AdmittedOriginalContext<'plan, I, L>>,
}
"""
assert s.count(anchor)==1
s=s.replace(anchor,anchor+"\ntype OriginalResult<'plan, I, L> = Result<Option<ResolvedOriginal<'plan, I, L>>, StageAudioError>;\n")
s=s.replace(") -> Result<Option<ResolvedOriginal<'plan, A::Issuer, A::Lease>>, StageAudioError>",") -> OriginalResult<'plan, A::Issuer, A::Lease>")
p.write_text(s)
