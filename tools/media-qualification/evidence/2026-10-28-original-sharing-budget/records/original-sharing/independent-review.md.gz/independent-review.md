# Independent review: final Original-sharing admission

Reviewed frozen `task.patch` (SHA `06e6881ff868f6b3762133799643ce5f3fe6f3fac98a82033e355bb93e1a29e0`), notes, pins, candidate source, and the final test/lint corrections. The review was read-only; no Cargo, rustc, or Git commands were run.

## Findings

No concrete correctness finding in the reviewed slice.

## Checked behavior

- `AudioDomain::clone_shared_admitted` reconstructs all fields of `AudioDomain` and `AudioWalkSeed`; it copies the four seed Vecs plus the nested instance repeat Vec, reserves before each buffer and identity clone, and separately reserves the Arc shell. Scalar/range fields are copied directly. Scope and returned-carrier fields place owned values before the lease, so failure/drop releases buffers and Arcs before returning admission.
- `AudioOwnerRetainedInput::into_shared_admitted` moves the retained graph into one newly admitted Arc shell. It does not purport to cover the already-built inner graph.
- The strategy-trait lint correction replaces the enum-plus-closure with private `LegacyOriginalSharing` and `AdmittedOriginalSharing` implementations. Their two final-sharing operations preserve the prior legacy `Arc::new(value)` / `Arc::new(value.clone())` and admitted calls. The common probe, its work charge, optional retained owners query, and boundary selection remain in one body. The `OriginalResult` alias is type-only.
- Root/Domain candidates reuse the actual selected query result and captured input; retained incoming contexts keep their prior owners query and direct owner-context behavior. The absent-selection case does not request fresh capture limits or synthesize work.
- The actual numerical description retains both Original and sound carriers. The final transfer checks both carrier issuers; the concrete callback also preflights ledger pointers, checked lease sum, and lane subtraction before graph publication. Node capacity is reserved beforehand, then publication and counter update are followed by an arithmetic-free joint commit. The `Description`/carrier field order preserves value-before-lease drops on failure; successful publication moves owning contexts into the graph before disarming leases.
- The PCM parity-test correction now compares the complete `AudioBlock` after the existing PCM-bit equality assertion. That adds coverage for dependencies, suppression, and relative depth rather than weakening those checks. The corrected admission module documentation expresses three separate lines instead of literal `\\n` text.
- Existing query/probe decisions and native-work bounds appear unchanged. The tests include exact/one-short Domain copy and accepted-Retained shell checks, cancellation cleanup, query parity, mismatched issuers, and a shared EQ admission harness retaining the independent native bound of 266241.

## Scope and verification limits

The patch expressly excludes source Input/query/capture construction and retained inner-graph allocations. This review does not treat those exclusions as defects in this final-sharing slice, and this slice must not be described as a full Original/Root/Domain/Core transient-peak proof. Parent reported final Audio/Plan suites and strict lint passing after the cited corrections; I did not run those checks.
