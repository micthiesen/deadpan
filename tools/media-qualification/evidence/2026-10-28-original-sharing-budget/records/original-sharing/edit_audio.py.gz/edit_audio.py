from pathlib import Path
r=Path('/tmp/deadpan-original-sharing-budget-2026-10-28/candidate/crates/deadpan-audio/src')
p=r/'authored_eq.rs';s=p.read_text();anchor='impl<\'plan> Context<\'plan> {'
assert s.count(anchor)==1
s=s.replace(anchor,'''enum FinalOriginal<'input, 'plan> {
    Retained(deadpan_plan::AudioOwnerRetainedInput<'plan>),
    Domain(&'input deadpan_plan::AudioDomain<'plan>),
}

'''+anchor,1)
start=s.index('        let probe = input.retained_probe_at(',s.index('    pub(super) fn finish_paid_owner_input('))
end=s.index('\n    }\n}',start)
old=s[start:end]
body=old.replace('return Ok(Self::Retained(Arc::new(retained)));','return share(FinalOriginal::Retained(retained));',1)
body=body.replace('Ok(Self::Domain(Arc::new(input.context().clone())))','share(FinalOriginal::Domain(input.context()))',1)
new='''        Self::finish_paid_owner_input_with(input, owner, at, control, |value| {
            Ok(match value {
                FinalOriginal::Retained(value) => Self::Retained(Arc::new(value)),
                FinalOriginal::Domain(value) => Self::Domain(Arc::new(value.clone())),
            })
        })
    }

    pub(super) fn finish_paid_owner_input_admitted<A>(
        input: &deadpan_plan::AudioOwnerInput<'plan>,
        owner: &AudioOwnerClock<'plan>,
        at: AudioSample,
        control: WorkControl<'_>,
        admission: &mut A,
    ) -> Result<deadpan_plan::AdmittedOriginalContext<'plan, A::Issuer, A::Lease>, StageAudioError>
    where A: deadpan_plan::AudioSoundContextAdmission<Error = StageAudioError> {
        Self::finish_paid_owner_input_with(input, owner, at, control, |value| {
            let limits = if A::METERED { control.query_limits()? }
                else { deadpan_plan::AudioQueryLimits::default() };
            match value {
                FinalOriginal::Retained(value) => value.into_shared_admitted(limits, admission),
                FinalOriginal::Domain(value) => value.clone_shared_admitted(limits, admission),
            }
        })
    }

    // The actual probe, owners query and boundary decision are shared once.
    // Only the final sharing operation differs at its original return site.
    fn finish_paid_owner_input_with<'input, T>(
        input: &'input deadpan_plan::AudioOwnerInput<'plan>,
        owner: &AudioOwnerClock<'plan>,
        at: AudioSample,
        control: WorkControl<'_>,
        share: impl FnOnce(FinalOriginal<'input, 'plan>) -> Result<T, StageAudioError>,
    ) -> Result<T, StageAudioError> {
'''+body
s=s[:start]+new+s[end:];p.write_text(s)
p=r/'shared_eq/node_description.rs';s=p.read_text()
s=s.replace('    pub(super) sound: Option<deadpan_plan::AdmittedSoundContext<\'plan, I, L>>,','    pub(super) original: Option<deadpan_plan::AdmittedOriginalContext<\'plan, I, L>>,\n    pub(super) sound: Option<deadpan_plan::AdmittedSoundContext<\'plan, I, L>>,',1)
needle='''    let original = if let Some(original) =
        original_context(plan, &incoming.original, &key, range, at, control)?
    {'''
replacement='''    let original = if let Some(original) =
        original_context_admitted(plan, &incoming.original, &key, range, at, control, admission)?
    {'''
assert needle in s;s=s.replace(needle,replacement,1)
old='''        Context::Domain(Arc::clone(
            sound
                .as_ref()
                .expect("created fallback")
                .processing_domain()
                .expect("processing Domain"),
        ))'''
new='''        ResolvedOriginal {
            context: Context::Domain(Arc::clone(
                sound.as_ref().expect("created fallback")
                    .processing_domain().expect("processing Domain"))),
            carrier: None,
        }'''
assert old in s;s=s.replace(old,new,1)
s=s.replace('''                original,
                sounds:''','''                original: original.context,
                sounds:''',1)
s=s.replace('''        sound,
    })
}''','''        original: original.carrier,
        sound,
    })
}''',1)
start=s.index("fn original_context<'plan>(")
s=s[:start]+'''struct ResolvedOriginal<'plan, I: Copy + Eq, L> {
    context: Context<'plan>,
    carrier: Option<deadpan_plan::AdmittedOriginalContext<'plan, I, L>>,
}

#[cfg(test)]
fn original_context<'plan>(
    plan: &'plan RenderPlan,
    incoming: &Context<'plan>,
    key: &OwnerKey,
    range: Range<AudioSample>,
    at: AudioSample,
    control: WorkControl<'_>,
) -> Result<Option<Context<'plan>>, StageAudioError> {
    Ok(original_context_admitted(plan, incoming, key, range, at, control,
        &mut sound_context_admission::Unmetered)?.map(|value| value.context))
}

'''+s[start:]
# Replace only actual production definition after the cfg wrapper.
start=s.index("fn original_context<'plan>(", s.index('#[cfg(test)]\\nfn original_context')+1) if False else s.index("fn original_context<'plan>(",s.index('struct ResolvedOriginal'))
start=s.index("fn original_context<'plan>(",start+1)
tail=s[start:].replace("fn original_context<'plan>(", "fn original_context_admitted<'plan, A>(",1)
tail=tail.replace('''    control: WorkControl<'_>,
) -> Result<Option<Context<'plan>>, StageAudioError> {''','''    control: WorkControl<'_>,
    admission: &mut A,
) -> Result<Option<ResolvedOriginal<'plan, A::Issuer, A::Lease>>, StageAudioError>
where A: deadpan_plan::AudioSoundContextAdmission<Error = StageAudioError> {''',1)
tail=tail.replace('''                Ok(Some(incoming.owner_context(plan, &clock, at, control)?))''','''                Ok(Some(ResolvedOriginal {
                    context: incoming.owner_context(plan, &clock, at, control)?,
                    carrier: None,
                }))''',1)
old='''        Ok(Some(Context::finish_paid_owner_input(
            &input,
            input.owner(),
            at,
            control,
        )?))'''
new='''        let carrier = Context::finish_paid_owner_input_admitted(
            &input, input.owner(), at, control, admission)?;
        let context = if let Some(domain) = carrier.domain() {
            Context::Domain(Arc::clone(domain))
        } else {
            Context::Retained(Arc::clone(carrier.retained().expect("shared retained")))
        };
        Ok(Some(ResolvedOriginal { context, carrier: Some(carrier) }))'''
assert old in tail;tail=tail.replace(old,new,1)
s=s[:start]+tail;p.write_text(s)
p=r/'sound_context_admission.rs';s=p.read_text()
old='''    /// Called only after owning values and this same charge reach Graph.
    pub(super) fn commit(&mut self) {
        self.ledger.borrow_mut().sound_context_frames -= self.frames;
        self.frames = 0;
    }
'''
assert old in s;s=s.replace(old,'',1)
needle="impl Drop for Lease<'_> {"
new='''/// All identity/sum/subtraction checks precede Graph publication.
pub(super) struct JointTransfer<'work> {
    ledger: &'work RefCell<ReadWork>,
    remaining: u64,
}
pub(super) fn preflight_transfer<'work>(
    control: WorkControl<'work>,
    original: Option<&Lease<'work>>,
    sound: Option<&Lease<'work>>,
) -> Result<JointTransfer<'work>, StageAudioError> {
    let mut total = 0_u64;
    for lease in [original, sound].into_iter().flatten() {
        if !std::ptr::eq(lease.ledger, control.work) {
            return Err(PlanError::AudioMetadataIssuerMismatch.into());
        }
        total = total.checked_add(lease.frames).ok_or(StageAudioError::Range)?;
    }
    let remaining = control.work.borrow().sound_context_frames.checked_sub(total)
        .ok_or(StageAudioError::Range)?;
    Ok(JointTransfer { ledger: control.work, remaining })
}
impl JointTransfer<'_> {
    /// The no-fail publication tail: no arithmetic, reservation or callbacks.
    pub(super) fn commit(self, original: Option<&mut Lease<'_>>, sound: Option<&mut Lease<'_>>) {
        self.ledger.borrow_mut().sound_context_frames = self.remaining;
        if let Some(lease) = original { lease.frames = 0; }
        if let Some(lease) = sound { lease.frames = 0; }
    }
}

'''+needle
s=s.replace(needle,new,1);p.write_text(s)
p=r/'shared_eq.rs';s=p.read_text()
old='''        let metadata_frames = description
            .sound
            .as_ref()
            .and_then(|sound| sound.lease())
            .map_or(0, sound_context_admission::Lease::frames);'''
new='''        let sound_frames = description.sound.as_ref().and_then(|value| value.lease())
            .map_or(0, sound_context_admission::Lease::frames);
        let original_frames = description.original.as_ref().and_then(|value| value.lease())
            .map_or(0, sound_context_admission::Lease::frames);
        let metadata_frames = sound_frames.checked_add(original_frames)
            .ok_or(StageAudioError::Range)?;'''
assert old in s;s=s.replace(old,new,1)
old='''        if description
            .sound
            .as_ref()
            .is_some_and(|sound| sound.issuer() != expected_issuer)
        {'''
new='''        if description.sound.as_ref().is_some_and(|value| value.issuer() != expected_issuer)
            || description.original.as_ref().is_some_and(|value| value.issuer() != expected_issuer)
        {'''
assert old in s;s=s.replace(old,new,1)
s=s.replace('''        let values = &mut description.values;
        let publish = |charge: Option<&mut sound_context_admission::Lease<'_>>| {''','''        let transfer = sound_context_admission::preflight_transfer(
            control,
            description.original.as_ref().and_then(|value| value.lease()),
            description.sound.as_ref().and_then(|value| value.lease()),
        )?;
        let values = &mut description.values;
        let publish = |original: Option<&mut sound_context_admission::Lease<'_>>,
                       sound: Option<&mut sound_context_admission::Lease<'_>>| {''',1)
old='''            if let Some(charge) = charge {
                charge.commit();
            }
        };
        if let Some(sound) = description.sound.as_mut() {
            sound.transfer_charge(expected_issuer, publish)?;
        } else {
            publish(None);
        }'''
new='''            transfer.commit(original, sound);
        };
        deadpan_plan::transfer_context_charges(
            expected_issuer, description.original.as_mut(), description.sound.as_mut(), publish,
        )?;'''
assert old in s;s=s.replace(old,new,1);p.write_text(s)
