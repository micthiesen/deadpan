# Next Original admission slice: actual final context sharing

Read-only recommendation, 2026-10-28. Live source pins are in source-pins.json.
No repository files, Cargo/rustc, Git state, provider or native operation was
changed/executed. ripwire.txt records the initial bounded navigation. This is
an implementation contract, not evidence that admission or tests already exist.

## Preferred bounded slice

Admit final owned Context sharing inside the EXISTING
authored_eq::Context::finish_paid_owner_input, on both return branches:

* authored_eq.rs:114: Arc::new(retained) after the same retained owner query
  and boundary match. Reserve the ArcInner<Retained> allocation before Arc::new;
  MOVE the existing retained graph, do not clone, reconstruct or estimate it.
  Only the new Arc allocation is covered here, not the graph already built.
* authored_eq.rs:117: Arc::new(input.context().clone()) after the same None or
  unmatched retained lookup. Replace ONLY this clone/Arc expression with a
  field-exhaustive admitted shared Domain clone. Cover its new Vec buffers,
  owning identity edges and Arc allocation before each creation. This is a
  closed finite leaf clone, not another structural query or binding walk.

Treat this as one final-sharing milestone. The Retained branch makes it
relevant to reached Split paths even when the Domain-copy branch is uncommon.
If scope must be reduced further, the Retained Arc wrapper is the smallest
literal actual allocation site, but explicitly buys no admission of its
already constructed inner graph. Do not advertise this as full Original peak
admission or as a work-limit optimization.

Keep one actual candidates query/capture, one retained probe (including None
work), the same optional retained owner query, same boundary decision, same
point-grid/root-grid semantics and foreign-plan guards. No cache, dry-run,
provider/native planning, retry, raised cap, weight change or work refund.

## Branch relevance: measured facts versus unknown

Current node_description_tests.rs:29
root_and_actual_domain_descriptions_keep_literal_context_stop_and_kind
constructs the real helper from both incoming Root and Domain and asserts
returned Domain over EQ/Wet and original_only modes. The fixture is an
unbound root Sequence/Tone, so this is an actual ordinary production branch,
not an unreachable fallback. The current None-probe test at :269 checks
probe.input().is_none() with probe.work()==9 independently before the helper.

The current retained fixture and real Context::owner_context call around
node_description_tests.rs:400-431 assert accepted Context::Retained; incoming
Retained tests around :238 separately prove the immediate Arc clone path.

Historical diagnostics already on disk:
- placement-profile selected: input.work calls42; retained.work calls42;
  retained owners.work calls42.
- placement-profile nested: the same42/42/42.
- input-index-profile allowner: the same62/62/62.
Exact source snapshots in those copied trees show retained.work is inside
if let Some(retained), owners.work immediately follows. Thus every reached
Root/Domain input in those profiles produced Some. These counters do NOT
record the later boundary-match predicate, so do NOT infer accepted
Retained counts or a Domain-return count. They also predate candidates and
honest None-probe billing. No current branch-frequency diagnostic was run.
The new final-sharing pair covers both possible returns; Domain clone alone
cannot honestly be called the dominant remaining Split allocation.

## Why the Domain clone is finite and closed

audio_domain.rs:99-141 explicitly declares the entire owning shape.
AudioDomain has borrowed plan; AudioWalkSeed; scalar samples/visible ranges;
InstancePath; optional AudioRootPlacement. No nested Domain, processing graph,
ResolvedAudioBinding, raw decoder or source authority is stored in it.

Exhaustively destructure both structs, without '..', so field additions fail
compilation at the clone helper. Copy these scalar fields verbatim:
plan, seed.bypass_binding (BindingTarget::Node/Gap usize), node, transform,
grid, extent, envelope, suppress_entry_editorial, root samples/visible,
placement (AudioRootPlacement: three scalar ExactRatio/range fields).

Explicit owned copies:
- definition: None or the Node/RepeatDefault/RepeatGap selector, each one NodeId.
- constraints: Vec<EnvelopeConstraint>; each element scalar except optional
  gap_after IterationId, whose allocation RevisionId is an owning Arc identity.
- editorial: Vec<EditorialConstraint>; each element contains the preceding
  EnvelopeConstraint plus scalar edges and optional pair of ExactRatio.
- repeats: Vec<RepeatInstance>, each NodeId and IterationId.
- retimes: Vec<AudioRetimeStage>, each NodeId plus scalar ratios/PitchPolicy.
- gap: optional DomainGap, scalar duration plus optional IterationId.
- instance: NodeId plus its separate Vec<RepeatInstance>.

All5 Vec buffers (constraints/editorial/repeats/retimes/instance.repeats) are
length-known at the actual clone site. Use exact requested capacities via the
same pinned allocator contract used by current sound admission, e.g.
Vec::with_capacity(len) then ordered pushes; do not Vec::resize from empty,
which can grow a small capacity. Empty vectors reserve0. No hidden collect
capacity policy, geometric growth or new query traversal is needed. Preserve
the derived clone field/element order, including new failure prefix ordering.

Identity Arc clones do not allocate new strings. Nevertheless existing
audio_allocated.rs and sound admission conservatively charge each owning edge
using Arc counters+actual text length/padding. Follow that convention, or
document a distinct physical-allocation-only slice; do not silently mix them.
No fresh string clones are required.

## Byte layouts, lifetime and overlap

Let V(T,n)=Layout::array::<T>(n) including overflow validation.
Let A(T)=Layout([usize;2]).extend(Layout::new::<T>()).pad_to_align().
Let I(text)=the same Arc layout with Layout::for_value(text).
All layout arithmetic checked. Each reservation is converted to the existing
8-byte frame units with ceil; per-allocation sums can exceed ceil(total/8).

Domain new copy D comprises the5 buffers above + per-owning-edge I amounts +
A(AudioDomain). Retained R comprises ONLY A(AudioOwnerRetainedInput), because
its processing/editorial/raw-domain values are moved into that shell.

Original candidate lifetime facts:
- candidates.rs: query borrows the exact Root/Domain parent, owns actual query.
- capture(self, index, limits) holds query owners while capture_observed walks;
  capture_observed clones observed owner and moves captured seed into Input.
- query drops before capture() returns. The resulting Input has a distinct
  cloned clock+captured Domain, but no membership-query buffer.
- node_description::original_context consumes Capture::into_input, then calls
  finish_paid_owner_input with &input. The Input and incoming Context stay
  alive across retained_probe_at and final sharing.
- on accepted Retained, processing span/editorial/raw_domain stay together;
  the retained owners query and boundary remain alive at the Arc::new return
  site. Moving the retained value invalidates no query borrow because the
  actual returned owners are plan-branded, not storage-borrowed from retained.
  Verify compiler, retain existing block/drop order.
- on Domain fallthrough, retained owners/probe temporaries from the if block
  are already dropped. Input and its Domain remain alive during the full new
  copy D. Do not transfer the source Domain's ownership or reduce peak by
  dropping Input early in this mechanical patch.
- current admitted sound carrier already exists before Original selection
  and remains live throughout. All new reservations coexist with its charge,
  any active_graph/native/PCM reservation, and existing cache entries until
  make_room really evicts them.
- the constructed shared Context enters DescriptionValues. Description may
  still construct boundary/legacy stop afterward, then native state/Node Vec.
  Keep new charge alive on all those errors and through Graph publication.

R/D bounds are IN ADDITION TO current existing allocations. They do not cover
the source Input or query/capture/retained/Core work that allocated earlier.
A conservative whole-process128MiB/RSS or full cold-recursion claim is false.

## Carrier/API shape

Use a narrowly named admitted-sharing carrier, not an ancestry/lookup token:

  AudioDomain::clone_shared_admitted(&self, limits, admission)
      -> AdmittedDomain<'plan, Issuer, Lease>
  AudioOwnerRetainedInput::into_shared_admitted(self, limits, admission)
      -> AdmittedRetained<'plan, Issuer, Lease>

Names illustrative. These methods must be used by the actual numerical
node-description path in the same patch. No stand-alone unused public hook.
The second method may accept no limits if it performs only the new fixed
charged reserve/creation operations under admission.spend; choose one shared
budget convention, do not grant an unbilled new traversal.

Reuse private accounting mechanics from current sound admission, not its
closed-shape with_processing_domain assertion: general Original Domains can
have nonempty constraints/editorial/retimes/gap/definition. Do not require them
to become empty or fallback to a sound Domain. Avoid a broad trait rename
merely to house this slice; share a small private layout/issuer/lease kernel
or a separate accounting policy adapter with the same concrete Audio ledger.

Carrier fields: owning intermediate values FIRST, then issuer+lease. It
retains the shared Arc so any Audio clone borrowed from shared() cannot be
the last owner before charge drop. Reserve each vector/identity before its
copy; partial fields must be stored in carrier before another fallible call.
Do not leave local partial buffers declared before a carrier lease such
that charge drops first on unwind/error.

Audio can keep existing finish_paid_owner_input compatibility, and factor
the same retained decision into a private common implementation whose final
sharing operation is selected by actual admitted/unmetered caller. The
unmetered entry must preserve old reported work and clone/Arc positions.
Do NOT duplicate the retained query/decision loop to add an admitted path.

Description gains optional Original-sharing carrier, placed after owning
DescriptionValues and before/alongside sound carrier. Incoming Retained's
immediate Arc::clone remains the same and needs no new physical Arc shell.
Empty-support sound fallback stays with the existing sound carrier.

Before Node publication check both issuer identities and checked-add both
lease amounts to the same retained total (plus native bound). Validate BOTH
before changing either ledger or pushing Node; do not introduce a fallible
second transfer after publishing the first. Push pre-reserved Node once,
commit both leases exactly once, then drop each redundant carrier Arc before
release. Graph drop-before-active-release remains unchanged.

## Work and failure semantics

All old Q, C, None-probe9 and retained-owner query charges occur once in their
current order. No second query or artificial work subtraction is introduced.
Any additional field/element/identity inspection and metadata reservation is
actual new work: bill it through controlled admission, sharing a bounded
remaining budget for this new clone operation. Check before each inspection
and reserve. Unmetered compatibility does not pay new instrumentation walks.
Do not call a new query_limits for absent candidate capture.

Define concrete per-inspection accounting in implementation and derive test
thresholds from actual operation receipts; do not guess the new total from old
28-Q or waive copied elements. Cancel/timeouts/refusal before an allocation
must drop prior copied values before leases; completed old work stays charged.
A real eviction by make_room may persist after later failure, as today.

## Focused test contract

1. Actual numerical Root and captured Domain descriptions using the existing
   real fixture must still return Domain with exact instance/support/grid/
   query results and same stop. Cover nonempty general seed fields through
   legal Repeat/gap, FollowSpeed/Preserve, authored definition and transported
   editorial constraints. A cold fake Domain is not sufficient coverage.
2. Actual accepted Retained fixture: real probe and owner membership, exact
   bound/reference_at/grid data unchanged; lease covers shell, object moved.
   Incoming Retained immediate Arc clone must retain ptr_eq and old work.
3. At the FINAL clone site with source Input already constructed, cap at exact
   measured D succeeds; one-less denies BEFORE the reached Vec/Arc creation.
   Use the trusted admission fixture's reserve-call order/guard Drop counters,
   not allocator/RSS guesses. Test each fallible reservation boundary in a
   bounded table. Retained final shell exact/one-less separately.
4. Wire the same cap through actual describe_admitted and shared_eq_node to
   prove the runtime branch invokes the new policy, rather than testing only
   an isolated clone helper. Select Domain and accepted Retained explicitly;
   absence/sound fallback must not accidentally stand in for either.
5. Successful Graph retained amounts equal native+sound+Original sharing;
   two new-node contexts add, cache-hit reuses no new share, tiles/native take
   keep all metadata charged. Failure after final-sharing but before boundary/
   native/publication frees each value then each lease exactly once.
6. Real pre-existing cache eviction on admission, cancellation/timeout/work
   refusal prefixes, distinct/unstable issuer rejection before allocation and
   no Graph publication on errors. No provider/native calls by Plan helpers.
7. Existing real PCM/dependency/depth/source-admission behavior remains exact.
   One query/capture is proved by common actual call graph and independent Q
   work oracle, not only a stand-alone API test. Added clone inspection work
   is explicit; existing None9 remains once.

These tests are proposed, not authored/run. Main owns compiler/evidence and
decides the next implementation. Full query/owner/capture/retained/Core
allocation admission remains owed after this slice.
