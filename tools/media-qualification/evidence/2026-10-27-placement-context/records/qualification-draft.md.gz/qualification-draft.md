# Joined sound placement and context clock, 2026-10-27

Certified-Split afterbirth history now obtains placement and its exact context
clock together. Placement already projects the owner, opaque provider and
higher ancestors. The new query captures two scalar ratios from that same
checked projection instead of making the caller project it again. An unvisited
context below the provider receives the original projection once, after all
private placement chain/projection paths have dropped.

The old public placement API uses a compile-time no-capture branch and retains
its original visits, allocations, arithmetic order and work. The new query
charges one scalar extraction plus every actual fallback projection. It accepts
no caller-provided projection and retains no path, plan Arc, heap cache or media
authority. Context membership still checks the exact node and full stable
Repeat prefix. Ordinary afterbirth paths still use the old API.

Five oracle tests cover owner/provider/higher reuse, below-provider fallback,
fixed old API work, Preserve/Shift, derived9/14 and FollowSpeed5/7 clocks,
16 Repeat segments with body/gap overrides, foreign branches and exact/one-short
budgets. Joined results match separate checked placement/project calls; the
reused path removes duplicate work, and fallback honestly charges its query.

Current code passes Core800, Plan534, Audio library198, definition171 and all203
existing stage tests, zero ignored. The unchanged Split matrix remains4pass/
3work-limit failures: all-owner Source/Sequence cut-three limited0+511 planwork,
nested selected prefix-two limited0+4096 planwork, selected samewindow frozen
projection work exhausted. No acceptance credit changes.

The isolated four-file patch builds and passes Core775, Plan521, Audio184 and
eight historical birth/processing tests, zero ignored. Initial strict lint
found only a collapsible nested if in a test. It was mechanically collapsed
after the broad runs, with all production inputs unchanged. Final focused
runtime rerun and strict lint are recorded separately.
