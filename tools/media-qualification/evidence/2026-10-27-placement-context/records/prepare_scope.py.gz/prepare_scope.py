from pathlib import Path
import json,difflib,hashlib
s=Path(__file__).resolve().parent
root=Path('/Users/michael/Code/deadpan')
isolated=Path('/tmp/deadpan-query-groundwork-2026-10-26/scoped')
files={
'crates/deadpan-core/src/audio_reference/sound_placement.rs':s/'sound_placement.before.rs',
'crates/deadpan-core/src/audio_reference.rs':s/'audio_reference.before.rs',
'crates/deadpan-plan/src/audio_sound_processing_history.rs':s/'audio_sound_processing_history.before.rs',
'crates/deadpan-core/src/audio_reference/sound_placement/tests.rs':None,
}
patch='';pins={}
for rel,baseline in files.items():
 before=(isolated/rel).read_text() if (isolated/rel).exists() else ''
 desired=(root/rel).read_text()
 if rel=='crates/deadpan-core/src/audio_reference.rs':
  old='pub use sound_placement::FrozenSoundPlacement;'
  new='pub use sound_placement::{FrozenSoundContextClock, FrozenSoundPlacement};'
  assert before.count(old)==1 and desired.count(new)==1
  desired=before.replace(old,new)
 elif baseline:
  assert before==baseline.read_text(),rel
 else:assert not before,rel
 patch+=''.join(difflib.unified_diff(before.splitlines(True),desired.splitlines(True),fromfile='a/'+rel if before else '/dev/null',tofile='b/'+rel))
 out=s/'scope'/rel;out.parent.mkdir(parents=True,exist_ok=True);out.write_text(desired)
 pins[rel]=hashlib.sha256(desired.encode()).hexdigest()
(s/'scoped.patch').write_text(patch)
(s/'scoped-files.json').write_text(json.dumps(list(files),indent=2)+'\n')
(s/'scoped-pins.json').write_text(json.dumps(pins,indent=2)+'\n')
print('Prepared independent4file patch',len(patch),'bytes')
