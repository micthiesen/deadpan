# Joined frozen placement and context projection

Read-only source audit, 2026-10-27. No Cargo or repository edits.
Current final matrix reported by parent: four passes, three failures; latest
all-owner/selected errors are plan work and nested is binding work. No claim
that this candidate resolves them.

## Proven source facts

FrozenAudioLayout::project (audio_reference.rs:2266) dispatches to
project_scoped_inner (:2358). It uses admitted self.index.parents/repeats/extents.
It does not call validate/build_index. Those indexes are built during admission
(:928); explicit validate (:1135) rebuilds them, but these project paths do not.

project_scoped_inner validates supplied occurrence depth, scope/target presence,
stable Repeat path order and play/override child selection, then walks the actual
target-to-root path. It charges each visited node and each encountered Repeat's
compact segment count. It returns exact origin/scale with checked ratio arithmetic.

sound_occurrence_placement (audio_reference/sound_placement.rs:22):
1. project(instance, ZERO, None) for owner origin;
2. build owner-to-root chain from cached parent indexes;
3. locate concrete context in that chain and outermost opaque provider;
4. project(provider) if provider is not the owner;
5. project EVERY higher ancestor, intersecting complete allocations/delivery.

Each step 4/5 projection walks that ancestor to root again. Actual ancestry
visits can therefore be quadratic in depth, including repeated compact Repeat
segment charges. This is repeated path execution, not index rebuilding.

Two caller layers additionally repeat placement work:
- Audio sound_clocks::placements (:226 historical, :253 current).
- Plan complete_processing_history_after_birth (:207 historical, :236 current).
The latter must validate the public supplied route, so dropping its checks on
the basis of caller-authored scalar SoundPlacement values would be unsound.

Preferred narrower exact duplicate:
- certified-Split afterbirth explicitly projects historical_context at :193,
  immediately before sound_occurrence_placement(...Some(context)) at :207.
- current placement at :236 is followed by project(context.owner) at :243.
- placement itself already projects that exact context when its chain index is
  the owner, provider, or above the provider. It presently discards the scalar
  context origin/scale and the caller computes them separately.

## Exact same-call conditions

Reuse only a projection produced by the SAME FrozenAudioLayout receiver:
same immutable allocation and same root. Equal NodeIds or metadata do not suffice.

The requested standalone projection is precisely:
- instance = complete context NodeId plus full stable Repeat ancestor vector;
- local = ExactRatio::ZERO;
- gap_after = None;
- projection mode = Affine.

Placement finds context by BOTH node equality and equality of the complete
Repeat prefix at the chain depth (sound_placement.rs context.position closure).
Its project closure reconstructs exactly that InstancePath from this node and
prefix, and calls the same self.project(...ZERO,None). The owner and provider
special cases must likewise compare the actual chain index, not only a node name.

A context strictly below the outermost provider may not be projected by the
placement loop. Context==owner is still already projected initially. For any
other unvisited context, execute the exact existing self.project(context,0,None)
once as fallback. Do not infer its origin from another ancestor or cached live
AudioOwnerClock.

Successful scalar results do not depend on unused budget; all actual visits
must still share the supplied aggregate budget. Budget failure can change only
because duplicate actual work has been removed. No caps or refunds.

## Bounded implementation proposal

Preserve the existing public sound_occurrence_placement API, results and costs.
Factor its body into a private implementation with an optional joined-context
request. The old public entry selects the original behavior: no extra context
query, capture, retained data or charge.

Add a joined public query returning the same FrozenSoundPlacement plus optional
context origin/frames_per_local_frame. The joined implementation owns validation
and projection; accept no caller-supplied projected tuple/proof.

Within the existing chain/context lookup, retain the raw context index before
max(provider). When an already required owner/provider/ancestor projection
matches that index, copy its two scalar ratios into the joined result before
the projection is dropped. Do not retain FrozenAudioProjection: it owns an
InstancePath/repeats vector. The new result needs no heap/Arc or plan borrow.

If no projection was captured for a present context, first finish placement and
drop ALL private placement temporaries (chain Vec, project closure, owner and
provider FrozenAudioProjection values). Then call the old standalone project
once. A private helper returning only placement + optional scalar pair naturally
ends those temporaries before the joined wrapper's fallback. This avoids adding
a simultaneous repeats-vector allocation to the old transient peak.

Plan afterbirth uses the joined query only when certified_split needs context
origins, replacing its separate context project + placement pair. Non-Split and
other existing callers retain the old placement method. Historical None contexts
need no projection. Keep all current journal, binding, alias, policy-Arc,
instance, route-window/count, context-birth and current extent guards.

## Work accounting

Old pair costs: context.project.work + placement.work. Placement.work already
contains its internal required project(context). The joined reuse must not
charge the omitted standalone traversal.

New joined reuse: unchanged actual placement visits + explicit bounded scalar
capture/return work. Preserve each still-executed ancestor/project/Repeat charge.
For fallback, charge placement visits + the one actual standalone projection +
the scalar extraction/return operations. Use remaining supplied work, never a
fresh allowance. Do not reduce whole-layout constants or pretend projections
were prevalidated away.

The old public API retains its old cost exactly because it does no joined
capture/fallback. New joined paths can cost a small additional scalar operation
when there is no repeated walk to remove; document that honestly. A scalar pair
is stack data. There is no query cache, extra retained historical plan, persistent
proof/interner, PCM, new heap collection or extended Arc lifetime.

## Why existing other data cannot replace these checks wholesale

SoundClockCorrespondence stores alias and scoped parent/Repeat identity maps,
not absolute placement offsets or all retime projection values. ScopedRepeat
contains iterations/child/overrides, not this concrete resolved affine origin.

RenderPlan.by_id and its live owner/domain clocks are not substitutes for a
historical frozen placement. Retained layouts can differ by scope, crop, birth,
Repeat play and phase. AudioSoundOwnerContext.policy can describe its outer
processing provider rather than the requested owner's own affine map.

A broader root-down transform rewrite would reassociate checked ExactRatio
operations. Equal rational results alone do not prove identical intermediate
overflow admission. This proposal reuses the exact existing project result and
does not change its arithmetic order.

## Focused verification proposal

- Old API behavior/work unchanged.
- Joined placement and context scalars equal two explicit legacy queries.
- Captured owner, provider and above-provider context cases.
- Strictly below-provider context fallback, and None context.
- Nested Preserve/FollowSpeed, crop/Partition, NTSC fractional offsets, stable
  Repeat plays with sparse body/gap overrides and dormant branches.
- Invalid/missing/wrong-order Repeat context and nonancestor context refuse.
- Work witness with a compact multi-segment Repeat path: show one real repeated
  context traversal disappears, with exact available-work and one-less checks.
- Existing Plan processing-birth/route authority tests and Audio PCM/matrix
  remain parent-owned; no performance percentage or acceptance claim yet.

## Error labels are not direct hotspot measurements

The message "sound processing history work" is emitted by
audio_sound_route.rs:529's processing_history_from_boundary aggregate route
construction guard, not FrozenAudioLayout::project. "audio binding work
exhausted" is emitted by audio_binding.rs Work::spend/remaining (:533/:541),
whereas frozen project emits "frozen projection work exhausted".
Upstream savings may move those later remaining-budget failures, but source
labels alone do not establish that placement dominates either case.
