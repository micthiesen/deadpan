from pathlib import Path
import json, difflib, hashlib, shutil
s=Path(__file__).resolve().parent
r=Path('/Users/michael/Code/deadpan')
isolated=Path('/tmp/deadpan-query-groundwork-2026-10-26/scoped')
files=json.loads((s/'scoped-files.json').read_text())
shutil.copyfile(s/'scoped.patch',s/'scoped-tested.patch')
patch=''; pins={}
for rel in files:
 p=r/rel
 if rel.endswith('/tests.rs'): before=''
 elif rel=='crates/deadpan-core/src/audio_reference.rs': before=(s/'audio_reference.head.rs').read_text()
 else: before=(s/('sound_placement.before.rs' if rel.endswith('/sound_placement.rs') else 'audio_sound_processing_history.before.rs')).read_text()
 after=p.read_text()
 if rel=='crates/deadpan-core/src/audio_reference.rs':
  old='pub use sound_placement::FrozenSoundPlacement;'
  new='pub use sound_placement::{FrozenSoundContextClock, FrozenSoundPlacement};'
  assert before.count(old)==1 and after.count(new)==1
  after=before.replace(old,new)
 assert (isolated/rel).read_text()==after, rel
 patch+=''.join(difflib.unified_diff(before.splitlines(True),after.splitlines(True),fromfile='a/'+rel if before else '/dev/null',tofile='b/'+rel))
 out=s/'scope'/rel;out.parent.mkdir(parents=True,exist_ok=True);out.write_text(after)
 pins[rel]=hashlib.sha256(after.encode()).hexdigest()
(s/'scoped.patch').write_text(patch)
(s/'scoped-pins-final.json').write_text(json.dumps(pins,indent=2)+'\n')
print('Final four-file patch',len(patch),'bytes')
