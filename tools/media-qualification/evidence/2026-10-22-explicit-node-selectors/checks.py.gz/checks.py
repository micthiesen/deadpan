from pathlib import Path
import subprocess,os,time,json,sys
s=Path('/tmp/deadpan-explicit-node-selectors-2026-10-22')
env=dict(os.environ,DEADPAN_FFMPEG_PREFIX='/Users/michael/Library/Developer/Deadpan/ffmpeg-8.0.3-opus-1.6.1-dav1d-1.5.4-qualified-3/prefix',CARGO_PROFILE_DEV_OPT_LEVEL='2',DEADPAN_REQUIRE_PHYSICAL_MAC='1',DEADPAN_REQUIRE_SYNTHETIC_WORKER='1')
stage=sys.argv[1]
subprocess.run(['python',str(s/'freeze.py'),stage],check=True)
commands=[('check',['cargo','check','--locked','-p','deadpan-core','-p','deadpan-app','-p','deadpan-cli','-p','deadpan-store','--features','deadpan-app/ui-harness','--all-targets'])]
rows=[]
for name,args in commands:
 start=time.monotonic()
 with (s/(stage+'-'+name+'.log')).open('w') as log:
  r=subprocess.run(args,stdout=log,stderr=subprocess.STDOUT,env=env)
 row={'command':args,'exit':r.returncode,'seconds':time.monotonic()-start}
 rows.append(row);(s/(stage+'-results.json')).write_text(json.dumps(rows,indent=2)+'\n')
 print(json.dumps(row),flush=True)
 subprocess.run(['python',str(s/'guard.py'),stage],check=True)
 if r.returncode:raise SystemExit(r.returncode)
