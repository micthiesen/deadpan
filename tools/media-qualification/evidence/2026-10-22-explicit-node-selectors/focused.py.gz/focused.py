from pathlib import Path
import subprocess,json,os,time,hashlib,shutil,sys
s=Path('/tmp/deadpan-explicit-node-selectors-2026-10-22')
env=dict(os.environ,DEADPAN_FFMPEG_PREFIX='/Users/michael/Library/Developer/Deadpan/ffmpeg-8.0.3-opus-1.6.1-dav1d-1.5.4-qualified-3/prefix',CARGO_PROFILE_DEV_OPT_LEVEL='2',DEADPAN_REQUIRE_PHYSICAL_MAC='1',DEADPAN_REQUIRE_SYNTHETIC_WORKER='1')
stage=sys.argv[1] if len(sys.argv)>1 else 'focused-first'
subprocess.run(['python',str(s/'freeze.py'),stage],check=True)
jobs=[
('core',['-p','deadpan-core','--test','explicit_node_selectors'],None),
('store',['-p','deadpan-store','--test','source_registration'],'test(node_selector)'),
('cli',['-p','deadpan-cli','--test','project_commands'],'test(macros::node)'),
('app',['-p','deadpan-app','--features','ui-harness','--bin','deadpan-app'],'test(explicit_node) | test(node_selection) | test(project::semantic::tests) | test(preview::edit_range::tests) | test(navigation::command::tests)')]
if len(sys.argv)>2:jobs=[job for job in jobs if job[0]==sys.argv[2]]
rows=[]
for name,args,expression in jobs:
 filters=['-E',expression] if expression else []
 with (s/(stage+'-'+name+'-list.json')).open('w') as out,(s/(stage+'-'+name+'-build.log')).open('w') as err:
  built=subprocess.run(['cargo','nextest','list','--locked',*args,*filters,'--message-format','json'],stdout=out,stderr=err,env=env)
 if built.returncode:raise SystemExit(built.returncode)
 identities={}
 for key,suite in json.loads((s/(stage+'-'+name+'-list.json')).read_text())['rust-suites'].items():
  tests=[n for n,c in suite.get('testcases',{}).items() if c.get('filter-match',{}).get('status')=='matches']
  if not tests:continue
  p=Path(suite['binary-path']);target=s/(stage+'-bin')/p.name;target.parent.mkdir(exist_ok=True);shutil.copy2(p,target)
  identities[key]={'path':str(p),'retained':str(target),'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'tests':tests}
 (s/(stage+'-'+name+'-binaries.json')).write_text(json.dumps(identities,indent=2)+'\n')
 subprocess.run(['python',str(s/'guard.py'),stage],check=True)
 start=time.monotonic()
 with (s/(stage+'-'+name+'.log')).open('w') as out:
  run=subprocess.run(['cargo','nextest','run','--locked',*args,*filters,'--test-threads','8','--no-fail-fast'],stdout=out,stderr=subprocess.STDOUT,env=env)
 subprocess.run(['python',str(s/'guard.py'),stage],check=True)
 for row in identities.values(): assert hashlib.sha256(Path(row['path']).read_bytes()).hexdigest()==row['sha256'] and hashlib.sha256(Path(row['retained']).read_bytes()).hexdigest()==row['sha256']
 row={'phase':name,'exit':run.returncode,'tests':sum(len(i['tests']) for i in identities.values()),'seconds':time.monotonic()-start,'sources_inputs_binaries_unchanged':True}
 rows.append(row);(s/(stage+'-results.json')).write_text(json.dumps(rows,indent=2)+'\n');print(json.dumps(row),flush=True)
 if run.returncode:raise SystemExit(run.returncode)
