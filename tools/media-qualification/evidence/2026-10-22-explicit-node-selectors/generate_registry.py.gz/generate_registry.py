from pathlib import Path
import subprocess,json,os,time,hashlib
s=Path('/tmp/deadpan-explicit-node-selectors-2026-10-22')
rows=json.loads((s/'focused-app-second-app-binaries.json').read_text())
assert len(rows)==1
binary=next(iter(rows.values()))
p=Path(binary['retained'])
assert hashlib.sha256(p.read_bytes()).hexdigest()==binary['sha256']
subprocess.run(['python',str(s/'guard.py'),'focused-app-second'],check=True)
results=[]
for variable,name in [('DEADPAN_UPDATE_ROUTING_BASELINE','routing_matches_the_pre_registry_baseline'),('DEADPAN_UPDATE_COMMANDS_MD','commands_reference_is_current')]:
 test='navigation::registry::tests::'+name
 env=dict(os.environ,**{variable:'1'})
 r=subprocess.run([str(p),'--exact',test,'--nocapture'],capture_output=True,text=True,env=env)
 (s/('generate-'+name+'.stdout')).write_text(r.stdout)
 (s/('generate-'+name+'.stderr')).write_text(r.stderr)
 assert r.returncode==101 and 'rewritten; review the diff' in r.stderr,(r.stdout,r.stderr)
 results.append({'test':test,'exit':r.returncode,'expected_rewrite_failure':True,'binary_sha256':binary['sha256']})
(s/'generated-results.json').write_text(json.dumps(results,indent=2)+'\n')
print(json.dumps(results))
