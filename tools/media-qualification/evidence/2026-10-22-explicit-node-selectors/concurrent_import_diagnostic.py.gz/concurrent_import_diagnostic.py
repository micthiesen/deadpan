from pathlib import Path
import hashlib
import json
import os
import subprocess
import time

scratch = Path("/tmp/deadpan-explicit-node-selectors-2026-10-22")
output = scratch / "concurrent-import-diagnostic"
output.mkdir(exist_ok=True)
binary = scratch / "broad-isolated-bin/deadpan_app-1665fcaccc742208"
expected = "a0f5db87cf5694db05e647f19d310ce5ea60403d3a51f808c1434792c0f66358"
overrides = {
    "DEADPAN_FFMPEG_PREFIX": "/Users/michael/Library/Developer/Deadpan/ffmpeg-8.0.3-opus-1.6.1-dav1d-1.5.4-qualified-3/prefix",
    "DEADPAN_REQUIRE_PHYSICAL_MAC": "1",
    "DEADPAN_REQUIRE_SYNTHETIC_WORKER": "1",
}
environment = dict(os.environ, **overrides)
cases = [
    "project::tests::backups::a_moved_linked_original_is_found_by_its_bookmark_and_relinked_on_open",
    "project::tests::backups::a_moved_file_with_different_bytes_is_reported_missing_not_relinked",
    "project::tests::native_new_starts_with_the_full_original_and_history_stops_at_that_baseline",
    "project::tests::unavailable_linked_original_invalidates_cached_insertion_without_losing_registration",
]
receipt = {
    "binary": str(binary),
    "expected_sha256": expected,
    "cwd": "/Users/michael/Code/deadpan/crates/deadpan-app",
    "environment_overrides": overrides,
    "batch_limit": 3,
    "sample_after_seconds": 3,
    "owned_test_deadline_seconds": 60,
    "samples": [],
    "tests": [],
}


def identity():
    actual = hashlib.sha256(binary.read_bytes()).hexdigest()
    assert actual == expected, actual
    return actual


def save():
    (output / "results.json").write_text(json.dumps(receipt, indent=2) + "\n")


identity()
for batch in range(3):
    live = []
    for index, case in enumerate(cases):
        prefix = output / f"batch-{batch + 1}-case-{index + 1}"
        stdout = prefix.with_suffix(".stdout").open("wb")
        stderr = prefix.with_suffix(".stderr").open("wb")
        command = [str(binary), "--exact", case, "--nocapture"]
        started = time.monotonic()
        process = subprocess.Popen(
            command,
            cwd=receipt["cwd"],
            env=environment,
            stdout=stdout,
            stderr=stderr,
        )
        row = {
            "batch": batch + 1,
            "case": case,
            "command": command,
            "pid": process.pid,
            "binary_sha256_before": identity(),
        }
        live.append((process, row, prefix, started, stdout, stderr))
    samplers = []
    sampled = set()
    while live:
        for item in list(live):
            process, row, prefix, started, stdout, stderr = item
            elapsed = time.monotonic() - started
            if process.poll() is None and elapsed >= 3 and process.pid not in sampled:
                sampled.add(process.pid)
                command = [
                    "sample", str(process.pid), "2", "1",
                    "-file", str(prefix.with_suffix(".sample.txt")),
                ]
                sample_stdout = prefix.with_suffix(".sample.stdout").open("wb")
                sample_stderr = prefix.with_suffix(".sample.stderr").open("wb")
                sampler = subprocess.Popen(command, stdout=sample_stdout, stderr=sample_stderr)
                sample_row = {
                    "batch": batch + 1,
                    "owned_test_pid": process.pid,
                    "command": command,
                    "started_after_seconds": elapsed,
                }
                samplers.append((sampler, sample_row, sample_stdout, sample_stderr))
            if process.poll() is None and elapsed >= 60:
                row["timed_out"] = True
                process.kill()
            if process.poll() is not None:
                row["exit"] = process.wait()
                row["seconds"] = elapsed
                stdout.close()
                stderr.close()
                row["passed"] = (
                    row["exit"] == 0
                    and "1 passed; 0 failed" in prefix.with_suffix(".stdout").read_text()
                )
                row["binary_sha256_after"] = identity()
                receipt["tests"].append(row)
                print(json.dumps(row), flush=True)
                live.remove(item)
                save()
        if live:
            time.sleep(0.025)
    for sampler, row, stdout, stderr in samplers:
        try:
            row["exit"] = sampler.wait(timeout=15)
        except subprocess.TimeoutExpired:
            sampler.kill()
            row["exit"] = sampler.wait()
            row["timed_out"] = True
        stdout.close()
        stderr.close()
        receipt["samples"].append(row)
        save()
    if any(not row["passed"] for row in receipt["tests"] if row["batch"] == batch + 1):
        receipt["stopped_after_reproduction"] = True
        break
receipt["binary_sha256_final"] = identity()
receipt["all_passed"] = all(row["passed"] for row in receipt["tests"])
receipt["test_count"] = len(receipt["tests"])
save()
print(json.dumps({
    "results": str(output / "results.json"),
    "all_passed": receipt["all_passed"],
    "test_count": receipt["test_count"],
    "sample_count": len(receipt["samples"]),
}), flush=True)
