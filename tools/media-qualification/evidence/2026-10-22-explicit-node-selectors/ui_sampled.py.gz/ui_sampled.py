from pathlib import Path
import subprocess,os,json,time,hashlib,concurrent.futures
s=Path('/tmp/deadpan-explicit-node-selectors-2026-10-22')
env=dict(os.environ,DEADPAN_FFMPEG_PREFIX='/Users/michael/Library/Developer/Deadpan/ffmpeg-8.0.3-opus-1.6.1-dav1d-1.5.4-qualified-3/prefix',CARGO_PROFILE_DEV_OPT_LEVEL='2',DEADPAN_REQUIRE_PHYSICAL_MAC='1',DEADPAN_REQUIRE_SYNTHETIC_WORKER='1')
subprocess.run(['python',str(s/'guard.py'),'broad-first'],env=env,check=True)
binaries=json.loads((s/'ui-final-binaries.json').read_text())
for r in binaries.values():assert hashlib.sha256(Path(r['path']).read_bytes()).hexdigest()==r['sha256']
cases=[r['case'] for r in json.loads((s/'broad-isolated-results.json').read_text())]
directory=s/'ui-sampled';directory.mkdir(exist_ok=True)
args=['cargo','nextest','run','--locked','-p','deadpan-app','--features','ui-harness','--test-threads','8','--no-fail-fast']
started=time.monotonic();seen={};samples={}
def sample(pid,case):
 target=directory/f'{pid}.sample.txt'
 try:
  r=subprocess.run(['sample',str(pid),'2','1','-file',str(target)],capture_output=True,text=True,timeout=8)
  return {'pid':pid,'case':case,'exit':r.returncode,'stdout':r.stdout,'stderr':r.stderr,'file':target.name}
 except subprocess.TimeoutExpired:return {'pid':pid,'case':case,'sample_timeout':True}
with (s/'ui-sampled.log').open('w') as log,concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
 p=subprocess.Popen(args,stdout=log,stderr=subprocess.STDOUT,env=env)
 while p.poll() is None:
  raw=subprocess.check_output(['ps','-axo','pid,ppid,args'],text=True)
  rows=[line.strip().split(None,2) for line in raw.splitlines()[1:]]
  for fields in rows:
   if len(fields)!=3:continue
   pid,parent,command=fields
   # Cargo launches cargo-nextest; verify the complete owned ancestry.
   parents={int(f[0]):int(f[1]) for f in rows if len(f)==3}
   ancestor=int(parent);visited=set()
   while ancestor not in visited and ancestor!=p.pid and ancestor in parents:
    visited.add(ancestor);ancestor=parents[ancestor]
   if ancestor!=p.pid or not any(case in command for case in cases):continue
   pid=int(pid);case=next(case for case in cases if case in command)
   seen.setdefault(pid,{'case':case,'first_seen_seconds':time.monotonic()-started})
   if time.monotonic()-started-seen[pid]['first_seen_seconds']>=4 and pid not in samples:
    samples[pid]=pool.submit(sample,pid,case)
  time.sleep(0.2)
 result=p.wait()
 reports=[f.result() for f in samples.values()]
subprocess.run(['python',str(s/'guard.py'),'broad-first'],env=env,check=True)
for r in binaries.values():assert hashlib.sha256(Path(r['path']).read_bytes()).hexdigest()==r['sha256']
receipt={'exit':result,'seconds':time.monotonic()-started,'nextest_pid':p.pid,'command':args,'seen':seen,'samples':reports,'sources_inputs_binaries_unchanged':True}
(s/'ui-sampled-result.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt),flush=True)
raise SystemExit(result)
