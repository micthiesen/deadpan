from pathlib import Path
import subprocess,os,json,time
s=Path('/tmp/deadpan-explicit-node-selectors-2026-10-22')
env=dict(os.environ,DEADPAN_FFMPEG_PREFIX='/Users/michael/Library/Developer/Deadpan/ffmpeg-8.0.3-opus-1.6.1-dav1d-1.5.4-qualified-3/prefix',CARGO_PROFILE_DEV_OPT_LEVEL='2',DEADPAN_REQUIRE_PHYSICAL_MAC='1',DEADPAN_REQUIRE_SYNTHETIC_WORKER='1')
broad=json.loads((s/'broad-first-result.json').read_text())
assert broad['exit']==100 and broad['selected_tests']==4549 and broad['rust_and_inputs_and_binaries_unchanged']
isolated=json.loads((s/'broad-isolated-results.json').read_text())
assert len(isolated)==4 and all(row['passed'] and row['exit']==0 for row in isolated)
expected={
 'project::tests::backups::a_moved_linked_original_is_found_by_its_bookmark_and_relinked_on_open',
 'project::tests::backups::a_moved_file_with_different_bytes_is_reported_missing_not_relinked',
 'project::tests::native_new_starts_with_the_full_original_and_history_stops_at_that_baseline',
 'project::tests::unavailable_linked_original_invalidates_cached_insertion_without_losing_registration',
}
assert {row['case'] for row in isolated}==expected
identities=json.loads((s/'broad-first-identities.json').read_text())['test_binaries']
assert all(row['suite']=='deadpan-app::bin/deadpan-app' and row['sha256']==identities[row['suite']]['sha256'] for row in isolated)
ui=json.loads((s/'ui-relocated-result.json').read_text())
assert ui['exit']==0 and ui['tests']==1270 and ui['sources_inputs_binaries_unchanged'] and ui['same_cases_and_executable_hashes_as_ui_final']
relocated=json.loads((s/'broad-relocated-result.json').read_text())
assert relocated['exit']==0 and relocated['tests']==4549 and relocated['sources_inputs_binaries_unchanged'] and relocated['same_cases_and_test_executable_hashes_as_broad_first']
relocated_helpers=json.loads((s/'broad-relocated-binaries.json').read_text())['helpers']
assert len(relocated_helpers)==5 and all(row['same_as_first_broad'] for row in relocated_helpers.values())
# Original-location runs remain failed. The verified archive runs preserve
# their cases, test bytes, concurrency and limits while changing location.
subprocess.run(['python',str(s/'guard.py'),'broad-first'],check=True,env=env)
commands=[
('strict-final-check',['cargo','xtask','check','--since','bfb8b811d51c0f19448f8c23a5b5a1184e72636d','--no-test']),
('strict-final-ui-clippy',['cargo','clippy','--locked','-p','deadpan-app','--features','ui-harness','--all-targets','--','-D','warnings']),
('strict-final-format',['cargo','fmt','--all','--','--check']),
('strict-final-whitespace',['git','diff','--check'])]
rows=[]
for name,args in commands:
 start=time.monotonic()
 with (s/(name+'.log')).open('w') as log:r=subprocess.run(args,stdout=log,stderr=subprocess.STDOUT,env=env)
 row={'name':name,'command':args,'exit':r.returncode,'seconds':time.monotonic()-start};rows.append(row)
 (s/'strict-final-results.json').write_text(json.dumps(rows,indent=2)+'\n')
 print(json.dumps(row),flush=True)
 if r.returncode:raise SystemExit(r.returncode)
subprocess.run(['python',str(s/'guard.py'),'broad-first'],check=True,env=env)
