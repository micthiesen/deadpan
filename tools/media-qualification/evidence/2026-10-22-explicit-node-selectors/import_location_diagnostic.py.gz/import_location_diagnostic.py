from pathlib import Path
import hashlib
import json
import os
import shutil
import subprocess
import time

scratch = Path("/tmp/deadpan-explicit-node-selectors-2026-10-22")
output = scratch / "import-location-diagnostic"
output.mkdir(exist_ok=True)
deps = Path("/Users/michael/Code/deadpan/target/debug/deps")
cases = [
    "project::tests::backups::a_moved_linked_original_is_found_by_its_bookmark_and_relinked_on_open",
    "project::tests::backups::a_moved_file_with_different_bytes_is_reported_missing_not_relinked",
    "project::tests::native_new_starts_with_the_full_original_and_history_stops_at_that_baseline",
    "project::tests::unavailable_linked_original_invalidates_cached_insertion_without_losing_registration",
]
specifications = [
    ("normal", "deadpan_app-1665fcaccc742208", "a0f5db87cf5694db05e647f19d310ce5ea60403d3a51f808c1434792c0f66358"),
    ("ui", "deadpan_app-7e20ea767f3f19d5", "7055795cc7b97961acc219fb9d22d9c51086769ff5f6227e1ca96dd2861910ca"),
]
overrides = {
    "DEADPAN_FFMPEG_PREFIX": "/Users/michael/Library/Developer/Deadpan/ffmpeg-8.0.3-opus-1.6.1-dav1d-1.5.4-qualified-3/prefix",
    "CARGO_PROFILE_DEV_OPT_LEVEL": "2",
    "DEADPAN_REQUIRE_PHYSICAL_MAC": "1",
    "DEADPAN_REQUIRE_SYNTHETIC_WORKER": "1",
}
environment = dict(os.environ, **overrides)
receipt = {
    "environment_overrides": overrides,
    "cwd": "/Users/michael/Code/deadpan/crates/deadpan-app",
    "directory_counts": [],
    "tests": [],
    "samples": [],
    "test_timeout_seconds": 60,
    "sampling_threshold_seconds": 3,
    "sampler_timeout_seconds": 60,
}


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def save():
    (output / "results.json").write_text(json.dumps(receipt, indent=2) + "\n")


def directory_count(path):
    count = 0
    with os.scandir(path) as entries:
        for _ in entries:
            count += 1
            if count >= 100000:
                break
    receipt["directory_counts"].append({
        "path": str(path), "entries": count, "capped_at_100000": count == 100000,
    })


directory_count(deps)
for mode, filename, expected in specifications:
    original = deps / filename
    assert digest(original) == expected
    compact_directory = output / f"compact-{mode}"
    compact_directory.mkdir(exist_ok=True)
    compact = compact_directory / filename
    shutil.copy2(original, compact)
    assert digest(compact) == expected
    directory_count(compact_directory)
    for site, binary in [("deps", original), ("compact", compact)]:
        assert digest(binary) == expected
        live = []
        samplers = []
        for index, case in enumerate(cases):
            prefix = output / f"{mode}-{site}-{index + 1}"
            stdout = prefix.with_suffix(".stdout").open("wb")
            stderr = prefix.with_suffix(".stderr").open("wb")
            command = [str(binary), "--exact", case, "--nocapture"]
            started = time.monotonic()
            process = subprocess.Popen(command, cwd=receipt["cwd"], env=environment, stdout=stdout, stderr=stderr)
            row = {
                "mode": mode, "site": site, "case": case, "command": command,
                "pid": process.pid, "parent_pid": os.getpid(), "binary_sha256_before": expected,
            }
            live.append([process, row, prefix, started, stdout, stderr, False])
        while live:
            for item in list(live):
                process, row, prefix, started, stdout, stderr, sampled = item
                elapsed = time.monotonic() - started
                if process.poll() is None and elapsed >= 3 and not sampled:
                    item[6] = True
                    command = ["sample", str(process.pid), "2", "1", "-file", str(prefix.with_suffix(".sample.txt"))]
                    sample_stdout = prefix.with_suffix(".sample.stdout").open("wb")
                    sample_stderr = prefix.with_suffix(".sample.stderr").open("wb")
                    sampler = subprocess.Popen(command, stdout=sample_stdout, stderr=sample_stderr)
                    samplers.append((sampler, {
                        "owned_test_pid": process.pid, "mode": mode, "site": site,
                        "command": command, "started_after_seconds": elapsed,
                    }, sample_stdout, sample_stderr))
                if process.poll() is None and elapsed >= 60:
                    row["timed_out"] = True
                    process.kill()
                if process.poll() is not None:
                    row.update(exit=process.wait(), seconds=elapsed)
                    stdout.close()
                    stderr.close()
                    row["passed"] = row["exit"] == 0 and "1 passed; 0 failed" in prefix.with_suffix(".stdout").read_text()
                    row["binary_sha256_after"] = digest(binary)
                    assert row["binary_sha256_after"] == expected
                    receipt["tests"].append(row)
                    live.remove(item)
                    save()
                    print(json.dumps({key: row[key] for key in ["mode", "site", "case", "pid", "exit", "seconds", "passed"]}), flush=True)
            if live:
                time.sleep(0.025)
        for sampler, row, stdout, stderr in samplers:
            try:
                row["exit"] = sampler.wait(timeout=60)
            except subprocess.TimeoutExpired:
                sampler.kill()
                row.update(exit=sampler.wait(), timed_out=True)
            stdout.close()
            stderr.close()
            receipt["samples"].append(row)
            save()
        assert digest(original) == expected and digest(compact) == expected
receipt["complete"] = True
save()
print(json.dumps({"results": str(output / "results.json"), "test_count": len(receipt["tests"]), "sample_count": len(receipt["samples"])}), flush=True)
