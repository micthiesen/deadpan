from pathlib import Path
import subprocess,os,json,time,hashlib,shutil
s=Path('/tmp/deadpan-explicit-node-selectors-2026-10-22')
env=dict(os.environ,DEADPAN_FFMPEG_PREFIX='/Users/michael/Library/Developer/Deadpan/ffmpeg-8.0.3-opus-1.6.1-dav1d-1.5.4-qualified-3/prefix',CARGO_PROFILE_DEV_OPT_LEVEL='2',DEADPAN_REQUIRE_PHYSICAL_MAC='1',DEADPAN_REQUIRE_SYNTHETIC_WORKER='1')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
assert json.loads((s/'ui-relocated-result.json').read_text())['exit']==0
subprocess.run(['python',str(s/'guard.py'),'broad-first'],env=env,check=True)
targets=['-p','deadpan-core','-p','deadpan-plan','-p','deadpan-audio','-p','deadpan-store','-p','deadpan-app','-p','deadpan-cli']
expression='package(deadpan-core) | package(deadpan-plan) | package(deadpan-audio) | package(deadpan-store) | package(deadpan-app) | test(macros) | test(semantic) | test(mark) | test(project_commands) | test(selection)'
archive=s/'broad-tests.tar.zst';target=s/'broad-relocated';target.mkdir(exist_ok=True)
with (s/'broad-archive-build.log').open('w') as log:
 subprocess.run(['cargo','nextest','archive','--locked',*targets,'--archive-file',str(archive),'--zstd-level=-1'],stdout=log,stderr=subprocess.STDOUT,env=env,check=True)
archive_sha=sha(archive)
reuse=['--archive-file',str(archive),'--extract-to',str(target),'--extract-overwrite','--workspace-remap',str(Path.cwd())]
with (s/'broad-relocated-list.json').open('w') as out,(s/'broad-relocated-list.log').open('w') as err:
 subprocess.run(['cargo','nextest','list',*reuse,'-E',expression,'--message-format','json'],stdout=out,stderr=err,env=env,check=True)
listing=json.loads((s/'broad-relocated-list.json').read_text());old=json.loads((s/'broad-first-identities.json').read_text());rows={}
for key,row in listing['rust-suites'].items():
 tests=[name for name,case in row.get('testcases',{}).items() if case.get('filter-match',{}).get('status')=='matches']
 if not tests:continue
 p=Path(row['binary-path']);assert p.resolve().is_relative_to(target.resolve())
 assert sha(p)==old['test_binaries'][key]['sha256'],key
 assert sorted(tests)==sorted(old['test_binaries'][key]['tests']),key
 rows[key]={'path':str(p),'sha256':sha(p),'tests':tests}
assert len(rows)==155 and sum(len(r['tests'])for r in rows.values())==4549
helpers={}
for name in ['deadpan-app','deadpan-cli','deadpan-media-worker','deadpan-transcribe','deadpan-track']:
 source=Path('target/debug')/name;matches=list(target.rglob(name))
 if not matches:
  destination=target/'target/debug'/name;destination.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(source,destination);matches=[destination]
 assert len(matches)==1 and sha(matches[0])==sha(source),(name,matches)
 helpers[name]={'path':str(matches[0]),'sha256':sha(source),'same_as_first_broad':sha(source)==old['helpers'][name]['sha256']}
(s/'broad-relocated-binaries.json').write_text(json.dumps({'test_binaries':rows,'helpers':helpers},indent=2)+'\n')
started=time.monotonic();args=['cargo','nextest','run',*reuse,'-E',expression,'--test-threads','8','--no-fail-fast']
with (s/'broad-relocated.log').open('w') as log:r=subprocess.run(args,stdout=log,stderr=subprocess.STDOUT,env=env)
subprocess.run(['python',str(s/'guard.py'),'broad-first'],env=env,check=True)
assert sha(archive)==archive_sha
for row in [*rows.values(),*helpers.values()]:assert sha(Path(row['path']))==row['sha256']
receipt={'exit':r.returncode,'tests':4549,'test_binaries':155,'seconds':time.monotonic()-started,'command':args,'archive_sha256':archive_sha,'sources_inputs_binaries_unchanged':True,'same_cases_and_test_executable_hashes_as_broad_first':True,'test_threads':8}
(s/'broad-relocated-result.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt),flush=True)
raise SystemExit(r.returncode)
