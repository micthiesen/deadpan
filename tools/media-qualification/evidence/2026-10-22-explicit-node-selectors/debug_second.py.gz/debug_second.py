from pathlib import Path
import subprocess,hashlib,json,shutil,os,time
s=Path('/tmp/deadpan-explicit-node-selectors-2026-10-22')
env=dict(os.environ,DEADPAN_FFMPEG_PREFIX='/Users/michael/Library/Developer/Deadpan/ffmpeg-8.0.3-opus-1.6.1-dav1d-1.5.4-qualified-3/prefix',CARGO_PROFILE_DEV_OPT_LEVEL='2',DEADPAN_REQUIRE_PHYSICAL_MAC='1',DEADPAN_REQUIRE_SYNTHETIC_WORKER='1')
subprocess.run(['python',str(s/'freeze.py'),'debug-second'],env=env,check=True)
with (s/'debug-second-build.log').open('w') as log:
 build=subprocess.run(['cargo','build','--locked','-p','deadpan-app','--features','ui-harness'],stdout=log,stderr=subprocess.STDOUT,env=env)
assert build.returncode==0,build.returncode
binaries={}
for name in ['deadpan-app','deadpan-media-worker','deadpan-transcribe','deadpan-track']:
 p=Path('target/debug')/name;t=s/'debug-second-bin'/name
 t.parent.mkdir(exist_ok=True);shutil.copy2(p,t)
 binaries[name]={'source':str(p),'executed':str(t),'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'freshly_built':name=='deadpan-app'}
(s/'debug-second-binaries.json').write_text(json.dumps(binaries,indent=2)+'\n')
subprocess.run(['python',str(s/'guard.py'),'debug-second'],env=env,check=True)
with (s/'debug-second-visual.log').open('w') as log:
 run=subprocess.run([binaries['deadpan-app']['executed'],'--ui-check','--scenario','explicit-node-selectors','--mode','visual','--output',str(s/'debug-second-visual'),'--kestrel-source','/Users/michael/.dotfiles/kestrel/Sources/Kestrel/Shortcuts.swift'],stdout=log,stderr=subprocess.STDOUT,env=env)
subprocess.run(['python',str(s/'guard.py'),'debug-second'],env=env,check=True)
for row in binaries.values():
 assert hashlib.sha256(Path(row['executed']).read_bytes()).hexdigest()==row['sha256']
summary={'exit':run.returncode,'source_and_retained_binaries_unchanged':True}
report=s/'debug-second-visual/report.json'
if report.exists():
 r=json.loads(report.read_text())
 summary['failed']=r['failed']
 summary['scenarios']=[{'name':x['name'],'failed':x['failed'],'checks':len(x['checks']),'frames':len(x['steps']),'findings':x['findings']}for x in r['scenarios']]
(s/'debug-second-result.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(summary))
raise SystemExit(run.returncode)
