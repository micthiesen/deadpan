from pathlib import Path
import subprocess,json,hashlib,time,shutil
s=Path('/tmp/deadpan-explicit-node-selectors-2026-10-22')
exe=Path('target/debug/deps/explicit_node_selectors-60975d8d36b2b4bc')
target=s/'baseline-bin'/exe.name
target.parent.mkdir(exist_ok=True)
shutil.copy2(exe,target)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
identity={'path':str(target),'sha256':sha(target)}
start=time.monotonic()
run=subprocess.run([str(target),'--exact','explicit_node_selector_admits_after_nested_child_and_empty_identity_controls','--nocapture'],capture_output=True,text=True)
(s/'baseline-run.stdout').write_text(run.stdout)
(s/'baseline-run.stderr').write_text(run.stderr)
expected=run.returncode==101 and ('unknown variant '+chr(96)+'node'+chr(96)) in run.stderr and 'Explicit Node selector admission must follow all public controls' in run.stderr and '0 passed; 1 failed' in run.stdout
result={'returncode':run.returncode,'seconds':time.monotonic()-start,'expected_sole_admission_failure':expected,'binary':identity}
(s/'baseline-result.json').write_text(json.dumps(result,indent=2)+'\n')
subprocess.run(['python',str(s/'guard.py'),'baseline'],check=True)
assert expected,run.stdout+run.stderr
base=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
paths=subprocess.check_output(['git','ls-tree','-r','--name-only',base],text=True).splitlines()
paths=[p for p in paths if p.endswith('.rs')]
requests=''.join(f'{base}:{p}\n' for p in paths).encode()
raw=subprocess.check_output(['git','cat-file','--batch'],input=requests)
offset=0
changes=[]
for p in paths:
 end=raw.index(b'\n',offset); header=raw[offset:end].split(); size=int(header[2]); offset=end+1
 data=raw[offset:offset+size];offset+=size+1
 if sha(Path(p))!=hashlib.sha256(data).hexdigest(): changes.append(p)
assert not changes,changes
new=sorted(set(json.loads((s/'baseline-source-identities.json').read_text()))-set(paths))
assert new==['crates/deadpan-core/tests/explicit_node_selectors.rs'],new
proof={'base_revision':base,'base_tracked_rust':len(paths),'unchanged':len(paths),'changed':changes,'new_rust':new,'all_public_controls_passed_before_sole_final_admission_failure':True}
(s/'baseline-git-proof.json').write_text(json.dumps(proof,indent=2)+'\n')
print(json.dumps(result));print(json.dumps(proof))
