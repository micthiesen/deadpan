from pathlib import Path
import subprocess,json,hashlib,os
s=Path('/tmp/deadpan-explicit-node-selectors-2026-10-22')
env=dict(os.environ,DEADPAN_FFMPEG_PREFIX='/Users/michael/Library/Developer/Deadpan/ffmpeg-8.0.3-opus-1.6.1-dav1d-1.5.4-qualified-3/prefix',CARGO_PROFILE_DEV_OPT_LEVEL='2')
subprocess.run(['python',str(s/'freeze.py'),'registry-second'],check=True)
with (s/'registry-second-list.json').open('w') as out,(s/'registry-second-build.log').open('w') as err:
 r=subprocess.run(['cargo','nextest','list','--locked','-p','deadpan-app','--features','ui-harness','--bin','deadpan-app','-E','test(navigation::registry::tests)','--message-format','json'],stdout=out,stderr=err,env=env)
assert r.returncode==0
subprocess.run(['python',str(s/'guard.py'),'registry-second'],check=True)
suites=json.loads((s/'registry-second-list.json').read_text())['rust-suites']
matched=[x for x in suites.values() if x.get('status')=='listed']
assert len(matched)==1
p=Path(matched[0]['binary-path']);identity=hashlib.sha256(p.read_bytes()).hexdigest()
test='navigation::registry::tests::routing_matches_the_pre_registry_baseline'
r=subprocess.run([str(p),'--exact',test,'--nocapture'],capture_output=True,text=True,env=dict(env,DEADPAN_UPDATE_ROUTING_BASELINE='1'))
(s/'registry-second-generate.stdout').write_text(r.stdout)
(s/'registry-second-generate.stderr').write_text(r.stderr)
assert r.returncode==101 and 'rewritten; review the diff' in r.stderr
(s/'registry-second-receipt.json').write_text(json.dumps({'exit':r.returncode,'expected_rewrite_failure':True,'binary':str(p),'sha256':identity,'reason':'Completion baseline filters against compiled-in previous verb usage; second generation includes the new select usage.'},indent=2)+'\n')
print('Second registry generation complete; review exact diff and run without rewrite flags.',flush=True)
