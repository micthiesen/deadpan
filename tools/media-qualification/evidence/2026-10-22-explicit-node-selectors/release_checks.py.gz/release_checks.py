from pathlib import Path
import subprocess,hashlib,json,shutil,os,time
s=Path('/tmp/deadpan-explicit-node-selectors-2026-10-22')
env=dict(os.environ,DEADPAN_FFMPEG_PREFIX='/Users/michael/Library/Developer/Deadpan/ffmpeg-8.0.3-opus-1.6.1-dav1d-1.5.4-qualified-3/prefix',CARGO_PROFILE_DEV_OPT_LEVEL='2',DEADPAN_REQUIRE_PHYSICAL_MAC='1',DEADPAN_REQUIRE_SYNTHETIC_WORKER='1')
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def run(name,args,extra=None):
 started=time.monotonic()
 with (s/(name+'.log')).open('w') as log:
  result=subprocess.run(args,stdout=log,stderr=subprocess.STDOUT,env=dict(env,**(extra or {})))
 row={'command':args,'exit':result.returncode,'seconds':time.monotonic()-started}
 (s/(name+'-receipt.json')).write_text(json.dumps(row,indent=2)+'\n')
 print(name,json.dumps(row),flush=True)
 if result.returncode: raise SystemExit(result.returncode)
def guard(): subprocess.run(['python',str(s/'guard.py'),'release-final'],env=env,check=True)
checks=json.loads((s/'strict-final-results.json').read_text())
assert len(checks)==4 and all(row['exit']==0 for row in checks)
subprocess.run(['python',str(s/'guard.py'),'broad-first'],env=env,check=True)
subprocess.run(['python',str(s/'freeze.py'),'release-final'],env=env,check=True)
run('release-app-build',['cargo','build','--locked','-p','deadpan-app','--release','--features','ui-harness','--bin','deadpan-app'])
binaries={}
for name in ['deadpan-app','deadpan-media-worker','deadpan-transcribe','deadpan-track']:
 p=Path('target/release')/name; target=s/'release-bin'/name
 target.parent.mkdir(exist_ok=True);shutil.copy2(p,target)
 binaries[name]={'source':str(p),'executed':str(target),'sha256':sha(p),'freshly_built':name=='deadpan-app'}
(s/'release-native-binaries.json').write_text(json.dumps(binaries,indent=2)+'\n')
guard()
kestrel='/Users/michael/.dotfiles/kestrel/Sources/Kestrel/Shortcuts.swift'
(s/'kestrel-source.json').write_text(json.dumps({'path':kestrel,'sha256':sha(Path(kestrel))},indent=2)+'\n')
for mode in ['visual','performance']:
 if mode=='performance':
  processes=subprocess.check_output(['ps','-axo','pid,ppid,etime,pcpu,comm'],text=True)
  conflicts=[line for line in processes.splitlines() if any(x in line.split()[-1] for x in ['cargo','rustc','deadpan'])]
  (s/'pre-performance-processes.json').write_text(json.dumps(conflicts,indent=2)+'\n')
  assert not conflicts,conflicts
  (s/'power.txt').write_text(subprocess.check_output(['pmset','-g','batt'],text=True))
 run('release-'+mode,[binaries['deadpan-app']['executed'],'--ui-check','--scenario','explicit-node-selectors','--mode',mode,'--output',str(s/('release-'+mode)),'--kestrel-source',kestrel])
 guard()
 for row in binaries.values(): assert sha(Path(row['executed']))==row['sha256']
report={}
for mode in ['visual','performance']:
 r=json.loads((s/('release-'+mode)/'report.json').read_text())
 report[mode]={'failed':r['failed'],'metadata':r['metadata'],'scenarios':[{'name':x['name'],'failed':x['failed'],'checks':len(x['checks']),'frames':len(x['steps']),'findings':x['findings'],'timings':{t['name']:t['summary']for t in x['timings']}}for x in r['scenarios']]}
(s/'release-native-summary.json').write_text(json.dumps(report,indent=2)+'\n')
expression='test(explicit_node_export_reresolves_after_hold_growth_whole_cut_and_repeat)'
args=['cargo','nextest','list','--release','--locked','-p','deadpan-cli','--test','preview_export','-E',expression,'--message-format','json']
with (s/'release-media-list.json').open('w') as out,(s/'release-media-build.log').open('w') as err:
 subprocess.run(args,stdout=out,stderr=err,env=env,check=True)
listing=json.loads((s/'release-media-list.json').read_text()); rows={}
for key,value in listing['rust-suites'].items():
 if value['status']=='listed': rows[key]=Path(value['binary-path'])
for name in ['deadpan-cli','deadpan-media-worker','deadpan-transcribe','deadpan-track']:
 rows[name]=Path('target/release')/name
identities={}
for key,p in rows.items():
 target=s/'release-media-bin'/p.name;target.parent.mkdir(exist_ok=True);shutil.copy2(p,target)
 identities[key]={'path':str(p.resolve()),'retained':str(target),'sha256':sha(p),'bytes':p.stat().st_size}
(s/'release-media-binaries.json').write_text(json.dumps(identities,indent=2)+'\n')
guard()
run('release-media',['cargo','nextest','run','--release','--locked','-p','deadpan-cli','--test','preview_export','--no-fail-fast','-E',expression],{'DEADPAN_PREVIEW_EXPORT_KEEP':'1','DEADPAN_PREVIEW_EXPORT_RESULTS':str(s/'release-media-result.json')})
guard()
for row in identities.values(): assert sha(Path(row['path']))==row['sha256'] and sha(Path(row['retained']))==row['sha256']
(s/'release-final-post.json').write_text(json.dumps({'sources_inputs_native_and_media_binaries_unchanged':True},indent=2)+'\n')
