from pathlib import Path
import subprocess,os,json,time,hashlib,shutil
s=Path('/tmp/deadpan-explicit-node-selectors-2026-10-22')
env=dict(os.environ,DEADPAN_FFMPEG_PREFIX='/Users/michael/Library/Developer/Deadpan/ffmpeg-8.0.3-opus-1.6.1-dav1d-1.5.4-qualified-3/prefix',CARGO_PROFILE_DEV_OPT_LEVEL='2',DEADPAN_REQUIRE_PHYSICAL_MAC='1',DEADPAN_REQUIRE_SYNTHETIC_WORKER='1')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
subprocess.run(['python',str(s/'guard.py'),'broad-first'],env=env,check=True)
archive=s/'ui-tests.tar.zst';target=s/'ui-relocated';before=sha(archive)
target.mkdir(exist_ok=True)
reuse=['--archive-file',str(archive),'--extract-to',str(target),'--extract-overwrite','--workspace-remap',str(Path.cwd())]
with (s/'ui-relocated-list.json').open('w') as out,(s/'ui-relocated-list.log').open('w') as err:
 subprocess.run(['cargo','nextest','list',*reuse,'--message-format','json'],stdout=out,stderr=err,env=env,check=True)
listing=json.loads((s/'ui-relocated-list.json').read_text());old=json.loads((s/'ui-final-binaries.json').read_text());rows={}
for key,row in listing['rust-suites'].items():
 tests=[name for name,case in row.get('testcases',{}).items() if case.get('filter-match',{}).get('status')=='matches']
 if not tests:continue
 p=Path(row['binary-path']);assert p.resolve().is_relative_to(target.resolve()),(p,target)
 assert sha(p)==old[key]['sha256']
 assert sorted(tests)==sorted(old[key]['tests'])
 rows[key]={'path':str(p),'sha256':sha(p),'tests':tests}
assert sum(len(r['tests']) for r in rows.values())==1270
for key,r in old.items():
 if key.startswith('helper-'):
  matches=list(target.rglob(Path(r['path']).name))
  if not matches:
   destination=target/'target'/Path(r['path']).resolve().relative_to(Path.cwd()/'target')
   destination.parent.mkdir(parents=True,exist_ok=True)
   shutil.copy2(r['path'],destination)
   matches=[destination]
  assert len(matches)==1,(key,matches)
  assert sha(matches[0])==r['sha256']
  rows[key]={'path':str(matches[0]),'sha256':r['sha256']}
(s/'ui-relocated-binaries.json').write_text(json.dumps(rows,indent=2)+'\n')
started=time.monotonic()
args=['cargo','nextest','run','--archive-file',str(archive),'--extract-to',str(target),'--extract-overwrite','--workspace-remap',str(Path.cwd()),'--test-threads','8','--no-fail-fast']
with (s/'ui-relocated.log').open('w') as log:
 r=subprocess.run(args,stdout=log,stderr=subprocess.STDOUT,env=env)
subprocess.run(['python',str(s/'guard.py'),'broad-first'],env=env,check=True)
assert sha(archive)==before
for row in rows.values():assert sha(Path(row['path']))==row['sha256']
receipt={'exit':r.returncode,'tests':1270,'seconds':time.monotonic()-started,'command':args,'archive_sha256':before,'sources_inputs_binaries_unchanged':True,'same_cases_and_executable_hashes_as_ui_final':True,'test_threads':8}
(s/'ui-relocated-result.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt),flush=True)
raise SystemExit(r.returncode)
