use std::{collections::BTreeMap,error::Error,path::Path};
use deadpan_core::*;
use deadpan_store::{AccessMode,ProjectStore,DATABASE_SCHEMA_VERSION};
type Result<T=()> = std::result::Result<T,Box<dyn Error>>;
fn node(value: &str) -> NodeId {
    NodeId::new(value).unwrap()
}

fn bound_initial() -> Result<ProjectDocument> {
    let empty = ProjectDocument::new(
        ProjectId::new("pause-project")?,
        RevisionId::new("initial")?,
        PresentationBasis {
            width: 16,
            height: 16,
            frame_rate: FrameRate::new(30_000, 1001)?,
            color_policy: ColorPolicy::SdrRec709,
        },
        node("root"),
    )?;
    let mut wire = serde_json::to_value(empty)?;
    wire["nodes"] = serde_json::to_value(BTreeMap::from([
        (node("root"), BeatNode::sequence("Root", vec![node("hold")])),
        (
            node("hold"),
            BeatNode::hold(
                "Original hold",
                HoldRecipe {
                    duration: FrameDuration::new(6)?,
                    video: HoldVideo::Background,
                    audio: HoldAudio::Silence,
                },
            ),
        ),
    ]))?;
    let unbound = ProjectDocument::from_json(&wire.to_string())?;
    let captured = capture_unbound_audio_bindings(
        &unbound,
        AudioTimingId {
            allocation: RevisionId::new("old-timing")?,
            ordinal: 0,
        },
    )?;
    wire["audio_bindings"] = serde_json::to_value(&captured)?;
    wire["audio_bindings"]["bindings"]["hold"]["resume"] = serde_json::to_value(AudioResume {
        local_boundary: ExactRatio::ONE,
        phase: AudioLocalPhase {
            constant: ExactRatio::new(1, 7)?,
            terms: vec![AudioPhaseTerm {
                placement: captured.bindings()[&node("hold")].lattice.clone(),
                from_local: ExactRatio::ZERO,
                to_local: ExactRatio::ONE,
            }],
        },
    })?;
    Ok(ProjectDocument::from_json(&wire.to_string())?)
}

fn command(document: &ProjectDocument, revision: &str, command: Command) -> CommandRequest {
    CommandRequest {
        project_id: document.project_id().clone(),
        expected_revision: document.revision_id().clone(),
        new_revision: RevisionId::new(revision).unwrap(),
        command,
    }
}

fn fixture(path: &Path) -> Result<ProjectDocument> {
    let initial = bound_initial()?;
    let mut store = ProjectStore::create(path, &initial)?;
    store.commit(&command(
        &initial,
        "split",
        Command::Split {
            node: node("hold"),
            at: FrameDuration::new(2)?,
            identities: SplitIdentities {
                nodes: vec![node("left"), node("right"), node("copy")],
            },
        },
    ))?;
    store.commit(&command(
        &store.snapshot()?,
        "rename",
        Command::Rename {
            node: node("copy"),
            label: "Renamed right hold".into(),
        },
    ))?;
    store.undo(&RevisionId::new("rename")?, RevisionId::new("undo-name")?)?;
    store.redo(
        &RevisionId::new("undo-name")?,
        RevisionId::new("redo-name")?,
    )?;
    store.undo(
        &RevisionId::new("redo-name")?,
        RevisionId::new("pending-redo")?,
    )?;
    let current = store.snapshot()?;
    store.validate()?;
    drop(store);
    Ok(current)
}

fn main() -> Result {
    assert_eq!(DOCUMENT_SCHEMA_VERSION,16);
    assert_eq!(DATABASE_SCHEMA_VERSION,22);
    let path=std::env::args().nth(1).expect("package path");
    let current=fixture(Path::new(&path))?;
    ProjectStore::open(Path::new(&path),AccessMode::ReadOnly)?.validate()?;
    println!("{}",serde_json::to_string_pretty(&serde_json::json!({
        "core_schema":DOCUMENT_SCHEMA_VERSION,
        "database_schema":DATABASE_SCHEMA_VERSION,
        "document":current,
    }))?);
    Ok(())
}
