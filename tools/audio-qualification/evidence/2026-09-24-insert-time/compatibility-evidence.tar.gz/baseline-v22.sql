BEGIN TRANSACTION;
CREATE TABLE generation_attempt_heads (
    request_id TEXT PRIMARY KEY REFERENCES generation_requests(request_id),
    high_water INTEGER NOT NULL CHECK (high_water BETWEEN 1 AND 9223372036854775807),
    latest_attempt_id TEXT NOT NULL,
    selected_ready_attempt_id TEXT,
    FOREIGN KEY (request_id,latest_attempt_id)
        REFERENCES generation_attempts(request_id,attempt_id),
    FOREIGN KEY (request_id,selected_ready_attempt_id)
        REFERENCES generation_attempts(request_id,attempt_id)
) STRICT;
CREATE TABLE generation_attempts (
    request_id TEXT NOT NULL REFERENCES generation_requests(request_id),
    attempt_id TEXT NOT NULL,
    ordinal INTEGER NOT NULL CHECK (ordinal BETWEEN 1 AND 9223372036854775807),
    cancellation_token TEXT NOT NULL,
    state TEXT NOT NULL CHECK (state IN (
        'queued','preflight','loading','running','validating','ready','failed','cancelling','cancelled'
    )),
    worker_stage TEXT CHECK (worker_stage IS NULL OR worker_stage IN (
        'preflight','runtime_loading','model_loading','conditioning','inference',
        'decoding','encoding','worker_validation'
    )),
    transition_sequence INTEGER NOT NULL
        CHECK (transition_sequence BETWEEN 1 AND 9223372036854775807),
    cancel_response TEXT CHECK (cancel_response IS NULL OR cancel_response IN ('cancelled','completed')),
    worker_candidate TEXT CHECK (worker_candidate IS NULL OR json_valid(worker_candidate)),
    failure_origin TEXT CHECK (failure_origin IS NULL OR failure_origin IN ('worker','host')),
    failure_code TEXT,
    failure_detail TEXT,
    PRIMARY KEY (request_id,attempt_id),
    UNIQUE (request_id,ordinal),
    CHECK ((failure_origin IS NULL) = (failure_code IS NULL)),
    CHECK ((failure_origin IS NULL) = (failure_detail IS NULL)),
    CHECK (cancel_response!='completed' OR worker_candidate IS NOT NULL)
) STRICT;
CREATE TABLE generation_bundle_receipts (
    request_id TEXT NOT NULL,
    attempt_id TEXT NOT NULL,
    bundle TEXT NOT NULL CHECK (json_valid(bundle)),
    availability TEXT NOT NULL CHECK (availability IN ('present','evicted')),
    PRIMARY KEY (request_id,attempt_id),
    FOREIGN KEY (request_id,attempt_id)
        REFERENCES generation_attempts(request_id,attempt_id)
) STRICT;
CREATE TABLE generation_candidate_receipts (
    request_id TEXT NOT NULL,
    attempt_id TEXT NOT NULL,
    staged_ref TEXT NOT NULL UNIQUE,
    sha256 TEXT NOT NULL,
    byte_length INTEGER NOT NULL CHECK (byte_length BETWEEN 1 AND 9223372036854775807),
    video TEXT NOT NULL CHECK (json_valid(video)),
    provider TEXT NOT NULL CHECK (json_valid(provider)),
    validator_id TEXT NOT NULL,
    validator_version TEXT NOT NULL,
    availability TEXT NOT NULL CHECK (availability IN ('present','evicted')),
    PRIMARY KEY (request_id,attempt_id),
    FOREIGN KEY (request_id,attempt_id)
        REFERENCES generation_attempts(request_id,attempt_id)
) STRICT;
CREATE TABLE generation_requests (
    request_id TEXT PRIMARY KEY,
    project_id TEXT NOT NULL,
    hold_id TEXT NOT NULL,
    request_version INTEGER NOT NULL
        CHECK (request_version BETWEEN 1 AND 9223372036854775807),
    origin_revision TEXT NOT NULL REFERENCES revisions(id),
    context_sha256 TEXT NOT NULL,
    constraints TEXT NOT NULL CHECK (json_valid(constraints)),
    provider TEXT NOT NULL CHECK (json_valid(provider)),
    bridge_plan TEXT CHECK (bridge_plan IS NULL OR json_valid(bridge_plan)),
    relevance TEXT NOT NULL CHECK (relevance IN ('current','stale','detached')),
    UNIQUE (hold_id, request_version)
) STRICT;
CREATE TABLE history (
            id INTEGER PRIMARY KEY,
            parent_id INTEGER REFERENCES history(id),
            revision_id TEXT NOT NULL REFERENCES revisions(id),
            request TEXT NOT NULL CHECK (json_valid(request)),
            edit TEXT NOT NULL CHECK (json_valid(edit))
        ) STRICT;
INSERT INTO "history" VALUES(1,NULL,'split','{"project_id":"pause-project","expected_revision":"initial","new_revision":"split","command":{"command":"split","node":"hold","at":2,"identities":{"nodes":["left","right","copy"]}}}','{"forward":{"project_id":"pause-project","from_revision":"initial","to_revision":"split","nodes":{"copy":{"before":null,"after":{"label":"Original hold","kind":{"type":"hold","recipe":{"duration":6,"video":{"type":"background"},"audio":{"type":"silence"}}}}},"left":{"before":null,"after":{"label":"Original hold","kind":{"type":"retime","child":"hold","duration":2,"mapping":{"start":0,"end":2},"pitch":"preserve","purpose":"partition"}}},"right":{"before":null,"after":{"label":"Original hold","kind":{"type":"retime","child":"copy","duration":4,"mapping":{"start":2,"end":6},"pitch":"preserve","purpose":"partition"}}},"root":{"before":{"label":"Root","kind":{"type":"sequence","children":["hold"]}},"after":{"label":"Root","kind":{"type":"sequence","children":["left","right"]}}}},"assets":{},"marks":{},"overrides":{},"audio_lineage":{"copy":{"before":null,"after":{"allocation":"split","origin":"hold"}},"hold":{"before":null,"after":{"allocation":"split","origin":"hold"}}},"audio_bindings":{"before":{"timings":[{"id":{"allocation":"old-timing","ordinal":0},"layout":{"root":"root","rate":{"numerator":30000,"denominator":1001},"nodes":{"hold":{"duration":6,"edges":{"node_start":"automatic","node_end":"automatic","source_placement_start":"automatic","source_placement_end":"automatic","repeat_gap_start":"automatic","repeat_gap_end":"automatic"},"kind":{"type":"hold","audio":{"type":"silence"}}},"root":{"duration":6,"edges":{"node_start":"automatic","node_end":"automatic","source_placement_start":"automatic","source_placement_end":"automatic","repeat_gap_start":"automatic","repeat_gap_end":"automatic"},"kind":{"type":"sequence","children":["hold"]}}},"overrides":{}}}],"bindings":{"hold":{"lattice":{"reference":{"timing":{"allocation":"old-timing","ordinal":0},"root":{"type":"project_root_round_even"},"physical":"hold"},"arguments":[],"births":[]},"resume":{"local_boundary":{"numerator":"1","denominator":"1"},"phase":{"constant":{"numerator":"1","denominator":"7"},"terms":[{"placement":{"reference":{"timing":{"allocation":"old-timing","ordinal":0},"root":{"type":"project_root_round_even"},"physical":"hold"},"arguments":[],"births":[]},"from_local":{"numerator":"0","denominator":"1"},"to_local":{"numerator":"1","denominator":"1"}}]}}}}},"after":{"timings":[{"id":{"allocation":"old-timing","ordinal":0},"layout":{"root":"root","rate":{"numerator":30000,"denominator":1001},"nodes":{"hold":{"duration":6,"edges":{"node_start":"automatic","node_end":"automatic","source_placement_start":"automatic","source_placement_end":"automatic","repeat_gap_start":"automatic","repeat_gap_end":"automatic"},"kind":{"type":"hold","audio":{"type":"silence"}}},"root":{"duration":6,"edges":{"node_start":"automatic","node_end":"automatic","source_placement_start":"automatic","source_placement_end":"automatic","repeat_gap_start":"automatic","repeat_gap_end":"automatic"},"kind":{"type":"sequence","children":["hold"]}}},"overrides":{}}}],"bindings":{"copy":{"lattice":{"reference":{"timing":{"allocation":"old-timing","ordinal":0},"root":{"type":"project_root_round_even"},"physical":"hold"},"arguments":[],"births":[]},"resume":{"local_boundary":{"numerator":"1","denominator":"1"},"phase":{"constant":{"numerator":"1","denominator":"7"},"terms":[{"placement":{"reference":{"timing":{"allocation":"old-timing","ordinal":0},"root":{"type":"project_root_round_even"},"physical":"hold"},"arguments":[],"births":[]},"from_local":{"numerator":"0","denominator":"1"},"to_local":{"numerator":"1","denominator":"1"}}]}}},"hold":{"lattice":{"reference":{"timing":{"allocation":"old-timing","ordinal":0},"root":{"type":"project_root_round_even"},"physical":"hold"},"arguments":[],"births":[]},"resume":{"local_boundary":{"numerator":"1","denominator":"1"},"phase":{"constant":{"numerator":"1","denominator":"7"},"terms":[{"placement":{"reference":{"timing":{"allocation":"old-timing","ordinal":0},"root":{"type":"project_root_round_even"},"physical":"hold"},"arguments":[],"births":[]},"from_local":{"numerator":"0","denominator":"1"},"to_local":{"numerator":"1","denominator":"1"}}]}}}}}}},"inverse":{"project_id":"pause-project","from_revision":"split","to_revision":"initial","nodes":{"copy":{"before":{"label":"Original hold","kind":{"type":"hold","recipe":{"duration":6,"video":{"type":"background"},"audio":{"type":"silence"}}}},"after":null},"left":{"before":{"label":"Original hold","kind":{"type":"retime","child":"hold","duration":2,"mapping":{"start":0,"end":2},"pitch":"preserve","purpose":"partition"}},"after":null},"right":{"before":{"label":"Original hold","kind":{"type":"retime","child":"copy","duration":4,"mapping":{"start":2,"end":6},"pitch":"preserve","purpose":"partition"}},"after":null},"root":{"before":{"label":"Root","kind":{"type":"sequence","children":["left","right"]}},"after":{"label":"Root","kind":{"type":"sequence","children":["hold"]}}}},"assets":{},"marks":{},"overrides":{},"audio_lineage":{"copy":{"before":{"allocation":"split","origin":"hold"},"after":null},"hold":{"before":{"allocation":"split","origin":"hold"},"after":null}},"audio_bindings":{"before":{"timings":[{"id":{"allocation":"old-timing","ordinal":0},"layout":{"root":"root","rate":{"numerator":30000,"denominator":1001},"nodes":{"hold":{"duration":6,"edges":{"node_start":"automatic","node_end":"automatic","source_placement_start":"automatic","source_placement_end":"automatic","repeat_gap_start":"automatic","repeat_gap_end":"automatic"},"kind":{"type":"hold","audio":{"type":"silence"}}},"root":{"duration":6,"edges":{"node_start":"automatic","node_end":"automatic","source_placement_start":"automatic","source_placement_end":"automatic","repeat_gap_start":"automatic","repeat_gap_end":"automatic"},"kind":{"type":"sequence","children":["hold"]}}},"overrides":{}}}],"bindings":{"copy":{"lattice":{"reference":{"timing":{"allocation":"old-timing","ordinal":0},"root":{"type":"project_root_round_even"},"physical":"hold"},"arguments":[],"births":[]},"resume":{"local_boundary":{"numerator":"1","denominator":"1"},"phase":{"constant":{"numerator":"1","denominator":"7"},"terms":[{"placement":{"reference":{"timing":{"allocation":"old-timing","ordinal":0},"root":{"type":"project_root_round_even"},"physical":"hold"},"arguments":[],"births":[]},"from_local":{"numerator":"0","denominator":"1"},"to_local":{"numerator":"1","denominator":"1"}}]}}},"hold":{"lattice":{"reference":{"timing":{"allocation":"old-timing","ordinal":0},"root":{"type":"project_root_round_even"},"physical":"hold"},"arguments":[],"births":[]},"resume":{"local_boundary":{"numerator":"1","denominator":"1"},"phase":{"constant":{"numerator":"1","denominator":"7"},"terms":[{"placement":{"reference":{"timing":{"allocation":"old-timing","ordinal":0},"root":{"type":"project_root_round_even"},"physical":"hold"},"arguments":[],"births":[]},"from_local":{"numerator":"0","denominator":"1"},"to_local":{"numerator":"1","denominator":"1"}}]}}}}},"after":{"timings":[{"id":{"allocation":"old-timing","ordinal":0},"layout":{"root":"root","rate":{"numerator":30000,"denominator":1001},"nodes":{"hold":{"duration":6,"edges":{"node_start":"automatic","node_end":"automatic","source_placement_start":"automatic","source_placement_end":"automatic","repeat_gap_start":"automatic","repeat_gap_end":"automatic"},"kind":{"type":"hold","audio":{"type":"silence"}}},"root":{"duration":6,"edges":{"node_start":"automatic","node_end":"automatic","source_placement_start":"automatic","source_placement_end":"automatic","repeat_gap_start":"automatic","repeat_gap_end":"automatic"},"kind":{"type":"sequence","children":["hold"]}}},"overrides":{}}}],"bindings":{"hold":{"lattice":{"reference":{"timing":{"allocation":"old-timing","ordinal":0},"root":{"type":"project_root_round_even"},"physical":"hold"},"arguments":[],"births":[]},"resume":{"local_boundary":{"numerator":"1","denominator":"1"},"phase":{"constant":{"numerator":"1","denominator":"7"},"terms":[{"placement":{"reference":{"timing":{"allocation":"old-timing","ordinal":0},"root":{"type":"project_root_round_even"},"physical":"hold"},"arguments":[],"births":[]},"from_local":{"numerator":"0","denominator":"1"},"to_local":{"numerator":"1","denominator":"1"}}]}}}}}}},"changed_ids":["copy","hold","left","right","root"],"duration_delta":0,"description":"Split beat"}');
INSERT INTO "history" VALUES(2,1,'rename','{"project_id":"pause-project","expected_revision":"split","new_revision":"rename","command":{"command":"rename","node":"copy","label":"Renamed right hold"}}','{"forward":{"project_id":"pause-project","from_revision":"split","to_revision":"rename","nodes":{"copy":{"before":{"label":"Original hold","kind":{"type":"hold","recipe":{"duration":6,"video":{"type":"background"},"audio":{"type":"silence"}}}},"after":{"label":"Renamed right hold","kind":{"type":"hold","recipe":{"duration":6,"video":{"type":"background"},"audio":{"type":"silence"}}}}}},"assets":{},"marks":{},"overrides":{}},"inverse":{"project_id":"pause-project","from_revision":"rename","to_revision":"split","nodes":{"copy":{"before":{"label":"Renamed right hold","kind":{"type":"hold","recipe":{"duration":6,"video":{"type":"background"},"audio":{"type":"silence"}}}},"after":{"label":"Original hold","kind":{"type":"hold","recipe":{"duration":6,"video":{"type":"background"},"audio":{"type":"silence"}}}}}},"assets":{},"marks":{},"overrides":{}},"changed_ids":["copy"],"duration_delta":0,"description":"Rename beat"}');
CREATE TABLE hold_request_clocks (
    hold_id TEXT PRIMARY KEY,
    high_water INTEGER NOT NULL
        CHECK (high_water BETWEEN 1 AND 9223372036854775807)
) STRICT;
CREATE TABLE original_media (
        content_id TEXT PRIMARY KEY,
        version INTEGER NOT NULL CHECK(version > 0),
        record TEXT NOT NULL CHECK(json_valid(record))
    ) STRICT;
CREATE TABLE redo (
            position INTEGER PRIMARY KEY,
            history_id INTEGER NOT NULL REFERENCES history(id)
        ) STRICT;
INSERT INTO "redo" VALUES(1,2);
CREATE TABLE revisions (
            id TEXT PRIMARY KEY,
            parent_id TEXT REFERENCES revisions(id),
            kind TEXT NOT NULL CHECK (kind IN ('initial','edit','undo','redo')),
            document TEXT NOT NULL CHECK (json_valid(document))
        ) STRICT;
INSERT INTO "revisions" VALUES('initial',NULL,'initial','{
  "schema_version": 16,
  "project_id": "pause-project",
  "revision_id": "initial",
  "presentation_basis": {
    "width": 16,
    "height": 16,
    "frame_rate": {
      "numerator": 30000,
      "denominator": 1001
    },
    "color_policy": "sdr_rec709"
  },
  "basis_state": {
    "rate_origin": "explicit",
    "geometry_origin": "explicit",
    "primary": null
  },
  "root": "root",
  "nodes": {
    "hold": {
      "label": "Original hold",
      "kind": {
        "type": "hold",
        "recipe": {
          "duration": 6,
          "video": {
            "type": "background"
          },
          "audio": {
            "type": "silence"
          }
        }
      }
    },
    "root": {
      "label": "Root",
      "kind": {
        "type": "sequence",
        "children": [
          "hold"
        ]
      }
    }
  },
  "assets": {},
  "marks": {},
  "overrides": {},
  "audio_bindings": {
    "timings": [
      {
        "id": {
          "allocation": "old-timing",
          "ordinal": 0
        },
        "layout": {
          "root": "root",
          "rate": {
            "numerator": 30000,
            "denominator": 1001
          },
          "nodes": {
            "hold": {
              "duration": 6,
              "edges": {
                "node_start": "automatic",
                "node_end": "automatic",
                "source_placement_start": "automatic",
                "source_placement_end": "automatic",
                "repeat_gap_start": "automatic",
                "repeat_gap_end": "automatic"
              },
              "kind": {
                "type": "hold",
                "audio": {
                  "type": "silence"
                }
              }
            },
            "root": {
              "duration": 6,
              "edges": {
                "node_start": "automatic",
                "node_end": "automatic",
                "source_placement_start": "automatic",
                "source_placement_end": "automatic",
                "repeat_gap_start": "automatic",
                "repeat_gap_end": "automatic"
              },
              "kind": {
                "type": "sequence",
                "children": [
                  "hold"
                ]
              }
            }
          },
          "overrides": {}
        }
      }
    ],
    "bindings": {
      "hold": {
        "lattice": {
          "reference": {
            "timing": {
              "allocation": "old-timing",
              "ordinal": 0
            },
            "root": {
              "type": "project_root_round_even"
            },
            "physical": "hold"
          },
          "arguments": [],
          "births": []
        },
        "resume": {
          "local_boundary": {
            "numerator": "1",
            "denominator": "1"
          },
          "phase": {
            "constant": {
              "numerator": "1",
              "denominator": "7"
            },
            "terms": [
              {
                "placement": {
                  "reference": {
                    "timing": {
                      "allocation": "old-timing",
                      "ordinal": 0
                    },
                    "root": {
                      "type": "project_root_round_even"
                    },
                    "physical": "hold"
                  },
                  "arguments": [],
                  "births": []
                },
                "from_local": {
                  "numerator": "0",
                  "denominator": "1"
                },
                "to_local": {
                  "numerator": "1",
                  "denominator": "1"
                }
              }
            ]
          }
        }
      }
    }
  }
}
');
INSERT INTO "revisions" VALUES('split','initial','edit','{
  "schema_version": 16,
  "project_id": "pause-project",
  "revision_id": "split",
  "presentation_basis": {
    "width": 16,
    "height": 16,
    "frame_rate": {
      "numerator": 30000,
      "denominator": 1001
    },
    "color_policy": "sdr_rec709"
  },
  "basis_state": {
    "rate_origin": "explicit",
    "geometry_origin": "explicit",
    "primary": null
  },
  "root": "root",
  "nodes": {
    "copy": {
      "label": "Original hold",
      "kind": {
        "type": "hold",
        "recipe": {
          "duration": 6,
          "video": {
            "type": "background"
          },
          "audio": {
            "type": "silence"
          }
        }
      }
    },
    "hold": {
      "label": "Original hold",
      "kind": {
        "type": "hold",
        "recipe": {
          "duration": 6,
          "video": {
            "type": "background"
          },
          "audio": {
            "type": "silence"
          }
        }
      }
    },
    "left": {
      "label": "Original hold",
      "kind": {
        "type": "retime",
        "child": "hold",
        "duration": 2,
        "mapping": {
          "start": 0,
          "end": 2
        },
        "pitch": "preserve",
        "purpose": "partition"
      }
    },
    "right": {
      "label": "Original hold",
      "kind": {
        "type": "retime",
        "child": "copy",
        "duration": 4,
        "mapping": {
          "start": 2,
          "end": 6
        },
        "pitch": "preserve",
        "purpose": "partition"
      }
    },
    "root": {
      "label": "Root",
      "kind": {
        "type": "sequence",
        "children": [
          "left",
          "right"
        ]
      }
    }
  },
  "assets": {},
  "marks": {},
  "overrides": {},
  "audio_lineage": {
    "copy": {
      "allocation": "split",
      "origin": "hold"
    },
    "hold": {
      "allocation": "split",
      "origin": "hold"
    }
  },
  "audio_bindings": {
    "timings": [
      {
        "id": {
          "allocation": "old-timing",
          "ordinal": 0
        },
        "layout": {
          "root": "root",
          "rate": {
            "numerator": 30000,
            "denominator": 1001
          },
          "nodes": {
            "hold": {
              "duration": 6,
              "edges": {
                "node_start": "automatic",
                "node_end": "automatic",
                "source_placement_start": "automatic",
                "source_placement_end": "automatic",
                "repeat_gap_start": "automatic",
                "repeat_gap_end": "automatic"
              },
              "kind": {
                "type": "hold",
                "audio": {
                  "type": "silence"
                }
              }
            },
            "root": {
              "duration": 6,
              "edges": {
                "node_start": "automatic",
                "node_end": "automatic",
                "source_placement_start": "automatic",
                "source_placement_end": "automatic",
                "repeat_gap_start": "automatic",
                "repeat_gap_end": "automatic"
              },
              "kind": {
                "type": "sequence",
                "children": [
                  "hold"
                ]
              }
            }
          },
          "overrides": {}
        }
      }
    ],
    "bindings": {
      "copy": {
        "lattice": {
          "reference": {
            "timing": {
              "allocation": "old-timing",
              "ordinal": 0
            },
            "root": {
              "type": "project_root_round_even"
            },
            "physical": "hold"
          },
          "arguments": [],
          "births": []
        },
        "resume": {
          "local_boundary": {
            "numerator": "1",
            "denominator": "1"
          },
          "phase": {
            "constant": {
              "numerator": "1",
              "denominator": "7"
            },
            "terms": [
              {
                "placement": {
                  "reference": {
                    "timing": {
                      "allocation": "old-timing",
                      "ordinal": 0
                    },
                    "root": {
                      "type": "project_root_round_even"
                    },
                    "physical": "hold"
                  },
                  "arguments": [],
                  "births": []
                },
                "from_local": {
                  "numerator": "0",
                  "denominator": "1"
                },
                "to_local": {
                  "numerator": "1",
                  "denominator": "1"
                }
              }
            ]
          }
        }
      },
      "hold": {
        "lattice": {
          "reference": {
            "timing": {
              "allocation": "old-timing",
              "ordinal": 0
            },
            "root": {
              "type": "project_root_round_even"
            },
            "physical": "hold"
          },
          "arguments": [],
          "births": []
        },
        "resume": {
          "local_boundary": {
            "numerator": "1",
            "denominator": "1"
          },
          "phase": {
            "constant": {
              "numerator": "1",
              "denominator": "7"
            },
            "terms": [
              {
                "placement": {
                  "reference": {
                    "timing": {
                      "allocation": "old-timing",
                      "ordinal": 0
                    },
                    "root": {
                      "type": "project_root_round_even"
                    },
                    "physical": "hold"
                  },
                  "arguments": [],
                  "births": []
                },
                "from_local": {
                  "numerator": "0",
                  "denominator": "1"
                },
                "to_local": {
                  "numerator": "1",
                  "denominator": "1"
                }
              }
            ]
          }
        }
      }
    }
  }
}
');
INSERT INTO "revisions" VALUES('rename','split','edit','{
  "schema_version": 16,
  "project_id": "pause-project",
  "revision_id": "rename",
  "presentation_basis": {
    "width": 16,
    "height": 16,
    "frame_rate": {
      "numerator": 30000,
      "denominator": 1001
    },
    "color_policy": "sdr_rec709"
  },
  "basis_state": {
    "rate_origin": "explicit",
    "geometry_origin": "explicit",
    "primary": null
  },
  "root": "root",
  "nodes": {
    "copy": {
      "label": "Renamed right hold",
      "kind": {
        "type": "hold",
        "recipe": {
          "duration": 6,
          "video": {
            "type": "background"
          },
          "audio": {
            "type": "silence"
          }
        }
      }
    },
    "hold": {
      "label": "Original hold",
      "kind": {
        "type": "hold",
        "recipe": {
          "duration": 6,
          "video": {
            "type": "background"
          },
          "audio": {
            "type": "silence"
          }
        }
      }
    },
    "left": {
      "label": "Original hold",
      "kind": {
        "type": "retime",
        "child": "hold",
        "duration": 2,
        "mapping": {
          "start": 0,
          "end": 2
        },
        "pitch": "preserve",
        "purpose": "partition"
      }
    },
    "right": {
      "label": "Original hold",
      "kind": {
        "type": "retime",
        "child": "copy",
        "duration": 4,
        "mapping": {
          "start": 2,
          "end": 6
        },
        "pitch": "preserve",
        "purpose": "partition"
      }
    },
    "root": {
      "label": "Root",
      "kind": {
        "type": "sequence",
        "children": [
          "left",
          "right"
        ]
      }
    }
  },
  "assets": {},
  "marks": {},
  "overrides": {},
  "audio_lineage": {
    "copy": {
      "allocation": "split",
      "origin": "hold"
    },
    "hold": {
      "allocation": "split",
      "origin": "hold"
    }
  },
  "audio_bindings": {
    "timings": [
      {
        "id": {
          "allocation": "old-timing",
          "ordinal": 0
        },
        "layout": {
          "root": "root",
          "rate": {
            "numerator": 30000,
            "denominator": 1001
          },
          "nodes": {
            "hold": {
              "duration": 6,
              "edges": {
                "node_start": "automatic",
                "node_end": "automatic",
                "source_placement_start": "automatic",
                "source_placement_end": "automatic",
                "repeat_gap_start": "automatic",
                "repeat_gap_end": "automatic"
              },
              "kind": {
                "type": "hold",
                "audio": {
                  "type": "silence"
                }
              }
            },
            "root": {
              "duration": 6,
              "edges": {
                "node_start": "automatic",
                "node_end": "automatic",
                "source_placement_start": "automatic",
                "source_placement_end": "automatic",
                "repeat_gap_start": "automatic",
                "repeat_gap_end": "automatic"
              },
              "kind": {
                "type": "sequence",
                "children": [
                  "hold"
                ]
              }
            }
          },
          "overrides": {}
        }
      }
    ],
    "bindings": {
      "copy": {
        "lattice": {
          "reference": {
            "timing": {
              "allocation": "old-timing",
              "ordinal": 0
            },
            "root": {
              "type": "project_root_round_even"
            },
            "physical": "hold"
          },
          "arguments": [],
          "births": []
        },
        "resume": {
          "local_boundary": {
            "numerator": "1",
            "denominator": "1"
          },
          "phase": {
            "constant": {
              "numerator": "1",
              "denominator": "7"
            },
            "terms": [
              {
                "placement": {
                  "reference": {
                    "timing": {
                      "allocation": "old-timing",
                      "ordinal": 0
                    },
                    "root": {
                      "type": "project_root_round_even"
                    },
                    "physical": "hold"
                  },
                  "arguments": [],
                  "births": []
                },
                "from_local": {
                  "numerator": "0",
                  "denominator": "1"
                },
                "to_local": {
                  "numerator": "1",
                  "denominator": "1"
                }
              }
            ]
          }
        }
      },
      "hold": {
        "lattice": {
          "reference": {
            "timing": {
              "allocation": "old-timing",
              "ordinal": 0
            },
            "root": {
              "type": "project_root_round_even"
            },
            "physical": "hold"
          },
          "arguments": [],
          "births": []
        },
        "resume": {
          "local_boundary": {
            "numerator": "1",
            "denominator": "1"
          },
          "phase": {
            "constant": {
              "numerator": "1",
              "denominator": "7"
            },
            "terms": [
              {
                "placement": {
                  "reference": {
                    "timing": {
                      "allocation": "old-timing",
                      "ordinal": 0
                    },
                    "root": {
                      "type": "project_root_round_even"
                    },
                    "physical": "hold"
                  },
                  "arguments": [],
                  "births": []
                },
                "from_local": {
                  "numerator": "0",
                  "denominator": "1"
                },
                "to_local": {
                  "numerator": "1",
                  "denominator": "1"
                }
              }
            ]
          }
        }
      }
    }
  }
}
');
INSERT INTO "revisions" VALUES('undo-name','rename','undo','{
  "schema_version": 16,
  "project_id": "pause-project",
  "revision_id": "undo-name",
  "presentation_basis": {
    "width": 16,
    "height": 16,
    "frame_rate": {
      "numerator": 30000,
      "denominator": 1001
    },
    "color_policy": "sdr_rec709"
  },
  "basis_state": {
    "rate_origin": "explicit",
    "geometry_origin": "explicit",
    "primary": null
  },
  "root": "root",
  "nodes": {
    "copy": {
      "label": "Original hold",
      "kind": {
        "type": "hold",
        "recipe": {
          "duration": 6,
          "video": {
            "type": "background"
          },
          "audio": {
            "type": "silence"
          }
        }
      }
    },
    "hold": {
      "label": "Original hold",
      "kind": {
        "type": "hold",
        "recipe": {
          "duration": 6,
          "video": {
            "type": "background"
          },
          "audio": {
            "type": "silence"
          }
        }
      }
    },
    "left": {
      "label": "Original hold",
      "kind": {
        "type": "retime",
        "child": "hold",
        "duration": 2,
        "mapping": {
          "start": 0,
          "end": 2
        },
        "pitch": "preserve",
        "purpose": "partition"
      }
    },
    "right": {
      "label": "Original hold",
      "kind": {
        "type": "retime",
        "child": "copy",
        "duration": 4,
        "mapping": {
          "start": 2,
          "end": 6
        },
        "pitch": "preserve",
        "purpose": "partition"
      }
    },
    "root": {
      "label": "Root",
      "kind": {
        "type": "sequence",
        "children": [
          "left",
          "right"
        ]
      }
    }
  },
  "assets": {},
  "marks": {},
  "overrides": {},
  "audio_lineage": {
    "copy": {
      "allocation": "split",
      "origin": "hold"
    },
    "hold": {
      "allocation": "split",
      "origin": "hold"
    }
  },
  "audio_bindings": {
    "timings": [
      {
        "id": {
          "allocation": "old-timing",
          "ordinal": 0
        },
        "layout": {
          "root": "root",
          "rate": {
            "numerator": 30000,
            "denominator": 1001
          },
          "nodes": {
            "hold": {
              "duration": 6,
              "edges": {
                "node_start": "automatic",
                "node_end": "automatic",
                "source_placement_start": "automatic",
                "source_placement_end": "automatic",
                "repeat_gap_start": "automatic",
                "repeat_gap_end": "automatic"
              },
              "kind": {
                "type": "hold",
                "audio": {
                  "type": "silence"
                }
              }
            },
            "root": {
              "duration": 6,
              "edges": {
                "node_start": "automatic",
                "node_end": "automatic",
                "source_placement_start": "automatic",
                "source_placement_end": "automatic",
                "repeat_gap_start": "automatic",
                "repeat_gap_end": "automatic"
              },
              "kind": {
                "type": "sequence",
                "children": [
                  "hold"
                ]
              }
            }
          },
          "overrides": {}
        }
      }
    ],
    "bindings": {
      "copy": {
        "lattice": {
          "reference": {
            "timing": {
              "allocation": "old-timing",
              "ordinal": 0
            },
            "root": {
              "type": "project_root_round_even"
            },
            "physical": "hold"
          },
          "arguments": [],
          "births": []
        },
        "resume": {
          "local_boundary": {
            "numerator": "1",
            "denominator": "1"
          },
          "phase": {
            "constant": {
              "numerator": "1",
              "denominator": "7"
            },
            "terms": [
              {
                "placement": {
                  "reference": {
                    "timing": {
                      "allocation": "old-timing",
                      "ordinal": 0
                    },
                    "root": {
                      "type": "project_root_round_even"
                    },
                    "physical": "hold"
                  },
                  "arguments": [],
                  "births": []
                },
                "from_local": {
                  "numerator": "0",
                  "denominator": "1"
                },
                "to_local": {
                  "numerator": "1",
                  "denominator": "1"
                }
              }
            ]
          }
        }
      },
      "hold": {
        "lattice": {
          "reference": {
            "timing": {
              "allocation": "old-timing",
              "ordinal": 0
            },
            "root": {
              "type": "project_root_round_even"
            },
            "physical": "hold"
          },
          "arguments": [],
          "births": []
        },
        "resume": {
          "local_boundary": {
            "numerator": "1",
            "denominator": "1"
          },
          "phase": {
            "constant": {
              "numerator": "1",
              "denominator": "7"
            },
            "terms": [
              {
                "placement": {
                  "reference": {
                    "timing": {
                      "allocation": "old-timing",
                      "ordinal": 0
                    },
                    "root": {
                      "type": "project_root_round_even"
                    },
                    "physical": "hold"
                  },
                  "arguments": [],
                  "births": []
                },
                "from_local": {
                  "numerator": "0",
                  "denominator": "1"
                },
                "to_local": {
                  "numerator": "1",
                  "denominator": "1"
                }
              }
            ]
          }
        }
      }
    }
  }
}
');
INSERT INTO "revisions" VALUES('redo-name','undo-name','redo','{
  "schema_version": 16,
  "project_id": "pause-project",
  "revision_id": "redo-name",
  "presentation_basis": {
    "width": 16,
    "height": 16,
    "frame_rate": {
      "numerator": 30000,
      "denominator": 1001
    },
    "color_policy": "sdr_rec709"
  },
  "basis_state": {
    "rate_origin": "explicit",
    "geometry_origin": "explicit",
    "primary": null
  },
  "root": "root",
  "nodes": {
    "copy": {
      "label": "Renamed right hold",
      "kind": {
        "type": "hold",
        "recipe": {
          "duration": 6,
          "video": {
            "type": "background"
          },
          "audio": {
            "type": "silence"
          }
        }
      }
    },
    "hold": {
      "label": "Original hold",
      "kind": {
        "type": "hold",
        "recipe": {
          "duration": 6,
          "video": {
            "type": "background"
          },
          "audio": {
            "type": "silence"
          }
        }
      }
    },
    "left": {
      "label": "Original hold",
      "kind": {
        "type": "retime",
        "child": "hold",
        "duration": 2,
        "mapping": {
          "start": 0,
          "end": 2
        },
        "pitch": "preserve",
        "purpose": "partition"
      }
    },
    "right": {
      "label": "Original hold",
      "kind": {
        "type": "retime",
        "child": "copy",
        "duration": 4,
        "mapping": {
          "start": 2,
          "end": 6
        },
        "pitch": "preserve",
        "purpose": "partition"
      }
    },
    "root": {
      "label": "Root",
      "kind": {
        "type": "sequence",
        "children": [
          "left",
          "right"
        ]
      }
    }
  },
  "assets": {},
  "marks": {},
  "overrides": {},
  "audio_lineage": {
    "copy": {
      "allocation": "split",
      "origin": "hold"
    },
    "hold": {
      "allocation": "split",
      "origin": "hold"
    }
  },
  "audio_bindings": {
    "timings": [
      {
        "id": {
          "allocation": "old-timing",
          "ordinal": 0
        },
        "layout": {
          "root": "root",
          "rate": {
            "numerator": 30000,
            "denominator": 1001
          },
          "nodes": {
            "hold": {
              "duration": 6,
              "edges": {
                "node_start": "automatic",
                "node_end": "automatic",
                "source_placement_start": "automatic",
                "source_placement_end": "automatic",
                "repeat_gap_start": "automatic",
                "repeat_gap_end": "automatic"
              },
              "kind": {
                "type": "hold",
                "audio": {
                  "type": "silence"
                }
              }
            },
            "root": {
              "duration": 6,
              "edges": {
                "node_start": "automatic",
                "node_end": "automatic",
                "source_placement_start": "automatic",
                "source_placement_end": "automatic",
                "repeat_gap_start": "automatic",
                "repeat_gap_end": "automatic"
              },
              "kind": {
                "type": "sequence",
                "children": [
                  "hold"
                ]
              }
            }
          },
          "overrides": {}
        }
      }
    ],
    "bindings": {
      "copy": {
        "lattice": {
          "reference": {
            "timing": {
              "allocation": "old-timing",
              "ordinal": 0
            },
            "root": {
              "type": "project_root_round_even"
            },
            "physical": "hold"
          },
          "arguments": [],
          "births": []
        },
        "resume": {
          "local_boundary": {
            "numerator": "1",
            "denominator": "1"
          },
          "phase": {
            "constant": {
              "numerator": "1",
              "denominator": "7"
            },
            "terms": [
              {
                "placement": {
                  "reference": {
                    "timing": {
                      "allocation": "old-timing",
                      "ordinal": 0
                    },
                    "root": {
                      "type": "project_root_round_even"
                    },
                    "physical": "hold"
                  },
                  "arguments": [],
                  "births": []
                },
                "from_local": {
                  "numerator": "0",
                  "denominator": "1"
                },
                "to_local": {
                  "numerator": "1",
                  "denominator": "1"
                }
              }
            ]
          }
        }
      },
      "hold": {
        "lattice": {
          "reference": {
            "timing": {
              "allocation": "old-timing",
              "ordinal": 0
            },
            "root": {
              "type": "project_root_round_even"
            },
            "physical": "hold"
          },
          "arguments": [],
          "births": []
        },
        "resume": {
          "local_boundary": {
            "numerator": "1",
            "denominator": "1"
          },
          "phase": {
            "constant": {
              "numerator": "1",
              "denominator": "7"
            },
            "terms": [
              {
                "placement": {
                  "reference": {
                    "timing": {
                      "allocation": "old-timing",
                      "ordinal": 0
                    },
                    "root": {
                      "type": "project_root_round_even"
                    },
                    "physical": "hold"
                  },
                  "arguments": [],
                  "births": []
                },
                "from_local": {
                  "numerator": "0",
                  "denominator": "1"
                },
                "to_local": {
                  "numerator": "1",
                  "denominator": "1"
                }
              }
            ]
          }
        }
      }
    }
  }
}
');
INSERT INTO "revisions" VALUES('pending-redo','redo-name','undo','{
  "schema_version": 16,
  "project_id": "pause-project",
  "revision_id": "pending-redo",
  "presentation_basis": {
    "width": 16,
    "height": 16,
    "frame_rate": {
      "numerator": 30000,
      "denominator": 1001
    },
    "color_policy": "sdr_rec709"
  },
  "basis_state": {
    "rate_origin": "explicit",
    "geometry_origin": "explicit",
    "primary": null
  },
  "root": "root",
  "nodes": {
    "copy": {
      "label": "Original hold",
      "kind": {
        "type": "hold",
        "recipe": {
          "duration": 6,
          "video": {
            "type": "background"
          },
          "audio": {
            "type": "silence"
          }
        }
      }
    },
    "hold": {
      "label": "Original hold",
      "kind": {
        "type": "hold",
        "recipe": {
          "duration": 6,
          "video": {
            "type": "background"
          },
          "audio": {
            "type": "silence"
          }
        }
      }
    },
    "left": {
      "label": "Original hold",
      "kind": {
        "type": "retime",
        "child": "hold",
        "duration": 2,
        "mapping": {
          "start": 0,
          "end": 2
        },
        "pitch": "preserve",
        "purpose": "partition"
      }
    },
    "right": {
      "label": "Original hold",
      "kind": {
        "type": "retime",
        "child": "copy",
        "duration": 4,
        "mapping": {
          "start": 2,
          "end": 6
        },
        "pitch": "preserve",
        "purpose": "partition"
      }
    },
    "root": {
      "label": "Root",
      "kind": {
        "type": "sequence",
        "children": [
          "left",
          "right"
        ]
      }
    }
  },
  "assets": {},
  "marks": {},
  "overrides": {},
  "audio_lineage": {
    "copy": {
      "allocation": "split",
      "origin": "hold"
    },
    "hold": {
      "allocation": "split",
      "origin": "hold"
    }
  },
  "audio_bindings": {
    "timings": [
      {
        "id": {
          "allocation": "old-timing",
          "ordinal": 0
        },
        "layout": {
          "root": "root",
          "rate": {
            "numerator": 30000,
            "denominator": 1001
          },
          "nodes": {
            "hold": {
              "duration": 6,
              "edges": {
                "node_start": "automatic",
                "node_end": "automatic",
                "source_placement_start": "automatic",
                "source_placement_end": "automatic",
                "repeat_gap_start": "automatic",
                "repeat_gap_end": "automatic"
              },
              "kind": {
                "type": "hold",
                "audio": {
                  "type": "silence"
                }
              }
            },
            "root": {
              "duration": 6,
              "edges": {
                "node_start": "automatic",
                "node_end": "automatic",
                "source_placement_start": "automatic",
                "source_placement_end": "automatic",
                "repeat_gap_start": "automatic",
                "repeat_gap_end": "automatic"
              },
              "kind": {
                "type": "sequence",
                "children": [
                  "hold"
                ]
              }
            }
          },
          "overrides": {}
        }
      }
    ],
    "bindings": {
      "copy": {
        "lattice": {
          "reference": {
            "timing": {
              "allocation": "old-timing",
              "ordinal": 0
            },
            "root": {
              "type": "project_root_round_even"
            },
            "physical": "hold"
          },
          "arguments": [],
          "births": []
        },
        "resume": {
          "local_boundary": {
            "numerator": "1",
            "denominator": "1"
          },
          "phase": {
            "constant": {
              "numerator": "1",
              "denominator": "7"
            },
            "terms": [
              {
                "placement": {
                  "reference": {
                    "timing": {
                      "allocation": "old-timing",
                      "ordinal": 0
                    },
                    "root": {
                      "type": "project_root_round_even"
                    },
                    "physical": "hold"
                  },
                  "arguments": [],
                  "births": []
                },
                "from_local": {
                  "numerator": "0",
                  "denominator": "1"
                },
                "to_local": {
                  "numerator": "1",
                  "denominator": "1"
                }
              }
            ]
          }
        }
      },
      "hold": {
        "lattice": {
          "reference": {
            "timing": {
              "allocation": "old-timing",
              "ordinal": 0
            },
            "root": {
              "type": "project_root_round_even"
            },
            "physical": "hold"
          },
          "arguments": [],
          "births": []
        },
        "resume": {
          "local_boundary": {
            "numerator": "1",
            "denominator": "1"
          },
          "phase": {
            "constant": {
              "numerator": "1",
              "denominator": "7"
            },
            "terms": [
              {
                "placement": {
                  "reference": {
                    "timing": {
                      "allocation": "old-timing",
                      "ordinal": 0
                    },
                    "root": {
                      "type": "project_root_round_even"
                    },
                    "physical": "hold"
                  },
                  "arguments": [],
                  "births": []
                },
                "from_local": {
                  "numerator": "0",
                  "denominator": "1"
                },
                "to_local": {
                  "numerator": "1",
                  "denominator": "1"
                }
              }
            ]
          }
        }
      }
    }
  }
}
');
CREATE TABLE single_source (
            singleton INTEGER PRIMARY KEY CHECK(singleton=1),
            profile TEXT NOT NULL CHECK(json_valid(profile)),
            baseline_history INTEGER REFERENCES history(id)
        ) STRICT;
CREATE TABLE source_qualifications (
            id TEXT PRIMARY KEY,
            original_content_id TEXT NOT NULL REFERENCES original_media(content_id),
            original_ref TEXT NOT NULL CHECK(json_valid(original_ref)),
            snapshot BLOB NOT NULL
        ) STRICT;
CREATE TABLE state (
            singleton INTEGER PRIMARY KEY CHECK (singleton=1),
            head_revision TEXT NOT NULL REFERENCES revisions(id),
            cursor INTEGER REFERENCES history(id),
            workflow TEXT NOT NULL DEFAULT 'generic' CHECK(workflow IN ('generic','single_source_v1'))
        ) STRICT;
INSERT INTO "state" VALUES(1,'pending-redo',1,'generic');
CREATE INDEX revision_parent ON revisions(parent_id);
CREATE INDEX history_revision ON history(revision_id);
CREATE UNIQUE INDEX one_current_generation_per_hold
    ON generation_requests(hold_id) WHERE relevance='current';
CREATE UNIQUE INDEX one_nonterminal_generation_attempt_per_request
    ON generation_attempts(request_id)
    WHERE state IN ('queued','preflight','loading','running','validating','cancelling');
COMMIT;
