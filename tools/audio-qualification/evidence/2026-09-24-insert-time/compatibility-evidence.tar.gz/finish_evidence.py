from pathlib import Path
import hashlib
import importlib.util
import json
import sqlite3
import tarfile

root = Path('/tmp/deadpan-db22-binary-20260924')
spec = importlib.util.spec_from_file_location('qualification', root / 'qualify.py')
qualification = importlib.util.module_from_spec(spec)
# The qualification script dispatches at module scope, so reuse definitions only.
source = (root / 'qualify.py').read_text().split("\nif sys.argv[1] == 'baseline':", 1)[0]
exec(compile(source, str(root / 'qualify.py'), 'exec'), qualification.__dict__)
old = json.loads((root / 'baseline-ledger.json').read_text())
initial = next(row[3] for row in old['documents'] if row[0] == 'initial')
resume = initial['audio_bindings']['bindings']['hold']['resume']
assert resume['local_boundary'] == {'numerator': '1', 'denominator': '1'}
assert resume['phase']['constant'] == {'numerator': '1', 'denominator': '7'}
assert len(resume['phase']['terms']) == 1
term = resume['phase']['terms'][0]
assert term['from_local'] == {'numerator': '0', 'denominator': '1'}
assert term['to_local'] == {'numerator': '1', 'denominator': '1'}
backup = next((root / 'migrated-v23.deadpan/Snapshots').glob('before-schema-23-*.sqlite'))
with sqlite3.connect(f'file:{backup}?mode=ro', uri=True) as db:
    assert db.execute('PRAGMA user_version').fetchone()[0] == 22
windows = [(1580, 1644), (3180, 3244), (9536, 9600)]
for start, end in windows:
    for stage in ['time-mapped', 'edge-faded']:
        outputs = []
        for name, package, binary in [('baseline', 'baseline-v22.deadpan', 'target/debug'), ('current', 'migrated-v23.deadpan', 'current-bin')]:
            label = f'{name}-{stage}-{start}-{end}'
            outputs.append(qualification.run(label, ['deadpan-cli', 'inspect-audio', str(root / package), '--samples', str(start), str(end), '--' + stage], root / binary))
        assert outputs[0] == outputs[1], (start, end, stage)
provenance = json.loads((root / 'provenance.json').read_text())
provenance['retained_backup_database_schema'] = 22
provenance['baseline_build']['exit_code'] = 0
provenance['binding_fixture_assertions'] = {'resume_boundary': '1', 'phase_constant': '1/7', 'term_from_local': '0', 'term_to_local': '1'}
provenance['additional_matching_raw_and_faded_sample_windows'] = windows
provenance['audio_fixture_limit'] = 'SilentHold PCM; verifies compatibility and binding admission, not nonzero DSP behavior.'
provenance['discarded_initial_build']['reason'] = 'Login shell resolved bare Cargo/rustc to Homebrew 1.98.0. Discarded initial build; qualified rebuild explicitly prefixed rustup shims in PATH and selected RUSTUP_TOOLCHAIN=1.97.1.'
qualification.save('provenance.json', provenance)
readme = '''# DB22 baseline binary compatibility qualification

Passed on 2026-09-24. No shared repository source or target files were changed.

The old executable was rebuilt now from commit 7277f29fe1ae96df5900d8871435f9961f697869, not retrieved as an archived shipped binary. All 2,127 tracked files were hash-verified against that commit's git archive. Only a scratch fixture-producer example was added. The qualified build used Rust 1.97.1, locked offline dependencies, the existing selected FFmpeg prefix, and a separate Cargo target. An initial accidental Homebrew Rust 1.98 build was discarded and is disclosed in provenance.json.

The producer used the baseline core/store APIs without schema-tag rewriting or direct SQL mutation. It created a DB22/core16 six-frame SilentHold with a nonzero resume at local 1, phase constant 1/7, and a nonzero placement phase term from 0 to 1. It then committed Split and Rename and performed undo/redo/undo, retaining six revision documents, two history transactions and pending redo.

The baseline CLI opened, validated and dumped the project. The current CLI migrated a closed copy to DB23/core17 and opened, validated and dumped it. Every revision document, request, edit, state row, redo row and table definition matched except the intended schema tags. The retained migration backup has DB version 22 and its SQL dump exactly matches the original. The original baseline package remains unchanged.

Actual time-mapped and edge-faded CLI PCM reads match exactly for windows [0,64), [1580,1644), [3180,3244), and [9536,9600). This SilentHold fixture verifies compatibility and binding admission, not nonzero DSP behavior.

Build command (cwd baseline):

```sh
PATH=/Users/michael/.cargo/bin:$PATH RUSTUP_TOOLCHAIN=1.97.1 DEADPAN_FFMPEG_PREFIX=/tmp/deadpan-media-compatible-xyhilms4/prefix CARGO_TARGET_DIR=/tmp/deadpan-db22-binary-20260924/target cargo build -p deadpan-cli -p deadpan-store --bin deadpan-cli --example create_v22_fixture --locked --offline
```

Qualification commands:

```sh
python3 /tmp/deadpan-db22-binary-20260924/qualify.py baseline
python3 /tmp/deadpan-db22-binary-20260924/qualify.py current /Users/michael/Code/deadpan/target/debug/deadpan-cli
python3 /tmp/deadpan-db22-binary-20260924/finish_evidence.py
```

See commands.jsonl for each exact CLI invocation, resolved executable hash, UTC timestamp and exit code. See provenance.json for compiler versions, source archive and binary/database hashes. The two project packages, producer source, SQL/history ledgers, scripts and captured CLI outputs are included. Rebuilt binaries, source tree and Cargo cache remain in the scratch directory but are excluded from this compact evidence archive.
'''
(root / 'README.md').write_text(readme)
archive = root / 'compatibility-evidence.tar.gz'
with tarfile.open(archive, 'w:gz') as out:
    for path in sorted(root.iterdir()):
        if path.is_file() and path.suffix not in ['.tar', '.gz'] and path.name != 'compatibility-evidence.sha256':
            out.add(path, arcname=path.name)
    for name in ['baseline-v22.deadpan', 'migrated-v23.deadpan']:
        out.add(root / name, arcname=name)
hash_value = qualification.sha(archive)
(root / 'compatibility-evidence.sha256').write_text(hash_value + '  compatibility-evidence.tar.gz\n')
print(json.dumps({'archive': str(archive), 'sha256': hash_value, 'bytes': archive.stat().st_size, 'additional_windows_passed': windows, 'backup_schema': 22}, indent=2))
