from pathlib import Path
import datetime
import hashlib
import json
import os
import shutil
import sqlite3
import subprocess
import sys
import tarfile

ROOT = Path('/tmp/deadpan-db22-binary-20260924')


def sha(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def save(name, value):
    (ROOT / name).write_text(json.dumps(value, indent=2, sort_keys=True) + '\n')


def run(label, args, directory):
    env = os.environ.copy()
    env['PATH'] = str(directory) + os.pathsep + env['PATH']
    executable = shutil.which(args[0], path=env['PATH'])
    started = datetime.datetime.now(datetime.timezone.utc).isoformat()
    result = subprocess.run(args, env=env, capture_output=True, text=True, timeout=60)
    (ROOT / (label + '.stdout')).write_text(result.stdout)
    (ROOT / (label + '.stderr')).write_text(result.stderr)
    entry = dict(label=label, args=args, executable=executable,
                 executable_sha256=sha(executable), started_utc=started,
                 exit_code=result.returncode)
    with (ROOT / 'commands.jsonl').open('a') as stream:
        stream.write(json.dumps(entry, sort_keys=True) + '\n')
    if result.returncode:
        raise RuntimeError(f'{label}: exit {result.returncode}: {result.stderr}')
    return json.loads(result.stdout)


def ledger(package):
    db = sqlite3.connect(f'file:{package / "project.sqlite"}?mode=ro', uri=True)
    try:
        docs = [(identity, parent, kind, json.loads(document)) for identity, parent, kind, document in
                db.execute('SELECT id,parent_id,kind,document FROM revisions ORDER BY id')]
        history = [(identity, parent, revision, json.loads(request), json.loads(edit)) for identity, parent, revision, request, edit in
                   db.execute('SELECT id,parent_id,revision_id,request,edit FROM history ORDER BY id')]
        return dict(version=db.execute('PRAGMA user_version').fetchone()[0],
                    documents=docs, history=history,
                    state=db.execute('SELECT * FROM state').fetchall(),
                    redo=db.execute('SELECT * FROM redo ORDER BY position').fetchall(),
                    tables=db.execute("SELECT name,sql FROM sqlite_master WHERE type='table' ORDER BY name").fetchall())
    finally:
        db.close()


def baseline():
    with tarfile.open(ROOT / 'baseline.tar') as archive:
        checked = 0
        for entry in archive:
            if entry.isfile():
                expected = hashlib.sha256(archive.extractfile(entry).read()).hexdigest()
                assert sha(ROOT / 'baseline' / entry.name) == expected, entry.name
                checked += 1
    package = ROOT / 'baseline-v22.deadpan'
    produced = run('baseline-produce', ['create_v22_fixture', str(package)], ROOT / 'target/debug/examples')
    assert produced['core_schema'] == 16 and produced['database_schema'] == 22
    binary_dir = ROOT / 'target/debug'
    run('baseline-doctor', ['deadpan-cli', 'doctor'], binary_dir)
    run('baseline-validate', ['deadpan-cli', 'project', 'validate', str(package)], binary_dir)
    document = run('baseline-dump', ['deadpan-cli', 'project', 'dump', str(package), '--json'], binary_dir)
    assert document == produced['document']
    run('baseline-audio', ['deadpan-cli', 'inspect-audio', str(package), '--samples', '0', '64', '--time-mapped'], binary_dir)
    run('baseline-faded', ['deadpan-cli', 'inspect-audio', str(package), '--samples', '0', '64', '--edge-faded'], binary_dir)
    old = ledger(package)
    assert old['version'] == 22
    assert len(old['documents']) == 6 and len(old['history']) == 2 and old['redo']
    assert all(row[3]['schema_version'] == 16 for row in old['documents'])
    save('baseline-ledger.json', old)
    db = sqlite3.connect(f'file:{package / "project.sqlite"}?mode=ro', uri=True)
    try:
        (ROOT / 'baseline-v22.sql').write_text('\n'.join(db.iterdump()) + '\n')
    finally:
        db.close()
    provenance = json.loads((ROOT / 'provenance.json').read_text())
    provenance.update(tracked_files_verified_against_git_archive=checked,
                      baseline_cli_sha256=sha(binary_dir / 'deadpan-cli'),
                      producer_binary_sha256=sha(ROOT / 'target/debug/examples/create_v22_fixture'),
                      baseline_database_sha256=sha(package / 'project.sqlite'),
                      baseline_sql_sha256=sha(ROOT / 'baseline-v22.sql'),
                      baseline_qualified=True)
    save('provenance.json', provenance)
    print(json.dumps(provenance, indent=2))


def current(binary):
    baseline_package = ROOT / 'baseline-v22.deadpan'
    package = ROOT / 'migrated-v23.deadpan'
    shutil.copytree(baseline_package, package)
    current_dir = ROOT / 'current-bin'
    current_dir.mkdir(exist_ok=True)
    shutil.copy2(binary, current_dir / 'deadpan-cli')
    before = ledger(package)
    run('current-doctor', ['deadpan-cli', 'doctor'], current_dir)
    migration = run('current-migrate', ['deadpan-cli', 'project', 'migrate', str(package)], current_dir)
    run('current-validate', ['deadpan-cli', 'project', 'validate', str(package)], current_dir)
    document = run('current-dump', ['deadpan-cli', 'project', 'dump', str(package), '--json'], current_dir)
    audio = run('current-audio', ['deadpan-cli', 'inspect-audio', str(package), '--samples', '0', '64', '--time-mapped'], current_dir)
    faded = run('current-faded', ['deadpan-cli', 'inspect-audio', str(package), '--samples', '0', '64', '--edge-faded'], current_dir)
    old_document = json.loads((ROOT / 'baseline-dump.stdout').read_text())
    old_document['schema_version'] = 17
    assert document == old_document
    assert audio == json.loads((ROOT / 'baseline-audio.stdout').read_text())
    assert faded == json.loads((ROOT / 'baseline-faded.stdout').read_text())
    after = ledger(package)
    expected = json.loads(json.dumps(before))
    expected['version'] = 23
    for row in expected['documents']:
        row[3]['schema_version'] = 17
    assert json.loads(json.dumps(after)) == expected
    backups = list((package / 'Snapshots').glob('before-schema-23-*.sqlite'))
    assert len(backups) == 1
    backup_db = sqlite3.connect(f'file:{backups[0]}?mode=ro', uri=True)
    try:
        backup_sql = '\n'.join(backup_db.iterdump()) + '\n'
        assert backup_sql == (ROOT / 'baseline-v22.sql').read_text()
    finally:
        backup_db.close()
    assert ledger(baseline_package) == before
    save('current-ledger.json', after)
    provenance = json.loads((ROOT / 'provenance.json').read_text())
    provenance.update(current_cli_source_path=str(binary),
                      current_cli_sha256=sha(current_dir / 'deadpan-cli'),
                      migrated_database_sha256=sha(package / 'project.sqlite'),
                      migration=migration,
                      all_documents_history_state_redo_and_tables_preserved=True,
                      only_schema_tags_changed=["database22_to23", "core16_to17"],
                      raw_and_faded_audio_equal=True,
                      retained_backup_dump_identical=True,
                      current_qualified=True)
    save('provenance.json', provenance)
    print(json.dumps(provenance, indent=2))


if sys.argv[1] == 'baseline':
    baseline()
elif sys.argv[1] == 'current':
    current(Path(sys.argv[2]))
else:
    raise SystemExit('baseline or current <CLI path> required')
