from pathlib import Path
import subprocess,json
b=Path('/tmp/deadpan-blaze-2026-10-26')
p=Path('src/main.rs')
s=p.read_text();assert 'assert_eq!(super::value(),7)' in s
s=s.replace('assert_eq!(super::value(),7)','assert_eq!(super::value(),13)')
p.write_text(s)
def run(label,args,expected=0):
 code=subprocess.call(['python',str(b/'run.py'),label,*args])
 if (expected==0 and code!=0) or (expected!=0 and code==0):raise SystemExit('unexpected result '+label)
run('probe-tests',['blaze','test','--locked'])
s+='\n#[test]\nfn newly_added_test_is_not_stale() { assert_eq!(value(),13); }\n'
p.write_text(s)
run('probe-new-test',['blaze','test','--locked'])
p.write_text(s+'\nfn invalid_borrow_probe() { let mut xs=vec![1]; let head=&xs[0]; xs.push(2); std::hint::black_box(head); }\n')
run('probe-borrow-blaze',['blaze','test','--locked','--no-run'],101)
run('probe-borrow-cargo',['cargo','+nightly-2026-10-25','test','--locked','--no-run'],101)
p.write_text(s)
print('Probe restored to valid source after expected borrow refusals')
