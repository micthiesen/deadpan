from pathlib import Path
import subprocess
b=Path('/tmp/deadpan-blaze-2026-10-26')
p=Path('crates/deadpan-core/src/exact.rs')
def run(label,cmd):
 if subprocess.call(['python',str(b/'run.py'),label,*cmd]):raise SystemExit(1)
old='self.numerator.checked_div_euclid(self.denominator).expect("validated positive denominator")'
for i,new in enumerate(['{ let numerator = self.numerator; numerator.div_euclid(self.denominator) }','{ let denominator = self.denominator; self.numerator.div_euclid(denominator) }'],2):
 s=p.read_text();assert s.count(old)==1;p.write_text(s.replace(old,new));old=new
 for engine,target in [('cargo','target-cargo'),('blaze','target-blaze')]:
  cmd=[engine]+(['+1.97.1'] if engine=='cargo' else [])+['test','--locked','-p','deadpan-core','--lib','--no-run','--target-dir',str(b/target)]
  run(f'core-{engine}-body-{i}',cmd)
