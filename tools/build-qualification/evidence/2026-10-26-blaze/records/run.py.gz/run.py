import hashlib,json,os,resource,subprocess,sys,time
from datetime import datetime,timezone
from pathlib import Path
base=Path(__file__).resolve().parent
label=sys.argv[1]; command=sys.argv[2:]
assert label.replace('-','').isalnum() and command
receipt=base/(label+'.json')
assert not receipt.exists()
r={'command':command,'cwd':os.getcwd(),'started_at':datetime.now(timezone.utc).isoformat(),'environment':{k:v for k,v in os.environ.items() if k.startswith(('CARGO_','RUSTUP_','DEADPAN_','BLAZE_','RA_JIT_'))}}
receipt.write_text(json.dumps(r,indent=2)+'\n')
start=time.monotonic()
with (base/(label+'.stdout')).open('xb') as out,(base/(label+'.stderr')).open('xb') as err:
 p=subprocess.Popen(command,stdout=out,stderr=err)
 r['pid']=p.pid; receipt.write_text(json.dumps(r,indent=2)+'\n')
 code=p.wait()
r.update(exit_code=code,seconds=time.monotonic()-start,finished_at=datetime.now(timezone.utc).isoformat(),maxrss_bytes=resource.getrusage(resource.RUSAGE_CHILDREN).ru_maxrss)
r['streams']={}
for ext in ['stdout','stderr']:
 path=base/(label+'.'+ext);data=path.read_bytes()
 r['streams'][ext]={'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}
receipt.write_text(json.dumps(r,indent=2)+'\n')
print(json.dumps({k:r[k] for k in ['exit_code','seconds','maxrss_bytes']}),flush=True)
sys.exit(code)
