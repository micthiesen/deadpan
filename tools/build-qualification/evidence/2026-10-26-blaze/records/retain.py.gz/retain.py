from pathlib import Path
import json,gzip,hashlib
b=Path('/tmp/deadpan-blaze-2026-10-26')
out=Path('/Users/michael/Code/deadpan/tools/build-qualification/evidence/2026-10-26-blaze')
assert not out.exists()
files=[]
def add(src,rel):
 raw=src.read_bytes(); data=gzip.compress(raw,mtime=0)
 q=out/(rel+'.gz');q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(data)
 files.append({'path':str(q.relative_to(out)),'source':str(src),'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest(),'expanded_bytes':len(raw),'expanded_sha256':hashlib.sha256(raw).hexdigest()})
for p in sorted(b.iterdir()):
 if p.is_file() and p.suffix in ['.json','.stdout','.stderr','.log','.patch','.txt','.py']:
  add(p,'records/'+p.name)
add(b/'native-replay/report.json','native-replay/report.json')
for p in sorted((b/'source-untracked').rglob('*')):
 if p.is_file():add(p,'source-wip/'+str(p.relative_to(b/'source-untracked')))
raw=(json.dumps({'schema_version':1,'files':files},indent=2)+'\n').encode()
(out/'inventory.json').write_bytes(raw)
digest=hashlib.sha256(raw).hexdigest();(out/'inventory.sha256').write_text(digest+'  inventory.json\n')
for row in files:
 data=(out/row['path']).read_bytes();assert len(data)==row['bytes'] and hashlib.sha256(data).hexdigest()==row['sha256']
 raw=gzip.decompress(data);assert len(raw)==row['expanded_bytes'] and hashlib.sha256(raw).hexdigest()==row['expanded_sha256']
print(json.dumps({'payloads':len(files),'stored_bytes':sum(f['bytes'] for f in files),'inventory_sha256':digest}))
