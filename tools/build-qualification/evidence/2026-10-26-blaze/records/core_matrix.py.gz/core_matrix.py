from pathlib import Path
import subprocess,sys
base=Path('/tmp/deadpan-blaze-2026-10-26')
def run(label,args):
 code=subprocess.call(['python',str(base/'run.py'),label,*args])
 if code: raise SystemExit(code)
cargo=['cargo','+1.97.1','test','--locked','-p','deadpan-core','--lib','--no-run','--target-dir',str(base/'target-cargo')]
blaze=['blaze','test','--locked','-p','deadpan-core','--lib','--no-run','--target-dir',str(base/'target-blaze')]
run('core-cargo-warm',cargo)
run('core-blaze-warm',blaze)
p=Path('crates/deadpan-core/src/exact.rs');s=p.read_text()
old='self.numerator.div_euclid(self.denominator)'
new='self.numerator.checked_div_euclid(self.denominator).expect("validated positive denominator")'
assert s.count(old)==1
(base/'core-floor-before.rs').write_text(s)
p.write_text(s.replace(old,new))
run('core-cargo-body',cargo)
run('core-blaze-body',blaze)
run('core-blaze-tests',['blaze','test','--locked','-p','deadpan-core','--lib','sound_clock::retime::tests','--target-dir',str(base/'target-blaze')])
run('core-cargo-tests',['cargo','+1.97.1','test','--locked','-p','deadpan-core','--lib','sound_clock::retime::tests','--target-dir',str(base/'target-cargo')])
