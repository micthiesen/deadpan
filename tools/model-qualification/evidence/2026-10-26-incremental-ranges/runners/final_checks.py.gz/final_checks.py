import os,subprocess,sys
base='/tmp/deadpan-native-incremental-2026-10-26'
steps=[
('joined-strict-fifth',['cargo','clippy','--locked','-p','deadpan-core','-p','deadpan-plan','-p','deadpan-audio','-p','deadpan-analysis','-p','deadpan-media','-p','deadpan-cli','-p','deadpan-app','-p','deadpan-store','--all-targets','--features','deadpan-app/ui-harness','--','-D','warnings']),
('cli-shot-ranges-second',['cargo','test','--locked','-p','deadpan-cli','--lib','shots::incremental::tests']),
('app-transcript-ranges-second',['cargo','test','--locked','-p','deadpan-app','--features','ui-harness','--bin','deadpan-app','preview::transcript::incremental::tests']),
('retime-boundary-proof-second',['cargo','test','--locked','-p','deadpan-core','--lib','sound_clock::retime::tests'])]
for label,cmd in steps:
 code=subprocess.call(['python',base+'/run.py',label,'--',*cmd])
 print(label,code,flush=True)
 if code: sys.exit(code)
